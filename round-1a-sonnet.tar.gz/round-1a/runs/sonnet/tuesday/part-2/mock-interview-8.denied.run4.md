Your prep pack is saved as /var/tmp/tuesday-measure/1a/runs/sonnet/tuesday/part-2/rooms/case-8-denied-c84da25d/ashgrove-credit-union_member-experience-lead_interview_pack.md. I built it in loop mode: a mini-pack for each of the three rounds on 26 November, with the values cheat sheet in the panel round, where the four values are scored. I sent no searches because your pasted values, the recruiter's email and the strategy brief already covered what research would have.

The pack names B2 as its highest-ROI prep. It is the question about your never having worked in a contact centre, which the JD's first line puts at the centre of the role. The pack's answer is to concede it plainly, hold only what your own sentences carry (the complaints log, the escalation script training, the spreadsheet), and give a plan for learning the channel.

Say the word and I'll play the Head of Member Services on B2, with live follow-ups.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Member Experience Lead, Ashgrove Credit Union: interview pack for Dara

Loop mode: three rounds on 26 November 2026 (recruiter, 30 minutes; Head of Member Services and your future manager, 45 minutes; panel of two branch managers, 60 minutes, including a 20-minute complaint-escalation case, also scored against the four values). Interviewers beyond their roles are not yet assigned, so there is no interviewer read.

## How to use this pack

- Personas are how a question arrives: Conversational, Skeptic, Values/Behavioral, Case/Strategist, Data-Driven Prober, Peer Evaluator, Pressure. Types are what is scored.
- Type key: VAL = behaviour against Ashgrove's published values; EXP = whether your own history survives scrutiny; JD = a stated requirement of the role; CO = knowledge of Ashgrove and its strategy; CASE = a live problem.
- Guidance is scaffolding, not a script. Where a cell says Answer slot, it is an instruction for the interview, not a question for me: answer from your own experience, or say plainly that the step was not yours or did not exist.
- Provenance labels: grounded (traceable to your inputs), inferred (derived, derivation named), generic (a pattern, no claim about Ashgrove or you).

## Prep triage (nine days, 17 to 26 November; no hours assumed)

1. Day 1: say your answers to A3 to A6 aloud once, in your own words. They are quick and the recruiter round comes first.
2. Days 1 to 3: B2 until it is boring. It is the highest-ROI prep in this pack.
3. Days 2 to 3: know your spreadsheet and your complaints log cold (E1, E2, E3).
4. Days 3 to 6: pick a real story for each of C5 to C8, or settle on the honest branch for it. The panel scores against all four values.
5. Days 5 to 8: run D2 to D4 aloud against a 20-minute timer.
6. Day 7: B4 and G1, the presenting and the contact-centre challenges under time pressure.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD (branch side) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says one branch's log and training, not a process across branches, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what sat around the log likely. If you dealt with any step before an entry reached the log or after it closed, say which and what you did, in your own words; if the log was where your part began and ended, say so plainly and stay with the log you handled |
| F2 | "Own the member complaints process end to end across branches and the contact centre" — JD (contact-centre side) | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | Your material says a monthly complaints spreadsheet your regional manager uses; it does not show what the sheet counted. Answer slot: expect 'what did it show, and how were the figures counted?'. Say what it showed in your own words; for any figure on it, say how it was counted and the assumption you would defend least; if you do not know how a figure was counted, say so plainly |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says new tellers, not supervisors, and the words stay there: "I trained new tellers on our escalation script." Answer slot: expect a probe on what the training involved. If you followed it up with the tellers afterwards, say how; if it was a single session or the script was not yours to adapt, say so plainly and stay with the tellers |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | The material does not show it either way. Answer slot: if you have worked with any digital or online-banking team, say what and what part was yours; if not, say so plainly and say what you would look for in complaint data to take to a digital team, as a plan |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe on the supervisor years. Lead in the quote's own terms: six years in retail banking, the last three as a branch supervisor. The JD says customer operations; your words stay retail banking |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [inferred] | discovery | Your material says a formal complaints log; it does not show whether any of those cases were subject to outside rules, and the words stay at the quote: "I handled the branch's formal complaints log." Answer slot: expect a probe on what handling the log involved. Say what you did with it, in your own words; if a step was not yours, say so plainly and stay with the log |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Then how you would prepare a first senior readout, said as a plan and never as a past |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | presentation | Lead with the quote in its own terms: you built the monthly complaints spreadsheet, and your regional manager uses it. Your material says spreadsheet, not a named tool, so the words stay at spreadsheet; the tool's name is yours to give if asked, in your own words |

The JD sets no pay, location, authorisation or credential term, so there is no gate row. The four-years line is a length-of-experience requirement, not a gate.

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Own the complaints process end to end across branches and the contact centre | B1, B2, D2, D3 |
| Report monthly on complaint volumes and resolution times | E1, D1 |
| Coach branch supervisors on escalations | C3, E3, F1 |
| Work with digital teams on self-service journeys | A7, C4, D1 |
| 4+ years in financial-services customer operations | A1 |
| Experience handling regulated complaints | E2 |
| Confident presenting to senior leaders | B4, C1 |
| Comfortable with Excel reporting | E1 |

## Grounding brief

| Fact from the 2026 strategy brief | Source | What it means for your answers |
|---|---|---|
| 40% of member service to move to digital channels by 2028 | Strategy brief, July 2026, as you relayed it | Feeds A7, D1. The JD's digital-teams line (F5) is where this lands in the role. Provenance: inferred |
| Eight branches to consolidate into five hubs over 2027 | Strategy brief, July 2026, as you relayed it | The branch-manager panel may have a stake in this; keep answers about members, not about whether the plan is right (C7, F2). Provenance: inferred |
| Small-business lending product launching in Q1 2027 | Strategy brief, July 2026, as you relayed it | No question rests on it; it is background vocabulary for A2. Provenance: generic |
| Main competitive pressure is app-only banks | Strategy brief, July 2026, as you relayed it | Gives context for why self-service journeys matter (A7, D1). Provenance: inferred |

The brief is four months old, inside the six-month freshness window. I hold your four points, not its full text.

## Sources

Provided documents: the JD you pasted; the values text you copied on 17 November 2026 from ashgrovecu.org/about/values (pasted text, not fetched); the recruiter's email on the three rounds; the 2026 strategy brief as you relayed it; your background message. No searches or fetches were sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values text fixes the values cheat sheet and the four VAL questions, names and wording included |
| 2. `Ashgrove Credit Union interview process member services` | skipped | The recruiter's email fixes the loop: three rounds, who runs each, how long, the 20-minute case and the panel's values scoring. Persona weights follow it |
| 3. `Ashgrove Credit Union strategy` | skipped | The July 2026 brief you relayed fixes the grounding brief and the CO and CASE content |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No interviewer is named yet, so there is no query to form; the upgrade menu says what a name would unlock |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and every JD-tagged question |

---

# Round 1: recruiter screen (30 minutes)

## Persona weights

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly opener, then pay, notice, location, reason for leaving | Dominant. The recruiter-screen prior is Conversational plus a light Skeptic, and nothing in the recruiter's email shifts it | Pre-script the 90-second arc; treat casual questions as scored; use the reverse-question slot |
| Skeptic | A quiet knockout check on the contact-centre line | Light. Same prior; F2 is where the JD and your own words meet | Concede plainly, then the nearest thing your material carries; a plan, not a past |

## Question bank

Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Four beats, each at the quote's scope, in your own words: six years in retail banking; the last three as a branch supervisor; the branch's formal complaints log and training new tellers on the escalation script; the monthly complaints spreadsheet your regional manager uses. Answer slot: close on your own reason for this role in one sentence; I do not supply it | The opening biography is scored even when it feels casual; F6 and F1 are what it rests on. EXP because it tests that your account matches your material |
| A2 | "Why Ashgrove, and why this role?" | CO | [grounded] | Pick one thing from Ashgrove's own words that you can speak to honestly, for example the values page line "Neighbours, Not Numbers — every branch is part of its town" or the strategy brief's 40% digital target, and say why it matters to you. Answer slot: give your actual reason; if the honest reason is mostly the role's scope rather than the employer, say that plainly. One value, one reason; do not recite the page back | Motivation is the recruiter's first consistency check, and the published values give you wording that is Ashgrove's, not generic. CO because it scores homework |
| A3 | "What salary are you looking for?" | JD | [generic] | Logistics slot: give your own figure, or ask what band the role carries before naming one. I supply no figure and no salary history. Say it in one sentence and stop | Pay is asked in nearly every recruiter screen and the only safe answer is yours. JD because it concerns the listed job's terms |
| A4 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period in your own words, and any flexibility you really have | A planning fact the recruiter needs for the loop. JD because it concerns the job's terms |
| A5 | "The role covers branches and the contact centre. Where could you be based, and how would travel between sites work for you?" | JD | [grounded] | Logistics slot: say where you can work and any limits on travelling between sites, in your own words. The brief's eight-to-five-hub plan may change site patterns, so asking the recruiter where the role sits is a fair answer to carry | The JD's branches-and-contact-centre line raises it. JD because it concerns the job's terms |
| A6 | "What's prompting you to look at a move?" | EXP | [generic] | Logistics slot: one honest sentence of your own reason, pointed at what you want rather than at anyone you are leaving. I supply no reason; if the honest one is awkward, say it plainly and briefly rather than substituting a tidier one | Reason for leaving is a standing recruiter-screen question. EXP because it tests consistency with the rest of your story |
| A7 | "What do you make of our move to put 40% of member service on digital channels by 2028?" | CO | [grounded] | State the target as the brief gives it, then give your own view in two sentences, including what you would want kept with a person. Answer slot: the JD's digital-teams line makes a probe on your own contact with digital teams likely. If you have worked with any, say what and what part was yours; if not, say so plainly and stay with your view of the target | The one strategy question a recruiter can ask casually; F5 is the row it presses on. CO because it scores knowledge of the brief |

Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role covers the contact centre as well as branches. Where does your experience sit against that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The short version of B2, which carries the full rehearsal. Say "I haven't worked in a contact centre." Then the nearest thing your material carries: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Then one sentence on what you would want to learn first, as a plan | Recruiters run light knockout checks and F2 is the row this one targets. JD because it scores a stated requirement |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What does the Head of Member Services most want the complaints lead to change in the first six months?" | Shows you think in outcomes, and the recruiter can tell you what the hiring manager has said |
| 2 | "Given the 2027 hub plan, where would the role be based, and how much of it is branch, hub or contact centre?" | Ties to the location question and to the brief, and surfaces whether the role covers the contact centre in practice |
| 3 | "What will the 20-minute escalation case look like, and is there anything to read beforehand?" | A fair preparation question the recruiter can answer in one line |
| 4 | "Who will be on the panel, and does the Head of Member Services have any priorities for this hire?" | Gets the names and priorities that unlock an interviewer read |
| 5 | "How does this role work with the digital team on self-service, and who is the contact?" | Shows you have read the JD's digital line and the 40% target |

---

# Round 2: Head of Member Services, your future manager (45 minutes, mostly behavioural)

## Persona weights

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario prompts, "tell me about a time" | Top. The recruiter says the round is mostly behavioural | Map a story where one of your quoted sentences carries one; where none does, use the selection scaffold and its honest branch. "We" for context, "I" for contribution |
| Skeptic | Quiet probing of the contact-centre and presenting gaps | Second. The hiring-manager prior puts Skeptic near the top; "mostly behavioural" pulls it down, and F2 and F8, both negatives you stated, pull it back up | Rehearse B2 until it is boring; concede plainly, hold what the quotes carry, give a plan |
| Data-Driven Prober | Line-by-line questions on the spreadsheet, the log and the training | Third. Not in the prior; added because the JD's monthly-reporting line (F3, F9) and your own spreadsheet sentence give a manager something to probe | Know what you can and cannot say about how each figure was counted; say plainly when you do not know |
| Case/Strategist | One live problem from the strategy brief | Low. The prior is Case-heavy; "mostly behavioural" reduces it, and one case stays because of the brief's 40% target | Clarify, objective, approach, metrics, risks; think aloud; challenge one premise respectfully |

## Question bank

Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to someone more senior." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something they did not want to hear. It needs a named stake, what you said and how, and an intact relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Do not dress a smaller moment as a bigger one | A standard behavioural stem, and the JD's senior-leaders line (F8) gives it weight for this role. VAL because it scores behaviour, not knowledge |
| C2 | "When have you put a member ahead of a target or an internal process?" | VAL | [grounded] | Selection scaffold, mapped to the value "Members First, Always — we decide from the member's side of the counter": a named member situation, the decision you made, what it cost the process, how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Ashgrove's first published value; a manager who owns member service will test it early. VAL because it scores behaviour against a published value |
| C3 | "Tell me about a time you helped a colleague through a difficult escalation." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: a named colleague's situation, what you did, how it ended. The nearest thing your material carries is "I trained new tellers on our escalation script", which is training on a script, so say it at that scope. If no such time comes to mind, say so plainly, then give the training and how you would go about helping a colleague through an escalation, as a plan | The JD's coach-on-escalations line raises it; F4 is the row it presses on. VAL because it scores behaviour; JD content |
| C4 | "Tell me about a time you worked with a digital or online-banking team." | JD | [grounded] | Selection scaffold: a named member problem you took to that team, what you asked of them, what changed. If no such time comes to mind, say so plainly, then say what you would look for in complaint data to take to a digital team as a self-service problem, as a plan | The JD's digital-teams line raises it; F5 is the row, and silence there is the likeliest place for a manager to probe. JD because it scores a stated requirement |

Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B2 | "You haven't worked in a contact centre, and this role owns complaints there too. Why should we believe you can run that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | The highest-ROI prep in this pack. Four steps. 1) Concede first, with no "but": "I haven't worked in a contact centre." 2) Hold what the quotes carry, at their scope: "I handled the branch's formal complaints log and trained new tellers on our escalation script", and "I built the monthly complaints spreadsheet our regional manager uses." The limit is named before it is asked for: your material shows one branch, so the ceiling for this answer is the log, the script and the spreadsheet. 3) The plan, said as a plan: what you would want to see and hear before changing anything, in your own words. 4) Rehearse three follow-ups: how contact-centre staff would take advice from someone who has not sat in the seat; what you would get wrong first; who you would lean on. Answer each with candour and the plan, never by adding to the quotes | F2 is the likeliest probe in the loop: the JD names the contact centre in its first line and your material states the negative. JD because it scores a stated requirement; Skeptic because it targets the gap |
| B3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | I do not pick for you. Two candidates in your material: "I haven't worked in a contact centre" and "I've never presented to anyone above regional level." Answer slot: name the one you honestly judge weakest, or another that is, in one sentence, then give the plan to close it. Calibrated candour beats bluffing a competency the manager owns | A standard Skeptic stem; F2 and F8 are the answers it invites. JD because it scores the listed requirements |
| B4 | "This role presents to senior leaders. What has your experience of that been?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I built the monthly complaints spreadsheet our regional manager uses." | Say plainly: "I've never presented to anyone above regional level." Then what your material carries, at its scope: "I built the monthly complaints spreadsheet our regional manager uses." That is a report others use, not a presentation, so do not describe it as one. Then the plan: how you would prepare a first senior readout, in your own words. Hold through two follow-ups by returning to the quote | The JD's senior-leaders line raises it; F8 is the row. JD because it scores a stated requirement |

Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through the monthly complaints spreadsheet you built. What did it show?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Beats the quote states: you built it, it is monthly, your regional manager uses it. Answer slot: expect 'how was each figure counted?' and 'which tool?'. Say what it showed in your own words; for any figure on it, say how it was counted, what it is sensitive to, and the assumption you would defend least; if you do not know how a figure was counted, say so plainly. Name the tool in your own words | The JD's reporting lines raise it; F3 and F9 are the rows. EXP because it tests what was actually yours |
| E2 | "Walk me through the formal complaints log you handled. What was it for and how did you use it?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Beats the quote states: the branch's formal complaints log, which you handled. Answer slot: expect follow-ups on what handling it involved day to day. Say what you did, in your own words; if a step was not yours, or there was no such step, say so plainly and stay with the log you handled | The JD's complaints-experience line raises it; F7 is the row. JD because it scores a stated requirement |
| E3 | "You trained new tellers on the escalation script. What did that involve?" | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Beats the quote states: new tellers, the branch's escalation script, training. Answer slot: if you followed the training up with the tellers afterwards, say how; if it was a single session, or the script was not yours to adapt, say so plainly and stay with the tellers. If asked how the same approach would work with supervisors, answer as what you would do, not what you have done | F4 is the row this presses on. EXP because it tests exactly what the training was |

Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "We want 40% of member service on digital channels by 2028. What does that mean for how we handle complaints?" | CASE | [inferred] | Clarify first: does member service include complaints, and which channels? Then structure: where complaints would arrive in digital channels; what a self-service complaint journey must still hand to a person; what you would measure (the JD's monthly volumes and resolution times). Challenge one premise respectfully: a complaint may be where a member most needs a person, which is the "Members First, Always" value. Think aloud; this makes no claim about your past | The brief's 40% target and the JD's digital-teams line both point here; the derivation is the pack's, hence inferred. CASE because it is a live strategy problem |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What does a good monthly complaints report look like to senior leaders, and what has it been missing?" | Shows you start from the reader of the report, which is the JD's reporting line |
| 2 | "Is complaint handling one process across branches and the contact centre today, or two?" | Asks before assuming, and answers the first question a manager worried about B2 would want you to ask |
| 3 | "With 40% of service moving digital by 2028, which complaint types do you expect to move first, and which do you want kept with a person?" | Ties to the brief and to Members First |
| 4 | "What would you want me to have learned by day 30, and by day 90?" | Turns the interview into a plan for the gaps without volunteering them |
| 5 | "What is the hardest escalation you expect me to coach a supervisor through?" | Shows you are picturing the job's real work |

---

# Round 3: panel of two branch managers (60 minutes, including a 20-minute case; scored against the four values)

## Persona weights

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario probes against the four published values | Top. The recruiter says the panel is the values round and scores against the four values, so each value gets one question | Map a story where a quoted sentence carries one; otherwise the selection scaffold and its honest branch; land the hard truth |
| Case/Strategist | The 20-minute complaint-escalation case | Second. The recruiter's email sets the case at 20 of 60 minutes | Clarify, objective, approach, record and reporting, risks; think aloud; state a hypothesis early |
| Peer Evaluator | Seam-splitting between branches and the complaints role; what you would need from them | Third. My reading, labelled inferred: branch managers run the branches where the JD's branch supervisors work, so the seam is theirs. Adjust if the panel's mix differs | Reciprocity framing; propose seam principles, do not pretend to know the seam |
| Pressure | One time-boxed challenge | Low. A panel prior blends each member's top two; Pressure is not top for either, so one question for composure. The cross-functional prior's Conversational weight is dropped because the email puts structure, a timed case and value scoring ahead of rapport | Pause, restate, hold the quoted position through two follow-ups, concede specifically |

## Question bank

Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C5 | "Tell us about a time you made a decision from the member's side of the counter." | VAL | [grounded] | Selection scaffold, mapped to "Members First, Always — we decide from the member's side of the counter": a named member situation, the decision you made, what it cost the branch or the process, how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The value's own words are the prompt; a panel scoring values will ask it in some form. VAL because it scores behaviour against a published value |
| C6 | "Tell us about a time you rewrote or re-explained something so a member understood it." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold, mapped to "Plain Words — if a member needs it explained twice, we wrote it wrong": a named piece of wording, what was wrong with it, what you changed, how you knew it worked. The escalation script you trained tellers on is the one place in your material where wording matters. Answer slot: if you wrote or changed any of that script's wording, say what and why; if it was issued to you, say so plainly and stay with the training. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The value says who is at fault when a member needs it explained twice, so the panel will look for wording behaviour; F4 is the nearest row. VAL because it scores behaviour against a published value |
| C7 | "Tell us about a time the local picture mattered more than the figure in front of you." | VAL | [grounded] | Selection scaffold, mapped to "Neighbours, Not Numbers — every branch is part of its town": a named branch or member situation, the figure you set aside or kept, why, how it ended. The 2027 plan consolidates eight branches into five hubs and the panel may have a stake in it, so keep the answer about members, not about whether the plan is right. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Branch managers are the people this value is about, and the hub plan sharpens it. VAL because it scores behaviour against a published value |
| C8 | "Tell us about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold, mapped to "Own the Fix — whoever finds the problem keeps hold of it until it is solved": a named problem, the step you took to keep hold of it, who you handed to or did not, how it ended. The nearest thing your material carries is "I handled the branch's formal complaints log", which is handling a log, not holding a problem to a fix, so say it at that scope. If no such time comes to mind, say so plainly, then give the log and how you would keep hold of a problem, as a plan | The value maps most directly onto the role, so expect it to be probed hardest. VAL because it scores behaviour against a published value |

Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D2 | "A member has raised the same complaint at a branch twice and says no one has come back to them. The branch supervisor rings you. Walk us through what you do." | CASE | [generic] | Clarify first, aloud: what the complaint is, what the member has been told, what is on record and in what status, how long it has waited, whether the member needs extra care. Objective: the member knows where they stand today and the problem has one named owner. Approach: the supervisor keeps hold of the case while you coach, which reads "Own the Fix" and your role together (my reading, not a stated rule); one call or letter in plain words. Then the record, how it shows in the monthly numbers, and the risks. State a hypothesis early. This makes no claim about your past | The recruiter's email sets a 20-minute escalation case; this is the pattern for it, so generic. CASE because it is a live problem |
| D3 | "The same member has now also contacted the contact centre and the app chat, and each has a different record. What now?" | CASE | [generic] | Which record is the complaint of record, confirmed with the member; one owner and one view across channels; tell the contact-centre lead and the supervisor; what you would ask a digital team to fix so records do not split. Keep it a plan; make no claim about contact-centre experience | A likely twist in a 20-minute case, and it presses on both the contact-centre line and the digital line without asking about your past. CASE because it extends the live problem |
| D4 | "The branch manager says the member is wrong and the branch followed process. What do you say?" | CASE | [generic] | Restate it. Concede what you do not know yet: what happened. Hold one position, that the member gets an answer in plain words and someone owns it until it is solved. Ask to see the record before any verdict. Hold it through two follow-ups; concede specifically, never fold on the position | The branch managers can play this out live, and it tests composure and the values together. CASE with pressure delivery |

Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "You'll be coaching supervisors on escalations. Where is the line between your job and ours, and what happens when we disagree?" | JD | [grounded] | Propose seam principles, not a pretended seam: the branch holds the member relationship, the complaints lead holds the process; for a disputed case, agree who decides before the case arrives. Say you would want to agree it with them in the first weeks. This claims nothing about your past | The JD's coach-supervisors line raises it. JD because it scores a stated requirement; Peer delivery |
| F2 | "Some of our branches may become hubs under the 2027 plan. What would you need from us, and what could we expect from you?" | CO | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Reciprocity framing. Need: one named contact per branch and a clear route for an escalation. Offer: what your material carries, at its scope, the escalation script you trained tellers on and the monthly complaints spreadsheet, plus what you would ask of them. Keep the answer about members, not about the plan | Branch managers are pricing what the hire costs them and what it gives them. CO because it uses the brief |

Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you rather than someone who has run a contact centre?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Pause and restate. Hold what the quotes carry: "6 years in retail banking, the last 3 as a branch supervisor", and "I handled the branch's formal complaints log and trained new tellers on our escalation script." Concede once, plainly: "I haven't worked in a contact centre", and that someone who has will know the channel better. Do not fold on the core claim; through two follow-ups, return to the branch material and never add to it | A persona stem, and F2 is where it bites. JD because it scores the listed requirement |

## Values cheat sheet

| Value (official name) | Working meaning (paraphrased) | Mapped story or scaffold |
|---|---|---|
| Members First, Always | Decide as the member would see it from their side of the counter | No row's evidence carries a story for this value. Selection scaffold at C5 and C2, ending in the honest branch: if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Plain Words | If a member needs it explained twice, the wording was wrong | Row F4 is nearest: "I handled the branch's formal complaints log and trained new tellers on our escalation script." It carries training on a script, not rewriting wording, so selection scaffold at C6, ending in the honest branch |
| Neighbours, Not Numbers | Every branch is part of its town, so local context counts beside the figures | No row's evidence carries a story for this value. Selection scaffold at C7, ending in the honest branch |
| Own the Fix | Whoever finds a problem keeps hold of it until it is solved | Row F1 is nearest: "I handled the branch's formal complaints log and trained new tellers on our escalation script." It carries handling a log, not holding a problem to a fix, so selection scaffold at C8, ending in the honest branch |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What does a good escalation from one of your supervisors look like today, and where does it go wrong?" | Gets the panel describing the real work, and the seam you would sit on |
| 2 | "How do you expect the move from eight branches to five hubs to change the complaints your branches see?" | Ties to the brief and shows you are thinking about the branches, not only the process |
| 3 | "What could a new complaints lead do in their first month that would genuinely help your branch?" | The reciprocity question for a peer-style panel |
| 4 | "Which of the four values do your supervisors find hardest to live out in a complaint, and why?" | Turns the values round into a conversation and shows the values are on your mind |
| 5 | "How would you want to hear about complaint trends from your branch, and how quickly?" | Shows you will report to the people closest to members |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has worked in a contact centre, or has contact-centre experience | Negative you stated, F2 | The plain acknowledgment F2 gives: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders, or above regional level | Negative you stated, F8 | The plain acknowledgment F8 gives: "I've never presented to anyone above regional level." No slot |
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says one branch's log and training. B2's and E2's slots stay inside the log |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: new tellers. The limit is the pack's observation: your material says tellers, not supervisors |
| Reported complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope: a monthly complaints spreadsheet your regional manager uses. E1's slot asks only what it showed and how any figure was counted |
| Handled regulated complaints | Inflated form of F7 | F7's quote at its own scope: a formal complaints log. The limit is the pack's observation: your material says formal, not regulated |
| Built the reporting in Excel, or has advanced Excel skills | Inflated form of F9 | F9's quote at its own scope: a spreadsheet. E1's slot asks only for the tool's name in your own words |

## Upgrade menu

- Interviewers' names once assigned: an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to their own path
- Your actual CV: the fit-snapshot evidence currently rests on your message alone, so F1, F3, F4, F7 and F9 could be quoted from the document and some could rise in confidence
- Your answers to the slots outside a drill: what your spreadsheet showed and in which tool (F3, F9), whether any of your branch's formal complaints followed rules from outside the branch and which (F7), any contact with a digital team (F5), and what followed your teller training (F4) would each turn a slot into a quoted story
- The full 2026 strategy brief: the grounding brief currently rests on your four points
- A line to the recruiter on the 20-minute case: its format and any reading would sharpen D2 to D4
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, covering interviewer public footprint once names exist, loop reports for this role family and recent organisation context
- A saved tuesday-dossier.md from an earlier session would add verified evidence and a list of claims to avoid, so the objection rehearsals start from what has been confirmed
