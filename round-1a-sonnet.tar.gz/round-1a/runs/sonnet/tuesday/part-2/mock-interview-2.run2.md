Web search was refused, so the pack will rest only on what you pasted. I'm building it now and will save it to the working directory.
Your prep pack is saved at `/var/tmp/tuesday-measure/1a/runs/sonnet/tuesday/part-2/rooms/case-2-denied-041c3abd/atlas-freight_operations-manager_interview_pack.md`. I built it for an unknown round on a generic loop pattern, since you don't know who's interviewing. The web searches I tried on Atlas were refused, so nothing in it is researched about the company. It has 22 questions, 6 reverse questions and a coverage table mapping each JD requirement to the questions that cover it.

The pack's highest-ROI rehearsal is B1: "You manage three supervisors today and this role has twelve across four sites. What makes you think you can make that jump?" The Power BI answer (B3) and defending the 40% (C1, F2) come next.

Say the word and I'll play the Skeptic on B1 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Do you know which round this is (recruiter screen, hiring manager or panel), or can you find out from the invite or one line to the recruiter? The answer reweights every bank.
Would you like to paste your CV? I built the pack from your summary alone, and your CV's own lines would replace those quotes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

Role: Operations Manager. Company: Atlas Freight (regional logistics, 800 employees, per the JD). Interviewer: not known. Relationship and round type: not known, so this pack is built for an unknown round on the generic loop pattern (screen, hiring manager, panel) with near-flat persona weights. Nothing about Atlas was researched in this session.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding, not a script: say only what you actually did, in your own words. Where a cell says "answer slot", it is an instruction for the interview. It asks you for nothing here.

| Type | What it scores |
|---|---|
| VAL | Behavioral and values alignment: whether past behavior shows what the employer says it values |
| EXP | Work-experience deep-dive: whether the claims survive scrutiny and what was actually yours |
| JD | Role and JD-driven: the listed duties and qualifications, including the gaps |
| CO | Company and strategy knowledge (none in this pack, because company research did not run) |
| CASE | Hypothetical or live problem: structure and reasoning, delivered live |

## Prep triage

You have about a week and I do not know how many hours that is, so this is an order of work. Do the first three well.

1. B1: rehearse it aloud until it is boring. This is the highest-ROI prep in the pack.
2. C1 and F2: be able to say plainly how the 40% was counted and which part was yours.
3. B3: a two-sentence Power BI answer you can say without flinching.
4. E1: the 90-second arc.
5. A1 to A4: say each structure aloud once.
6. Reverse questions: pick three to ask.

Everything else is insurance.

## Fit snapshot

Requirements are quoted from the JD you pasted. Evidence is your own summary message, since no CV was supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material shows warehouse and distribution ops and one site's surge plan, not terminal operations or four sites, and the words stay there: "I ran the site's peak-season surge plan two years running." Answer slot: the JD's four sites make a probe on reach likely. If any of your responsibility went beyond one site, or into a freight terminal, say what and when; if not, or if it was not yours, say so plainly and stay with the site whose plan you ran |
| F2 | "drive on-time performance and cost-per-shipment down" — JD (the on-time half) | none given | none | [grounded] | discovery | Your material states no on-time figure or service measure. Answer slot: if you tracked on-time performance or a comparable service measure, say what it was, how it was counted and what moved, in your own words; if you did not, or it was not yours, say so plainly and say what you would want to know first |
| F3 | "drive on-time performance and cost-per-shipment down" — JD (the cost half) | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | The quote is about the mis-pick rate and the words stay there: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: the JD's cost line raises a probe on measures beyond mis-picks. If you tracked any other measure around that redesign, say which and how it moved; if you did not, say so plainly and stay with the mis-pick rate |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material says three supervisors, the JD says twelve, and the words stay at the quote: "I'm currently a senior shift manager over 3 supervisors." Answer slot: if you have led more than three supervisors, or supervisors at more than one site, say when and how many; if not, say so plainly and move to your plan for twelve, said as a plan and never as a past |
| F5 | "build reporting in Excel/Power BI" — JD (the Excel half) | "solid Excel" — your message | low | [inferred] | discovery | Derived: "solid Excel" touches the requirement without showing whether it reaches it. Answer slot: if any of your Excel work was shared with others or recurred on a schedule, say what it was and who used it, in your own words; if it was not, say so plainly and stay with "solid Excel" |
| F6 | "build reporting in Excel/Power BI" — JD (the Power BI half) | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used Power BI." Then how you would learn it, said as a plan and never as a past. Never a claim of Power BI exposure, and nothing added to make the gap feel smaller |
| F7 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | Your material gives years in ops and a current supervising role, and does not show how long you have held roles of that kind. Answer slot: say the roles you held across the seven years and how long in each, in your own words; if you do not have the dates to hand, say that rather than rounding. The JD marks this required, so expect the number to be checked |
| F8 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message; "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | none | The quote already reaches the requirement: "I'm green belt certified." It is a statement with nothing inspected behind it, so expect a probe on it. Say it as you stated it, and name the belt type and certifying body only from your certificate |

No row is a gate: the JD states no licence, location, schedule or pay term, so there is nothing here to surface as a gate.

## Persona table

The weights rest on the generic loop pattern, not on Atlas's documented process, because no loop source was available. Because the round is unknown, I kept the weights near flat and tilted depth toward the personas that press hardest on this snapshot's thinnest rows (F1, F4, F6).

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (A, 4 questions) | Live problems: diagnose on-time, plan peak, size cost | High. The JD's duties are run-the-operation duties (F1, F2, F3), which are natural live problems, and a case needs no history | Clarify, then objective, segments, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic (B, 4 questions) | Quiet probing of scale, domain and tools | High. F1, F4 and F6 are the largest gaps and the JD's headline duties press on them | Rehearse B1 until boring; build bridges only from your own quoted sentences and say the limit plainly |
| Data-Driven Prober (C, 4 questions) | Line-by-line probing of the 40% and the measures | High. The 40% is the one headline figure (F3) and the JD names reporting (F5, F6) | Know what you can and cannot say about how the 40% was counted; say plainly when you do not know |
| Values/Behavioral (D, 3 questions) | Scenario probes, STAR-shaped stories | Medium. No values-style round is detected on the generic pattern and no published values were available, so these use persona themes | Pick a story where the hard truth landed; "we" for context, "I" for your contribution |
| Conversational (E, 3 questions) | Friendly opener, casual probes of the JD | Medium. A screen or an early chat is plausible when the round is unknown, and casual questions are still scored | A 90-second arc; treat casual JD questions as scored |
| Pressure (F, 2 questions) | Time-boxed challenge, attribution probe | Lower. Nothing indicates an executive or bar-raiser round, but the 40% invites it | Pause, restate, hold through two follow-ups, concede only what is true and specific |
| Peer Evaluator (G, 2 questions) | Seam-splitting with adjacent teams | Lower. Peers are unknown, but a four-site role touches neighbouring teams | Reciprocity; propose seam principles rather than pretending to know the seam |

## Question banks

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "On-time performance has slipped at one of your four sites for three weeks running. Where do you start?" | CASE | [generic] | Structure aloud; this makes no claim about your past. Clarify what on-time means here (measured at which event, against which promise) and whether the slip sits in one lane, shift, customer or day. Segment before you diagnose, separate what the site controls from what it does not, name the smallest first test and the one measure you would watch, and say the risk of acting too early. Challenge one premise politely, such as whether three weeks makes a trend | The JD's on-time line (F2) as a live problem; CASE because it scores structure, and the pattern is generic, not a fact about this employer |
| A2 | "Cost-per-shipment has to come down across the terminals. What do you need to know first, and what would you refuse to cut?" | CASE | [generic] | Clarify what goes into cost-per-shipment here (which costs, which shipments) before you move it. Split the problem by where the cost sits, and name one thing you would protect and the measure it protects. No claim about your past | The JD's cost line (F3) as a live problem; JD content with CASE delivery |
| A3 | "You have been handed daily operations at four sites. What does your first month look like?" | CASE | [generic] | Structure around learning before fixing: what you would ask each site first, which handful of measures you would agree, how you would meet the supervisors, and one early change you would choose and why. No claim about your past | F1 and F4 together; it sets up B1's ramp plan; CASE because it presupposes nothing about your history |
| A4 | "Peak season is six weeks out and volume will rise at all four sites in the same week. How do you plan it?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Structure first: demand, capacity, labour, handoffs, escalation triggers, who decides what. Then one anchoring sentence at its scope: "I ran the site's peak-season surge plan two years running." Answer slot: the question's four sites go beyond the quote. If any part of your plan involved more than one site, say which and how, in your own words; if it did not, say so plainly and say how you would start across four | F1 is the strongest adjacent evidence for the operating duty; CASE delivery with an EXP anchor |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You manage three supervisors today and this role has twelve across four sites. What makes you think you can make that jump?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI rehearsal in this pack, and the hold is only what the quote carries: "I'm currently a senior shift manager over 3 supervisors." The limit is this pack's observation, not words for you: the material says three supervisors, not twelve, and says nothing about more than one site. Answer slot: if you have led more than three supervisors, or supervisors at more than one site, say when and how many; if not, say so plainly, then give your ramp plan for twelve as a plan: how you would get to know each supervisor and each site in the first weeks, in your own words. Follow-ups to rehearse: "What is the largest team you have led?" (answer from the slot), "What breaks first when the span grows?" (answer as a plan), "What if a supervisor at another site will not follow your direction?" (answer as a plan). Hold by returning to the quote and the plan, never by adding to the quote | F4 and F1 are where the JD's headline duties press hardest, so this objection will arrive in some form; JD because it scores the stated requirement |
| B2 | "Why leave a senior shift manager role for this one, and why Atlas?" | EXP | [grounded] "currently a senior shift manager over 3 supervisors" | Answer slot: give your own reason for moving and your own reason for this company, in your words, kept as two separate halves. This pack has no reason of yours and supplies none. Research on Atlas did not run, so the "why Atlas" half rests on what you find on Atlas's own pages this week | The Skeptic's "why leave, why here, why now" probe; EXP because the reason for leaving tests consistency with your history (F4) |
| B3 | "The role builds reporting in Excel and Power BI. Where are you with each?" | JD | [grounded] "solid Excel"; "never used Power BI" | Power BI first, plainly: "I've never used Power BI." Then, as a plan and not a past, say what you would do first and how soon, in your own words; describe no Power BI exposure. Excel at its scope: "solid Excel." Answer slot: if any of your Excel work was shared with others or recurred on a schedule, say what it was and who used it; if it was not, say so plainly and stay with "solid Excel" | F5 and F6: the one gap you have stated in words, so the honest answer is ready before the probe arrives |
| B4 | "Your background is warehouse and distribution. What is different about running terminals, and what would you need to learn?" | JD | [grounded] "7 years in warehouse and distribution ops" | Start at the quote's scope: "7 years in warehouse and distribution ops." Answer slot: the JD says terminal operations. If any of those years was spent in a freight terminal or a similar environment, say where and what you did; if none was, say so plainly and name what you would ask the site teams first, as a plan. Do not describe terminal practice you have not done | F1; the domain-transfer objection is the likely second probe after B1 |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Story-mapped on F3: the mis-pick rate, the 40%, the pick-path redesign, which are the beats the quote states, told in your own words with the attribution the quote gives. The four slots a figure raises, each in your own words: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly and stay with the quote. The pack supplies no baseline, period or method | F3 is the only headline figure, so a prober goes here first; EXP because it tests attribution |
| C2 | "You hold a green belt. What have you done with it?" | JD | [grounded] "green belt certified"; "cut mis-pick rate 40% by redesigning the pick path" | "I'm green belt certified." Answer slot: the JD's Lean/Six Sigma line makes a probe on method likely. If the pick-path redesign used a method from the belt, say which and how; if it was done another way, or the belt was not applied to a project, say so plainly and stay with the certification and the redesign as the quote states it. Name the belt type and certifying body only from your certificate | F8 and F3; the JD marks Lean/Six Sigma a plus, so the question lands on the one row that is already strong |
| C3 | "If I gave you one page to run four sites each morning, which numbers are on it and why?" | JD | [generic] | Structure by decision: for each number, the decision it drives, how often it is read and who owns it. Include the two measures the JD names (on-time performance, cost-per-shipment) and say how you would define each before showing it; say what you would leave off. It needs no past and says nothing about tools beyond B3 | F2, F3 and F5 asked as a design problem, so it works even where your history is thin; JD content with CASE delivery |
| C4 | "Which measures does your current role hold you to, and are on-time performance and cost-per-shipment among them?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path" | Say what your material carries: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if you were held to a measure beyond the mis-pick rate, say which, how it was counted and what it did, in your own words; if you were not, or it was not measured at your level, say so plainly and stay with the mis-pick rate | F2 and F3; the question's premise is the JD's, and the guidance does not adopt it |

### D. Values/Behavioral

No published Atlas values were available, so these three use the JD's supervisor-leadership line and standard persona themes. If Atlas has a values-style round, send the values page and these become value-by-value rows.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you got a group of supervisors to change how they worked." | VAL | [generic] | Selection scaffold: pick a time with a named change, someone who resisted, what you yourself did, and what held afterwards; "we" for context, "I" for your own part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's supervisor-leadership line (F4) as an open prompt; no sentence of yours carries a story for it, so it is a scaffold |
| D2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a named customer situation, the metric you set aside, what it cost, and where the relationship stood afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem; the JD names two measures (F2, F3) an operations manager balances |
| D3 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: the truth, the evidence you had, how it landed, and whether the relationship held. Choose a story where the hard truth actually landed; where none comes to mind, say so rather than supply an ending, then give the nearest thing your material does carry, or how you would handle it | Persona stem, a standard behavioral probe for a role that reports upward |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | A 90-second arc using only those five beats at their scope. The order, the dates and the roles between them are not in your material: tell them in your own order and say if you do not recall which came first. Close on one sentence of your own about why this role; the pack supplies none | F1, F3, F7 and F8; a casual opener that sets every later probe |
| E2 | "What are you actually playing with in Lean or Six Sigma these days?" | JD | [grounded] "green belt certified" | Casual register, still scored. "I'm green belt certified." Answer slot: if you are using a method from it on anything now, say what, in your own words; if you are not, say so plainly and stay with the certification. Do not offer a list of tools you have not used | F8 asked casually, because the JD marks it a plus |
| E3 | "How long have you been leading people, roughly?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Start at the quotes' scope: 7 years in warehouse and distribution ops, and currently a senior shift manager over 3 supervisors. Answer slot: the JD sets a required minimum, so expect the number to be checked. Say the roles you held across the seven years and how long in each, in your own words; if you do not have the dates to hand, say that rather than rounding | F7 is a required line the quotes do not settle, so it arrives in casual form |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over a candidate who already runs four sites?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | Pause, restate the question, then hold with what the quotes carry: "I cut mis-pick rate 40% by redesigning the pick path. I ran the site's peak-season surge plan two years running." Hold through two follow-ups by returning to those sentences, never by adding to them. Concede the scale difference specifically and stop. Answer slot: if you have not run more than one site, say so plainly; if you have, say which | The Pressure persona's time-boxed comparison; F1 and F4 are where it presses |
| F2 | "That 40%: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold the quote's attribution: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if others contributed to the redesign or the result, say who and what, in your own words; if it was your own work end to end, say so plainly; if you do not know how the 40% was counted, say that too. Concede only what is true and specific, and never fold on the claim to restore harmony | F3; persona stem for an attribution probe; EXP because it tests what was actually yours |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our teams sit side by side. Where is the seam between operations and us, and what happens when we disagree?" | CASE | [generic] | Propose seam principles rather than pretending to know the seam: what each side owns, who decides when they conflict, and how each hears from the other first. Add reciprocity: what you would bring their team. Do not assert an existing seam. No claim about your past | Persona stem; a four-site role (F1) touches neighbouring teams, so seam questions are plausible; CASE because it asks no past |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Say your principle first, then pick a time as a selection scaffold: a named piece of cross-team work, who did what, and how credit was shared. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem; VAL because it scores behaviour under shared ownership |

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| "Own daily terminal operations across 4 sites" | A3, A4, B1, B4, F1, G1 |
| "drive on-time performance and cost-per-shipment down" (on-time) | A1, C3, C4 |
| "drive on-time performance and cost-per-shipment down" (cost) | A2, C3, C4 |
| "lead a team of 12 supervisors" | A3, B1, D1 |
| "build reporting in Excel/Power BI" | B3, C3 |
| "5+ years operations leadership required" | E1, E3 |
| "Lean/Six Sigma a plus" | C2, E2 |

There are no CO questions: company research did not run, so none could be grounded in Atlas's strategy. Headline figure covered: the 40% (C1, F2).

## Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| R1 | "How is on-time performance measured here, at which event and against which promise, and where does it stand against target today?" | It shows you ask what a figure means before promising to move it, which mirrors A1 |
| R2 | "How are the twelve supervisors spread across the four sites, and what most often pulls them off the floor?" | It shows you think about span and attention, the two things B1 presses on |
| R3 | "What does reporting look like today, and how much of it lives in Excel versus Power BI?" | It opens the Power BI topic on your terms and lets them describe the real state before you are asked |
| R4 | "What would the first ninety days in this seat need to deliver, and which site needs the most attention first?" | It signals you plan to learn before changing things, which is the ramp plan in B1 and A3 |
| R5 | "What would make you say, a year from now, that this was a clear success?" | It gets the scoring sheet in their own words; the rapport-style slot is weighted, so never answer "no questions" |
| R6 | "What does the process look like from here, and who else will I meet?" | It fixes the unknown round for your remaining prep and costs nothing to ask |

## Prohibited claims

What this pack will not coach, built before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Led twelve supervisors, or led supervisors across several sites | Inflated form of F4 | F4's quote at its own scope: "I'm currently a senior shift manager over 3 supervisors." The limit is the pack's observation: the material says three, not twelve. B1's slot stays inside what you led |
| Ran terminal operations or four sites | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation: the material says warehouse and distribution ops and one site's plan |
| Cut cost per shipment | Inflated form of F3 | F3's quote at its own scope: the mis-pick rate. C4's slot asks only about other measures you actually tracked |
| Has used Power BI | Negative you stated, F6 | The plain acknowledgment F6 gives: "I've never used Power BI." No slot |
| Led a Lean or Six Sigma project | Inflated form of F8 | F8's quote at its own scope: "I'm green belt certified." C2's slot stays inside what you did with it |
| Seven years of operations leadership | Inflated form of F7 | F7's quote at its own scope: "7 years in warehouse and distribution ops." E3's slot asks for your roles and how long in each |

## Sources

Provided documents: the JD text you pasted into your message, and your own background summary in the same message. No CV, recruiter note or interviewer information was provided. No dossier was present.

Searches sent (all refused by the host; no results returned):

- "Atlas Freight regional logistics company values": refused
- "Atlas Freight interview process operations manager": refused
- "Atlas Freight regional logistics news strategy": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Every call was refused. It would have given the official value names for a values cheat sheet and the themes for D1 to D3 |
| 2. `Atlas Freight interview process operations manager` | unavailable | Every call was refused. It would have fixed the loop and the persona weights, which now rest on the generic pattern |
| 3. `Atlas Freight strategy` / recent news | unavailable | Every call was refused. It would have grounded CO and CASE questions in Atlas's current priorities |
| 4. interviewer name and company | n/a | No name was given, so there was no query to form |
| 5. representative `Operations Manager` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Search permission, or a paste of Atlas's values page and careers page → official value names, the documented loop and current strategy; the persona weights stop resting on the generic pattern, and D1 to D3 can become value-by-value rows. If you allow search, a deeper pass is also possible: up to 6 more searches and 2 more fetches, several more minutes
- Which round this is, and who it is with (the recruiter's invite or a one-line email) → reweights every bank; a recruiter's stated focus areas or announced deliverable would add coverage or a build section
- The interviewer's name → an interviewer read, persona weights from their public footprint, and a reverse question tied to their path
- Your CV → every fit-snapshot row currently quoting your summary message moves to your CV's own lines, and rows F5 and F7 may firm up
- Your certificate for the green belt (belt type, certifying body, date) → F8 moves from medium to high
- Your answers to the answer slots, said outside a drill → F1 (any reach beyond one site), F2 and F3 (other measures tracked), F4 (any team larger than three), F5 (shared or recurring Excel work), F7 (your roles and years in each) each move from a slot to quoted evidence, and B1, C4 and E3 are rewritten around them
- A tuesday-dossier.md, if you already have one → verified evidence and standing limits arrive ready-made, so fewer rows depend on a one-message summary
