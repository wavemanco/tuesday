The pack is saved. I built it from your highlights and notes only, and no web research was run.

Full path: `/var/tmp/tuesday-measure/1a/runs/sonnet/tuesday/part-2/rooms/case-1-denied-94762d78/northwind-data_senior-gtm-strategy-lead_interview_pack.md`

It's built for one 60-minute conversation with Dan as a peer. It has 20 questions across six personas, weighted toward Peer Evaluator and Data-Driven Prober. The Skeptic bank holds the highest-ROI rehearsal, C1: the missing sales-ops and quota-setting experience, asked by the person who owns that function. The JD requirements are your highlights, not the full JD text. No values bank is included, because no values-style round is documented.

Say the word and I'll play Dan as the Skeptic on C1, with follow-ups that react to Priya's answers.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Did the recruiter name any focus areas, or ask Priya to prepare anything for Dan (a POV, a presentation, a take-home)? A prepared deliverable would add its own build section.
2. Can you paste the full JD text? It would turn the requirement rows from your summary into quoted JD lines, and might add rows the highlights omit.
3. Do you want me to research Northwind's values and interview process, plus Dan's public talks and writing? This would send Northwind's and Dan's names to a search service, so I held off until you say yes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Interview pack: Senior GTM Strategy Lead, Emerging Products — Northwind Data

**Interviewer:** Dan Kovac, Director of Sales Strategy — a peer (both of you report to the same VP)
**Format:** one 60-minute conversation
**Candidate:** Priya
**Built from:** the coach's message — JD highlights (not the full JD), a candidate summary, a summary of Dan's profile, and a research note on Northwind. No web research was run (tier L0), so every fact about Northwind comes from that note.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. The guidance in each row is scaffolding for a spoken answer, not a script.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values. No VAL bank appears here, because no values-style round is detected and no published values are in hand |
| EXP | Whether the CV's claims survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know Northwind's strategy and can think at its altitude |
| CASE | Structure and reasoning on a live problem from the role |

Three conventions run through the banks:

- The quoted sentences in each Provenance cell are the only things the guidance says about Priya's past. Say them at their own scope.
- An answer slot is an instruction for the interview. It is not a blank to fill in here. Each has two honest branches: you did it and can say how, or you did not, or it was not yours, and you say so plainly.
- **The highest-ROI prep in this pack is C1**, the sales-ops and quota-setting objection, asked by the person who owns that function. B1 to B3 and F2, on the ~$400M figure, come next.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "11 years — 2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | Your material says product strategy and ops, not go-to-market, so the words stay there: "I spent nine years in product strategy and ops at a large consumer-tech company." Answer slot: the JD's ownership line makes a probe on how far that work reached beyond the product itself likely. If any of it did, say which part was yours and how you decided, in your own words; if none did, or it was not yours, say so plainly and stay with the product strategy and ops work |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | The quote is a proposal credited with an uplift. It does not say which lifecycle stage the change addressed or how the opportunity was found. Words: "I proposed a store-surface change credited with a ~$400M ARR uplift." Answer slot: the JD's stage line makes a probe on how that opportunity was found likely. If you found it through analysis, say what you looked at and what was yours, in your own words; if it came another way, or the finding was not yours, say so plainly and stay with the proposal |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | discovery | The quote names the tools and does not show what was run. Words: "I'm skilled in SQL and Tableau." Answer slot: Dan's data-driven profile and the JD's independent-analysis line make a probe on what you have run yourself likely. If you ran an analysis end to end yourself, say what question it answered and what you did in each tool, in your own words; if others pulled the data or built the views, or you have not worked that way, say so plainly and stay with "skilled in SQL and Tableau" |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | Your material says a revenue model used in negotiations, not a motion, and the words stay there: "I built a partner-level revenue model used in carrier negotiations." Answer slot: the JD's required-experience line makes a probe on whether your work reached beyond the model likely. If it did, say where and what part was yours, in your own words; if it did not, or the reach was not yours, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | presentation | Lead with the sentence in its own terms: "I set annual volume targets with cross-org consensus." Do not swap in the JD's "cross-functional" or add an adjective the sentence does not carry. Answer slot: a probe on how the consensus formed is likely. If teams disagreed along the way, say who and what moved, in your own words; if they did not, or it was not yours, say so plainly and stay with the targets and the consensus |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — the coach's notes | medium | [grounded] | presentation | Say it as written: "I use AI tools daily." It is not AI product, strategy or launch experience, and it is not worded as any of those. Answer slot: a casual question on this is scored. Say which tools and for what, in your own words; if the use is ad hoc or personal, say so; if none of it sits on work you shipped, say so plainly and stay with daily use |
| F7 | Sales-ops and quota-setting fluency — the interviewer's own function ("Director of Sales Strategy", your message); not in the JD highlights | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [grounded] | capability | A gap the candidate stated, and wording cannot close it. Words: "I don't have classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past: "Before proposing anything, I'd learn from your team how the numbers are built here." F5's quote says volume targets, not quotas, and stays a separate row. Nothing is added to make the gap feel smaller |

No row is a hard gate. The JD highlights name no term such as location, travel, pay or authorization. The full JD may add some (see the upgrade menu).

## Reading the interviewer

Everything here comes from the profile summary the coach supplied. No public footprint was researched.

| Signal | Source | What it means for the conversation |
|---|---|---|
| "relentlessly data-driven" | Dan's self-description, per your message | Expect every number to be probed to its assumptions: bank B and F2 |
| Career spine in pricing and monetization | Your message | His native language is pricing, packaging and unit economics. Case questions tilt there: D2 |
| One early-stage-startup chapter | Your message | Expect pace and resourcing probes of a large-company background (C3), and expect builder stories to land |
| Peer, same VP | Your message | He is pricing what a hire costs and contributes to his own work, in his own function. The stated gap in F7 sits inside his territory, so candor beats bluffing (C1) |

Mirror opportunities:

- **Shared vocabulary.** Revenue and monetization language connects to F4's quote, "built a partner-level revenue model used in carrier negotiations". The quote says revenue model and negotiations. It does not say pricing, so do not describe it as pricing work.
- **Shared jump.** None is offered. No row of the fit snapshot carries Priya's side of a pricing or startup path.

## Persona table

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy (a rehearsal method, not a claim) | Bank |
|---|---|---|---|---|
| Peer Evaluator | Seam-splitting with his team, "what do you need from me", credit and disagreement | High. Peer rounds weight this persona first, and the single 60-minute conversation is with a peer | Reciprocity first. Propose seam principles instead of pretending to know the seam. Tell disagreement only from a sentence you can quote | A, 5 questions |
| Data-Driven Prober | Line-by-line on the CV figure, the model, the SQL and Tableau claim | High. Peer rounds weight it, and his "relentlessly data-driven" self-description raises it. The ~$400M figure is the obvious target | Know what you can and cannot say about how the figure was counted. Name the weakest assumption you know of before he does. Say plainly what you do not know | B, 5 questions |
| Skeptic | The sales-ops and quota-setting gap, the partner-motion requirement, big-company-to-small-company pace | Medium-high. F7 is a stated gap inside his function, F4 is thin against a "required" line, and the startup chapter signals pace probes | Rehearse the single most predictable objection until it is boring. Bridge only from adjacent evidence you actually stated. Be candid about what he personally owns | C, 3 questions |
| Case/Strategist | A live problem on whitespace, bundling or the three priorities | Medium. Peer rounds are not case-led, but the role is strategy and his pricing spine tilts him toward pricing cases | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully | D, 3 questions |
| Conversational | The opening biography and a casual question about AI | Low-medium. A 60-minute conversation opens with the journey, and the JD flags AI as a plus, so the casual question is still scored | A 90-second arc built only from quoted sentences. Treat the casual AI question as scored | E, 2 questions |
| Pressure | Time-boxed "why you", "how much was you" | Low. Nothing in his profile suggests a stress style, and peer rounds are usually collegial. It is rehearsed because a data-driven interviewer can turn pointed on the headline figure | Pause, restate, hold the position through two follow-ups, concede specifically | F, 2 questions |
| Values/Behavioral | Scenario probes against published values | Low. The loop is one conversation with a peer, no values-style round is detected, and no published values are in hand. No separate bank. Behavioral probes appear in A2 and A4 | Not applicable until values are researched | None |

## Question banks

### A. Peer Evaluator (weight: highest, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "We'll both touch these two new product lines. Where do you see the seam between your work and mine?" | JD | [inferred] from the JD highlights' ownership line and Dan's title | Clarify before proposing: ask Dan where he sees the seam today. Then offer principles, not a map you cannot know yet: who decides what, shared definitions of the stages, and who hears about a disagreement first. Close on what you would bring his team before what you need. This is a conversation pattern and claims nothing about Northwind's real split | F1's ownership line sits next to Dan's function, so seam awareness is the first thing a peer prices. JD because it tests the stated ownership, with Peer delivery |
| A2 | "Tell me about a time you disagreed with a peer team and how it got resolved." | JD | [grounded] "set annual volume targets with cross-org consensus" | Story map from the one quoted sentence: say it as written, "I set annual volume targets with cross-org consensus", and stop there if that is all it carries. Answer slot: a probe on how the consensus formed is likely. If teams disagreed along the way, say who, what you did and what part was yours, in your own words; if they did not, or it was not yours, say so plainly and describe the consensus as it was. If no real disagreement comes to mind, say so, then give the nearest thing your material carries, the consensus on the targets, or how you would handle it. Hold your position and name what you would concede | F5 is the evidence for the influence requirement, and a peer tests it as a disagreement story. JD content with EXP delivery. The theme is the JD's influence line and the Peer persona's disagreement stem |
| A3 | "What would you need from my team in your first ninety days?" | JD | [inferred] from the JD highlights' influence line and Dan's role | Reciprocity first. Open with what you can offer his team in the first month, in your own words and from work you have actually done. Then ask for what a newcomer needs from a sales strategy team: how the numbers are built, how stages are defined, and where the field's pain sits. Asks are questions and make no claims | F5's requirement is about working across teams, and a peer asks this to see whether you reduce or add to his load. JD because it scores the stated influence line |
| A4 | "How do you handle credit when work spans teams?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Use "we" for context and "I" for contribution. The "I" in your sentence sits on the proposal: "I proposed a store-surface change credited with a ~$400M ARR uplift." The sentence does not say who credited it or what others did. Answer slot: if others carried the change after you proposed it, say who and what they did; if no one did, or you do not know how the credit was assigned, say so plainly and stay with "I proposed" | F2's figure carries a credit word, and credit-sharing is a Peer stem. EXP because it tests attribution honesty |
| A5 | "Land, adopt, expand and renew only work as a shared language if we define the stages the same way. How would you get there with my team?" | JD | [inferred] from the JD highlights' stage line | Ask how Northwind defines each stage today before proposing anything. Then propose a method: agree entry and exit definitions, name one data owner per stage, and where the definitions differ, put both views in front of the VP you share. It is a plan for the conversation and claims nothing about your past | F2's requirement is stage-based whitespace, and it only works on shared definitions, which is where a sales strategy peer's work meets yours. JD because it tests the stated requirement |

### B. Data-Driven Prober (weight: highest, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Open with the sentence as written: "I proposed a store-surface change credited with a ~$400M ARR uplift." Then the four defend-the-number slots, each in your own words and none supplied here: how the figure was counted, what it is most sensitive to, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so plainly and stay with what you do know | F2 holds the headline figure, which is where a prober starts. EXP because it tests whether the number survives scrutiny |
| B2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Name it before he does. Answer slot: if you know the assumption you would defend least, say it and what would change if it were wrong, in your own words; if you do not know how the figure was built, say so plainly and stay with "I proposed" the change. Rehearse until the admission sounds like a gain in credibility, not a retreat | The weakest-assumption move is the standard prober counter, and it is a Prober stem. F2. EXP |
| B3 | "Who credited the uplift to your change, and on what basis?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | The question rests on the sentence's own word, "credited". Answer slot: if you know who credited it and how, say so in your own words; if you do not, or it was not set by you, say so plainly and stay with the proposal. Never describe an attribution method you did not use | F2's attribution is the second thing a prober asks after the count. EXP because it separates your part from the credit |
| B4 | "Tell me about the revenue model you built for the carrier negotiations. What was it for, and how was it used?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story map on the beats the sentence states: a model, at partner level, used in carrier negotiations. Say it as "I built a partner-level revenue model used in carrier negotiations" and tell the rest in your own words. Answer slot: a probe on how far the model reached beyond the negotiations is likely. If it reached further, say where and what part was yours; if it did not, or the reach was not yours, say so plainly and stay with the model used in carrier negotiations | F4 is the only evidence for the partner requirement, and a monetization-spine interviewer will want to dig into a revenue model. EXP because it tests what was actually yours |
| B5 | "Tell me about an analysis you ran in SQL or Tableau that changed a decision." | JD | [grounded] "skilled in SQL/Tableau" | No quoted sentence carries an analysis story, so this is a selection scaffold. Pick one where you can name the question, the data, what you did yourself in the tool, and what changed. If that analysis exists, offer to walk him through it end to end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I'm skilled in SQL and Tableau", or how you would approach it | F3's requirement is explicit about SQL and Tableau, and a data-driven interviewer will test it. JD because it scores a stated requirement |

### C. Skeptic (weight: medium-high, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Your background doesn't include classic sales-ops or quota-setting. How do you expect that to show up when you work next to my team?" | JD | [grounded] "No classic sales-ops or quota-setting experience." and "set annual volume targets with cross-org consensus" | **Highest-ROI prep in this pack.** This will be asked in some form, in his own function, and a rehearsed non-defensive answer changes the interview. (1) Pause and restate the question. (2) Name the limit before he presses: "I don't have classic sales-ops or quota-setting experience." (3) Then what your material carries, at its scope: "I set annual volume targets with cross-org consensus." Do not call the targets quotas and do not argue they are equivalent. (4) A plan, not a past: "Before proposing anything, I'd learn from your team how the numbers are built here." Follow-up 1, "Isn't setting volume targets just quota-setting?": hold the sentence and concede in the same breath: "I set annual volume targets with cross-org consensus; I don't have classic quota-setting experience." Follow-up 2, "Then why should I trust you with numbers a field team carries?": hold the same position, concede that trust is earned by how you work with his team, and say what you would do, such as asking his team to review any target logic before it goes anywhere. Follow-up 3, "What would you get wrong first?": answer slot, name the thing you expect to get wrong first in your own words; if you cannot name one, say so plainly. Never fold on the core sentence just to restore harmony, and never add to it | F7 is a stated gap and F5's sentence is the nearest thing, so the objection is aimed exactly where the material is thin. JD because it scores the requirement in this role's sales-adjacent surface. Skeptic delivery, Peer stakes |
| C2 | "I don't see partner-motion design in your background. How would you handle the partner side of this role?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Pause, then the nearest thing your material carries, at its scope: "I built a partner-level revenue model used in carrier negotiations." The limit is the pack's observation: the sentence says a model used in negotiations, not a motion. Answer slot: if your work with carriers went beyond the model, say what and what was yours, in your own words; if it did not, or it was not yours, say so plainly and stay with the model. Then a plan: ask how Northwind works with partners today before proposing anything | F4 is thin against a line the JD marks required, so a skeptic goes here second. JD because it scores the stated requirement. Skeptic delivery |
| C3 | "You've spent nine years at a large consumer-tech company, and Northwind is around 3,000 people with two new product lines to launch. What do you expect to be different?" | JD | [grounded] "11 years — 2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | Answer in your own words from your own view of the difference. Answer slot: if you have worked on something new with few resources, say what and what was yours; if not, say so plainly and say how you would work without a playbook. The honest reason for the move goes here too. Give your real reason in your own words, and link it to one of the three priorities in the research note only if the link is real for you. Do not supply a reason you do not hold | The coach's research note and his startup chapter both point to pace and resourcing probes of a big-company background. F1. JD because it tests fit with the role's conditions. Skeptic delivery |

### D. Case/Strategist (weight: medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A new product line has just launched. How would you find whitespace across land, adopt, expand and renew? What do you need to know first?" | CASE | [generic] | Think aloud in this order. Clarify: who the buyer and user are, what each stage means at Northwind, what data exists, and what decision this serves. Then objective, segmentation by stage and customer type, approach with a hypothesis stated early, metrics, risks. Challenge one premise respectfully. Use Northwind's own stage words: land, adopt, expand, renew. This question asks about no past, and the guidance makes no claim about yours | The JD's whitespace line, F2, as a live problem. `[generic]` because it is a pattern for the problem and not a fact about Northwind |
| D2 | "A much larger platform vendor bundles something similar to our new product into what it already sells. How do you think about pricing and packaging against that?" | CASE | [grounded] research note on the bundling threat | Clarify what the bundle includes and who buys it. Segment the customers a bundle serves well from those it does not. Name the levers (price, packaging, who sells it). Add metrics and risks. Challenge one premise, such as whether the price should be defended at all. Pricing is Dan's native ground, so ask before asserting. The pack observes that the material as given names no pricing work, so if he goes deeper into price mechanics, say plainly where your own material stops and ask how his team does it | The research note names bundling as the main competitive threat, and his pricing spine makes this his home ground. CASE because it is a live problem set in the role |
| D3 | "Northwind's stated priorities are enterprise expansion, the Compass launch and profitability. For a new product line, what does the first plan need to decide, and where do those priorities pull against each other?" | CO | [grounded] research note on the three priorities | Name the three priorities accurately as the consensus item that shows you did the homework. Then the divergence: pick the priority the new line serves first and the one it should not try to serve, state it as a hypothesis, name the evidence that would change your mind, and concede one real cost of your pick. The research note is undated, so confirm the priorities against Northwind's own latest statements before using them by name. This question asks about no past | The three priorities are the strategy frame, and a peer in sales strategy will use them. CO because it tests strategy fluency, with CASE delivery. The pick-plus-anti-pick shape is judgment, where reciting the priorities would only show homework |

### E. Conversational (weight: low-medium, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through the journey: consulting, then consumer tech, and now this." | EXP | [grounded] "11 years — 2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" and "built a partner-level revenue model used in carrier negotiations" and "proposed a store-surface change credited with a ~$400M ARR uplift" | A 90-second arc with four beats. Beat 1 is the first clause of the first quote: "2 years strategy consulting at a top firm". Beat 2 is the second clause: "then 9 at a large consumer-tech company in product strategy & ops". Beat 3 is one or both headline lines at their own scope: "I built a partner-level revenue model used in carrier negotiations" and "I proposed a store-surface change credited with a ~$400M ARR uplift". Beat 4 is why this role. Answer slot: give your own reason in your own words, tied to a line in the role. The pack supplies none. Let him draw the thread between the beats | The biography question is how a conversation like this almost always opens. EXP because it is the CV in narrative form. F1, F2, F4 |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Say it as written: "I use AI tools daily." Answer slot: which tools and for what, in your own words; if the use is ad hoc or personal, say so. Treat the casual register as scored, because the JD flags AI as a plus. If he moves to Compass, think aloud as a user and as a strategist. The pack observes that the material does not show AI product or launch work, so stay with daily use | F6 is a plus-skill, and a casual question on a hot JD topic is the Conversational stem. JD because it scores a stated preference |

### F. Pressure (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over someone who has run sales strategy for years?" | JD | [grounded] "set annual volume targets with cross-org consensus" and "built a partner-level revenue model used in carrier negotiations" and "proposed a store-surface change credited with a ~$400M ARR uplift" and "No classic sales-ops or quota-setting experience." | Hold, then concede, in one minute. Lead with the three sentences at their own scope: "I set annual volume targets with cross-org consensus", "I built a partner-level revenue model used in carrier negotiations" and "I proposed a store-surface change credited with a ~$400M ARR uplift". Then one clause of concession: "I don't have classic sales-ops or quota-setting experience." Do not say what the sentences prove, and let him draw the inference. Hold through two follow-ups by returning to the same sentences, and add nothing to them | This is the Pressure stem for a peer round, aimed at F7. JD because it scores fit to the role. Pressure delivery |
| F2 | "That ~$400M: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause and restate the question. Hold the position the sentence carries: "I proposed a store-surface change credited with a ~$400M ARR uplift." Answer slot: which part was yours beyond the proposal, in your own words; if you do not know how the credit was assigned, or the rest was not yours, say so plainly and stay with "I proposed". Concede specifically what you cannot speak to, and never claim a share you cannot back | The attribution-honesty probe is a Pressure stem, and F2 is the figure it lands on. EXP |

## Requirement coverage

| Requirement | Fit row | Questions |
|---|---|---|
| "own GTM strategy for two new product lines" | F1 | A1, C3, D3 |
| "identify whitespace across land/adopt/expand/renew" | F2 | A5, D1 |
| "run independent analysis in SQL and Tableau" | F3 | B5 |
| "partner-motion design experience required" | F4 | B4, C2 |
| "strong cross-functional influence" | F5 | A2, A3 |
| "AI experience a plus" | F6 | E2 |
| Sales-ops and quota-setting, the interviewer's function | F7 | C1, F1 |
| The ~$400M figure, the headline metric | F2 | A4, B1, B2, B3, F2 |
| Pricing and the bundling threat, from the research note and Dan's profile | none, a research-note item | D2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "Your career has run through pricing and monetization, with one early-stage chapter. What from that chapter do you still use at Northwind's size?" | Ties to his own path and turns the interview into a peer conversation. Check the profile summary is accurate before using it |
| RQ2 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer. It shows you are thinking about his load, not only your own ramp |
| RQ3 | "Where does the line between Sales Strategy and go-to-market for new products sit today, and who settles it when it blurs?" | Puts the seam from A1 and A5 on the table, in his terms, and learns who decides |
| RQ4 | "How is Sales Strategy seeing bundling by the larger platform vendor show up in deals today?" | The research note's main competitive threat, asked of the person closest to deals. It signals homework and invites the practitioner view |
| RQ5 | "Compass is launching alongside the push on enterprise expansion. How do you expect new product lines to sit next to it in how your team plans?" | Uses two of the three stated priorities and probes how the new lines compete for attention |
| RQ6 | "Which numbers does your team trust most, and which do you trust least?" | Lands with a self-described data-driven interviewer and reveals the data landscape you would inherit |
| RQ7 | "What would make this role a clear success at six months, and how would you and I know?" | A shared measure between peers, and it replaces a generic closing question |

## Prohibited claims

Claims this pack will not coach, with the basis and the honest form of each.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or led go-to-market strategy | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says product strategy and ops, not go-to-market. The slots in F1 and C3 stay inside the quote |
| Designed a partner motion | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: a model used in negotiations, not a motion. The slots in B4 and C2 ask only what reached beyond the model |
| Has sales-ops or quota-setting experience | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I don't have classic sales-ops or quota-setting experience." No slot |
| Treated the annual volume targets as quotas | Inflated form of F5, and F7's stated negative | F5's quote at its own scope: "I set annual volume targets with cross-org consensus." Plus F7's plain acknowledgment |
| Delivered, owned or measured the ~$400M ARR uplift | Inflated form of F2 | F2's quote at its own scope: a proposal, credited with the uplift. The credit's source and method are answer slots only |
| AI product, strategy or launch experience | Inflated form of F6 | F6's quote at its own scope: "I use AI tools daily." The limit is the pack's observation |

## Sources

**Provided documents:** the coach's message, which supplied the role and JD highlights, the candidate summary, the interviewer profile summary, and the research note on Northwind's three stated priorities and its main competitive threat. The research note is undated and was not checked against current sources. No `tuesday-dossier.md` was present, and the pack was built from the raw inputs.

Research tier: L0 — no searches

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | No search sent, because consent to research has not been given. Would have moved: a values cheat sheet if a values-style round is documented, and VAL questions |
| 2. `Northwind Data interview process` | skipped | The user's own words fix the loop: one 60-minute conversation with a peer. Persona weights follow it, and no values-style round is detected |
| 3. `Northwind Data strategy` | skipped | The research note supplies the three priorities and the competitive frame, which fix the CO and CASE rows |
| 4. `Dan Kovac Northwind Data` | unavailable | A name was given, so a query could be formed, but no search was sent because consent to research has not been given. Would have moved: an interviewer read grounded in public talks or writing, and a reverse question tied to them |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights supplied fix the JD-tagged rows |

## Upgrade menu

- The full JD text → the six requirement rows now rest on your summary of the JD and would become quoted JD lines. Any gate (location, travel, pay, authorization) or mid-list item the highlights omit would get its own row or question
- The recruiter's guidance (stated focus areas, and any pre-declared deliverable such as a POV or presentation) → coverage that follows the recruiter's steer and, if there is a deliverable, a build section for it
- Consent to research (values, loop structure, strategy, and Dan's public talks or writing) → a values cheat sheet if a values round is documented, an interviewer read grounded in his own words, and a reverse question tied to them. A deeper pass would add a strategy brief and a grounding section
- Priya's own answers to the slots in B1 to B3 and F2 (how the ~$400M figure was counted, what it is sensitive to, the weakest assumption, her part), F3 (an analysis she ran end to end), and F4 (what her carrier work covered beyond the model) → those rows upgrade, and the guidance becomes story-mapped on her words
- An inspectable artifact: the written proposal or results readout behind the ~$400M figure, the revenue model or negotiation deck, or a SQL query or Tableau view she built → F2, F4 and F3 from `medium` toward `high`
- The time Priya has to prepare → a prioritized prep schedule sized to it
- A `tuesday-dossier.md`, if one exists → verified evidence, the underwriter's named objection and absolute prohibited claims, which sharpen the guidance rows
