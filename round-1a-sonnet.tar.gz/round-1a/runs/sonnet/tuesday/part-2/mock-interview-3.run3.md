I'm preparing your Stripe pack from the Mock Interview playbook. I've read its rules and I'm loading the search tools now, to pull Stripe's published values and interview process.
Search wasn't approved, so I'm building the pack from your message alone and labeling everything generic. I'm writing it to a file now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a/runs/sonnet/tuesday/part-2/rooms/case-3-denied-611a6fc7/stripe_product-operations-manager_interview_pack.md`.

I built it for a final round with an unknown interviewer, so persona weights are flat. The web searches I tried weren't approved, so the pack contains no facts about Stripe. Every question is labeled generic. The company-knowledge question (A4) tells you to read current public sources yourself. The upgrade menu lists what each missing input would unlock.

I can play the Skeptic on B2, "Which part of this role would you be weakest at on day one?" The pack names it as the highest-value prep, provisionally, until I can see your background.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Who will you be meeting in the final round (hiring manager, peer, skip-level, cross-functional), and is it one session or several? The answer reweights every question bank.
2. Can you paste the job description and your CV, or a few lines on your work? Without them I can't map your own stories to the questions, though I can proceed without.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Interview pack: Product Operations Manager, Stripe (final round)

Interviewer: not named. Relationship: not stated, so persona weights are flat. Built from one sentence of input: a final-round interview at Stripe for a Product Operations Manager role. No JD, CV, interviewer or round details were provided, and no research ran (see Sources).

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Tag | Meaning |
|---|---|
| VAL | Behavioral and values alignment: does past behavior show the company's published values |
| EXP | Work-experience deep-dive: does a claim survive scrutiny, and what was actually yours |
| JD | Role-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge: how deep is the homework |
| CASE | Live problem from the role: structure and reasoning |

Every question here is labeled generic. Nothing was available to ground it in Stripe, the posting, or your history. The upgrade menu says what would change that.

## Fit snapshot (worksheet variant)

You gave no background, so this is a worksheet to fill in, not an assessment of you. Requirements are role-family patterns, not quotes from a posting. Each bridge column describes what strong evidence looks like and gives a selection scaffold. No row says anything about your past.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinate launches and programs across several functions (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is one named launch or program with the functions involved and your own part in it. Selection scaffold: pick an occasion where several teams depended on each other and something had to land on a date; it needs the teams involved, what you personally did, and how it ended. If no such occasion comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Run or improve an operating cadence: planning, reviews, status rituals (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a recurring process, its purpose, and what changed once it ran. Selection scaffold: pick a recurring meeting, review or planning cycle you ran or reshaped; it needs what it was for and what you changed. If no such process comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Use data to find problems and measure whether product work is landing (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a metric you defined, tracked or reported, with how it was counted and what part was yours. Selection scaffold: pick one figure you have reported; it needs its definition, its source, and the assumption you would defend least. If no such figure comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Design processes or tooling that other teams actually adopt (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a process or tool others used and what was adopted versus ignored. Selection scaffold: pick something you set up that other people had to use; it needs who used it and what happened to it. If no such thing comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Influence without authority; align stakeholders who disagree (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a disagreement, your position, and how it was resolved. Selection scaffold: pick a time you needed people outside your reporting line to change course; it needs the stakes and whether the relationship survived. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Work through ambiguity and set priorities with incomplete information (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a choice you made between competing demands, with the criteria you used. Selection scaffold: pick a time the priorities were unclear and you had to choose; it needs the options and your reason for the call. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

## Persona table

Weights are flat. The relationship to the interviewer is unstated, and no loop source established how many sessions this final holds or who runs them. Treat these weights as a blend: if your final is several back-to-back sessions, each session will lean on a different row.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problems: plan this, diagnose that | High. Final rounds for operations roles tend to include a live problem, and nothing here contradicts it; the case questions need no claim about your past | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully |
| Skeptic | Probes gaps and motivation: why this role, why now, weakest area | High. Any final round tests whether your story survives cross-examination | Rehearse the single most predictable objection until it is boring; build bridges only from adjacent work you can say plainly you did |
| Values / Behavioral | Scenario probes: unpopular truth, customer over a metric | Medium. No values-style round is established here, and none is assumed | Choose stories where the hard truth actually landed; if the material shows none, say so rather than supplying an ending |
| Peer Evaluator | Seam-splitting, collaboration, credit sharing | Medium. Product operations sits between teams, so peer probes are plausible in any loop | Reciprocity framing: what you bring their team. Propose seam principles instead of pretending to know the seam |
| Pressure | Interrupts and time-boxes; tests composure | Medium-low as a style, but a time-boxed question can come from anyone | Pause, restate, anchor in what you stated, hold through two follow-ups before conceding anything real |
| Data-Driven Prober | Presses on how a number was counted | Medium. Operations roles lean on metrics | Know what you can and cannot say about how each figure was counted; say plainly when you do not know |
| Conversational | Friendly, unstructured; still scored | Medium-low, but common as an opener | A 90-second arc for the biography question; treat casual questions about the role as scored |

## Question banks

IDs run by persona so a drill can reference them. Every Provenance cell reads generic because no raising source and no candidate quote existed. Answer slots are instructions for the interview, not questions for this conversation.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A launch is two weeks out and three teams disagree about whether it is ready. What do you do in the next 48 hours?" | CASE | [generic] | Clarify first: what readiness means, who decides, what is at risk if it slips. Then structure: gather each team's concrete blockers, separate must-fix from can-follow, propose a decision with a named owner, and say what you would escalate. Challenge one premise aloud, such as whether a single launch date is fixed. The question needs no claim about your past, so the guidance makes none | Tests F1 and F5 as a live decision. CASE because it scores structure under a deadline |
| A2 | "A feature shipped a quarter ago and adoption is 20 percent below plan. Diagnose it." | CASE | [generic] | Clarify the plan's basis, the metric's definition and the time window before hypothesizing. Segment: who was expected to adopt versus who did, funnel steps, and whether the shortfall is awareness, fit or friction. Name the data you would pull first and the decision each result would change | Tests F3 as a live diagnosis. CASE because it is a metric-drop pattern |
| A3 | "Sketch how you would set up the planning and review cadence for a product org you have just joined. What do you need to know first?" | CASE | [generic] | Open with what you need to know: team count, existing rituals, where decisions stall, who consumes the output. Then objective, minimum viable cadence, how you would test it with one team before rolling out, and how you would tell whether it earned its meeting time | Tests F2 and F4. CASE because it is a design problem from the role's core |
| A4 | "What do you think Stripe's product organization most needs from product operations right now, and what would you want to find out before answering?" | CO | [generic] | This answer must come from current public sources you read before the interview, because nothing in this pack establishes facts about Stripe. Structure it as: what you read, what that suggests, what you would verify with the team. Say plainly what you do not yet know. A confident claim from memory is the failure | Tests the homework depth for the CO slot. Generic by necessity; the upgrade menu says what fixes that |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "So, why product operations, and why Stripe, and why now?" | JD | [generic] | Rehearse a 60-second answer in three beats: what draws you to the function, what draws you to this company, what makes the timing right. Each beat should rest on something true about you that you can say in your own words. Selection scaffold: if the company beat comes from public sources you have read, say which; if no specific reason comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Motivation consistency is scored in nearly every final round. JD because it tests fit with the stated function |
| B2 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | This is the pack's named highest-ROI rehearsal, provisional until a JD and CV exist. Pick your genuine weakest area, name it plainly, and give a concrete ramp plan in terms of what you would do in your first weeks. Hold through two follow-ups: a ramp plan is a plan, not a past achievement. Concede exactly what is true and no more. If you cannot name one, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The gap probe is the most predictable objection in any final round. Its sharpest form depends on your actual gaps, which this pack cannot see |
| B3 | "Tell me about a time you had to learn a function or domain quickly." | EXP | [generic] | Selection scaffold: it needs a named stake, what you did in the first weeks, and what the outcome showed. Pick the instance that best matches this role's ambiguity. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Skeptics test whether adjacent experience transfers. EXP because it checks what you actually did. Covers F6 |
| B4 | "Tell me about a time you were not the right fit for something you took on." | EXP | [generic] | Selection scaffold: it needs what mismatched, what you did about it, and what you learned that changed later behavior. The honest version beats a polished one. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Tests honest self-assessment, which the Skeptic scores. EXP because it asks for a real instance |

### C. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: it needs the truth, the audience, what you risked, and whether the hard truth actually landed. Use we for context and I for your contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioral probe; covers F5. VAL because it scores behavior, not a specific published value, since none was established |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: it needs the customer's problem, the metric you did not serve, and the call you made. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard values probe that fits operations work where internal metrics can pull against users. VAL |
| C3 | "Tell me about a process you set up that other teams ignored or resisted." | VAL | [generic] | Selection scaffold: it needs what you set up, why it met resistance, and what you changed or accepted. A story where you did not win is allowed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Covers F4 from the failure side. VAL because it scores how you act when adoption is not guaranteed |

### D. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles instead of claiming to know this team's seam: who owns the decision, who owns the information, who is informed. Then a disagreement rule: bring data, name the decision owner, agree what would change your mind. Close with what you would offer their team | Product operations lives on seams. JD because it tests the role's core relationship |
| D2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: it needs a concrete case where credit could have been contested and what you did. We for context, I for contribution. If no such case comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Peer interviewers probe credit-sharing. VAL |
| D3 | "What could a new person do in their first month that would genuinely help my team?" | JD | [generic] | A reciprocity answer: listen for pain points, offer to take one recurring chore or reporting gap, and ask what a useful first deliverable looks like. State it as what you would do, not as something you have done | Reverses the peer's pricing of the hire. JD |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, restate, then answer in what the material you hold lets you say plainly. Anchor on one specific thing you bring, in your own words, and avoid comparing yourself to people you have not met. Hold through two follow-ups before conceding anything; concede only what is true | Tests composure and the ability to hold a position. JD |
| E2 | "You have told me you work cross-functionally. Convince me it is more than meetings." | JD | [generic] | Open prompt in guise of a challenge: restate it, then give one instance in your own words where cross-functional work produced a decision or a changed outcome. If no such instance comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Hold, then concede what is genuinely uncertain | Pressure persona's devil's-advocate move on F1 and F5. JD |

### F. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a number you reported. How was it counted?" | EXP | [generic] | Selection scaffold: pick one figure you can defend. Be ready to say how it was counted, what it is sensitive to, which part was yours, and the assumption you would defend least, named before they ask. If you do not know how a figure was counted, say so plainly. If no such figure comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Defend-the-number is the probe operations roles draw. Covers F3. EXP |
| F2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | Answer slot: name the assumption in your own words, and the fix you would make if you could re-run it. If you do not know which assumption is weakest, say so plainly and say what you would check first | The prober's standard second question. EXP |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | Prepare a 90-second arc in your own words: where you started, the two or three turns that led to this role, and why this is the next step. Build it only from what is true, and keep each turn to a sentence | The casual opener is still scored on economy. EXP |
| G2 | "What are you actually playing with in operations or tooling these days?" | JD | [generic] | Answer slot: name something real you have been trying, in your own words, and what you learned. If nothing, say so plainly and name what you would pick up first | Tests genuine interest. JD |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 Launch and program coordination | A1, E2 |
| F2 Operating cadence | A3 |
| F3 Data and measurement | A2, F1, F2 |
| F4 Process and tooling adoption | A3, C3 |
| F5 Influence without authority | A1, C1, D1, E2 |
| F6 Ambiguity and prioritization | B3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a successful first six months in this role look like, and how will you know?" | Shows you think in outcomes and gives you the interviewer's own yardstick to answer against |
| R2 | "Where do product decisions most often stall today, and what has already been tried?" | Signals diagnostic thinking and surfaces the real problem the role exists for |
| R3 | "How does this role work with the product teams it supports: embedded, shared, or request-driven?" | Clarifies the seam before you are asked to propose one |
| R4 | "What is one thing you wish someone in this role had done earlier?" | Invites candor and shows you are planning a ramp |
| R5 | "How is the role's impact measured, and who sees the measure?" | Tests whether the role is accountable to something specific |
| R6 | "What could a new person do in their first month that would genuinely help your team?" | A reciprocity question for a peer interviewer; it shows you are thinking about their load |

## Prohibited claims

Nothing candidate-specific can be listed: no CV, message or dossier supplied a sentence this pack could inflate. The standing limit is below.

| Not coached | Basis | Honest form |
|---|---|---|
| Any claim about your past work, results, ownership or figures that you did not state in your own words | No candidate material was provided, so every story is a selection scaffold | Pick a real instance, say what you did in your own words, and use the honest branch where nothing comes to mind |

## Sources

Provided documents: your message only (company, role, final round).

Searches sent, all refused:

- "Stripe operating principles values": refused
- "Stripe interview process Product Operations Manager": refused
- "Stripe strategy 2026 news": refused
- "Stripe Product Operations Manager job description": refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Would have supplied official value names for a cheat sheet and VAL mapping; nothing about Stripe's values is stated here |
| 2. Stripe interview process, product operations | unavailable | Would have established the final round's sessions and persona weights; the weights here are flat |
| 3. Stripe strategy and recent news | unavailable | Would have grounded A4 and a CO bank; A4 is generic |
| 4. Interviewer name and Stripe | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative Product Operations Manager JD | unavailable | Would have replaced the generic requirements in F1 to F6 with quoted ones |

Loop structure: no loop source established it, so the pack falls back to the generic archetype (screen, hiring manager, panel) with flat weights. That is a pattern, not Stripe's documented process.

## Upgrade menu

- The job description text → the six generic rows in the fit snapshot become quoted requirements, and gate terms such as location or schedule can be checked
- Your CV or a few sentences about your work → the selection scaffolds become story maps built from your own words, and the highest-ROI objection can be named for you
- Who you are meeting and in what order (if your final is several sessions, send the schedule) → persona weights reweight and per-session mini-packs become possible
- The interviewer's name → an interviewer read and a reverse question tied to their path
- Approval to research Stripe's published values, interview process and recent strategy → a values cheat sheet, grounded CO and CASE questions, and fewer generic labels
- A recruiter email on focus areas or any pre-declared deliverable → coverage of any graded assignment
- A tuesday-dossier.md from an earlier session → verified evidence and prohibited claims would constrain the guidance
