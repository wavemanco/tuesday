Web search was refused for both queries (Northwind's values and Dan's public footprint), so I'm building the pack from your inputs alone. I'll record that in the pack's Sources section.
Your prep pack for Priya's conversation with Dan is saved at `/var/tmp/tuesday-measure/1a/runs/sonnet/tuesday/part-2/rooms/case-1-denied-80d0f914/northwind-data_senior-gtm-strategy-lead_interview_pack.md`.

It's a 22-question bank, tabulated by persona and by type. Every question has answer guidance and a rationale. It also has a fit snapshot, a requirement-coverage table, a persona table with the weighting shown, an interviewer read, six reverse questions, a prohibited-claims list and an upgrade menu.

- **Weighting:** because Dan is a peer who self-describes as "relentlessly data-driven" and comes from pricing, the Peer Evaluator and Data-Driven Prober banks carry the most weight, with five questions each.
- **Highest-ROI prep:** question C1. Dan runs sales strategy, and the material says Priya has no classic sales-ops or quota-setting experience, so expect that objection in some form. Second is B1/B2, defending the ~$400M ARR figure. The guidance keeps it at "proposed… credited with", which is all her summary says.
- **No research:** web search was refused for both queries (Northwind's values and Dan's public footprint). The pack is built only from what you gave me. The interviewer read rests on your summary of Dan's profile, and the VAL questions are generic because no published values were read. The Sources section records this.
- **Thin material:** I only had JD highlights and a one-paragraph candidate summary. Each fit-snapshot row rests on a single line, so many guidance cells are answer slots, not story maps.

Say the word and I'll play Dan as the Skeptic on C1, the question the pack names as highest-ROI.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Did the recruiter give any focus areas or pre-work for the conversation with Dan? A declared deliverable would add a build section.
Can you paste the full JD text and Priya's CV? Without them I'll keep working from the highlights, but the pack can't see mid-list requirements.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Mock-interview pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

**Role:** Senior GTM Strategy Lead, Emerging Products, Northwind Data (B2B data-infrastructure SaaS, about 3,000 employees)
**Candidate:** Priya. Written to her, so "you" means Priya.
**Interviewer:** Dan Kovac, Director of Sales Strategy. A peer: he and Priya would report to the same VP.
**Round:** one 60-minute conversation with Dan.
**Built on:** the peer relationship and single-session loop you stated, the JD highlights, a short candidate summary, a summary of Dan's profile, and your research note. Web research was refused in this session, so nothing here comes from a search (see Sources).

**Highest-ROI prep in this pack: C1.** Dan runs sales strategy, and your material states that you have no classic sales-ops or quota-setting experience. Expect that objection in some form, possibly collegial (A4, A5), possibly time-boxed (F1). Rehearse C1 until the plain acknowledgment sounds boring. Second priority: B1 and B2, the defense of the ~$400M ARR figure in front of a self-described "relentlessly data-driven" peer.

## 1. How to use this pack

Personas are how a question arrives. Types are what is being scored.

| Tag | Name | What it is really testing |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the behaviors a role needs. No published Northwind values were read, so VAL rows here are generic |
| EXP | Work-experience deep-dive | Whether the claims on your background survive scrutiny, and what was actually you |
| JD | Role / JD-driven | The stated responsibilities and qualifications, gaps included |
| CO | Company and strategy knowledge | Whether you can think at Northwind's altitude |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the real role |

- Guidance is scaffolding, not a script. Every guidance cell is built to be spoken in 90 to 120 seconds.
- Only sentences quoted in a row's Provenance cell are claims about your past. Everything else in guidance is a method or a slot.
- An **answer slot** is an instruction for the interview, not a question for now. It names something Dan is likely to probe and gives two honest branches: say how it went in your own words, or say plainly that there was no such step or it was not yours. Either branch is a good answer. A confident detail you cannot repeat under a second question is the bad one.
- Provenance labels: `[grounded]` rests on something you supplied, `[inferred]` is a derivation named in the row, `[generic]` is a pattern with no claim about Northwind or you.

## 2. Fit snapshot

The JD side is your highlights, not the full posting. A role with a full JD may carry mid-list requirements this table cannot see.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| S1 | "own GTM strategy for two new product lines" — JD highlights, your message | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — your message | medium | [grounded] | transferability | The material says consulting, then product strategy and ops. It does not say go-to-market and it does not say new product lines, and the words stay at that scope: "Before that, two years in strategy consulting at a top firm. Then nine years in product strategy and ops at a large consumer-tech company." Answer slot: the JD's two new product lines make a probe likely on whether any of that work was bringing something new to market. If any was, say which and what part was yours, in your own words. If none was, or it was not yours, say so plainly and stay with the product strategy and ops work |
| S2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — your message | medium | [grounded] | transferability | Adjacent revenue work, not shown to sit in any customer-lifecycle stage. The words: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." Keep "proposed" and "credited with". Answer slot: the JD names four lifecycle stages, so expect a probe on which one the change acted on. If it acted on one, say which, in your own words. If it does not fit that frame, say so plainly and describe the change as it was |
| S3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — your message | medium | [grounded] | none | No gap on the tools, but a one-line skill claim with nothing inspected behind it, so expect a probe on "independent". Lead with the quote's own terms: "I'm skilled in SQL and Tableau." Answer slot: if there is an analysis you ran yourself from question to output, offer to walk through it. If the analysis work was shared, or someone else's, say so plainly |
| S4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — your message | medium | [grounded] | transferability | Your material says a revenue model at partner level that was used in negotiations. It does not say you designed how a partnership worked, and "required" means Dan will test exactly this. The words: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: if the model shaped how a partner relationship was structured, say how and what was yours. If it priced or measured and nothing more, say so plainly and stay with the model |
| S5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — your message | medium | [grounded] | presentation | The quote already reaches the requirement in other terms. Keep it exactly: "I set annual volume targets with cross-org consensus." Observation for the pack: the sentence says targets, not quotas. Answer slot: if getting to consensus meant resolving a disagreement, say what it was and what you did, in your own words. If there was none, or it was not yours to resolve, say so plainly and stay with the targets |
| S6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — your message | low | [inferred] | discovery | The quote touches the plus without showing whether it reaches work on an AI product; the pack derives that gap and asserts no AI work. Answer slot: with Compass an AI copilot (your research note), expect a casual probe. Name the tools you use and what you use them for, in your own words. If the use is personal productivity, say so plainly |
| S7 | Sales-ops and quota-setting fluency. Not a quoted JD line: plain prose, the likely territory of a Director of Sales Strategy, `[generic]` | "No classic sales-ops or quota-setting experience." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. The words: "I haven't had classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past: ask how targets and quotas are set today before proposing anything. Nothing added to make the gap feel smaller |

Gates: the highlights state no eligibility term (authorization, location, schedule, pay, a credential), so no gate rows were created. If the full JD has one, send it and the row will be added.

## 3. Requirement coverage

| JD requirement | Questions covering it |
|---|---|
| own GTM strategy for two new product lines | F2, D1, D3, E1 |
| identify whitespace across land/adopt/expand/renew | D1, B1 |
| run independent analysis in SQL and Tableau | B4, A4 |
| partner-motion design experience required | B3 |
| strong cross-functional influence | A1, A2, A4 |
| AI experience a plus | B5, E2 |
| Not in the highlights: sales-ops and quota-setting (Dan's likely territory) | C1, C2, F1 |
| Not in the highlights: published values | G1, G2 are generic; no values were read, so this is none, and why: the research was refused |

## 4. Grounding brief

All of this is your research note. It is undated, so confirm it is still current before leaning on it.

| Item | What it says | Provenance | How to use it |
|---|---|---|---|
| Priority 1 | Enterprise expansion | [grounded] your research note | Use "expand" in the land/adopt/expand/renew framing of D1 first |
| Priority 2 | An AI copilot launch, "Compass" | [grounded] your research note | The context for the AI plus (S6) and for D1 and D2 |
| Priority 3 | Reaching profitability | [grounded] your research note | A pricing and unit-economics lens for D3, which is also Dan's native ground |
| Competitive threat | Bundling by a much larger platform vendor | [grounded] your research note | D2. Name the threat as the note states it and no more |

## 5. Reading the interviewer

Source: your summary of Dan's profile. His public footprint was not searched.

| Signal (from your summary) | What it implies for you |
|---|---|
| Self-describes as "relentlessly data-driven" | Every number gets probed to its assumptions: B1 and B2. Know what you can and cannot say about how each figure was counted |
| Career spine in pricing and monetization roles | Expect cases in pricing, packaging and unit economics (D3). Your material does not show pricing work, so do not borrow his vocabulary for your past (prohibited list). Ask him instead (RQ1) |
| One early-stage-startup chapter | Possible probes on pace and scrappiness from someone with nine years in a large company (C3). No quoted sentence carries a startup story, so there is none to offer |
| Peer, same VP | He is pricing what you cost him and add to his work. Lead with reciprocity (A4, RQ3) and propose seam principles rather than claiming to know the seam (A1) |

Mirror opportunities: none offered. A shared career jump needs your side of it in a quoted row, and the material does not show one.

## 6. Persona table

Weights are a shown judgment. Recalibrate if you know something the pack does not.

| Persona | How it shows up with Dan | Likelihood, with the reasoning | Counter-strategy (a rehearsal method, not a claim) | Bank |
|---|---|---|---|---|
| Peer Evaluator | Seams between his team and Emerging Products GTM, "what do you need from me", credit when work spans teams | High. Relationship prior for a peer; no signal pulls it down | Reciprocity framing; seam principles; a disagreement story only if one exists | A, 5 questions |
| Data-Driven Prober | Reads the background line by line, asks how numbers were counted, two follow-ups deep | High. Peer prior plus "relentlessly data-driven" pushes it up, and the ~$400M figure is a magnet | Name the weakest assumption you would defend least before he does; say plainly when you do not know | B, 5 questions |
| Skeptic | Quiet probing of the gaps in S1, S4 and S7 | Medium. A peer will test the objection in collegial packaging, and "required" on partner-motion design raises it | Rehearse the single objection until it is boring; bridge only from adjacent quotes | C, 3 questions |
| Case/Strategist | Live problems on Compass, bundling, pricing | Medium. A peer prior is weak here, but the pricing spine and a strategy-heavy role tilt it up | Clarify, objective, segmentation, approach, metrics, risks; think aloud | D, 3 questions |
| Conversational | Chatty opener, casual AI question | Low to medium. Opening minutes of any conversation; casual questions on hot JD topics still count | A 90-second arc built from your own sentences; treat the casual AI question as scored | E, 2 questions |
| Pressure | Time-boxed "why you" | Low. A peer is not the usual stress interviewer, but a Director testing a gap may time-box | Pause, restate, hold the position through two follow-ups, concede specifically | F, 2 questions |
| Values/Behavioral | Scenario probes | Low. One peer conversation, no values-round source, no published values read | Selection scaffolds; a story only where your material carries one | G, 2 questions |

Loop: your own words establish one 60-minute session with Dan, so no archetype fallback was needed and no values-style round is detected. The values cheat sheet is dropped for that reason.

## 7. Question banks

### A. Peer Evaluator (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our teams will sit side by side. Where do you see the seam between Sales Strategy and GTM for Emerging Products, and what happens when we disagree?" | JD | [grounded] your brief: peer, same VP | Do not pretend to know the seam. Ask what is already agreed between the two teams, then offer principles: the owner of a decision is the one who acts on it, who is consulted is named up front, and an unresolved disagreement goes to the shared VP with both views written down. Say you would test those against how the two teams work today. The question needs no claim about your past | The peer relationship makes the seam the most likely opening; JD because it scores the cross-functional requirement in S5, CASE in delivery |
| A2 | "Tell me about a time you disagreed with a peer in another org and how it resolved." | JD | [grounded] "set annual volume targets with cross-org consensus" | The sentence carries two beats: annual volume targets, and cross-org consensus. If the disagreement happened there, tell it in those beats. Pick an instance with a named disagreement, your position, what moved and a relationship that stayed intact. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | An open prompt themed from the JD's influence line (S5); JD for the requirement, VAL in delivery |
| A3 | "How do you handle credit when work spans teams?" | VAL | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | The sentence says you proposed the change and it was credited with the uplift. Answer slot: if others built or ran it, or shared the credit, say who and what, in your own words. If not, say so plainly and describe how you would handle credit. Keep "proposed" | A peer stem about turf and credit; the ARR claim is where credit questions land (S2); VAL because it scores behavior, not a metric |
| A4 | "What would you need from me in your first 90 days?" | JD | [grounded] "skilled in SQL/Tableau" | Reciprocity first: what you would bring his team, then what you need. You are skilled in SQL and Tableau, so you can offer to take analysis off his team's plate if that would help. As the ask, say you would want to understand how targets and quotas are set today before proposing anything. This is a plan, not a claim | Tests whether the hire adds to or reduces his load; ties to S3 and covers S7 as a plan rather than a past |
| A5 | "If we set up the handoffs between GTM for the new lines and my team, which numbers would you want to own and which would you expect us to?" | CASE | [generic] | Structure: the decision a number feeds, who acts on it, who maintains the definition. Principle: whoever acts on a number owns its definition, and shared definitions get agreed before dashboards do. Say what you would need to ask before committing to a split. The question needs no claim about your past | A seam problem in a data-driven peer's language; CASE because it is a live design problem |

### B. Data-Driven Prober (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Defend the number in your own words. Say what the sentence says: you proposed the change and it was credited with the uplift. Answer slots: how the figure was counted, what it is sensitive to, and which assumption behind it you would defend least. Name that assumption before he does. If you do not know how it was counted, say so plainly | A headline number in front of a self-described data-driven interviewer (S2); EXP because it scores whether the claim survives scrutiny |
| B2 | "Credited by whom, and how much of that was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Stay at the sentence's scope: proposed, credited with. Answer slot: if you know who credited it and on what basis, say so; if you do not, say so plainly. Answer slot: which part of the outcome was yours; if part was not, say which, plainly. Do not move from "proposed" to a larger verb | The second-level follow-up to B1, and the attribution probe the persona exists for; EXP because it tests what was actually you |
| B3 | "The role requires partner-motion design experience. Walk me through the partner-level revenue model: what went into it, and how it was used in carrier negotiations." | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story-map on the sentence's beats only: you built the model, it was at partner level, it was used in carrier negotiations. Answer slot: what went into it and who supplied the inputs, in your own words. Answer slot: how it was used in the negotiations, and whether you were in the room; if you were not, or others used it, say so plainly and stay with the model | The only requirement marked "required" (S4); JD because it tests that requirement through its nearest quote, EXP in delivery |
| B4 | "The JD says independent analysis in SQL and Tableau. Tell me about the most recent analysis you ran yourself, start to finish." | JD | [grounded] "skilled in SQL/Tableau" | You are skilled in SQL and Tableau. Pick an instance where you can state the question, where the data came from, what you did with it and what changed because of it. If none comes to mind that you ran start to finish, say so plainly, then give the nearest thing your material does carry, or how you would run one | A data-driven peer will ask to see the tool claim in use (S3); JD because it scores the stated skill |
| B5 | "Tell me about the last time an AI tool gave you a wrong or misleading answer. What did you check, and what did you change?" | JD | [inferred] "uses AI tools daily" | Derivation: the JD makes AI a plus and your note makes Compass a priority, so a prober will test judgment with the tools, not only use. Pick an instance with a named tool, what went wrong, what caught it and what you changed. If none comes to mind, say so plainly and describe how you check AI output, or how you would | A prober tests the AI claim at its weakest point (S6); JD for the plus, EXP in delivery |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "I don't see classic sales-ops or quota-setting in your background. How do you plan to work with that gap on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience." and "set annual volume targets with cross-org consensus" | **Deepest rehearsal.** Level 1, the acknowledgment, said first and flat: "I haven't had classic sales-ops or quota-setting experience." Follow-up 1, "So what do you bring on the numbers side?": the targets sentence at its own scope, "I set annual volume targets with cross-org consensus." Follow-up 2, "That is not the same thing, is it?": hold the sentence exactly as it reads and repeat the acknowledgment as your concession; do not widen the sentence to meet the objection. Follow-up 3, "What would you need from my team?": a plan, not a past. Ask how targets and quotas are set today before proposing anything | The most predictable objection: Dan's seat meets the one gap you stated (S7). JD in the sense that the role sits next to his work; EXP in delivery |
| C2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience." | Name one weakness and a ramp plan, in your own words. The honest candidates are the ones the pack's snapshot shows (S1, S4, S7). Pick the one you are surest of and say it plainly, then say how you would close it. For S7 the words are: "I haven't had classic sales-ops or quota-setting experience." Do not name a weakness you are inventing | A Skeptic stem; scores calibrated candor over bluffing a competency the interviewer may own |
| C3 | "Most of your career has been inside one large company. What makes you think a new product line inside a 3,000-person company will feel different, and why do you want that?" | EXP | [grounded] "then 9 at a large consumer-tech company in product strategy & ops" | State the fact as it stands: nine years in product strategy and ops at a large consumer-tech company. Answer slot: give your actual reason for this role and this move, in your own words; the pack supplies none. If part of your reason is about pace or ownership, say that plainly and do not dress it as scrappiness you did not describe | Motivation and adaptability are a Skeptic's fixed ground, and Dan has a startup chapter (reading the interviewer); EXP because it tests the career path |

### D. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Compass is launching. You have two weeks to propose how we find whitespace across land, adopt, expand and renew for it. What do you need to know first?" | JD | [grounded] your research note: Compass, enterprise expansion | Structure aloud: clarify (who the target customers are, what usage data exists, which stage is already owned), objective, segmentation, approach, metrics, risks. Challenge one premise politely, for example whether to start with expand given the stated enterprise-expansion priority. Say which cuts you would run yourself in SQL and Tableau. The question needs no claim about your past | The whitespace line from the JD (S2) as a live problem on the actual launch; JD content, CASE delivery |
| D2 | "A much larger platform vendor starts bundling a competing capability into its suite. How does that change your plan for Compass?" | CO | [grounded] your research note: bundling by a much larger platform vendor | Clarify first: is Compass sold alone or attached to something existing, and which customers overlap with the bundle. Segment by exposure to the bundle, say where you would defend and where you would not compete, and name the signal you would watch. Use the threat as the note states it, no more. The question needs no claim about your past | The named main competitive threat, in a data-driven peer's frame; CO because it tests strategy fluency, CASE in delivery |
| D3 | "Profitability is one of the three priorities. For a new line with an uncertain adoption curve, how would you decide whether to price for landing customers or for margin?" | CASE | [grounded] your research note: reaching profitability | State a hypothesis, name the trade-off, say what data you would pull and what would change your mind. Invite his view: it is his home ground. Do not present this as pricing experience from your past; the question needs no such claim | Dan's pricing and monetization spine, applied to a stated priority; CASE because it is a live problem |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc whose factual beats are the sentence's: two years in strategy consulting at a top firm, then nine in product strategy and ops at a large consumer-tech company. Answer slot: why this role and why now, in your own words. Pick one or two items from your quoted material (S2, S4, S5) to leave him with, at their own scope | The standard opener, and a casual register that is still scored (S1) |
| E2 | "What are you actually playing with in AI these days?" | JD | [inferred] "uses AI tools daily" | Derivation as in B5. Name the tools and one thing you use them for, in your own words. If the use is mostly personal productivity, say so plainly. Treat it as scored | The JD plus, asked casually (S6) |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over a candidate who has run sales ops and quotas?" | JD | [grounded] "No classic sales-ops or quota-setting experience." and "built a partner-level revenue model used in carrier negotiations" and "set annual volume targets with cross-org consensus" | Pause, restate the question. Hold: what you bring, using only the two quoted sentences at their scope. Concede specifically: "I haven't had classic sales-ops or quota-setting experience." Hold through two follow-ups by returning to the quotes, not by adding to them | The time-boxed version of C1 (S7) |
| F2 | "Why should we trust you to own GTM for a new product line?" | JD | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | Hold only what the sentence carries. Answer slot: if you have brought something new to market, say what and which part was yours, in your own words. If you have not, say so plainly and say how you would spend the first 90 days. Do not widen product strategy and ops into go-to-market | The JD's headline ownership line pressed hardest (S1) |

### G. Values/Behavioral (generic: no published values were read)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a truth that was hard to hear, a reaction, and a relationship that was intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem, kept because a peer conversation can still drift here |
| G2 | "When have you put a customer outcome ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision with a named metric, a named customer outcome, what you gave up and how it was received. Dan is data-driven, so name the metric as well as the customer. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem, tuned to a metrics-minded listener |

## 8. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "Your career has been in pricing and monetization. When a new line's pricing and packaging are still moving, what do you want the GTM owner to bring you so it is not a surprise?" | Tied to his own path; it invites the expert and shows you read him rather than only the company |
| RQ2 | "You had an early-stage chapter before this. What did it change about how you judge an early motion when the data is thin?" | Tied to his path; it turns the scrappiness probe into a peer conversation and speaks to his data-driven side |
| RQ3 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer |
| RQ4 | "Where do you expect the seam between your team and Emerging Products GTM to be hardest, and how has the VP wanted disagreements handled?" | Moves A1 from your hypothesis to his experience, and shows you think about the shared reporting line |
| RQ5 | "With bundling by a larger vendor as the main competitive threat, what is the first signal in your data you would watch?" | CO in his language; uses your research without reciting it |
| RQ6 | "What would a strong first 90 days look like for this role, in numbers you would check?" | Fits a data-driven interviewer and makes the bar explicit |

## 9. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or led go-to-market for a new product line | Inflated form of S1 | S1's quote at its own scope. The limit is the pack's observation: the material says product strategy and ops, not go-to-market. F2's slot stays inside that |
| Drove, delivered or owned the ~$400M ARR uplift, or called it expansion or renewal revenue | Inflated form of S2 | S2's quote at its own scope: "proposed" and "credited with". B1 and B2 slots stay inside it |
| Designed a partner motion, or led carrier negotiations | Inflated form of S4 | S4's quote: "built a partner-level revenue model used in carrier negotiations". B3's slots stay inside the model |
| Has pricing or monetization experience | Inflated form of S4: a revenue model is a different kind of work from pricing | S4's quote at its own scope. D3 asks for reasoning and makes no claim about your past |
| Set sales quotas, or has sales-ops experience | Negative you stated, S7; also the stretched form of S5's sentence | The plain acknowledgment S7 gives: "I haven't had classic sales-ops or quota-setting experience." The targets sentence stays at its own scope. No slot |
| Built, shipped or led an AI product or feature | Inflated form of S6 | S6's quote at its own scope: "uses AI tools daily". The pack's observation: the material shows use, not work on an AI product |

## 10. Sources

**Provided documents:** your message (role and company, JD highlights, candidate summary, interviewer profile summary, research note). No `tuesday-dossier.md` was present.

**Searches sent (both refused by the host permission prompt, none retried):**
- "Northwind Data B2B data infrastructure company values": refused
- "Dan Kovac Director of Sales Strategy Northwind Data": refused

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | The search was refused. It would have supplied official value names for VAL questions. Without it G1 and G2 are generic, and with no values-style round detected the values cheat sheet would be dropped anyway |
| 2. `Northwind Data interview process {role family}` | skipped | Your own words establish the loop: one 60-minute conversation with a peer. Persona weights follow from that, so a search could not have moved them |
| 3. `Northwind Data strategy` / recent news | skipped | Your research note already supplies the three priorities and the competitive threat, which fix the CO and CASE bank. The note is undated; the upgrade menu offers a currency check |
| 4. `Dan Kovac Northwind Data` | unavailable | The search was refused. It would have added talks and writing to the interviewer read and to RQ1 and RQ2. The read rests on your summary of his profile |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions |

## 11. Upgrade menu

- Full JD text → the six quoted requirements become full-JD quotes, mid-list requirements this pack cannot see get questions, and any gate (location, authorization, pay) gets its row
- Priya's CV → each snapshot row currently rests on one line of a summary; a CV could carry a story for S1, S2, S4 or S6 and turn several answer slots into story maps
- Priya's own answers to the slots in S1, S2, S4, S5 and S6 → each becomes quoted evidence and the rows that draw on it regenerate
- The recruiter's guidance on focus areas, or any pre-work for the Dan conversation → coverage matched to what is scored, and a build section for any declared deliverable
- Search permission, or deep research (up to 6 further searches and 2 further fetches, several more minutes, run only on your say-so) → Northwind's published values by name, Dan's talks and writing, a currency check on your research note, and role-family loop reports
- Prep time available → a prioritized prep schedule sized to it
- A `tuesday-dossier.md` → verified evidence and the most likely objection derived from evidence instead of inferred, plus a guardrail list for claims you may not make
