Search was refused on all four research targets, so I'm building the pack from your JD and background only. I'll flag what that costs in the pack itself.
Femi, your prep pack is saved as `/var/tmp/tuesday-measure/1a/runs/sonnet/tuesday/part-2/rooms/case-7-denied-ca13b1d0/saltmarsh-games_live-operations-producer_interview_pack.md`. It has 21 questions, plus a fit snapshot, persona weights, reverse questions and a list of claims it won't coach.

I built it for a hiring-manager round with Tobias, since your note didn't say otherwise. All four web searches (Saltmarsh's values, interview process, strategy, and Tobias) were refused, so it uses only your JD and background. That means no interviewer read, no values sheet, and the company-knowledge questions (D2, D3) are generic.

- **Highest-ROI prep:** B1, "You haven't worked on a game with in-app purchases." Say the plain acknowledgment once, then give a plan for getting up to speed.
- **Next in line:** The Skeptic round will also press on "never led a team" (B4) and on running calendars for two titles when your material shows one (B2).
- **Your strongest ground:** The calendar, the release checklist and the retention numbers. The pack uses your own sentences at their own scope and leaves answer slots where your material is silent, so you fill those in honestly rather than from the pack.

Say the word and I'll play the Skeptic on B1 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias your future manager, and did the recruiter mention any focus areas or something to prepare, such as a presentation or a case? The answer reweights every bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations
**Round:** one 60-minute interview, on Friday. Relationship assumed to be hiring manager, because nothing in your message says otherwise; if that is wrong, the persona weights change (see the upgrade menu).

## How to use this pack

Personas describe how a question is asked. Types describe what it is scoring. Guidance is scaffolding for a spoken answer, not a script: where it quotes you, it uses your own words at their own scope, and where your material is silent it gives you an answer slot to fill honestly in the interview.

| Type | What it scores |
|---|---|
| VAL | Behavior against the company's published values |
| EXP | Whether claims in your background survive scrutiny |
| JD | Stated responsibilities and qualifications, gaps included |
| CO | Knowledge of the company and its games |
| CASE | A live problem from the actual role |

## Prep triage

Three days. Do these in order; everything else is insurance.

| Order | Do this | Where |
|---|---|---|
| 1 | Say the in-app purchase acknowledgment and your plan aloud until it is boring, then run the sixty-second version | B1, then G1 |
| 2 | Talk each case through aloud, thinking out loud, in the order the guidance gives | A1 to A5 |
| 3 | Write your own answers to the answer slots on the calendar, checklist and retention rows, then rehearse them | A4, B2, B4, C1 |
| 4 | Time your 90-second arc | D1 |
| 5 | Play both Saltmarsh titles, note one mechanic and one question for each, and pick your reverse questions | D3, RQ1 to RQ6 |

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | Your material gives the years and the title, and does not show whether the main title ran as a live service; the words stay at "4 years as an associate producer at a puzzle-game studio." Answer slot: the JD's live-service line makes a probe likely. If the main title ran as a live service, say what that meant for how you worked, in your own words; if it did not, or you are unsure it fits that description, say so plainly and stay with the weekly drops you ran |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead with it in the quote's own terms: you ran it, weekly, for the main title, for two years |
| F3 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | The words stay at the quote: "I ran the weekly content-drop calendar for our main title for the last two years." Your material names content drops for the main title and shows no events and no second title. Answer slot: the JD's two-titles line makes a probe likely. If you planned events, or fed another title's calendar, say which and how, in your own words; if not, say so plainly and stay with the calendar you ran |
| F4 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show this one. Answer slot: if you coordinated any of these disciplines on a drop, say which and how, in your own words; if you did not, or it was not yours, say so plainly and say how you would start |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | The words stay at the quote: "Presented the monthly retention numbers to the studio head." Your material says presented, not wrote the review or defined the KPIs. Answer slot: the JD's own line makes a probe on who defined the KPIs and who wrote reviews likely. If any were yours, say which, in your own words; if you presented numbers someone else defined, say so plainly and stay with presenting them |
| F6 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | The JD names the same artifact you did, so lead with it in the quote's terms: you wrote the release checklist, and your QA team still uses it. Your material says written, not run on each release, and nothing is added to it here |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | presentation | Lead with it in the quote's terms: you presented the monthly retention numbers to the studio head. Your material does not say which measures or how they were counted, so expect that probe (C1) |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | discovery | The checklist is the one written artifact your material names, and it does not show other writing. Answer slot: if other documents of yours were relied on by others, say which; if the checklist is the main one, say so and stay with it |
| F9 | Monetization and in-app purchase literacy. Not in the JD; listed because your message states a gap here | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you have stated it. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Never a claim to equivalent work, and nothing added to make the gap feel smaller |
| F10 | Leading a team. Not in the JD, which says coordinate, not lead; listed because your message states it | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | Words: "I haven't led a team." Then how you would get commitments without authority, said as a plan and never as a past |

## Persona table

Weights start from the hiring-manager prior and are adjusted by the loop. Nothing establishes more than one session, and no source describes Saltmarsh's process, so the loop falls back to the generic archetype with flat tilt. Recalibrate if you know more.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems from the role: plan this calendar, diagnose this drop | High. Hiring-manager prior, and the JD is a list of running-the-calendar tasks | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise |
| Skeptic | Quiet probing of the in-app purchase gap, the two-titles step and the team-leading gap | High. Hiring-manager prior, and your message states two gaps | Rehearse B1 until boring; calibrated candor, no bluffing; a plan for each gap |
| Data-Driven Prober | Line-by-line on the retention numbers and the checklist | Medium. The JD names retention metrics and KPIs, and your retention work is quotable | Know how the numbers were counted and say plainly when you do not |
| Conversational | Friendly journey and "what are you playing" questions | Medium. Common opener in a 60-minute single session, still scored | Scripted 90-second arc; treat casual questions as scored |
| Peer Evaluator | Seam questions between producer and design, art or engineering | Medium. The JD's coordination line is entirely cross-team | Seam principles as proposals; reciprocity; disagreement with spine and tact |
| Pressure | Time-boxed "why you" and "how much was you" | Low. Not a prior for a hiring manager | Pause, restate, hold two follow-ups, concede specifically |
| Values/Behavioral | Scenario probes against published values | Low, no bank. No values round is documented, and no published values were read | Not applicable until a values round is shown |

## Question banks

### A. Case/Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've just inherited the live-events calendar for a mobile title. What do you need to know first, and how would you structure the next eight weeks?" | CASE | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Think aloud in order: what you need to know (goals, what is already scheduled, which teams are constrained), objective, segments of the player base, approach to the calendar, metrics, risks. Challenge one premise respectfully. You may say once, in the quote's terms, "I ran the weekly content-drop calendar for our main title for the last two years", then go back to structure. Answer slot: if you ran events and not only drops, say how the two differed, in your own words; if the work was drops only, say so plainly and ask what an event adds | F3 is the nearest evidence to the JD's calendar line, and the calendar is the most direct live problem a hiring manager can set. CASE because it scores structure over a right answer |
| A2 | "Retention for an event's players came in 20% below the previous event's. Diagnose it." | CASE | [generic] | Clarify first: which retention measure, over what window, against what baseline, and whether the data can be trusted. Then split the problem: who played, platform and version, event content and timing, anything else live at the same time, the release itself. Say what you would check first and why, and name the assumption you are least sure of. The question needs no claim about your past, so the guidance makes none | F7's requirement turned into a live problem. CASE because it tests diagnosis, and `[generic]` because it is a pattern for the problem, not a fact about this employer |
| A3 | "A designer, an artist and an engineer each tell you their part of Thursday's update will slip two days, and community has already announced the date. What do you do?" | CASE | [generic] | Ask what is driving each slip; find which slips are independent and which block the others; list what can be cut, staggered or moved; say who decides and what you bring them; then say what community is told and when. Close by saying what you would record for the post-event review. No claim about your past | F4's coordination line asked as a decision rather than a history. CASE because there is a right structure but no right answer |
| A4 | "Walk me through how you would run the release checklist with QA for an event going live on Thursday." | JD | [grounded] "Wrote the release checklist our QA team still uses." | Open in the quote's terms: "I wrote the release checklist our QA team still uses." Then describe, as a plan for this event, what you would check and when, and where QA would own an item and where you would. Answer slot: the JD says manage the checklist with QA, so expect a probe on how releases ran against yours. If you ran releases against it with QA, say how, in your own words; if QA ran it, or you only wrote it, say so plainly and stay with the checklist you wrote | F6 is the JD's named artifact, so this is a near-certain topic. JD because it scores the stated responsibility, with CASE delivery |
| A5 | "Two titles want a big event in the same week, and they share art and QA. How do you decide?" | CASE | [generic] | Ask what each event is for and what is fixed; what is shared and what is not; the cost of delay on each side. Then options (stagger, scale one down, move one), who decides and what you bring them, and what you tell both teams. Say when you would escalate. No claim about your past | F3's two-titles line as a live problem, since the calendar claim stops at one title. CASE because it scores prioritization under shared constraints |

### B. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't worked on a game with in-app purchases. How would you get up to speed on the economy of a game that has them?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "Presented the monthly retention numbers to the studio head." | The highest-ROI rehearsal in this pack. Start with the plain acknowledgment: "I haven't worked on a game with in-app purchases." Say it once, evenly, without apologizing or padding. Then give the plan as a plan: what you would ask to see and who you would sit with in the first weeks, in your own words. You may add one fact in the quote's terms: "I presented the monthly retention numbers to the studio head." Hold through two follow-ups by returning to those two sentences. Concede specifically that you have no purchase-economy experience, and do not suggest your puzzle-game work covers it | F9 is the largest gap you stated, and F5's KPI line is where it is most likely to be pressed, so this question arrives in some form. JD because it scores the role's metrics responsibility |
| B2 | "The role runs calendars for two titles. Tell me about the calendar you ran and where two titles would stretch it." | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Tell the calendar in the quote's terms: weekly, the main title, two years. Answer slot: if you ever planned for or fed another title's calendar, say how; if not, say so plainly and say what you would set up first. Where two titles would stretch it is your own thinking: name the one stretch point you would watch first and why. Hold by returning to the calendar you ran | F3 and F2 together: the calendar is quotable and the second title is not. JD because it scores the stated two-titles requirement |
| B3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Name a real thin spot, first, before they do. Your material supports "I haven't worked on a game with in-app purchases." If a different part feels weaker to you, say that one and say plainly why. Then say what you would do about it in the first weeks, as a plan. Do not offer a disguised strength | F9 and F4 are the thinnest rows. JD because it asks you to read the posting against yourself |
| B4 | "You haven't led a team, and this role coordinates design, art, engineering and community on each update. How would you get commitments from those teams?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Acknowledge once: "I haven't led a team." Then the method as a plan, in your own words: what you would ask each discipline for, by when, and what you would do when a date is at risk. Answer slot: the JD's coordination line makes a probe on past coordination likely. If you coordinated any of these disciplines on a drop, say which and how; if you did not, or it was not yours, say so plainly and say how you would start. Hold through two follow-ups by returning to the plan, never by claiming coordination you did not do | F10 and F4 together. JD because it scores the coordination requirement |
| B5 | "The role asks for three-plus years producing live-service games or apps. How do your four years fit?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." | Say it in the quotes' terms: "4 years as an associate producer at a puzzle-game studio", the last two running the weekly content-drop calendar for the main title. Answer slot: the live-service wording is the JD's. If the main title ran as a live service, say what that meant for how you worked, in your own words; if you are unsure it fits that description, say so plainly and describe the weekly drops. Do not shorten "associate producer" to "producer" | F1 is the requirement the posting states as a number, so it is asked directly. JD because it scores the stated qualification |

### C. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You presented the monthly retention numbers. Walk me through how one of them was counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Say what you did in the quote's terms: "I presented the monthly retention numbers to the studio head." Answer slots, each in your own words: how a number was counted; what it is sensitive to; the assumption behind it you would defend least; which part was yours, building it or presenting it. "I don't know how it was counted" is an honest answer. If a slot was not yours, say so plainly and return to presenting | F7 and F5. EXP because it tests whether the figures survive scrutiny |
| C2 | "What goes into a good post-event review, in your view?" | JD | [generic] | Structure: the goal restated, what happened against it, why (who played, timing, issues), what is worth repeating or changing, owners and dates. Answer slot: the JD says own the post-event review and the KPIs it reports. If you wrote reviews after drops, say what yours covered, in your own words; if you did not, say so plainly and say how you would build one | F5's requirement asked as a design question, so it needs no claim about your past. JD because it scores the stated responsibility |
| C3 | "Tell me about the release checklist you wrote." | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Say it in the quote's terms: "I wrote the release checklist our QA team still uses." Answer slot: what is in it and what led you to write it, in your own words; if there was no particular trigger, say so. Stay at what the quote says and do not describe its reach beyond your QA team | F6 and F8. EXP because it tests what you actually did |

### D. Conversational (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc built only from these four sentences, in that order, each in your own words at its own scope. A fifth beat, why this role and why now, is yours to supply: say your own reason, because the pack gives none | F1 to F7. EXP because it tests the story's consistency, in the casual register that is still scored |
| D2 | "What are you actually playing at the moment, and what would you steal from it for a live event?" | CO | [generic] | Name a game you really play and one specific mechanic you noticed, then what you would take from it. If you do not play mobile live-service games, say what you do play and what you would go and look at. Say only what you have seen | A casual question on a hot topic for this role, and scored. CO because it tests whether you follow the field |
| D3 | "What do you already know about our two titles, and what would you want to find out?" | CO | [generic] | This pack holds no facts about Saltmarsh's titles, because research was refused. Before Friday, play both, note one event or loop mechanic and one question for each, and say only what you saw. Mark what you know against what you are guessing | The generic cost of missing research; the upgrade menu says what would fix it. CO because it tests homework depth |

### E. Peer Evaluator (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Design and engineering each think the update date is theirs to set. Where is the seam between a producer and them, and what happens when we disagree?" | JD | [generic] | Offer seam principles as proposals and ask where Saltmarsh draws the line, rather than claiming to know it. Add what you bring them, in reciprocity: one clear picture of what ships when. Answer slot: if you have disagreed with a design or engineering lead about a date, say what happened and what you did, in your own words; if not, say so plainly and say how you would handle it | F4's coordination line, asked as collaboration. JD because it scores the stated requirement |
| E2 | "How do you handle credit when work spans teams?" | EXP | [generic] | State the principle you actually hold, in your own words. Give one real instance if you have one; if no instance comes to mind, say so plainly and say how you would handle it. Do not invent a story to fit | A standard peer probe for cross-team roles, and the JD's coordination line (F4) makes it likely. EXP because it tests behavior, not published values |
| E3 | "What does clear written communication look like on a live update: what do you send, to whom, and when?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Describe the shape you would use, as a plan. The checklist is the one written artifact your material names: "I wrote the release checklist our QA team still uses." Answer slot: if other documents of yours were relied on by others, say which; if the checklist is the main one, say so and stay with it. Offer to bring a sample | F8's requirement, asked concretely. JD because it scores the stated communication requirement |

### G. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over a candidate who has run live events with in-app purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." "Never led a team, and never worked on a game with in-app purchases." | Hold on the three facts, in those terms, in order, and stop; let them draw the inference, and do not say your work proves you can learn the economy. Concede specifically: "I haven't worked on a game with in-app purchases." Hold through two follow-ups by returning to the three sentences, never by adding to them | F9 is the sharpest edge of the comparison. JD because it scores fit against the posting, with Pressure delivery |
| G2 | "That calendar you ran — how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: say which parts were yours to decide and which were set by someone else, in your own words; if the calendar was largely handed to you, say so plainly. Hold the position by returning to the quote, "I ran the weekly content-drop calendar for our main title for the last two years", and concede specifically what was not yours | F2 and F3 rest on this one sentence, so attribution is where it will be tested. EXP because it tests what was actually yours |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A1, A5, B2 |
| "coordinate design, art, engineering and community teams on each update" | A3, B4, E1 |
| "own the post-event review and the KPIs it reports" | B1, C2 |
| "manage the release checklist with QA" | A4, C3 |
| "3+ years producing live-service games or apps" | B5 |
| "experience running a content calendar" | B2, A1 |
| "comfortable with player-retention metrics" | C2, A2, C1 |
| "clear written communication" | E3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "What would a good first 90 days look like for this role?" | It shows you are planning to deliver, and the answer tells you what he will measure |
| RQ2 | "How is the live-events calendar set today, and who decides when a date has to move?" | It goes straight to the coordination seam in the JD |
| RQ3 | "Where do updates most often slip here, and what usually causes it?" | It shows you think from the release checklist and risk, not only the plan |
| RQ4 | "How is a post-event review used afterwards: who reads it, and what has it changed?" | It tests whether the review and KPI ownership the JD names have real weight |
| RQ5 | "How is a producer's time usually split between the two titles?" | It shows you have read the two-titles line and are thinking about load |
| RQ6 | "What would you want a new producer who hasn't worked on in-app purchases to learn in their first month?" | It turns your stated gap into a plan he can shape, and shows you named it before he did |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has worked on a game with in-app purchases, or has equivalent monetization experience | Negative you stated, F9 | The plain acknowledgment F9 gives: "I haven't worked on a game with in-app purchases." No slot |
| Has led a team | Negative you stated, F10 | "I haven't led a team." No slot |
| Ran the live-events calendar for two titles | Inflated form of F3 | F3's quote at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." The limit is the pack's observation: the material names content drops for the main title, not events and not two titles |
| Owns the post-event review and the KPIs it reports | Inflated form of F5 | F5's quote at its own scope: "Presented the monthly retention numbers to the studio head." The limit is the pack's observation: the material says presented, not wrote or owned |
| Manages the release checklist with QA | Inflated form of F6 | F6's quote at its own scope: "Wrote the release checklist our QA team still uses." The limit is the pack's observation: the material says written, not run on each release |
| Has three or more years producing live-service games | Inflated form of F1 | F1's quote at its own scope: "4 years as an associate producer at a puzzle-game studio." The limit is the pack's observation: the material gives associate producer and does not show live service |

## Sources

Provided documents: the job description text and your background, both pasted in your message. No tuesday-dossier.md was present.

Searches sent, none returned anything:

- "Saltmarsh Games values mobile game studio" — refused
- "Saltmarsh Games Live Operations Producer interview process" — refused
- "Saltmarsh Games strategy news mobile titles" — refused
- "Tobias Wrenfield Saltmarsh Games Head of Live Operations" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Would have moved a values cheat sheet and VAL themes; no published values were read, so none are used |
| 2. `Saltmarsh Games interview process live operations` | unavailable | Would have moved loop structure and persona weights; the loop rests on your message and the generic archetype |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | Would have moved the CO bank and a strategy-grounded CASE; D2 and D3 are `[generic]` |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Would have moved the interviewer read, persona adjustments and a reverse question tied to his path; all are absent |
| 5. representative `Live Operations Producer` JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Tobias Wrenfield's public profile, talks or posts (paste them, or let a search run) → an interviewer read, persona weights adjusted to his public footprint, and a reverse question tied to his career path
- Saltmarsh's published values, interview process and current strategy (pasted pages, a recruiter email, or a search) → a values cheat sheet if a values round exists, strategy-grounded CO and CASE questions, and D2 and D3 become `[grounded]`
- A deeper research pass, if search becomes available: up to 6 more searches and 2 more fetches, several more minutes → a strategy brief and role-family loop reports
- Your CV lines for these roles → F1 to F8 quote the CV as well as your message, and more rows can be graded on specifics
- A copy of the release checklist, a monthly retention report excerpt or a content calendar from your last role, names removed → F6 and F7 can move from `medium` to `high`, and F2 gains an inspectable artifact
- Your answers to the answer slots on F1, F3, F4, F5 and F6 → each becomes a quoted sentence, and the rows and banks that draw on it are regenerated
- The recruiter's guidance on focus areas, or any pre-declared deliverable such as a presentation or a case → coverage tuned to what is announced, and a build section for any deliverable
- Whether Tobias is your future manager, a peer or a skip-level → persona weights recomputed and the banks reordered
- A tuesday-dossier.md from a prior job-underwriter pass would add verified evidence and any prohibited claims, replacing the ones built here from your message
