Web searches for Atlas Freight were refused, so I'm building the pack from your JD and background alone and will mark it that way. Writing it now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a/runs/sonnet/tuesday/part-2/rooms/case-2-denied-2d55387f/Atlas-Freight_operations-manager_interview_pack.md`. It has 21 questions across seven interviewer styles, plus a fit snapshot against the JD, reverse questions and a short prep schedule.

I built it for a hiring-manager round, since you didn't say who you're meeting. The three web searches I tried on Atlas Freight were refused, so nothing in the pack comes from research on them. Their values, interview format and strategy questions are generic, and the pack labels them that way.

The most likely line of questioning is scale: you lead 3 supervisors now, and the role has 12 across 4 sites. Question A2 is the one to rehearse first. The pack coaches you to say the number plainly and answer from what you told me.

Three other things to know:
- **Power BI:** the pack coaches you to say you haven't used it and to give a plan for learning it. It does not coach any claim to Power BI work.
- **The 40% mis-pick cut:** be ready to say how it was counted and which part was yours. If you don't know how it was counted, saying so plainly is a fine answer.
- **Your 7 years:** the JD wants 5+ years of operations leadership. Your message doesn't say how many of your 7 years were in a lead or supervisory role, so the pack asks you to state that number yourself.

Say the word and I'll run a live drill as the Skeptic on A2. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions, or convert the pack to Word.

Is your first interview with a hiring manager, a recruiter, a panel, or someone else? Your answer reweights the question banks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Atlas-Freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

**Role:** Operations Manager, Atlas Freight (regional logistics, 800 employees)
**Interviewer and relationship:** not known. Built on the hiring-manager prior; no loop source establishes this company's rounds, so persona weights rest on that prior and not on Atlas Freight's documented process.
**Version:** first pass

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

| Type | What it is testing |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether the claims in your background survive scrutiny |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company and can think at its altitude |
| CASE | Structure and reasoning on a live problem from the role |

An answer slot is an instruction for the interview, not a question for you now. Each has two branches, and both are fine. "If you did this, say how" and "if there was no such step, or it was not yours, say so plainly" are equally good answers.

## Prep triage

You have about a week. Do these in order; everything else is insurance.

| Order | Do this | Where |
|---|---|---|
| 1 | Rehearse the scale question out loud until it is boring: 3 supervisors today, 12 in the role | A2, then A1 |
| 2 | Be able to say how the 40% was counted, what it is sensitive to, which assumption you would defend least, and which part was yours | C1, C2, E1 |
| 3 | Write your two-sentence plain acknowledgment on Power BI and your honest answer on Excel | A5, F5, F6 |
| 4 | Practice thinking aloud on two cases | B1, B2 |
| 5 | Read the Atlas Freight website yourself; this pack could not research it | D3 |

Everything else is insurance.

## Fit snapshot

Requirements are quoted from the JD you pasted. Evidence is quoted from your message and nothing else. No row stands on anything the pack knows about Atlas Freight.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "ran the site's peak-season surge plan two years running" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your words stay at their scope: "I ran the site's peak-season surge plan two years running, and I'm currently a senior shift manager over 3 supervisors." The pack's observation is that your material says one site's plan and a shift role, not four sites. Answer slot: the JD's four-site line makes a probe on the span of your responsibility likely. If any of your responsibility covered more than one site, or ran beyond your own shift, say which and how, in your own words; if none did, or it was not yours, say so plainly and stay with the surge plan you ran |
| F2 | "drive on-time performance and cost-per-shipment down" (the on-time-performance half) — JD | "ran the site's peak-season surge plan two years running" — your message | low | [inferred] | discovery | Your material does not show whether on-time performance was tracked, and the bridge is not stretched to say it was. Answer slot: if you tracked on-time performance or another service measure, say which measure and what it did, in your own words; if you did not, or it was not yours, say so plainly and say what you would measure first |
| F3 | "drive on-time performance and cost-per-shipment down" (the cost-per-shipment half) — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | low | [inferred] | discovery | A mis-pick rate is not a cost per shipment, and your material does not show a cost effect either way. Answer slot: if any cost effect of the redesign was tracked, say what was counted; if none was, say so plainly and say what you would measure first. The 40% itself raises the four defend-the-number slots in C1 and C2 |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your words: "I'm currently a senior shift manager over 3 supervisors." The pack's observation is that your material says 3, not 12, and the answer keeps that number. Answer slot: the JD's 12 makes a probe on scale likely. If you have led supervisors beyond those 3, say how many and over what period; if not, say so plainly and say how you would approach 12, as a plan and never as a past |
| F5 | "build reporting in Excel/Power BI" (the Excel half) — JD | "solid Excel" — your message | low | [inferred] | discovery | "Solid Excel" is your own adjective and does not say what you built with it. Answer slot: the JD asks about building reporting, so expect a probe on which reports. If you built any, say which and who used them, in your own words; if you did not, say so plainly and stay with the words "solid Excel" |
| F6 | "build reporting in Excel/Power BI" (the Power BI half) — JD | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Your words: "I haven't used Power BI." Then how you would learn it, said as a plan and never as a past. Never a claim to Power BI work. The JD pairs the two tools with a slash; whether either one satisfies it is a question for the employer, not a thing to assume |
| F7 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | low | [inferred] | discovery | Your material gives 7 years in operations and a current supervisory role; it does not show how many of the 7 years were in a lead or supervisory role, and the reading that claims less is the one kept. Answer slot: if your count of years in a lead or supervisory role reaches 5, state it with the roles, in your own words; if it is fewer, say the number plainly and stay with the 7 years in operations |
| F8 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap, but a certification with nothing inspected behind it, so expect a probe. Lead with it in your own terms: "I'm green belt certified." Answer slot: if you have applied green belt methods to a project, name the project and what you did; if not, say so plainly |

## Persona table

Round type and interviewer are unknown, so the starting weights are the hiring-manager prior, adjusted for nothing else. The pack states this because the weights are a judgment you can overrule: if you learn the round, reweight.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the scale jump and the tools you have not used | High: the hiring-manager prior puts it first, and F1, F4 and F6 are the rows it presses on | Rehearse the single most predictable objection until it is boring; bridge only from what you stated, with the limit named |
| Case/Strategist | Live problems from the job: on-time performance slipping, cost per shipment rising | High: the hiring-manager prior puts it first, and the JD is built around those two measures | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise |
| Data-Driven Prober | Reads your numbers line by line | Mid: the 40% is the one figure you gave, and F2, F3 and F5 are where a reporting-minded interviewer goes | Know how the 40% was counted, or say plainly you do not know |
| Conversational | Friendly opener, "walk me through the journey" | Mid: always plausible, and scored even when casual | A 90-second arc built only from your own sentences |
| Pressure | Interrupts, time-boxes, questions your share of the result | Low-mid: scale-up roles invite it, but nothing in the inputs says this loop does | Pause, restate, hold two follow-ups before conceding anything real |
| Values/Behavioral | Scenario probes on judgment | Low: no published values were researched and no values round is documented, so this is a generic scaffold | Choose stories where the hard truth landed; where none comes to mind, say so |
| Peer Evaluator | Seams between sites, credit-sharing | Low: relevant if a site manager is on the loop, which is not known | Reciprocity framing; propose seam principles rather than pretending to know the seam |

## Question banks

Bank letters skip F so they do not collide with the fit-snapshot rows.

### A. Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never used Power BI"; "currently a senior shift manager over 3 supervisors" | Choose one real limit and say it first, at its own scope: "I've never used Power BI" or "I'm currently a senior shift manager over 3 supervisors." Then give a ramp plan in your own words, as a plan for what you will do. Do not name a limit your material does not show, and do not soften the one you pick | F4 and F6 are the limits you stated, so this is the honest answer to a question every Skeptic asks. JD because it scores the listed requirements |
| A2 | "This role leads 12 supervisors across 4 sites, and you're currently over 3. What changes for you at that size?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI rehearsal in this pack. Say the number plainly: "I'm currently a senior shift manager over 3 supervisors." Follow-up 1: "What's the largest group of supervisors you've led?" Answer slot: if you have led more than those 3, say how many and over what period; if not, say so plainly and return to the 3. Follow-up 2: "How would you run four sites at once?" Answer slot: if any of your responsibility covered more than one site, say which; if none did, say so plainly and give the plan you would follow. Hold your position by returning to the quote, never by adding to it. Name the limit before it is asked for | F1 and F4 are where the role presses hardest against your material, so this objection arrives in some form in nearly any version of this loop. JD because it scores the headline requirements |
| A3 | "Why this move, and why now?" | EXP | [generic] | The question needs no claim about your past, and no quoted sentence of yours carries a reason, so this is a selection scaffold: give your actual reason in your own words, tied to something specific about this role. If no single reason comes to mind, say so plainly, then give the nearest honest thing | A motivation probe is a Skeptic staple and tests consistency; F1 is the step up it will circle |
| A4 | "The role needs 5+ years of operations leadership. How many of your seven years were leadership?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Say the 7 years as stated. Answer slot: if your count of years in a lead or supervisory role reaches 5, state it with the roles; if it is fewer, say the number plainly and stay with the 7 years. Do not round up | F7 is the one JD line stated as required, so a literal count is likely. JD because it scores a stated requirement |
| A5 | "The JD asks for reporting in Excel and Power BI. What's your experience with each?" | JD | [grounded] "solid Excel"; "never used Power BI" | Excel: "I have solid Excel." Answer slot: if you built reports in it, say which and who used them; if you did not, say so plainly. Power BI: "I haven't used Power BI." Then a plan for how you would learn it, as a plan. Never describe Power BI work | F5 and F6 together; the capability gap is the one the candidate stated, so the honest answer is already in your own words |

### B. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You take over four terminals and on-time performance is slipping at one of them. What do you need to know first, and what do you do in the first two weeks?" | CASE | [generic] | Needs no claim about your past, so the guidance makes none. Clarify first: how on-time performance is defined, what changed and when, which lanes and shifts. Then objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully | The JD's on-time-performance line (F2) set as a live problem; `[generic]` because it is a pattern for the problem, not a fact about this employer |
| B2 | "Cost per shipment has risen for two quarters running. Diagnose it." | CASE | [generic] | Same structure. Name what you would split the cost by before proposing any cause, and say which measures you would want in hand. No claim about your past | The JD's cost-per-shipment line (F3) as a live problem; CASE because it scores reasoning, not the right answer |
| B3 | "Peak season hits and two of your four sites are short-staffed. How do you allocate people and volume?" | CASE | [generic] | The case itself needs no claim about your past. If it helps, ground it at its own scope in "ran the site's peak-season surge plan two years running", and stop there rather than describing what a surge plan contains | F1's surge-plan quote is the nearest real experience to this scenario; the question scores structure and trade-off reasoning |
| B4 | "Your supervisors each report on-time performance a different way. How do you get to one number?" | CASE | [generic] | Definitions first, then source of record, then refresh cadence, then who owns it. Mention Excel only at the scope of "solid Excel"; say nothing about Power BI beyond your plan | F5 and F6 as a live reporting problem; the JD's reporting line is the raising source |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Story-mapped on the quote's own beats: the mis-pick rate, the 40%, the pick-path redesign. Defend-the-number slots, each in your own words: how it was counted; what it is sensitive to; which part was yours. Answer slot: if you know how it was counted, say how; if you do not, say plainly "I don't know how it was counted" and return to the quote | The only figure you gave, so a Prober goes here first; F3's thin bridge is the next place they would press |
| C2 | "Which assumption behind that 40% would you defend least?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Name the weakest assumption you know of before they do, in your own words. Answer slot: if you know of one, say which; if you do not, say so plainly. The pack names none for you | The weakest-assumption move turns a gotcha into credibility; EXP because it tests whether you know your own number |
| C3 | "How would you build a weekly view of on-time performance and cost per shipment for four sites, and what would it show first?" | JD | [generic] | A design question, so no claim about your past. Cover the definition of each measure, the source, the refresh, and what a first-glance view would flag. Excel only at the scope of "solid Excel"; Power BI only as your plan | F2, F3 and F5 together; JD because it scores the reporting requirement, CASE in delivery |

### D. Conversational/Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | A 90-second arc built only from those five sentences, in whatever order tells your story. Add no employers, titles, dates or reasons your quotes do not carry. Answer slot: where you want to say how you moved from one stage to the next, say it in your own words, or leave it out | Casual opener, still scored; F1, F4, F8 supply its beats |
| D2 | "What are you actually using from your Lean or Six Sigma training these days?" | JD | [grounded] "green belt certified" | Open with "I'm green belt certified." Answer slot: if you are applying green belt methods to current work, name the project and what you did; if not, say so plainly and say what you would apply first | F8 is the JD's plus-line, asked casually, which is how mid-list items usually arrive |
| D3 | "What do you know about us so far?" | CO | [generic] | This pack could not research Atlas Freight, so it supplies nothing about them. Say only what you have actually read, and read their own site and job posting first. Where you have read nothing yet, say what you would ask instead | Homework depth is scored; `[generic]` because no research ran, and the upgrade menu says what would change that |

### E. Pressure/Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold-then-concede. Hold the position the quote carries: you cut the rate by redesigning the pick path. Answer slot: if part of it was someone else's, say which part and which was yours; if all of the redesign was yours, say so plainly. Concede only what is true, specifically, and do not fold on the core claim to restore harmony | The attribution probe that exists to catch inflation; the preparation is candor |
| E2 | "Sixty seconds: why you over someone who already runs multiple sites?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | Pause, restate, then use only those three sentences at their own scope. Hold through two follow-ups. The concession is the F4 limit said plainly: "I'm currently a senior shift manager over 3 supervisors." Do not claim multi-site experience | F1 and F4 are what this challenge goes after; JD because it scores fit to the listed role |

### G. Values/Behavioral

No published Atlas Freight values were researched and no values round is documented, so these are generic scaffolds, not company-mapped.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not soften it, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem at a supervisor-lead altitude; no quoted sentence of yours carries a story for it |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where service and a cost or productivity number pulled apart, what you chose and what it cost. If none comes to mind, say so plainly, then give the nearest thing, or how you would handle it | The JD's two measures, on-time performance and cost per shipment, can pull against each other, so this is likely in some form (F2, F3) |

### H. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "If a peer site's priorities collide with yours on a shared constraint, how do you settle it?" | JD | [generic] | A principle answer, not a story: what you would ask, what you would put in writing, who escalates and when. Propose seam principles; do not pretend to know how Atlas Freight's sites divide work. No claim about your past | F1's four-site span makes the seams between sites a plausible probe |
| H2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say plainly which part was yours, in your own words. Answer slot: if others contributed to the redesign, say who and how; if it was yours alone, say so plainly. Credit given generously is credibility | A persona stem; C1's attribution slot returns here in collegial packaging |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Own daily terminal operations across 4 sites | A2, B1, B3, H1 |
| Drive on-time performance down | B1, B4, C3 |
| Drive cost-per-shipment down | B2, C3 |
| Lead a team of 12 supervisors | A2, E2 |
| Build reporting in Excel/Power BI | A5, B4, C3 |
| 5+ years operations leadership | A4 |
| Lean/Six Sigma | D2 |

## Reverse questions

No interviewer information exists, so none is tied to a career path.

| # | Question | Why it lands |
|---|---|---|
| R1 | "How do you define on-time performance across the four sites, and what does the baseline look like?" | Shows you think in definitions before targets and tells you what you would actually own |
| R2 | "What would a strong 90 days and a strong first year look like on on-time performance and cost per shipment?" | Turns the JD's two headline measures into a success definition you can be held to |
| R3 | "How are the 12 supervisors spread across the four sites, and where is the team's biggest development need?" | Shows you start from the people, and puts the scale question on the table on your terms |
| R4 | "What does the reporting stack look like today, and would an Excel-first start with Power BI built over time be workable?" | Surfaces the Power BI gap as a plan and gets the employer's real expectation on the record |
| R5 | "What is the hardest part of this role that isn't in the posting?" | Asks for the unwritten job, which a generic "any questions" answer never does |

## Prohibited claims

Built before the banks. Each entry is a claim this pack will not coach.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team of 12 supervisors | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the material says 3, not 12. A2's slot stays inside the 3 |
| Owned or ran terminal operations across multiple sites | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation: the material says one site's surge plan and a shift role, not four sites |
| Improved on-time performance or cut cost per shipment | Inflated form of F2 and F3 | The mis-pick and surge-plan quotes at their own scope. The limit is the pack's observation: neither quote carries those measures. B-bank slots and C1 stay inside the quotes |
| Has 5+ years of operations leadership | Inflated form of F7 | The "7 years in warehouse and distribution ops" quote at its own scope. The limit is the pack's observation: the material does not show how many of those years were leadership |
| Has used Power BI or built Power BI reports | Negative the candidate stated, F6 | The plain acknowledgment F6 gives: "I haven't used Power BI." No slot |

## Sources

Provided documents: the job description text you pasted, and the background you described in your message. No other document was provided and none was read.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Search refused by the host. Would have moved: a values cheat sheet and company-mapped VAL questions |
| 2. `Atlas Freight interview process {role family}` | unavailable | Search refused by the host. Would have moved: the loop structure and persona weights |
| 3. `Atlas Freight strategy` / recent news | unavailable | Search refused by the host. Would have moved: grounded CO and CASE questions in place of the generic ones |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `{role title}` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

Queries sent, all refused with nothing returned: `Atlas Freight regional logistics company values`; `Atlas Freight interview process operations manager terminal`; `Atlas Freight regional logistics terminals news strategy 2026`.

## Upgrade menu

- Search access, or pages you paste from Atlas Freight's own site (values, careers, news) → grounded values mapping, CO and CASE questions in place of the generic ones; a deeper research pass beyond that (up to 6 more searches and 2 more fetches, several more minutes) is available if search access is granted
- The round type and who you are meeting → reweighted persona banks; with a name, an interviewer read and a reverse question tied to their path
- Anything the recruiter told you about focus areas or a pre-declared exercise → coverage the pack cannot guess
- Your own answers to the slots in F1, F2, F3, F4, F5 and F7, stated outside a drill → those rows become quoted evidence and their bridges sharpen
- Your actual resume, and the green belt certificate → F7 and F8 move from your message to inspectable documents, and F8's confidence can rise
- A `tuesday-dossier.md` from a prior job-underwriter run, if you have one → verified evidence and the objection already named, replacing this pack's inferences
