Searches were denied, so I'm writing the pack from your material only and saving it now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a/runs/sonnet/tuesday/part-2/rooms/case-1-denied-c5c9325d/Northwind-Data_senior-gtm-strategy-lead_interview_pack.md`.

- **What's in it:** 19 questions across six personas, each with a type tag, provenance, answer guidance and rationale. It also has the fit snapshot, interviewer read, persona table, six reverse questions, prohibited claims, sources and an upgrade menu.
- **Research:** web search was not permitted in this run, so all four searches were refused. The pack rests on your message alone, including your research note on Northwind's priorities, which I couldn't check for freshness. Dan's profile comes only from what you gave me.
- **Persona weighting:** Data-Driven Prober ranks first and Peer Evaluator second. Dan's "relentlessly data-driven" self-description lifts the Prober above the usual peer-round weighting.
- **Highest-ROI prep:** C1, the "no sales-ops or quota-setting experience" objection. The pack gives the plain acknowledgment, what her material does carry, and a ramp plan.
- **Biggest gaps:** partner-motion design is required in the JD, and her only adjacent evidence is the carrier revenue model. The pack keeps every answer to what her notes actually say.
- **Values round:** no values-style round is detected, so there is no values cheat sheet and no values-tagged questions.

Say the word and I'll play the Prober on A1, the question on the ~$400M ARR figure.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Northwind-Data_senior-gtm-strategy-lead_interview_pack.md -----
# Interview prep pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

**Interviewer:** Dan Kovac, Director of Sales Strategy. Relationship: peer, both reporting to the same VP. One 60-minute conversation.

**Built on this assumption:** a single peer round, with no other loop information. Research searches were not permitted in this run, so everything about Northwind and Dan comes from your notes and is labeled that way.

**Highest-ROI prep in this pack: C1**, the "no sales-ops or quota-setting" objection. It is asked in some form in almost every version of this conversation, because Dan owns that territory.

## How to use this pack

- **Personas** describe how a question arrives (who is asking, in what style). **Types** describe what is being scored.
- Type key:
  - **VAL**: behavioral/values alignment, tied to published values.
  - **EXP**: work-experience deep-dive; do your claims survive scrutiny.
  - **JD**: role and job-description driven.
  - **CO**: company and strategy knowledge.
  - **CASE**: a live problem, structured aloud.
- Guidance is scaffolding, not a script. Where a cell says "answer slot", it is an instruction for the interview, and the honest answer is yours in your own words. Either branch of a slot is a fine answer.
- No VAL questions appear as a type: no values-style round is detected (the loop you described names none) and no published values are in hand. B4 carries the behavioral shape instead.

## Fit snapshot

Requirements are quoted from the JD highlights in your message, which are a summary and not the full JD.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — your message | medium | [grounded] | transferability | Your material says product strategy and ops at a consumer-tech company. It does not show go-to-market work for a new offering, and the words stay at the quote: "I spent nine years in product strategy and ops at a large consumer-tech company." Answer slot: the JD's two-new-product-lines line makes a probe on go-to-market likely. If any of your work took a new offering to customers, say what and which part was yours, in your own words; if none did, or it was not yours, say so plainly and stay with the product strategy and ops you described |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — your message | medium | [grounded] | transferability | Your material says you proposed the change and that it was credited with the uplift. It does not show analysis across customer lifecycle stages, so the words stay at the quote: "I proposed a store-surface change credited with a ~$400M ARR uplift." Answer slot: the JD's whitespace line makes a probe on how the proposal was found likely. If any analysis of that kind sat behind it, say what it looked at and what part was yours; if none did, or it was not yours, say so plainly and stay with the proposal |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — your message | medium | [grounded] | none | The quote already names both tools. It is a self-reported skill line with nothing inspected behind it, so expect a probe on the word independent (A3). Lead in the quote's terms: skilled in SQL and Tableau |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — your message | medium | [grounded] | transferability | Your material says you built the model and that it was used in carrier negotiations. It does not show who designed the partner structure behind it, and the words stay at the quote: "I built a partner-level revenue model used in carrier negotiations." Answer slot: the JD marks partner-motion design as required, so a probe on design is near certain. If any part of a partner motion was yours to design, say which and how you decided; if none was, or it was not yours, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — your message | medium | [grounded] | presentation | Lead with the quote in its own terms: you set annual volume targets with cross-org consensus. The material does not say how the consensus was reached or what it took, so the guidance adds no stakeholders, disagreements or tactics. B4 carries the slot |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — your message | medium | [grounded] | presentation | The words stay at the quote: "I use AI tools daily." Which tools, for what, and with what result are yours to say; the pack supplies none (E2) |
| F7 | Sales-ops and quota-setting experience, an area Dan owns. Not in the JD highlights; a peer-lens row | "No classic sales-ops or quota-setting experience." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I don't have classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. Your material describes volume targets, not quotas, and the words keep that distinction |

## Reading the interviewer

Source: the profile language and career pattern you supplied. No public search ran, so nothing else is claimed.

| Signal | Source | Practical implication |
|---|---|---|
| Self-described "relentlessly data-driven" | Profile language, your message | Expect every number to be probed to its assumptions. Make A1 and A2 your most rehearsed answers |
| Career spine in pricing and monetization | Your message | Case questions will likely arrive in packaging, pricing and unit-economics terms (D1) |
| One early-stage-startup chapter | Your message | He may test for pace and scrappiness against a large-company background, and a builder story lands well with him. Do not borrow a startup identity; ask about his chapter (R1) |
| Peer, same VP | Your message | He is pricing what the hire costs and contributes to his own work. Bring reciprocity (B3, R3) |

**Mirror opportunity.** His public path is pricing and monetization; the shared vocabulary is revenue. Pair it with F4: "built a partner-level revenue model used in carrier negotiations". The material does not say the model involved pricing, so offer it as revenue-model work and let him draw the link. There is no shared career jump to use: nothing in the supplied material reaches a consulting-to-consumer-tech parallel with his path.

## Persona table

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober | Dan reads the CV line by line and goes two levels deep on the ARR figure and the revenue model | **Highest.** The peer prior pairs Peer Evaluator with Prober, and his self-description pushes Prober above it | Know what you can and cannot say about how each number was counted; say plainly when you do not know; name the weakest assumption before he does |
| Peer Evaluator | Seam-splitting between his team and yours; what you need from him; credit across teams | **High.** The relationship prior, unchanged by his profile | Reciprocity framing; propose seam principles, not a pretend seam; disagreement with spine and tact |
| Skeptic | The sales-ops and quota gap, partner-motion design, consumer-tech to B2B, why now | **Medium.** The fit snapshot has one stated capability gap and two transferability gaps in his territory | Rehearse C1 until boring; bridges only from quoted work, with the limit said plainly |
| Case/Strategist | Packaging, pricing and sequencing problems set on Compass and the two new lines | **Medium.** A peer round is not case-led, but his pricing spine pulls case angles toward his native language | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise |
| Conversational | Opening arc; "what are you playing with in AI" | **Low-medium.** Likely as the opening minutes, still scored | A 90-second arc; treat the casual AI question as scored |
| Pressure | "How much of that was actually you?" | **Low.** He is a peer, not a stress interviewer, but the attribution probe appears collegially | Pause, restate, hold through two follow-ups, concede specifically |
| Values/Behavioral | Not weighted | No values-style round is detected and no published values are in hand | B4 covers the behavioral shape |

## Question banks

### A. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The ~$400M ARR uplift on your CV: who credited it, and how was it counted?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Tell the part the quote carries: you proposed the change, and the uplift is the figure it was credited with. Answer slot on how it was counted: if you know, say how, in your own words; if you do not know how it was counted, say so plainly. That answer is honest and holds up better than a guess. Never describe a method you cannot repeat under a second question | F2 is the headline metric, and Dan's data-driven self-description makes it the first target. EXP because it tests whether the number survives scrutiny |
| A2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Name, before he does, the assumption you would defend least, in your own words. If you know of none, or do not know how the figure was built, say so plainly. Then return to what the quote carries: you proposed the change | The weakest-assumption move turns a gotcha into a credibility gain. Same evidence as A1 (F2), asked one level deeper, as probers do |
| A3 | "You'd be running analysis independently in SQL and Tableau. Tell me about an analysis you ran yourself, start to finish." | JD | [grounded] "skilled in SQL/Tableau" | The quote carries the skill, not a story, so this is a selection scaffold. Pick one analysis you personally ran. It needs the question you started with, where the data came from, one place the numbers could mislead you, and what it changed. If no such analysis comes to mind, say so plainly, then give the nearest thing your material carries, or how you would approach it | F3 covers the requirement in tool terms; the word independent is what Dan will test. JD because it scores a stated qualification, EXP in delivery |
| A4 | "Tell me about the partner-level revenue model on your CV: what was it for, and how was it used?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story-mapped on F4: you built it; it was partner-level; it was used in carrier negotiations. Those are the beats the quote states; tell them in your own words. Answer slot: expect a probe on who used it and for what decision. Say what you know; if you were not in those conversations, say so plainly and stay with the model you built | F4 is the evidence for a required partner-motion line and the likeliest place Dan's revenue vocabulary meets your material. EXP because it tests what was actually yours |
| A5 | "What did it take to get cross-org consensus on those annual volume targets?" | EXP | [grounded] "set annual volume targets with cross-org consensus"; "No classic sales-ops or quota-setting experience." | Tell it with the quote's own scope: annual volume targets, cross-org consensus. The quote does not carry the method or the disagreements, so say only what you recall in your own words and add nothing you cannot repeat under a follow-up. Keep the word volume targets. If he asks how that differs from quota-setting, the plain acknowledgment is yours: "I don't have classic sales-ops or quota-setting experience." | F5 and F7 meet here. A sales-strategy peer will test where volume targets end and quotas begin. EXP because it is a deep-dive on a CV line |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | Propose principles, not a seam you cannot know yet: each decision has one owner and the other side is consulted; disagreements go to data first, then to the shared VP only if they stay stuck. Ask what his team owns today before drawing any line. The question needs no claim about your past, so the guidance makes none | The peer relationship makes seam-splitting near certain, and the JD's two new product lines sit next to his work. JD because it scores the role, CASE in delivery; generic because it is a pattern, not a fact about Northwind |
| B2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Describe your part in the quote's words: you proposed the change. Answer slot: if others built or launched it, say who and what they did, in your own words; if you do not know the split, say so plainly. Never imply the credit was all yours | Credit-sharing is a stock peer probe, and the ARR line is where it lands (F2). EXP because it tests attribution honesty |
| B3 | "What would you need from me and my team in your first 90 days?" | JD | [grounded] "skilled in SQL/Tableau" | Lead with reciprocity: what you offer his team, then what you need. You can offer to run analysis yourself in SQL and Tableau; that is the quote's skill and a future offer, not a past claim. Then your needs as questions: data access, how targets are set today | Dan is pricing what the hire adds to his work. JD because it scores the role, with the reciprocity framing the peer prior calls for |
| B4 | "Tell me about a time you got teams that don't report to you to commit to a shared number." | JD | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on F5: the beats are the annual volume targets and the cross-org consensus. Answer slot: the JD's cross-functional line makes a probe on how disagreement was resolved likely. If there was disagreement and you moved someone, say what and which part was yours; if consensus came without friction, or was not yours to build, say so plainly and stay with the targets | Covers the cross-functional requirement. JD because it scores the stated qualification; the behavioral shape stands in for a values round that is not detected |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "I don't see classic sales-ops or quota-setting in your background. How would you handle that in this role?" | JD | [grounded] "No classic sales-ops or quota-setting experience."; "set annual volume targets with cross-org consensus"; "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | **The deepest rehearsal in this pack.** Level 1, the acknowledgment: "I don't have classic sales-ops or quota-setting experience." Level 2, what the quotes carry, at their scope: "I set annual volume targets with cross-org consensus." Do not call them quotas. Level 3, the ramp as a plan, never a past: learn how sales targets are set here, starting with Dan's team, then work from there; give your own time frame and no figure you have not decided. Hold through two follow-ups by returning to the quoted work; concede explicitly what you have not done; never claim a quota or sales-ops practice to restore comfort | F7 is where Dan's expertise presses hardest, and the negative is one you stated. JD because it scores a competency adjacent to the role, Skeptic in delivery |
| C2 | "Partner-motion design is a requirement here. What have you designed?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Say what the quote carries: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if any part of a partner motion was yours to design, say which and how you decided; if none was, or it was not yours, say so plainly and stay with the model. The limit is a limit, not a confession. Hold by returning to the model, never by adding to it | A required JD line with one adjacent quote (F4). JD because it scores the stated requirement |
| C3 | "Why leave a large consumer-tech company after nine years, and why this role, why now?" | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | Give your actual reason for leaving and your actual reason for this role, in your own words; the pack supplies neither. You can connect to the three priorities in your research note: enterprise expansion, the Compass launch, profitability. Say which one is genuinely yours. Keep it consistent with everything else you tell Dan | Motivation consistency is the Skeptic's core test, and a nine-year tenure invites it (F1). EXP because the reason for leaving is tagged there |

### D. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Suppose a much larger platform vendor bundles comparable capability into what customers already pay for. How would you think about packaging and pricing Compass? What do you need to know first?" | CASE | [grounded] your research note: AI copilot launch ('Compass'); main competitive threat is bundling by a much larger platform vendor | Clarify first: the objective (growth or margin), the buyer, what the bundle really covers. Then segment customers, outline two or three packaging options, and name the metrics you would watch and the risks. Say your framework aloud, and challenge one premise respectfully. Use Dan's vocabulary: value metric, willingness to pay, cannibalization. The question asks about no past, so the guidance makes no claim about yours | His pricing spine makes this his native ground, and the note names bundling as the main threat. CASE because it is a live problem; strategy-grounded on the provided note |
| D2 | "Enterprise expansion is a stated priority. Where would you look for whitespace across land, adopt, expand and renew for a new product line, and what would you pull first?" | CASE | [grounded] "identify whitespace across land/adopt/expand/renew"; "run independent analysis in SQL and Tableau" JD highlights; your research note: enterprise expansion | Clarify what the product line is and what data exists. Split the account base by lifecycle stage, then name the first cut you would pull and the decision it would inform. You can say you would pull it yourself, which is the skill the JD names. The guidance claims nothing about analysis you have done | Direct hit on the JD's whitespace line (F2). CASE; the data angle suits a data-driven peer |
| D3 | "Enterprise expansion, Compass and profitability are all priorities. Where do you expect them to pull against each other, and how would you sequence two new product lines?" | CO | [grounded] your research note: three stated priorities | Name the real tension in your own reasoning: what each priority wants from the same product line, and where capacity or margin is the constraint. Give a sequencing logic with a stated assumption and one thing that would change your mind. Do not recite the three priorities back; he knows them. Bring one thing they do not state | The strategy-grounded question the rubric requires. It rests on a note of unknown age that could not be checked here. CO because it tests altitude on the company's strategy, CASE in delivery |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops"; "built a partner-level revenue model used in carrier negotiations"; "proposed a store-surface change credited with a ~$400M ARR uplift" | A 90-second arc in three beats: two years in strategy consulting, then nine in product strategy and ops, then one or two proof points at their quoted scope: the revenue model, the proposal. Close on why this role, in your own words (slot from C3). Do not state what the work proves; let him draw the inference | The biography question opens most conversations and is scored. EXP because it checks the CV story hangs together |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Start with the quote: "I use AI tools daily." Answer slot: name which tools and what you use them for, in your own words; if it is narrower than a project, say so plainly. Do not suggest you have built AI products. You can ask what Compass will do for sales teams | The JD marks AI experience as a plus, and a casual question is still scored (F6). JD because it scores the stated plus |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "That result: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause and restate the question. Hold: "I proposed the change; the uplift is what it was credited with." Hold through two follow-ups by returning to the quote. Concede specifically: say what you cannot speak to, such as how it was counted, if you do not know. Never fold on the core claim just to restore harmony, and never extend it | The standard attribution probe, arriving collegially from a peer (F2). EXP because it tests candor about the headline number |
| F2 | "Sixty seconds: why you rather than someone who has run GTM for a B2B product?" | JD | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops"; "proposed a store-surface change credited with a ~$400M ARR uplift" | Lead with what the quotes carry: two years of strategy consulting, then nine in product strategy and ops, and the proposal at its scope. Answer slot: if you have go-to-market or B2B work, say what and which part was yours; if you have none, say so plainly and stay with the strategy and ops you described. Do not claim B2B experience to win the minute | Time-boxed and motive-testing, the stress form of C1 and F1. JD because it scores fit against the stated role |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Most of your career has been in pricing and monetization, with one early-stage chapter. What did that chapter change about how you work now?" | Ties to his own path, turns an interrogation into a peer conversation, and shows you researched him. It asks about his chapter and does not claim a parallel |
| R2 | "Which metric do you trust most for land, adopt, expand and renew today, and which do you trust least?" | A data-driven peer will answer at length. It shows you think about measurement quality |
| R3 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer: it asks what you can add before what you need |
| R4 | "Where is the seam between the new lines' GTM and your team's work most blurry right now?" | Follows B1 with a real ask, and signals you will treat the seam as shared work |
| R5 | "As Compass heads to launch, where is a larger vendor's bundle hardest to displace?" | Uses the competitive threat from your note and invites his field knowledge on it |
| R6 | "From your seat, what would make this hire a clear success at six months?" | Invites a scorecard you can work to and shows you are thinking about the same VP |

## Prohibited claims

Built from the fit snapshot before the question banks. The banks are written against it.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran GTM strategy for a product line | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says product strategy and ops, not GTM. The F1 slot stays inside that quote |
| Designed or ran a partner motion or partner program | Inflated form of F4 | F4's quote at its own scope. The material says a revenue model, not a motion. C2's slot stays inside the model |
| Negotiated, or led, the carrier negotiations | Inflated form of F4 | The quote says the model was used in carrier negotiations, and no more |
| Drove, delivered or owned the ~$400M ARR uplift | Inflated form of F2 | F2's quote at its own scope: proposed, and credited with. A1, A2, B2 and F1 stay there |
| Set quotas, or has quota-setting or sales-ops experience | Negative you stated, F7 | The plain acknowledgment F7 gives: "I don't have classic sales-ops or quota-setting experience." The nearest quoted work stays "volume targets" |
| Built or led AI products or AI GTM | Inflated form of F6 | F6's quote: "I use AI tools daily." E2's slot stays at use |

## Sources

**Provided documents:** your message, which holds the JD highlights, the candidate summary, Dan's profile language and career pattern, and your research note on Northwind's three priorities, Compass and the bundling threat. The research note's age is unknown, and none of it could be checked in this run.

**Queries sent, all refused (search permission was not granted):**

- "Northwind Data company values": refused
- "Northwind Data interview process strategy GTM": refused
- "Dan Kovac Director of Sales Strategy Northwind Data": refused
- "Northwind Data Compass AI copilot launch enterprise expansion profitability": refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | The values cheat sheet and any VAL questions; both are absent, and the upgrade menu says what would restore them |
| 2. `Northwind Data interview process` | unavailable | Loop structure; persona weights rest on your description of one peer conversation and the peer prior, not on a documented loop |
| 3. `Northwind Data strategy` / recent news | unavailable | Whether your research note is still current; D1 to D3 rest on the note unchecked |
| 4. `Dan Kovac Northwind Data` | unavailable | His published talks and writing; the interviewer read rests on the profile language you supplied alone |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights you supplied fix the fit snapshot rows and the JD-tagged questions as far as they go |

## Upgrade menu

- The full JD text → the six JD rows rest on a highlight summary, so a full JD could add requirements, and any location, travel, schedule or work-authorization term it holds would surface as a gate row.
- Search access, or Northwind's values and interview pages pasted in → a values cheat sheet if a values round exists, a documented loop, and a current check of your research note.
- Dan's talks, posts or recent writing, pasted in or found with search access → his recurring themes as likely questions, and sharper reverse questions.
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes; needs search access first) → a grounding brief on strategy, competitors and org context. Offered once, and not re-asked.
- The candidate's CV text, verbatim → F1 to F6 quote the CV's own sentences instead of your summary, and the ARR line can be checked against the CV's wording. For the ARR claim, the document where the uplift was credited, if one exists, would lift its confidence from medium.
- Priya's answers to the slots in F1, F2, F4 and E2, given outside a drill → each of those rows becomes grounded in her own words.
- The recruiter's guidance on focus areas, any announced deliverable and the rest of the loop → graded-deliverable sections and per-round coverage.
- Prep time available → a prioritized prep schedule.
- A `tuesday-dossier.md` → verified evidence, absolute prohibited claims and a named highest-ROI objection, in place of the ones inferred here.
