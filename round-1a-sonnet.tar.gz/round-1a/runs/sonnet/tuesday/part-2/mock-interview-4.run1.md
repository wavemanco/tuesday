Web search was denied, so I'm building the pack from your dossier alone. Anything specific to Quartzline will be marked generic, and I'm saving the pack now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a/runs/sonnet/tuesday/part-2/rooms/case-4-denied-e3644aa2/quartzline_product-manager-platform-apis_interview_pack.md`. It's built for a hiring-manager round and has 22 questions across seven personas. Skeptic and Case/Strategist are weighted highest, since that's how a hiring manager tends to run it.

- **No Quartzline research:** Web search was denied (all three searches were refused). Everything specific to Quartzline, meaning values, loop structure and strategy, is marked generic. Questions A5 and B4 and the two values questions (G1, G2) are scaffolds, not company-grounded.
- **Highest-ROI prep:** A1 uses the objection your dossier named: "You have never held the PM title or owned a roadmap…". The pack coaches a plain concession of both halves, then a bridge limited to the integrations and the playbook, then a plan for how you'd learn the roadmap. It deliberately keeps the quarterly roadmap-input sessions out of that answer, because the dossier marks roadmap ownership as a gap to acknowledge, not bridge. Those sessions get their own question (A4).
- **A gap in the dossier:** R2 (shipped API or platform products) is a must-have in the handoff. It isn't listed among the weak areas, so no strategy was set for it. Your integration evidence says "integrations of the vendor's REST APIs", not shipping one. I graded it as transferability from the quote alone and wrote an answer slot for it (A3). It's worth settling before Thursday.
- **Answer slots:** Where your verified evidence doesn't reach a requirement (API docs and schemas, engineering and sales, agile, adoption tracking, specs), the pack gives two-branch slots for you to answer from your own experience. It doesn't script answers for you. Filling them in would sharpen rows F3 to F9.

Say the word and I'll run a live drill as the Skeptic on A1.
I can also save an updated `tuesday-dossier.md` recording what this prep exposed, including the R2 gap, for you to carry forward.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

Hiring-manager round, one 45-minute conversation on Thursday. Interviewer: the hiring manager, name not given. Built from `tuesday-dossier.md` (job-underwriter, dossier_version 1.1) and your message. Web search was not permitted in this session, so nothing in this pack comes from research on Quartzline.

## How to use this pack

Personas are how a question arrives. Types are what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Tag | Meaning |
|---|---|
| VAL | Behavioral or values alignment: does past behavior show the behavior asked about |
| EXP | Work-experience deep-dive: do your claims survive scrutiny |
| JD | Role and JD-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem set in the role |

An answer slot is an instruction for the interview, not a question for you now: answer it from your own experience, or say plainly that it was not yours.

## Prep triage

Two days, Tuesday to Thursday. The few things done well, in order:

1. A1, then E1 aloud until the concession sounds boring. This is the highest-ROI prep in the pack.
2. B1 and B3: the two cases that test the authority seam the posting leaves open.
3. C1 and C2: the 30+ figure and the playbook, which are the two claims a prober can open.
4. D1: the 90-second arc.
5. Reverse questions 1 and 2.

Everything else is insurance.

## Fit snapshot

Requirements are quoted from the dossier's role_profile. Evidence is quoted from the dossier's handoff. F3 to F5 and F7 to F9 carry their own limits; read the bridge cell before you rehearse.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier R1, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier handoff, verified evidence 1 | low | [inferred] | transferability | Adjacent work, said as adjacent, which is the underwriter's positioning: integration leadership next to the PM seat, never product management experience. Words: "I haven't held a product manager title or role" (the dossier's prohibited_claims item), then the quote at its own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Do not argue a count of years |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibilities, and the R1 sub-claim | none given | none | [grounded] | capability | The dossier records this as acknowledge_gap, with prohibited_claims "Having owned a product roadmap". Words: "I haven't owned a product roadmap." Then a plan, said as a plan and never as a past: learn how the roadmap is set today and where the two squad leads' decisions sit before proposing changes. No bridge and no slot |
| F3 | "Shipped API or platform products" — dossier R2, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier handoff, verified evidence 1 | low | [inferred] | transferability | The dossier lists R2 as high priority but not among its weak areas, so no strategy binds it; this row is graded from the quote alone. The quote says integrations of the vendor's REST APIs, not shipping an API or platform product, and the words stay there: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Answer slot: the requirement's own wording makes a probe on shipping likely. If you shipped an API or platform product, or had a part in shipping one, say which part and what you did, in your own words; if you did not, or it was not yours, say so plainly and stay with the integrations you led |
| F4 | "Technical fluency: API docs, schemas" — dossier R3, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier handoff, verified evidence 1; "Wrote the internal integration playbook her team uses" — dossier handoff, verified evidence 2 | medium | [grounded] | discovery | The quotes reach REST APIs and architecture, and name neither API docs nor schemas. Answer slot: the requirement names API docs and schemas, so expect a probe on them. If you worked with either in the integrations or the playbook, say how, in your own words; if you did not, or it was not yours, say so plainly and stay with the REST API and architecture work you led. The dossier marks the playbook inspectable, which makes it the one thing you could offer to show |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier R4, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier handoff, verified evidence 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier handoff, verified evidence 3 | medium | [grounded] | discovery | The quotes name clients and product, and neither names engineering or sales. Evidence 3 is confirmed with limited inspectable proof, so expect a probe and volunteer the limit before it is extracted: say what you can show of those sessions and what you cannot. Answer slot: the requirement lists engineering, sales and customers. If you worked with engineering or sales on these, say how; if you did not, or it was not yours, say so plainly and stay with the clients and the product feed |
| F6 | "Agile delivery experience" — dossier R5, preferred | none given | low | [grounded] | discovery | The dossier's strategy is clarify, and no verified entry speaks to this requirement, so nothing about your past goes in the answer. Answer slot: the requirement's own words are the likely probe. If you have delivered that way inside a product organization, say how, in your own words; if you never worked that way, say so plainly, then say what you would want to confirm about how Quartzline defines it |
| F7 | "Run discovery with integration partners" — dossier role_profile responsibilities | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier handoff, verified evidence 3 | medium | [grounded] | discovery | The quote at its own scope: "I ran quarterly roadmap-input sessions feeding client evidence to product." It is an input to product, not the decision. Answer slot: the responsibility names discovery with partners. If any of those sessions was discovery work with partners, say how, in your own words; if none was, or it was not yours, say so plainly and stay with the sessions |
| F8 | "Define and track adoption metrics" — dossier role_profile responsibilities | none given | none | [grounded] | discovery | Answer slot: the responsibility makes a probe on adoption likely, and the dossier notes no current baseline is stated. If you tracked adoption or usage of any integration, say what was tracked and how it was counted, in your own words; if none, or it was not yours, say so plainly and say what you would measure first |
| F9 | "Write specs and drive delivery with two engineering squads" — dossier role_profile responsibilities | none given | none | [grounded] | discovery | Answer slot: expect a probe on specs. If you wrote specs for an engineering team, say what and for whom, in your own words; if you did not, or it was not yours, say so plainly and say how you would learn the squads' format first |

## Persona table

The loop is one 45-minute session with the hiring manager, established by your own words; no values round is documented, so none is assumed.

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the title and roadmap gap | High: a hiring manager is derisking a gap, and the underwriter named a Skeptic objection. 5 questions | Rehearse the one objection until it is boring; concede the title and roadmap plainly; bridge only from the quotes, limit named |
| Case/Strategist | Live problems from the role: plan, diagnose, sequence | High: the hiring-manager row of the persona priors, and the role is a roadmap and adoption job. 5 questions | Clarify first, then structure, then answer; think aloud; challenge one premise respectfully; speak in conditionals, never as a past |
| Data-Driven Prober | Opens the 30+ figure and the playbook | Mid: there is one headline figure and one inspectable artifact. 3 questions | Know how the figure was counted, or say plainly you do not; name the assumption you would defend least |
| Conversational | Friendly opener, the biography question | Mid: 45 minutes begins with it, and casual questions are scored. 3 questions | A 90-second arc built only from the three quoted sentences |
| Peer Evaluator | The seam with the two squad leads | Low to mid: the hiring manager may voice the squad leads' view. 2 questions | Propose seam principles and ask where the seam is; never pretend to know it |
| Pressure | Time-boxed challenge on the same objection | Low: the dossier gives no sign of a stress style. 2 questions | Pause, restate, hold through two follow-ups, concede specifically |
| Values/Behavioral | Scenario probes | Low: no values round is documented and no published values were available. 2 questions | Selection scaffold ending in the honest branch |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; prohibited_claims: "Having held a product manager title or role"; prohibited_claims: "Having owned a product roadmap" | The underwriter named this objection, so it gets the deepest rehearsal. Concede first, in both halves, with words sourced from the dossier's prohibited_claims: "I haven't held a product manager title or role, and I haven't owned a product roadmap." Then the bridge with its limit: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live, and I wrote the internal integration playbook my team uses. That is adjacent to the PM seat, not the seat." Then a plan, never a past: learn how the roadmap is set today and where the squad leads' decisions sit before proposing changes. Likely follow-ups, each one an open prompt: what you would need from the hiring manager in the first ninety days; what you would be doing for the first time; why this is a reasonable risk for them. Hold by returning to the quoted integrations, never by adding to them; concede the title and the roadmap every time; do not compare yourself to the PM with three years | F1 and F2 are the gap this question presses on, so it arrives in some form. JD because it scores the title requirement; Skeptic is the delivery |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] prohibited_claims: "Having owned a product roadmap"; prohibited_claims: "Having set prioritization for an engineering squad" | Name the roadmap first, in the sourced words from prohibited_claims: "I haven't owned a product roadmap." If the follow-up goes to squad priorities, the sourced words are "I haven't set prioritization for an engineering squad." Then the ramp plan, as a plan. If asked for a second item, answer slot: the JD asks for agile delivery. If you have delivered that way inside a product organization, say how, in your own words; if you never worked that way, say so plainly, then say what you would want to confirm about how Quartzline defines it | F2 is the capability gap and F6 the clarify area; this is where both are surfaced calmly. JD because it scores the posting's own list |
| A3 | "I don't see shipped API products in your background — how would you handle the shipping part of this role?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Story-mapped on F3, with its limit: the quote says integrations of the vendor's REST APIs, so say exactly that: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Answer slot: if you shipped an API or platform product, or had a part in shipping one, say which part and what you did, in your own words; if you did not, or it was not yours, say so plainly and stay with the integrations you led. Then how you would learn the squads' shipping rhythm, as a plan | F3 is a must-have the dossier did not grade as weak, so this question tests the row the dossier is silent on. JD because it scores R2 |
| A4 | "Walk me through those quarterly roadmap-input sessions." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Story-mapped on F7: you ran them, they were quarterly, and they fed client evidence to product, which are the quote's own beats; tell them in your own words. Confirmed with limited inspectable proof, so volunteer the limit yourself: say what you can show and what you cannot. Answer slot: the JD raises roadmap and discovery, so expect a probe on whether the input changed what product did. If it did, say what changed and whose decision it was; if nothing changed, or it was not yours to know, say so plainly and stay with the sessions. Present the sessions as an input, never as the decision | F7 is a medium-confidence claim, the kind a prober finds the seam in. EXP because it tests what was actually yours |
| A5 | "Why leave, why here, why now?" | CO | [generic] | Selection scaffold, because no sentence of yours carries a reason: give your actual reason for the move in one sentence, then one reason tied to something you can name about Quartzline's partner API platform. This pack could not research Quartzline, so it supplies no company fact; if no such reason comes to mind, say so plainly, then say what you would want to learn first | Motivation consistency is the Skeptic's standing probe, and a role change this size makes it likelier. CO because the third part tests company homework |

### B. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You start Monday as PM for the partner-facing API platform — what do you need to know first?" | CASE | [inferred] derived from the dossier's role_profile unknowns | Clarify before structuring. Your first two clarifications are the posting's own open items: which roadmap decisions the PM makes alone and which belong to the two squad leads, and how adoption is measured today and against what baseline. Then objective, partner segments, approach, metrics, risks. Say it as a plan in the conditional; it asks about no past | The unknowns are the dossier's, so the case rehearses the exact things you need to verify anyway. CASE because it scores structure on a problem from the role |
| B2 | "Adoption of a partner API is flat quarter over quarter — diagnose it." | CASE | [generic] | Clarify what adoption means here and what the baseline is; segment partners; separate reach from depth; form two hypotheses and say what data would split them. Think aloud and challenge one premise respectfully. It asks about no past | Adoption metrics are a named responsibility (F8), and a diagnosis is the standard way a hiring manager tests them live. CASE with a pattern the pack does not claim is specific to Quartzline |
| B3 | "A squad lead wants to ship a breaking change to the API and a large partner objects. Who decides, and what do you do?" | CASE | [generic] | Ask first where the decision sits, since the posting leaves squad authority unstated. Then principles, not a claimed authority: gather the partner's impact, lay out options, bring the squad lead and the partner to one table, and escalate if you disagree. Speak in the conditional throughout | F2 and F9 make the seam the thing to probe. CASE because it is a live problem, and it tests whether you claim authority the posting does not evidence |
| B4 | "Where do you see the biggest opportunity or risk for our partner API platform?" | CO | [generic] | This pack could not research Quartzline, so it supplies no company fact. Frame the answer as what you would want to confirm: how partners find, adopt and stay on the API, using the posting's own responsibilities as headings. Do not state a Quartzline fact you have not read | The coverage rule asks for a strategy-grounded question where research succeeded, and it did not; this is the honest generic version. CO because it tests company altitude |
| B5 | "You have three requests: a large partner's custom endpoint, a documentation overhaul, and a rate-limit change. How do you sequence them?" | CASE | [generic] | Name your criteria before the order: partner impact, effort, risk, reversibility. Pick one premise to challenge, such as whether the custom endpoint is really custom. Say "I would" throughout, since this is hypothetical; it is not an account of how you have sequenced work | Roadmap sequencing is the heart of R1 (F2), and a case lets you show structure without a past to defend. CASE because it asks for no history |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 30+ was counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The figure counts integrations, and the quote says you led them, which are the only beats the sentence carries. Answer slot: how it was counted, what it is sensitive to, which assumption behind it you would defend least, and which part was yours. Answer each in your own words; where you do not know how it was counted, say so plainly. The pack supplies no counting method | F1 and F3 both lean on this figure, so it is the first number a prober opens. EXP because it is a defend-the-number question |
| C2 | "Tell me about the integration playbook you wrote." | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Story-mapped on F4: you wrote it, and your team uses it. The dossier marks it inspectable, so you can offer to walk through it end to end; check first that it is yours to share, since it is internal. Answer slot: the JD names API docs and schemas. If the playbook covers either, say how; if it does not, say so plainly and stay with what it does cover | F4 is the technical-fluency row, and the playbook is its one inspectable artifact. EXP because it tests what the artifact actually is |
| C3 | "The role defines and tracks adoption metrics. What have you tracked?" | EXP | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Start from what the quote carries: you led integrations through to go-live. Answer slot: if any adoption or usage was tracked for them, say what and how it was counted, in your own words; if none was, or it was not yours, say so plainly and say what you would measure first. Never describe a metric you did not track | F8 is silent in the material, so this rehearses the honest answer before the probe. EXP because it tests tracking, and the question's premise is the JD's, not an adopted fact |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc with three beats, each one a quoted sentence: the integrations you led, the playbook you wrote, the sessions you ran. The fourth beat is your own reason for this role in one sentence, which this pack does not supply. Close on the role, not on a claim about the title | F1, F4 and F7 are the three sentences you can stand behind, so the opener is built only from them. EXP because it is a walk through the record |
| D2 | "What are you actually playing with in API products these days?" | CO | [generic] | Casual in register and scored anyway. Pick something you really use or read about API design, docs or schemas, and say what you made of it. If nothing comes to mind, say so plainly, then give the nearest thing your material does carry | R3 names API docs and schemas, so a rapport-style question about them is likely. CO because it tests current interest in the domain |
| D3 | "What does a typical week running one of those integrations look like?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Walk the stages the quote lists, in order, and say which took most of your time. Answer slot: the JD lists engineering, sales and customers. If you worked with engineering or sales in those stages, say how; if you did not, or it was not yours, say so plainly and stay with the clients | F5 is where the quotes stop short of the requirement. EXP because it tests the shape of the work |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a PM who has done this job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; prohibited_claims: "Having held a product manager title or role" | Pause and restate the question. Hold only what the quote carries: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Concede in the sourced words: "I haven't held a product manager title or role." Hold through two follow-ups by returning to the quote; concede the title every time and never concede the integrations. Do not argue that you are the better choice | A1 under time pressure; F1 is the claim being held. JD because it scores the title requirement |
| E2 | "That playbook, those integrations — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | Hold on the quote's verbs: led, and wrote. Your material does not say how large the team was or which parts others did. Answer slot: say which parts were yours alone and which were shared, in your own words, and if a part was shared, say so plainly. Hold through two follow-ups by returning to those verbs, never adding to them | Attribution probes exist to catch inflation, and F1 and F4 are the two claims a stress interviewer would test. EXP because it scores honesty about contribution |

### F. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Our two squads sit alongside you — where's the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles and ask where the seam actually is: who owns which decisions, and who breaks a tie. Offer what you bring the squads: partner evidence reaching them early. Keep it to questions and principles; it asks for no past | F9 and the open authority question are the likeliest peer probe. JD because it scores the posting's squad responsibility |
| F2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Selection scaffold: pick a time work really did span teams, with a named contribution that was yours, and one that was someone else's, said plainly. If no such time comes to mind, say so, then give the nearest thing your material does carry, or how you would handle it | A collegial form of the attribution probe. EXP because it tests candor about contribution |

### G. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not soften it, and a relationship still intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem; no values page was available, so this is rehearsal of the pattern only. VAL because it tests behavior, not knowledge |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision with the customer's cost and the metric's cost both named, and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A partner-facing role makes customer-first stories likely, and the stem is the persona's. VAL because it tests behavior against a trade-off |

## Requirement coverage

| Requirement or responsibility | Questions |
|---|---|
| R1 3+ years product management experience | A1, A2, E1 |
| Own the roadmap (R1 sub-claim) | A1, A2, B1, B5 |
| R2 Shipped API or platform products | A3 |
| R3 Technical fluency: API docs, schemas | C2, D2 |
| R4 Stakeholder management | A4, D3, B3, F1 |
| R5 Agile delivery experience | A2 (answer slot); no separate question, since it is preferred and the dossier's strategy is clarify |
| Run discovery with integration partners | A4 |
| Define and track adoption metrics | B2, C3 |
| Write specs and drive delivery with two engineering squads | B3, F1; no spec-writing question — none, because nothing in the material reaches it and a premised question would invent a practice (F9 holds the slot) |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The posting asserts the authority and does not evidence it, and your answer to A1 depends on it. It reads as diligence about how the role works |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | Adoption is a named responsibility with no stated baseline. It tells you what you would be held to |
| 3 | "How does partner evidence reach the roadmap today, and who runs that?" | It opens the topic of the quarterly sessions without claiming more than they were, and shows you think about discovery as a system |
| 4 | "What would a strong first ninety days look like for someone who comes from integration delivery rather than a PM seat?" | It turns the A1 objection into a joint plan and lets the hiring manager say what would reassure them |
| 5 | "Where do the two squads and product disagree most often today?" | It surfaces the seam from F1 before you are inside it, and it shows what the role absorbs |
| 6 | "What would make this hire a mistake in six months?" | A direct question the hiring manager can answer honestly, and it is never generic |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | The dossier's prohibited_claims | The plain acknowledgment: "I haven't held a product manager title or role", then F1's quote at its own scope |
| Having owned a product roadmap | The dossier's prohibited_claims, and the acknowledge_gap area for R1 | The plain acknowledgment: "I haven't owned a product roadmap", then a plan, never a past. No bridge and no slot |
| Having set prioritization for an engineering squad | The dossier's prohibited_claims | The plain acknowledgment: "I haven't set prioritization for an engineering squad." No slot |
| Having shipped an API or platform product | Inflated form of F3 | F3's quote at its own scope; the limit is the pack's observation: the material says integrations of the vendor's APIs, not shipping one |
| Having run discovery with partners, or shaped the roadmap through the quarterly sessions | Inflated form of F7 | F7's quote at its own scope: the sessions fed client evidence to product. The decision was not described |

## Sources

Provided: `tuesday-dossier.md` pasted in your message, consumed for role_profile, decision (context only) and handoff_to_mock_interview. The round, the 45 minutes and the day are your own words.

Searches sent, all refused because web search was not permitted:

- `Quartzline company values principles`: refused
- `Quartzline interview process product manager`: refused
- `Quartzline API platform strategy news`: refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Would have fed a values cheat sheet and the VAL bank; without it, G1 and G2 are generic and no cheat sheet is built |
| 2. `Quartzline interview process product manager` | unavailable | Would have documented the loop and any values round; the persona weights rest on your stated 45-minute hiring-manager session |
| 3. `Quartzline strategy` / recent news | unavailable | Would have grounded the CO bank; B4 and A5 are generic |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's role_profile fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Web search permitted for this session: the three declined targets run, the generic CO and VAL rows (A5, B4, G1, G2) can become grounded, and a values cheat sheet appears if a values round is documented. A deeper pass is also available, up to 6 more searches and 2 more fetches and several more minutes.
- The hiring manager's name: a reading of their public footprint, adjusted persona weights and a reverse question tied to their own path.
- The recruiter's prep email: stated focus areas and any pre-declared deliverable.
- Your plain-text answers to the slots in F3, F4, F5, F6, F7, F8 and F9: each row moves from a slot to a story map, and A3, A4, C2, C3 and D3 sharpen with them.
- An agenda or notes from one of the quarterly sessions: the artifact that could raise F7 from medium to high.
- Your raw CV behind the confirmed claims: more rows to quote, and a check on the three sentences this pack rests on.
- How many hours you have before Thursday: the prep triage sized to it.
