Routing to mock-interview. Reading its playbook.
No dossier is present. Reading the playbook's reference files now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a/runs/sonnet/tuesday/part-2/rooms/case-3-denied-17f4ce8d/stripe_product-operations-manager_interview_pack.md`.

I built it for a final round with an unknown interviewer, so the persona weights are blended. The Case/Strategist and Skeptic styles lead. It holds 21 questions with answer guidance, six questions for you to ask them, and a requirement-coverage table.

My web searches were not permitted, so nothing in the pack is a fact about Stripe: no values, no interview format, no current strategy. I also had no job description or CV, so every row is generic and no guidance assumes anything about your past. Where a question asks about your experience, the guidance tells you how to pick your own example and ends with an honest fallback if none fits.

The highest-value prep is question B1: "Where does product operations end and project management begin, and which side of that line has your own work sat on?" I inferred that one from the role, not from your background.

I can play the Skeptic on B1 as a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed. If you'd like the pack as a Word document, say so and I'll convert it.

Three questions would restructure the pack:
1. Who is your interviewer (a future manager, a peer, a skip-level or a cross-functional partner), and is the final several back-to-back sessions? Any recruiter guidance, such as stated focus areas or a take-home, goes with that.
2. Can you paste the job description and a few lines of your background? I can proceed without them, but they would turn the generic rows into your own story map.
3. Are location, work authorization and any onsite requirement for this role settled on your side?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe — Product Operations Manager: final-round prep pack

Interviewer: not given. Relationship: not given. Built as a blended final-round pack, session mode, one upcoming conversation. No job description, no CV and no research were available, so every row is labeled `[generic]` and nothing here is a fact about Stripe or about you.

## How to use this pack

- Personas describe how a question is asked. Types describe what is being scored.
- Types: VAL (behavioral and values alignment), EXP (work-experience deep-dive), JD (role-driven), CO (company and strategy knowledge), CASE (live hypothetical problem).
- Guidance is scaffolding, not a script. Where a question asks about your past, the guidance tells you how to choose an instance and ends with an honest branch; it never supplies the story. The story has to be yours.
- Question IDs run by persona (A1, A2, B1...) so a drill can point at one.
- The highest-ROI prep is B1. It is inferred from the role family, not from your background; a CV would replace the inference with evidence.

## Fit snapshot

No background was supplied, so this is the worksheet variant. Requirements are role-family prose, not quotes, because no posting or recruiter wording was supplied. Nothing here is a claim about you.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Running a launch or program that spans several teams — role-family, no posting | none given | none | [generic] | discovery | Strong evidence is one named program: what shipped, which teams were involved, what was yours and what was others'. Selection scaffold: pick one program with a date, a named stake and teams that did not report to you. If no such program comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would run one |
| F2 | Metrics, reporting and an operating cadence such as reviews and planning rhythms — role-family, no posting | none given | none | [generic] | discovery | Strong evidence is a metric or review you owned and can explain end to end. Selection scaffold: pick a number you reported, and be ready to say how it was counted and what part was yours. If no such number comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would set one up |
| F3 | Influencing product, engineering and business partners without authority over them — role-family, no posting | none given | none | [generic] | discovery | Strong evidence is a disagreement with a named stake and an intact relationship afterwards. Selection scaffold: pick a time a partner team did not want what you proposed. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach it |
| F4 | Clear written and spoken communication, such as executive updates and decision documents — role-family, no posting | none given | none | [generic] | discovery | Strong evidence is a document or update you wrote that changed a decision. Selection scaffold: pick one, and be ready to say who read it and what happened next. If none comes to mind, say so plainly, then give the nearest thing your material does carry |
| F5 | Prioritisation and judgement in ambiguity, including deciding what process not to build — role-family, no posting | none given | none | [generic] | discovery | Strong evidence is a trade-off you made, with the option you turned down. Selection scaffold: pick a time you declined to build or fix something. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would decide |
| F6 | Fluency in the company's products and users — role-family, no posting | none given | none | [generic] | discovery | Research did not run, so no product or user fact is in this pack. Selection scaffold: pick one product or announcement you have actually followed and be ready to say why it caught your attention. If none comes to mind, say so plainly, and say what you would want to learn first |
| F7 | Location, work authorization and any onsite pattern for the role — role-family, no posting | none given | none | [generic] | hard_gate | Your material does not establish whether this is met. It is a term, not something wording can fix, and nothing in this pack bridges it. It is confirmed with the recruiter before the round, not rehearsed |

## Persona table

The loop is not established: no loop source was read, so the weights rest on round-type priors and the generic archetype, not on a documented Stripe process. No values-style round is detected, so there is no values cheat sheet.

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy (a rehearsal method, not a claim) |
|---|---|---|---|
| Case / Strategist | Live operating problems: plan this launch, diagnose this metric, design this cadence | Highest. A hiring manager is the most common final-round seat and a hiring-manager round leans on this persona and the Skeptic; the role is an operating role, so a live problem is natural | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic | Probes the line between product operations and project management, and why this role, why now | High. Same hiring-manager prior; product operations is a role whose boundaries are argued, so the boundary question is the likeliest objection | Rehearse the boundary answer until it is boring; use only your own material and say plainly where it stops; add a concrete ramp plan |
| Peer Evaluator | Seam between product operations and product management or engineering; credit across teams; what you need from them | Mid. A final round often includes a peer or cross-functional seat, and this role lives on seams | Reciprocity framing: what you bring their team; propose seam principles rather than claiming to know the seam |
| Data-Driven Prober | Numbers, how they were counted, the assumption you would defend least | Mid. A role that runs metrics reviews invites probing of your own numbers | Know how any figure you cite was counted; say plainly when you do not know; name the weakest assumption before they do |
| Values / Behavioral | Scenario stories: an unpopular truth, a customer ahead of an internal metric | Low-mid. No values-style round is detected, but a cross-functional seat may still ask | Pick stories where the hard truth actually landed; use we for context and I for contribution |
| Conversational / Rapport | Open biography and casual questions about what you are exploring | Low-mid. Friendly questions are still scored | A pre-scripted 90-second arc from your own sentences; never answer the reverse-question slot with nothing |
| Pressure / Stress | Time-boxed, devil's-advocate challenges to your motives and your share of results | Low. Possible from a skip-level seat; the interviewer is unknown | Pause, restate, anchor in what you actually said, hold through two follow-ups before conceding anything real |

## Question banks

Every row is `[generic]`: none rests on a sentence of yours, and none asserts anything about Stripe. Open prompts ask you to choose an instance; the story is yours to pick. Case questions presuppose nothing about your past.

### A. Case / Strategist (weight highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A major product launches in six weeks across three teams and nobody owns the launch checklist. Sketch the plan: what do you need to know first?" | CASE | [generic] | Ask first: what launch means here, what is already committed, who can say no. Then objective, who must act, the critical path, the metrics that say it is ready, the risks. Name the one premise you would challenge, such as whether a single owner is the fix | Covers F1 and F3. CASE because it scores structure over the answer |
| A2 | "A key activation metric for a self-serve product dropped 20 percent week over week. Diagnose it." | CASE | [generic] | Clarify the metric's definition and window, then split by segment, channel, product change and data pipeline. Say which cut you check first and why. Close with what you would tell the team today versus after more data | Covers F2. The classic diagnose-a-metric form for an operating role |
| A3 | "Design an operating cadence for a product org whose teams keep shipping late and surprising each other. What do you set up in the first 90 days, and what do you leave alone?" | CASE | [generic] | Start by diagnosing before prescribing: what is late, what is surprising, for whom. Then a minimal cadence, such as planning, a status review and an escalation path, with a stated reason for each. Name what you would deliberately not add | Covers F1, F2 and F5. JD content, CASE delivery; the leave-alone half scores judgement |
| A4 | "You can fund one of three improvements this quarter: a launch readiness checklist, a single source of truth for roadmap status, or a monthly metrics review. How do you choose?" | CASE | [generic] | Name the criteria first, such as cost of the current failure, time to value and who must change behavior. Pick one, say what would change your mind, and say what you give up | Covers F5. Forced trade-offs reveal prioritisation |
| A5 | "Which of our products or announcements have you followed most closely, and what would it mean for the operations behind it?" | CO | [generic] | Pick something you have actually followed and say why, then reason about the operating consequence aloud. If nothing comes to mind, say so plainly and say what you would want to learn first. No company fact is supplied here because research did not run | Covers F6. CO questions go generic without research, which is the cost of that missing step |

### B. Skeptic (weight high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Where does product operations end and project management begin, and which side of that line has your own work sat on?" | JD | [generic] | The highest-ROI rehearsal in this pack. Say where you draw the line in your own terms, then pick one piece of your own work and place it honestly. If it sat nearer project management, say so plainly and say what you would do to move toward the other side. Hold through two follow-ups by returning to what you actually did | Covers F1 and F5. This objection is inferred from the role family, not from your background; it will arrive in some form. JD because it tests the role's boundary |
| B2 | "Which part of a product operations role would you be weakest at on day one?" | JD | [generic] | Name one real weak spot, state its limit, and give a ramp plan with a first step in the first two weeks. Do not name a fake weakness | Covers F4 and F5. Scores honest self-assessment |
| B3 | "Why this role, why here, why now?" | EXP | [generic] | Three short beats in your own words: what pulls you to the work, why this company, why this moment. Keep it consistent with your biography answer in the Conversational bank. If one beat is not true for you, drop it | Covers F6. EXP because it tests motivation consistency across your own story |
| B4 | "How would you earn credibility with product managers and engineers who did not ask for an operations partner?" | CASE | [generic] | A plan, not a history: listen first, find one painful recurring problem, fix it quietly, share the credit, then propose the next step. State what you would not do in the first month | Covers F3. A live problem about the future, so it presupposes nothing about your past |

### C. Values / Behavioral (weight low-mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: it needs a named stake, a moment you did not soften it, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Covers F3 and F4. A standard stem for a scored behavioral conversation |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where the two actually conflicted and say what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Covers F5. Tests judgement over generic virtue |

### D. Peer Evaluator (weight mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where is the seam between product operations and product management, and what happens when we disagree?" | JD | [generic] | Propose seam principles rather than pretending to know the seam: who decides, who is consulted, what gets written down. Say how you disagree: evidence first, then a named decider | Covers F1 and F3. Peers price what a hire adds to or takes from their load |
| D2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Selection scaffold: pick a piece of cross-team work and say who got named and how. If no such piece comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Covers F3. Probes spine and tact together |
| D3 | "What would you need from me in your first month, and what could you take off my plate?" | JD | [generic] | Answer both halves: one concrete ask, one concrete offer. Keep the offer inside what you could really do in a month | Covers F3. Reciprocity framing |

### E. Data-Driven Prober (weight mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Pick a number you have reported at work. Walk me through how it was counted." | EXP | [generic] | Selection scaffold: pick a figure you can explain from source to slide. Say how it was counted, what it is sensitive to, and which part was yours. If no such figure comes to mind, say so plainly, and say how you would count one | Covers F2. Metrics are the probe target for an operating role |
| E2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | Name the assumption you know of before they do. If you do not know how a part of it was counted, say so plainly; that is a credibility gain, not a loss | Covers F2. The standard follow-up to E1 |
| E3 | "Which two or three metrics would you put on a product org's weekly operating review, and which would you refuse to include?" | CASE | [generic] | Choose by decisions they would change, not by what is easy to measure. Name the refusal and the reason. Say how you would check the metrics are being used | Covers F2 and F5. A live problem, so no claim about your past |

### F. Conversational / Rapport (weight low-mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [generic] | Pre-script a 90-second arc from your own CV sentences: where you started, the thread that links your roles, why this one next. It is scored even though it sounds casual. Without your CV this pack cannot write it; say so plainly and draft it from your own words | Covers F4. The biography question is scored |
| F2 | "What is something about how product teams run that you have been experimenting with lately?" | JD | [generic] | Pick something real and small: what you tried, what you saw, what you would change. If nothing comes to mind, say so plainly and say what you would like to try | Covers F6. Casual questions about live topics are still scored |

### G. Pressure / Stress (weight low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over an internal candidate?" | EXP | [generic] | Pause, restate, then three beats: what you bring, the evidence in your own words, what you would do first. Anchor in what you have actually done, not in comparison | Covers F4. Composure test |
| G2 | "Choose a result you are proud of. How much of it was actually you?" | EXP | [generic] | Selection scaffold: pick a result where you can separate your part from the team's. Say what was yours and what was others', and hold that through two follow-ups, conceding any specific you are unsure of. If no such result comes to mind, say so plainly | Covers F1 and F2. Rehearses precise attribution under pressure |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 Cross-team launch or program | A1, A3, B1, D1, G2 |
| F2 Metrics and operating cadence | A2, A3, E1, E2, E3, G2 |
| F3 Influence without authority | A1, B4, C1, D1, D2, D3 |
| F4 Communication | B2, C1, F1, G1 |
| F5 Prioritisation in ambiguity | A3, A4, B1, B2, C2, E3 |
| F6 Fluency in products and users | A5, B3, F2 |
| F7 Location, authorization, onsite pattern | none, and why: a gate is confirmed with the recruiter, not rehearsed |

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R1 | "How will you judge whether this role has worked at six months and at twelve?" | Shows you think in outcomes and gives you the scoring sheet | [generic] |
| R2 | "Which operating problem would you most want solved in the first 90 days?" | Turns the interview into scoping and lets you test your plan from A3 | [generic] |
| R3 | "Where do product operations, product management and engineering leadership argue about who decides, and how does that usually resolve?" | Shows you have thought about the seam from B1 and D1 | [generic] |
| R4 | "What does this team do that I would not see from the job description?" | Invites candor and shows curiosity beyond the posting | [generic] |
| R5 | "What has changed in how the team works over the last six months?" | Signals you care about direction of travel, not only the current state | [generic] |
| R6 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer; it answers D3 from their side | [generic] |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| none listed | No candidate sentences were supplied, so there is no quote whose wording could be stretched and no stated negative | Every cell in this pack is a selection scaffold, an answer slot or a live problem, and none asserts anything about your past. When you add your CV, this section is rebuilt against it |

## Sources

Provided documents: your message (company, role, final round). No job description, CV, interviewer profile or recruiter guidance was provided, and no `tuesday-dossier.md` was present.

Queries sent, all refused: "Stripe operating principles values" (refused); "Stripe interview process product operations manager" (refused); "Stripe strategy 2026 news priorities stablecoins agentic commerce tender offer" (refused); "Stripe Product Operations Manager job description responsibilities qualifications" (refused).

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Every call was refused. It would have supplied the official value names and the values cheat sheet |
| 2. Stripe interview process, product operations | unavailable | Every call was refused. It would have established the loop; persona weights fall back to the generic archetype and say so |
| 3. Stripe strategy and recent news | unavailable | Every call was refused. It would have fed CO and CASE questions grounded in current strategy; A5 is generic instead |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative product operations JD | unavailable | Every call was refused. It would have turned F1 to F6 from plain prose into quoted, labeled requirements |

## Upgrade menu

- The job description text → F1 to F6 become quoted requirements and the JD-tagged questions become grounded
- Your CV or a short background paragraph → the worksheet becomes a real fit snapshot with your own sentences quoted, the guidance becomes story maps, and B1 is built from evidence instead of inference
- The interviewer's name and title, or who is in the round → an interviewer read and persona weights from their public footprint
- If your final is several sessions, the schedule → per-session mini-packs
- Recruiter guidance, such as focus areas or a pre-declared deliverable → coverage of that deliverable
- Search permission → Stripe's published values, loop and current strategy, the values cheat sheet if a values round is documented, and grounded CO questions; a deeper tier would add up to 6 further searches and 2 further fetches, several more minutes, run only if you say so
- A tuesday-dossier.md from an earlier review of this role → verified evidence and the objection worth the deepest rehearsal, replacing the inferred one in B1
