Reading is done, and I'm now running the L1 company research on Quartzline: values, interview process, and strategy. Then I'll build the pack.
Web search was refused, so I'm building the pack from the dossier alone. Company-specific parts will be labeled generic and the refused searches logged in Sources.
The script needs approval I don't have, so I'm expanding the Q1–Q3 shorthand into the full quoted sentences with direct edits instead.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a/runs/sonnet/tuesday/part-2/rooms/case-4-denied-ec4bc30d/Quartzline_product-manager-platform-apis_interview_pack.md`. I built it for a 45-minute hiring-manager round, using the dossier alone. The web searches on Quartzline were refused, so company-specific parts (values, loop, strategy) are labeled generic and the refused searches are logged in the pack's Sources.

- **Highest-ROI prep:** B1, the objection your dossier named ("never held the PM title or owned a roadmap"). The pack coaches a plain concession, then your three verified facts framed as adjacent work, then the limit, then a ramp plan. It never claims PM experience.
- **Where the dossier ties your hands:** roadmap ownership is an acknowledge-gap area, so the roadmap cases (A1, B5) are answered as method, not memory.
- **Medium-confidence claim:** the quarterly roadmap-input sessions are confirmed but thinly proven. The pack coaches you to volunteer that limit before a prober finds it.
- **Duration:** the dossier's summary says "seven years," but no verified entry carries a duration. The pack states none until you confirm dates.
- **Prep plan:** the pack includes a two-day triage. Today: B1, D1, D3 and your opener (E1). Wednesday: the cases (A1–A3) plus filling in the answer slots in your own words.

I can run a live drill, starting with the Skeptic on B1. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions. Or I can convert the pack to a Word document if you'd prefer that.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

**Round:** hiring manager, 45 minutes, Thursday 2026-11-19. **Interviewer:** name not given. **Built from:** your underwriting dossier (conditional_go) alone; no web research ran (see Sources).

## How to use this pack

Personas describe how a question arrives; types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your claims survive scrutiny; what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem from the role, structured aloud |

Two things to know before you read a guidance cell. First, an **answer slot** is an instruction for the interview: it names a probe the interviewer is likely to make and gives you two honest branches, one for if you did the thing and one for if you did not or it was not yours. Fill it from your own memory; the pack will not supply the detail. Second, the labels in the Provenance column are `[grounded]` (traceable to your dossier), `[inferred]` (derived, derivation named) and `[generic]` (a pattern, no claim about you or Quartzline).

## Prep triage

You have about two days. Do these in order; everything else is insurance.

1. **Today:** rehearse B1 aloud, three times, then D1 and D3 (the time-boxed and interrupted versions). B1 is the highest-ROI prep in this pack. Then write and say E1, your 90-second arc.
2. **Wednesday:** run A1, A2 and A3 aloud as structures (clarify, objective, approach, metrics, risks). Fill the answer slots in B2, B3, C1 and C3 in your own words, in writing, once each.
3. **Thursday morning:** B1 once more, then pick three reverse questions (section 11) and say them aloud. Stop there.

Everything else is insurance.

## Fit snapshot

No requirement in the dossier's `role_profile` is a gate (a term you meet or do not). R1's years requirement is graded like any other row, not as a gate. The dossier does not grade R2, R3 or R4 individually, so those rows are this pack's own reading and carry `[inferred]`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | low | [inferred] | transferability | The dossier's allowed strategy is bridge: adjacent work, positioned as adjacent, never as PM experience. Words stay at the quotes' scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs: scoping, requirements, architecture, UAT, go-live." The limit, as the pack's observation: your material shows integration leadership and input sessions, and no PM title or role. Plain acknowledgment, sourced to `prohibited_claims` item "Having held a product manager title or role": "I haven't held a product manager title or role." The second quote is medium confidence (confirmed, limited inspectable proof), so expect a probe on it and volunteer its limit before it is extracted |
| F2 | "Owning a roadmap and prioritization authority" — dossier uncertain_or_weak_areas (R1 sub-claim); the responsibility reads "Own the roadmap for the partner-facing API platform" — dossier role_profile | none given | none | [grounded] | capability | The dossier records this as an acknowledge_gap area, so there is no bridge and no answer slot. Words, sourced to `uncertain_or_weak_areas` and to `prohibited_claims` items "Having owned a product roadmap" and "Having set prioritization for an engineering squad": "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then a ramp plan, said as future: "In the first weeks I'd learn how roadmap decisions are made here and which belong to whom before proposing anything." Nothing added to make the gap feel smaller |
| F3 | "Shipped API or platform products" — dossier role_profile R2, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | medium | [inferred] | transferability | The quote is integrations of the vendor's APIs; the pack's observation is that your material does not show shipping an API or platform product. Words stay at the quote: "I led 30+ end-to-end client integrations of the vendor's REST APIs: scoping, requirements, architecture, UAT, go-live." Answer slot: R2's wording makes a probe on what you shipped likely. If you shipped an API or platform product, say which and what your part was, in your own words; if you did not, or it was not yours, say so plainly and stay with the integrations |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | medium | [inferred] | discovery | Both quotes touch the requirement and neither shows whether it reaches API docs or schemas, and you have stated no absence. Words: "I wrote the internal integration playbook my team uses." Answer slot: R3's wording makes a probe on what the playbook and the integrations involved likely. If any of it was API reference or schema material, say what and how you used it; if none was, say so plainly and stay with the playbook as written. The playbook is the one inspectable artifact in your evidence |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [inferred] | transferability | The quotes carry client-facing delivery and a channel from clients to product; they do not mention engineering or sales as stakeholders you worked with. Words stay at the quotes' scope. Answer slot: R4 names engineering and sales, so expect a probe on those two. If you worked with either, say how and what your part was; if you did not, say so plainly and stay with clients and product |
| F6 | "Agile delivery experience" — dossier role_profile R5, preferred; "Agile delivery inside a product org" — dossier uncertain_or_weak_areas | none given | low | [grounded] | discovery | The dossier's strategy is clarify: the evidence may exist and was not established, and no verified entry speaks to it, so nothing about your past is asserted here. Answer slot, B4: R5's wording makes a probe likely; if you have worked in an agile delivery model, say how in your own words; if you never worked that way, say so plainly. Then ask what they mean by it: "Which cadence and ceremonies do your two squads run?" |

## Persona table

The weights rest on the hiring-manager relationship prior in this skill's persona model plus the dossier's objection. Quartzline's actual loop is not established (research did not run), so the weights rest on a pattern, the generic screen, hiring manager, panel archetype, and not on Quartzline's documented process. Recalibrate if you know something about the loop.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems from the role: prioritize, diagnose adoption, write a spec | High (bank A, 5 questions). A hiring manager is buying capability, and the role's responsibilities are concrete enough to build cases from | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully per case. Answer roadmap cases as a method, never as a memory (F2) |
| Skeptic | Quiet, persistent probing of the gap: no PM title, no roadmap | High (bank B, 5 questions). The dossier names this objection, and a first-time-PM hire is exactly where a manager derisks | Rehearse B1 until it is boring; the bridge rests only on adjacent work you quoted, with its limit stated, plus a ramp plan |
| Data-Driven Prober | Reads your lines one by one; asks how a number was counted | Medium (bank C, 3 questions). "30+" is a headline figure and a prober will test it | Know what you can and cannot say about how the figure was counted; say plainly when you do not know; name the weakest assumption before they do |
| Pressure | Interrupts, time-boxes, tests whether you hold a position without defensiveness | Medium (bank D, 3 questions). B1 gets asked in a harder register if the manager wants to test composure | Pause, restate, anchor in what you stated, hold through two follow-ups before conceding anything real |
| Conversational | Chatty opener, "walk me through the journey" | Low-medium (bank E, 2 questions). Every 45-minute interview opens somewhere, and it is still scored | A 90-second arc built from your quoted sentences; treat casual questions as scored |
| Values/Behavioral | Behavior stories, "tell me about a time" | Low (bank F, 2 questions). No values-style round is detected: the fallback archetype is generic and no Quartzline source documents one | Pick stories your own material actually carries; where none comes to mind, say so plainly |
| Peer Evaluator | Seam-splitting between teams | Low, no bank. It belongs to a round with a squad lead, which is not this round; the squad-lead seam is covered in A3 and the reverse questions | Propose seam principles rather than pretending to know the seam |

## Question banks

Provenance quotes are the sentences each cell rests on, copied from the fit snapshot. A row whose guidance makes no claim about you carries its label alone.

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two partners want conflicting changes to the API in the same quarter, and engineering can take one. How do you decide, and what do you need to know first?" | CASE | [generic] | A method, not a memory, because F2 is an acknowledge_gap area (`uncertain_or_weak_areas`). Clarify first: what each change affects, how many partners, what is committed already. Then objective, a small set of criteria you would state aloud, a recommendation with its reasoning, what you would tell the partner who loses, and the risk. If asked whether you have decided this before, the sourced answer is "I haven't owned a product roadmap" (`prohibited_claims`), then back to method | The role's roadmap responsibility makes prioritization the likeliest live case. Tied to F2. JD content, CASE delivery |
| A2 | "Adoption of a new partner endpoint is flat six weeks after launch. Diagnose it." | CASE | [generic] | Ask how adoption is defined and measured before diagnosing; the dossier says no baseline is stated, so asking is both good structure and real diligence. Then segment partners, walk the path from interest to a live integration, form two or three hypotheses, say which metric would confirm each, and name a risk. You may use the stages in Q1 ("scoping, requirements, architecture, UAT, go-live") only as a way to name where partners could stall, not as a claim about measuring adoption: your material does not show defining or tracking adoption metrics | The JD's adoption-metrics responsibility is the unknown the dossier flagged, so a diagnose-a-metric case is likely. Tied to F3 and F4. CASE delivery, JD content |
| A3 | "You are writing the spec for a breaking change to an endpoint partners already use. What goes in it, and how do you get two engineering squads delivering against it?" | CASE | [generic] | Structure only: what you need to know first (who consumes the endpoint, what depends on it), the spec's parts (the change, the reason, a migration path for partners, what partners will be told and when), and how you would agree ownership of the work with each squad lead before writing anything. Propose the principle for dividing the work rather than pretending to know the seam: the authority split with the squad leads is an open question in the dossier, so ask it. Make no claim about having written specs | The JD names specs and two squads, and the seam with squad leads is the dossier's unresolved risk. Tied to F2 and F4. CASE delivery, JD content |
| A4 | "Tell me about a time you had to work through an API's documentation or schema to get something unblocked." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | Story-map only what the quotes state: "I led 30+ end-to-end client integrations of the vendor's REST APIs: scoping, requirements, architecture, UAT, go-live," and "I wrote the internal integration playbook my team uses." Pick one moment in your own words. Answer slot: R3's wording ("API docs, schemas") makes a probe on whether that work involved reference or schema material likely. If it did, say what and what your part was; if it did not, say so plainly and stay with the integrations and the playbook | R3 is an important requirement and F4 is a discovery row, so this is where the evidence is least established. JD content, EXP delivery |
| A5 | "How would you run discovery with our integration partners in your first 30 days?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Method first: who the partners are, what you would ask, how you would hear from the ones who are quiet. One sentence from your own material, at its own scope: "I ran quarterly roadmap-input sessions feeding client evidence to product." Volunteer the limit before it is extracted: the sessions fed evidence to product, and "I haven't owned a product roadmap" (`prohibited_claims`, `uncertain_or_weak_areas`). The dossier marks this claim confirmed with limited inspectable proof, so expect a probe on the sessions themselves and describe them only as you remember them | The JD's discovery responsibility meets F5's medium-confidence evidence, and a prober will find that seam. Tied to F1 and F5. JD content, CASE delivery |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | **The highest-ROI rehearsal in this pack; the underwriter named it, wording as written.** Four moves, in order. (1) Concede first, plainly, sourced to `prohibited_claims` and `uncertain_or_weak_areas`: "I haven't held a product manager title or role, and I haven't owned a product roadmap." (2) Offer the adjacent case and call it adjacent: "I led 30+ end-to-end client integrations of the vendor's REST APIs: scoping, requirements, architecture, UAT, go-live. I wrote the internal integration playbook my team uses. I ran quarterly roadmap-input sessions feeding client evidence to product." Do not call any of this product management. (3) Name the limit before they do: that is integration work and input to product, not the job, and a PM with three years has done parts of the job you have not. (4) Close with the ramp plan, said as future: "In the first weeks I'd learn how roadmap decisions are made here and which belong to whom before proposing anything." Hold through two follow-ups by returning to the quotes, never adding to them. If asked to name a roadmap decision you made, the answer is the concession. If asked what product did with the sessions' evidence, say only what you know first-hand. Do not tell them what the work proves; describe it and let them decide | F1 and F2 are the largest gap, and the dossier's condition is that the bridge stays adjacent. JD content, Skeptic delivery |
| B2 | "Which API or platform product have you shipped?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Start from what the quote carries: "I led 30+ end-to-end client integrations of the vendor's REST APIs: scoping, requirements, architecture, UAT, go-live." Say plainly that this is integrations of the vendor's APIs. Answer slot: if you shipped an API or platform product, say which and what your part was, in your own words; if you did not, or it was not yours, say so plainly and stay with the integrations | R2 is a must-have, and F3 is where the question presses. JD content |
| B3 | "Tell me about working across engineering, sales and customers." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | Story-map only the two stakeholder sides the quotes carry: customers, through "I led 30+ end-to-end client integrations of the vendor's REST APIs: scoping, requirements, architecture, UAT, go-live," and product, through "I ran quarterly roadmap-input sessions feeding client evidence to product." Volunteer that the second is confirmed with limited inspectable proof. Answer slot: R4 names engineering and sales, so expect a probe on those two. If you worked with either, say how and what your part was; if you did not, say so plainly and stay with clients and product | R4 is a high-priority requirement in the handoff and F5 is thin on two of its three stakeholder groups. JD content, EXP delivery |
| B4 | "How have you worked in an agile delivery model?" | JD | [grounded] | No verified entry speaks to this, so nothing about your past is asserted. Answer slot: R5's wording ("Agile delivery experience") is the interviewer's probe. If you have worked in an agile delivery model, say how, in your own words; if you never worked that way, say so plainly. Then turn it into a question you actually need answered: "Which cadence and ceremonies do your two squads run, so I know what I'd be stepping into?" | F6 is a clarify area in the dossier and the preferred requirement most likely to be asked casually. JD content |
| B5 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer with the dossier's acknowledge_gap area, not a bridge: "Owning the roadmap and setting priorities. I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad" (`uncertain_or_weak_areas`, `prohibited_claims`). Then the ramp plan, as future, and what you would lean on, at its own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs: scoping, requirements, architecture, UAT, go-live." Calibrated candor beats bluffing a competency the manager personally owns | Persona stem for the Skeptic, aimed straight at F2. JD content |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You say 30+ integrations. How were those counted?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The figure is attached to client integrations, so keep it there. Four slots, each in your own words, none supplied by this pack. Answer slot: how the 30+ was counted. Answer slot: what the figure is sensitive to. Answer slot: the assumption behind it you would defend least. Answer slot: which part of the integrations was yours. For each, "I don't know how it was counted" or "that part was not mine" is an honest branch. Name the weakest assumption before they do | F1 and F3 both rest on this figure, and probers go to headline numbers first |
| C2 | "Walk me through one of those integrations, scoping to go-live." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The beats the quote states are the stages: "scoping, requirements, architecture, UAT, go-live." Choose one integration and tell those stages in order, in your own words, saying what you did at each and what others did. No stage beyond those five gets added by this pack; add detail only if it is yours | Tests whether F1's evidence survives a walk-through. EXP content, Prober delivery |
| C3 | "Tell me about the playbook: what it covers and how your team uses it." | EXP | [grounded] "Wrote the internal integration playbook her team uses" | "I wrote the internal integration playbook my team uses." Describe what it contains in your own words. Answer slot: R3's wording makes a probe on whether it holds API reference or schema material likely; if it does, say what; if not, say so plainly. The dossier marks this the one inspectable claim, so check whether you are allowed to show a section of it and say so only if you are | F4's strongest evidence. EXP content, JD fit |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a PM who has done this for three years?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | The B1 answer, compressed: concede in one sentence ("I haven't held a product manager title or role," `prohibited_claims`), give the three quoted facts in one breath at their own scope, name the limit, stop. Do not fill the remaining time with extra claims; silence after a clean answer is fine. Hold through two follow-ups, then concede specifically | Time-boxed version of the dossier's objection (F1, F2). JD content, Pressure delivery |
| D2 | "That result: how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold the word the quote uses: "Led." Say which stages were yours and which were done with or by others, in your own words. Answer slot: which of scoping, requirements, architecture, UAT and go-live you decided versus carried out; if some belonged to others, say which, and if the whole sequence was yours, say that. Concede uncertainty specifically, never fold on "Led" just to restore harmony | The attribution probe exists to catch inflation (F1, F3). EXP content, Pressure delivery |
| D3 | "Stop. You keep saying integration. Is that product management, or isn't it?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | Do not claim it is. The dossier's condition is that this is adjacent, never PM experience: "I haven't held a product manager title or role" (`prohibited_claims`). Then stay with the quotes: "I led 30+ end-to-end client integrations of the vendor's REST APIs," and "I ran quarterly roadmap-input sessions feeding client evidence to product." Call it adjacent work and state its limit. Hold that position through two follow-ups; do not drift into "I effectively did the PM job" | Tests the positioning discipline directly (F1). JD content, Pressure delivery |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc with three beats the quotes carry, in your own words: the client integrations ("I led 30+ end-to-end client integrations of the vendor's REST APIs"), the playbook ("I wrote the internal integration playbook my team uses"), the input sessions ("I ran quarterly roadmap-input sessions feeding client evidence to product"). Then your own reason for wanting this role. Answer slot: give your actual reason for moving toward product in your own words; this pack supplies none. Frame the arc as adjacent work moving toward product, not as PM experience | A biography opener is almost certain, and a scripted arc is how you control the first five minutes. EXP content, Conversational delivery |
| E2 | "Tell me about something recent that shaped how you think about API design." | JD | [generic] | A selection scaffold: choose one specific thing you read, used or built, say what you took from it and what you would do differently, in your own words. If nothing recent comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would stay current. Nothing about your past is asserted here | A casual question about a hot JD topic (R3) that is still scored. JD content |

### F. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you delivered an unpopular truth to leadership." | EXP | [generic] | A selection scaffold: pick a time with a named stake, a moment you did not fold, and an intact relationship afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Nothing about your past is asserted here | Persona stem; no published Quartzline values are in hand, so it is tagged EXP, not VAL. Low weight |
| F2 | "When did you put a customer ahead of an internal metric?" | EXP | [generic] | The same scaffold: a named stake, what the metric was, what you chose and why, how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would decide. Nothing about your past is asserted here | Persona stem; a partner-facing role makes customer-first framing a likely probe. Low weight |

### Requirement coverage

| Requirement | Questions |
|---|---|
| R1: 3+ years product management experience (F1) | B1, B5, D1, D3, E1 |
| R1 sub-claim: roadmap and prioritization authority (F2) | A1, A3, B1, B5, D1 |
| R2: shipped API or platform products (F3) | B2, A2, C1, C2, D2 |
| R3: technical fluency, API docs, schemas (F4) | A4, C3, E2 |
| R4: stakeholder management across engineering, sales, customers (F5) | B3, A5 |
| R5: agile delivery experience (F6) | B4 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | From the dossier: the posting asserts decision authority over the two squads without evidencing it. The answer is something you genuinely need before accepting, and it reads as diligence about the seat's scope |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | From the dossier: adoption metrics are a named responsibility but no baseline is stated. It tells you whether the metric you would own already exists |
| 3 | "When the two squads disagree on priorities, how does that get resolved today?" | Turns the authority question into a concrete mechanism and avoids presuming where the seam is |
| 4 | "What would you want a new PM here to have learned or delivered by the end of the first 90 days?" | Lets the manager name the bar, and tells you whether the ramp plan in B1 matches it |
| 5 | "What would you need to see to be confident in someone who has not held the PM title?" | Puts the objection in the room where you can answer it, and shows you are not hiding the gap. Ask it only after B1 has gone well |
| 6 | "How do partners tell you what is wrong with the API today, and who hears it first?" | Opens the discovery responsibility without claiming anything about your own history with it |
| 7 | "What is the one thing about this role that is not in the posting?" | A closing question that is never generic, because the answer changes what you would accept |

## Prohibited claims

Built from the dossier's `prohibited_claims` before the banks were written. These bind every guidance cell, slot and drill.

| Not coached | Basis | Honest form |
|---|---|---|
| Holding a product manager title or role | `prohibited_claims`: "Having held a product manager title or role" | The plain acknowledgment: "I haven't held a product manager title or role." Then F1's quotes at their own scope, positioned as adjacent |
| Having owned a product roadmap | `prohibited_claims`: "Having owned a product roadmap"; `uncertain_or_weak_areas` acknowledge_gap area | The plain acknowledgment: "I haven't owned a product roadmap," plus a ramp plan. No bridge and no slot. The input-sessions quote stays at "feeding client evidence to product" |
| Having set prioritization for an engineering squad | `prohibited_claims`: "Having set prioritization for an engineering squad" | The plain acknowledgment: "I haven't set prioritization for an engineering squad." Do not stretch "requirements" or "scoping" in the integration quote into prioritization authority |
| Having shipped an API or platform product | Inflated form of F3: R2 widens the integration quote | F3's quote at its own scope. The limit is the pack's observation: the material says integrations of the vendor's APIs, not shipping a product |
| Having authored API documentation or schemas | Inflated form of F4: R3 widens the playbook quote | F4's quotes at their own scope. The limit is the pack's observation: the material says the playbook, not API reference or schemas |

## Sources

- **Provided:** `tuesday-dossier.md`, dossier_version 1.1, generated by job-underwriter on 2026-08-14 (three months before this pack, so check the posting has not changed). Sections consumed: `role_profile` (requirements, responsibilities, unknowns) and `handoff_to_mock_interview` (high-priority requirements, verified candidate evidence, uncertain or weak areas with allowed strategies, the likely objection, risks to validate, employer questions, prohibited claims). Not present in the dossier: `evidence_map`, `evidence_state`, `risk_register`. The dossier's decision (conditional_go) is context only.
- **Searches sent:** "Quartzline values" — refused. "Quartzline interview process product manager" — refused. "Quartzline partner API platform strategy news" — refused. No page fetches were sent. Nothing in this pack about Quartzline's values, loop or strategy comes from outside the dossier.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | The search was refused. Would have fed a values cheat sheet; none is built, and the F bank uses persona stems only |
| 2. `Quartzline interview process product manager` | unavailable | The search was refused. Would have set the loop and persona weights; they rest on the hiring-manager relationship prior and the generic archetype instead |
| 3. `Quartzline partner API platform strategy news` | unavailable | The search was refused. Would have fed a company-strategy CO question; the cases in bank A are generic and labeled so |
| 4. `{interviewer name} Quartzline` | n/a | No interviewer name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's `role_profile` fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The interviewer's name → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to their own path
- Quartzline research (search was refused this session; allow it, or paste Quartzline's values page, careers or interview page, and any strategy brief) → a company-strategy question, loop-based persona weights, and a values cheat sheet if a values round is documented. A deeper pass, up to 6 more searches and 2 more fetches and several more minutes, would add strategy and org context once search is allowed
- The recruiter's prep email, any stated focus areas or any pre-declared deliverable → coverage for each, and a build section for any take-home or presentation
- Something shareable from one of the quarterly roadmap-input sessions (an agenda, notes or a deck) → the medium-confidence claim behind F1 and F5 can move toward high, which shrinks the seam a prober will find
- Your dates and tenure for the integration work (the dossier's decision summary mentions a duration, but no verified entry carries one, so this pack states none) → B1 and E1 can include a duration
- Your answers to the answer slots in B2, B3, B4, C1 and A4, written in your own words → those rows regenerate as story-mapped guidance
