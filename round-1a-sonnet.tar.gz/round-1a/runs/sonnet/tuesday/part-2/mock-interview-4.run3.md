I've read the mock-interview playbook and its reference files. Next I'll run a small research pass on Quartzline, then build the pack from your dossier.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a/runs/sonnet/tuesday/part-2/rooms/case-4-denied-c46fc7d6/quartzline_product-manager-platform-apis_interview_pack.md`. I built it for a hiring-manager round from your dossier alone, because the three Quartzline searches (values, interview process, strategy) were refused. Quartzline facts, company-knowledge question D3 and the case questions are therefore generic, and the Sources section says so.

Rehearse B1 first, since the dossier names it as the objection you'll get. It asks why Quartzline should hire you over a PM with three years of the actual job. The pack has you state the limits before you're asked: you haven't held the PM title and haven't owned a roadmap. Then you give the integration and roadmap-input work as adjacent experience, not PM experience.

The dossier doesn't flag R2, "shipped API or platform products", as a weak area, but your verified evidence is about integrating the vendor's APIs, not shipping them. I treated it as an open question (F3, A5). Decide your honest answer before Thursday.

I asked no questions, since the dossier covers the JD and your evidence and you gave the round type.

Say the word and I'll play the Skeptic on B1, the question the pack names as its highest-ROI prep.
I can also save a `tuesday-dossier.md` update recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

Round: hiring-manager conversation, 45 minutes, Thursday. Interviewer: the hiring manager (no name given). Built from your dossier (`tuesday-dossier.md`) with no outside research, because the search calls were refused (see Sources).

## How to use this pack

Personas describe how a question is asked; types describe what is scored. Guidance is scaffolding, not a script: every line of proposed language below is pending your approval, so change anything that is not true to what you did, and say it in your own words.

| Type | What it scores |
|---|---|
| VAL | Behavior against the company's published values (no bank in this pack: no values-style round was detected) |
| EXP | Whether your claims survive scrutiny and what was actually yours |
| JD | The stated role requirements, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem, structure over the "right" answer |

## Prep triage (Tuesday and Wednesday)

1. Tonight: rehearse B1 aloud until it is boring, then B2 and E1. B1 is the highest-ROI prep in this pack; the dossier names it as the objection you will face.
2. Tonight: C1, C2 and E2, the questions on your own numbers and sessions, using only the sentences quoted in the fit snapshot.
3. Wednesday: think aloud through A1 and A2 using the clarify, objective, segmentation, approach, metrics, risks order. Decide your own honest branch on every answer slot (A4, A5, B3, B4).
4. Wednesday: D1, your 90-second arc, then the reverse questions below.

Everything else is insurance.

## Fit snapshot

Requirement text comes from the dossier's `role_profile`; evidence cells hold only the verified sentences the dossier carries.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | low | [inferred] | transferability | Strategy is bridge, with the limit named: this is adjacent work, never product management experience. Derived from the dossier's bridge framing over the two quotes. Words: "I led 30+ end-to-end client integrations of the vendor's REST APIs, and I ran quarterly roadmap-input sessions feeding client evidence to product. That is adjacent to product management, and I haven't held a product manager title or role." The last clause rests on `prohibited_claims`: "Having held a product manager title or role". No years figure is claimed, because no quote carries one |
| F2 | "Owning a roadmap and prioritization authority (R1 sub-claim)" — dossier uncertain_or_weak_areas | none given | none | [grounded] | capability | The dossier records this as `acknowledge_gap`, so there is no bridge and no slot. Words come only from the dossier field `prohibited_claims`: "Having owned a product roadmap" and "Having set prioritization for an engineering squad". Say: "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F3 | "Shipped API or platform products" — dossier role_profile, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | high | [inferred] | discovery | The dossier carries no weak-area grade for this must-have, so this row is the pack's own call: your quote says integrations of the vendor's REST APIs, which touches the requirement without showing whether you shipped an API or platform product. Answer slot: the requirement's wording makes a probe on shipping likely. If you shipped an API or platform product, say which and what part was yours, in your own words; if not, or it was not yours, say so plainly and stay with the integrations you led |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | high | [inferred] | discovery | The quotes show REST APIs, architecture and a playbook you wrote; the pack's observation is that they do not show API docs or schemas. Answer slot: the requirement names API docs and schemas, so expect a probe. If you worked from or wrote API docs or schemas, say which and how, in your own words; if not, say so plainly and return to the integrations and the playbook |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [inferred] | discovery | The roadmap-input sentence is confirmed with limited inspectable proof, so expect a probe on it and volunteer its limit: it says sessions feeding client evidence to product. Answer slot: the requirement names engineering, sales and customers. For each you worked with, say how, in your own words; for any you did not, say so plainly and stay with the clients and product the quotes name |
| F6 | "Agile delivery experience" — dossier role_profile, preferred | none given | low | [grounded] | discovery | Strategy is clarify: no verified sentence speaks to this requirement itself, so nothing about your past goes in. Answer slot: the requirement's own wording, agile delivery, is the probe. If you worked that way, say how in your own words; if you never worked that way, say so plainly, then say what you would want to confirm about how Quartzline defines it |

## Persona table

Weighting rests on the relationship prior for a hiring manager, adjusted by the dossier's named objection and by your own words about the round. Your note establishes one session, a 45-minute conversation with the hiring manager. No company loop document was read, and no values-style round was detected, so there is no values bank. No interviewer profile exists, so no interviewer signals were applied.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (A) | Live problems on the partner API roadmap and adoption | High: hiring managers buy capability through live problems, and the JD's responsibilities are about roadmap, discovery and adoption | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic (B) | Quiet, persistent probing of the title and roadmap gap, motivation, weakest day-one area | High: the dossier names this objection and gives the gap's strategy, so the Skeptic is the persona the dossier raises | Rehearse the objection until it is boring; bridge only from the quoted sentences with the limit named; calibrated candor on what you haven't done |
| Data-Driven Prober (C) | Walks the quoted claims line by line | Medium: there is one headline number and one medium-confidence sentence a prober will test | Know what you can and cannot say about how the number was counted; say plainly where you do not know |
| Conversational (D) | The biography opener and casual questions about the space | Medium: standard opener for any first conversation, and still scored | A pre-scripted 90-second arc; treat casual questions as scored |
| Pressure (E) | Time-boxed challenges to the move | Low: no signal for a stress style | Pause, restate, hold the quoted position through two follow-ups, concede specifically |
| Peer Evaluator (P) | The seam with the two squad leads | Low: the hiring manager is not a peer, but squad authority is an open unknown in the dossier | Propose seam principles, do not pretend to know the seam |

## Question banks

All guidance below is proposed language pending your approval. Answer slots are instructions for the interview, not questions for this conversation.

### A. Case/Strategist (weight high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You are the PM for our partner API platform. Two squads, one quarter, and partners are asking for three different things. How do you decide what to work on first?" | CASE | [generic] | Clarify before structuring: what the objective is this quarter, who the partners are, and which of these calls the PM makes alone versus with the squad leads. Then segment the requests, choose an approach, name the metrics and the risks. Think aloud and challenge one premise. The question needs no claim about your past, so the guidance makes none | F2's area is where this case presses hardest; asking about decision authority doubles as your reverse question and answers one of the dossier's unknowns. CASE because it is a live problem on the actual role |
| A2 | "Adoption of the partner API has gone flat. How do you diagnose it?" | CASE | [generic] | Start by asking how adoption is measured today and what the baseline is. Then segment partners, locate where they drop off between signing up and going live, form hypotheses, say what data would separate them, and name the cheapest first test. No claim about your past | The dossier lists the current adoption baseline as an unknown, so the honest first move is to ask for it. CASE because it is diagnosis delivered live |
| A3 | "What adoption metrics would you define for a partner-facing API platform, and which one would you deliberately not track?" | CASE | [generic] | Structure it as a short list tied to the objective, with the reason each metric moves a decision, and one metric you would refuse with the reason. Say what you would need to learn about the current measurement first. No claim about your past | Defining and tracking adoption metrics is one of the role's responsibilities; a deliberate anti-pick shows judgment. CASE because it is asked as a design problem |
| A4 | "How comfortable are you with API docs and schemas? What would you do in your first week with ours?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | Story-mapped on F4: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live", and "I wrote the internal integration playbook my team uses". The playbook is a document you wrote, not API reference docs, so say it as a playbook. Answer slot: the requirement names API docs and schemas. If you worked from or wrote API docs or schemas, say which and how; if not, say so plainly and return to the integrations. For the first week, state a plan, not a past: what you would read first and who you would ask | F4 is the evidence for the technical-fluency requirement. JD because it scores a stated requirement |
| A5 | "Tell me about an API or platform product you shipped." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Selection scaffold, because the quote shows integrations of the vendor's APIs, not a product you shipped. Pick an instance that reached users live, with a named stake and a clear statement of what part was yours. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry: "I led 30+ end-to-end client integrations of the vendor's REST APIs, through go-live", or say how you would approach it | F3 is a must-have with no weak-area grade in the dossier, so this is the likeliest unprepared miss. JD because it scores R2 directly |

### B. Skeptic (weight high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; "Wrote the internal integration playbook her team uses"; `prohibited_claims`: "Having held a product manager title or role"; `prohibited_claims`: "Having owned a product roadmap" | The highest-ROI rehearsal in the pack, named by the dossier. Limit first, before it is asked: "I haven't held a product manager title or role, and I haven't owned a product roadmap." Then the adjacent work at its own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs, and I ran quarterly roadmap-input sessions feeding client evidence to product." Then a ramp plan, said as a plan: what you would learn first about how the two squads decide and how adoption is measured today. Follow-up 1, a PM with three years of the job: hold by returning to the two sentences and adding nothing. Follow-up 2, what you would get wrong in month one: name what the dossier lists as absent, "I haven't set prioritization for an engineering squad" (`prohibited_claims`: "Having set prioritization for an engineering squad"), then the plan. Follow-up 3, how would I know this is not a project role with a new title: the roadmap-input sentence is medium confidence, confirmed with limited inspectable proof, so volunteer its limit, that it says input sessions and not what product decided, and point to the playbook as the artifact a prober can inspect. At every level, describe what you did and let them draw the inference | F1 and F2 are the objection's two halves: F1 is bridged with its limit, F2 is acknowledged with no bridge. JD because it scores R1 |
| B2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] `prohibited_claims`: "Having set prioritization for an engineering squad" | Name the roadmap and prioritization piece first, plainly: "I haven't set prioritization for an engineering squad." Then a ramp plan in the future tense: how you would learn the squads' decision process in the first weeks and who you would ask. No bridge on this one; the dossier found no credible evidence for it, and inventing one live is how a candidate gets caught | F2 is the acknowledge_gap area. JD because it asks you to rank the JD's own parts |
| B3 | "What has your agile delivery experience looked like?" | JD | [grounded] | Answer-shaped as a clarification, with nothing about your past asserted. Answer slot: agile delivery is the requirement's own wording, so expect a probe on how you worked. If you worked that way, say how, in your own words; if you never worked that way, say so plainly, then say what you would want to confirm about how Quartzline defines it | F6 is a clarify area: the evidence may exist and was not established. JD because it scores a stated preference |
| B4 | "Tell me about a time you had to align engineering, sales and a customer on something." | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Selection scaffold: pick a time with a named stake, a moment you did not fold, and an intact relationship at the end, and say which of engineering, sales and the customer was involved. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I ran quarterly roadmap-input sessions feeding client evidence to product", at that scope | F5's quote carries no alignment story, so this is the scaffold case. JD because stakeholder management is a stated requirement |
| B5 | "Why a product role, why this one, and why now?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Give your own reasons for each of the three; the pack supplies none. The one anchor from your material is what you did: "I led 30+ end-to-end client integrations of the vendor's REST APIs." For why this role, use only what the posting and the recruiter told you, because no research on Quartzline could be run for this pack. Rehearse it until it sounds consistent with B1 | The Skeptic scores motivation consistency; F1 is why the question is asked. JD because it tests fit to the listed job |

### C. Data-Driven Prober (weight medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You led 30+ integrations. Walk me through how that number was counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Keep the figure at "30+", not a rounder number. Answer slot: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours, each in your own words. Name the weakest assumption before they do. If you do not know how it was counted, say so plainly | A headline number is where a prober starts, and F1 and F3 both lean on it. EXP because it tests attribution and counting |
| C2 | "What did end-to-end cover? Where did your part start and stop?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The quoted sentence gives five beats: scoping, requirements, architecture, UAT, go-live. Tell them in your own words and add none. Answer slot: if any of the five sat with someone else, say which and how it was divided; if none did, say so plainly | "Led" is the sentence's verb, so the probe is where leading stopped. EXP because it tests what was actually yours |
| C3 | "Tell me about the playbook you wrote. What is in it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Say it at the quote's scope: "I wrote the internal integration playbook my team uses." The contents are not stated anywhere in your material, so describe them in your own words. The dossier marks this claim high confidence with the playbook inspectable, so offer to walk them through it | It is the one inspectable artifact behind F4, and a prober will ask to see it. EXP because it tests whether you know your own document |

### D. Conversational (weight medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc with three quoted beats: the integrations you led, the playbook you wrote, the roadmap-input sessions you ran. Close with your own sentence on why you want the product side. Keep each beat at its sentence and let the interviewer draw the inference | The biography question is where a title gap is framed first. EXP because it tests the story of your own career |
| D2 | "What are you playing with in the API space these days?" | JD | [generic] | Selection scaffold: pick something you are actually doing now, say what it is and what you learned from it. If nothing comes to mind, say so plainly, then say what you would explore first. The pack does not know your current projects and supplies none | A casual question about a hot JD topic is still scored. JD because it probes the technical-fluency requirement informally |
| D3 | "What do you know about us and where the partner API sits in the business?" | CO | [generic] | Research for this pack could not run, so the pack supplies no facts about Quartzline. Prepare this answer yourself from Quartzline's own public pages and the posting, and say only what you read there. If you did not find something, ask about it instead of guessing | Company homework is part of a hiring-manager conversation; `[generic]` because no research could be sent, which is the cost of that, noted in the upgrade menu. CO because it tests company knowledge |

### E. Pressure (weight low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a PM who has already done this job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; `prohibited_claims`: "Having held a product manager title or role" | Pause and restate. Hold the quoted position through two follow-ups: "I led 30+ end-to-end client integrations of the vendor's REST APIs, and I ran quarterly roadmap-input sessions feeding client evidence to product." Concede specifically rather than folding: "I haven't held a product manager title or role." Never claim the title or a roadmap to win the exchange | The time-boxed version of B1; JD because it still scores R1 |
| E2 | "That roadmap-input work — how much of it was actually you?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Hold on the sentence's own verb: "I ran quarterly roadmap-input sessions feeding client evidence to product." Volunteer the limit: it says the sessions and the input, not what product decided. Answer slot: if any of that input changed what product did, say what and which part was yours; if you never saw the outcome, or nothing changed, say so plainly and stay with the sessions | This sentence is medium confidence, confirmed with limited inspectable proof, so this is where a probe lands. EXP because it tests attribution |

### P. Peer Evaluator (weight low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "We have two squads, each with a lead. Where is the seam between a PM and a squad lead, and what happens when you and a lead disagree?" | CASE | [generic] | Propose seam principles instead of pretending to know Quartzline's seam: who owns the problem, who owns the solution, how a disagreement is escalated and resolved. Ask what the current seam is. No claim about your past | The dossier lists decision authority versus the two squad leads as an unknown. CASE because it is a live seam problem |
| P2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Selection scaffold: pick a time a result spanned teams, say what your own part was and what the other team's was, and how credit landed. If no such time comes to mind, say so plainly, then say how you would handle it. Use "we" for context and "I" for your contribution | A collegial probe for turf awareness. EXP because it tests attribution habits |

## Requirement coverage

| Requirement | Questions |
|---|---|
| R1 3+ years product management experience | B1, B2, B5, E1, E2, D1 |
| R2 Shipped API or platform products | A5, C1 |
| R3 Technical fluency: API docs, schemas | A4, C3, D2 |
| R4 Stakeholder management across engineering, sales, customers | B4, P1, P2 |
| R5 Agile delivery experience | B3 |

The company-and-strategy question D3 is `[generic]` and no values bank exists; both are explained in Sources.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The dossier lists decision authority as asserted but not evidenced. It reads as diligence and tells you what the job actually is before you accept |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | The dossier names the baseline as missing. The answer tells you whether the responsibility to define and track adoption starts from something or from nothing |
| 3 | "How do the two squads run delivery today, and how would you want a new PM to plug into it?" | It lets the interviewer define agile delivery for you (F6) instead of you guessing at it, and shows interest in the team's actual rhythm |
| 4 | "Where does client and partner integration feedback enter the roadmap today, and who owns turning it into backlog?" | It speaks from the vantage your quoted sentences share (feeding client evidence to product) without claiming more |
| 5 | "If you hired a PM from an adjacent background, what would make the first quarter a success or a miss in your eyes?" | It turns the B1 objection into a shared plan and tells you what ramp the manager would expect |

## Prohibited claims

Built from the dossier's `prohibited_claims`, its `acknowledge_gap` area and the pack's own fit snapshot, before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | `prohibited_claims` | The quote at its own scope: "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live", and the plain acknowledgment: "I haven't held a product manager title or role." |
| Having owned a product roadmap | `prohibited_claims`, and the dossier's `acknowledge_gap` area for owning a roadmap and prioritization authority | The quote at its own scope: "Ran quarterly roadmap-input sessions feeding client evidence to product", with the pack's observation that the sentence says input sessions, not roadmap decisions, and the plain acknowledgment: "I haven't owned a product roadmap." No slot, no bridge |
| Having set prioritization for an engineering squad | `prohibited_claims`, and the same `acknowledge_gap` area | The plain acknowledgment: "I haven't set prioritization for an engineering squad." Then a plan, never a past. No slot |
| Shipped an API or platform product | Inflated form of F3 | The quote at its own scope; the pack's observation is that your material says integrations of the vendor's REST APIs, not shipping them. A5's slot stays inside that |
| Wrote API docs or schemas | Inflated form of F4 | The playbook quote at its own scope: "Wrote the internal integration playbook her team uses". A4's slot asks only whether you worked from or wrote API docs or schemas, in your own words |

## Sources

Provided documents: `tuesday-dossier.md` pasted in the conversation, envelope version 1.1. Consumed sections: `role_profile` (requirements and responsibilities, unknowns as analysis only), `handoff_to_mock_interview` (verified evidence, weak areas and strategies, the named objection, risks and employer questions, prohibited claims) and `decision` as context only. The named objection in B1 comes from the dossier. The pack's persona weights rest on your stated round and the hiring-manager relationship prior, not on a documented Quartzline loop.

Searches sent, all refused by the host, none returning a result:

- "Quartzline company values" — refused
- "Quartzline interview process product manager" — refused
- "Quartzline partner API platform strategy news" — refused

No fetches were sent.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Would have fed a values cheat sheet and VAL themes; nothing in this pack comes from it |
| 2. `Quartzline interview process product manager` | unavailable | Would have named the loop and decided whether a values round exists; persona weights fall back to your own words and the relationship prior |
| 3. `Quartzline strategy` / recent news | unavailable | Would have grounded D3 and the CASE questions in Quartzline's current priorities; they are `[generic]` instead |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's `role_profile` already fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Search access for Quartzline → values, loop structure and strategy come from sources instead of nothing, D3 and the CASE bank become `[grounded]` rows, and a values cheat sheet appears if a values round exists. A deeper pass would add up to 6 further searches and 2 further fetches and take several more minutes
- The hiring manager's name → an interviewer read from their public professional footprint, reweighted personas and a reverse question tied to their own path
- The recruiter's prep note or process email → focus areas and any pre-declared deliverable, which would get its own build section
- Your own answers on whether you shipped an API or platform product, worked from or wrote API docs or schemas, worked directly with engineering and sales, and worked in an agile delivery process → F3, F4, F5 and F6 firm up and A4, A5, B3 and B4 become story-mapped instead of slots or scaffolds
- An inspectable artifact behind the roadmap-input sessions, such as a session agenda or a readout sent to product → F5's medium confidence can rise and E2's probe gets stronger ground
