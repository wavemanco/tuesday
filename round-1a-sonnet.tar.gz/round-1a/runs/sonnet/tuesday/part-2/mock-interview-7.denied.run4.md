The web searches were refused, so I'm building the pack from your JD and background alone. I'll mark everything about Saltmarsh and Tobias as unresearched.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a/runs/sonnet/tuesday/part-2/rooms/case-7-denied-aefbc9bb/saltmarsh-games_live-operations-producer_interview_pack.md`. I built it for a hiring-manager round, since your note doesn't say how Tobias relates to the role.

Web search was refused in this session, so none of the four searches ran. That means nothing about Saltmarsh's values, strategy or hiring process, or about Tobias beyond his title, is in the pack, and the Sources table marks those four rows unavailable. The 20 questions come from your JD and background alone. There are no company-strategy questions, and the case questions are generic.

The prep I'd put first is A1, "I see you haven't worked on a game with in-app purchases. What does that mean for how you would handle the KPIs this role reports?" It rests on the gap you named, and the pack coaches a plain acknowledgment followed by a plan, not a claim.

There is a Tuesday–Thursday prep schedule and a coverage table that maps each JD requirement to the questions that cover it.

Say the word and I'll play the Skeptic on A1 so you can hear how it lands out loud.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the person this role would report to, or more senior or cross-functional, and did the recruiter name any focus areas or ask for a presentation or take-home? Either answer reweights the banks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

- **Role:** Live Operations Producer, Saltmarsh Games (mobile game studio)
- **Candidate:** Femi
- **Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed: hiring manager, because the material does not say. Format: one 60-minute interview, on Friday.
- **Research status:** web search was refused in this session, so nothing here about Saltmarsh's values, strategy or hiring process, or about Tobias beyond his title, comes from research. Rows that would have used it say so.

## How to use this pack

Personas describe how a question arrives: who is asking and in what style. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Whether past behavior shows the company's published values. Not used here: no published values were in hand |
| EXP | Whether the claims on your CV survive scrutiny: what you actually did |
| JD | A stated responsibility or qualification in the posting, including its gaps |
| CO | Company and strategy knowledge. Not used here: research was refused |
| CASE | A live problem set in the role, answered on the spot |

Answer slots are instructions for the interview, not questions for you now. Each has two honest branches, and "that was not mine" or "there was no such step" is a complete answer.

## Prep triage

You have Tuesday, Wednesday and Thursday. Do these in order.

1. Tuesday: A1 first, aloud, until the plain acknowledgment and the plan sound boring. Then A2 and A3.
2. Wednesday: C3 and C1 (your calendar and your retention numbers), then the D1 arc, timed to 90 seconds.
3. Thursday: one case aloud (B1, B3 or B5), then E2, then pick three reverse questions.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says one main title and weekly content drops, with nothing inspected behind it, and the words stay there: "For the last two years I ran the weekly content-drop calendar for our main title." The JD says live events, two titles, and planning; the quote carries none of the three. Answer slot: the JD's "plan" makes a probe on how the calendar was set likely. If you decided what went into each drop, say how you decided; if it was set elsewhere, or you only ran it, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show which teams you worked with. Answer slot: the JD names four teams, so expect a probe on who you worked with on a drop. If you worked with any of design, art, engineering or community, say which and what you did, in your own words; if none, or it was not yours, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | discovery | The words stay at "I presented the monthly retention numbers to the studio head." Your material does not show whether those numbers were read against particular drops or events, or whether any review followed. Answer slot: if a review followed a drop, say what it covered and what part was yours; if none did, or it was not yours, say so plainly and stay with presenting the numbers |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | Lead with the quote's own terms: "I wrote the release checklist, and our QA team still uses it." The JD says manage and the quote says wrote, so do not say manage. A written checklist in current use is something a probe can ask to see, with nothing inspected behind it yet |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | medium | [grounded] | discovery | The words: "For four years I was an associate producer at a puzzle-game studio." Your material gives the years and the studio type and does not say whether the game was live-service. Answer slot: if the game was a live-service title, say how it ran in your own words; if it was not, say so plainly and stay with the four years |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it, so expect a probe. Lead with it in its own terms: weekly, your main title, two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap, but expect a probe on how the numbers were counted; C1 rehearses it. Lead with presenting them monthly to the studio head, in the quote's own terms |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | The checklist is the one written thing your material names, and the quote does not show who read it beyond QA. Derived from: a checklist being a written document. Answer slot: if you have written material you could show, such as an update, a plan or a review, say what it was; if there is none you can share, say so plainly and stay with the checklist |
| F9 | Leading a team: a role-family expectation, not a JD line; the JD asks only that you coordinate teams | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't led a team." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F10 | Familiarity with in-app purchases on mobile titles: not a JD line, carried because it is the gap you named | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then what you would learn first and from whom, said as a plan and never as a past |

## Persona table

Assumption: Tobias is the hiring manager. The weights rest on the relationship prior for a hiring-manager round, adjusted by one loop fact from your own words (a single 60-minute session with him). They are not adjusted for anything about Tobias, because search was refused and his title is the only signal.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet, persistent probing of the stated gaps and thin rows | High. The hiring-manager prior puts Skeptic first, and you named two gaps (F9, F10) and the snapshot has three discovery rows | Rehearse the single most predictable objection until it is boring; bridge only from what you said; plain acknowledgment plus a plan |
| B. Case / Strategist | Live problems from the role: plan, diagnose, decide | High. The hiring-manager prior puts Case first, and the JD is a list of live tasks | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| C. Data-Driven Prober | Reads your lines one by one and asks how numbers were counted | Medium. F7 and F3 are your only metric lines, and the JD asks for comfort with retention metrics | Say what you know and do not know about how the numbers were counted; name the assumption you would defend least |
| D. Conversational | Friendly openers such as the walk-through of your journey | Medium. A 60-minute session usually opens this way, but nothing in the material says it will | Prepare a 90-second arc built from your own sentences; treat casual questions as scored |
| E. Pressure | Time-boxed challenges to attribution and motive | Low. Nothing in the material signals a stress style | Pause, restate, hold through two follow-ups, concede only what your sentences concede |
| F. Values / Behavioral | Scenario probes on cross-team friction and hard conversations | Low. No values-style round is documented and no published values are in hand, so these questions theme on the JD's team-coordination line and carry no VAL tag | Pick a story only where one of your sentences carries it; otherwise use the scaffold and its honest branch |

The Peer Evaluator is omitted: nothing says Tobias is a peer. If he is skip-level or cross-functional, say so and the banks reweight.

## Question banks

Ordered by weight. The highest-ROI prep in the pack is A1.

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "I see you haven't worked on a game with in-app purchases. What does that mean for how you would handle the KPIs this role reports?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." and "Presented the monthly retention numbers to the studio head." | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment: "I haven't worked on a game with in-app purchases." Stay with what your material carries: "I presented the monthly retention numbers to the studio head." Then give a plan, said as a plan and never as a past: what you would ask to see in the first weeks and who you would ask, in your own words. Follow-up one asks which measures you know from outside your own work; name only what you truly know, and if you know none, say so plainly. Follow-up two asks who gets you up to speed; name the people or sources you would use. Concession wording: "That is the biggest gap I would carry on day one, and this is how I would close it." Never describe work on purchases as something you did | F10 is the gap you stated and F3 is the requirement it presses on, so this objection arrives in some form; JD because it scores the KPI line |
| A2 | "You haven't led a team, and this role coordinates four disciplines on every update. Where does coordinating end and leading begin for you?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." and "I ran the weekly content-drop calendar for our main title for the last two years." | Open with the plain acknowledgment: "I haven't led a team." Then the calendar in its own words: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD names design, art, engineering and community, so expect a probe on who you worked with on a drop. If you worked with any of them, say which and what you did; if none, or it was not yours, say so plainly and stay with the calendar. Hold through two follow-ups by returning to what you ran, never by adding to it | F9 is the stated gap and F2 the requirement it presses on; JD because it scores the coordination line |
| A3 | "You ran the content-drop calendar for your main title. This role covers two titles at once. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Say it at its own scope: "For the last two years I ran the weekly content-drop calendar for our main title." Your material shows one title, so the second title is a plan, not a past. Answer slot: if you ran or touched any second title's schedule, say what and how much was yours; if not, say so plainly. Then give your own plan for adding a title, in your own words | F1 is where the JD's two-title mandate presses hardest; JD because it scores the stated requirement |
| A4 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Selection scaffold: choose a requirement where your material is thinnest and name it plainly. Two are already yours to name: "I haven't led a team" and "I haven't worked on a game with in-app purchases". Pair the one you choose with a plan. If no other gap comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Do not name a gap you have not stated unless it is true | F9, F10 and the discovery rows F2 and F5 are the candidates; JD because it asks you to score yourself against the posting |
| A5 | "What is drawing you to Saltmarsh and to live operations?" | EXP | [generic] | Your material carries no reason, so the words must be yours. Give your own reason plainly. Tie it to one line of the JD that you actually want to do, quoted from the posting. Do not borrow reasons from the posting's tone | Motivation consistency is what the Skeptic scores; EXP because it tests whether your story holds, `[generic]` because no sentence of yours carries a reason |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Imagine a live event ends and day-7 retention for the players who joined it is 20 percent below the title's usual. Walk me through your diagnosis." | CASE | [generic] | Clarify first: what the baseline is, which cohort, what changed around the event. Then the objective, how you would segment, the approach, the metrics and the risks. Think aloud and challenge one premise, such as whether the cohort is comparable. The question needs no claim about your past, so the guidance makes none | A live problem from the JD's retention line, F7's requirement; `[generic]` because it is a pattern, not a fact about this employer |
| B2 | "Imagine two titles each want a big event the same weekend and only one team can support both. How do you decide?" | CASE | [generic] | Ask what is fixed and what can move. Name your criteria and who decides. Say the trade-off aloud, then say how you would tell each side. The guidance makes no claim about your past | A hypothetical from the JD's two-title and coordination lines, F1 and F2 |
| B3 | "A build fails QA the day before an update ships. Walk me through your next two hours." | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Structure it: what you would ask QA first, what you would tell the other teams and when, and the decision you would put to Tobias. You may mention the checklist you wrote, in the quote's words. Answer slot: if the checklist covers a failing build, say how; if it does not, say so plainly and answer from your own plan | JD's release-checklist line, F4; CASE because it is a live problem |
| B4 | "Sketch the plan for the next four weeks of events on a title with flat retention. What do you need to know first?" | CASE | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Start with the questions you would ask, then objective, segments, approach, metrics, risks. You may say you have run a weekly calendar, in the quote's words. Do not claim an event you did not run | F1 and F6; a persona stem applied to the role |
| B5 | "After an event ends, what would your review contain and which KPIs would you report?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Describe the review you would run and choose the few KPIs you would report, with a reason for each, in your own words. Answer slot: if the numbers you presented were ever read against a specific drop, say what that showed; if not, say so plainly and stay with presenting them. Do not list a purchase metric as something you reported | The JD's review-and-KPI line, F3, asked as a design question |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the retention numbers you presented each month were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slots, in your own words: which retention measure it was and how it was counted; what it is sensitive to; the assumption behind it you would defend least; and which part of the work was yours. If you do not know how something was counted, say so plainly. Name the weakest assumption before he does | F7 and F3 are your only metric lines, so a prober goes here; EXP because it tests attribution |
| C2 | "Which retention metrics are you most comfortable with, and which least?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Name them from your own knowledge. If some you have only seen and not worked with, say so plainly. Start from presenting them monthly | The JD says comfortable, which is F7's requirement; JD because it scores it |
| C3 | "Walk me through how you ran the weekly content-drop calendar." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | The beats the quote states: weekly, your main title, two years. Answer slot: the JD says plan, so expect a probe on how drops were chosen. If you decided what went in each drop, say how; if it was set elsewhere, or you only ran it, say so plainly and describe how you ran it | F6 is the line a prober reads first; F1 is where it is thin |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." and "I ran the weekly content-drop calendar for our main title for the last two years." and "Wrote the release checklist our QA team still uses." and "Presented the monthly retention numbers to the studio head." | A 90-second arc built only from these four sentences, in your own words and order. Answer slot: if the game was a live-service title, say how it ran; if it was not, say so plainly. End on why this role, which is yours to say | The biography question is scored even when friendly; F5 is the row whose gap this answer can close |
| D2 | "Tell me about a game whose live events you think are done well." | JD | [generic] | Selection scaffold: pick a game you actually follow, say what it did and what you would copy. If none comes to mind, say so plainly, then say what you would look for in a live event. Do not claim to know how a studio ran its events internally | A casual question on the JD's live-events topic, which is scored all the same |
| D3 | "How do you like to keep teams in the loop on an update?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Describe your own way. You may mention the checklist, in the quote's words. Answer slot: if you have a written update you could show, say what it was; if there is none, say so plainly | The JD's written-communication line, F8 |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a producer who has run live events on a title with in-app purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." and "Never led a team, and never worked on a game with in-app purchases." | Pause and restate. Hold only what the first quote carries: "I ran the weekly content-drop calendar for our main title for the last two years." Concede what the second quote concedes: "I haven't worked on a game with in-app purchases." Hold through two follow-ups; do not claim an edge you cannot back | F6 is the strength to hold and F10 the concession; JD because it tests fit against the posting |
| E2 | "You presented the monthly retention numbers. How much of the analysis behind them was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if you did any of the analysis, say which part and how; if someone else did it or you only presented the numbers, say so plainly and stay with presenting them. Hold through two follow-ups by returning to what you presented | F7 and F3 both rest on this sentence; EXP because the question tests attribution |

### F. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time design and engineering wanted different things from the same update." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Selection scaffold: pick an update where two disciplines pulled apart. It needs a named stake, what you did, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is running the weekly calendar, or how you would handle it | The JD's coordination line, F2; EXP because it tests what you did |
| F2 | "Tell me about a time you delivered an unpopular truth to leadership." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Selection scaffold: pick a time the news was unwelcome, name the stake, and say what happened to the relationship. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is presenting the monthly numbers to the studio head, or how you would handle it | A persona stem; the studio head in your sentence is the only leadership audience your material names |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A3, B2, B4, C3 |
| "coordinate design, art, engineering and community teams on each update" | A2, B2, D3, F1 |
| "own the post-event review and the KPIs it reports" | A1, B1, B5, C1 |
| "manage the release checklist with QA" | B3 |
| "3+ years producing live-service games or apps" | D1, E1 |
| "experience running a content calendar" | A3, B4, C3 |
| "comfortable with player-retention metrics" | B1, C1, C2 |
| "clear written communication" | D3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good first 90 days look like for this producer across the two titles?" | It shows you think in ramps, and it makes Tobias say what he expects of two titles at once |
| R2 | "Which KPIs does the post-event review report today, and which would you want this role to change?" | The JD says KPIs without listing them; this puts the list on the table on your terms |
| R3 | "How do design, art, engineering and community hand work to each other on an update today, and where does it catch?" | It follows the JD's coordination line and tells you where the job is hard |
| R4 | "How does QA work with the producer on the release checklist today: who owns it, and who changes it?" | It is the one JD item you have a document for, so the conversation starts on your ground |
| R5 | "I haven't worked on a game with in-app purchases. What would you want me to learn first?" | It turns your named gap into a plan conversation; use it only if A1 did not already cover it |
| R6 | "Is the live-events calendar one shared plan across the two titles, or one per title?" | It answers the question A3 raises before you have to |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Planned and ran the live-events calendar for two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says the main title's weekly content drops, not live events and not a second title. A3's slot stays inside what you ran |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope. The material says presenting the monthly retention numbers, not owning a review |
| Managed the release checklist and releases with QA | Inflated form of F4 | F4's quote at its own scope: you wrote the checklist and QA still uses it |
| Produced a live-service game | Inflated form of F5 | F5's quote at its own scope: an associate producer at a puzzle-game studio for four years. D1's slot asks only whether the game was live-service |
| Drove retention improvements | Inflated form of F7 | F7's quote at its own scope: you presented the monthly numbers |
| Led a team | Negative you stated, F9 | The plain acknowledgment F9 gives: "I haven't led a team." No slot |
| Worked on a game with in-app purchases | Negative you stated, F10 | The plain acknowledgment F10 gives: "I haven't worked on a game with in-app purchases." No slot |

## Sources

Provided documents: the JD pasted in your message, and the background in your message. No `tuesday-dossier.md` was present.

Searches sent, each refused:

- "Saltmarsh Games values": refused
- "Saltmarsh Games interview process live operations producer": refused
- "Saltmarsh Games mobile studio strategy news": refused
- "Tobias Wrenfield Saltmarsh Games": refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Every call was refused. It would have fed a values cheat sheet, which also needs a values-style round the material does not document, so no section 10 appears |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | Every call was refused. It would have named the rounds and moved persona weights; the weights rest on the one session you described |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | Every call was refused. It would have grounded CO and CASE questions in current priorities; the CASE bank is `[generic]` instead and there are no CO questions |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Every call was refused. It would have produced the interviewer read, persona adjustments and a reverse question tied to his path |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Search access, or pasted pages → the Saltmarsh values page, any strategy brief and anything Tobias has published would give a values cheat sheet if a values round exists, CO questions, an interviewer read with persona adjustments, and a reverse question tied to his path
- A deeper research pass (L2) once search is allowed, up to 6 more searches and 2 more fetches, several more minutes → a strategy brief and recent-organization context for the CO and CASE banks
- Whether Tobias is your direct manager or more senior, and anything the recruiter named (focus areas, a presentation or take-home) → persona weights recomputed, and a build section for any pre-declared deliverable
- Your answers to the slots on F1, F2, F3 and F5 (how drops were chosen, which teams you worked with, whether any review followed a drop, whether the game was live-service) → those rows move from discovery toward grounded and the matching guidance becomes story-mapped
- The release checklist itself, a calendar page or a retention report you can show → F4, F6 and F7 can move from `medium` toward `high`, and F8's written-communication row gets a real sample
- A `tuesday-dossier.md` → verified evidence and absolute prohibited-claims lists would replace the ones this pack built locally
