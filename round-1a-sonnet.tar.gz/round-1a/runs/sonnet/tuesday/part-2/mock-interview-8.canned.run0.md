Your prep pack is built and saved. The next step is for you to read it. I made it a loop-mode pack because your three rounds on 26 November are already scheduled. Each round has its own mini-pack, and there is a shared fit snapshot before them.

I used only what you pasted: the JD, the values, the recruiter's email and the strategy brief. I ran no web searches because those four items already answered what a search would have. The pack's Sources section lists this.

Three things in it:
- **The highest-ROI prep is question D1 in round 2.** Your manager-to-be is likely to ask how you would own the contact-centre half of the role, given that you have never worked in one. The pack gives you a plain acknowledgment, the adjacent evidence at its true scope, and a concession for the third follow-up.
- **Your stated gaps are handled as gaps.** The contact centre and presenting above regional level get honest wording and a plan, not a bridge.
- **Some JD requirements your material doesn't settle.** Whether your complaints were regulated, what your spreadsheet counted, whether it was Excel, and any digital-team work get answer slots. Each slot has an honest branch for "that wasn't mine" or "that didn't exist".

File: `/var/tmp/tuesday-measure/1a/runs/sonnet/tuesday/part-2/rooms/case-8-canned-32c1c8f0/ashgrove-credit-union_member-experience-lead_interview_pack.md`

Say the word and I'll play the Skeptic on D1, pushing back on what you actually said.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Loop mode: three scheduled rounds on 26 November 2026 (pack built 17 November 2026).

| Round | Format (recruiter's email) | Interviewer, by role only |
|---|---|---|
| 1 | 30 minutes | The recruiter |
| 2 | 45 minutes, mostly behavioural | The Head of Member Services, who would be your manager |
| 3 | 60 minutes, including a 20-minute case on a complaint escalation; the panel is also the values round and scores against the four values | A panel of two branch managers |

Names for rounds 2 and 3 are not yet assigned, so there is no interviewer read. The highest-ROI prep in this pack is question D1 (round 2): owning the contact-centre half of the role when you have said you have not worked in one.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you did.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows Ashgrove's published values |
| EXP | Whether your own experience holds up under questions about what was actually you |
| JD | The listed requirements of the role, gaps included |
| CO | Whether you can think at the credit union's level: strategy, competition, recent moves |
| CASE | A live problem from the role, scored on structure and reasoning |

Three marks you will see in guidance cells. An answer slot is an instruction for the interview, not a question for you now: it names what an interviewer is likely to probe and gives two honest branches. A selection scaffold is what to look for in a story where none of your sentences carries one. Provenance labels: `[grounded]` traces to something you or the employer supplied, `[inferred]` is derived from it, `[generic]` is a pattern for the problem with no claim about Ashgrove or you.

## Fit snapshot (shared across all three rounds)

Requirements are quoted from the JD you pasted. Evidence cells hold only your own sentences, from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says your branch's log, not a process across branches, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on where your involvement with a complaint began and ended likely. Say where, in your own words; if the log was the extent of it, or the rest was not yours, say so plainly and stay with the log |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your sentence says you built the monthly spreadsheet and that your regional manager uses it; it does not say what it counted. Answer slot: the JD names volumes and resolution times, so expect a probe on what yours held. Say what it counted, in your own words; if resolution times were not one of the measures, say so plainly and stay with what the spreadsheet did hold |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your sentence says tellers and a script, not supervisors: you "trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on supervisors likely. If any of that training or guidance reached supervisors, say what and how, in your own words; if none did, or it was not yours, say so plainly and stay with the tellers |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent on this, so the pack writes no words for it. Answer slot: the JD names digital teams and self-service journeys, so expect a probe. If you worked with a digital team on anything, say what and what part was yours, in your own words; if you did not, say so plainly, and say what you would want to learn first about how members use the self-service channels |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap on length. Lead with the sentence's own terms: six years in retail banking, the last three as a branch supervisor. Expect a probe on how branch work maps to "customer operations"; the contact-centre side of that is F2 |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | Your sentence says a formal complaints log; it does not say whether those complaints fell under external rules or timeframes. Answer slot: the JD names regulated complaints, so expect a probe on which rules applied. Say what you know, in your own words; if the log was internal, or the rules side was not yours, say so plainly and stay with "handled the branch's formal complaints log" |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't presented above regional level." Then how you would prepare a first senior presentation, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your sentence says spreadsheet, not Excel. Answer slot: the JD names Excel, so expect a probe on the tool. Say which tool and what you did in it, in your own words; if it was not Excel, say so plainly and stay with "built the monthly complaints spreadsheet our regional manager uses" |

## Grounding brief (shared)

Your recruiter sent the 2026 strategy brief; these rows are your summary of it plus the JD. The brief is about four months old and is shared with every other candidate, so bring one item to show you read it and then your own view.

| Fact | Source | Provenance | Where it shows up |
|---|---|---|---|
| Move 40% of member service to digital channels by 2028 | 2026 strategy brief (July 2026), as you gave it | [grounded] | F1, I1 reasoning, I3 |
| Consolidate eight branches into five hubs over 2027 | 2026 strategy brief, as you gave it | [grounded] | G5, I2 |
| Launch a small-business lending product in Q1 2027 | 2026 strategy brief, as you gave it | [grounded] | I4 |
| Main competitive pressure is app-only banks | 2026 strategy brief, as you gave it | [grounded] | F2 |
| Member-owned, about 900 staff | The JD you pasted | [grounded] | G5 |

## Sources and research accounting (shared)

Provided documents: the JD; the four values as copied from ashgrovecu.org/about/values on 17 November 2026; the recruiter's email on the three rounds; your summary of the July 2026 strategy brief; your background as you stated it. No `tuesday-dossier.md` was present. No searches or fetches were sent: the values page and the strategy brief were supplied in full, and the recruiter's email establishes the loop. The page URL names only where your pasted text came from, so it was not fetched.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | Could not have moved the values cheat sheet: the four values are pasted, by name and definition |
| 2. `Ashgrove Credit Union interview process member services` | skipped | Could not have moved the loop or persona weights: the recruiter's email gives the three rounds, who runs each and what each holds |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | Could not have moved the CO and CASE banks: the July 2026 brief you supplied gives current priorities and the competitive frame |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No interviewer name was given, so there was no query to form; the interviewer read is absent and the upgrade menu says what names would unlock |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

# Round 1 mini-pack: recruiter screen (30 minutes)

## Persona weights, round 1

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational (A) | Friendly opener, then logistics and motivation in a casual register | High. The recruiter row's prior is Conversational plus a light Skeptic, and the email says this is 30 minutes with the recruiter. Casual questions here are still scored | A pre-scripted 90-second arc for the biography question; treat the casual questions as scored |
| Skeptic, light (B) | Quiet knockout checks against the JD: the contact centre, regulated complaints, years | Medium. The JD's first sentence names the contact centre and a recruiter checks requirements before passing you on | Say the plain acknowledgment first, then the adjacent fact at its own scope, then stop; the deep rehearsal sits in round 2 |

## Question bank, round 1

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F6, F1 and F3, with the beats the quotes state: six years in retail banking, the last three as a branch supervisor; handled the branch's formal complaints log and trained new tellers on the escalation script; built the monthly complaints spreadsheet the regional manager uses. Tell them in your own words in about 90 seconds, then stop. Answer slot: the closing beat is why this role. Say in your own words what draws you to owning complaints; if no reason comes clearly, say so plainly and stay with the three beats | The recruiter's opening question is the one every candidate gets and the one that sets the frame; EXP because it tests what you can say about your own path |
| A2 | "Why Ashgrove, and why now?" | CO | [grounded] | Makes no claim about your past. Choose one of the four published values (Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix) that you can speak to in a sentence of your own, and at most one item from the strategy brief to show you read it. Answer slot: if no value connects, say so plainly and say what you want to learn about the credit union | Recruiter screens test motivation consistency; CO because the answer is judged on how well it fits Ashgrove specifically |
| A3 | "What are your salary expectations?" | JD | [generic] | Logistics slot: give your own number or range, or ask for the role's band first, and say which you are doing. Supply no figure that is not yours | Pay is a recruiter-screen staple; JD because it concerns the listed job's terms. The pack never supplies a figure |
| A4 | "What is your notice period?" | JD | [generic] | Logistics slot: give your actual notice period in your own words, and any flexibility only if it is real | A knockout check on start date; JD because it concerns the job's terms |
| A5 | "Where and how can you work for this role?" | JD | [generic] | Logistics slot: say in your own words where and how often you can work at branches, hubs and the contact centre, and any constraint that is real | The role spans branches and the contact centre, so location and travel are asked early; JD because it concerns the job's terms |
| A6 | "What is behind your move, and why leave your current role?" | EXP | [generic] | Logistics slot: give your own reason, framed around what you are moving toward, and give only a reason that is true. Do not criticise your current employer | The reason for leaving is a standard recruiter check for consistency; EXP because it is about your own history and choices |
| B1 | "The role covers the contact centre as well as branches, and you've said you haven't worked in one. How do you see that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Words: "I haven't worked in a contact centre." Then F1's quote at its own scope, "handled the branch's formal complaints log", and one sentence of plan in your own words. Keep it to about 30 seconds; the deep rehearsal is D1 | F2 is the gap named in the JD's first sentence and the likeliest knockout question; JD because it scores the stated requirement |
| B2 | "The role needs experience handling regulated complaints. What does that look like in your background?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F7: you handled the branch's formal complaints log. Answer slot: the JD's regulated-complaints line makes a probe on which rules and timeframes applied likely. Say what you know, in your own words; if the log was internal, or the rules side was not yours, say so plainly and stay with the log | F7 is the requirement your sentence touches but does not show; JD because it scores a named requirement |
| B3 | "You have six years in retail banking. How does that map to customer operations here?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Say it in the sentence's own terms: six years in retail banking, the last three as a branch supervisor. Do not widen it to contact-centre or operations work the sentence does not carry; F2 covers that edge | F6 is the years-and-sector requirement; JD because the recruiter is checking it against the JD |

## Reverse questions, round 1

| # | Question | Why it lands |
|---|---|---|
| R1-1 | "What happens after round 3, and who makes the decision?" | Shows you are planning the process, and the answer calibrates how much weight rounds 2 and 3 carry |
| R1-2 | "Which part of this role is most urgent for the first quarter?" | Tells you what the Head of Member Services will probe in round 2 |
| R1-3 | "Is the role based at a branch, a hub or the contact centre, and how much time at the others?" | Closes the logistics gap from A5 and tells you where the contact-centre exposure would come from |

---

# Round 2 mini-pack: Head of Member Services, your would-be manager (45 minutes, mostly behavioural)

## Persona weights, round 2

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral (C) | "Tell me about a time" questions, STAR-shaped, mapped to the published values | High, and raised above the hiring-manager prior. The prior for a hiring manager is Case plus Skeptic, but the recruiter's email says this round is mostly behavioural | Map one story to each value where your sentences carry one; use "we" for context and "I" for contribution; where none carries one, say so plainly |
| Skeptic (D) | Persistent probing of the gaps: the contact centre, presenting upward, coaching supervisors | High. A manager is deciding whether to take on a risk, and F2 and F8 are gaps you have stated | Rehearse the contact-centre objection until it is boring; adjacent evidence at its own scope plus a ramp plan |
| Data-Driven Prober (E) | Line-by-line questions on the spreadsheet you built | Medium. The JD asks for monthly reporting on volumes and resolution times, and your spreadsheet is the nearest evidence | Know what you can and cannot say about how each measure was counted, and say plainly when you do not know |
| Case/Strategist, light (F) | A short live problem from the strategy brief | Low to medium. The recruiter's note says mostly behavioural, so cases are held back for round 3, but the digital goal is the brief's headline | Clarify, objective, segmentation, approach, metrics, risks; challenge one premise respectfully |

## Question bank, round 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold, since your material carries no such story: pick a time you told someone senior something they did not want to hear. It needs a named stake, what you actually said, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioural probe from the Values/Behavioral stems; VAL because it tests behaviour under the Members First and Own the Fix themes, though no row carries the story |
| C2 | "Tell me about a time something had to be explained to a member twice." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F4: the beat the sentence carries is training new tellers on the escalation script. Answer slot: the Plain Words value makes a probe on wording likely. If any wording of the script, or of what members were told, was changed after someone needed it explained twice, say what and what part was yours, in your own words; if nothing was changed, or it was not yours to change, say so plainly and stay with the training | Plain Words is a published value, and F4's sentence is the nearest thing your material carries to it; VAL because it asks for a specific decision, not a slogan |
| C3 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F1: you handled the branch's formal complaints log. Answer slot: Own the Fix asks who kept hold until it was solved. If a complaint you logged was one you kept hold of until it was resolved, pick one and say what you did and what was yours, in your own words; if complaints passed to others once logged, or following through was not yours, say so plainly and stay with the log | Own the Fix is a published value, and the complaints log is where it would show; VAL because it tests whether the behaviour, not the phrase, is there |
| C4 | "When did you put a member ahead of an internal target or process?" | VAL | [generic] | Selection scaffold, since your material carries no such story: pick a time a member's situation and a rule or target pulled apart. It needs the member, what the rule said, what you chose and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The customer-ahead-of-metric stem maps to Members First; VAL because it tests behaviour against the published value |
| D1 | "The role owns complaints end to end across branches and the contact centre, and you've said you haven't worked in a contact centre. How would you own that half?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The highest-ROI rehearsal in this pack. Level 1: "I haven't worked in a contact centre. I handled the branch's formal complaints log." Level 2, the follow-up on your first month: your plan, in your own words, about what you would ask to see first, such as how complaints arrive and are recorded there and how they pass to and from branches, before changing anything. Level 3, "so you would be learning on the job": concede it plainly, "Yes, I haven't worked in one, and I would start by learning how it works from the people who do." The limit, named before it is asked for: do not claim call-handling, queue, tooling or contact-centre colleagues, which your material does not carry. Answer slot: if any complaints in your branch came from or went to a contact centre, say what you saw and what was yours, in your own words; if there was no such contact, say so plainly. Hold through two follow-ups by returning to the log, never by adding to it | F2 is the gap the JD names in its first sentence, so this objection arrives in some form from the person who would manage you; JD because it scores the stated requirement |
| D2 | "You'd present the monthly complaints report to senior leaders. You haven't presented above regional level, so what is your plan?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I built the monthly complaints spreadsheet our regional manager uses." | Words: "I haven't presented above regional level." Then F3's quote at its own scope: you "built the monthly complaints spreadsheet our regional manager uses." Plan, in your own words and said as a plan: ask what format and length senior leaders prefer, rehearse the first presentation with your manager, and lead with the decision you need. Answer slot: if anything you built reached anyone above your regional manager, say what and how, in your own words; if nothing did, say so plainly | F8 is a stated gap in a requirement that the JD makes explicit; JD because it scores the listed requirement |
| D3 | "You trained new tellers. Coaching branch supervisors on escalations is a different relationship, so how would you approach it?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say what the sentence carries: you "trained new tellers on our escalation script." Plan, in your own words and as a plan: start by finding out how supervisors currently handle escalations and what they find hard, before offering the script. Answer slot: if any of that training or guidance reached supervisors, say what and how, in your own words; if none did, or it was not yours, say so plainly and stay with the tellers | F4 is the adjacent-evidence row: tellers stand where the JD says supervisors; JD because it scores a named responsibility |
| E1 | "Walk me through the monthly complaints spreadsheet you built. What did it count?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F3 and F9: the beats the sentence states are that you built it, that it is monthly and about complaints, and that your regional manager uses it. Answer slot: the JD names volumes and resolution times, so expect a probe on what it counted. Say what each measure held, in your own words; if resolution times were not one of them, say so plainly. A second slot on the tool: say which tool it was and what you did in it; if it was not Excel, say so plainly | F3 and F9 both rest on this one sentence, so a prober reads it line by line; EXP because it tests what was actually yours |
| E2 | "Which measure in that spreadsheet would you trust least, and why?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | The weakest-assumption move, in your own words: name the measure whose counting you would defend least before the interviewer does. Answer slot: say how it was counted, what it is sensitive to and which part was yours; if you do not know how a figure was counted, say so plainly. The pack names no measure and no method | Probers convert a number into a credibility test; EXP because it tests attribution and honesty about the figure's limits |
| F1 | "The brief sets a goal of moving 40% of member service to digital channels by 2028. How should a complaint work in a digital journey, and what do you need to know first?" | CASE | [grounded] | Makes no claim about your past. Clarify first: which complaint types move first, what a member can do in the app and when they can reach a person, how a digital complaint reaches the same log as a branch one. Then objective: a member never explains twice (Plain Words) and a complaint is never unowned (Own the Fix); segmentation by complaint type; approach; metrics such as volumes, resolution times and reopened complaints; risks such as a complaint that arrives digitally with no owner. Challenge one premise respectfully, for example whether every complaint belongs in the digital channel. Answer slot: if you have worked with a digital team on anything, say what and what part was yours, in your own words; if you have not, say so plainly and say what you would want to learn first | The digital goal is the brief's headline and the JD names digital teams (F5); CASE because it is a live problem in the role, with a CO edge |
| F2 | "App-only banks are named as the main competitive pressure. Where does a credit union with branches win a complaint?" | CO | [grounded] | Makes no claim about your past. Bring one consensus item to show you read the brief, then one position of your own with a concession. Candidate theses, to adopt only if you hold them: a complaint is owned by a named person who stays with it; or the member never has to explain twice. Concession: members who want it all in the app must be served well there too. The anti-pick: do not argue branches against digital; the brief commits to both | A public strategy brief is a consensus answer every prepared candidate can assemble; CO because it asks for judgment at the credit union's altitude |

## Reverse questions, round 2

| # | Question | Why it lands |
|---|---|---|
| R2-1 | "How does a complaint move today between a branch and the contact centre, and where, if anywhere, does it tend to stall?" | Shows diligence on the end-to-end mandate without assuming a problem exists |
| R2-2 | "What would the first 90 days need to show for you to say the monthly report is working?" | Ties your reporting experience to how your manager will judge you |
| R2-3 | "How do you want branch supervisors to experience this role: as support or as oversight?" | Surfaces the coaching relationship before you are in it |
| R2-4 | "With eight branches becoming five hubs over 2027, how do you see complaints being owned during the transition?" | Grounded in the brief, and shows you read it as an operations problem |

---

# Round 3 mini-pack: panel of two branch managers (60 minutes, 20-minute escalation case, scored against the four values)

## Persona weights, round 3

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral (G) | Scenario probes mapped to the four published values, scored | High. The recruiter's email says the panel scores against the four values, and a values-style round is documented there | One story per value where your sentences carry one; a selection scaffold with an honest branch where none does |
| Case/Strategist (I) | The 20-minute case on a complaint escalation, and possibly follow-on cases from the brief | High on time alone: the email gives 20 of the 60 minutes to the case | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise |
| Peer Evaluator (H) | Seam questions: what you need from a branch manager, where your job meets theirs | Medium. The panel is two branch managers, and the JD has you coaching branch supervisors, so the seam between you and a branch manager is real. The panel is blended because names and relationships are not given | Reciprocity framing; propose seam principles rather than pretending to know the seam |

The Conversational and Pressure personas are held out: nothing in the email suggests either. The upgrade menu says what names would change.

## Question bank, round 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you decided from the member's side of the counter." | VAL | [grounded] | Selection scaffold, since your material carries no such story: pick a time a member's situation and the easy answer pulled apart. It needs the member's situation, what you chose and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Members First is a published value and the panel scores against it; no quoted sentence carries the story, so this is the scaffold case |
| G2 | "Tell me about a time you explained something difficult in plain words, to a member or a colleague." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F4: the beat the sentence carries is training new tellers on the escalation script. Answer slot: Plain Words makes a probe on what you changed or made clearer likely. If you reworded anything after someone needed it explained twice, say what and what part was yours, in your own words; if nothing was reworded, or it was not yours to change, say so plainly and stay with the training | Plain Words is a published value; VAL because the panel scores whether behaviour, not the phrase, is there |
| G3 | "Tell me about a time you did something because it mattered to the people your branch served, not because a number asked for it." | VAL | [grounded] | Selection scaffold, since your material carries no such story: pick a time you acted for the town or the people your branch served. It needs who benefited, what you did and what the number said at the time. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Neighbours, Not Numbers is a published value, and branch managers hold the branch's place in its town; no quoted sentence carries the story |
| G4 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F1: you handled the branch's formal complaints log. Answer slot: if a complaint you logged was one you kept hold of until it was resolved, pick one and say what you did and what was yours, in your own words; if complaints passed to others once logged, or following through was not yours, say so plainly and stay with the log | Own the Fix is a published value, and it is the one closest to the role's end-to-end mandate; rehearsed here a second time because the panel scores it |
| G5 | "Why a member-owned credit union, and what would you want to protect as eight branches become five hubs?" | VAL | [grounded] | Makes no claim about your past. Pick one value you can speak to in a sentence of your own, and say what you would want to protect as a principle, not a promise. Answer slot: if no value connects, say so plainly and say what you want to learn from the panel | The consolidation goes straight to a branch manager's world; VAL and CO because the question blends the values with a strategy fact |
| H1 | "You'd coach my supervisors on escalations. Where is the seam between you and me, and what happens when we disagree?" | JD | [grounded] | Makes no claim about your past. Propose seam principles rather than claiming to know the seam: agree up front who owns the complaint at each stage, keep the case in front of both of you when you disagree, and escalate a standing disagreement to your manager. Reciprocity: say what you would bring to their branch, such as a consistent way to handle escalations and a monthly view of what is happening across branches | The Peer Evaluator probes seams between adjacent roles; JD because the coaching line is the listed responsibility |
| H2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say what the sentence carries: you "built the monthly complaints spreadsheet our regional manager uses." Answer slot: if anyone else contributed data or checked it, say who and how, in your own words; if you built it alone, say so plainly and stay with the sentence | A peer-style credit probe; EXP because it tests attribution |
| H3 | "What would you need from branch managers in your first month?" | JD | [generic] | Makes no claim about your past. Ask for access and time, not answers: access to the complaint data, time with supervisors, and an honest account of what is hardest. Say it as what you would offer in return too | The reciprocity question for a peer-style panel; JD because it concerns working with branches |
| I1 | "A member says a fee was wrongly charged. The branch supervisor cannot resolve it and escalates, and three days later the member contacts the contact centre to say no one has been in touch. It lands on your desk. Work through it." | CASE | [generic] | Makes no claim about your past. Clarify first: what the member has been told so far and by whom, whether it is already a formal complaint and what clock applies under Ashgrove's own procedure, whether the charge was correct, and what the member wants. Objective: solve the member's problem and keep their trust. Segment: the fee itself, the communication failure, the process gap. Approach: one named owner, contact the member today, check the facts, reply in plain words, agree the next update date. Metrics: time to first contact, time to resolution, reopened. Risk: the member falling between branch and contact centre. Concession: say you would need Ashgrove's actual procedure to be sure of the timeframes | The email gives 20 minutes to a complaint escalation case; CASE because it is a live problem, and `[generic]` because it is a pattern for the problem, not a fact about Ashgrove |
| I2 | "One of the eight branches is due to fold into a hub, and complaints from its members have gone up. Diagnose." | CASE | [grounded] | Makes no claim about your past. Clarify: what changed and when, which complaint types rose, whether the rise is about the service change or how it was communicated. Segment members by how they use the branch. Hypothesise, then say how you would test it. Metrics: volumes and resolution times by type. Risk: Neighbours, Not Numbers, treating a town's anxiety as noise | The consolidation is in the brief and the panel is branch managers; CASE because it asks for structure on a live problem |
| I3 | "Supervisors escalate very differently: some pass everything up and some almost nothing. What do you do first?" | CASE | [generic] | Makes no claim about your past. Clarify what the monthly data shows and what supervisors have been told to escalate. First, listen to supervisors on what they find hard. Then agree what should escalate, coach on real cases and measure whether escalations become more consistent. Concession: you would not know the right threshold until you had seen the cases | The JD's coaching line makes the escalation pattern the core of the role; CASE because it asks for a first move and a structure |
| I4 | "A small-business lending product launches in Q1 2027. How would you get complaint handling ready before the first complaint arrives?" | CASE | [grounded] | Makes no claim about your past. Clarify who the customers are and whether the rules for complaints differ for business customers, which you would ask, not assume. Then where complaints will arrive, who owns them, how they enter the monthly report, and how the wording stays plain. Risk: a new product with an old process | The launch is in the brief; CASE because it asks for preparation on a problem that does not yet exist |

## Values cheat sheet, round 3

The four values are by their published names. Working meanings are paraphrased from the page you copied.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No quoted sentence carries a story. Selection scaffold: pick a time a member's situation and the easy answer pulled apart; it needs the member, what you chose and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it (G1) |
| Plain Words | If a member needs it explained twice, the wording was wrong | F4: "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message. The beat the sentence carries is the training; the slot in G2 covers anything reworded |
| Neighbours, Not Numbers | Every branch is part of its town | No quoted sentence carries a story. Selection scaffold: pick a time you acted for the people your branch served and not because a number asked for it. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it (G3) |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message. The beat the sentence carries is the log; the slot in G4 covers following a complaint through |

## Reverse questions, round 3

| # | Question | Why it lands |
|---|---|---|
| R3-1 | "What do your supervisors find hardest about escalations today?" | Gives the panel a chance to teach you the problem, and tells you where the coaching would start |
| R3-2 | "What could a new Member Experience Lead do in their first month that would genuinely help your branch?" | The reciprocity question for a peer-style panel; shows you are thinking about their load, not only yours |
| R3-3 | "Which of the four values is hardest to hold on a busy day in a branch?" | Shows you treat the values as operational, and tells you what the panel is most alert to |
| R3-4 | "How are branch managers being involved as the hubs take shape?" | Grounded in the brief; shows you see the consolidation through their eyes |

---

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own the complaints process end to end across branches and the contact centre | B1, D1, C3, G4, I1 |
| Report monthly on complaint volumes and resolution times | E1, E2, D2, I3 |
| Coach branch supervisors on escalations | D3, H1, I3 |
| Work with digital teams on self-service journeys | F1, F2, I2 |
| 4+ years in financial-services customer operations | A1, B3 |
| Experience handling regulated complaints | B2, I1 |
| Confident presenting to senior leaders | D2 |
| Comfortable with Excel reporting | E1, E2 |

## Prohibited claims

What this pack will not coach, and why. Built from the fit snapshot before the question banks.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the member complaints process end to end | Inflated form of F1 | F1's quote at its own scope: "handled the branch's formal complaints log." The limit is the pack's observation, not words for you: your material says your branch's log, not a process across branches. D1's and G4's slots stay inside the log |
| Handled regulated complaints | Inflated form of F7 | F7's quote at its own scope: "handled the branch's formal complaints log." The limit is the pack's observation: your sentence says formal, not that external rules applied. B2's slot asks only which rules applied, if any |
| Reported on complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope: "built the monthly complaints spreadsheet our regional manager uses." The limit is the pack's observation: your sentence does not say what it counted. E1's slot asks only what it held |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: you "trained new tellers on our escalation script." The limit is the pack's observation: your sentence says tellers, not supervisors. D3's slot stays with the tellers |
| Has worked in a contact centre | Negative you stated, F2 | The plain acknowledgment F2 gives: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment F8 gives: "I haven't presented above regional level." No slot |

## Upgrade menu

- The interviewers' names and roles, once assigned → an interviewer read from their public professional footprint, per-person persona weights for the panel, and a reverse question tied to an interviewer's own career path
- Your CV → the six `your message` quotes become CV lines, and rows F1, F3, F4, F7 and F9 may gain a second quote that raises their confidence or closes their slot
- Your answers to the slots, stated outside a drill → the spreadsheet's measures and tool (F3, F9), whether the complaints in your log fell under external rules (F7), where your involvement with a complaint ended (F1), any contact with a digital team (F5), and whether any training or guidance reached supervisors (F4); each answer becomes quoted evidence and the rows regenerate
- Ashgrove's published member-complaints procedure, pasted → I1 and I2 move from `[generic]` patterns to cases built on their own stages and timeframes
- The recruiter's answer on the 20-minute case: whether it is given cold or in advance, and whether any materials come with it → case coaching sized to the format, and a graded-deliverable section if anything is pre-declared
- How many hours you have before 26 November → a prep triage that puts the few things worth doing first, in order
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → Ashgrove's recent organisation context, interviewer footprint once names exist, and reported loop structure for this role family, which would sharpen the CO and CASE banks
- A `tuesday-dossier.md`, if you have one from earlier work → verified-evidence grading and a prohibited-claims list from that work; this pack is complete without one
