Search was refused here, so I'm building the pack from your dossier alone. Writing it now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a/runs/sonnet/tuesday/part-2/rooms/case-4-denied-af5dedaf/quartzline_product-manager-platform-apis_interview_pack.md`. I built it for the hiring-manager round from your dossier alone, because web search was refused here. That means there is no Quartzline values page, loop detail or strategy in it, and the case questions are generic. It has 20 questions across six personas, ten fit-snapshot rows, six reverse questions and a prohibited-claims list. The prep triage is sized to Thursday.

The most important rehearsal is A1, the objection the underwriter named. It has the exact concession wording, the bridge with its limit, a ramp plan and three follow-up levels. R2 ("Shipped API or platform products") is a must-have the dossier never graded, so I graded it myself as a transferability gap. Check it against how you remember that work.

Say the word and I'll play the Skeptic on A1 as a live drill. I can also save an updated `tuesday-dossier.md` with the rehearsal gaps this prep exposed, or convert the pack to a Word document.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

Role: Product Manager, Platform APIs. Company: Quartzline. Round: a 45-minute conversation with the hiring manager, on Thursday. Interviewer: name not given, so there is no interviewer read. Built from your dossier (`tuesday-dossier.md`, version 1.1) alone: web search was refused in this session, so nothing here comes from research.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did. Where a cell says answer slot, it is an instruction for the interview, not a question for this conversation.

| Type | What it scores |
|---|---|
| VAL | Behavioral and values alignment: past behavior, not generic virtue |
| EXP | Work-experience deep-dive: whether your claims survive scrutiny, and what was actually you |
| JD | Role and JD-driven: whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem from the role, worked out loud |

The highest-ROI prep in this pack is A1. The underwriter named that objection from evidence you confirmed, and it gets the deepest rehearsal.

## Prep triage

Sized to the time between now and Thursday. Do these in order; everything else is insurance.

1. Tonight: say A1 aloud three times, then D1 against a sixty-second clock. Concede the title and roadmap points in one sentence each, hold the bridge.
2. Wednesday: A3, A4, C1 and D2 aloud, attribution first (what was yours, what was not). Read your own integration playbook once, so C2 starts from the page.
3. Wednesday: B1 and B2 aloud, saying the structure before the content. Then E1 as a 90-second arc.
4. Thursday morning: pick two reverse questions from V1 to V6 (V1 and V2 first), and run A2 once.

Everything else is insurance.

## Fit snapshot

Requirements are the dossier's `role_profile` lines. The dossier graded F1, F2 and F7 itself; the underwriter did not grade the other rows, so those are this pack's own reading and carry `[inferred]`. Check F3 first: it is a must-have the dossier did not grade.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1 | low | [grounded] | transferability | The underwriter's framing, with its limit kept: adjacent work, never product management experience. Words: "I led 30+ end-to-end client integrations of the vendor's REST APIs: scoping, requirements, architecture, UAT, go-live." The limit is the pack's observation: the material shows integration delivery, not a product role. The plain acknowledgment is sourced by `prohibited_claims`: "Having held a product manager title or role", so the words are "I haven't held a product manager title or role." |
| F2 | "Owning a roadmap and prioritization authority" — dossier uncertain_or_weak_areas, R1 sub-claim | none given | none | [grounded] | capability | No bridge: the dossier's strategy for this area is `acknowledge_gap`, and the underwriter found nothing to bridge with. Words come only from the dossier field: `prohibited_claims`: "Having owned a product roadmap" supports "I haven't owned a product roadmap." Then how you would learn it, said as a plan and never a past: ask the squad leads which decisions are whose, and how adoption is measured today. Nothing is added to make the gap feel smaller |
| F3 | "Shipped API or platform products" — dossier role_profile R2, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1 | low | [inferred] | transferability | The dossier did not grade R2; this is the pack's reading, derived from the quote carrying adjacent work that does not reach the requirement. Words stay at the quote's scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Answer slot: the must-have line makes a probe on which stages were yours likely. If any of scoping, requirements, architecture, UAT or go-live were yours to set, say which and how you decided, in your own words; if one was not yours, or there was no such step, say so plainly and stay with the integrations you led. The material says integrations, not products |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence 2 | low | [inferred] | discovery | Both quotes touch the requirement (REST integration architecture; a written playbook) and neither shows whether it reaches API docs or schemas. Answer slot: the line makes a probe on reading or writing API docs and schemas likely. If you worked with them, say how and name one you can walk through; if your work did not go through docs or schemas, say so plainly and say what you would read first |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4, the customers part | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1 | high | [inferred] | presentation | The quote already reaches the customers part in other terms; the pack's reading of R4 is its own, since the dossier left it ungraded. Lead with the quote's own terms: clients, and the stages from scoping to go-live, because a named record beats an adjective. Add nothing about what those engagements were like |
| F6 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4, the engineering and sales part | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence 3 | medium | [inferred] | discovery | The quote shows client evidence going to product; it does not show work with engineering or sales. Answer slot: the line names both, so expect a probe. If you worked directly with either, say how and over what; if your work ran through clients and product only, say so plainly and stay there. The dossier marks this quote confirmed with limited inspectable proof, so expect a probe on it |
| F7 | "Agile delivery experience" — dossier role_profile R5, preferred | none given | low | [grounded] | discovery | The dossier's strategy for this area is `clarify`. No confirmed entry speaks to the requirement, so nothing about your past goes in the answer unless it sits in the slot. Answer slot: the line makes a probe on whether you have worked in sprints beside a product org likely. If you did, say how your work fit and in what role; if you never worked that way, say so plainly, and say what you would want to confirm about how this team runs it |
| F8 | "Run discovery with integration partners" — dossier role_profile responsibilities | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence 3 | medium | [inferred] | discovery | Words stay at the quote: "I ran quarterly roadmap-input sessions that fed client evidence to product." Confirmed with limited inspectable proof, so volunteer the limit before it is extracted. Answer slot: the responsibility makes a probe on how the sessions ran likely. If any of the format, the attendees or the form the evidence took was yours to set, say which, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the sessions you ran |
| F9 | "Define and track adoption metrics" — dossier role_profile responsibilities | none given | none | [grounded] | discovery | Strong evidence here would be a measure you defined or tracked for the integrations, named as you actually counted it. Answer slot: if you defined or tracked any such measure, say what you counted and how; if none, say so plainly, and say what you would measure first |
| F10 | "Write specs and drive delivery with two engineering squads" — dossier role_profile responsibilities | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1 | low | [inferred] | discovery | The quote touches requirements and architecture without showing who received them. Answer slot: if requirements you wrote went to an engineering team, say what form they took and who received them; if you wrote none, say so plainly and say how you would write them |

## Persona table

| Persona | How it shows up here | Weight | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | Quiet probing of the missing title and roadmap, the day-one weakness, why now | High | Hiring-manager prior is Case and Skeptic, and the underwriter named a Skeptic-shaped objection (A1) | Rehearse the one predictable objection until it is boring; concede what the dossier says you cannot claim, bridge only from quoted work with its limit named |
| Case/Strategist | Live problems on the platform: two squads, adoption, a breaking change | High | Hiring-manager prior; the role's unknowns (decision authority, adoption baseline) make live problems likely | Clarify, then structure, then answer; say the framework aloud; challenge one premise respectfully |
| Data-Driven Prober | Reads the quoted lines closely: the 30+ figure, the playbook | Mid | Each quoted line is a magnet; the 30+ figure needs a defend-the-number row | Know what you can and cannot say about how the figure was counted; name your weakest assumption first |
| Pressure | Time-boxed "why you over a PM with the actual job" | Mid | The A1 objection arrives in this register from a manager who is derisking a gap | Pause, restate, hold the bridge through two follow-ups, concede specifics plainly |
| Conversational | The biography question, an agile-process question in casual register | Low | A manager opener, and still scored | A 90-second arc built only from your quoted lines |
| Values/Behavioral | Scenario prompts on unpopular truths and customer-first calls | Low | No loop source documents a values round; your note describes one conversation with the hiring manager, and no Quartzline values were available | Selection scaffolds ending in the honest branch; no story the pack supplies |
| Peer Evaluator | Seam-splitting with squad leads | Not weighted | The interviewer is the hiring manager, not a peer; the squad-lead seam is carried inside B1, V1 and V3 | None needed this round |

Weights rest on the hiring-manager relationship prior and your own description of the round. No interviewer information exists, so no signals adjusted them.

## Question banks

### A: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | The underwriter named this objection, so it gets the most follow-up levels. Concede first, before it is extracted: "I haven't held a product manager title or role, and I haven't owned a product roadmap" (sourced by `prohibited_claims`: "Having held a product manager title or role" and "Having owned a product roadmap"). Then the bridge, with its limit named as adjacent and not the same job: "I led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping and requirements through architecture, UAT and go-live, and I wrote the internal integration playbook my team uses." Then a ramp plan, said as a plan: in the first weeks, ask the squad leads which decisions are whose, and ask how adoption is measured today. Follow-up one, "so what have you decided": return to the quoted work, never to prioritization. Follow-up two, "a PM with three years has done the job": agree in one sentence that they have and you have not. Follow-up three, "then why you": give your own reason in your own words, naming one quoted line the role can use on day one and one thing you must learn first. Hold the bridge through two follow-ups; never add to it | F1 and F2 are where this presses hardest, so it will arrive in some form. JD because it scores the R1 must-have; Skeptic delivery |
| A2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] | Name the roadmap and prioritization piece first. The dossier lists it as an `acknowledge_gap` area, "Owning a roadmap and prioritization authority (R1 sub-claim)", with no credible evidence behind it, so there is no bridge and no slot here. Words: "I haven't owned a product roadmap" (sourced by `prohibited_claims`: "Having owned a product roadmap"). Then the plan: ask the squad leads what is decided where, ask how adoption is measured today, and say what you would sit in on first. Stop there, and do not reach for the roadmap-input sessions as a rescue | F2 is the capability row. JD because it scores a stated requirement; the stem is the Skeptic's own |
| A3 | "Walk me through the roadmap-input sessions you ran." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Story-mapped on F8: the sessions, their quarterly rhythm, and the evidence you fed to product are the beats the quote states; tell them in your own words and keep the verb where the quote has it. The underwriter marks this confirmed with limited inspectable proof, so volunteer the limit: say what you can show and what you cannot. Answer slot: the JD's discovery line makes a probe on how the sessions ran likely. If any of the format, the attendees or the form the evidence took was yours to set, say which, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the sessions you ran | F8 is the medium-confidence entry, so a probe is expected. EXP because it tests what was actually yours |
| A4 | "This role asks for shipped API or platform products — what's the closest work you've done?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Story-mapped on F3: the integrations you led, from scoping to go-live, are the beats the quote states; name the work as adjacent and let the interviewer judge how close it is. Answer slot: the must-have line makes a probe on which stages were yours to set likely. If any of scoping, requirements, architecture, UAT or go-live were yours to decide, say which and how you decided, in your own words; if one was not yours, or there was no such step, say so plainly and stay with the integrations you led | F3 is a must-have the dossier did not grade, so the honest answer is rehearsed here before a probe arrives. JD because it scores R2 |
| A5 | "Why move into product from where you are, and why now?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | The pack holds no reason of yours and supplies none; give your actual reason in your own words. Shape it: what pulled you toward this work, one line of your material that touches product work, which is the quoted one, said at its own scope, and what you are not claiming, the title and the roadmap | Motivation consistency is what a Skeptic scores; F1 is why it is asked. EXP because it tests whether your story survives cross-examination |

### B: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have two squads and one quarter. One partner needs a new endpoint; the other squad needs a deprecation finished. How do you decide, and who is in the room?" | CASE | [generic] | Clarify first: what each costs, which partners are affected, what the deadline is, what adoption data exists. Then objective, criteria, options, risks. On who decides, do not pretend to know the seam: propose principles for what is a PM call and what is a squad lead's call, and ask which decisions the PM makes alone. Answer slot: the JD's "Write specs and drive delivery with two engineering squads" line makes a probe on how you would write the decision up likely. If you wrote requirements for engineering in your integration work, say what form they took; if you wrote none, say so plainly and describe how you would write them | A live problem from the squad-authority unknown, and from F10. CASE because it scores structure; `[generic]` because it is a pattern for the problem, not a fact about Quartzline |
| B2 | "Suppose partner API adoption has stalled for two quarters. Diagnose it." | CASE | [generic] | Ask first how adoption is defined and measured today and what the baseline is; these are open on this role, so asking is the right move. Then segment (new versus existing partners, stages from sign-up to production use, offered as a structure for the case), hypotheses, the data each needs, how you would test it, risks. Say the framework aloud and state your hypothesis early | F9 is the adoption-metrics row. CASE because it asks for diagnosis from a stated symptom |
| B3 | "A large partner asks for a breaking change to a live endpoint. Walk me through your decision." | CASE | [generic] | Clarify who else depends on it and how severe the problem is; options such as versioning, a deprecation window or an opt-in; partner communication; what you would want documented. Use the vocabulary of docs, schemas and versions naturally. It is a hypothetical, so say "I would" and describe no past | F4 is the technical-fluency row; this tests it without asking about your history |
| B4 | "Sketch the discovery plan for the partner platform's next quarter — what do you need to know first?" | CASE | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Clarify the objective and which decisions the discovery feeds; who you would talk to; how often; how you would synthesize. One clause about yourself, at its own scope: "I have run quarterly roadmap-input sessions that fed client evidence to product." Do not extend it | F8 is the discovery responsibility. CASE delivery for a JD item |
| B5 | "Which two adoption metrics would you put on the platform dashboard, and what would each one miss?" | CASE | [generic] | Ask what is tracked today before choosing. Pick two with different failure modes and name what each would miss; naming the weakest assumption before the interviewer does is the move | F9 again, as a metric question. CASE with a JD source |

### C: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You led 30+ integrations. How was that counted, and what part of each was yours?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The four slots a figure raises, each in your own words: how the 30+ was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. The pack names no method. If you do not know how it was counted, say so plainly and say what you do know. Keep "led" at the quote's scope | F1, F3 and F5 all rest on this line, so the number gets the defend-the-number rehearsal. EXP because it tests attribution |
| C2 | "Walk me through the integration playbook — what's in it, and who uses it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Story-mapped on F4: you wrote it, and your team uses it. The dossier records this as high confidence and inspectable, so offer to share a page. Answer slot: the JD's technical line makes a probe on whether it covers API docs or schemas likely. If it does, say what it covers, in your own words; if it does not touch them, say so plainly and describe what it does cover | The playbook is the pack's most inspectable evidence, so a careful reader goes here. EXP with a JD link |
| C3 | "Show me how you read an API doc — what do you look for first?" | JD | [generic] | A short think-aloud: authentication, the resource model, versioning, errors and limits, deprecation. This is a method, so it asserts nothing about your past. If a follow-up asks whether you have written such docs, use F4's answer slot | F4, tested live. JD content, CASE delivery |

### D: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | A1 compressed to a minute: the concession (sourced by `prohibited_claims`: "Having held a product manager title or role" and "Having owned a product roadmap"), the bridge quote at its own scope, one sentence of plan. Pause and restate before answering. Hold the bridge through two follow-ups and concede specifics plainly | A1 in the Pressure register; F1 |
| D2 | "That 30+ — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold the sentence's own scope. Answer slot: which engagements and which parts were yours, in your own words; if part of the work belonged to others, say which, plainly. Hold through two follow-ups, then concede anything real, specifically | The persona's own attribution stem, aimed at F1 |
| D3 | "Tell me about a time you had to say no to a client." | EXP | [generic] | Selection scaffold: pick an instance with a named stake, the moment you said no, and a relationship still intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Under interruption, hold your answer, then concede only what is true | The JD's stakeholder line raises the theme; F5 and F6 are why it is asked |

### E: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc of three beats, one per quote: the integrations you led, the playbook you wrote, the sessions you ran (marked medium, so expect a probe on that one). Name the arc as integration work, adjacent to this role. Close with your own reason for this role, in your own words | F1 and F8 are the arc's limits. EXP because it is a biography question, though casual in register |
| E2 | "How does your delivery work run day to day, and where does it touch an agile team?" | JD | [grounded] | The dossier's strategy here is `clarify`, and no confirmed entry speaks to the requirement, so nothing about your past goes in unless it sits in the slot. Answer slot: the JD's "Agile delivery experience" line makes a probe on whether you have worked in sprints beside a product org likely. If you did, say how your work fit and in what role; if you never worked that way, say so plainly, and say what you would want to confirm about how this team defines and runs it | F7 |

### G: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not soften it, and a working relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The persona's stem; no published Quartzline values were available, so this is not value-mapped |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a specific decision, what the internal metric was, what it cost, and how it landed. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The persona's stem; the same limit as G1 |

## Requirement coverage

| Requirement | Questions |
|---|---|
| R1: "3+ years product management experience" | A1, A2, D1 |
| R1 sub-claim: roadmap and prioritization authority | A1, A2, B1 |
| R2: "Shipped API or platform products" | A4, C1 |
| R3: "Technical fluency: API docs, schemas" | C2, C3, B3 |
| R4: "Stakeholder management across engineering, sales, customers" | B1, D3 |
| R5: "Agile delivery experience" | E2 |
| Run discovery with integration partners | A3, B4 |
| Write specs and drive delivery with two engineering squads | B1 |
| Define and track adoption metrics | B2, B5 |
| Own the roadmap for the partner-facing API platform | A1, A2, B1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| V1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | Decision authority is asserted in the posting and not evidenced; asking reads as diligence and answers something you need to know before accepting |
| V2 | "How is partner API adoption measured today, and what is the current baseline?" | Adoption metrics are a named responsibility with no baseline stated |
| V3 | "Where do the two squads' priorities pull against each other today, and who settles it?" | Tests the seam V1 opens, and shows you think about it as a seam |
| V4 | "What does the team hear from partners today that it cannot yet act on?" | Opens the discovery topic without claiming anything about your past |
| V5 | "What would you want a new PM to have changed in their first ninety days?" | Gets the manager's own success definition, which shapes your first-weeks plan |
| V6 | "What would make you doubt a hire from the integration side in month three?" | Asks for the objection directly, while you can still answer it |

## Prohibited claims

Built before the banks and binding on every cell. The first three come from the dossier's `prohibited_claims`; the last two are built locally from the fit snapshot.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier `prohibited_claims` | F1's quote at its own scope, plus the plain acknowledgment "I haven't held a product manager title or role" |
| Having owned a product roadmap | Dossier `prohibited_claims`, and the `acknowledge_gap` area for F2 | The plain acknowledgment "I haven't owned a product roadmap". No bridge, no slot |
| Having set prioritization for an engineering squad | Dossier `prohibited_claims` | F1's quote at its own scope; if probed, "I haven't set prioritization for an engineering squad". B1 stays hypothetical, in "I would" |
| Shipped an API or platform product | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material says integrations led, not products shipped. A4's slot stays inside the stages |
| Shaped or set the roadmap through the roadmap-input sessions | Inflated form of F8 | F8's quote at its own scope: the sessions fed evidence to product. A3's slot asks only how the sessions ran |

## Sources

Provided: your dossier, `tuesday-dossier.md` version 1.1, generated 2026-08-14. Consumed: `role_profile` (the requirement and responsibility lines), `handoff_to_mock_interview` (verified evidence, weak areas and strategies, the named objection, risks and employer questions, prohibited claims) and `decision` (context only). The dossier carries no `evidence_map`, `evidence_state` or `risk_register`, so rows the underwriter did not grade are this pack's reading.

Searches sent, all refused:

- "Quartzline company values": refused
- "Quartzline interview process product manager": refused
- "Quartzline strategy news partner API platform": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Would have fed a values cheat sheet; none is built, and G1 and G2 are unmapped scaffolds |
| 2. `Quartzline interview process product manager` | unavailable | Would have named the loop; weights rest on your description of the round and the hiring-manager prior |
| 3. `Quartzline strategy` / recent news | unavailable | Would have grounded a CO or CASE question in current strategy; the CASE bank is `[generic]` |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so there was no query to form |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's `role_profile` fixes the requirement lines the fit snapshot and JD questions use |

## Upgrade menu

- The interviewer's name or profile → an interviewer read, persona weights from their public footprint, and a reverse question tied to their path
- The recruiter's prep email → coverage of any focus area or deliverable they announced, replacing round-type priors
- Quartzline's values page, careers page or strategy material pasted in (or search granted) → G1 and G2 mapped to named values, and a strategy-grounded case in place of the `[generic]` B bank; a deeper research pass would add up to 6 more searches and 2 more fetches, several more minutes
- The agendas or decks from the quarterly roadmap-input sessions → F6 and F8 can rise from medium confidence, because an inspectable artifact is what raises the band
- Your own words on the answer slots in F3, F4, F6, F7, F8, F9 and F10 → those rows become quoted evidence the next pack can map as `[grounded]`
- An evidence map from the underwriter in `tuesday-dossier.md` → F3 to F6 and F8 to F10 graded by the underwriter instead of by this pack
