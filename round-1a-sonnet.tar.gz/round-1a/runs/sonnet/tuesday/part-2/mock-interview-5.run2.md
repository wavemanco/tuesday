Web search was refused in this session, so I'm building the pack from what you told me and labelling everything else generic. Writing it now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a/runs/sonnet/tuesday/part-2/rooms/case-5-denied-eec3254c/Kelverton-Rail_senior-partnerships-manager_interview_pack.md`.

I built it on three limits:
- **Research:** web search was refused in this session. I sent six queries, none returned anything, and I'm not retrying. The pack uses only what you told me, and nothing in it about Kelverton's values, strategy or process, or about Deepa and Ross, comes from the web.
- **Market report:** the strategy report isn't in the conversation, so I haven't read it. Its content appears nowhere in the pack. A4 and the thesis differentiation are written for you to fill from your own notes.
- **Job description:** I didn't have one, so the requirements are the recruiter's quoted words plus two generic role-family rows.

The pack assumes "operator partnerships" means Kelverton's relationships with the train operating companies it sells to. You say that aloud in your first minute.

- **Highest-ROI prep:** the objection that you've "never sold into rail" and "never carried a direct quota". Rehearse B1, C1 and D3 first. The pack gives you the plain acknowledgment using your own words and does not coach you to claim quota experience. Prohibited-claims section 13 lists what it won't coach, including "booked the £4M" and "built the ISV channel".
- **The 15-minute POV:** section 5 has the spoken structure, three thesis options each with a mandatory concession, and a recommendation (lead with depth-first, hold the ecosystem thesis for Q&A). It ends on the operator close the recruiter asked for.
- **Four hours:** the prep triage puts the POV first at 75 minutes and the commercial objection second at 45.
- **Where you'll need to answer:** the answer slots (how the £4M was counted, what counted as a partner, which part was yours, why rail) are for you to answer in your own words. The pack doesn't supply them.

If you'd like the pack as a Word document, say so and I'll convert it.
Say the word and I'll play Ross on C1 and C2, the time-boxed revenue question and the "how much of it was actually you" follow-up.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.

Can you paste the job description? It would turn the two generic requirement rows into quoted ones and show whether any requirement has no question yet; if you don't have it, say skip and the pack stands as is.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Kelverton-Rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail

Second-round panel, Tuesday, 60 minutes. Panel: Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). First 15 minutes: your spoken POV, no slides. Rest: Q&A, where Ross will push on commercials. Built without the job description, without the content of the strategy report, and without web research (see Sources).

## How to use this pack

Personas describe how a question arrives; types describe what is being scored. Guidance is scaffolding, not a script: say only what you actually did, in your own words.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values (none detected for this loop, so no VAL rows) |
| EXP | Whether claims about your experience survive scrutiny, and what was actually you |
| JD | The stated role and its requirements, including the gaps |
| CO | Company and strategy knowledge, thinking at their altitude |
| CASE | A live problem from the role, structure over the right answer |

Labels: `[grounded]` rests on something you said or the recruiter said; `[inferred]` is derived and the derivation is named; `[generic]` is a role-family pattern with no claim about Kelverton or you. An answer slot is an instruction for the interview, not a question for you now.

## Prep triage (four hours)

1. 75 min: build and speak the POV aloud, timed, recorded on your phone (section 5). Do it twice; the second time, stop yourself at 13 minutes.
2. 45 min: the commercial objection. B1, then C1, then D3, out loud, until the plain acknowledgment sounds boring. This is the highest-ROI prep in the pack.
3. 45 min: fill the answer slots in D1, D2 and C2 in your own words. Write nothing you cannot say twice under a follow-up.
4. 30 min: A2, A3, A5 and the reverse questions in section 11.
5. 30 min: full run-through, POV then three questions picked at random from banks B to D.

Everything else is insurance: E1, E2, B2, B3 and A4 if you cannot get the report's content to hand.

## 4. Fit snapshot

No job description was supplied, so the requirements are the recruiter's own words as you quoted them, plus two role-family requirements written as plain prose and labelled `[generic]`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [grounded] | transferability | Your material says an ISV channel at a payments company, grown "from 6 partners to 40", and the words stay at that scope; nothing quoted shows operators as partners. Answer slot: the POV ask makes a probe on how the channel work maps to operator partnerships likely. If any of how you grew the channel carries over, say which and why, in your own words; if the two are different kinds of partnership, or it does not carry, say so plainly and stay with the ISV channel you ran |
| F2 | "Please land on what it means for the operators themselves." — recruiter's email | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." — your message | medium | [grounded] | transferability | Your material says bus and light rail network planning and "the operator world from the other side"; it does not say train operating companies, and the words stay at bus and light rail. Answer slot: the ask for an operator-level close makes a probe on what you know of a train operator's side likely. If anything from the consulting years carries over, say what, in your own words; if nothing does, say so plainly and ask the panel what matters most to their operators instead |
| F3 | "Ross will push on commercials." — recruiter's email | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message; "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | medium | [grounded] | transferability | The figure is influenced revenue and the words stay there: "roughly £4M of influenced revenue". Answer slots (D1, D2, C2): how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours, each in your own words; "I don't know how it was counted" is an honest branch |
| F4 | carrying a direct revenue number for the role (role-family requirement, no job description supplied) | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't carried a direct quota; my number was influenced revenue." Then how you would learn to carry one, said as a plan and never as a past. Never a claim to quota or booked revenue, and nothing added to make the gap feel smaller |
| F5 | selling to or working with train operating companies (role-family requirement, no job description supplied) | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't sold into rail specifically." Then your plan for learning it, said as a plan and never as a past. F2 is the nearest adjacent material and is not a substitute |

**Requirement coverage**

| Requirement | Covered by |
|---|---|
| F1, the POV on operator partnerships | A1, A2, A3, A4, B4, C3, C4, E1 |
| F2, the close on what it means for operators | A1, A2, A5, B4, E1, E2 |
| F3, commercials | A5, C1, C2, D1, D2, D3 |
| F4, a direct revenue number | B1, B2, C1, D3 |
| F5, working with train operating companies | B1, B2, B4, E2 |
| Format: 15 minutes, no slides, then Q&A | A1 and section 5 |

## 5. Graded deliverable: the 15-minute POV

The recruiter announced it: "present a short POV on where you'd take our operator partnerships over the next 18 months", "no slides needed, just talk us through it", and "Please land on what it means for the operators themselves." That last line is the requested close, and it is the last thing you say, not an afterthought.

**Assumption to say out loud in your first minute:** you took "operator partnerships" to mean Kelverton's relationships with the train operating companies it sells scheduling software to. If that reading is wrong the panel will correct it in ten seconds, and saying it is the clarify step the Case/Strategist scores.

**Grounded facts to build on** (each is a quoted sentence from the row named):

- F1: "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue."
- F2: "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)."
- F4 and F5: "Never sold into rail specifically and never carried a direct quota, only influenced revenue."

**Thesis options.** Pick one to lead with. Each carries a mandatory concession, said aloud before the panel asks for it. The operator-meaning cell is yours to fill from the report and what you actually know; the pack supplies no facts about operators.

| Thesis | What it means for operators (your words) | Mandatory concession | Provenance |
|---|---|---|---|
| T1. Go deep with a few operators before widening | Answer slot: what one operator would see differently by month six, from the report and your own knowledge; if you cannot say, say what you would ask them first | Your count is partners, "from 6 partners to 40", which is no evidence about depth; this thesis runs against the one number you have | [inferred] derived from F1 and the 18-month frame; a pattern, not a claim about Kelverton |
| T2. Agree shared measures with operators early, so partnership is judged on operator outcomes | Answer slot: which outcome an operator would hold you to, in your words; if you do not know what operators already track, say that is your first question | "Never carried a direct quota"; your number was influenced revenue, so you would want the commercial owner's view on how these measures meet a direct number | [inferred] derived from F3, F4 and Ross's commercial focus |
| T3. Build a partner ecosystem around the operators | Answer slot: what operators gain from third parties around the product, in your words; if you cannot say, name what you would need to learn | "Never sold into rail specifically"; the channel you ran was an ISV channel at a payments company, a different kind of partnership | [inferred] derived from F1; a pattern, not a claim about Kelverton |

**Recommendation (inferred):** lead with T1, use T2 as your answer to "how would you know it's working" (A5), and hold T3 for the Q&A. T1's concession is the cleanest and keeps your commercial gap out of your opening minutes; T3 leans hardest on the part of your background that is least like rail.

**Differentiation.** You said the strategy team circulated the report internally, so assume the panel knows it. A shortlist anyone prepared can assemble scores as homework. Bring one item the report names to prove grounding, then one thesis-driven divergence with reasons, then the anti-pick: one thing on the consensus list you would sequence later or not do in 18 months. Fill all three from your notes on the report; the pack has not seen it. Never coach yourself to correct the panel on a point; depart from the report with reasons instead.

**Spoken structure (about 13 minutes, leaving room for interruptions):**

1. Assumptions and what you don't know (1 to 2 minutes).
2. Thesis and why this one over the other two (3 to 4 minutes).
3. The 18 months in phases, the anti-pick, and the measures (3 to 4 minutes).
4. Your concession, before they ask (1 minute).
5. What it means for operators, last (3 minutes): what an operator sees by month six, what by month 18, and what you would ask of them in return. Each earlier point should tie back to this.

## 8. Persona table

Weights come from the relationship priors in three passes. Deepa is your future manager, so the hiring-manager row gives Case/Strategist and Skeptic. Ross is the Commercial Director, so the executive row gives Case/Strategist and Pressure; the recruiter's own words, "Ross will push on commercials", lift the Prober. The loop is established by the recruiter's words: one session, a panel of two, 60 minutes, 15 of them a POV, the rest Q&A. No values-style round was named, so none is assumed and there is no values cheat sheet.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | The POV itself, then live follow-ups on it from both panelists | high: the recruiter's POV ask plus both members' priors | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| B. Skeptic | Deepa probing the gap between ISV payments and rail operators | high: F4 and F5 are stated gaps and she is the future manager | Rehearse the single objection until it is boring; adjacent evidence only, with the limit said plainly |
| C. Pressure | Ross time-boxing and interrupting on revenue | medium-high: "Ross will push on commercials" and the executive prior | Pause, restate, hold two follow-ups, then concede specifically; never invent a number |
| D. Data-Driven Prober | Ross or Deepa unpicking the £4M and the 6 to 40 | medium: the recruiter's commercial signal plus two headline figures | Know how each figure was counted, name your weakest assumption first, say plainly what you do not know |
| E. Conversational | An opener or a warm aside before the hard questions | low: the format starts with the POV, but casual questions are still scored | A 90-second arc for the journey question; treat casual questions about scheduling as scored |

## 9. Question banks

### A. Case/Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Talk us through where you'd take our operator partnerships over the next 18 months, and what that means for the operators." | JD | [grounded] | Section 5 is the build. Assumption first, one thesis with its concession, the 18 months in phases with the anti-pick, and operators last. Guidance makes no claim about your past here | This is the announced deliverable itself and F1 and F2 are what it is scored against; JD because it is the stated assignment |
| A2 | "What would you need to know about our operators before you committed to any of this?" | CASE | [generic] | Name your first three questions in your own words, for example who owns an operator relationship today, what an operator is already asked to commit to, and what the last partnership attempt taught Kelverton. Say which you would ask first and why. Think aloud; clarify before you structure | Case/Strategist panels score whether you clarify before you structure; the question is the live form of F1 and presupposes nothing about your past |
| A3 | "Pick one operator relationship to deepen and one to deprioritise in the first six months. How do you choose?" | CASE | [generic] | Say your criteria before you pick, then pick, then name the cost of the deprioritised one. This is the anti-pick rehearsed live. Do not name a real operator unless the report does | Segmentation and the willingness to say no are what distinguish judgement from a recited shortlist; F1 is the requirement it tests |
| A4 | "Where do you agree with the strategy report, and where would you go a different way?" | CO | [grounded] "She also attached the market report their strategy team circulated internally last quarter, which I've read." | One item the report names, to prove grounding; one divergence with reasons; one thing you would not do. Fill each from your notes: you have read it and the pack has not. Disagree with reasons, never by correcting the panel | The report was circulated internally per your message, so reciting it scores as homework and departing from it scores as judgement; CO because it tests company-altitude thinking |
| A5 | "Eighteen months out, how would you know it was working, and what would operators see?" | CASE | [generic] | Three measures: one operator-facing, one commercial, one leading. Say which you would trust least and why. If using T2, name how operator outcomes meet the commercial owner's number. State what you would need to learn to set the targets | Metrics and the operator close are both in the recruiter's brief, and this is the metric step of the case structure; F3 is where it presses |

### B. Skeptic (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't sold into rail and you haven't carried a direct quota. What makes you the right person to own these relationships?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment, in your own words: "I haven't sold into rail specifically, and I haven't carried a direct quota; my number was influenced revenue." Then only what your quotes carry: "running the ISV channel", "took it from 6 partners to 40". Then your plan for the gap, said as a plan. Follow-up one, "why you over someone who has": hold on those quotes, add nothing. Follow-up two, "influenced isn't owned": concede it plainly and do not reframe influenced as direct. Concession wording to rehearse: "That's a real gap, and I'd rather you weigh it than have me talk around it." Limit named before it is asked for: your material does not show quota work | F4 and F5 are the predictable objection and the stated gaps; Ross's commercial push makes it near-certain. JD because it scores the stated role |
| B2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Pick your honest weakest part and say it first. The material already carries two candidates, rail selling and a direct number. Then your ramp plan as a plan: what you would do in the first 90 days, in your own words, and what you would ask Deepa for. If something else is your real weakest part, say that instead | F4 and F5 again, in the collegial form a future manager asks; calibrated candour beats bluffing a competency the panel owns |
| B3 | "You've spent the last four years in payments. Why rail, why us, why now?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Your material states no reason for this move, so the pack does not write one. Answer slot: give your real reasons in your own words; if the honest reason is simply that the work interests you, say so plainly. Keep it to three sentences and end on the role, not on your history | Motivation consistency is the Skeptic's score, and F1 shows the move from payments to rail; EXP because it tests your own story |
| B4 | "Your partners were software vendors. Ours are train operating companies. What stays the same and what doesn't?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue."; "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Answer slot: if anything about how you ran the ISV channel carries over, say what and why, in your own words; if the two are different kinds of partnership, say so plainly and stay with the ISV channel you ran. Then what you would want to learn from the consulting years' side of "the operator world", at bus and light rail scope, and no further | F1 and F2 are the two bridges and the question tests where each stops; EXP because it asks what actually transfers |

### C. Pressure (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: what revenue will operator partnerships add in your first 18 months?" | CASE | [generic] | Hold, do not guess. Pause and restate. Say what you would need before giving a figure: the baseline today, how revenue is attributed, and what is already in the pipeline. Offer a date by which you would commit to a number. Never offer a figure you cannot defend, and never cite your influenced revenue as a forward target. If pushed twice, concede that you cannot give a defensible number yet and say what would change that | A time-boxed commercial question that tests composure; F3 and F4 are where a fabricated number would come from, and a pack that supplied one would be coaching it. CASE because it is a live sizing problem |
| C2 | "That £4M. How much of it was actually you?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Hold at the quote's scope: you ran the ISV channel and the figure is influenced revenue, roughly £4M. Answer slot: say which part was yours and which was others', in your own words; if others closed the deals or set the terms, say so plainly. Hold through two follow-ups by returning to the quote, never by adding to it; concede the limit specifically: influenced, not booked | F3's figure is the likeliest target of an attribution probe; EXP because it tests what was yours |
| C3 | "Stop there. Why would an operator do that rather than what they do today?" | CASE | [generic] | Interrupted mid-POV. Do not defend by repeating. Say what you do not know about what operators do today, then hold your thesis for one reason you can state, then restate your concession. Hold through a second push and concede specifically, not generally | The POV is the live test of the thesis, and Ross may interrupt it; F1 is the requirement. CASE because it is a challenge on a live plan |
| C4 | "What would you say no to in your first six months?" | CASE | [generic] | The anti-pick, answered fast. Name one thing, give one reason, and say what you would revisit and when. Do not hedge it into a list; one clear no scores better than five | The role includes saying no to partners and to internal asks; time-boxed pressure tests whether you have a position. F1 is the requirement |

### D. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the £4M was counted." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Answer slot: say how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours, each in your own words. "Roughly" is yours; say how rough. If you do not know how it was counted, say so plainly. Name the weakest assumption before they do | A headline figure is the Prober's first target; F3 is the row. EXP because it tests whether the figure survives scrutiny |
| D2 | "Six to forty partners. What counted as a partner?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Answer slot: say what counted as a partner and what the count is sensitive to, in your own words; if there was no formal definition, say so plainly. Keep the number attached to partners. Name the assumption you would defend least | The second headline figure; F1 carries it. EXP because it tests the definition behind the number |
| D3 | "What's the difference between influenced revenue and a direct quota, and what would carrying one change?" | EXP | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Start with the plain acknowledgment: "I haven't carried a direct quota; my number was influenced revenue." Then your view of what accountability would change, as an expectation about the future and in your own words, never as something you have done. Do not describe quota-like experience unless it is quoted | This is Ross's territory and the commercial form of B1; F4 is the row. EXP because it tests whether you understand what you have not done |

### E. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)."; "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | A 90-second arc in your own words, only these beats: five years in transport consulting, bus and light rail network planning; nine years in partnerships, the last four on the ISV channel at a payments company; then why this role, which is your own answer to B3. Do not add titles, team sizes or outcomes | The biography question is scored even when it sounds friendly; F1 and F2 are the arc's two halves |
| E2 | "What interests you about how train operators handle scheduling?" | CO | [grounded] "She also attached the market report their strategy team circulated internally last quarter, which I've read." | Answer slot: say what you have actually read or seen, in your own words; you have read the report, so you can say what struck you in it. If scheduling depth is not yours, say so plainly and say what you would want to understand first. Do not bluff technical depth to a panel that owns the product | A casual question on the product's own subject is still scored; CO because it tests homework. F5 is the limit |

## 11. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How is success measured for this role in the first year: a direct number, an influenced target, or something else?" | You genuinely need to know, and it brings the commercial question out on your terms before Ross raises it |
| R2 | "How do you and Ross divide ownership of an operator relationship once it turns commercial, and what happens at the seam?" | It shows you think about the join between partnerships and commercial, and gives Ross a place to speak in his own territory |
| R3 | "What has an operator partnership delivered so far that you'd call the model, and what has one that didn't work taught you?" | It calibrates your POV against what they actually believe and invites a candid answer |
| R4 | "What would you most want a new partnerships manager to push back on you about?" | Asked of your future manager; it signals spine and tact together and tells you how she takes disagreement |
| R5 | "Which part of the strategy report do you think is least settled?" | It proves you read it and asks them to say where they are still deciding; no one else will ask it |
| R6 | "What would you want me doing with operators in my first 30 days?" | It shows a ramp mindset and answers B2's weakness directly |

## 13. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Carried a quota or owned a revenue number | Negative the candidate stated, F4 | The plain acknowledgment F4 gives: "I haven't carried a direct quota; my number was influenced revenue." No slot |
| Sold into rail | Negative the candidate stated, F5 | The plain acknowledgment F5 gives: "I haven't sold into rail specifically." No slot |
| Knows train operating companies from the inside | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation, not words for you: the material says bus and light rail network planning. B4's slot stays inside it |
| Booked, closed or owned the £4M | Inflated form of F3 | F3's quote at its own scope: "roughly £4M of influenced revenue". The limit is the pack's observation: the material says influenced, not booked. C2 and D1 stay inside it |
| Built the ISV channel or designed its partner programme | Inflated form of F1 | F1's quote at its own scope: "running the ISV channel", "took it from 6 partners to 40". The limit is the pack's observation: the material says running the channel, not building it. C2's slot stays inside it |

## 14. Sources

Provided documents: your message, including the recruiter's email as you quoted it. The strategy report the recruiter attached was not pasted or uploaded, so nothing in this pack comes from its content. No dossier was present.

Searches sent, all refused by this session's permissions, so none returned anything:

- "Kelverton Rail company values": refused
- "Kelverton Rail interview process partnerships manager": refused
- "Kelverton Rail scheduling software train operating companies strategy news": refused
- "Deepa VP Partnerships Kelverton Rail": refused
- "Ross Commercial Director Kelverton Rail": refused
- "Senior Partnerships Manager rail technology job description operator partnerships UK": refused

Research tier: L1 — searches 6 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Every call refused. Would have named published values and detected whether a values round exists; none is assumed, so there is no VAL bank or cheat sheet |
| 2. `Kelverton Rail interview process partnerships` | unavailable | Every call refused. The recruiter's own words establish this session's loop, so persona weights rest on them and not on an archetype; a documented loop could still add earlier or later rounds |
| 3. `Kelverton Rail strategy` / recent news | unavailable | Every call refused. Would have moved A4 and A5 and the thesis differentiation; those rows lean on your notes on the report instead |
| 4. `Deepa` and `Ross` at Kelverton Rail | unavailable | Both calls refused. Would have supplied an interviewer read and a reverse question tied to their career paths; the read is dropped |
| 5. representative `Senior Partnerships Manager` JD | unavailable | Every call refused. Would have supplied quoted requirements for the fit snapshot; the recruiter's words and two generic role-family rows stand in |

## 15. Upgrade menu

- The job description → the two `[generic]` requirement rows F4 and F5 become quoted requirements, and any mid-list requirement not yet covered gets its own JD question
- The strategy report's headline priorities, pasted → A4, A5 and the three theses become `[grounded]` instead of `[inferred]`, and a grounding brief section is added
- Your answers to the slots, written outside any drill (how the £4M was counted, what a partner was, which part was yours, why rail, your first 90 days) → D1, D2, C2, B3 and B2 move from answer slots to story-mapped rows
- A one-line email to the recruiter: does the role carry a revenue number, and does "operator partnerships" mean the train operating companies Kelverton sells to → settles F4 and the assumption in section 5
- Deepa's and Ross's surnames or public profiles → an interviewer read, tuned persona weights and a reverse question tied to each one's own path
- Web search enabled for this session → values, loop structure, recent strategy and interviewer footprint, all currently unavailable
- A `tuesday-dossier.md` from an earlier assessment of this role → verified evidence and a named highest-ROI objection instead of an inferred one
