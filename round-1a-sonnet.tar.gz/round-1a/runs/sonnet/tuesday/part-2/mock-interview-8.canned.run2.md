The prep pack is written and saved. I'm sending the file now, then I'll give you the summary.
Dara, your prep pack is saved as `Ashgrove-Credit-Union_member-experience-lead_interview_pack.md`. I built it as three mini-packs, one per round on 26 November. The recruiter's email gave me the structure, and it names roles but no people, so there is no interviewer read.

The pack has:
- a shared fit snapshot of the JD requirements against your own words
- a requirement-coverage table
- persona weights and a question bank for each round, with reverse questions
- a values cheat sheet for the panel round
- a list of claims the pack won't coach

The highest-value prep is **D1**: "You haven't worked in a contact centre. How would you own the complaints process there?" The answer is to say the limit first in your own words. Then give what you did handle, the branch's formal complaints log. Then give a plan for learning the contact-centre side. Hold that through three follow-ups without adding anything.

Where your material was silent, the pack gives you slots to fill in your own words, not stories. That covers whether the log was "regulated", what your spreadsheet counted, whether it was Excel, and any work with digital teams or coaching supervisors. I ran no web research, because your pasted values, the strategy points, the recruiter's email and the JD already cover what a search could have added.

I can play the Head of Member Services on D1 and push on it with follow-ups. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed. And if you want the pack as a Word document, say so and I'll convert it.

Did the recruiter say whether the escalation case comes in advance or on the day? The answer reshapes the three practice cases in the panel round (G1 to G3).

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Ashgrove-Credit-Union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Loop: three rounds on 26 November 2026, built in loop mode from the recruiter's email.

| Round | Who | Length | Relationship | What the recruiter said |
|---|---|---|---|---|
| 1 | The recruiter | 30 minutes | Recruiter screen | A conversation |
| 2 | Head of Member Services | 45 minutes | Your future manager | Mostly behavioural |
| 3 | Panel of two branch managers | 60 minutes | Panel, cross-functional | Includes a 20-minute case on a complaint escalation; also the values round, scored against the four values |

No interviewer names are assigned beyond these roles, so there is no interviewer read in this pack.

## How to use this pack

- Personas are how a question is asked. Types are what it is scoring. Every question carries both a persona (its bank) and a type tag.
- Type key: VAL is behavioural or values alignment, whether your past behaviour shows the published values. EXP is a deep-dive into your own work, what was actually yours. JD is a stated requirement of the role, including its gaps. CO is company and strategy knowledge. CASE is a live problem from the role.
- Provenance labels: grounded means traceable to something you or Ashgrove supplied. Inferred means derived from a reasonable extension, with the derivation named. Generic means a pattern with no claim about Ashgrove or about you.
- Guidance is scaffolding, not a script. Where a cell says Answer slot, it is an instruction for the interview, not a question for this conversation: answer whichever branch is true, in your own words.
- Every sentence about your past comes from your own words, quoted. Where your material is silent, the pack gives a slot, not a story.

## Fit snapshot (shared by all three rounds)

Requirements are quoted from the JD you supplied. Evidence is your own words and nothing else.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says the branch's log, not the process across branches, with nothing inspected behind it, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what happened to a complaint after it was logged likely. If any step after the log was yours to set, say which and how you decided, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the log you handled |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [inferred] | discovery | Your material says a monthly complaints spreadsheet, not what it counted, so the words stay at "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names volumes and resolution times, so expect a probe on what the sheet counted. If it counted either, say which and how, in your own words; if it counted neither, say so plainly and stay with the sheet you built |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | low | [inferred] | discovery | Your word is spreadsheet, not Excel, so the pack does not say Excel for you. Answer slot: if the sheet was in Excel, say so in your own words; if it was another tool, or you are less sure of Excel, say so plainly and stay with the sheet you built |
| F5 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | The quote already carries the years and the title, in other terms than the JD. Lead with it as it stands: "six years in retail banking, the last three as a branch supervisor." Expect a probe on what the first three years held, and answer in your own words |
| F6 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | low | [inferred] | discovery | Your material says a formal log, not what rules it was kept under. Answer slot: the JD says regulated, so expect a probe on what governed the log. If it was kept under external or regulatory rules, say which, in your own words; if it was an internal log only, or you are unsure what applied, say so plainly and stay with the log you handled |
| F7 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your material says tellers and a script, not supervisors, and the words stay there: "I trained new tellers on our escalation script." Answer slot: if you have ever helped another supervisor through an escalation, say who and how, in your own words; if you have not, or there was no such step, say so plainly and stay with the tellers you trained |
| F8 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not show this either way. Answer slot: if you have worked with any digital team, say with whom and on what, in your own words; if not, say so plainly and say how you would approach a journey so that no member has to ask twice |
| F9 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Then how you would prepare for it, said as a plan and never as a past. Never a claim to senior presenting |

## Requirement-coverage line

| JD requirement | Questions that cover it |
|---|---|
| Own the member complaints process end to end across branches and the contact centre | B1, D1, D2, G2 |
| Report monthly on complaint volumes and resolution times | E3 |
| Coach branch supervisors on escalations | D3, H3 |
| Work with digital teams on self-service journeys | E2, J2 |
| 4+ years in financial-services customer operations | A1 |
| Experience handling regulated complaints | D4, G1 |
| Confident presenting to senior leaders | B2, C4, J1 |
| Comfortable with Excel reporting | E3 |
| Headline metrics on your CV | — none, because you gave no figure, so there is no defend-the-number question |

## Grounding brief

From the 2026 strategy brief the recruiter sent you (published July 2026) and the JD you supplied. The pack reads nothing further into either.

| Item | What it says | Source | Provenance | Where it is used |
|---|---|---|---|---|
| Digital shift | Move 40% of member service to digital channels by 2028 | Strategy brief, as you summarised it | [grounded] | A7, E2, J2 |
| Branch network | Consolidate eight branches into five hubs over 2027 | Strategy brief | [grounded] | A7, E1, G3, R3 reverse questions |
| New product | Launch a small-business lending product in Q1 2027 | Strategy brief | [grounded] | G1 |
| Competitive frame | The main competitive pressure is app-only banks | Strategy brief | [grounded] | A7, E2 |
| Organisation | Member-owned, about 900 staff | JD | [grounded] | A2 |

---

# Round 1: Recruiter screen (30 minutes)

## Persona table, round 1

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly opener, logistics, motivation | High: the recruiter-screen prior is Conversational plus a light Skeptic, and the logistics questions arrive in a friendly register | Pre-script the 90-second arc; treat every casual question as scored; never answer no questions to the reverse-question slot |
| Skeptic (light) | Knockout checks and consistency on the two stated limits | Medium: the JD asks for the contact centre and for senior presenting, and your own message names both as gaps | Say each limit first, in your own words, then the plan |

## Bank A: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" "I handled the branch's formal complaints log" "I built the monthly complaints spreadsheet our regional manager uses" | A 90-second arc on the three beats the quotes state: six years in retail banking, the last three as a branch supervisor; the branch's formal complaints log you handled; the monthly complaints spreadsheet you built that your regional manager uses. Tell them in your own words and close on why complaints work is the next step, which only you can supply | F5 carries the years, F1 and F3 the complaints work; EXP because it tests what was actually yours, and the biography question is the likeliest opener |
| A2 | "Why this role, and why Ashgrove?" | CO | [grounded] | Choose one of the four published values by name that matches a reason you actually hold, say the reason in your own words, and tie it to what the JD says the role does. The question needs no claim about your past, so the guidance makes none. If no one value fits honestly, say so plainly and name the part of the JD that does | Motivation consistency is the recruiter's main scored item; CO because it tests homework on what Ashgrove says about itself |
| A3 | "What is prompting you to look at a move now?" | EXP | [generic] | Logistics slot: give your actual reason, in your own words. Keep it about what you are moving toward, and say plainly if there is more than one reason | Reason for leaving is one of the four recruiter-screen logistics; EXP because it tests whether your story is consistent |
| A4 | "What are your salary expectations?" | JD | [generic] | Logistics slot: give your own number, or ask for the role's band first. Do not state a figure you have not decided on | Pay is a recruiter-screen logistics item; JD because it concerns the listed job's terms |
| A5 | "What is your notice period?" | JD | [generic] | Logistics slot: give your actual notice period, and say plainly if it can be shortened | Notice is a recruiter-screen logistics item; JD because it concerns the listed job's terms |
| A6 | "Where and how often can you work? The role spans branches and the contact centre." | JD | [generic] | Logistics slot: give your actual constraints on location and days, in your own words. The JD does not say where the role is based, so asking the recruiter is fine | Location is a recruiter-screen logistics item; JD because it concerns the listed job's terms |
| A7 | "What do you know about where Ashgrove is heading?" | CO | [grounded] | Pick one strategy point from the brief, such as the move from eight branches to five hubs over 2027 or the 40% digital target by 2028, say what it means for how members would experience a complaint, and phrase what you do not know as a question you would ask. Do not claim knowledge beyond the brief | A CO question grounded in the current strategy; recruiters score whether you read what they sent you |

## Bank B: Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" "I've never presented to anyone above regional level" | Choose one and say it first, in the quote's own terms: "I haven't worked in a contact centre" or "I've never presented to anyone above regional level." Then say how you would close it, as a plan. Add nothing to either limit; the choice of which to lead with is yours | F2 and F9 are limits you have stated; the recruiter will reach for them and a calm, named limit reads as self-awareness |
| B2 | "The role reports monthly to senior leaders. Who have you presented to?" | JD | [grounded] "I've never presented to anyone above regional level" "I built the monthly complaints spreadsheet our regional manager uses" | Say it plainly: "I've never presented to anyone above regional level." Then the nearest thing your material carries, at its scope: the monthly complaints spreadsheet you built that your regional manager uses. Then how you would prepare for a first senior presentation, as a plan | F9 is a stated limit and F3 the nearest evidence; JD because it scores the stated requirement |

## Reverse questions, round 1

| # | Question to ask | Why it lands |
|---|---|---|
| R1.1 | "Is the escalation case in the panel round something I will see in advance, or on the day, and in what format?" | Un-researchable and it reshapes your prep; a recruiter can usually answer in one line |
| R1.2 | "What does the Head of Member Services most want this role to change in its first six months?" | Shows you think about the outcome, not only the title |
| R1.3 | "How are the eight branches becoming five hubs expected to affect the complaints process?" | Ties to the strategy brief the recruiter sent you, so it signals you read it |
| R1.4 | "Is there anything in my background you would want me to address before I meet the Head of Member Services?" | Invites the objection early, so you hear it before round 2 |
| R1.5 | "What does the panel's values scoring look like, and what do the branch managers care about most?" | The recruiter knows how the panel scores, and the answer sharpens round 3 |

---

# Round 2: Head of Member Services, your future manager (45 minutes)

## Persona table, round 2

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "Tell me about a time" scenarios; the recruiter says this round is mostly behavioural | High: the recruiter's own words, and Ashgrove's published values give the themes | Where a quoted sentence of yours carries a story, map it; where none does, choose an instance against stated criteria; say plainly if none comes to mind |
| Skeptic | Probes the gaps a manager is buying around | High: the hiring-manager prior is Case plus Skeptic, and your own message names the contact centre and senior presenting as gaps | Rehearse the single most predictable objection until it is boring; say the limit first |
| Case / Strategist | Live problems from the role's roadmap | Medium: the hiring-manager prior includes it, lowered because the recruiter said mostly behavioural | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |

## Bank C: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you put a member ahead of an internal target." | VAL | [grounded] | Open prompt on Members First, Always. Selection scaffold: choose an instance with a named stake, a moment you chose the member's side, and a relationship still intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The first published value, and the persona stem for the customer-over-metric question; the pack supplies no instance because none of your sentences carries one |
| C2 | "Tell me about a time you had to explain something to a member more than once." | VAL | [grounded] | Open prompt on Plain Words. Selection scaffold: choose an instance where the second explanation taught you something about the first, and say what changed in how you explained it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The second published value; the theme comes from the value's own wording, so a candidate who cannot give an instance should say how they would handle it |
| C3 | "Tell me about a complaint you kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Open prompt on Own the Fix. The log you handled is where to look for the instance, nothing more: it carries no particular complaint. Selection scaffold: choose one you saw through to its end, and say what you personally did at each hand-off. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The fourth published value, and the theme closest to the complaints role; F1 is the quote the instance would come from |
| C4 | "Tell me about a time you delivered an unpopular truth to someone senior." | VAL | [generic] | Open prompt from the Values persona stem. Selection scaffold: choose an instance where the truth landed and the relationship held. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Do not use a regional-level instance to imply senior presenting | Connects to the senior-leaders requirement without asserting senior experience; F9 is the stated limit |

## Bank D: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You haven't worked in a contact centre. How would you own the complaints process there?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log" | The highest-ROI rehearsal in this pack. Say the limit first, in your words: "I haven't worked in a contact centre." Then the nearest thing your material carries, at its scope: "I handled the branch's formal complaints log." Then a plan, said as a plan: what you would want to learn first about how complaints reach and leave the contact centre, and from whom. Hold through three follow-ups by returning to the limit, the log and the plan, never by adding to them. Likely follow-ups: how long would that take; what if the contact-centre team resists a branch supervisor's view; what would you do in week one. For the last, concede in specific words: "That is a real gap for me, and this is how I would close it." Never imply contact-centre work | F2 is the limit you stated and the JD's own sentence puts the contact centre in the scope of the role, so this objection arrives in some form; JD because it scores the stated requirement. Deepest rehearsal because it is the biggest gap and the one a manager is most likely to press |
| D2 | "The JD says end to end across branches. What part of the process have you owned yourself?" | JD | [grounded] "I handled the branch's formal complaints log" | Hold only what the quote carries: "I handled the branch's formal complaints log." Answer slot: if any step after the log was yours to set, say which and how you decided, in your own words; if there was no such step, or it was not yours, say so plainly and describe how you handled the log. Hold through two follow-ups by returning to the log, never by adding to it | F1 is where the end-to-end mandate presses hardest; JD because it scores the stated requirement |
| D3 | "The role coaches branch supervisors on escalations. What have you done in that line?" | JD | [grounded] "trained new tellers on our escalation script" | Start at the quote's scope: "I trained new tellers on our escalation script." Answer slot: if you have helped another supervisor through an escalation, say who and how, in your own words; if you have not, or there was no such step, say so plainly and stay with the tellers you trained | F7 is adjacent work, tellers not supervisors, and the JD raises the supervisor line |
| D4 | "The JD asks for experience handling regulated complaints. Tell me about yours." | JD | [inferred] "I handled the branch's formal complaints log" | Start with what you said: "I handled the branch's formal complaints log." Answer slot: if the log was kept under external or regulatory rules, say which, in your own words; if it was an internal log only, or you are unsure what applied, say so plainly and stay with the log you handled | F6 is thin because your word is formal, not regulated; the label is inferred because the probe is the JD's, not yours |

## Bank E: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Eight branches become five hubs over 2027. What happens to complaint handling in the year of the move?" | CASE | [grounded] | Clarify first: which branches, what members touch complaints in a move, who holds a complaint when a branch closes. Then objective, segmentation, approach, metrics, risks, thinking aloud. Challenge one premise respectfully: whether the move increases complaints is not given. Tie to Neighbours, Not Numbers. The question asks about no past, so the guidance makes no claim about yours | A CO or CASE question on the brief's most operational item; it is the one most likely to be live on this manager's roadmap |
| E2 | "The strategy moves 40% of member service to digital by 2028. Where do complaints sit in that?" | CASE | [grounded] | Clarify what counts as service and which complaints suit self-service. Structure: members who want to raise it themselves, members who need a person, the handoff between them. Use Plain Words as your test: if a member needs it explained twice, the journey was written wrong. Mention app-only banks as the pressure only as context | The brief's digital target and the JD's self-service line together; CASE because it is a live design problem |
| E3 | "Walk me through your first monthly report to me on complaint volumes and resolution times." | CASE | [inferred] "I built the monthly complaints spreadsheet our regional manager uses" | Open with what you said: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if the sheet counted volumes or resolution times, say which and how, in your own words; if it counted neither, say so plainly. On Excel, if the sheet was in Excel, say so; if it was another tool, name it plainly. Then structure the report aloud: ask who reads it and what they decide, how complaint and resolved are defined, then the layout. Name the assumption you would defend least | F3 and F4 are discovery rows; CASE because the report is a live design, JD because it covers the reporting and Excel lines |

## Reverse questions, round 2

| # | Question to ask | Why it lands |
|---|---|---|
| R2.1 | "What would a good first quarter look like in this role, and who should I meet first?" | Shows you plan a ramp, which answers the contact-centre gap before it is raised again |
| R2.2 | "How are complaint volumes and resolution times reported to senior leaders today, and who reads them?" | Shows you think about the audience, which is the part of the role you have not done |
| R2.3 | "Where does contact-centre complaint handling sit today, compared with the branches?" | Turns the biggest gap into a collaborative question, not a defence |
| R2.4 | "With 40% of member service moving to digital by 2028, what should a self-service complaint journey never do?" | Ties to the brief and the Plain Words value in one question |
| R2.5 | "What do the digital teams most need from this role?" | Opens the digital requirement, where your material is silent, as a partnership question |

---

# Round 3: Panel of two branch managers (60 minutes: values round and a 20-minute escalation case)

## Persona table, round 3

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scored against the four values, by managers from outside your function | Highest: the recruiter says the panel is the values round and scores against the four values, a loop source that documents it | Map a story to each value where a quoted sentence carries one, a selection scaffold where none does; we for context, I for contribution |
| Case / Strategist | The 20-minute escalation case | High: the recruiter's email documents it | Clarify, objective, segmentation, approach, metrics, risks, thinking aloud; challenge one premise respectfully |
| Peer Evaluator | Seams between branches and the complaints role; what they get from you | Medium: branch managers sit beside the role and their supervisors are the ones you would coach | Reciprocity framing; propose seam principles, not claims to know the seam |
| Skeptic (light) | Probes on senior presenting and digital | Medium: both are gaps in your own message or silent in it | Say each limit first, then the plan |

## Bank F: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Members First, Always: tell us about a time you decided from the member's side of the counter." | VAL | [grounded] | Open prompt on the value. Selection scaffold: choose an instance where the member's view and the easy internal answer differed, and say what you decided and why. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The first published value; no quoted sentence of yours carries a story for it |
| F2 | "Plain Words: tell us about a time you made something clearer for a member or a colleague." | VAL | [grounded] "trained new tellers on our escalation script" | Start with the quote's scope: "I trained new tellers on our escalation script." Answer slot: the value is about wording that had to be explained twice. If you reworded or simplified any of what you trained on, say what and why, in your own words; if you did not, say so plainly and stay with the training | F7's quote is the closest you have to this value, and it says training, not rewording |
| F3 | "Neighbours, Not Numbers: tell us about a time the figures and what you knew about a branch's members pointed different ways." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Open prompt on the value. The spreadsheet is the place to look and carries no such instance. Selection scaffold: choose an instance where you acted on what you knew about the members rather than the figure alone. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Expect the tension: this role reports numbers monthly | F3 is a monthly numbers task set against a value that says numbers are not the point; the panel may press it |
| F4 | "Own the Fix: tell us about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Open prompt on the value. The log is where to look for the instance and carries no particular problem. Selection scaffold: choose one you saw through, and say what you personally did at each hand-off. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The fourth published value and the closest to the complaints role |

## Values cheat sheet

Value names are as published on the page you copied from ashgrovecu.org/about/values.

| Value | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | F1 is the place to look: "I handled the branch's formal complaints log". It carries no particular story. Selection scaffold: choose an instance with a named stake and the member's side chosen; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Plain Words | If a member needs it explained twice, the wording failed | F7: "trained new tellers on our escalation script". It says training, not wording. Selection scaffold: choose an instance of making something clearer; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Neighbours, Not Numbers | Every branch is part of its town | F3: "I built the monthly complaints spreadsheet our regional manager uses". It is a numbers task. Selection scaffold: choose an instance where what you knew about a branch's members changed what you did; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log". It carries no particular problem. Selection scaffold: choose one you saw through; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

## Bank G: Case / Strategist (the 20-minute escalation case)

The cases below are practice cases written for this pack. They are not Ashgrove's case, whose format is not known.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "A member has complained three times about the same fee. A branch supervisor wants to settle it at the counter. The member now says they will close all their accounts, including a small-business account. What do you do?" | CASE | [generic] | Clarify first: what has been promised, who holds it now, what clock applies to a formal complaint here, what the member actually wants. Objective: the member's side of the counter, with the record intact. Then who owns it from now (Own the Fix), what the member hears and in what words (Plain Words), what is recorded and reported, and what the supervisor is coached on afterwards. Challenge one premise, such as whether settling at the counter is the right default. The question asks about no past, so the guidance makes no claim about yours | The panel's 20-minute escalation case is documented; the small-business detail echoes the Q1 2027 launch in the brief, as context only |
| G2 | "A complaint starts in the contact centre, is passed to a branch, and the member has now phoned three times. Who holds it?" | CASE | [generic] | The same structure, aimed at hand-offs: one named holder at any moment, a record the next person can read without asking the member again, and a rule for when it moves. The question needs no claim about your past, so the guidance makes none | Tests end to end across branches and the contact centre, the JD's own line, and F2 is the gap the panel may probe next |
| G3 | "One of the eight branches is due to close into a hub. A long-standing member raises a complaint about the move at the counter. What should the supervisor do, and what do you track?" | CASE | [grounded] | Clarify the member's specific complaint before structuring. Objective: the member stays, and the complaint is heard as a complaint, not as a protest. Approach: what the supervisor says and records, who follows up, how the move itself is separated from service failures in the reporting. Tie to Neighbours, Not Numbers. The question asks about no past | Ties the brief's eight-to-five consolidation to the panel of branch managers, who live it |

## Bank H: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Branches and the complaints lead sit side by side. Where is the seam, and what happens when we disagree about an escalation?" | JD | [generic] | Propose seam principles, not a claim to know the seam: who holds a complaint, when it moves, what the branch decides. For disagreement, a selection scaffold: choose an instance of disagreeing with a peer that showed spine and tact and left the relationship intact. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The peer persona stem; the panel members' day-to-day relationship with the role |
| H2 | "What would you need from my supervisors, and what would we get from you?" | JD | [generic] | Reciprocity: lead with what the branch gets, such as a clear route for escalations and plain feedback, then what you would need. The question asks about no past, so the guidance makes none | Peers price what a hire adds to their load before what it costs |
| H3 | "The role coaches branch supervisors on escalations. What have you done in that line?" | JD | [grounded] "trained new tellers on our escalation script" | At the quote's scope: "I trained new tellers on our escalation script." Answer slot: if you have helped another supervisor through an escalation, say who and how, in your own words; if you have not, or there was no such step, say so plainly and stay with the tellers you trained | The same limit as D3, asked by the people whose supervisors you would coach; F7 |

## Bank J: Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "You would present monthly to senior leaders. What is the most senior group you have presented to?" | JD | [grounded] "I've never presented to anyone above regional level" | Say it plainly: "I've never presented to anyone above regional level." Then how you would prepare for a first senior presentation, as a plan. Add nothing to the limit | F9 is a stated limit; JD because it scores the stated requirement |
| J2 | "The role works with digital teams on self-service journeys. What have you done with digital teams?" | JD | [grounded] | Answer slot: if you have worked with any digital team, say with whom and on what, in your own words; if not, say so plainly and say how you would approach a journey so no member has to ask twice. The guidance asserts nothing about your past | F8 has no evidence; the JD raises the line and the brief's 40% digital target makes it more likely |

## Reverse questions, round 3

| # | Question to ask | Why it lands |
|---|---|---|
| R3.1 | "When a branch escalation lands badly, what would you want a complaints lead to do differently from today?" | Gets the branch managers' real pain and shows you are asking from their side |
| R3.2 | "How should branch input shape complaint handling as eight branches become five hubs?" | Connects to Neighbours, Not Numbers and to the brief |
| R3.3 | "What could a new complaints lead do in the first month that would genuinely help your branch?" | Reciprocity question for a panel that sits beside the role |
| R3.4 | "Which of the four values do you see tested most in a complaint escalation, and what does it look like in your branch?" | Turns the values round into a conversation, and the answer tells you what the panel scores |
| R3.5 | "What would help your supervisors most from the complaints lead?" | Opens the coaching line, where your material carries tellers and not supervisors |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owns the complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says the branch's log, not the process across branches. D2's slot stays inside the log |
| Coached branch supervisors on escalations | Inflated form of F7 | F7's quote at its own scope: tellers and a script. The limit is the pack's observation: the material says tellers, not supervisors. D3 and H3's slots stay inside the tellers |
| Reported monthly on complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope. E3's slot asks only what the spreadsheet counted |
| Handled regulated complaints | Inflated form of F6 | F6's quote at its own scope: a formal log. D4's slot asks only what governed the log |
| Is experienced in Excel reporting | Inflated form of F4 | F4's quote at its own scope: a spreadsheet. E3's slot asks only which tool |
| Has worked in a contact centre | Negative you stated, F2, as "Never worked in a contact centre" | The plain acknowledgment F2 gives: "I haven't worked in a contact centre." No slot |
| Has presented above regional level | Negative you stated, F9, as "I've never presented to anyone above regional level" | The plain acknowledgment F9 gives: "I've never presented to anyone above regional level." No slot |

## Sources

Provided documents: the JD you pasted; the four published values you copied from ashgrovecu.org/about/values on 17 November 2026; the recruiter's email about the three rounds; the key points of the 2026 strategy brief Ashgrove published in July 2026, as the recruiter sent it; your own background, in your message. No tuesday-dossier.md was present.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The values page you pasted already fixes the four value names and their wording, so a search could not have moved the values cheat sheet |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | The recruiter's email names the three sessions, who runs each, the 20-minute case and the values scoring, which fixes the loop structure and the persona weights |
| 3. `Ashgrove Credit Union strategy` | skipped | The strategy points you supplied, from a brief published in July 2026, already fix the CO and CASE questions and the grounding brief |
| 4. `interviewer name Ashgrove Credit Union` | n/a | No interviewer name was given, only roles, so there was no query to form; the interviewer read is absent and the upgrade menu says what a name would unlock |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The recruiter's answer on whether the case comes in advance or on the day → G1 to G3 can be reshaped to that format, and a prep plan can be sized to it
- The brief itself, rather than the four points → the grounding brief and the CO and CASE questions can cite the brief's own wording and numbers
- The names of the Head of Member Services and the two branch managers → an interviewer read, persona weights tuned to each public footprint, and a reverse question tied to each person's path
- Your CV or a longer account of the first three years of your six → F5's presentation gap and F1 and F6's discovery rows can be upgraded from your own words
- What the monthly complaints spreadsheet counted, and in which tool → F3 and F4 can move from discovery to a grounded answer, and E3 becomes a story map
- Anything you did on escalations beyond training tellers → F7 and D3 and H3 can become a story map
- A deeper research pass, up to 6 more searches and 2 more fetches and several more minutes, covering Ashgrove's strategy and recent organisation context → a fuller grounding brief and sharper CO questions; say the word and I will run it
- The hours you have before 26 November → a prep triage that puts the few highest-ROI items in order, with everything else marked as insurance
- tuesday-dossier.md, if you already hold one → the gaps and objections it records would sharpen the guidance cells and the prohibited list
