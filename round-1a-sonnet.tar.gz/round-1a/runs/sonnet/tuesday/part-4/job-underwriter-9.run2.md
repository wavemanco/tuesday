I've read the playbook and I'm now running the research it calls for. That's checking that Marrowgate Housing exists as described, and comparing the pay band for the role.
**Yes, what they've asked for is routine at this stage (RR1). Status: `conditional_go`.** Bank details, PPS number and a passport scan, asked for after a written offer and sent through a portal, is normal onboarding. The thing to confirm is that the portal really is theirs. Web search was refused in this session, so I could not check that Marrowgate Housing exists as described. Everything below comes from what you pasted.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Hybrid, two days in Limerick office), R2 (Salary €38,000–€42,000), R3 (Right to work in Ireland)
- `must_have`: direct: R4, R6, R7 · adjacent: R8 (Monthly payroll for 240 staff) · unclear: R5 (Irish PAYE, PRSI and USC)
- `important`: direct: R9, R11 · unclear: R12 (Answer staff payroll queries) · absent: R10 (Pension changes)

R10 — you confirmed you've never done it, the main recoverable gap; R8 — adjacent on scale and cadence; R5 — Irish jurisdiction not stated in your background.

**Opportunity ledger.** The offer matches the ad on title, pay band, location and hybrid terms, and it followed two in-person interviews. What's still open is the portal's address (RR1), the contract terms (RR2) and the sender's domain (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Hybrid, two days in Limerick office), R2 (Salary €38,000–€42,000), R3 (Right to work in Ireland); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the portal address is confirmed through contact details you find yourself — RR1; (2) contract terms arrive in writing — RR2; (3) the sender's domain matches the employer's own site — RR3.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick | `[grounded]` ad header |
| Mandate | Monthly payroll for 240 staff, starters, leavers, pension changes, payroll-to-ledger reconciliation, staff queries | `[grounded]` ad |
| First-year outcomes | Not stated | `[grounded]` ad silence |
| Working pattern | Hybrid, two days a week in the Limerick office; reports to Declan Garvagh, Finance Manager | `[grounded]` ad and offer |
| Scope read | One payroll post running a 240-person monthly cycle, with no team mentioned | `[inferred]` from the ad's single-post wording |
| Market calibration | Not run. The €40,000 offer sits inside the ad's €38,000–€42,000 band | `[grounded]` offer and ad; no market sweep |
| Unknowns | Contract terms, probation, pension scheme, start date, who handles pension changes first | `[grounded]` offer silence |
| Contradictions | None between the ad and the offer on title, pay, location or hybrid terms | `[grounded]` both texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in Limerick office | hard_gate | unclear | none | hard_gate | You haven't stated a constraint on this. The offer matches the ad | `[grounded]` ad and offer; no constraint given | Q2 |
| R2 | Salary €38,000–€42,000 (offer €40,000) | hard_gate | unclear | none | hard_gate | No pay floor given. The offer is inside the band | `[grounded]` ad and offer | Q2 |
| R3 | Right to work in Ireland, inferred from the offer's passport check | hard_gate | unclear | none | hard_gate | The ad is silent. The offer says the check happens after acceptance. Your status isn't stated | `[inferred]` from the offer's right-to-work step | Q2 |
| R4 | 2+ years running payroll | must_have | direct | medium | none | 3 years of fortnightly payroll for 90 staff, self-reported with no artifact yet | `[grounded]` your background | none |
| R5 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | Your background doesn't say which jurisdiction the hotel group payroll ran in | `[grounded]` background silence | Q3 |
| R6 | Strong Excel | must_have | direct | medium | none | Daily use, pivot tables and XLOOKUP, self-reported | `[grounded]` your background | none |
| R7 | Payroll qualification or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024, with no document inspected | `[grounded]` your background | A copy of the certificate would raise this to high |
| R8 | Run monthly payroll for 240 staff | must_have | adjacent | medium | transferability | You ran fortnightly payroll for 90 staff. Limit: you haven't run a monthly cycle or this headcount | `[grounded]` background; `[inferred]` adjacency | G3 |
| R9 | Process starters and leavers | important | direct | medium | none | Stated in your background | `[grounded]` your background | none |
| R10 | Process pension changes | important | absent | none | capability | You've never done these yourself. Your manager handled them | `[grounded]` your statement | G1 |
| R11 | Monthly payroll-to-ledger reconciliation | important | direct | medium | none | Stated in your background | `[grounded]` your background | none |
| R12 | Answer staff payroll queries | important | unclear | low | discovery | Your background doesn't mention handling queries | `[grounded]` background silence | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pension changes (R10, important) | capability | You have no hands-on pension changes. You saw your manager do them | It is a named duty in the ad. It is likely to be on your first-month list | Closure path: ask for pension-change training or a handover in the first weeks; shadowing a change counts only as exposure | A scheme guide or procedure note from the new employer | `[grounded]` your statement; `[inferred]` that it lands early in the role |
| G2 | Irish PAYE, PRSI and USC (R5, must_have) | discovery | Jurisdiction of your hotel-group payroll isn't stated | The ad names these three | Filing Irish payroll returns; applying USC and PRSI classes; handling Revenue notices | Payslips with names redacted, or a Revenue filing summary | `[grounded]` background silence |
| G3 | Monthly cycle at 240 staff (R8, must_have) | transferability | Fortnightly at 90 staff, with monthly reconciliation | Cadence and scale are the stated differences | Month-end payroll for any group; peak periods at the hotel group | A sanitized payroll calendar | `[inferred]` adjacency derived from your background |
| G4 | Staff payroll queries (R12, important) | discovery | Not mentioned | The ad lists it as a duty | Payslip queries; leaver final-pay questions | Any query log or template | `[grounded]` background silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Bank, PPS and passport requested through an onboarding portal | unknown | — | "we will send you a link to our onboarding portal, where you add your bank details ... your PPS number ... and a scan of your passport" | The requests come after a written offer naming role, pay and manager, and after two in-person interviews, which fits routine onboarding. What isn't yet known is where the link will point | `[generic]` pattern for post-offer checks, not a claim about this employer | Can you confirm the portal's web address, and that the link will come from your own domain? Ask through contact details you find on the employer's own site | unresolved |
| RR2 | Offer gives no contract terms | unknown | — | "permanent post ... starting on a date we agree once your notice period ends" | Probation, notice, holiday and pension terms are not in the email | `[grounded]` offer silence | Will a written contract with probation, notice and pension terms come before I'm asked to upload documents? | unresolved |
| RR3 | Employer not independently checked from here | unknown | — | "Marrowgate Housing People Team" | Web search was refused, so existence and the sender's domain were not checked against the employer's own site. Two interviews at their office are strong evidence in your favour, and I'm relying on your account of them | `[grounded]` research refused; `[grounded]` your account of the interviews | Does the sender's domain match the one on your interview invitations and Marrowgate's own site? | unresolved |
| RR4 | Pay and role terms match the ad | positive_signal | — | "€40,000 a year ... Payroll Administrator ... two days a week in our Limerick office" | The offer repeats the ad's title, location and hybrid terms, with pay inside the stated band | `[grounded]` ad and offer | Who owns pension changes in the first month? | noted |

The address as you pasted it ends in `.example`, which is a placeholder domain that cannot be a real website. I'm taking it as something you swapped in. If it is literally what the email shows, tell me, because that changes RR3.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Send bank, PPS and passport details only through the portal, once its address is confirmed. Don't send them by email or chat, and don't paste them to me | See RR1 | `[generic]` sensible handling for sensitive documents | pending your approval |
| A2 | Within the five working days, ask for the contract terms in writing | See RR2 | `[grounded]` offer's five-day window | pending your approval |
| A3 | Ask who handles pension changes in your first month and what training there is | See R10, G1 | `[grounded]` R10 row | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search for Marrowgate Housing was refused. It would have moved RR3 and the contradictions row |
| 2. Role-family sweep | unavailable | The search for payroll administrator pay in Ireland was refused. It would have moved the market calibration row |
| 3. Hiring manager's public footprint | unavailable | The search on Declan Garvagh's professional background was refused. It would have moved the scope read |

## Dossier offer

If you'd like a saved copy of this assessment as `tuesday-dossier.md`, say so and I'll write it. I won't unless you ask.

## Upgrade menu

- Marrowgate's own website or careers page → RR3 closes.
- The portal link's address, once they send it → RR1 closes.
- Your constraints on pay, office days and right to work → R1 to R3 resolve.
- A copy of your Payroll Technician certificate → R7 to `high`.
- Permission to search the web (up to 5 searches and 2 fetches) → RR3 and the market calibration row.

## Questions

- **RR3:** Does the sender's domain match the one on your interview invitations, and is it the same one on Marrowgate's website? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
- **R1 to R3:** Do you have any firm limits on pay, office days or work eligibility that this offer must meet? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
- **G2:** Did your hotel-group payroll run under Irish PAYE, PRSI and USC, and who filed the returns? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.