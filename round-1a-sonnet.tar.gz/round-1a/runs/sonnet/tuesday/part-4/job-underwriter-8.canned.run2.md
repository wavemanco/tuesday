I searched once for Velloway Logistics's own careers page and got no results, so I'm finishing the assessment from what you've shared.

**No, I wouldn't go ahead. This job is very likely a scam, so don't send your details, don't pay anything, and don't deposit the cheque.** Several of the demands are ones a real employer doesn't make before an offer, or at all (RR1, RR2, RR3). Status: `no_go`.

**Fit ledger.**

- `hard_gate` — unclear: R5 (Pay of at least €30,000 a year)
- `must_have` — direct: R1, R2, R3
- `important` — unclear: R4 (Quiet place to work)

R1, R2, R3 — your background matches what the posting asks, self-reported; R5 — the posted range doesn't settle your floor.

**Opportunity ledger.** The role fails on its own terms. It asks for equipment money (RR1), a cheque deposit with a transfer onward (RR2), and bank, tax and ID details before any real offer (RR3). The whole process runs in chat (RR4), and the employer can't be established (RR5).

- **Hard gates:** none failed; unconfirmed: R5 (Pay of at least €30,000 a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`), RR5 (`severity: high`).
- **What would change this:** these requests would have to be withdrawn, and the employer would have to confirm the role through contact details you find yourself on its own site. Until then the status holds.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Velloway Logistics: not established. One search for its careers page returned nothing | `[grounded]` search returned no results |
| Mandate | Remote order processing, "no experience needed, full training provided" | `[grounded]` posting |
| Pay and hours | "up to €26 an hour plus commission", 15–30 hours a week. That is about €20,280 a year at 15 hours and €40,560 at 30, if the top rate were paid. Reaching €30,000 at €26 an hour needs about 22 hours a week | `[grounded]` posting figures; the arithmetic is mine |
| Process | Telegram only, "no calls or video interviews" | `[grounded]` posting |
| Contact | A `postmail.example` address given for "HR", not a company domain | `[grounded]` the message you pasted |
| Market calibration | Not run, so no market band for this role | `[generic]` no role-family sweep |
| Unknowns | Real employer, who the contract would be with, the commission rate, the pay actually offered | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Strong attention to detail | must_have | direct | medium | none | About 60 Zendesk tickets a day and a weekly team tracker. Self-reported, with no accuracy figure | `[grounded]` your background | none |
| R2 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel. Self-reported | `[grounded]` your background | none |
| R3 | Good written English | must_have | direct | medium | none | Written ticket work for three years, and this chat. No inspectable sample | `[grounded]` your background | none |
| R4 | A quiet place to work | important | unclear | none | discovery | You haven't said | `[grounded]` silence | moot given the decision |
| R5 | Pay of at least €30,000 a year (your constraint) | hard_gate | unclear | high | hard_gate | Confidence grades your own stated floor. Fit is `unclear` because "up to €26" and a 15–30 hour range don't settle it | `[grounded]` your statement and the posting | moot given the decision |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay against your floor (R5, hard_gate) | hard_gate | The posting gives only a ceiling rate and a wide hours range | It decides fit for you, but not whether the role is real | A written offer from an independently verified employer stating the rate and guaranteed hours | A contract naming the employer | `[grounded]` posting wording |
| G2 | Quiet workspace (R4, important) | discovery | Not stated | Minor, and only relevant if the role were real | Not applicable | None needed | `[grounded]` silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages" | This request is very likely a scam. Real employers don't ask new hires to pay for equipment | `[generic]` known pattern for requests of this shape | Ask the employer, through contact details you find on its own site: "Do you require new hires to pay for equipment?" Pay nothing while you check | confirmed |
| RR2 | Cheque deposit with onward transfer | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest" | This request is very likely a scam. Don't deposit the cheque. Paying out of a cheque before it has fully cleared is a known pattern in which you end up owing the money | `[generic]` known pattern | Ask the employer through contacts you found independently whether it sends cheques like this. Hold the deposit and any transfer. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call | confirmed |
| RR3 | Bank, tax and ID details before an offer | red_flag | high | "please send your IBAN, your PPS number and a clear photo of your passport" | These details were asked for at the screening stage, before any written offer naming the role and pay. That is a sign the message may not come from who it names | `[generic]` pattern | Ask the employer through independently found contacts: "Do you collect IBAN, PPS and passport before a written offer?" Send none of them meanwhile | confirmed |
| RR4 | Process run wholly in chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | Interviews and the offer happen only in chat, so nothing lets you check who you're dealing with | `[generic]` pattern | Can I speak to the hiring manager by phone or video, arranged through your company's own site? | confirmed |
| RR5 | Employer not established, with off-domain contact | risk_signal | high | "Velloway Logistics"; "velloway.hr@postmail.example" | The entity may be too new to have a footprint, or the posting may not represent a real hiring employer. These possibilities are not ranked | `[generic]` pattern, not a claim about this one. `[grounded]` one search returned nothing | Can you point me to this role on your own careers site, and who I'd be interviewing with? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Send nothing further: no IBAN, PPS number or passport photo, no €349, no cheque deposit or transfer. I haven't used or repeated your IBAN, and it isn't needed for this assessment | see RR1, RR2, RR3 | `[grounded]` the messages | pending your approval |
| P2 | If you still want to check, find the company's own website and contact details yourself, and ask there whether this role and these requests are real | see RR5 | `[grounded]` register | pending your approval |
| P3 | Keep the chat and the posting as a record, and tell the jobs site | A posting like this is worth reporting so others don't get caught | `[generic]` common practice | pending your approval |
| P4 | If the cheque arrives, don't lodge it. If you have already shared anything, contact your bank | see RR2, RR3 | `[generic]` common practice | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics careers Order Processing Coordinator" and got no results, so the employer is not established. It moved RR5 and role reality's Organization row |
| 2. Role-family sweep | skipped | RR1–RR3 already fix the decision, so a pay band could not change it. It would have fed the market calibration row |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I can save this as `tuesday-dossier.md` if you'd like a record.

**Upgrade menu**
- The live posting's link on the jobs site, or the company's own careers page → RR5 could close.
- The sender's real email domain, checked against the company's own site → RR3 and RR5 gain evidence.
- A deeper research pass (up to 5 more searches and 2 more fetches) → RR5 gets more evidence. It would not change the decision.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.