## Decision snapshot

**Yes, worth taking the call. Nothing in the posting or Ronan's message asks you for money, documents or personal details, though I couldn't verify Fernquay from here. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Salary €52,000–€60,000)
- `must_have` — direct: R3, R4, R5, R6
- `important` — adjacent: R7 (Own the booking flow end to end), R8 (First designer, no design peer)

R8 — the real stretch, a first-designer seat against never having been the only designer; R7 — your checkout redesign bridges it, its limit named; R2 — waiting on your pay floor.

**Opportunity ledger.** Plausibly a small real company, but unverified from here (RR1). The WhatsApp contact reads as ordinary scheduling, with the invite-email check still open (RR2). The equity terms and design support are unstated (RR3, RR5). One entry runs the other way: the pay and scope are stated plainly (RR4).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Fernquay verifies as a real company and the invite email comes from its own domain — RR1, RR2; (2) the salary clears your floor — R2; (3) the equity terms and design support check out on the call — RR3, RR5.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: six people in Galway, booking software for sea-kayak and surf schools | `[grounded]` posting |
| Mandate | First designer; own the booking flow end to end, run research calls with school owners, ship alongside two engineers, work most closely with co-founder Ronan Kehoe | `[grounded]` posting |
| Working pattern | Hybrid, two days a week in the Galway office | `[grounded]` posting |
| Compensation | €52,000–€60,000 plus 0.5–1% equity; vesting, share class and strike terms not stated | `[grounded]` posting |
| Scope read | A broad one-person remit (design, research, delivery) with no design peer named | `[inferred]` from "first designer" against the list of duties |
| Market calibration | Not established: no search ran, and I won't give a market band from memory | — |
| Unknowns | Contract type; who reviews design work; what success looks like in year one; equity terms | `[grounded]` posting silent on each |
| Contradictions | None visible between the posting and Ronan's message: he is named as co-founder in the posting and signs as Ronan from Fernquay | `[grounded]` both texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week at the Galway office | hard_gate | direct | medium | none | You live in Galway, so the days are feasible. You haven't said whether you want them, and your residence is your own statement with nothing to inspect | `[grounded]` your message | Confirm in G3 |
| R2 | Salary €52,000–€60,000 against your pay floor | hard_gate | unclear | none | hard_gate | You haven't stated a floor, so the pay term can't be checked | `[grounded]` posting states the band, you've stated no floor | G3 |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company, self-reported with no artifact yet | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" is confirmed but unproven. Your portfolio would be the inspectable artifact for a designer | `[grounded]` your background | Share a case-study link if you want this raised |
| R5 | You have run your own user research | must_have | direct | medium | none | Monthly usability sessions with customers. The posting's "research calls with school owners" may be more exploratory than usability testing, and it doesn't say | `[grounded]` your background; `[inferred]` the possible difference | none |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your background | none |
| R7 | Own the booking flow end to end | important | adjacent | medium | discovery | You redesigned checkout. Whether you owned the wider journey (search, availability, changes, cancellations) isn't stated | `[grounded]` checkout redesign; `[inferred]` the limit from silence on the rest | G1 |
| R8 | First designer, no design peer (implied) | important | adjacent | medium | transferability | You say you've never been the only designer. What carries over: self-run research and close work with engineers. Limit: no evidence of setting up process or tooling without a design lead. First designers usually do both | `[grounded]` your statement; `[generic]` what first-designer roles usually involve | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Booking-flow ownership beyond checkout (R7, important) | discovery | A checkout redesign is confirmed. The rest of the journey isn't covered either way | "End to end" is the posting's own phrase, so scope is the likeliest thing they'll probe | Owning availability or search screens; redesigning change and cancellation flows; working with payments or support on booking problems | The checkout case study Ronan mentioned, or a journey map | `[grounded]` your background is silent beyond checkout; `[generic]` interviewers probe scope claims |
| G2 | Working with no design lead (R8, important) | transferability | Self-run monthly sessions and an engineering squad, but always inside a design team | This is the clearest difference between your history and the seat | Recruiting your own research participants; setting your own research cadence; making design calls without a reviewer | A research plan or a session write-up | `[grounded]` your statement; `[inferred]` that this is the main stretch |
| G3 | Pay and office days against your limits (R1, R2, hard gates) | hard_gate | The band and the two days are known. Your floor and your view on the days are not | A gate the inputs don't settle stays open until you answer | Your minimum salary; the office days you'll accept | — | `[grounded]` posting terms; no constraints from you |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | low | "six people in Galway making booking software for sea-kayak and surf schools" | No search ran, so this is unchecked, not failed. A six-person firm may simply have a thin footprint | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site? | unresolved |
| RR2 | Contact on WhatsApp, with the invite sent by email | unknown | — | "I have emailed you a calendar invite with the video link" | Scheduling by chat is not a signal on its own. What matters is whether the invite email comes from a Fernquay address | `[generic]` small teams often schedule by chat; `[grounded]` the message asks only for a call | Which email address will the invite come from, and can you confirm it on your website? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "0.5–1% equity" | The percentage may come with vesting, cliff, share-class or dilution terms that change what it's worth | `[inferred]` from the posting's silence on terms | What are the vesting schedule, cliff and share class behind the equity? | unresolved |
| RR4 | Pay and scope stated plainly | positive_signal | — | "Salary €52,000–€60,000 plus 0.5–1% equity" | A stated band and a named co-founder are consistent with a real hiring process | `[grounded]` posting | What would move a candidate within that band? | noted |
| RR5 | First designer with no design support named | unknown | — | "You would be our first designer" | Design may be reviewed by founders or engineers, not by a designer | `[inferred]` from the posting's list of duties | Who reviews your design work, and how are design decisions made today? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, check that the invite email comes from a Fernquay address, and look up the company and the two interviewers' public professional profiles yourself | see RR1, RR2 | `[grounded]` register | pending your approval |
| A2 | Bring one real project, with its limits stated plainly: what was yours and what the team's | The posting says they'd rather see one messy real project than a polished deck | `[grounded]` posting | pending your approval |
| A3 | Ask RR1, RR3 and RR5 verbatim on the call | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were sent (company and booking software; company and careers) and both were refused. It would have settled RR1 and whether the posting is live |
| 2. Role-family sweep | unavailable | One search (first-designer salary and scope in Ireland) was refused. It would have given a market band for R2 and role reality |
| 3. Hiring manager's public footprint | unavailable | One search on Ronan Kehoe's public professional profile was refused. It would have informed scope and your positioning |

## Dossier offer

If you want a saved record of this, I can write it up as `tuesday-dossier.md`.

## Upgrade menu

- Your pay floor and view on the office days → R1 and R2 close.
- The invite email's sender address → RR2 closes.
- A link to Fernquay's site or careers page → RR1 closes.
- The checkout case study or a research write-up → R4, R5 and R7 can rise toward `high`.
- Permission for searches → targets 1–3 run and fill role reality's market calibration.

## Questions

G3 — What's the lowest salary you'd accept, and are two office days a week fine for you?

G1 — Beyond checkout, did you own other parts of the booking journey, such as availability, changes or cancellations? What was yours and what was the team's?

G2 — Have you set up research or design process yourself without a design lead, such as recruiting participants or deciding your own cadence?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.