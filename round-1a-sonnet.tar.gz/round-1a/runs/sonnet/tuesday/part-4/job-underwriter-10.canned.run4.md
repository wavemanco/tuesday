Checking whether Fernquay exists as described, then I'll run the salary check and look at Ronan's public profile.
**Yes, it's worth taking the call, and what I could check says Fernquay is legit. Status: `conditional_go`.** Your own constraints weren't given, so pay is unconfirmed against your floor (R8). The WhatsApp message is the one odd thing, and it asks for nothing except a call time (RR1).

## Decision snapshot

**Fit ledger.**

- `hard_gate` — direct: R9 · unclear: R8 (Pay €52,000–€60,000)
- `must_have` — direct: R1, R2, R3, R5 · adjacent: R6 (Own the booking flow end to end)
- `important` — adjacent: R7 (First designer, no design peers) · unclear: R4 (Research calls with school owners)

R6 — checkout is part of a booking flow, not all of it; R7 — a squad with engineers is not working solo; R4 — who your usability participants were is not stated.

**Opportunity ledger.** The employer and posting match the company's own pages (RR1), and the pay is stated and sits inside a market band (RR4). Still open: the equity terms (RR2), what support a first designer gets (RR3) and the company's financial footing (RR5).

- **Hard gates:** none failed (R9 `direct`); unconfirmed: R8 (Pay €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the pay meets your floor — R8; (2) the video invite arrives from a Fernquay address — RR1; (3) equity terms and design support are answered on the call — RR2, RR3.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: six people in Galway, makes Kelproster booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. Founded 2023 by Ronan Kehoe and Saoirse Doyle, and says it is funded by its customers | `[grounded]` Fernquay's own About page; self-description, not independently confirmed |
| Posting | A live careers page matches your posting: first design hire, hybrid with two days a week in Galway, €52,000–€60,000 plus equity, apply with one real project | `[grounded]` careers page fetched |
| Mandate | Own the booking flow end to end, run research calls with school owners, ship with two engineers, work closely with Ronan | `[grounded]` posting |
| Hiring contact | Ronan Kehoe is listed as co-founder and CEO, and before that was product lead at a Galway travel-software company for five years | `[grounded]` search result on his public profile page; not opened |
| Scope read | Booking flow, research and shipping in one seat is the usual breadth for a first design hire at a six-person company | `[generic]` role-family pattern |
| Market calibration | A survey of Irish product designers with 3 to 5 years' experience gives a median base of €57,000 and a middle range of €51,500 to €62,000. The posted range sits inside it. The band is a pattern, not Fernquay's offer | `[generic]` Tillerby 2026 salary report (n=520); `[grounded]` posting's own figures |
| Unknowns | Equity type and vesting, your salary floor, design support for a first designer, runway | — |
| Contradictions | None found between the posting and the careers page. The careers page snippet says "plus equity" without the 0.5–1% figure | `[grounded]` both pages read |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years of product design | must_have | direct | medium | none | You describe 4 years as a product designer. This is self-report with no artifact inspected yet, so `medium`. | `[grounded]` your background | none |
| R2 | Strong Figma | must_have | direct | medium | none | You use Figma daily. Self-reported; the case study you sent is the inspectable proof. | `[grounded]` your background | none |
| R3 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. Confirmed and specific, but no artifact inspected. | `[grounded]` your background | none |
| R4 | Run research calls with school owners | important | unclear | low | discovery | Your sessions were with customers. Whether those were business operators or end travellers is not stated. | `[grounded]` your background silent on participant type | Gap queue G1 |
| R5 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers. | `[grounded]` your background | none |
| R6 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned a checkout flow at a travel-booking company. Limit: checkout is one stage of a booking flow, and what else you owned is not stated. | `[grounded]` your background; `[inferred]` that end to end spans more than checkout | Gap queue G2 |
| R7 | Work as the first and only designer | important | adjacent | medium | transferability | Inferred from "first designer". You have never been the only designer. Squad work carries over; setting design direction with no peer does not. | `[inferred]` from the posting's "first designer"; `[grounded]` your statement | Gap queue G3 |
| R8 | Pay of €52,000–€60,000 | hard_gate | unclear | low | hard_gate | No floor was given, so whether the range meets it is unsettled. The range is inside the market band above. | `[grounded]` posting figures; `[generic]` band | Ask your floor (closing question) |
| R9 | Hybrid, two days a week in the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year, so the location term is met. Whether two fixed office days suit you is not stated. | `[grounded]` your background and posting | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Research with school owners (R4, important) | discovery | Monthly usability sessions with customers; participant type not stated | Interviewing business owners differs from testing with consumers, and this role includes both | Sessions with business or partner customers; calls with operators or suppliers; research that changed a roadmap decision | A research summary, a session guide, a readout deck | `[grounded]` background silent on participant type; `[generic]` that the two research settings differ |
| G2 | End-to-end booking flow (R6, must_have) | transferability | Checkout redesign confirmed; surrounding stages not stated | This is the role's central scope, and the bridge needs its limit named | Search, availability, basket, payment, confirmation or amendment screens you shaped | Before and after flows from the checkout case study | `[inferred]` bridge from checkout to a full flow |
| G3 | Being the only designer (R7, important) | transferability | The bridge: four years in a squad with engineers. The limit: always had design peers. The strengthener: a decision you made without design review | A first designer has no peer review. | n/a, no question asked | Your squad's design-system or review practices, if you contributed to them | `[inferred]` from your statement and the posting; `[generic]` that first-designer roles lack peer review |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Contact came by WhatsApp, not the posting's email route | unknown | — | Careers page: "Apply with one real project to jobs@fernquay.example"; message: "I have emailed you a calendar invite" | Small teams often schedule by chat; the message asks only for a call time and nothing else | `[generic]` small-team pattern; `[grounded]` the message asks for a call time only | Which address will the invite come from, and who besides Saoirse will be on the call? | unresolved |
| RR2 | Equity terms unstated | unknown | — | "0.5–1% equity" | The percentage may come with vesting, strike or dilution terms not yet shown | `[inferred]` from the posting giving a percentage and no terms | What is the equity type, vesting schedule and strike price, and what share of the company is the 0.5–1% of? | unresolved |
| RR3 | First designer with no design peer | risk_signal | low | "You would be our first designer" | Priorities, critique and growth may depend wholly on the two founders | `[inferred]` from "first designer" and the team size; `[generic]` that first-designer roles lack peers | Who gives design feedback day to day, and who sets design priorities? | unresolved |
| RR4 | Pay disclosed, scope concrete | positive_signal | — | "€52,000–€60,000 plus 0.5–1% equity" | Terms are transparent and sit inside the market band above | `[grounded]` posting; `[generic]` band | What would move you within the range? | noted |
| RR5 | Financial footing unverified | unknown | — | Fernquay's About page: "funded by its customers" | Customer funding is self-reported and runway is unknown | `[grounded]` self-reported on Fernquay's page; `[generic]` that revenue at small booking-software firms can be seasonal | What is the runway, and how is revenue spread across the year? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, check the invite email comes from a Fernquay address. If it doesn't, email jobs@fernquay.example from the careers page and ask | see RR1 | `[grounded]` careers page | pending your approval |
| A2 | Ask the RR1 to RR5 questions verbatim in the call | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A3 | Lead with the checkout redesign and say plainly what part of the flow was yours | see R6; Ronan's own background is travel software | `[grounded]` R6; `[grounded]` his public profile snippet | pending your approval |

If you want to rehearse the video call, mock-interview is the module for that.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway" and "Fernquay Product Designer Galway careers"; found "About Fernquay" (fernquay.example/about); fetched "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer). It established the employer and the live posting. Role reality's contradictions row: posting and careers page agree |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland startup first designer 3+ years equity", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Market calibration `[generic]`; the posted range sits inside the band |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe). Only the search snippet was read. It moved the plan's A3 positioning; the Saoirse (CTO) search was not run |

One caveat on the research: every page that confirms Fernquay is the company's own, apart from the profile page and the salary survey. I found no independent coverage in four searches, which is normal for a six-person firm but means "legit" rests on Fernquay's own pages.

I can save this as a `tuesday-dossier.md` for later turns if you'd like.

## Upgrade menu

- Your salary floor and any other must-haves (office days, start date) → R8 and R9 settle, and the hard-gates line stops saying checks are unknown.
- The checkout case study or a research summary → R2, R3, R6 and R4 can rise toward `high`.
- The invite's sender address → RR1 closes.
- The equity terms in writing → RR2 closes.
- A deeper research pass on Fernquay (funding, customers, leadership, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

Questions:

1. R8 — What is your salary floor, and does €52,000–€60,000 meet it?
2. G1 — In your monthly usability sessions, were the participants business customers or end travellers, and did you run the calls yourself?
3. G2 — Besides checkout, which stages of the booking flow did you personally design?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.