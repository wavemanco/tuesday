I've run four searches and found the company, the live posting and a salary benchmark. Next I'll fetch the careers page to check it matches what you were sent.
## Decision snapshot

**Yes, it looks legitimate and worth taking the call. Status: `conditional_go`.** The posting is live on Fernquay's own careers page (RR1). R3, R4, R5 and R6 are `direct`, R8 and R7 are `adjacent`, and pay (R2) waits on your floor. A WhatsApp message that only schedules a call is not a warning sign here, because nothing in it asks you for money, documents or personal details (RR2).

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Pay €52,000–€60,000 plus equity)
- `must_have` — direct: R3, R4, R5, R6 · adjacent: R8 (Own the booking flow end to end)
- `important` — adjacent: R7 (Working as the first and only designer)

R8 — a credible bridge from your checkout redesign, its limit named; R7 — squad work with engineers, no solo ownership yet; R2 — waiting on your pay floor.

**Opportunity ledger.** The employer matches its own pages (RR1) and the pay sits inside the surveyed band (RR5). Open items are the invite's origin (RR2), the equity terms (RR3), and a first-designer remit with no stated success measures (RR4).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Pay €52,000–€60,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your pay floor and the equity terms work for you — R2, RR3; (2) the invite's sender checks out against the domain on Fernquay's careers page — RR2; (3) you're comfortable being the only designer and the booking flow's scope fits what you've done — R7, R8, RR4.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: six people in Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle, funded by its customers. It makes booking software for sea-kayak, surf and sailing schools in Ireland and Scotland | `[grounded]` Fernquay "About" page (search result) |
| Mandate | First design hire: own the booking flow, run research calls with school owners, ship with two engineers, work most closely with Ronan | `[grounded]` the posting you pasted |
| Working pattern | Hybrid, two days a week in Galway. The careers page says the same | `[grounded]` posting and careers page (fetched) |
| Pay | €52,000–€60,000 plus 0.5–1% equity. The careers page gives the salary range and says only "plus equity", with no percentage | `[grounded]` posting and careers page |
| Scope read | A generalist remit: one designer covering flow design, research and delivery for a six-person company | `[inferred]` from "first designer" against the stated team size |
| Market calibration | The posted salary sits inside the middle half of one Ireland-wide survey for designers with 3–5 years (median €57,000, range €51,500–€62,000, n=520). That is a market pattern, not an offer to you, and the survey is not specific to Galway or start-ups. Equity is not in it | `[generic]` Tillerby 2026 survey, read from a search snippet; `[grounded]` posting for the posted figure |
| Hiring manager | Ronan Kehoe is a co-founder, shown on a profile as CEO, with five years before that as product lead at a Galway travel-software company. The About page names Saoirse Doyle as co-founder; "CTO" comes from the message and I did not find it confirmed | `[grounded]` About page and profile snippet (search results) |
| Unknowns | Equity terms, how success is measured, the process after this call, whether any design tooling or system exists | — |
| Contradictions | None material. The About page adds sailing schools and Scotland, which the posting doesn't mention. The equity percentage appears in your posting but not on the careers page | `[grounded]` posting against careers page and About page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week at the Galway office | hard_gate | direct | medium | none | You live in Galway, so the location term is met. You haven't said whether two fixed office days suit you, so the schedule side is a lead | `[grounded]` your message (prose background) | Q1 |
| R2 | Pay €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | No floor stated, so the gate is not settled. The band sits at the survey median for your experience, but equity's value is unknown | `[grounded]` posting, no stated floor; `[generic]` survey band | Q1 |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company, self-reported | `[grounded]` your message | none |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" is stated. "Strong" is a level, and a portfolio or file would be the inspectable proof | `[grounded]` your message | offer: portfolio link raises it |
| R5 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. The posting's calls are with school owners, a business audience, and your sessions' format and audience beyond "customers" are unstated. Medium until you say more | `[grounded]` your message | offer: a session plan or findings write-up |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your message | none |
| R7 | Working as the first and only designer | important | adjacent | low | transferability | Squad work gives you engineer collaboration. The limit is that you've never been the only designer, so no peer review, no design lead, and you set your own standards. This requirement is derived from the posting's "first designer" line | `[inferred]` from the posting line and your stated history | G1 |
| R8 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned a travel-booking company's checkout flow. Checkout is one stage of a booking flow, and how much of the stages around it you owned is unstated | `[grounded]` your message; `[inferred]` that checkout is one stage | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Sole-designer experience (R7, important) | transferability | Four years in a squad; you've never been the only designer | The posting makes you the first designer, so this is the likeliest thing the founders will probe | A feature you designed alone end to end; a freelance or side project; a stretch covering for a designer who left | A case study that names what you decided alone | `[grounded]` your message; `[generic]` that founders hiring a first designer tend to probe this |
| G2 | Scope beyond checkout (R8, must_have) | transferability | You owned the checkout redesign; the stages before and after it aren't described | "Booking flow end to end" is the posting's headline responsibility | Search or availability screens, booking changes or cancellations, confirmation emails, mobile flow | The checkout case study you already sent; before and after screens | `[grounded]` your message; `[inferred]` the headline status from the posting's wording |
| G3 | Your pay floor and office-day limits (R1, R2, hard_gate) | hard_gate | Neither is stated | Both are hard-gate terms and nothing else can settle them | Your minimum salary; how you'd value equity; any days you can't be in Galway | Nothing needed, only your statement | `[grounded]` no constraint given |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer, role and people match public pages | positive_signal | — | "Six people, based in Galway… Founded 2023 by Ronan Kehoe and Saoirse Doyle" | The company is real and small, and its thin online footprint fits a six-person firm founded in 2023 | `[grounded]` About page, careers page and profile snippet; `[inferred]` that the thin footprint is explained by size and age | Who else would I meet after this call, and what does the process look like from there? | noted |
| RR2 | Contact began on WhatsApp, invite sent by email | unknown | — | "I have emailed you a calendar invite with the video link" | Scheduling by chat is common at small firms. I haven't seen the invite's sender address or video link | `[inferred]` from the message and the posting's "small and informal" tone | Could you send the invite from your fernquay address, or tell me which address it comes from? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | Equity in a customer-funded company may have little near-term cash value, and vesting, cliff and share type are unstated | `[inferred]` from the posting's silence and the About page's "funded by its customers" | What are the vesting schedule, cliff and share type, and is the equity options or shares? | unresolved |
| RR4 | First designer, no stated success measures | risk_signal | low | "own the booking flow end to end" | With no design peer and no stated measures, scope could widen and "good" could be left undefined | `[inferred]` from the posting's silence on success measures | What would a good booking flow look like at six and twelve months, and who decides design priorities against engineering ones? | unresolved |
| RR5 | Pay stated and inside the surveyed band | positive_signal | — | "€52,000–€60,000" | The posted figure sits in the middle half of the surveyed range for your experience | `[grounded]` posting; `[generic]` Tillerby survey band | Where in this range would someone with four years' experience sit? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, check the invite's sender address ends in fernquay.example, the domain on the careers page, and that the video link goes to a mainstream video service | see RR2 | `[grounded]` careers page domain | pending your approval |
| A2 | Open with the checkout redesign at the Dublin travel-booking company, and state its scope as it was: the checkout flow | Ronan's background is product lead in travel software, so a booking-flow story is the nearest to his own | `[grounded]` your message and the profile snippet; `[inferred]` that this is the story he'll connect with | pending your approval |
| A3 | Describe your research as monthly usability sessions with customers, and say plainly whether you have interviewed business owners | The posting's calls are with school owners; see R5 | `[grounded]` your message | pending your approval |
| A4 | Prepare one honest answer on never having been the only designer: the squad evidence, then the limit | see R7, G1 | `[grounded]` your message | pending your approval |
| A5 | Ask RR3, RR4 and RR5's questions verbatim on the call | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway", which returned "About Fernquay" (fernquay.example/about), and "Fernquay product designer careers Galway". Fetched "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer). Moved RR1 and the contradictions row. The fetched page was a short summary, so I compared pay, hybrid pattern and the first-hire line, not the full posting |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland 2026 mid-level Dublin Galway startup", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report), read from the snippet only. Moved market calibration, R2's reasoning and RR5 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe), snippet only. Moved the hiring-manager row and A2 |

I'm happy to save this as a `tuesday-dossier.md` you can carry forward; just say so.

**Upgrade menu**

- Your pay floor and office-day limits → R1 and R2 settle, and the hard-gates line stops flagging constraints not given.
- Your portfolio or a Figma file → R4 toward `high`.
- The checkout case study you sent, or before and after screens → R8's scope question closes or narrows.
- A session plan or findings write-up from one of your usability sessions → R5 toward `high`.
- The invite's sender address → RR2 closes.
- The full posting as you received it → I could read only a short summary on the careers page, so this confirms the posting text itself.
- A deeper research pass on Fernquay (customers, funding, leadership, public reviews; up to 5 more searches and 2 more fetches) → strengthens RR1; say the word and it runs.
- Rehearsing the 45-minute call → the mock-interview module does that.

**Questions**

Q1 (G3) — What's the lowest salary you'd accept, how would you value the equity, and are two fixed office days in Galway workable for you?
Q2 (G1) — Have you ever been the only designer on a piece of work, such as a feature, a freelance job or a side project? What did you decide alone, and what happened?
Q3 (G2) — Did your checkout redesign touch the stages before or after checkout, such as search, changes or cancellations, and which were yours?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.