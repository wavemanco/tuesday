**Yes, it looks legitimate and worth taking the call, with the conditions below · `conditional_go`**

The employer checks out on every page I could reach, and the WhatsApp message asks nothing of you beyond a call time (RR1, RR6). I have no CV from you, so the fit side rests on your description of your background and counts as self-report until you add proof.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Salary €52,000–€60,000)
- `must_have` — direct: R3, R4, R5, R8 · adjacent: R6 (Own the booking flow end to end), R7 (Run research calls with school owners)
- `important` — adjacent: R9 (First designer, no design peers)

R6 — the checkout redesign bridges toward the whole flow, its limit named; R7 — customer usability sessions bridge toward owner interviews, one question open; R9 — never the only designer, the step this role asks.

**Opportunity ledger.** The employer is attributable and the posting is live on its own careers page (RR1), and the pay sits inside a market band (RR4). Open: a first-designer load with no design peer (RR2), equity terms (RR3), a customer-funded runway (RR5), and confirming the WhatsApp sender through the email invite (RR6).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the band meets your pay floor — R2; (2) the first-designer load is acceptable once you hear what is expected by month three and who reviews your work — RR2; (3) the calendar invite comes from a fernquay.example address — RR6.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, founded 2023 by Ronan Kehoe and Saoirse Doyle. It makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. Six people in Galway, funded by its customers | `[grounded]` About page, seen as a search result |
| Posting | The careers page matches your posting on role, hybrid two days in Galway and pay. It says "Apply with one real project" | `[grounded]` careers page, fetched |
| Mandate | First design hire: own the booking flow, run research calls with school owners, ship alongside two engineers | `[grounded]` posting |
| Hiring contact | Ronan Kehoe is co-founder and CEO, and was a product lead at a Galway travel-software company for five years before Fernquay. Nothing more was looked for | `[grounded]` profile, seen as a search result |
| Scope read | The role bundles design, research and delivery for one person. Ronan's travel-software background sits near your own travel-booking years | `[inferred]` from the posting's three duties against a six-person team, and from the profile against your background |
| Market calibration | Product designers with 3 to 5 years in Ireland: median base €57,000, interquartile range €51,500 to €62,000. The posted €52,000–€60,000 sits inside that range. This is a market band, not Fernquay's offer, and the survey is not specific to Galway or to booking software | `[generic]` Tillerby 2026 Ireland survey (n=520), seen as a search result; `[grounded]` posting for the band |
| Unknowns | Equity terms; whether Fernquay is profitable; who reviews design work; whether Saoirse's CTO title matches her listing as co-founder (the About page gives no title) | `[grounded]` About page and posting are silent on each |
| Contradictions | None between the posting, the careers page, the About page and the message | `[grounded]` careers page fetched; About page seen as a search result |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in the Galway office | hard_gate | direct | medium | none | You said you moved back to Galway last year. That is specific, but it is not a stated constraint, and nothing is inspectable | `[grounded]` your intro | none |
| R2 | Salary €52,000–€60,000 | hard_gate | unclear | none | hard_gate | The posting states the band, and you have not given a floor, so fit cannot be settled | `[grounded]` posting; no constraint stated | Ask your floor (closing question) |
| R3 | 3+ years of product design | must_have | direct | medium | none | You describe 4 years as a product designer. Self-report, with no CV inspected | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" shows use, and the strength is shown by the artifact. Your checkout case study may serve, but I have not seen it | `[grounded]` your background | Link a Figma file or the case study to raise it |
| R5 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. Whether that included discovery interviews is open (see R7) | `[grounded]` your background | none |
| R6 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned a travel-booking company's checkout flow. Limit: checkout is one part of a booking flow, and end-to-end ownership is wider | `[grounded]` your background; `[generic]` that a booking flow usually spans more stages than checkout | See G1 |
| R7 | Run research calls with school owners | must_have | adjacent | low | discovery | Usability sessions with customers are near this. I do not know who the customers were, who recruited them, or whether the sessions explored needs as well as testing screens. I took the lower band on that doubt | `[grounded]` your background; `[inferred]` that owner calls are partly exploratory | See G2 |
| R8 | Work directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your background | none |
| R9 | First designer, so no design peers to lean on | important | adjacent | low | transferability | You have never been the only designer. Your squad work bridges part of it. Limit: setting direction, critique and process alone is unexercised | `[grounded]` your statement; `[generic]` that sole-designer roles carry that load | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Booking-flow breadth (R6, must_have) | transferability | A checkout redesign. Nothing yet on search, availability, cancellation or confirmation | Ownership of the whole flow is the posting's first duty | Work on availability or date selection, rebooking or cancellation, or confirmation emails, even as part of the squad | A flow map, a before/after of any adjacent screen | `[grounded]` your summary; `[generic]` that those stages usually sit around checkout |
| G2 | Owner-style research (R7, must_have) | discovery | Monthly customer sessions, with no detail on who, how recruited, or whether they were exploratory | The posting names research calls with school owners | Interviews with business customers, or sessions where you set the questions and synthesised the findings | A discussion guide or synthesis note, sanitised | `[grounded]` your summary; `[inferred]` that owner calls lean exploratory |
| G3 | Sole-designer work (R9, important) | transferability | Squad work with engineers, always alongside other designers | You would set direction with no peer review | Times you made design decisions with no designer to check them, or set up a process or library | Any example of that | `[grounded]` your statement; `[generic]` that first-designer roles often add process-setting |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer attributable, posting live | positive_signal | — | "six people, based in Galway" | Fernquay exists as described and the role is on its own careers page | `[grounded]` About page, seen as a search result, and careers page, fetched | Beyond Ronan and Saoirse, who would I meet before an offer? | noted |
| RR2 | First-designer load | risk_signal | low | "You would be our first designer" | One person carries design, research and shipping with no peer review. This may be ordinary at this size | `[inferred]` from the posting's three duties; `[generic]` that first-designer roles at small firms commonly bundle these | What would you expect me to have shipped by month three, and who reviews my work? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "0.5–1% equity" | The range is given, but not vesting, options versus shares, or what the stake is based on. The firm is customer-funded, so there is no priced round to read from | `[grounded]` posting and About page; `[inferred]` from the silence | Is the equity options or shares, what is the vesting schedule, and how is the percentage calculated? | unresolved |
| RR4 | Pay inside the market band | positive_signal | — | "€52,000–€60,000" | The posted band is within the interquartile range for 3 to 5 years' experience | `[grounded]` posting; `[generic]` Tillerby band, seen as a search result | Where in the band would you expect me to land? | noted |
| RR5 | Customer-funded runway unknown | unknown | — | "funded by its customers" | Pay depends on revenue. The firm may be profitable, but nothing I found says | `[inferred]` from the funding line | Is Fernquay profitable, and how many schools pay today? | unresolved |
| RR6 | Contact moved to WhatsApp | unknown | — | "I have emailed you a calendar invite with the video link" | A founder at a six-person firm may simply be scheduling informally. The message asks only for a call time. Whether it came from Ronan can be checked via the invite | `[inferred]` from the message's purpose; `[generic]` that small firms often schedule by chat | Could you confirm the invite came from your fernquay.example address? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, check the invite's sender address is on fernquay.example, and that the video link is on a mainstream platform | see RR6 | `[grounded]` RR6 | pending your approval |
| A2 | Lead with what you said: you redesigned checkout and ran monthly usability sessions with customers. Say "checkout flow", not "booking flow", unless you touched more | see R6, R7 | `[grounded]` your summary | pending your approval |
| A3 | State plainly that you have not been the only designer, then give your nearest example (G3) | see R9 | `[grounded]` your statement | pending your approval |
| A4 | Bring one real project, rough edges included. Both the careers page and the posting ask for one | see R4 | `[grounded]` careers page and posting | pending your approval |
| Q1 | Ask the questions of RR2, RR3 and RR5 verbatim on the call | The register doubles as call preparation | `[grounded]` register | pending your approval |

If you want to rehearse the call with Ronan and Saoirse, mock-interview does that.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway", which returned "About Fernquay" (fernquay.example/about), and "Fernquay Product Designer Galway careers"; fetched "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer). Moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland startup mid-level 2026", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Moved market calibration and RR4 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe). Moved the hiring-contact row and the scope read |

I can save this as a `tuesday-dossier.md` if you want one for later.

**Upgrade menu**
- Your pay floor → R2 settles and the decision firms up.
- Your CV, or a link to the checkout case study or a Figma file → R4 can reach `high` and R3 gets checked against a document.
- A short description of your usability sessions (who, how recruited, what you asked) and any discussion guide → R5 and R7.
- Which other booking stages you touched besides checkout → R6.
- Any example of deciding alone, or setting up a process → R9.
- Fernquay's answers on equity, profitability and who reviews design → RR2, RR3 and RR5 close.
- A deeper diligence pass on Fernquay and its founders (up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**
- R2 — What is the lowest salary you would accept, and does the equity change that?
- G2 — In your monthly sessions, who were the customers, how were they recruited, and did you ever interview them about needs rather than only testing screens?
- G1 — Besides checkout, which other parts of the booking flow did you work on, and what did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.