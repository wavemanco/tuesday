**Worth your time? The first, yes: Duinvaart, `conditional_go`. The second, no: Kroonhaven, `no_go`, because B2, B3 and B5 (three must-haves) have no planning evidence.**

## Decision snapshot

**Duinvaart Cold Chain, Operations Analyst**

**Fit ledger.**

- `hard_gate` — unclear: A1 (Hybrid, three days Rotterdam office)
- `must_have` — direct: A2, A3, A4
- `important` — direct: A5a · adjacent: A6 (Route changes with depot managers) · unclear: A5b (Temperature compliance)
- `preferred` — adjacent: A7 (Dutch a plus)

A5b — cold-chain temperature work unproven; A6 — a credible bridge, its limit named.

**Opportunity ledger.** The employer is unverified (RA1) and the salary is not stated (RA2). The scope is concrete (RA3).

- **Hard gates:** none failed; unconfirmed: A1 (Hybrid, three days Rotterdam office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the Rotterdam schedule works for you (A1); (2) the employer and live posting verify (RA1); (3) temperature-compliance experience is claimed only if you confirm it (A5b).

**Kroonhaven Foods, Supply Planner**

**Fit ledger.**

- `hard_gate` — unclear: B1 (On-site in Utrecht)
- `must_have` — adjacent: B6 (Fluent Dutch) · unclear: B4 (Advanced Excel) · absent: B2 (3+ years FMCG planning), B3 (Own the 13-week supply plan), B5 (SAP IBP or similar)
- `important` — adjacent: B7 (Run the weekly S&OP meeting)

B2, B3, B5 — no planning evidence, a capability gap; B6 — conversational, not fluent; B7 — a bridge, limit named.

**Opportunity ledger.** The employer is unverified (RB1) and the salary is not stated (RB2).

- **Hard gates:** none failed; unconfirmed: B1 (On-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** B2, B3 and B5 would each need planning evidence you hold that I haven't seen.

## Role reality

| Role | Element | What it is | Provenance |
|---|---|---|---|
| Duinvaart | Organization | A refrigerated-fleet operator in Rotterdam, as the posting describes itself | `[grounded]` posting, not verified |
| Duinvaart | Mandate | Track on-time delivery and temperature compliance, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` posting |
| Duinvaart | Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` posting |
| Duinvaart | Scope read | One analyst covering reporting and depot liaison; no team, reporting line or decision rights stated | `[inferred]` from the responsibility list's silence on authority |
| Duinvaart | Unknowns | Salary, reporting line, where the temperature data comes from | `[grounded]` posting silent |
| Kroonhaven | Organization | A chilled ready-meals producer in Utrecht, as the posting describes itself | `[grounded]` posting, not verified |
| Kroonhaven | Mandate | Own the 13-week supply plan, balance capacity against forecast, run the weekly S&OP meeting | `[grounded]` posting |
| Kroonhaven | Working pattern | On-site in Utrecht | `[grounded]` posting |
| Kroonhaven | Scope read | An ownership role: "own" and "run" put the plan and the meeting with this post, but authority over production capacity is not stated | `[inferred]` from the posting's verbs against its silence on authority |
| Kroonhaven | Unknowns | Salary, reporting line, who attends the S&OP meeting | `[grounded]` posting silent |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| A1 | Hybrid, three days a week in the Rotterdam office | hard_gate | unclear | none | hard_gate | You have not stated your location or schedule limits, and your last employer was in Amsterdam, so whether this commute works is unsettled | `[grounded]` posting; no constraint given | Question A1 below |
| A2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier, specific but self-reported. Your CV was not provided, so whether it already says this is unchecked | `[grounded]` your background statement | Share your CV to check |
| A3 | Strong SQL | must_have | direct | medium | none | SQL daily, stated by you, with no artifact inspected | `[grounded]` your background statement | none |
| A4 | Power BI or Tableau | must_have | direct | medium | none | Power BI daily, including the on-time delivery dashboard your depot managers use | `[grounded]` your background statement | A sanitized dashboard screenshot would raise it to `high` |
| A5a | Track on-time delivery across the fleet | important | direct | medium | none | Your dashboard is on-time delivery reporting for a parcel fleet, not a refrigerated one | `[grounded]` your background statement | none |
| A5b | Track temperature compliance across a refrigerated fleet | important | unclear | none | discovery | Nothing you have said touches temperature or condition monitoring | `[grounded]` background silent | Question A5b below |
| A6 | Work with depot managers on route changes | important | adjacent | medium | transferability | You ran the weekly route-performance review and depot managers use your dashboard. Nothing says the review led to route changes | `[grounded]` your statement; limit named | Question A6 below |
| A7 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational Dutch is real but short of fluent; the posting asks only for a plus | `[grounded]` your statement | State it plainly as conversational |
| B1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | No location or commute constraint given | `[grounded]` posting; no constraint given | Ask only if you reopen this role |
| B2 | 3+ years supply or demand planning in FMCG | must_have | absent | none | capability | You confirmed you have never worked in planning, and the carrier is not FMCG | `[grounded]` your statement | Closure path in G3 |
| B3 | Own the 13-week supply plan, balancing capacity against forecast | must_have | absent | none | capability | Your route-performance work is analysis of delivered service, not a capacity-versus-forecast plan | `[grounded]` your statement | Closure path in G3 |
| B4 | Advanced Excel | must_have | unclear | none | discovery | Excel is not mentioned; SQL and Power BI do not stand in for it | `[grounded]` background silent | Ask only if you reopen this role |
| B5 | SAP IBP or a similar planning system | must_have | absent | none | capability | SQL and Power BI are reporting tools, not planning systems | `[grounded]` your statement | Closure path in G3 |
| B6 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational Dutch is the nearer neighbour, and the posting asks for fluent. How much of the S&OP work is in Dutch is not stated | `[grounded]` your statement and the posting | none |
| B7 | Run the weekly S&OP meeting | important | adjacent | medium | transferability | You ran a weekly route-performance review. S&OP is a cross-functional demand, supply and finance meeting, so that review is the bridge and its limit is the scope | `[grounded]` your statement; `[generic]` what S&OP usually covers | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Temperature compliance (A5b, important) | discovery | Your background is silent on temperature or condition monitoring | It is the cold-chain half of the first duty listed | Tracking late or damaged time-critical parcels; sensor or scan exceptions; compliance reports to a customer | A sanitized exception report or dashboard view | `[grounded]` silence; `[generic]` that this is what separates cold-chain from parcel analysis |
| G2 | Route changes with depot managers (A6, important) | transferability | You ran the weekly review; nothing says routes changed as a result | The posting's second responsibility is route changes | A review finding that led to a changed route, timetable or depot allocation | Sanitized review notes or an action log | `[grounded]` your statement; `[inferred]` that a concrete example would turn the bridge into evidence |
| G3 | Planning ownership, FMCG years and planning system (B2, B3, B5, must_have) | capability | No planning work in your history; the closest work is reporting and review | Together they are what the post is | Nothing in what you have said qualifies | None | `[grounded]` your statement; `[generic]` that analyst-level planning or S&OP support roles are the usual way into the function |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RA1 | Duinvaart not established from attributable sources | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RA2 | Salary not stated | unknown | — | The posting as pasted has no salary | The figure may be withheld or simply absent from the excerpt | `[grounded]` posting silent | What salary range is budgeted for this post? | unresolved |
| RA3 | Responsibilities and tools are named concretely | positive_signal | — | "build weekly dashboards in Power BI, and work with depot managers on route changes" | The day-to-day work is defined | `[inferred]` from the responsibility list | Which fleet metrics are reported today, and who uses them? | noted |
| RB1 | Kroonhaven not established from attributable sources | risk_signal | medium | "Kroonhaven Foods, Utrecht" | Same possibilities as RA1 | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RB2 | Salary not stated | unknown | — | The posting as pasted has no salary | The figure may be withheld or simply absent from the excerpt | `[grounded]` posting silent | What salary range is budgeted for this post? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | For Duinvaart, lead the resume with the on-time delivery dashboard your depot managers use and the weekly route-performance review you ran, naming SQL and Power BI in those same lines | A2, A3, A4, A5a, A6 | `[grounded]` your background statement | resume_edits_pending_approval |
| E2 | Add no temperature-compliance or cold-chain wording until you confirm real work behind it | A5b | `[grounded]` the A5b row | resume_edits_pending_approval |
| A1 | Check Duinvaart's own careers page for the live posting before investing effort | RA1 | `[grounded]` the RA1 row | pending your approval |
| A2 | Skip Kroonhaven as posted; if planning interests you, look at analyst-level planning or S&OP support roles | B2, B3, B5, G3 | `[generic]` role-family pattern | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Duinvaart Cold Chain Rotterdam" and "Kroonhaven Foods Utrecht chilled ready meals"; the host refused both, since search permission was not granted. This would have moved RA1 and RB1, and whether each posting is live |
| 2. Role-family sweep | unavailable | Searched "operations analyst logistics Netherlands salary Rotterdam"; refused. This would have moved the market calibration for RA2 and RB2 |
| 3. Hiring manager's public footprint | n/a | No name was given for either role, so there was no query to form |

## Upgrade menu

- Search permission, or the links to each live posting → RA1 and RB1 resolve, and the salary bands behind RA2 and RB2 appear.
- Your CV → A2 to A4 are checked against how it actually reads, and E1 becomes a real edit.
- A sanitized dashboard screenshot → A4 to `high`.
- Any temperature, exception or SLA-breach report you have built → A5b moves off `unclear`.
- An example where your review changed a route → A6 firms up.

I can write this up as `tuesday-dossier.md` whenever you want it.

A1 — Where are you based, and is three days a week in Rotterdam workable for you?
A5b — Have you tracked temperature or other condition-sensitive compliance, or any similar exception data? What did you own?
A6 — Did your weekly route-performance review ever lead to a route change you proposed to depot managers? What happened?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.