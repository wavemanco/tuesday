Web search was declined, so this runs on your two postings and your background alone.

# Decision snapshot

**Yes to Duinvaart, no to Kroonhaven.** Duinvaart is `conditional_go`. Kroonhaven is `no_go`: A5b and the commute are open on one side, while B2, B3 and B6 are absent must-haves on the other.

## Duinvaart Cold Chain — Operations Analyst

**Fit ledger.**

- `hard_gate` — unclear: A1 (three days a week in Rotterdam office)
- `must_have` — direct: A2, A3, A4, A5a · unclear: A5b (temperature compliance tracking)
- `important` — adjacent: A6 (route changes with depot managers)
- `preferred` — adjacent: A7 (Dutch a plus)

A5b — the cold-chain half of the job, unevidenced; A6 — a credible bridge, its limit named.

**Opportunity ledger.** The employer could not be checked from here (A-RR1), pay is unstated (A-RR2), and the three office days are untested against your commute (A-RR3). One entry runs the other way: the deliverables are concrete (A-RR4).

- **Hard gates:** none failed; unconfirmed: A1 (three days a week in Rotterdam office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the Rotterdam commute works for you — A1, A-RR3; (2) the posting is live on Duinvaart's own careers page — A-RR1; (3) any temperature-controlled work you did is confirmed — A5b, G1.

## Kroonhaven Foods — Supply Planner

**Fit ledger.**

- `hard_gate` — unclear: B1 (on-site in Utrecht)
- `must_have` — adjacent: B4 (run the weekly S&OP meeting), B7 (fluent Dutch) · unclear: B5 (advanced Excel) · absent: B2 (3+ years of FMCG planning), B3 (own the 13-week supply plan), B6 (SAP IBP or similar)

B2, B3, B6 — no direct or adjacent evidence; B4 — a bridge with its limit named.

**Opportunity ledger.** The employer could not be checked from here (B-RR1) and pay is unstated (B-RR2). The scope is well defined (B-RR3), but it is defined around work you haven't done.

- **Hard gates:** none failed; unconfirmed: B1 (on-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** the posting would have to accept analyst-side experience in place of planning years (B2), plus a planning system (B6) and a plan you own (B3). Nothing in the posting suggests that.

# Duinvaart: role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam, a refrigerated-fleet operator | `[grounded]` posting header; existence not verified (A-RR1) |
| Mandate | Track on-time delivery and temperature compliance, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` posting |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` posting |
| Scope read | An analyst post close to your current one, with temperature compliance added | `[inferred]` from the posting's duties against your stated duties |
| Market calibration | Not run, because search was declined. No pay band is available for this role | — |
| Unknowns | Salary; the team around the role; who sets route changes | — |
| Contradictions | None between the posting and your background | `[grounded]` the two documents |

# Duinvaart: evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| A1 | Three days a week in the Rotterdam office | hard_gate | unclear | none | hard_gate | You gave no location or commute constraint, so the term is unsettled. Your work was in Amsterdam, which says nothing on whether Rotterdam is workable | `[grounded]` constraints not given | Ask whether the commute works (closing block) |
| A2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | You stated 4 years as an operations analyst at a parcel carrier. This is self-report, with no inspectable artifact yet | `[grounded]` your background | none |
| A3 | Strong SQL | must_have | direct | medium | none | You stated daily SQL use. Self-report only | `[grounded]` your background | A sanitized query or report would raise to `high` |
| A4 | Power BI or Tableau | must_have | direct | medium | none | You stated daily Power BI use, including the on-time delivery dashboard your depot managers use | `[grounded]` your background | A dashboard screenshot would raise to `high` |
| A5a | Track on-time delivery across the fleet | must_have | direct | medium | none | The on-time delivery dashboard is your own. The limit is that a parcel network's service measures may differ from a refrigerated fleet's | `[grounded]` your background; `[generic]` that service measures differ by operator type | none |
| A5b | Track temperature compliance | must_have | unclear | low | discovery | Nothing you gave mentions temperature-controlled or excursion tracking. It may exist and not have been mentioned | `[grounded]` silence in your background | G1 |
| A6 | Work with depot managers on route changes | important | adjacent | medium | discovery | Depot managers used your dashboard and you ran the weekly route-performance review. Neither says you proposed or made route changes | `[grounded]` your background | G2 |
| A7 | Dutch a plus | preferred | adjacent | medium | transferability | Your Dutch is conversational. That meets "a plus" in part, and your own word marks the limit | `[grounded]` your statement | State the level plainly in the application |

# Kroonhaven: role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, Utrecht, a chilled ready-meals producer | `[grounded]` posting header; existence not verified (B-RR1) |
| Mandate | Own the 13-week supply plan, balance capacity against forecast, run the weekly S&OP meeting | `[grounded]` posting |
| Working pattern | On-site in Utrecht | `[grounded]` posting |
| Scope read | A planner post with ownership of the plan, which is more than analytical support | `[inferred]` from "own" and "run" in the posting |
| Market calibration | Not run, because search was declined | — |
| Unknowns | Salary; whether analyst experience is ever accepted for planning years | — |
| Contradictions | None | `[grounded]` the two documents |

# Kroonhaven: evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| B1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | Constraints not given | `[grounded]` constraints not given | Same question as A1 |
| B2 | 3+ years of supply or demand planning in FMCG | must_have | absent | none | capability | You said you have never worked in planning. Years of experience are graded as fit, not as a gate | `[grounded]` your statement | Closure path in G4 |
| B3 | Own the 13-week supply plan | must_have | absent | none | capability | No planning ownership in your background | `[grounded]` your statement | Closure path in G4 |
| B4 | Run the weekly S&OP meeting | must_have | adjacent | medium | transferability | You ran a weekly route-performance review. That is a different kind of meeting from S&OP, which balances demand, supply and capacity, so the limit is substantial | `[grounded]` your background; `[generic]` what S&OP covers | none |
| B5 | Advanced Excel | must_have | unclear | low | discovery | You named SQL and Power BI, not Excel | `[grounded]` silence in your background | none: carried as a minor unknown |
| B6 | SAP IBP or a similar planning system | must_have | absent | none | capability | You named no planning system | `[grounded]` your background | Closure path in G4 |
| B7 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational Dutch is below fluent. Running a weekly meeting in Dutch is the heaviest use of it | `[grounded]` your statement | none |

# Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Temperature compliance (A5b, must_have) | discovery | Your background is silent on temperature-controlled work | The cold-chain half of the Duinvaart role. Resolving it decides whether the fit is strong or partial | Chilled or pharma parcels; time-and-temperature excursion reports; cold-chain customers you reported to; SLA breach analysis | A report or dashboard view, sanitized | `[grounded]` silence; `[generic]` that cold-chain employers weigh this |
| G2 | Route changes with depot managers (A6, important) | discovery | The review and the dashboard are stated. Any route change is not | It decides whether to present A6 as direct experience or as a bridge | A route you proposed to change after a review; a depot-level decision your numbers drove | A review pack or change note | `[grounded]` your background |
| G3 | Commute and location (A1, B1, hard_gate) | hard_gate | No location constraint given | Both roles require office presence | A stated base and a workable commute | Your location | `[grounded]` constraints not given |
| G4 | Planning ownership, years and system (B2, B3, B6, capability) | capability | No planning evidence, by your own statement | These are the reasons for `no_go` | Closure path: target planning-analyst, demand-planning or supply-chain-analyst roles, plus a planning tool course or a small forecast project | A forecast or planning project | `[generic]` the typical entry path into planning roles |

# Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| A-RR1 | Employer not established from attributable sources | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | The employer may be too small to have much of a web footprint, the posting may be stale or aggregated, or the employer may not be hiring as described. None of these is ranked above the others | `[generic]` pattern for employers of unknown size, not a claim about this one | Can you point me to this role on your careers page, and who I would work with? | unresolved |
| A-RR2 | Salary not stated | unknown | — | no figure given | The posting may leave pay for later in the process | `[inferred]` from the posting's silence | What salary range is budgeted for this post? | unresolved |
| A-RR3 | Three office days against a commute not yet checked (A1) | unknown | — | "three days a week in our Rotterdam office" | The days may be fixed or flexible | `[inferred]` from the posting | Which three days are fixed, and which can be chosen? | unresolved |
| A-RR4 | Concrete deliverables named | positive_signal | — | "weekly dashboards in Power BI" | Success looks measurable | `[grounded]` posting | How is success measured in the first 90 days? | noted |
| B-RR1 | Employer not established from attributable sources | risk_signal | medium | "Kroonhaven Foods, Utrecht" | Same possibilities as A-RR1, none ranked above the others | `[generic]` pattern for employers of unknown size, not a claim about this one | Can you point me to this role on your careers page? | unresolved |
| B-RR2 | Salary not stated | unknown | — | no figure given | Pay may be withheld | `[inferred]` from the posting's silence | What salary is budgeted for this post? | unresolved |
| B-RR3 | Clear, bounded scope | positive_signal | — | "13-week supply plan" | The role is well defined | `[grounded]` posting | How is the plan's accuracy measured? | noted |

# Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Duinvaart: put the on-time delivery dashboard your depot managers use, and the weekly route-performance review you ran, at the top of the CV. This reorders your existing lines and adds no new claim | A3, A4, A5a, A6 | `[grounded]` your own sentences | `resume_edits_pending_approval` |
| E2 | Duinvaart: say "conversational Dutch" plainly, since the posting only calls Dutch a plus | A7 | `[grounded]` your statement | pending your approval |
| Q1 | Duinvaart: ask A-RR1 through A-RR4's questions verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Duinvaart: check the posting on Duinvaart's own careers page before investing effort | A-RR1 | `[grounded]` register | pending your approval |
| K1 | Kroonhaven: don't apply. Put the time into Duinvaart and into planning-analyst or supply-chain-analyst postings | B2, B3, B6 | `[generic]` the typical entry path into planning | pending your approval |

Tailoring the CV line by line for Duinvaart is resume-tailor's job, if you want it.

# Evidence status

Verified: none yet. Rejected inferences: none.

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches for each employer's name were refused. They would have settled A-RR1 and B-RR1 |
| 2. Role-family sweep | unavailable | The searches on Rotterdam analyst pay and Dutch FMCG planner pay were refused. They would have given the market calibration row for each role |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

# Dossier offer

If it would help, I can save this as `tuesday-dossier.md`; there's no pressure.

# Upgrade menu

- A link to Duinvaart's and Kroonhaven's own careers pages for these roles → A-RR1 and B-RR1 close without search.
- Your base location → A1 and B1 resolve.
- A sanitized report showing temperature or time-critical parcels → A5b rises from `unclear`.
- A review pack, or a note on one route change → A6 rises to `direct`.
- A dashboard screenshot or a sanitized query → A3 and A4 rise to `high`.
- Salary ranges → A-RR2 and B-RR2 close.
- A deeper research pass (up to 5 more searches and 2 more fetches) needs the search permission declined this session.

# Questions

G1 — At the parcel carrier, did you ever track temperature-controlled or time-critical shipments, or excursion reports? What did you own, and what happened?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

A1 and B1 — Where are you based, and is three days a week in Rotterdam workable, or five in Utrecht?

G2 — Did your weekly route-performance review lead to route changes you proposed or made with depot managers?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.