**Yes, worth pursuing, and nothing in the posting or the WhatsApp message asks anything risky of you. I couldn't verify Fernquay from here, so the status is `conditional_go`: go ahead with the call while you check the employer yourself (RR1).**

My web searches were refused, so none of this has been checked against the web. It rests only on your posting, the message and your background.

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Salary €52,000–€60,000)
- `must_have` — direct: R3, R4, R5, R6
- `important` — adjacent: R7 (Own the booking flow end to end), R8 (Research calls with school owners), R9 (First designer, no design peers)

R9 — the real stretch, and your own stated limit; R7 — checkout is a credible bridge to the whole flow, limit named; R2 — pay is stated, your floor is not.

**Opportunity ledger.** The employer can't be established from here (RR1), and the equity and funding terms are unstated (RR2). The WhatsApp contact is not itself a warning sign (RR3), the post has no named success outcomes (RR4), and the scope is concrete and fits a first-design hire (RR5).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer verifies independently — RR1; (2) the salary meets your floor and the equity terms are explained — R2, RR2; (3) you get a clear answer on design support for a first designer — R9, RR4.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, booking software for sea-kayak and surf schools. Not independently confirmed | `[grounded]` posting |
| Mandate | Own the booking flow end to end, run research calls with school owners, ship alongside two engineers | `[grounded]` posting |
| Reports to / works with | Co-founder Ronan Kehoe; the message names Saoirse as CTO | `[grounded]` posting and message |
| Working pattern | Hybrid, two days a week in the Galway office | `[grounded]` posting |
| Pay | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting |
| Scope read | Three duties that fit one first design hire at a six-person company; no bundling of unrelated roles | `[inferred]` from the posting's three stated duties |
| Market calibration | Not run: the search was refused, and I won't offer a band from memory | — |
| Unknowns | Equity terms (vesting, strike, dilution); funding and runway; first-year outcomes; whether Saoirse is one of the two engineers | — |
| Contradictions | None between the posting and the message. Careers page not checked | `[grounded]` the two texts you pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week at the Galway office | hard_gate | direct | medium | none | You said you moved back to Galway last year, so the location term is met. You haven't stated an office-days preference, so I'm not claiming more | `[grounded]` your background | none |
| R2 | Salary €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | The posting states the pay. Your floor wasn't given, so I can't say whether it clears | `[grounded]` posting; your floor not given | Question 1 below |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company, self-reported and not yet inspected | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" is confirmed and specific. The case study you sent is the inspectable artifact and I haven't seen it | `[grounded]` your background | none |
| R5 | You have run your own user research | must_have | direct | medium | none | Monthly usability sessions with customers, which matches the requirement as worded | `[grounded]` your background | none |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | Worked in a squad with four engineers | `[grounded]` your background | none |
| R7 | Own the booking flow end to end | important | adjacent | medium | transferability | You redesigned the checkout flow, which is one stage of a booking flow. The limit is that nothing says you owned discovery, availability or post-booking | `[grounded]` your background; `[inferred]` that the posting's "end to end" is wider than checkout | G3 |
| R8 | Run research calls with school owners | important | adjacent | medium | transferability | Your sessions were with customers. School owners are the people who buy the software, and nothing yet shows you have talked to business buyers | `[grounded]` your background; `[inferred]` that owners are a different audience from customers | Question 2 below |
| R9 | Work as the first and only designer | important | adjacent | medium | transferability | Inferred from "you would be our first designer". You've never been the only designer. Owning a redesign and running research carry over, but setting your own priorities without peer review is unproven | `[grounded]` the posting and your own limit; `[inferred]` as a requirement | G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | First and only designer (R9, important) | transferability | Squad experience with engineers; never solo | The role has no design peer. Your answer on how you would work without one is likely to be probed | Times you set your own research agenda; prioritised design work against engineers' capacity; made a call with no design reviewer | Your case study and a short written account of how you decided what to work on | `[grounded]` your stated limit; `[inferred]` that this will be probed |
| G2 | Research with business buyers (R8, important) | transferability | Customer usability sessions only | The posting names school owners as the research audience | Calls with merchants, partners, suppliers or other business users; internal stakeholder interviews | Session notes or a research summary, sanitised | `[grounded]` your background; `[inferred]` the audience difference |
| G3 | Whole booking flow, not only checkout (R7, important) | transferability | Checkout redesign confirmed | "End to end" is the stated scope | Work on search, availability, confirmation or amends and cancellations | A flow map or the case study they already liked | `[grounded]` your background and the posting |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Fernquay … six people in Galway" | The company may be too new or small to have a footprint, the posting may be stale, or I couldn't check at all. Obscurity alone is not a finding | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your own careers page, and tell me who will be on the call? | unresolved |
| RR2 | Equity and funding terms unstated | unknown | — | "0.5–1% equity" | Vesting, strike price, dilution and runway are all missing, so the equity can't be valued yet | `[inferred]` from the posting's silence on terms | What are the vesting terms and strike price, and how many months of runway do you have? | unresolved |
| RR3 | First contact by WhatsApp | unknown | — | "Ronan from Fernquay here … I have emailed you a calendar invite with the video link" | Informal messaging for scheduling is common at small companies. The message asks for nothing but a call time, and the invite came by email, which gives you a sender domain to check | `[generic]` pattern for small companies; `[grounded]` the message asks for no money, ID or documents | Is the invite from a Fernquay address, and does it match the domain on your careers page? | unresolved |
| RR4 | No first-year outcomes stated | unknown | — | "own the booking flow end to end" | A first designer with no named success measure, and no named design mentor | `[inferred]` from the posting's silence | What would this person have shipped after 12 months, and who gives design feedback? | unresolved |
| RR5 | Concrete scope and realistic process | positive_signal | — | "we would rather see one messy real project than a polished deck" | The duties are specific and the process is stated | `[grounded]` posting | How were the booking flow's current problems found? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, find Fernquay's own site or careers page independently and compare its domain to the sender of the calendar invite | RR1, RR3 | `[grounded]` register | pending your approval |
| A2 | Confirm the time by replying to the email invite rather than WhatsApp, until the domain matches | RR3 | `[inferred]` from the register | pending your approval |
| A3 | Ask the RR1, RR2 and RR4 questions verbatim on the call | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A4 | Lead with the checkout redesign and the monthly usability sessions, as you described them, and say plainly what was yours and what was the squad's | R5, R7, R9 | `[grounded]` your own sentences | pending your approval |

Rehearsing the call itself is the mock-interview module's job; ask for it by name if you want it.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches ("Fernquay booking software sea kayak surf schools Galway", "Fernquay product designer job Galway") were refused. These would have settled RR1 and the contradictions row |
| 2. Role-family sweep | unavailable | One search (product designer salary Ireland, first-designer startup) was refused. It would have fed market calibration and the pay check on R2 |
| 3. Hiring manager's public footprint | unavailable | One search ("Ronan Kehoe Fernquay co-founder") was refused. It would have fed the scope read and which story to lead with |

## Upgrade menu

- Allow web search and I'll rerun targets 1–3, which could close RR1 and calibrate R2.
- A link to the live posting or Fernquay's careers page would settle RR1 on its own.
- Your salary floor and any office-days limits would settle R2 and the hard-gates line.
- The case study they liked would let R4 reach `high`, and would speak to G1 and G3.
- Session notes from a research round, sanitised, would address G2.

I can also write this up as `tuesday-dossier.md` if you'd like to keep it, with no obligation.

R2 — What's your minimum acceptable salary, and what would you need to know about the equity to count it?
G2 — Have you run sessions or calls with business owners, partners or merchants rather than consumers? If so, what did you own?
RR1 — Where did you find and apply to this posting, and does the emailed invite come from a domain that matches Fernquay's own site?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.