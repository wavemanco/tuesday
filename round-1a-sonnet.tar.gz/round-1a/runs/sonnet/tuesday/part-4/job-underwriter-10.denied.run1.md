Search permission was declined, so everything below runs on your two messages alone.

## Decision snapshot

**Yes, worth taking the call, and I can't confirm the company is real from here. Status: `conditional_go`.** Nothing in your messages asks anything of you that is a warning sign (RR2, RR3). Fernquay itself is not established (RR1), and that caps the status at `conditional_go`.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Two days a week at the Galway office), R2 (Salary €52,000–€60,000 against your floor)
- `must_have` — direct: R3, R4, R5, R6 · adjacent: R7 (Own the booking flow end to end)
- `important` — adjacent: R9 (First designer, no design peer) · unclear: R8 (Research calls with school owners)

R7 — a credible bridge, its limit named; R8 (`low`) — the audience of your usability sessions is not stated; R9 (`low`) — new ground, by your own account.

**Opportunity ledger.** The posting is concrete about scope and pay and asks nothing of you (RR3, RR6). The unknowns are the company's independent footprint (RR1), where the WhatsApp contact came from (RR2), the equity terms (RR5), and the load of being the sole designer (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Two days a week at the Galway office), R2 (Salary €52,000–€60,000 against your floor); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) Fernquay verifies independently, with the invite from a company address — RR1, RR2; (2) your pay floor sits inside the stated band — R2; (3) two Galway office days work for you — R1; (4) the end-to-end claim is framed as exactly what you owned — R7.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, booking software for sea-kayak and surf schools. Not independently confirmed | `[grounded]` the posting as you pasted it; search refused |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship with two engineers, work most closely with co-founder Ronan Kehoe | `[grounded]` posting |
| Working pattern | Hybrid, two days a week in the Galway office | `[grounded]` posting |
| Compensation | €52,000–€60,000 plus 0.5–1% equity; vesting, exercise terms and funding stage unstated | `[grounded]` posting |
| Scope read | Concrete deliverables, but one person covering research, design and shipping with no design peer | `[inferred]` from "first designer" and "own … end to end" |
| Market calibration | Not established: the role-family search was refused, so no band is given rather than one from memory | `[grounded]` search refused |
| Unknowns | Employer's own site; how Ronan has your number; equity terms; who reviews design work today | — |
| Contradictions | None between the posting and the WhatsApp message: same company, same co-founder, your checkout case study | `[grounded]` both texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week at the Galway office | hard_gate | unclear | low | hard_gate | You live in Galway, but you haven't said whether two office days suit you. Confidence grades your statement, which is thin | `[grounded]` your move back to Galway; posting term | G1 |
| R2 | Salary €52,000–€60,000 | hard_gate | unclear | none | hard_gate | The posting states the band. Your floor wasn't given, so the gate can't be settled | `[grounded]` posting figure; floor not given | G2 |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company, self-reported and uninspected | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | Daily use, self-reported | `[grounded]` your background | Portfolio would raise to `high` |
| R5 | You have run your own user research | must_have | direct | medium | none | Monthly usability sessions with customers. Limit: usability testing, not discovery interviews | `[grounded]` your background | none |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | Worked in a squad with four engineers | `[grounded]` your background | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned a checkout flow. Limit: checkout is one stage, and end-to-end ownership isn't stated | `[grounded]` your checkout redesign; `[inferred]` that checkout is a stage of booking | G3 |
| R8 | Research calls with school owners | important | unclear | low | discovery | Your sessions were with "customers". Whether those were travellers or travel businesses isn't stated | `[grounded]` your wording | G4 |
| R9 | First designer, no design peer | important | adjacent | low | transferability | You have never been the only designer. Owning the checkout redesign is the nearest evidence | `[inferred]` from "first designer" in the posting | G5 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Office days (R1, hard_gate) | hard_gate | You live in Galway; willingness for two fixed days is unstated | A term you meet or don't | Commute, caring or other fixed commitments | None needed; your answer | `[grounded]` your messages |
| G2 | Pay floor (R2, hard_gate) | hard_gate | The band is stated; your floor isn't | A term you meet or don't | Your current Dublin salary and Galway cost of living | None needed; your answer | `[grounded]` posting |
| G3 | End-to-end ownership (R7, must_have) | transferability | Checkout redesign confirmed; wider booking journey unstated | Decides how honestly you can claim "end to end" | Owning search, selection, payment or confirmation steps; post-booking emails | Your checkout case study with before/after | `[grounded]` your background; `[generic]` that "end to end" is probed on calls |
| G4 | School-owner research (R8, important) | discovery | Audience of your sessions not stated | The role's research is with business owners | Sessions with operators, partners or B2B users | A research summary or session guide | `[grounded]` your wording |
| G5 | Sole-designer remit (R9, important) | transferability | Always in a design-plus-engineering squad | You'd set your own process | Setting standards, running critiques, or leading design on a project | A design-system or process doc you drove | `[inferred]` from the posting |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools." | The company may be too new or small for a footprint, or the posting may not reflect a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one; `[grounded]` you found little online | Can you point me at the role on your own careers site, and send the invite from your company address? | unresolved |
| RR2 | First contact by WhatsApp | unknown | — | "I have emailed you a calendar invite with the video link. Just shout here if the time does not suit." | Chat for scheduling with the invite by email can be ordinary for a small team; unknown is how Ronan got your number and whether the invite comes from a Fernquay address | `[generic]` for the ordinary part; `[grounded]` the message text | Can you confirm the invite will come from a Fernquay address, and who else is on the call? | unresolved |
| RR3 | Concrete scope, nothing asked of you | positive_signal | — | "own the booking flow end to end, run research calls with school owners, and ship alongside our two engineers" | The scope is specific, and the call is a video interview with a named CTO | `[grounded]` posting and message; no payment, ID or documents requested in what you've shared | Who has been designing the booking flow until now? | noted |
| RR4 | Sole-designer load | risk_signal | low | "You would be our first designer" | One person may carry research, design and process with no design mentor | `[inferred]` from "first designer" against "own … end to end" | Who reviews design work today, and what do you expect beyond the booking flow in year one? | unresolved |
| RR5 | Equity terms unstated | unknown | — | "0.5–1% equity" | The percentage is stated, but vesting, exercise terms and funding stage are not | `[grounded]` posting silence | What are the vesting, cliff and exercise terms, and what stage is the company at? | unresolved |
| RR6 | Salary stated, market band unchecked | unknown | — | "Salary €52,000–€60,000" | Stating a band is transparent; whether it fits market is unchecked | `[grounded]` posting figure; comparison not run | Where in the band would an offer for my experience sit? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, look for Fernquay's own site and the invite's sender address, and check Ronan's and Saoirse's public professional pages | see RR1, RR2 | `[grounded]` RR1, RR2 | pending your approval |
| A2 | Put the RR1, RR2, RR4 and RR5 questions to Ronan and Saoirse on the call | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A3 | Open with what you wrote: you redesigned the checkout flow and ran monthly usability sessions with customers. Claim end-to-end ownership only to the extent your G3 answer supports | see R5, R7 | `[grounded]` your sentences | pending your approval |
| A4 | Decide your pay floor before the call and ask where in the band you would sit | see R2, RR6 | `[grounded]` posting | pending your approval |

For prepping the 45-minute call itself, mock-interview is the module for that.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches "Fernquay booking software sea kayak surf schools Galway" and "Fernquay product designer Galway careers" were refused. Would have moved RR1 and the contradictions row |
| 2. Role-family sweep | unavailable | Search "first product designer startup Ireland salary €52,000 €60,000 equity" was refused. Would have moved market calibration and RR6 |
| 3. Hiring manager's public footprint | unavailable | Search "Ronan Kehoe Fernquay co-founder" was refused. Would have moved the scope read and A3's positioning |

If you'd like, I can write this up as `tuesday-dossier.md` to carry forward.

## Upgrade menu

- A link to Fernquay's own site or careers page, or the invite's sender address → RR1 and RR2 close, and the cap on `conditional_go` lifts.
- Search permission → the three targets above run and calibrate pay and scope.
- Your pay floor and office-day answer → R1 and R2 settle, and the status can move to `go` or `no_go`.
- Your checkout case study or portfolio link → R3 to R7 can reach `high`.
- Who your usability sessions were with → R8 resolves.

**Questions**

G1 — Do two fixed office days a week in Galway work for you?

G2 — What is your minimum acceptable salary, and does equity change that?

G3 — Which steps of your company's booking journey did you personally own besides checkout, and which stayed with others?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.