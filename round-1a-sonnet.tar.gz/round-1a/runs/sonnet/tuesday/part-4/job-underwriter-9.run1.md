I'm checking whether Marrowgate Housing exists as described and what payroll administrator roles in Limerick normally pay, then I'll give you the full assessment.
I couldn't run the three web searches (employer, pay norms, Declan Garvagh) because permission was refused, so everything below rests on what you pasted. I didn't retry.

## Decision snapshot

**Yes. Asking for bank details, a PPS number and a passport scan after a written offer is normal (RR1), and accepting is worth it on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Hybrid, two days in Limerick office), R2 (Salary €38,000–€42,000)
- `must_have`: direct: R3, R5, R6, R8, R9 · adjacent: R7 (Run monthly payroll for 240 staff) · unclear: R4 (Irish PAYE, PRSI and USC)
- `important`: absent: R10 (Process pension changes)

R7 — a credible bridge, its limit named; R4 (`low`) — your background is silent on jurisdiction; R10 — a gap you named yourself, with a closure path in G1.

**Opportunity ledger.** The offer matches the ad's terms and followed two in-person interviews (RR3). The data requests are routine post-offer onboarding (RR1). Two checks are still open: who stands behind the people@ mailbox (RR4), and the employer itself, which I couldn't search (RR2).

- **Hard gates:** none failed; unconfirmed: R1 (Hybrid, two days in Limerick office), R2 (Salary €38,000–€42,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the portal link checks out before you enter anything (RR1, RR2, RR4); (2) €40,000 and the two Limerick days meet your own limits (R1, R2); (3) you raise pension changes with Declan before starting (R10, G1); (4) you get the written contract before or with your acceptance (RR3).

I don't need your passport, PPS number or bank details for any of this, so please don't paste them here.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick, about 240 staff | `[grounded]` ad and offer, as you pasted them; not independently checked |
| Mandate | Monthly payroll, starters, leavers, pension changes, payroll-to-ledger reconciliation, staff payroll queries | `[grounded]` ad |
| Terms offered | Permanent, €40,000, hybrid with two office days, reporting to Declan Garvagh, Finance Manager, start after your notice period | `[grounded]` offer email |
| Contradictions | None between the ad and the offer: €40,000 sits inside €38,000–€42,000 and the hybrid terms match | `[grounded]` ad against offer |
| Market calibration | Not calibrated: the pay search was refused. €40,000 is judged only against the posting's own band | `[grounded]` ad band |
| Unknowns | Contract terms, probation, pension scheme, payroll software, team size, who else does payroll | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in the Limerick office | hard_gate | unclear | none | hard_gate | The ad and offer agree on the term. You haven't stated a limit of your own, so whether it's met isn't established | `[grounded]` ad and offer agree; no constraint from you | Closing question on R1 and R2 |
| R2 | Salary €38,000–€42,000 | hard_gate | unclear | none | hard_gate | €40,000 is inside the advertised band. Your floor isn't given | `[grounded]` ad and offer | Closing question on R1 and R2 |
| R3 | 2+ years running payroll | must_have | direct | medium | none | 3 years of fortnightly payroll for 90 staff at a hotel group. Confirmed in your own words, nothing inspected | `[grounded]` your background | none |
| R4 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | Your background doesn't say which tax system the hotel payroll ran under | `[grounded]` background silent on jurisdiction | Closing question G2 |
| R5 | Strong Excel | must_have | direct | medium | none | Daily use, pivot tables and XLOOKUP stated, no sample inspected | `[grounded]` your background | none |
| R6 | Payroll qualification or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024, stated. Not inspected, so a copy would raise it to `high` | `[grounded]` your background | Offer: a copy of the certificate |
| R7 | Run monthly payroll for 240 staff | must_have | adjacent | medium | transferability | Bridge: 90-staff fortnightly payroll. Limit: smaller headcount, and fortnightly rather than monthly | `[grounded]` background and ad | See G3 |
| R8 | Process starters and leavers | must_have | direct | medium | none | Stated in your background, nothing inspected | `[grounded]` your background | none |
| R9 | Monthly payroll-to-general-ledger reconciliation | must_have | direct | medium | none | Stated in your background, nothing inspected | `[grounded]` your background | none |
| R10 | Process pension changes | important | absent | none | capability | You've said your manager handled these. The ad lists it among the duties, not under Requirements. Pension changes are commonly learned on the job, which makes this gap one to raise, not hide | `[grounded]` your statement; `[generic]` that this is commonly learned on the job | See G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pension changes (R10, important) | capability | You haven't processed these yourself | It's a named duty, so the likeliest early question is who will show you how | Changing an employee's pension contribution rate; processing a scheme joiner or opt-out; checking pension deductions against a provider schedule | A hand-over note or checklist from Declan | `[grounded]` your statement; `[inferred]` that it's a named duty from the ad's duty list |
| G2 | Irish tax rules (R4, must_have) | discovery | Jurisdiction of your hotel payroll isn't stated | A must-have with nothing in hand to close it | Running Revenue payroll submissions; applying tax credits and PRSI classes; USC at year-end | A payslip format or Revenue year-end return with details removed | `[grounded]` background silent |
| G3 | Scale and cadence (R7, must_have) | transferability | 90 staff fortnightly against 240 staff monthly | The bridge has a named limit, not a blocker | A larger or multi-site run; monthly cut-offs | The employer's payroll system and run schedule | `[grounded]` background and ad |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Bank, PPS and passport details requested after the offer | unknown | — | "Once you accept, we will send you a link to our onboarding portal, where you add your bank details ... your PPS number ... and a scan of your passport" | After a written offer naming role and pay, these are usual onboarding steps: paying you, registering you with Revenue, checking right to work. The thing to check is the link, not the request | `[generic]` onboarding pattern; `[grounded]` the request comes after a written offer | Can you confirm the portal's web address and that the link will come from your own domain? | unresolved |
| RR2 | Employer not independently checked | unknown | — | "Marrowgate Housing, a housing association in Limerick" | I couldn't check the employer. You've been to their office twice, which is a point in its favour | `[grounded]` you attended two in-person interviews; searches refused | Can you give me your registration number with the housing regulator, so I can check it? | unresolved |
| RR3 | Offer terms match the ad | positive_signal | — | "permanent post ... €40,000 a year ... hybrid with two days a week" | Pay, role and hybrid pattern match the ad, and the post is permanent with a named manager | `[grounded]` ad against offer | Can I see the contract and job description, with probation, notice and pension terms? | noted |
| RR4 | Offer comes from a shared mailbox, unsigned by a person | unknown | — | "people@marrowgate.example" ... "Marrowgate Housing People Team" | A shared HR mailbox is ordinary, but nobody you met has put their name to it | `[inferred]` from the sign-off against your two interviews | Can one of the people who interviewed me confirm this offer? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check where the portal link points before opening it. Compare the address with the one from your interviews, or ring the office number on their own website | See RR1, RR4 | `[generic]` verification practice | pending your approval |
| A2 | Enter bank, PPS and passport details only in the portal. Never send them by email or message. Bring the original passport on day one, as the offer says | See RR1 | `[generic]` data-handling practice | pending your approval |
| A3 | Ask for the written contract before or with your acceptance | See RR3 | `[grounded]` RR3 | pending your approval |
| A4 | Raise pension changes with Declan, asking who will take you through them | See R10, G1 | `[grounded]` your statement | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search permission refused. It would have moved RR2 and role reality's contradictions row |
| 2. Role-family sweep | unavailable | Search permission refused. It would have moved market calibration for €40,000 |
| 3. Hiring manager's public footprint | unavailable | Search permission refused for the Declan Garvagh query. It would have moved the scope read and the plan |

I can offer a one-time deeper pass (L2): up to 5 more searches and 2 more fetches, if you allow searching.

I can save this as `tuesday-dossier.md` if you want a copy to keep.

## Upgrade menu

- Allowing web search would run the three research rows above and could close RR2.
- Your pay floor and the commute you'll accept would settle R1 and R2.
- The written contract would close RR3 and the pension and probation unknowns.
- The portal link and its sender address, when it arrives, would settle RR1 and RR4.
- A copy of your Payroll Technician certificate would raise R6 to `high`.

## Questions

- **R1, R2:** Do €40,000 and two days a week in Limerick sit within your own limits on pay, commute and notice?
- **G2:** Was your hotel-group payroll run under Irish PAYE, PRSI and USC, and did you submit to Revenue yourself?
- **G1:** Did the interviewers know you hadn't processed pension changes, and what did you say?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.