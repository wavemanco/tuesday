I'm running the research step now: checking whether Marrowgate Housing exists as described, then a quick salary check for this role.
**Yes, this request is normal at this stage (RR2). Accept once the employer and the written terms check out. Status: `conditional_go`.** The "never hand these over" rule you were taught is about pre-offer and unsolicited requests, and this is neither.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Salary €38,000–€42,000), R2 (Hybrid, two days a week)
- `must_have` — direct: R3, R5, R6 · unclear: R4 (Irish PAYE, PRSI and USC)
- `important` — direct: R8, R9 · adjacent: R7 (Monthly payroll, 240 staff) · unclear: R11 (Staff payroll queries) · absent: R10 (Pension changes)

R4 — Irish tax knowledge isn't stated either way; R10 (`none`) — you've said you haven't done pension changes yourself; R7 — monthly and 240 staff are a step up from fortnightly and 90.

**Opportunity ledger.** Consistent but not independently verified: I couldn't confirm the employer from here (RR1), the portal request fits post-offer onboarding (RR2), and no written terms have arrived yet (RR3). One entry runs the other way: the offer matches the posting (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Salary €38,000–€42,000), R2 (Hybrid, two days a week); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and the offer's sender are verified (RR1); (2) the contract terms arrive in writing before you accept or resign (RR3); (3) the €40,000 and the two office days meet your own minimums (R1, R2); (4) you frame pension changes honestly as new to you (R10).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick | `[grounded]` JD header; not confirmed by research (see Evidence status) |
| Mandate | Monthly payroll for 240 staff, starters, leavers, pension changes, payroll-to-ledger reconciliation, staff queries | `[grounded]` JD |
| Reporting line | Declan Garvagh, Finance Manager | `[grounded]` offer email |
| Working pattern | Hybrid, two office days a week in Limerick; permanent post | `[grounded]` JD and offer |
| Pay | Posted €38,000–€42,000; offered €40,000 | `[grounded]` JD and offer |
| Market calibration | Not given: the search that would set a market band was refused, so I won't state one | `[grounded]` tier line below |
| Unknowns | Team size around the role; payroll software; pension scheme and who handles changes today; probation, notice, hours, holidays | `[grounded]` JD and offer are silent on each |
| Contradictions | None between the JD and the offer on title, pay range, hybrid pattern and two office days | `[grounded]` both documents as you pasted them |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Salary €38,000–€42,000 (offered €40,000) | hard_gate | unclear | none | hard_gate | No pay floor given, so I can't say whether €40,000 meets it. Confidence grades your statement of the constraint, and there isn't one | `[grounded]` no constraint stated | Question Q2 |
| R2 | Hybrid, two days a week in the Limerick office | hard_gate | unclear | none | hard_gate | Your commute and schedule limits weren't given | `[grounded]` no constraint stated | Question Q2 |
| R3 | 2+ years running payroll | must_have | direct | medium | none | Three years of fortnightly payroll for 90 staff at a hotel group. Self-reported, so expect a probe | `[grounded]` your stated background | none |
| R4 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | Your background doesn't say whether the hotel group's payroll was Irish, or what the certificate covered. Irish tax knowledge is probably the first thing a Finance Manager checks | `[grounded]` background silence; `[generic]` what such a manager checks | G1 |
| R5 | Strong Excel | must_have | direct | medium | none | Daily use, pivot tables and XLOOKUP, stated | `[grounded]` your stated background | none |
| R6 | Payroll qualification or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024. The awarding body wasn't named | `[grounded]` your stated background | none |
| R7 | Run the monthly payroll for 240 staff | important | adjacent | medium | transferability | Same core work at fortnightly frequency and 90 staff. The limit is that you haven't run a monthly cycle or this headcount | `[grounded]` background; the scale gap is arithmetic on stated figures | G3 |
| R8 | Process starters and leavers | important | direct | medium | none | Starters and leavers named in your background | `[grounded]` your stated background | none |
| R9 | Reconcile payroll to the general ledger monthly | important | direct | medium | none | You stated a monthly payroll-to-ledger reconciliation | `[grounded]` your stated background | none |
| R10 | Process pension changes | important | absent | none | capability | You confirmed you haven't done these; your manager did | `[grounded]` your own statement | G2 |
| R11 | Answer staff payroll queries | important | unclear | low | discovery | Your background doesn't mention handling staff queries | `[grounded]` background silence | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Irish PAYE, PRSI and USC (R4, must_have) | discovery | The hotel group's payroll jurisdiction and the certificate's content aren't stated | A must_have at `unclear`; a yes would close it | Filing Irish payroll submissions to Revenue; applying PRSI classes and USC rates to starters; issuing P45s or year-end figures | The certificate's module list, or a sanitised payslip layout | `[grounded]` background silence; `[generic]` that Irish payroll work looks like this |
| G2 | Pension changes (R10, important) | capability | You confirmed none done yourself | The role lists it as a duty, so it is a real learning gap | Watching your manager process them, or preparing the inputs for them, only if that is true. I won't assume it | None to attach. A handover or a short course would be the closure path | `[grounded]` your statement; `[generic]` that employers often give a handover period for a specific duty |
| G3 | Monthly cycle, 240 staff (R7, important) | transferability | Fortnightly, 90 staff: the same skill at a different scale | A credible bridge. The limit is cycle and headcount, and the strengthener is knowing their cycle calendar and software | Any month-end close you ran alongside payroll | The employer's pay calendar and payroll system | `[grounded]` stated figures; `[inferred]` bridge from the reconciliation you do monthly |
| G4 | Staff payroll queries (R11, important) | discovery | Nothing stated | Low impact on the decision | Answering payslip or tax-credit queries from staff or managers | An example you remember | `[grounded]` background silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and sender not established from here | risk_signal | low | "Marrowgate Housing, a housing association in Limerick" | The employer is probably as described, since you interviewed twice in person at their office. I couldn't run the check, and the sender address as pasted ends `.example`, a placeholder suffix I assume you masked | `[generic]` pattern: a failed or missing check is a reason to verify, not a finding about this firm; `[grounded]` the two in-person interviews | Can you confirm the address your People Team writes from, and the web address of the onboarding portal? | unresolved |
| RR2 | Bank, PPS and passport requested, after acceptance, through a portal | unknown | — | "Once you accept, we will send you a link to our onboarding portal, where you add your bank details for salary payments, your PPS number for Revenue, and a scan of your passport" | This is routine onboarding: it follows a written offer that names the role and pay, and each item has a stated purpose. The advice you were given targets requests before an offer, or from someone you can't verify. The portal link hasn't arrived, so it is unchecked | `[generic]` how post-offer onboarding usually works; `[grounded]` the offer names role and pay, and the request comes after it | Can you confirm the portal's web address, and who administers it? | unresolved |
| RR3 | Written terms not yet seen | unknown | — | "reporting to Declan Garvagh, Finance Manager, hybrid with two days a week" | The offer email gives role, pay and pattern, but not probation, notice, hours, holidays or pension scheme | `[grounded]` the email lists none of these; `[generic]` that these usually come in a written contract | Can you send the contract and terms, including the pension scheme, before the five-day deadline? | unresolved |
| RR4 | Offer matches the posting | positive_signal | — | "€40,000 a year ... hybrid with two days a week in our Limerick office" | Role title, pay within the posted range, hybrid pattern and office days all agree with the ad | `[grounded]` JD and offer compared | Who handled pension changes before, and will there be a handover? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before accepting, reply asking for the written contract and terms, and ask for a few extra days if verification needs them | RR3, R10 | `[grounded]` the offer's five-working-day window | pending your approval |
| A2 | Check the offer came from the same address as your interview correspondence | RR1 | `[grounded]` your two in-person interviews | pending your approval |
| A3 | When the portal link arrives, confirm it with the People Team using contact details you already hold or find on their own site, not the link itself. Upload only through the portal, never as an email attachment | RR1, RR2 | `[generic]` common safeguard for personal documents | pending your approval |
| A4 | In the loop, ask the RR4 pension-handover question and which payroll software they use | G2, G3 | `[grounded]` gap queue and register | pending your approval |

One extra, beyond the spec: I can draft the A1 reply for you to review. It would add a ready-to-send email, and this offer's five-day window earns it. I'll build it only on your approval.

## Evidence status

Verified: none yet. No ID details were supplied here, and none are needed for this assessment.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Marrowgate Housing Limerick housing association" was refused. It would have fed role reality's organization row and RR1 |
| 2. Role-family sweep | unavailable | The search "Payroll Administrator salary Ireland Limerick PAYE PRSI USC" was refused. It would have given the market calibration and tested €40,000 against role norms |
| 3. Hiring manager's public footprint | unavailable | The search on the Finance Manager's name and the employer was refused. It would have informed which story to lead with |

I've dropped the three searches rather than retry them.

If you want the dossier file for later use or for interview prep, say so and I'll produce it.

**Upgrade menu**

- Grant search permission → RR1, the market band for R1 and the manager's footprint all firm up.
- Your pay floor and commute limits → R1 and R2 move from `unclear` to met or failed.
- The certificate's module list, or a payslip layout → R4 moves toward `direct`.
- The written contract → RR3 closes, and the pension scheme details frame G2.

**Questions**

Q1 (G1) — Was your hotel group's payroll run on Irish PAYE, PRSI and USC, and what did the certificate cover? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

Q2 (R1, R2) — Does €40,000 meet your minimum pay, and can you work two days a week in the Limerick office? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.