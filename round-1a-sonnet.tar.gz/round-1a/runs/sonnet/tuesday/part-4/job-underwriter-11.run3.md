# Job Underwriting — Duinvaart Cold Chain (A) and Kroonhaven Foods (B)

## Decision snapshot

**You asked whether either is worth your time. Duinvaart: yes, apply. Status: `conditional_go`. Kroonhaven: no, don't spend tailoring effort on it. Status: `no_go`, because R10, R12 and R13 are `must_have` rows with no planning evidence behind them.**

### A. Operations Analyst, Duinvaart Cold Chain, Rotterdam

**Fit ledger.**

- `hard_gate`: unclear: R1 (Hybrid, three days in Rotterdam)
- `must_have`: direct: R2, R3, R4
- `important`: direct: R5a, R6 · unclear: R5b (Temperature compliance on refrigerated fleet)
- `preferred`: adjacent: R7 (Dutch a plus)

R5b: cold-chain exposure is unconfirmed; R7 (`medium`): conversational Dutch, limit named.

**Opportunity ledger.** The posting is concrete: named metrics and a named tool (RR3). The pay is not stated (RR1), the commute is unknown (RR2), and the working language with depot managers is unknown (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Hybrid, three days in Rotterdam); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) three days a week in Rotterdam is workable for you (R1, RR2); (2) the refrigerated-fleet side is presented as adjacent unless you have real exposure to it (R5b).

### B. Supply Planner, Kroonhaven Foods, Utrecht

**Fit ledger.**

- `hard_gate`: unclear: R8 (On-site in Utrecht)
- `must_have`: adjacent: R9 (Fluent Dutch) · unclear: R11 (Advanced Excel) · absent: R10 (3+ years planning in FMCG), R12 (SAP IBP or similar), R13 (Own the 13-week supply plan)
- `important`: adjacent: R14 (Run the weekly S&OP meeting)

R10, R12, R13: no planning work on the record; R14 (`medium`): a weekly review you ran is the nearest bridge, its limit named.

**Opportunity ledger.** The role is clearly scoped (RR6). The pay is not stated (RR5) and the commute is unknown (RR7). The weakness is on the fit side, not the opportunity side.

- **Hard gates:** none failed; unconfirmed: R8 (On-site in Utrecht); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **What would change this:** documented planning work (R10, R13) and a planning-system exposure (R12) that I can't see in your background, plus Dutch you could run a meeting in (R9).

## Role reality

| Role | Element | What it is | Provenance |
|---|---|---|---|
| A | Organization | Duinvaart Cold Chain, a refrigerated-fleet operator, Rotterdam | `[grounded]` posting header |
| A | Mandate | Track on-time delivery and temperature compliance, weekly Power BI dashboards, route changes with depot managers | `[grounded]` posting |
| A | Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` posting |
| A | Scope read | A standard analyst seat that matches the kind of work you do now, with a cold-chain layer added | `[inferred]` from the posting's duties against your stated background |
| A | Market calibration | Not run; the posting gives no pay figure | `[grounded]` posting silent on pay |
| B | Organization | Kroonhaven Foods, an FMCG chilled ready-meals maker, Utrecht | `[grounded]` posting header |
| B | Mandate | Own the 13-week supply plan, balance capacity against forecast, run weekly S&OP | `[grounded]` posting |
| B | Working pattern | On-site in Utrecht | `[grounded]` posting |
| B | Scope read | A planning seat that is yours from day one: the plan and the meeting are both owned, not shared | `[inferred]` from "own" and "run" in the posting |
| B | Market calibration | Not run; the posting gives no pay figure | `[grounded]` posting silent on pay |
| Both | Contradictions | None inside either posting; neither checked against the employer's own site | `[grounded]` postings read, nothing else fetched |

## Evidence map

**A. Duinvaart**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, three days a week in Rotterdam | hard_gate | unclear | none | hard_gate | You stated no location or schedule limits. Your current job is in Amsterdam, which doesn't settle where you live or whether the commute works | `[grounded]` no constraint given | G1 |
| R2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier, self-reported and specific, with no document inspected | `[grounded]` your background | none |
| R3 | Strong SQL | must_have | direct | medium | none | SQL daily for four years; "strong" will be probed in a technical screen | `[grounded]` your background | none |
| R4 | Power BI or Tableau | must_have | direct | medium | none | Power BI daily, including a dashboard depot managers use | `[grounded]` your background | A dashboard screenshot would raise it to `high` |
| R5a | Track on-time delivery | important | direct | medium | none | You built the on-time delivery dashboard | `[grounded]` your background | none |
| R5b | Track temperature compliance on refrigerated vehicles | important | unclear | none | discovery | Nothing said about temperature, cold chain or compliance monitoring. Cold-chain operators often treat temperature data as a regulated record | `[grounded]` background silent; `[generic]` on regulated records | G2 |
| R6 | Work with depot managers on route changes | important | direct | medium | none | You ran the weekly route-performance review, and depot managers use your dashboard | `[grounded]` your background | none |
| R7 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational Dutch is credible. The limit is that written or meeting-level Dutch is not established | `[grounded]` your stated level | G3 |

**B. Kroonhaven**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R8 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | No location or schedule limits stated | `[grounded]` no constraint given | G1 |
| R9 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational is below fluent; the limit is meetings and written plans in Dutch | `[grounded]` your stated level | G3 |
| R10 | 3+ years supply or demand planning in FMCG | must_have | absent | none | capability | You said you have never worked in planning, and the parcel-carrier work is a different sector | `[grounded]` your statement | G4 |
| R11 | Advanced Excel | must_have | unclear | none | discovery | Excel isn't mentioned in your background; SQL and Power BI are not a substitute on a planner's job | `[grounded]` background silent | Confirm Excel depth if you ever revisit this role |
| R12 | SAP IBP or a similar planning system | must_have | absent | none | capability | Your tools are SQL and Power BI, which are analytics tools rather than planning systems | `[grounded]` your background | G4 |
| R13 | Own the 13-week supply plan, capacity against forecast | must_have | absent | none | capability | No planning work stated | `[grounded]` your statement | G4 |
| R14 | Run the weekly S&OP meeting | important | adjacent | medium | transferability | You ran a weekly route-performance review. The limit is that S&OP means reconciling demand, supply and finance and owning the plan being discussed | `[grounded]` your review; `[generic]` on what S&OP involves | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and schedule (R1, R8) | hard_gate | No stated limits on commute, office days or relocation | Both postings carry a place and presence term, and this decides whether A is a go | Living within reach of Rotterdam or Utrecht, or a move you would make | Nothing needed beyond your answer | `[grounded]` no constraint given |
| G2 | Temperature compliance (R5b, important) | discovery | The background is silent on temperature or cold chain | It is the one duty in A that your current job may not have exercised | Excursion or SLA reporting, any monitored-goods or regulated-delivery work, alerting on vehicle data | A sanitized exception report or dashboard view | `[grounded]` background silent; `[inferred]` that it matters most to A because it is named in the posting's first sentence |
| G3 | Working-level Dutch (R7, R9) | transferability | Conversational Dutch only | Preferred for A, must-have for B | Running a meeting, writing a report, or handling depot or customer calls in Dutch | A short written Dutch sample, or a certificate level | `[grounded]` your stated level |
| G4 | Supply planning (R10, R12, R13) | capability | No planning work, system or ownership evidence | Three must-haves for B with nothing direct or adjacent behind them | Nothing identified yet; closure means a role that builds planning exposure first | A planning course or a system certification | `[grounded]` your statement; `[generic]` that analytics roles near logistics are a common route toward planning seats |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | A: pay not stated | unknown | — | (no figure in the posting) | The band may be fine; the posting simply doesn't publish it | `[grounded]` posting silent | What is the salary range for this post? | unresolved |
| RR2 | A: Rotterdam three days against an Amsterdam work history (R1) | unknown | — | "three days a week in our Rotterdam office" | The commute may be unworkable, or you may already live nearby | `[inferred]` from your current Amsterdam job against the posting's location | Are the three office days fixed, or can they flex around depot visits? | unresolved |
| RR3 | A: duties are specific and measurable | positive_signal | — | "Track on-time delivery and temperature compliance... build weekly dashboards in Power BI" | Success is defined by named metrics, and they overlap with work you already do | `[grounded]` posting | What would a good first quarter look like in these metrics? | noted |
| RR4 | A: working language with depot managers unclear | unknown | — | "Dutch a plus" | Depot-level conversations may run in Dutch even if the team is bilingual | `[inferred]` from "a plus" plus depot-level work | Which language do the depot reviews and dashboards run in? | unresolved |
| RR5 | B: pay not stated | unknown | — | (no figure in the posting) | The band may be fine; the posting simply doesn't publish it | `[grounded]` posting silent | What is the salary range for this post? | unresolved |
| RR6 | B: scope is clear | positive_signal | — | "Own the 13-week supply plan... run the weekly S&OP meeting" | The mandate is concrete and measurable | `[grounded]` posting | Who sits in the weekly S&OP, and what decisions does it make? | noted |
| RR7 | B: on-site Utrecht (R8) | unknown | — | "On-site in Utrecht" | Presence may be strictly five days | `[grounded]` posting says on-site with no day count | Does on-site mean five days a week? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Settle the commute (G1) before applying to Duinvaart | R1 is the one unconfirmed gate | `[grounded]` R1 | pending your approval |
| A2 | Apply to Duinvaart and lead with the on-time dashboard and the weekly route review, the closest matches to R4, R5a, R6; no new resume wording is proposed here | Those rows are `direct` | `[grounded]` R4, R5a, R6 rows | pending your approval |
| A3 | Ask RR1, RR2, RR4 verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| B1 | Don't spend tailoring time on Kroonhaven now; revisit only if planning exposure turns up | R10, R12, R13 are `absent` | `[grounded]` the rows | pending your approval |
| B2 | If you apply to Kroonhaven anyway, expect a literal screen against R10 and R12 | Years-and-systems requirements are commonly screened as written | `[generic]` screening pattern | pending your approval |

## Evidence status

Verified: none yet. Your background is self-reported and no document has been inspected.

Research tier: L0 — no searches

| Target | Status | What it moved, or would have |
|---|---|---|
| Duinvaart: 1. Official site and careers page | unavailable | Not run this pass. It would have confirmed the posting is live and the company exists as described (RR1, RR2, contradictions) |
| Duinvaart: 2. Role-family sweep | unavailable | Not run this pass. It would have set a market band for the pay RR1 leaves open |
| Duinvaart: 3. Hiring manager's public footprint | n/a | No name was given |
| Kroonhaven: 1. Official site and careers page | unavailable | Not run this pass. It would have confirmed the posting is live (RR5, RR7) |
| Kroonhaven: 2. Role-family sweep | unavailable | Not run this pass. It would have set a market band for the pay RR5 leaves open |
| Kroonhaven: 3. Hiring manager's public footprint | n/a | No name was given |

I can turn this assessment into `tuesday-dossier.md` whenever you want a file to keep.

## Upgrade menu

- Your commute answer (G1) → R1 and R8 close; Duinvaart moves to `go` or stays conditional on that alone.
- A cold-chain or compliance-style report you built (G2) → R5b resolves, and `medium` confidence on R4 can rise to `high` if the artifact is a dashboard.
- A hiring manager's name for either role → role reality's scope read and which story to lead with.
- A research pass on both employers (up to 5 searches and 2 fetches each) → live-posting checks and a pay band for RR1 and RR5. Say the word and it runs. If it surfaces something that warrants more, I can offer up to 5 more searches and 2 more fetches once, for deeper diligence.

**G1** — Where do you live, and is three days a week in Rotterdam (or five in Utrecht) workable for you?
**G2** — Has any of your work touched temperature-controlled goods, SLA compliance reporting, or exception monitoring on vehicles?
**G3** — Could you run a meeting or write a report in Dutch today, or is it conversation only?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.