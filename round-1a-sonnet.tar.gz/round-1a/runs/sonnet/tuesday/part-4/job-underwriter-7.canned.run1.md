Searches are back: the employer exists and the pay data is in. I'm fetching the careers page to check that the posting is live and matches your copy.
## Decision snapshot

**Yes, this is worth applying for. No hard gate fails (R1, R2), and the gaps can be recovered. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3, R5 · adjacent: R4 (Care for housebound adults in their own homes) · unclear: R6 (Care planning and clear written records on the electronic patient record)
- `important` — direct: R8, R9 · adjacent: R7 (Small caseload of your own) · unclear: R10 (Leg-ulcer care), R11 (Continence care), R12 (End-of-life visits)
- `preferred` — absent: R13 (Doppler assessment for leg ulcers)

R4 and R7 — credible bridges, limits named; R6 (`low`) — your CV is silent, one answer would settle it; R13 — a stated gap on a preferred row.

**Opportunity ledger.** The advert looks sound on what it shows. The pay is stated and sits inside the survey band (RR4), the support structure is stated (RR2), and the team lead has spoken on training for staff new to community work (RR3). Whether the posting is still live (RR1) and what the rota and terms are (RR5) are not yet confirmed.

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed live on the employer's own careers page — RR1; (2) your records and care-planning experience comes out in an answer to G1 — R6; (3) the home-visiting and caseload bridge is framed as adjacent (R4, R7) and Doppler is stated plainly as not yet done (R13).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015, 410 staff, four locality hubs | `[grounded]` the company's About page, fetched |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin and care planning, on an electronic patient record | `[grounded]` advert |
| Caseload and support | A small caseload of your own, supported by a senior community nurse | `[grounded]` advert |
| Hiring contact | Rhiannon Mabbott leads the Halifax district nursing team, after eleven years as a district nurse; at a 2025 forum she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` forum speaker page, found by search |
| Scope read | A Band 5 post with a small, supported caseload reads as an entry route into community nursing, not a senior solo role | `[inferred]` from the advert's "small caseload" and "supported by a senior community nurse" |
| Pay and travel | £31,050–£37,800 plus mileage; pool cars provided | `[grounded]` advert |
| Market calibration | A 2026 survey of community staff nurses at Band 5 in England puts median basic pay at £34,300 (interquartile range £32,400–£36,600). Mileage was paid to 61% of respondents and 24% had a pool or lease car. The advert's range brackets that median, and a provided pool car is less common than paid mileage. This is a pattern, not this employer's offer | `[generic]` one salary survey, found by search |
| Unknowns | Whether the post is still open; shift pattern, weekend and evening rota; whether training in Doppler assessment is provided; terms and conditions | `[inferred]` from the advert's silence on each |
| Contradictions | The advert and the About page agree on adult community nursing in Calderdale. The careers page was not read, so the posting itself is not cross-checked | `[grounded]` About page against advert |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | Your CV states Registered Nurse (Adult), registration active, revalidation due March 2028. It is self-reported and I have not checked the register; checking is yours | `[grounded]` CV | none |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Your CV states a full UK licence, category B. Pool cars are provided, so a licence is the only driving requirement | `[grounded]` CV and advert | none |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward, per your CV. This is a length-of-experience requirement, not a gate, and is met on its face | `[grounded]` CV | none |
| R4 | Caring for housebound adults in their own homes | must_have | adjacent | medium | transferability | Your 18 months in the discharge-to-assess team visited patients at home in their first week after discharge. Limit: that is a time-limited post-discharge visit, not an ongoing district nursing relationship with housebound adults | `[grounded]` CV for the visits; `[inferred]` for the limit, from the advert's "housebound adults" | see G4 |
| R5 | Wound care | must_have | direct | medium | none | Your CV names pressure ulcers and surgical wounds. The advert's wound care is not limited to those types, and leg ulcers are carried separately at R10 | `[grounded]` CV | none |
| R6 | Care planning and clear, timely written records on the electronic patient record | must_have | unclear | low | discovery | Your CV is silent on records, care planning and any electronic record system. Ward and discharge work involves documentation, but that is not something your CV states, so it cannot be asserted as yours | `[grounded]` CV silence | ask G1 |
| R7 | A small caseload of your own, supported by a senior community nurse | important | adjacent | medium | transferability | You told me you have never held your own caseload. The nearest evidence is the discharge-to-assess visits. The support the advert describes suggests a ramp-up for newcomers | `[grounded]` your statement and CV; `[inferred]` ramp-up, from the advert's support wording | frame as adjacent; ask RR2 |
| R8 | Catheter care | important | direct | medium | none | Your CV names catheter care. The advert pairs it with continence care, which is R11 | `[grounded]` CV | none |
| R9 | Insulin administration | important | direct | medium | none | Your CV names insulin administration. The advert also lists care planning, which sits in R6 | `[grounded]` CV | none |
| R10 | Leg-ulcer care | important | unclear | low | discovery | Your CV names pressure ulcers and surgical wounds, not leg ulcers. Wound work is indirect context, not evidence of leg-ulcer care | `[grounded]` CV | ask G2 |
| R11 | Continence care | important | unclear | low | discovery | Your CV names catheter care but not continence care more widely | `[grounded]` CV | covered by G1's wider recall if useful |
| R12 | End-of-life visits | important | unclear | low | discovery | Your CV is silent on end-of-life care. Acute medical wards and home visits after discharge may have involved it, but nothing here says so | `[grounded]` CV silence | ask G3 |
| R13 | Doppler assessment for leg ulcers (desirable) | preferred | absent | none | capability | You told me you have never done one. It is listed as desirable, not essential, and the team lead has spoken publicly on Doppler training for newcomers (RR3) | `[grounded]` your statement, advert and forum page | state plainly; ask RR3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Records and care planning on an electronic patient record (R6, must_have) | discovery | Your CV is silent on records, care plans and any electronic record system | A must-have the advert says is essential; an answer could settle it and move the decision from `conditional_go` toward `go` | Writing visit or ward notes on an electronic system; contributing to discharge or care plans; handover notes others relied on; any audit of your documentation | A redacted note template, a discharge-plan format, or a line from an appraisal | `[grounded]` CV silence; `[inferred]` that an answer could move the status |
| G2 | Leg-ulcer care (R10, important) | discovery | Pressure-ulcer and surgical-wound care are stated; leg ulcers are not | The advert lists leg-ulcer care first among its wound work and the team lead has spoken on leg-ulcer clinics (RR3) | Compression bandaging; assessing a leg wound's cause; follow-up on venous or mixed ulcers during ward or home visits | A competency record or training certificate, if you hold one | `[grounded]` CV and advert; `[grounded]` forum page for the team lead's interest |
| G3 | End-of-life visits (R12, important) | discovery | The CV is silent on end-of-life care | It is a stated duty and affects how the work is described to you in interview | Caring for dying patients on the ward; end-of-life care in discharge visits; anticipatory medicines; supporting relatives | Training record or reflective account | `[grounded]` CV silence |
| G4 | Home visiting and caseload bridge (R4, R7; must_have, important) | transferability | Discharge-to-assess visits at home, but no own caseload and no long-term district nursing | The most likely objection to a candidate from an acute ward; a stated limit reads stronger at interview than an overstated bridge | The shape of your visit list; how many patients you saw in a week; any follow-up you owned between visits | A rota or visit-list format, with patient details removed | `[inferred]` bridge derived from your discharge-to-assess role; `[generic]` that this is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting live status not confirmed | unknown | — | "Join our district nursing team" | The company's About page says current vacancies are on its careers page, which I did not read, so the post's live status and closing date are unchecked | `[grounded]` About page wording; `[inferred]` that the post may or may not still be open | Is the Band 5 Community Staff Nurse post still open, and what is the closing date? | unresolved |
| RR2 | Support structure stated | positive_signal | — | "supported by a senior community nurse" | A newcomer to community work would get a named senior to learn from | `[inferred]` from the advert's wording | How big is a new Band 5 nurse's caseload in the first few months, and how often do they work alongside the senior nurse? | noted |
| RR3 | Team lead publicly supports training for newcomers | positive_signal | — | "Doppler assessment for leg ulcers" (desirable) | The post may include Doppler training, given the team lead's talk on training staff new to community work | `[grounded]` forum speaker page; `[inferred]` for how it applies to this post | Is Doppler training provided to new starters, and over what timescale? | noted |
| RR4 | Pay stated and within the survey band | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The advert is transparent and its range brackets the survey median | `[grounded]` advert; `[generic]` survey band, one source, not this employer's offer | Where in the range would a nurse with five years' ward experience start? | noted |
| RR5 | Hours, rota and terms unstated | unknown | — | "end-of-life visits" | A community service with end-of-life visits may include evening or weekend work, and the advert does not say | `[generic]` pattern for community nursing services; the advert is silent | What is the shift pattern, is there weekend or evening work, and what are the terms and conditions? | unresolved |

## Application plan

Everything below is proposed and nothing is final until you approve it. That covers the advice in the Why column as well as any wording. I would not write a line for your CV until G1 to G3 are answered.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with the discharge-to-assess secondment, stated as home visits in the first week after discharge, not as district nursing | R4 and R7 are adjacent, and the stated limit reads stronger than an overstated bridge | `[grounded]` CV | resume_edits_pending_approval |
| E2 | Pull wound care, catheter care and insulin administration out of the skills list and into the experience entries, in your CV's own wording | R5, R8 and R9 are `direct` and currently easy to miss | `[grounded]` CV | resume_edits_pending_approval |
| A1 | Take up the advert's invitation to an informal chat with Rhiannon Mabbott, and ask the RR1, RR2, RR3 and RR5 questions verbatim | The register doubles as interview preparation | `[grounded]` advert and register | pending your approval |
| A2 | In the application, say plainly that you have not done a Doppler assessment, and ask whether training is provided | R13 is a stated gap on a desirable row, and the team lead has spoken on training newcomers | `[grounded]` your statement and forum page | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none. Your National Insurance number isn't needed for this and I haven't used it.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Community Staff Nurse Band 5 district nursing Calderbrook Community Health CIC job"; fetched "About Calderbrook Community Health" (calderbrookhealth.example/about). Role reality's organization row: the employer exists as the advert describes it. The careers page was not read, so the posting's live status is RR1 |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse district nursing Calderdale salary Agenda for Change 2026 pay scale", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Market calibration `[generic]` and RR4 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Role reality's hiring-contact row, RR3 and A2 |

## Dossier offer

I can write this up as a `tuesday-dossier.md` if you want to keep it or carry it into later work.

## Upgrade menu

- The live posting or the employer's careers page link → RR1 closes, and the employer is cross-checked against the posting itself.
- Answers to G1, G2 and G3 → R6, R10 and R12 move from `unclear` toward `direct` or `adjacent`, and `conditional_go` could become `go`.
- A redacted visit-list format, a competency record or a training certificate → the matching row's band can rise toward `high`.
- The shift pattern and terms, from the informal chat → RR5 closes.
- A deeper research pass on Calderbrook Community Health (leadership changes, inspection history, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

G1 — Have you written visit notes, care plans or discharge plans on an electronic record system, on the ward or in the discharge-to-assess team, and what did you record?
G2 — Have you cared for a patient's leg ulcer (for example compression bandaging or assessing why a leg wound wasn't healing), and which part was yours?
G3 — Have you looked after dying patients on the ward or in your home visits, and what was your role?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.