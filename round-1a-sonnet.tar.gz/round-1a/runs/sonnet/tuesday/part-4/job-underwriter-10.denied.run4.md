Reading is done. I'm now running the research step: checking whether Fernquay exists, a salary sweep for Irish product designers, and Ronan Kehoe's public professional footprint.
I couldn't check Fernquay online. The three web searches were refused, so nothing below comes from outside your posting and message, and I haven't retried.

**Decision snapshot**

**Worth taking the call, and I can't confirm they're legit from here. Nothing you've shared asks you for money or ID, or points to a scam. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R8 (Salary €52,000–€60,000), R9 (Hybrid, two days a week in Galway)
- `must_have` — direct: R1, R2, R3, R5
- `important` — adjacent: R4 (research calls with school owners), R6 (own booking flow end to end), R7 (first designer, no design peers)

R4 — usability sessions confirmed, owner-style interviews not; R7 — the step to sole designer, its limit named.

**Opportunity ledger.** The employer is unverified (RR1), the sender's identity is unconfirmed (RR2), and the equity terms and runway are unstated (RR4, RR5). The posting is open about pay and equity (RR3), and the first-designer scope is a real step up for you (RR6).

- **Hard gates:** none failed; unconfirmed: R8 (Salary €52,000–€60,000), R9 (Hybrid: two days a week at the Galway office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Fernquay's own site or careers page shows this role and names Ronan Kehoe, and the invite comes from a company domain (RR1, RR2); (2) pay and office days fit your limits (R8, R9); (3) being the only designer is something you want (R7, RR6).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, booking software for sea-kayak and surf schools. Not verified outside the posting | `[grounded]` posting; existence unchecked (RR1) |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship with two engineers | `[grounded]` posting |
| Reporting | Works most closely with co-founder Ronan Kehoe, who is also the sender of your WhatsApp | `[grounded]` posting and your message agree on the name |
| Pay | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting |
| Working pattern | Hybrid, two days a week in the Galway office | `[grounded]` posting |
| Scope read | A founder-adjacent solo design seat with no stated design lead | `[inferred]` from "first designer" and the absence of any design hire above you |
| Market calibration | Not run: the role-family search was refused, so no band is offered | — |
| Unknowns | Funding and runway, equity terms, who sets product priorities, what the CTO's part in the process is | — |
| Contradictions | None between the posting and the message | `[grounded]` posting against your message |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years of product design | must_have | direct | medium | none | You describe 4 years as a product designer at a Dublin travel-booking company. This is self-report in prose, with no artifact inspected yet | `[grounded]` your background | none |
| R2 | Strong Figma | must_have | direct | medium | none | "Figma daily" is your own statement. The case study they praised is the inspectable artifact, but I haven't seen it | `[grounded]` your background | offer: link the case study to raise it |
| R3 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers, which is user research you ran yourself | `[grounded]` your background | none |
| R4 | Research calls with school owners | important | adjacent | medium | transferability | Usability sessions are confirmed. Limit: you haven't said you ran open-ended discovery interviews, which is likely what owner calls are. Interviewers often probe this distinction | `[grounded]` your background; `[generic]` that discovery and usability research differ | see G1 |
| R5 | Working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your background | none |
| R6 | Own the booking flow end to end | important | adjacent | medium | transferability | You redesigned the checkout flow. Limit: checkout is one stage of a booking flow, and you haven't said you owned the stages before it | `[grounded]` your background; `[inferred]` that end-to-end is broader than checkout | see G2 |
| R7 | Be the first and only designer | important | adjacent | low | transferability | You confirm you've never been the only designer. What carries over is owning the checkout redesign and running your own research. Limit: no experience setting design direction with no peers | `[grounded]` your statement; `[inferred]` the bridge from the checkout ownership | see G3 |
| R8 | Salary €52,000–€60,000 (your pay floor is not given) | hard_gate | unclear | none | hard_gate | The posting states the band but I don't know your floor, so I can't say whether it clears | `[grounded]` posting; your constraint unstated | Q1 |
| R9 | Two days a week at the Galway office | hard_gate | unclear | low | hard_gate | You moved back to Galway last year, so the location likely works. Your view on fixed office days is unstated | `[grounded]` posting and your move; `[inferred]` that you live in Galway | confirm on the call |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owner-style research (R4, important) | transferability | Usability sessions with customers; no mention of open-ended discovery interviews | The posting names research calls with school owners as a core duty | Customer interviews before a redesign; calls to understand why bookings were dropped; feedback sessions with operators or partners | A research plan, a synthesis doc, or a case-study section on the interviews | `[grounded]` your background; `[generic]` that interviewers probe this line |
| G2 | End-to-end booking flow (R6, important) | transferability | A checkout redesign; the stages before and after it are unstated | "End to end" is the job's headline scope | Work on search, availability, basket or confirmation emails; a flow map you drew | The checkout case study, or a flow diagram | `[grounded]` your background; `[inferred]` the scope gap |
| G3 | Sole-designer scope (R7, important) | transferability | Always worked alongside other designers | A solo seat means no design peer to review or set direction | Times you set a standard, a pattern library or a process without a design lead | A design-system page, or a process doc you wrote | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "six people in Galway making booking software for sea-kayak and surf schools" | The company may be too new or small to have a footprint, or I couldn't check because search was refused. This is a gap in what I could check, not a finding about Fernquay | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your own careers page? | unresolved |
| RR2 | First contact by WhatsApp; invite sent by email | unknown | — | "I have emailed you a calendar invite with the video link" | Scheduling by chat is not a warning sign by itself. The sender's identity stays unconfirmed until the invite's email domain is checked | `[generic]` that small teams often use chat for scheduling; `[grounded]` the message | Could you send the invite from your company email, and confirm Ronan and Saoirse's roles? | unresolved |
| RR3 | Pay and equity stated up front | positive_signal | — | "€52,000–€60,000 plus 0.5–1% equity" | The posting is transparent about pay | `[grounded]` posting | What's the vesting schedule on the equity? | noted |
| RR4 | Equity terms unstated | unknown | — | "0.5–1% equity" | Vesting, share class and strike price may matter more than the percentage | `[generic]` that equity terms vary widely | What are the vesting, cliff and share class? | unresolved |
| RR5 | Funding and runway unstated | unknown | — | "We are six people" | Runway for a six-person team is unknown | `[generic]` pattern for early-stage teams | How long is the runway, and how is the company funded? | unresolved |
| RR6 | Solo-designer scope without a design lead | risk_signal | low | "You would be our first designer" | You may carry design decisions with nobody senior to review them, which is new for you | `[inferred]` from the posting against your never-the-only-designer history | Who reviews design decisions, and who sets product priorities? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, find Fernquay's own site or careers page yourself and check it lists this role and names Ronan Kehoe. Check which email domain the invite came from | see RR1, RR2 | `[grounded]` register | pending your approval |
| A2 | Ask RR1, RR2, RR4, RR5 and RR6's questions verbatim on the call | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A3 | If asked about being the only designer, you could say: "I haven't been the only designer. I redesigned our checkout flow and ran monthly usability sessions with customers, working in a squad with four engineers." Every clause traces to your own words | see R7 | `[grounded]` your background | pending your approval |
| A4 | Confirm office days and your pay floor with them before investing in later rounds | see R8, R9 | `[grounded]` gate rows | pending your approval |

When you want to rehearse the video call, mock-interview can run that prep.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search for Fernquay was refused. It would have fed role reality's organization row and RR1 |
| 2. Role-family sweep | unavailable | The search for Irish product-designer salary bands was refused. It would have filled market calibration and checked the band against your floor |
| 3. Hiring manager's public footprint | unavailable | A name was given (Ronan Kehoe, co-founder), so a query could be formed, but the search was refused. It would have fed the scope read and the plan's positioning |

If you'd like me to retry, grant the web-search permission and I'll run those three targets.

I'd offer to write `tuesday-dossier.md` from this assessment if you want it, no pressure.

**Upgrade menu**

- Web-search permission → RR1 and the organization row close or sharpen; the salary band is set against R8; Ronan's public professional background informs the scope read.
- Your pay floor → R8 resolves to met or failed.
- Your view on two fixed office days → R9 resolves.
- The checkout case study link, or a flow diagram → R2 and R6 can rise to `high`.
- Any discovery-interview write-up → R4 narrows.
- The invite's sending email domain → RR2 closes or escalates.

**Questions**

Q1 (R8) — What is the lowest salary you'd accept, so I can check whether the €52,000–€60,000 band works for you?

Q2 (RR2) — Did you give Ronan your number when you applied, for example on the application form, with the checkout case study attached?

Q3 (G1) — Have you ever run open-ended interviews, not usability tests, with customers? What did you learn, and what changed because of it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.