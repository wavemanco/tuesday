I'm still reading the underwriting playbook's reference files (evidence map shape, gap rules, research tiers) so I can build the assessment properly; then I'll deliver it.
**Yes, worth applying for. Status: `go`.** R1 and R2, the two hard gates, both come out `direct`. Your gaps are leg-ulcer work, holding your own caseload and Doppler assessment. The advert allows for each of them, so none is a barrier.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3, R4, R5a, R6a, R7 · adjacent: R5b (Leg-ulcer care) · unclear: R9 (Clear, timely written records on the electronic patient record)
- `important` — adjacent: R10 (Own small caseload) · unclear: R6b (Continence care), R8 (End-of-life visits), R11 (Care planning)
- `preferred` — absent: R12 (Doppler assessment)

R5b — a credible bridge, its limit named; R10 — home visits without owning the caseload; R12 — absent, and named in the advert as desirable only.

**Opportunity ledger.** The advertised pay sits inside the survey range (RR3) and the caseload is supported, with the team lead offering a chat (RR5). Open items are whether the posting is still live (RR1), how mileage works alongside pool cars (RR2), and the rota (RR4).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** a posting that turns out closed (RR1), or a rota (RR4) that clashes with constraints you haven't told me about.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract. Founded 2015, 410 staff, four locality hubs | `[grounded]` its About page (search result) |
| Mandate | District nursing for housebound adults at home: wounds and leg ulcers, catheter and continence care, end-of-life visits, insulin, care planning, on an electronic patient record | `[grounded]` advert |
| Structure | A small caseload of your own, supported by a senior community nurse | `[grounded]` advert |
| Pay and vehicle | £31,050–£37,800 plus mileage; pool cars provided | `[grounded]` advert |
| Market calibration | Band 5 community staff nurse, England: median £34,300, interquartile range £32,400–£36,600, from a 2026 pay survey of 1,240 respondents. Basis: one search, snippet only, page not fetched. It is a market band, not this employer's offer | `[generic]` Wardround 2026 survey; `[grounded]` advert for the advertised range |
| Hiring contact | Rhiannon Mabbott leads the Halifax district nursing team after eleven years as a district nurse. At a 2025 forum she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` forum speaker page (search result) |
| Unknowns | Rota, weekends and on-call; caseload size; how mileage works with pool cars; first-year expectations | `[grounded]` advert is silent on each |
| Contradictions | None found in the advert; the careers page was not reached, so the advert was not checked against it | `[grounded]` fetch returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | You state active registration as a Registered Nurse (Adult), revalidation due March 2028. This is self-reported, and the register entry hasn't been inspected. I won't use your PIN in any search; checking it is for you and the employer | `[grounded]` CV | none |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | You state a full UK licence, category B. Self-reported; pool cars are provided, so no own-car need is stated | `[grounded]` CV, advert | none |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward. It is a length-of-experience item, not a gate, so it is graded as an ordinary requirement | `[grounded]` CV | none |
| R4 | Caring for housebound adults in their own homes | must_have | direct | medium | none | Eighteen months seconded to the discharge-to-assess team, visiting patients at home in their first week after discharge. Those are post-discharge patients, and the CV doesn't say how many were housebound long-term | `[grounded]` CV | none |
| R5a | Wound care | must_have | direct | medium | none | Pressure ulcers and surgical wounds, stated. Setting is acute ward and home visits | `[grounded]` CV | none |
| R5b | Leg-ulcer care | must_have | adjacent | medium | transferability | Pressure-ulcer and surgical wound care carries over. Limit: the CV doesn't mention leg ulcers or compression therapy. Strengthener: any leg-ulcer dressings or compression you applied or saw | `[inferred]` adjacency from the wound care stated | G1 |
| R6a | Catheter care | must_have | direct | medium | none | Stated on the CV, with no setting or scale given | `[grounded]` CV | none |
| R6b | Continence care | important | unclear | low | discovery | The CV is silent on continence care beyond catheters. I tiered it `important` because the advert pairs it with catheters in one duty | `[grounded]` CV silence, advert | G3 |
| R7 | Insulin administration | must_have | direct | medium | none | Stated on the CV | `[grounded]` CV | none |
| R8 | End-of-life visits | important | unclear | low | discovery | The CV is silent on palliative or end-of-life care. On an acute medical ward it may exist, but that is a lead, not evidence | `[grounded]` CV silence | G3 |
| R9 | Clear, timely written records, on an electronic patient record | must_have | unclear | low | discovery | Marked essential. The CV doesn't mention documentation or any record system. Five years of ward nursing involves recording, but that is not a claim you've made | `[grounded]` CV silence | G4 |
| R10 | Own small caseload, supported by a senior community nurse | important | adjacent | medium | transferability | You've said you've never held your own caseload. The home visits in discharge-to-assess are the nearest work. Limit: you did not own a caseload. The advert provides senior support for exactly this | `[grounded]` your statement, CV | none; raise with the team lead (A1) |
| R11 | Care planning | important | unclear | low | discovery | The CV doesn't mention care planning. Discharge-to-assess may have involved it, which is a lead only | `[grounded]` CV silence | G3 |
| R12 | Doppler assessment for leg ulcers (desirable) | preferred | absent | none | capability | You've said you've never done one. Desirable, not essential | `[grounded]` your statement, advert | closure path in G5 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Leg-ulcer care (R5b, must_have) | transferability | Pressure-ulcer and surgical wound care; no leg-ulcer or compression work stated | A named duty at `adjacent`, and the team lead has spoken on leg-ulcer clinics | Applying or observing compression bandaging; leg-ulcer dressing changes on the ward; tissue viability input on a leg wound | A competency record or training certificate, if you have one | `[grounded]` CV; `[inferred]` that the team lead cares about it, from her talk topic |
| G3 | End-of-life, continence and care-planning work (R8, R6b, R11, all important) | discovery | The CV is silent on all three | Each is a named duty, so a short answer could move three rows | Palliative patients on the ward; syringe-driver or symptom-control involvement; bladder and bowel care beyond catheters; writing or updating a care or discharge plan in discharge-to-assess | A care-plan template you used, or a training record | `[grounded]` CV silence |
| G4 | Documentation and the electronic patient record (R9, must_have) | discovery | The CV names no record system and says nothing on documentation | Essential in the advert, and your records are what the senior nurse will rely on at the start | Which electronic system the ward and discharge-to-assess used; any documentation audit or feedback | An audit result or a reference mentioning records | `[grounded]` CV silence |
| G5 | Doppler assessment (R12, preferred) | capability | No evidence and no claim | Desirable, not required | No question needed. The closure path is to ask whether the employer trains staff in it | Any course or competency sign-off, once done | `[grounded]` your statement; `[inferred]` that training is offered, from the team lead's talk on Doppler training for staff new to community work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting still live is unconfirmed | unknown | — | "Community Staff Nurse, Band 5 — Calderbrook Community Health CIC, Halifax" | The careers page wasn't reached at the address I tried, so the posting may be closed, or my address may simply be wrong | `[grounded]` fetch returned no page at that address | Is this post still open, and what is the closing date? | unresolved |
| RR2 | Mileage stated alongside pool cars | unknown | — | "pool cars are provided" … "plus mileage" | Mileage may apply to business miles in an own car or in some other arrangement; the advert doesn't say | `[inferred]` from the two terms side by side | When is mileage paid, given that pool cars are provided? | unresolved |
| RR3 | Advertised pay against the market band | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The advertised range spans the survey's median and interquartile range, so the pay is not out of line | `[grounded]` advert; `[generic]` survey band, England-wide, not this employer | Where in the range would five years' acute experience be placed? | noted |
| RR4 | Rota and hours unstated | unknown | — | The advert is silent on hours, weekends and on-call | Visiting patients at home may include weekends or evenings; the advert doesn't say | `[grounded]` advert silence | What does the rota look like, including weekends, evenings and on-call? | unresolved |
| RR5 | Supported caseload and an open invitation to talk | positive_signal | — | "supported by a senior community nurse" … "For an informal chat about the role" | A first caseload comes with named support and a reachable lead | `[grounded]` advert | How is a caseload built up for a nurse who hasn't carried one before? | noted |

## Application plan

Everything here is proposed. Nothing goes on your CV or into a message until you approve it, and that covers the advice below as well as the table.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Put the discharge-to-assess home visiting near the top of the CV. Say plainly what it was: visits in the first week after discharge. Don't call it a caseload | R4, R10 | `[grounded]` CV | pending your approval |
| E2 | Name wound care, catheter care and insulin administration in the opening lines | R5a, R6a, R7 | `[grounded]` CV | pending your approval |
| A1 | Take up the offer of an informal chat with Rhiannon Mabbott. Ask RR1, RR2, RR4 and RR5 verbatim, and ask whether Doppler training is provided | R10, R12 and the register | `[grounded]` advert invites the chat; `[inferred]` on Doppler, from her published talk | pending your approval |
| A2 | State openly in the application that you haven't yet held your own caseload or done Doppler assessment, and show the closest work you have | R10, R12 | `[grounded]` your statement | pending your approval |

## Evidence status

Verified: none yet.

Your National Insurance number isn't needed for this, so I haven't used or repeated it.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about). Fetched calderbrookhealth.example/careers, a guessed address, and no page was there. Moved the organization row and RR1: the employer is attributable, but the posting is not confirmed live |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse district nursing salary 2026 NHS pay scale", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved the market calibration row and RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Moved the hiring-contact row and plan items A1 and G5 |

I can write this up as `tuesday-dossier.md` if you'd like to keep it.

## Upgrade menu

- Your answer to G1 → R5b's bridge narrows or stays as it is.
- Your answer to G3 → R8, R6b and R11 move off `unclear`.
- Your answer to G4 → R9 moves off `unclear`.
- The team lead's answers on rota, mileage and the closing date → RR1, RR2 and RR4 close.
- A deeper research pass on Calderbrook (leadership changes, staff and patient reports, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

G1 — Have you applied or watched compression bandaging or leg-ulcer dressings, on the ward or on home visits? What was your part in it?

G3 — Have you cared for end-of-life patients, handled continence care beyond catheters, or written or updated a care or discharge plan? Tell me which, and what was yours.

G4 — Which electronic patient record did your ward and the discharge-to-assess team use, and did you get any feedback on your records?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.