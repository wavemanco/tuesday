Still working through the assessment playbook's formatting rules; I've read most of them and I'm checking the table shapes next.
**Yes, worth applying: status `conditional_go`.** R1 and R2, the two hard gates, are `direct`; R3 and R5 are `direct`; R4 is the one must-have the CV doesn't yet evidence.

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3, R5 · unclear: R4 (Clear, timely written records)
- `important`: direct: R7, R8 · adjacent: R6 (leg-ulcer care), R10 (small caseload of your own) · unclear: R9 (End-of-life visits and care planning)
- `preferred`: absent: R11 (Doppler assessment)

R10 — a credible bridge, its limit named; R6 — wound skills carry over, leg-ulcer work unevidenced; R11 — desirable only.

**Opportunity ledger.** The employer matches its description, and the stated pay and the senior-nurse support are sound (RR1, RR2). Three things are unanswered: whether the posting is live (RR3), the terms and conditions (RR4), and the rota and caseload size (RR5).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed live, see RR3; (2) your CV shows record-keeping evidence, see R4; (3) the discharge-to-assess home visits are framed as adjacent to a caseload, never as one, see R10.

Your National Insurance number isn't needed for any of this. I haven't used it and won't repeat it.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | A community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015; 410 staff in four locality hubs | `[grounded]` "About Calderbrook Community Health" |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin, care planning, on an electronic patient record | `[grounded]` JD |
| Structure | A small caseload of your own, supported by a senior community nurse; pool cars provided | `[grounded]` JD |
| Pay | £31,050–£37,800 plus mileage | `[grounded]` JD |
| Market calibration | Band 5 community staff nurse median basic pay is about £34,300 (interquartile range £32,400–£36,600), so the advertised range sits across that band. This is the market's figure, not this employer's offer. | `[generic]` Wardround 2026 pay guide, England survey |
| Team lead | Rhiannon Mabbott leads the Halifax district nursing team and has spoken publicly on leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` speaker page |
| Scope read | A standard entry-level community post: one year of experience is required and Doppler is only desirable | `[inferred]` from the JD's essential and desirable lists |
| Unknowns | Whether the posting is live, whether terms follow NHS pay scales, the rota and weekend pattern, how big a "small" caseload is | — |
| Contradictions | None found between the JD and the About page | `[grounded]` About page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration, Adult Nurse | hard_gate | direct | medium | none | You state active registration, revalidation due March 2028. That is self-reported and checkable on the public register. | `[grounded]` CV | You can check the register entry yourself |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | You state a full category B licence. Pool cars are provided. | `[grounded]` CV, JD | none |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years on an acute medical ward. This is a length of experience, not a gate. | `[grounded]` CV | none |
| R4 | Clear, timely written records | must_have | unclear | low | discovery | The CV is silent on recording. Ward nursing usually involves heavy documentation, but nothing here shows it. | `[grounded]` CV silence; `[generic]` ward documentation norm | See G1 |
| R5 | Wound care | must_have | direct | medium | none | Pressure ulcers and surgical wounds are on your CV. | `[grounded]` CV | none |
| R6 | Leg-ulcer care | important | adjacent | medium | transferability | Wound care carries over. Compression and leg-ulcer management are not claimed. | `[grounded]` CV; `[inferred]` adjacency | See G4 |
| R7 | Catheter care | important | direct | medium | none | Catheter care is on your CV. Continence care beyond catheters isn't claimed. | `[grounded]` CV | none |
| R8 | Insulin administration | important | direct | medium | none | Insulin administration is on your CV. | `[grounded]` CV | none |
| R9 | End-of-life visits and care planning | important | unclear | low | discovery | Nothing on the CV either way. | `[grounded]` CV silence | See G2 |
| R10 | A small caseload of your own, visiting patients at home | important | adjacent | medium | transferability | Your 18-month secondment visiting patients at home in their first week after discharge is a real bridge. You say you've never held your own caseload, so the limit is ownership over time. | `[grounded]` CV and your statement; `[inferred]` bridge | See G3 |
| R11 | Doppler assessment (desirable) | preferred | absent | none | capability | You say you've never done one. | `[grounded]` your statement | Closure path in G5 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Written records (R4, must_have) | discovery | Nothing on the CV about recording or electronic patient records | It is the one must-have row below `direct`, so closing it firms up the application | Discharge-to-assess visit notes; electronic patient record systems used on the ward; audit or documentation feedback | Name of the systems used; any audit result | `[grounded]` CV silence; `[generic]` that employers screen records closely in nursing posts |
| G2 | End-of-life and care planning (R9, important) | discovery | The CV doesn't mention palliative work or care plans | The JD lists both explicitly | Last-days-of-life care on the ward; anticipatory medicines; care plans written during discharge-to-assess | A care plan you wrote, with patient details removed | `[grounded]` CV silence |
| G3 | Owning a caseload (R10, important) | transferability | Home visits are evidenced; ownership over time is not | It is the main limit on a role that gives you your own caseload | Following the same patients across several visits; deciding visit frequency; escalating to a GP or district nurse | A description of the secondment's structure | `[inferred]` bridge from the secondment |
| G4 | Leg-ulcer care (R6, important) | transferability | Pressure ulcer and surgical wound care only | The advertised work includes leg-ulcer care | Applying or reviewing compression; venous or mixed ulcers on the ward | Any leg-ulcer training record | `[grounded]` CV |
| G5 | Doppler (R11, preferred) | capability | No Doppler experience | Desirable only. The team lead has spoken on Doppler training for staff new to community work, so training may be offered on joining, but I can't confirm that for this post. | A closure path: ask whether training is provided, or find an accredited course | — | `[grounded]` speaker page; `[inferred]` that training may be offered |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay stated and in the market band | positive_signal | — | "£31,050–£37,800 a year plus mileage" | Transparent pay across a range that brackets the market median | `[grounded]` JD; `[generic]` band | What starting point would I join at? | noted |
| RR2 | Supervision stated | positive_signal | — | "supported by a senior community nurse" | A newcomer to caseload work is not left alone | `[grounded]` JD | How is the support structured in the first months? | noted |
| RR3 | Posting not confirmed live | unknown | — | "Community Staff Nurse, Band 5 — Calderbrook Community Health, Halifax" | The careers page returned nothing from here, so I couldn't see the posting | `[grounded]` careers fetch returned no page | Is this vacancy open, and what is the closing date? | unresolved |
| RR4 | Terms and conditions unstated | unknown | — | "Band 5 ... £31,050–£37,800" | A CIC may follow NHS pay scales or set its own terms; pension and leave could differ | `[generic]` pattern for CICs holding NHS contracts | Are terms in line with NHS Agenda for Change? | unresolved |
| RR5 | Rota and caseload size unstated | unknown | — | "a small caseload of your own" | Weekend and evening cover and caseload size are unknown | `[inferred]` from the JD's silence | What is the rota, and how many patients make a typical caseload? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with the discharge-to-assess home visiting, described as visits to patients at home in the first week after discharge | See R10. Don't call it district nursing or a caseload. | `[grounded]` CV | pending your approval |
| E2 | Add a line on records and systems used, once G1 is answered | See R4 | `[grounded]` R4 row | pending your approval |
| A1 | Take up the offered informal chat with Rhiannon Mabbott. Ask RR3, RR4 and RR5, and whether Doppler training is provided. | Using the contact in the advert | `[grounded]` JD | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax community staff nurse district nursing" and "community staff nurse Band 5 district nursing Calderbrook Halifax"; read "About Calderbrook Community Health" (calderbrookhealth.example/about). It confirmed the employer exists as described, so the employer-not-established entry doesn't apply. The fetch of calderbrookhealth.example/careers returned no page, which leaves RR3 open. |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse district nursing requirements experience Doppler caseload salary 2026"; read "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). It moved the market-calibration row and RR1. |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook Community Health"; read "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). It moved the team-lead row, G5 and A1. |

## Offer

I can write this up as `tuesday-dossier.md`, with no pressure to; say if you want it.

## Upgrade menu

- A list of the record systems you've used, or an audit result → R4 can move up from `low`.
- A care plan you wrote, with patient details removed → R9 and R10 firm up.
- The live posting link or the closing date → RR3 closes.
- The recruiter's answers on terms and rota → RR4 and RR5 close.
- Any non-negotiables, such as a pay floor or no weekends → the hard-gate checks against them can run.
- A deeper research pass on Calderbrook (up to 5 more searches and 2 more fetches) → say the word and it runs.

## Questions

G1 — Which electronic patient record systems have you used, and how did you keep your notes timely, on the ward or during the discharge-to-assess secondment? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G2 — Have you cared for patients in their last days of life, or written care plans? What did you personally own? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G3 — During the secondment, did you follow the same patients over several visits and decide visit frequency yourself, or was each visit allocated to you? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.