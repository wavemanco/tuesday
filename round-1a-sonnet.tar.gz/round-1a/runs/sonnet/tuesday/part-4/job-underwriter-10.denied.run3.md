Researching Fernquay's footprint and the role's market band now, then I'll write up the assessment.
I couldn't run any research on Fernquay. All four searches I tried were refused, so I haven't checked whether the company exists as described. The assessment below rests only on what you pasted, and it says where that limits it.

## Decision snapshot

**Yes, worth pursuing, so take the call, but verify the company first. On whether it's legit: I couldn't establish Fernquay from here, and nothing you shared asks you for money or personal details (RR1, RR2, RR5). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Salary €52,000–€60,000)
- `must_have` — direct: R3, R4, R5, R6 · adjacent: R7 (Own the booking flow end to end)
- `important` — adjacent: R8 (First designer on the team)

R7 (`medium`) — closest to your checkout redesign, scope of your ownership unconfirmed; R8 (`medium`) — no solo-designer history, in your own words.

**Opportunity ledger.** The employer is unverified because the research didn't run (RR1), and the equity terms are unstated (RR3). Against that, the posting is specific about pay, hybrid terms and scope, and the message matches it (RR5).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Fernquay verifies as a live employer with this role on its own site (RR1); (2) the calendar invite comes from a Fernquay address (RR2); (3) the pay band clears your floor (R2) and the equity terms are given in writing (RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: six people in Galway, booking software for sea-kayak and surf schools | `[grounded]` posting |
| Mandate | First designer; own the booking flow end to end; run research calls with school owners; ship alongside two engineers; work closest with co-founder Ronan Kehoe | `[grounded]` posting |
| Pay and terms | €52,000–€60,000 plus 0.5–1% equity; hybrid, two office days a week in Galway | `[grounded]` posting |
| Scope read | A coherent one-person design remit: one product flow plus research, with no team to lead | `[inferred]` from the posting's scope against its stated team size |
| Market calibration | Not established. The role-family search was refused, so I won't state a pay band for this title and size from memory | `[grounded]` search refused |
| Unknowns | First-year outcomes; who reviews design work; equity terms; contract type; how the team is funded | `[grounded]` posting silent on each |
| Contradictions | None between the posting and the WhatsApp message: both name Ronan as co-founder, and the message adds a CTO, Saoirse | `[grounded]` the two texts you pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week at the Galway office | hard_gate | direct | medium | none | You live in Galway after moving back last year, so the office days are feasible. You haven't said you accept two fixed days, so `medium` | `[grounded]` your statement of where you live | none |
| R2 | Salary €52,000–€60,000 | hard_gate | unclear | none | hard_gate | The posting states the band, but you haven't given a pay floor, so I can't say whether it meets your terms. Whether the band is fair for a solo designer in Galway is uncalibrated | `[grounded]` posting figure; no candidate floor given | G2 asks for your floor |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company. This is your own prose account, so `medium`; it is not a gate | `[grounded]` your background as stated | none |
| R4 | Strong Figma | must_have | direct | medium | none | Daily use is confirmed. "Strong" isn't something I can inspect without your case study | `[grounded]` your statement | Share the case study link, which would raise this to `high` |
| R5 | You have run your own user research | must_have | direct | medium | none | Monthly usability sessions with customers, which meets the requirement as written. The role's research calls are with school owners, and discovery interviews with small-business owners are a different kind of work from usability sessions | `[grounded]` your statement; `[generic]` the usability-versus-discovery difference | Be ready to say plainly which kind you've run |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your statement | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | discovery | You redesigned a checkout flow at a travel-booking company, which is booking-adjacent. What you personally owned across research, design and handoff isn't stated | `[grounded]` your statement; `[inferred]` that "end to end" is wider than a checkout | See G1 |
| R8 | First designer on the team | important | adjacent | medium | transferability | You have never been the only designer. What carries over is design work embedded in an engineering squad. The limit is that you haven't set up a design practice or quality bar alone | `[grounded]` your statement | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Booking-flow ownership (R7, must_have) | discovery | A checkout redesign is stated, but not whether you owned research, design, specs and handoff | The role's core responsibility; clarity here decides how strongly to lead with it | Writing the research plan; deciding what shipped; fixing the flow after launch; being the design voice in planning | The checkout case study, a before/after, a usability findings summary | `[grounded]` the statement's silence on ownership; `[generic]` that a first-designer interview probes ownership |
| G2 | Pay floor (R2, hard_gate) | hard_gate | The posting's band is known; your floor is not | A pay gate you haven't confirmed is the one thing that could end this quickly | Your current salary range and the lowest you'd accept | Your own figure; nothing to attach | `[grounded]` no floor given |
| G3 | Solo-designer readiness (R8, important) | transferability | Squad-embedded design, no solo history | A first-designer seat has no design peer to lean on | Setting up a shared component library, a research cadence or a design review habit from nothing, even informally | A design-system file or research repository you started | `[inferred]` from your stated background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools" | The entity may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer. My searches were refused, so this is unchecked rather than negative | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Recruiter reached you on WhatsApp; invite sent by email | unknown | — | "I have emailed you a calendar invite with the video link" | Scheduling by chat for a video interview is not a signal in itself. What is unverified is whether the invite comes from a Fernquay address | `[inferred]` from the message text | Could you send the invite from your Fernquay address, and who else will be on the call? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | A percentage range with no vesting, strike price or share class cannot be valued | `[inferred]` from the posting's silence on terms | What vesting schedule, strike price and share class sit behind the 0.5–1%, and will it be in the offer letter? | unresolved |
| RR4 | First designer, no design peer | risk_signal | low | "You would be our first designer" | Nobody on the team may be placed to review design work or set the quality bar | `[generic]` pattern for first-designer roles, not a claim about this one | Who reviews design work today, and what should be shipped in the first six months? | unresolved |
| RR5 | Specific terms and consistent contact | positive_signal | — | "Salary €52,000–€60,000 plus 0.5–1% equity" | The posting gives pay, hybrid terms and scope, and the message names the same co-founder. Neither the posting nor the message asks you for money, bank details or ID | `[grounded]` the posting and the message | What does success look like for the booking flow at six months? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, check Fernquay yourself: its own website and careers page, and the Irish company registry's public search | See RR1; I couldn't | `[generic]` standard checks for a small employer | pending your approval |
| A2 | Check that the calendar invite comes from the company's own domain, and confirm the call through that address | See RR2 | `[grounded]` RR2 | pending your approval |
| A3 | Lead with your checkout redesign and your monthly usability sessions, in your own words, and say plainly that you have worked in a squad and haven't been the only designer | Matches R5 and R7 without stretching them, and answers R8 before it is asked | `[grounded]` your own sentences | pending your approval |
| A4 | Ask the RR1, RR3 and RR4 questions verbatim on the call, and ask for the equity terms in writing | The register doubles as call preparation | `[grounded]` register | pending your approval |

Rehearsing the call itself is the mock-interview module's job, and I haven't done it here.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches for Fernquay and the posting were refused. It would have moved role reality's organization and contradictions rows, and RR1 |
| 2. Role-family sweep | unavailable | One search for a solo product designer's pay and scope was refused. It would have moved the market calibration row and the pay comparison under R2 |
| 3. Hiring manager's public footprint | unavailable | A name was given, but the one search for Ronan Kehoe was refused. It would have moved the scope read and A3's positioning |

## Dossier offer and upgrade menu

I can save this as `tuesday-dossier.md` so it carries into later steps, if you want it.

- A link to Fernquay's careers page or the live posting → RR1 resolves and the decision likely moves toward `go`.
- Your pay floor → R2 closes, and the hard-gates line becomes a real check.
- The checkout case study link → R4 to `high`, and R7's scope gets read directly.
- The invite's sender address → RR2 closes.
- Search permission for the three declined targets → role reality's calibration and the RR1 check run properly.

## Questions

G1 — In the checkout redesign, what did you personally own across research, design, specs and handoff, and what changed as a result?

G2 — What's your pay floor, and is there any other term you won't trade, such as office days or start date?

RR1 — Where did you find the posting, and what address did the calendar invite come from?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.