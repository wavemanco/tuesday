Checked the company name with one search. Writing up the assessment now.

## Decision snapshot

**No, don't go ahead, and send nothing. RR1, RR2, RR3 and RR4 are confirmed demands, each `severity: high`. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Pay of at least €30,000 a year)
- `must_have` — direct: R2, R4 · adjacent: R3 (Strong attention to detail)

R2, R4 — your Excel tracker and Zendesk writing line up with the asks; R3 (`medium`) — ticket volume is the evidence, not a direct measure.

**Opportunity ledger.** The messages ask you to pay for equipment (RR1), to lodge a cheque and pass most of it on (RR2), and to hand over bank, tax and ID details before any offer (RR3). The whole process is chat-only (RR4), the contact address is off any company domain (RR5), and the employer could not be established (RR6). The pay is only a ceiling (RR7).

- **Hard gates:** none failed; unconfirmed: R1 (Pay of at least €30,000 a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`), RR6 (`severity: high`).
- **What would change this:** the status moves only if the vacancy appears on the employer's own website, found by you and not through these messages. It would also need a written offer with pay terms that asks for no payment, no cheque and no personal documents.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics", named in the posting. One web search returned no results, which does not prove the firm doesn't exist but leaves it not established | `[grounded]` posting header; one search, no results |
| Mandate | Remote order processing, 15–30 hours a week, "up to €26 an hour plus commission" | `[grounded]` posting |
| Process | Hiring "runs on Telegram", with no calls or video interviews | `[grounded]` posting |
| Terms conflict | The posting says "full training provided" and mentions no cost. The recruiter then asks for €349 for equipment, which was not in the posting | `[grounded]` posting against the messages you pasted |
| Pay reach | At 15 to 30 hours and the full €26 for 52 weeks, the ceiling is €20,280 to €40,560 a year before commission. €30,000 needs about 22 hours a week at the top rate | `[inferred]` arithmetic on the posting's own figures; assumes the top rate and no unpaid weeks |
| Unknowns | The actual rate, the commission terms, and who the employer is | `[grounded]` absent from the posting and messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Your pay floor of at least €30,000 a year | hard_gate | unclear | high | hard_gate | Confidence grades your own stated floor. Fit is `unclear` because "up to" is a ceiling and commission is unquantified (RR7) | `[grounded]` your statement; posting wording | Get written pay terms from the employer through a channel you verify |
| R2 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel. Self-reported, nothing inspected | `[grounded]` your background | none |
| R3 | Strong attention to detail | must_have | adjacent | medium | transferability | About 60 Zendesk tickets a day at a parcel courier is adjacent evidence. It does not measure accuracy | `[grounded]` your background; `[inferred]` adjacency | none; moot while RR1 to RR4 stand |
| R4 | Good written English | must_have | direct | medium | none | Written ticket handling is the evidence. The posting's own mixed grammar says nothing about you | `[grounded]` your background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay floor (R1, hard_gate) | hard_gate | An "up to €26" ceiling, hours you set yourself, and unquantified commission | Your €30,000 floor is a gate the posting does not settle | The weekly hours you could actually work; any commission rate stated in writing | A written offer with rate and commission from a verified employer channel | `[grounded]` posting wording; `[inferred]` that it would not settle the gate |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Asked to pay for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages" | This request is very likely a scam. Pay nothing | `[generic]` a fee for equipment before pay is a known scam pattern | To the employer named, via contact details you find on its own website, not this chat: is this vacancy real, and do you ask new hires to pay for equipment? | confirmed |
| RR2 | Asked to deposit a cheque and pass most of it on | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner" | This request is very likely a scam. Don't deposit the cheque. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call | `[generic]` a cheque followed by an instruction to transfer money on is a known scam pattern | To the employer named, via its own website's contact details: do you send new hires cheques to forward to a supplier? | confirmed |
| RR3 | Bank, tax and ID details requested before any offer | red_flag | high | "please send your IBAN, your PPS number and a clear photo of your passport" | This was asked at the first screening, before any offer. Nothing about it is routine onboarding | `[grounded]` message order as you pasted it; `[generic]` that such requests normally follow a written offer | To the employer named, via its own website: when and why do you collect these from candidates? | confirmed |
| RR4 | Hiring and offer run wholly by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | Interview and offer both happened in chat only. This sign alone shows a way of working, and not who the firm is | `[grounded]` posting and messages | To the employer named, via its own website: is this recruiter on your team and is Telegram your process? | confirmed |
| RR5 | Contact off any company domain | risk_signal | medium | "email velloway.hr@postmail.example" | The address is on a mail provider and not a company site. The messages may not come from the firm they name | `[inferred]` from the address against a firm of this name | To the employer named, via its own website: is this address one of yours? | unresolved |
| RR6 | Employer not established from attributable sources | risk_signal | high | "Velloway Logistics" | The firm may be too new or small to have a footprint, the posting may be stale or copied, or it may not represent a real hiring employer. Severity is high because it comes with RR5 and RR1 to RR4 | `[generic]` pattern, not a claim about this firm | Can you point me at this role on your own careers site, and who I would be interviewing with? | unresolved |
| RR7 | Pay is a ceiling against your floor (R1) | unknown | — | "Earn up to €26 an hour plus commission" | The real rate and commission may be well below the ceiling | `[inferred]` from "up to" and the withheld commission terms | What is the hourly rate and the commission per order? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Pay nothing, deposit no cheque, and send no IBAN, PPS number or passport photo. I won't use or repeat the IBAN you pasted, and none of it is needed for this assessment | RR1, RR2, RR3 | `[grounded]` register | pending your approval |
| P2 | Look up the firm yourself and use only contact details from its own site to ask the register's questions | RR6 | `[grounded]` register | pending your approval |
| P3 | Don't send anything further in the Telegram chat until that check is done | RR4, RR5 | `[grounded]` register | pending your approval |
| P4 | Report the posting to the jobs site. If you ever paid or shared details, call your bank at once | RR1, RR3 | `[generic]` standard response | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics careers order processing coordinator"; no results, so not established. This fed role reality's organization row and RR6 |
| 2. Role-family sweep | skipped | RR1 to RR4 already fix the status, and RR7 is computed from the posting's own figures |
| 3. Hiring manager's public footprint | n/a | No name was given, only a chat handle, so there was no query to form |

I can write this up as `tuesday-dossier.md` if you want a copy; say the word.

## Upgrade menu

- The vacancy on the firm's own careers page, or a link to the original ad on the jobs site → RR6 closes or hardens.
- A written pay and commission statement from a verified channel → R1 and RR7 settle.
- A deeper research pass (up to 5 more searches and 2 more fetches) → RR6 gets a fuller check of the firm and recent reports.

No questions this turn: no answer could change the status.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.