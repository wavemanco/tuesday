Searched twice for the firm and found nothing, so here is the assessment.

## Decision snapshot

**No, don't go ahead. RR1, RR2, RR3 and RR4 are each `severity: high` and confirmed by the messages you pasted. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Earn up to €26 an hour, 15–30 hours)
- `must_have`: direct: R2 · adjacent: R3 (Strong attention to detail), R4 (Good written English)

R1 — the posting shows a pay ceiling and no floor; R2 (`medium`) — your own account of the tracker, no artifact inspected.

**Opportunity ledger.** The chat asks you to pay for equipment (RR1), lodge a cheque and forward most of it (RR2), and hand over bank, tax and passport details before any offer (RR3). The posting says hiring runs only on Telegram (RR4), and the employer could not be established from here (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Earn up to €26 an hour, 15–30 hours).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would change this:** the employer would have to be confirmed through contact details you find yourself on its own site, not through this chat. The payment, cheque and pre-offer ID requests would have to be withdrawn, and a written offer naming the role and pay would have to arrive. R1 would still need an answer on guaranteed hours.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics": no attributable web presence found | `[grounded]` search returned no results; not established |
| Mandate | Remote order processing, spreadsheets, "full training provided" | `[grounded]` posting |
| Pay and hours | "Up to €26 an hour plus commission", 15–30 hours a week; commission terms not given | `[grounded]` posting |
| Hiring process | Telegram only, no calls or video; screening, interview and offer all arrived in chat | `[grounded]` posting and your messages |
| Market calibration | Not established: the role-family search returned nothing, so no pay band is offered | `[generic]` no band available |
| Unknowns | Registered employer, employment basis, commission terms, who "payroll" is | `[inferred]` from what the messages leave out |
| Contradictions | The first message asks for payroll details before the chat interview it mentions; the "equipment partner" is never named | `[grounded]` your messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Annual income of at least €30,000 (your constraint; posting: "up to €26 an hour", 15–30 hours) | hard_gate | unclear | high | hard_gate | Confidence grades your stated floor. At the posting's own ceiling, 30 hours at €26 for 52 weeks is €40,560 and 15 hours is €20,280; €30,000 at 30 hours needs about €19.23 an hour, every week. "Up to" and the hours range settle nothing, and commission is undefined | `[grounded]` your floor and the posting's figures | Moot unless RR1–RR4 clear; then ask for the guaranteed hourly rate and hours in writing |
| R2 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel; self-reported, nothing inspected | `[grounded]` your background | none |
| R3 | Strong attention to detail | must_have | adjacent | medium | transferability | About 60 tickets a day in Zendesk and tracker upkeep carry over. Limit: nothing here measures accuracy or error rates | `[grounded]` your background; limit `[inferred]` from what it omits | none |
| R4 | Good written English | must_have | adjacent | medium | transferability | Zendesk tickets and training two starters point to written work. Limit: the mix of written and phone contact in your role is unknown, and no writing sample was inspected | `[grounded]` your background; limit `[inferred]` | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Whether income reaches €30,000 (R1, hard_gate) | hard_gate | An hourly ceiling, a variable 15–30 hours, undefined commission | Your floor is a gate, and the posting cannot show it is met | Not applicable: this is a term of the role, not experience | A written offer stating guaranteed hours and rate from an employer you have verified independently | `[grounded]` posting wording; `[inferred]` that a written offer is where it would be settled |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Asked to pay for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | A real employer does not ask a new hire to pay for kit up front; this request is very likely a scam. Don't send the €349. | `[generic]` known pattern for requests of this kind, not a claim about any named party | Does the company supply equipment itself, and can I confirm this request with you through the contact details on your own website? | confirmed |
| RR2 | Asked to lodge a cheque and forward the balance | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest..." | A lodged cheque can show in an account before it clears and be reversed later, leaving you out the money you sent on; this request is very likely a scam. Don't deposit the cheque. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. | `[generic]` known pattern for requests of this kind | Can you confirm, through your company's own published contact details, that this cheque and the transfer instruction come from you? | confirmed |
| RR3 | Bank, tax and passport details requested before any offer | red_flag | high | "Before your chat interview, please send your IBAN, your PPS number and a clear photo of your passport..." | Payroll data is normally collected after a written offer naming the role and pay, and nothing like that has been made; hold all three | `[generic]` onboarding sequence of a credible employer | Why are these needed before an offer, and can I give them after a written offer instead? | confirmed |
| RR4 | Entire hiring process in chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." | Interview and offer both happened only in chat; this means no one can be checked against an employer, and who is behind the account is unresolved | `[grounded]` posting and your messages | Can I speak with a named person at the company on a number published on your own site? | confirmed |
| RR5 | Employer not established | risk_signal | medium | "Velloway Logistics"; "Message @VellowayHiring to apply" | The firm may be too new or small for a footprint, the posting may be aggregated or stale, or the message may not come from who it names. None of these is ranked above the others | `[generic]` pattern, not a claim about this one | Can you point me to this role on your own careers page and name the registered company? | unresolved |
| RR6 | Contact address on a general mail domain | risk_signal | low | "velloway.hr@postmail.example" | The address does not show a company domain, so it cannot confirm who is writing | `[inferred]` from the address as written | Is there an email on your company's own domain I can write to? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't send your IBAN, PPS number or passport photo, don't transfer anything, and don't lodge the cheque if it arrives | see RR1, RR2, RR3 | `[grounded]` register | pending your approval |
| A2 | If you want to test the employer, find it yourself on an official company register or its own website and use only contact details found there, not the chat or the email in the message | see RR5, RR6 | `[generic]` verification practice | pending your approval |
| A3 | Keep the chat as a record and report the posting to the jobs site where you found it | see RR4 | `[generic]` common practice | pending your approval |
| A4 | Pay terms: only if the employer verifies, ask for hourly rate and guaranteed hours in writing before any further step | see R1, G1 | `[grounded]` R1 | pending your approval |

## Evidence status

Verified: none yet. Your IBAN is not repeated or used anywhere in this response, and your PPS number and passport aren't needed for this assessment.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics": no results, so the employer is not established, which feeds RR5 and role reality's organization row. No page was fetched |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator work from home Telegram interview cheque equipment fee scam": no results; it moved nothing, and market calibration stays unestablished |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I can't establish the firm from here; no results is not proof it doesn't exist, but the requests above stand on their own.

I can save this as `tuesday-dossier.md` if you want it to keep or share.

**Upgrade menu**

- The registered company name and number, found independently of the chat → RR5 and RR6 can close.
- A link to the live posting on the jobs site → target 1 can check that the posting exists and matches.
- A written offer stating hourly rate and guaranteed hours → R1 and G1 can close.
- A deeper research pass (up to 5 more searches and 2 more fetches) — say the word and it runs.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.