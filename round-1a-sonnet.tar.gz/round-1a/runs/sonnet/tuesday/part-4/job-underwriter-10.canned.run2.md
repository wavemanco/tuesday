Still working on your question: I've read the underwriting playbook and I'm now running a few web checks on Fernquay, the Galway salary range, and Ronan's public profile.
**Short answer:** Yes, worth continuing, and I found nothing to suggest it isn't legit. The one thing I couldn't confirm is the WhatsApp contact itself. Check the sender of the calendar invite before the call (details at RR1).

## Decision snapshot

**Yes to both on what I could check: worth taking the call, since R3, R4, R5 and R7 are `direct` and R6 is `adjacent`, and Fernquay's own pages match the posting (RR2). The WhatsApp contact is unverified (RR1). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Salary €52,000–€60,000)
- `must_have` — direct: R3, R4, R5, R7 · adjacent: R6 (Own the booking flow end to end)
- `important` — adjacent: R8 (Research calls with school owners), R9 (First designer on the team)

R6 — a credible bridge, its limit named; R9 — never the only designer, so the bridge is a squad seat to a solo seat; R4 (`medium`) — confirmed, waiting on an artifact.

**Opportunity ledger.** The employer's own pages match the posting (RR2) and the stated pay sits inside a market band (RR5). The open items are the WhatsApp channel (RR1), the equity terms (RR3) and how long a customer-funded team of six can fund a first design hire (RR4).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your pay floor sits at or below the posted band — R2, RR5; (2) the invite email comes from a Fernquay address — RR1; (3) equity terms are written down before you weigh the 0.5–1% — RR3; (4) the "first designer" gap is framed honestly as adjacent — R9.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. Six people in Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle, funded by its customers | `[grounded]` About Fernquay (fernquay.example/about), search result text |
| Mandate | First design hire: own the booking flow, research calls with school owners, ship with two engineers | `[grounded]` posting |
| Live posting | The careers page lists the same role, hybrid, two days a week in Galway, €52,000–€60,000 plus equity, and asks for one real project sent to a jobs@ address | `[grounded]` Product Designer — Fernquay careers (fernquay.example/careers/product-designer), search result text |
| Compensation | €52,000–€60,000 plus 0.5–1% equity; the careers page says only "equity", so the percentage rests on the posting alone | `[grounded]` posting and careers page |
| Scope read | One product, one flow, two engineers: a bounded mandate that matches the title | `[inferred]` from the posting's scope against its stated team size |
| Market calibration | For 3 to 5 years' experience in Ireland, median base €57,000 and interquartile range €51,500–€62,000, so the posted band sits inside the middle half of that survey. This is a market pattern, not Fernquay's offer | `[generic]` Tillerby 2026 Ireland Design Salary Report (tillerby.example/2026-ireland-design-salary-report), n=520, from search result text; `[grounded]` posting for the band |
| Co-founder | Ronan Kehoe is listed as co-founder and CEO, and before that was product lead at a Galway travel-software company for five years. The WhatsApp message calls Saoirse the CTO; the pages I saw name her as co-founder but not her title | `[grounded]` LinkedIn profile search result (linkedin.example/in/ronan-kehoe); CTO title not established |
| Unknowns | Equity type, vesting and strike terms; runway; who else is on the call; what the two engineers' seniority is | — |
| Contradictions | None between the posting, the careers page and the About page | `[grounded]` the three pages' search result text |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week at the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year, so the office days are workable. Medium because this is your own prose, not a stated constraint | `[grounded]` posting and your background | none |
| R2 | Salary €52,000–€60,000 (your floor not given) | hard_gate | unclear | none | hard_gate | The band is stated, but no floor was given, so there is nothing to check it against. Confidence grades your statement of a floor, and there is none yet | `[grounded]` posting; your floor not stated | Question G1 |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company, stated by you and not yet inspected | `[grounded]` your stated background | A CV or LinkedIn link would raise this to high |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" is confirmed and plausible, but no file or portfolio has been inspected | `[grounded]` your stated background | Link the checkout case study they already saw, or a Figma file | 
| R5 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. Confirmed and specific, with no artifact yet. Expect a probe on method | `[grounded]` your stated background | A sanitized session guide or findings summary would raise this to high |
| R6 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned checkout, which is one step of a booking journey. The limit is that nothing yet shows ownership of search, availability, cancellations or confirmations. A smaller company may also expect fewer handoffs than a Dublin squad did | `[grounded]` your checkout redesign; `[generic]` that small-team ownership is usually broader than one step | Question G2 |
| R7 | Happy working directly with engineers | must_have | direct | medium | none | Squad of four engineers, stated by you | `[grounded]` your stated background | none |
| R8 | Run research calls with school owners | important | adjacent | medium | transferability | Your sessions were with travel-booking customers, who are mostly consumers. The limit is that owner-operators of small schools are a business audience with different priorities | `[grounded]` your sessions; `[generic]` that business-owner interviews differ from consumer ones | Bring one example of a research insight that changed a design decision |
| R9 | First designer on the team (implied by "you would be our first designer") | important | adjacent | medium | transferability | You have worked in a squad, never as the only designer. The limit is no design peer to review, no existing system, and you set your own process. Strong squad experience is real evidence but is not the same thing | `[grounded]` your statement that you have never been the only designer; `[inferred]` requirement from the posting's "first designer" wording | Question G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay floor against the posted band (R2, hard_gate) | hard_gate | The band is stated and your floor is not, so whether the gate is met is unestablished | A gate the inputs do not settle stays open, and it can move the decision either way | Your current salary, your minimum, and what equity would have to offer to offset a lower base | None needed; your own statement is the evidence | `[grounded]` posting states a band, your floor absent |
| G2 | Booking flow beyond checkout (R6, must_have) | transferability | You redesigned checkout; the rest of the journey is not described | A must-have at `adjacent`, and the likeliest area for them to probe | Search or availability screens you designed, cancellation or amendment flows, confirmation emails, mobile booking, a design-system piece | A before/after of any non-checkout screen, or a flow diagram | `[inferred]` from the posting's "end to end" against your checkout description; `[generic]` that this is the usual probe |
| G3 | Solo design ownership (R9, important) | transferability | Squad experience only | Being first designer means setting process without peers; the honest answer is better prepared than improvised | A freelance or side project, a design system you started, a stretch where you were the only designer on a feature, a time you set a research cadence | A link to any one of those | `[grounded]` your statement; `[generic]` that first-designer roles stress self-direction |
| G4 | Business-owner research (R8, important) | transferability | Consumer-facing sessions only | Their research calls are with school owners | Any B2B or supplier-side interviews, such as tour operators, partners or internal stakeholders | A summary of one B2B conversation | `[inferred]` from your sessions against the posting |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | First contact came by WhatsApp, with the invite by email | unknown | — | "I have emailed you a calendar invite with the video link" | The message only schedules a call, and nothing in it asks you for money, documents or personal details. Small teams often use messaging for scheduling, but I cannot confirm from here that the sender is Ronan or that the number belongs to Fernquay | `[generic]` pattern for six-person firms; `[grounded]` message content as you shared it | Could you confirm the invite will come from a Fernquay address, and who else will be on the call? | unresolved |
| RR2 | Employer matches the posting | positive_signal | — | "Six people, based in Galway. Founded 2023 by Ronan Kehoe and Saoirse Doyle" | The entity exists, the live careers page carries the same role and band, and Ronan's profile matches the name in the posting | `[grounded]` About and careers pages as returned by search; I did not open the pages themselves | What was the first design problem you hoped this hire would take on? | noted |
| RR3 | Equity terms unstated | unknown | — | "0.5–1% equity" | Equity type, vesting and strike price are not in the posting or the careers page, so its value cannot be judged yet | `[inferred]` from the posting's silence | What are the vesting terms and the share class, and is the percentage before or after the next round? | unresolved |
| RR4 | Customer-funded team of six hiring a first designer | unknown | — | "funded by its customers" | A bootstrapped firm avoids investor pressure, but runway for a €52,000–€60,000 hire is not shown in anything I read | `[generic]` bootstrapped-firm pattern; `[grounded]` About page wording | How many months of runway does the current revenue give the team, and is this hire budgeted in it? | unresolved |
| RR5 | Posted pay sits inside a market band | positive_signal | — | "€52,000–€60,000" | The band falls within the survey's interquartile range for 3 to 5 years' experience, so it does not look mispriced for the title | `[generic]` Tillerby survey band from search result text; `[grounded]` posting figure | Is the band fixed, or is there room depending on experience? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, check the invite's sender address ends in Fernquay's own domain, and share no bank, tax or ID details with anyone at any stage before a written offer | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Bring one messy real project, ideally with a non-checkout screen, as the careers page and posting both ask for | see R6, G2 | `[grounded]` posting and careers page | pending your approval |
| A3 | Describe R9 as squad experience with a stated limit, never as "ran design" or "founding designer" experience | see R9 | `[grounded]` R9 row | pending your approval |
| A4 | Ask RR1, RR3 and RR4's questions verbatim on the call | The register doubles as interview preparation | `[grounded]` register | pending your approval |

Rehearsing for the call itself is the mock-interview module's job; I haven't done it here.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway" and "Fernquay Product Designer Galway careers"; results "About Fernquay" (fernquay.example/about) and "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer). Role reality's organization, live-posting and contradictions rows, and RR2. I read search result text only and did not fetch either page |
| 2. Role-family sweep | yes | Searched "first product designer startup Ireland salary €52,000 €60,000 equity"; result "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Market calibration and RR5 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe co-founder Fernquay"; result "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe). Role reality's co-founder row; it also names his earlier travel-software role |

I can write all of this up as a `tuesday-dossier.md` for later steps if you'd like.

**Upgrade menu**

- Your pay floor → R2 and RR5 close, and the decision likely simplifies to `go` or `no_go`.
- Your CV, portfolio or the checkout case study link → R3, R4 and R5 move toward `high`.
- A non-checkout screen or flow → G2 narrows R6's limit.
- Any solo or freelance work → G3 narrows R9's limit.
- The invite email's sender domain → RR1 closes.
- A deeper pass on Fernquay (funding, customer reviews, any hiring or leadership history; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

G1 — What is your salary floor, and is anything else a firm limit for you, such as contract type or office days?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G2 — Beyond checkout, which parts of a booking journey have you designed yourself (search, availability, cancellations, confirmations), and what happened as a result?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G3 — Have you ever been the sole decision-maker on a design piece, such as freelance, a side project or a feature with no other designer, and what did you set up yourself?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.