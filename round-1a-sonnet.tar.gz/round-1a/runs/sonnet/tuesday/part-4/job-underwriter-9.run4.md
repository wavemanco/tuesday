Quick note first: I tried three web searches to check Marrowgate, the pay band and the hiring manager. They were refused, so everything below rests on what you pasted.

## Decision snapshot

**Yes, being asked for bank details, PPS number and a passport scan is a normal onboarding step after a written offer like this one. Verify the sender and the portal link before you upload anything. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R3 · unclear: R1 (Hybrid, two days in Limerick office), R2 (Salary €38,000–€42,000)
- `must_have`: direct: R4, R6, R7, R8 · unclear: R5 (Irish PAYE, PRSI and USC)
- `important`: adjacent: R10 (240 staff) · absent: R9 (pension changes)

R5 — your Irish tax knowledge isn't stated in what you shared; R9 — you told me you haven't processed pension changes yourself.

**Opportunity ledger.** The offer matches the ad and names the role, pay, manager and location (RR3). Two things are unconfirmed: the employer, because my research didn't run (RR1), and the contract terms the email leaves out (RR4). The data request itself is routine (RR2).

- **Hard gates:** none failed (R3 `direct`); unconfirmed: R1 (Hybrid, two days in Limerick office), R2 (Salary €38,000–€42,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm the sender and portal link through contact details you find yourself, before uploading anything (RR1, RR2); (2) you get the written terms and they suit you (RR4, R1, R2); (3) you describe the pension-change gap plainly (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick | `[grounded]` ad |
| Mandate | Run monthly payroll for 240 staff, process starters, leavers and pension changes, reconcile payroll to the ledger monthly, answer queries | `[grounded]` ad |
| Working pattern | Hybrid, two days a week in the Limerick office; reports to Declan Garvagh, Finance Manager | `[grounded]` ad and offer |
| Pay | Ad: €38,000–€42,000. Offer: €40,000, permanent | `[grounded]` ad and offer |
| Scope read | One post owns the full payroll cycle and its ledger reconciliation; no team or payroll system is named | `[inferred]` from the duty list against its silence on support |
| Market calibration | Not established: the role-family search did not run, so I won't give a band | — |
| Contradictions | None between the ad and the offer on title, pay band, hybrid pattern or permanence | `[grounded]` the two texts you pasted |
| Unknowns | Contract terms, probation, notice, leave, pension scheme, payroll software, start date | `[grounded]` the offer is silent on each |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in the Limerick office | hard_gate | unclear | none | hard_gate | No statement from you on location or commute, so whether the term works for you is unsettled | `[grounded]` ad, your silence | Answer the closing question on R1 and R2 |
| R2 | Salary €38,000–€42,000 (offer €40,000) | hard_gate | unclear | none | hard_gate | The offer sits inside the ad's band; I don't know your pay floor | `[grounded]` ad and offer, your silence | Answer the closing question on R1 and R2 |
| R3 | A payroll qualification or working towards one | hard_gate | direct | medium | none | You hold a Payroll Technician certificate (2024). Awarding body and level weren't stated and no document was inspected | `[grounded]` your statement | Keep the certificate to hand |
| R4 | 2+ years running payroll | must_have | direct | medium | none | Three years of fortnightly payroll for 90 staff. This is your own account, not inspected | `[grounded]` your statement | none |
| R5 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | You didn't say whether the hotel payroll ran under Irish rules | `[grounded]` your background is silent on jurisdiction | Closing question G1 |
| R6 | Strong Excel | must_have | direct | medium | none | Daily use, pivot tables and XLOOKUP | `[grounded]` your statement | none |
| R7 | Monthly payroll-to-ledger reconciliation | must_have | direct | medium | none | You describe doing this at the hotel group | `[grounded]` your statement | none |
| R8 | Starters and leavers | must_have | direct | medium | none | You describe processing both | `[grounded]` your statement | none |
| R9 | Pension changes | important | absent | none | capability | You haven't done these; your manager handled them | `[grounded]` your statement | Closure path in G2; ask how this is handled |
| R10 | 240 staff, monthly cycle | important | adjacent | medium | transferability | Your 90-staff fortnightly run is real, adjacent experience. The limit is size: 240 staff is more than twice that headcount | `[grounded]` your statement | Be ready to say that headcount difference out loud |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Irish PAYE, PRSI, USC (R5, must_have) | discovery | Your payroll experience is clear. Whether it was Irish PAYE, PRSI and USC isn't | R5 is a `must_have` and the one unclear row among them | Running payroll under Irish rules, handling PRSI classes, applying USC, year-end returns to Revenue | A payslip layout with details removed, or a process note | `[grounded]` background silent on jurisdiction; `[inferred]` that a clear answer settles R5 |
| G2 | Pension changes (R9, important) | capability | You haven't processed them and your manager did | The duty is in the ad, so you will be asked how you'd handle it | Pension contribution changes on joiners or leavers, scheme-provider files, opt-outs | A sanitized procedure note if you have one | `[grounded]` your statement; `[inferred]` that this is a learnable task, since you already do starters and leavers |
| G3 | Whether R1 and R2 work for you (hard_gate) | hard_gate | The offer's terms are known; your limits are not | A failed gate would end the decision however strong the fit | Your pay floor, commute, whether two office days is workable | None needed | `[grounded]` your constraints weren't given |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer unconfirmed by me (research didn't run) | risk_signal | low | "Marrowgate Housing, a housing association in Limerick" | You met them twice in person at their office, which counts strongly for a real employer. Severity is the lower of low or medium for that reason. The sender domain and the portal link remain unchecked | `[grounded]` your two in-person interviews; `[generic]` pattern that an unchecked sender stays unverified | Can you confirm the portal address, and that its link will come from your own domain? | unresolved |
| RR2 | Bank details, PPS number and passport scan requested after acceptance | unknown | — | "where you add your bank details for salary payments, your PPS number for Revenue, and a scan of your passport" | A written offer naming the role, pay and manager, followed by identity and payroll checks, is the routine order. The risk would be a link from an unfamiliar address, or a request for more than this list | `[generic]` onboarding pattern, not a claim about this employer | Which fields does the portal collect, and does the passport scan need to be in before day one? | unresolved |
| RR3 | Offer matches the ad | positive_signal | — | "Payroll Administrator at €40,000 a year ... hybrid with two days a week in our Limerick office" | Title, band, hybrid pattern and permanence agree across both documents | `[grounded]` the ad and the offer | Who handles pension changes today, and is there a handover? | noted |
| RR4 | Contract terms absent from the offer email | unknown | — | "starting on a date we agree once your notice period ends" | Probation, leave, pension scheme and notice terms may be in a contract not yet sent | `[grounded]` the email is silent on each | Can I see the contract and terms before I accept? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Find Marrowgate's phone or email on its own website. Confirm with the People Team that the offer is genuine and the portal link will come from their domain. Don't use details from the offer email alone | RR1, RR2 | `[grounded]` register | pending your approval |
| A2 | Ask for the written contract and terms before accepting. The five-working-day window is for your reply to the offer, so asking is a reasonable use of it | RR4 | `[grounded]` the offer's reply deadline | pending your approval |
| A3 | Enter bank details, PPS number and passport scan only in the verified portal, never by email, chat or text | RR2 | `[generic]` general good practice | pending your approval |
| A4 | Raise pension changes yourself. A draft line, traced to your own words: "I've run starters, leavers and the monthly ledger reconciliation myself; I haven't processed pension changes, as my manager handled those. How are they handled here?" | R9, RR3 | `[grounded]` your statement | pending your approval |

## Evidence status

Verified: none yet. Please don't paste your passport or PPS number here; I don't need them.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Marrowgate Housing Limerick housing association" was refused. It would have confirmed the employer exists and the ad is live, moving RR1 and the contradictions row |
| 2. Role-family sweep | unavailable | The search "payroll administrator Ireland salary Limerick PAYE PRSI USC" was refused. It would have set a pay band and scope norm in role reality and checked R2 |
| 3. Hiring manager's public footprint | unavailable | The search "Declan Garvagh Finance Manager Marrowgate Housing" was refused. It would have informed the scope read and A4 |

I can draft this as a `tuesday-dossier.md` if you want to keep it, with no pressure to.

**Upgrade menu**

- Web search permission → RR1 and the market calibration move from unestablished to checked.
- The contract and terms → RR4 closes and R1 and R2 can be settled.
- Your payroll's jurisdiction and a process note → R5 resolves.
- Your pay floor and commute limit → the hard-gate line stops reading as unconfirmed.

**Questions**

G1 — Was the hotel group's payroll run under Irish rules, and what did you handle yourself (PRSI classes, USC, Revenue returns)? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G3 — Is €40,000 with two office days a week in Limerick workable for you, or is there a pay floor or commute limit it must meet? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.