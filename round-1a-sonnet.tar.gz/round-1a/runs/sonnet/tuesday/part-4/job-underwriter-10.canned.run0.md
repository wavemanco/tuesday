Fernquay's own pages match your posting. Before I write this up, I'm running one last search on Ronan's public professional background, since you'll be on a call with them.
**Decision snapshot**

**Yes, it's worth taking the call, and the employer matches its own pages (RR1). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Salary €52,000–€60,000)
- `must_have` — direct: R3, R4, R5, R6 · adjacent: R7 (Own the booking flow end to end)
- `important` — adjacent: R8 (First and only designer), R9 (Research calls with school owners)

R7 — a credible bridge through the checkout redesign, its limit named; R8 — never the only designer, the real stretch; R2 — waiting on your pay floor.

**Opportunity ledger.** The employer and the live posting agree with its own site (RR1), and the pay sits inside the market band (RR3). Open items are the WhatsApp contact next to an email-only application route (RR2), equity terms the posting doesn't give (RR4), the solo-designer scope (RR5) and the funding basis (RR6).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your pay floor sits at or below the posted range (R2); (2) the calendar invite checks out as coming from Fernquay's own domain (RR2); (3) the solo-designer scope and what already exists get confirmed on the call (R8, RR5).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. Six people, Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle, funded by its customers | `[grounded]` search result for "About Fernquay" (fernquay.example/about) |
| Online footprint | Thin, which is what you noticed | `[generic]` six-person companies usually have a small public footprint; the entity itself is attributable, per the row above |
| Posting consistency | The live careers page matches your pasted posting: first design hire, hybrid with two days in Galway, €52,000–€60,000 plus equity. It asks for applications by email to jobs@fernquay.example with one real project | `[grounded]` fetched "Product Designer — Fernquay careers" |
| Mandate | Own the booking flow, run research calls with school owners, ship with two engineers, work closely with Ronan Kehoe | `[grounded]` your pasted posting |
| Hiring manager | Ronan Kehoe, co-founder and CEO, previously product lead at a Galway travel-software company for five years | `[grounded]` search result "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe) |
| Scope read | A one-person design function with no design peer. You would set the practice up as well as work in it | `[inferred]` from "first designer" against your record of always working inside a team |
| Market calibration | Ireland, product designers with 3–5 years: median base €57,000, interquartile range €51,500–€62,000 (n=520). The posted range sits inside it, at the lower half. This is a market band, never Fernquay's offer | `[generic]` Tillerby 2026 Ireland Design Salary Report; `[grounded]` posting for the posted range |
| Unknowns | Equity terms, runway, what design groundwork already exists, whether the CTO title is Saoirse Doyle's (the About page names her as co-founder) | — |
| Contradictions | None between the posting and the careers page. One difference in channel: the posting says apply by email, and contact reached you on WhatsApp (RR2) | `[grounded]` careers page against your message |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week at the Galway office | hard_gate | direct | medium | none | You live in Galway, so the term is met. You haven't stated it as a constraint, so I'm reading it from your background. | `[grounded]` your background: moved back to Galway last year | none |
| R2 | Salary €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | You haven't given a pay floor, so nothing settles whether the range clears it. | `[grounded]` no constraint stated | Answer the pay-floor question below |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company. Self-reported, no artifact inspected yet. | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" is confirmed but uninspected. A design portfolio is the artifact this field keeps. | `[grounded]` your background | Share the checkout case study (or a Figma file) to raise it to `high` |
| R5 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. | `[grounded]` your background | none |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers. | `[grounded]` your background | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned a checkout flow, which is part of a booking flow. Limit: checkout is one stage, and it's unclear how much of the surrounding flow was yours. | `[grounded]` your background; `[inferred]` that checkout is only part of the flow | See G2 |
| R8 | First and only designer | important | adjacent | medium | transferability | You've worked as a designer with engineers, but never as the only designer, and you said so. Limit: no experience of setting up design practice alone. | `[grounded]` your statement; `[inferred]` the requirement from "first designer" | See G1 |
| R9 | Research calls with school owners | important | adjacent | medium | transferability | Your sessions were with customers of a travel-booking company. Limit: whether those were consumers or business owners isn't stated, and small business owners are a different conversation. | `[grounded]` your background; `[generic]` that owner interviews differ from consumer usability tests | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Sole-designer practice (R8, important) | transferability | Four years inside a team. No stated experience of choosing tools, setting standards or deciding priorities without design peers | It's the biggest difference between this role and your history, and the call will probably test it | Starting a component library or shared Figma file; setting up a research habit nobody asked for; deciding design priorities with engineers and no design lead | The case study, or a research summary you wrote | `[grounded]` your statement; `[generic]` that first-designer interviews probe this |
| G2 | Booking flow ownership (R7, must_have) | transferability | Checkout redesign confirmed. The parts before and after checkout aren't described | The role owns the whole flow, so how far your ownership reached sets how strong the bridge is | Search and availability screens; confirmation and cancellation flows; changes you made after the redesign shipped | Before-and-after screens, or the outcome of the checkout change | `[grounded]` checkout redesign; `[inferred]` scope beyond it unknown |
| G3 | Owner-type research (R9, important) | transferability | Monthly usability sessions, with customers of unknown type | Owner calls differ from consumer tests in what you ask and what you learn | Sessions with partners or suppliers, not only end customers; interviews about how someone runs their business | A research plan or findings summary | `[grounded]` your background; `[generic]` that owner interviews differ |
| G4 | Pay floor (R2, hard_gate) | hard_gate | Your minimum isn't known | It's the only gate that can still change the decision | Your current salary band and the lowest figure you would accept | — | `[grounded]` constraint not stated |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer matches the posting | positive_signal | — | "Six people, based in Galway. Founded 2023 by Ronan Kehoe and Saoirse Doyle" | The company exists as the posting describes, and the careers page lists the same role | `[grounded]` About page result and fetched careers page | What does the design function look like in twelve months? | noted |
| RR2 | WhatsApp contact beside an email-only application route | unknown | — | "I have emailed you a calendar invite with the video link. Just shout here if the time does not suit." | The message asks only for a call time, and nothing like money, bank details or ID. Informal small teams often schedule on WhatsApp. I can't tie the number or the invite to Fernquay from what you've shared. | `[generic]` small-team habits; `[grounded]` message content | Could you confirm by email from your company address that the call is with you and Saoirse on that date? | unresolved |
| RR3 | Pay inside the market band | positive_signal | — | "€52,000–€60,000 plus 0.5–1% equity" | The posted range overlaps the market median and is stated openly | `[grounded]` posting; `[generic]` Tillerby 2026 band | Is the range fixed, or does it move with experience? | noted |
| RR4 | Equity terms not given | unknown | — | "0.5–1% equity" | Without vesting, share class or strike price, the equity can't be valued | `[inferred]` from the posting's silence | What vesting terms, share class and strike price would the 0.5–1% carry? | unresolved |
| RR5 | First designer, nothing in place stated | risk_signal | low | "You would be our first designer: own the booking flow end to end" | You may start with no design system, research habit or design peer to learn from | `[inferred]` from "first designer"; `[generic]` that first-designer roles at small firms often cover several jobs | What exists today (design system, analytics, a research routine), and what would I build from scratch? | unresolved |
| RR6 | Funding basis and runway not stated | unknown | — | "funded by its customers" | Salary and equity depend on customer revenue. The posting doesn't show how stable it is. | `[inferred]` from "funded by its customers" | How long is the current runway, and how is revenue trending? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, check the calendar invite's sender address ends in fernquay.example. If it doesn't, email jobs@fernquay.example using the address on the careers page, not the WhatsApp number | See RR2 | `[grounded]` careers page address | pending your approval |
| A2 | Lead with the checkout redesign and the monthly usability sessions. Say plainly that you've worked in a squad with four engineers and have never been the only designer. Don't describe the checkout work as owning the whole booking flow | R7 and R8 limits; every clause traces to your own sentences | `[grounded]` your background | pending your approval |
| A3 | Ronan's background is in travel-software product, which overlaps your travel-booking work, so the checkout story is in his own domain | See R7 | `[grounded]` his public profile; `[inferred]` the overlap | pending your approval |
| A4 | Ask the verification questions from RR1, RR4, RR5 and RR6 in the call, and confirm the pay range (RR3) | The register doubles as interview preparation | `[grounded]` register | pending your approval |

Rehearsing the call itself is mock-interview's job, which I can run if you want it.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway" (returned "About Fernquay", fernquay.example/about) and "Fernquay product designer Galway careers"; fetched "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer). Moved the organization, posting-consistency and contradictions rows, RR1 and RR2. The About page came from a search result, not a full read |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland startup first designer equity", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Moved the market calibration row and RR3. It gave pay only, nothing on equity or scope norms |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder background", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe). Moved the hiring-manager row and A3. A search result only, not a full read |

I can write this up as a `tuesday-dossier.md` if you want to keep it or reuse it in later sessions.

**Upgrade menu**

- Your checkout case study or a Figma file → R4 to `high`, and it firms up R7 and G2.
- Your pay floor → R2 resolves, and the decision likely simplifies to `go` or `no_go`.
- The sender address on the calendar invite → RR2 closes.
- Whether your research sessions were with consumers or business owners → R9 and G3 narrow.
- A deeper check on Fernquay (customer reviews, recent news, hiring history; up to 5 more searches and 2 more fetches) → say the word and it runs.

**Questions**

- G4 — What is the lowest salary you'd accept, and does €52,000–€60,000 clear it?
- G1 — In the checkout redesign, what was yours alone, what went to the team, and which decisions did you make without a design lead above you?
- RR2 — Did your application include your WhatsApp number, and does the invite email's sender address end in fernquay.example?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.