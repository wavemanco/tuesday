I'm partway through reading the job-underwriter playbook's reference files. I still need the gap taxonomy, the output rules and the research-tier rules before I write the assessment.
I've finished the research (three searches and one page fetch) and I'm writing up the assessment.

## Decision snapshot

**Yes, worth applying for, on conditions. The three hard gates (R1, R2, R3) are met on your own account and the clinical core (R5, R6, R9) is direct. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1, R2, R3
- `must_have` — direct: R4, R5, R6, R9 · adjacent: R7 (Leg-ulcer care), R8 (Catheter and continence care) · unclear: R10 (End-of-life visits), R11 (Clear, timely written records on the electronic patient record)
- `important` — adjacent: R12 (Hold a small caseload of your own) · unclear: R13 (Care planning)
- `preferred` — absent: R14 (Doppler assessment for leg ulcers)

R7 — a credible bridge from your wound care; R10 and R11 — the CV is silent, and one answer each could move them; R12 — new to you, with senior support named in the advert.

**Opportunity ledger.** The role looks sound on what the advert shows: the pay, car and caseload terms read well (RR2, RR3, RR4). The posting's live status, the induction offered and the working pattern are open (RR1, RR5, RR6).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`, R3 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed live, RR1; (2) your end-of-life and electronic-record experience is evidenced, R10 and R11; (3) leg-ulcer care and caseload are presented as adjacent, never as direct experience, R7 and R12.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC, a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract. Founded 2015, 410 staff, four locality hubs | `[grounded]` the company's About page |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin administration, care planning, all on an electronic patient record | `[grounded]` JD |
| Caseload and support | A small caseload of your own, supported by a senior community nurse | `[grounded]` JD |
| Pay and car | £31,050–£37,800 plus mileage; pool cars provided | `[grounded]` JD |
| Scope read | A normally scoped staff nurse post. The tasks are the usual district nursing set and the advert asks for one year's experience | `[inferred]` from the task list against the entry requirement |
| Market calibration | A 2026 survey of Band 5 community staff nurses in England (n=1,240) gives median basic pay of £34,300 and an interquartile range of £32,400–£36,600. This advert's range spans that interquartile range. The same survey found 24% had a pool or lease car and 61% were paid mileage. It is a survey pattern, never this employer's offer | `[generic]` Wardround 2026 pay guide; `[grounded]` JD for the advertised range |
| First 90 days and first year | Not stated | `[grounded]` JD silent |
| Unknowns | Posting live status and closing date; induction and Doppler training; shift pattern, weekends and out-of-hours; caseload size; which electronic record system | — |
| Contradictions | None found between the advert and the About page. The careers page was not found at the address I tried, so I could not confirm the post is listed | `[grounded]` About page read; careers address returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | You state an active registration with revalidation due March 2028. It is self-reported, and the register is public, so checking it is yours to do | `[grounded]` CV | none |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Category B full licence stated, which is what a pool-car role needs | `[grounded]` CV | none |
| R3 | Based in Halifax | hard_gate | direct | medium | none | You live in Halifax and the post is in Halifax. Travel between patients is by pool car | `[grounded]` CV and JD | none |
| R4 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward | `[grounded]` CV | none |
| R5 | Nursing patients in their own homes | must_have | direct | medium | none | Eighteen months seconded to a discharge-to-assess team, visiting patients at home in their first week after discharge | `[grounded]` CV | CV edit E1 pending approval |
| R6 | Wound care | must_have | direct | medium | none | Pressure ulcers and surgical wounds named | `[grounded]` CV | CV edit E1 pending approval |
| R7 | Leg-ulcer care | must_have | adjacent | low | transferability | Wound care is real, but leg ulcers, compression and venous assessment are not mentioned. Adjacent, with that limit named wherever it is used | `[inferred]` adjacency from the wound care stated | see G1 |
| R8 | Catheter and continence care | must_have | adjacent | medium | discovery | Catheter care is stated. Continence care is not mentioned, and it may simply be missing from the CV | `[grounded]` CV for catheters; `[grounded]` silence for continence | see G3 |
| R9 | Insulin administration | must_have | direct | medium | none | Stated. Insulin care planning is carried separately in R13 | `[grounded]` CV | none |
| R10 | End-of-life visits | must_have | unclear | low | discovery | The CV is silent. Acute medical ward work often includes end-of-life care, but nothing here says you did it | `[grounded]` CV silence; `[generic]` that it is common on such wards | see G2 |
| R11 | Clear, timely written records on the electronic patient record | must_have | unclear | low | discovery | Nothing on documentation or any record system in the CV | `[grounded]` CV silence | see G4 |
| R12 | A small caseload of your own, with senior support | important | adjacent | medium | transferability | You have never held a caseload. The discharge visiting is home-based work, but you did not own a list. The advert names senior support, which sets the bar lower | `[grounded]` your statement; `[grounded]` JD | see G5 |
| R13 | Care planning | important | unclear | low | discovery | Named in the advert and absent from the CV | `[grounded]` JD; CV silence | see G5 |
| R14 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You have not done one. The advert lists it as desirable, so it is a minor risk and not a blocker | `[grounded]` your statement | closure path in G6 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Leg-ulcer care (R7, must_have) | transferability | Pressure ulcer and surgical wound care. No compression or leg-ulcer work stated | A `must_have` at `adjacent`, and the area where the post's own named training need sits | Dressings or compression on leg wounds on the ward or in discharge visits; tissue viability link work | A competency record, or a sanitized wound-care note | `[inferred]` bridge from stated wound care |
| G2 | End-of-life visits (R10, must_have) | discovery | Nothing stated | The post includes end-of-life visits, and this is a `must_have` at `unclear` | Last-days care on the ward, syringe driver involvement, family conversations, anticipatory prescribing | A brief description of your role in end-of-life care | `[grounded]` CV silence |
| G3 | Continence care (R8, must_have) | discovery | Catheters stated, continence not | Closes the second half of a `must_have` row | Bladder and bowel care, catheter changes, continence assessments | One line on any continence work | `[grounded]` CV silence |
| G4 | Written records and the electronic record (R11, must_have) | discovery | Nothing stated | The advert makes records an essential criterion | Electronic record use on the ward or in discharge-to-assess; audit results | The system name and your documentation role | `[grounded]` CV silence |
| G5 | Caseload and care planning (R12 important, R13 important) | transferability and discovery | Visiting after discharge, nothing on owning a list or writing care plans | Both are named duties of the post | Deciding visit order, writing discharge plans, reviewing patients at follow-up | A description of who set your visit plan | `[grounded]` your statement; CV silence |
| G6 | Doppler (R14, preferred) | capability | None | Desirable only. The Team Lead's public talk suggests the service trains newcomers, so it looks like a gap that closes in post | Not applicable; a gap you carry honestly | Willingness to train, said plainly | `[inferred]` from the Team Lead's 2025 talk on Doppler training for staff new to community work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting live status not confirmed | unknown | — | "Community Staff Nurse, Band 5 — Calderbrook Community Health CIC, Halifax" | The post may be open and simply not at the careers address I tried. Or it may be closed or listed elsewhere | `[grounded]` careers address returned no page; `[generic]` that listings move | Is this post still open, and what is the closing date? | unresolved |
| RR2 | Pay set against market | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The advertised range spans the survey's typical band, which suggests a normal offer for the grade | `[generic]` survey pattern; `[grounded]` JD range | Where would a nurse with five years' ward experience start in that range? | noted |
| RR3 | Pool cars provided | positive_signal | — | "a full UK driving licence (pool cars are provided)" | A pool car is less common than mileage alone in the survey, so this is a comparatively good term | `[generic]` survey: 24% had a pool or lease car | Are pool cars available for every shift, and is mileage paid when a personal car is used? | noted |
| RR4 | Responsibility matched by support | positive_signal | — | "hold a small caseload of your own, supported by a senior community nurse" | A realistic scope for a nurse new to community work | `[inferred]` from the support named beside the caseload | How big is a new starter's caseload, and how is the senior nurse's support structured in the first months? | noted |
| RR5 | Induction and training not stated | unknown | — | "Desirable: Doppler assessment for leg ulcers" | The post may expect new community nurses to be trained on the job. The advert is silent, though the Team Lead has spoken publicly about training newcomers | `[inferred]` from the advert's silence and the Team Lead's 2025 talk | What induction and competency sign-off, including Doppler training, do new community nurses receive, and over how long? | unresolved |
| RR6 | Working pattern not stated | unknown | — | "end-of-life visits" | Visits like these may involve evenings, weekends or an on-call element. The advert does not say | `[generic]` that community nursing posts often carry a rota; the advert is silent | What is the shift pattern, including weekends, bank holidays and out-of-hours? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Use the offered informal chat with Rhiannon Mabbott before applying, and ask RR1, RR5 and RR6 there | The advert invites it, and it settles the live status and the working pattern | `[grounded]` JD | pending your approval |
| E1 | Put the discharge visiting and the home-based work first in your CV. Lead with R5, then wound, catheter and insulin work. Describe the discharge role as visiting patients at home after discharge, with no caseload wording | The posting's core is home visits, and R5 is your strongest direct row | `[grounded]` CV | pending your approval |
| E2 | Name leg-ulcer care and the caseload as things you would be building on, not things you have done | Keeps R7 and R12 at `adjacent` | `[grounded]` R7, R12 rows | pending your approval |
| A2 | Show interest in Doppler training in your supporting statement without claiming skill | The Team Lead has spoken on nurse-led leg-ulcer clinics and on Doppler training for new community staff, so interest is likely to land | `[inferred]` from the public talk summary | pending your approval |
| Q1 | Ask RR1, RR3, RR4, RR5 and RR6 verbatim at the chat or interview | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Your National Insurance number isn't needed for this assessment and I haven't used it. An application form has no use for it until an offer.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about): the entity exists and matches the advert's description. A fetch of calderbrookhealth.example/careers returned no page, so the posting is not confirmed live. Moved role reality's organization and contradictions rows, and RR1 |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse district nursing Band 5 salary 2026 Agenda for Change pay scale", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved the market calibration row, RR2 and RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook Community Health", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Moved G6, RR5 and plan rows A2. The advert names her as the contact for a chat, not as the hiring manager |

I can save this as `tuesday-dossier.md` to carry forward, if you'd like.

## Upgrade menu

- The name of the electronic record system you used, with a line on your documentation role → R11.
- Any end-of-life care you gave → R10, and one line on continence work → R8.
- A description of who set your visit plan in discharge-to-assess, and whether you wrote care plans → R12 and R13.
- Your constraints (pay floor, hours, weekends, travel) → the hard-gates line stops reading "checks unknown".
- A link to the live posting or its closing date → RR1.
- Interview prep, if you apply, is a separate module, mock-interview.
- A deeper pass on Calderbrook (leadership changes, public staff and patient reports, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

1. **R10:** Have you been directly involved in end-of-life care on the ward or in discharge-to-assess, and what did you do?
2. **R12 and R13:** In discharge-to-assess, did you decide visit order or frequency and write care plans yourself, or did someone else set those?
3. **Hard gates:** Do you have a pay floor, or limits on hours or weekends, that I should check this against?

A line or two each is enough, you can say "skip" to any, and pasting a few CV bullets works too.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.