I searched for the employer and found nothing, so I'm writing up the full assessment now.

**Decision snapshot**

**No, don't go ahead, and don't send anything. This job is very likely a scam: RR1, RR2 and RR3 each ask you for money, a cheque deposit, or bank and ID details. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Pay of at least €30,000 a year)
- `must_have` — direct: R2, R3, R4

R2, R3 and R4 (all `medium`) — your background is self-reported, so these are leads and not proof.

**Opportunity ledger.** The role itself fails on what it asks of you: payment for equipment (RR2), a cheque to deposit and forward (RR1), and bank and ID details before any offer (RR3). A hiring process run wholly in chat (RR4) and an employer I couldn't find (RR5) add to that. The pay is also uncertain against your floor (RR6).

- **Hard gates:** none failed; unconfirmed: R1 (Pay of at least €30,000 a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would change this:** the requests would have to not exist. There would have to be no payment, no cheque and no pre-offer ID or bank details. Interviews and the offer would have to happen outside chat, and Velloway's own website, found independently, would have to confirm the posting and the contact.

I'm not repeating your IBAN, and neither it, your PPS number nor your passport photo is needed to assess this.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics", with no web presence I could find | `[grounded]` two searches returned no results |
| Mandate | Remote order processing, spreadsheets, written English; no experience needed | `[grounded]` posting |
| Pay and hours | Up to €26 an hour plus commission, 15–30 hours a week. At the top rate that is about €20,300 to €40,500 a year over 52 weeks. Your €30,000 floor needs about 22 hours a week at the maximum rate | `[grounded]` posting figures; arithmetic mine |
| Process | Telegram only, no calls or video | `[grounded]` posting |
| Contradiction | The posting says "full training provided" and mentions no purchases, but the chat then asks you to buy a €349 kit | `[grounded]` posting against your messages |
| Contact | The HR email isn't shown to be on any company domain of its own | `[inferred]` from the address you quoted |
| Unknowns | Who the sender is; whether the named employer is involved at all | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay of at least €30,000 a year (your hard constraint) | hard_gate | unclear | high | hard_gate | Confidence grades your own stated floor. Fit is `unclear` because "up to €26" and variable hours don't settle it, and the posting gives a range, not a guarantee | `[grounded]` your constraint and the posting | Moot given RR1–RR3 |
| R2 | Strong attention to detail | must_have | direct | medium | none | About 60 Zendesk tickets a day, self-reported with nothing inspectable yet | `[grounded]` your background | none |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel; self-reported | `[grounded]` your background | none |
| R4 | Good written English | must_have | direct | medium | none | Written ticket work, and you trained two new starters; self-reported | `[grounded]` your background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay at or above €30,000 (R1, hard_gate) | hard_gate | Pay is stated only as a ceiling and hours as a range | Whether the pay meets your floor decides it, but only if the role were real | A written, guaranteed hourly rate and weekly hours from the employer's own site | The employer's own published pay terms | `[grounded]` posting wording |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Cheque to deposit, then forward most of it | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." | This request is very likely a scam. Don't deposit the cheque. | `[generic]` a known pattern of overpayment-style requests; not a claim about any named party | To the employer's own HR, via contacts you find yourself on its site: do you issue cheques to new hires to forward to suppliers? | confirmed |
| RR2 | Paying for equipment | red_flag | high | "please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages" | A request to pay for the job or kit is a recognised warning sign | `[generic]` known pattern | To the employer, as above: do you require staff to buy equipment? | confirmed |
| RR3 | Bank, tax and ID details before any offer | red_flag | high | "Before your chat interview, please send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up." | Those details were asked for before any written offer | `[generic]` known pattern | To the employer, as above: when and why do you collect these? | confirmed |
| RR4 | Hiring run wholly by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." | The interview and the offer both happened only in chat. The message may not come from who it names | `[inferred]` from the posting and your messages | To the employer, as above: do you hire only by Telegram? | confirmed |
| RR5 | Employer not established | risk_signal | medium | "Velloway Logistics" | Two searches found nothing. The entity may be too new or small to have a footprint, or the posting may not represent a real hiring employer. Severity stays at the lower value because only two searches ran | `[generic]` pattern, not a claim about this one | Can you point me at this role on your own careers site? | unresolved |
| RR6 | Pay may fall below your floor | unknown | — | "Earn up to €26 an hour plus commission" | The commission is unspecified, and your floor needs about 22 hours a week at the top rate (R1) | `[inferred]` from the posting figures | What guaranteed hourly rate and weekly hours does this post carry? | unresolved |

For RR1–RR4, hold any payment, deposit or disclosure while you check. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't send the IBAN, PPS number or passport photo | see RR3 | `[grounded]` RR3 | pending your approval |
| A2 | Don't pay the €349 and don't lodge the cheque | see RR1, RR2 | `[grounded]` RR1, RR2 | pending your approval |
| A3 | If you want to check, find the company's own website or contacts independently, not through the Telegram handle or the email you were given | see RR1–RR4 | `[grounded]` register | pending your approval |
| A4 | Stop replying, and report the posting to the jobs site | Gives the site a chance to remove it | `[generic]` common practice | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics" and "Velloway Logistics Remote Order Processing Coordinator careers"; both returned nothing. Moved RR5 to "not established" |
| 2. Role-family sweep | skipped | The decision and RR1–RR4 are fixed by the requests in your messages; a market band would change no row |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- Velloway's own website or careers page, if you can find one independently → RR5 and the employer check.
- Any written offer on company letterhead, plus the posting's link → whether the posting is live.
- A deeper research pass on the employer (up to 5 more searches and 2 more fetches) — say the word and it runs.

Offer: I can save this as a `tuesday-dossier.md` if you'd like a record.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.