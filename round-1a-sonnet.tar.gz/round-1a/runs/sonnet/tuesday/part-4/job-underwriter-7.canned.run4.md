I'm running the L1 research the playbook calls for: checking that Calderbrook exists and the posting is live, and getting a pay and scope benchmark for the role.
# Job Underwriting Assessment: Community Staff Nurse, Band 5 at Calderbrook Community Health CIC, Halifax

*Stage assumed: evaluating.*

## Decision snapshot

**Yes, this is worth applying for, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3, R6 · adjacent: R4 (Wound and leg-ulcer care), R5 (Catheter and continence care), R7 (Care of housebound adults at home) · unclear: R10 (Clear, timely written records)
- `important`: adjacent: R8 (Own small caseload) · unclear: R9 (End-of-life visits), R11 (Care planning)
- `preferred`: absent: R12 (Doppler assessment for leg ulcers)

R4, R5, R7, R8 — credible bridges, limits named; R9 (`none`) — no evidence either way; R12 — preferred, absent.

**Opportunity ledger.** Sound on its face: pay, caseload size and senior support are all stated (RR2, RR4). Open items are whether the post is live (RR1), whether Doppler training is offered (RR3) and the working pattern (RR5).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** the post confirmed live (RR1); end-of-life care experience confirmed or honestly framed as absent (R9); the caseload step-up shown as an adjacent bridge, never as caseload experience (R8); Doppler training confirmed as offered (RR3, R12).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | A community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract. Founded 2015, 410 staff, four locality hubs | `[grounded]` the company's About page |
| Role | Band 5 district nursing post for housebound adults at home: wounds and leg ulcers, catheter and continence care, end-of-life visits, insulin, care planning, electronic patient record. Small own caseload with senior-nurse support | `[grounded]` posting |
| Hiring contact | Rhiannon Mabbott leads the Halifax district nursing team, after eleven years as a district nurse. In 2025 she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` forum speaker page (search snippet) |
| Scope read | A genuine district-nursing post structured for a nurse stepping into caseload-holding, not a bundled or authority-free role | `[inferred]` from the "small caseload … supported by a senior community nurse" wording |
| Market calibration | £31,050–£37,800 sits around the survey median of £34,300, inside a survey spread of £32,400–£36,600 (n=1,240, England, 2026). The survey found mileage paid to 61% and a pool or lease car for 24%, so a pool car is on offer here | `[grounded]` the posting's figure; `[generic]` the survey band, never this employer's offer to you |
| Unknowns | Whether the post is live; hours and weekend or out-of-hours pattern; Doppler training timescale; where you would start on the range | none |
| Contradictions | None found between the posting and the About page | `[grounded]` About page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | CV states Registered Nurse (Adult), registration active, revalidation due March 2028. A stated claim with nothing yet inspected, so `medium`. Checking the register is yours | `[grounded]` CV | none |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | CV states a full UK licence, category B. Pool cars are provided, so no vehicle is needed | `[grounded]` CV and posting | none |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward. A length-of-experience requirement is not a gate | `[grounded]` CV | none |
| R4 | Wound and leg-ulcer care | must_have | adjacent | medium | transferability | Wound care including pressure ulcers and surgical wounds is stated. Leg-ulcer care is not. Limit: compression therapy and ulcer assessment are not in the CV | `[grounded]` CV; `[inferred]` the adjacency, derived from the pressure-ulcer and surgical-wound work | See G4 |
| R5 | Catheter and continence care | must_have | adjacent | medium | discovery | Catheter care is stated. Continence care is not mentioned, so the claim is carried at catheter care only | `[grounded]` CV | Confirm continence work in the recovery turn if it exists; otherwise carry as is |
| R6 | Insulin administration | must_have | direct | medium | none | Insulin administration is stated on the CV | `[grounded]` CV | none |
| R7 | Caring for housebound adults in their own homes | must_have | adjacent | medium | transferability | Eighteen months seconded to the discharge-to-assess team, visiting patients at home in their first week after discharge. Limit: short post-discharge episodes, not an ongoing housebound caseload | `[grounded]` CV; `[generic]` that district nursing is mostly long-term follow-up | See G2 |
| R8 | A small caseload of your own | important | adjacent | low | transferability | You say you have never held your own caseload. The discharge-to-assess visits are adjacent evidence of working alone in homes, but how independent that work was is unstated, so `low` | `[grounded]` your statement and CV; `[inferred]` the autonomy, left unconfirmed | See G2 |
| R9 | End-of-life visits | important | unclear | none | discovery | The CV is silent. An acute medical ward may have included palliative patients, which is a lead and not evidence | `[grounded]` CV silence; `[generic]` that medical wards often include palliative patients | See G1 |
| R10 | Clear, timely written records on an electronic patient record | must_have | unclear | low | discovery | Five years of ward nursing implies records, but the CV names no system or documentation work | `[grounded]` CV silence; `[inferred]` from the role | See G3 |
| R11 | Care planning | important | unclear | low | discovery | The discharge-to-assess role may have involved planning, but the CV does not say | `[grounded]` CV silence | See G3 |
| R12 | Doppler assessment for leg ulcers (desirable) | preferred | absent | none | capability | You have never done one. The posting lists it as desirable, not essential. The hiring contact has spoken publicly on Doppler training for staff new to community work, so training looks like a realistic closure path | `[grounded]` your statement and the posting; `[inferred]` that training is offered here | Ask about training (RR3) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | End-of-life visits (R9, important) | discovery | The CV says nothing on palliative or end-of-life care | Unaddressed, it is the one listed duty with no evidence behind it | Caring for dying patients on the ward; rapid discharges home for end-of-life care; anticipatory medication; supporting families | A reflective note, a ward palliative-care competency record, a reference | `[grounded]` CV silence; `[generic]` that interviewers for this work usually ask about it |
| G2 | Working alone at home and holding a caseload (R7, R8) | transferability | Home visits on discharge-to-assess, but no statement of how independently you worked or planned your own visits | R8 is the point where you say you have no direct experience, and R7 is the core of the post | Planning your own visit list; deciding on the spot what to escalate; managing a patient across several visits | A description of a typical week, a service outline, a reference from the team lead | `[grounded]` CV and your statement; `[inferred]` that the bridge may be stronger than the CV shows |
| G3 | Records and care planning (R10, R11) | discovery | No system named; planning not mentioned | R10 is essential in the posting | An electronic patient record you used on the ward or in discharge-to-assess; writing a discharge plan; audited documentation | The name of the system, a competency sign-off | `[grounded]` CV silence |
| G4 | Leg-ulcer care and Doppler (R4, R12) | capability | Pressure-ulcer and surgical-wound care, no leg ulcers, no Doppler | R4 is a `must_have` at `adjacent`; R12 is preferred and trainable | Any leg-ulcer dressing or compression work seen on the ward; tissue viability study days | A training certificate or competency record | `[grounded]` CV and your statement; `[inferred]` closure path from the contact's public talk |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Post live not confirmed | unknown | — | "Community Staff Nurse, Band 5 — Calderbrook Community Health CIC, Halifax" | The About page confirms the company and says vacancies are on a careers page. The address I tried returned no page, so the post may be live at another address or may be stale | `[grounded]` About page fetched; careers address tried returned no page; `[inferred]` that this leaves liveness open | Is this post currently open, and what is the closing date and interview format? | unresolved |
| RR2 | Caseload held with senior support | positive_signal | — | "You will hold a small caseload of your own, supported by a senior community nurse." | The post is built for a nurse starting to hold a caseload | `[inferred]` from the posting's wording | How is a new starter's caseload built up, and how much senior-nurse time is protected for support? | noted |
| RR3 | Doppler training not described | unknown | — | "Desirable: Doppler assessment for leg ulcers" | Because it is desirable and not essential, new starters may be trained. The contact has spoken on Doppler training for community newcomers | `[grounded]` the contact's talk; `[inferred]` that it applies to this post | Is Doppler training offered to new starters, and by when would I be expected to be competent? | unresolved |
| RR4 | Pay stated | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The range sits around the survey median. Where you would start on it is unknown | `[grounded]` posting figure; `[generic]` survey band | Where on the range would my experience start, and what is the mileage rate? | unresolved |
| RR5 | Working pattern unstated | unknown | — | "end-of-life visits" | End-of-life care may involve evening or weekend visits, and the posting gives no hours or rota | `[generic]` pattern for district nursing; `[grounded]` posting silence | What are the working hours, weekend rota and any out-of-hours or lone-working expectations? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Move the discharge-to-assess home-visiting work to the top of the CV, stated as post-discharge visits and not as a caseload | See R7, R8 | `[grounded]` CV | pending your approval |
| E2 | Bring catheter care, insulin administration and wound care (pressure ulcers and surgical wounds) into one visible clinical-skills line, with no leg-ulcer or continence claim unless confirmed | See R4, R5, R6 | `[grounded]` CV | pending your approval |
| Q1 | Use the informal chat the advert offers with the named team lead to ask the RR1, RR3, RR4 and RR5 questions verbatim | The register doubles as interview preparation | `[grounded]` posting | pending your approval |
| A1 | Describe leg-ulcer, caseload and Doppler experience as absent or adjacent, never as held | See R4, R8, R12 | `[grounded]` your statement | pending your approval |

Nothing above is final CV wording or outreach until you approve it.

## Evidence status

Verified: none yet. The Government ID number you included is not needed and was not used or repeated.

Research tier: L1 — searches 4 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Calderbrook Community Health CIC Community Staff Nurse Band 5 district nursing vacancy". Fetched "About Calderbrook Community Health" (calderbrookhealth.example/about) and tried calderbrookhealth.example/careers, which returned no page. Moved: the organization row, and RR1 (employer exists as described; post liveness not established) |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse district nursing salary 2026 Agenda for Change pay scale", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide), read from its search snippet. Moved: the market calibration row and RR4 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott), read from its search snippet. Moved: the hiring contact row, R12 and RR3 |

I can offer to save this as `tuesday-dossier.md` whenever you want it.

## Upgrade menu

- Any palliative-care or end-of-life experience you can describe → R9 moves from `unclear`, and G1 closes or becomes an honest gap.
- A short description of how independently you ran your discharge-to-assess visits → R7 and R8 firm up, and E1 can be worded properly.
- The name of the electronic patient record you used → R10 and R11 move.
- A careers-page link or the recruiter's reply on RR1 → the post-live condition closes.
- A deeper research pass on Calderbrook (staff reports, NHS contract news, trust inspection history; up to 5 more searches and 2 more fetches) → say the word and it runs.

## Questions

G1 — Have you cared for patients at the end of life, on the ward or in discharge-to-assess? What did you personally do, and who else was involved?

G2 — In your discharge-to-assess work, did you plan your own visit list and decide alone what to escalate? What did a typical week look like?

G3 — Which electronic patient record did you use, and did you write discharge or care plans yourself?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.