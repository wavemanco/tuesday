Checking whether each employer exists as described, then I'll write up both assessments.
Search permission was declined, so employer checks didn't run and this rests on the postings and your background. Short version: the first role is worth applying to, and the second isn't.

# 1. Operations Analyst — Duinvaart Cold Chain, Rotterdam

## Decision snapshot

**Yes, worth your time — on conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Three days in Rotterdam office)
- `must_have` — direct: R2, R3, R4
- `important` — direct: R5a, R6 · unclear: R5b (Temperature compliance)
- `preferred` — adjacent: R7 (Dutch a plus)

R5b — cold-chain exposure unproven; R7 (`medium`) — conversational Dutch against a stated plus.

**Opportunity ledger.** The deliverables are concrete (RR3), but the employer is unverified (RR1) and pay is withheld (RR2).

- **Hard gates:** none failed; unconfirmed: R1 (Three days in Rotterdam office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the Rotterdam three-day pattern is workable for you — R1; (2) the employer and live posting verify — RR1; (3) your parcel-carrier work is framed as adjacent to temperature compliance, not equivalent — R5b.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, a refrigerated-fleet operator in Rotterdam | `[grounded]` posting header; existence not checked |
| Mandate | Track on-time delivery and temperature compliance, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` posting |
| Working pattern | Hybrid, three office days a week in Rotterdam | `[grounded]` posting |
| Scope read | An analyst post whose named tools and duties match what you do daily | `[inferred]` from the posting's list against your stated work |
| Unknowns | Salary, team size, whether the fleet data is clean enough to dashboard | — |
| Contradictions | None inside the posting | `[grounded]` posting only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, three days a week in the Rotterdam office | hard_gate | unclear | low | hard_gate | Your home location and commute limits weren't given, so whether you meet this term is not established | `[grounded]` posting term; constraint unstated | Closing question 2 |
| R2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier; self-reported, nothing inspected | `[grounded]` your background | none |
| R3 | Strong SQL | must_have | direct | medium | none | You use it daily; "strong" is a judgement an interviewer may test | `[grounded]` your background | Be ready for a live query exercise |
| R4 | Power BI or Tableau | must_have | direct | medium | none | Daily Power BI use, including the on-time delivery dashboard your depot managers use. Whether you built or maintain it is unstated, so I claim only the use | `[grounded]` your background | A sanitized screenshot would raise it to `high` |
| R5a | Track on-time delivery | important | direct | medium | none | The dashboard above and the weekly route-performance review you ran | `[grounded]` your background | none |
| R5b | Track temperature compliance on a refrigerated fleet | important | unclear | low | discovery | Nothing stated about temperature-controlled loads or sensor data. Parcel carriers sometimes handle chilled goods, so evidence may exist | `[grounded]` silence in your background; `[generic]` that some carriers handle chilled parcels | Closing question 1 |
| R6 | Work with depot managers on route changes | important | direct | medium | none | You ran the weekly route-performance review and depot managers use your dashboard. Whether route changes followed is unstated, so claim the review, not the outcomes | `[grounded]` your background | Be ready to say what changed after a review |
| R7 | Dutch a plus | preferred | adjacent | medium | transferability | Your own level is conversational. Limit: a working-language document or meeting is untested | `[grounded]` your statement | Offer to meet any Dutch need honestly at that level |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Temperature compliance (R5b, important) | discovery | Nothing on temperature-controlled freight or sensor or excursion data | It is the one duty in the posting with no match in your background | Chilled or pharma parcels, temperature-excursion reports, SLA breach analysis, cold-handling audits | A sanitized report or dashboard view | `[grounded]` background silent; `[generic]` that excursion reporting is the usual form of this work |
| G2 | Location term (R1, hard_gate) | hard_gate | Commute or relocation situation unknown | A term you meet or don't; no wording changes it | — | — | `[grounded]` posting term, constraint not given |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | May be too small for a footprint, the posting may be stale, or it may not be a live hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your careers site, and who would I be working with? | unresolved |
| RR2 | Pay not stated | unknown | — | Posting lists no salary | May sit below your floor or simply not be published | `[inferred]` from the posting's silence | What is the salary range for this post? | unresolved |
| RR3 | Concrete deliverables named | positive_signal | — | "weekly dashboards in Power BI" | Scope is defined and measurable | `[grounded]` posting | What does a good first quarter look like? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check the live posting on the company's own careers page before applying | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Lead with the on-time delivery dashboard your depot managers use and the weekly route-performance review you ran, in your own words | see R4, R5a, R6 | `[grounded]` your background | pending your approval |
| A3 | Ask the RR1 to RR3 questions verbatim in the first conversation | The register doubles as interview prep | `[grounded]` register | pending your approval |

If you apply, resume-tailor can draft the CV edits as an approve-first ledger.

# 2. Supply Planner — Kroonhaven Foods, Utrecht

## Decision snapshot

**No, not worth your time as it stands. Status: `no_go`. R2, R3 and R6 are must-haves with no planning evidence behind them.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (On-site in Utrecht)
- `must_have` — adjacent: R4 (Weekly S&OP meeting), R7 (Fluent Dutch) · unclear: R5 (Advanced Excel) · absent: R2 (3+ years FMCG planning), R3 (13-week supply plan), R6 (SAP IBP or similar)

R2, R3 and R6 — no planning experience, by your own account; R4 (`medium`) — a real bridge from the weekly review, its limit named.

**Opportunity ledger.** The scope is concrete (RR3), but the employer is unverified (RR1) and pay is withheld (RR2).

- **Hard gates:** none failed; unconfirmed: R1 (On-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** planning experience in FMCG or a comparable setting, and Dutch at fluent level, would have to exist and be evidenced. You'd be changing careers into this post, not moving sideways.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, a chilled ready-meals producer in Utrecht | `[grounded]` posting header; existence not checked |
| Mandate | Own the 13-week supply plan, balance capacity against forecast, run the weekly S&OP meeting | `[grounded]` posting |
| Working pattern | On-site in Utrecht | `[grounded]` posting |
| Scope read | A planning-owner role, not an analyst role | `[inferred]` from "own the plan" and "run the meeting" |
| Unknowns | Salary, team size, planning-system maturity | — |
| Contradictions | None inside the posting | `[grounded]` posting only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Utrecht | hard_gate | unclear | low | hard_gate | Your location and commute limits weren't given | `[grounded]` posting term; constraint unstated | Closing question 2 |
| R2 | 3+ years supply or demand planning in FMCG | must_have | absent | none | capability | You've never worked in planning, and your carrier background is not FMCG. Experience length isn't a gate, but work near it is the only evidence it could rest on | `[grounded]` your statement; `[generic]` that postings asking years in a sector are often screened on it literally | Closure path: a planning role in a smaller scope first |
| R3 | Own the 13-week supply plan, capacity against forecast | must_have | absent | none | capability | No plan-ownership or capacity-balancing work stated | `[grounded]` your statement | Carry as a material risk |
| R4 | Run the weekly S&OP meeting | must_have | adjacent | medium | transferability | You ran a weekly route-performance review. Limit: it wasn't a demand, supply and finance planning cycle and you didn't own a plan | `[grounded]` your background | If proceeding, state that limit plainly |
| R5 | Advanced Excel | must_have | unclear | low | discovery | Your tools are SQL and Power BI; Excel use is unstated | `[grounded]` silence in your background | Ask only if you proceed |
| R6 | SAP IBP or a similar planning system | must_have | absent | none | capability | No planning-system use stated, and you've never worked in planning | `[grounded]` your statement | Carry as a material risk |
| R7 | Fluent Dutch | must_have | adjacent | medium | transferability | Your level is conversational, below the stated bar. Limit: running a meeting in Dutch is untested | `[grounded]` your statement | The posting sets this as required, not a plus |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Planning ownership and system (R2, R3, R6; must_have) | capability | No planning work, plan ownership or planning-system use | Three must-haves with nothing behind them is the basis of `no_go` | A scoped path would be a demand-planning or analyst post inside a planning team, not this one | — | `[grounded]` your statement; `[inferred]` that a team-embedded analyst post is the nearer step |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established | risk_signal | medium | "Kroonhaven Foods, Utrecht" | May be too small for a footprint, the posting may be stale, or it may not be a live hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your careers site, and who would I report to? | unresolved |
| RR2 | Pay not stated | unknown | — | Posting lists no salary | May sit below your floor or simply not be published | `[inferred]` from the posting's silence | What is the salary range for this post? | unresolved |
| RR3 | Scope and cadence are concrete | positive_signal | — | "13-week supply plan", "weekly S&OP meeting" | The role is well defined | `[grounded]` posting | Who owns the forecast the plan is balanced against? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply; spend the time on roles like the first one | see G1 | `[inferred]` from R2, R3, R6 | pending your approval |
| A2 | If you apply anyway, ask the RR1 to RR3 questions verbatim and state R4's limit plainly | The register becomes essential | `[grounded]` register | pending your approval |

# Evidence status

Verified: none yet. Everything above rests on the two postings and your own account, so the confidence bands cap at `medium`. The call is yours; I'm recommending, not deciding.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Duinvaart Cold Chain Rotterdam refrigerated transport" and "Kroonhaven Foods Utrecht chilled ready meals"; both were refused because search permission wasn't granted. Would have settled RR1 for each role |
| 2. Role-family sweep | unavailable | Not sent, because the user hasn't granted search. Would have moved pay calibration (RR2) for each role |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

# Next steps

I can save this as `tuesday-dossier.md` if you want a record to carry into later steps.

**Upgrade menu**
- Allow web search and I'll run the employer checks on both firms, which would close or confirm RR1 in each.
- A sanitized dashboard screenshot would raise R4 to `high`.
- An answer to question 1 would resolve R5b.
- Your pay floor would let RR2 be checked against your own limit in each role.
- Any temperature or chilled-freight report you handled would close G1 for the first role.

**Questions**
1. G1 (first role) — Have you handled chilled or temperature-controlled parcels, or any temperature-excursion reporting? What was your part, and was there a report or dashboard view? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
2. R1 (both roles) — Where do you live, and is a three-day weekly commute to Rotterdam, or five days a week to Utrecht, workable for you? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
3. RR2 (both roles) — What's the lowest salary you'd accept? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.