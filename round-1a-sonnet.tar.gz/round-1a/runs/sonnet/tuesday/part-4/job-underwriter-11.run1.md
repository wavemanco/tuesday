I've read the underwriter playbook and its reference files. Next I'm loading the search tool to check that both employers exist and that the postings are live, then I'll write up the assessment.
# Assessment: two roles

## Decision snapshots

**Role 1, Duinvaart Cold Chain, Operations Analyst. Yes, worth your time: `conditional_go`.**

**Fit ledger.**
- `hard_gate`: unclear: R7 (Hybrid, three days in Rotterdam)
- `must_have`: direct: R1, R2, R3, R5 · unclear: R4b (Temperature compliance on refrigerated fleet)
- `must_have`, split row: direct: R4a
- `preferred`: adjacent: R6 (Dutch a plus)

R4b (`low`): the one real unknown, with a recall prompt below; R7: the commute is not yet settled; R6: conversational Dutch against a "plus".

**Opportunity ledger.** The posting is plausible on its face, but the employer is not established from here (RR1) and the salary is withheld (RR2).
- **Hard gates:** none failed; unconfirmed: R7 (Hybrid, three days in Rotterdam); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting and employer verify as live, RR1; (2) the three-days-in-Rotterdam commute works for you, R7; (3) the temperature-compliance gap is framed honestly as adjacent or as a gap, R4b.

---

**Role 2, Kroonhaven Foods, Supply Planner. No, I'd skip it: `no_go`.**

**Fit ledger.**
- `hard_gate`: unclear: R8 (On-site in Utrecht)
- `must_have`: adjacent: R6 (Run the weekly S&OP meeting), R5 (Fluent Dutch) · unclear: R3 (Advanced Excel) · absent: R1 (3+ years planning in FMCG), R2 (Own the 13-week supply plan), R4 (SAP IBP or similar)

R1, R2 and R4 — no planning work in your history, and no planning tool; R5 and R6 — the Dutch and the review are real adjacent evidence, with limits named.

**Opportunity ledger.** The employer is not established from here (RR3) and the salary is withheld (RR4).
- **Hard gates:** none failed; unconfirmed: R8 (On-site in Utrecht); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **What would change this:** a different set of facts. R1, R2 and R4 would need real planning evidence, and you said you've never worked in planning. If you proceed anyway, RR3 and RR4 become your first questions.

---

## Role 1: Operations Analyst

### Role reality

| Element | What it is | Provenance |
|---|---|---|
| Mandate | Track on-time delivery and temperature compliance for a refrigerated fleet, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` posting |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` posting |
| Scope read | A mid-level analyst remit with no team, budget or decision rights stated; it reads as an individual-contributor post | `[inferred]` from the posting's silence on reports and authority |
| Market calibration | Not run; no search was available (see Evidence status) | `[generic]` no band is asserted |
| Unknowns | Salary, employer footprint, whether the three office days are fixed | `[grounded]` posting silent on all three |

### Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier; stated in your message, no artifact inspected, so `medium` | `[grounded]` your stated background | none |
| R2 | Strong SQL | must_have | direct | medium | presentation | You use SQL daily; "strong" is the posting's word and your claim is confirmed but unprobed. Expect a technical screen | `[grounded]` your stated background; `[generic]` that analyst roles of this kind often test SQL | Lead the CV with SQL-specific outcomes |
| R3 | Power BI or Tableau | must_have | direct | medium | none | Power BI daily, including a dashboard in production use by depot managers | `[grounded]` your stated background | A screenshot or sanitized export would raise this to `high` |
| R4a | Track on-time delivery | must_have | direct | medium | presentation | You built the on-time delivery dashboard that your depot managers use; this is the posting's first named duty | `[grounded]` your stated background | Put this first on the CV |
| R4b | Temperature compliance on a refrigerated fleet | must_have | unclear | low | discovery | Nothing you've said touches temperature or cold chain. A parcel carrier may have handled temperature-sensitive parcels, but that is unconfirmed | `[grounded]` your background is silent on it; `[inferred]` that parcel work may have touched it | Recall prompt G1 |
| R5 | Work with depot managers on route changes | must_have | direct | medium | presentation | You ran the weekly route-performance review and your dashboard serves depot managers | `[grounded]` your stated background | Surface the review on the CV |
| R6 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational Dutch is real, and the posting calls fluency a plus, not a requirement. Limit: not fluent, so don't claim it | `[grounded]` your stated Dutch level and the posting's wording | State the level honestly |
| R7 | Hybrid, three days a week in Rotterdam | hard_gate | unclear | none | hard_gate | You live or work in Amsterdam, but gave no commute or location constraint, so whether this term works for you is unsettled | `[grounded]` posting term; `[inferred]` Amsterdam from your last employer | G2 |

### Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Temperature compliance (R4b, must_have) | discovery | Your background doesn't mention temperature, cold chain or compliance reporting | It is the one named duty with no evidence; closing it moves the decision from `conditional_go` toward `go` | Tracking temperature-sensitive or pharma parcels; reporting delivery exceptions against a service standard; building SLA or compliance views in Power BI | A dashboard screenshot or a KPI definition document | `[grounded]` background silent; `[generic]` that compliance reporting transfers in part |
| G2 | Hybrid commute (R7, hard_gate) | hard_gate | The posting requires three Rotterdam days and I don't know your constraints | A gate the inputs don't settle stays open, and wording cannot solve it | None | None | `[grounded]` posting term |

### Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | The entity may be small, the posting may be stale, or it may not represent a live hiring employer; the search was refused, so this is the default entry | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers page, and who would I work with day to day? | unresolved |
| RR2 | Salary withheld | unknown | — | (no figure in the posting) | The figure may be below market for four years of experience, or the firm may just not publish | `[generic]` pattern of postings that omit pay | What salary range is budgeted for this role? | unresolved |
| RR3 | Authority over route changes not stated | unknown | — | "work with depot managers on route changes" | The analyst may advise on route changes without owning them | `[inferred]` from the posting's silence on decision rights | Does this role recommend route changes or decide them? | unresolved |

### Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check the posting on Duinvaart's own site and confirm the three office days before you apply | RR1, R7 | `[grounded]` register | pending your approval |
| A2 | Lead the CV with the on-time delivery dashboard and the weekly route-performance review, in your own existing wording | R4a, R5 | `[grounded]` your stated background | pending your approval |
| A3 | Ask RR2 and RR3 in the first call | The register doubles as interview prep | `[grounded]` register | pending your approval |

---

## Role 2: Supply Planner

### Role reality

| Element | What it is | Provenance |
|---|---|---|
| Mandate | Own the 13-week supply plan for chilled ready-meals, balance capacity against forecast, run the weekly S&OP meeting | `[grounded]` posting |
| Working pattern | On-site in Utrecht, no hybrid mentioned | `[grounded]` posting |
| Scope read | A core planning role that sits at the centre of the S&OP cycle, not an entry-level post | `[inferred]` from "own" and "run" in the duties and the 3+ year requirement |
| Market calibration | Not run; no search was available | `[generic]` no band is asserted |

### Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years supply or demand planning in FMCG | must_have | absent | none | capability | You said you've never worked in planning. This is a length-of-experience requirement, so it is graded as a gap, not a gate. FMCG is also new to you | `[grounded]` your statement | Name a closure path or carry as a material risk |
| R2 | Own the 13-week supply plan | must_have | absent | none | capability | Core duty; no planning ownership in your history | `[grounded]` your statement | none |
| R3 | Advanced Excel | must_have | unclear | low | discovery | You use SQL and Power BI daily, but Excel depth is unstated | `[grounded]` background silent on Excel | Recall prompt G1 |
| R4 | SAP IBP or a similar planning system | must_have | absent | none | capability | No planning-system experience in what you described | `[grounded]` your stated background | none |
| R5 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational Dutch is real. Limit: the posting says fluent and you are not, in a role where the meeting is run in Dutch | `[grounded]` your stated Dutch level; `[inferred]` the meeting language from the posting | State the level honestly |
| R6 | Run the weekly S&OP meeting | important | adjacent | medium | transferability | You ran a weekly route-performance review. Limit: an operations review isn't an S&OP meeting, which reconciles demand, supply and finance | `[grounded]` your stated background; `[generic]` what an S&OP meeting covers | Bridge, with its limit named |
| R8 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | No constraints were given, so whether the location works for you is unsettled | `[grounded]` posting term | none unless you proceed |

### Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G3 | Advanced Excel (R3, must_have) | discovery | No Excel depth described | The only must-have that evidence could still move | Forecast or capacity models, pivot-heavy reconciliations, lookup-based planning sheets | A sanitized workbook | `[grounded]` background silent |

### Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR4 | Employer not established from attributable sources | risk_signal | medium | "Kroonhaven Foods, Utrecht" | Same default entry as RR1; the search was refused | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers page? | unresolved |
| RR5 | Salary withheld | unknown | — | (no figure in the posting) | The pay may not match the seniority implied by "own" and "run" | `[inferred]` from the posting's silence | What salary range is budgeted? | unresolved |

### Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A4 | Don't apply on this evidence; spend the time on roles like Role 1 | R1, R2, R4 | `[grounded]` map rows | pending your approval |
| A5 | If you apply anyway, don't describe the route-performance review as S&OP experience | R6 limit | `[grounded]` R6 row | pending your approval |

---

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches for "Duinvaart Cold Chain Rotterdam" and "Kroonhaven Foods Utrecht" were refused, so neither employer nor posting is verified. This produced RR1 and RR4 as default entries and caps Role 1 at `conditional_go` |
| 2. Role-family sweep | unavailable | A salary and scope search for operations analysts in the Netherlands was refused. It would have fed the market calibration lines |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Dossier offer

I can save this as `tuesday-dossier.md` so a later session picks it up. Say the word.

## Upgrade menu

- The posting URLs or the companies' careers pages → RR1 and RR4 close, and Role 1 can move to `go`.
- Your commute and location limits → R7 and R8 settle.
- A dashboard screenshot or sanitized export → R3 and R4a rise to `high`.
- A sanitized workbook → R3 in Role 2 moves, though it can't rescue that role.
- Permission to search the web → market calibration and the employer checks run (up to 5 searches and 2 fetches at this tier).

## Questions

G1 — Did your parcel work ever touch temperature-sensitive shipments, or any compliance or service-level reporting, and what did you own in it? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G2 — Is a three-day Rotterdam commute from where you live workable for you, and are there any location or schedule limits I should treat as fixed?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.