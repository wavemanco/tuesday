Web search was refused, so I've checked your offer only against what you pasted. Here's the assessment.

## Decision snapshot

**Yes, those three asks are normal once you hold a written offer that names the role and pay (RR1), so the job is worth accepting on the conditions below. Status: `conditional_go`.** Your rule is a good one before any offer, and for anyone who asks out of the blue. It doesn't apply here. The condition is that you check where the onboarding link comes from before you type anything into it.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Hybrid, two days in Limerick), R2 (Salary €38,000–€42,000)
- `must_have`: direct: R3, R5, R6 · unclear: R4 (Irish PAYE, PRSI and USC)
- `important`: direct: R7, R8 · adjacent: R10 (Payroll for 240 staff, monthly) · absent: R9 (Pension changes)

R9 — you've confirmed you haven't done these yourself, so it's a real gap to name; R10 (`medium`) — a bridge from 90 staff fortnightly, limit named; R4 — your background doesn't say which country's tax rules you ran.

**Opportunity ledger.** The data requests come after a written offer that names the role, pay and your manager, so they read as ordinary onboarding (RR1). The employer couldn't be checked against its own site from here (RR2), and the terms are specific and match between ad and offer (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Hybrid, two days a week in Limerick), R2 (Salary €38,000–€42,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the portal link verifies as coming from Marrowgate before you enter anything (RR1, RR2); (2) the two office days and €40,000 are inside your own limits (R1, R2); (3) you ask who covers pension changes and what training you get (R9, RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick | `[grounded]` ad and offer email; its existence is not confirmed from public sources (RR2) |
| Mandate | Run monthly payroll for 240 staff; starters, leavers and pension changes; monthly payroll-to-ledger reconciliation; staff payroll queries | `[grounded]` ad |
| Working pattern and reporting | Hybrid, two days a week in the Limerick office; reports to Declan Garvagh, Finance Manager | `[grounded]` ad and offer |
| Pay | Ad range €38,000–€42,000; offered €40,000 | `[grounded]` ad and offer |
| Market calibration | Not run: the role-family search was refused, so €40,000 is not set against a market band | `[grounded]` evidence status below |
| Unknowns | Contract terms beyond the email; the pension scheme and who handles changes today; whether the post sits alone or in a team; the portal's web address | `[grounded]` the offer is silent on each |
| Contradictions | None between the ad and the offer on title, pay or hybrid pattern | `[grounded]` the two texts compared |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in the Limerick office | hard_gate | unclear | none | hard_gate | You haven't said whether two Limerick days a week fits your life, so there is no statement of yours to grade. Ad and offer agree on the pattern | `[grounded]` ad, offer, and your silence | G1 question |
| R2 | Salary €38,000–€42,000 (offered €40,000) | hard_gate | unclear | none | hard_gate | No pay floor from you, so no statement to grade. The offer sits inside the ad's range | `[grounded]` ad, offer, and your silence | G1 question |
| R3 | 2+ years running payroll | must_have | direct | medium | none | Three years of fortnightly payroll for 90 staff at a hotel group, from your own account with nothing inspected. Expect a probe on scope | `[grounded]` your background | none |
| R4 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | Payroll runs and a Payroll Technician certificate are stated; the tax jurisdiction isn't. Irish rules are plausible from your PPS question, but that is a guess | `[grounded]` background silent on jurisdiction; `[inferred]` Ireland from the PPS question | G2 question |
| R5 | Strong Excel | must_have | direct | medium | none | Daily use, pivot tables and XLOOKUP, self-reported | `[grounded]` your background | none |
| R6 | Payroll qualification or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024. The certificate itself hasn't been inspected | `[grounded]` your background | A copy of the certificate would raise this to `high` |
| R7 | Process starters and leavers | important | direct | medium | none | Starters and leavers handled at the hotel group | `[grounded]` your background | none |
| R8 | Reconcile payroll to the general ledger monthly | important | direct | medium | none | Monthly payroll-to-ledger reconciliation at the hotel group | `[grounded]` your background | none |
| R9 | Process pension changes | important | absent | none | capability | You've told me you never did these; your manager did. Confirmed, so absent rather than unclear | `[grounded]` your own statement | G3 closure path |
| R10 | Run the monthly payroll for 240 staff | important | adjacent | medium | transferability | Credible bridge: 90 staff fortnightly plus a monthly reconciliation. Limit: you haven't run a monthly cycle or a headcount of 240 | `[grounded]` your background; `[inferred]` the bridge | Ask RR3's question about support in the first months |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Two Limerick days and €40,000 against your own limits (R1, R2) | hard_gate | Nothing from you on commute, pay floor or where you live | Gates are terms you meet or don't, and wording can't fix one | Not applicable: this is a yes or no on your side | Not applicable | `[grounded]` your silence on both |
| G2 | Irish tax rules in your past payroll work (R4, must_have) | discovery | A certificate and payroll runs, no stated jurisdiction | A must-have; if the rules were Irish, R4 moves to `direct` | Running PAYE, PRSI or USC deductions, year-end returns, or Revenue filings | A payslip layout or a Revenue return from your last role, with the personal data removed | `[grounded]` background silent; `[inferred]` that Irish rules are likely |
| G3 | Hands-on pension changes (R9, important) | capability | No direct or adjacent work stated | Named in the ad's list of duties, so expect it to come up in your first months | Not applicable: no question, since you've said you haven't done it | The scheme's rules and a handover from the current person | `[grounded]` your statement; `[generic]` that new payroll staff are usually trained on a scheme's rules |

Closure path for G3: ask who handles pension changes today and what handover you get (RR3), and read the scheme's rules before your start date.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Personal and ID details requested through a portal, after an offer | unknown | — | "we will send you a link to our onboarding portal, where you add your bank details for salary payments, your PPS number for Revenue, and a scan of your passport for our right-to-work check" | After a written offer that names role and pay, these are the usual payroll, Revenue and right-to-work steps. What is still unverified is where the link, once sent, comes from | `[generic]` pattern for onboarding after an offer; `[grounded]` the offer names role, pay and manager | What web address will the onboarding link come from, so I can check it before I enter anything? | unresolved |
| RR2 | Employer not established from public sources here | risk_signal | low | "Marrowgate Housing People Team" | The searches were refused, so nothing was checked. Severity is low because you attended two interviews at their office, which is evidence they exist | `[generic]` pattern: an unchecked employer stays unresolved until verified | Can you give me the page on your own site that lists this role, and a People Team number I can call to confirm this offer? | unresolved |
| RR3 | Specific, consistent terms | positive_signal | — | "reporting to Declan Garvagh, Finance Manager" and "€40,000 a year" | Title, pay, hybrid pattern and a named manager match the ad | `[grounded]` ad and offer compared | Who handles pension changes today, and what handover or training will I get? | noted |

Hold rule for RR1: don't enter bank, PPS or passport details until the link is confirmed to come from Marrowgate. I'm going only on what you've shared, and I can get this wrong, so the check and the call are yours.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Reach the portal only from a link in an email from the People Team address you've been using, or from an address the People Team confirms by phone, using a number from their own site | RR1, RR2 | `[grounded]` register | pending your approval |
| A2 | Put bank, PPS and passport details only into the portal, and send none of them by email | RR1 | `[generic]` common safeguard | pending your approval |
| A3 | Bring the original passport on your first day, as the offer asks, and hand nothing over before then | RR1 | `[grounded]` the offer's own wording | pending your approval |
| A4 | Ask RR3's question about pension-change support before or soon after you start | R9, R10 | `[grounded]` R9, R10 rows | pending your approval |

## Evidence status

Verified: none yet. None of your bank, PPS or passport details are needed here, so don't paste them.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Marrowgate Housing Limerick housing association careers payroll administrator"; the call was refused. It would have fed role reality's organization row and RR2 |
| 2. Role-family sweep | unavailable | Searched "payroll administrator Limerick salary Ireland housing association"; refused. It would have fed the market calibration line |
| 3. Hiring manager's public footprint | unavailable | Searched "Declan Garvagh Finance Manager Marrowgate Housing"; refused. It would have fed the scope read and positioning |

Optional extra, on your approval: a short reply accepting the offer and asking for the portal's web address, drafted for you to approve. It would put RR1's check in writing.

I can save this as a `tuesday-dossier.md` if you'd like to keep it.

## Upgrade menu

- Search permission, so targets 1–3 run: checks the role against Marrowgate's own pages, calibrates €40,000, and looks at the manager's public professional footprint.
- Your commute and pay floor: R1 and R2 resolve.
- Whether your past payroll ran under Irish tax rules: R4 can move to `direct`.
- The Payroll Technician certificate: R6 to `high`.
- The link itself when it arrives, with the sending address: RR1 and RR2 can close or escalate.

G1 — Are two office days a week in Limerick and €40,000 inside your limits, or is either one a problem? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G2 — Was your hotel-group payroll run under Irish PAYE, PRSI and USC, and who handled the year-end filings? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.