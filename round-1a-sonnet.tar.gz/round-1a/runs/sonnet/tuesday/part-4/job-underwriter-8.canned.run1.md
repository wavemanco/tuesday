I searched for the firm and found nothing. Everything below rests on your posting and the three messages you pasted.

## Decision snapshot

**No, don't go ahead, and send nothing yet. RR1, RR2 and RR3 (each `severity: high`) ask for payment, a cheque deposit and bank and ID details before any written offer. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Pay of at least €30,000 a year)
- `must_have` — direct: R2, R3, R4
- `important` — unclear: R5 (A quiet place to work)

R1 — the pay term the posting does not settle; R2 (`medium`) — your tracker work, no artifact yet.

**Opportunity ledger.** The requests in the messages (RR1, RR2, RR3), the chat-only process (RR4) and an employer I could not find (RR5) outweigh anything on the fit side. The pay terms are also vague (RR6).

- **Hard gates:** none failed; unconfirmed: R1 (Pay of at least €30,000 a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`), RR5 (`severity: high`).
- **What would change this:** all requests for money, a cheque deposit and pre-offer ID withdrawn. The employer would also need to confirm the role through contact details you find yourself on its own site, and put a written offer naming the role and pay in front of you.

I haven't used or repeated your IBAN. A bank account number isn't needed to assess a posting, and sending it would only hurt you.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics". Two searches returned no results, so the employer is not established | `[grounded]` searches returned nothing |
| Mandate | Remote order processing, spreadsheets, written English, 15–30 hours a week | `[grounded]` posting |
| Pay | "Up to €26 an hour plus commission". At the top rate, 15 hours a week is about €20,280 a year and 30 hours about €40,560. Reaching €30,000 would take about 23 hours every week at the top rate | `[grounded]` posting figures; `[inferred]` annual sums, 52 weeks |
| Process | Telegram only, no calls or video. Bank and ID details were requested first, then equipment money, then a cheque | `[grounded]` posting and your messages |
| Contradictions | The posting says "no experience needed, full training provided", but you were asked to buy equipment. You were told you "passed the interview" after chat questions only, with no written offer or contract | `[grounded]` posting and your messages |
| Unknowns | Who the employer is, the contract type, the guaranteed rate and hours, how commission works | `[grounded]` posting silent |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay of at least €30,000 a year (your hard constraint) | hard_gate | unclear | high | hard_gate | Confidence grades your own stated floor. Fit is `unclear` because "up to €26" with 15–30 hours does not settle it. Commission is unquantified | `[grounded]` your statement and posting | A written rate and minimum hours would be needed. Moot while RR1–RR3 stand |
| R2 | Strong attention to detail | must_have | direct | medium | none | About 60 Zendesk tickets a day is confirmed and specific, but nothing is inspectable | `[grounded]` your background | none |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep a weekly team tracker in Excel; no artifact seen | `[grounded]` your background | none |
| R4 | Good written English | must_have | direct | medium | none | Ticket-based written support is your daily work | `[grounded]` your background | none |
| R5 | A quiet place to work | important | unclear | low | discovery | Not stated by you | `[grounded]` silence | none, since the decision does not depend on it |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay vs your floor (R1, hard_gate) | hard_gate | Top rate and range only; commission undefined | A role that can't state pay can't be checked against €30,000 | Not a recall gap; the employer must state it | A written contract naming rate, minimum hours and commission | `[grounded]` posting wording |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Decision rule | Status |
|---|---|---|---|---|---|---|---|---|---|
| RR1 | Payment for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | A request to pay for the job or its kit is a sign that something is wrong | `[generic]` known pattern; no claim about who is behind it | Do you ask new hires to pay for equipment? Please confirm through your own website or phone line | Pay nothing while you check | confirmed |
| RR2 | Cheque to deposit and forward | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." | A cheque can show as credited before the bank finishes checking it. If it later fails, the bank takes the money back and you are out what you sent | `[generic]` known pattern | Will you confirm in writing, through contact details I find on your own site, that this cheque comes from you? | This request is very likely a scam. Don't deposit the cheque or transfer anything. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. | confirmed |
| RR3 | Bank, tax and ID details before an offer | red_flag | high | "send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up" | These details were requested before any written offer | `[generic]` known pattern | Will payroll collect these only after a written offer naming role and pay, via your own site? | Share nothing while you check | confirmed |
| RR4 | Hiring run only in chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." | The interview and the "job is yours" message both happened in chat | `[grounded]` posting and your messages | Can I speak to someone by phone or video, using a number from your own website? | Treat it as unverified until an independent check | confirmed |
| RR5 | Employer not established | risk_signal | high | "Velloway Logistics"; contact is a free-mail address | No result for the name; the contact is off any company domain beyond scheduling. It may be too new to have a footprint, or the posting may not represent a real hiring employer | `[generic]` pattern, not a claim about this firm | Where on your own careers site is this role listed, and who would I report to? | Verify before any effort | unresolved |
| RR6 | Pay vague | unknown | — | "Earn up to €26 an hour plus commission" | The top rate may be rare and commission may be unquantified | `[inferred]` from "up to" and no stated commission rule | What is the guaranteed hourly rate, minimum weekly hours and commission formula? | Ask in writing | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Don't send the IBAN, PPS number or passport photo | RR3 | `[grounded]` register | pending your approval |
| P2 | Don't pay the €349, and don't lodge the cheque or transfer any part of it | RR1, RR2 | `[grounded]` register | pending your approval |
| P3 | Check the firm yourself using a site or phone number you find independently, not the Telegram chat or the free-mail address | RR5 | `[grounded]` register | pending your approval |
| P4 | If you have already sent anything, tell your bank, and consider reporting it to the police and to the jobs site | Limits harm | `[generic]` standard step | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics careers Order Processing Coordinator" and "Velloway Logistics company Ireland". Both returned no results and no page was fetched, so the employer is not established. This moved RR5 |
| 2. Role-family sweep | skipped | RR1–RR4 already fix the decision. A market band would not change `no_go` |
| 3. Hiring manager's public footprint | n/a | Only a Telegram handle was given, no name |

I can save this as `tuesday-dossier.md` if you want a record.

**Upgrade menu**
- The jobs site and a link to the original posting would let me check it against the messages.
- Any company website or phone number you find independently would help RR5.
- Knowing whether you have given them anything beyond answers to the interview questions would show what to protect.
- A deeper research pass (up to 5 more searches and 2 more fetches) is available if you say the word.

**Questions**
- RR3 — Beyond answering interview questions in the chat, did you give them anything such as your address, date of birth, an ID photo or a PPS number?
- RR5 — Which jobs site was the posting on, and did it link to any company website?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.