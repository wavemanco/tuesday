I'm reading the skill's reference rules before I write the assessment, so the output follows its required format.
# Job Underwriting Assessment: Senior Pricing Analyst, Brindlemoor

## Decision snapshot

**Yes, apply, on one condition: the posting disagrees with itself about where the job is done (R1). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote (UK))
- `must_have`: direct: R2, R3, R4, R5a, R6, R7 · unclear: R5b (Monitor rating models)
- `preferred`: direct: R8

R5b is a silence in what you described, not a known gap. R1 is a conflict between the posting's own pages.

**Opportunity ledger.** The role looks real, is pointed at the work you do, and reports to a named Director of Pricing (RR5). Its working pattern conflicts between sources (RR1), salary is withheld (RR2), company size and stage are not established (RR3), and success measures and decision rights are unstated (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the working pattern is confirmed compatible with what you need (R1, RR1); (2) your monitoring work for the young-driver GLM can be evidenced (R5b, G1); (3) the salary clears your floor (RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech selling pet insurance. The role is live on its own careers page; size, stage and funding are not established | `[grounded]` JD and careers page, brindlemoor.co.uk/careers/senior-pricing-analyst |
| Mandate | Own pricing analytics for the pet-insurance product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reporting line | Reports to the Director of Pricing, Odile Varga | `[grounded]` careers page and JD |
| Working pattern | The JD says "Fully remote (UK)". The careers page says "Leeds office four days a week" | `[grounded]` both sources, which contradict each other |
| People management | The JD lists no line-management requirement | `[grounded]` JD silence |
| First-year outcomes | Not stated | `[grounded]` JD silence |
| Scope read | End-to-end ownership for one product, from model build through tests to recommendations | `[inferred]` from the JD's verbs |
| Hiring manager's public footprint | Previously head of pricing analytics at Calloway Re for six years. Spoke at the 2025 Insurance Pricing Forum on "Small Books, Loud Errors", about monitoring rating models in small books | `[grounded]` search result for "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga); snippet only, page not fetched |
| Market calibration | Pricewell 2026 survey, senior pricing analyst at UK insurers and insurtechs (n=612): median base £58,400, interquartile range £52,100 to £64,900. The posting withholds pay, so this is an expectation, not Brindlemoor's offer | `[generic]` one salary search, snippet only; `[grounded]` JD for the withheld figure |
| Unknowns | Salary; working pattern; size of the pet book and the team; decision rights; success measures | — |
| Contradictions | JD "Fully remote (UK)" against careers page "Leeds office four days a week" | `[grounded]` the two sources |

## Evidence map

Your claims below come from your own description. No CV or artifact was supplied, so none is above `medium`.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | low | hard_gate | Your location and whether remote is a requirement for you were not given. The posting's two pages disagree on the working pattern | `[grounded]` JD and careers page; your constraints not stated | RR1's question to the employer; G1 asks you whether the gate is met |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You describe 5 years of pricing analytics at a UK motor insurer, the last 2 as senior analyst. Stated, not yet inspectable | `[grounded]` your description | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily", stated without an artifact | `[grounded]` your description | a sanitized query or notebook would raise it |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for your young-driver book | `[grounded]` your description | none |
| R5a | Build rating models | must_have | direct | medium | none | Same evidence as R4: you built the GLM rating model | `[grounded]` your description | none |
| R5b | Monitor rating models | must_have | unclear | low | discovery | You said "maintained". That does not say what monitoring you did (actual against expected, drift, refresh triggers). Resolved downward until you say more | `[grounded]` your description is silent on monitoring | G1 |
| R6 | Design and read price tests | must_have | direct | medium | none | You ran 14 price tests last year with the underwriting team. Who designed them is not stated, so expect a probe on design | `[grounded]` your description | a sanitized test write-up would raise it |
| R7 | Present to underwriting or actuarial leads; turn results into recommendations | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your description | none |
| R8 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer meets "insurance experience". The posting does not ask for pet experience, and you have none | `[grounded]` JD and your description | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Monitor rating models (R5b, must_have) | discovery | "Maintained" the young-driver GLM; no description of monitoring | A must-have the hiring manager has published on, so expect a probe. Resolving it could move R5b to `direct` | An actual-against-expected tracker; drift or segment-lift checks; criteria for when to refit or recalibrate; alerts or a regular model-health review | A sanitized monitoring dashboard, a model-health pack or a review note | `[grounded]` your description is silent; `[grounded]` the manager's published talk topic (snippet) |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern contradicts itself | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | One source may be stale, or the role may have changed. Rated medium, not higher, because the cause is unknown | `[inferred]` from the two pages disagreeing | Is this role fully remote, or based in the Leeds office four days a week? | unresolved |
| RR2 | Salary withheld | unknown | — | No figure in the JD | May sit above, within or below the Pricewell band, or the company may simply not publish | `[inferred]` from the withheld figure against the `[generic]` band | What is the salary range for this post? | unresolved |
| RR3 | Company size and stage not established | unknown | — | "insurtech", and nothing further | My first search on the company name returned nothing. The careers page exists, so the posting is live, but the company's scale is unknown | `[grounded]` my searches; `[generic]` that new insurtechs often have thin footprints | How large is the pricing team, and how big is the pet book? | unresolved |
| RR4 | Success measures and decision rights unstated | unknown | — | "Own pricing analytics" | Ownership may stop at recommendations, with rate changes decided elsewhere | `[inferred]` from the JD's verbs against its silence | Which pricing decisions does this role make, and what would success look like in the first year? | unresolved |
| RR5 | Named reporting line to a pricing leader | positive_signal | — | "reports to the Director of Pricing" | A named senior owner suggests the role has a real sponsor | `[grounded]` careers page and the profile snippet | Who else will I work with day to day? | noted |

## Application plan

All rows are proposals. The first block is `resume_edits_pending_approval`: the lines are in your own words, reordered to the top, with nothing added.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with: "Built and maintained the GLM rating model for the young-driver book" | R4, R5a | `[grounded]` your sentence | pending your approval |
| E2 | Then: "Ran 14 price tests with the underwriting team last year" | R6 | `[grounded]` your sentence | pending your approval |
| E3 | Then: "Present the quarterly pricing review to the head of underwriting" | R7 | `[grounded]` your sentence | pending your approval |
| E4 | Keep "5 years pricing analytics at a UK motor insurer, the last 2 as senior analyst" as the opening line | R2, R8 | `[grounded]` your sentence | pending your approval |
| A1 | Confirm the working pattern before investing in the loop | R1, RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Say plainly that you have not worked on pet insurance. The cycle you've run (GLM, tests, presenting to underwriting) is the adjacent evidence, and it did not exercise pet-specific pricing | R8 | `[grounded]` your statement; `[inferred]` adjacency | pending your approval |
| A3 | Don't claim monitoring depth until G1 is answered, and don't claim experience with small books | R5b | `[grounded]` R5b row | pending your approval |
| A4 | Never managing anyone is not a gap against this JD, which lists no management requirement. If it comes up, state it as it is | Role reality | `[grounded]` JD silence | pending your approval |

## Evidence status

Verified: none yet. Stage: assumed evaluating, since none was stated.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech" (no results, company not established beyond the posting) and "Brindlemoor careers Senior Pricing Analyst"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). The posting is live and matches the JD on role and reporting line. It contradicts the JD on working pattern, which moved R1 and RR1 |
| 2. Role-family sweep | yes | Searched "Senior Pricing Analyst pet insurance UK remote salary", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). It supplied the market calibration band and the RR2 comparison |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga). It supplied the scope read and the G1 and A3 positioning |

## Dossier offer

I can write all of this up as `tuesday-dossier.md` if you want it to keep or reuse; it's your call.

## Upgrade menu

- Your CV, or a sanitized monitoring dashboard or model-health note → R5b could reach `direct`, and E1 to E4 could be checked against your actual wording.
- A sanitized price-test write-up or a query or notebook → R6 and R3 could rise to `high`.
- The recruiter's answer on working pattern → R1 and RR1 close.
- Your salary floor → RR2 can be set against the survey band.
- A deeper research pass on Brindlemoor (funding, leadership churn, public employee reports, recent news; up to 5 more searches and 2 more fetches) → RR3 could close. Say the word and it runs.

## Questions

1. **R1 / RR1:** Is fully remote a requirement for you, or could you work four days a week in the Leeds office?
2. **G1 (R5b):** For the young-driver GLM, what did you personally track after it went live (actual against expected, drift, segment performance), and what made you refit or recalibrate it?
3. **RR2:** Do you have a minimum salary below which you wouldn't proceed?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.