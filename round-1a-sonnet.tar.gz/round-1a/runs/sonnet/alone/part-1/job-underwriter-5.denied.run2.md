Reading the skill's rules is done. Now I'm checking that Pellucid's careers page and company details are real and current, before I write the assessment.
## Decision snapshot

**Yes, this is worth applying to, on conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver), R2 (Salary $148,000–$166,000 plus equity)
- `must_have`: direct: R3, R4, R5, R6, R7, R8
- `important`: adjacent: R9 (BigQuery); unclear: R10 (Ingestion from app and CRM), R11 (Data contracts for analysts)

R9 (`medium`) is a credible bridge with its limit named; R10 and R11 — the CV is silent, which isn't evidence of absence.

**Opportunity ledger.** Reasonable on its face: the salary is disclosed and brackets the market median (RR2). Open items are that I couldn't confirm the posting is live (RR1), the scope may be broader than the usual senior remit (RR3), and no manager (RR4) or equity terms (RR5) are given.

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:**
  1. R1 and R2 are checked against your own constraints.
  2. The posting is confirmed live on Pellucid's own careers page (RR1).
  3. BigQuery is framed as adjacent, never as experience you have (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026). I couldn't check it against the live site | `[grounded]` company text you pasted |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Requirements | 5+ years data engineering; SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Terms | $148,000–$166,000 plus equity; Remote (US) or Denver office | `[grounded]` JD |
| First-year outcomes | Not stated in the JD | `[grounded]` JD silence |
| Scope read | Ingestion, modelling and contracts together read as end-to-end ownership of the reporting stack. No reports are mentioned either way | `[inferred]` from the JD's mandate against the survey's scope norm below |
| Market calibration | Series B–D Senior Data Engineer base: median $151,000, interquartile range $139,000–$163,500, 'Senior' typically 5–8 years, typically one domain's pipelines and no direct reports. The posting's range runs from $3,000 below that median to $2,500 above its 75th percentile. Your 6 years sit inside the 5–8 band. The survey is a pattern, not this employer's offer, and it was supplied by your recruiter and not checked | `[generic]` Datawright 2026 report (n=2,310), as you supplied it; `[grounded]` JD for the posting's figures |
| Unknowns | Hiring manager and team size; whether the pay figure is base salary; equity terms; whether Denver and remote pay differ | `[grounded]` JD and posting silent |
| Contradictions | None between the JD and the company text as pasted; neither was checked against the live site | `[grounded]` the two pasted texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location, work authorization and any location constraint weren't given, so I can't test the gate | `[grounded]` JD term; nothing from you yet | Q1 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | The figure is stated, but your pay floor wasn't given | `[grounded]` JD figure; nothing from you yet | Q1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | 6 years at a payroll company as you describe it; no document checked | `[grounded]` your message | Put dates on the CV |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use, stated; no artifact | `[grounded]` your message | none |
| R5 | dbt | must_have | direct | medium | none | You built the project, about 180 models. A sanitized lineage screenshot would raise this to `high` | `[grounded]` your message | Offer in upgrade menu |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse; the JD says "a cloud warehouse" in its requirements | `[grounded]` your message and JD | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow named as your orchestrator | `[grounded]` your message | none |
| R8 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite | `[grounded]` your message | Offer in upgrade menu |
| R9 | BigQuery (the JD's warehouse) | important | adjacent | medium | transferability | Same class of warehouse as Snowflake. Limit: you have not used BigQuery at all, so its cost and partitioning model are unexercised | `[inferred]` adjacency from Snowflake; `[grounded]` your statement | G3 |
| R10 | Ingestion from the app and CRM | important | unclear | low | discovery | You didn't say what sources your Airflow pipelines ingested from | `[grounded]` your message silent on sources | G1 and Q2 |
| R11 | Data contracts that analysts depend on | important | unclear | low | discovery | Great Expectations and a dbt project may have served analysts under agreed expectations; you didn't say | `[grounded]` your message silent | G2 and Q3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Ingestion from app and CRM (R10, important) | discovery | Airflow and dbt are stated; the source systems feeding them aren't | Ingestion is the first thing the JD's mandate names | Loading from application databases or from SaaS or CRM-style APIs into your warehouse, including any Airflow ingestion DAGs | A sanitized DAG list or source inventory | `[inferred]` silence is a gap in the CV, not proof of absence |
| G2 | Data contracts (R11, important) | discovery | Great Expectations and dbt exist, but no stated agreement with analysts | The JD names contracts as something analysts depend on | Agreed schemas or test expectations on tables others consume; dbt tests tied to downstream analysts | Sanitized test config or a schema-change note | `[inferred]` from the tests you described; `[generic]` that tests on shared tables often serve as informal contracts |
| G3 | BigQuery (R9, important) | transferability | Snowflake only | It is the warehouse the JD names | Snowflake cost and performance tuning, clustering or partitioning work | A small BigQuery project built on public data. Until you do it, it is not experience you can claim | `[inferred]` bridge from Snowflake; limit named |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting and employer not independently confirmed | risk_signal | low | "Founded 2016, Denver. 264 employees. Series C ($52M, February 2026)." | The posting could be stale, or the funding claim might not hold up. Rated low because the pasted JD and company text agree with each other | `[grounded]` the two pasted texts agree; `[generic]` pasted copies can go stale | Is this role still open, and when was the posting published? | unresolved |
| RR2 | Range disclosed and near market median | positive_signal | — | "Salary $148,000–$166,000 plus equity" | Transparent pay at a level the survey says is normal for the title | `[grounded]` JD figure; `[generic]` survey band | Is the range base salary, and does it differ between Denver and remote? | noted |
| RR3 | Scope may exceed the usual single-domain remit | risk_signal | low | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts our analysts depend on" | The role may be the whole data-engineering stack for a small team. Rated low because the JD may just describe the team's remit | `[inferred]` JD against `[generic]` survey scope norm | How many data engineers are on the team, and which of ingestion, modelling and contracts does this role own alone? | unresolved |
| RR4 | No hiring manager named | unknown | — | "The posting names no hiring manager" (your note) | The reporting line and team shape are unknown | `[grounded]` your note on the posting | Who would I report to, and who is on the data team today? | unresolved |
| RR5 | Equity unquantified | unknown | — | "plus equity" | The size, vesting and valuation basis are missing, so the equity can't be priced | `[grounded]` JD silence | What is the grant size, the vesting schedule, and the valuation basis? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Settle R1 and R2 against your own constraints before investing time | They are the unconfirmed gates | `[grounded]` R1, R2 | pending your approval |
| A2 | Confirm the posting on Pellucid's own careers page and note its date | see RR1 | `[grounded]` RR1 | pending your approval |
| E1 | CV: state the dbt project as "about 180 models on Snowflake" and the Great Expectations suite as one you set up, in your own words and no stronger | see R5, R8 | `[grounded]` your message | pending your approval |
| E2 | CV and cover note: describe BigQuery as new to you, built on Snowflake and dbt, with no BigQuery claim | see R9 | `[inferred]` bridge, limit named | pending your approval |
| Q4 | Ask RR3, RR4 and RR5's questions verbatim on a first call | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Fetched pellucidlearning.com/careers/senior-data-engineer and searched "Pellucid Learning Series C $52M tutoring Denver"; the host refused both, so nothing came back. It would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | skipped | Your pasted Datawright figures are in hand and already fix the market calibration line and the pay-mismatch check |
| 3. Hiring manager's public footprint | n/a | The posting names no manager, so there was no query to form |

## Dossier offer

If you'd like, I can save this as `tuesday-dossier.md` to build on in later turns.

## Upgrade menu

- Your location, work authorization and pay floor → R1 and R2 resolve, and the decision likely moves to `go` or `no_go`.
- A sanitized dbt lineage view or Great Expectations config → R5 and R8 rise to `high`.
- What your pipelines ingested from, and whether analysts relied on your tests → R10 and R11 resolve.
- A small BigQuery project on public data → R9's bridge narrows, once it exists.
- The hiring manager's name → the scope read and which story the plan leads with for that reader.
- The link to the posting on Pellucid's own careers page, or search permission for this session → RR1 can close.
- A deeper research pass on Pellucid (funding and leadership churn, public candidate and employee reports, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs; the host refused my first calls, so it would need search permission.

## Questions

1. **R1, R2:** Where are you based and authorized to work, and is there a pay floor or an unacceptable location?
2. **G1, R10:** What did your Airflow pipelines ingest from, such as app databases, SaaS or CRM APIs, or files?
3. **G2, R11:** Did analysts or other teams rely on your dbt models and Great Expectations checks under any agreed schema or test expectations?

Answer in text, paste a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.