I'm reading the skill's remaining rules, on output format and research tiers. Then I'll write the full assessment.
**Yes, apply, once R10 and RR1 clear · `conditional_go`**

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R10 (Fully remote, UK-based)
- `must_have`: direct: R1, R2, R3, R4a, R6 · adjacent: R5 (Design and read price tests) · unclear: R4b (Monitor rating models)
- `important`: unclear: R7 (Recommendations to product)
- `preferred`: direct: R8 · adjacent: R9 (Pet-insurance product knowledge)

R5: running 14 tests is the same activity, but design versus run is unstated; R4b: "maintained" is not stated as "monitored"; R9: a credible bridge from motor, its limit named.

**Opportunity ledger.** The duties are concrete (RR4). Four things are open:
- Whether the employer and posting are real (RR1).
- The salary is withheld (RR2).
- Whether the role has reports or sits alone (RR3). Never having managed anyone is not a gap against this JD, because it asks for no management experience.

- **Hard gates:** none failed; unconfirmed: R10 (Fully remote, UK-based); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm you meet R10; (2) Brindlemoor and the live posting verify, per RR1; (3) you can truthfully say what you owned in the price tests, per R5.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech; the post owns pricing analytics for its pet-insurance product | `[grounded]` JD header and text |
| Reporting line | Hiring manager is Odile Varga, Director of Pricing | `[grounded]` JD |
| Mandate | Build and monitor rating models; design and read price tests; turn results into recommendations for underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| First-year outcomes | Not stated | `[grounded]` JD silence |
| Scope read | One product's pricing analytics under a Director, titled senior; whether it is a solo seat or leads others is not stated | `[inferred]` from "Own pricing analytics" against the JD's silence on team |
| Market calibration | Not established: the role-family sweep did not run (Evidence status, row 2), so no band is offered | `[grounded]` Evidence status |
| Unknowns | Salary; team and reports; first-year outcomes; the data and test tooling | `[grounded]` JD silence |
| Contradictions | None found in what you provided. The live posting could not be checked against it | `[grounded]` provided JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You state 5 years in pricing analytics at a UK motor insurer, the last 2 as senior analyst. Confirmed by you, no inspectable artifact yet | `[grounded]` your statement | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily." The claim is clear but gives no detail on what you build with them, so expect a probe | `[grounded]` your statement | none |
| R3 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book | `[grounded]` your statement | a sanitized factor summary would raise to high |
| R4a | Build rating models | must_have | direct | medium | none | Same evidence as R3: built the young-driver model | `[grounded]` your statement | none |
| R4b | Monitor rating models | must_have | unclear | low | discovery | You said "maintained"; monitoring is not stated, and I won't assume it | `[grounded]` your wording; `[inferred]` that monitoring may exist | see G2 |
| R5 | Design and read price tests | must_have | adjacent | medium | discovery | You ran 14 price tests with the underwriting team. That is the same activity, but whether you designed them or read the results is not stated | `[grounded]` your statement | see G1 |
| R6 | Present to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your statement | a slide excerpt would raise to high |
| R7 | Recommendations for product (the JD says "underwriting and product") | important | unclear | low | discovery | Your evidence names underwriting only; nothing about product teams | `[grounded]` your statement's silence | see G3 |
| R8 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your statement | none |
| R9 | Pet-insurance product knowledge (implied by the role, not required by the JD) | preferred | adjacent | medium | transferability | Carries over: GLM rating and price testing on an insurance book. Limit: you have no pet work, and pet-specific rating factors such as breed or age are not in your history | `[grounded]` your statement; `[generic]` that pet pricing uses its own rating factors | see G4 |
| R10 | Fully remote, UK-based | hard_gate | unclear | low | hard_gate | You worked at a UK insurer, so UK-based is plausible. Residency, right to work and remote-only fit are not stated | `[inferred]` from your UK employer | one question, below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Design of price tests (R5, must_have) | discovery | 14 tests run; your role in designing them is unstated | The JD names design explicitly, and an interviewer will probe the line between running and designing | Choosing what to test; deciding how traffic was split or sized; agreeing success measures with underwriting; reading a result and recommending a rollout | A sanitized test readout or design note | `[grounded]` your statement; `[generic]` that this role family probes design versus execution |
| G2 | Model monitoring (R4b, must_have) | discovery | "Maintained" does not establish tracking against actuals | The JD pairs monitoring with building | Periodic actual-versus-expected checks; refresh triggers; dashboards others used | A monitoring pack excerpt or refresh log | `[grounded]` your wording |
| G3 | Recommendations to product (R7, important) | discovery | Only underwriting is evidenced | The JD names product as a second audience | Findings you took to a product or proposition team; pricing input to a product change | A deck excerpt or email summary | `[grounded]` your statement's silence |
| G4 | Pet-insurance knowledge (R9, preferred) | transferability | Motor GLM work, no pet exposure | Preferred only, but it is the likeliest interview objection | Any animal, health or other claims-cost-driven rating work; reading about pet rating factors | A short note on how you'd adapt your young-driver factor work | `[inferred]` bridge from your motor GLM work; `[generic]` that this is the likeliest objection |
| G5 | UK-based and remote fit (R10, hard_gate) | hard_gate | Location, right to work and constraints not stated | A hard gate that is unconfirmed | Not applicable | Your own statement | `[grounded]` JD terms; your constraints not given |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established | risk_signal | low | "Brindlemoor (insurtech)" | The check did not run, so the employer and the live posting are unverified; severity is low for that reason. It may be a small or new firm, or a stale posting | `[generic]` pattern for firms of this size, not a claim about this one | Can you point me to this role on Brindlemoor's own careers site, and who I'd be interviewing with? | unresolved |
| RR2 | Salary withheld | unknown | — | No salary stated in the JD provided | The pay may sit below what you accept, or the firm may not publish pay | `[inferred]` from the JD's silence | What salary range is budgeted for this post? | unresolved |
| RR3 | Team and reports unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | The seat may be solo, or may carry people to lead | `[inferred]` from "Own" against the JD's silence on team | Does this role have direct reports, and who else works on pet pricing? | unresolved |
| RR4 | Duties are concrete | positive_signal | — | "build and monitor rating models, design and read price tests, and turn the results into recommendations for underwriting and product" | The scope is defined, with a named Director as hiring manager | `[grounded]` JD | What would success look like in the first year? | noted |

## Application plan

Proposed language, `resume_edits_pending_approval`. Each line traces to a sentence you wrote and adds nothing new.

| # | Proposed line | Traces to your sentence | Status |
|---|---|---|---|
| E1 | Five years in pricing analytics at a UK motor insurer, the last two as senior analyst. | "5 years pricing analytics at a UK motor insurer, the last 2 as senior analyst" | pending your approval |
| E2 | Built and maintained the GLM rating model for the young-driver book. | "Built and maintained the GLM rating model for our young-driver book" | pending your approval |
| E3 | Ran 14 price tests with the underwriting team last year. Use the calendar year on the CV. | "Ran 14 price tests last year with the underwriting team" | pending your approval |
| E4 | Present the quarterly pricing review to the head of underwriting. | "I present the quarterly pricing review to the head of underwriting" | pending your approval |
| E5 | Use SQL and Python daily. | "SQL and Python daily" | pending your approval |
| I1 | Interview framing: "I haven't worked on pet insurance; what I bring is GLM rating-model work and price testing in motor." | "Never worked on pet insurance"; your GLM and price-test statements | pending your approval |

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Verify Brindlemoor and the live posting before investing effort | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask RR2, RR3 and RR4's questions with the recruiter or Odile Varga | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A3 | Don't claim any people-management; if asked, say you haven't managed anyone | The JD asks for none | `[grounded]` your statement and the JD | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Brindlemoor pet insurance insurtech careers"; the call was refused. It would have confirmed the employer exists and the posting is live, feeding RR1 and the contradictions row |
| 2. Role-family sweep | unavailable | Searched "senior pricing analyst insurance UK salary remote GLM"; the call was refused. It would have given the market calibration line and a pay band against RR2 |
| 3. Hiring manager's public footprint | unavailable | Searched "Odile Varga Director of Pricing Brindlemoor"; the call was refused. It would have informed the scope read and which story to lead with |

## Upgrade menu

I can also write this up as `tuesday-dossier.md` if you want to keep it.

- Search permission granted → targets 1–3 run: RR1 closes or escalates, a pay band lands against RR2, and Odile Varga's published footprint shapes the plan. After that, a deeper pass (up to 5 more searches and 2 more fetches) is available on a yes.
- A sanitized GLM factor summary, a price-test readout, or a quarterly-review slide → R3, R5 and R6 can reach `high`.
- Your CV, if it differs from what you told me → I re-check R1–R8 against it.
- The live posting link → RR1's posting-is-live check.
- Your pay floor and any other non-negotiables → R10 and RR2 get checked against them.

**Questions**

R10: Are you UK-based with the right to work in the UK, and is there a pay floor or any other term that would rule this role out?

R5 (G1): For the 14 price tests, which parts did you personally own: choosing what to test, how it was split, running the analysis, or reading results with underwriting?

R4b (G2): After the young-driver GLM went live, what monitoring did you personally do on it, if any, and how often?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.