I've read the posting and the skill's rules. Next I'm running the budgeted research on Quillfield, the role's market band and the hiring manager's public profile, then I'll write up the assessment.
## Decision snapshot

**Yes, apply. R6 (owning a forecast) and R7b (billing data) are real gaps, but neither is a hard gate. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Bristol hybrid, two office days), R2 (pay £61,500–£67,000 against your floor)
- `must_have` — direct: R3, R4, R5a, R8 · adjacent: R6 (Owning a forecast) · unclear: R5b (Spreadsheet modelling), R7a (Finance on revenue data) · absent: R7b (Billing data)

R6 (`medium`) is a credible bridge through your monthly pipeline review, with its limit named. R7b is a capability gap and is carried as a material risk. R1 and R2 are unconfirmed because I don't have your constraints.

**Opportunity ledger.** The role is sound on the posting's face. The employer exists as described (RR1) and the pay sits inside a published band (RR4). Open items: who owns the forecast number (RR2), a bundle of duties under one title (RR3), the option terms (RR5), no stated outcomes (RR6), and the posting not yet seen on Quillfield's own site (RR7).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days), R2 (pay £61,500–£67,000 against your floor); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. The Bristol hybrid terms and the pay range both work for you (R1, R2).
  2. Your pipeline-review work holds up as a forecast bridge, which depends on your answer to G1 (R6, RR2).
  3. You name the billing gap plainly and never present it as experience (R7b).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants, founded 2018 in Bristol, 96 employees, £11M Series A closed April 2025 | `[grounded]` Quillfield "About" page |
| Mandate | Own CRM and billing data; build the pipeline and renewal reporting that sales and finance run on; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern and pay | Bristol, hybrid, two office days a week; £61,500–£67,000 plus share options | `[grounded]` posting |
| Hiring manager | Tamsin Achebe is Head of Revenue Operations at Quillfield. Earlier she was a sales operations manager at Corvane Payments for four years. No talks or writing turned up | `[grounded]` her profile page; that she is the hiring manager is the recruiter's statement to you, not in the posting |
| Scope read | The posting says nothing on reports or team size. With a Head of RevOps in place, this role likely sits beneath or beside hers, so the forecast split with her and the CFO is unclear | `[inferred]` from her title against the posting's silence |
| Market calibration | A UK B2B software revenue operations lead has a median base of £64,200 (interquartile range £57,800–£70,400). The posted range is inside it, near the median. The band is national, not Bristol-specific, and it describes the market, not this employer's offer | `[generic]` Ledgerline 2026 pay guide, from a search snippet; `[grounded]` posting for the figure |
| Unknowns | Reporting line; forecast ownership; option size and vesting; first-year outcomes; support staff | — |
| Contradictions | None between the posting and the About page. The posting itself was not found on Quillfield's own site (see RR7) | `[grounded]` About page; no page at the careers address tried |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two office days a week | hard_gate | unclear | none | hard_gate | The posting states the term; your location and constraints weren't given | `[grounded]` posting; your constraints unknown | gate question below |
| R2 | Pay £61,500–£67,000 plus options | hard_gate | unclear | none | hard_gate | The figure is stated; your floor wasn't given | `[grounded]` posting; floor unknown | gate question below |
| R3 | 4+ years in RevOps, sales ops or similar analytics at a B2B software company | must_have | direct | medium | none | Five years in sales ops, the last two running RevOps, so the years are met. Your employer was a B2B payments company, not strictly "software", which is a risk and not a gate | `[grounded]` your account, no document | none |
| R4 | Salesforce or HubSpot administration | must_have | direct | medium | none | Salesforce admin certified. The certification is inspectable, so it could reach `high` | `[grounded]` your account | share the credential link |
| R5a | Strong SQL | must_have | direct | medium | none | You use it weekly. That shows use, not level, so "strong" rests on your word | `[grounded]` your account | a sanitized query or dashboard |
| R5b | Spreadsheet modelling | must_have | unclear | low | discovery | You use Excel daily, but daily use doesn't show modelling (forecast, scenario or revenue models) | `[grounded]` your account; `[inferred]` that use isn't modelling | see G4 |
| R6 | Experience owning a forecast | must_have | adjacent | medium | transferability | You run the monthly pipeline review with your sales director. Limit: finance owned the forecast, so you haven't owned the number or worked it with a CFO | `[grounded]` your account; `[inferred]` adjacency | see G1 |
| R7a | Working with finance on revenue data | must_have | unclear | low | discovery | Your renewal dashboards touch revenue, but whether finance used or reconciled them isn't stated | `[grounded]` your account; `[inferred]` | see G2 |
| R7b | Working with finance on billing data | must_have | absent | none | capability | You said you've never worked on billing data. No adjacent evidence has surfaced | `[grounded]` your statement | see G3 |
| R8 | Own CRM data; build pipeline and renewal reporting for sales and finance | must_have | direct | medium | none | You rebuilt your pipeline and renewal dashboards and hold the admin certification. Who used them isn't stated | `[grounded]` your account | a sanitized screenshot would raise it |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning a forecast (R6, must_have) | transferability | You run the pipeline review but finance owned the company forecast | The posting's headline duty is running the forecast with the CFO. A stronger bridge narrows the likeliest objection | Giving a commit or best-case number that finance used; a forecast-accuracy review; building the pipeline-to-forecast roll-up finance consumed | Sanitized review deck, forecast-vs-actual sheet | `[grounded]` your account; `[inferred]` that this is the likeliest objection |
| G2 | Finance on revenue data (R7a, must_have) | discovery | Renewal dashboards exist, but finance's involvement is unknown | A discovery gap may be closed by work you already did | Reconciling renewal values to finance's figures; agreeing ARR or bookings definitions with finance; supplying data to month-end | A definitions doc, a reconciliation sheet | `[grounded]` your account; `[inferred]` |
| G3 | Billing data (R7b, must_have) | capability | No direct or adjacent evidence; you've never worked on it | The role owns billing data. This is a real gap, so it's carried as a material risk | Closure path: learn how invoices, credit notes and renewals reach the CRM; do a small billing-to-CRM reconciliation project; be upfront at interview that you'd be learning it. No question is asked unless you think this classification is wrong | A reconciliation exercise you could show | `[grounded]` your statement; `[generic]` that this is a common onboarding gap |
| G4 | Spreadsheet modelling (R5b, must_have) | discovery | Daily Excel use, no modelling named | "Modelling" is in the requirement | A renewal or pipeline-coverage model; a scenario sheet for quota or headcount | A sanitized model | `[grounded]` your account; `[inferred]` |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer exists as described | positive_signal | — | "Founded 2018 in Bristol; 96 employees. Series A (£11M)" | Quillfield is an established, funded business | `[grounded]` About page | Who would I be working with day to day? | noted |
| RR2 | Forecast ownership split | unknown | — | "run the quarterly revenue forecast with the CFO" | With a Head of RevOps in post, the forecast may be shared across three people or may sit mainly with one | `[inferred]` from Tamsin's title against the posting's silence | Who owns the forecast number: this role, the Head of Revenue Operations or the CFO? Who signs it off? | unresolved |
| RR3 | Several jobs under one title | risk_signal | low | "own our CRM and billing data, build the pipeline and renewal reporting… and run the quarterly revenue forecast" | CRM admin, billing data, reporting and forecasting may be more than one person covers. I put this at low because the posting doesn't say the role is unsupported | `[inferred]` from the duty list; `[generic]` that growing companies often fold these together | What analyst, admin or finance support does this role have? | unresolved |
| RR4 | Pay stated and inside the band | positive_signal | — | "£61,500–£67,000 plus share options" | The range is transparent and near the market median | `[grounded]` posting; `[generic]` Ledgerline band | Where in the range would this role be placed? | noted |
| RR5 | Option terms absent | unknown | — | "plus share options" | The grant size, vesting and strike aren't stated | `[grounded]` posting silence | What is the option grant, vesting schedule and strike price? | unresolved |
| RR6 | No stated outcomes | unknown | — | (the posting lists duties, no outcomes) | The first-year measures of success may not be defined | `[grounded]` posting silence | What would success look like at 90 days and at 12 months? | unresolved |
| RR7 | Posting not seen on Quillfield's own site | unknown | — | "Tallyboard Jobs … Quillfield" | It may be hosted via a job board, or the careers page may live elsewhere. I tried one address and found nothing, which proves little | `[inferred]` from one failed address | Can you point me to this role on Quillfield's own careers site? | unresolved |

## Application plan

Nothing below is final until you approve it. That covers the advice as well as the table.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with the rebuilt pipeline and renewal dashboards and the Salesforce admin certification | R4, R8 | `[grounded]` your account | pending your approval |
| E2 | State the pipeline review for what it is ("runs the monthly pipeline review with the sales director"). Don't say you owned the forecast | R6; keeps the claim honest | `[grounded]` your account | pending your approval |
| E3 | Say plainly in the cover note or interview that billing data is new to you. Add a bridge line only if G2 turns up something real | R7b | `[grounded]` your statement | pending your approval |
| A1 | Ask the recruiter about the gate terms and who owns the forecast (RR2) before investing in the loop | R1, R2, RR2 | `[grounded]` register | pending your approval |
| A2 | Open with your pipeline and renewal work for Tamsin. Her public footprint is thin (a title and a payments-company history), so I'd read nothing into her preferences | Her path is the same kind as yours | `[inferred]` from her profile | pending your approval |
| Q1 | Ask RR2, RR3, RR5, RR6 and RR7 verbatim in the process | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 2 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software careers" and fetched "Quillfield careers" (quillfield.co.uk/careers), which had no page. The "About Quillfield" page (quillfield.co.uk/about) came up. Role reality: organization; RR1, RR7 |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary Bristol UK B2B software", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide), read as a snippet only. Market calibration; RR4 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield" and fetched "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Role reality: hiring manager and scope read; A2 and RR2 |

Seeing everything laid out, I can build `tuesday-dossier.md` from this if you'd like it.

## Upgrade menu

- A credential link for your Salesforce admin certification raises R4 to `high`.
- A sanitized pipeline-review deck or forecast-vs-actual sheet firms up R6 and G1.
- A sanitized dashboard screenshot or SQL sample raises R5a and R8.
- Your location, and your salary floor, close R1 and R2.
- The recruiter's answers on forecast ownership, support, options and outcomes close RR2, RR3, RR5 and RR6.
- The role on Quillfield's own careers site closes RR7.
- Any talks or writing by Tamsin Achebe would sharpen A2, though none turned up.
- A deeper pass on Quillfield (funding, leadership changes, hiring patterns, recent news; up to 5 more searches and 2 more fetches) runs if you say the word.

**Questions**

1. G1 — Has your monthly pipeline review involved giving a commit or forecast number that finance or leadership used? What did you own, and how did it compare with the actuals?
2. G2 — Have you worked with finance on revenue figures, for example reconciling renewal values or agreeing ARR or bookings definitions? What did you own?
3. R1, R2 — Do the Bristol hybrid terms (two office days) and the £61,500–£67,000 range both work for you?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.