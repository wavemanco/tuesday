I'll read the reference files the skill points to before building the assessment.
**Yes, apply, on two conditions. Status: `conditional_go`.** You meet R2, R3, R4, R5a, R6a and R7 directly. The conditions are that Brindlemoor and the live posting are verified (RR1) and that your UK base is confirmed (R1). I couldn't check either from here. Your two worries are covered below: pet insurance is new to you (R8, RR3), and the JD asks for no line management, so your lack of it costs nothing against the map.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote — UK)
- `must_have` — direct: R2, R3, R4, R5a, R6a, R7 · unclear: R5b (Design price tests)
- `important` — adjacent: R8 (Own pricing analytics for the product) · unclear: R6b (Recommendations for product)
- `preferred` — direct: R9

R8 — a segment model versus a whole product, its limit named; R5b — design ownership not stated; R6b — product-side work not evidenced; R1 — UK base unconfirmed.

**Opportunity ledger.** The remit is concretely stated (RR4). The employer is not established from here (RR1). The pasted JD gives no salary (RR2) and says nothing about team size or decision rights (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote — UK); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Brindlemoor and the live role are confirmed on its own careers page, per RR1; (2) you are confirmed UK-based for the remote post, per R1.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, described as an insurtech with a pet-insurance product | `[grounded]` JD header as you pasted it |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing | `[grounded]` as you provided |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| First-90-day and first-year outcomes | Not stated in the JD you pasted | `[grounded]` JD silence |
| Scope read | A single-product pricing seat with a defined remit. Whether it has reports or other analysts is unstated, and nothing in the JD requires management | `[inferred]` from the responsibility list against its silence on team |
| Market calibration | Not established. The role-family sweep did not run, so no salary band or title norm is offered | `[grounded]` the search was refused (see Evidence status) |
| Unknowns | Salary; team size and reporting line; decision rights over rate changes; maturity of the existing rating models | `[grounded]` none stated in the JD |
| Contradictions | None found between the JD and your background. The posting could not be checked against Brindlemoor's own pages | `[grounded]` nothing fetched |

## Evidence map

Your background was typed into the conversation, so it counts as CV-equivalent and `medium` is the ceiling on a first pass.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | low | hard_gate | You haven't stated where you are based or your right to work. Your UK motor insurer role suggests you are UK-based but doesn't settle it. Confidence is low because there is no statement of the constraint itself | `[inferred]` from the UK employer | Closing question R1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You state 5 years of pricing analytics, the last 2 as senior analyst. Specific, but self-reported with nothing inspectable | `[grounded]` your background text | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You say you use both daily. That shows frequency, not depth, so expect a probe on what you build in each | `[grounded]` your background text | A sanitized query or notebook would raise it to `high` |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. That is the same technique the role needs, in a different line of insurance | `[grounded]` your background text | A redacted model summary or documentation page would raise it to `high` |
| R5a | Run price tests with underwriting | must_have | direct | medium | none | You ran 14 price tests last year with the underwriting team | `[grounded]` your background text | none |
| R5b | Design price tests (hypothesis, split, sizing) | must_have | unclear | low | discovery | "Ran" doesn't say whether you designed the tests or executed ones set up by others. Ambiguity resolves downward, so this is `unclear` until you say | `[grounded]` the wording of your claim | Closing question G1 |
| R6a | Turn results into recommendations for underwriting | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting, and ran tests with that team. The word "recommendations" is mine, not yours, so confirm it fits before using it | `[grounded]` your background text | Confirm in interview prep |
| R6b | Turn results into recommendations for product | important | unclear | low | discovery | Nothing in your background mentions a product team or product decisions | `[grounded]` your background silence | Closing question G2 |
| R7 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your background text | A redacted review deck would raise it to `high` |
| R8 | Own pricing analytics for the product | important | adjacent | medium | transferability | You owned the model for a segment of a motor book. The role owns a whole product's pricing analytics. Limit: nothing says you owned the full product, its rate strategy or its budget | `[inferred]` from "young-driver book" against "pet-insurance product" | Frame as segment ownership, never product ownership |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a UK motor insurer. The JD asks for insurance, not pet insurance | `[grounded]` your background text and JD | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Price test design (R5b, must_have) | discovery | 14 tests run with underwriting, with no account of who set the hypothesis, split and sample size | A must-have at `unclear`. The JD says "design and read", so the design half decides how strong this row is | Choosing the test and control groups; setting the sample size or run length; writing the test plan; deciding what counted as a win | A test plan or read-out, redacted | `[grounded]` your wording; `[generic]` that "design" is a separate skill from "run" in test roles |
| G2 | Product-facing recommendations (R6b, important) | discovery | No mention of working with a product team or a product-level audience | The JD names product as a second audience for recommendations | A test result that changed a product feature, bundle or tier; a pricing review where product attended | A review deck slide or a note of the outcome | `[grounded]` your background silence |
| G3 | Whole-product ownership (R8, important) | transferability | Segment-level model ownership only | The role owns the product; this is the likeliest objection to your profile | Rate or model work beyond the young-driver book; any role in setting rates across a product | A redacted model scope note | `[inferred]` bridge from segment to product; `[generic]` that this is the objection a whole-product role raises |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or the role may not be a live opening | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Salary not stated | unknown | — | The JD as pasted has no pay figure | The post may pay below what a senior pricing seat would be expected to | `[inferred]` from the pasted JD's silence; no band was researched | What salary range is budgeted for this role? | unresolved |
| RR3 | Authority and team unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | The role may carry accountability for the product's pricing without decision rights over rate changes or any analyst support | `[inferred]` from the ownership wording against the JD's silence on authority | Which rate decisions does this role make, and who else sits in the pricing team? | unresolved |
| RR4 | Responsibilities and audiences stated concretely | positive_signal | — | "build and monitor rating models, design and read price tests, and turn the results into recommendations for underwriting and product" | Scope is defined, with named outputs and audiences | `[grounded]` JD | Who owns the rating models today, and what is their current state? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | CV line: "Built and maintained the GLM rating model for the young-driver book" at a UK motor insurer | R4; your own sentence, with the employer type added from your background | `[grounded]` your background text | `resume_edits_pending_approval` |
| E2 | CV line: "Ran 14 price tests last year with the underwriting team" | R5a; keep "ran" until G1 is answered | `[grounded]` your background text | `resume_edits_pending_approval` |
| E3 | CV line: "Present the quarterly pricing review to the head of underwriting" | R7 | `[grounded]` your background text | `resume_edits_pending_approval` |
| E4 | Positioning: say plainly that your background is motor pricing and pet insurance is new to you. Make no claim to pet-specific rating knowledge | R9, R8 | `[grounded]` your background text | pending your approval |
| E5 | If asked about management: you have not managed anyone. Do not imply otherwise | The JD does not ask for it; see RR3 for whether the seat has reports | `[grounded]` your background text and JD | pending your approval |
| A1 | Confirm the role exists on Brindlemoor's own careers page, using contact details you find yourself, before spending effort on the application | RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask RR1, RR2, RR3 and RR4's verification questions verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Brindlemoor pet insurance insurtech careers Senior Pricing Analyst"; refused, no permission granted. It would have moved role reality's organization and contradictions rows and settled RR1 |
| 2. Role-family sweep | unavailable | Searched "senior pricing analyst UK insurance salary remote GLM"; refused. It would have moved role reality's market calibration and the seniority-compensation check behind RR2 |
| 3. Hiring manager's public footprint | unavailable | Searched "Odile Varga Director of Pricing Brindlemoor"; refused. It would have moved role reality's scope read and which story the plan leads with |

I can turn this assessment into a `tuesday-dossier.md` file whenever you want one.

**Upgrade menu**

- Permission to search would run all three targets above. That would settle RR1 and RR2 and add a market band for pay.
- Your location and right to work, plus any pay floor or other non-negotiables, would settle R1 and make the hard-gate checks real.
- A redacted GLM summary or model documentation page would raise R4 to `high`; a sanitized SQL or Python sample would raise R3.
- A redacted price-test plan or read-out would resolve R5b and strengthen R5a.
- A redacted quarterly review deck would raise R7 and could show product involvement for R6b.
- The live posting URL or Brindlemoor's careers page would settle RR1 directly.

**Questions**

- R1 — Are you UK-based with the right to work in the UK for a fully remote post?
- G1 — On the 14 price tests, which parts did you personally own: choosing the test and control groups, setting sample size or run length, writing the plan, reading the result? What did the underwriting team or others own?
- G2 — Did any test result or pricing review change something a product team owned, such as a feature, tier or bundle? What was your part?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.