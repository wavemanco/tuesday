Checking Pellucid's site and the live posting was blocked, so this assessment rests on what you pasted. The Evidence status section has details.

## Decision snapshot

**Yes, worth applying: the six `must_have` rows R3, R4, R5, R6, R7 and R8 are all `direct`. R9 (BigQuery) is `adjacent`, and your location and pay floor are still unconfirmed. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver office), R2 (Pay $148,000–$166,000 plus equity)
- `must_have`: direct: R3, R4, R5, R6, R7, R8
- `important`: adjacent: R9 (BigQuery as the warehouse) · unclear: R10 (Ingestion from app and CRM), R11 (Data contracts analysts depend on)

R9 (`medium`): a credible bridge, its limit named; R10, R11: discovery gaps, nothing in your message either way; R1, R2: waiting on your constraints.

**Opportunity ledger.** The posting states its pay, and the figure overlaps the market band you supplied (RR3). The employer and live posting are unchecked (RR1), and the team, reporting line and on-call load are unstated (RR2, RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office), R2 (Pay $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed live on Pellucid's own careers page (RR1); (2) the location and pay terms work for you (R1, R2); (3) the team and scope answers hold up in the interview (RR2, RR4); (4) BigQuery is framed as adjacent and never as experience (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` the About text you pasted; not independently checked |
| Mandate | Build and run pipelines behind the platform's reporting: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` JD |
| Stack and requirements | 5+ years, SQL and Python, dbt and a cloud warehouse, Airflow or similar, data quality testing | `[grounded]` JD |
| Pay and location | $148,000–$166,000 plus equity; Remote (US) or Denver office | `[grounded]` JD |
| First 90 days and first year | Not stated | `[grounded]` JD silent |
| Scope read | Three areas (ingestion, warehouse modelling, contracts) plus "run", with no team size given; it may be broader than one domain | `[inferred]` from the JD's three named areas against the report's typical scope |
| Market calibration | Report: Senior at Series B–D has a base median of $151,000 and an interquartile range of $139,000–$163,500 (n=2,310), "senior" typically means 5–8 years, and the usual scope is one domain with no reports. The posted range starts $3,000 below that median and ends $2,500 above the range's upper edge. Your 6 years sits inside the 5–8 norm. | `[grounded]` the Datawright report you supplied, as pasted, and the JD figures; the typical-scope clause is `[generic]` |
| Unknowns | Hiring manager, team size, reporting line, on-call expectations, equity terms, process | `[grounded]` posting names none |
| Contradictions | None between the JD and About text as pasted; live pages not checked | `[grounded]` pasted material only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location and work authorization weren't given, and the JD terms are stated | `[grounded]` JD; candidate constraints not given | Q1 |
| R2 | Pay $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | The range is stated, but your pay floor wasn't given | `[grounded]` JD; candidate constraints not given | Q1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years at a B2B payroll company; there's no dated CV or inspectable artifact yet | `[grounded]` your message | A dated CV would firm this up |
| R4 | Strong SQL and Python | must_have | direct | medium | none | "Daily" use is stated; "strong" is the JD's word, and nothing inspectable is attached | `[grounded]` your message | A sanitized query or code sample would raise to high |
| R5 | dbt | must_have | direct | medium | none | You built the project, about 180 models, on Snowflake; no inspectable artifact yet | `[grounded]` your message | A sanitized lineage graph or project tree would raise to high |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse and the requirement doesn't name one; the JD's BigQuery mention is carried in R9 | `[grounded]` JD wording and your message | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow use is stated, but whether you wrote the DAGs or only ran them is not, so `medium` carries that caveat | `[grounded]` your message | Confirm what you authored (see the upgrade menu) |
| R8 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite, which is ownership of the test suite | `[grounded]` your message | A sanitized suite config would raise to high |
| R9 | BigQuery as the warehouse (inferred from the responsibilities line) | important | adjacent | medium | transferability | Carries over: dbt modelling and warehouse work on Snowflake. Limit: you've never used BigQuery, so its specifics are unexercised. | `[inferred]` adjacency from your Snowflake and dbt work; `[generic]` that dbt logic mostly carries across warehouses | A small BigQuery project (W1) narrows the limit |
| R10 | Ingestion from app and CRM | important | unclear | low | discovery | Your message doesn't name your source systems or say who built the ingestion | `[grounded]` your message silent | Q3 |
| R11 | Data contracts analysts depend on | important | unclear | low | discovery | The test suite is nearby context, but nothing describes agreements with consumers | `[inferred]` from the Great Expectations suite | Q2 |

R9's `requirement_source` is inferred from the JD's "dbt-modelled warehouse in BigQuery". It is not in the JD's requirements list.

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R9, important) | transferability | Snowflake and dbt on about 180 models; no BigQuery use | The JD names BigQuery as the warehouse, so it's the likeliest objection | A side project or sandbox run of a dbt model on BigQuery; any prior contact with its query or cost model | A repo or README of the small project | `[inferred]` bridge from Snowflake and dbt; `[generic]` that it's the likeliest objection |
| G2 | Ingestion from app and CRM (R10, important) | discovery | Pipelines are implied by Airflow use; sources aren't named | The JD lists ingestion first among its areas | Pulling from a product database, a CRM or third-party APIs; building or owning a connector | A DAG outline or architecture sketch | `[grounded]` your message silent on sources |
| G3 | Data contracts (R11, important) | discovery | A test suite you set up; no consumer agreements described | The JD names the contracts analysts depend on | Schema or freshness agreements with analysts; ownership rules; handling a broken expectation | A contract doc, a README or an alert runbook | `[grounded]` your message silent; `[inferred]` from the test suite |
| G4 | Location and pay terms (R1, R2, hard_gate) | hard_gate | The JD terms are stated, but your constraints weren't given | A failed gate would cap the status at `hold_pending_answers` or lower | Not applicable; this is a yes or no | Your own statement | `[grounded]` constraints not given |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and live posting not verified | risk_signal | low | "Founded 2016, Denver. 264 employees. Series C ($52M, February 2026)" | The pasted pages may be stale or incomplete. This is a gap in checking, not a finding about Pellucid. | `[generic]` pattern for pasted postings; no claim about this employer | Can you point me at this role on your careers site, and who would I be interviewing with? | unresolved |
| RR2 | Scope and team unstated against a three-area mandate | unknown | — | "Build and run the pipelines … ingestion … a dbt-modelled warehouse … data contracts" | The role may carry more than the report's one-domain norm, possibly as the only data engineer | `[inferred]` from the JD's scope against the `[generic]` typical scope in the report | How many data engineers and analysts are there today, who does this role report to, and which of ingestion, modelling and contracts does it own? | unresolved |
| RR3 | Stated pay overlaps the market band | positive_signal | — | "$148,000–$166,000 plus equity" | The range sits around the report's median; equity terms are unstated | `[grounded]` JD and the pasted report | How is the equity structured (type, vesting, strike)? | noted |
| RR4 | "Run" implies operations; on-call unstated | unknown | — | "Build and run the pipelines" | Production support duties may exist off hours | `[inferred]` from "run" against silence on support | What are the on-call or support expectations for pipelines this role runs? | unresolved |

## Application plan

Every row below is a proposal pending your approval, including the positioning advice; nothing here is final CV language or outreach text.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with the dbt project (about 180 models, Snowflake) and the Great Expectations suite you set up, ahead of the tools list | See R5, R8 | `[grounded]` your message | pending your approval |
| E2 | Describe BigQuery as the stated gap, bridged by Snowflake and dbt work, never as BigQuery experience | See R9 | `[grounded]` your message; `[inferred]` bridge | pending your approval |
| W1 | A small dbt project run on BigQuery, claimed as exactly what it is | Narrows G1's limit | `[inferred]` from R9 | pending your approval |
| A1 | Confirm the posting is live on Pellucid's own careers page before investing time | See RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask the questions from RR1, RR2, RR3 and RR4 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | A search ("Pellucid Learning online tutoring K-12 Denver Series C") and a fetch (pellucidlearning.com/careers/senior-data-engineer) were both refused for lack of permission. They would have moved role reality's organization and contradictions rows and RR1. |
| 2. Role-family sweep | skipped | The Datawright report's figures are in hand and fix the market calibration row and the pay check in RR3 |
| 3. Hiring manager's public footprint | n/a | The posting names no one, so there was no query to form |

## Dossier offer

I can save this as `tuesday-dossier.md` if you want to keep it.

## Upgrade menu

- A link to the live posting, or search permission for the company check → RR1 and role reality's organization row close.
- Your location, work authorization and minimum base → R1 and R2 close; the status becomes `go` or `no_go`.
- A sanitized lineage graph, a Great Expectations suite config or a DAG outline → R5, R7 and R8 rise to `high`.
- Source-system detail → R10 resolves.
- A hiring manager's name from the recruiter → role reality's scope read, and which story the plan leads with.
- A deeper pass on Pellucid (funding and leadership churn, public employee reports, recent news; up to 5 more searches and 2 more fetches) → fills RR1 and the opportunity ledger. Say the word and it runs, once search permission is granted.

## Questions

- R1, R2 — Do the posting's location options (Remote US, or Denver) and its $148,000–$166,000 range both work for you, and if not, which one doesn't?
- R11 — Have you set or enforced expectations with the analysts who use your models (schema, freshness, ownership, what happens when a test fails)? Who set them, and how were they communicated?
- R10 — Which source systems fed your warehouse (product database, CRM, third-party APIs), and which ingestion did you build yourself?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.