I'll read the skill's reference files before building the assessment.
**Yes, apply — `conditional_go`.** Your evidence is `direct` on R2, R3, R4, R5a, R6 and R8, and the two things you flagged don't block you. Pet insurance sits in R10, a `preferred` row. The posting lists no people-management requirement, so there is no map row for it. The conditions are R1 confirmed and Brindlemoor's posting verified (RR1).

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK))
- `must_have` — direct: R2, R3, R4, R5a, R6, R8 · adjacent: R7 (Recommendations for underwriting and product) · unclear: R5b (Monitor rating models)
- `preferred` — direct: R9 · adjacent: R10 (Pet-insurance familiarity)

R10 — a credible bridge, its limit named; R5b — unconfirmed, waiting on your answer; R7 — underwriting side evidenced, product side not.

**Opportunity ledger.** Concrete work and a named hiring manager (RR5), but the employer could not be checked (RR1), pay is withheld (RR3), and team size and decision rights are unstated (RR2, RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you are UK-based with the right to work there — R1, G1; (2) Brindlemoor and the live posting verify — RR1; (3) the pet gap is framed as adjacent, never as pet-pricing experience — R10; (4) pay and team scope prove acceptable in the first conversation — RR2, RR3.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech, with a pet-insurance product | `[grounded]` JD header; not checked externally |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reports to | Odile Varga, Director of Pricing | `[grounded]` JD |
| People management | The JD lists none; direct reports are neither required nor ruled out | `[grounded]` JD silent |
| Working pattern | Fully remote (UK) | `[grounded]` JD |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Scope read | A single-product pricing role covering models, tests and recommendations. It reads as an individual-contributor "senior" post, though that is not confirmed | `[inferred]` from the JD's three duties and its silence on reports |
| Market calibration | Not established. The role-family sweep did not run, so there is no band for title, scope or pay | `[grounded]` JD states no pay; sweep unavailable |
| Unknowns | Pay, team size, any direct reports, who decides rate changes | `[grounded]` JD silent on each |
| Contradictions | None inside the JD itself; no outside source was available to compare it against | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | low | hard_gate | The JD sets a UK remote term. You work at a UK motor insurer, which suggests UK location but doesn't settle residence or right to work. No constraints were given | `[inferred]` from your UK employer; `[grounded]` JD | G1 question |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | "5 years pricing analytics at a UK motor insurer, the last 2 as senior analyst". Specific, but typed in and uninspected. A length of experience, not a gate | `[grounded]` your intake message | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily". "Strong" isn't something prose can show | `[grounded]` your intake message | A sanitized query or notebook would raise it to `high` |
| R4 | GLM experience | must_have | direct | medium | none | "Built and maintained the GLM rating model for our young-driver book". The scope is one motor segment, and the claim stays that narrow | `[grounded]` your intake message | Sanitized model documentation or factor tables would raise it to `high` |
| R5a | Build rating models | must_have | direct | medium | none | Same GLM build evidence as R4 | `[grounded]` your intake message | none |
| R5b | Monitor rating models | must_have | unclear | low | discovery | You said "maintained". That is near monitoring but doesn't establish it, and ambiguity resolves downward | `[grounded]` the word you used; `[inferred]` that it may cover monitoring | G2 question |
| R6 | Design and read price tests | must_have | direct | medium | none | "Ran 14 price tests last year with the underwriting team". "Ran" doesn't say how much was design versus readout | `[grounded]` your intake message | When drafting E2, state your own part (design, analysis, readout) in your words |
| R7 | Turn results into recommendations for underwriting and product | must_have | adjacent | medium | discovery | You ran tests with underwriting and present the quarterly review to the head of underwriting. Recommending specific actions isn't stated, and nothing touches product | `[grounded]` your intake message; `[inferred]` that recommendations may sit inside that work | G3 question |
| R8 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | "I present the quarterly pricing review to the head of underwriting" | `[grounded]` your intake message | A sanitized review deck would raise it to `high` |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your intake message | none |
| R10 | Pet-insurance familiarity (implied by the product) | preferred | adjacent | medium | transferability | You've never worked on pet insurance. What carries over is insurance pricing, GLMs and test design. Pet-specific exposures and claims patterns are not exercised. Rating factors usually differ by line, so expect to be asked | `[grounded]` your stated gap; `[generic]` that factors differ by line; requirement `[inferred]` from "pet-insurance product" | G4 bridge; no question |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | UK location and right to work (R1, hard_gate) | hard_gate | A UK employer, nothing stated about residence or authorization | The role is UK-remote only; if the term is unmet, wording can't fix it | None needed; this is a yes or no | None | `[grounded]` JD term and your silence |
| G2 | Rating-model monitoring (R5b, must_have) | discovery | "Maintained" the model; monitoring not stated | A must-have JD duty; `direct` here would leave the build and monitor pair fully covered | Tracking actual-versus-expected by factor; periodic refits; drift or loss-ratio checks; a dashboard others used | A monitoring pack, a refit note, a dashboard screenshot | `[grounded]` CV-level silence; `[generic]` that "build and monitor" is usually probed as a pair |
| G3 | Recommendations to underwriting and product (R7, must_have) | discovery | Tests run with underwriting and a quarterly review presented; no stated recommendations or product contact | R7 is the row where the JD's outcome ("turn results into recommendations") is least evidenced | A test readout ending in a rate action; a proposal underwriting adopted; work with a product or proposition team | A readout or review slide, sanitized | `[grounded]` intake; `[inferred]` that moving R7 to `direct` strengthens the case |
| G4 | Pet-insurance domain (R10, preferred) | transferability | Motor pricing, GLM and tests | A preferred row, but it's the likeliest interview objection | Anything touching claims severity, breed or age-style rating factors, or vet-cost inflation; a short note comparing the two lines | A one-page sanitized comparison note you write | `[inferred]` bridge from your motor work; `[generic]` that this is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The search that would confirm the employer didn't run. The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not be a real hiring employer. These are possibilities side by side | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Team size and direct reports unstated | unknown | — | "Own pricing analytics" | The post may be a solo analyst role or sit within a team, and the "senior" title may or may not carry reports | `[inferred]` from the JD's title against its silence on reports | How large is the pricing team, and does this role have or plan direct reports? | unresolved |
| RR3 | Pay withheld | unknown | — | JD states no pay | The figure may be disclosed later in the process, or may not suit your floor | `[grounded]` JD silent | What salary range is budgeted for this post? | unresolved |
| RR4 | Authority over rate changes unstated | unknown | — | "turn the results into recommendations for underwriting and product" | The role may advise while underwriting and product decide, which is normal for an analyst post but unconfirmed here | `[inferred]` from the JD's "recommendations" wording | Who makes the final call on rate changes, and how are test results fed into it? | unresolved |
| RR5 | Concrete scope, named hiring manager, remote term stated | positive_signal | — | "Fully remote (UK)"; hiring manager named | The posting is specific about duties, requirements and working pattern | `[grounded]` JD | What would success look like after the first year? | noted |

## Application plan

Everything in this plan, the table and the positioning rows alike, is proposed and pending your approval. The edit lines use your own words and add no facts.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | CV line: "Built and maintained the GLM rating model for the young-driver book at a UK motor insurer" | R4, R5a | `[grounded]` your intake message | resume_edits_pending_approval |
| E2 | CV line: "Ran 14 price tests with the underwriting team", with the year added by you and your own part stated | R6 | `[grounded]` your intake message | resume_edits_pending_approval |
| E3 | CV line: "Present the quarterly pricing review to the head of underwriting" | R8 | `[grounded]` your intake message | resume_edits_pending_approval |
| P1 | Lead the application with R4, R6 and R8, since these are the evidence closest to the JD's wording | R4, R6, R8 | `[grounded]` rows | pending your approval |
| P2 | On pet insurance, say plainly that you've priced motor and not pet, then say what carries over (GLMs, tests, working with underwriting) and what you'd need to learn | R10, G4 | `[grounded]` your stated gap | pending your approval |
| P3 | If asked about managing people, say you haven't managed anyone. Don't present informal mentoring or participation as leadership unless you tell me something that supports it | RR2 | `[grounded]` your intake message | pending your approval |
| Q1 | Ask RR1 to RR4 verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Check the posting on Brindlemoor's own careers page before investing effort | RR1 | `[grounded]` RR1 | pending your approval |

## Evidence status

Verified: none yet. Your background was typed in, so every claim of yours is a lead at `medium` at most until you confirm specifics or attach an artifact. Unverified leads from memory: none. Rejected inferences: none.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Brindlemoor pet insurance" and "Brindlemoor careers Senior Pricing Analyst"; the host refused both because search permission wasn't granted. It would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | Searched "senior pricing analyst pet insurance UK salary remote"; refused for the same reason. It would have moved the market calibration row and the pay comparison under RR3 |
| 3. Hiring manager's public footprint | unavailable | Searched "Odile Varga Director of Pricing Brindlemoor"; refused for the same reason. It would have moved the scope read and which story the plan leads with (P1) |

Everything not drawn from the JD or your message is labeled `[inferred]` or `[generic]` above, and no company facts were used.

If you'd like, I can write this up as `tuesday-dossier.md` for you to keep.

**Upgrade menu**
- Search permission, so targets 1 to 3 can run → RR1 (employer verification), the market band for RR3, and a read of Odile Varga's public professional footprint for P1.
- Your CV or a sanitized artifact (a model spec, a test readout, a review deck) → R3, R4 and R8 can rise to `high`, and E1 to E3 are checked against the real text.
- Your pay floor and any other non-negotiables (contract type, hours) → R1 resolves, and pay and contract get gate rows checked against the role.
- A note on pet versus motor pricing that you write → G4's bridge gets a work sample.

**Questions**

G1 — Are you based in the UK with the right to work there, and are there any non-negotiables (pay floor, contract type, hours) this role must meet?

G2 — What monitoring did you run on the young-driver GLM after it went live, and which parts were yours?

G3 — Which rate or product changes have your test and model results led you to recommend, and who made the final call?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.