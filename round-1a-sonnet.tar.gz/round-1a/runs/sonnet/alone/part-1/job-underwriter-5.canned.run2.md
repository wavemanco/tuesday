I've read the underwriting rules and am now loading the web tools. I'll check that the Pellucid posting and company page are live and match what you pasted, then write up the assessment.
**Yes, it's worth applying, with conditions. Status: `conditional_go`.** The role matches what you've done: R3, R4, R5, R6, R7 and R8 all line up with your dbt/Snowflake, Airflow and Great Expectations work. The conditions are the two hard gates I can't check without your constraints, and BigQuery, which is new to you.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000 plus equity)
- `must_have`: direct: R3, R4, R5, R6, R7, R8
- `important`: adjacent: R9 (BigQuery); unclear: R10 (Ingestion from app and CRM), R11 (Data contracts)

R9 is a credible bridge with its limit named; R10 and R11 are silent in what you gave me, so they are open questions, not weaknesses.

**Opportunity ledger.** Transparent and concrete: the pay is stated and sits at or above the cohort median (RR1), the stack is named (RR2), and the employer and live posting check out (RR3). Three things are open: how many people share the data-engineering work (RR4), the equity terms (RR5), and who the hiring manager is (RR6).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) you are US-based or will work from Denver, R1; (2) the range clears your minimum, R2; (3) BigQuery is framed honestly as new to you, R9; (4) the scope and team size hold up in the first conversation, RR4.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` about page, fetched via search |
| Mandate | Build and run the pipelines behind reporting: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` live posting |
| First-year outcomes | None stated in the posting | `[grounded]` posting silent |
| Working pattern | Remote (US) or the Denver office | `[grounded]` live posting |
| Scope read | Ingestion, warehouse and contracts together could be the whole reporting stack, which is broader than the single-domain scope the survey calls typical. This is a read, not a stated fact | `[inferred]` from the posting's three duties against the report's "one domain's pipelines" |
| Market calibration | Your recruiter's report puts Senior Data Engineer at Series B–D companies at a $151,000 median, with $139,000–$163,500 as the middle half. The posting's $148,000–$166,000 starts just under the median and tops out above the upper quartile. "Senior" typically means 5–8 years, and your 6 sits inside that. Pellucid's Series C is in the report's cohort. | `[generic]` Datawright 2026 report, n=2,310, supplied by you; `[grounded]` posting's figures |
| Unknowns | Team size and who owns what; equity terms; hiring manager; first-year outcomes | — |
| Contradictions | None between what you pasted and the live careers page and about page | `[grounded]` both fetched/searched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Location: Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location and work authorization weren't given, so I can't say whether you meet it | `[grounded]` posting term; your constraints not provided | Question 1 |
| R2 | Pay $148,000–$166,000 plus equity (checked against your minimum) | hard_gate | unclear | none | hard_gate | Your minimum wasn't given. The range is stated, but the equity amount isn't (RR5) | `[grounded]` posting figure; your floor not provided | Question 1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You have 6 years in data engineering at a B2B payroll company. Stated by you and not yet inspectable | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You use both daily, and about 180 dbt models are SQL-heavy work. "Strong" is a self-description | `[grounded]` your background | none |
| R5 | dbt | must_have | direct | medium | presentation | You built the dbt project, about 180 models. Scale and ownership are your strongest line here, so the CV should lead with them | `[grounded]` your background | E1 |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake in production is a cloud warehouse | `[grounded]` your background | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | You used Airflow, the tool named | `[grounded]` your background | none |
| R8 | Data quality testing | must_have | direct | medium | presentation | You set up the Great Expectations suite, which is direct evidence and worth surfacing in role terms | `[grounded]` your background | E2 |
| R9 | BigQuery (the warehouse named in the role description) | important | adjacent | medium | transferability | Adjacent: a dbt project on Snowflake exercises the same modelling and warehouse concepts. Limit: you haven't used BigQuery, so its cost model and platform specifics are unexercised | `[inferred]` adjacency from Snowflake/dbt; requirement implied by the posting's description | G1 |
| R10 | Ingestion from the tutoring app and a CRM | important | unclear | low | discovery | Nothing you gave me says what sources your pipelines ingested | `[grounded]` background silent | G2 |
| R11 | Data contracts for analysts | important | unclear | low | discovery | Nothing you gave me touches contracts or schema agreements | `[grounded]` background silent | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R9, important) | transferability | Snowflake and dbt at scale; no BigQuery | The posting names it in the stack, so it will likely come up in interviews | A side project or a sandbox dbt run on BigQuery; any GCP exposure; a migration or cross-warehouse evaluation | A small public repo, a README, a dbt project on a BigQuery sandbox | `[grounded]` background; `[generic]` that a named stack gets probed |
| G2 | Ingestion from app and CRM (R10, important) | discovery | Nothing on the sources your pipelines ingested | One of the three named duties; resolving it could confirm the fit is direct | Pulling in a product database, event stream or CRM (Salesforce, HubSpot) export; loading third-party API data; building an incremental load | A pipeline diagram, a DAG screenshot, a sanitized design doc | `[grounded]` background silent |
| G3 | Data contracts (R11, important) | discovery | Nothing on contracts | The posting says analysts depend on them | Agreed schemas or SLAs with upstream teams; Great Expectations checks used as a producer/consumer agreement; schema-change processes | A sanitized schema-change policy, a contract doc, or a test-suite excerpt | `[grounded]` background silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Stated range at or above the cohort median | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The posting is transparent, and pay is in line with the market for the title | `[grounded]` posting figure against the `[generic]` report band | Where in the range does a candidate with my background land? | noted |
| RR2 | Concrete, named stack and duties | positive_signal | — | "a dbt-modelled warehouse in BigQuery" | The role has a defined scope and a real data stack | `[grounded]` posting | What does the current pipeline estate look like today? | noted |
| RR3 | Employer and live posting verified | positive_signal | — | "Accepting applications." | The company exists as described and is hiring | `[grounded]` careers page and about page | None needed | noted |
| RR4 | Team size and ownership unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | The role may be sole or near-sole data engineer across the whole reporting stack, broader than the survey's typical scope | `[inferred]` from the posting's three duties against the report's typical scope | How many data engineers are there, and who owns what? | unresolved |
| RR5 | Equity unspecified | unknown | — | "plus equity" | The equity could be small or hard to value, so total compensation is unclear | `[generic]` pattern for equity in postings without terms | What are the equity grant size, vesting and strike terms? | unresolved |
| RR6 | No hiring manager named | unknown | — | (posting names no hiring manager) | Who the role reports to, and into which function, is unknown | `[grounded]` posting silent | Who does this role report to? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead a CV bullet with building the dbt project of about 180 models on Snowflake, in your own terms | see R5 | `[grounded]` your background | resume_edits_pending_approval |
| E2 | Surface setting up the Great Expectations test suite as data quality testing | see R8 | `[grounded]` your background | resume_edits_pending_approval |
| E3 | In the application note, state Snowflake experience and say plainly that BigQuery is new to you; make no claim about it | see R9 | `[grounded]` your background | pending your approval |
| W1 | Optional: a small dbt project on a BigQuery sandbox, to give you something to point to | see G1 | `[generic]` common way to narrow a named-tool gap | pending your approval |
| Q1 | Ask the register's questions for RR4, RR5 and RR6 in the loop | The register is interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning online tutoring K-12 Denver Series C" (returned "About Pellucid Learning", pellucidlearning.com/about) and fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer). Both match what you pasted, the posting is live ("Accepting applications"), and the employer is established. This feeds RR3 and the contradictions row |
| 2. Role-family sweep | skipped | The Datawright report you supplied is in hand and fixes the market calibration line and the pay comparison. A search wouldn't change either |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there was no query to form |

I can write all of this up as `tuesday-dossier.md` if you want a file to keep.

**Upgrade menu**
- Your location and pay minimum → R1 and R2 resolve, and the decision becomes `go` or `no_go`.
- An answer on ingestion sources → R10 resolves.
- An answer on data contracts → R11 resolves.
- Any BigQuery or GCP exposure, or a sandbox repo → R9's bridge narrows.
- The hiring manager's name → I can read their public professional footprint and shape the application plan for that reader.
- A deeper research pass on Pellucid (funding and leadership changes, hiring patterns, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**
1. R1, R2: Are you based in the US (or willing to work from Denver), and does $148,000–$166,000 clear your minimum?
2. R10, R11: Have you built ingestion from app or CRM sources, or set agreed schemas or contracts with analysts or upstream teams, and what did you own?
3. R9: Do you have any BigQuery or other GCP exposure, even in a side project?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.