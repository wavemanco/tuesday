I'll read the reference files the skill requires before building the assessment.
Reading is done; now I'm running the three L1 research searches: the company, the pay band, and the hiring manager.
**Yes, worth applying to, but confirm the working pattern first, because R1 is unconfirmed. Status: `conditional_go`.**

You mentioned you've never managed anyone. The JD doesn't ask for it (see the Scope read row in Role reality).

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote working pattern, UK)
- `must_have`: direct: R2, R3, R4, R5, R6, R8a · unclear: R7 (Monitor rating models), R8b (Recommendations to product)
- `preferred`: direct: R9 · adjacent: R10 (Pet-insurance domain)

R7 — "maintained" is stated, monitoring detail is not; R8b — product-facing work not yet evidenced; R10 — a credible bridge, its limit named.

**Opportunity ledger.** The role is live on the employer's own careers page and reports to a named pricing leader (RR5). Its working pattern contradicts the JD you pasted (RR1), and salary, team size and decision rights are not stated (RR3, RR4). Little public footprint was found beyond the company's own pages (RR2).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote working pattern, UK); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the working pattern is confirmed as one you accept (R1, RR1); (2) the salary clears your floor, which I don't have (RR3); (3) the pet-insurance bridge is framed as adjacent, never as pet experience (R10).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product. Size, stage and funding were not established. | `[grounded]` JD header; `[grounded]` careers page on brindlemoor.co.uk |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, give recommendations to underwriting and product | `[grounded]` JD |
| Reports to | Director of Pricing, Odile Varga | `[grounded]` JD; `[grounded]` careers page |
| Working pattern | The JD says "Fully remote (UK)". The careers page says "Leeds office four days a week". | `[grounded]` both sources, which disagree |
| Compensation | Not stated in the JD, and not on the careers page text fetched | `[grounded]` JD; `[grounded]` fetched page |
| Scope read | A single-product analytics role. The JD names no direct reports, so having managed no one is not a requirement gap. | `[inferred]` from the JD's silence on reports |
| Market calibration | Senior pricing analyst at UK insurers and insurtechs: median base £58,400, interquartile range £52,100 to £64,900 (n=612). This is a market band, never Brindlemoor's offer. | `[generic]` Pricewell 2026 pay survey, seen as a search result; `[grounded]` JD, for the withheld figure |
| Hiring manager | Director of Pricing at Brindlemoor. Previously head of pricing analytics at Calloway Re for six years. Spoke at the 2025 Insurance Pricing Forum on "Small Books, Loud Errors", about monitoring rating models in small books. | `[grounded]` public profile search result |
| Manager emphasis | Monitoring is probably weighted heavily in this role | `[inferred]` from the talk topic against the JD's "build and monitor" |
| Unknowns | Salary, team size, decision rights, company stage and funding, and the true working pattern | `[grounded]` JD and careers page silence |
| Contradictions | JD "Fully remote (UK)" against careers page "Leeds office four days a week" (RR1) | `[grounded]` both sources |

## Evidence map

Your background is typed prose, which has the same standing as a CV. Nothing is above `medium` until you attach something inspectable.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote working pattern, UK | hard_gate | unclear | none | hard_gate | You have not said whether remote is a requirement for you, so there is no claim to grade. The JD says remote and the careers page says Leeds four days a week, so the role's own terms don't settle it. | `[grounded]` JD and careers page; `[grounded]` no constraint stated | Ask whether it is firm (question G1) |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You describe 5 years of pricing analytics at a UK motor insurer, the last 2 as senior analyst. Specific, with nothing inspected yet. | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You state daily use of both. No artifact has been inspected. | `[grounded]` your background | A code sample or description of a pipeline would raise to `high` |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for your young-driver book. Specific, but no documentation has been inspected. | `[grounded]` your background | Sanitized model documentation would raise to `high` |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. | `[grounded]` your background | A review deck, sanitized, would raise to `high` |
| R6 | Design and read price tests | must_have | direct | medium | none | You ran 14 price tests last year with the underwriting team. The 14 counts tests, not outcomes. | `[grounded]` your background | A sanitized test readout would raise to `high` |
| R7 | Monitor rating models | must_have | unclear | low | discovery | You said "maintained". What you tracked, how often, and what it triggered are not stated. Roles like this usually probe monitoring in detail. | `[grounded]` your background; `[generic]` interview pattern | Question G3 |
| R8a | Recommendations to underwriting | must_have | direct | medium | none | Your price tests ran with the underwriting team and your review goes to its head. | `[grounded]` your background | none |
| R8b | Recommendations to product | must_have | unclear | low | discovery | Nothing stated reaches a product team. The JD pairs underwriting and product. | `[grounded]` your background silence | Question G2 |
| R9 | Insurance experience | preferred | direct | medium | none | Five years at a motor insurer. | `[grounded]` your background | none |
| R10 | Pet-insurance domain knowledge | preferred | adjacent | medium | transferability | The JD does not ask for pet experience. This row is inferred from the product. Your GLM and price-testing work carries over. The pet-specific factors it has not exercised are named in G4. | `[inferred]` from "pet-insurance product" in the JD; `[grounded]` you have none | See G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Working pattern (R1, hard_gate) | hard_gate | JD and careers page disagree; your constraint is unknown | A gate that could decide whether this is worth pursuing | Not applicable: this asks whether the gate is met, not for a workaround | The employer's written confirmation | `[grounded]` the two sources |
| G2 | Recommendations to product (R8b, must_have) | discovery | Underwriting-facing work is clear; product-facing work is not stated | The JD names both audiences, so a gap here shows up in the interview | A pricing change you proposed that product or a proposition team acted on; a test result that changed a product feature or tier | A recommendation memo or readout, sanitized | `[grounded]` your background silence; `[generic]` roles pairing the two audiences ask for it |
| G3 | Model monitoring (R7, must_have) | discovery | "Maintained" is stated, but not what was tracked or what it triggered | Monitoring is in the JD, and the hiring manager has spoken publicly on it | Drift or stability reports; actual-versus-expected tracking; refits or factor changes triggered by monitoring | A sanitized monitoring report or dashboard screenshot | `[grounded]` the JD; `[inferred]` weight from the manager's talk |
| G4 | Pet-specific rating knowledge (R10, preferred) | transferability | A motor GLM and price tests carry over as method. Pet-specific rating factors are not evidenced. | A preferred row, so it is a minor risk. The honest framing is a strength with a stated limit. | Any work on a small or sparse book, or on a product with inflation-linked claims costs | A note on how you handled sparse data | `[inferred]` from your motor work; `[generic]` that pet books differ from motor |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern contradicts the posting (see R1) | risk_signal | medium | JD "Fully remote (UK)"; careers page "Leeds office four days a week" | One source may be stale, or the role may have changed. I rated it `medium` and not `high` because I don't know your constraint. | `[inferred]` from two sources disagreeing | Is this role fully remote, or based in the Leeds office four days a week? | unresolved |
| RR2 | Thin footprint beyond the employer's own pages | unknown | — | "Accepting applications. Senior Pricing Analyst…" | The company may be small or young. A search for the name plus "pet insurance" returned nothing. | `[generic]` pattern for firms of this size, not a claim about Brindlemoor | What is the company's stage, size and funding? | unresolved |
| RR3 | Salary withheld | unknown | — | None: the JD and the fetched page state no figure | The figure may sit inside or outside the £52,100 to £64,900 interquartile range | `[inferred]` from the withheld figure against the `[generic]` band | What salary range is budgeted for this post? | unresolved |
| RR4 | Team and decision rights unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | You may be the sole analyst, with no stated resources | `[inferred]` from the JD's ownership language against its silence on team | Who else works on pricing analytics, and which rating changes does this role decide versus recommend? | unresolved |
| RR5 | Reports to a pricing specialist | positive_signal | — | "reports to the Director of Pricing" | The line is to someone with a pricing-analytics background and a public interest in model monitoring | `[grounded]` careers page and profile search result | How does the team review rating-model performance today? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with three lines, each in your own words: "Built and maintained the GLM rating model for the young-driver book"; "Ran 14 price tests last year with the underwriting team"; "Present the quarterly pricing review to the head of underwriting". No outcomes or metrics are added, because you gave none. | R4, R6, R5 | `[grounded]` your background | resume_edits_pending_approval |
| E2 | Cover-note line: "I have not worked on pet insurance. I bring five years of pricing analytics at a UK motor insurer, including a GLM rating model I built and maintained and 14 price tests run with underwriting last year." | R10 | `[grounded]` your background | pending your approval |
| A1 | Confirm the working pattern with the employer through the careers page before investing in the application | R1, RR1 | `[grounded]` RR1 | pending your approval |
| A2 | If your monitoring answer (G3) is substantive, put it near the top of the CV and cover note. Her public talk was on monitoring, but add nothing about monitoring until you confirm it. | R7, RR5 | `[inferred]` from the manager's talk topic | pending your approval |
| A3 | Ask RR2 to RR5's questions verbatim in the interview | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance" (no results) and "Brindlemoor insurtech careers Senior Pricing Analyst". Fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). It confirmed the posting is live and surfaced the working-pattern contradiction (R1, RR1). The fetched page carried one short paragraph, with no salary or requirements, so the company's stage and size are not established (RR2). |
| 2. Role-family sweep | yes | Searched "senior pricing analyst pet insurance UK remote salary", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). It moved the market calibration row and RR3. Only the search snippet was read. |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga). It moved the manager rows in Role reality, RR5 and A2. Only the search snippet was read. |

If you'd like these findings as a saved `tuesday-dossier.md`, say so and I'll write it.

## Upgrade menu

- Stage: I assumed you are evaluating, not yet applying.
- Your working-pattern requirement and salary floor → R1 and RR3 close, and the status likely becomes `go` or `no_go`.
- Your CV or a prior resume → the E1 edits are checked against your actual text, and any line your CV dropped can be recovered.
- A sanitized GLM factor summary, monitoring report, or price-test readout → R4, R6 and R7 can move from `medium` and `low` to `high`.
- A product-facing recommendation you made → R8b resolves.
- A deeper research pass on Brindlemoor (funding, leadership, hiring patterns, recent news; up to 5 more searches and 2 more fetches) → RR2 resolves. Say the word and it runs.

**Questions**

G1 — Is fully remote a firm requirement for you, or would four days a week in a Leeds office work?
G2 — Have you made a pricing recommendation that went to a product or proposition team, and what happened with it?
G3 — After the young-driver GLM went live, what did you track on it, how often, and what did you change because of it?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.