Still working through the skill's reference files before I write the assessment. The posting is read, and I'm on the output rules and the worked report next.
**Yes, worth applying to, on conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol, two office days), R2 (£61,500–£67,000 pay)
- `must_have`: direct: R3, R4, R6 · adjacent: R5 (SQL and spreadsheet modelling), R7 (owning a forecast) · unclear: R8b (finance on revenue data) · absent: R8a (billing data)

R7 (`medium`): a credible bridge with its limit named; R8a: nothing in what you've told me touches billing data; R8b (`low`): a lead worth probing, nothing confirmed yet.

**Opportunity ledger.** Quillfield exists as described and the stated pay band sits inside the role-family range (RR1, RR4). The open items are where the posting appears (RR2), who owns billing data and the forecast and with what support (RR3), and what the options are worth (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol, two office days), R2 (£61,500–£67,000 pay); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. R1 and R2 are checked against your own limits.
  2. RR3 gets a concrete answer on who owns billing data and the forecast, and what support exists. This matters because R7 is adjacent and R8a is absent.
  3. RR2 is resolved: Quillfield confirms the role is open.
  4. R7 is framed as adjacent and R8a stated plainly, never claimed.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants, founded 2018 in Bristol, 96 employees, Series A (£11M) closed April 2025 | `[grounded]` quillfield.co.uk/about (search snippet) |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting for sales and finance; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern | Bristol, hybrid, two office days a week | `[grounded]` posting |
| Pay | £61,500–£67,000 plus share options; option terms not stated | `[grounded]` posting |
| Market calibration | Median base £64,200 for a UK B2B software revenue operations lead (interquartile range £57,800–£70,400, n=438). The posted band sits inside that range around the median. The figure is UK-wide, not Bristol-specific, and is a market pattern, not this employer's offer | `[generic]` Ledgerline 2026 pay guide (snippet only); `[grounded]` the posting's own band |
| Hiring manager | Tamsin Achebe is listed as Head of Revenue Operations at Quillfield, previously four years as a sales operations manager at Corvane Payments. This agrees with what the recruiter told you | `[grounded]` public profile snippet |
| Scope read | A Lead may sit under an existing Head of Revenue Operations, so this could be a hands-on role in an established function rather than a first hire. The posting doesn't say | `[inferred]` from her title against the posting's silence on team and reporting line |
| First-year outcomes | Not stated | `[grounded]` posting silent |
| Unknowns | Billing system and who owns it today; who builds the forecast model now; team size; success measures; option terms | `[inferred]` from posting silence |
| Contradictions | None found between the posting and Quillfield's about page | `[grounded]` posting and about page |

## Evidence map

Your background is typed prose, so it counts as self-report at the same standing as a CV, which caps confidence at `medium` for now.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two office days a week | hard_gate | unclear | none | hard_gate | You haven't stated a location or office-day limit, so the term can't be checked | `[grounded]` posting term; your silence | Closing question tagged R1/R2 |
| R2 | £61,500–£67,000 plus options | hard_gate | unclear | none | hard_gate | You haven't stated a pay floor, so the band can't be checked | `[grounded]` posting term; your silence | Closing question tagged R1/R2 |
| R3 | 4+ years in revenue ops, sales ops or similar at a B2B software company | must_have | direct | medium | none | You state 5 years in sales operations, the last 2 running revenue operations for the UK team. No inspectable artifact yet. Whether a B2B payments company counts as a software company is the open point | `[grounded]` your background; `[inferred]` on the sector read | Describe the employer's product truthfully in the application |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified is a specific claim. The certificate record hasn't been inspected | `[grounded]` your background | Offer the certification record to raise it to `high` |
| R5 | Strong SQL and spreadsheet modelling | must_have | adjacent | medium | discovery | SQL weekly and Excel daily are confirmed usage. "Strong" and "modelling" (forecast or scenario models) aren't shown | `[grounded]` your background | A sanitized query or workbook would settle it |
| R6 | Build the pipeline and renewal reporting that sales and finance run on | must_have | direct | medium | none | You rebuilt the pipeline and renewal dashboards. Whether finance used them isn't stated (see R8b) | `[grounded]` your background | A sanitized dashboard screenshot would raise it to `high` |
| R7 | Experience owning a forecast; run the quarterly forecast with the CFO | must_have | adjacent | medium | transferability | You run the monthly pipeline review with your sales director. That feeds a forecast, but you've never owned the company forecast and finance did. The limit is the number, the finance audience and CFO-level reporting | `[grounded]` your background | G2 |
| R8a | Working with finance on billing data (the posting also has you own billing data) | must_have | absent | none | capability | You state you've never worked on billing data. This is a stated gap, not an inferred one | `[grounded]` your statement | Closure path in G3; carry it as a material risk |
| R8b | Working with finance on revenue data | must_have | unclear | low | discovery | The renewal dashboards touch revenue figures, but finance's involvement isn't stated. This is a lead, not a claim | `[inferred]` from the renewal dashboards against silence on finance | G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Finance and revenue data (R8b, must_have) | discovery | Renewal dashboards exist, but the data's source and finance's role aren't stated | Resolving it could lift R8b from `unclear` and narrow the combined finance requirement | Renewal figures reconciled against finance's numbers; ARR or churn reports agreed with finance; a finance contact who signed off your dashboard definitions | A dashboard definition sheet, a reconciliation note, a month-end deck | `[grounded]` silence on finance involvement |
| G2 | Forecast ownership (R7, must_have) | transferability | A monthly pipeline review with the sales director. Finance owned the forecast | The posting says you will run the quarterly forecast with the CFO. The bridge is the pipeline input and the limit is owning the number | Supplying coverage or conversion assumptions to finance; flagging a forecast miss; a model finance adopted | A sanitized pipeline-coverage view or forecast-accuracy sheet | `[grounded]` your statement; `[grounded]` posting wording |
| G3 | Billing data (R8a, must_have) | capability | No billing-data work | Billing data is part of the stated mandate, so this is a material risk and not a polish item | Closure paths: learning how the billing system's data feeds renewals; one small reconciliation project at your current employer; asking Quillfield for a sample extract before an offer | Anything you build in a closure project | `[grounded]` your statement; `[generic]` closure paths |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer matches the posting's description | positive_signal | — | "Founded 2018 in Bristol; 96 employees. Series A (£11M) closed in April 2025." | Quillfield is a real, funded invoicing software company | `[grounded]` quillfield.co.uk/about | Who is on the revenue operations team today, and where does this role sit? | noted |
| RR2 | Posting not seen on Quillfield's own site | unknown | — | "Revenue Operations Lead, Quillfield. Bristol, hybrid" | The role may be listed only on the job board. My fetch tried one guessed address and found no page, so the careers page may simply sit elsewhere | `[grounded]` fetch result; `[inferred]` on the reason | Is this role open, and where is it listed on your own careers site? | unresolved |
| RR3 | Scope with no stated team, systems owner or success measures | unknown | — | "own our CRM and billing data... run the quarterly revenue forecast with the CFO" | The role may carry billing data and forecast accountability without stated support, and may sit under an existing Head of Revenue Operations | `[inferred]` from the posting's scope language against its silence | Who owns the billing system and the forecast model today, what support does this role have, and what does success look like at twelve months? | unresolved |
| RR4 | Pay stated and in range | positive_signal | — | "£61,500–£67,000 plus share options" | The band is not a seniority-pay mismatch against the role-family range | `[grounded]` posting figure; `[generic]` Ledgerline band, UK-wide | What decides where in the band an offer lands? | noted |
| RR5 | Share options unquantified | unknown | — | "plus share options" | Their value depends on grant size, vesting and strike, none of which the posting gives | `[inferred]` from posting silence | What is the typical option grant for this role, and on what vesting and strike terms? | unresolved |

## Application plan

All rows are proposed and pending your approval, including the prose advice. Nothing here is final until you say so, and any resume wording stays `resume_edits_pending_approval`.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the resume with five years in sales operations, two running UK revenue operations, the Salesforce admin certification, and the rebuilt pipeline and renewal dashboards. State the monthly pipeline review as run with the sales director. Do not describe it as forecast ownership | see R3, R4, R6, R7 | `[grounded]` your background | pending your approval |
| P1 | Present R7 as a bridge with its limit named: pipeline input to a forecast finance owned. Say plainly that you haven't worked on billing data (R8a) | see R7, R8a | `[grounded]` your statements | pending your approval |
| P2 | Write to Tamsin Achebe with specifics from your own pipeline-review work rather than titles, since her public background includes four years in sales operations | her profile snippet | `[inferred]` from her public career pattern | pending your approval |
| W1 | A one-page sanitized pipeline-coverage or forecast-input sheet | see R5, R7 | `[grounded]` R5, R7 rows | pending your approval |
| A1 | Ask the recruiter to confirm the role's listing and the billing and forecast ownership before investing in the loop | see RR2, RR3 | `[grounded]` register | pending your approval |
| Q1 | Ask the verification questions of RR3 and RR5 verbatim in interviews | the register doubles as preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company Bristol", which returned "About Quillfield" (quillfield.co.uk/about). Fetched quillfield.co.uk/careers, which returned no page. Moved role reality's organization row, RR1 and RR2 |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary Bristol B2B software", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved the market calibration row and RR4 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Snippet only, no page fetched. Moved the hiring-manager and scope-read rows and P2 |

I can turn this into a `tuesday-dossier.md` file if you'd like one.

**Upgrade menu**
- Your CV or the certification record would raise R3 and R4 toward `high`, and show whether any gap type is a presentation problem.
- A sanitized dashboard screenshot would do the same for R6.
- A sanitized query or forecast-input sheet would settle R5 and strengthen R7.
- A link to the role on Quillfield's own careers page, or the recruiter's email domain, would close RR2.
- The option terms would close RR5.
- A deeper research pass on Quillfield (funding and leadership changes, public employee reports, recent news; up to 5 more searches and 2 more fetches) will run if you say the word.

**Questions**
1. R1/R2 — Does Bristol with two office days a week and £61,500–£67,000 work for you, or is there a location or pay limit it breaks?
2. G1 — When you built the pipeline and renewal dashboards, did you use revenue or invoice figures from finance? If so, which numbers, who in finance, and did finance use the dashboards?
3. G2 — What have you personally contributed to the company forecast, such as assumptions you supplied, a miss you flagged, or a model finance adopted? Who made the final call?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.