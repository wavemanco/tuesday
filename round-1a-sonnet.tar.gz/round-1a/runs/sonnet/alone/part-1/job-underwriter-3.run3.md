I've read the underwriting rules and am now running two quick public searches: one to check that Novaline exists as described, and one for market pay and scope for this title.
**Status: `no_go`.** This isn't worth pursuing. R1 and R2 are hard gates and both fail. The feeling that something is off is also backed by the posting's own wording (RR3 to RR6).

## Decision snapshot

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (On-site in Austin five days a week), R2 (Base compensation $70–85k)
- `must_have` — direct: R4, R5 · unclear: R3 (8+ years growth leadership)
- `important` — unclear: R6 (SEO and content), R7 (Brand and PR), R8 (Team of one)
- `preferred` — unclear: R9 (Partnerships), R10 (Sales ops)

R1, R2 — failed gates no wording can fix; R4, R5 — the paper match you describe holds on paid and lifecycle; R3 — your nine years are in growth, with the leadership share not stated.

**Opportunity ledger.** The terms are stated plainly (RR8), but the role looks underpriced and overloaded. RR3 covers pay and equity against scope, RR4 a team of one across many functions, RR5 an always-on expectation, and RR6 success metrics left undefined. RR7 (the employer) is unchecked.

- **Hard gates:** failed: R1 (On-site in Austin five days a week), R2 (Base compensation $70–85k)
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`)
- **What would change this:** R1 would need to allow remote work from Portland, and R2 would need a base at or above your $150k. The posting says "no exceptions" on location and gives no sign the pay range is flexible.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` the posting's own claims; not independently checked (RR7) |
| Mandate | Own revenue growth end to end: paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Team and reporting | Team of one to start; reports to the CEO, dotted line to the board | `[grounded]` posting |
| Working pattern | On-site in Austin five days a week, no exceptions; evenings and weekends "when it matters" | `[grounded]` posting |
| Pay | $70–85k base plus "meaningful equity upside", with no equity figures given | `[grounded]` posting |
| Success measures | None stated; "success metrics will evolve as we learn" | `[grounded]` posting |
| Scope read | Seven functions with no team, which is more than one person normally covers well | `[inferred]` from the posting's function list against "team of one" |
| Market calibration | Not established. The role-family sweep did not run, so no pay band is stated | `[grounded]` the posting's figure only; no band available |
| Unknowns | Equity size, vesting and strike; marketing budget; headcount plan; who defines success | — |
| Contradictions | A head-level title and "8+ years" sit beside a team of one and $70–85k base. This is a tension in the terms, not a conflict between sources | `[inferred]` from the posting's title, seniority and pay terms |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Austin five days a week, no exceptions | hard_gate | hard_gate_fail | high | hard_gate | Your constraint is remote-only from Portland with no relocation, stated plainly and confirmed. The posting rules remote out | `[grounded]` posting and your statement | none; only the employer changing terms resolves it |
| R2 | Base compensation $70–85k | hard_gate | hard_gate_fail | high | hard_gate | Your floor is $150k base. The top of the posted range is below it | `[grounded]` posting and your statement | none; only the employer changing terms resolves it |
| R3 | 8+ years growth leadership | must_have | unclear | medium | discovery | You say 9 years in growth and growth lead, then Head of Growth, with teams of 3–7. How many of those years were in a lead role isn't stated, so the lower reading applies. This is a length-of-experience requirement, not a gate | `[grounded]` your background as typed; read as CV-equivalent | confirm years in lead roles if you proceed |
| R4 | Paid acquisition | must_have | direct | medium | none | You say you owned paid and controlled the budget while scaling $8M to $40M ARR over three years. Specific, but nothing inspectable yet | `[grounded]` your background as typed | none |
| R5 | Lifecycle and CRM | must_have | direct | medium | none | You say you owned lifecycle and are deep in Braze. Specific, with no inspectable artifact | `[grounded]` your background as typed | none |
| R6 | SEO and content | important | unclear | low | discovery | Your background doesn't mention SEO or content ownership | `[grounded]` silence in your background | see G1 |
| R7 | Brand and PR | important | unclear | low | discovery | Your background doesn't mention brand or PR | `[grounded]` silence in your background | see G2 |
| R8 | Operating with no team ("team of one to start") | important | unclear | low | discovery | You built teams of 3–7. Whether you've run growth hands-on without one isn't stated | `[grounded]` your background as typed | see G3 |
| R9 | Partnerships | preferred | unclear | low | discovery | Not mentioned in your background | `[grounded]` silence in your background | see G4 |
| R10 | Sales ops | preferred | unclear | low | discovery | Not mentioned in your background | `[grounded]` silence in your background | see G4 |

## Gap recovery queue

These gaps don't change the decision. They matter only if you proceed against it.

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO and content (R6, important) | discovery | No SEO or content work described | The posting bundles it into one owner's remit | Owning organic traffic targets, a content calendar, or an agency relationship | A traffic report or a content plan | `[grounded]` silence in your background |
| G2 | Brand and PR (R7, important) | discovery | No brand or PR work described | Same bundle, and a different skill set from paid and lifecycle | Launch announcements, press handling, brand guidelines you set | A press list or a brand brief | `[grounded]` silence in your background |
| G3 | Working without a team (R8, important) | discovery | Teams of 3–7 are described, with no solo stretch | The posting makes this the starting condition | Early-stage stints before hiring, or periods covering several channels yourself | A role history or a channel ownership list | `[grounded]` background as typed |
| G4 | Partnerships and sales ops (R9, R10, preferred) | discovery | Neither is described | Preferred only, so a minor risk | Affiliate or co-marketing deals; CRM and pipeline reporting for sales | A partner agreement or a pipeline dashboard | `[grounded]` silence in your background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | On-site five days a week against your remote-only constraint (R1) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions." | The terms conflict with a stated non-negotiable of yours, so it is a red flag for you whatever the market thinks of it | `[grounded]` posting and your statement | Is the five-day Austin requirement fixed for this role? | confirmed |
| RR2 | Base below your floor (R2) | red_flag | high | "$70–85k base" | The posted range sits below your stated $150k minimum | `[grounded]` posting and your statement | Is the posted base range the whole cash range for this role? | confirmed |
| RR3 | Pay and equity against the seniority and scope asked | risk_signal | medium | "8+ years growth leadership required"; "$70–85k base plus meaningful equity upside" | Years and mandate may be priced below what the scope buys; I take the lower severity because no market band was established | `[inferred]` from the posting's seniority and scope against its pay | What are the equity percentage, vesting and strike price? | unresolved |
| RR4 | Many functions with no team or stated resources | risk_signal | medium | "You will be a team of one to start — we believe in players who don't need a bench." | Responsibility for several full roles may come without budget or decision rights | `[inferred]` from the posting's function list against its silence on budget | What budget and headcount are committed for the first year? | unresolved |
| RR5 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Out-of-hours work may be routine, not occasional | `[inferred]` from the posting's phrasing | How often did the team work evenings or weekends last quarter? | unresolved |
| RR6 | No success measures on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | Accountability to the CEO and board with no fixed definition of success | `[inferred]` from the posting's silence on first-year outcomes | What does success look like at 90 days and at 12 months? | unresolved |
| RR7 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The company may be real and merely small, or the posting may be stale; the check could not run | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site? | unresolved |
| RR8 | Pay, location and schedule terms stated openly | positive_signal | — | "no exceptions" | The posting lets you see the mismatch before investing time | `[grounded]` posting | — | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't invest in an application | see R1, R2, RR1, RR2 | `[grounded]` the two failed gate rows | pending your approval |
| A2 | If you proceed anyway, put RR3 to RR7's questions to the company before any interview loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

I'm proposing no resume or outreach wording. Nothing here would be worth sending.

## Evidence status

Verified: none yet. Your background as typed is at CV-equivalent standing, so it is a set of leads for verification, not proof.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Austin Series A"; the search was refused. It would have fed role reality's organization and contradictions rows and RR7 |
| 2. Role-family sweep | unavailable | Searched "Head of Growth salary startup Series A base compensation 2026"; the search was refused. It would have fed the market calibration row and RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given, only "the CEO" |

I'm offering a `tuesday-dossier.md` file of this assessment if you want one to keep.

## Upgrade menu

- Search access, so the company check and the pay-band sweep can run → RR7 closes or hardens, and RR3 gets a market band to compare against.
- The CEO's name → role reality's scope read, and the positioning in the application plan.
- Your years in lead roles (R3) and any SEO, brand or solo-operation history (R6 to R10) → those rows move off `unclear`. This only matters if you decide to proceed.

No questions this turn. Nothing you could answer would move R1 or R2.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.