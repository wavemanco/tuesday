I'm reading the skill's reference files so the assessment follows its required format. I'll run the remaining reads as separate commands.
## Decision snapshot

**No. R1 and R2, both hard gates, fail on the posting's own terms. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: `hard_gate_fail`: R1 (On-site in the Austin office 5 days a week), R2 (Base $70–85k)
- `must_have`: `direct`: R4, R5, R6 · `unclear`: R3 (8+ years growth leadership), R7 (SEO/content), R8 (brand and PR), R9 (partnerships), R10 (sales ops)
- `important`: `unclear`: R11 (Team of one to start)

R1 and R2: the posting's terms conflict with your location and pay constraints; R4 (`medium`): budgeted scaling evidence from your own account; R7, R8, R9, R10: your background is silent on them, which is not the same as negative.

**Opportunity ledger.** Apart from your fit, the role reads thin and heavy:
- A long function list for a team of one, at a base the employer sets (RR3, RR4).
- An always-on tone (RR5) and success metrics that will "evolve" (RR6).
- Budget and equity terms left unstated (RR7, RR8).
- An employer nothing here has verified (RR9).
- One positive: the CEO reporting line (RR10).

- **Hard gates:** failed: R1 (On-site in the Austin office 5 days a week), R2 (Base $70–85k)
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`)
- **What would change this:** R2 would need a base at or above your $150k floor, and R1 would need remote work from Portland permitted. Both are the employer's to change, and the posting says "no exceptions" on R1.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, "e-commerce enablement startup, Series A, profitable since day one" | `[grounded]` JD header. These are the employer's own claims, and nothing here has verified them |
| Mandate | "Own all revenue growth end to end": paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` JD |
| Resources | "a team of one to start"; no budget, headcount or contractor support stated | `[grounded]` JD states the team of one and is silent on budget |
| Reporting | CEO, "with a dotted line to the board" | `[grounded]` JD |
| Working pattern | On-site in Austin 5 days a week, "no exceptions"; "evenings and weekends when it matters is just who we are" | `[grounded]` JD |
| Compensation | "$70–85k base plus meaningful equity upside"; equity is unquantified | `[grounded]` JD |
| First-90-days and first-year outcomes | Not stated: "success metrics will evolve as we learn" | `[grounded]` JD; nothing is inferred |
| Scope read | A wide set of specializations under one title with no stated support, read against "team of one" | `[inferred]` from the function list against the team-of-one statement |
| Market calibration | Not established. The role-family sweep did not run, so no band is stated | `[grounded]` the JD's own $70–85k figure; no market figure available |
| Unknowns | Budget and decision rights; equity size; whether customers are merchants (B2B) or consumers, against your B2C subscription background; whether the posting is live | `[grounded]` JD silence |
| Contradictions | None found between the JD and anything you provided; no careers page was available to compare | `[grounded]` inputs in hand |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in the Austin office 5 days a week, "no exceptions" | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your statement ("remote-only … in Portland and I'm not relocating"), which is specific and your own. Fit fails because the JD requires daily on-site presence and rules out exceptions | `[grounded]` JD and your stated constraint | Surface only. Wording cannot solve it; only you or the employer changing terms does |
| R2 | Base $70–85k | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated floor of at least $150k base. Fit fails because the top of the posted range is below it | `[grounded]` JD and your stated constraint | Surface only; the employer would have to change the range |
| R3 | 8+ years growth leadership | must_have | unclear | medium | discovery | You state 9 years in growth, then Growth lead, then Head of Growth. Years held in lead or head titles aren't stated, so the leadership reading stays open. Ambiguity resolves downward. Years-of-experience requirements are often screened literally | `[grounded]` your prose background, unprobed so capped at `medium`; `[generic]` on screening | Note the years in lead or head titles (moot unless R1 and R2 change) |
| R4 | Own revenue growth, with budget responsibility | must_have | direct | medium | none | "Scaled one company from $8M to $40M ARR over three years with a budget I controlled." Budget size isn't stated, and the employer sells to e-commerce, while your two companies are B2C subscription. That is the limit on how far the claim carries | `[grounded]` your prose background | A board deck or dashboard export showing the $8M-to-$40M path would raise it to high |
| R5 | Paid acquisition | must_have | direct | medium | none | You state you owned paid at both companies | `[grounded]` your prose background | An account export or spend summary would raise it |
| R6 | Lifecycle/CRM | must_have | direct | medium | none | You state you owned lifecycle and are deep in Braze | `[grounded]` your prose background | A Braze program export would raise it |
| R7 | SEO/content | must_have | unclear | none | discovery | Your background doesn't mention it. It may exist unmentioned | `[grounded]` background silence | See G2 |
| R8 | Brand and PR | must_have | unclear | none | discovery | Your background doesn't mention it | `[grounded]` background silence | See G2 |
| R9 | Partnerships | must_have | unclear | none | discovery | Your background doesn't mention it | `[grounded]` background silence | See G2 |
| R10 | Sales ops | must_have | unclear | none | discovery | Your background doesn't mention it | `[grounded]` background silence | See G2 |
| R11 | Team of one to start, executing without a bench | important | unclear | low | discovery | You built and managed teams of 3–7. Solo hands-on execution of every function isn't stated | `[grounded]` your prose background | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Years in leadership titles (R3, must_have) | discovery | 9 years in growth stated; lead and head years not split out | The posting asks for 8+ years of leadership. It matters only if R1 and R2 change | Dates of the Growth lead promotion and the Head of Growth start | Dated titles on a CV or LinkedIn export | `[grounded]` background; `[inferred]` that it matters only if the gates move |
| G2 | SEO/content, brand/PR, partnerships, sales ops (R7, R8, R9, R10, must_have) | discovery | Background is silent on all four | The JD bundles these into the mandate, so unevidenced ones become interview probes | Content or SEO programs you directed, press or brand launches, co-marketing or affiliate deals, lead routing or CRM-to-sales handoffs | A content calendar, a traffic report, a partnership agreement, a pipeline report | `[grounded]` background silence; `[generic]` that wide-scope growth roles tend to probe the functions a candidate hasn't evidenced |
| G3 | Solo execution (R11, important) | discovery | Team-building evidence only | The role starts as a team of one | Stretches where you executed hands-on with no team | A campaign you personally built and ran | `[grounded]` background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posted base is below your floor (R2) | red_flag | high | "$70–85k base plus meaningful equity upside" | The range is the employer's statement of what this role pays, and it fails your $150k floor as written | `[grounded]` JD and your stated floor | Is the $70–85k base range firm for this role, or is there approved room above it? | confirmed |
| RR2 | Daily on-site presence against remote-only (R1) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions." | The employer states no flexibility, and you are remote-only and in Portland | `[grounded]` JD and your stated constraint | Is the on-site requirement tied to this role specifically, or could remote work ever be considered? | confirmed |
| RR3 | Pay may not match seniority and mandate | risk_signal | medium | "8+ years growth leadership required"; "dotted line to the board"; "$70–85k base" | The base may sit below what this seniority and mandate normally command. It is unsized because the market sweep didn't run, which keeps it at medium | `[generic]` pattern, not a market figure | How was the base range set, and what roles was it benchmarked against? | unresolved |
| RR4 | Many specializations, one person, no stated support | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops. You will be a team of one to start" | Several full roles folded into one title, with no stated budget or contractors to cover them | `[inferred]` from the function list against the team of one and the budget silence | Which of these functions get budget or agency support in year one, and which would I execute myself? | unresolved |
| RR5 | Out-of-hours expectation | risk_signal | low | "evenings and weekends when it matters is just who we are" | Out-of-hours work may be routine. "When it matters" keeps this below medium | `[inferred]` from the "just who we are" framing | In the last quarter, how many evenings or weekends did the team work, and what triggered them? | unresolved |
| RR6 | Success undefined on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | You would be accountable for revenue with no fixed definition of success | `[inferred]` from "own all revenue growth" against this statement | What does success look like at 90 days and at 12 months, and who decides when the metrics change? | unresolved |
| RR7 | Budget and decision rights not stated | unknown | — | "Report to the CEO with a dotted line to the board" | Resources and authority may be uncommitted | `[inferred]` from the JD's silence | What marketing budget and hiring authority come with this role? | unresolved |
| RR8 | Equity unquantified | unknown | — | "meaningful equity upside" | No grant size is given, so the equity can't offset the pay gap on current information | `[inferred]` from the absence of a figure | What is the grant as a share of fully diluted equity, with vesting and strike terms? | unresolved |
| RR9 | Employer and posting unverified | unknown | — | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | Stage and profitability are the posting's own claims; nothing in hand attributes Novaline or a live posting to a real entity | `[grounded]` JD claim; no verifying source in hand | Can you point me to this role on your careers site, and who would I interview with? | unresolved |
| RR10 | Senior reporting line | positive_signal | — | "Report to the CEO with a dotted line to the board" | Senior access and visibility | `[inferred]` from the stated reporting line | Who sits on the board, and how often would this role present to them? | noted |

## Application plan

Every row is proposed and pending your approval. No resume edits or outreach text are proposed, because nothing here asks you to say anything new about your history.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't spend application effort on this role | R1 and R2 fail on the posting's own terms; RR1, RR2 | `[grounded]` map and register rows | pending your approval |
| A2 | If you engage anyway, put RR1 and RR2's questions to the employer before anything else, and stop if the answers hold | Cheapest test of whether either gate can move | `[grounded]` register | pending your approval |
| A3 | Filter future searches to postings that state remote work and a base at or above $150k | Avoids the same two failures upfront | `[generic]` search practice | pending your approval |

## Evidence status

Verified: R1 and R2 claims (the constraints you stated), in the sense that the claim is verified; their fit stays `hard_gate_fail`. Unverified leads: the experience claims behind R3, R4, R5, R6 and R11, which are prose background and not yet probed. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Series A Austin careers Head of Growth"; the call was refused. It would have moved role reality's organization and contradictions rows and RR9 |
| 2. Role-family sweep | unavailable | Searched "Head of Growth startup salary range 2026 base compensation Series A"; the call was refused. It would have moved the market calibration row and RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I can write this up as `tuesday-dossier.md` if you want to keep it; say the word.

## Upgrade menu

- Search permission would run targets 1 and 2: whether Novaline and the posting are real (RR9) and a market band for RR3.
- Dated lead and head titles → R3 resolves.
- Evidence on SEO/content, brand/PR, partnerships or sales ops → R7, R8, R9, R10 move off `unclear`.
- A deck or dashboard export showing the $8M-to-$40M path, or a Braze or paid-account export → R4, R5, R6 can reach `high`.
- The CEO's name → target 3 would run, and the application plan could say which story to lead with.
- The employer's answers on RR1, RR2, RR7 and RR8 → R1 and R2 are the only rows that could change the status.

Questions: none this turn. R1 and R2 fail as stated, so no answer on R3 or R7 through R11 would move the status.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.