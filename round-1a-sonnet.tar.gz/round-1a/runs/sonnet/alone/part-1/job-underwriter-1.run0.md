I'll read the skill's reference files first.
I've finished reading the skill's rules. Next I'm checking whether Harborlight Health and this posting can be verified, and what the market pays for this role. After that I'll write the assessment.
**Short answer: yes, apply. You're a fit on the core of the role, and the only real holdback is that I couldn't verify the employer.**

## Decision snapshot

**Yes, apply once the posting verifies. R1, R2, R3, R4 and R6 land `direct`, and R5, R7b, R8 and R9 are the soft spots. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R6 · adjacent: R5 (metrics layer)
- `important` — direct: R7a · unclear: R7b (clinicians), R8 (mentor two junior analysts)
- `preferred` — adjacent: R9 (healthcare data, HIPAA)

R5 (`medium`) — governed Looker work bridges to a metrics layer, limit named; R7b and R8 — your background is silent, so they are discovery gaps and not capability gaps; R9 (`medium`) — a GDPR/CCPA bridge, not HIPAA experience.

**Opportunity ledger.** The role is concretely scoped (RR4) and sits beside a possible bundling of several jobs under one title (RR3). The employer is not established from here (RR1), and pay and location are not in the pasted text (RR2).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting verifies live on Harborlight's own careers site (RR1); (2) your pay and location constraints are checked against the role (RR2); (3) the HIPAA bridge is framed as adjacent and never as healthcare experience (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up of about 400 people at Series C, with a care-navigation app | `[grounded]` JD header; existence not verified |
| Mandate | Own product analytics for the app: metrics layer, A/B tests, self-serve Looker dashboards, PM and clinician partnership, mentoring two junior analysts | `[grounded]` JD |
| Scope read | A senior individual-contributor post with light people leadership (two juniors), covering the metrics, experimentation, BI and mentoring tracks | `[inferred]` from the duty list and the "two junior analysts" line |
| Market calibration | Not calibrated: no role-family search ran, so I have no band and won't quote one from memory | `[generic]` degraded section, upgrade menu says what would fill it |
| Unknowns | Pay; location or remote policy; who owns the data models under the metrics layer; how clinicians work with the analytics team | — |
| Contradictions | None between the JD and your background; the employer's own pages were not checked | `[grounded]` JD against your stated background |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years at a consumer-subscription company, so it clears the stated years. Confirmed prose, with no document inspected yet | `[grounded]` your stated background | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake is confirmed. "Expert" is the level to evidence; roles like this often screen SQL live | `[grounded]` your background; `[generic]` that SQL is commonly screened live | a sanitized query or a data-model sample would raise it to `high` |
| R3 | Experiment design at scale | must_have | direct | medium | none | You designed and ran the experimentation program: 30+ tests a year, including the pricing test behind an 11% retention lift. No readout inspected, so expect a probe on method | `[grounded]` your background | a sanitized experiment readout would raise it to `high` |
| R4 | Looker or a similar BI tool; self-serve dashboards | must_have | direct | medium | none | You built the Looker instance from scratch with 40+ governed dashboards, matching the JD's tool | `[grounded]` your background | a sanitized dashboard screenshot would raise it to `high` |
| R5 | Define and maintain the metrics layer | must_have | adjacent | medium | discovery | Governed dashboards and a monthly metrics memo are close. Limit: nothing says you owned metric definitions in a semantic layer (LookML or similar) | `[grounded]` your background; `[inferred]` that definition work likely exists, unconfirmed | see G1 |
| R6 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | A monthly metrics memo the exec team reads and a monthly VP Product presentation | `[grounded]` your background | the memo, sanitized, would raise it to `high` |
| R7a | Partner with product managers to turn analysis into roadmap decisions | important | direct | medium | none | Monthly presentation to the VP Product; the roadmap link itself is not stated | `[grounded]` your background | none |
| R7b | Partner with clinicians | important | unclear | none | discovery | Nothing stated. You may have worked with comparable domain experts, but that is not in your background | `[grounded]` your background's silence | see G4 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Your background doesn't mention mentoring or managing | `[grounded]` your background's silence | see G2 |
| R9 | Healthcare data experience (HIPAA) a plus | preferred | adjacent | medium | transferability | GDPR/CCPA consumer PII handling and a consent-state model in the warehouse. Limit: no healthcare data, and none of HIPAA's own rules | `[grounded]` your background; `[generic]` that HIPAA is a distinct regime from GDPR/CCPA | see G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R5, must_have) | discovery | Governed dashboards and a metrics memo, but no statement of who owned metric definitions | It's the first duty the JD lists, and R5 is the one `must_have` row below `direct` | Defining metrics like "active subscriber" or "retention" in LookML, dbt or a metrics doc; settling a definition dispute between teams; versioning a metric change | A metrics glossary, a LookML excerpt or a definitions doc, sanitized | `[grounded]` background silence on ownership; `[inferred]` that resolving it moves R5 to `direct` |
| G2 | Mentoring (R8, important) | discovery | No mention of mentoring or managing | The JD names two juniors, so this is a visible duty | Onboarding an analyst, reviewing others' queries, running an analytics office hour, supervising an intern | A mentoring plan or review checklist | `[grounded]` background silence |
| G3 | HIPAA and healthcare data (R9, preferred) | transferability | GDPR/CCPA PII handling and a consent-state model. Limit: no PHI, no HIPAA | It's preferred and not required, but it's the obvious interview probe for a health employer | The consent-state model, data minimization, access controls, de-identification, a privacy review you sat in | A sanitized consent-model diagram | `[grounded]` background; `[generic]` that health employers probe this |
| G4 | Clinician partnership (R7b, important) | discovery | Nothing stated | The JD pairs PMs with clinicians for roadmap decisions | Working with dietitians, nutritionists, medical or compliance advisors, or ops specialists to shape a metric or test | A write-up of a test designed with a domain expert | `[grounded]` background silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "digital-health scale-up, ~400 people, Series C" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay and location not in the pasted text | unknown | — | no pay or location line in the pasted text | The posting may state them elsewhere, or withhold them | `[inferred]` from the pasted text's silence | What is the budgeted salary range, and is the role remote, hybrid or on-site? | unresolved |
| RR3 | Several specializations under one title | risk_signal | low | "define and maintain the metrics layer, design and analyze A/B tests, build self-serve dashboards in Looker ... and mentor two junior analysts" | Metrics modeling, experimentation, BI and people leadership may be folded into one senior role. Severity is low because the scope could simply be a mature product-analytics post | `[inferred]` from the breadth of the duty list | Who owns the data models under the metrics layer today, and how is the analytics team organized? | unresolved |
| RR4 | Concrete responsibilities and a named team | positive_signal | — | "mentor two junior analysts" | The role has defined duties and some direct reports to mentor | `[grounded]` JD | What does success look like for the first year? | noted |

## Application plan

All rows and advice here are proposals pending your approval; nothing is final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the resume and summary with the experimentation program (30+ tests a year, the pricing test behind an 11% retention lift) and the Looker build (40+ governed dashboards) | see R3, R4 | `[grounded]` your stated background | pending your approval |
| E2 | Frame the consent-state model and GDPR/CCPA handling as adjacent privacy-data experience. Claim neither healthcare nor HIPAA experience | see R9 | `[grounded]` your background; prohibited claim: healthcare or HIPAA experience | pending your approval |
| E3 | Add a metrics-layer bullet only after G1 confirms what you owned | see R5 | `[grounded]` R5 row | pending your approval |
| W1 | Sanitize one experiment readout and one dashboard or metrics-memo page as inspectable samples | see R2, R3, R4, R6 | `[grounded]` R-row next actions | pending your approval |
| A1 | Verify the posting is live on Harborlight's own careers site before applying | see RR1 | `[grounded]` register | pending your approval |
| Q1 | Ask the verification questions of RR1 to RR4 verbatim in the loop | the register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Harborlight Health care navigation app careers Senior Product Analyst"; the search was refused, so nothing came back. It would have settled whether the employer exists as described and the posting is live (RR1, role reality's contradictions row) |
| 2. Role-family sweep | unavailable | Searched "senior product analyst digital health salary range US"; refused. It would have supplied the market calibration and the pay check in RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- Permission to run web search, so targets 1 and 2 can run: RR1 can clear or confirm, and role reality gets a market calibration.
- Sanitized artifacts (an experiment readout, a Looker dashboard screenshot, the metrics memo, a SQL sample) → R2, R3, R4 and R6 to `high`.
- An answer to G1 → R5 resolves, likely to `direct`.
- An answer to G2 and G4 → R8 and R7b leave `unclear`.
- The full posting or its link (pay, location) and your non-negotiables → RR2 and the hard-gates line become checkable.
- The hiring manager's name → role reality's scope read and which story the plan leads with.

I can save all of this as `tuesday-dossier.md` if you'd like.

Questions (at most three, each tied to its row):

- **G1** — Which metric definitions did you personally own in a governed layer (LookML, dbt, a metrics doc), who relied on them, and how did you handle changes?
- **G2** — Have you mentored or onboarded other analysts? What did you do, for whom, and for how long?
- **Constraints** — What are your non-negotiables for this role: pay floor, location or remote, and work authorization?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.