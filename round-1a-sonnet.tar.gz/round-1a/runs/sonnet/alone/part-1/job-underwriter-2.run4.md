**Short answer to "am I wasting my time?": No, the pivot is credible. This particular posting is a stretch because it calls 3+ years of PM experience a must-have and you've never held a PM title (R1a). Treat it as `conditional_go`, applied to through a warm route rather than a cold application.**

I couldn't run web research, so the employer, the market and pay band are unchecked.

## Decision snapshot

**Fit ledger.**

- `must_have` — direct: R3, R4a · adjacent: R1b (PM-type work over 3+ years), R2 (shipped API or platform products), R6 (roadmap ownership) · unclear: R5 (agile delivery) · absent: R1a (3+ years in a PM role)
- `important` — direct: R7 · adjacent: R8 (specs and delivery with two squads) · unclear: R4b (launches with sales and support), R9 (adoption metrics)

R1a — a literal title bar, unmet; R2 — consumed APIs in depth, never shipped one; R5, R9 — CV silent, recoverable.

**Opportunity ledger.** Concretely scoped duties (RR3), but the employer is unchecked (RR2), pay is unstated (RR1), and decision rights and reporting line are open (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify (RR2); (2) a recruiter or referrer confirms the 3+ years bar flexes for PM-adjacent work (R1a); (3) evidence for R2, R5 and R9 is recovered or honestly carried as gaps; (4) your adjacent work is framed as adjacent, never as a PM title or a shipped API.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, ~150 people, Series B | `[grounded]` JD header; not verified externally |
| Mandate | Own the roadmap of a partner-facing API platform | `[grounded]` JD |
| Duties | Partner discovery, specs, delivery with two engineering squads, adoption metrics, launches with sales and support | `[grounded]` JD |
| Scope read | One platform and two squads is a bounded remit, though "own the roadmap" may mean less than it sounds at this size | `[inferred]` from the duty list against the JD's silence on decision rights |
| Seniority pattern | Postings like this tend to favor candidates who have already owned an API or platform product | `[generic]` role-family pattern, not searched |
| Market calibration | Not run; no salary band to set against the unstated pay | `[generic]` — see evidence status |
| Unknowns | Pay, reporting line, existing PM team, year-one outcomes, whether the 3+ years bar flexes | — |
| Contradictions | None found in the JD as pasted | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years in a product management role | must_have | absent | none | capability | You've never held a PM title, so the literal bar is unmet. The JD labels it must-have, so a literal screen would likely filter a cold application | `[grounded]` your statement; `[generic]` that such bars are often screened literally | Closure path: warm route and recruiter question (A1); R1b carries the substance |
| R1b | PM-type work across 3+ years, regardless of title | must_have | adjacent | medium | transferability | Seven years of scoping, requirements, roadmap-input sessions and coordination with PMs and engineers is credible adjacent work. Limit: you fed product decisions, you didn't own them | `[grounded]` CV | G3 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | 30+ end-to-end integrations of your vendor's REST APIs and an internal integration playbook the team uses. Limit: you implemented and documented against APIs, you didn't ship one | `[grounded]` CV | G1 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI and integration architecture on 30+ projects. Medium because no artifact has been inspected | `[grounded]` CV | none; the playbook could raise it to `high` |
| R4a | Stakeholder management across engineering and customers | must_have | direct | medium | none | You coordinated your engineers, client engineers and PMs through workshops to go-live | `[grounded]` CV | none |
| R5 | Agile delivery | must_have | unclear | low | discovery | The CV describes project delivery, not sprints, backlogs or squad cadence. Silence, not evidence of absence | `[grounded]` CV silence | G2 |
| R6 | Own the roadmap | must_have | adjacent | medium | transferability | You ran quarterly roadmap-input sessions. Limit: collecting input is not prioritizing trade-offs or saying no | `[grounded]` CV | G3 |
| R7 | Discovery with integration partners | important | direct | medium | none | Scoping workshops and feedback sessions with clients who consume the APIs | `[grounded]` CV | none |
| R8 | Write specs, drive delivery with two squads | important | adjacent | medium | transferability | Requirements documents and custom-build coordination. Limit: specs were client-specific, not a product backlog | `[grounded]` CV | G2 |
| R4b | Coordinate launches with sales and support | important | unclear | low | discovery | The CV doesn't mention sales or support partnership | `[grounded]` CV silence | G4 |
| R9 | Define and track adoption metrics | important | unclear | low | discovery | No metrics work appears on the CV | `[grounded]` CV silence | G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Shipped product and adoption metrics (R2, R9) | discovery | Integrations delivered, but nothing you built that others adopted and you measured | These two rows are the likeliest interview probes; a confirmed shipped internal tool would lift both | An internal tool or integration kit others used, a template or SDK sample, a dashboard of who used it | A usage screenshot, a short write-up, the playbook itself | `[grounded]` CV silence; `[inferred]` this is the likeliest probe, from the JD's stress on shipped products |
| G2 | Agile delivery and specs (R5, R8) | discovery | Delivery with engineers, but no cadence, backlog or sprint evidence | R5 is a must-have left at `unclear` | Joining a client's sprint planning, writing tickets or acceptance criteria, running a backlog for custom builds | A sample ticket set or a spec excerpt, sanitized | `[grounded]` CV silence |
| G3 | Roadmap ownership (R6, R1b) | discovery | Feedback sessions are shown, outcomes are not | Whether input became shipped features decides if R6 stays `adjacent` | A feature that shipped because of your sessions, a prioritization argument you made to PMs | A roadmap excerpt or a feedback summary that went to product | `[grounded]` CV; `[inferred]` outcomes may exist unstated |
| G4 | Launch coordination (R4b) | discovery | No sales or support partnership shown | Important rather than must-have, so not asked this round | Handoffs to support at go-live, enablement for sales | Go-live checklist | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay not stated | unknown | — | JD gives no compensation | The band may sit above or below a first PM role for you, and I couldn't check the market | `[inferred]` from the JD's silence; no band was researched | What is the salary range for this role? | unresolved |
| RR2 | Employer not established | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The search was refused, so I couldn't check that the company, size or opening match. It may be fine; small firms often have thin footprints | `[generic]` pattern; not a claim about this company | Can you point me at the role on your careers site, and who I'd interview with? | unresolved |
| RR3 | Duties concretely scoped | positive_signal | — | "run discovery with integration partners; write specs and drive delivery with two engineering squads" | The role has a defined shape and partner-facing focus that fits your background | `[grounded]` JD | Who owns the partner roadmap today? | noted |
| RR4 | Decision rights and reporting line unclear | unknown | — | "Own the roadmap" | Roadmap ownership may be shared with a head of product or the CTO | `[inferred]` from the JD's silence on reporting line | Who does this role report to, and which roadmap decisions does it make alone? | unresolved |

## Application plan

Everything in this section is proposed and pending your approval, the prose advice as much as the table rows. Nothing here is final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Reach the hiring manager or a recruiter through a referral, and ask whether the 3+ years bar flexes for PM-adjacent experience | R1a, since a cold application is likely screened on the literal bar | `[generic]` pattern about literal screens; `[grounded]` R1a row | pending your approval |
| A2 | Confirm the posting on Quartzline's own careers page before investing effort | RR2 | `[grounded]` RR2 | pending your approval |
| E1 | Lead the CV with the roadmap-input sessions, the playbook and the integration scale, labelled as what they were (feedback to product, internal tooling, integration leadership). Don't use PM-title language or "shipped API" wording. I'll draft the wording once you approve the direction | R1b, R2, R6 | `[grounded]` CV | pending your approval |
| W1 | A one-page spec for a hypothetical partner-API improvement, drawn from integration pain you've seen, as a work sample | R2, R8: the fastest honest way to show product thinking | `[inferred]` from R2 and R8 limits | pending your approval |
| Q1 | Ask RR1, RR3 and RR4's questions verbatim in the process | They double as interview preparation | `[grounded]` register | pending your approval |
| A3 | Alongside this role, consider titles such as technical PM, integrations PM or API PM at API vendors, where your integration background counts as domain strength | Several tries beat one stretch role | `[generic]` role-family pattern, unresearched | pending your approval |

## Evidence status

Verified: none yet. Unverified lead: a prior-conversation note that you may have built an internal request-triage tool that support agents adopted. It is a `memory_lead`, not evidence, and is not used in any row until you confirm it.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search was refused (query: Quartzline careers, Product Manager Platform APIs). It would have confirmed the company and posting, feeding role reality and RR2 |
| 2. Role-family sweep | unavailable | Search was refused (query: API platform PM salary and scope, SE-to-PM transitions). It would have fed the market calibration and RR1 |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Dossier offer and upgrade menu

I can save all of this as `tuesday-dossier.md` if you want a file to keep.

- Permission to search the web → targets 1 and 2 run, which clears or confirms RR2 and gives a pay band for RR1.
- A confirmed answer on the triage tool (G1) → R2 and R9 may improve, and R1b strengthens.
- The integration playbook or a sanitized sample → R3 to `high`, and evidence for R2 and R8.
- A sample ticket or spec excerpt (G2) → R5 and R8.
- A roadmap or feedback summary that reached product (G3) → R6.
- Your constraints (pay floor, location, work authorization) → hard-gate checks run instead of staying unknown.
- The hiring manager's name → footprint research and sharper positioning.

## Questions

1. **G1** — Did you build anything that other people adopted, such as the request-triage tool my notes mention? If so, what did you own, who used it, and how did you know it worked?
2. **G2** — On custom builds, did you write tickets, acceptance criteria or specs that engineers worked from in sprints? What did that look like?
3. **G3** — Did anything from your quarterly roadmap-input sessions end up shipped, and what was your part in getting it prioritized?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.