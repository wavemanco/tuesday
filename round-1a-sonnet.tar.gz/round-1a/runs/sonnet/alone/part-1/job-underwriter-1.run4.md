I'll read the reference files the skill requires before building the assessment.
Yes, apply. You're a credible fit, and the one thing I couldn't confirm is that the employer and posting are real, because my web searches were refused. Status: `conditional_go`. R1, R2, R3, R4 and R5 are `direct` matches. The gaps are in what the JD lists around them.

## Decision snapshot

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R5 · adjacent: R6 (Define and maintain the metrics layer)
- `important` — adjacent: R7a (Partner with product managers) · unclear: R7b (Partner with clinicians), R8 (Mentor two junior analysts)
- `preferred` — adjacent: R9 (Healthcare data experience, HIPAA)

R6 — governed Looker work suggests a metrics layer, not yet confirmed; R7b and R8 — no evidence stated either way; R9 — a bridge from GDPR/CCPA work, its limit named.

**Opportunity ledger.** The role is concretely listed (RR5), but the employer could not be checked (RR1), pay and work arrangement are unstated (RR2, RR3), and the scope is broad (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify, as in RR1; (2) pay and location prove acceptable once stated, as in RR2 and RR3 (you've given no constraints yet); (3) scope and ownership check out in interviews, as in RR4; (4) the metrics-layer and mentoring claims are confirmed before they go on a CV, as in R6 and R8.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, about 400 people, Series C | `[grounded]` JD header as pasted; not checked against any outside source |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, Looker dashboards, partnering with PMs and clinicians, mentoring two junior analysts | `[grounded]` JD |
| Requirements | 5+ years product analytics, expert SQL, experiment design at scale, Looker or similar, written communication with non-technical stakeholders; healthcare/HIPAA a plus | `[grounded]` JD |
| Hard-gate terms | None stated: authorization, location, schedule and pay are all silent | `[grounded]` JD silence |
| First 90 days / first year | Not stated | `[grounded]` JD silence |
| Scope read | A senior individual contributor with a mentoring duty rather than a people manager; the JD says "mentor", not "manage" | `[inferred]` from the JD's wording on the two junior analysts |
| Market calibration | Not established. The research was refused, so no title, scope or pay band is asserted | `[grounded]` research refused, nothing used from memory |
| Unknowns | Pay; location or remote policy; the data stack beyond Looker; who owns the warehouse and modelling layer; reporting line; what success looks like in year one | `[grounded]` JD silence |
| Contradictions | None inside the JD. Consistency with the company's own careers page is unchecked | `[grounded]` JD; `[grounded]` search refused |

## Evidence map

Your background was typed into the chat. That makes it self-reported, so `medium` is as high as any row goes until something inspectable is attached.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | You state 6 years of product analytics at a consumer-subscription company. That clears the number, and years of experience are not a gate | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | You state daily SQL on Snowflake. "Expert" is the JD's word, not yours, and nothing inspectable is attached yet. Roles like this commonly add a live SQL exercise | `[grounded]` your background; `[generic]` on the exercise | Optional: a sanitized query or model sample would raise it to `high` |
| R3 | Experiment design at scale | must_have | direct | medium | none | You state you designed and ran the program, 30+ A/B tests a year, including the pricing test behind an 11% retention lift, on about 2M subscribers. It's not yet stated whether 11% is relative or in points, or how much of that test's design was yours. Interviewers commonly probe both | `[grounded]` your background; `[generic]` on the probe | Optional: a sanitized pricing-test readout would raise it to `high` |
| R4 | Looker or similar BI; self-serve dashboards | must_have | direct | medium | none | You state you built the Looker instance from scratch with 40+ governed dashboards. "Self-serve" isn't in your words, so don't claim it until you confirm it | `[grounded]` your background | Optional: a redacted screenshot of a governed explore would raise it |
| R5 | Written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads and present to the VP Product monthly | `[grounded]` your background | Optional: a redacted memo would raise it |
| R6 | Define and maintain the metrics layer | must_have | adjacent | medium | discovery | Building Looker from scratch and governing 40+ dashboards plausibly involved shared metric definitions. You haven't said you defined or versioned metrics, and the consent-state model shows warehouse modelling, not metric governance | `[inferred]` from the Looker and consent-model claims | See G1 |
| R7a | Partner with PMs to turn analysis into roadmap decisions | important | adjacent | medium | discovery | You present monthly to the VP Product and a test of yours drove a retention result. Working directly with PMs and changing roadmap choices isn't stated | `[inferred]` from the VP Product relationship | Confirm later which roadmap choices your analysis changed |
| R7b | Partner with clinicians | important | unclear | none | discovery | Nothing in your background mentions working with domain-expert stakeholders. I won't assume an equivalent | `[grounded]` background silence | See G3 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Your background says nothing about mentoring, reviewing others' work or managing | `[grounded]` background silence | See G2 |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | You've handled GDPR/CCPA consumer PII and built the consent-state model. Limit: no protected health information and no HIPAA rules. HIPAA governs health data under rules that differ from consumer-privacy law | `[grounded]` your background; `[generic]` on HIPAA differing | See G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R6, must_have) | discovery | Looker built from scratch, 40+ governed dashboards, and a consent-state model. Nothing on how metrics were defined or versioned | R6 is a `must_have` row at `adjacent`. Confirming it would likely move it to `direct` and remove the most likely probe | Owning shared Looker measures or LookML models; a metric dictionary; settling conflicting numbers for one KPI such as retention or churn; a certified-metrics process | A sanitized LookML excerpt, a metric-definitions doc, a screenshot of a governed explore | `[grounded]` background silence; `[generic]` that this role family probes metric ownership |
| G2 | Mentoring (R8, important) | discovery | No mentoring or review work stated | The JD names it as a duty, so an absent answer reads as a gap | Onboarding a new analyst; reviewing others' SQL or test designs; pairing; writing analysis standards | An onboarding doc or review checklist, with no names | `[grounded]` background silence |
| G3 | Clinician partnership (R7b, important) | discovery | No domain-expert stakeholder work stated | Clinical input is part of the mandate, and a bridge to similar work would help | Shaping tests with specialists in another domain, such as nutrition, food safety, operations or customer care, and interpreting results with them | A co-written test brief | `[grounded]` background silence |
| G4 | HIPAA (R9, preferred) | transferability | Adjacent: GDPR/CCPA PII and a consent-state model. Limit: no protected health information or HIPAA rules | A `preferred` row, so it won't decide the outcome, but a stated limit reads better than an overreach | Gating data by consent state; restricted-access datasets; audit or deletion requests | A sanitized description of the consent-state model's states and what they gated | `[grounded]` your background; `[generic]` on HIPAA differing |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The company may be too new or small for an obvious footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. My searches were refused, so nothing is confirmed either way | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who I'd be interviewing with? | unresolved |
| RR2 | Pay not stated in the posting | unknown | — | JD silent on compensation | Pay may sit anywhere relative to the role-family band, which I couldn't look up. Withholding it is itself worth a question | `[inferred]` from the JD's silence | What salary band is budgeted for this role? | unresolved |
| RR3 | Location and work arrangement not stated | unknown | — | JD silent on location and remote policy | The role may require on-site presence or limit hiring to certain states | `[inferred]` from the JD's silence | Is this role remote, hybrid or on-site, and where? | unresolved |
| RR4 | Broad scope: metrics layer, experimentation, dashboards, stakeholders and mentoring in one role | risk_signal | low | "define and maintain the metrics layer, design and analyze A/B tests, build self-serve dashboards in Looker… mentor two junior analysts" | The scope may fold several specialisms into one post, or may be ordinary for a senior analyst at a company this size. The JD states no ownership of the warehouse or modelling layer and no success measures. Rated low rather than medium because the JD doesn't show the problem itself | `[inferred]` from the JD's list of duties against its silence on data engineering and success measures | What does a good first year look like, and who owns the warehouse and modelling layer? | unresolved |
| RR5 | Duties and tools are listed concretely | positive_signal | — | "Own product analytics… build self-serve dashboards in Looker… mentor two junior analysts" | The JD says what the role does, names its tools, and sizes the mentoring | `[grounded]` JD | Who are the two junior analysts, and how long have they been on the team? | noted |

## Application plan

Every row is a proposal, advice included. Nothing here is final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting is live on the company's own careers site and the recruiter's email domain matches, before spending effort | RR1 | `[grounded]` RR1 | pending your approval |
| E1 | CV line, your words only: "Built the company's Looker instance from scratch — 40+ governed dashboards." Don't write "metrics layer" or "self-serve" until G1 and R4 are confirmed | R4, R6 | `[grounded]` your background | resume_edits_pending_approval |
| E2 | CV line, your words only: "Designed and ran the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift." Say whether 11% is relative or points before it goes in | R3 | `[grounded]` your background | resume_edits_pending_approval |
| E3 | CV line: "Write the monthly metrics memo the exec team reads; present to the VP Product monthly." | R5, R7a | `[grounded]` your background | resume_edits_pending_approval |
| E4 | Cover-letter honesty on HIPAA: "I haven't worked with HIPAA-regulated data. I've handled GDPR/CCPA consumer PII and built our warehouse's consent-state model." Don't call the consent model protected-health-data experience | R9 | `[grounded]` your background | resume_edits_pending_approval |
| E5 | Hold back any mentoring or clinician-collaboration claim until G2 and G3 are answered | R7b, R8 | `[grounded]` the rows | pending your approval |
| Q1 | In interviews, ask RR1, RR2, RR3 and RR4's questions verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were sent and refused: "Harborlight Health care navigation app Series C" and "Harborlight Health careers Senior Product Analyst". Employer, stage, size and whether the posting is live are unconfirmed. This feeds RR1 and the contradictions row in role reality |
| 2. Role-family sweep | unavailable | One search was sent and refused: "senior product analyst digital health salary range Looker SQL experimentation". It would have set the market calibration and RR2's comparison against the pay band. I did not fill the gap from memory |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I'm not retrying the searches. Say if you want that, or give me the live posting link and I'll read it as an input.

I can write up all of this as a `tuesday-dossier.md` if you'd like to keep it.

## Upgrade menu

- A link to the posting on Harborlight's own careers page → RR1 can close, which lifts the cap on `conditional_go`.
- Search permission → targets 1 and 2 run, setting the pay band against RR2 and confirming the company.
- Your salary floor, location and any authorization or schedule limits → hard-gate rows appear, so the hard-gates line becomes a real check.
- The hiring manager's name → scope read and which of your stories to lead with.
- A sanitized LookML excerpt or governed-explore screenshot → R4 and R6 rise.
- A sanitized pricing-test readout → R3 reaches `high`.
- A redacted metrics memo → R5 reaches `high`.
- A sanitized query or model sample → R2 reaches `high`.

Questions, each tagged to its row:

G1 — Did you define or version the metrics your Looker dashboards shared, through LookML, a metric dictionary or a certified-metrics process? What was yours, who used it, and what changed as a result?

G2 — Have you mentored, onboarded or reviewed other analysts' work? What did you do, for whom, and for how long?

C1 — Do you have non-negotiables I should check this role against: salary floor, location or remote, work authorization, schedule? The JD states none of these, so I can't check them yet.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.