Reading the skill's reference files is done. Next I'm loading the search tools so I can check that Harborlight Health exists and get a salary range for this role. Then I'll write the assessment.
# Job Underwriting Assessment: Senior Product Analyst, Harborlight Health

## Decision snapshot

**Yes, apply. You're a fit on the core of the role (R1, R2, R3, R4, R5 are all `direct`), conditional on the employer checking out. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R5 · unclear: R6 (Metrics layer definition and upkeep)
- `important` — adjacent: R7a (Partnering with PMs on roadmap) · unclear: R7b (Partnering with clinicians), R8 (Mentoring two junior analysts)
- `preferred` — adjacent: R9 (Healthcare data / HIPAA)

R6 — the one must-have your background doesn't yet speak to; R9 (`medium`) — a credible privacy bridge, its limit named; R7b, R8 — nothing stated yet either way.

**Opportunity ledger.** The employer could not be verified (RR1), and the posting is silent on pay and location (RR2). The reporting line and team shape are also unstated (RR3). On the other side, the duties are concrete and the stage is named (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify, see RR1; (2) pay and location are compatible with what you need, see RR2 (you haven't given me your limits yet); (3) R6 resolves, meaning you can say truthfully what you owned in metric definitions; (4) the healthcare bridge is framed as adjacent, never as HIPAA experience (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up, about 400 people, Series C, with a care-navigation app. This is the posting's description only; I couldn't check it. | `[grounded]` JD as pasted |
| Mandate | Own product analytics for the app: metrics layer, A/B tests, self-serve Looker dashboards, analysis turned into roadmap decisions with PMs and clinicians, and mentoring two junior analysts | `[grounded]` JD |
| First-90-days / first-year outcomes | Not stated. Likely: take over the metrics definitions, the experiment pipeline and the dashboards. | `[inferred]` from the JD's verbs "define and maintain", "design and analyze", "build" |
| Scope read | One product's analytics end to end, plus a small mentoring remit. "Define and maintain" leaves open whether a metrics layer exists today or must be built. | `[inferred]` from the JD's wording against its silence on current state |
| Working pattern, location, pay | Not stated in the posting | `[grounded]` JD silence |
| Market calibration | Not established. The pay-band search did not run, so I give no band rather than quote one from memory. | `[generic]` fallback, nothing researched |
| Unknowns | Reporting line; team size; whether a metrics layer exists; how clinicians take part in decisions; pay; location | — |
| Contradictions | None inside the JD. The careers page was not checked. | `[grounded]` JD read; careers page not reached |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | You stated 6 years at a consumer-subscription company. No artifact inspected, so `medium`. | `[grounded]` your stated background | A CV or LinkedIn timeline would raise to high |
| R2 | Expert SQL | must_have | direct | medium | none | You use SQL daily on Snowflake over 6 years. "Expert" is a self-grade in any resume, so expect a live SQL probe. | `[grounded]` your stated background | A sanitized query sample would raise to high |
| R3 | Experiment design at scale | must_have | direct | medium | none | You designed and ran the program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift, on about 2M subscribers. | `[grounded]` your stated background | A sanitized experiment readout would raise to high |
| R4 | Looker or similar BI tool | must_have | direct | medium | none | You built the Looker instance from scratch, with 40+ governed dashboards. | `[grounded]` your stated background | A dashboard inventory or screenshot (sanitized) would raise to high |
| R5 | Written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads and present monthly to the VP Product. | `[grounded]` your stated background | A sanitized memo excerpt would raise to high |
| R6 | Define and maintain the metrics layer | must_have | unclear | low | discovery | "Governed dashboards" and the memo suggest metric definitions existed. You didn't say you wrote or owned them, so I can't credit it. | `[grounded]` background silent on definition ownership | Question Q1 |
| R7a | Partner with PMs to turn analysis into roadmap decisions | important | adjacent | medium | discovery | Roadmap-facing work is evidenced at VP Product level (the monthly presentations, the pricing test). Day-to-day work with individual PMs isn't stated, so I don't assume it. | `[grounded]` your stated background; limit named | Gap queue G2 |
| R7b | Partner with clinicians | important | unclear | low | discovery | Nothing stated about working with clinical or other domain-expert stakeholders. | `[grounded]` background silent | Gap queue G2 |
| R8 | Mentor two junior analysts | important | unclear | low | discovery | Your background doesn't mention managing or mentoring anyone. | `[grounded]` background silent | Question Q2 |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | You handled GDPR/CCPA consumer PII and built the warehouse's consent-state model. You have no healthcare or HIPAA experience. Preferred tier, so a bridge rather than a blocker. | `[grounded]` your stated background; `[inferred]` adjacency | Gap queue G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R6, must_have) | discovery | 40+ governed dashboards and a monthly exec memo, but no statement that you defined the metrics behind them | It's the first duty in the JD and the only must-have row not at `direct` | Writing metric definitions in LookML or a shared spec; settling "what counts as an active subscriber / retained"; a metrics glossary the company used | A sanitized metric-definition doc, LookML snippet or glossary | `[grounded]` background silence; `[generic]` that a metrics layer is the posting's headline duty |
| G2 | PM and clinician partnership (R7a, R7b, important) | discovery | VP Product-level presentations; no stated day-to-day work with PMs or with domain experts | The role turns analysis into roadmap decisions with both groups | Experiments co-designed with PMs; work with ops, culinary or nutrition specialists, who are the nearest analogue to clinicians | A sanitized experiment brief naming the partners | `[grounded]` background silence; `[inferred]` analogue from the meal-kit context |
| G3 | Healthcare / HIPAA (R9, preferred) | transferability | GDPR/CCPA PII handling and the consent-state model, with no health data | Preferred only, but it's the JD's one stated domain plus | Any sensitive-category data, access controls, de-identification or audit work in your warehouse | A short description of the consent model's scope | `[grounded]` your stated background; limit: no HIPAA, no PHI |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. Severity stays at medium because the check didn't run, and obscurity isn't evidence of a problem. | `[generic]` pattern, not a claim about this company | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay and location unstated | unknown | — | The posting gives a title, company description and duties, with no pay figure or location | The range may sit below what a senior analyst expects, or the role may require an office or a region you can't do | `[inferred]` from the JD's silence | What is the salary range, and is the role remote, hybrid or on-site, and where? | unresolved |
| RR3 | Reporting line and team shape unstated | unknown | — | "Own product analytics… mentor two junior analysts" | "Own" plus a mentoring remit may mean you'd be the only senior analyst on the app, with the metrics layer partly yours to build | `[inferred]` from the JD's verbs against its silence on the team | Who does this role report to, and what does the analytics team look like today? | unresolved |
| RR4 | Duties are concrete and the stage is named | positive_signal | — | "define and maintain the metrics layer, design and analyze A/B tests, build self-serve dashboards in Looker" | The role's scope is specific rather than generic, and the tools match your Looker/Snowflake-style stack | `[grounded]` JD states the duties and the tool | Which part of the metrics layer exists today, and which would I build? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Resume line, traced to your sentence: "Designed and ran the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift." Lead with it, since R3 is the strongest match. | see R3 | `[grounded]` your stated background | resume_edits_pending_approval |
| E2 | Resume line, traced to your sentence: "Built the consent-state model for our warehouse; handled GDPR/CCPA consumer PII." It sits near the top as your privacy-data evidence. It does not claim HIPAA or health data. | see R9 | `[grounded]` your stated background | resume_edits_pending_approval |
| P1 | In the cover note or recruiter call, say plainly that healthcare is new to you and that your privacy work is GDPR/CCPA. That keeps the R9 bridge honest and heads off the likeliest probe. | see R9 | `[inferred]` the probe is likely given the JD's HIPAA line | pending your approval |
| A1 | Confirm the employer and the live posting on Harborlight's own careers page before investing in an application | see RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | In a screen, ask RR2 and RR3's verification questions verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. No claim of yours has been confirmed beyond your own description of it. Rejected inferences: "owned the metric definitions" and "mentored or managed analysts" were not inferred, because your background doesn't state either.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Harborlight Health care navigation app company careers"; the call was refused, so nothing returned. It would have moved role reality's organization and contradictions rows and RR1. |
| 2. Role-family sweep | unavailable | Searched "senior product analyst digital health salary range experimentation Looker"; the call was refused, so nothing returned. It would have moved the market calibration line and RR2. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |

I've offered a dossier file below, and have sent nothing outward.

One more thing: I can write all of this up as a `tuesday-dossier.md` you can keep, if you'd like it.

## Upgrade menu

- Permission to run the two refused searches → RR1 closes or sharpens, and role reality gets a `[generic]` pay and scope band.
- Your CV, or any sanitized artifact (an experiment readout, a dashboard inventory, a memo excerpt, a query sample) → R1–R5 can rise from `medium` to `high`, and the resume lines are audited against your actual wording.
- An answer to Q1 → R6 moves from `unclear` toward `direct` or `adjacent`, the only must-have row still open.
- The hiring manager's name → role reality's scope read, and which of your stories to lead with.
- Your constraints on pay, location and work authorization → the hard-gates line stops reading "unknown".

## Questions

1. **(R6)** Did you write or own the metric definitions behind those dashboards, for example in LookML or a shared metrics spec? If so, which metrics, and who relied on them?
2. **(R8)** Have you formally or informally mentored, managed or onboarded other analysts, and how many?
3. **(RR2 and your hard constraints)** Do you have non-negotiables on pay floor, location or remote work, or work authorization that I should check this role against?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.