Output gets truncated; I'll read the files in pieces.
## Decision snapshot

**Yes, apply, on conditions. The role is within reach but two of its duties are new to you: the forecast (R7) and billing data (R9). Status: `conditional_go`.** I'm assuming you're still evaluating, since you didn't say you've applied.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Bristol office two days a week), R2 (Salary £61,500–£67,000)
- `must_have` — direct: R3, R5, R6 · adjacent: R7 (owning a forecast) · unclear: R4 (at a B2B software company), R8 (working with finance on billing or revenue data) · absent: R9 (owning billing data)
- `important` — direct: R10

R7 — the monthly pipeline review is the nearest thing you've run to the forecast, its limit named; R9 — billing data is new to you; R4 — whether your employer counts as a software company needs confirming.

**Opportunity ledger.** The employer is real, and the pay sits inside the surveyed band (RR3). The role's shape is under-specified: team, reporting line and first-year outcomes are unstated (RR1), the forecast boundary with finance is unclear (RR2), the share-option terms are missing (RR4), and I couldn't find the posting on Quillfield's own site (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol office two days a week), R2 (Salary £61,500–£67,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) Bristol with two office days (R1) and the pay range (R2) meet your own limits; (2) interviews show the forecast and billing-data learning is supported (RR1, RR2); (3) the posting is confirmed live on Quillfield's side (RR5).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield makes invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol, 96 employees, £11M Series A closed April 2025 | `[grounded]` search result "About Quillfield" (quillfield.co.uk/about), a snippet; the page itself was not fetched |
| Mandate | Own CRM and billing data. Build pipeline and renewal reporting for sales and finance. Run the quarterly revenue forecast with the CFO | `[grounded]` JD |
| Working pattern and pay | Bristol hybrid, two office days a week. £61,500–£67,000 plus share options, with no option terms given | `[grounded]` JD |
| Hiring manager | You were told Tamsin Achebe. Her public profile reads "Head of Revenue Operations, Quillfield", and before that sales operations manager at Corvane Payments for four years | `[grounded]` your recruiter, and search result "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe) |
| Reporting line | Unstated. The role may sit under her | `[inferred]` from her title and the recruiter's statement; the JD is silent |
| First-90-days and first-year outcomes | None stated | `[grounded]` JD silence |
| Scope read | Four mandates in one post: CRM, billing data, reporting, forecast. The two you haven't done are the ones that touch finance, so the post sits at the sales–finance seam | `[inferred]` from the JD's four duties against your background |
| Market calibration | Ledgerline's 2026 UK survey of revenue operations leads in B2B software (n=438) gives a median base of £64,200 and a range of £57,800–£70,400. The posting's £61,500–£67,000 sits inside that range. The survey is UK-wide, not Bristol-specific, and only pay was swept, not title or scope norms | `[generic]` the band, from a search snippet; `[grounded]` the JD's own figure |
| Unknowns | Team size, reporting line, who builds and signs off the forecast, option terms, whether the post is new or a replacement | — |
| Contradictions | None between your recruiter's account and Tamsin's public title. The posting appears only on a third-party board, and a careers search found nothing on Quillfield's own site | `[grounded]` search results |

## Evidence map

Your background came as prose, so it counts as CV-equivalent and rows top out at `medium`.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two office days a week | hard_gate | unclear | none | hard_gate | You haven't said where you live or whether two Bristol days works. "UK team" doesn't settle it. Confidence is `none` because no constraint has been stated | `[grounded]` JD; your message silent on location | Q1 |
| R2 | Salary £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | No pay floor stated, so I can't say whether the range meets it | `[grounded]` JD; your message silent on pay | Q1 |
| R3 | 4+ years in revenue operations, sales operations or a similar analytics role | must_have | direct | medium | none | You have 5 years in sales operations, the last 2 running revenue operations for the UK team. This is a length-of-experience requirement, so it is not a gate. Self-reported | `[grounded]` your background | none |
| R4 | …at a B2B software company | must_have | unclear | low | discovery | You said "B2B payments company". I can't tell whether it sells software or payments processing, and the JD's wording is software | `[grounded]` your wording against the JD's | G1, Q2 |
| R5 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified and you rebuilt the pipeline and renewal dashboards. The certificate hasn't been inspected | `[grounded]` your background | none |
| R6 | Strong SQL and spreadsheet modelling | must_have | direct | medium | discovery | SQL weekly and Excel daily show use. "Strong" and "modelling" depth isn't established | `[grounded]` your background; depth not probed | Be ready to describe one model you built |
| R7 | Experience owning a forecast | must_have | adjacent | medium | transferability | You've never owned the company forecast, because finance did. You run the monthly pipeline review with the sales director. That is a bridge, not ownership | `[grounded]` your statement; the adjacency is `[inferred]` from the pipeline review | G3 |
| R8 | Experience working with finance on billing or revenue data | must_have | unclear | low | discovery | You've never worked on billing data. The "or revenue data" limb may be met by renewal reporting if finance used it, and that's unconfirmed | `[grounded]` your statement; the possible link is `[inferred]` | G2, Q3 |
| R9 | Own the company's billing data (responsibility) | must_have | absent | none | capability | You confirmed no billing-data work. This is a duty of the role, not just a preference | `[grounded]` your statement | G4 |
| R10 | Build pipeline and renewal reporting for sales and finance teams | important | direct | medium | none | You rebuilt your pipeline and renewal dashboards. Whether finance was a consumer is covered by R8 | `[grounded]` your background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Software-company employer (R4, must_have) | discovery | "B2B payments company", with nothing on whether it sells software | A cheap fact that could settle a must-have either way. Quillfield itself sells payments software | Your employer selling a platform or product subscription; recurring-revenue or renewal reporting, which implies a software-style model | Your employer's product page, or a CV line describing the product | `[grounded]` your wording; `[inferred]` that renewal reporting points to a subscription model |
| G2 | Finance collaboration on revenue data (R8, must_have) | discovery | Renewal dashboards exist; nothing says finance used or reconciled them | R8 is one of two finance-facing must-haves, and one answer could move it to `adjacent` or `direct` | Finance relying on your renewal or pipeline numbers; reconciling CRM figures to finance's; sharing monthly reports with finance | A dashboard screenshot with figures removed, or a finance-facing report | `[grounded]` your background silent on finance use |
| G3 | Forecast ownership (R7, must_have) | transferability | You run the pipeline review with the sales director. Finance owned the forecast | The JD asks you to run the forecast with the CFO, so the limit will be probed. Interviewers for a role like this often probe the line between contributing to a forecast and owning it | Bridge: the pipeline review you run. Limit: you haven't built or signed off a company forecast. Strengthener: a small forecast model on pipeline data as a work sample, proposed and pending your approval | A sanitized pipeline-review pack or a work-sample model | `[grounded]` your statements; `[generic]` that forecast ownership is commonly probed |
| G4 | Billing data (R9, must_have) | capability | No billing-data work, confirmed by you | A named duty you haven't done. The decision carries this as a material risk rather than a block | Closure path: ask in interviews which billing system and exports the role uses, and learn how invoices map to CRM records; a renewal-to-invoice reconciliation exercise on your own data, if you have access | A short written approach, not a claim of experience | `[grounded]` your statement; closure path is `[inferred]` |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Team, reporting line and first-year outcomes unstated | unknown | — | "Revenue Operations Lead, Quillfield." | The post may be a single contributor accountable for four areas, or a lead under Tamsin with support | `[inferred]` from the JD's silence on team and outcomes | Who does this role report to, does it have anyone reporting in, and what should be true a year in? | unresolved |
| RR2 | Forecast boundary with finance unclear | unknown | — | "run the quarterly revenue forecast with the CFO" | "Run" could mean RevOps builds and owns the model with CFO sign-off, or supplies pipeline input to a finance-owned model. Your experience is nearer the second | `[inferred]` from the JD wording against your R7 evidence | Who builds the forecast model, who signs it off, and what does this role own in it? | unresolved |
| RR3 | Pay inside the surveyed band | positive_signal | — | "Salary £61,500–£67,000" | The range is market-aligned for the title | `[grounded]` JD figure; `[generic]` the Ledgerline band | Where in the range would someone with my background sit? | noted |
| RR4 | Share options with no terms | unknown | — | "plus share options" | Value depends on grant size, vesting and strike price, none of which the posting gives | `[generic]` pattern for equity at venture-backed firms, not a claim about this one | What is the option grant, vesting schedule and strike price? | unresolved |
| RR5 | Posting seen only on a third-party board | unknown | — | "Revenue Operations Lead, Quillfield." (jobs.tallyboard.example) | Quillfield's careers page may not be indexed, or the role may be advertised through a recruiter first. The employer itself is established | `[inferred]` from a careers search that returned no results; `[generic]` for the reasons | Is this role listed on Quillfield's own careers page, and which team would I interview with? | unresolved |

## Application plan

All of this is proposed, and nothing is final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask the recruiter the RR1, RR2 and RR5 questions before investing in the loop | They settle what the role is and whether the posting is live | `[grounded]` register | pending your approval |
| P1 | Positioning advice: lead with the Salesforce admin certification, the dashboards you rebuilt and the monthly pipeline review with the sales director. Say plainly that finance owned the forecast and that you haven't worked on billing data. Don't present the pipeline review as forecast ownership. Tamsin's earlier years at a payments company may make your payments background easy for her to place | Each line traces to your sentences, and the R7 and R9 limits stay stated. The last point rests on her public profile | `[grounded]` your statements and her profile snippet | pending your approval |
| E1–E3 | CV lines, in the table below | R3, R5, R6, R10 | `[grounded]` your sentences | `resume_edits_pending_approval` |
| Q1 | Take the RR1–RR5 questions into the interviews verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |

| # | Proposed line | Traces to your words | Status |
|---|---|---|---|
| E1 | "Ran revenue operations for the UK team at a B2B payments company (last 2 of 5 years in sales operations)" | "5 years in sales operations at a B2B payments company, the last 2 running revenue operations for the UK team" | `resume_edits_pending_approval` |
| E2 | "Rebuilt the pipeline and renewal dashboards; Salesforce admin certified" | "Salesforce admin certified; I rebuilt our pipeline and renewal dashboards" | `resume_edits_pending_approval` |
| E3 | "Run the monthly pipeline review with the sales director; SQL weekly, Excel daily" | "I run the monthly pipeline review with our sales director. SQL weekly, Excel daily" | `resume_edits_pending_approval` |

You didn't send a CV, so these are proposed lines, not edits to existing ones.

Offer beyond the spec: a short plan for the two finance-facing gaps (R7, R9), covering what to ask for and learn in your first weeks. This posting earns it because the forecast and billing data are the role's two duties you haven't done. I'll build it only if you approve.

## Evidence status

Verified: none yet. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company", which returned "About Quillfield" (quillfield.co.uk/about), and "Quillfield careers Revenue Operations Lead Bristol", which returned no results. This established the employer in role reality. It left the posting unconfirmed on Quillfield's own site, which became RR5 |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary Bristol B2B SaaS", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). This gave the market calibration and RR3. It covered pay only, not title or scope norms |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). This fed the hiring-manager and reporting-line rows and plan row P1 |

## Dossier offer and upgrade menu

I can save this as a `tuesday-dossier.md` for you to keep if you want it.

- Your CV → R3, R5, R6 and R10 can be inspected, and E1–E3 become real edits rather than proposed lines.
- A pay floor and your location → R1 and R2 move from `unclear` to met or failed, and the decision likely settles to `go` or `no_go`.
- A dashboard screenshot with figures removed, or a pipeline-review pack → R5, R6 and R10 can reach `high`.
- The recruiter's answers on team, forecast ownership and the live posting → RR1, RR2 and RR5 close.
- A deeper pass on Quillfield (funding and leadership changes, hiring patterns, recent news, employee reports; up to 5 more searches and 2 more fetches) → this would sharpen the register. Say the word and it runs.

## Questions

Q1 (R1, R2) — Are you based within reach of Bristol for two office days a week, and what is your pay floor?
Q2 (R4, G1) — Does your current employer sell software or a subscription product, or is it payments processing?
Q3 (R8, G2) — Did finance ever use your pipeline or renewal reports, or did you reconcile your numbers against theirs? What did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.