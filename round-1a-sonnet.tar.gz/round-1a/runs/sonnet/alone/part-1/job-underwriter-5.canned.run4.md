I'm reading the skill's reference files, starting with its research-tier and trigger rules, before I write the assessment.
**Yes, it's worth applying. R1 and R2, the location and pay gates, need confirming first. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity)
- `must_have`: direct: R3, R4, R5, R6, R7, R8
- `important`: adjacent: R9 (BigQuery in the dbt warehouse); unclear: R10 (Ingestion from app and CRM), R11 (Data contracts)

R9 is a credible bridge with its limit named (Snowflake, never BigQuery). R10 and R11 are things you haven't said either way.

**Opportunity ledger.** The posting is sound on what it shows: pay is published and sits at or above the supplied band (RR1), and the employer's own pages are consistent (RR3). Equity terms (RR2) and the reporting line and scope (RR4) are unknown.

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 confirmed: you can work in the US without sponsorship, remote or in Denver. (2) R2 meets your pay floor. (3) R9 is framed honestly as adjacent, and RR4's scope question gets a concrete answer.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` company's own about page; funding is the company's statement, not independently confirmed |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD, matched to the live careers page |
| Working pattern | Remote (US) or the Denver office | `[grounded]` JD |
| First-year outcomes | Not stated | `[grounded]` JD silence |
| Scope read | Three areas (ingestion, warehouse modelling, contracts) in one role, against a report-typical scope of one domain's pipelines. It may be broader than typical, or a sole-engineer post | `[inferred]` from the JD's three areas against the supplied report's typical scope |
| Market calibration | Senior Data Engineer at Series B–D: base median $151,000, interquartile range $139,000–$163,500, "Senior" typically 5–8 years, no direct reports. Pellucid is Series C and the JD names no reports. The band is a pattern, not this employer's offer | `[generic]` Datawright 2026 report (n=2,310), supplied by your recruiter; `[grounded]` JD for the posted range and the Series C stage |
| Unknowns | Reporting line, team size, equity terms, success metrics, whether the warehouse already exists or is to be built, sponsorship stance | `[grounded]` JD silence |
| Contradictions | None between the pasted posting and the live careers page, or between the pasted about text and the search result for the about page | `[grounded]` careers page fetched; about page seen as a search result |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you are or your work authorization. Confidence is `none` because the constraint hasn't been stated | `[grounded]` JD; your silence | Question R1 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | No pay floor stated. The posted range is in the JD; the comparison with the band is in RR1 | `[grounded]` JD; your silence | Question R2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company clears the floor. Self-reported, nothing inspected yet | `[grounded]` your message | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. "Strong" is the JD's word and your evidence is daily use, so expect a probe | `[grounded]` your message; `[generic]` that loops for this title probe it | none |
| R5 | dbt | must_have | direct | medium | none | You built the dbt project on Snowflake, about 180 models | `[grounded]` your message | Offer: a sanitized schema or docs excerpt would raise to `high` |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse. The requirement names none, and the JD's BigQuery mention is carried in R9 | `[grounded]` your message and JD | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | You named Airflow for orchestration. Whether you wrote DAGs or ran existing ones isn't stated, so the claim stays as you wrote it | `[grounded]` your message | none |
| R8 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite. The JD asks for data quality testing, not a named tool | `[grounded]` your message | Offer: a sanitized suite config would raise to `high` |
| R9 | BigQuery warehouse (named in the responsibilities, not the requirements list) | important | adjacent | medium | transferability | Adjacent: dbt modelling on a cloud warehouse. Limit: you've never used BigQuery, so its specifics are untried by you, such as cost and performance tuning, dialect differences and the dbt adapter. Strengthener: a small project (W1) | `[inferred]` adjacency from your Snowflake work and the tiering from the JD's wording; `[generic]` that these are where warehouses differ | G1 |
| R10 | Ingestion from the app and CRM | important | unclear | low | discovery | You mentioned Airflow but not which sources fed your pipelines or whether you built the ingestion | `[grounded]` your silence | G2 |
| R11 | Data contracts analysts depend on | important | unclear | low | discovery | Your Great Expectations suite is nearby, but nothing you've said covers agreements on schema or freshness with the people consuming the data | `[grounded]` your silence | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R9, important) | transferability | Snowflake and dbt experience, no BigQuery | The JD names BigQuery in its first sentence, so it will likely come up early | A warehouse migration or evaluation; Snowflake cost or performance tuning; any GCP or BigQuery coursework or side project | A dbt repo excerpt, a tuning write-up, a small public project | `[grounded]` your "never used BigQuery"; `[generic]` that stack-named responsibilities get probed |
| G2 | Ingestion from the app and CRM (R10, important) | discovery | Airflow named, sources not | It is the first responsibility the JD lists | Pipelines pulling from a product database, an event stream or a CRM API; incremental loads and backfills | A DAG file with sources visible, or an architecture diagram | `[grounded]` your silence on sources |
| G3 | Data contracts (R11, important) | discovery | Great Expectations suite only | It is the JD's third named area and what the analysts depend on | Agreed freshness or schema expectations with analysts; alerts on upstream schema changes; tests on model outputs others relied on | A schema file excerpt, an expectation suite, a contract or runbook doc | `[grounded]` your silence; `[inferred]` that the suite may be related |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay published, at or above the band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The $157,000 midpoint is $6,000 above the $151,000 median, and the top of the range is above the $163,500 upper quartile, so no seniority-pay mismatch. The low end is $3,000 below the median | `[grounded]` posted range; `[generic]` band | Where would my experience place me in the range, and does it differ for remote versus Denver? | noted |
| RR2 | Equity terms unstated | unknown | — | "plus equity" | The grant may be options or shares of uncertain value, and Series C status doesn't tell the terms | `[generic]` pattern, not a claim about this employer | What is the equity: type, size, vesting, and latest valuation? | unresolved |
| RR3 | Employer and posting verified | positive_signal | — | "Accepting applications." | The employer exists as described and the posting is live. Funding and headcount are the company's own statements | `[grounded]` careers page fetched; about page seen as a search result | How big is the data team today, and what does each person own? | noted |
| RR4 | Scope and reporting line unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | Three areas in one post may mean a sole or near-sole data engineer, broader than the report's typical one-domain scope | `[inferred]` from the JD's three areas against `[generic]` report scope | Who does this role report to, who else is on the data team, and what does success look like at twelve months? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Resume line: "Built the dbt project (about 180 models) on Snowflake at a B2B payroll company" | R5; traces to "Built our dbt project on Snowflake — about 180 models" | `[grounded]` your message | resume_edits_pending_approval |
| E2 | Resume line: "Set up the Great Expectations data-quality test suite" | R8; traces to "I set up our Great Expectations test suite" | `[grounded]` your message | resume_edits_pending_approval |
| E3 | Cover-note sentence: "My warehouse experience is Snowflake; I haven't used BigQuery yet." | R9; naming the step yourself keeps the claim to what you said | `[grounded]` your "never used BigQuery" | pending your approval |
| W1 | A small dbt project run on BigQuery, and claim only what you actually build | R9, G1 | `[inferred]` from the G1 strengthener | pending your approval |
| A1 | Ask your recruiter for the equity terms and range placement before the first call | RR1, RR2 | `[grounded]` register | pending your approval |
| Q1 | Ask RR2 and RR4's questions verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer): live, "Accepting applications", same text as pasted. Searched "Pellucid Learning online tutoring K-12 Denver Series C", which returned "About Pellucid Learning" (pellucidlearning.com/about), same text as pasted. Moved: the contradictions row and RR3; the failed-attribution entry is not triggered |
| 2. Role-family sweep | skipped | The Datawright report's figures are in hand and fix the market calibration line and RR1, so a search could not change either |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there was no query to form |

I can turn this into a `tuesday-dossier.md` file whenever you want it.

## Upgrade menu

- Your CV: lets me check presentation gaps on R3–R8 and draft edits from its own wording.
- A sanitized dbt schema excerpt, Great Expectations suite or DAG file: raises R5, R7 and R8 toward `high`.
- Your location, authorization and pay floor: settles R1 and R2, so the decision becomes `go` or `no_go`.
- The hiring manager's name, once the recruiter has it: shapes the scope read and which story to lead with.
- A deeper research pass on Pellucid (leadership changes, hiring patterns, public employee reports, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

Questions:

1. R1: Can you work in the US without sponsorship, and would you work remote or in the Denver office?
2. R2: What is your base-pay floor, and does equity count toward it?
3. G2, G3: Which source systems fed your Airflow pipelines, and did you ever agree schema or freshness expectations with the people consuming the data, even informally?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.