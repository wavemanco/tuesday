I'll read the reference files the skill requires before building the assessment.
Reading is done, so I'm now running the company, salary-band and hiring-manager searches before I write the assessment.
**Yes, go for it, on one condition: pin down where the job is based.** The JD asks for neither pet-insurance experience nor people management, so your two stated gaps aren't requirements. The status is `conditional_go`. R2, R3, R4, R5, R6 and R7 (the `must_have` rows) read `direct`, and the one open item is R1, a `hard_gate` on location, where the JD and the live careers page disagree.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK))
- `must_have` — direct: R2, R3, R4, R5, R6, R7
- `important` — direct: R8a · unclear: R8b (Recommendations for product)
- `preferred` — direct: R9

R1 — JD and careers page disagree on where the work happens; R8b — product-side recommendations not yet evidenced; R6 (`medium`) — monitoring not stated explicitly.

**Opportunity ledger.** Clear mandate and a named reporting line (RR3), but the working location is contradicted between two sources (RR1), the salary is withheld (RR2), the team and sign-off rights are unstated (RR4), and company size and stage are not established beyond its own careers page (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) location confirmed and acceptable to you — R1, RR1; (2) the salary range is compatible with your floor — RR2; (3) you have a truthful product-recommendation example — R8b.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product; the role reports to the Director of Pricing. Size, stage and funding are not established | `[grounded]` JD; careers page `brindlemoor.co.uk/careers/senior-pricing-analyst` |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, recommend to underwriting and product | `[grounded]` JD |
| Working pattern | JD says "Fully remote (UK)". The live careers page says "Leeds office four days a week" | `[grounded]` both quotes; see RR1 |
| What the JD does not ask | Pet-insurance experience (insurance experience is "a plus") and people management are not listed | `[grounded]` JD |
| Domain distance | Pet rating likely turns on factors such as breed and age that motor does not use, so expect domain questions | `[generic]` role-family pattern |
| Scope read | One owner of pricing analytics, with no team or direct reports mentioned | `[inferred]` from the JD's "own" wording and its silence on reports |
| Market calibration | Senior pricing analysts at UK insurers and insurtechs: median £58,400, interquartile range £52,100 to £64,900. The posting withholds its figure, so this is a band, not Brindlemoor's offer | `[generic]` Pricewell 2026 pay survey (n=612); `[grounded]` JD silent on pay |
| Hiring manager | Odile Varga, Director of Pricing: spoke at the 2025 Insurance Pricing Forum on monitoring rating models in small books ("Small Books, Loud Errors"); previously head of pricing analytics at Calloway Re for six years | `[grounded]` public profile page in search results |
| Unknowns | First-90-day and first-year outcomes; team size; sign-off rights on rating changes; salary | `[grounded]` JD silence |
| Contradictions | Location (see above) | `[grounded]` JD vs careers page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | The JD says remote, the careers page says Leeds four days a week, and you've stated no location constraint, so the gate can't be settled. Confidence is none because there is no statement of yours to grade | `[grounded]` JD and careers page quotes; no candidate constraint given | Answer Q1; ask the employer (RR1) |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | "5 years pricing analytics at a UK motor insurer, the last 2 as senior analyst" clears 4+. Self-reported, nothing inspectable yet. Years of experience is not a gate | `[grounded]` your background, prose | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily"; no artifact seen | `[grounded]` your background, prose | A sanitized code or query sample would raise it to high |
| R4 | GLM experience | must_have | direct | medium | none | "Built and maintained the GLM rating model for our young-driver book": one book, motor | `[grounded]` your background, prose | A redacted model document would raise it to high |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | "Present the quarterly pricing review to the head of underwriting": underwriting side only, no actuarial audience stated | `[grounded]` your background, prose | A redacted review deck would raise it to high |
| R6 | Build and monitor rating models | must_have | direct | medium | discovery | Building and maintaining are stated. Monitoring practice (tracking drift, performance, alerts) is not stated, so the band stays medium | `[grounded]` your background; `[inferred]` that "maintained" includes monitoring | Answer Q2 |
| R7 | Design and read price tests | must_have | direct | medium | none | "Ran 14 price tests last year with the underwriting team" | `[grounded]` your background, prose | A sanitized test write-up would raise it to high |
| R8a | Turn results into recommendations for underwriting | important | direct | medium | none | Tests run with underwriting, and the quarterly review goes to its head | `[grounded]` your background, prose | none |
| R8b | Turn results into recommendations for product | important | unclear | low | discovery | Nothing stated about a product audience | `[grounded]` background silent | Answer Q3 |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer; the product line differs | `[grounded]` your background, prose | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and terms (R1, hard_gate) | hard_gate | Two sources disagree and you've given no constraints | A location mismatch could end the application whatever your fit | Not experience; a fact about what you can accept | The recruiter's written confirmation of working pattern | `[grounded]` JD vs careers page |
| G2 | Model monitoring (R6, must_have) | discovery | Build and maintain are clear; monitoring is not described | The JD names "monitor"; a stated monitoring practice would firm the row | A drift or performance report you reviewed; a scheduled model-health check; a trigger for refitting | A redacted monitoring pack | `[grounded]` background wording; `[inferred]` that the JD's "monitor" makes this worth confirming |
| G3 | Product audience (R8b, important) | discovery | Only underwriting is mentioned | JD names product as a recommendation audience | A price-test result taken to a product or proposition team; input to a new feature or cover-level decision | A sanitized recommendation memo | `[grounded]` background silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working location contradicted (see R1) | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | The JD copy may be stale, or the page may reflect the real expectation | `[inferred]` from two sources disagreeing | Is this role fully remote, or based in the Leeds office four days a week? | unresolved |
| RR2 | Salary withheld | unknown | — | JD gives no compensation figure | Pay may sit anywhere in or outside the market band | `[inferred]` from the missing figure against the `[generic]` band | What is the salary range for this role? | unresolved |
| RR3 | Clear ownership and reporting line | positive_signal | — | "Own pricing analytics for our pet-insurance product; reports to the Director of Pricing" | Scope and manager are defined | `[grounded]` careers page and JD | What would a successful first year look like? | noted |
| RR4 | Team and decision rights unstated | unknown | — | "turn the results into recommendations for underwriting and product" | Role may recommend without sign-off authority, and may be a one-person function | `[inferred]` from the JD's silence on team and sign-off | Who else is in the pricing team, and who signs off rating changes? | unresolved |
| RR5 | Company size and stage not established | unknown | — | "Brindlemoor (insurtech)" | A first company search returned nothing; only its careers page and a profile page surfaced | `[grounded]` search results; `[generic]` that small firms often have thin footprints | How large is the company, and at what funding stage? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Open with: "Five years in pricing analytics at a UK motor insurer, the last two as senior analyst; built and maintained the GLM rating model for the young-driver book; ran 14 price tests with the underwriting team last year." Every clause is your own sentence | see R2, R4, R7 | `[grounded]` your background | resume_edits_pending_approval |
| A1 | Confirm the working pattern with the recruiter before investing in the application | see R1, RR1 | `[grounded]` register | pending your approval |
| A2 | Read Odile Varga's published talk or writing before any interview | The mandate names monitoring, and her public talk covers it | `[grounded]` her profile; `[inferred]` relevance from the JD's "monitor" | pending your approval |
| A3 | Say plainly in the application that your insurance work is motor, and that you'd come to pet-specific rating as a learner | see R9 and role reality's domain row | `[generic]` role-family pattern | pending your approval |
| W1 | A one-page sanitized price-test write-up | see R7, R8b | `[grounded]` R7, R8b rows | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech" (no results) and "Brindlemoor careers Senior Pricing Analyst"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). Role reality: the location contradiction (RR1); company size and stage stayed unestablished (RR5) |
| 2. Role-family sweep | yes | Searched "Senior Pricing Analyst pet insurance UK remote salary", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). Market calibration, and RR2's band |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga). Role reality's hiring-manager row and A2 |

## Dossier offer

I can save this as `tuesday-dossier.md` if you want to keep it.

## Upgrade menu

- Your non-negotiables on location, days in office and pay → R1 can resolve to met or failed, and RR2 gets set against your floor.
- A redacted GLM document, monitoring pack, review deck or test write-up → R3, R4, R5, R6 or R7 move from `medium` to `high`.
- A product-facing recommendation example → R8b closes.
- A deeper research pass on Brindlemoor (funding, leadership, public staff reports; up to 5 more searches and 2 more fetches) → RR5 may close. Say the word and it runs.

## Questions

1. **G1 (R1)** — What are your non-negotiables on location, office days and pay, and does a Leeds office four days a week fit them?
2. **G2 (R6)** — Did you track the young-driver model's performance after launch, and if so how, and what did you do when it drifted?
3. **G3 (R8b)** — Have you taken a price-test result to a product or proposition team, and what did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.