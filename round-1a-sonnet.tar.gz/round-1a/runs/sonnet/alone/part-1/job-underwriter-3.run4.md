I'll read the skill's reference files before building the assessment.
I've read the skill's reference files and I'm now running two research searches: one to check that Novaline exists, and one for the pay band for this role. After that I'll write the assessment.
# Job Underwriting Assessment: Head of Growth at Novaline

## Decision snapshot

**No, this posting isn't worth pursuing as written. R1 and R2, both hard gates, fail. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: hard_gate_fail: R1 (Pay: $70–85k base against a $150k floor), R2 (On-site Austin five days, against remote-only)
- `must_have`: direct: R4, R5 · adjacent: R3 (8+ years growth leadership)
- `important`: unclear: R6 (SEO/content), R7 (brand and PR), R8 (partnerships), R9 (sales ops)

R1 and R2 — pay and location both fail; R4 and R5 — the paid and lifecycle match you saw on paper; R3 — a question of how many of your years were in leadership, not a gate.

**Opportunity ledger.** Your sense that something is off is borne out by the posting itself: seven functions are bundled onto one person (RR2), the pay sits well below the seniority asked for (RR1), always-on hours are expected (RR3), success metrics are undefined (RR4), and budget, decision rights and equity are unstated (RR5, RR6). One entry runs the other way, because the posting states its pay and on-site terms plainly (RR8). The employer is not verified (RR7).

- **Hard gates:** failed: R1 (Pay: $70–85k base against a $150k floor), R2 (On-site Austin five days, against remote-only)
- **Severe red flags:** none found. RR2 is a red flag at `severity: medium`.
- **What would change this:** the posting would have to offer at least $150k base (R1) and allow remote work from Portland (R2). The posting says "no exceptions" on location, so R2 has no path to resolution on the employer's own words.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` JD header; not independently verified (RR7) |
| Mandate | "Own all revenue growth end to end": paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` JD |
| Reporting | CEO, with a dotted line to the board | `[grounded]` JD |
| Team and resources | "A team of one to start"; no budget stated | `[grounded]` JD |
| Working pattern | "Evenings and weekends when it matters is just who we are"; on-site Austin five days, "no exceptions" | `[grounded]` JD |
| Pay | $70–85k base plus unquantified "meaningful equity upside". The gap to your floor is $65–80k | `[grounded]` JD figure and your stated floor |
| Success metrics | "Will evolve as we learn"; no first-90-day or first-year outcomes stated | `[grounded]` JD |
| Scope read | Seven functions with no bench is the work of several roles folded into one title | `[inferred]` from the function count against "team of one" |
| Market calibration | Not calibrated. The role-family search was refused, so I state no market band. The pay gap in R1 rests on the posting's figure against your floor alone | `[grounded]` JD figure and your floor |
| Unknowns | Budget, decision rights, equity terms, customer type (B2B or B2C), whether the employer verifies | — |
| Contradictions | Not checkable: the careers page was not reached | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Compensation: $70–85k base (your floor: at least $150k base) | hard_gate | hard_gate_fail | high | hard_gate | Even the top of the range is $65k below your floor. Equity is not base pay and is unquantified, so it doesn't offset the gap. Confidence grades your stated constraint, not the role | `[grounded]` JD quote and your stated floor | none. Wording can't close this; only a base of $150k or more would |
| R2 | On-site Austin, five days a week, "no exceptions" (you: remote-only, Portland, not relocating) | hard_gate | hard_gate_fail | high | hard_gate | The posting excludes the exception you would need. Confidence grades your stated constraint, not the role | `[grounded]` JD quote and your stated constraint | none |
| R3 | 8+ years growth leadership | must_have | adjacent | medium | discovery | You said "9 years in growth", then Growth lead, then Head of Growth. The 9 years attach to growth, not to leadership, so I resolve downward until you say how many were in lead or head titles. Confirmed prose with no inspectable artifact, so expect a probe. A years-of-experience requirement is not a gate | `[grounded]` your background, stated in prose | confirm the years in lead and head titles |
| R4 | Paid acquisition | must_have | direct | medium | none | You said you "owned paid" at two B2C subscription companies and had a budget you controlled during the $8M to $40M ARR scale-up. Confirmed prose, nothing inspected yet | `[grounded]` your background, stated in prose | a sanitized channel or budget summary would raise this to `high` |
| R5 | Lifecycle / CRM | must_have | direct | medium | none | You said you owned lifecycle and are deep in Braze. Confirmed prose, nothing inspected yet | `[grounded]` your background, stated in prose | a sanitized lifecycle program summary would raise this to `high` |
| R6 | SEO / content | important | unclear | none | discovery | Your background doesn't mention it. Silence is not absence on a first pass | `[grounded]` your background is silent | see G2 |
| R7 | Brand and PR | important | unclear | none | discovery | Your background doesn't mention it | `[grounded]` your background is silent | see G2 |
| R8 | Partnerships | important | unclear | none | discovery | Your background doesn't mention it | `[grounded]` your background is silent | see G2 |
| R9 | Sales ops | important | unclear | none | discovery | Your background doesn't mention it. The posting doesn't say whether Novaline sells B2B or B2C | `[grounded]` your background is silent; `[inferred]` that the sales-ops fit depends on Novaline's customer type | see G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Years in growth leadership (R3, must_have) | discovery | "9 years in growth" and two lead-level titles, with no split of years by title | A literal reading of "8+ years growth leadership" turns on this split | Start and end dates for the Growth lead and Head of Growth roles | Prior resume or LinkedIn dates | `[grounded]` your prose gives no split by title |
| G2 | SEO/content, brand and PR, partnerships, sales ops (R6, R7, R8, R9, all important) | discovery | Nothing in your background touches them | They matter only if R1 and R2 ever move | Any content or SEO program you directed; partner or affiliate deals you brokered; press or brand work you owned; sales-handoff or CRM-to-sales work | A sanitized program summary or deal list | `[grounded]` your prose is silent on them |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay looks low for the seniority and scope asked | risk_signal | medium | "Compensation: $70–85k base plus meaningful equity upside" against "8+ years growth leadership required" | The pay may be set for a narrower or more junior role than the title and scope describe. I can't confirm against a market band because the role-family search was refused, so this stays a risk signal | `[inferred]` from the JD's seniority and scope against its figure | What is the budgeted base for this role, and is any of it flexible? | unresolved |
| RR2 | Seven functions on one person, with no team | red_flag | medium | "Own all revenue growth end to end: paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops. You will be a team of one to start" | Several full roles are folded into one title. I took the lower severity because the posting doesn't say whether hires will follow | `[inferred]` from the function count against "team of one" | Which of these functions will be hired for, and when, and what budget covers contractors or tools? | unresolved |
| RR3 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Extra hours may be routine, not occasional | `[inferred]` from the phrase "just who we are" | In the last quarter, how many evenings and weekends did the team work, and was it compensated? | unresolved |
| RR4 | Success undefined on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | You could be held accountable for a moving target | `[inferred]` from the JD's silence on outcomes | What would you expect the first hire to have achieved at 90 days and at 12 months? | unresolved |
| RR5 | Budget and decision rights unstated | unknown | — | "Report to the CEO with a dotted line to the board" | Responsibility without stated spend or authority; the dotted line may add oversight without adding authority | `[inferred]` from the JD's silence on budget | What marketing budget does this role control, and which decisions does it make alone? | unresolved |
| RR6 | Equity unquantified | unknown | — | "meaningful equity upside" | "Meaningful" may be a small grant with unfavorable terms | `[inferred]` from the JD giving no share count, percentage or vesting | What is the grant as a percentage of fully diluted shares, and what are the vesting and strike price? | unresolved |
| RR7 | Employer not verified | unknown | — | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The company may be small, new or hard to find, or the posting may not be what it says. I could not check | `[generic]` pattern for early-stage companies, not a claim about this one | Can you point me to this role on Novaline's own careers site, and tell me who I would interview with? | unresolved |
| RR8 | Pay and on-site terms stated up front | positive_signal | — | "$70–85k base" and "on-site in our Austin office 5 days a week — no exceptions" | The posting lets you see the terms before spending effort | `[grounded]` JD | Is the on-site rule fixed for this role as the posting says? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply to this posting as written | R1 and R2 both fail, and the employer has closed R2 in its own words | `[grounded]` R1, R2 | pending your approval |
| A2 | If you choose to proceed against the `no_go`, ask the RR1, RR2 and RR5 questions verbatim before investing further | They are the questions most likely to confirm the mismatch quickly | `[grounded]` register | pending your approval |
| A3 | Check pay and location against your two constraints before reading a posting for fit | Wording can't fix a gate, so checking gates first saves effort | `[inferred]` from how this posting fails them | pending your approval |

No resume edits are proposed.

## Evidence status

Verified: R1 and R2, as your own stated constraints. Verified is about the claim, not the fit, and the fit of both is `hard_gate_fail`. Unverified leads: R3, R4 and R5 come from your prose background, which has the standing of a CV and has not been inspected.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Series A Austin careers Head of Growth"; the call was refused and returned nothing. It would have moved role reality's organization and contradictions rows and RR7 |
| 2. Role-family sweep | unavailable | Searched "Head of Growth salary base range Series A startup 2026"; the call was refused and returned nothing. It would have moved the market calibration row and RR1 |
| 3. Hiring manager's public footprint | n/a | No name was given. The posting says only "the CEO" |

I can produce `tuesday-dossier.md` from this assessment if you want a saved copy.

## Upgrade menu

- Permission to run web searches would let me retry targets 1 and 2. That would confirm whether Novaline exists as described (RR7) and calibrate the pay against a market band (RR1, market calibration row).
- The dates of your Growth lead and Head of Growth roles would settle R3 (G1).
- A sanitized channel or budget summary would raise R4 to `high`, and a sanitized lifecycle program summary would raise R5.
- Any SEO, brand, PR, partnership or sales-ops work you have done would move R6 through R9 (G2).
- A link to the live posting on Novaline's own careers page would close RR7.
- A deeper research pass on Novaline (up to 5 more searches and 2 more fetches) could add funding and hiring-pattern findings to the register. It can't change the `no_go`, and it would need search permission first.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.