Still loading the skill's reference rules, mainly the snapshot format and the fit and gap vocabulary. After that I'll write the full assessment.
**Yes, apply. You're a fit on the core of this role, and the posting needs one check first. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R5 · unclear: R6 (Define and maintain the metrics layer)
- `important` — direct: R7a · unclear: R7b (Partner with clinicians), R8 (Mentor two junior analysts)
- `preferred` — adjacent: R9 (Healthcare data experience, HIPAA); R9 (`medium`)

R6 — governed Looker work is plausible evidence, but nobody has confirmed you owned metric definitions; R7b and R8 — your background is silent; R9 — a privacy bridge, not HIPAA.

**Opportunity ledger.** The posting reads as concrete (RR4), but I couldn't establish that Harborlight exists as described (RR1). Compensation is withheld (RR2), and the JD gives no authority basis for the mentoring (RR3).

- **Hard gates:** none failed. The JD states no authorization, location, schedule or pay term, so there are no gate rows. Candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is live on Harborlight's own careers page (RR1); (2) the R6 metrics-layer ownership is confirmed by you; (3) the healthcare gap is carried as adjacent (R9), never as HIPAA experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up of about 400 people at Series C, with a care-navigation app | `[grounded]` JD header as pasted; not verified (RR1) |
| Mandate | Own product analytics: metrics layer, A/B tests, self-serve Looker dashboards, partnering with PMs and clinicians, mentoring two junior analysts | `[grounded]` JD |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Working pattern, location, pay | Not stated | `[grounded]` JD silent |
| Scope read | Hands-on ownership of one product area plus light team leadership; "own" and "mentor" together suggest a lead-IC post, not a manager role | `[inferred]` from "own product analytics" set against "mentor two junior analysts" with no mention of reports or hiring |
| Market calibration | Not run, so there is no band for title, scope or pay | `[generic]` none; the role-family sweep did not run |
| Unknowns | Salary; location and remote policy; whether the two juniors are direct reports; who the clinical partners are; Looker's current state (greenfield or inherited) | — |
| Contradictions | None between the JD and your background as provided | `[grounded]` the two inputs |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Your 6 years of product analytics at a ~2M-subscriber meal-kit company clears the stated bar. It is a length-of-experience line, not a gate. No document inspected | `[grounded]` your account | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake across 6 years. "Expert" is a level a screen or interview tests, so expect a live SQL exercise | `[grounded]` your account | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | You designed and ran a program of 30+ A/B tests a year, including the pricing test tied to an 11% retention lift. A 2M-subscriber base is plausible scale, but the JD doesn't define "at scale". Expect probing on your own role in the pricing test | `[grounded]` your account; `[inferred]` that 2M subscribers meets "at scale" | a sanitized test write-up would raise to high |
| R4 | Looker or a similar BI tool | must_have | direct | medium | none | You built the company's Looker instance from scratch, with 40+ governed dashboards | `[grounded]` your account | a dashboard screenshot would raise to high |
| R5 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads and present monthly to the VP Product | `[grounded]` your account | a sanitized memo would raise to high |
| R6 | Define and maintain the metrics layer | must_have | unclear | medium | discovery | Looker with 40+ governed dashboards and a warehouse consent-state model are adjacent, but you haven't said whether you authored the explores or metric definitions. I'm not inferring it | `[grounded]` your account; `[inferred]` that governed dashboards imply some metric governance | see gap queue G1 |
| R7a | Partner with product managers on roadmap decisions | important | direct | medium | none | You present monthly to the VP Product and write the exec memo | `[grounded]` your account | none |
| R7b | Partner with clinicians | important | unclear | none | discovery | Nothing provided on working with clinical or other domain experts | `[grounded]` your account silent | see gap queue G2 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Your background is silent on mentoring or leading analysts | `[grounded]` your account silent | see gap queue G3 |
| R9 | Healthcare data experience (HIPAA) a plus | preferred | adjacent | medium | transferability | GDPR/CCPA consumer-PII handling and a consent-state model are a credible privacy-data bridge. Limit: no healthcare data and no HIPAA exposure, and that limit must stay visible wherever the bridge is used | `[inferred]` adjacency from the privacy work you described; `[generic]` that regulated-data posture is what the "plus" is probing | frame as adjacent only |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R6, must_have) | discovery | Built Looker, 40+ governed dashboards, a consent-state model | R6 is the first-listed responsibility, and a `must_have` row at `unclear` is the one most likely to move the decision | Writing LookML or equivalent, a canonical metric dictionary, resolving "two dashboards, two numbers" disputes | A sanitized metric-definition doc or an explore screenshot | `[inferred]` from the governed-dashboard claim |
| G2 | Clinician partnership (R7b, important) | discovery | Nothing on domain-expert stakeholders | The JD names clinicians as co-owners of roadmap decisions | Working with nutritionists, culinary, medical or compliance experts in a non-analyst function | A project where a domain expert changed your analysis | `[grounded]` your account silent |
| G3 | Mentoring (R8, important) | discovery | Nothing on mentoring | JD lists it as a duty | Onboarding analysts, reviewing others' SQL or experiments, informal tech-lead work | Any named instance with scale and outcome | `[grounded]` your account silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | A scale-up this size should have a public footprint, but the search was not permitted, so existence and posting liveness are unchecked. It may be real and fine | `[generic]` pattern, not a claim about this company | Is the role on Harborlight's own careers site, and who would I interview with? | unresolved |
| RR2 | Compensation not stated | unknown | — | JD as pasted has no pay figure | The band may or may not fit a 6-year senior analyst; I can't calibrate it | `[inferred]` from the pasted text's silence | What is the budgeted range for this role? | unresolved |
| RR3 | Mentoring duty with no stated authority | unknown | — | "mentor two junior analysts" | The juniors may report to you, or may be a dotted-line arrangement under a different manager | `[inferred]` from the JD's silence on reporting lines | Do the two junior analysts report to this role? | unresolved |
| RR4 | Explicit responsibilities and named tooling | positive_signal | — | "define and maintain the metrics layer, design and analyze A/B tests, build self-serve dashboards in Looker" | The scope is specific, not a vague "data person" posting | `[grounded]` JD | What are the first three metrics or experiments this role would own? | noted |

## Application plan

All rows below, and the advice in them, are proposals pending your approval; nothing is final until you say so.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Verify the posting on Harborlight's own careers page before investing time | see RR1 | `[grounded]` RR1 | pending your approval |
| E1 | Lead with the experimentation program and the pricing test (R3), stating your own role in it exactly as it was, without implying the test alone produced the 11% lift | see R3 | `[grounded]` your account | pending your approval |
| E2 | Put the Looker build and governed dashboards near the top, with an honest line on what you defined versus what others did (R4, R6) | see R4, R6 | `[grounded]` your account | pending your approval |
| E3 | Describe the consent-state model and GDPR/CCPA work as privacy-data experience; state plainly that you haven't worked with HIPAA data, with no wording that implies otherwise | see R9 | `[grounded]` R9 row | pending your approval |
| Q1 | Ask RR1, RR2 and RR3 verbatim in the recruiter conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Harborlight Health care navigation app careers"; the host refused it, so the employer's existence and the posting's liveness are unchecked. It would have moved RR1 and role reality's organization and contradictions rows |
| 2. Role-family sweep | unavailable | Searched "Senior Product Analyst digital health salary range US"; the host refused it. It would have moved the market calibration line, and RR2's band |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer

I can save all of this as a `tuesday-dossier.md` file if you'd like.

## Upgrade menu

- Permission for web search, or a link to the live posting or Harborlight's careers page → RR1 resolves, and the market calibration and RR2's pay band can run.
- A deeper diligence pass (funding and leadership churn, candidate and employee reports, recent news; up to 5 more searches and 2 more fetches) — say the word once search works and it runs.
- A sanitized A/B test write-up → R3 to `high`.
- A sanitized metric-definition doc or explore screenshot → R6 resolves, and R4 can reach `high`.
- A sanitized monthly memo → R5 to `high`.
- The hiring manager's name → the scope read and which of your stories to lead with.
- Your pay floor, location and authorization needs → the hard-gate checks stop being unknown.

## Questions

1. **(G1, R6)** Did you write the metric definitions yourself, for example in LookML or a shared metric dictionary, or did you consume definitions others owned?
2. **(G3, R8)** Have you onboarded, mentored or reviewed the work of other analysts, formally or informally?
3. **(Hard gates)** What are your non-negotiables on pay floor, location or remote, and work authorization, so I can check them against the role?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.