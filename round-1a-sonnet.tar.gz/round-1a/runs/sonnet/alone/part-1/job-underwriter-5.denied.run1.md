## Decision snapshot

**Yes, this is worth an application, with conditions. Status: `conditional_go`.** R1, R2, R3, R4 and R5, the whole `must_have` tier, are `direct`. Two things hold it at conditional: R9 and R10 can't be checked against your constraints, because you haven't given any. RR1 is also open, because I couldn't re-check the posting or the company live.

**Fit ledger.**

- `hard_gate`: unclear: R9 (Salary $148,000–$166,000), R10 (Remote (US) or Denver office)
- `must_have`: direct: R1, R2, R3, R4, R5
- `important`: adjacent: R6 (a dbt-modelled warehouse in BigQuery) · unclear: R7 (ingestion from our app and CRM), R8 (data contracts our analysts depend on)

R6 — a credible bridge, its limit named; R7, R8 — your background is silent, so discovery.

**Opportunity ledger.** The pay is in market (RR5) and the stack and deliverables are concrete (RR6). Equity (RR2), the manager and team (RR3) and how broad the scope is (RR4) are unknown. The employer is unverified from here (RR1).

- **Hard gates:** none failed; unconfirmed: R9 (Salary $148,000–$166,000), R10 (Remote (US) or Denver office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting verifies live on Pellucid's careers page (RR1); (2) your pay floor and location fit (R9, R10); (3) scope and team size come back sensible (RR3, RR4); (4) BigQuery is described as adjacent, never as experience (R6).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states. Founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` About text as you pasted it; not re-checked live |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and the data contracts analysts depend on | `[grounded]` JD |
| Terms | $148,000–$166,000 plus equity; Remote (US) or the Denver office | `[grounded]` JD |
| Scope read | Three areas (ingestion, modelling, contracts) under one "build and run" mandate, with no team size, no reports and no on-call expectations stated. That is probably wider than a single domain's pipelines | `[inferred]` from the JD's three areas against the report's typical scope below |
| Market calibration | Report median is $151,000, interquartile range $139,000–$163,500, for Senior Data Engineers at Series B–D companies. The posting's low end is $3,000 under the median and its top end is $2,500 above the range's upper bound. "Senior" typically means 5–8 years and ownership of one domain's pipelines with no direct reports. The band is what the market pays, not this employer's offer | `[generic]` Datawright 2026 report (n=2,310) as sent by your recruiter; `[grounded]` the JD's figure |
| Unknowns | Hiring manager (none named), team size, equity terms, on-call, who the analysts are | `[grounded]` JD silence |
| Contradictions | None between the pasted JD and About text; neither could be re-checked live | `[grounded]` pasted pages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years of data engineering at a B2B payroll company. That's self-report with nothing inspectable yet, so `medium`, and expect a probe on what you owned | `[grounded]` your background as stated | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | Daily use is stated; no artifact has been inspected | `[grounded]` your background as stated | none |
| R3 | dbt and a cloud warehouse | must_have | direct | medium | none | Built the company's dbt project on Snowflake, about 180 models. Specific, with nothing inspectable yet. The BigQuery part of the stack is R6 | `[grounded]` your background as stated | offer: a sanitized dbt docs or lineage excerpt would raise to `high` |
| R4 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow stated by name | `[grounded]` your background as stated | none |
| R5 | Experience with data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite; it's a first-person ownership claim | `[grounded]` your background as stated | offer: a sanitized suite config or a list of the checks would raise to `high` |
| R6 | A dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | What carries over is dbt modelling on another cloud warehouse (R3). The limit is that you've never used BigQuery, so partitioning, cost model and its SQL dialect are untouched. The JD's requirements list says "a cloud warehouse", while BigQuery appears only in the mandate, so I tiered it `important` | `[grounded]` your stated Snowflake-only history; `[inferred]` the tiering from JD wording | see gap queue G1 |
| R7 | Ingestion from the app and CRM | important | unclear | low | discovery | Nothing in your background says either way. Low, not none, since payroll platforms normally ingest from operational systems | `[grounded]` background silence; `[generic]` that pattern | see gap queue G2 |
| R8 | Data contracts analysts depend on | important | unclear | low | discovery | Silent. Your tests and dbt work may have involved contract-like agreements with analysts or upstream teams, but nothing says so | `[grounded]` background silence | see gap queue G3 |
| R9 | Salary $148,000–$166,000 | hard_gate | unclear | none | hard_gate | The JD states the figure, but you gave no floor, so nothing can be confirmed against it | `[grounded]` JD; no constraint supplied | one gate question, below |
| R10 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | The JD states the terms, but you gave no location or authorization constraints | `[grounded]` JD; no constraint supplied | same question as R9 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R6, important) | transferability | dbt and Snowflake, no BigQuery | The role's warehouse is BigQuery. A real bridge with its limit named reads stronger in screening than an implied claim | A personal or side project on BigQuery's free tier; a Snowflake-to-BigQuery comparison you've worked through; a migration you scoped | A small repo or dbt project run against BigQuery | `[grounded]` your stated no-BigQuery history; `[generic]` that this is the likeliest objection for this stack |
| G2 | Ingestion from app and CRM (R7, important) | discovery | Silent | It is the first-named responsibility in the JD, and the answer could move R7 to `direct` | Loading from a product database or event stream; syncing Salesforce, HubSpot or a similar CRM into the warehouse; an ELT tool or custom loader you ran | A pipeline diagram, a DAG screenshot, a README | `[grounded]` background silence on sources |
| G3 | Data contracts (R8, important) | discovery | Silent | The JD names contracts as something analysts depend on | Agreed schemas or SLAs with upstream owners; dbt model contracts, tests or freshness checks that analysts relied on; a deprecation or breaking-change process | A sanitized schema spec, a contract doc, a dbt YAML excerpt | `[grounded]` background silence on contracts |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not established from here | risk_signal | low | "Founded 2016, Denver. 264 employees. Series C ($52M, February 2026)." | The text came from the company's own pages, so I rate this low, not medium. The posting could still be stale or aggregated | `[generic]` pattern for any posting not re-checked, not a claim about Pellucid | Can you confirm this role is open, and point me at it on your careers site? | unresolved |
| RR2 | Equity unspecified | unknown | — | "plus equity" | The grant could be small or large; the JD gives no size, vesting or valuation basis | `[grounded]` JD silence | What is the equity range for this level, and how does it vest? | unresolved |
| RR3 | Hiring manager and team unnamed | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | Team size and reporting line are unknown | `[grounded]` JD silence; you noted the posting names no manager | Who would I report to, and who else is on the data team? | unresolved |
| RR4 | Scope may be wider than one domain | risk_signal | low | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts our analysts depend on" | One person could be asked to own ingestion, modelling and contracts. The report's typical scope is one domain's pipelines | `[inferred]` from the JD's three areas; `[generic]` the report's norm | Which of these areas does this role own, and what is the on-call expectation for running them? | unresolved |
| RR5 | Pay at or above the market band | positive_signal | — | "$148,000–$166,000 plus equity" | Stated pay is competitive for a Senior Data Engineer at this stage | `[grounded]` JD figure against the report as pasted | What is the leveling for this band? | noted |
| RR6 | Stack and deliverables are concrete | positive_signal | — | "dbt-modelled warehouse in BigQuery" | Named tools and outputs suggest a defined role | `[grounded]` JD | What does success look like at 90 days? | noted |

## Application plan

All rows below are proposed. Nothing in this table or in the advice around it is final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the resume with the dbt project (about 180 models on Snowflake), the Airflow orchestration and the Great Expectations suite you set up | see R3, R4, R5 | `[grounded]` your stated background | pending your approval |
| E2 | Describe BigQuery honestly as new to you, with Snowflake dbt as the bridge. Don't list it as a skill | see R6 | `[grounded]` your stated no-BigQuery history | pending your approval |
| A1 | Confirm the posting is live on Pellucid's careers page and apply there | see RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask the verification questions of RR1, RR2, RR3 and RR4 in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Pellucid Learning Series C $52M tutoring Denver" and fetched pellucidlearning.com/careers/senior-data-engineer; both were refused because tool permission wasn't granted. It would have moved the contradictions row and RR1 |
| 2. Role-family sweep | skipped | The pasted Datawright report fixes the market calibration row and RR5; a search couldn't change them |
| 3. Hiring manager's public footprint | n/a | The posting names no manager, so there was no query to form |

## Closing

I can write all of this to `tuesday-dossier.md` if you want a saved copy.

**Upgrade menu**
- Web access, permitted for the posting and company check → RR1 resolves, and the contradictions row is confirmed.
- A sanitized dbt docs or lineage excerpt → R3 to `high`.
- A sanitized Great Expectations config or check list → R5 to `high`.
- A small BigQuery project or repo → G1 and R6 strengthen.
- Your pay floor and location constraints → R9 and R10 resolve.
- The hiring manager's name → the scope read and the lead story in the plan sharpen.
- A deeper Pellucid pass, if you want it (up to 5 more searches and 2 more fetches) → funding, leadership and hiring-pattern checks for the register.

**Questions**
1. R9 and R10 — Do $148,000–$166,000 and a US-remote or Denver-based role both work for you, with no minimum or location constraint I should know about?
2. R7 — Have you owned ingestion from an application database or a CRM into your warehouse, and what was yours?
3. R8 — Have you set up data contracts, or agreed schemas or SLAs, that analysts or upstream teams relied on?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.