I'll read the reference files the skill points to before building the assessment.
## Decision snapshot

**Yes, apply, on conditions. Your two worries, no pet insurance and no line management, are not requirements in the posting (see role reality). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK))
- `must_have` — direct: R2, R3, R4, R5a, R6, R8 · unclear: R5b (Monitor rating models)
- `important` — unclear: R7 (Recommendations for product)
- `preferred` — direct: R9

R5b — your wording says built and maintained, not monitored; R6 (`medium`) — you ran 14 tests, and whether you designed them is unconfirmed; R7 — product-side recommendations aren't evidenced yet.

**Opportunity ledger.** Sound on its face but unverified: I couldn't establish the employer from my search (RR1), pay is withheld (RR2), and team size and decision rights are unstated (RR3). One entry runs the other way: the responsibilities are specific and a named Director owns the role (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Brindlemoor and the live posting verify (RR1); (2) you confirm you're UK-based and can work remotely from there (R1); (3) you can evidence monitoring work, or the gap is stated plainly in the application (R5b, G1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD header |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote (UK) | `[grounded]` JD |
| Reports to | Odile Varga, Director of Pricing | `[grounded]` user-supplied |
| Pet-specific experience | Not listed as a requirement; the JD says "insurance experience a plus" | `[grounded]` JD |
| People management | No requirement for it, and no reports are mentioned | `[grounded]` JD silence |
| Scope read | One product line, with a single owner of its pricing analytics; team size and who else sits in pricing aren't stated | `[inferred]` from "own" against the JD's silence on team |
| Hiring manager footprint | Spoke at the 2025 Insurance Pricing Forum on "Small Books, Loud Errors" (monitoring rating models in small books); previously head of pricing analytics at Calloway Re for six years | `[grounded]` search result for her profile page, snippet only |
| Market calibration | UK senior pricing analyst base pay at insurers and insurtechs: median £58,400, interquartile range £52,100 to £64,900. The posting states no salary, so this is the band to expect, not Brindlemoor's offer (RR2) | `[generic]` Pricewell 2026 survey (n=612); `[grounded]` JD for the missing salary |
| Unknowns | Salary; team and decision rights; success measures; whether the posting is live on the company's own site | `[grounded]` JD silence |
| Contradictions | None found between the JD and your background; the JD couldn't be checked against a careers page | `[grounded]` search returned no company page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | low | hard_gate | You work at a UK insurer, but you haven't stated where you're based or your right to work. Confidence is `low` because there is no stated constraint to grade | `[inferred]` from "UK motor insurer" in your background | G3: confirm the gate is met |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years in pricing analytics, the last 2 as senior analyst. Prose self-report, nothing inspected | `[grounded]` your background, stated in prose | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Daily" use is specific, but no artifact has been inspected | `[grounded]` your background | A sanitised notebook or query sample would raise it to `high` |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. Motor GLM, not pet | `[grounded]` your background | A sanitised model-documentation page or lift chart would raise it to `high` |
| R5a | Build rating models | must_have | direct | medium | none | Same GLM evidence as R4, claimed for one young-driver model | `[grounded]` your background | none |
| R5b | Monitor rating models | must_have | unclear | low | discovery | "Maintained" may include monitoring but doesn't establish it. Ongoing model-performance tracking is not stated | `[grounded]` your wording; `[generic]` that maintaining a model usually involves some monitoring, which isn't evidence here | G1 |
| R6 | Design and read price tests | must_have | direct | medium | discovery | You ran 14 tests last year with underwriting. "Ran" is what you said, so I'm not reading it as "designed" until you confirm (ambiguity resolves downward) | `[grounded]` your background | G2 |
| R7 | Turn results into recommendations for product | important | unclear | low | discovery | You present to underwriting. Nothing links your work to product decisions | `[grounded]` your background silence | G4 |
| R8 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your background | A sanitised review deck would raise it to `high` |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | 5 years at a UK motor insurer. The limit is that it's motor, not pet; the JD asks for insurance generally | `[grounded]` your background and JD | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Monitoring rating models (R5b, must_have) | discovery | "Built and maintained" a GLM, with no mention of tracking its performance after launch | A must-have at `unclear`; resolving it is the likeliest way to firm up the application | Tracking actual-vs-expected or loss ratios on the model; refit or recalibration triggers; drift or segment checks; a model review pack | A monitoring dashboard, a review deck or a recalibration note, sanitised | `[grounded]` CV-equivalent silence; `[generic]` that rating-model roles routinely test for monitoring |
| G2 | Designing price tests (R6, must_have) | discovery | You "ran" 14 tests; who set the hypothesis, split and success measure isn't stated | A must-have where "design" is named in the JD | Choosing test and control splits, sizing a test, setting guardrails, deciding the readout metric | A test plan or a readout, sanitised | `[grounded]` your wording |
| G3 | UK-based and able to work remotely (R1, hard_gate) | hard_gate | Nothing stated about location or right to work | A gate the inputs don't settle | Not applicable: it is met or it isn't | Not needed | `[grounded]` no statement given |
| G4 | Product-side recommendations (R7, important) | discovery | Your audience so far is underwriting | The JD names product as a recipient | A pricing change you took to product or proposition owners; a test readout read by product | A readout or a brief, sanitised | `[grounded]` your background silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not be a real hiring employer. A profile page for Odile Varga naming Brindlemoor turned up, but it is third-party and doesn't establish the company or a live role | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your careers site, and who I'd interview with? | unresolved |
| RR2 | Salary not stated | unknown | — | JD gives no pay figure | Pay may sit above or below the market band in role reality | `[grounded]` JD silence; `[generic]` band | What salary range is budgeted for this role? | unresolved |
| RR3 | Team and decision rights not stated | unknown | — | "Own pricing analytics for our pet-insurance product" | You may be the sole pricing analyst, accountable for recommendations without clarity on who decides | `[inferred]` from "own" against the JD's silence on team, reports and authority | Who else sits in pricing today, and which pricing changes does this role recommend rather than decide? | unresolved |
| RR4 | Responsibilities specific, with a named senior owner | positive_signal | — | "build and monitor rating models, design and read price tests, and turn the results into recommendations" | The duties are concrete and consistent with each other | `[grounded]` JD | What would success look like in the first year? | noted |

## Application plan

Every row below, and the positioning notes inside them, is a proposal and `pending your approval`. Nothing is final until you say so.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | In your CV, lead with the GLM you built and maintained, the 14 price tests run with underwriting, and the quarterly review to the head of underwriting, in your own words and figures. Keep "ran" as "ran" until G2 is answered | see R4, R5a, R6, R8 | `[grounded]` your background | resume_edits_pending_approval |
| E2 | If G1 yields real monitoring evidence, put it near the top, since the JD names monitoring and the hiring manager's published talk is about monitoring models in small books | see R5b | `[grounded]` JD and search snippet | pending your approval |
| A1 | Before investing effort, find the role on Brindlemoor's own careers page and check that any recruiter email comes from the company's domain | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Say plainly that your insurance work is motor, not pet, and that you'd be learning the pet rating factors | see R9 | `[grounded]` your background | pending your approval |
| Q1 | Ask the verification questions of RR1, RR2, RR3 and RR4 verbatim in the loop | the register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Stage assumed: evaluating, since you didn't say otherwise.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance" and got no results, so the employer is not established from here. That moved RR1 and caps the decision at `conditional_go` |
| 2. Role-family sweep | yes | Searched "Senior Pricing Analyst pet insurance UK remote salary", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). It moved the market calibration band `[generic]` and RR2. It said nothing on scope norms |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga); I read the snippet and didn't fetch the page. It moved the scope read and E2 |

## Closing

I can write all of this up as `tuesday-dossier.md` if you'd like a file to keep.

**Upgrade menu**

- Your CV → rows R2 to R9 get checked against your actual wording rather than a prose summary.
- A sanitised GLM documentation page, notebook, review deck or price-test readout → R3, R4 and R8 to `high`, and G1 and G2 may close.
- A link to the role on Brindlemoor's own careers page, or the recruiter's email domain → RR1.
- Your pay floor and any other non-negotiables → R1 and the hard-gates line, which currently can't check against your constraints.
- A deeper research pass on Brindlemoor (funding, leadership changes, hiring patterns, recent news; up to 5 more searches and 2 more fetches) → RR1 and the opportunity ledger. Say the word and it runs.

**Questions**

- G3 — Are you based in the UK, and can you work remotely from there?
- G1 — Have you tracked how your GLM performed after launch, for example actual versus expected, drift, or a trigger for refitting? What did you own, and what came of it?
- G2 — For the 14 price tests, who set the hypothesis, the test and control split, and the success measure? What was yours?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.