Status: I've loaded the underwriting skill and read its output rules. Next I'm reading its evidence and risk rules, then checking that Pellucid exists as described, before I write up the verdict.
**Yes, it's worth applying: `conditional_go`.** The conditions are in the snapshot below. This is a first pass built only from what you pasted plus one check of Pellucid's own site.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote US or Denver), R2 (Salary $148,000–$166,000)
- `must_have` — direct: R3, R4, R5, R6, R7, R8
- `important` — adjacent: R9 (BigQuery as the named warehouse); unclear: R10 (data contracts analysts depend on), R11 (ingestion from app and CRM)

R9 — a credible bridge through Snowflake, its limit named; R10, R11 — payroll-side evidence not yet given.

**Opportunity ledger.** The pay is stated and sits at the market median (RR1), and the posting is live and matches the company's own site (see Evidence status). The open items are scope and ownership (RR2, RR3), equity terms (RR4) and whether one range covers remote and Denver (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver), R2 (Salary $148,000–$166,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) your location, work authorization and pay floor clear R1 and R2; (2) RR2 and RR3 verify as one owned domain with a named reporting line; (3) BigQuery is framed as adjacent, never as experience you have.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` company About page; these are the company's own statements, not independently confirmed |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` posting |
| First 90 days / first year | Not stated | `[grounded]` posting silent |
| Working pattern | Remote (US) or Denver office | `[grounded]` posting |
| Scope read | The mandate runs from ingestion through modelling to contracts. The pay report's typical senior scope is one domain's pipelines with no reports, so this may be broader than usual, or the same thing described end to end | `[inferred]` posting's scope list set against the report's typical scope |
| Market calibration | The posted range straddles the report's median ($151,000), and its top end ($166,000) is just above the upper quartile ($163,500). The range sits at or slightly above market for Series B–D senior roles. Your 6 years falls inside the report's typical 5–8, and the posting asks for 5+ | `[grounded]` posting figure and your recruiter's Datawright 2026 report (n=2,310); `[inferred]` the comparison. It assumes the posted "salary" is base pay, like the report's figure |
| Unknowns | Reporting line and team size, equity terms, whether one range covers remote and Denver, who the analysts are | `[grounded]` posting silent on each |
| Contradictions | None between your pasted posting and the live careers page | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you are or your work authorization. The posting's "Remote (US)" implies US-based, but that is not stated as an authorization term | `[grounded]` posting; your location not given | G4 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | You haven't given a pay floor, so I can't say whether the range clears it. The range is at market per role reality | `[grounded]` posting; floor not given | G5 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You stated 6 years at a B2B payroll company. A length requirement is graded as evidence, not as a gate. No CV or artifact seen yet, hence `medium` | `[grounded]` your statement | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily", stated and plausible. "Strong" is unproven until a sample or probe | `[grounded]` your statement | none |
| R5 | dbt | must_have | direct | medium | none | Built your dbt project on Snowflake, about 180 models. Specific and a similar scale to what the role describes. No inspectable artifact yet | `[grounded]` your statement | none |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse. The posting asks for "a cloud warehouse" here and names BigQuery only in the mandate (see R9) | `[grounded]` your statement; `[inferred]` that the requirement text is not BigQuery-specific | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow for orchestration at your payroll company, which is named in the requirement itself | `[grounded]` your statement | none |
| R8 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite. How far it covered your pipelines is not yet stated | `[grounded]` your statement | none |
| R9 | BigQuery, the warehouse the role runs | important | adjacent | medium | transferability | Snowflake plus dbt is the same kind of work. You have never used BigQuery, and its cost and tuning model is not something you have exercised. The posting names it as stack, not as a requirement, so I tiered it `important` | `[grounded]` your statement; `[inferred]` the tiering from the posting's wording | G1 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | Nothing you've said covers agreed schemas or expectations with downstream users. Your dbt and Great Expectations work may be near it, but I won't assume that | `[grounded]` posting; your evidence silent | G2 |
| R11 | Ingestion from app and CRM | important | unclear | low | discovery | You haven't said what fed your pipelines. Payroll data is usually pulled from several systems, which is a pattern and not evidence about your pipelines | `[grounded]` posting; your evidence silent; `[generic]` pattern | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R9, important) | transferability | Snowflake with dbt, Airflow and about 180 models; no BigQuery | The likeliest probe in a screen. A bridge with its limit stated reads weaker and interviews stronger | A personal dbt project on a BigQuery sandbox; any BigQuery tables you queried at work | A small repo or a short written walkthrough | `[inferred]` bridge from your Snowflake work; `[generic]` that this is the likeliest probe |
| G2 | Data contracts (R10, important) | discovery | No mention of agreed schemas, freshness or breaking-change rules with consumers | This is one of the posting's three named responsibilities | Schema or freshness agreements with analysts; dbt model tests or exposures that consumers relied on; change notices for downstream users | A doc, README or screenshot of such an agreement | `[grounded]` posting names it; `[generic]` on what counts |
| G3 | App and CRM ingestion (R11, important) | discovery | Sources and ingestion method unknown | It is the first of the three named responsibilities | Loading from product databases, event streams, SaaS APIs or CRM exports; managed connectors or custom loaders | A pipeline diagram or DAG screenshot | `[grounded]` posting names it |
| G4 | Location and authorization (R1, hard_gate) | hard_gate | Not given | Cannot be fixed by wording; either it fits or it doesn't | A statement of your location and authorization | None needed | `[grounded]` posting's terms |
| G5 | Pay floor (R2, hard_gate) | hard_gate | Not given | Decides whether the range is worth the effort | A statement of your floor | None needed | `[grounded]` posting's range |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay stated and at market | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range is transparent and sits at the median of the user-supplied report, with room above it | `[grounded]` posting and your recruiter's report; `[inferred]` the comparison | Where in this range would a hire with 6 years of experience land? | noted |
| RR2 | Scope may run from ingestion through contracts | risk_signal | low | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts our analysts depend on" | The role may be the sole or early data engineer owning three layers. The report's typical senior scope is one domain. I took the lower severity because the posting could equally describe one coherent domain | `[inferred]` from the JD's scope list against the report's typical scope | Who else is on the data team, and which of ingestion, modelling and contracts does this role own alone? | unresolved |
| RR3 | No hiring manager or reporting line | unknown | — | You noted the posting names no hiring manager | Unknown reporting line, team size and decision rights | `[grounded]` your note; posting silent on reporting | Who does this role report to, and who are the analysts depending on the contracts? | unresolved |
| RR4 | Equity unspecified | unknown | — | "plus equity" | The grant could be material or nominal; no figure or vesting is given | `[grounded]` posting silent on terms | What form does the equity take, how large is the grant for this level, and what is the vesting schedule? | unresolved |
| RR5 | One range for two work locations | unknown | — | "Remote (US) or our Denver office" | The same range may or may not apply to remote and Denver hires | `[grounded]` posting lists one range | Is the pay range the same for remote and Denver hires? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Resume line, `resume_edits_pending_approval`: "Built dbt project on Snowflake — about 180 models" | See R5. I dropped "our" and kept your verb and number. If you built it with others, say so and I'll adjust | `[grounded]` your sentence | pending your approval |
| E2 | Resume line, `resume_edits_pending_approval`: "Set up Great Expectations test suite" | See R8. Add what it covered only after you tell me | `[grounded]` your sentence | pending your approval |
| A1 | Interview framing: "Six years of data engineering; dbt on Snowflake, Airflow for orchestration. I haven't used BigQuery." Say the BigQuery limit first, before you're asked | See R9. It keeps the adjacency honest and gives the screen no surprise | `[grounded]` your statements | pending your approval |
| A2 | Optional: a small BigQuery practice project to narrow G1 before an onsite | See R9. Not needed to apply | `[inferred]` strengthener derived from G1 | pending your approval |
| Q1 | Ask RR2 through RR5 in the screen, verbatim from the register | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Everything about you is your own statement, so none of it is inspected, and the evidence map holds the resulting `medium` bands.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer), which says "Accepting applications" and matches your pasted posting. Searched "Pellucid Learning online tutoring K-12 Series C Denver", which returned "About Pellucid Learning" (pellucidlearning.com/about), matching your pasted company text. It confirmed the employer and live posting, so no failed-attribution entry is needed. Stage and size remain the company's own statements |
| 2. Role-family sweep | skipped | Your recruiter's pay report is in hand: it fixes the market calibration and the mismatch check, so a search could not change either |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there was no query to form |

I can write up the whole assessment as a `tuesday-dossier.md` if you'd like to keep it.

## Upgrade menu

- Your location, authorization and pay floor → R1 and R2 move to `direct` or `hard_gate_fail`, which can turn `conditional_go` into `go` or `no_go`.
- Your CV or a DAG, repo or test-suite screenshot → R3 to R8 can rise from `medium` toward `high`, and E1 and E2 get finalized against your actual wording.
- What fed your pipelines and who consumed your models → R10 and R11 may move to `adjacent` or `direct`.
- A BigQuery practice repo → G1's limit narrows.
- The hiring manager's name, if one surfaces → role reality's scope read and which story to lead with.
- A deeper research pass on Pellucid (funding, leadership churn, public employee reports, recent news; up to 5 more searches and 2 more fetches) → the register gets independent confirmation of the Series C and headcount. Say the word and it runs.

## Questions

1. G4 (R1): Where are you based, and are you authorized to work in the US without sponsorship?
2. G5 (R2): Is $148,000 at or above your pay floor, or is there a number below which you'd skip this?
3. G2 (R10): Did analysts or other teams depend on your dbt models or tests with any agreed schema, freshness or change-notice expectations, and what did you own of that?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.