I'm reading the skill's remaining rules (research tiers, evidence-map shape) before I write the assessment.
**Not a waste of time, but a cold application to this posting is a stretch.** R1 (3+ years product management experience) and R5 (own the roadmap) are where it will cost you. Status: `conditional_go`.

## Decision snapshot

**Fit ledger.**

- `must_have`: direct: R3, R4a · adjacent: R1 (3+ years PM experience), R2 (shipped API or platform products) · unclear: R5 (own the roadmap)
- `important`: adjacent: R6 (partner discovery and specs), R9 (launches with sales and support) · unclear: R4b (sales stakeholders), R7 (adoption metrics), R8 (agile delivery with two squads)

R1 — you did adjacent work but never held a PM title, so this is the row a screener is most likely to stop on; R5 — you gathered roadmap input, and ownership isn't evidenced yet; R3 (`medium`) — your strongest row, confirmed, no artifact inspected.

**Opportunity ledger.** The posting is specific about scope (RR4). The employer couldn't be checked from here (RR1), salary isn't stated (RR2), and roadmap authority against sales-driven asks is unstated (RR3).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:**
  1. The employer and live posting verify (RR1).
  2. You treat R1 as a risk to manage, not a formality: say plainly that your experience is adjacent, and try to reach a human before the résumé screen.
  3. Your answers on the gaps below turn up real ownership evidence, especially for R5.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, ~150 people, Series B | `[grounded]` JD header; existence not verified (RR1) |
| Mandate | Own the partner-facing API platform roadmap; run partner discovery; write specs; drive two squads; track adoption; coordinate launches | `[grounded]` JD |
| Stated requirements | Must-have: 3+ years PM; shipped API/platform products; technical fluency; stakeholder management; agile delivery | `[grounded]` JD |
| First-90-days and first-year outcomes | Not stated | `[grounded]` JD silence |
| Scope read | A product-owner post for a platform with an external developer audience, with delivery through two squads. | `[inferred]` from "two engineering squads" and "partner-facing" |
| "3+ years" requirement | The JD marks it must-have. A length-of-experience requirement is graded as fit, not as a gate, but it is likely to be applied literally at the first screen. | `[generic]` hiring-screen pattern, not a claim about Quartzline |
| Market calibration | Not run, because the search was refused. The band for this title and seniority is unknown. | — |
| Unknowns | Salary; level; decision rights over the roadmap; who the partners are; whether the 3+ years is flexible | — |
| Contradictions | None visible inside the JD; not compared with a careers page | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years product management experience | must_have | adjacent | medium | transferability | You have 7 years in solutions/implementation, wrote requirements documents, and worked beside PMs on custom builds, but never held a PM title or owned a product. Limit: none of this is PM ownership, and a literal screen will see "no PM title". | `[grounded]` your résumé; `[generic]` the screening pattern | Reframe honestly (E1–E3); ask about flexibility (A1) |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ integrations of your company's REST APIs, so you know the consuming side well. Limit: integrating an API is not shipping one. | `[grounded]` your résumé | Question G1 may surface a shipped product |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL and OpenAPI reading, plus integration architecture across 30+ clients. Medium because nothing has been inspected yet. | `[grounded]` your résumé | The playbook, sanitized, would raise this to `high` |
| R4a | Stakeholder management: engineering and customers | must_have | direct | medium | none | You coordinated your engineers, the client's engineers and PMs, and ran client workshops and UAT. | `[grounded]` your résumé | none |
| R4b | Stakeholder management: sales | important | unclear | low | discovery | The résumé is silent on working with sales. | `[grounded]` résumé silence | See G4 |
| R5 | Own the roadmap | must_have | unclear | low | discovery | You ran quarterly sessions collecting client feedback for product. That is input to a roadmap, not prioritization or ownership. | `[grounded]` your résumé | Question G2 |
| R6 | Partner discovery; write specs | important | adjacent | medium | transferability | Scoping workshops and requirements documents are real discovery and spec work, but project-scoped for one client at a time. That is a different kind of work from product discovery across many partners. | `[grounded]` your résumé | Bridge in E1 |
| R7 | Define and track adoption metrics | important | unclear | low | discovery | Nothing on the résumé about metrics. SQL fluency is relevant, but no metric work is stated. | `[grounded]` résumé silence | Question G1 |
| R8 | Drive delivery with two squads; agile | important | unclear | low | discovery | You coordinated engineers on custom builds, but methodology and delivery ownership aren't stated. | `[grounded]` résumé silence | See G3 |
| R9 | Coordinate launches with sales and support | important | adjacent | medium | transferability | Client go-lives are launches of a kind. Limit: they were launches of an implementation, not of a product to a market. | `[grounded]` your résumé | none yet |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Shipped product and adoption metrics (R2, R7; both feed R1) | discovery | A prior conversation mentioned an internal request-triage tool that support agents adopted. It is unconfirmed and not evidence. | If it is real and yours, it is the closest thing to a shipped product with an adoption story, and it could move R2 and R7. | Defining what the tool should do; choosing between options; how adoption was measured; what changed after launch | A short write-up, usage numbers, a screenshot, a before/after | `[grounded]` memory lead; `[inferred]` that it could move R2 and R7 |
| G2 | Roadmap ownership (R5) | discovery | Feedback gathering is evidenced; deciding what gets built is not. | A must-have at `unclear` is the row most likely to separate a conditional go from a stretch. | Choosing which client request became a custom build; saying no to one; a product decision your input visibly changed | A custom-build decision memo, a feedback-to-roadmap trail | `[grounded]` résumé; `[generic]` that PM hiring probes prioritization |
| G3 | Agile delivery (R8) | discovery | You worked with engineers on builds; the method isn't stated. | A short answer could take R8 to `direct`. | Sprint ceremonies, backlog grooming, release planning with a dev team | A ticket board, release notes | `[grounded]` résumé silence |
| G4 | Sales interface (R4b) | discovery | Not stated. | Posting asks for sales and support coordination at launch. | Pre-sales scoping calls, handoffs from sales into implementation | A handoff doc, scoping template | `[grounded]` résumé silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The company may be real and simply small, the posting may be stale, or it may not represent a live hiring employer. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who I would be interviewing with? | unresolved |
| RR2 | Salary not stated | unknown | — | JD gives no figure | Pay may sit at a mid-level PM band; the band is unknown. | `[inferred]` from the posting's silence | What salary band is budgeted for this role? | unresolved |
| RR3 | Authority over the roadmap unstated | unknown | — | "Own the roadmap for our partner-facing API platform" | At a ~150-person company, roadmap ownership may be shared with sales or founders. | `[inferred]` from the JD's scope language against its silence on decision rights | Which roadmap decisions does this role make alone, and which go to leadership or sales? | unresolved |
| RR4 | Scope and delivery structure are specific | positive_signal | — | "drive delivery with two engineering squads" | Defined structure suggests a real, resourced role. | `[grounded]` JD states squads, partners, metrics | What does success look like at 12 months? | noted |

## Application plan

`resume_edits_pending_approval`: each line below uses your own words and is not applied until you approve.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with "Led 30+ client integrations of our REST APIs, from scoping workshops and requirements documents through integration architecture, UAT and go-live" | R2, R6; your sentence reordered, nothing added | `[grounded]` résumé | resume_edits_pending_approval |
| E2 | "Ran quarterly sessions collecting client feedback as input for the product team" | R5, R6; kept as input-gathering, not roadmap ownership | `[grounded]` résumé | resume_edits_pending_approval |
| E3 | "Wrote the integration playbook the whole team uses" | R3, R1; unchanged | `[grounded]` résumé | resume_edits_pending_approval |

Other proposed actions, each pending your approval:

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before applying, ask a recruiter or contact whether adjacent experience will be considered for the 3+ years | R1 is the likeliest screen-out | `[generic]` screening pattern | pending your approval |
| A2 | Positioning: lead with API integration depth and client-facing discovery; do not call it PM experience | The reframing audit forbids the kind change | `[grounded]` résumé | pending your approval |
| A3 | Alongside this posting, look at roles near yours: technical PM, integrations or partner PM, product operations | Fit may be stronger where titled PM years are not a must-have | `[generic]` role-family pattern | pending your approval |
| W1 | A one-page sample spec for an API improvement drawn from integration problems you've seen, labeled as a sample and not as shipped work | Would raise R6 and R3 toward `high` | `[inferred]` | pending your approval |
| Q1 | Ask the register questions of RR1–RR4 verbatim in the loop | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: a prior-conversation mention of an internal request-triage tool that support agents adopted, unconfirmed and used only as the basis for G1.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search sent for "Quartzline logistics technology company Product Manager Platform APIs careers" was refused. Would have moved: whether the employer exists as described and the posting is live (RR1), and the contradictions row |
| 2. Role-family sweep | unavailable | Search sent for "API product manager salary technical product manager platform APIs requirements transition from solutions engineer" was refused. Would have moved: market calibration and the salary check (RR2) |
| 3. Hiring manager's public footprint | n/a | No name was given |

I made no further attempts after the refusal.

Would you like me to save this as `tuesday-dossier.md`? I can, and nothing is saved unless you say so.

## Upgrade menu

- Search permission, so targets 1 and 2 can run → RR1 and RR2 close, and the market calibration row appears.
- An answer on G1 (the triage tool), with any write-up or usage numbers → R2, R7 and possibly R5 move; the tool's description would need your confirmation first.
- Your pay floor, location, and level you'd accept → the hard-gates line stops saying "constraints not given".
- The hiring manager's name → positioning for that reader.
- A sanitized copy of your integration playbook → R3 to `high`.

## Questions

- **G1:** Did you build the request-triage tool yourself? What did you own, who adopted it, and how did you know it worked?
- **G2:** Was there a time you decided which client request became a custom build, or chose between competing requests? What was yours to decide, and what happened?
- **Constraints:** What's your pay floor and location or remote requirement, and would you take a step down in level for the right role?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.