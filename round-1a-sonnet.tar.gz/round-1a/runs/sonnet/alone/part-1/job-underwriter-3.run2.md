I'm reading the skill's remaining rule files, on output format and research tiers, before I write the assessment.
## Decision snapshot

**No — this isn't worth pursuing. R1 and R2, both hard gates, fail · `no_go`.**

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (Base pay at least $150k), R2 (Remote-only, Portland)
- `must_have` — direct: R3, R4, R5 · unclear: R6 (SEO/content)
- `important` — unclear: R7 (Brand, PR, partnerships), R8 (Sales ops), R9 (Team of one)

R1 — the posted base is below your floor; R2 — five office days in Austin against remote-only; R3, R4, R5 — the fit that makes it look good on paper.

**Opportunity ledger.** Your instinct has rows behind it: seven functions bundled into one seat (RR4), no stated budget or decision rights (RR5), always-on expectations (RR6), success metrics left undefined (RR7), and pay that may not match the title (RR3). The employer itself could not be checked (RR8).

- **Hard gates:** failed: R1 (Base pay at least $150k), R2 (Remote-only, Portland)
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`)
- **What would change this:** a base at or above your $150k floor (R1) and remote work from Portland (R2). The posting states "no exceptions" on location. Strong fit on R3, R4 and R5 doesn't offset either gate.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, described as an e-commerce enablement startup, Series A, profitable since day one. Not verified here (research row 1 below) | `[grounded]` JD header, as the posting states it |
| Mandate | "Own all revenue growth end to end": paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` JD |
| Reporting line | CEO, with a dotted line to the board | `[grounded]` JD |
| Team | "A team of one to start" | `[grounded]` JD |
| Working pattern | On-site in Austin 5 days a week, "no exceptions"; evenings and weekends "when it matters" | `[grounded]` JD |
| Compensation | $70–85k base plus "meaningful equity upside", with no equity figures given | `[grounded]` JD |
| First 90 days / first year | Not stated. "Success metrics will evolve as we learn" | `[grounded]` JD |
| Scope read | One person covering a full growth function (channels, brand/PR, partnerships, sales ops) while the title and 8+ year requirement signal a leader. The two don't obviously fit together | `[inferred]` from the JD's function list against "team of one" |
| Market calibration | Not established. The role-family sweep did not run, so no pay band is offered, and the posted figure can't be compared with market here (RR3) | `[grounded]` research row 2 unavailable |
| Unknowns | Marketing budget, spend authority, hiring plans, equity terms, how success is defined | `[inferred]` from what the JD omits |
| Contradictions | Only one source (the posting), so none cross-checked | `[grounded]` inputs provided |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Base pay at least $150k (your constraint) | hard_gate | hard_gate_fail | high | hard_gate | Your floor is confirmed. The posted band is $70–85k, so its top is $65k below your floor. Wording can't close this | `[grounded]` your stated floor and the JD figure | none — carried as RR1 |
| R2 | Remote-only; no relocation from Portland (your constraint) | hard_gate | hard_gate_fail | high | hard_gate | Your constraint is confirmed. The posting requires Austin on-site 5 days a week, "no exceptions" | `[grounded]` your stated constraint and the JD | none — carried as RR2 |
| R3 | 8+ years of growth leadership | must_have | direct | medium | none | You report 9 years, including growth lead and Head of Growth roles at two B2C subscription companies, with teams of 3–7. That is a length-of-experience requirement, not a gate. Self-reported, no artifact inspected | `[grounded]` your account, unverified | an ARR growth report would raise this to high |
| R4 | Paid acquisition | must_have | direct | medium | none | You owned paid, with a budget you controlled while scaling one company from $8M to $40M ARR over three years. No artifact inspected | `[grounded]` your account | a channel-level performance report would raise this to high |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You owned lifecycle and report deep Braze experience. No artifact inspected | `[grounded]` your account | a sanitized lifecycle program summary would raise this to high |
| R6 | SEO/content | must_have | unclear | low | discovery | You didn't mention SEO or content among what you owned. Silence isn't absence | `[grounded]` your summary's silence | see G1 |
| R7 | Brand, PR, partnerships | important | unclear | low | discovery | Not mentioned in your summary | `[grounded]` your summary's silence | see G2 |
| R8 | Sales ops | important | unclear | low | discovery | Not mentioned. Your companies were B2C subscription, and "enablement" in the header may point to a business-customer sales motion, which would make this less familiar territory | `[grounded]` your summary's silence; `[inferred]` the sales motion from the posting's own wording | see G3 |
| R9 | Operating as a team of one | important | unclear | low | discovery | You built and managed teams of 3–7. Whether you've executed hands-on across channels without a team isn't stated | `[grounded]` your summary | see G4 |

## Gap recovery queue

The decision rests on R1 and R2, so closing any of these gaps would not move the status unless both gates move first.

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content (R6, must_have) | discovery | Paid, lifecycle and experimentation are stated. SEO and content aren't | A must-have, but only relevant if the gates were resolved | Owning an organic-traffic target; commissioning or briefing content; technical SEO work with engineering | An organic traffic report or a content calendar | `[grounded]` your summary's silence |
| G2 | Brand, PR, partnerships (R7, important) | discovery | Nothing in your summary | An important responsibility the posting bundles into the role | Launch positioning; press or affiliate deals; co-marketing | A partnership summary or a launch brief | `[grounded]` your summary's silence |
| G3 | Sales ops (R8, important) | discovery | Nothing in your summary | The posting lists it as a growth function | CRM or pipeline reporting for a sales team; lead routing or scoring | A pipeline or lead-flow report | `[grounded]` your summary's silence |
| G4 | Team of one (R9, important) | discovery | You have team-building evidence, not solo-execution evidence | The posting expects solo execution at the start | Periods when you ran channels yourself; a pre-hire phase at either company | A before-hire channel report | `[grounded]` your summary |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Base pay below your floor (R1) | red_flag | high | "$70–85k base plus meaningful equity upside" | The equity is unquantified and can't be valued from the posting | `[grounded]` JD figure and your stated floor | Is the base negotiable beyond the posted range, and what is the equity grant in shares and as a percentage of fully diluted? | confirmed |
| RR2 | On-site 5 days against remote-only (R2) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | The employer states the policy is fixed | `[grounded]` JD and your stated constraint | Is there any remote or hybrid arrangement for this role, or is the stated policy final? | confirmed |
| RR3 | Seniority and scope against pay | risk_signal | medium | "8+ years growth leadership required" beside "$70–85k base" | Pay may sit below what a head-level, all-channels mandate commands. The market band wasn't established, so this stays a signal rather than a finding | `[inferred]` from the posted figure against the JD's own requirements | What is the compensation philosophy for this role, and how was the range set? | unresolved |
| RR4 | Bundled specializations | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops" | Several full functions may be folded into one seat | `[inferred]` from the count of functions against "team of one" | Which of these areas does this role execute itself in year one, and which will be hired or contracted? | unresolved |
| RR5 | Responsibility without stated authority or resources | unknown | — | "Own all revenue growth end to end" | Budget and decision rights aren't stated | `[inferred]` from the JD's silence | What budget and spend authority come with this role? | unresolved |
| RR6 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Out-of-hours work may be routine rather than occasional | `[inferred]` from the quote | In the last six months, how often did the team work evenings or weekends? | unresolved |
| RR7 | No success definition on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | Accountability for revenue with no fixed yardstick | `[inferred]` from the quote | What would success look like at 90 days and at 12 months, and who sets it? | unresolved |
| RR8 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The entity may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer. Research couldn't run to tell | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your careers site, and who would I be interviewing with? | unresolved |
| RR9 | Direct CEO reporting line stated | positive_signal | — | "Report to the CEO with a dotted line to the board" | Clear seniority in the structure | `[grounded]` JD | Who currently owns growth decisions, and how often does this role meet the CEO? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply as posted | R1 and R2 fail on your own stated constraints | `[grounded]` R1, R2 | pending your approval |
| A2 | If you proceed against `no_go` anyway, ask RR1 and RR2 verbatim before spending any effort | If the employer flexes neither, nothing else matters | `[grounded]` register | pending your approval |
| A3 | Carry RR3 to RR7 as your questions in any conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

No CV or outreach language is proposed, since A1 recommends against applying.

## Evidence status

Verified: none yet. Stage wasn't stated, so I assumed you're evaluating.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Austin Series A"; refused. It would have moved role reality's organization row and RR8 |
| 2. Role-family sweep | unavailable | Searched "Head of Growth salary Series A startup base compensation 2026"; refused. It would have moved the market calibration row and RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Upgrade menu

- Permission to run web search (it was refused this session) → rows 1 and 2 would run, closing RR8 and settling RR3 and the market calibration.
- A link to the live posting or the company's careers page → RR8 and role reality's organization row.
- The hiring manager's or CEO's name → row 3.
- A growth report from the $8M to $40M ARR period, or a channel-level performance report → R3 and R4 to `high`.
- Evidence of SEO, brand, PR, partnership or sales-ops work → R6, R7 and R8 move.

I can also write this up as `tuesday-dossier.md` if you'd like to keep it.

Questions: none. The decision turns on your two stated constraints, not on anything I could ask you.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.