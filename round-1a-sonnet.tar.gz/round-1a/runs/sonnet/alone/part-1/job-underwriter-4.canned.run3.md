Still reading the skill's reference files so the assessment follows its format. Next I'm reading the question-selection and decision-snapshot rules.
## Decision snapshot

**Yes, it's worth applying, once the employer checks out (RR1). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R10 (Fully remote, UK)
- `must_have`: direct: R1, R2, R3, R4a, R5a, R6 · unclear: R4b (Monitor rating models), R5b (Design price tests)
- `important`: direct: R7a · adjacent: R8 (Pet-insurance domain) · unclear: R7b (Recommendations for product)
- `preferred`: direct: R9

R4b: your CV says "maintained", which doesn't establish monitoring. R5b: "ran" doesn't say who designed the tests. R8: a credible bridge, its limit named.

**Opportunity ledger.** The role is plausible and well matched to your motor work, but the employer isn't established from public sources (RR1) and the salary is withheld (RR2). The posting is silent on team and decision rights (RR3). One entry runs the other way: the hiring manager has a published talk on monitoring rating models (RR4).

- **Hard gates:** none failed; unconfirmed: R10 (Fully remote, UK); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Brindlemoor and a live posting verify on its own site (RR1). (2) You can truthfully evidence monitoring and test design (R4b, R5b). (3) UK-based remote working is confirmed (R10). (4) The pet bridge is framed as adjacent, never as pet experience (R8).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product. Its existence was not established by search (RR1) | `[grounded]` JD header; not corroborated by an official source |
| Mandate | Own pricing analytics for pet: build and monitor rating models, design and read price tests, and turn the results into recommendations for underwriting and product | `[grounded]` JD |
| Reports to | Odile Varga, Director of Pricing | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | A single-product analytics remit with four named activities, which is ordinary for a senior analyst. The JD names no first-year outcomes and doesn't mention line management | `[inferred]` from the four listed activities and the JD's silence on outcomes and reports |
| Market calibration | A pay survey puts senior pricing analysts at UK insurers and insurtechs at a median base of £58,400, interquartile range £52,100 to £64,900 (n=612). The posting withholds salary, so this is the expected band and not Brindlemoor's offer (RR2). Scope norms were not searched | `[generic]` Pricewell 2026 survey snippet; `[grounded]` JD for the withheld salary |
| Unknowns | Salary; whether the role has reports or decision rights; how much product-facing work there is; the contract basis | — |
| Contradictions | None inside the JD. The JD could not be checked against Brindlemoor's own site, because no site result was found | `[grounded]` JD; search returned no results |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You state 5 years of pricing analytics at a UK motor insurer, the last 2 as senior analyst. Specific and confirmed, but it's your word with no document inspected | `[grounded]` your background | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily." Confirmed, with no artifact to inspect | `[grounded]` your background | none |
| R3 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book | `[grounded]` your background | a sanitized model summary would raise to high |
| R4a | Build rating models | must_have | direct | medium | none | Same GLM build as R3, on a young-driver motor book | `[grounded]` your background | as R3 |
| R4b | Monitor rating models | must_have | unclear | low | discovery | You said "maintained". That may include monitoring, but your sentence doesn't say what you did. The hiring manager's published talk is on monitoring, so expect a probe | `[grounded]` your wording; `[inferred]` that the talk topic raises the probe risk | G1 |
| R5a | Read price tests | must_have | direct | medium | none | "Ran 14 price tests last year with the underwriting team." Running them with underwriting implies reading the results, but you haven't described a read-out | `[grounded]` your background | a sanitized test read-out would raise to high |
| R5b | Design price tests | must_have | unclear | low | discovery | "Ran" is ambiguous between designing and executing. I take the reading that claims less | `[grounded]` your wording | G2 |
| R6 | Present to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting, and the JD accepts underwriting or actuarial | `[grounded]` your background | none |
| R7a | Recommendations for underwriting | important | direct | medium | none | Your quarterly review and 14 tests with the underwriting team are both underwriting-facing | `[grounded]` your background | none |
| R7b | Recommendations for product | important | unclear | none | discovery | Nothing you've said touches a product team | `[grounded]` no product-facing evidence supplied | G4 |
| R8 | Pet-insurance domain (implied by the product) | important | adjacent | medium | transferability | GLM rating on a personal-lines motor book carries over. The limit: you have never worked on pet, and pet-specific rating factors and claims behaviour are untested in your history | `[inferred]` adjacency from your motor work; `[generic]` that factor knowledge differs by product | G3 |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a UK motor insurer | `[grounded]` your background | none |
| R10 | Fully remote, UK (a term) | hard_gate | unclear | low | hard_gate | Your location and right to work weren't stated. A UK employer is suggestive, not confirmation | `[grounded]` JD term; `[inferred]` from your UK employer | G5 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Monitor rating models (R4b, must_have) | discovery | "Maintained" the GLM; no description of monitoring | A must-have at `unclear`, and the hiring manager's own published topic | Actual-versus-expected tracking; drift or segment checks; refit triggers; a dashboard others used; flagging a deteriorating segment | A monitoring pack, a dashboard screenshot, a refit note | `[grounded]` CV wording; `[generic]` that monitoring is the usual meaning of the verb in this role family |
| G2 | Design price tests (R5b, must_have) | discovery | "Ran 14 price tests" with no design detail | Design is a named duty; running someone else's design is a different claim | Choosing the test and control cells; sizing the sample; setting the success measure; writing the read-out | A test plan, a read-out deck, a results note | `[grounded]` your wording |
| G3 | Pet-insurance domain (R8, important) | transferability | Motor GLM work carries over; nothing pet-specific | The most likely objection in screening | Any personal-lines product work with claim-cost drivers like age or breed analogues; a side analysis of pet or vet-cost data | A short note on what you would check first in a pet book | `[inferred]` from your motor work; `[generic]` that this is the likeliest objection |
| G4 | Recommendations for product (R7b, important) | discovery | No product-team work in evidence | One half of a stated duty | A pricing recommendation that changed a product feature, cover tier or excess | A recommendation paper or deck | `[grounded]` no evidence supplied |
| G5 | UK remote working (R10, hard_gate) | hard_gate | Your location and right to work are unstated | A gate the inputs don't settle | — | Nothing to produce | `[grounded]` JD term; your location unstated |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The company may be too new or small for a web footprint, the posting may be stale or aggregated, or it may not be a real hiring employer. A profile page names Brindlemoor, but that's a person's page and not the employer's own | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your own careers site, and who I'd interview with? | unresolved |
| RR2 | Salary withheld | unknown | — | JD gives no figure | The figure may sit below the survey band in role reality, or the employer may not publish pay | `[inferred]` from the posting's silence against the `[generic]` band | What salary range is budgeted for this post? | unresolved |
| RR3 | Team, reports and decision rights unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | "Own" may carry accountability without a team or sign-off rights | `[inferred]` from the JD's scope wording against its silence on authority | Which pricing changes does this role decide alone, and which need sign-off from you or underwriting? | unresolved |
| RR4 | Hiring manager named, with a published talk on monitoring rating models in small books | positive_signal | — | "The hiring manager is Odile Varga, Director of Pricing" | The role's monitoring remit is likely real and taken seriously | `[grounded]` JD names the manager; `[grounded]` search snippet of a public profile, page not opened | How is model monitoring split between this role and the pricing director today? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | CV summary line built from your own sentences: built and maintained the GLM rating model for a UK motor young-driver book; ran price tests with the underwriting team; presents the quarterly pricing review to the head of underwriting. No new numbers or verbs | R3, R4a, R5a, R6, R7a | `[grounded]` your background | resume_edits_pending_approval |
| E2 | Keep the CV's motor context visible and say so plainly in the cover letter: rating and test work on motor, not pet | R8, the honest bridge | `[grounded]` your background | pending your approval |
| E3 | Hold any "monitoring" or "test design" wording until G1 and G2 are answered | R4b, R5b; nothing unverified goes on a CV | `[grounded]` your wording | pending your approval |
| A1 | Before applying, find the role on Brindlemoor's own careers page, or check the recruiter's email domain | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask for the salary range at the first call and compare it to the survey band | RR2 | `[grounded]` RR2 | pending your approval |
| A3 | For Odile Varga, lead with the maintenance story for the GLM, adding monitoring detail only once confirmed. Her published topic makes it the likely probe | R4b, RR4 | `[grounded]` search snippet; `[inferred]` that it shapes the probe | pending your approval |
| Q1 | Ask RR1, RR2, RR3 and RR4's verification questions verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance", which returned no results, so the employer is not established. This produced RR1 and caps the decision at `conditional_go` |
| 2. Role-family sweep | yes | Searched "Senior Pricing Analyst pet insurance UK remote salary", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). It gave the pay band for market calibration and RR2. It said nothing about scope norms |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga). The snippet gave the 2025 talk topic and a prior pricing-analytics role, which fed RR4 and A3. The page was not opened |

I can write this up as `tuesday-dossier.md` if you want to keep it.

## Upgrade menu

- Brindlemoor's careers-page link, or the recruiter's email domain: RR1 closes, and the decision likely moves to `go`.
- Your location, right to work and any salary floor or other non-negotiables: R10 resolves, and the salary can be set against your floor.
- A sanitized model summary, monitoring pack, test plan or read-out: R3, R4a, R4b, R5a and R5b can rise to `high`.
- Any product-facing recommendation you've made: R7b resolves.
- The salary range from Brindlemoor: RR2 closes.
- A deeper research pass on Brindlemoor (funding, leadership, public reports; up to 5 more searches and 2 more fetches): say the word and it runs.

## Questions

- G1: When you maintained the young-driver GLM, what monitoring did you do yourself, such as actual-versus-expected tracking, drift checks or refit triggers? Did you own it, and who saw the output?
- G2: Of the 14 price tests, which did you design (cells, sample size, success measure, read-out) and which did you run to someone else's design?
- G5: Are you UK-based and eligible to work in the UK, and do you have any non-negotiables such as a salary floor?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.