I've read the skill's rules. Now I'm loading the search tools so I can check that Pellucid and the posting are real and see where the pay falls against the market.
## Decision snapshot

**Yes, this looks worth applying to, on conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver), R2 (Pay $148,000–$166,000 plus equity)
- `must_have`: direct: R3, R4, R5, R6, R7, R8
- `important`: adjacent: R9 (BigQuery warehouse); unclear: R10 (Ingestion from app and CRM), R11 (Data contracts)

R9 — a credible bridge, its limit named; R10, R11 — your payroll work may cover them, but nothing you've told me shows it yet.

**Opportunity ledger.** The stated terms are sound: the pay range sits around the market median (RR2) and the stack is concrete (RR5). Several things are unknown: equity terms (RR3), team, reporting line and on-call (RR4), and scope breadth (RR6). The employer is not independently established (RR1), which caps the status here.

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver), R2 (Pay $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify — RR1; (2) you confirm location, US work authorization and pay fit — R1, R2; (3) the BigQuery gap is framed as adjacent, never as BigQuery experience — R9.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` the about-page text you pasted; not independently checked (RR1) |
| Mandate | Build and run the pipelines behind reporting: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` JD |
| Requirements | 5+ years data engineering; SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Working pattern and pay | Remote (US) or Denver office; $148,000–$166,000 plus equity | `[grounded]` JD |
| First-year outcomes | Not stated | `[grounded]` JD silence |
| Scope read | The JD names ingestion, warehouse modelling and contracts together. That may be wider than the single domain's pipelines the pay report describes as typical | `[inferred]` from the JD's three strands against the report's scope norm (RR6) |
| Market calibration | Senior Data Engineer at Series B–D: base median $151,000, interquartile range $139,000–$163,500, "senior" typically 5–8 years, one domain's pipelines, no direct reports. The posting's low end is $3,000 under the median and its top is $2,500 over the range's upper quartile edge. This is a band, not this employer's offer | `[generic]` the Datawright 2026 report (n=2,310) your recruiter sent; `[grounded]` JD for the posting's figures |
| Unknowns | Hiring manager (none named), team size, equity terms, on-call, whether the range varies by location | `[grounded]` JD silence |
| Contradictions | None found between what you pasted from the two pages; the pages themselves were not re-read | `[grounded]` your pasted text |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You've given no location or US work authorization, so the gate can't be checked | `[grounded]` JD term; your silence | Question 1 |
| R2 | Pay $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | You've given no pay floor, so the gate can't be checked. The range's place in the market is in RR2 | `[grounded]` JD term; your silence | Question 1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years at a B2B payroll company. It's a length requirement, so graded as fit, not as a gate. Self-reported, nothing inspected | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | "Daily" use shows frequency. "Strong" has nothing inspectable behind it yet | `[grounded]` your background | none |
| R5 | dbt | must_have | direct | medium | none | You built the dbt project, about 180 models. Specific and plausible, with no artifact inspected | `[grounded]` your background | none |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse. The BigQuery-specific part is its own row, R9 | `[grounded]` your background and JD | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | You used Airflow for orchestration. You didn't say how much of the DAG work was yours, so I'm reading ownership at the lower level | `[grounded]` your background; ownership unstated | none |
| R8 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite. That's setup, and it doesn't say how widely it was used or what it caught | `[grounded]` your background | none |
| R9 | A dbt-modelled warehouse in BigQuery (named in the responsibilities, not the requirements list) | important | adjacent | medium | transferability | Snowflake plus 180 dbt models carries over. Limit: you have never used BigQuery | `[grounded]` your statement; `[inferred]` that the dbt and warehouse skills carry over | G1 |
| R10 | Ingestion from the app and CRM | important | unclear | low | discovery | Airflow is named, but the source systems and how data was pulled aren't | `[grounded]` your silence on sources | G2 |
| R11 | Data contracts analysts depend on | important | unclear | low | discovery | A test suite checks data. A contract is an agreement with producers or consumers, and nothing you've said shows one | `[grounded]` your silence; `[generic]` that contracts and tests are different things | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R9, important) | transferability | Snowflake and a 180-model dbt project; no BigQuery use, by your own account | It's the named warehouse in the mandate, so expect it to be probed | Any GCP or BigQuery contact at the payroll company, such as a BI tool reading from it; performance or cost tuning on Snowflake; dbt adapter work | A sanitized dbt lineage or docs screenshot; a small dbt-on-BigQuery project on public data | `[grounded]` your statement; `[inferred]` the strengthener |
| G2 | Ingestion from app and CRM (R10, important) | discovery | Airflow named, sources unnamed | The JD's first listed responsibility | Pulling a CRM's API on a schedule; loading from an application database; handling late or changed upstream data | A sanitized DAG outline or architecture sketch | `[grounded]` your silence |
| G3 | Data contracts (R11, important) | discovery | A Great Expectations suite, nothing on agreements with upstream teams or analysts | The JD names it as the thing analysts depend on | Agreeing schemas or freshness with an app team; dbt model contracts or exposures; reviewing upstream changes before they landed | A schema-change process note, or a model YAML with contracts | `[grounded]` your silence; `[generic]` that the posting treats it as central |
| G4 | Location, authorization and pay terms (R1, R2, hard_gate) | hard_gate | None of your constraints given | A failed gate caps the decision however strong the fit elsewhere | Not applicable: these are terms you meet or don't | Nothing to attach | `[grounded]` your silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | low | "Founded 2016, Denver. 264 employees. Series C ($52M, February 2026)" | I couldn't read the live page or search for the company, so the size, funding and live posting are unconfirmed. Nothing suggests a problem; I rate it low because the details come from the employer's own pages | `[generic]` pattern, not a claim about this company | Can you point me at this role on your careers site, and say who I'd interview with? | unresolved |
| RR2 | Pay range sits around the market median | positive_signal | — | "$148,000–$166,000 plus equity" | The posted range is transparent and brackets the report's median; it's a typical figure for the title, not an exceptional one | `[grounded]` JD range; `[generic]` the report's band | Is this range base pay, and does it vary by location (Denver versus remote)? | noted |
| RR3 | Equity terms unstated | unknown | — | "plus equity" | The grant size, vesting and valuation basis may matter to total pay | `[inferred]` from the JD naming equity with no terms | What is the equity grant for this level, and how does it vest? | unresolved |
| RR4 | Team, reporting line and on-call unstated; no hiring manager named | unknown | — | "Build and run the pipelines" | "Run" may mean operational ownership, possibly including out-of-hours support | `[inferred]` from the wording "build and run" | Who does this role report to, how big is the data team, and is there an on-call rotation? | unresolved |
| RR5 | Concrete stack and consumers named | positive_signal | — | "a dbt-modelled warehouse in BigQuery, and the data contracts our analysts depend on" | The role's tools and its internal customers are specific | `[grounded]` JD | Which analysts or teams consume the contracts today? | noted |
| RR6 | Scope may be wider than one domain | unknown | — | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts" | One person may own ingestion, modelling and contracts, whereas the report's typical senior scope is one domain's pipelines | `[inferred]` from the JD's three strands against `[generic]` report scope | Which of ingestion, modelling and contracts does this role own end to end, and who owns the rest? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | CV line, proposed: "Built our dbt project on Snowflake — about 180 models." Move it to the top of the experience section. Every clause is your sentence, reordered | R5, R6 | `[grounded]` your background | `resume_edits_pending_approval` |
| E2 | CV line, proposed: "Set up our Great Expectations test suite." Placed beside E1. I added no coverage or outcome claim because you gave none | R8 | `[grounded]` your background | `resume_edits_pending_approval` |
| P1 | Positioning advice: open with dbt scale and data quality, since they match the JD's lead requirements, and put the BigQuery gap in a single plain sentence rather than burying it | R5, R8, R9 | `[grounded]` rows R5, R8, R9 | pending your approval |
| P2 | Interview framing for BigQuery: "I haven't used BigQuery. I built our dbt project on Snowflake, about 180 models." It claims nothing beyond your sentences | R9 | `[grounded]` your statement | pending your approval |
| W1 | A small dbt project run on BigQuery with public data, to narrow R9's limit | R9, G1 | `[inferred]` strengthener | pending your approval |
| A1 | Check the live posting on the company's own careers page before investing in the application | RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask RR2, RR3, RR4 and RR6 verbatim in the loop. Each is worth the time to hear the answer | RR2, RR3, RR4, RR6 | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Pellucid Learning online tutoring K-12 Denver Series C $52M" and tried to fetch pellucidlearning.com/careers/senior-data-engineer. Both were refused, so nothing was returned. It would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | skipped | The Datawright figures you supplied are in hand and already fix the market calibration, RR2 and the scope read |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there was no query to form |

## Dossier offer

I can write all of this to `tuesday-dossier.md` if you want a file to keep.

## Upgrade menu

- Your location, work authorization and pay floor → R1 and R2 move from `unclear` to a firm met or failed.
- Search and fetch permission, or the live posting's text pasted from the company's careers page → RR1 and the organization row close; the status could simplify to `go`.
- A sanitized dbt docs page, lineage graph or model YAML → R5 toward `high`; a model contract or schema agreement would also settle R11.
- A sanitized DAG outline → R7 and R10 firm up.
- A dbt-on-BigQuery sandbox project → R9's limit narrows.
- The hiring manager's name → the scope read and which story to lead with.
- A deeper research pass on Pellucid (funding, leadership churn, public employee reports; up to 5 more searches and 2 more fetches), once searching is permitted.

## Questions

1. **R1, R2:** What are your non-negotiables on location, US work authorization and base pay for a role like this?
2. **G3:** In your payroll work, did you ever agree a schema, freshness or definition with an upstream team or the analysts who used your models, and what did you personally own?
3. **G2:** Which source systems fed your warehouse, and how did the data get in?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.