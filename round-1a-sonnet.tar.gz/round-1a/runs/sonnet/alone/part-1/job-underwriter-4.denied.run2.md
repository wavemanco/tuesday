I'll read the reference files the skill points to before building the assessment.
## Decision snapshot

**Yes, apply, on conditions. Your must-haves R2, R3, R4, R5, R6 and R7 each read `direct` on your own account. Pet-insurance experience (R10) is a preferred item, and the posting as pasted asks for no people management. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote (UK))
- `must_have`: direct: R2, R3, R4, R5, R6, R7
- `important`: direct: R8a · unclear: R8b (Recommendations for product)
- `preferred`: direct: R9 · adjacent: R10 (Pet-insurance domain)

R10 — a credible bridge, its limit named; R8b — the product side is unevidenced; R1 — a location term still to confirm.

**Opportunity ledger.** The employer is unverified from here (RR1), the posting as pasted gives no salary (RR2), and whether the post carries reports (RR3) and who decides rating changes (RR4) is open. One entry runs the other way: the scope is concrete (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the role verifies as live on Brindlemoor's own careers page (RR1); (2) your UK base is confirmed against R1; (3) salary and contract terms are visible before you invest in the loop (RR2); (4) the pet bridge is framed as adjacent and never as pet-pricing expertise (R10).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, described as an insurtech with a pet-insurance product. Not verified here (RR1) | `[grounded]` JD as pasted |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reports to | Odile Varga, Director of Pricing | `[grounded]` JD header as given |
| Working pattern | Fully remote (UK) | `[grounded]` JD |
| First-year outcomes | Not stated in the JD | `[grounded]` JD silence |
| Scope read | A hands-on senior individual-contributor post spanning modelling, testing and stakeholder recommendations. The JD names no direct reports (RR3) | `[inferred]` from the JD's verbs against its silence on reports |
| Market calibration | Not established. The role-family sweep did not run, so no salary band is offered and none is invented | `[grounded]` see Evidence status, target 2 |
| Unknowns | Salary; contract basis; who decides rating changes; whether reports or mentoring are expected | `[grounded]` JD silence on each |
| Contradictions | None inside the JD itself. The careers page was not checked | `[grounded]` JD as pasted |

## Evidence map

Your background was typed into the conversation, so it counts as CV-equivalent self-report. `medium` is the ceiling until you probe or attach something.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | low | hard_gate | You have not stated where you are based or your right to work. Your UK employer is indirect context only, so the constraint is unconfirmed | `[grounded]` intake silent on location; `[inferred]` UK base from a UK employer | G3: confirm UK base and that remote suits you |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You state 5 years in pricing analytics at a UK motor insurer, the last 2 as senior analyst. It is specific, with no inspectable artifact yet | `[grounded]` your stated background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You state daily use of both. The claim is specific but unprobed, so expect a technical probe | `[grounded]` your stated background | offer: a sanitized query or notebook sample would raise to `high` |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. The claim is specific, with no inspectable artifact yet | `[grounded]` your stated background | offer: a model documentation excerpt would raise to `high` |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting, which is the audience the JD names | `[grounded]` your stated background | offer: a sanitized review deck would raise to `high` |
| R6 | Build and monitor rating models | must_have | direct | medium | none | "Built and maintained" covers building. Monitoring is implied by maintaining, but you have not described monitoring work specifically | `[grounded]` your stated background; `[inferred]` monitoring from "maintained" | CV line to state the monitoring you did, if true |
| R7 | Design and read price tests | must_have | direct | medium | none | You ran 14 price tests last year with underwriting. "Ran" does not say how much of the design was yours, so I take the lower claim | `[grounded]` your stated background | CV line to say what you designed versus ran, if true |
| R8a | Turn results into recommendations for underwriting | important | direct | medium | none | The 14 tests with underwriting and the quarterly review both end in recommendations to that function | `[grounded]` your stated background | none |
| R8b | Turn results into recommendations for product | important | unclear | none | discovery | Nothing you have said touches product stakeholders. You may have done this work and not mentioned it | `[grounded]` intake silent on product | G1 |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer is insurance experience, though in a different line | `[grounded]` your stated background | none |
| R10 | Pet-insurance domain (implied by the product, not asked for in the JD) | preferred | adjacent | medium | transferability | Carries over: GLM rating, price-test design, and working with underwriting. Limit: you have no pet exposure. Pet pricing typically has its own rating factors and claims-cost drivers, such as breed, age and vet-fee inflation | `[grounded]` your stated gap; `[generic]` pet versus motor rating differences | G2: bridge with the limit named |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Product-side recommendations (R8b, important) | discovery | Underwriting is your only named stakeholder. Product is not mentioned either way | An `important` row at `unclear` is the cheapest one to move, and the JD names product alongside underwriting | A test readout or rate-change recommendation that went to a product, commercial or distribution owner; pricing input to a cover or tier redesign; a quarterly-review item product acted on | A sanitized readout, a deck excerpt, a rate-change paper | `[grounded]` intake silent on product; `[generic]` that pricing roles commonly serve product owners |
| G2 | Pet-insurance domain (R10, preferred) | transferability | Motor GLM, test design and underwriting partnership. No pet exposure, as you say | A preferred row, so unlikely to decide the outcome, but it is the first thing an interviewer will probe given the product | Any non-motor line or product you priced; claims-cost inflation or renewal-pricing work; retention or elasticity modelling. Titles do not matter, the method does | A short sanitized write-up of how you would structure a pet rating model: a work sample, not a claim | `[grounded]` your stated gap; `[generic]` that interviewers probe the domain gap |
| G3 | UK base and remote working (R1, hard_gate) | hard_gate | Nothing states your location or right to work | A gate the inputs do not settle stays a gate. It is cheap to confirm and decisive if wrong | Not applicable. This is a fact about you, not a recall prompt | None needed | `[grounded]` intake silent on location |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Salary absent from the posting as pasted | unknown | — | No pay figure appears in the pasted JD | The figure may be unpublished by the employer, or may have been left out when the posting was copied | `[grounded]` JD as pasted silent; `[generic]` that postings often omit pay | What salary range is budgeted for this post, and is it permanent? | unresolved |
| RR3 | Reports and mentoring expectations unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | The post may be an individual-contributor ownership role, or may carry mentoring or a first report | `[inferred]` from the JD naming no reports | Does this role have direct reports, or is mentoring or line management expected in the first year? | unresolved |
| RR4 | Ownership of rating decisions unclear | unknown | — | "turn the results into recommendations for underwriting and product" | "Own" analytics may sit beside recommendation-only rights, with the Director of Pricing or underwriting deciding changes | `[inferred]` from "recommendations" against "own" | Who makes the final rating-change decisions: this role, the Director of Pricing, or underwriting? | unresolved |
| RR5 | Responsibilities are specific and map to work you have done | positive_signal | — | "build and monitor rating models, design and read price tests" | Scope is concrete rather than a bundle of unrelated specialisms | `[grounded]` JD wording | What would a strong first year look like in this seat? | noted |

## Application plan

Everything here, including the advice inside the rows, is proposed. Nothing becomes CV, outreach or interview language until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the role is live on Brindlemoor's own careers page before spending effort on the application | see RR1 | `[grounded]` RR1 | pending your approval |
| E1 | Lead with the young-driver GLM model, the 14 price tests run with underwriting, and the quarterly review to the head of underwriting. State what you designed versus ran only if true | see R4, R5, R7 | `[grounded]` your stated background | pending your approval |
| E2 | Frame pet as a new line: "same method, different book". Name the limit plainly and claim no pet-pricing expertise | see R10, G2 | `[grounded]` R10 row | pending your approval |
| W1 | Optional: a one-page sketch of how you would approach a pet rating model, as a work sample | see R10 | `[inferred]` bridge from the R10 row | pending your approval |
| A3 | If asked about people management, say plainly you have not managed anyone, and ask what the post expects | see RR3 | `[grounded]` your own statement | pending your approval |
| Q1 | Ask the questions of RR1 to RR5 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Stage is assumed to be evaluating.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search "Brindlemoor pet insurance insurtech careers Senior Pricing Analyst" was refused. It would have settled whether the employer exists as described and the posting is live. That feeds role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | Search "senior pricing analyst insurance UK salary remote GLM pricing analytics" was refused. It would have given the market calibration row a salary band and the scope read a norm, and sharpened RR2 |
| 3. Hiring manager's public footprint | unavailable | Search "Odile Varga Director of Pricing Brindlemoor" was refused. It would have informed the scope read and which of your stories the plan leads with for this reader |

I can offer the dossier as a file, `tuesday-dossier.md`, if you want one to keep.

## Upgrade menu

- Search access granted, or the live posting link, or the careers page text pasted in → RR1 resolves, role reality's organization and contradictions rows firm up, and the decision may move from `conditional_go` to `go`.
- A sanitized query, notebook, model documentation excerpt or review deck → R3, R4 and R5 can reach `high`.
- Any product-facing readout or rate-change paper → R8b moves off `unclear`.
- The salary range → RR2 closes, and it is checked against your floor if you give one.
- Odile Varga's public talks or writing, once search is allowed → the scope read and the lead story for her.
- A deeper research pass on Brindlemoor (funding, leadership, recent news; up to 5 more searches and 2 more fetches) → fills the register further. Say the word and it runs, once search access is granted.

G3 — Are you UK-based, and does fully remote work for you?
G1 — Have you ever taken a test result or rate recommendation to a product, commercial or distribution owner? What did you own, and what happened?
RR2 — What is the lowest salary you would accept, and is there anything else about the role's terms that would be a deal-breaker?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.