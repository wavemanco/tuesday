I'm loading the skill's remaining reference files, then checking that the posting is live. After that I'll write the assessment.
**Yes, it's worth applying, on conditions. Status: `conditional_go`.** I assumed your stage is "evaluating" because you didn't give one.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote (US) or Denver), R2 (Salary $148,000–$166,000 against your floor)
- `must_have` — direct: R3, R4, R5, R6, R7, R9, R10
- `important` — adjacent: R8 (BigQuery warehouse) · unclear: R11 (Ingestion from app and CRM), R12 (Data contracts analysts depend on)

R8 — a credible bridge, its limit named; R11 and R12 — your background is silent on them, one question each.

**Opportunity ledger.** The role is plausibly sound and pays well on its face (RR2). Equity terms (RR3), what "Senior" covers here (RR4) and the unnamed manager (RR5) are open. The employer's own pages were not checked live (RR1).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver), R2 (Salary $148,000–$166,000 against your floor); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed live on Pellucid's own careers page, which closes RR1; (2) your location and salary floor are confirmed against R1 and R2; (3) the BigQuery gap is framed as adjacent, never as BigQuery experience (R8).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Live online tutoring for K-12 schools in 31 US states. Founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` the about-page text you pasted; I could not check it against the live page |
| Mandate | Build and run the pipelines behind reporting: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Scope read | Wider than the pay report's "one domain's pipelines": ingestion, modelling and contracts are all named. At 264 people this could be a small data team where the role spans stages | `[inferred]` from the JD's three named responsibilities against the report's typical scope |
| Market calibration | Senior at Series B–D: base median $151,000, interquartile range $139,000–$163,500. "Senior" typically means 5–8 years, with no direct reports. Your 6 years sits inside that | `[generic]` Datawright 2026 report as your recruiter supplied it; a pattern, not Pellucid's offer |
| Unknowns | Team size and reporting line, hiring manager, equity terms, first-90-day outcomes, on-call expectations | `[grounded]` posting silent on each |
| Contradictions | None between the JD and the about text. Neither was checked against the live site | `[grounded]` the two pasted texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | low | hard_gate | The posting states the terms. Your location and US work authorization were not given, so the gate can't be called met | `[grounded]` JD; candidate constraints not given | Question C1 |
| R2 | Pay $148,000–$166,000 plus equity | hard_gate | unclear | low | hard_gate | The range is stated, but your floor is not, so the gate is unconfirmed | `[grounded]` JD; candidate constraints not given | Question C1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | 6 years at a B2B payroll company, stated by you. No CV or dated artifact has been seen | `[grounded]` your statement | none |
| R4 | Strong SQL | must_have | direct | medium | none | Daily SQL use plus a roughly 180-model dbt project. "Strong" is the JD's judgment and an interview will probe it | `[grounded]` your statement | none |
| R5 | Strong Python | must_have | direct | medium | none | Daily Python use, stated. No artifact shows depth | `[grounded]` your statement | none |
| R6 | dbt | must_have | direct | medium | none | You built the project, about 180 models. A sanitized project doc or lineage screenshot would raise this to `high` | `[grounded]` your statement | offer: project doc |
| R7 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse, so the requirement as written is met | `[grounded]` your statement | none |
| R8 | BigQuery (the JD's named warehouse) | important | adjacent | medium | transferability | Adjacent: dbt modelling and warehouse work on Snowflake. Limit: you have never used BigQuery, so nothing BigQuery-specific has been exercised | `[inferred]` adjacency from Snowflake plus dbt | see G1 |
| R9 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow named directly, so the requirement is met as written | `[grounded]` your statement | none |
| R10 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite. A sanitized suite excerpt would raise this to `high` | `[grounded]` your statement | offer: suite excerpt |
| R11 | Ingestion from the app and the CRM | important | unclear | low | discovery | Your background doesn't say what sources you ingested at the payroll company. Product-event or CRM ingestion may exist and be unmentioned | `[grounded]` background silent | Question G2 |
| R12 | Data contracts analysts depend on | important | unclear | low | discovery | Nothing stated about schema agreements, SLAs or analyst-facing guarantees. You may have done this without calling it a contract | `[grounded]` background silent | Question G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8, important) | transferability | Snowflake plus 180-model dbt project. No BigQuery use | The JD names BigQuery, so it is the most visible gap against the stack. An interviewer will ask | A dbt-on-BigQuery side project; any exposure to BigQuery through a vendor or analyst integration; migration or cost-tuning work on Snowflake that maps to the same concepts | A small public repo or a short write-up. Bridge limit: stays "no production BigQuery" | `[inferred]` bridge from your Snowflake and dbt work; `[generic]` that warehouse specifics are what interviews test |
| G2 | App and CRM ingestion (R11, important) | discovery | Background silent on source types | Ingestion is the first named responsibility | Loading product events or application database exports; syncing a CRM such as Salesforce or HubSpot into the warehouse; building or maintaining a connector or an ELT tool setup | A pipeline diagram, a DAG screenshot, a README | `[grounded]` background silent; `[inferred]` that payroll-platform work plausibly included app data |
| G3 | Data contracts (R12, important) | discovery | Background silent | The JD calls contracts what analysts depend on | Agreeing schemas or freshness SLAs with analysts or upstream teams; dbt model contracts or tests that block bad changes; a change process for breaking columns | A contract doc, a dbt `schema.yml` excerpt, an incident note | `[grounded]` background silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not checked against live pages | risk_signal | low | "Founded 2016, Denver. 264 employees. Series C ($52M, February 2026)" | I could not fetch the live pages, so the pasted text may be stale or edited. A pasted about page is also a low-concern source, which is why this is `low` | `[generic]` pattern: pasted copies can lag the live site; not a claim about Pellucid | Can you point me to this role on your own careers site, and say who I'd be interviewing with? | unresolved |
| RR2 | Pay stated and in the upper half of the market band | positive_signal | — | "Salary $148,000–$166,000" | The range's low end is $3,000 below the $151,000 median, and its high end is $2,500 above the $163,500 top of the interquartile range. The $157,000 midpoint is $6,000 above the median, so the pay fits the title | `[grounded]` JD range and Datawright report as supplied; arithmetic done from those figures | Where in the range would someone with this background land? | noted |
| RR3 | Equity named, terms withheld | unknown | — | "plus equity" | The grant size, vesting and strike terms may change total pay either way | `[inferred]` from the posting naming equity without terms | What is the equity grant for this level, and what are the vesting and exercise terms? | unresolved |
| RR4 | Scope of "Senior" unclear against typical single-domain scope | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | The role may be an end-to-end data engineering post, wider than the typical senior remit in the report | `[inferred]` from the JD's three named responsibilities against the `[generic]` report scope | How many data engineers are on the team, and which pipelines and models would I own from day one? | unresolved |
| RR5 | No hiring manager named | unknown | — | "The posting names no hiring manager" | Reporting line and team context are unknown | `[grounded]` you noted no manager is named | Who would I report to, and who would be on my interview loop? | unresolved |

## Application plan

All rows below, and the prose advice under them, are proposals pending your approval. Nothing here is finalized until you say so.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with your dbt project, the Great Expectations suite and Airflow, in your own wording and with "Snowflake" stated plainly. Do not list BigQuery | R6, R9, R10 are your strongest `direct` rows; R8 is `adjacent` and must stay so | `[grounded]` your background statements | pending your approval |
| E2 | In the cover note, say the warehouse experience is Snowflake with dbt, that BigQuery is new to you, and why the modelling work carries over. Add only what you can then confirm in conversation | R8's limit is named up front rather than found by the interviewer | `[inferred]` framing derived from R8 | pending your approval |
| W1 | A small dbt-on-BigQuery sample, if time permits | Narrows R8's limit. It will not turn it into production BigQuery experience | `[inferred]` from G1 | pending your approval |
| A1 | Open Pellucid's careers page yourself and confirm the posting is live and matches | I could not run the check (see Evidence status) | `[grounded]` RR1 | pending your approval |
| Q1 | Ask RR3, RR4 and RR5's questions verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Everything about your background is your own statement. Nothing has been confirmed against a CV or artifact.

Research tier: L1 — searches 0 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | I sent two fetches, of pellucidlearning.com/careers/senior-data-engineer and pellucidlearning.com/about, to check your pasted text was live and current. Both were refused, so nothing moved. It would have fed RR1 and role reality's contradictions row |
| 2. Role-family sweep | skipped | The Datawright report you pasted already fixes the market calibration line and the pay comparison in RR2 |
| 3. Hiring manager's public footprint | n/a | The posting names no manager, so there was no query to form |

## Dossier offer

I can save all of this as a `tuesday-dossier.md` file if you want to keep it or build on it later.

## Upgrade menu

- Your location, US work authorization and base-salary floor → R1 and R2 resolve, and `conditional_go` likely becomes `go` or `no_go`.
- Pasting the live careers page text, or approving the page fetch → RR1 closes and the employer facts become checked rather than pasted.
- A sanitized dbt project doc, lineage screenshot or Great Expectations suite excerpt → R6 and R10 can move from `medium` to `high`.
- Answers on ingestion sources and contracts → R11 and R12 move from `unclear`.
- The hiring manager's name, once known → scope read and which story to lead with.
- A deeper research pass on Pellucid (funding, leadership churn, public employee and candidate reports, recent news; up to 5 more searches and 2 more fetches). It needs the fetch permission that was refused above, so say the word and approve it if you want it to run.

**Questions** (answer in text, paste a voice transcript, attach a document, drop a link, or say skip, for any of them):

- C1 (R1, R2) — Where are you based and authorized to work, do you prefer remote or Denver, and what's the lowest base salary you'd accept?
- G2 (R11) — At the payroll company, did you ingest data from a product application or a CRM, and what did you own in that pipeline?
- G3 (R12) — Did you ever agree schema, freshness or quality guarantees with analysts or upstream teams, and how were they enforced?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.