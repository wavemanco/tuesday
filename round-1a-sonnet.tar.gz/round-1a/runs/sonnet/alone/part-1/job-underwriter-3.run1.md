I've read the underwriting rules. Now I'm running the budgeted research: checking whether Novaline exists as described, and what comp this role usually pays.
Searching isn't permitted in this session, so I couldn't check Novaline or the market. The assessment below runs on your message and the posting alone, and says where that limits it.

## Decision snapshot

**No, this isn't worth pursuing. R1 and R2 are both hard gates and both fail. Status: `no_go`.** The "something feels off" is real, but the two gates settle it before the other flags matter.

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (On-site Austin 5 days a week), R2 (Base pay $70–85k)
- `must_have` — direct: R3, R5, R6, R7 · adjacent: R8 (Team of one) · unclear: R4 (8+ years growth leadership)
- `important` — unclear: R9 (SEO/content), R10 (Brand and PR), R11 (Partnerships), R12 (Sales ops)

R8 — a bridge, its limit named; R4 — the leadership span inside your 9 years isn't stated; R9, R10, R11, R12 — functions you haven't claimed yet.

**Opportunity ledger.** The role has problems apart from your constraints. It bundles functions into a one-person seat (RR4, RR7), uses always-on language (RR5), and leaves success metrics open (RR6). Pay is stated against a heavy requirement stack (RR3), and the employer is unverified (RR8). One entry runs the other way: the terms are explicit (RR9).

- **Hard gates:** failed: R1 (On-site Austin 5 days a week), R2 (Base pay $70–85k)
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`)
- **What would change this:** R1 would need to be remote or workable from Portland, and R2 would need a base of at least $150k. The posting rules out the first in its own words ("no exceptions").

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` JD header; not independently checked |
| Mandate | Own all revenue growth end to end across paid, SEO/content, lifecycle/CRM, brand, PR, partnerships and sales ops | `[grounded]` JD |
| Reporting | CEO, with a dotted line to the board | `[grounded]` JD |
| Team and budget | A team of one "to start"; no budget or decision rights stated | `[grounded]` JD states the team size; `[inferred]` that budget is unstated, from silence |
| Working pattern | On-site in Austin 5 days a week, "no exceptions"; evenings and weekends "when it matters" | `[grounded]` JD |
| Pay | $70–85k base plus "meaningful equity upside", no figure or terms given for the equity | `[grounded]` JD |
| First-year outcomes | None stated; "success metrics will evolve as we learn" | `[grounded]` JD |
| Scope read | Seven functions in one seat with no bench is broad for a single hire | `[inferred]` from the function count against the team-of-one line |
| Market calibration | Not established. The role-family sweep did not run, so no band for this title and scope is stated | `[grounded]` the posting's own figure; sweep unavailable |
| Unknowns | Who Novaline's customers are, the equity terms, budget and decision rights, and whether the posting is live | — |
| Contradictions | Not checked against the company's site. Inside the posting, a "Head of" title with 8+ years of leadership required sits against a team of one and a $70–85k base | `[inferred]` from the JD's own terms |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Austin, 5 days a week, no exceptions | hard_gate | hard_gate_fail | high | hard_gate | Your stated limit is remote-only, in Portland, no relocation. Confidence grades your own confirmed constraint; the JD's "no exceptions" is why the gate fails | `[grounded]` JD quote and your statement | Surface only; wording can't solve it |
| R2 | Base pay of $70–85k | hard_gate | hard_gate_fail | high | hard_gate | Your floor is $150k base. That is $65k above the top of the posted range, so no point in the range clears it. Confidence grades your own confirmed constraint | `[grounded]` JD quote and your statement | Surface only; wording can't solve it |
| R3 | 8+ years of growth work | must_have | direct | medium | none | You state 9 years in growth. Self-reported and nothing inspectable yet, so `medium` | `[grounded]` your statement | none |
| R4 | 8+ years of growth leadership | must_have | unclear | low | discovery | You were "growth lead, then Head of Growth", but you didn't say how many of the 9 years were in the lead and head roles. The ambiguity resolves downward. Years-of-experience terms are screened literally by some employers | `[grounded]` your statement; `[generic]` on literal screening | Recall question G1 |
| R5 | Own revenue growth, with a budget | must_have | direct | medium | none | You scaled one company from $8M to $40M ARR over three years with a budget you controlled. The limit: both companies were B2C subscription, and the posting doesn't say who Novaline's customers are. This row reads revenue ownership only; R9–R12 carry the rest of "end to end" | `[grounded]` your statement; `[grounded]` JD silent on customer type | A sanitized ARR or channel report would raise it to `high` |
| R6 | Paid acquisition | must_have | direct | medium | none | You stated you owned paid at both companies | `[grounded]` your statement | A sanitized channel report would raise it |
| R7 | Lifecycle/CRM | must_have | direct | medium | none | You stated you owned lifecycle and are deep in Braze | `[grounded]` your statement | A sanitized lifecycle program summary would raise it |
| R8 | Working as a team of one, with no bench | must_have | adjacent | low | transferability | You built and managed teams of 3–7 and are deep in SQL, GA4 and Braze, which is hands-on tooling. Doing the work alone was not stated. Taking the lower band | `[grounded]` your statement; `[inferred]` the adjacency, from the tools | Gap queue G2 |
| R9 | SEO/content | important | unclear | none | discovery | Nothing in what you've said touches it | `[grounded]` your statement is silent | Gap queue G3 |
| R10 | Brand and PR | important | unclear | none | discovery | Nothing in what you've said touches it | `[grounded]` your statement is silent | Gap queue G3 |
| R11 | Partnerships | important | unclear | none | discovery | Nothing in what you've said touches it | `[grounded]` your statement is silent | Gap queue G3 |
| R12 | Sales ops | important | unclear | none | discovery | Nothing in what you've said touches it | `[grounded]` your statement is silent | Gap queue G3 |

## Gap recovery queue

R1 and R2 get no recovery row. They are hard gates, and no repositioning changes them.

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Growth leadership span (R4, must_have) | discovery | 9 years in growth, lead then Head, with no split of the years | A literal "8+ years" screen would read the leadership portion only | Dates for your first lead or manager title at either company | A dated role history | `[grounded]` your statement; `[generic]` that some employers screen titled years literally |
| G2 | Solo operation (R8, must_have) | transferability | Team-building and hands-on tools; no stated stretch of working with no one reporting to you | A team-of-one seat tests execution depth, not team management | A stretch before your teams existed, or a channel you ran yourself end to end | A sanitized experiment log or a channel build you did yourself | `[inferred]` bridge from the tools you named; `[generic]` that solo seats test execution depth |
| G3 | Breadth beyond paid and lifecycle (R9, R10, R11, R12, important) | discovery | No stated work in SEO/content, brand, PR, partnerships or sales ops | The posting bundles all of them into the one seat | Content or SEO work you directed; a partnership or affiliate deal; a PR or launch push; CRM or pipeline reporting you owned | Any sanitized output in these areas | `[grounded]` your statement is silent; `[generic]` that growth heads often touch some of these |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | On-site requirement conflicts with your remote-only constraint (R1) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions." | The employer has said it won't flex this term | `[grounded]` JD quote | Is the 5-day on-site requirement fixed for this seat? | confirmed |
| RR2 | Pay range sits below your floor (R2) | red_flag | high | "Compensation: $70–85k base plus meaningful equity upside." | Equity is the only lever, and no terms are given | `[inferred]` from the JD's silence on equity terms | What are the equity terms (percentage, vesting, strike price)? | confirmed |
| RR3 | Seniority-pay mismatch | risk_signal | medium | "8+ years growth leadership required" beside "$70–85k base" | The pay may sit below what this requirement stack normally commands. The sweep that would test it did not run, so it stays a risk signal | `[inferred]` from the JD's own terms; no band established | What is the budgeted base for this seat, and how was the range set? | unresolved |
| RR4 | Bundled specializations | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops" | Several full roles are folded into one title | `[generic]` pattern for bundled postings | Which two or three of these would matter most in year one? | unresolved |
| RR5 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | After-hours work may be routine and the phrase gives it no limit | `[generic]` pattern for this wording | What does a typical month of evening and weekend work look like for this seat? | unresolved |
| RR6 | Success metrics left open on a demanding mandate | risk_signal | medium | "Must thrive on ambiguity; success metrics will evolve as we learn" | Accountability for all revenue growth, with no definition of success | `[inferred]` from the JD's scope against its silence on outcomes | What would success look like at 90 days and at 12 months? | unresolved |
| RR7 | Responsibility without stated resources | risk_signal | medium | "You will be a team of one to start" | Accountability for everything, with no budget, team or decision rights named | `[inferred]` from the JD's silence on budget and authority | What budget and decision rights does this seat have? | unresolved |
| RR8 | Employer not established | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The company may be too new or small to have a footprint, the posting may be stale, or it may not be a real hiring employer. No check ran | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR9 | Terms stated plainly | positive_signal | — | "Compensation: $70–85k base"; "no exceptions" | The posting lets you judge fit on pay and location at once | `[grounded]` JD states both | Is the $70–85k range the budgeted base for this seat? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't spend application effort on this posting | R1 and R2 fail and neither term is likely to move | `[grounded]` R1, R2 | pending your approval |
| A2 | On future postings, check location and pay terms first, before reading the responsibilities | Both of your constraints are visible in the posting text | `[grounded]` your constraints | pending your approval |
| A3 | For a posting that clears both gates, lead with your own sentence: "scaled one company from $8M to $40M ARR over three years with a budget I controlled" | It is your strongest stated evidence (R5); I haven't proposed new wording | `[grounded]` your statement | pending your approval |

## Evidence status

Verified: none yet. Leads to confirm: none; nothing was recalled from earlier conversation.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search for Novaline's site and role was refused, so nothing was learned. It would have moved role reality's organization and contradictions rows and RR8 |
| 2. Role-family sweep | unavailable | The salary search was refused. It would have moved the market-calibration row and RR3 |
| 3. Hiring manager's public footprint | n/a | The posting names no one, only "the CEO", so there is no query to form |

## I can also emit this as `tuesday-dossier.md` if you want it saved.

## Upgrade menu

- Permission to search → runs targets 1 and 2: whether Novaline and a live posting exist (RR8), and a market band for this seat (RR3, the market-calibration row).
- A link to Novaline's own careers page, or the recruiter's email domain if one has contacted you → RR8 closes without a search.
- A sanitized ARR or channel report, a lifecycle program summary, or an experiment log → R5, R6 and R7 to `high`.
- Dates for your lead and head titles → R4 resolves.
- Any work in SEO/content, brand, PR, partnerships or sales ops → R9, R10, R11 and R12 move off `unclear`.
- The CEO's name → role reality's scope read.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.