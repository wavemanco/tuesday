I've read the posting and the skill's rules. Next I'm loading the search tool for the company, market-pay and hiring-manager checks, then I'll write up the assessment.
**Should you go for it? Yes, apply, with conditions · `conditional_go`.** R6 (owning a forecast) is adjacent and R7b (billing data) is absent, and both are `must_have` rows. R1 and R2, the Bristol hybrid and the salary, can't be checked because I don't know your constraints.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Bristol hybrid, two office days), R2 (salary £61,500–£67,000)
- `must_have` — direct: R3, R4, R5a · adjacent: R6 (owning a forecast) · unclear: R5b (spreadsheet modelling), R7a (working with finance on revenue data) · absent: R7b (billing data)
- `important` — direct: R8 · adjacent: R9 (forecast with the CFO)

R6 — a credible bridge, its limit named; R7b — you've told me you haven't worked on billing data.

**Opportunity ledger.** The pay is stated and in range (RR4). The open points are who owns the forecast (RR1), the team and scope under the "Lead" title (RR2), what owning billing data means (RR3), the option terms (RR5) and whether Quillfield's own site lists the role (RR6).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days), R2 (salary £61,500–£67,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:**
  1. The Bristol hybrid and the pay band both work for you (R1, R2).
  2. The forecast split with the CFO turns out to be one you can grow into (R6, RR1).
  3. You name the billing-data gap plainly and the ramp-up is confirmed (R7b, RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants, founded 2018 in Bristol, 96 employees, Series A (£11M) closed April 2025 | `[grounded]` quillfield.co.uk/about, from search |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting for sales and finance; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern and pay | Bristol, hybrid, two office days a week; £61,500–£67,000 plus share options (terms not stated) | `[grounded]` posting |
| Requirements stated | 4+ years in RevOps, sales ops or similar analytics at a B2B software company; HubSpot or Salesforce admin; strong SQL and spreadsheet modelling; experience owning a forecast; experience working with finance on billing or revenue data | `[grounded]` posting |
| First-year outcomes | Not stated in the posting | `[grounded]` posting silent |
| Hiring manager | Named by the recruiter, not in the posting. A profile snippet shows Tamsin Achebe as Head of Revenue Operations at Quillfield, previously sales operations manager at Corvane Payments for four years | `[grounded]` recruiter via you, plus a search snippet; I did not open the profile page |
| Scope read | Four jobs sit under one title: CRM and billing data, reporting, forecast, finance partnership. A Head of RevOps already exists, so this is probably a lead under her, with team size unknown | `[inferred]` from the posting's scope list plus the profile title |
| Market calibration | £61,500–£67,000 sits inside the survey's interquartile range (£57,800–£70,400) and near its median (£64,200) for UK B2B software revenue operations leads, so it is not a mismatch | `[generic]` Ledgerline 2026 pay guide, n=438; `[grounded]` the posting's figure |
| Unknowns | Forecast ownership split; reporting line and team; billing system and who administers it; option terms | — |
| Contradictions | None between the posting and Quillfield's About page. The role is not yet confirmed on Quillfield's own careers page (RR6) | `[grounded]` both pages |

## Evidence map

Your background is self-report from your message, so it counts as CV-equivalent and sits at `medium` at most.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two office days a week | hard_gate | unclear | none | hard_gate | The posting states the term. You haven't told me your location or whether it works, so there's no stated constraint to grade | `[grounded]` posting; no candidate constraint given | Q1 |
| R2 | Salary £61,500–£67,000 | hard_gate | unclear | none | hard_gate | Pay is stated, but your floor isn't given | `[grounded]` posting; no candidate constraint given | Q1 |
| R3 | 4+ years in RevOps, sales ops or similar analytics at a B2B software company | must_have | direct | medium | none | 5 years in sales ops, the last 2 running RevOps for the UK team. Unconfirmed whether a payments company counts as "B2B software" | `[grounded]` your background message; sector fit `[inferred]` | Describe the employer's product in a line so the sector reads clearly |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified | `[grounded]` your background message | A certification record would raise this to `high` |
| R5a | Strong SQL | must_have | direct | low | discovery | SQL weekly shows use, not depth | `[grounded]` your message; depth unprobed | Offer a sanitized query or a described example |
| R5b | Spreadsheet modelling | must_have | unclear | low | discovery | Excel daily and rebuilt dashboards show use, not modelling | `[grounded]` your message | A sanitized model would close it |
| R6 | Experience owning a forecast | must_have | adjacent | medium | transferability | You run the monthly pipeline review with your sales director, which feeds a forecast, but finance owned it. The limit is that you have not owned the number | `[grounded]` your message; the bridge is `[inferred]` | G1; Q2 |
| R7a | Working with finance on billing or revenue data | must_have | unclear | low | discovery | Your renewal dashboards likely touched revenue figures, but whether you worked with finance on them is unconfirmed | `[inferred]` from renewal dashboards | G3; Q3 |
| R7b | Owning billing data | must_have | absent | none | capability | You say you have never worked on billing data. Nothing adjacent is in evidence | `[grounded]` your message | G2 |
| R8 | Pipeline and renewal reporting for sales and finance | important | direct | medium | presentation | You rebuilt the pipeline and renewal dashboards. Your message doesn't say finance used them | `[grounded]` your message | E1 |
| R9 | Running the forecast with the CFO | important | adjacent | medium | transferability | You hold a monthly review with a sales director, not a finance executive. Quarterly CFO work is unevidenced | `[grounded]` your message; the posting's "with the CFO" is `[grounded]` | Same as R6 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning a forecast (R6, must_have) | transferability | Monthly pipeline review with the sales director; finance owned the company forecast | A `must_have` at `adjacent` and the role's headline duty. A stronger bridge narrows the likeliest objection | Building a pipeline-to-forecast roll-up finance used; tracking forecast against actuals; setting a commit or best-case method | A sanitized forecast-versus-actual view | `[inferred]` bridge; `[generic]` that this is the likeliest objection |
| G2 | Billing data (R7b, must_have) | capability | No billing-data work in evidence | A `must_have` at `absent`. The posting says you would own the data | No credible adjacent evidence. Closure is either a bridge via renewal data or an agreed ramp-up | Nothing to attach today | `[grounded]` your message |
| G3 | Working with finance on revenue data (R7a, must_have) | discovery | Renewal dashboards, with no stated finance link | A real link could lift R7a and soften G2 | Reconciling renewals against invoiced revenue; agreeing definitions with finance; a monthly finance review | A dashboard screenshot or definitions doc | `[inferred]` from renewal dashboards |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Forecast ownership split unclear | unknown | — | "run the quarterly revenue forecast with the CFO" | The CFO may own the model and the number, with this role supplying inputs | `[inferred]` from the posting's wording | Who owns the forecast model and the number the board sees: this role or finance? | unresolved |
| RR2 | Wide scope under "Lead", team unstated | risk_signal | low | "own our CRM and billing data, build the pipeline and renewal reporting…" | Several jobs may be folded into one title. A Head of RevOps exists, so reporting is probably to her. Rated low because the team may well be adequate | `[inferred]` from the scope list plus the profile title | Who does this role report to, and who else is in the team? | unresolved |
| RR3 | Billing data ownership undefined | unknown | — | "own our CRM and billing data" | This may include administering the billing system, not only reporting on it | `[inferred]` from "own" | Which billing system, who administers it today, and what does owning the data mean day to day? | unresolved |
| RR4 | Pay stated and in range | positive_signal | — | "£61,500–£67,000 plus share options" | Pay is disclosed and sits within the market range, so no mismatch | `[grounded]` posting; `[generic]` band | Where in the band would an offer sit? | noted |
| RR5 | Option terms unstated | unknown | — | "plus share options" | The value may be material or negligible depending on terms | `[generic]` pattern for early-stage companies | What are the option terms: size, vesting, strike? | unresolved |
| RR6 | Role not confirmed on Quillfield's own careers page | unknown | — | "Revenue Operations Lead, Quillfield" (from the Tallyboard listing) | The search may simply not have returned it. The company itself is established | `[generic]` pattern: listings on job boards often lag a company's own page | Can you point me to this role on Quillfield's own careers page? | unresolved |

## Application plan

Every row below is proposed. Nothing is final until you approve it, and that covers the advice in the Why column as well as the table.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with the rebuilt pipeline and renewal dashboards and the monthly pipeline review with your sales director | Your strongest direct evidence for R8 | `[grounded]` your message | pending your approval |
| E2 | Describe forecast work as "inputs to a forecast finance owned". Don't say you owned the forecast | Keeps R6 and R9 honestly adjacent | `[grounded]` your message | pending your approval |
| E3 | Say plainly that you haven't worked on billing data, and offer renewal revenue data as your closest work only if G3 confirms it | R7b is absent. This stops an interviewer from finding it first | `[grounded]` R7b | pending your approval |
| W1 | A sanitized forecast-versus-actual view or dashboard screenshot | Would help R6, R5b and R8 | `[inferred]` | pending your approval |
| A1 | Ask the recruiter RR1, RR2, RR3, RR5 and RR6 before investing in the process | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A2 | In any conversation with Tamsin Achebe, open from sales-ops and payments-company common ground and the pipeline and renewal reporting | Her public title and past role are sales-ops-shaped. This is what is published, not a read of what she wants | `[grounded]` profile snippet | pending your approval |

## Evidence status

Verified: none yet. Your background is unverified self-report. Rejected inferences: none.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company careers Bristol", which returned "About Quillfield" (quillfield.co.uk/about). It confirmed the company exists as described and moved role reality's organization and contradictions rows. No careers-page result came back, which is RR6 |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK B2B software Bristol", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). It moved the market calibration row and RR4 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Only the snippet was used. It moved the scope read and plan row A2 |

## Closing

If you'd like to keep this, I can write it up as `tuesday-dossier.md`.

**Upgrade menu**
- Your location and salary floor → R1 and R2 move to met or failed, and the decision firms up.
- A Salesforce certification record → R4 to `high`.
- A sanitized forecast-versus-actual view or dashboard → R6, R5b and R8 strengthen.
- Quillfield's own careers-page link or the recruiter's email domain → RR6 closes.
- Deeper research on Quillfield (funding, leadership changes, public staff reports; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**
- Q1 (R1, R2) — Does two days a week in Bristol and a £61,500–£67,000 base work for you?
- Q2 (G1, R6) — Who produced the forecast numbers behind your monthly pipeline review, and did you build or reconcile any piece of the roll-up that fed finance's forecast?
- Q3 (G3, R7a) — When you built the renewal dashboards, did you work with finance on the revenue figures, and what did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.