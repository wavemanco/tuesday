I'll read the reference files the skill points to before building the assessment.
The search tool was refused permission, so both L1 searches failed. This assessment rests on your resume and the JD only, and the research accounting below says exactly what that left unchecked.

## Decision snapshot

**For this role, you aren't wasting your time: it is worth applying to on conditions. Status: `conditional_go`.** This verdict covers Quartzline's role. It does not settle whether the PM pivot as a whole is worth it.

**Fit ledger.**

- `must_have` — direct: R3, R4a · adjacent: R1 (3+ years product management experience), R2 (Shipped API or platform products), R6 (Discovery with integration partners) · unclear: R4b (Stakeholder work with sales), R5 (Own the roadmap)
- `important` — adjacent: R7 (Specs and delivery with two squads), R9 (Launches with sales and support) · unclear: R8 (Adoption metrics), R10 (Agile delivery)

R1 — the gap is the missing PM title, not the underlying work, and the limit is named; R5 — roadmap ownership is the question that can move the decision; R3 (`medium`) — confirmed from your resume, no artifact inspected.

**Opportunity ledger.** The scope and stakeholders are named plainly (RR6). The employer is not yet established (RR1), pay is not stated (RR2), roadmap decision rights are unspecified (RR3), first-year success is undefined (RR4), and the title-literal screen risk is RR5.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and the live posting verify, see RR1; (2) you can show real roadmap or prioritization ownership (R5, G1) or the recruiter confirms adjacent experience counts (R1, RR5); (3) the application presents your work as adjacent and never as a PM title (R1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, a B2B logistics-tech company, about 150 people, Series B | `[grounded]` JD header; its existence is not established (RR1) |
| Mandate | Own the roadmap for the partner-facing API platform; run partner discovery; write specs and drive delivery with two squads; define and track adoption metrics; coordinate launches with sales and support | `[grounded]` JD |
| First-90-day and first-year outcomes | Not stated in the JD | `[grounded]` JD silence (RR4) |
| Scope read | One product area, two engineering squads, and every function from discovery to launch on one person: a full-cycle single-product PM post | `[inferred]` from the responsibility list and the two named squads |
| Seniority | Mid-level product manager, given a 3+ year floor and no "senior" or "lead" in the title | `[inferred]` from the title and the experience floor |
| Market calibration | Not run: the role-family sweep was refused, so no salary band or title norm is offered | `[grounded]` research accounting below |
| Unknowns | Salary; who the role reports to; who owns the roadmap when sales and partners conflict; whether the 3+ years must be under a PM title | `[grounded]` JD silence |
| Contradictions | None visible within the JD; no second source was checked | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years product management experience | must_have | adjacent | medium | transferability | Seven years working beside PMs on custom builds, and running roadmap-input sessions for product, is adjacent work. You have never held a PM title. Posts that state a years-of-PM floor are often screened on title, so expect it to be read literally. | `[grounded]` your resume and your own statement of no PM title; `[generic]` how such floors are screened | Ask the recruiter whether adjacent experience counts (RR5); see G1 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ client integrations of your employer's REST APIs. That is delivering on someone else's API product, not owning its design or release, which is the limit. A product-ownership example would narrow it. | `[grounded]` your resume | See G2 |
| R3 | Technical fluency: API docs and schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI specs and integration architecture across 30+ integrations all point the same way. It is self-reported with no artifact inspected, so expect a probe. | `[grounded]` your resume, caveat named | Optional: a sanitized architecture doc would raise this to `high` |
| R4a | Stakeholder management across engineering and customers | must_have | direct | medium | none | You coordinated your engineers, the client's engineers and product managers, and ran scoping workshops and roadmap-input sessions with clients. | `[grounded]` your resume | none |
| R4b | Stakeholder management with sales | must_have | unclear | low | discovery | The resume does not mention sales at all. No claim exists to grade. | `[grounded]` resume silence | See G3 |
| R5 | Own the roadmap | must_have | unclear | low | discovery | You ran quarterly sessions collecting client feedback for product. That is input to a roadmap, not deciding or prioritizing it. A prior-conversation lead about a request-triage tool is unconfirmed, so it can prompt a question and nothing more. | `[grounded]` resume wording; `[inferred]` that the triage lead could bear on this row | See G1 |
| R6 | Run discovery with integration partners | must_have | adjacent | medium | transferability | Scoping workshops and feedback sessions with integrating clients are discovery-shaped. You gathered the input and product decided what to do with it, which is the limit. | `[grounded]` your resume | See G1 |
| R7 | Write specs and drive delivery with two engineering squads | important | adjacent | medium | transferability | You wrote requirements documents and integration architecture and coordinated engineers on custom builds. Those were client-integration specs, not product specs for standing squads. | `[grounded]` your resume | Surface the closest example, see E1 |
| R8 | Define and track adoption metrics | important | unclear | low | discovery | SQL is on the resume, but no metric you defined or tracked is stated. | `[grounded]` resume silence on metrics | See G3 |
| R9 | Coordinate launches with sales and support | important | adjacent | medium | transferability | Go-lives were client deployments you led, with an internal playbook. A product launch is a different kind of work, so the bridge is partial. | `[grounded]` your resume | none beyond the framing in E1 |
| R10 | Agile delivery | important | unclear | low | discovery | No sprint, backlog or agile mention appears. Custom-build coordination with engineers may have run that way, which is unconfirmed. | `[grounded]` resume silence | Fold into the answer to G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Roadmap ownership and prioritization (R5, must_have; also R6) | discovery | Roadmap-input sessions, which are inputs. An unconfirmed lead about a request-triage tool that support agents adopted. | R5 is the row that can move the decision, since the role says "own the roadmap". | A tool or process where you chose what to build or fix and in what order; a backlog you ranked; a trade-off you decided between clients or teams | A one-page description, a screenshot, an adoption figure, a ticket board | `[grounded]` resume wording; `[inferred]` that this row decides the application's strength |
| G2 | Owning a product, not delivering one (R2, must_have; also R7, R10) | transferability | 30+ delivered integrations of a REST API. Nothing says you owned something that shipped. | A must-have at `adjacent`. A stronger bridge narrows the likeliest objection. | The triage tool; a client-driven API change you wrote the requirements for and engineering shipped; the playbook as a product used by a team; sprint-style delivery with engineers | A spec, a release note, the playbook, adoption numbers | `[grounded]` resume; `[generic]` that this is the usual objection for an integration-side applicant |
| G3 | Sales partnership and metrics (R4b must_have, R8 important) | discovery | No sales contact and no defined metrics on the resume. | R4b is a must-have with no evidence yet. R8 is lower priority. | Joint client calls with sales; pre-sale scoping; time-to-go-live or integration-health numbers you pulled with SQL | A deck, a dashboard screenshot, an email thread | `[grounded]` resume silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The company may be too small to have a footprint, the posting may be stale, or it may not represent a real employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Compensation not stated | unknown | — | Header and body carry no figure | The band may sit above or below what you need, and the posting does not say | `[inferred]` from the JD's silence; no band available | What salary range is budgeted for this role? | unresolved |
| RR3 | Roadmap ownership with unstated decision rights | unknown | — | "Own the roadmap for our partner-facing API platform" | Priorities may be shared with sales or a head of product | `[generic]` pattern in roles that name ownership but no authority | Who sets priorities across the two squads when partner and internal requests conflict, and who does this role report to? | unresolved |
| RR4 | No first-year outcomes stated | unknown | — | "define and track adoption metrics" | Success may not be defined yet | `[inferred]` from the JD, which names activities and no outcomes | What would success look like at six and twelve months? | unresolved |
| RR5 | Years-of-PM floor may be read as a title requirement | risk_signal | low | "3+ years product management experience (must-have)" | The screen could be strict, but a small company may weigh the work over the title. I took the lower severity for that reason. | `[generic]` hiring-screen pattern | Does the 3+ years need to be under a PM title, or does product work in an adjacent role count? | unresolved |
| RR6 | Scope and stakeholders stated concretely | positive_signal | — | "drive delivery with two engineering squads; coordinate launches with sales and support" | The role is specified well enough to discuss | `[grounded]` JD | Which partners are the first discovery targets? | noted |

## Application plan

Both blocks below are `pending your approval`.

**`resume_edits_pending_approval`** — each proposed line traces to your own sentences:

| # | Current line | Proposed line | Basis |
|---|---|---|---|
| E1 | "Ran quarterly roadmap-input sessions collecting client feedback for product" | "Ran quarterly sessions collecting client feedback as input to the product roadmap" | Your sentence. The verb stays "ran … collecting"; no ownership is added. |
| E2 | (no summary) | "Solutions engineer and implementation lead, 7 years, working between client engineers, our engineers and product managers on REST API integrations; moving into API and platform product management." | 7 years, your three-way coordination and REST APIs are all yours. "Moving into" is your own statement of the pivot. |
| E3 | Integration-playbook line | Move it up, text unchanged | Placement only. |

**Positioning advice, `pending your approval`:** open with the 30+ integrations and the roadmap-input sessions, say plainly that the work was adjacent to PM, and ask about the title question (RR5) before investing in the full loop. Do not say "product experience" for any of this work until G1 and G2 are answered.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask the recruiter RR1 and RR5 before applying | Resolves the two conditions that cost the least to check | `[grounded]` RR1, RR5 | pending your approval |
| A2 | Carry RR2, RR3 and RR4 into the interview as your questions | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A3 | Ask someone you know at Quartzline or in its partner network for an introduction | Referrals are a common way past a literal screen | `[generic]` hiring pattern, not a fact about this employer | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: a prior-conversation mention of a request-triage tool that support agents adopted, unconfirmed and used only to prompt G1. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Quartzline logistics technology partner API platform Product Manager"; the call was refused. It would have established whether Quartzline exists as described and whether the posting is live, feeding RR1. |
| 2. Role-family sweep | unavailable | Searched "Product Manager platform API salary range B2B SaaS Series B typical requirements transition from solutions engineer"; the call was refused. It would have fed the market calibration row and the seniority-compensation check against RR2. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |

## Dossier offer

I can save all of this as a `tuesday-dossier.md` file whenever you want it.

## Upgrade menu

- Search permission: with it, I'd run targets 1 and 2 and RR1 could close and a market band could be added.
- Your pay floor and any location or schedule limits → the hard-gates line stops reading "checks unknown" and gains rows.
- Your sanitized architecture doc, playbook excerpt or any spec → R3 to `high`, R2 and R7 strengthen.
- The recruiter's answer on the PM-title question → RR5 and R1 close.
- The hiring manager's name → the scope read and which of your stories to lead with.

## Questions

G1 — Have you ever personally decided what got built or fixed, and in what order, such as a tool, a backlog or a trade-off between clients? What did you own, who used it, and what happened? Your triage tool may be the example, if so.

G2 — Is there anything you started, specified and got shipped, such as a tool, a feature or a client-driven API change, where engineers built it from your requirements? Did it run with sprints or a backlog?

G3 — Did you work with sales on client deals or renewals, and have you defined or tracked a metric such as time-to-go-live, adoption or integration health?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.