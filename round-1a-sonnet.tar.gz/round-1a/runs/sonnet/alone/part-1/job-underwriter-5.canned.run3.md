Still working: I've read most of the underwriting rules and now need the evidence-map row spec. After that I'll check the company's careers and about pages.
## Decision snapshot

**Yes, this looks worth applying to, on conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver office)
- `must_have`: direct: R2, R3, R4, R5, R7, R8
- `important`: adjacent: R6 (BigQuery in the role's stack); unclear: R9 (ingestion from app and CRM), R10 (data contracts for analysts)

R6 (`medium`) is a credible bridge with its limit named; R9, R10 your background doesn't mention yet, so they're open questions rather than gaps.

**Opportunity ledger.** The posting is transparent on pay, and the pay sits at or above the report's median (RR3). It is thin on equity terms (RR1), team and manager (RR2), and on-call (RR4). Funding and headcount come only from the company's own page (RR5). The posting is live and matches what you pasted (RR6).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:**
  1. You confirm US location and work authorization (R1).
  2. BigQuery is presented as not yet used, with Snowflake as the adjacent experience (R6, G1).
  3. You get answers on equity and team structure early in the process (RR1, RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning runs live online tutoring for K-12 schools in 31 US states. Founded 2016 in Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` company About page, fetched (self-reported figures) |
| Mandate | Build and run the pipelines behind reporting: ingestion from the app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts analysts depend on | `[grounded]` JD, careers page fetched |
| Requirements | 5+ years data engineering; strong SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Terms | $148,000–$166,000 plus equity; Remote (US) or Denver office | `[grounded]` JD |
| First-90-days and first-year outcomes | Not stated | `[grounded]` JD silent |
| Scope read | One domain (reporting pipelines), with no direct reports mentioned and no management language | `[inferred]` from the JD's wording against the report's typical scope |
| Market calibration | 5+ years sits inside the report's typical 5–8 for "Senior". The posted band's low end is $3,000 under the $151,000 median, its midpoint ($157,000) is above it, and its top is $2,500 over the $163,500 upper quartile. Scope of one domain with no reports matches the report's typical scope | `[generic]` Datawright 2026 report, supplied by you (n=2,310, Series B–D); `[grounded]` JD for the posted band |
| Unknowns | Equity terms, hiring manager and team size, on-call, first-year outcomes, how deep the BigQuery expectation goes | `[grounded]` JD silent on each |
| Contradictions | None between what you pasted and the pages fetched | `[grounded]` both pages fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location and work authorization weren't given, so the term isn't established. You haven't stated a constraint of your own either | `[grounded]` JD terms; your background is silent | Question Q1 |
| R2 | 5+ years data engineering | must_have | direct | medium | none | You describe 6 years of data engineering at a B2B payroll company. It is self-reported prose, so `medium` is the intake ceiling | `[grounded]` your background statement | Share a CV to check dates |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily" plus a 180-model dbt project supports SQL well. Python rests on that daily-use statement alone, and "strong" is the employer's word | `[grounded]` your background statement | A sanitized model or DAG excerpt would raise it to `high` |
| R4 | dbt | must_have | direct | medium | none | You built your company's dbt project on Snowflake, about 180 models | `[grounded]` your background statement | A sanitized model excerpt or project structure |
| R5 | A cloud warehouse | must_have | direct | medium | none | The JD asks for "a cloud warehouse", and Snowflake is one. BigQuery is carried separately as R6 | `[grounded]` your background statement | none |
| R6 | BigQuery, the role's named warehouse | important | adjacent | medium | transferability | Snowflake with dbt is adjacent. The limit: you have never used BigQuery. The JD names it in the stack and doesn't list it under Requirements | `[grounded]` your statement and JD; `[inferred]` priority from the JD's description of the stack | G1 and Q3 |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | You used Airflow for orchestration | `[grounded]` your background statement | A sanitized DAG excerpt |
| R8 | Experience with data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite | `[grounded]` your background statement | A suite excerpt or check list |
| R9 | Ingestion from the app and CRM | important | unclear | low | discovery | Your background doesn't say what sources fed your pipelines. The pipelines at a payroll company may have used other source types | `[grounded]` your statement is silent; `[generic]` that source types vary by company | G2 and Q2 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | Nothing in your background mentions contracts or agreed schemas, though your tests may be adjacent to them | `[grounded]` your statement is silent | G3 and Q2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R6, important) | transferability | Snowflake plus dbt at 180 models. No hands-on BigQuery | The JD names BigQuery as the warehouse. It is the likeliest question in a screen | A BigQuery or GCP evaluation, side project or migration discussion; a dbt project on any non-Snowflake warehouse | A repo or short write-up. A small dbt project on BigQuery's no-cost tier would narrow the limit | `[grounded]` your statement; `[generic]` that a named warehouse draws a direct question |
| G2 | Ingestion from app and CRM (R9, important) | discovery | The source systems behind your pipelines are unstated | The role's first named duty is ingestion from an app and a CRM | Loading a product database, an event stream or a CRM export; vendor API syncs; CDC or batch loads | A pipeline diagram or a README, sanitized | `[grounded]` your statement is silent |
| G3 | Data contracts (R10, important) | discovery | Great Expectations tests are on record. Contracts with consumers aren't | "Data contracts analysts depend on" is in the mandate | Agreed schemas or SLAs with analysts or upstream teams; schema-change review; documented model owners | A contract doc, a schema-change policy or a dbt model YAML, sanitized | `[grounded]` your statement is silent; `[inferred]` that your tests may be adjacent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Equity unquantified | unknown | — | "plus equity" | The grant may be small or heavily back-loaded. Or the posting may just omit terms | `[inferred]` from the JD naming equity without a figure | What is the equity range for this level, and what are the vesting terms and the latest share price? | unresolved |
| RR2 | Hiring manager and team not named | unknown | — | "Build and run the pipelines" | You may be one of few data engineers, with the whole pipeline in your hands | `[inferred]` from "build and run" and the posting naming no manager | Who does this role report to, and who else is on the data team? | unresolved |
| RR3 | Pay at or above market | positive_signal | — | "$148,000–$166,000 plus equity" | The range is stated openly and its midpoint is above the report's median | `[grounded]` JD and your report's median and quartiles | Where in the range would a candidate with six years land? | noted |
| RR4 | On-call unstated | unknown | — | "Build and run" | "Run" may imply pager duty for the pipelines | `[generic]` pattern for roles that both build and operate | Is there an on-call rotation for the pipelines, and how often does it page? | unresolved |
| RR5 | Company figures are self-reported only | unknown | — | "264 employees. Series C ($52M, February 2026)." | The funding and headcount may be accurate. This pass found only the company's own page for them | `[grounded]` About page fetched, one search returned only that page | Who led the February 2026 round, and what is the data team's hiring plan? | unresolved |
| RR6 | Posting live and consistent | positive_signal | — | "Accepting applications." | The role is open and matches what you were given | `[grounded]` careers page fetched | What are the interview stages and the timeline? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Put this line first among your tools bullets, in your own words: "Built our dbt project on Snowflake — about 180 models." | R4, R5 | `[grounded]` your background statement | resume_edits_pending_approval |
| E2 | Add or surface: "Set up our Great Expectations test suite." | R8 | `[grounded]` your background statement | resume_edits_pending_approval |
| E3 | Use one plain line in the cover note and the screen: "My warehouse experience is Snowflake; I haven't used BigQuery." | R6 | `[grounded]` your background statement | pending your approval |
| W1 | Optionally build a small dbt project on BigQuery's no-cost tier, so you could say you have hands-on time | G1 | `[generic]` common way to narrow a named-tool gap | pending your approval |
| Q1 | Ask RR1, RR2, RR4 and RR5 verbatim with the recruiter or in the first screen | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Confirm your location and authorization against R1 before investing in the loop | R1 | `[grounded]` R1 row | pending your approval |

## Evidence status

Verified: none yet. Every claim above is your own prose background, held at `medium` or below until an artifact or a probe answer backs it.

Research tier: L1 — searches 1 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning online tutoring Series C $52M Denver", which returned only "About Pellucid Learning" (pellucidlearning.com/about). Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer), which shows "Accepting applications" and the text you pasted. Fetched "About Pellucid Learning" (pellucidlearning.com/about), also the same text. Moved: role reality's organization and contradictions rows, RR5, RR6. The funding round has no independent source yet |
| 2. Role-family sweep | skipped | The Datawright report you pasted fixes the market calibration line and RR3's comparison |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there is no name to search |

## Dossier offer

I can turn this into a `tuesday-dossier.md` you can keep, if you want it.

## Upgrade menu

- Your location, work authorization and pay floor: R1 closes, and pay can be set against your floor.
- Your CV: row wording gets checked against it and E1–E2 can be finalized.
- A sanitized dbt model, DAG or Great Expectations excerpt, or a public repo: R3, R4, R7 and R8 can move toward `high`.
- Answers on G2 and G3, plus any BigQuery exposure: R6, R9 and R10 resolve or stay named gaps.
- The hiring manager's name: the footprint target runs and the scope read sharpens.
- Equity terms from the recruiter: RR1 closes.
- A deeper pass on Pellucid, covering independent confirmation of the Series C, hiring patterns, employee reports and recent news (up to 5 more searches and 2 more fetches). Say the word and it runs.

## Questions

1. **R1 and pay:** Are you in the US and authorized to work there without sponsorship, and do you prefer remote or Denver? Do you have a pay floor or other must-haves, such as no on-call or minimum equity, I should check against?
2. **R9, R10:** What sources fed your pipelines at the payroll company (app database, CRM, vendor APIs)? Did you agree schemas or expectations with analysts or upstream teams, in any form?
3. **R6:** Have you had any hands-on time with BigQuery or GCP, even a side project or an evaluation?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.