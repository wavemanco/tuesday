**Nadia, you're not wasting your time on the pivot. This role is a stretch rather than a fit: R1b (3+ years of titled PM experience) is a must-have you can't meet as written, and the rest of your background bridges most of the other requirements. Status: `conditional_go`, meaning one targeted application with your expectations set accordingly.**

## Decision snapshot

**Fit ledger.**

- `must_have` — direct: R3, R4, R6a · adjacent: R1a (specs and delivery with engineering), R2 (shipped API or platform products), R5 (own the roadmap) · absent: R1b (3+ years titled PM experience)
- `important` — unclear: R6b (sales and support launch coordination), R7 (agile delivery), R8 (adoption metrics)

R1b — a titled-years gap, not a verdict on capability; R1a, R2, R5 — credible bridges, limits named; R7, R8 — CV silent.

**Opportunity ledger.** The mandate is concretely stated (RR3), but the employer is unverified because research did not run (RR1), pay and location are withheld (RR2), and the JD does not say whether the titled-years bar bends (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Quartzline verifies as a live employer with a live posting (RR1); (2) the recruiter or hiring manager confirms adjacent product work is considered against R1b (RR4); (3) the bridges for R1a, R2 and R5 are framed as adjacent, never as PM experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B | `[grounded]` JD header, not independently verified |
| Mandate | Own the roadmap for the partner-facing API platform; run discovery with integration partners; write specs and drive delivery with two engineering squads; define and track adoption metrics; coordinate launches with sales and support | `[grounded]` JD |
| Stated requirements | 3+ years PM experience (labelled must-have); shipped API or platform products; technical fluency; stakeholder management across engineering, sales and customers; agile delivery | `[grounded]` JD |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Scope read | The customer is an integration partner and the product is an API, which is the same surface you have spent seven years implementing from the client side | `[inferred]` from the JD's "partner-facing API platform" against your resume |
| Market calibration | Not done. The role-family sweep could not run, so no pay band or title norm is offered and nothing here should be read as one | `[grounded]` search permission not granted |
| Unknowns | Pay, location and remote policy; whether this is the first PM on the platform; how strictly the 3+ years is enforced | `[grounded]` JD silent |
| Contradictions | None found between the JD and your resume; the JD was not checked against Quartzline's own careers page | `[grounded]` the two provided inputs |

## Evidence map

Every resume claim is self-report at intake, so `medium` is the ceiling here.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | Write specs and drive delivery with engineering squads | must_have | adjacent | medium | transferability | You wrote requirements documents and coordinated your engineers, the client's engineers and PMs on custom builds. Limit: this was delivery of client integrations, not a product squad's backlog, and you did not own prioritization | `[grounded]` resume | See G2 |
| R1b | 3+ years of product management experience | must_have | absent | none | capability | You have never held a PM title, so the titled version of this requirement is absent. It is a length-of-experience requirement, so it is not a gate. Employers often screen explicit titled-years requirements literally | `[grounded]` your statement; `[generic]` how such requirements are screened | Ask RR4's question before investing; no wording fixes this |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | Thirty-plus client integrations of your employer's REST APIs, end to end, plus an integration playbook your team uses. Limit: you integrated and implemented the product; nothing confirmed shows you shipped one | `[grounded]` resume; `[inferred]` that the playbook is the closest product-like artifact | See G1 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI specs, and REST integration architecture are stated and specific, but no artifact has been inspected | `[grounded]` resume | A sanitized integration architecture diagram or playbook excerpt would raise this to `high` |
| R4 | Run discovery with integration partners | must_have | direct | medium | presentation | Scoping workshops and quarterly roadmap-input sessions collecting client feedback for product are the same activity with integration clients. The resume files them under implementation rather than input into product | `[grounded]` resume | Edit E1 pending approval |
| R5 | Own the roadmap | must_have | adjacent | medium | transferability | You fed client input into the product roadmap. Limit: you did not decide what got built or in what order | `[grounded]` resume | Name the limit in any use of the claim |
| R6a | Stakeholder management with engineering and customers | must_have | direct | medium | none | You coordinated your engineers, client engineers and product managers, and you ran client-facing workshops through to go-live | `[grounded]` resume | Same artifact request as R3 |
| R6b | Coordinate launches with sales and support | important | unclear | low | discovery | The resume says nothing about sales or support. Go-lives involved clients, but how launch work was split with sales and support is not stated | `[grounded]` resume silence | See G3 |
| R7 | Agile delivery | important | unclear | low | discovery | The resume describes UAT and go-live phases but not sprints, backlogs or squad ceremonies | `[grounded]` resume silence | See G2 |
| R8 | Define and track adoption metrics | important | unclear | low | discovery | Nothing confirmed. Agent memory suggests an internal request-triage tool that support agents adopted, which is an unconfirmed lead and not evidence | `[inferred]` from an unconfirmed memory lead | See G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Shipped product and adoption metrics (R2, R8) | discovery | Integration work and a playbook are confirmed; whether you ever built something others adopted, and how you knew, is not | R2 is a `must_have` row at `adjacent`; a confirmed adopted tool would be the nearest thing to a shipped product on your record | A tool, template, script or process other people actually used; a usage count or before-and-after change; an internal launch announcement | A screenshot, a short write-up, a usage figure, a note from a user | `[grounded]` resume silence; `[inferred]` that this could move R2 |
| G2 | Agile delivery and prioritization (R1a, R7) | discovery | Requirements documents and engineer coordination are confirmed, but not sprint rhythm or who decided scope | These are the nearest checks on the delivery half of the role | Planning or grooming with a squad; negotiating scope with engineers mid-build; a release you sequenced | A sprint board export, a release plan, a scope-change log | `[grounded]` resume silence; `[generic]` that interviews for this role probe delivery ownership |
| G3 | Sales and support launch coordination (R6b) | discovery | Client-facing go-lives are confirmed; the sales and support side is not | A named requirement at `important`, and a cheap one to close if the work exists | Preparing sales or support for a client launch; handoffs to support after go-live; enablement material | A handoff checklist or launch note | `[grounded]` resume silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "B2B logistics-tech, ~150 people, Series B" | Search permission was not granted, so nothing could attribute the company or confirm the posting is live. The company may be genuine and merely unchecked | `[generic]` pattern for any unchecked employer, not a claim about this one | Can you point me to this role on your own careers site, and who the hiring manager would be? | unresolved |
| RR2 | Pay and location withheld | unknown | — | JD gives neither | The JD may omit them, or the figures may sit outside what you would accept | `[inferred]` from the JD's silence | What is the salary range, and is the role remote, hybrid or on-site? | unresolved |
| RR3 | Mandate stated concretely | positive_signal | — | "Own the roadmap for our partner-facing API platform... drive delivery with two engineering squads" | Scope, squads and deliverables are named, which suggests a defined role | `[grounded]` JD | Who owns the platform roadmap today, and what has the last two quarters' delivery looked like? | noted |
| RR4 | Flexibility on the 3+ years unknown | unknown | — | "3+ years product management experience (must-have)" | The bar may be strict or may be a proxy for product work that can be shown another way | `[inferred]` from the JD labelling it must-have against its silence on equivalents | Would you consider a candidate whose product work has been in an implementation role rather than a PM title? | unresolved |

## Application plan

Every row is proposed and none is applied.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Resume edit: move "Ran quarterly roadmap-input sessions collecting client feedback for product" to the first bullet under your current role, wording unchanged | See R4 | `[grounded]` resume | `resume_edits_pending_approval` |
| E2 | Resume edit: add a summary line "Solutions engineer and implementation lead, 7 years: led 30+ client integrations of our REST APIs end to end, from scoping workshops to go-live; moving into product management." Each clause traces to your own statements | See R2, R3, R6a | `[grounded]` resume and your stated aim | `resume_edits_pending_approval` |
| A1 | Verify Quartzline and the live posting on its own careers page before writing anything | See RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Before investing in a full application, ask the recruiter RR4's question | See R1b, RR4 | `[grounded]` RR4 | pending your approval |
| A3 | Alongside this one, consider roles titled technical product manager, API product owner or partner-integration product manager, and PM moves inside your current employer, since an existing track record there can substitute for a PM title | See R1b | `[generic]` role-family pattern | pending your approval |
| W1 | If G1 is confirmed, a one-page sanitized write-up of the triage tool | See R2, R8 | `[inferred]` from an unconfirmed memory lead | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: a prior-context mention of an internal request-triage tool that support agents adopted — unconfirmed, and used only to prompt G1.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Quartzline logistics technology company careers Product Manager Platform APIs"; the host refused it. It would have set role reality's contradictions row and RR1 |
| 2. Role-family sweep | unavailable | Searched "API platform product manager salary requirements transition from solutions engineer"; the host refused it. It would have set the market calibration row and RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- Permission to run searches → RR1 and the contradictions row close, and the market calibration row gets a sourced band for RR2.
- An answer to G1 → R2 and R8 may move, and E-row wording on shipped products becomes possible.
- An answer to G2 or G3 → R1a, R7 and R6b firm up.
- A sanitized integration architecture diagram or the integration playbook → R3 and R6a to `high`.
- Your non-negotiables (pay floor, location, sponsorship, notice period) → the hard-gates line stops reading "checks against them unknown".
- A deeper company pass (up to 5 more searches and 2 more fetches) → funding, leadership and hiring patterns for RR1; say the word and it runs once searches are permitted.

I can also write all of this into a `tuesday-dossier.md` you can keep, if you'd like it.

G1 — Is the request-triage tool real, and is there anything inspectable behind it? Which parts did you own, who used it and how many, and how did you know it worked?
G2 — On any custom build, did you take part in sprint planning, scope negotiation or release sequencing with engineers, and who decided what got built first?
C1 — What are your non-negotiables on pay, location and anything else that would rule this role out?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.