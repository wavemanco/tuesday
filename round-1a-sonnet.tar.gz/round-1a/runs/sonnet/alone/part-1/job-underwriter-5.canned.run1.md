I'll read the reference files the skill requires before building the assessment.
I'm still reading the skill's reference files, mainly the research-tier rules and the evidence-map format, before I write the assessment.
I'm writing up the assessment now.

## Decision snapshot

**Yes, it's worth applying — `conditional_go`.** The JD's core requirements (R3, R4, R5, R7, R8) all map directly to your work. The conditions are below, and none of them is a weakness in your background.

**Fit ledger.**

- `hard_gate` — unclear: R1 (US-remote or Denver), R2 (pay range against your floor)
- `must_have` — direct: R3, R4, R5, R7, R8
- `important` — adjacent: R6 (BigQuery); unclear: R9 (ingestion from app and CRM), R10 (data contracts)

R4 (`medium`) — "strong" rests on daily use plus the two artifacts in R5 and R8, not yet inspected; R6 — Snowflake is a credible bridge, its limit named; R9, R10 — the CV is silent, so these are open questions rather than gaps.

**Opportunity ledger.** The stated pay is in line with the market report (RR1) and the posting is live and consistent with the company's own pages (RR2). Open unknowns: the team and scope around the role (RR3), the hiring manager (RR4), and the equity terms (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (US-remote or Denver), R2 (pay range against your floor); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) your own location and pay floor clear R1 and R2; (2) BigQuery is framed as adjacent to Snowflake, never as experience (R6); (3) the team and scope questions in RR3 verify sensibly in the loop.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016 in Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` About page, fetched via search. The funding and headcount appear only on the company's own page |
| Mandate | Build and run the pipelines behind the platform's reporting: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Requirements | 5+ years data engineering; strong SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Terms | $148,000–$166,000 plus equity; Remote (US) or Denver office | `[grounded]` JD |
| First-90-days and first-year outcomes | Not stated | `[grounded]` JD silent |
| Scope read | The mandate spans three areas (ingestion, warehouse modelling, contracts). That may be more than one domain's pipelines | `[inferred]` from the three-part mandate against the pay report's "one domain" scope norm |
| Market calibration | Senior Data Engineer at Series B–D companies: base median $151,000, interquartile range $139,000–$163,500; "Senior" typically means 5–8 years; typical scope is one domain's pipelines, no direct reports. Your 6 years sits inside the 5–8 range | `[generic]` pattern from the Datawright 2026 report you supplied; `[grounded]` for your 6 years |
| Unknowns | Team size and whether this is the first or only data engineer; hiring manager; equity terms; whether pay varies by location | — |
| Contradictions | None between your pasted text and the live careers and About pages | `[grounded]` both pages fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Based in the US (remote) or Denver | hard_gate | unclear | none | hard_gate | You haven't stated your location or any location constraint, so nothing can be checked against the gate | `[grounded]` JD term; candidate constraints not given | Question R1/R2 in the closing block |
| R2 | Base pay $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | You haven't stated a pay floor, so the range can't be checked against it. The range itself is calibrated in RR1 | `[grounded]` JD term; candidate constraints not given | Question R1/R2 in the closing block |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years at a B2B payroll company. A length-of-experience requirement is not a gate. Self-reported, no inspectable proof yet | `[grounded]` your statement | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You state daily use of both. "Strong" is a judgement that daily use alone doesn't establish; the 180-model dbt project and the test suite are the supporting evidence, so expect a depth probe | `[grounded]` your statement | An inspectable sample (a sanitized model or script) would raise it to high |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | You built the dbt project, about 180 models, on Snowflake, a cloud warehouse. Confirmed and specific, no artifact inspected | `[grounded]` your statement | A sanitized model list or project structure would raise it to high |
| R6 | BigQuery as the warehouse the role runs on | important | adjacent | medium | transferability | Snowflake with dbt is a credible adjacency. Limit: you have not used BigQuery, so its cost model, partitioning and clustering choices are unexercised. The JD lists "a cloud warehouse" as the requirement and names BigQuery only in the mandate | `[inferred]` adjacency derived from your Snowflake and dbt work; `[grounded]` that you have never used BigQuery | Gap queue G1 |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | You state Airflow for orchestration, which the JD names directly | `[grounded]` your statement | none |
| R8 | Data quality testing | must_have | direct | medium | none | You state you set up the Great Expectations test suite. Confirmed and specific, nothing inspected | `[grounded]` your statement | A sanitized suite config or example expectations would raise it to high |
| R9 | Ingestion from the product app and CRM | important | unclear | low | discovery | The CV and your statement name orchestration but not which sources you ingested. Not claimed, not ruled out | `[grounded]` silence in your statement | Gap queue G2 |
| R10 | Data contracts that analysts depend on | important | unclear | low | discovery | You mention a dbt project and a test suite, but not any agreed interface with analysts. Nothing is assumed from them | `[grounded]` silence in your statement | Gap queue G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R6, important) | transferability | Snowflake plus dbt at 180-model scale. No BigQuery use | The mandate names BigQuery, so it is the most likely probe for you. A stated bridge with its limit reads stronger in interview than a stretch | Any BigQuery exposure, even a personal project or a migration you took part in; reading cost and partitioning concepts you applied in Snowflake | A small BigQuery project or a short comparison note of Snowflake and BigQuery concepts you worked through | `[inferred]` bridge from your Snowflake work; `[generic]` that warehouse-specific cost and partitioning questions are common in this role family |
| G2 | Ingestion from app and CRM (R9, important) | discovery | Orchestration is evidenced; the sources feeding it are not | The JD lists app and CRM ingestion first in its mandate, so which of it you owned is a likely probe | Loading product database tables or event data; syncing a CRM or another SaaS API; building or fixing a connector; handling schema changes from an upstream source | A pipeline DAG, an architecture diagram, or a README, sanitized | `[grounded]` your statement's silence on sources |
| G3 | Data contracts (R10, important) | discovery | A dbt project and tests, with nothing stated about who relied on them or how | The JD names analysts depending on contracts. If your dbt tests or documented models served that purpose, it is a stronger match than the map currently shows | Tests or documented schemas an analyst team depended on; agreeing model changes with downstream users; versioned or deprecated models | A sanitized schema doc, a model YAML, or a change-notice example | `[grounded]` your statement's silence on downstream users |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Stated pay sits at the market median to above the upper quartile | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range is realistic for the title: the floor is $3,000 below the $151,000 median and the ceiling is $2,500 above the $163,500 upper quartile | `[grounded]` JD range and the Datawright report's figures; `[generic]` that the report covers Series B–D companies, and Pellucid is Series C | Where in this range would a candidate with my background land? | noted |
| RR2 | Posting live and consistent with the company's own pages | positive_signal | — | "Accepting applications. Senior Data Engineer — Pellucid Learning." | The employer exists as described and is hiring. The $52M and 264-employee figures are first-party only | `[grounded]` careers page fetched, About page returned by search | Is the funding round announced anywhere other than your own site? | noted |
| RR3 | Team, authority and scope unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | The role may be a sole data engineer covering ingestion, modelling and contracts, which is broader than the report's one-domain scope norm | `[inferred]` from the three-part mandate and silence on team size; `[generic]` for the report's scope norm | How many data engineers and analysts are there today, and who owns ingestion, the warehouse and the contracts? | unresolved |
| RR4 | Hiring manager not named | unknown | — | none (the posting names no one) | The reporting line and the seniority of the person you'd work for are unknown | `[grounded]` posting names no hiring manager | Who would I report to, and who would be on my interview loop? | unresolved |
| RR5 | Equity terms unstated | unknown | — | "plus equity" | The grant size, vesting and strike price are unknown, so the equity's value can't be compared with the base | `[grounded]` JD gives no equity figures | What is the grant range for this level, how does it vest, and what is the latest 409A or strike price? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Resume line: "Built our dbt project on Snowflake, about 180 models" | R5. Traces to your sentence "Built our dbt project on Snowflake — about 180 models" | `[grounded]` your statement | `resume_edits_pending_approval` |
| E2 | Resume line: "Set up our Great Expectations test suite" | R8. Traces to your sentence "I set up our Great Expectations test suite" | `[grounded]` your statement | `resume_edits_pending_approval` |
| E3 | Positioning advice: name Snowflake as the warehouse you have used and say plainly that BigQuery is new to you. Do not claim BigQuery experience | R6 and G1: the honest bridge reads stronger in interview than a stretch | `[grounded]` you have never used BigQuery | pending your approval |
| E4 | Ask the recruiter for the hiring manager's name, so a public-footprint check can inform the positioning | RR4; target 3 is `n/a` until a name exists | `[grounded]` RR4 | pending your approval |
| Q1 | Ask RR3, RR4 and RR5's questions verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. The CV-level claims in R3, R4, R5, R7 and R8 are your own statements and stay leads until you provide an inspectable artifact.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer) and searched "Pellucid Learning Series C $52M tutoring Denver", which returned "About Pellucid Learning" (pellucidlearning.com/about). Both calls checked your pasted text. They confirm the posting is live and matches your paste. The company facts only appear on its own page. Moved: role reality's contradictions row, RR2 |
| 2. Role-family sweep | skipped | The pay report you pasted already fixes the market calibration line and the pay check in RR1 |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there is no query to form |

I can also offer a dossier of this assessment as `tuesday-dossier.md`, if you'd like to keep it.

## Upgrade menu

- Your location and pay floor → R1 and R2 resolve to `direct` or `hard_gate_fail`.
- Answers to G2 and G3 → R9 and R10 move from `unclear` toward `direct`.
- A sanitized dbt model list, test suite config or pipeline README → R4, R5 and R8 can reach `high`.
- Any BigQuery exposure → G1's bridge narrows.
- The hiring manager's name → the scope read, and which of your stories to lead with for that reader.
- A deeper research pass on Pellucid Learning: funding and leadership churn, hiring patterns, and recent news (up to 5 more searches and 2 more fetches). Say the word and it runs.

## Questions

1. R1/R2 — What are your non-negotiables on location and base pay, if you have any?
2. G2 — Have you built or owned pipelines that pulled data from an application database or a CRM into the warehouse, and what exactly did you own?
3. G3 — Did your dbt tests or models serve as an agreed interface for analysts, and who relied on them?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.