I'll read the reference files the skill names before building the assessment.
**Yes, apply, once Brindlemoor checks out: `conditional_go`.** The fit is strong, and the unknowns are about the employer and the terms, not about you. I couldn't run any research, so the employer, the posting and the pay are all unchecked (see Evidence status).

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote, UK-based)
- `must_have` — direct: R2, R3, R4, R5a, R6, R7 · unclear: R5b (Monitor rating models)
- `important` — unclear: R8 (Recommendations to product)
- `preferred` — direct: R9 · adjacent: R10 (Pet-insurance domain)

R1 — your residence isn't stated; R5b — "maintained" isn't the same as stated monitoring; R8 — product stakeholders never appear in your background; R10 — a credible bridge, its limit named.

**Opportunity ledger.** The role is unverified, not troubled. The employer is not yet established (RR1), pay is withheld (RR2), and team shape and success measures are unstated (RR3, RR4). The JD's concrete duties and its fully remote UK terms run the other way (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK-based); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Brindlemoor and the live posting verify (RR1); (2) pay is disclosed and meets a floor you haven't given me (RR2); (3) you confirm R1.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD header; not checked against any outside source |
| Title and mandate | Senior Pricing Analyst: own pricing analytics for the pet-insurance product, build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reports to | Odile Varga, Director of Pricing | `[grounded]` your message |
| Working pattern | Fully remote (UK) | `[grounded]` JD |
| Scope read | A hands-on senior individual-contributor seat on one product. The JD lists no line management and no direct reports | `[inferred]` from the JD's duty list and its silence on reports |
| Market calibration | Not calibrated: the role-family sweep did not run, so there is no band for this title and no pay figure to compare. Four-plus years with a senior title is a conventional pairing for the family | `[generic]` role-family pattern, no search behind it |
| First-90-days and first-year outcomes | Not stated in the JD | `[grounded]` JD silence |
| Unknowns | Pay; team size and tooling; contract basis; success measures; how much of the pricing sits with this seat versus the Director | `[grounded]` JD silence on each |
| Contradictions | None between the JD and your background; no cross-check against Brindlemoor's own pages was possible | `[grounded]` JD read against your message |

## Evidence map

Your background was typed into the conversation. It has the standing of a CV: leads to verify, not proof, so nothing here is above `medium`.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK-based | hard_gate | unclear | low | hard_gate | You haven't stated where you live or work from. Your five years are at a UK motor insurer, which points to the UK but doesn't settle it. Confidence is `low` because nothing has been confirmed; the fit stays `unclear` until you answer | `[grounded]` JD term; `[inferred]` UK residence from a UK employer | G1: confirm you are UK-based |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | "5 years pricing analytics at a UK motor insurer, the last 2 as senior analyst" against 4+. This is a length-of-experience requirement, so it is graded as a requirement, not a gate. Self-reported, nothing inspected | `[grounded]` your stated background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily" is specific on frequency but says nothing of what you built | `[grounded]` your stated background | none; a sanitized query or notebook sample would raise it to `high` |
| R4 | GLM experience | must_have | direct | medium | none | You "built and maintained the GLM rating model for our young-driver book", a direct match, with no inspectable artifact yet | `[grounded]` your stated background | none; sanitized model documentation (factor tables, lift charts) would raise it to `high` |
| R5a | Build rating models | must_have | direct | medium | none | Same evidence as R4: you built a rating model. Scope is one book (young-driver), carried into any wording | `[grounded]` your stated background | none |
| R5b | Monitor rating models | must_have | unclear | low | discovery | You said "maintained", not monitoring. Claiming drift or performance monitoring would add a practice you haven't stated | `[grounded]` your wording; `[inferred]` that maintenance may include monitoring | G2 |
| R6 | Design and read price tests | must_have | direct | medium | discovery | You "ran 14 price tests last year with the underwriting team". "Ran" doesn't say whether you designed them, sized them or only read them, so the claim stays at "ran" until you say more | `[grounded]` your stated background | G3 |
| R7 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You "present the quarterly pricing review to the head of underwriting". The JD says "underwriting or actuarial", so the underwriting side matches | `[grounded]` your stated background and JD wording | none |
| R8 | Turning results into recommendations for underwriting and product | important | unclear | low | discovery | Underwriting is covered by R6 and R7. Product stakeholders appear nowhere in your background | `[grounded]` background silence on product | G4 |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your stated background | none |
| R10 | Pet-insurance domain knowledge (not in the JD; implied by the product the role owns) | preferred | adjacent | medium | transferability | Rating-model and test work carry over from motor. The limit is that you have exercised none of pet's own rating drivers. Pet pricing commonly turns on factors such as breed, age and pre-existing conditions, which motor does not use | `[inferred]` bridge from your motor work to the product named in the JD; `[generic]` on pet's rating drivers | G5 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | UK-based, fully remote (R1) | hard_gate | UK employer, but no stated location | The one gate the JD sets; a term you meet or don't, which no wording changes | Not experience-based | None needed | `[grounded]` JD term; `[inferred]` from employer location |
| G2 | Monitoring of rating models (R5b) | discovery | "Maintained" the GLM model; nothing on tracking performance or drift | A `must_have` row at `unclear`; it names half of the first duty in the JD | Scheduled actual-versus-expected checks; a lift or stability review after a rate change; refitting when performance slipped; a monitoring pack someone else reviewed | A monitoring pack, a dashboard screenshot, or a refit note, sanitized | `[grounded]` your wording; `[generic]` that monitoring is routine duty for rating-model owners |
| G3 | Ownership of test design (R6) | discovery | 14 tests "ran"; design versus analysis not separated | "Design and read price tests" is a named duty, so which half was yours decides the line | Choosing control and test splits; sizing a test; agreeing success criteria with underwriting; writing the readout | A sanitized test readout or design note | `[grounded]` your wording; `[inferred]` that design ownership will be probed from the JD's "design" |
| G4 | Recommendations to product (R8) | discovery | Underwriting audience shown; product not | The JD names product as a second audience | A pricing change you took to a product owner; a proposal that altered a feature or cover level | A recommendation deck or memo, sanitized | `[grounded]` background silence on product |
| G5 | Pet-insurance domain (R10) | transferability | Motor rating and testing experience | Closes the most visible objection to your application | Frequency and severity modelling; claims inflation work; any rating factor with a long-tail claims pattern | A short sanitized note comparing the two books' rating factors | `[inferred]` bridge from your motor work; `[generic]` that pet rates differ from motor |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | It may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not be a real hiring employer. Obscurity alone is not a red flag | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who I would be interviewing with? | unresolved |
| RR2 | Pay withheld | unknown | — | JD states no compensation | The posting may simply not publish pay, or the figure may sit below what a senior role pays. There is no calibration to say which | `[inferred]` from the JD's silence | What salary range is budgeted for this post? | unresolved |
| RR3 | Team shape and decision rights unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | "Own" may be full ownership or recommendation-only beside a Director who sets the price | `[inferred]` from the JD's wording against its silence on authority | Which pricing decisions does this role make, and which go to the Director? | unresolved |
| RR4 | No stated success measures | unknown | — | JD lists duties, no outcomes | Accountability may be loosely defined for a seat that owns a whole product's pricing analytics | `[inferred]` from the JD listing duties with no outcomes | What would success look like at six and twelve months? | unresolved |
| RR5 | Concrete duties and clear working terms | positive_signal | — | "build and monitor rating models, design and read price tests" | The duties are specific and consistent with a functioning pricing team; remote UK is stated plainly | `[grounded]` JD wording | Who owns the current rating model and test pipeline? | noted |

## Application plan

Everything here is proposed. The table and the notes beneath it are each pending your approval, and nothing is final until you approve it.

`resume_edits_pending_approval` — each line below is in your own words, repositioned and not extended. If your CV doesn't already lead with them, move them to the top:

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | "Built and maintained the GLM rating model for our young-driver book" | see R4, R5a | `[grounded]` your own sentence | pending your approval |
| E2 | "Ran 14 price tests last year with the underwriting team" | see R6; the number stays on the tests | `[grounded]` your own sentence | pending your approval |
| E3 | "Present the quarterly pricing review to the head of underwriting" | see R7 | `[grounded]` your own sentence | pending your approval |
| P1 | In any cover note or intro, state plainly that your background is motor pricing and you haven't worked on pet insurance | see R10; claiming pet knowledge would be untraceable to what you told me | `[grounded]` your stated gap | pending your approval |
| A1 | Confirm the role is live on Brindlemoor's own careers page, and the recruiter's email domain if one writes to you, before investing in the application | see RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask the questions of RR1, RR2, RR3 and RR4 verbatim at the first screen | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Your background is intake prose of CV standing; no inspectable artifact has been supplied. Unverified leads: none from memory.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were refused: "Brindlemoor pet insurance insurtech" and "Brindlemoor careers Senior Pricing Analyst". It would have settled RR1 and the contradictions row |
| 2. Role-family sweep | unavailable | One search was refused: "senior pricing analyst pet insurance UK salary remote". It would have supplied the market calibration and a pay band against RR2 |
| 3. Hiring manager's public footprint | unavailable | A name was given, so one search was sent and refused: "Odile Varga Director of Pricing". It would have informed the scope read and which story to lead with |

## Dossier offer

I can write all of this up as `tuesday-dossier.md` if you'd like a file to keep.

## Upgrade menu

- Enabling web search → the three target rows above run, which could clear RR1, fill the market calibration and settle RR2. A deeper L2 pass is also available afterwards (up to 5 more searches and 2 more fetches).
- Your location and pay floor → R1 resolves and RR2 gets a hard comparison.
- Sanitized GLM model documentation (factor tables, lift charts) → R4 and R5a to `high`.
- A sanitized price-test readout or design note → R6 to `high`.
- A monitoring pack or refit note → R5b resolves.
- A recommendation memo that went to a product owner → R8 resolves.
- Your actual CV → the E-rows are checked against its real wording instead of your summary.

## Questions

G1 — Are you UK-based, and would you be working from the UK?
G2 — Did you track the young-driver GLM's performance after it went live (actual versus expected, drift, refits), and what did you do when it slipped?
G3 — On the 14 price tests, which parts were yours: choosing the test and control split, sizing, setting success criteria, or analysing the readout?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.