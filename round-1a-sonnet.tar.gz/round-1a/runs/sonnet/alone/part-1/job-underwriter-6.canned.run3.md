I've read the posting and the skill's reference files. Next I'll run the research the skill budgets for: the company, the role-family pay band, and the hiring manager's public footprint.
# Should you go for the Revenue Operations Lead role at Quillfield?

## Decision snapshot

**Yes, Joss, apply, but as a stretch with two named gaps, not a clean match. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol hybrid, two days a week in the office), R2 (Salary £61,500–£67,000)
- `must_have`: direct: R3, R4 · adjacent: R5 (SQL and spreadsheet modelling), R6 (Experience owning a forecast) · unclear: R7b (Working with finance on revenue data) · absent: R7a (Billing data experience)
- `important`: direct: R8 · adjacent: R9 (Running the quarterly forecast with the CFO)

R6 — a credible bridge, its limit named; R7a — a stated gap with no evidence behind it; R1, R2 — terms not yet checked against you.

**Opportunity ledger.** The role looks sound and transparent: the pay is stated and sits inside the survey band (RR3), and the company matches the posting (RR4). Two things are unverified: who is accountable for the forecast (RR1) and how much billing data you would own (RR2).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two days a week in the office), R2 (Salary £61,500–£67,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. Bristol with two office days and the stated pay both work for you (R1, R2).
  2. The forecast accountability (RR1) and billing-data scope (RR2) turn out to leave room to learn, rather than requiring day-one experience.
  3. R6 and R7a are framed honestly as adjacent and absent, never as owned experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants, founded 2018 in Bristol, 96 employees, Series A (£11M) closed April 2025 | `[grounded]` About Quillfield page (search result) |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting for sales and finance; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern and pay | Bristol, hybrid, two office days a week; £61,500–£67,000 plus share options | `[grounded]` posting |
| First-year outcomes | Not stated in the posting | `[grounded]` posting silent |
| Hiring manager | Tamsin Achebe is listed as Head of Revenue Operations at Quillfield, previously a sales operations manager at Corvane Payments. This matches what your recruiter said. I read only the search snippet, not the full profile | `[grounded]` search result snippet |
| Scope read | The role bundles CRM, billing data, reporting and the forecast. That is wide, but it fits one lead role at a company this size. A Head of RevOps already exists, so the "Lead" title probably sits beneath her | `[inferred]` from the posting's four duties and the manager's listed title |
| Market calibration | The Ledgerline 2026 UK survey puts revenue operations leads in B2B software at a median base of £64,200 (n=438; interquartile range £57,800–£70,400). The posted range sits within it. The survey is UK-wide, not Bristol-specific, and is not Quillfield's offer | `[generic]` role-family sweep, one search; `[grounded]` posting for the range |
| Unknowns | Who is accountable for the forecast number; what "billing data" covers; the share option terms; the reporting line | — |
| Contradictions | None found between the posting and the company's About page | `[grounded]` both read |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two office days a week | hard_gate | unclear | none | hard_gate | The posting states the term. You haven't told me your location or office constraints, so I can't say whether it's met | `[grounded]` posting; no constraint given | Question 1 |
| R2 | Salary £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | The posting states the pay. Your floor isn't given, so I can't check it | `[grounded]` posting; no constraint given | Question 1 |
| R3 | 4+ years in RevOps, sales ops or analytics at a B2B software company | must_have | direct | medium | none | Five years in sales operations, two of them running RevOps for the UK team. Caveat: you describe the employer as a B2B payments company, and the posting says B2B software. Expect a probe on whether it counts as software | `[grounded]` your account; `[generic]` that titled-years requirements are often screened literally | none |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified. The certificate is stated but I haven't inspected it | `[grounded]` your account | Offer: the certificate would raise this to `high` |
| R5 | Strong SQL and spreadsheet modelling | must_have | adjacent | medium | discovery | SQL weekly and Excel daily show use. They don't show whether you've built models such as forecasts or what-if scenarios | `[grounded]` your account; `[inferred]` that "modelling" implies more than daily use | G4 |
| R6 | Experience owning a forecast | must_have | adjacent | medium | transferability | You've never owned the company forecast, because finance did. The adjacent evidence is the monthly pipeline review with your sales director and the pipeline dashboards you rebuilt. The limit is that you haven't built the number or answered for it | `[grounded]` your account | G1; Question 2 |
| R7a | Experience working with billing data | must_have | absent | none | capability | You've never worked on billing data, and I found no adjacent evidence. This is a plain gap. A closure path is in G2 | `[grounded]` your account | G2 |
| R7b | Working with finance on revenue data | must_have | unclear | low | discovery | Your renewal dashboards touch revenue. Your CV and account don't say whether you reconciled them with finance's figures. I haven't seen how you worked with finance | `[grounded]` your account; `[inferred]` that renewals imply some finance contact | G3; Question 2 |
| R8 | Build pipeline and renewal reporting for sales and finance | important | direct | medium | presentation | You rebuilt both dashboards. Whether finance was a user isn't stated, so say who used them | `[grounded]` your account | E1 |
| R9 | Run the quarterly forecast with the CFO | important | adjacent | medium | transferability | You run a monthly review with a sales director. Nothing shows CFO-level or quarterly-forecast exposure | `[grounded]` your account | G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast ownership and CFO-facing work (R6, R9) | transferability | Monthly pipeline review with your sales director; finance owned the forecast | A must-have at `adjacent`. A stronger bridge narrows the likeliest objection | Feeding pipeline numbers into the finance forecast; explaining a forecast miss; building a coverage or conversion assumption finance used | A sanitized pipeline-to-forecast bridge, or a review pack excerpt | `[inferred]` bridge from your account; `[generic]` that forecast ownership is the likeliest objection |
| G2 | Billing data (R7a) | capability | No evidence of billing data work | A must-have with nothing behind it. It is carried as a material risk | Closure path: a self-built worked example reconciling renewals to invoiced amounts using public or invented data, and learning the vocabulary of invoicing and subscription billing. It's a bridge you build, not an experience you claim | A small SQL example you could discuss, clearly labelled as practice | `[grounded]` your account; `[generic]` on the closure path |
| G3 | Finance collaboration on revenue data (R7b) | discovery | Renewal dashboards; no stated finance contact | Could move R7b from `unclear` to `adjacent` or `direct` | Reconciling renewal figures with finance; agreeing ARR or renewal definitions; supporting a month-end or board pack | A definitions doc, a reconciliation sheet, an email thread (sanitized) | `[grounded]` silence in your account |
| G4 | SQL and spreadsheet modelling (R5) | discovery | Frequency of use, not depth | Posting says "strong" | A forecast or scenario model; a cohort or churn query; a model other people used | A sanitized model or query | `[grounded]` your account |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Forecast accountability beside a Head of RevOps | unknown | — | "run the quarterly revenue forecast with the CFO" | The role may own the forecast process, or may support a forecast the Head and CFO own | `[inferred]` from the posting against the manager's listed Head title | Who is accountable for the forecast number, and where does this role report? | unresolved |
| RR2 | Billing data scope unclear | unknown | — | "own our CRM and billing data" | "Billing data" could mean the company's own subscription billing, or data from its customers' invoicing product, and ownership could mean building pipelines or just reporting | `[inferred]` from the posting's wording and the company's invoicing product | Which billing systems and data does this role own, and who owns them today? | unresolved |
| RR3 | Pay stated and within band | positive_signal | — | "£61,500–£67,000 plus share options" | The range is transparent and inside the survey's interquartile range, so pay is unlikely to be a mismatch | `[grounded]` posting; `[generic]` survey band | What are the option terms: grant size, vesting, strike? | noted |
| RR4 | Company matches the posting | positive_signal | — | "Quillfield, the invoicing software company" | The employer exists as described, with recent funding and a mid-size team | `[grounded]` About page | What does the revenue and finance team look like today, and who else would I work with? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Reposition the pipeline and renewal dashboards as revenue reporting and say who used them, without implying finance was a user unless true | R8, R7b | `[grounded]` your account | pending your approval |
| E2 | Describe the forecast work as "contributed pipeline inputs and ran the monthly review", never as owning the forecast. Do not claim billing data experience | R6, R7a: your own account sets these limits | `[grounded]` your account | pending your approval |
| W1 | Optional: a small, clearly labelled practice example reconciling renewals to invoices in SQL | G2, R7a | `[grounded]` G2 | pending your approval |
| A1 | Check Bristol, two office days and pay with the recruiter before investing in the process | R1, R2 | `[grounded]` posting | pending your approval |
| Q1 | Ask RR1 to RR4's verification questions in the first conversation with Tamsin | The register doubles as interview prep | `[grounded]` register | pending your approval |
| A2 | Lead with the sales-ops and pipeline-reporting story. The hiring manager's listed background is sales operations, so it's a reader your strongest evidence fits | R3, R8 | `[grounded]` search snippet | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company Bristol careers"; result "About Quillfield" (quillfield.co.uk/about). The company exists as described (stage, size, product) and nothing contradicts the posting. I did not fetch Quillfield's own careers page, so the posting is confirmed only on the job board you linked |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary Bristol UK B2B software"; result "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). It fed the market calibration row and RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield"; result "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe), snippet only. It confirmed the recruiter's attribution, fed the scope read and RR1, and informed plan row A2 |

I can write all of this into a `tuesday-dossier.md` file if you want to keep or reuse it.

## Upgrade menu

- Your location and pay floor → R1 and R2 move from `unclear` to met or failed.
- A sanitized pipeline review pack or forecast input → G1, R6 and R9 firm up.
- A sanitized finance reconciliation, definitions doc or email thread → G3, R7b firms up.
- A sample model or query → G4, R5 can reach `high`.
- Your Salesforce certificate → R4 rises to `high`.
- Quillfield's own careers page link → confirms the posting is live on their site.
- A deeper research pass on Quillfield (funding and leadership changes, hiring patterns, candidate and employee reports, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

1. R1, R2 — Does Bristol with two office days a week, at £61,500–£67,000, work for you?
2. G1, G3 — When you've worked with finance on pipeline and renewals, what did you feed into or check against their forecast and revenue figures, and who signed off the numbers?
3. G4 — Have you built a model in Excel or SQL, such as a forecast, scenario or cohort analysis, that other people relied on?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.