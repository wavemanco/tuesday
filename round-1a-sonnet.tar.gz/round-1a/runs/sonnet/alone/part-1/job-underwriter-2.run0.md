I'll read the reference files the skill requires before building the assessment.
I've finished reading the skill's rules and am now running the L1 research: one check on whether Quartzline exists as described, and one on market norms for this role.
**Not a waste of time, but a reach: R1a (3+ years PM experience, titled) is `absent`, and R1b and R2 are `adjacent`, not `direct`. Status: `conditional_go`.**

I couldn't run any web research because the search permission was refused. Nothing below about Quartzline or the market comes from outside your JD and resume.

**Fit ledger.**

- `must_have` — direct: R3 · adjacent: R1b (PM work in practice), R2 (Shipped API or platform products) · absent: R1a (3+ years PM experience, titled)
- `important` — direct: R8 · adjacent: R4 (Sales alongside engineering and customers), R7 (Roadmap ownership, specs, squad delivery), R9 (Launches with sales and support) · unclear: R5 (Agile delivery), R6 (Adoption metrics)

R1a — a title gap no rewording closes; R1b, R2 — credible bridges, limits named; R5, R6 — resume silent, one answer could move them.

**Opportunity ledger.** The employer is unverified (RR1) and compensation is unstated (RR2). Scope reads concrete (RR3), and authority and reporting line are unknown (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify on Quartzline's own careers page (RR1); (2) a recruiter or hiring contact signals that equivalent PM work can count toward "3+ years" (R1a); (3) your answer to G1 shows you owned something product-like (R2, R6).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, ~150 people, Series B | `[grounded]` JD header; existence not externally checked |
| Mandate | Own the roadmap for the partner-facing API platform, run partner discovery, write specs, drive delivery with two engineering squads, define adoption metrics, coordinate launches with sales and support | `[grounded]` JD |
| Scope read | Concrete mandate with named delivery capacity (two squads) and a named success theme (adoption) | `[inferred]` from the JD's responsibility list |
| First-90-days outcomes | Likely: learn the current roadmap, start discovery with integration partners, set adoption metrics. The JD states none | `[inferred]` from the responsibility list; no outcomes stated |
| Market calibration | Not established, because the role-family sweep did not run. No band is offered | `[grounded]` search refused |
| Compensation | None in the pasted JD | `[grounded]` JD silence |
| Contradictions | None inside the JD; JD against careers page not checked | `[grounded]` JD; check unavailable |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years product management experience, held as a PM role | must_have | absent | none | capability | You state you have never held a PM title, so titled years are zero. Roles listing years of PM experience as must-have are often screened on title literally; that is a risk, not a gate | `[grounded]` your statement; `[generic]` screening pattern | A1; closure path in A4 |
| R1b | PM work in practice, the substance behind the years | must_have | adjacent | medium | transferability | Requirements documents, scoping workshops, quarterly roadmap-input sessions and coordination with PMs on custom builds are PM-shaped work. Limit: you fed the roadmap, and nothing says you owned prioritization. Medium: self-reported, nothing inspected | `[grounded]` resume | G2 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ end-to-end integrations of your employer's REST APIs and wrote the internal integration playbook. Limit: that is adoption and implementation of an API product, with no stated ownership of its design, roadmap or release | `[grounded]` resume | G1 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI specs and integration architecture across 30+ projects. Medium: no artifact inspected yet; a sanitized playbook excerpt would raise it | `[grounded]` resume | Offer to share a sanitized playbook excerpt |
| R4 | Stakeholder management across engineering, sales, customers | important | adjacent | medium | discovery | Own and client engineers, client stakeholders and PMs are stated. Sales is not mentioned | `[grounded]` resume, silent on sales | G3 |
| R5 | Agile delivery | important | unclear | low | discovery | The resume describes UAT and go-live but no sprints or squad ceremonies | `[grounded]` resume silence | G4 |
| R6 | Define and track adoption metrics | important | unclear | low | discovery | The resume is silent on metrics. An unconfirmed lead from prior conversation (a support-adopted tool) could bear on this; it is a question prompt only | `[grounded]` resume silence; `[grounded]` memory lead, unconfirmed | G1 |
| R7 | Own roadmap, write specs, drive delivery with two squads | important | adjacent | medium | transferability | Requirements documents and engineer coordination carry over. Limit: coordinating builds for clients differs from owning prioritization and squad capacity | `[grounded]` resume | G2 |
| R8 | Run discovery with integration partners | important | direct | medium | presentation | Scoping workshops and quarterly client feedback sessions are partner discovery in substance. The resume frames them as implementation | `[grounded]` resume | E1 |
| R9 | Coordinate launches with sales and support | important | adjacent | medium | transferability | You ran client go-lives. Limit: those are client launches, not product launches with sales and support | `[grounded]` resume | E2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Shipped products and adoption metrics (R2, R6) | discovery | Integration work is clear. A prior-conversation note suggests an internal request-triage tool that support agents adopted; nothing about it is confirmed | R2 is a `must_have` row at `adjacent`; a confirmed owned tool would be the closest thing to a shipped product on the resume | A tool or workflow others adopted; deciding what it did; tracking whether people used it; a pilot or rollout you ran | A short write-up, screenshots, usage numbers, or a sanitized spec | `[grounded]` resume silence; `[grounded]` memory lead, unconfirmed |
| G2 | Prioritization ownership (R1b, R7) | discovery | Roadmap input and requirements are stated; who decided what was built is not | The PM-versus-input-giver line decides how R1b and R7 read | Deciding scope on a custom build; saying no to a client request; choosing between client asks for a release | A requirements document with your decisions, or a scope-change record | `[grounded]` resume; `[generic]` that PM interviews probe this line |
| G3 | Working with sales (R4) | discovery | Engineers, clients and PMs are stated; sales is not | Sales coordination is a named responsibility | Joint calls with account executives; scoping input to deals; handoffs from sales | A handoff template or deal-scoping note | `[grounded]` resume silence |
| G4 | Agile delivery (R5) | discovery | No sprint or squad evidence | Listed requirement, lower weight | Sprint planning with engineers; backlog refinement; release trains | A sprint board export | `[grounded]` resume silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or the entity may not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your careers site, and who would I be interviewing with? | unresolved |
| RR2 | Compensation not stated | unknown | — | No compensation figure in the pasted JD | The posting may withhold pay, or the paste may omit it. A band was not established because research did not run | `[grounded]` JD silence | What salary range is budgeted for this role? | unresolved |
| RR3 | Concrete scope and capacity | positive_signal | — | "drive delivery with two engineering squads; define and track adoption metrics" | The role has a defined mandate, named delivery capacity and a measurable success theme | `[grounded]` JD states them | What does success look like at six and twelve months? | noted |
| RR4 | Authority and reporting line unstated | unknown | — | "Own the roadmap for our partner-facing API platform" | Ownership is claimed, but decision rights over prioritization and squad capacity are unstated | `[inferred]` from the JD's silence on reporting and decision rights | Who does this role report to, and who decides when sales and engineering priorities conflict? | unresolved |

## Application plan

Everything in this table and the advice in the sections around it is proposed and pending your approval. Nothing is final until you say so.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Move the roadmap-input sessions and the scoping workshops to the top of your resume, in your own words, with no PM title or "product management" label, e.g. "Ran quarterly roadmap-input sessions collecting client feedback for product" and "Led scoping workshops and requirements documents for 30+ client REST API integrations through UAT and go-live" | See R8, R1b | `[grounded]` resume wording | pending your approval |
| E2 | Draft a cover note that names the missing PM title up front, then gives the bridge: integration work, partner discovery, roadmap input. State each limit (input, not ownership) | See R1a, R2, R9 | `[grounded]` map rows | pending your approval |
| A1 | Ask the recruiter or hiring contact whether "3+ years" is read as titled years or as equivalent work, before investing in a full application | See R1a | `[grounded]` R1a | pending your approval |
| A2 | Verify the employer and the live posting on Quartzline's own careers site before applying | See RR1 | `[grounded]` RR1 | pending your approval |
| A3 | Seek a warm introduction to the hiring manager; referrals often bypass keyword screens | How hiring commonly works, not a fact about this employer | `[generic]` role-family pattern | pending your approval |
| A4 | Run a parallel track for roles that screen on substance, such as technical or platform PM titles, or an internal move to PM at your current employer, where you already work beside PMs | R1a cannot be closed by wording | `[generic]` common pivot routes | pending your approval |
| Q1 | Ask RR2, RR3 and RR4 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: an internal request-triage tool that support agents adopted, from prior conversation and unconfirmed. Rejected inferences: none.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Quartzline logistics technology partner API platform company" and "Quartzline careers Product Manager Platform APIs"; both refused. Would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | Searched "Product Manager platform API role requirements salary Series B B2B SaaS 2026 internal transition from solutions engineer"; refused. Would have moved the market calibration row and RR2's band |
| 3. Hiring manager's public footprint | n/a | No name was given, so no query could be formed |

Beyond the spec: I can also build a one-page bridge map, from your 30+ integrations to each JD responsibility with the limit stated, if you approve. This engagement earns it because R2, R7 and R9 all turn on the same bridge.

If you want the dossier file for this assessment, I can write `tuesday-dossier.md`.

**Upgrade menu**
- Permission for the L1 searches → RR1, role reality and the market band in RR2 resolve.
- Your answer to G1, plus a spec, screenshots or usage numbers → R2 and R6 can move, and R2 may reach `medium` with a confirmed claim or `high` with an artifact.
- A sanitized playbook excerpt → R3 can reach `high`.
- The hiring manager's name → the scope read and which of your stories to lead with.
- The recruiter's answer on A1 → decides whether R1a is a screen or a conversation.

**Questions**
1. G1 — Did you build or own the request-triage tool (or anything like it)? What did it do, who used it, and how did you know it worked?
2. G2 — On a custom build, have you decided what went into scope or been the person who said no to a client request? Give one example and what was yours.
3. Constraints — What is your pay floor, your location or remote requirement, and would you accept a lower title (Associate, Technical PM or Product Owner) to get the first PM role?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.