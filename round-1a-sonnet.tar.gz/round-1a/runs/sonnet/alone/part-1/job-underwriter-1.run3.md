I've read the underwriting rules and am now loading the search tool to check that Harborlight Health exists as described and to calibrate the role's market norms.
**Yes, apply. You're a fit on the stated requirements: R1, R2, R3, R4 and R5 are direct matches, and R6 is the one open must-have. Status: `conditional_go`.**

# Job Underwriting Assessment: Senior Product Analyst, Harborlight Health

## Decision snapshot

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R5 · unclear: R6 (Define and maintain the metrics layer)
- `important` — adjacent: R7 (Partner with product managers on roadmap decisions) · unclear: R8 (Partner with clinicians), R9 (Mentor two junior analysts)
- `preferred` — adjacent: R10 (Healthcare data experience, HIPAA)

R6 — your Looker and warehouse work sits next to it but never says who owned metric definitions; R8 and R9 — nothing offered either way yet; R10 (`medium`) — a real bridge, its limit named in the map.

**Opportunity ledger.** The duties are concrete, but the terms are thin. The pasted JD gives no pay or location (RR2, RR3), and the state of the metrics layer you'd inherit is unknown (RR4). The employer could not be checked from here (RR1), because the web searches were refused. One entry runs the other way: the duties and stakeholders are named specifically (RR6).

- **Hard gates:** none stated in the JD; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) Harborlight and this live posting verify on its own careers page (RR1); (2) pay and location, once known, clear your constraints (RR2, RR3); (3) you confirm you owned metric definitions, not only dashboards (R6, G1); (4) the healthcare gap is framed as adjacent, never as HIPAA experience (R10)

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, about 400 people, Series C, care-navigation app. Stated in the JD header and not verified | `[grounded]` JD header, unverified |
| Mandate | Own product analytics for the app: metrics layer, A/B tests, self-serve Looker dashboards, partnering with PMs and clinicians, mentoring two junior analysts | `[grounded]` JD |
| Stated requirements | 5+ years product analytics, expert SQL, experiment design at scale, Looker or similar, written communication with non-technical stakeholders; HIPAA healthcare data a plus | `[grounded]` JD |
| Hard gates | None stated: no location, pay, authorization or schedule terms in the pasted text | `[grounded]` JD silence |
| First-year outcomes | Not stated, and none can be derived carefully from the duty list | `[grounded]` JD silence |
| Scope read | Broad for one seat: metrics layer, experimentation, BI, stakeholder partnership and people mentoring together. Postings like this often combine duties that larger teams split between analytics engineering and product analytics | `[inferred]` from the count of distinct duties; `[generic]` for the team-split pattern |
| Compensation | Not in the pasted JD. No market band established | `[grounded]` JD silence |
| Unknowns | Pay, location or remote terms, current state of the metrics layer, whether the two juniors exist yet and the reporting line, how clinicians are accessed | — |
| Contradictions | None between the JD and your background. Employer-side consistency could not be checked | `[grounded]` inputs |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | You state 6 years of product analytics. Years of experience is graded as fit, not as a gate. No CV or reference was inspected, so `medium` | `[grounded]` your stated background | none |
| R2 | Expert SQL | must_have | direct | medium | none | "SQL daily on a Snowflake warehouse" across six years. "Expert" is a level others grade, so expect a live SQL screen | `[grounded]` your stated background; `[generic]` that a SQL screen is likely | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | You designed and ran the program: 30+ A/B tests a year on about 2M subscribers, including the pricing test behind an 11% retention lift. Expect probes on methodology | `[grounded]` your stated background | offer: a sanitized experiment write-up would raise this to `high` |
| R4 | Looker or similar BI tool | must_have | direct | medium | none | You built the Looker instance from scratch, with 40+ governed dashboards. The JD says "self-serve"; whether stakeholders self-served is not stated | `[grounded]` your stated background | an inspectable artifact (screenshot, sanitized model) would raise this to `high` |
| R5 | Written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads, and present to the VP Product monthly | `[grounded]` your stated background | offer: a sanitized memo would raise this to `high` |
| R6 | Define and maintain the metrics layer | must_have | unclear | low | discovery | "Governed dashboards" and a warehouse consent-state model are nearby, but you did not say you defined or owned metric definitions. Not claimed until you confirm | `[grounded]` the evidence listed; `[inferred]` that it may exist | see G1 |
| R7 | Partner with product managers to turn analysis into roadmap decisions | important | adjacent | medium | discovery | You run tests for a product org and present monthly to the VP Product. That the analysis drove specific roadmap decisions is not stated beyond the pricing test's retention result | `[grounded]` your stated background | see G2 |
| R8 | Partner with clinicians | important | unclear | none | discovery | Nothing offered about clinical or other domain-expert stakeholders | `[grounded]` silence in your background | see G3 |
| R9 | Mentor two junior analysts | important | unclear | none | discovery | Mentoring or managing analysts is not mentioned | `[grounded]` silence in your background | see G4 |
| R10 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | GDPR/CCPA consumer PII handling and the warehouse consent-state model are credible privacy-governance work. Limit: no health data, no HIPAA, no clinical data standards. Name that limit wherever the bridge is used | `[inferred]` adjacency from your stated work | see G5 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer ownership (R6, must_have) | discovery | A built Looker instance, governed dashboards, a warehouse consent-state model; nothing on who defined metrics | It is a `must_have` row at `unclear`, and the JD lists it first among duties | Writing the shared definitions (retention, churn, activation), a Looker modeling layer, a metric dictionary, an arbitration process for definitions | A sanitized metric dictionary or modeling-layer screenshot | `[grounded]` your stated work; `[inferred]` that evidence may exist |
| G2 | Analysis to roadmap decisions (R7, important) | discovery | The pricing test and monthly VP Product presentations | The JD's purpose for the role is turning analysis into decisions | A test or analysis that changed what shipped or was priced, and who you worked with | A one-line decision log | `[grounded]` your stated work |
| G3 | Clinician or domain-expert partnership (R8, important) | discovery | Nothing offered | Clinicians are a named stakeholder group in the JD | Working with dietitians, food-safety, culinary, medical-adjacent or other specialist teams on analysis | A project description | `[grounded]` silence |
| G4 | Mentoring junior analysts (R9, important) | discovery | Nothing offered | The JD names two juniors | Onboarding analysts, reviewing their SQL or dashboards, running office hours | A short description of what you did and for whom | `[grounded]` silence |
| G5 | Healthcare and HIPAA (R10, preferred) | transferability | GDPR/CCPA PII handling and the consent-state model | It is a preferred row, so a minor risk, but it is the likeliest interview objection | Any health, benefits or wellness-adjacent data, or privacy-governance reviews | A sanitized description of the consent-state model's scope | `[inferred]` bridge; `[generic]` that this is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from here | risk_signal | low | "digital-health scale-up, ~400 people, Series C" | Stage and size come only from the pasted text. Posting and company details may be accurate, but nothing independent confirms them | `[generic]` pattern for any unchecked posting, not a claim about this company | Is this role live on your careers page, and which domain will the recruiter write from? | unresolved |
| RR2 | Compensation not in the pasted JD | unknown | — | (none: no figure appears) | The posting may state pay and the paste dropped it, or it is withheld | `[inferred]` from the absence in the text provided | What is the budgeted salary range for this role? | unresolved |
| RR3 | Location and work arrangement unstated | unknown | — | (none: no location appears) | Remote, hybrid or on-site could matter against your constraints | `[inferred]` from the absence in the text provided | Is the role remote, hybrid or on-site, and where? | unresolved |
| RR4 | Metrics layer: build or inherit? | unknown | — | "define and maintain the metrics layer" | "Define and maintain" can mean a greenfield build or inherited, uneven definitions | `[inferred]` from the verb pair | What exists today: a modeled layer, or definitions scattered across dashboards? | unresolved |
| RR5 | Mentoring scope and reporting line | unknown | — | "mentor two junior analysts" | "Mentor" may mean informal guidance with no formal line management | `[inferred]` from the verb | Do the two juniors report to this role, and do they exist yet? | unresolved |
| RR6 | Specific duties and named stakeholders | positive_signal | — | "partner with product managers and clinicians to turn analysis into roadmap decisions" | The role's purpose is defined, with named partners | `[grounded]` JD | Which roadmap decisions did analytics change last quarter? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Resume summary line: "Product analyst with six years in consumer subscription. Built the company's Looker instance from scratch (40+ governed dashboards) and designed and ran its experimentation program (30+ A/B tests a year)." | See R1, R3, R4 | `[grounded]` your stated background | resume_edits_pending_approval |
| E2 | Resume bullet: "Designed the pricing test behind an 11% retention lift." | See R3 | `[grounded]` your stated background | resume_edits_pending_approval |
| E3 | Resume bullet: "Built the consent-state model for the warehouse; handled GDPR and CCPA consumer PII." | See R10; deliberately does not say HIPAA, compliance expertise or health data | `[grounded]` your stated background | resume_edits_pending_approval |
| P1 | Healthcare positioning: say plainly that you haven't worked in healthcare and that your closest work is GDPR/CCPA PII handling and the consent-state model. Don't present it as HIPAA experience | See R10, G5 | `[grounded]` R10 row | pending your approval |
| A1 | Confirm the company and live posting on Harborlight's own careers page before investing in the application | See RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask the recruiter RR2 and RR3 early, against your pay and location constraints | Terms the JD leaves open | `[grounded]` RR2, RR3 | pending your approval |
| A3 | Prepare for a live SQL or experiment-design exercise and for probes on the 11% result's methodology | Role-family pattern, not a fact about this employer | `[generic]` role-family pattern | pending your approval |
| Q1 | Ask RR4, RR5 and RR6's questions verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Everything above rests on your own stated background in this message, with no CV, link or artifact inspected, so every claim is a lead.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches for "Harborlight Health care navigation app Series C" and "Harborlight Health careers Senior Product Analyst" were both refused (permission not granted). It would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | The search for "senior product analyst digital health salary range 2026" was refused. It would have given a market calibration line and a pay comparison for RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I can produce `tuesday-dossier.md` from this assessment if you want a saved copy.

## Upgrade menu

- Your CV or a prior resume → E1–E3 get checked against your actual wording, and any presentation gaps surface.
- A sanitized experiment write-up, metrics memo, or dashboard or model screenshot → R3, R4 and R5 move toward `high`.
- A sanitized metric dictionary or modeling-layer screenshot → R6 resolves.
- Your constraints (pay floor, location or remote, authorization, schedule) → hard-gate rows get built, and the hard-gates line stops reading "checks unknown".
- Permission for web search, or a link to the live posting → RR1, a market band for RR2, and role reality's contradictions row.
- The hiring manager's name → the scope read and which story to lead with.

## Questions

1. **G1 (R6):** Did you define and own the metric definitions (retention, churn, activation), in Looker or in the warehouse? If so, in what form: a modeling layer, a dictionary, or something else?
2. **G2, G3 (R7, R8):** Name one analysis that changed what shipped, and who you worked with. Have you worked with any specialist stakeholders such as dietitians, food-safety or culinary teams?
3. **G4 (R9):** Have you mentored, onboarded or reviewed the work of other analysts, and how?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.