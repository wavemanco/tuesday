I'm running a short round of company research on Kelverton Rail (values, interview process, strategy, the two interviewers) before I build the pack.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a/runs/sonnet/alone/part-2/rooms/case-5-denied-cabd69c6/Kelverton_Rail_senior-partnerships-manager_interview_pack.md`.

I built it for the single 60-minute panel the recruiter described: your unslided POV, then Q&A. Deepa gets the strategist and skeptic lens, and Ross gets the commercials and pressure lens. I had no job description, and the web searches I tried (values, process, strategy, the two interviewers) were all refused in this session. Nothing in the pack therefore comes from outside your message. I also never saw the market report, so the pack gives you a method for using it rather than content from it.

The highest-ROI rehearsal is **C1**: "You haven't carried a number and you haven't sold into rail. Convince me." Concede both plainly, hold only the 6-to-40 partners and the bus and light rail planning, and say what you'd verify first. The POV section has three candidate theses, each with a mandatory concession, and closes on what it means for operators. The four-hour triage puts the POV first, then C1.

I can run a live drill with Deepa or Ross as the interviewer, starting with C1. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the job description's requirements text? It would turn the quota and rail rows into quoted JD lines and show any location or travel gate.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Kelverton_Rail_senior-partnerships-manager_interview_pack.md -----
# Senior Partnerships Manager, Kelverton Rail: second-round panel prep pack

**Round:** one 60-minute panel. First 15 minutes: your unslided POV on operator partnerships over the next 18 months, landing on what it means for the operators themselves. Rest: Q&A, with Ross pushing on commercials.
**Panel:** Deepa (VP Partnerships, your future manager) and Ross (Commercial Director).
**Built on:** your message, including the recruiter's email as you quoted it. No job description was supplied, and no web research returned anything (see Sources), so company-specific content is absent rather than guessed.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and only say what you actually did. An "answer slot" is an instruction for the interview, not a question for you now: say what is true for you, or say plainly it was not yours.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values. None in this pack: no values round is named in the recruiter's description and no values page was read |
| EXP | Whether your CV claims survive scrutiny and attribution |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and market knowledge, thinking at the company's altitude |
| CASE | A live problem from the actual role, reasoned aloud |

## Prep triage (about four hours)

Do these in order. Each is tied to a section or question ID.

1. **90 minutes:** build and rehearse the POV (Graded deliverable below). Say it aloud twice, timed to 12 to 13 minutes so Q&A starts on time.
2. **45 minutes:** C1, the highest-ROI rehearsal in this pack. Say it aloud until it is boring, including both follow-ups.
3. **45 minutes:** re-read the market report with the consensus, divergence and anti-pick frame (A5, E2).
4. **30 minutes:** B1 to B3 (your £4M figure), then B4 and F1 (commercial structure and the seam).
5. **30 minutes:** E1 (your 90-second arc) and your reverse questions.

Everything else is insurance.

## Fit snapshot

No gate rows appear because no job description was supplied; a gate such as location or travel would show up there once one is. Quotes in the evidence column are your words only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email, as quoted in your message | "9 years in partnerships, last 4 at a payments company running the ISV channel" — your message; "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Your material says a payments ISV channel, not operator partnerships in rail, with nothing inspected behind it. Words: "For four years I ran the ISV channel at a payments company and took it from 6 partners to 40." Answer slot: the ask makes a probe on how an ISV channel compares to operator partnerships likely. If a real parallel exists, say what it is in your own words; if none does, or if the operators here are a different kind of partner, say so plainly and return to the channel you ran |
| F2 | "Please land on what it means for the operators themselves." — recruiter's email, as quoted in your message | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Your material says bus and light rail network planning; it does not say which operators, or whether any ran trains, and "the other side" is your phrase. Words: "I spent five years in transport consulting, in bus and light rail network planning." Answer slot: the ask makes a probe on what operators need from a supplier likely. If that work showed you what an operator needs, say what, in your own words, and which side you were on; if it did not, or it was not rail, say so plainly and stay with bus and light rail |
| F3 | "Ross will push on commercials." — recruiter's email, as quoted in your message | "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | discovery | A Commercial Director will test this figure and nothing in your material says how it was counted. Words: "I took it from 6 partners to 40, roughly £4M of influenced revenue." Answer slot: say how the £4M was counted, what it is most sensitive to, which assumption behind it you would defend least, and which part was yours, in your own words; if you do not know how it was counted, say so plainly and stay with the figure as you gave it |
| F4 | Carrying a direct revenue number — role-family prose, no source | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't carried a direct quota; what I have is influenced revenue." Then how you would learn to carry one, said in the future tense as a plan and never as a past |
| F5 | Selling into the train operating companies who buy the software — role-family prose, no source | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | You have said this too. Words: "I haven't sold into rail specifically." Then the adjacent ground you actually stated (F2) at its own scope, and a ramp plan in the future tense. Never a claim to rail selling |

## Graded deliverable: the 15-minute POV

The recruiter announced this as a graded piece, so treat it like an assignment.

**Grounded facts to build on** (these are the only things about you the POV may assert):

| Row | Sentence from that row's evidence cell |
|---|---|
| F1 | "took it from 6 partners to 40, roughly £4M of influenced revenue" |
| F2 | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" |

**Shape (talk, no slides):** about 2 minutes stating and testing your working definition of "operator partnerships" (customers, co-development partners, or both), about 7 for two or three theses each with its concession, about 2 for the anti-pick, about 3 for the close on operators. Leave a minute spare.

**Candidate theses.** These are positions to argue, not facts about Kelverton. Pick two, maybe three, and keep each concession in.

| Thesis | What it argues | Mandatory concession | Provenance |
|---|---|---|---|
| T1: fewer, deeper operator partnerships | Concentrate effort on a small set of operators and co-own outcomes with them, rather than spreading thin | Depth concentrates risk in a few relationships, and you do not yet know how many operators matter or which are strategic; that is the first thing you would verify | [generic] |
| T2: agree the operator's success measures first | Settle with each operator, before committing resources, what working looks like to them | The measures an operator picks may be ones Kelverton cannot move alone, so some will need negotiating down | [generic] |
| T3: grow a partner ecosystem around the operator | Where operators are served by integrators or other technology partners, build a structured channel around that relationship. It is the thesis closest to your stated channel work (F1), at the channel's own scope | It adds a layer between Kelverton and the operator and could dilute the direct relationship; it only holds if operators want it. Whether it fits rail is untested in your material | [generic] |

**Differentiating from the report.** The market report is circulated and equally available to rival candidates, so its shortlist is the consensus answer. Bring one consensus item, cited by its section, to show you read it; then one thesis-driven divergence with your reasons; then one anti-pick, something you would decline to do and why. Pack content cannot be more specific, because the report's text was not supplied.

**The requested close, what it means for the operators themselves.** End on three beats: what changes for an operator, what you would ask the operator to commit, and how the operator would tell it was working. Name no operator need as fact unless you can stand behind it; say "my hypothesis, which I would test with operators" where you cannot. Do not claim rail knowledge beyond F2 and F5.

## Persona table

The loop is established by the recruiter's description: one panel session. Weights follow the hiring-manager prior for Deepa (Case/Strategist plus Skeptic), the executive and commercial prior for Ross (Prober plus Pressure), and the recruiter's own words.

| Persona | How it shows up in this panel | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (bank A) | Follow-ups on the POV, live problems from the partnerships role | High. Hiring-manager prior, and the POV is a quarter of the session | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully (A1 to A5) |
| Data-Driven Prober (bank B) | Ross taking your £4M figure and "influenced" apart | High. "Ross will push on commercials" (recruiter), and the figure is in F3 | Know what you can and cannot say about how it was counted; name the weakest assumption first, or say you do not know (B1 to B4) |
| Skeptic (bank C) | Deepa probing the rail and quota gaps | High. Hiring-manager prior, and both gaps are ones you stated (F4, F5) | Rehearse the one objection (C1) until boring; bridges only from what you stated; a ramp plan in the future tense |
| Pressure (bank D) | Ross interrupting, time-boxing, asking for one number | Medium. Executive prior, plus "push" in the recruiter's wording | Pause, restate, anchor in what you stated, hold through two follow-ups, concede specifically (D1 to D3) |
| Conversational (bank E) | Opening biography and an informal "what are you looking at" | Medium-low. A 60-minute panel opens with the POV, but a friendly register usually surrounds Q&A | Pre-scripted 90-second arc; treat casual questions as scored (E1, E2) |
| Peer Evaluator (bank F) | Ross asking where partnerships ends and direct commercial work begins | Medium-low. A Commercial Director sits next to partnerships | Reciprocity framing; propose seam principles rather than claiming to know the seam (F1, F2) |

Values/Behavioral is not weighted: no values round is named in the recruiter's description.

## Question banks

Provenance comes first because the sentences a row may draw on are fixed before any guidance is written. Highest-ROI prep in the pack: **C1**.

### A. Case/Strategist (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Before you tell us where you'd take our operator partnerships, what would you want to know first?" | CASE | [generic] | Clarify before structuring. Ask what "operator partnership" means here (customers, co-development partners, or both), which operators matter most, what the 18 months must deliver, and how success is judged. Ask two or three questions, not ten, then state your working assumption aloud and proceed. The question needs no claim about your past, so the guidance makes none | The recruiter's "operator partnerships" is undefined in your material, and a manager scores whether you clarify before answering; CASE because it tests the first move of the POV |
| A2 | "Give us the shape of the 18 months: what comes first, what comes later, and what would you decline to do?" | CASE | [generic] | Structure: objective, segmentation, approach, metrics, risks. Name one thing you would decline and why, and one premise you would test with them. It is a method for the problem, not a claim about what you have done | Follow-up on the POV from Deepa, the person who will own the plan; CASE because it scores structure |
| A3 | "A larger operator partner tells us our scheduling product doesn't fit how they actually run their service and is weighing a competitor. What do you do in the first week?" | CASE | [generic] | Structure it: what you would ask them first, who inside Kelverton you would bring in, what you would not promise, and what you would record. No claim about your past; say plainly where you would need Kelverton's own facts before committing to anything | A live partnerships problem built from the recruiter's operators focus (F2's requirement), asked as a decision; generic because it is a pattern, not a fact about this employer |
| A4 | "What do you think an operator weighs most when choosing a scheduling-software supplier, and how would you test that?" | CO | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Give a hypothesis and call it one. Anchor it at the scope of the quote: bus and light rail network planning. Then say how you would test it with operators. Answer slot: if that planning work showed you what operators need from a supplier, say what, in your own words; if it did not, or it was not rail, say so plainly and say how you would find out | F2 is the only operator-side evidence you have; CO because it tests whether you think at the company's altitude, and the guidance does not assert what operators want |
| A5 | "Our strategy team circulated a market report last quarter. What would you push back on in it?" | CO | [grounded] "the market report their strategy team circulated internally last quarter, which I've read" | Bring one consensus item, cited by section, to show you read it; then one divergence with reasons; then one anti-pick. The report's text was not supplied, so name the specifics yourself, in your own words. Answer slot: if any section of it overlaps with what you saw in bus and light rail work, say which; if none does, say so plainly and make the divergence a reasoned view | The recruiter attached the report, so some version of this question is likely; CO because it tests homework depth, and differentiating beats reciting a shared source |

### B. Data-Driven Prober (top weight, Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You said roughly £4M of influenced revenue. Walk me through how that was counted." | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Open with the figure at its own scope: "roughly £4M of influenced revenue." Answer slot: say how it was counted, what it is most sensitive to, which assumption behind it you would defend least, and which part was yours, in your own words; if you do not know how it was counted, say so plainly and stay with the figure as you gave it | F3 is the headline metric on the CV and Ross is the likeliest to take it apart; EXP because it tests attribution honesty |
| B2 | "'Influenced' is carrying a lot of weight. How is that different from revenue you closed?" | EXP | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Hold what the sentence says: "I haven't carried a direct quota; what I have is influenced revenue." Answer slot: say how an influenced deal was identified, in your own words; if there was no fixed rule, or it was not yours to set, say so plainly and describe what you do know about how the figure was built. Do not describe it as closed or booked | The qualifier is yours, so it is the first thing a commercial reader presses; F4 is the evidence; EXP because it tests precision about what the number means |
| B3 | "You went from 6 partners to 40. Which of those were yours, and which would have come anyway?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Start with the quote's own words: you took it from 6 to 40. Answer slot: say which of the additions were your doing and what else contributed, in your own words; if you cannot separate them, or others did part of it, say so plainly and return to the 6 and the 40 as you stated them. No team size or process is asserted here | A "how much was you" attribution probe on F1 and F3; EXP |
| B4 | "How would you structure the economics with an operator partner, and what would you want to know before putting a number on the table?" | JD | [generic] | A method, not a history. What each side gives and gets, how it is measured, what risk each carries, and what Kelverton's levers are. Answer slot: if you have set or negotiated partner terms, say what and which part was yours; if not, or it was not yours, say so plainly and walk the structure as how you would approach it | "Ross will push on commercials" raises this directly; JD because the recruiter named it as the focus, and nothing in your material shows commercial terms |

### C. Skeptic (top weight, Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You haven't carried a number and you haven't sold into rail. Convince me." | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue."; "took it from 6 partners to 40, roughly £4M of influenced revenue"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | **Highest-ROI rehearsal.** Concede first, plainly, in your words: "I haven't carried a direct quota, and I haven't sold into rail specifically." Hold only what the quotes carry: you took the ISV channel from 6 partners to 40, and you did five years of bus and light rail network planning. Follow-up 1, "bus and light rail isn't heavy rail": agree it is what it was and stay at that scope. Follow-up 2, "what will you get wrong in month one": say what you would verify first, in the future tense. Never claim to know rail | F4 and F5 are the stated gaps and F1 and F2 are the adjacent evidence; this combined objection is the likeliest question for this candidate in this loop, so a rehearsed non-defensive answer changes the interview. JD because it scores the requirement |
| C2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Pick from what you actually told me: "I haven't sold into rail specifically" or "I haven't carried a direct quota." Choose the one you are better able to ramp on, then give the ramp as a plan in the future tense. Calibrated candor beats bluffing a competency Ross or Deepa owns | F4 and F5; a stock Skeptic stem that tests honest self-assessment; JD |
| C3 | "Why leave payments for rail-tech, and why now?" | EXP | [generic] | Selection scaffold: give your own reason in your own words, tied to something specific in what the recruiter described (the POV on operator partnerships, the operators as the focus). It needs a stake and an honest sentence, not a slogan. If no single reason comes to mind, say so plainly, then give the nearest thing you can stand behind | Motivation consistency is scored in every loop; the pack has no sentence of yours carrying a reason, so it gives a scaffold rather than a story |
| C4 | "Your ISV partners sold into a very different buyer. What transfers?" | JD | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel"; "took it from 6 partners to 40, roughly £4M of influenced revenue" | Say what you ran, at its own scope: you ran the ISV channel at a payments company and took it from 6 partners to 40. Answer slot: if a real parallel with operator partnerships exists, say what it is in your own words; if none does, or the operators are a different kind of partner, say so plainly and return to the channel you ran. Do not say the channel proves anything; let them draw the inference | F1 is where the transfer is asked; JD because the recruiter's POV ask tests it directly |

### D. Pressure (mid weight, Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has sold into rail?" | JD | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Pause, restate, then hold-then-concede. Concede plainly that you have not sold into rail specifically. Hold the two things you stated: you took the ISV channel from 6 partners to 40, and you did bus and light rail network planning. Do not say you are better; say what you would bring and what you would need to learn | A time-boxed stress version of C1 in Ross's register; F1, F2 and F5 are the evidence; JD |
| D2 | "You've given us a plan and no numbers. Pick one: what's the number at month 18?" | CASE | [generic] | Name the kind of number your thesis implies and what it would count, then say plainly you do not have Kelverton's baseline and would want it. Do not invent a figure. Hold through one more push, then concede specifically what you cannot yet know | Pressure on the POV; CASE because it tests reasoning under a time box, and the guidance supplies no number |
| D3 | "An operator wants a bespoke deal our direct sales team says undercuts list pricing. You have two minutes. What's your call?" | CASE | [generic] | Structure aloud: what the operator is really asking for, what it costs, who else needs to be in the decision, and what you would not do alone. Hold your call through two follow-ups and concede what you would need to know. No claim about your past | Tests the partnership and direct-commercial seam under pressure; generic because it is a pattern |

### E. Conversational (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey: transport consulting, payments, and now here." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | A 90-second arc told in your own words: five years in transport consulting in bus and light rail network planning, then four at a payments company running the ISV channel, then why this role. Treat the consulting years as consulting, not as partnerships; your message gives 9 years in partnerships alongside 5 and 4, so say which years were which if asked. Answer slot: your reason for this role is yours to give, in your own words | The opening biography question is near-certain in a friendly register; F1 and F2 carry the arc, and EXP because it tests whether the CV hangs together |
| E2 | "What are you actually curious about in operator scheduling right now?" | CO | [grounded] "the market report their strategy team circulated internally last quarter, which I've read" | Answer from what you have actually looked at. Answer slot: if something in the report you read caught your attention, say what and why, in your own words; if nothing did, or you have not looked at scheduling itself, say so plainly and say what you would read first. Casual questions on the role's hot topics are scored | A rapport-style question about the JD's headline topic; the report is the one document in hand; CO |

### F. Peer Evaluator (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Your partners and our direct sales team will sometimes want the same operator. Where's the seam, and what happens when we disagree?" | CASE | [generic] | Propose seam principles rather than pretending to know the current seam: who owns the relationship, shared visibility of the pipeline, a rule for when interests collide. Ask how it works today. Show spine and tact together. No claim about your past | Ross's function sits next to partnerships, so the seam is likely; CASE because it asks for a decision, and generic because it is a pattern |
| F2 | "How do you handle credit when a deal spans partnerships and sales?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Start with what the sentence says: the figure is influenced revenue. Answer slot: if you had a rule for sharing credit with other teams on those deals, say what it was and who set it; if there was no rule, or it was not yours, say so plainly and return to the figure as you gave it | "Influenced" is a credit-sharing concept and Ross owns the sales side; F3 is the evidence; EXP |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| "present a short POV on where you'd take our operator partnerships over the next 18 months" (recruiter) | A1, A2, A5, D2, plus the POV build |
| "Please land on what it means for the operators themselves." (recruiter) | A3, A4, plus the POV close |
| "Ross will push on commercials." (recruiter) | B1, B2, B3, B4, D3, F2 |
| Carrying a direct revenue number (role-family prose) | B2, C1, C2 |
| Selling into train operating companies (role-family prose) | C1, C2, D1, C4 |
| Working next to direct sales (role-family prose) | F1, F2, D3 |
| Motivation for this move (role-family prose) | C3, E1 |
| The circulated market report (recruiter attachment) | A5, E2 |

## Reverse questions

No interviewer profile was found, so none is tied to a path.

| # | Question | Why it lands | For |
|---|---|---|---|
| R1 | "When you say operator partnerships, who are the partners, and what does a good one look like to you?" | Surfaces the definition the POV rests on, and shows you will not prescribe before you know | Deepa |
| R2 | "What would the first 90 days need to have produced for you to say the hire was working?" | Sets the bar in the manager's own words and gives you something to be measured against that is not a quota you do not have | Deepa |
| R3 | "How is partner-sourced or partner-influenced revenue counted here today, and who owns the number?" | Moves Ross's pressure on commercials into a shared problem and shows you know "influenced" is a definition, not a fact | Ross |
| R4 | "Where does the partnerships team's work end and the commercial team's begin when an operator is both a partner and a customer?" | Names the seam before it becomes a conflict and signals you think about the other team's load | Ross |
| R5 | "What has changed since the market report circulated that I should know?" | Shows you read it and treats the panel as the people who know more than the document | Both |
| R6 | "What would an operator tell us today is the one thing that makes Kelverton easy or hard to work with?" | Brings the operator voice back in, which is where the POV ends | Both |

## Prohibited claims

Built before the banks. None is coached anywhere in this pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Has sold into rail | Negative you stated, F5 | The plain acknowledgment F5 gives: "I haven't sold into rail specifically." No slot |
| Has carried a quota or revenue target | Negative you stated, F4 | The plain acknowledgment F4 gives: "I haven't carried a direct quota; what I have is influenced revenue." No slot |
| Closed, booked or owned £4M of revenue | Inflated form of F3 | F3's quote at its own scope: roughly £4M of influenced revenue. The limit is the pack's observation: the material says influenced, not closed. B1 and B2 stay inside how the figure was counted |
| Worked with or planned for train operating companies | Inflated form of F2 | F2's quote at its own scope: bus and light rail network planning. The material does not say heavy rail or which operators; A4 and C1 stay at that scope |
| Built the ISV channel from nothing, or set its strategy | Inflated form of F1 | F1's quote at its own scope: ran the ISV channel and took it from 6 partners to 40. The material does not say how the channel started or who set its direction |

## Sources

**Provided documents:** your message, including the recruiter's email as you quoted it. The market report the recruiter attached was not pasted, so nothing in this pack comes from its content. No dossier was supplied.

Research tier: L1 — searches 5 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | The call was refused, so published value names are unknown. It would have supplied raising sources for VAL questions; none is in this pack |
| 2. `Kelverton Rail interview process partnerships` | unavailable | The call was refused. The loop rests on the recruiter's description alone, which is enough to fix one panel session; the search would have checked for other rounds |
| 3. `Kelverton Rail scheduling software train operating companies strategy news` | unavailable | The call was refused, so there is no current strategy context. It would have grounded A4 and A5 and a grounding brief section |
| 4. `Deepa VP Partnerships Kelverton Rail` and `Ross Commercial Director Kelverton Rail` | unavailable | Both calls were refused. The interviewer read is absent; the upgrade menu says what a profile would unlock |
| 5. representative Senior Partnerships Manager JD | unavailable | No search was sent: the host had refused the first five calls. It would have replaced role-family prose in F4 and F5 with a fetched JD's quoted requirements |

Every search sent: `Kelverton Rail values` (refused); `Kelverton Rail interview process partnerships` (refused); `Kelverton Rail scheduling software train operating companies strategy news` (refused); `Deepa VP Partnerships Kelverton Rail` (refused); `Ross Commercial Director Kelverton Rail` (refused).

## Upgrade menu

- The job description text: the F4 and F5 requirements become quoted JD lines, JD-tagged questions follow its real list, and any gate such as location or travel surfaces as a row
- The market report, pasted or its key sections: A5, E2 and the POV's consensus and divergence step become specific, and a grounding brief section becomes possible
- Which of your nine years in partnerships sit before the payments role: the E1 arc and F1's evidence get tighter, since your message gives 9 years in partnerships alongside 5 and 4
- How the £4M was counted, and an artifact that shows it, such as a partner-attributed revenue report or CRM export: F3 can move from medium toward high and B1 to B3 stop being slots
- Search access: Kelverton's published values, loop and current strategy, and the two interviewers' public professional footprints become available, giving an interviewer read and a reverse question tied to their paths. A deeper research pass is also available: up to 6 more searches and 2 more fetches, several more minutes, offered once
- The recruiter, in one email: what "operator partnerships" means here and whether Ross has a particular commercial topic in mind, which would restructure bank B and the POV's opening
- A `tuesday-dossier.md` from an earlier evidence review, if you have one, would add confirmed evidence and constraints on the rail and quota gaps; it is never a precondition
