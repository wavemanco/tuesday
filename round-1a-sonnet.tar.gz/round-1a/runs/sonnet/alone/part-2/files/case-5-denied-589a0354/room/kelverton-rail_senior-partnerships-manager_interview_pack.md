# Interview pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, one 60-minute panel. Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). The first 15 minutes are your POV on operator partnerships over the next 18 months, no slides, landing on what it means for the operators themselves. The rest is Q&A, and Ross will push on commercials. Source: the recruiter's email as you quoted it. This is a first version.

## How to use this pack

- Personas are how a question is asked. Types are what it scores. Tags: **VAL** (values alignment), **EXP** (work-experience deep-dive), **JD** (role requirements, gaps included), **CO** (company and strategy knowledge), **CASE** (live problem).
- Guidance is scaffolding, not a script. Where a cell quotes you, the quote is the limit of what to claim. Where it says "answer slot", it is an instruction for the interview: answer from your own experience, or say plainly that the practice was not yours.
- No VAL questions are included: your recruiter's description names a POV and Q&A, not a values round, and no published values page was available to this pack.
- Square brackets appear only as provenance labels: grounded (traceable to your messages), inferred (derived from an adjacent source), generic (a pattern with no claim about Kelverton or you).

## Prep triage (about 4 hours)

| Order | Time | Do this | Tied to |
|---|---|---|---|
| 1 | 75 min | Draft the POV, then say it aloud twice against a 15-minute clock. Reread the market report once, only to pick one consensus item and one point you will depart from | Graded deliverable below; C2, C4 |
| 2 | 60 min | The highest-ROI objection: say A1 aloud until it is boring, then defend the £4M through B1, B2, B5 | A1, B1, B2, B5 |
| 3 | 45 min | Ross's pressure: D1, D2, D3 and B3, with someone interrupting at 60 seconds | D1, D2, D3, B3 |
| 4 | 30 min | The 90-second opener and the reverse questions | E1, Reverse questions |
| 5 | 30 min | A drill with a stand-in panel, then C1 and C3 cold | C1, C3, A2, A3 |

Everything else in this pack is insurance.

## Fit snapshot

Requirements come from the recruiter's words, since no job description was supplied. Two rows state a role-family expectation with no supplied source and are labelled as such.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email, as you quoted it | "9 years in partnerships, last 4 at a payments company running the ISV channel" — your message; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Your material carries partnership running in a payments company's ISV channel and consulting on bus and light rail. Neither is Kelverton's operator partnerships, and the words stay at those scopes: "For the last four years I was running the ISV channel at a payments company." Answer slot: expect a probe on what the ISV channel taught you that applies to operators. If any part of how you ran it applies, say which and why, in your own words; if you are unsure any does, say so plainly and return to the consulting years |
| F2 | "Please land on what it means for the operators themselves." — recruiter's email, as you quoted it | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Your material says bus and light rail network planning, not train operating companies, and the words stay there: "I did five years of transport consulting on bus and light rail network planning." Answer slot: expect a probe on how far that reaches. If the work touched train operators, say how; if none of it did, say so plainly and return to the bus and light rail work |
| F3 | "Ross will push on commercials." — recruiter's email, as you quoted it | "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | discovery | Your material gives the figure and the word influenced, and does not show how it was counted or what part was yours. Answer slot: expect the four probes a figure raises: how the £4M was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. Answer each in your own words; where you do not know how it was counted, say so plainly. "Roughly" and "influenced" stay in every sentence. A second slot: if you set commercial terms with partners, say what you did, in your own words; if others set them, say so plainly |
| F4 | Carry a revenue number in a rail-sector role — role-family expectation, no source supplied | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't sold into rail and I haven't carried a direct quota; what I've had is influenced revenue." Then how you would learn the sector, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F5 | Build and scale a partner programme — role-family expectation, no source supplied | "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message; "9 years in partnerships, last 4 at a payments company running the ISV channel" — your message | medium | [generic] | none | No gap, but a figure with nothing inspected behind it, so expect a probe. Lead in the quote's own terms: "I took it from 6 partners to 40." F3 holds the four defend-the-number probes |

## Graded deliverable: the 15-minute POV

**Facts to build on**

| Fact | Source | Provenance |
|---|---|---|
| The brief is "present a short POV on where you'd take our operator partnerships over the next 18 months", with "no slides needed, just talk us through it", and to "land on what it means for the operators themselves" | Recruiter's email, as you quoted it | [grounded] |
| Your side of the operator world, at its own scope: "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | F2 | [grounded] |
| Your side of the partner world, at its own scope: "9 years in partnerships, last 4 at a payments company running the ISV channel" | F1 | [grounded] |
| The report is an internal strategy-team document, so the panel knows it better than you do | Your message | [grounded] |

**Three theses.** Pick one. Each has a mandatory concession and a close on what it means for the operators. They are positions to argue, not facts about Kelverton: test each against the report before choosing.

| # | Thesis | Mandatory concession | What it means for the operators (the requested close) | Provenance |
|---|---|---|---|---|
| T1 | Fewer, deeper operator partnerships beat broad coverage: concentrate on a small set and build a shared plan with each | It concentrates risk in a few accounts and slows reach; Ross will ask what happens if one steps back, so have the answer ready | A named counterpart and a shared plan with measures; in return the operator gives access and time | [generic] |
| T2 | Make the partnership's results visible to the operator first and to Kelverton second, through a shared scorecard | Operators may not want another thing to report on, and a scorecard can expose a weak result; say what you would do then | The operator can show its own board what the partnership delivered; in return it shares the data the scorecard needs | [generic] |
| T3 | Build a partner layer around the product, the thing an ISV channel does: third parties who extend it, so operators get more from the same software | It is the thesis nearest your experience and the furthest from proven in this sector; say what you would test first and that you do not yet know if operators want it | Operators get capabilities they would otherwise wait for or build; in return they accept third parties near their scheduling | [generic] |

For T3, describe what you ran at its quoted scope (F1) and let them draw the inference. Answer slot: if any part of how the ISV channel was designed maps to operators, say what and how, in your own words; if you are unsure it maps, say so and present it as a thing to test.

**Differentiation.** The report is equally available to anyone the panel has met. Bring one consensus item from it to prove you read it, then one thesis of your own that departs from it, with reasons. Do not recite its shortlist. **Anti-pick:** name one thing Kelverton should say no to over 18 months, such as bespoke work for a single operator that does not generalise, or partner breadth for its own sake. A partnerships role includes saying no.

**Rehearsal timing (a budget, expect interruptions from Ross).** 2 minutes framing, including one plain line of your limit from F4 ("I haven't sold into rail"), since a stated limit disarms the first probe. 3 minutes on the consensus item. 6 minutes on your thesis and its concession. 2 minutes on the anti-pick. 2 minutes landing on the operators: one thing they can do that they cannot today, one thing they stop having to do, one thing they are asked to give. Name each from your own view or the report; the pack does not supply them.

## Persona table

The loop is established by the recruiter's own words: one panel, two interviewers. No archetype fallback is used. Panel rule: blend the top two personas of each member's relationship.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Deepa probing the gap to the role, quietly and persistently | High, weight 5. Hiring-manager prior is Case plus Skeptic, and F4 is a stated gap | Rehearse A1 until it is boring; calibrated candor over bluffing a competency they own |
| Data-driven Prober (B) | Ross on the £4M and on commercial terms | High, weight 5. The recruiter's own words say Ross will push on commercials, and F3 is a headline figure | Know what you can and cannot say about how the figure was counted; name the weakest assumption first |
| Case / Strategist (C) | Deepa on the POV and live problems from the operator side | High, weight 4. Hiring-manager prior, plus a 15-minute POV | Clarify, structure, answer; use their vocabulary; challenge one premise respectfully |
| Pressure (D) | Ross interrupting or time-boxing | Medium, weight 3. Executive prior for a Commercial Director, softened because the recruiter framed Ross's push as commercial, not stress | Pause, restate, hold through two follow-ups, concede specifically |
| Conversational (E) | Opening and closing exchanges | Low, weight 2. Panels open warm, and casual questions are still scored | A scripted 90-second arc; never answer "I think you've covered everything" in the reverse-question slot |
| Values, Peer | Not expected | Not covered: no values round is described, and neither interviewer is a peer | None |

## Question banks

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Neither rail nor a direct quota is in your background. Which of those two worries you more, for this role?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue."; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | **The highest-ROI rehearsal in this pack.** Hold only what the quotes carry. Say both limits plainly: "I haven't sold into rail and I haven't carried a direct quota; what I've had is influenced revenue." Choose which worries you more and say why; the choice is yours. Then what the quotes do carry, at their scope: the consulting years on bus and light rail network planning and the four years running the ISV channel. Close with a plan for the limit you chose, said as a plan and never as a past. Hold through two follow-ups by returning to the quotes, never by adding to them; concede that the limit is real | F4 and F3 are where both panelists press hardest, so this arrives in some form. JD because it scores the role's fit directly; the Skeptic stem is "which part would you be weakest at" |
| A2 | "Payments ISVs and train operators are different worlds. What from the first carries over to the second?" | JD | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel" | Tell what you ran in your own words, at the quote's scope: the last four years at a payments company running the ISV channel. Answer slot: if any part of how you ran the channel applies to operators, say which and why; if you are not sure any does, say so plainly and say what you would test first. Describe what you did and let them draw the inference; do not assert that the ISV results predict operator results | F1 is the evidence for the POV requirement and the likeliest place the transfer is tested; JD because it scores the stated task |
| A3 | "Your consulting work was bus and light rail network planning. How far does that reach with a train operating company?" | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Say it at its scope: "I did five years of transport consulting on bus and light rail network planning." Answer slot: if the work touched train operators, say how; if none did, say so plainly and say what you would need to learn first. Do not extend "the operator world" beyond the modes the quote names | F2 is the only evidence for the land-on-operators requirement, and its scope is narrower than the role; EXP because it tests what the work actually covered |
| A4 | "Why this role, why Kelverton, and why now?" | JD | [grounded] "She also attached the market report their strategy team circulated internally last quarter, which I've read." | An open prompt, so the reasons are yours; the pack supplies none. Three short beats: what draws you to operators, what draws you to this company, why this point in your career. If you cite the report, cite one specific thing you can discuss for a minute. If there is a reason you are leaving the payments company, say it in your own words | The motivation probe every Skeptic runs; JD because it scores fit with this role, and the report is the one company source you have in hand |
| A5 | "What would you need from me in your first ninety days?" | JD | [generic] | Reciprocity framing: what you need (introductions to operators, access to the account history, the commercial structures in use) and what you would bring back by day ninety, said as a plan. It makes no claim about your past | Deepa is your future manager, so a collaboration question is likely; JD because it scores readiness for the role |

### B. Data-driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the £4M was counted." | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | The four probes a figure raises, answered in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Keep "roughly" and "influenced". If you have an analysis you did yourself, offer to walk through it end to end; if you do not know how it was counted, say so plainly | F3 is the headline figure on the page; EXP because it tests whether the number survives |
| B2 | "You say influenced, not carried. Where is the line between the two, in your numbers?" | EXP | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Hold what you said: "I never carried a direct quota; what I had was influenced revenue." Answer slot: if a rule separated influenced from direct revenue in how the £4M was tallied, say what it was; if no rule did, or you do not know, say so plainly | The line between the two is Ross's most natural commercial question given F3 and F4; EXP because it tests attribution |
| B3 | "Take one operator partnership. How would you structure the commercials: what does each side put in, and what does each take out?" | CASE | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Live problem. Clarify the partnership's purpose first, then who pays and who benefits, then how you would test the terms, then risks. Say aloud what you do not know about how rail operators buy and ask Ross. Do not invent price points. Answer slot: if a follow-up asks whether you have set partner terms before, say what you did in your own words; if others set them, or you only influenced them, say so plainly and return to "roughly £4M of influenced revenue" | The recruiter says Ross will push on commercials, so a live commercial problem is likely (F3); CASE because it is a structure-before-answer problem |
| B4 | "From 6 partners to 40. What did it cost to win and to keep those partners?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue"; "9 years in partnerships, last 4 at a payments company running the ISV channel" | Say what the quote says: "I took it from 6 partners to 40." Answer slot: if you tracked what winning or supporting partners cost, say what you tracked, in your own words; if you did not, or it sat with others, say so plainly and say what you would track here. Do not estimate a figure aloud | The recruiter's commercials signal makes cost a likely probe on F5; EXP because it tests the economics of your own claim |
| B5 | "Which assumption behind that figure would you defend least?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Name it yourself before they do; this converts a gotcha into credibility, and the pack does not name it for you. Answer slot: say the assumption in your own words; if you do not know the assumptions behind how it was counted, say so plainly. Add which part of it was yours | The standard Prober stem for a headline metric (F3); EXP because it scores whether you know your own number |

### C. Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sketch your first ninety days with our operator partnerships. What do you need to know first?" | CASE | [generic] | Clarify, objective, segmentation, approach, metrics, risks. Think aloud. Ask how Kelverton groups its operators before proposing your own grouping, and challenge one premise respectfully. It makes no claim about your past | A live problem from the role, from the hiring manager's side; CASE because it scores structure |
| C2 | "You've read our strategy team's market report. What in it would you push back on?" | CO | [grounded] "She also attached the market report their strategy team circulated internally last quarter, which I've read." | The pack has not seen the report, so name one claim to push back on and one to build on, with reasons. Bring one consensus item, then one divergence; do not recite the shortlist. If you agree with all of it, say what it leaves out. Do not coach the interviewers on their own document | The report is the one company source in hand; CO because it tests current strategy at their altitude |
| C3 | "An operator tells you the product is working but the partnership isn't. What do you do?" | CASE | [generic] | Ask what "isn't working" means to them and who is saying it; separate the product from the partnership; propose a joint review with a shared measure; concede what you cannot know from outside; end on what it means for the operator. It makes no claim about your past | The POV's close is "what it means for the operators", so a live operator problem is likely (F2); CASE because it scores reasoning |
| C4 | "What should 'partnership' mean for an operator that it doesn't mean for a customer who just buys the software?" | CO | [generic] | Define the term before using it: ask how Kelverton uses it. Then give differences you could argue, such as what each side contributes beyond payment, shared outcomes, a say in the roadmap, as hypotheses to test, not facts about Kelverton | This is the question the POV answers in 15 minutes (F1); CO because it scores the company's own vocabulary |

### D. Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That result — how much of it was actually you?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue"; "9 years in partnerships, last 4 at a payments company running the ISV channel" | Hold: "I was running the ISV channel and took it from 6 partners to 40." Hold through two follow-ups, then concede specifically. Answer slot: say which parts were yours alone and which were shared and with whom; if you do not know the split, say so plainly. Never promote "running" to "built" or "influenced" to "closed" | F5 and F3 carry the attribution probe; EXP because it tests what was yours |
| D2 | "Sixty seconds: why you over a candidate who has already sold into rail?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue."; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Pause, restate. Plain acknowledgment: "I haven't sold into rail." Then what the quotes carry at scope: the consulting on bus and light rail network planning and the four years running the ISV channel. Claim no advantage the quotes do not carry. Concede the rail-sales point cleanly; end on what you would do about it, as a plan | F4 is the gap this question presses, in its stress-interview form; JD because it scores the stated fit |
| D3 | "Stop there. What does that cost us, and when do we see a return?" | CASE | [generic] | Pause and restate. Say what you would need to know to put a number on it; give the cost categories as questions you would ask, not figures. Concede that you do not have Kelverton's numbers, offer the first test, then return to where you were in the POV | Ross may interrupt the POV on commercials, per the recruiter's signal; CASE because it is a live problem under time pressure |

### E. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey, from consulting to here." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | A 90-second arc, in the order your CV runs them: five years of transport consulting on bus and light rail network planning; nine years in partnerships, the last four at a payments company running the ISV channel; then why operators now, in your own reasons. Answer slot: the quotes do not say what the earlier partnership years were; say what they were in your own words, or keep the arc to the years the quotes carry | The opening question of most panels; EXP because it tests whether the CV's story hangs together (F1) |
| E2 | "What are you actually playing with in rail tech these days?" | CO | [generic] | Answer slot: if you follow something in rail scheduling or operations technology, name it, in your own words; if you do not, say so plainly and name what in the report caught your attention | A casual question on a hot topic for the role, scored anyway; CO because it tests current interest |

### Requirement coverage

| Requirement | Questions |
|---|---|
| POV on operator partnerships over 18 months (F1) | Graded deliverable, C2, C4, E2 |
| Land on what it means for the operators (F2) | Graded deliverable, A3, C3 |
| Ross will push on commercials (F3) | B1, B2, B3, B4, B5, D3 |
| Carry a revenue number in a rail-sector role (F4) | A1, B2, D2 |
| Build and scale a partner programme (F5) | A2, B4, D1, E1 |
| Values alignment | None: no values round is described and no values page was available |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "When you say operator partnerships, which operators, and what does the partnership give each side?" | It settles whether the role is account-led, co-development or something else, and shows you are testing the same definition C4 tests |
| R2 | "Ross, how is partner-influenced revenue counted here, and does this role carry a number?" | It puts the quota gap on the table on your terms, before it is raised as an objection |
| R3 | "What would success look like at 18 months, and who would judge it?" | It matches the POV's horizon and shows you think in their time frame |
| R4 | "What did the strategy team's report leave open that you most want this role to answer?" | It uses the one document you share and invites them to talk about their own thinking |
| R5 | "What is the hardest part of working with operators to get right?" | It asks for their experience, not their pitch, and gives you material to build on in the Q&A |
| R6 | "Deepa, what would you want me to do differently from the last person in this seat, or from what you'd expect?" | A manager-directed question that invites candor; use it only if the seat's history was not already described |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Carried a quota or owned revenue directly | Negative you stated, F4 | The plain acknowledgment F4 gives: "I haven't carried a direct quota." No slot |
| Sold into rail | Negative you stated, F4 | The plain acknowledgment F4 gives: "I haven't sold into rail." No slot |
| Closed, won or sourced £4M | Inflated form of F3 | F3's quote at its own scope: "roughly £4M of influenced revenue". The limit is the pack's observation: your material says influenced, not closed or sourced |
| Built the ISV channel | Inflated form of F5 | F5's quote at its own scope: "took it from 6 partners to 40". The limit is the pack's observation: your material says running the channel and growing it, not building it |
| Knows train operating companies from the inside | Inflated form of F2 | F2's quote at its own scope: "bus and light rail network planning". The limit is the pack's observation: your material says bus and light rail, not train operating companies |

## Sources

**Provided:** your message, which quotes the recruiter's email and gives your background; the market report is named in your message but its content was not supplied, so nothing in this pack comes from it. No dossier.

**Searches sent (all four refused, no results returned):**
- Kelverton Rail company values — refused
- Kelverton Rail strategy scheduling software train operating companies — refused
- Deepa VP Partnerships Kelverton Rail — refused
- Senior Partnerships Manager rail technology train operating companies job description — refused

**Fetches:** none.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | The call was refused. Would have fed a values cheat sheet, which this pack omits anyway because no values round is described |
| 2. Interview process | skipped | Your recruiter's words fix the loop: one panel of two, a 15-minute POV and Q&A; the persona weights follow from them |
| 3. Strategy and recent news | unavailable | The call was refused. Would have fed a grounding brief and made C2 and C4 specific; they are generic or report-based instead |
| 4. Interviewers (Deepa, Ross) | unavailable | The call was refused, and no query for Ross was sent. Would have fed the interviewer read and a reverse question tied to their paths; both are absent |
| 5. Representative JD | unavailable | The call was refused. Would have fed the fit snapshot's requirements, which are the recruiter's words and two unsourced role-family lines instead |

## Upgrade menu

- The job description → F4 and F5 become quoted requirements, any gate (right to work, location, travel, clearance) surfaces as its own row, and the JD-tagged questions gain a raising source
- The market report's headline conclusions, pasted → a grounding brief, a sharper consensus-and-divergence plan for the POV, and C2 and C4 become specific
- Your CV, especially the partnership years before the payments company → F1, F5 and E1 become story-mapped instead of slots; the document behind the £4M, such as a partner-programme attribution report, would lift F3 from medium to high
- Your own answers to the answer slots in A2, A3, B1, B2, B4 and D1 → each becomes a quoted fact and the rows that draw on it regenerate
- A reply from the recruiter on what "operator partnerships" means at Kelverton and what Ross's commercial focus is → reweights the B and C banks
- The interviewers' full names or public profiles → an interviewer read and a reverse question tied to their paths
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes; it needs search permission, which was refused in this session) → strategy brief, interviewer footprints, recent org context
- A tuesday-dossier.md from a job-underwriter run → verified evidence, a named top objection and an absolute prohibited-claims list, replacing the locally built list above
