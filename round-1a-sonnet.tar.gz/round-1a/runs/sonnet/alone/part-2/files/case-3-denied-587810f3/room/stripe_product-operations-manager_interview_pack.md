# Interview pack: Product Operations Manager, Stripe

Final-round interview. Interviewer name and relationship: not given. Session length and number of sessions: not given.

Built from the role title, the company and "final round" alone. There is no JD, no CV and no interviewer information, and web research was not available (see Sources). That makes this a worksheet-style pack: every question about your past is a selection scaffold, and nothing here states a fact about Stripe.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Tag | Name | What it is testing |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the company's published values, not generic virtue |
| EXP | Work-experience deep-dive | Whether your claims survive scrutiny, and what was actually you |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge | Homework depth and whether you can think at the company's altitude |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the role, delivered live |

The highest-ROI prep in this pack is B1, "Which part of this role would you be weakest at on day one?" It is asked in some form in nearly every final round, and an unrehearsed answer is where candidates sound defensive or bluff. Rehearse it until it is boring.

## Fit snapshot

No JD was supplied, so the requirements below are role-family requirements written as plain prose, labeled `[generic]`. They are not quotes from Stripe's posting. No CV or background was supplied, so every evidence cell reads `none given` and this is the worksheet variant. Fill the Evidence column yourself from your real experience before you rehearse.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Drive cross-functional programs and launches across product, engineering and go-to-market teams (role-family, no JD supplied) | none given | none | [generic] | discovery | Strong evidence here is a launch or program you can describe by what you did, who you worked with and what happened. Selection scaffold: pick one program where several teams depended on you, with a named stake and a clear result; if no such program comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Define and track product metrics and operating cadences (role-family, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a metric you can explain end to end: how it was counted, what it is sensitive to, which part was yours. Selection scaffold: pick one figure you can defend under a second question; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Design and improve processes and tooling for how product teams work (role-family, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a process or tool you changed, with the before and after in your own terms. Selection scaffold: pick one change you made to how a team worked and who adopted it; if no such change comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Influence stakeholders and reach decisions without direct authority (role-family, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a decision you moved where you owned neither side. Selection scaffold: pick one moment with a named stake and an intact relationship at the end; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Prioritize and structure work under ambiguity (role-family, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a case where the brief was unclear and you chose a structure. Selection scaffold: pick one ambiguous brief and how you decided what to do first; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Communicate clearly with leadership, in writing and aloud (role-family, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a recommendation you put to senior people and what came of it. Selection scaffold: pick one such moment, including one where the message was unwelcome; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

## Requirement coverage

| Requirement | Questions that cover it |
|---|---|
| F1 launches and cross-functional programs | A1, A3, E1 |
| F2 metrics and operating cadences | A2, A4, D1, D2, D3 |
| F3 process and tooling | A1, A4 |
| F4 influence without authority | A3, C3, E1, E2, F3 |
| F5 prioritizing under ambiguity | A1, A4, B3 |
| F6 communicating with leadership | C1, F1, G1 |

Not covered, and why: specific tools or methods. No JD names any, so none are invented here.

## Persona table

No loop source established how this final round is run, so the fallback archetype is Generic and the weights are close to flat. That is a pattern, not Stripe's documented process. If your final is several back-to-back sessions, send the schedule and the weights can be set per session.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (bank A, 5 questions) | A live problem on how product teams run: diagnose, design, prioritize | Highest. Operations roles are scored on structure, and a final round typically includes a hiring manager or senior leader who sets a problem. This is a prior, not a finding about Stripe | Clarify, objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully |
| Skeptic (bank B, 4 questions) | Quiet probing of gaps, motivation and day-one weaknesses | High. A final round is where remaining doubts get tested, and your gaps are unknown to me, so the probe is generic | Rehearse the single most predictable objection until it is boring. Use only adjacent evidence you actually have, plus a concrete ramp plan |
| Values / Behavioral (bank C, 3 questions) | Scenario questions scored against published values | Medium. I could not read Stripe's published values, so these use common themes, not Stripe's own names | One story per theme where your material has one. Use "we" for context and "I" for contribution |
| Data-Driven Prober (bank D, 3 questions) | Numbers probed two levels deep | Medium. Operations work is metric-heavy, so any figure you give will be pressed | Know how each figure was counted and say plainly when you do not |
| Peer Evaluator (bank E, 3 questions) | Seam-splitting with adjacent teams and credit-sharing | Medium. Likely if one session is with a product or program peer | Reciprocity: say what you bring their team. Propose seam principles, not a pretended seam |
| Pressure (bank F, 3 questions) | Time-boxed, devil's-advocate challenges | Lower. More likely from a skip-level or senior leader | Pause, restate, hold through two follow-ups, then concede only what is true |
| Conversational (bank G, 2 questions) | Friendly, loosely structured openers | Lower in a final round, but still scored | Prepare a 90-second arc. Treat casual questions as scored |

## Question banks

Guidance cells name no events, numbers or practices from your past, because no material about your past was provided. Each is a structure or a selection scaffold that ends in an honest branch.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Product teams are shipping faster than the launch process can handle. What do you need to know first, and how would you structure fixing it?" | CASE | [generic] | Ask what is breaking and for whom before structuring. Then state the objective, segment the problem (planning, readiness, communication, post-launch), propose an approach, name the metrics, and flag risks. Challenge one premise, such as whether process is really the bottleneck | A live problem from the role family (F1, F3, F5). CASE because it scores structure, not a right answer |
| A2 | "A key product metric dropped 20 percent week over week. Diagnose it." | CASE | [generic] | Check definition and instrumentation first, then timing, segments and recent changes, then candidate causes ranked by likelihood and cost to test. Say what you would ask for and in what order | F2 in a live setting. Diagnosis cases are a standard operations probe, labeled generic because no Stripe metric is used |
| A3 | "Two product teams want the same engineering quarter for conflicting priorities, and you own neither. How do you get to a decision?" | CASE | [generic] | Establish facts and shared criteria, identify who actually decides, propose options with their costs, agree the escalation path, and record the outcome. Say how you keep both teams bought in | F1 and F4 together. CASE delivery of an influence-without-authority question |
| A4 | "Design the operating cadence for a product organization. What meetings and artifacts do you set up, and what do you cut?" | CASE | [generic] | Ask the size and stage of the organization first, since the answer depends on it. Then give principles (decisions over updates, one source of truth) and name what you would cut and why | F2, F3 and F5. The clarifying question is the scored move |
| A5 | "Why Stripe, and what would you want this role to change in your first six months?" | CO | [generic] | Use only reasons from material you have actually read, such as the company's own pages or product. This pack supplies no Stripe facts, so none are scripted. If you have not yet read enough to answer specifically, say so plainly, and prepare two reasons before the interview | CO because it tests homework. Generic because research was unavailable, which is the honest cost of that |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | The highest-ROI rehearsal in this pack. Name one real gap plainly, then say the nearest thing your material does carry, or how you would close the gap, with a concrete first-90-days step. Hold through two follow-ups ("that sounds significant", "why take the risk?") by returning to what is true, never by adding to it. Concede exactly what is real and no more. If no gap comes to mind, say what you would want to learn first | The objection every candidate meets in some form, so a boring honest answer changes the interview. JD because it scores the role's stated demands, gaps included |
| B2 | "Why this move, and why now?" | EXP | [generic] | Give your real reason in one or two sentences, consistent with the arc of your actual history. If there is no single clear reason, say so plainly and give the honest mix | Motivation consistency is the Skeptic's core score. EXP because it tests whether your story holds together |
| B3 | "What would make you fail in this role?" | JD | [generic] | Name a realistic risk and what you would do to catch it early. A risk with a mitigation reads as self-knowledge, and a risk with none reads as a gap | F5 under uncertainty. JD because it probes role demands |
| B4 | "What would make you say no to this role?" | CO | [generic] | State your genuine non-negotiables, if any, without bluffing. If you have none, say what you would want to understand first | Tests fit and honesty. CO because the answer shows what you know of the work |

### C. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not soften the message, and a relationship still intact at the end. Use "I" for what you said and did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F6. Stem from the Values persona. Choose a story where the hard truth actually landed |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a case where the two truly conflicted, say what you weighed and what you chose. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Stem from the Values persona. Generic because Stripe's published values were not read |
| C3 | "Tell me about a time you disagreed with a partner team. How did it end?" | VAL | [generic] | Selection scaffold: pick a disagreement where you showed both spine and tact, and say what you did and what resulted. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4. Theme from the Peer persona's disagreement stem |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Pick a number from your recent work that you are proud of. Walk me through how it was counted." | EXP | [generic] | Choose a figure you can defend. Answer in your own words: how it was counted, what it is sensitive to, and which part was yours. If you do not know how it was counted, say so plainly | F2. The candidate chooses the figure, so nothing is presupposed |
| D2 | "Follow-up to D1: which assumption behind that number would you defend least?" | EXP | [generic] | Name the weakest assumption you actually know of, before they do. If you do not know of one, say so plainly and say how you would test it | The weakest-assumption move converts a gotcha into credibility |
| D3 | "What would you track to know a launch process is working, and how would you know the metrics are not being gamed?" | JD | [generic] | Structure: outcome metrics, leading indicators, a counter-metric, and a periodic spot-check of the underlying work. Say which you would start with | F2 as a design question, so it presupposes no past |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles (who owns the decision, who is consulted, how disputes escalate) rather than pretending to know the real seam. Offer what you bring their team | F1 and F4. Reciprocity framing is the scored move |
| E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick an instance where credit was shared or contested and say what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Stem from the Peer persona |
| E3 | "What would you need from me in your first month?" | JD | [generic] | Name two or three concrete asks, and pair each with what you would give back | Peers price what the hire adds to their load |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, then give three beats in your own words, each one a fact from your real material. Hold through the follow-up, and concede what you do not know about the team's context | Stem from the Pressure persona. Scores composure |
| F2 | "Think of a result you have owned. How much of it was actually you?" | EXP | [generic] | Say plainly what was yours and what was the team's, in that order. Hold your claim through two follow-ups, concede specifics you cannot support, and never fold on the core | An attribution probe. Honest precision is the rehearsal |
| F3 | "Product teams often see operations as overhead. Convince me you are not." | JD | [generic] | Acknowledge the concern as fair, then say how you would earn trust: start with a team's own problem, show a result they care about, and remove work rather than adding it | F4. Scores whether you stay non-defensive |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | Prepare a 90-second arc from your own CV: where you started, one or two turning points, why this role next. Every beat should be something you can back up | F6. Casual openers are scored on economy |
| G2 | "What have you been reading or trying lately that bears on this work?" | JD | [generic] | Have one real answer ready. If you have not been following anything relevant, say so plainly and say what you would pick up first | Tests genuine interest, asked casually |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would a successful first six months look like, and how would you measure it?" | Shows you think in outcomes, and gives you the scoring sheet |
| 2 | "What is the hardest thing product teams currently struggle with in how they work, that this role would touch?" | Surfaces the real problem behind the title |
| 3 | "When teams disagree on priorities, how does this role get involved and where does it stop?" | Tests the role's authority and the seam, in a way that signals you have thought about influence without authority |
| 4 | "What have people in this role done that you wish they had done earlier?" | Invites candor and shows you plan to start fast |
| 5 | "What has changed in how this team works over the last year, and what has not?" | Shows curiosity about direction, not just status |
| 6 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity question for a peer session. Converts evaluation into collaboration |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Any specific claim about your past experience, such as a result, a figure, a team size or a title | No CV or background was provided, so nothing in this pack is traceable to your history | Every history question is a selection scaffold. Say only what you actually did, in your own words |
| Any fact about Stripe's values, products, strategy, leadership or interview process | Web research was refused, and these facts are not taken from memory | Say only what you have read yourself, and say so plainly where you have not |

## Sources

Provided documents: none. No JD, CV, interviewer profile or dossier was supplied.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

Searches sent, each refused for lack of permission and none returned a result:

- `Stripe operating principles values` — refused
- `Stripe interview process product operations manager` — refused
- `Stripe strategy news 2026` — refused
- `Stripe Product Operations Manager job description` — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | Would have set the values themes by name for bank C. Bank C uses persona stems instead |
| 2. `Stripe interview process product operations` | unavailable | Would have named the final round's sessions and set persona weights. Weights are near flat, from the Generic archetype |
| 3. `Stripe strategy` / recent news | unavailable | Would have grounded a CO question in current strategy. A5 and B4 are generic |
| 4. `{interviewer name} Stripe` | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. representative `Product Operations Manager` JD | unavailable | Would have set the fit snapshot's requirements from a real posting. They are role-family prose labeled generic |

## Upgrade menu

- Your CV or a few lines of your background → the six fit rows move from `none given` to quoted evidence, the guidance becomes story-mapped where your sentences carry a story, and the prohibited list can name the exact wording to avoid
- The job description text → the six role-family rows become quoted requirements, and any tool or method it names gets its own question
- The interviewer's name and role, or the session schedule → persona weights set per session, an interviewer read, and a reverse question tied to their path
- The recruiter's prep notes → coverage of any focus area or pre-declared deliverable, which gets its own build section
- Permission to search the web → Stripe's published values, loop structure and current strategy replace the generic rows in banks A and C. A deeper pass would add up to 6 more searches and 2 more fetches and take several more minutes
- A saved `tuesday-dossier.md` from an earlier session → verified evidence and prohibited claims arrive ready to use, though this pack works without one
