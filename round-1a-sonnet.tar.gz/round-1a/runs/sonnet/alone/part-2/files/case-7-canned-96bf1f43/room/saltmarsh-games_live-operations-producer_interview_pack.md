# Interview pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed: the hiring manager, because the careers page puts the hiring manager in the one 60-minute interview it describes. Your note did not say, so this is an assumption.
**Round:** the 60-minute interview on Friday. The careers page calls it the Outage Hour: a live-incident tabletop, then a values conversation.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Every answer-guidance cell is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether your CV claims survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company's strategy and can think at its altitude |
| CASE | Structure and reasoning on a live problem from the role |

## Prep triage

Three days, in this order:

1. **Tuesday:** C1 (the highest-ROI prep in this pack), then C2. Say each out loud until the plain acknowledgment sounds boring.
2. **Wednesday:** A1, A3 and A5 out loud against a clock. Then pick the stories for B1 to B4 using the scaffolds.
3. **Thursday:** D1 (decide what you can and cannot say about how the retention numbers were counted), E1, and the reverse questions.

Everything else in the pack is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message | medium | [grounded] | discovery | A years requirement is not a gate, so it is graded like any other row. Your material gives the years and the title "associate producer", not whether the game was live-service. Answer slot: the JD says producing, so expect a probe on both. If the main title ran ongoing updates, say how, in your own words; if it did not, or your role sat below producer, say so plainly and stay with the four years |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap, but a message line with nothing inspected behind it, so expect a probe. Lead with the quote's own terms: weekly, content-drop, main title, two years |
| F3 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for one main title, not timed live events and not two titles, and the words stay at that scope. Answer slot: if any part of the calendar involved timed events or more than one title, say how, in your own words; if none did, say so plainly and stay with the calendar you ran |
| F4 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show this either way. Answer slot: if you coordinated across those disciplines on the drops, say who and how, in your own words; if you did not, or one of them was not part of your drops, say so plainly and describe how you would do it |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your quote says presented, not owned and not post-event, and the words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose which numbers went into the presentation, say so; if someone else chose them, or no review came with them, say so plainly and stay with the presenting |
| F6 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | The quote already reaches the requirement in other terms: "I wrote the release checklist our QA team still uses." The pack's observation is that your material says wrote and still used, not who ran each release's checklist. This is the row an interviewer with a QA background is most likely to press |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | The quote reaches the requirement in role-relevant terms. A message line with nothing inspected behind it, so expect a probe on how the numbers were counted (D1) |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | low | [inferred] | discovery | Writing a checklist touches this requirement without showing the quality of your writing. Answer slot: name a piece of your own writing you could show or describe if asked; if there is none you can share, say so plainly and say how you would show it |
| F9 | Familiarity with in-app purchase economies on mobile titles: a role-family expectation, not in the JD ([generic]) | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |

## Reading the interviewer

| Public fact | Source | Provenance | Practical implication |
|---|---|---|---|
| Head of Live Operations at Saltmarsh Games; GDC 2026 talk "Patch Notes Are a Promise" | Search result, GDC 2026 talk page | [grounded] | The talk's title and argument say he reads announced versus shipped closely. Be exact about what a release contained and what it did not |
| His argument: a live team is judged by how often its patch notes describe what actually shipped | Same search result | [grounded] | Expect claims about your past to be tested for scope. Hold each claim at the size of your own sentence |
| Previously a QA lead at a console studio | Same search result | [grounded] | The release checklist (F6) is the likeliest place for a close follow-up |

**Mirror opportunity:** his public path runs through QA, and your quoted line is "Wrote the release checklist our QA team still uses" (F6). That shared vocabulary, checklists and QA, is the fair common ground. Do not build on anything else.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | The tabletop: a simulated outage during a live event | **High.** The careers page describes a "live-incident tabletop on a simulated outage during a live event" [grounded] | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud. Challenge one premise respectfully |
| Values / Behavioral | The values conversation | **High.** The same page says the hour ends with "a values conversation", and the values page names three values [grounded] | Map a story to each value where one of your quoted sentences carries one; use a selection scaffold where none does |
| Skeptic | Probing the two gaps you named: no in-app purchases, no team led | **Medium-high.** A hiring manager is derisking, and you stated both gaps yourself (F9) [inferred] | Rehearse C1 until it is boring. Bridge only from your quoted sentences, plus a ramp plan said as a plan |
| Data-Driven Prober | Retention numbers and the release checklist | **Medium.** F7 and F6 are the lines a prober reads closely, and the talk theme points to close reading of claims [inferred] | Know what you can and cannot say about how the numbers were counted, and say plainly where you do not know |
| Pressure | Time-boxing inside the tabletop | **Low-medium.** A simulated outage is time-pressured by design, and no source says the interviewer will interrupt [inferred] | Pause, restate, hold a position through two follow-ups before conceding anything real |
| Conversational | Opening and closing the hour | **Low.** Bookend questions are likely in any round [generic] | A 90-second arc for "walk me through the journey" |
| Peer Evaluator | Not weighted | A hiring-manager round, so no peer seat is expected [inferred] | None needed |

## Question banks

### A. Case / Strategist (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A live event went out forty minutes ago and players are reporting that rewards are not being granted. Support tickets are climbing and the community channel is angry. It is your call. What do you do in the first fifteen minutes?" | CASE | [generic] | Structure it aloud. Clarify first: how many players, which platforms, since when, whether anything changed in the release. Then objective: stop further harm and tell players the truth. Then the order of actions and who you pull in from engineering, QA and community. Then what you would say to players and what you would hold back until it is confirmed. Then what you would review afterward. Make no claim about your past | The Outage Hour is documented as a tabletop on a simulated outage during a live event, so this is the likeliest shape of the first half-hour. CASE because it is a live problem with no past presupposed |
| A2 | "From February our two titles share one events calendar under Project Larkspur. You are handed the first eight weeks. What do you need to know first, and how do you build it?" | CO | [grounded] | Open with clarifying questions: what is fixed already, what each title's players expect, which teams hold constraints. Then objective, then how you would sequence the weeks and which cadence you would protect, then the metrics you would watch, then the risks. Challenge one premise respectfully, for example whether the two audiences should share beats at all. The question needs no claim about your past, so the guidance makes none | The strategy page ties the calendar to a model change, so this is the question that shows you know where the role is going. CO because it needs current company vocabulary, CASE in delivery |
| A3 | "QA tells you two hours before an event goes live that they have found a blocker. Design wants to ship. What happens?" | CASE | [generic] | Clarify the severity and what the blocker affects. Name the decision and who owns it. Set out the options: ship, delay, or ship with the affected piece switched off. Say what you would tell players under the value that says the company announces what is built, not what is hoped. Close with what you would change in the checklist afterwards. Make no claim about your past | Tests the release-checklist half of the JD (F6) under pressure. CASE because the decision is live |
| A4 | "An event's retention looks flat compared with the previous one. How do you work out why?" | CASE | [generic] | Clarify what flat means: which cohort, what window, compared with what. Segment before diagnosing. List hypotheses (content, timing, bugs, comparison group), what evidence each would need, and which you would check first. Name the assumption in your own comparison that you would trust least, before the interviewer does. Make no claim about your past | Tests the metrics half of the JD (F5, F7). The weakest-assumption move is built in because it is a metric question |
| A5 | "Art says the new event assets will be three days late. Engineering's build locks on Thursday, and community has already announced the date. What do you do?" | CASE | [generic] | Clarify what is truly late and what can ship without it. Lay out the options: a cut scope, a delayed date, a partial ship. Say what you would tell community, and when, in line with the value that says players come before plans. Name the cost of each option. Make no claim about your past | Tests cross-team coordination (F4) as a live problem rather than a story you may not have |

### B. Values / Behavioral (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed. Which one won?" | VAL | [grounded] | Selection scaffold, for the value Players Before Plans ("when the calendar and the players disagree, the players win"). Pick a time with a named stake, a moment you chose, and a result you can describe. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Published value 1. No quoted sentence of yours carries a calendar-versus-players moment, so this is a scaffold, not a story map (F2) |
| B2 | "Tell me about a time what was announced and what was built did not match." | VAL | [grounded] | Selection scaffold, for Ship the Patch Not the Promise ("we announce what is built, not what is hoped"). Pick a time where you caught the mismatch or told someone about it; it needs a specific moment and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Published value 2, and the theme of the interviewer's own talk. No quoted sentence carries it, so it is a scaffold |
| B3 | "Tell me about a time a release left your checklist better than it found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Story map on F6: you wrote the release checklist, and your QA team still uses it. Those are the beats the quote states; tell them in your own words. Answer slot: the value says every release leaves the checklist better, so expect a probe on how the checklist changed after a release. If it changed, say how and what part was yours; if it never changed, or the change was not yours, say so plainly and stay with the checklist you wrote | Published value 3, and the one value where your material has a quoted sentence. Verb held at "wrote" |
| B4 | "Tell me about a time you delivered an unwelcome truth." | VAL | [generic] | Selection scaffold. Pick a time with a named stake, a person who did not want to hear it, and a result you can describe. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard values-round prompt and a fair bridge to the announced-versus-built theme. No quote carries it |

### C. Skeptic (weight: medium-high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You have never worked on a game with in-app purchases, and from February our two titles move to a season pass. How would you get up to speed?" | JD | [grounded] "never worked on a game with in-app purchases" | **The highest-ROI prep in this pack.** Hold the limit as the quote states it: "I've never worked on a game with in-app purchases." Then give a plan, said as a plan: the first things you would learn and who you would ask, in your own words. Hold the same answer through two follow-ups by returning to the plan, never by adding to your past. Concede specifically if pressed: the monetisation side is new to you | F9 is the gap you named, and the Larkspur season-pass move makes it likely this question arrives in some form. JD because it scores a role expectation, not a stated requirement |
| C2 | "You have never led a team. Part of this role is getting design, art, engineering and community aligned on each update. Where does your authority come from?" | JD | [grounded] "Never led a team" | Plain acknowledgment: "I've never led a team." The JD line asks for coordination, not management, so stay with coordination. Answer slot: if you coordinated across disciplines on your drops, say who and how you handled a disagreement, in your own words; if you did not, or the coordination was not yours, say so plainly and describe how you would build agreement | F4 is a discovery row and this is the probe on it. JD because the line is in the posting |
| C3 | "You ran one title's calendar. We have two, and from February one shared calendar. What changes for you?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Hold at scope: "I ran the weekly content-drop calendar for our main title for the last two years." Then say plainly what is different, in your own words, and what you would do first. Answer slot: if any of your drops touched a second title or a shared dependency, say how; if none did, say so plainly and stay with the calendar you ran | F3 is a transferability row: one title, content drops. This is where the scope difference gets tested |

### D. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You presented monthly retention numbers to the studio head. Walk me through how those were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Defend-the-number slots, each in your own words: how the retention figure was counted, what it is most sensitive to, the assumption behind it you would defend least, and which part of the work was yours. If you do not know how it was counted, say so plainly; that is an honest answer. Never describe a method you did not use | F7 is the CV line a prober reads first. The weakest-assumption move is built in |
| D2 | "When have you checked release notes against what actually shipped?" | VAL | [grounded] | Selection scaffold, tied to Ship the Patch Not the Promise. Pick a specific release where you compared the two and something differed; name what you did about it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The interviewer's published talk theme and the second value. Open prompt, so it presupposes no event |
| D3 | "Which KPIs go in a post-event review, and what would you refuse to report?" | JD | [generic] | Structure: the decision the review should inform, the three or four measures you would put first, and why. Then what you would leave out and why, naming the weakest assumption in your most important measure. Make no claim about your past | Covers the post-event review clause (F5) as a role question, not an experience question |

### E. Pressure (weight: low-medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has run a monetised live game?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "never worked on a game with in-app purchases" | Pause, restate, answer once. Hold: four years as an associate producer at a puzzle-game studio, and the weekly content-drop calendar for your main title for the last two years. Concede plainly: "I've never worked on a game with in-app purchases." Do not add to the held claim under pressure | F1, F2 and F9 together. JD because it scores fit against the posting. Hold-then-concede structure built in |
| E2 | "That calendar: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Hold the verb the quote carries: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: say which parts were yours to set and which were set for you; if the content priorities came from someone else, say so plainly and describe how you ran the calendar around them. The honest branch is a limit, not a confession | F2 is where attribution is tested. EXP because it probes what was actually yours |

### F. Conversational (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Walk me through the journey. How did you get into live operations?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" | A 90-second arc with only the beats your quote states: the four years, the role of associate producer, the puzzle-game studio. Answer slot: why live operations at a mobile studio now. Give any reason that is true; if no reason comes to mind, say so plainly | F1. The casual register is still scored |
| F2 | "What are you playing at the moment, and what would you change about its events?" | JD | [generic] | Name a live game you actually play, and one honest observation about its events. Make no claim about your past | A casual question on a topic the JD flags. Pick a game you really play |

## Values cheat sheet

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | No quoted sentence carries it (F2 is a calendar, not a disagreement). Selection scaffold: pick a time you chose players over a plan, with a named stake. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | No quoted sentence carries it. Selection scaffold: pick a time you corrected or declined an announcement. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F6: "Wrote the release checklist our QA team still uses". Beats are the quote's own; anything about how it changed after a release is an answer slot (B3) |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "With per-title event teams retiring into one live-ops group from February, where would this role sit, and which calendar would I inherit first?" | Shows you read the Larkspur announcement and are thinking about the job as it will be, not as it was posted |
| 2 | "Your GDC talk argued that a live team is judged by whether its patch notes match what shipped. What do you track here for that, and where is the team today?" | Ties to his own published argument and asks for something he can answer honestly |
| 3 | "You came to live operations through QA. What from QA do you still use every week?" | Tied to his own public path, and it opens the checklist conversation on his ground |
| 4 | "What does a good post-event review look like here, and which KPIs must it report?" | Asks about the clause you would own and shows you think in outcomes |
| 5 | "What is the fastest way for someone new to a season-pass model to get fluent here?" | Turns the monetisation gap into a ramp conversation instead of waiting for the objection |
| 6 | "What should I have changed in the release checklist by day ninety?" | Ties to the third value and signals you would leave the build greener |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team | A negative you stated: "Never led a team" — your message | "I've never led a team." The JD asks for coordination, and C2's slot stays with coordination |
| Has worked on in-app purchases or monetised events | A negative you stated: "never worked on a game with in-app purchases" — your message | "I've never worked on a game with in-app purchases." Then a plan, said as a plan. No slot on what monetisation work involved |
| Ran the live-events calendar for two titles | Inflated form of F3 | F3's quote at its own scope: a weekly content-drop calendar for one main title. The limit is the pack's observation, not words for you |
| Owned the post-event review and its KPIs | Inflated form of F5 | F5's quote at its own scope: "I presented the monthly retention numbers to the studio head." C-bank and D-bank slots stay inside the presenting |
| Managed the release process with QA | Inflated form of F6 | F6's quote at its own scope: you wrote the checklist QA still uses. The pack's observation is that the quote says wrote, not ran |

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| "3+ years producing live-service games or apps" | E1, F1 |
| "experience running a content calendar" | C3, E2, A2 |
| "Plan and run the live-events calendar for two of our mobile titles" | A2, C3 |
| "coordinate design, art, engineering and community teams on each update" | A3, A5, C2 |
| "own the post-event review and the KPIs it reports" | A4, D3 |
| "manage the release checklist with QA" | A3, B3 |
| "comfortable with player-retention metrics" | A4, D1 |
| "clear written communication" | none, and why: no question is likely to score writing directly in a live conversation; F8's slot is the preparation, and you can bring a piece of writing if you have one |

## Sources

**Provided documents:** the JD text, and your message about your background.

**Searches sent:**

- "Saltmarsh Games values" → https://saltmarshgames.com/values
- "Saltmarsh Games interview process live operations producer" → https://saltmarshgames.com/careers/interviewing
- "Saltmarsh Games strategy news mobile" → https://saltmarshgames.com/news/project-larkspur
- "Tobias Wrenfield Saltmarsh Games" → https://talks.gdconf.example/2026/patch-notes-are-a-promise

**Fetches sent:** https://saltmarshgames.com/values and https://saltmarshgames.com/careers/interviewing, both read in full. The Larkspur announcement and the GDC talk page were read as search-result snippets only.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet and B1 to B4: three values by name |
| 2. `Saltmarsh Games interview process live operations producer` | yes | Loop structure: one 60-minute hiring-manager session, tabletop then values; persona weights and the detected values round follow it |
| 3. `Saltmarsh Games strategy news mobile` | yes | A2, C1, C3 and reverse questions 1 and 5 (Project Larkspur, September 2026). Snippet only |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | Interviewer read, D2 and reverse questions 2 and 3. Snippet only |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Whether Tobias is your future manager, and anything the recruiter said about the tabletop (which title it uses, tooling, who else is in the room) → reweights the persona table and sharpens A1 to A5
- Your answers to the answer slots in F1, F3, F4, F5, F6 and F8 → the rows they draw on become quoted evidence and the matching banks regenerate
- Whether the main title at your studio was a live-service game with ongoing updates → settles F1
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a grounding brief on the Larkspur move and a full read of the GDC talk
- A `tuesday-dossier.md` from a job-underwriter run → verified evidence for the medium-confidence rows and a sharper take on the objection worth the most rehearsal
