# Interview pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Three rounds on 26 November 2026, so this is a loop pack: one shared fit snapshot, then a mini-pack per round.

| Round | Who | Length | Persona weights rest on |
|---|---|---|---|
| 1 | The recruiter | 30 minutes | Recruiter-screen prior |
| 2 | Head of Member Services, your future manager | 45 minutes, "mostly behavioural" | Hiring-manager prior, adjusted by the recruiter's description |
| 3 | Panel of two branch managers, including a 20-minute case on a complaint escalation; also the values round, scored against the four values | 60 minutes | The recruiter's description of the panel |

No interviewer names have been assigned, so there is no interviewer read. Round structure comes from the recruiter's email, which is a loop source.

## How to use this pack

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows one of Ashgrove's published values |
| EXP | Whether your own background survives a closer look, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know Ashgrove's strategy and can think at its level |
| CASE | A live problem: structure and reasoning |

Question IDs run by persona sub-table: A and B for round 1, C to F for round 2, G to I for round 3. Labels in square brackets say where a claim comes from: grounded in something you or Ashgrove supplied, inferred from it, or a generic pattern. An answer slot is an instruction for the interview, never a question for this chat. Where a slot has two branches, "no such step, or it was not mine" is a fully acceptable answer.

All three rounds fall on the same day. Keep your account of each of your own sentences identical from one round to the next.

The single highest-ROI rehearsal in this pack is **D1**, the scope objection: you would own the process across every branch and the contact centre, and your material is the branch log. It will be asked in some form. Rehearse it until the concession is boring.

## Prep triage (17 to 25 November)

| Order | When | Do | Tied to |
|---|---|---|---|
| 1 | 17 to 18 Nov | Write a few honest lines for each answer slot on F1, F3, F4, F5 and F7. "There was no such step" is a valid answer. | Fit snapshot; feeds D1, E1, C1, F1, B3 |
| 2 | By 20 Nov | Say D1 aloud, with all three follow-up levels, until the concession wording stops costing you anything. | D1, D4 |
| 3 | By 22 Nov | For round 3, the scored round: choose or consciously skip a story for each of the four values, then say the case structure aloud on H1 to H3. | G1 to G5, H1 to H3, values cheat sheet |
| 4 | By 24 Nov | Settle your real answers on reason for leaving, notice, pay and location, and time A1 to 90 seconds. | A1, A3 to A6 |
| 5 | 25 Nov | One run of the reporting and presenting answers: the spreadsheet, the monthly report, presenting upward. | E1, E2, D3 |

Everything else is insurance.

## Fit snapshot

Your evidence cells hold only your own words, from your message. None of the JD requirements is a gate: the 4+ years line is experience, not a legal or credential bar.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says the branch's log, not a process across branches, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on which parts of the log handling were yours to decide likely. If any were, say which and how you decided, in your own words; if none were, or there was no such decision, say so plainly and describe how you handled the log |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The quote shows a monthly complaints spreadsheet that your regional manager uses; the material does not show what it counted. Answer slot: the JD names volumes and resolution times, so expect a probe on what yours held. If it held either, say how it was counted and which assumption behind it you would defend least; if it held something else, or did not record how long cases took, say so plainly and describe what it did hold |
| F4 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | The quote says new tellers and a script, not supervisors, and the words stay there: "I trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on whether the script's use ever needed more than the training likely. If a teller or another supervisor struggled and you helped, say what happened and what part was yours; if not, say so plainly and stay with the training |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not mention digital work. Answer slot: the JD raises it, so expect a probe. If you have worked with an online or app team on anything members use themselves, say what and what your part was; if you have not, say so plainly and say what you would ask them first |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap, but self-reported with nothing inspected behind it. Lead with it in its own terms: six years in retail banking, the last three as a branch supervisor |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | The quote says a formal log; the material does not show whether external rules governed it. Answer slot: the JD says regulated, so expect a probe. If external rules applied, name them as you know them and say what your part was; if you are not sure, or it was an internal log, say so plainly and stay with the log you handled |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Then how you would prepare for a first leadership presentation, said as a plan and never as a past |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | presentation | The quote already reaches the requirement in other terms; say it in its own words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the quote says spreadsheet, the JD says Excel. If it was Excel, say so; if it was another tool, name that tool, and say plainly how comfortable you are in it |

## Grounding brief

From the 2026 strategy brief the recruiter sent (published July 2026), as you summarised it. The Source wording column quotes your summary; the implication is this pack's reading.

| Move | Source wording | Implication for your answers | Provenance |
|---|---|---|---|
| Digital shift | "move 40% of member service to digital channels by 2028" | Matches the JD's self-service line; expect probes on which complaints belong in digital and which do not (F1 and F2 in the round 2 bank) | [inferred] |
| Hub consolidation | "consolidate eight branches into five hubs over 2027" | The round 3 panel is branch managers; expect hub and "Neighbours, Not Numbers" angles (H3, G3) | [inferred] |
| New product | "launch a small-business lending product in Q1 2027" | A new product is a new thing members can complain about; a topic to ask about, not a claim about what will happen | [inferred] |
| Competitive frame | "the main competitive pressure is app-only banks" | Useful when explaining why self-service must work and why a member leaving matters (F2, H1) | [inferred] |

The brief is about four months old, inside the window where strategy is still current. You summarised it; the full document would let this section carry exact wording (upgrade menu).

## Requirement coverage

| Requirement | Questions |
|---|---|
| "Own the member complaints process end to end" | D1, D4, H1, H2 |
| "across branches and the contact centre" | B1, D1, D2 |
| "report monthly on complaint volumes and resolution times" | E1, E2 |
| "coach branch supervisors on escalations" | C1, H2, I1, I2 |
| "work with digital teams on self-service journeys" | F1, F2 |
| "4+ years in financial-services customer operations" | A1 |
| "experience handling regulated complaints" | B3 |
| "confident presenting to senior leaders" | D3, C2 |
| "comfortable with Excel reporting" | E1, E2 |
| Values: Members First, Always | G1, G5, H1 |
| Values: Plain Words | G2, F2 |
| Values: Neighbours, Not Numbers | G3, H3 |
| Values: Own the Fix | G4, H1 |

---

# Round 1: the recruiter (30 minutes)

## Persona table, round 1

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly, unstructured; journey, motivation, pay, notice, location, reason for leaving | High. The recruiter-screen prior is Conversational plus a light Skeptic, and the recruiter's own words describe 30 minutes "with me" | A pre-rehearsed 90-second arc; treat every casual question as scored; give real, own answers on logistics |
| Skeptic (light) | Knockout checks on the JD's two obvious pressure points | Medium. The JD names the contact centre and regulated complaints, and F2 is a limit you have stated | Say the limit plainly in one sentence, then give the plan; do not over-explain |

## Question bank, round 1

### A: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" "I handled the branch's formal complaints log" "trained new tellers on our escalation script" "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped, 90 seconds, in your own words, using only these beats: six years in retail banking; the last three as a branch supervisor; the branch's formal complaints log you handled; the new tellers you trained on the escalation script; the monthly complaints spreadsheet you built that your regional manager uses. Close with why this role, in your own words, tied to one line of the JD | The opening question is scored for economy; F6 is the years requirement and F1, F3, F4 are the rows the arc touches; EXP because it tests what you will stand behind |
| A2 | "What draws you to this role at Ashgrove?" | CO | [grounded] | Choose one JD line and one of the four published values you can honestly say something about, and say why it fits you in your own words. The values are Ashgrove's wording, for instance "Own the Fix — whoever finds the problem keeps hold of it until it is solved." One strategy fact is enough if it genuinely connects: the brief's digital shift or the competition from app-only banks. Make no claim about your past beyond what A1 carries | Motivation-consistency check; CO because it tests homework on a published values page and brief |
| A3 | "What's prompting you to look at a move now?" | EXP | [generic] | Logistics slot: give your actual reason in your own words, in a sentence or two. Say what you are moving toward rather than what you are leaving, and do not name colleagues. If part of the reason is not about this role, say so plainly | The recruiter-screen row for reason for leaving; EXP because the reason is scored for consistency with the rest of your story |
| A4 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period, and any flexibility only if it is real | The listed job's terms; a recruiter needs this to plan |
| A5 | "What salary are you looking for?" | JD | [generic] | Logistics slot: give your own number, or ask for the role's band first and respond to it. Either way, a figure only if it is yours | The listed job's terms; the only safe answer is your own |
| A6 | "Where would you be able to work from, and how often?" | JD | [grounded] | Logistics slot: give your real constraints in your own words. It is also reasonable to ask which site the role is based at, since the brief says eight branches become five hubs over 2027 | The listed job's terms; the brief's hub plan is the reason the site question is worth asking |

### B: Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role covers the contact centre as well as branches. What's your experience there?" | JD | [grounded] "Never worked in a contact centre" | Say it plainly, once: "I've never worked in a contact centre." Then a plan in the future tense, in your own words: what you would ask to see first and whom you would ask. Do not follow the limit with a bridge you cannot quote | F2 is a stated limit; JD because it scores the requirement. A short, calm answer is what the screen is checking for |
| B2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" "I've never presented to anyone above regional level." | Choose one of your own stated limits and say it in those words, then say how you would close it, as a plan. Do not minimise it and do not list every gap | F2 and F8 are the two limits you stated; Skeptic stem, JD tag |
| B3 | "The role needs experience handling regulated complaints. What have you handled?" | JD | [grounded] "I handled the branch's formal complaints log" | Lead with the quote's own words: you handled the branch's formal complaints log. Answer slot: the JD says regulated, so expect a probe on whether external rules governed the log. If they did, name the rules as you know them and say what your part was; if you are not sure, or it was an internal log, say so plainly and stay with the log you handled | F7 is the requirement a recruiter screens for; the quote touches it without showing whether it reaches it |

### Reverse questions, round 1

| # | Ask | Why it lands |
|---|---|---|
| 1 | "What will the 45-minute conversation with the Head of Member Services focus on, and is there anything you'd suggest I bring?" | It uses the recruiter's own guidance and shows you are preparing for the next step |
| 2 | "For the panel's 20-minute escalation case, is the material given on the day or sent beforehand?" | The case format is unknown, and the recruiter can usually say |
| 3 | "Which site would the role be based at, given the move from eight branches to five hubs?" | Ties a practical question to the brief |
| 4 | "How are branch and contact-centre complaints handled today, and who would I work with in each?" | Shows you are thinking about the end-to-end scope the JD names |
| 5 | "What does this role's first monthly report need to show to land well?" | Uses the JD's reporting line to ask about success |

---

# Round 2: the Head of Member Services (45 minutes)

## Persona table, round 2

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Past-behaviour questions: coaching, difficult messages | High. The recruiter calls this round "mostly behavioural" | Pick stories your own quoted sentences carry; "we" for context, "I" for what you did |
| Skeptic | Quiet probing of the contact centre, scope and presenting gaps | High. The hiring-manager prior includes the Skeptic, and F2 and F8 are limits you have stated | Say the limit plainly, hold what your sentences carry, then give a plan |
| Data-Driven Prober | Walk-through of your spreadsheet and how a report would be trusted | Medium. The JD's monthly-reporting line and your spreadsheet are the one artifact a manager can ask about | Say what it held and how it was counted, or say plainly that you do not know |
| Case / Strategist | Live problems on the manager's own roadmap, such as digital self-service | Medium to low. The hiring-manager prior puts it high, but "mostly behavioural" pulls it down | Clarify first, then structure, then answer; challenge one premise respectfully |

## Question bank, round 2

### C: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you coached someone through an escalation." | JD | [grounded] "trained new tellers on our escalation script" | Story-mapped on F4 at its own scope: new tellers, the escalation script, you trained them. Answer slot: the JD's coaching line makes a probe on one person who found it hard likely. If a teller or another supervisor struggled and you helped, say what happened and what part was yours, in your own words; if there was no such moment, say so plainly and stay with the training you gave | F4 is the evidence for the JD's coaching line; JD because it scores the stated responsibility |
| C2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not fold, and a relationship that was intact afterwards. Keep "leadership" at the level it really was, since your material states a limit on presenting upward. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F8 is the row this probes; persona stem, VAL because it scores whether the hard truth actually landed |

### D: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "This role owns complaints across every branch and the contact centre. You've handled the branch's log. What makes you ready for that scope?" | JD | [grounded] "I handled the branch's formal complaints log" "Never worked in a contact centre" "I built the monthly complaints spreadsheet our regional manager uses." "trained new tellers on our escalation script" | **Highest-ROI rehearsal.** Say your limit before it is asked for: your material is the branch's log and no contact centre. Level 0, hold: "I handled the branch's formal complaints log." Concede specifically: "I've never worked in a contact centre." Then a plan in your own words for your first weeks. Follow-up 1, "so you've never owned anything across branches": return to the log, never add to it. Answer slot: if any part of the log handling was yours to decide, say which and how you decided; if none was, or there was no such decision, say so plainly and describe how you handled the log. Follow-up 2, "what would you get wrong first": name, in your own words, the thing you do not yet know about the contact centre. Follow-up 3, "why should we believe it would scale": do not add evidence. Return to what you built, "I built the monthly complaints spreadsheet our regional manager uses", and to the training, "I trained new tellers on our escalation script", each at its own scope, and say you would learn the rest. Hold the position through two follow-ups; concede the contact centre without conceding that you can learn it | F1 and F2 are the biggest gap and the most predictable objection; JD with Skeptic delivery. Deepest means the most follow-up levels and the exact concession wording, never more claim than the quotes carry |
| D2 | "What do you think is different about handling a complaint in a contact centre?" | JD | [grounded] "Never worked in a contact centre" | Open with the plain acknowledgment: "I've never worked in a contact centre." Do not assert differences you do not know. Offer what you would ask contact-centre colleagues first, as questions, in your own words, and label any guess as a guess | F2; a candid, curious answer is what this probe scores |
| D3 | "Monthly reporting goes to senior leaders. How comfortable are you presenting at that level?" | JD | [grounded] "I've never presented to anyone above regional level." | Hold-then-concede. Concede the fact in its own words: "I've never presented to anyone above regional level." Do not claim confidence you have not stated. Then a plan in your own words for a first presentation: what you would ask the audience, and what you would want reviewed beforehand. Offer to walk your manager through a draft | F8 is a stated limit; JD because the requirement is explicit, Skeptic because it goes straight at the gap |
| D4 | "Sixty seconds: why you over a candidate who has run a contact centre team?" | JD | [grounded] "I handled the branch's formal complaints log" "I built the monthly complaints spreadsheet our regional manager uses." "Never worked in a contact centre" | Time-boxed, hold-then-concede. Hold only what the quotes carry: the branch's formal complaints log you handled, and the monthly complaints spreadsheet you built that your regional manager uses. Concede: "I've never worked in a contact centre." Do not claim to be stronger than that candidate | A pressure-flavoured form of D1; F1, F2 and F3 are the rows it draws on |

### E: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped at the quote's scope: you built it, it is monthly, it is about complaints, and your regional manager uses it. Answer slot: the JD names volumes and resolution times, so expect a probe on what yours held and how each figure was counted. If it held either, say how it was counted, what it is sensitive to and which assumption behind it you would defend least; if it held something else, or did not record how long cases took, say so plainly and describe what it did hold. The JD also names Excel: say which tool it was, as it was | F3 and F9; the only artifact in your material, so the likeliest place to be probed |
| E2 | "What would a monthly complaints report for senior leaders contain, and how would you know the numbers could be trusted?" | CASE | [generic] | Structure it aloud: who reads it and what decisions they take from it; define the terms first, such as what counts as a complaint and when a case opens and closes; the few measures the JD names, volumes and resolution times, cut by branch and channel; the checks that make a figure trustworthy; the caveats. Use an example from your own spreadsheet only if you have answered E1's slot. The question needs no claim about your past | The JD's reporting line asked as a design problem rather than a record; CASE delivery, JD content |

### F: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Have you worked with digital teams on anything members use themselves?" | JD | [grounded] | Answer slot: if you have worked with an online or app team on anything members use themselves, say what, who and what your part was, in your own words; if you have not, say so plainly, then say what you would ask them first. Make no claim about digital work your material does not carry | F5 has no evidence; the JD raises it, so the honest answer needs rehearsing |
| F2 | "Ashgrove wants 40% of member service on digital channels by 2028. Which kinds of complaint would you be slow to move to self-service, and why?" | CASE | [grounded] | Clarify first: what "member service" counts. Then segment by kind of complaint and by what the member is going through; say what makes a journey suited to self-service and what does not. Use the values' own words where they help, for instance "if a member needs it explained twice, we wrote it wrong." Name the competitive reason, app-only banks, for why self-service has to work. Say one premise you would test. The question needs no claim about your past | The brief's digital move asked as a decision; CASE with CO content, and the JD's self-service line |

### Reverse questions, round 2

No interviewer profile exists, so none of these is tied to the interviewer's own path.

| # | Ask | Why it lands |
|---|---|---|
| 1 | "Which complaints take longest to resolve today, and what is your read on why?" | Starts from a real problem, which is the Own the Fix instinct |
| 2 | "How do branches and the contact centre hand a complaint to each other today?" | Goes straight to the end-to-end scope in the JD |
| 3 | "Who are the senior leaders this role reports to, and what decisions do they take from the monthly report?" | Turns the presenting gap into preparation |
| 4 | "Which self-service journeys come first for the 40% goal, and where does complaints data feed in?" | Connects your role to the digital strategy |
| 5 | "How would you want me to learn the contact centre in my first weeks?" | Shows candour about the gap and asks how to close it |

---

# Round 3: the panel of two branch managers (60 minutes, including a 20-minute case)

## Persona table, round 3

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Stories scored against the four published values | Highest. The recruiter says the panel is the values round and scores against the four values | One story or an honest scaffold per value; hard truths that actually landed |
| Case / Strategist | The 20-minute complaint-escalation case | High. A case is stated; its format is not, so the practice cases below are generic | Clarify, objective, segmentation, approach, metrics, risks; say the framework aloud |
| Peer Evaluator | Where the role meets branch management; what you need from them and what you bring | Medium. The panel are branch managers whose supervisors you would coach, so the seam question is likely | Propose seam principles rather than pretending to know the seam |
| Skeptic | Why a branch manager would take your coaching | Low to medium. F4 is adjacent evidence, not direct | Hold what your sentences carry; say the limit plainly |

## Question bank, round 3

### G: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [generic] | Selection scaffold for Members First, Always: pick a time with a named member situation, a decision you made, someone who disagreed or a cost you accepted, and an outcome. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The first of the four published values; open prompt, VAL because it scores a specific decision |
| G2 | "Tell me about a time something had to be explained to a member twice." | VAL | [grounded] "trained new tellers on our escalation script" | Selection scaffold for Plain Words: pick a time with what was said first, what the member needed, what you changed and whether it held. Answer slot: the value is about wording, and your material carries a script you trained tellers on. If the script's wording was ever yours to change, or you changed how you taught it, say what and why, in your own words; if not, say so plainly and use another example. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The value's own test, "if a member needs it explained twice, we wrote it wrong"; F4 is the nearest row, and no quote shows the script's wording was yours |
| G3 | "You built a monthly complaints spreadsheet. How do you stop the numbers hiding the town?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | For Neighbours, Not Numbers, name the tension honestly: figures flatten places. Say what you built in the quote's words. Answer slot: if the spreadsheet ever showed or missed something about one branch or town, say what it was and what you did; if not, say so plainly, then say what you would put beside the numbers, as a plan | F3; the value pits numbers against place, and a values panel will test whether you see it |
| G4 | "Tell me about a complaint you kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | For Own the Fix, the log is your setting and nothing more. Answer slot: if one complaint was yours from first report to close, say what it was, what you did at each step and who else you needed; if none was, or the log was a record rather than cases you worked, say so plainly and describe how you would carry one. Include what it cost you | F1; the value is stated as "whoever finds the problem keeps hold of it until it is solved" |
| G5 | "When did you put a member ahead of an internal target or procedure?" | VAL | [generic] | Selection scaffold, second Members First story: pick a time with a named member, a rule or target you were measured on, a choice and what it cost. Choose one where the hard truth actually landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem for the first value; a values panel often asks two stories on one value |

### H: Case / Strategist

H1 and H2 are practice cases written for this pack. They are not the panel's actual case, whose format is not yet known.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "A member has complained at their branch twice and once through the contact centre, and now says they are leaving for an app-only bank. What do you do, and in what order?" | CASE | [generic] | Clarify first: what each channel recorded, what the member wants, who holds the case now, and what time limits or rules apply. Objective: fix the member's problem, keep the relationship, make the record whole. Approach: name one owner now, contact the member in plain words, join the three records, fix before diagnosing the cause. Then metrics and risks. Say the structure aloud before using it, and challenge one premise. The case asks about no past, so the guidance makes no claim | The 20-minute escalation case; touches Members First, Plain Words and Own the Fix together |
| H2 | "A supervisor has held a complaint for two weeks without escalating it, because the member 'seemed fine'. How do you coach them?" | CASE | [generic] | Clarify the facts first. Treat it as a conversation, not a verdict: ask how they decided, put the member's side in the room, agree what should have triggered an escalation, and check the process was clear to them. Agree a follow-up. State what you would look at in the process itself. No claim about your past | The JD's coaching line asked as a decision; CASE with JD content |
| H3 | "Eight branches become five hubs over 2027. What would you want to know about complaints before the first branch closes?" | CO | [grounded] | Structure it: a baseline by branch and channel; what members in each town currently complain about; how members will tell Ashgrove when something goes wrong during the change; what staff in affected branches need. Tie to Neighbours, Not Numbers. Do not state what the hub move will do to complaints as fact; frame it as what you would find out | The brief's hub move; the panel are branch managers, so altitude and tact are both scored |

### I: Peer Evaluator and Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "You'd coach our supervisors on escalations. Where is the seam between you and a branch manager, and what happens when we disagree?" | JD | [grounded] "trained new tellers on our escalation script" | Propose seam principles rather than claiming to know the seam: who decides what, who is told when. Add what you bring to their team, at the quote's scope: "I trained new tellers on our escalation script." Answer slot: if you have disagreed with a manager and kept the relationship, say what it was about and how it ended; if not, say so plainly and describe how you would handle it | F4; persona stem for the Peer Evaluator, with reciprocity |
| I2 | "Why would a branch manager listen to you on escalations?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" "I handled the branch's formal complaints log" | Do not argue status. Hold what the quotes carry: six years in retail banking, the last three as a branch supervisor, and the branch's formal complaints log you handled. Answer slot: if you have shown a supervisor or manager how escalation works, say what happened; if not, say so plainly and say what you would ask them first | F4 and F1; Skeptic delivery from a branch-manager audience |

### Reverse questions, round 3

| # | Ask | Why it lands |
|---|---|---|
| 1 | "How do complaints reach you today, and what do you wish you were told sooner?" | Reciprocity: starts from the panel's own work |
| 2 | "What could a new person in this role do in their first month that would genuinely help your branch?" | The peer reciprocity question |
| 3 | "What happens to a branch's complaint handling when it becomes part of a hub?" | Connects to the brief; shows you are thinking about the change |
| 4 | "Which of the four values is hardest to hold on a busy day, and what does it look like when someone does?" | The panel scores against the values, so this asks about their lived version |
| 5 | "Where do you see the line between what a branch manager decides and what this role does?" | Invites the seam conversation on your terms |

---

## Values cheat sheet (round 3)

Values are Ashgrove's published wording, as you pasted it from the values page on 17 November 2026.

| Value (official name) | Working meaning (paraphrased) | Mapped story | Questions |
|---|---|---|---|
| Members First, Always | Decide from the member's seat, not the institution's | No quoted sentence carries a story. Selection scaffold ending in its honest branch: if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | G1, G5 |
| Plain Words | If the member needed it twice, the fault was in the writing, not the member | F4: "trained new tellers on our escalation script"; whether the wording was yours is an answer slot, with the honest branch in G2 | G2 |
| Neighbours, Not Numbers | A branch is part of its town; a figure is not the whole picture | F3: "I built the monthly complaints spreadsheet our regional manager uses."; the slot in G3 | G3 |
| Own the Fix | The person who finds a problem keeps it until it is solved | F1: "I handled the branch's formal complaints log"; the slot in G4 | G4 |

## Prohibited claims

Built from the fit snapshot before the banks. Each entry is a claim this pack will not coach.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log". The limit is the pack's observation: your material says the branch's log, not a process across branches. D1's slot stays inside the log |
| Has worked in a contact centre | Negative you stated, F2 | The plain acknowledgment: "I've never worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment: "I've never presented to anyone above regional level." No slot |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: "trained new tellers on our escalation script". The limit is the pack's observation: your material says new tellers, not supervisors. C1's slot stays with the training |
| Reported complaint figures to senior leaders | Inflated form of F3, and limited by F8 | F3's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." |

## Sources

Provided documents: the JD text; the four values, pasted from ashgrovecu.org/about/values on 17 November 2026; the recruiter's email on the three rounds; your summary of the 2026 strategy brief (published July 2026, sent by the recruiter); your background message. No dossier was present.

Searches and fetches sent: none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values text fixes the values cheat sheet and the VAL banks |
| 2. Ashgrove interview process, member services roles | skipped | The recruiter's email names all three rounds, who runs each and what each holds, so it fixes the loop and the persona weights |
| 3. Ashgrove strategy and recent news | skipped | The pasted brief summary, four months old, already fixes the grounding brief and the CO and CASE questions |
| 4. Interviewer name and Ashgrove | n/a | No names have been assigned, so there is no query to form; the interviewer read is absent |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Interviewer names, once assigned → an interviewer read per round, persona weights adjusted from public professional footprint, and a reverse question tied to each interviewer's own path
- The recruiter's answer on the case format (material on the day or beforehand, and what the 20-minute case is built on) → H1 and H2 become targeted instead of generic practice cases
- Your written answers to the slots on F1, F3, F4, F5 and F7 → those rows move from discovery or transferability to story-mapped guidance in D1, E1, C1, F1 and B3
- An anonymised extract or the report layout of your monthly complaints spreadsheet, with no member details → F3 and F9 confidence from medium toward high, and exact beats for E1 and E2
- The full 2026 strategy brief rather than a summary → exact wording in the grounding brief and sharper CO and CASE questions
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) on Ashgrove's recent organisational context, role-family loop reports and the strategy → more current CO questions; offered once, say the word if you want it
- A tuesday-dossier.md from job-underwriter, if you ever run it → verified evidence and graded objections to build the pack on, in place of the ones inferred here
