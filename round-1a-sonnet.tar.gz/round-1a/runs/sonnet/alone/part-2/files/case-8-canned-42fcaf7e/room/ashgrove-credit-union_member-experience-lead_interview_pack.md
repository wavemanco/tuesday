# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

Prepared for Dara. Loop mode: three rounds on 26 November 2026, no interviewer names yet.

| Round | Who | Length | Shape, per the recruiter's email |
|---|---|---|---|
| 1 | The recruiter | 30 minutes | A conversation |
| 2 | The Head of Member Services, who would be your manager | 45 minutes | Mostly behavioural |
| 3 | A panel of two branch managers | 60 minutes | Includes a 20-minute case on a complaint escalation; also the values round, scored against the four values |

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words.

| Type | What it scores |
|---|---|
| VAL | Whether your past behaviour shows Ashgrove's published values |
| EXP | Whether what you have said about your experience survives follow-up questions |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know where Ashgrove is heading |
| CASE | How you structure a live problem from the role |

Three things recur:

- An **answer slot** is an instruction for the interview. Answer it from what really happened. Either branch is a good answer, and saying plainly that something was not yours is one of them.
- Provenance tags: `[grounded]` traces to something you or Ashgrove supplied, `[inferred]` is this pack's derivation, `[generic]` is a rehearsal pattern with no claim about you or Ashgrove.
- **Highest-ROI prep in this pack: D1** (Round 2), the contact-centre objection. It will arrive in some form in all three rounds, and B1 and L1 rehearse its other appearances.

## Fit snapshot

Shared by all three rounds. Evidence is your own words, quoted. No row is a gate: none of the JD's requirements is a term such as a licence, location or pay.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says a branch's log, not a process across branches, and the words stay at the log: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what happened to a complaint beyond the log likely. If any other stages of a complaint's handling were yours, say which and what you decided, in your own words; if the log was your whole part, or other stages were not yours, say so plainly and stay with the log |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I have never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your material says you built a monthly complaints spreadsheet that your regional manager uses; it does not say what the spreadsheet counted. Answer slot: the JD names volumes and resolution times, so expect a probe on which of those it carried and how each was counted. Say what it counted and how, in your own words; if it counted something else, or you do not know how a figure was counted, say so plainly and stay with the spreadsheet you built |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | Your material says spreadsheet, not which tool. Answer slot: the JD names Excel, so expect a probe on the tool. Say which tool you built it in; if it was Excel, say what you did in it, in your own words; if it was another tool, say so plainly and stay with the spreadsheet you built |
| F5 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says new tellers and a script, not supervisors, and the words stay there: you trained new tellers on your branch's escalation script. Answer slot: the JD's escalation line makes a probe on whether anyone beyond the new tellers was helped likely. If you showed any colleague how to handle an escalation, say who and what your part was, in your own words; if not, or it was not yours, say so plainly and stay with the tellers and the script |
| F6 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent on this. Answer slot: the JD names self-service journeys with digital teams, so expect a probe. If you worked with any digital or app team, say what you did and what changed, in your own words; if you did not, say so plainly, and say what you would want to learn from members first |
| F7 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | presentation | Say it as it stands: you have spent six years in retail banking, the last three as a branch supervisor. Let the interviewer map it to the requirement; do not relabel your own history in the JD's phrase |
| F8 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | discovery | Your material says "formal"; it does not say what made the log's complaints formal. The words stay at the quote: "I handled the branch's formal complaints log." Answer slot: the JD's regulated-complaints line makes a probe on what governed them likely. If outside rules applied to the complaints you handled, say which and what your part was, in your own words; if you are not sure, or none did, say so plainly and stay with the log |
| F9 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I have never presented to anyone above regional level." Then how you would prepare, said as a plan and never as a past. Your material does not say what you have presented at any level, so the pack claims none |

## Requirement coverage

| Requirement | Questions that cover it |
|---|---|
| F1 own the complaints process end to end | A1, D3, G1, H4, J1 |
| F2 across branches and the contact centre | B1, D1, J1, L1 |
| F3 report monthly on volumes and resolution times | E1, E2, J3 |
| F4 Excel reporting | B3, E1 |
| F5 coach branch supervisors on escalations | C2, K2 |
| F6 digital teams on self-service journeys | C3, G2 |
| F7 4+ years in financial-services customer operations | A1 |
| F8 regulated complaints | B2, D3 |
| F9 presenting to senior leaders | B1, C1, D2 |

## Grounding brief

From the 2026 strategy brief Ashgrove published in July 2026, as you relayed it. The vocabulary is theirs; sound current, do not recite it.

| Item | Where it bites in this loop | Provenance |
|---|---|---|
| Move 40% of member service to digital channels by 2028 | JD line on self-service journeys (F6); questions A2 and G2 | [grounded] |
| Consolidate eight branches into five hubs over 2027 | Round 3 panel are branch managers; sets up a tension with "Neighbours, Not Numbers" (H3, J2) | [grounded] |
| Launch a small-business lending product in Q1 2027 | Nothing in the JD points at it; know it exists and use it only if an interviewer raises it | [grounded] |
| The main competitive pressure is app-only banks | Used in the J1 rehearsal case and in G2 | [grounded] |

---

# Round 1: the recruiter (30 minutes)

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly walk-through of your background and motives, plus pay, notice, location and reason for leaving | High: the recruiter's email calls it 30 minutes with them, and a recruiter screen's usual job is logistics and motivation | Short pre-scripted arc; treat casual questions as scored |
| Skeptic, light | Knock-out checks against the JD in a friendly register | Medium: the JD's headline items (contact centre, regulated complaints, senior presenting) are where the material is thinnest | Say each limit plainly and move to what your material carries |

### Bank A: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc using only the beats these sentences state: six years in retail banking, the last three as a branch supervisor; you handled the branch's formal complaints log; you trained new tellers on your escalation script; you built the monthly complaints spreadsheet your regional manager uses. The quotes do not say what your first three years held, so say that in your own words if asked. Close with why this role, in your own words | F7 is the spine of the arc and F1 and F3 supply the complaints beats. EXP because it tests whether the story holds together; delivered conversationally |
| A2 | "What draws you to Ashgrove and to this role?" | CO | [grounded] | Choose one reason that is really yours and tie it to something Ashgrove publishes: a line from its values, such as "we decide from the member's side of the counter", or the digital shift in its strategy. Say why it matters to you, in your own words, rather than reciting it. The guidance makes no claim about your past | The recruiter is checking motivation consistency; CO because the answer must show the homework. The values and strategy are your supplied material |
| A3 | "What salary are you looking for?" | JD | [generic] | Logistics slot: give your own number as a range you would accept, or ask for the role's band first. Either is fine. Give no figure you would not take | Recruiter screens carry a pay check; the pack supplies no figure because only yours is safe |
| A4 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period in your own words. Say what, if anything, is negotiable only if that is true | A start-date check; the safe answer is the true one |
| A5 | "Where are you able to work, and how often?" | JD | [generic] | Logistics slot: give your own constraints on location and days in your own words. The JD covers branches and the contact centre, so ask which sites the role is based at and how it would move between them | A location check; the JD's multi-site scope makes the follow-up natural |
| A6 | "Why are you looking to move now?" | EXP | [generic] | Logistics slot: give your real reason in your own words, framed around what you are moving toward. If part of it is about what you are leaving, say that plainly, without naming colleagues | Consistency check on motivation; EXP because it is about your own history |

### Bank B: Skeptic, light

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would be hardest for you on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pick the limit you will lead with and say it in your own words: "I have never worked in a contact centre" or "I have never presented to anyone above regional level". Follow each with a plan, said as a plan. No claim about doing either. D1 and D2 rehearse each in full | F2 and F9 are the two limits you stated. JD because it scores the requirement list; Skeptic delivery in a friendly register |
| B2 | "What experience do you have of handling regulated complaints?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Open with what the sentence states: you handled the branch's formal complaints log. Answer slot: the JD asks for regulated complaints, so expect a probe on what governed them. If outside rules applied to the complaints you handled, say which and what your part was; if you are not sure, or none did, say so plainly and stay with the log | F8 is thin and the recruiter's knock-out check lands here first. JD because it scores a stated requirement |
| B3 | "How comfortable are you with Excel?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Open with the sentence: you built a monthly complaints spreadsheet that your regional manager uses. Answer slot: say which tool it was built in; if Excel, say what you did in it, in your own words; if another tool, say so plainly and stay with the spreadsheet | F4 is the evidence for the Excel line; the tool is the likeliest probe. JD because it scores the stated skill |

### Reverse questions: Round 1

| # | Question | Why it lands |
|---|---|---|
| 1 | "Who will I meet in rounds two and three, and can you share their names and roles once they are assigned?" | Lets you tune delivery per interviewer, and the answer upgrades this pack |
| 2 | "For the 20-minute case in round three, is there anything I should know beforehand or bring?" | Pulls out any pre-declared deliverable, the highest-leverage recruiter detail |
| 3 | "Who owns complaints today across the branches and the contact centre, and where would this role sit?" | Shows you are thinking about ownership of the whole process, and tells you how big the seam is |
| 4 | "The strategy brief aims for 40% of member service to be digital by 2028. How does this role connect to that in its first year?" | Shows you read the brief and ties the role to its direction |
| 5 | "What happens after 26 November, and when should I expect to hear?" | Low-risk logistics that closes the call on a practical note |

---

# Round 2: the Head of Member Services (45 minutes)

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Open "tell me about a time" prompts | Highest: the recruiter's email calls the round mostly behavioural | Story where one of your sentences carries it; otherwise pick against stated criteria and keep the honest branch |
| Skeptic | Quiet probing of the contact-centre and senior-presenting gaps | High: a future manager derisks gaps, and F2 and F9 are stated limits | Rehearse D1 until it is boring; limit first, plan second |
| Data-Driven Prober | "How was that counted" on the monthly spreadsheet | Medium: the JD asks for monthly reporting and Excel | Know what you can and cannot say about how each figure was counted |
| Case / Strategist | Short live problems from the role and the strategy | Lower than a hiring-manager prior, because the recruiter said mostly behavioural | Clarify, then structure; use their vocabulary |

### Bank C: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to someone senior." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not soften the message, and a relationship intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem; relevant because the role reports to senior leaders (F9). VAL because it scores behaviour, not a claim |
| C2 | "Tell me about a time you helped someone handle an escalation." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F5 at its own scope: new tellers, and your branch's escalation script. Answer slot: the JD's escalation line makes a probe on whether anyone beyond the new tellers was helped likely. If you showed any colleague how to handle an escalation, say who and what your part was; if not, or it was not yours, say so plainly and stay with the tellers and the script | F5 is the evidence for the escalation line and the likeliest place the interviewer probes scope. EXP because it tests what was actually yours |
| C3 | "Tell me about a time you worked with a team outside your branch to improve something for members." | JD | [generic] | Selection scaffold: pick a time with a named team, what you asked of them, and what changed. If no such time comes to mind, say so plainly, then say how you would approach working with a digital team | F6 is silent; the JD's digital line raises it. JD because it scores the stated requirement |
| C4 | "Tell me about a time you had to give a member an outcome they did not want to hear." | VAL | [generic] | Selection scaffold: pick a time with a named situation, what you said and how you put it plainly, and how the member was left. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Complaints outcomes are the role's daily material (F1); VAL because it scores Members First and Plain Words in action |

### Bank D: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You have never worked in a contact centre, and this role owns complaints across it. Why should I think you can do that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | **The highest-ROI rehearsal in the pack.** Beat 1, limit first: "I have never worked in a contact centre." No softening words. Beat 2, what the quote carries, at its own scope: you handled the branch's formal complaints log and trained new tellers on your escalation script. Stop there; do not add that it transfers. Beat 3, a plan said as a plan, in your own words: what you would do in your first weeks to learn how the contact centre handles complaints today. Follow-up 1, "a plan is not experience": agree, and do not add to beat 2. Follow-up 2, "what if the contact-centre team will not follow someone who has not done their job": concede specifically, in your own words, what you would ask them to teach you, and say you are not claiming to do their job. Follow-up 3, "so what makes you the right hire": return to the two things your quotes carry, plus F3, "I built the monthly complaints spreadsheet our regional manager uses." Hold the quoted beats through all three; concede only the contact-centre experience | F2 is the objection most likely aimed at this candidate, because the JD puts the contact centre in the headline requirement. JD because it scores the stated requirement; deepest rehearsal means the most follow-up levels, with the limit stated before it is asked for |
| D2 | "This role presents to senior leaders. What is your experience of that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Say the limit in your own words: "I have never presented to anyone above regional level." Then a plan, said as a plan: how you would prepare for the first senior audience, for instance offering a dry run of your first report with your manager before it goes further. Hold the plan; concede that the experience is the part you would be building | F9 is a stated limit and the JD names senior presenting. JD because it scores the requirement |
| D3 | "You handled the branch's formal complaints log. What made those complaints formal?" | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Open with the sentence's own words: you handled the branch's formal complaints log. Answer slot: say what made them formal, in your own words; if outside rules applied, say which and what your part was; if you are not sure, or none did, say so plainly and stay with the log | F8 is thin and F1's end-to-end reach depends on it. EXP because it tests what the log really was |

### Bank E: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through the monthly complaints spreadsheet you built: what did it track and who used it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | The beats the sentence states: you built it, it was monthly, and your regional manager uses it. Defend-the-number slots, each in your own words: how its figures were counted, what they were sensitive to, which assumption you would defend least, and which part was yours. If you do not know how something was counted, say so plainly. The JD names volumes and resolution times; if the spreadsheet carried either, say how each was counted; if it carried something else, say what | F3 and F4 both draw on this sentence, so it takes the closest scrutiny. EXP because it tests attribution and counting |
| E2 | "How would you define resolution time for a complaint that starts in a branch and ends in the contact centre?" | CASE | [generic] | Clarify first: when the clock starts (the member's first contact or when it is logged as a complaint) and when it stops (response sent or member accepts), how reopened complaints count, and one definition for both channels. Say aloud the definition you would least want to defend. Say you would confirm which timeframes apply rather than guess. The question needs no claim about your past | F3's resolution-time line, tested as a live definition rather than a past claim. CASE because it scores structure; Prober delivery |

### Bank G: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "In your first month, what would you want to understand about our complaints before changing anything?" | CASE | [generic] | Structure: what is counted today and how; where complaints change hands between branches and the contact centre; what members are told at each hand-off; who keeps hold of each complaint until it is solved, which is Ashgrove's own value, "Own the Fix". Say you would listen before changing. No claim about your past | A manager's first-month question tests judgment on F1's whole-process scope without needing a past. CASE because it scores clarifying before structuring |
| G2 | "Our strategy is to move 40% of member service to digital by 2028. What does that mean for complaints?" | CO | [grounded] | Bring the consensus item to prove grounding: the 40% by 2028 target and the pressure from app-only banks, as the brief states them. Then one thesis of your own, yours only if you believe it: for instance, which complaint types you would keep with a person for now. Ask which journeys they expect to move first. No claim about your past | The brief is equally available to every candidate, so recite one item and differentiate with a reasoned view. CO because it scores strategy fluency; F6 is the related requirement |

### Reverse questions: Round 2

| # | Question | Why it lands |
|---|---|---|
| 1 | "What does the monthly complaints report look like today, and who reads it?" | Ties to the reporting requirement and shows you think about the reader |
| 2 | "Where do complaints get stuck between branches and the contact centre today?" | Shows ownership thinking and surfaces the real problem you would inherit |
| 3 | "Which complaint journeys do you expect to move to digital first under the 2028 target?" | Ties the role to the strategy and the self-service line |
| 4 | "As eight branches become five hubs through 2027, how do you see escalation changing for the supervisors I would be working with?" | Shows you read the consolidation as it affects the coaching part of the role |
| 5 | "What would you want from me in my first ninety days that you do not get today?" | Reciprocity with a future manager; invites the real expectation |

---

# Round 3: the panel of two branch managers (60 minutes, with a 20-minute case)

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | One scored question per Ashgrove value | Highest: the recruiter says the panel scores against the four values | Map a story to each value where your sentences carry one; keep the honest branch where they do not |
| Case / Strategist | The 20-minute complaint-escalation case | High: the recruiter named it, and it is a third of the round | Clarify, objective, approach, metrics, risks; say your structure aloud |
| Peer Evaluator | Seam and "what do you need from us" with the managers whose supervisors you would coach | Medium: the JD has you coaching branch supervisors, who work to these managers | Offer seam principles, not a pretended map; say what you bring before what you need |
| Pressure | A challenge on the contact-centre gap or on credit for the spreadsheet | Low: no signal of a stress style in the recruiter's email | Hold through two follow-ups, concede specifically |

### Values / principles cheat sheet

Ashgrove's four values as published on its values page, which you copied on 17 November 2026.

| Value | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decisions start from the member's side of the counter | No sentence of yours carries a decision. Selection scaffold: a time you chose the member's side when the easier path suited the branch or process, with a named stake and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would decide (H1) |
| Plain Words | If a member has to be told twice, the wording was at fault | F5: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Answer slot in H2 on whether the wording was yours to change |
| Neighbours, Not Numbers | Each branch belongs to its town | F3: "I built the monthly complaints spreadsheet our regional manager uses." A spreadsheet is the likeliest thing the panel tests this value against; selection scaffold in H3. Expect the eight-to-five hub plan to colour how the managers hear it |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Answer slot in H4 on whether a complaint stayed with you until solved |

### Bank H: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you decided from the member's side of the counter." | VAL | [grounded] | Selection scaffold: pick a decision where the member's side and the easier path pulled apart; name the stake, what you did, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would decide. The guidance makes no claim about your past | Scores Members First, Always, from Ashgrove's published wording. VAL because it scores behaviour against a named value |
| H2 | "Tell me about a time a member needed something explained twice." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The beat the sentence carries: you trained new tellers on your branch's escalation script. Answer slot: the value says a member told twice means the wording was at fault, so expect a probe on wording. If you ever changed what members were told, say what changed and why; if the wording was not yours to change, or you did not change it, say so plainly and stay with the training | F5 is the nearest sentence to a member-facing script. VAL because it scores Plain Words |
| H3 | "Tell me about a time you thought about a branch's town rather than the numbers." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | The sentence states you built a monthly complaints spreadsheet that your regional manager uses. Selection scaffold for the story: a moment where the figures said one thing and what you knew of the branch's members said another; name what you did. If no such time comes to mind, say so plainly, then say how you would hold both | F3's monthly numbers are where this value is most likely to press, and the brief's hub plan sets a tension with it for branch managers. VAL because it scores Neighbours, Not Numbers |
| H4 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The beat the sentence carries: you handled the branch's formal complaints log. Answer slot: the value says whoever finds a problem keeps hold of it until it is solved. If a particular complaint stayed with you until resolved, say which parts were yours and how it ended; if it passed to someone else, or you did not see it through, say so plainly and stay with the log | F1's end-to-end line is where Own the Fix presses hardest. VAL because it scores the value against what you actually did |

### Bank J: Case / Strategist

The recruiter said the case is on a complaint escalation. J1 to J3 are rehearsal scenarios written for this pack, not the panel's case.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "A member's complaint has moved between a branch and the contact centre three times, and they say they will move to an app-only bank. Walk us through what you do." | CASE | [generic] | Clarify first: what the member wants, what they have been told, who holds the complaint now, and any time limits running. Objective: one named person keeps hold of it until it is solved, and the member hears it in plain words. Then the immediate action, the process fix behind the hand-offs, and how you would record it. Say your structure aloud and challenge one premise, such as whether "three times" is the real problem. No claim about your past | The 20-minute case is the largest single block of the round; J1 practises its shape. CASE because it scores structure; the app-only bank frame is the brief's competitive pressure (F1, F2) |
| J2 | "A branch manager says escalating this will hurt the branch's numbers. What do you say?" | CASE | [generic] | Acknowledge the concern, then restate the objective from the member's side. Ask what the number is used for. Propose agreeing escalation criteria in advance. Hold member-first through two follow-ups; concede specifically that you would listen to how the branch is measured. No claim about your past | A natural second turn in an escalation case, and where Neighbours, Not Numbers and Members First meet. CASE because it scores reasoning under a stakeholder push |
| J3 | "Six months on, how would you tell whether the escalation process is working?" | CASE | [generic] | Define the measures before using them: complaint volumes and resolution times, as the JD names them, and how members feel. Name the definition you would least want to defend. Say what the figures would miss. No claim about your past | Metrics are the JD's monthly-reporting line (F3). CASE because it scores how you would judge success |

### Bank K: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "Where is the seam between a complaints lead and a branch manager, and what happens when we disagree?" | JD | [generic] | Offer seam principles, not a pretended map: who decides what escalates, who owns follow-up, how disagreements are settled. Say you would agree the seam with them. Show spine and tact together. No claim about your past | Persona stem; the managers' supervisors are the people the role coaches (F5). JD because it scores how the role works with branches |
| K2 | "One of my supervisors escalates everything, or nothing. How would you coach them?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Structure: look at their cases together, ask what makes them hold or send, agree what good looks like, follow up later. If it helps, mention the tellers' script training at its own scope: you trained new tellers on your branch's escalation script; do not present it as work with supervisors | F5 is the evidence for the escalation line and its limit. JD because it scores the stated coaching requirement |
| K3 | "What would you need from us branch managers to make this work?" | JD | [generic] | Reciprocity framing: say what you would offer first, such as a clear regular picture of how each branch's complaints are going, as a proposal and not a past. Then what you would ask for. No claim about your past | The managers are pricing what the hire costs and brings to their branches. JD because it scores how you would run the cross-branch part of the role |

### Bank L: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| L1 | "Sixty seconds: why you, and not someone who has run a contact centre?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I built the monthly complaints spreadsheet our regional manager uses." | Hold-then-concede in sixty seconds. Concede first, plainly: "I have never worked in a contact centre." Then hold the beats your quotes carry, choosing two: you built the monthly complaints spreadsheet your regional manager uses; you handled the branch's formal complaints log. Make no comparison with anyone else. Hold through two follow-ups; concede only the contact-centre experience | The same objection as D1 in a time-boxed form (F2). JD because it scores the requirement; Pressure delivery |
| L2 | "That monthly spreadsheet: how much of it was actually you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Hold the sentence's own verb: you built it. Answer slot: if anyone else contributed, such as a data source, a template or a review, say which part and whose; if it was all yours, say so plainly. If you do not know where some figures came from, say so. Hold through two follow-ups by returning to the sentence, never by adding to it | F3 is a claim every prober tests for attribution. EXP because it scores what was actually yours |

### Reverse questions: Round 3

| # | Question | Why it lands |
|---|---|---|
| 1 | "How do complaints reach you as a branch manager today, and what would you want to be different?" | They are the users of the process; invites the real pain point |
| 2 | "What would you most want to protect about how your branch looks after members as the hub change comes?" | Meets the panel on Neighbours, Not Numbers without taking a side on the plan |
| 3 | "What could a new person in this role do in their first month that would genuinely help your branch?" | Reciprocity question; shows you think of the managers as partners |
| 4 | "Which of the four values do you find hardest to live up to in practice, and why?" | Turns the scored round into a conversation and shows the values are not just words to you |
| 5 | "What would make a supervisor trust a complaints lead who came from outside their branch?" | Shows you understand the coaching part of the role is earned |

---

## Prohibited claims

What this pack will not coach, and why. Every guidance cell was written against this list.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the member complaints process end to end across branches | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says a branch's log, not a process across branches. F1's slot stays inside the log |
| Coached branch supervisors on escalations | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation: the material says new tellers and a script, not supervisors. C2's and K2's guidance stay with the tellers and the script |
| Has worked in a contact centre | Negative you stated, F2 | The plain acknowledgment F2 gives: "I have never worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F9 | The plain acknowledgment F9 gives: "I have never presented to anyone above regional level." No slot |

## Sources

Provided documents: the JD as you pasted it; Ashgrove's four values as you copied them on 17 November 2026 from ashgrovecu.org/about/values; the recruiter's email about the three rounds; the four points you gave from the July 2026 strategy brief (a summary you typed, not the brief itself); your background as you described it.

No searches or fetches were sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values page supplies all four names and wordings, which fix the values cheat sheet and the VAL questions |
| 2. Ashgrove interview process, member-experience roles | skipped | The recruiter's email names three rounds and says who runs each and what each holds, which fixes the loop and the persona weights |
| 3. Ashgrove strategy, recent news | skipped | The four points from the July 2026 brief fix the grounding brief, G2 and the J1 frame; no later news was checked |
| 4. Interviewer names at Ashgrove | n/a | No names exist yet, only roles, so the interviewer read is absent; the upgrade menu says what names would unlock |
| 5. Representative Member Experience Lead JD | skipped | The JD you pasted fixes the fit snapshot and every JD-tagged question |

## Upgrade menu

- Interviewer names for rounds two and three → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to their own path
- The recruiter's guidance on the 20-minute case: its format, and whether you are given material or asked to present → Bank J restructured to match, and a graded-deliverable section if anything is pre-declared
- Your answers to the slots in F1, F3, F4, F5, F6 and F8, given outside a drill → those rows gain quoted evidence and the banks that draw on them regenerate
- A copy of the monthly complaints spreadsheet with member details removed → F3 and F4 move from limited inspectable proof toward high confidence
- Your prep hours before 26 November → a prioritised schedule that puts D1 and the Round 3 values answers first
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → a fuller grounding brief on Ashgrove's recent moves and competitors, and checked currency of the strategy points
- A tuesday-dossier.md, if you have one → verified evidence per requirement and a pre-decided strongest objection in place of the one this pack inferred
