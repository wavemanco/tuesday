# Mock-interview pack: Senior GTM Strategy Lead, Emerging Products — Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy — a **peer** (both report to the same VP). **Round:** one 60-minute conversation. **Built from:** the JD highlights, the candidate summary, the interviewer description and the research note you supplied. No web research came back (see Sources).

**Highest-ROI prep in this pack: C1.** The stated gap on sales-ops and quota-setting is the objection most likely to be asked in some form, and it gets the deepest rehearsal.

## How to use this pack

Personas describe how a question arrives. Types describe what it is scoring. Guidance is scaffolding, not a script: say it in your own words and say only what you actually did.

| Type | What it is really testing |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether the claims on your background survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem from the actual role |

No VAL questions appear. No source in hand documents a values round or the company's published values, so none was built.

A line of the form "Answer slot:" is an instruction for the interview, never a question to answer here. It names what the interviewer will probably probe, then gives two honest branches. Take whichever one is true.

## Fit snapshot

Requirements are quoted from the JD highlights as you gave them. Evidence is quoted from your message. The one row whose requirement comes from your description of the company, not from the JD, says so.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — your message | low | [inferred] | discovery | The quote shows product strategy and ops work and does not show whether any of it was taking a product to market. Answer slot: the JD puts GTM ownership first, so expect a probe on any product or motion you took to market. If you did, say which and what part was yours, in your own words; if you did not, or it was not yours, say so plainly and stay with the product strategy and ops work |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights | "proposed a store-surface change credited with a ~$400M ARR uplift" — your message | medium | [grounded] | transferability | The quote is a proposal credited with an uplift, nothing inspected behind it, and its words stay there: "I proposed a store-surface change credited with a ~$400M ARR uplift." It names no lifecycle stage. Answer slot: expect a probe on which stage of the customer lifecycle the change touched. If it touched one, say which; if it was not framed that way, say so plainly and stay with the change |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights | "skilled in SQL/Tableau" — your message | medium | [grounded] | none | No gap in wording, but a skills line with nothing inspected behind it, so expect a probe. Lead with the quote's own terms: skilled in SQL and Tableau. Any particular analysis is for B3 to surface |
| F4 | "partner-motion design experience required" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — your message | medium | [grounded] | transferability | The quote is a revenue model used in negotiations, and its words stay there: "I built a partner-level revenue model used in carrier negotiations." The JD word is experience, not a credential, so this is not a gate. Answer slot: expect a probe on whether the model shaped how the carrier relationship was run. If it shaped any step, say which and how; if it informed negotiations only, say so plainly |
| F5 | "strong cross-functional influence" — JD highlights | "set annual volume targets with cross-org consensus" — your message | medium | [grounded] | presentation | The quote already carries the influence evidence in other terms: targets, annual, with consensus across orgs. Lead with that, at its scope: "I set annual volume targets with cross-org consensus." Add nothing about how consensus was reached unless you say it (answer slot in A5) |
| F6 | "AI experience a plus" — JD highlights | "uses AI tools daily" — your message | medium | [grounded] | none | The quote reaches the requirement at the level of use. Keep it at use. Which tools and for what is for E2 to surface |
| F7 | Sales-ops and quota-setting fluency, as expected of a peer in sales strategy — role-family expectation, not a JD quote | "No classic sales-ops or quota-setting experience." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I don't have classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F8 | "B2B data-infrastructure SaaS" — your description of Northwind, not the JD | "a large consumer-tech company in product strategy & ops" — your message | low | [inferred] | discovery | The quote is consumer-tech and does not show whether any of the work faced business customers or partners. Answer slot: expect a probe on B2B or enterprise exposure. If any of your work faced business customers or partners, say which and what part was yours, in your own words; if none did, say so plainly and stay with what the quotes carry |

No gate rows. Nothing in the material is a term the candidate meets or does not (authorization, licence, location, schedule, pay, travel), so there was nothing to surface. A full JD may change that.

## Requirement coverage

| JD requirement | Covered by | Note |
|---|---|---|
| Own GTM strategy for two new product lines | C3, D1, D2, D4, E3 | F1 is the thinnest row; C3 makes you pick your own weakest point first |
| Whitespace across land/adopt/expand/renew | D2, B4, B1 | B1 rehearses the one figure that touches this |
| Independent analysis in SQL and Tableau | B3, B4, A3 | |
| Partner-motion design experience | B5, A1 | |
| Cross-functional influence | A5, A2, A1 | |
| AI experience (a plus) | E2, D2 | |
| Sales-ops and quota-setting fluency (role-family) | C1, F1, A4 | Stated negative; sourced |

## Reading the interviewer

Public footprint beyond your description is not established, because no search returned. Everything here is Dan's profile as you described it.

| Signal (as you described it) | What it likely changes | Provenance |
|---|---|---|
| Profile self-describes as "relentlessly data-driven" | Probers up. Expect every figure to be taken down to its inputs: B1, B2, B5, F2 | [grounded] |
| Career spine in pricing and monetization roles | Case questions tilt to pricing, packaging and unit economics: D3. Revenue and ARR are his native vocabulary | [grounded] |
| One early-stage-startup chapter | Expect a probe on working without a playbook (C4). Whether that chapter makes builder stories land is a derivation from the persona signal rules, not something he said | [inferred] |
| Peer, same VP | He is pricing what your hire does to his work. Seam and reciprocity: A1, A3, A4 | [grounded] |

**Mirror opportunity (shared vocabulary).** His pricing and monetization spine pairs with F4's sentence, "built a partner-level revenue model used in carrier negotiations", and F2's sentence, "proposed a store-surface change credited with a ~$400M ARR uplift". Use revenue language where those quotes allow, and no further. No fit row carries a candidate-side jump that matches his startup chapter, so none is offered.

## Persona weights

Order of reasoning: relationship prior (peer), then interviewer signals, then the loop. Your words establish the loop (one session, run by Dan), so no archetype fallback was used.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Peer Evaluator (5 questions) | Seam-splitting between sales strategy and emerging-products GTM; credit; what you need from him | high — the peer prior puts this first, and he shares a VP with you | Reciprocity framing. Propose seam principles rather than pretending to know the seam. Keep any disagreement story to what the F5 quote carries |
| B. Data-Driven Prober (5) | Figures taken to inputs, assumptions and attribution | high — peer prior, plus "relentlessly data-driven" | Know what you can and cannot say about how each figure was counted, and say plainly when you do not know. Name the weakest assumption you know of before he does |
| C. Skeptic (4) | The sales-ops gap, B2B move, why now, startup-pace probe | high — the stated gap is the obvious target, and the startup chapter adds a pace probe | Rehearse C1 until it is boring. Bridges only from the quotes. Calibrated candor over bluffing a competency he may own |
| D. Case / Strategist (4) | Live problems from the role: GTM plan, whitespace, bundling, sequencing | medium — a peer tests reasoning less than a manager, but his pricing spine tilts cases toward packaging | Clarify, objective, segmentation, approach, metrics, risks. Think aloud. Challenge one premise respectfully |
| E. Conversational (3) | Biography opener, AI chat, why Northwind | medium — easy to underrate, and these are still scored | A 90-second arc for the biography. Treat the AI question as scored |
| F. Pressure (2) | Time-boxed "why you", attribution challenge | low — a peer is less likely to stress-test than a skip-level | Pause, restate, hold the position the quotes carry through two follow-ups, concede specifically |
| Values/Behavioral | — | none — no source documents a values round | No bank |

## Question banks

### A. Peer Evaluator (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our teams sit side by side. Where is the seam between sales strategy and GTM for the new lines, and what happens when we disagree?" | JD | [grounded] "set annual volume targets with cross-org consensus" | Offer seam principles, not a map: who owns the question, who owns the number, how a disagreement escalates, what each side commits to share. Do not claim to know his team's seam. If you reach for a story, the quote carries only the targets and the consensus. Answer slot: if there was disagreement inside that consensus, say what it was and what was yours; if consensus came without any, say so plainly and stay with the targets | Peer prior; the seam is the first thing a peer prices. F5 is the only row on influence. JD because it scores the cross-functional requirement, with a peer-style delivery |
| A2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Credit language is already in the quote. Say it at its scope: you proposed the change, and the uplift was credited to it. Answer slot: who credited it, and which parts of the outcome were yours and which belonged to others, in your own words; if you cannot say, say so plainly. Describe how you share credit as a practice you hold now | Stem from the persona model for peers; F2's wording makes it a natural follow-on. EXP because it tests attribution honesty |
| A3 | "What do you need from me and my team in your first 90 days, and what could you do for us?" | JD | [grounded] "skilled in SQL/Tableau" | Lead with what you can offer, at that scope: you are skilled in SQL and Tableau, so analysis support on the new lines is a fair offer. Then what you need: his team's view of how targets and pipeline are run today. Keep the ask to learning, since F7 is a stated gap | The reciprocity question the persona calls for. F3 is the evidence behind the offer. JD because the answer defines how the role works alongside his |
| A4 | "In sizing whitespace for a new line, who sets the targets, you or my team?" | JD | [grounded] "No classic sales-ops or quota-setting experience." | Principle first: sizing and target mechanics are a shared seam, and sales strategy holds the mechanics. If pressed on your own background, use the plain acknowledgment: "I don't have classic sales-ops or quota-setting experience." Then say what you would take from his team, as a plan | A peer testing whether you will stay out of his lane or overreach into it. F7 is why the acknowledgment is ready. JD because it scores the whitespace requirement from the seam angle |
| A5 | "Tell me about a time you had to influence a team you had no authority over." | EXP | [grounded] "set annual volume targets with cross-org consensus" | Story map on F5: the targets, the annual cycle, the consensus across orgs, told in your own words. Answer slot: the JD asks for strong cross-functional influence, so expect a probe on how consensus was reached. If you did something specific to get there, say what; if consensus came without any particular step of yours, say so plainly and stay with the targets | Open prompt themed from the JD's influence line. F5 is the only evidence row. EXP because it tests what was actually yours |

### B. Data-Driven Prober (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The ~$400M ARR figure — walk me through how it was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Say it at its scope: you proposed the change, and the uplift was credited to it. Then the four slots a figure raises. Answer slot: how the figure was counted; what it is most sensitive to; the assumption behind it you would defend least, named before he asks; which part was yours. If you do not know how it was counted, say so plainly | Headline figure on the background, so it is the magnet for a data-driven peer. F2 is the row; "credited with" makes attribution the second question. EXP because it tests the claim, not the company |
| B2 | "How did you set those annual volume targets — what went in, and who pushed back?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | The quote carries the targets, the annual cycle and the consensus. Answer slot: the inputs and method, and who pushed back. If you built the method, say how; if it was handed to you, or there was no formal method, or no one pushed back, say so plainly and return to the consensus | Probers ask for inputs on any number. F5 is the evidence and it is silent on method. EXP because it tests ownership of the method |
| B3 | "Tell me about an analysis you ran yourself in SQL or Tableau, start to finish." | JD | [grounded] "skilled in SQL/Tableau" | The quote is a skill statement, not a specific analysis, so this is a selection scaffold. Pick one where you wrote the queries or built the views yourself. Name the question it answered, the data, what changed as a result. If no such analysis comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach one | JD requires independent analysis; open prompt themed from the JD line. F3's evidence has nothing inspected behind it, so the story must come from you |
| B4 | "How would you test whether whitespace in land, adopt, expand or renew is real before recommending investment?" | CASE | [generic] | Structure: what decision it feeds, what data you would pull for each stage, what would make you stop. Say which cuts you would run in SQL first. Name the weakest assumption in your own approach before he does. The question needs no claim about your past, so the guidance makes none | Probers like validation questions. Covers the whitespace requirement as a live problem. `[generic]` because it is a pattern for the problem |
| B5 | "Walk me through the revenue model for the carriers — inputs, and how you checked it." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | The quote carries a partner-level revenue model, used in carrier negotiations. Answer slot: the inputs, and any check on the model. If you chose the inputs and checked it, say how, in your own words; if inputs were supplied or no check was run, say so plainly. Name the assumption you would defend least | A model is the second place a prober looks for inputs. F4 is silent on both. EXP because it tests how the model was actually built |

### C. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "I don't see classic sales-ops or quota-setting in your background. How would you handle that in this role?" | JD | [grounded] "No classic sales-ops or quota-setting experience." and "set annual volume targets with cross-org consensus" | **Highest-ROI rehearsal.** Hold, then concede. Concede first, plainly and specifically: "I don't have classic sales-ops or quota-setting experience." Do not fold on the rest. What the material does carry, at its scope: you set annual volume targets with cross-org consensus. Keep the targets as the quote names them. Then a ramp plan, said as a plan: the first two things you would learn and whom you would ask. Follow-up 1: asked how those targets compare with sales targets. Answer slot: if the way you set yours resembled it, say how, in your own words; if it did not, or you cannot say, say so plainly and return to the consensus. Follow-up 2: "What would you get wrong in month one?" Name one specific thing, in your own words. Follow-up 3: "Why should I trust you with the number?" Return to the two quotes and stop | The stated gap is the one objection every route into this loop ends at, and a peer who works in sales strategy owns that competency. F7 and F5. JD because it scores the requirement head on; the persona is Skeptic. Deepest rehearsal means three follow-ups and the exact concession, not more claims |
| C2 | "You have spent nine years at a consumer company. Why a B2B data-infrastructure company, and why now?" | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | The quote supplies the nine years and the consumer-tech setting; the reason is yours. Answer slot: give your actual reason for the move and for Northwind specifically, in your own words. You may tie it to the priorities in your research note: enterprise expansion, the Compass launch, profitability. The pack cannot say which of those is true for you. If there is no single clear reason, say that plainly and give the nearest honest one | Motivation consistency is the Skeptic's core score. F8's gap makes the question near-certain. EXP because it is a reason-for-moving probe |
| C3 | "Which part of this JD would you be weakest at on day one?" | JD | [inferred] derived from the thinnest fit rows, F1 and F8 | You choose, and choose honestly. The pack's observation: F1 and F8 are the thinnest rows. Pick the one that is true for you, name it plainly, then give the ramp: what you would do in the first weeks. Answer slot: if your honest weakest point is something else, say that instead. A named weakness with a plan beats a disguised strength | Persona stem; the whole fit snapshot decides what the honest answer is. JD because it scores self-assessment against the list. `[inferred]` because it is derived from the grading of the rows |
| C4 | "New product lines often start with no playbook. Tell me about a time you worked without one." | EXP | [inferred] theme from the JD line "own GTM strategy for two new product lines" and his startup chapter | Selection scaffold: pick a time where there was no template, you made a named decision, and the work held. Say what you decided and why, in your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Do not describe a startup-style pace you did not live | Tests the scrappiness probe his profile makes likely. The raising source is the JD's new-lines line. EXP because it asks for a past instance. `[inferred]` because the link to his chapter is a derivation |

### D. Case / Strategist (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sketch the GTM plan for a new product line two quarters from launch. What do you need to know first?" | CASE | [generic] | Clarify first: who buys, who uses, what it replaces, how it is priced and sold today. Then objective, segmentation, approach by stage (land, adopt, expand, renew), metrics, risks. Say the structure aloud before using it. Challenge one premise politely. No claim about your past | Covers the headline JD requirement as a live problem. `[generic]` because no source describes either product line. CASE because it scores structure |
| D2 | "Compass is launching. Where is the whitespace across land, adopt, expand and renew, and what would you pull first?" | CASE | [grounded] "an AI copilot launch ('Compass')" — your research note | Use only the name and the fact of a launch; you know nothing else about the product. Clarify: standalone or attached, which segments, what price signal exists. Then one cut per stage in SQL (for example adoption by cohort, expansion by segment). Say which you would pull first and why. Flag what you cannot know from outside | The one current-strategy question the research note supports. CO and CASE together: it uses the company's own term. Grounded only in the note, since no search came back |
| D3 | "A much larger platform vendor bundles something that overlaps ours. How does that change your plan, and how do you price against a bundle?" | CO | [grounded] "main competitive threat is bundling by a much larger platform vendor" — your research note | Clarify what overlaps and for which customers. Then the structure: what is defensible on its own, what is only valuable inside a bundle, where standalone price and packaging should differ. The material shows no pricing quote, so say plainly if pricing is not your own ground and reason from structure; he will respect that more than a bluff. If you reach for the revenue model, keep it at its scope: "built a partner-level revenue model used in carrier negotiations" | His pricing spine tilts cases here, and bundling is the stated competitive threat. F4 is the only revenue-model row. CO because it needs strategy awareness; CASE delivery |
| D4 | "Enterprise expansion and profitability are both priorities. How do you sequence GTM investment for the new lines when they pull against each other?" | CO | [grounded] "enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" — your research note | Principles, not a plan you cannot know: what you would stage-gate, which leading indicators would release more investment, what you would not fund yet. Name the trade-off you would make and the evidence that would change your mind. No claim about your past | A senior strategy hire is asked how priorities collide. Grounded in your note's three priorities only. CO because it tests altitude |

### E. Conversational (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" and "built a partner-level revenue model used in carrier negotiations" | A 90-second arc with the beats the first quote states: two years in strategy consulting, then nine years in product strategy and ops at a large consumer-tech company. Pick one proof point from the second quote or from F2's, at its scope. Answer slot: why this role now, in your own words, in one sentence | The casual opener that is still scored. F1 and F4. EXP because it is the CV walkthrough |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | The quote is daily use of AI tools. Answer slot: name the tools and what you use them for. If you built anything, say what; if it is use only, say so plainly and say what you have learned from it. Do not describe building or shipping AI products | The persona stem for a plus-skill asked casually; the JD names AI experience. F6 is at use level, so the answer should be too |
| E3 | "What drew you to Northwind's new product lines in particular?" | CO | [grounded] "enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" — your research note | Name the priorities you can see from your note and say which one pulls you, and why, in your own words. Do not recite them as a list. Answer slot: if what pulls you is something other than those three, say that instead | A peer checks interest is real. Grounded in the note only; richer detail would need research |

### F. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over a candidate who has run a sales org's planning cycle?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations", "set annual volume targets with cross-org consensus" and "No classic sales-ops or quota-setting experience." | Pause and restate. Hold the position the quotes carry: you built a partner-level revenue model used in carrier negotiations, and you set annual volume targets with cross-org consensus. Concede specifically: "I don't have classic sales-ops or quota-setting experience." Hold through two follow-ups; never add to the quotes to win the minute | Time-boxed challenge on F7. JD because it scores fit against the listed job; Pressure delivery |
| F2 | "That ~$400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold: you proposed the change, and the uplift was credited to it. Concede specifically, in your own words, where your part ended. Answer slot: if others built, launched or measured it, say so plainly and say what the proposal contributed; if you cannot separate your part, say that. Never claim the uplift as yours | The stem for attribution; F2 makes it likely. EXP because it tests honesty under pressure |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your background is in pricing and monetization. How does that shape how you would want whitespace in the new lines sized?" | Tied to his own career path, as you described it. It treats him as the expert and invites his framework |
| R2 | "You have had an early-stage chapter as well as larger-company roles. What did you carry from it into a larger company?" | Tied to his path again. Converts the startup-pace probe into a peer conversation |
| R3 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer. Signals you are thinking about his load, not just yours |
| R4 | "Where do sales strategy and emerging-products GTM most often collide, and what rule has helped?" | Shows you expect the seam and want a practical rule |
| R5 | "How is sales strategy thinking about Compass relative to the enterprise expansion priority?" | Uses the two priorities from your note and asks for his live view, not a recital |
| R6 | "What does success in this role look like at six months, in numbers you would look at?" | A data-driven peer will care that you ask for the metric |
| R7 | "What does our VP most want from the two of us together?" | Peers sharing a boss; surfaces how the pairing is meant to work |

## Prohibited claims

Not coached in any cell of this pack. Each is a claim a candidate reaches for under pressure; the honest form is on the right.

| Not coached | Basis | Honest form |
|---|---|---|
| Has sales-ops or quota-setting experience | Negative you stated, F7 | The plain acknowledgment: "I don't have classic sales-ops or quota-setting experience." No slot |
| Treating the annual volume targets as sales quotas | Inflated form of F5 | F5's quote at its own scope: "set annual volume targets with cross-org consensus". The limit is the pack's observation: the quote says volume targets, not sales quotas |
| Designed the partner motion or partner program | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the quote says a revenue model used in negotiations, not the motion. B5's slot stays inside the model |
| Drove or generated the ~$400M ARR | Inflated form of F2 | F2's quote at its own scope, with "credited" kept. The limit is the pack's observation: credit to a change is not the same as the candidate causing it. B1's and F2's slots ask only how it was counted and which part was yours |
| Built or shipped AI products | Inflated form of F6 | F6's quote at its own scope: uses AI tools daily. E2's slot asks only which tools and for what |

## Sources

Provided: your message — the JD highlights, the candidate summary, the interviewer description and the research note on Northwind's priorities and competitive threat. Nothing else was provided, and no document was fetched.

Searches sent, all refused:
- "Northwind Data company values principles" — refused
- "Northwind Data interview process strategy GTM role" — refused
- "Dan Kovac Northwind Data Director of Sales Strategy" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | Every call was refused. Would have fed a values cheat sheet and VAL questions by published value name; neither is in this pack |
| 2. Northwind Data interview process, GTM strategy roles | unavailable | Every call was refused. Would have shown whether a values or case round exists; the loop here rests on your words alone |
| 3. Northwind Data strategy and recent news | skipped | Your research note already supplies the three priorities and the competitive threat, and every strategy question uses only those |
| 4. Dan Kovac, Northwind Data | unavailable | The call was refused. Would have added published talks or writing to the interviewer read; it holds only your description |
| 5. Representative Senior GTM Strategy Lead JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Full JD text → the fit-snapshot requirements become exact JD quotes, and any requirement beyond the highlights, including any term such as location or authorization, would become a row
- Priya's CV, or her own answers to the answer slots in F1, F2, F4 and F8 → low and medium rows become story-mapped guidance instead of slots; the artifact that would raise the medium rows is the carrier-model workbook or the write-up behind the ARR credit
- A real analysis she ran in SQL or Tableau, with its question and outcome → B3 becomes a story map and F3 can reach high
- Dan's published talks or posts, or his full profile text → the interviewer read and R1 and R2 could be tailored
- Northwind's values page and the recruiter's description of the loop → values-round detection, a VAL bank and a values cheat sheet if a values round exists
- Research access → a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) would feed a grounding brief and sharper CO questions
- The recruiter's focus areas for this conversation → coverage reweighted from assumption to stated priorities
- Prep time available → a prioritized prep schedule
- A tuesday-dossier.md from job-underwriter → verified evidence and absolute prohibited claims would replace the locally built list
