# Interview pack: Live Operations Producer, Saltmarsh Games

Candidate: Femi. Interviewer: Tobias Wrenfield, Head of Live Operations. Round: 60-minute interview, built as a hiring-manager round because the note did not say how Tobias relates to the role. If he is a skip-level or cross-functional interviewer, the persona weights change (see the persona table).

## How to use this pack

Personas describe how a question arrives; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Tag | Meaning |
|---|---|
| VAL | Behavioral or values alignment: does past behavior show what the company says it values |
| EXP | Work-experience deep-dive: does the background survive scrutiny, and what was actually yours |
| JD | Role-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge: homework depth |
| CASE | Live problem from the actual role: structure and reasoning |

Bank letters skip F so that fit-snapshot rows (F1 to F10) are never confused with questions. An answer slot is an instruction for the interview, not a question for you now: it has two honest branches, and either one is a good answer.

## Prep triage

Three days until Friday. In order:

1. A1, the single most likely objection to you (highest-ROI prep in this pack). Say it aloud until it is boring.
2. C1 and D2, the two CV lines an interviewer can pick at: the retention numbers and the release checklist.
3. B1 and B4, the live problems closest to the JD's own wording.
4. A3 and A4, then H2.

Everything else is insurance.

## Fit snapshot

Your words are quoted from your message. No JD line here is a gate: the JD states no location, schedule, authorization or pay term, and its years requirement is graded as experience, not as a gate.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for one main title; the JD says live events across two titles, so the words stay at: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: expect a probe on the second title and on whether any drops were time-limited events. If you have planned across more than one title or run time-limited events, say how, in your own words; if not, say so plainly and stay with the one title's calendar |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | low | [inferred] | discovery | The calendar sentence does not show which teams you worked with. Answer slot: if you worked directly with any of the four teams the JD names, say which and what your part was, in your own words; if you worked with none of them directly, or the coordination was not yours, say so plainly and return to the calendar you ran. The JD says coordinate; your material does not say you led anyone, see section 13 |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Words stay at the quote: "I presented the monthly retention numbers to the studio head." The material says presented, not that the numbers or a review were yours. Answer slot: expect a probe on who chose which numbers were reported. If you chose or built any of them, say which, in your own words; if you did not, or no post-update review existed, say so plainly and stay with the monthly presentation |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | A CV-style line with nothing inspected behind it, so expect a probe. Lead with the quote's own terms: "I wrote the release checklist, and our QA team still uses it." A named artifact in use beats an adjective |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | low | [inferred] | discovery | The sentence gives four years as an associate producer; it does not say whether the title was updated live throughout. Reading: a titled-years requirement is likely checked literally, so this is a risk to name, not a gate. Answer slot: say how many of those years were on a live-updated title, in your own words; if it was fewer than the JD's number, say the number plainly |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it. Lead with it in its own terms: you ran it, weekly, for the main title, for two years. A named record beats an adjective |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | presentation | Words stay at the quote: "I presented the monthly retention numbers to the studio head." The probe is how those numbers were counted; that slot is in C1 |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | Words stay at the quote: "I wrote the release checklist, and our QA team still uses it." A written artifact other people still use is what the material carries |
| F9 | In-app-purchase experience, common for mobile live-operations roles; not stated in the JD | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Never a claim to spend or monetization work |
| F10 | Leading people, common for producer roles; not stated in the JD, which says coordinate | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | You have said so. Words: "I haven't led a team." The JD's wording is coordinate, and F2's slot is where coordination is rehearsed. Never a claim to have led design, art, engineering or community |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| live-events calendar for two titles | B1, G1, H2 |
| coordinate design, art, engineering and community | A4, B3, G1, G2 |
| post-event review and its KPIs | B4, C1, C3 |
| release checklist with QA | D2, E2 |
| 3+ years producing live-service games or apps | A3, D1 |
| experience running a content calendar | D1, H2 |
| comfortable with player-retention metrics | B2, C1, C2, C3 |
| clear written communication | D2 touches the written checklist; otherwise none, because writing is scored in any written exercise and none was announced |

## Persona table

No interviewer profile and no documented loop were available, so weights start from the relationship prior and are flat on everything else.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the gaps: in-app purchases, team leadership, whether the years count | 5. A hiring manager is buying capability and derisking gaps, and F9, F10 and F5 are the thinnest rows | Rehearse A1 until it is boring; bridge only from the quotes in F1, F3, F4 |
| Case / Strategist | Live problems on the real role: plan two calendars, diagnose a retention dip, resolve a team clash | 5. Hiring-manager prior; the JD is built from planning, coordinating and reviewing | Clarify, objective, segmentation, approach, metrics, risks; think aloud |
| Data-Driven Prober | Pulls on the retention numbers and the KPIs the review reports | 3. The role reports KPIs, and F3 and F7 are the two rows built on one presented-numbers sentence | Know what you can and cannot say about how the numbers were counted; say plainly when you do not know |
| Conversational | Friendly opener ("walk me through your journey"), still scored | 3. A 60-minute conversation usually opens here | A 90-second arc from F6, F4 and F7 quotes |
| Values / Behavioral | Behavioral prompts on unpopular truths and release risk | 2. No values page or loop source could be read, so no values round is detected; prompts here come from the JD and standard stems | Selection scaffolds with an honest branch |
| Peer / cross-functional | Where the seams between design, art, engineering, community and live-ops sit | 2. Rises sharply if Tobias is cross-functional or the hour includes a peer | Seam principles, not claimed turf |
| Pressure | Time-boxed "why you" and "how much was you" | 2. Lower-prior for a manager round, but F9 and F10 invite it | Hold through two follow-ups, concede specifically, never fold on the core |

## Question banks

### Bank A: Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Nothing in your background involves in-app purchases. How would you handle that in this role?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases."; "Presented the monthly retention numbers to the studio head." | The highest-ROI rehearsal in this pack. Start with the plain acknowledgment and stop: "I haven't worked on a game with in-app purchases." Then say what your material carries, at its scope: "I presented the monthly retention numbers to the studio head." Do not offer retention reporting as the same kind of work as spend. Follow-up 1, what you would want to learn first: answer slot, say what you would want to understand first about how events relate to revenue and who you would ask, as a plan in your own words; if you do not yet know what you would ask, say so plainly. Follow-up 2, that sounds like a big gap: concede it is a real limit, specifically, and hold your position without claiming equivalence | F9 is the thinnest row and the likeliest objection; JD because it scores a stated gap, not a stated requirement |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Choose a limit your material actually shows rather than a polished weakness. The two it shows are in-app purchases and leading a team: "I haven't worked on a game with in-app purchases" or "I haven't led a team." Say it once, plainly, then the plan for closing it in your own words. Answer slot: if neither is the real weakest point for you, say which is and why, from your own experience | F9 and F10 are the stated gaps; JD because it is the Skeptic stem for the weakest area |
| A3 | "The JD asks for three years producing live-service games or apps. Walk me through the years that count." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio."; "I ran the weekly content-drop calendar for our main title for the last two years." | Say the four years and the calendar in those words. Answer slot: expect a probe on whether the other years were on a live-updated title. If they were, say what your part was; if they were not, say the number of years that were and stay with the calendar you ran. Do not stretch a year count | F5 is the row a literal screen is likeliest to catch; JD because it scores the first stated requirement |
| A4 | "You would be coordinating design, art, engineering and community on every update. Which of those have you worked with directly?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: the JD raises all four teams, so expect a probe on each. Name the ones you worked with directly and what your part was, in your own words; if you worked with none of them directly, or the coordination was not yours, say so plainly and return to the calendar you ran | F2 is a discovery row, so the guidance asks before it tells; JD because the four teams are the JD's |
| A5 | "Why this role, and why Saltmarsh?" | CO | [generic] | The reasons are yours; the pack supplies none. Give one reason for the role and one for this studio, each something you can name and verify from their own titles or posting. Answer slot: if you have not looked closely at their games yet, say what drew you to the role and do that homework before Friday | The Skeptic stem for motivation consistency; CO because "why Saltmarsh" needs real homework. Labeled generic because no company research could be run |

### Bank B: Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sketch how you would plan the next six weeks of events across two titles at once. What do you need to know first?" | CASE | [generic] | Clarify first: what each title's calendar and release windows look like now, what the team capacity is, what QA can take, what each event is for. Then state an objective, segment the work by title and by team dependency, propose a sequencing approach, name the metrics, and flag the main risk. Challenge one premise respectfully, for example whether the two titles should share a rhythm. The guidance makes no claim about your past | The JD's first responsibility as a live problem; CASE because it asks for structure, not history |
| B2 | "Day-seven retention on one title fell after last week's event. Diagnose it." | CASE | [generic] | Confirm the data first, then segment: new versus returning players, platform, region, and what else shipped. Compare against earlier events, check release or technical changes, and say what you would look at to separate event design from a bug. Name what you would not conclude yet | Tests retention-metric comfort without presuming anything you did; CASE with JD content |
| B3 | "Engineering says an update cannot make Thursday, but community has already announced it. What do you do?" | CASE | [generic] | Establish what is actually at risk and who knows what, then options: partial ship, shifted date, an honest player message. Decide who must be told and in what order, and what changes in how dates get announced. The guidance makes no claim about your past | The JD's four-team coordination as a live decision; CASE |
| B4 | "Walk me through how you would run a post-event review and decide which KPIs it reports." | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Structure: what the event was for, the measures set before launch, what happened, why, what changes next time. Answer slot: the JD says the producer owns the review and its KPIs, so expect a probe on what you have done here. If you have written or sat in such a review, say your part; if not, say so plainly and describe the monthly retention presentation as you gave it | F3 is where the ownership claim presses; JD because it scores a stated responsibility |
| B5 | "What have you looked at in our titles so far, and what would you want to understand about their event calendars?" | CO | [generic] | Name only what you have actually played or read, and what you noticed. Answer slot: if you have not looked yet, say so and say what you would check first. Do this homework before Friday; the pack could not research the studio | CO differentiator; labeled generic because no company research could be run |

### Bank C: Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the monthly retention numbers you presented. Which measures were in them?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | The beats the sentence carries are monthly, retention, studio head; tell them in your own words. Answer slot: the JD asks for comfort with retention metrics, so expect probes on counting. If you know which measures were included and how they were counted, say so; if you do not know how they were counted, say that plainly. Name the assumption behind them you would defend least, in your own words; if you did not build them, say so | F3 and F7 rest on one sentence, so this is where a prober presses |
| C2 | "After an update ships, which player-retention measures do you look at first?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: name the measures you actually use, in your own words; if you have mostly worked with the numbers as they were presented, say so plainly and say what you would want shown first | F7; JD because it scores the retention-metric requirement |
| C3 | "How would you know an event worked?" | CASE | [generic] | Decide the success measure before launch, name what else could explain a change, and say what result would make you stop or change the event. The guidance makes no claim about your past | The KPI-ownership requirement as a thinking question; CASE |

### Bank D: Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey from associate producer to here." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio."; "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses."; "Presented the monthly retention numbers to the studio head." | A 90-second arc with four beats, each one a sentence you said: four years as an associate producer at a puzzle-game studio; the weekly content-drop calendar for the main title for two years; the release checklist QA still uses; the monthly retention numbers presented to the studio head. Answer slot: the reason you want live operations next is yours to say; the pack supplies none | The opener is scored, and the four sentences are the whole of the material, so they set the interview's frame |
| D2 | "Tell me about the release checklist you wrote." | EXP | [grounded] "Wrote the release checklist our QA team still uses." | The beats the sentence carries: you wrote it, QA still uses it. Answer slot: the JD says the producer manages the checklist with QA, so expect a probe on how it was kept current. If you changed it over time, say how and why; if it was written once and used as it was, say so plainly | F4 and F8; EXP because it tests what was actually yours |
| D3 | "What mobile games are you playing at the moment, and what do their events do well?" | JD | [generic] | Name only games you actually play and what you actually noticed. No claim about your work is needed | A casual question about a core JD topic, still scored |

### Bank E: Values / Behavioral (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not soften it, and an intact relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The behavioral stem; the retention presentation might hold one, but the quote does not say, so no story is mapped |
| E2 | "Tell me about a time a release was at risk and you had to make a call." | VAL | [generic] | Selection scaffold: pick a time a checklist item or a QA finding put a drop in doubt, with the decision, who you told, and what changed afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's QA and checklist line turned into a behavioral prompt |

### Bank G: Peer / cross-functional (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Several teams want updates in the same fortnight. How do you decide whose request goes first, and what happens when we disagree?" | CASE | [generic] | Propose principles instead of pretending to know the seam: player impact, dependency, capacity, a visible tie-break rule. Say what you would bring the other team, not only what you need. The guidance makes no claim about your past | The coordination requirement from a peer's seat |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Say how you handle it as a principle: name the contributions, credit the teams in the review. Answer slot: if a real moment comes to mind, say what happened and your part; if not, give the principle only | Peer stem for partnership fit |

### Bank H: Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Sixty seconds: why you over a producer who has run events on a game with in-app purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years."; "Never led a team, and never worked on a game with in-app purchases." | Pause, restate the question, then hold: "I ran the weekly content-drop calendar for our main title for the last two years." Concede the limit once and specifically: "I haven't worked on a game with in-app purchases." Do not claim you are better, and do not fold on the calendar. Hold through two follow-ups | F9 under time pressure; JD because it scores fit against the role's gap |
| H2 | "That calendar. How much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold the sentence you said: you ran it. Answer slot: if any part was shared or set by someone else, say which, plainly; if all of it was yours, say that in your own words. Hold through the second follow-up by returning to the calendar, never by adding to it | F1 and F6 rest on this sentence; EXP because attribution probes exist to test it |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would a strong first 90 days look like for a producer on these two titles?" | Shows you are planning for outcomes, and the answer tells you how the role is judged |
| 2 | "Which KPIs does the post-event review report today, and who decides when one changes?" | Mirrors the JD's own ownership line and tells you how much of F3's ground is open |
| 3 | "How do design, art, engineering and community agree on an update's scope today, and where is that hardest?" | Tests the coordination part of the job with the person who owns it |
| 4 | "How does the release checklist work with QA today, and what would you change if you could?" | Connects to the checklist you wrote, F4, without claiming more than it says |
| 5 | "How do events on these titles relate to revenue, and what should I learn first to be useful on that side?" | Turns your biggest gap, F9, into a signal that you plan to close it |
| 6 | "What has surprised you most about leading live operations here?" | A rapport question for the head of the function; role-generic because no profile of Tobias could be researched |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has worked on, or run events on, a game with in-app purchases | Negative you stated, F9 | The plain acknowledgment: "I haven't worked on a game with in-app purchases." Then a plan, never a past |
| Has led a team, or led design, art, engineering or community | Negative you stated, F10 | "I haven't led a team." The JD says coordinate; F2's slot covers what was yours |
| Planned and ran live events across two titles | Inflated form of F1 | F1's quote at its own scope: a weekly content-drop calendar for one main title. The limit is the pack's observation, not words for you |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope: you presented the monthly retention numbers. The material says presented, not owned |
| Analysed or built the retention metrics | Inflated form of F7 | F7's quote at its own scope; C1's slot asks only how they were counted |
| Has three or more years producing live-service games | Inflated form of F5 | F5's quote at its own scope: four years as an associate producer; the live-updated years are the A3 slot |

## Sources

Provided documents: the JD text and your background, both pasted in your message.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

Searches sent, all refused (this session did not grant search permission), so nothing below came from the web:

- "Saltmarsh Games values": refused
- "Saltmarsh Games interview process live operations producer": refused
- "Saltmarsh Games mobile studio news strategy": refused
- "Tobias Wrenfield Saltmarsh Games": refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Would have fed a values cheat sheet; without it, bank E is generic and no values round is detected |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | Would have fixed the loop and persona weights; weights rest on a hiring-manager prior |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | Would have grounded B5, A5 and a strategy-based CO question; they are labeled generic |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Would have given an interviewer read and a reverse question tied to his path; reverse questions are role-generic |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Search access, or the studio's values page and a description of their interview process pasted in → bank E and the CO questions become grounded, a values cheat sheet appears if a values round exists, and persona weights follow the real loop
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes), if search is available → a strategy brief for the two titles and recent studio context, which turns B5 and A5 into strategy-based questions
- Tobias's public profile or talks → an interviewer read, retuned persona weights, and a reverse question tied to his own path
- The recruiter's note on what the hour covers, and any exercise to prepare → coverage of a graded deliverable if one was announced; usually one email to the recruiter
- Your answers to the slots in F1, F2, F3 and F5 (for instance how many of your four years were on a live-updated title) → those rows move from discovery or transferability toward grounded, and the questions that draw on them get story-mapped guidance
- A sample of the release checklist and an export of the content-drop calendar, with any identifying details removed → F4, F6 and F8 move from medium to high confidence
- A tuesday-dossier.md from an earlier evidence check, if you have one → verified evidence and a named prohibited-claims list instead of the ones built here from your message
