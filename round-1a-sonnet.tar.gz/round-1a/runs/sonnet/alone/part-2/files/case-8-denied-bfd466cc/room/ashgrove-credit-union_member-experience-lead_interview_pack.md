# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara. **Date of the loop:** 26 November 2026, nine days from today (17 November 2026). **Mode:** loop, three rounds, each with its own persona weights, bank and reverse questions, built on one shared fit snapshot.

| Round | Who | Length | What the recruiter's email says |
|---|---|---|---|
| 1 | The recruiter | 30 minutes | Not described beyond the length |
| 2 | Head of Member Services, who would be your manager | 45 minutes | "mostly behavioural" |
| 3 | Panel of two branch managers | 60 minutes | Includes "a 20-minute case on a complaint escalation"; "the panel is also the values round — they score against the four values" |

The interviewers' names are not assigned, so there is no interviewer read; personas rest on the roles above.

## How to use this pack

Personas describe how a question arrives; types describe what it is scoring. Guidance is scaffolding, not a script: say it in your own words, and say only what you did. An **answer slot** is an instruction for the interview, not a question for me: answer it truthfully from your own experience, and if the practice it names was not yours, or never existed, say so plainly and return to the sentence you can stand behind.

| Type | What it is scoring |
|---|---|
| VAL | Whether past behaviour shows one of Ashgrove's published values |
| EXP | Whether what you say you did survives follow-up questions |
| JD | Whether you can do the job as the JD states it, gaps included |
| CO | Whether you know Ashgrove's strategy and can think at its altitude |
| CASE | Structure and reasoning on a live problem from the role |

**Highest-ROI prep in this pack: B2**, the contact-centre question, which appears in lighter form in B1 and S1. It is the gap you stated yourself, and the JD's first responsibility line names the contact centre. Rehearse B2 until the concession sounds ordinary.

## Fit snapshot (shared by all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says the branch's formal complaints log and the escalation script, and says nothing about the process end to end or about other branches. The words stay at that scope: "I handled the branch's formal complaints log." Answer slot: the JD's first responsibility line makes a probe likely on what happened to a complaint before it reached the log and after it left. If any stage beyond the log was yours, say which and what you did, in your own words; if the log was where your part began and ended, say so plainly and stay with the log and the script |
| F2 | "end to end across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller, and no claim that branch work covers it |
| F3 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | discovery | Your material says a formal log, not what rules it sat under, and the bridge should not be stretched from "formal". Answer slot: the JD's experience requirement makes a probe likely on what the log was kept under. If it was kept under external rules, say which and what they asked of you, in your own words; if it was an internal log only, or you did not know the rules behind it, say so plainly and stay with the log you handled |
| F4 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your material says you built it and your regional manager uses it; it does not say what the spreadsheet showed. Words stay at: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: expect a probe on whether it showed volumes, resolution times or both. If it showed either, say which and how each was counted, in your own words; if it showed something else, say so plainly and say what |
| F5 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | The sentence says spreadsheet, not which tool, and the pack reads it downward: it does not say Excel. Answer slot: say which tool you built it in; if it was Excel, say so, and if it was another tool, say so plainly and say how comfortable you are in Excel, in your own words |
| F6 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message; "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | transferability | Your material says new tellers and the escalation script, not supervisors and not coaching. Words at that scope: "I trained new tellers on our escalation script." Answer slot: if you ever helped a supervisor with an escalation, say what and which part was yours, in your own words; if the training was the script and the tellers, say so plainly and stay there. You were a branch supervisor for three years by your own sentence, so what a supervisor needs from a coach is your own view to give, never coaching you did |
| F7 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent on digital work, which is not the same as none. Answer slot: if you have worked with an app or digital team on anything members use, say what it was and which part was yours, in your own words; if you have not, say so plainly, and say what you would want to ask them first |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't presented to anyone above regional level." Then how you would prepare, said as a plan and never as a past. The pack's observation: your material does not show where Ashgrove draws the line for senior leaders, so the limit is stated against your own words, not the JD's |
| F9 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | presentation | Say it in the sentence's own terms: six years in retail banking, the last three as a branch supervisor. Use the JD's phrase "customer operations" only if you would use it for your own work; the pack does not borrow it for you. Expect a probe on whether branch supervision is the work the JD means; that is the pack's observation, not an answer |

All evidence comes from one message, not a CV, which is why nothing is above medium.

## Grounding brief (shared)

The facts below are the four strategy points you pasted from Ashgrove's July 2026 strategy brief, which is under six months old. The pack does not hold the full brief.

| # | Fact, as you gave it | Source | Provenance |
|---|---|---|---|
| G1 | "move 40% of member service to digital channels by 2028" | 2026 strategy brief, as you pasted it | [grounded] |
| G2 | "consolidate eight branches into five hubs over 2027" | 2026 strategy brief, as you pasted it | [grounded] |
| G3 | "launch a small-business lending product in Q1 2027" | 2026 strategy brief, as you pasted it | [grounded] |
| G4 | "the main competitive pressure is app-only banks" | 2026 strategy brief, as you pasted it | [grounded] |

| # | Reading for this loop | Derived from | Provenance |
|---|---|---|---|
| H1 | The digital target is the likeliest strategy topic in round 2, because it sits beside the JD's digital-teams line (F7) | G1 and the JD line quoted in F7 | [inferred] |
| H2 | The branch-to-hub change is the likeliest strategy topic in round 3, and it sits next to the value "Neighbours, Not Numbers — every branch is part of its town"; the two pull against each other, and a branch-manager panel may have its own stake in it | G2 and the published value | [inferred] |
| H3 | The small-business product is a one-sentence awareness item; it is unlikely to carry a question of its own | G3 and the loop's three round descriptions | [inferred] |
| H4 | App-only banks are the frame for why self-service must be good, which is what the JD's self-service line serves | G4 and the JD line quoted in F7 | [inferred] |

Differentiate; do not recite. The brief went to you from the recruiter, so any prepared candidate can repeat its four points. Bring one to show you have read it, then take a position with reasons (E4 shows the shape).

## Round 1: the recruiter (30 minutes)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A Conversational | Friendly opener; pay, notice, location and reason for leaving asked casually | High. A recruiter screen's usual mix is conversational with logistics, and thirty minutes leaves little room for anything heavier | A 90-second arc for the opener from your three sentences; treat every casual question as scored; at the end, never say "I think you've covered everything" |
| B Skeptic, light | A knock-out check in a friendly register: contact centre, regulated complaints | Medium. The same recruiter-screen mix includes light checking, and the JD's own words make those two items the obvious ones | Have the two plain acknowledgments ready (B1), one clause each |
| C, D, E, P, S | Prober, Values, Case, Peer, Pressure | Low. The recruiter's email puts the behavioural round with the manager and the values and case round with the panel | Nothing specific for this round |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor."; "I handled the branch's formal complaints log and trained new tellers on our escalation script."; "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc built only from the beats those sentences state: six years in retail banking, the last three as a branch supervisor; the branch's formal complaints log and training new tellers on the escalation script; the monthly complaints spreadsheet you built. Tell each beat in your own words, and end on your own reason for this role | The opener of a recruiter screen is close to certain, and the arc frames everything after it. F9 is the evidence for the experience requirement; EXP because it tests what you did |
| A2 | "What's prompting you to look at a move now?" | EXP | [generic] | Logistics slot: give your actual reason, in your own words, in two sentences, and point it at what this role asks of you. Say only reasons that are true | A recruiter screen checks the reason for leaving every time; EXP because it tests whether the story is consistent. The pack supplies no reason because none of your material states one |
| A3 | "What salary are you looking for?" | JD | [generic] | Logistics slot: give your own number, or ask for the role's band first. Your material states no figure and the pack supplies none | Pay is a logistics item in every recruiter screen; JD because it is a term of the listed job |
| A4 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period | A logistics item with one safe answer, which is yours; JD because it is a term of the listed job |
| A5 | "The role covers branches and the contact centre. What does your travel and working pattern allow?" | JD | [grounded] | Logistics slot: state your actual constraints plainly; where you do not know the role's pattern, ask the recruiter what it is before committing to one | The JD names both settings, so a location and travel check follows; JD because it is a term of the listed job |
| A6 | "Why Ashgrove?" | CO | [grounded] | Choose one thing you have actually read in the published values or the strategy brief, or the member-owned structure the JD states, say why it matters to you in your own words, and stop. Do not recite the brief | Motivation and homework are tested together at a screen; CO because it scores knowledge of Ashgrove, not of the job |
| A7 | "Tell me about the complaints you've handled." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F1 and F3: the branch's formal complaints log is the beat the sentence states; tell it in your own words at that scope. Answer slot: the JD's experience requirement makes a probe likely on what the log was kept under. If it was kept under external rules, say which and what they asked of you; if it was an internal log only, or you did not know the rules behind it, say so plainly and stay with the log you handled | The knock-out check for the headline requirement, in a friendly register. F3 is a discovery row, so the probe lands where the material is thinnest |
| B1 | "Which part of this role would be newest to you?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Name the two things you have already said plainly: "I haven't worked in a contact centre" and "I haven't presented to anyone above regional level." One clause each, then, as plans and never as pasts, how you would learn the first and prepare for the second. Stop there | The light form of the loop's biggest objection, rehearsed so it is boring before round 2. F2 and F8 are your own stated gaps; JD because it scores the stated requirements |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "Where does the complaints process start and end today, and who owns it now?" | It tests the scope of the JD's first responsibility line and shows you are thinking about ownership, which Ashgrove's own value is about |
| RQ2 | "Is the case in round 3 sent in advance or given on the day, and is it written or a conversation?" | The recruiter can answer in one line, and the answer decides how you rehearse E2 and E3 |
| RQ3 | "What does the Head of Member Services want to cover in round 2?" | It asks for process, not for what impresses someone, and the answer reweights the round 2 bank |
| RQ4 | "How does this role fit with the move to digital channels in the strategy brief?" | It shows you have read the brief without reciting it, and it surfaces how much of the job is digital |
| RQ5 | "What happens after round 3, and how soon do you decide?" | A plain, expected question; it shows you are managing the process, not only the interviews |

## Round 2: the Head of Member Services, your would-be manager (45 minutes, mostly behavioural)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| B Skeptic | Quiet, persistent probing of the stated gaps and of why this step | Highest. A hiring manager's usual mix is capability and skepticism, because they are buying a capability and pricing the gaps; your own sentences name two gaps (F2, F8) and the JD names both | Rehearse B2 until the concession sounds ordinary; every acknowledgment is one plain clause followed by a plan |
| C Prober | "Walk me through" on the log, the spreadsheet and the training | High. "Mostly behavioural" means stories get followed two levels down, and each of your claims has a short sentence behind it | Know what each sentence states and stop there; when a follow-up goes beyond it, answer the slot's honest branch |
| D Values and Behavioural | "Tell me about a time" prompts | Medium. The recruiter's email puts the values scoring with the panel, so round 2 behavioural is competence-led rather than values-led. The JD's coaching and senior-audience lines supply the themes | Use the selection scaffolds in D1 and D2; if no story fits, say so plainly |
| E Case | One live problem on the digital line | Low to medium. A hiring manager's usual mix includes a case, but "mostly behavioural" pulls it down and the panel owns the escalation case | Think aloud, clarify first |
| S Pressure | Time-boxed challenge | Low. Nothing in the email suggests a stress style | Pause before answering |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B2 | "The role owns the complaints process across branches and the contact centre, and you've said you haven't worked in a contact centre. How would you own that part?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level."; "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The deepest rehearsal here, in four layers. Say the limit first, before it is pressed: "I haven't worked in a contact centre." Hold only what the sentence carries, at its own scope: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Follow-up one, "why would a branch log carry over?": return to the log and the script and do not say the two processes are the same. Follow-up two, "what would you do in your first weeks?": a plan, said as a plan, for how you would learn how complaints reach the contact centre and where they join the branch process. Follow-up three, "what if the contact centre team knows more than you?": concede explicitly, in words like "On that part they will know more than I do on day one", and do not fold on the log and the script | F2 is your stated gap and the JD's first line names the contact centre, so this question arrives in some form. JD because it scores a stated responsibility; it gets the most follow-up levels because it is the most likely objection |
| B3 | "The role asks for confidence presenting to senior leaders, and you've said you haven't presented above regional level. What would you do about that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level."; "I built the monthly complaints spreadsheet our regional manager uses." | Open with the plain statement: "I haven't presented to anyone above regional level." Then, as a plan, how you would prepare a first presentation to senior leaders: what you would want to know about the audience and what you would put first. Answer slot: if you have presented complaint figures in person to anyone, say to whom and what part was yours; if the spreadsheet was only sent or read, say so plainly and stay with "I built the monthly complaints spreadsheet our regional manager uses." Hold through two follow-ups by returning to that sentence, never by adding to it | F8 is your stated gap and the JD names it as a requirement. JD because it scores that requirement; the slot lets the premise be false |
| B4 | "You've been a branch supervisor for three years. Why is this the next step rather than a branch manager role?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Give your own reason, in your own words, and point it at the content of this role (complaints, reporting, coaching) so it reads as a move toward something. Keep to what the sentence says: six years in retail banking, the last three as a branch supervisor. Say only the part of your reason that is true and relevant | A manager tests motivation consistency before spending a year on someone. F9 is the evidence base; EXP because it tests whether your story holds together |
| B5 | "The role works with digital teams on self-service journeys. What's your experience there?" | JD | [grounded] | Answer slot: if you have worked with an app or digital team on anything members use, say what it was and which part was yours, in your own words; if you have not, say so plainly, and say what you would want to ask them first, as a plan | F7 is a discovery row, so the answer is not yet in the pack. The JD's last responsibility line and G1 make a probe likely |
| C1 | "Walk me through the monthly complaints spreadsheet you built — what did it show, and who used it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F4 and F5, at the sentence's scope: you built it, it was monthly, it was about complaints, your regional manager uses it. Answer slot: expect a probe on whether it showed volumes, resolution times or both, and in which tool. If it showed either, say which and how each was counted; if it showed something else, say so plainly and say what. Name the tool, whichever it was | The JD asks for reporting on volumes and times and for Excel; F4 and F5 are the rows a prober presses. EXP because it tests what you built |
| C2 | "How did the complaints log work at your branch?" | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Tell it at the sentence's scope: you handled the branch's formal complaints log. Answer slot: the JD's first responsibility line makes a probe likely on what happened to a complaint before it reached the log and after it left. If any stage beyond the log was yours, say which and what you did; if the log was where your part began and ended, say so plainly and stay with the log | F1 and F3 are where the prober goes next. EXP because it tests whether you can describe the work you say you did |
| C3 | "Tell me about training the new tellers on the escalation script." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F6: new tellers and the escalation script, the two beats the sentence states. Answer slot: the JD asks for coaching branch supervisors, so expect a probe on whether it went beyond the script. If you ever helped a supervisor with an escalation, say what and which part was yours; if the training was the script and the tellers, say so plainly and stay there | F6 is a transferability row and the relationship differs: tellers are not supervisors. EXP because it tests what was actually yours |
| D1 | "Tell me about a time you coached someone through a difficult escalation." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold, because no sentence of yours carries a coaching story: pick a time a colleague was stuck on an escalation and you helped; it needs the specific escalation, what you said or did, and what happened to the member. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I trained new tellers on our escalation script", or how you would handle it | The JD's coaching line is the raising source, and F6 shows where the material stops. JD content, behavioural delivery |
| D2 | "Tell me about a time you delivered an unpopular truth to someone more senior." | EXP | [generic] | Selection scaffold: pick a time you told someone senior what they did not want to hear; it needs the specific message, how you chose to say it, and the working relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A manager who needs someone to report upward tests this directly; F8 is the related gap. EXP because it tests a past behaviour, not a published value |
| E1 | "Digital want to let members raise a complaint in the app. What do you need to know first, and what would worry you?" | CASE | [grounded] | Clarify before you structure: what counts as a complaint in the app, who sees it, who keeps hold of it. Then the objective, the kinds of complaint, your approach, the measures (the JD's own: volumes and resolution times) and the risks. Say the structure aloud. A position to argue, not a claim about your past: whoever receives a complaint in the app still keeps hold of it until it is solved, which is the wording of Ashgrove's own value. Concede what the app does better, which is access at any hour | The JD's digital line and G1 raise it, and F7 shows you have no stated experience there, so reasoning aloud is the rehearsal. CASE because it is a live problem from the role |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ6 | "What would you want me to have understood by day 90?" | It asks for the manager's own measure and ties your first quarter to it |
| RQ7 | "Which senior leaders see the monthly complaints report today, and what do they ask about it?" | It shows you are already thinking about the audience your stated gap (F8) points at |
| RQ8 | "How do contact centre and branch complaints reach the same record today?" | It goes straight at the part of the role you have not done and shows you want to learn it |
| RQ9 | "Who decides when a complaint journey moves into the app, and how do complaints teams get a say?" | It connects to G1 and to F7 without claiming digital experience |
| RQ10 | "What is the hardest part of this role that the JD doesn't say?" | A generic but strong question for a future manager; it invites candour |

## Round 3: the panel of two branch managers (60 minutes, values round, 20-minute escalation case)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| D Values and Behavioural | Scenario prompts scored against the four published values | Highest. The recruiter says the panel "is also the values round — they score against the four values", and a values round documented by the recruiter is the strongest weighting evidence | A story or an honest scaffold for each of the four values (cheat sheet below) |
| E Case and Strategist | The 20-minute escalation case, plus strategy altitude | High. The recruiter names the case; twenty of sixty minutes is a third of the session | Clarify, structure, think aloud; challenge one premise respectfully |
| P Peer | The seam between your role and a branch manager; credit and disagreement | Medium. The JD has you coaching branch supervisors, who sit in these managers' branches, so they are pricing what you cost and contribute to their work; this is an inference from the JD and the panel's roles | Reciprocity framing: what you bring their supervisors, and seam principles in place of pretending to know the seam |
| S Pressure | A time-boxed challenge on the gap | Low. Panels of peers rarely run a stress style, but B2's objection can return in time-boxed form | Hold, then concede |
| A, B, C | Conversational, Skeptic, Prober | Low in this round; the Skeptic's questions come back inside D and P | Nothing specific |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D3 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] | Selection scaffold, because no sentence of yours carries this story: pick a time you chose what was right for a member when it cost you, the branch or a target something; it needs the specific decision, what it cost and what the member got. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The value "Members First, Always" is the raising source. VAL because it scores the published value, not generic virtue |
| D4 | "Tell me about a time a member needed something explained twice." | VAL | [grounded] | Selection scaffold: pick a time something you said or wrote was not clear enough the first time; it needs the specific thing, what you changed, and what the member understood afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | "Plain Words — if a member needs it explained twice, we wrote it wrong" is the raising source, and complaint responses are written work |
| D5 | "Tell me about a time you put a branch's town ahead of a number." | VAL | [grounded] | Selection scaffold: pick a time a figure pointed one way and the people or the place pointed another, and you went with the people or the place; it needs the specific figure, the decision and the result. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The value "Neighbours, Not Numbers" is the raising source; F4 is the numbers side of the pairing, so a monthly-spreadsheet builder will be asked it. H2 shows the pull with the consolidation |
| D6 | "Tell me about a time you kept hold of a problem until it was solved." | VAL | [grounded] | Selection scaffold: pick a time you found a problem and stayed with it through every handover until it was solved; it needs the specific problem, who else it passed through, and the end. Expect the tension with escalation: an escalation hands a case on, and the value says the finder keeps hold. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | "Own the Fix — whoever finds the problem keeps hold of it until it is solved" is the raising source, and it bears directly on an escalation role |
| E2 | "A member has complained at the counter twice about the same fee. The supervisor isn't sure whether it is now a formal complaint or should be escalated. Walk us through what you do." | CASE | [generic] | Clarify first: what the member said and what was recorded, what they want, and any time limits that apply. Then objective, approach, measures and risks. Who keeps hold (the value), what the member is told and in what words (the value), what is recorded. If you do not know the rules Ashgrove's complaints sit under, say so and say who you would ask; do not invent a time limit. Say the structure aloud and challenge one premise respectfully | The recruiter names a 20-minute case on a complaint escalation; this is the pattern for it. The pack has no information about the actual case |
| E3 | "A complaint starts in the contact centre and the member then walks into a branch. Who owns it, and how does the member experience that?" | CASE | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Reason from principle; you can say plainly that you have not worked in the contact centre. One owner who keeps hold of it (the value), a written handover so the member never repeats the story (the value on explaining twice), and what the branch and the contact centre each see. A position to argue, with its concession: one owner can slow a handover when the owner is not in the room | The JD names branches and the contact centre, and F2 is your stated gap, so reasoning aloud from principle is the rehearsal |
| E4 | "Eight branches are becoming five hubs over 2027. What happens to complaints from members whose branch changes, and what would you want in place?" | CO | [grounded] | Bring one item from the brief to show grounding (G2), then your own position. Thesis to argue: agree who keeps hold of an open complaint before a branch changes, and watch complaint volumes by branch before and after each change. Concession: that relies on figures being comparable across the old and new structure, which you have not seen. Anti-pick: do not move a member with an open complaint into a new channel mid-complaint | G2 is the raising source and the panel are branch managers. CO because it scores strategy at Ashgrove's altitude; differentiate from the brief, do not recite it |
| P1 | "You'd coach our supervisors on escalations. They know their branch and their members better than you will. How do you earn their time?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor."; "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Reciprocity: say what you would bring their supervisors, and propose principles for the seam rather than claiming to know it. You can say you were a branch supervisor for three years and speak to what a supervisor wants from a coach as your own view. Do not say you coached supervisors; the sentence says new tellers and a script | F6 is a transferability row and the panel sits on the supervisors' side of the seam. JD because it scores the coaching line |
| P2 | "Where's the seam between you and a branch manager when a complaint comes in? What happens when we disagree?" | CASE | [generic] | Seam principles: the branch keeps the member relationship; the lead owns the process and the reporting; one owner per complaint. For the disagreement, a selection scaffold, because no sentence of yours carries one: pick a time you disagreed with someone at your level or above on how to handle a case; it needs what each of you wanted, how it settled and the relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The peer persona's standard stem, set in the JD's own seam between a central lead and the branches |
| S1 | "Sixty seconds: why you rather than someone who has worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level."; "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Hold, then concede. Hold what the sentence carries, at its scope: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Concede explicitly: "I haven't worked in a contact centre." Do not argue you are better; say what you offer and the part you would learn. Hold through two follow-ups; if pressed on the gap, repeat the concession in the same words | B2's objection in its time-boxed form; Pressure is low-weight here but this is the one place it is likely to appear |

### Values cheat sheet

Values are as published on ashgrovecu.org/about/values, copied on 17 November 2026.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Selection scaffold (D3): pick a time you chose what was right for a member when it cost something; it needs the decision, the cost and what the member got. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Plain Words | If a member needs it explained twice, the writing was wrong | Selection scaffold (D4): pick a time something you said or wrote was unclear the first time; it needs the thing, the change and what the member understood afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Neighbours, Not Numbers | Every branch is part of its town | Selection scaffold (D5): pick a time a figure pointed one way and the people or the place pointed another; it needs the figure, the decision and the result. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Selection scaffold (D6): pick a time you stayed with a problem through every handover; it needs the problem, who else it passed through and the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

None of your quoted sentences carries a story for any of the four, so all four are scaffolds. The most useful next step is to find candidate stories before 26 November; if one of them comes to mind outside this conversation, send it and the sheet regenerates.

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ11 | "What could a new Member Experience Lead do in their first month that would genuinely lighten your supervisors' load on escalations?" | Reciprocity: it asks what you can give the people you would work beside |
| RQ12 | "When a complaint has come up in your branch, what did you wish the central process had done differently?" | It invites a real story, which is worth more than a policy answer and gives you material for the seam |
| RQ13 | "How do you expect complaint handling to look across the hubs once eight branches become five?" | It uses G2 and asks for their view without reciting the brief |
| RQ14 | "How do your supervisors currently learn the escalation steps?" | It goes at the coaching line (F6) and shows you want the starting point |
| RQ15 | "What would make a branch say a complaint had been owned rather than passed on?" | It uses the value's own idea of ownership and asks for their measure |

## Requirement coverage

| JD requirement | Fit row | Questions |
|---|---|---|
| "Own the member complaints process end to end across branches and the contact centre" | F1, F2 | A7, B2, C2, E2, E3, S1 |
| "report monthly on complaint volumes and resolution times" | F4 | C1, B3 |
| "coach branch supervisors on escalations" | F6 | C3, D1, P1 |
| "work with digital teams on self-service journeys" | F7 | B5, E1 |
| "4+ years in financial-services customer operations" | F9 | A1, B4 |
| "experience handling regulated complaints" | F3 | A7, C2 |
| "confident presenting to senior leaders" | F8 | B1, B3, D2 |
| "comfortable with Excel reporting" | F5 | C1 |

Each of the four published values has a VAL question (D3 to D6). Your material states no headline figure, so there is no defend-the-number question.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches | Inflated form of F1 | F1's sentence at its own scope. The limit is the pack's observation, not words for you: the material says the branch's log and the script, not the process end to end. The slots in A7 and C2 stay inside the log |
| Has handled regulated complaints | Inflated form of F3 | F3's sentence at its own scope. The pack's observation: the material says a formal log, not what it sat under. A7's slot asks only what the log was kept under, in your own words |
| Has worked in a contact centre, or that branch work covers it | A negative you stated, F2 | The plain acknowledgment F2 gives: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | A negative you stated, F8 | The plain acknowledgment F8 gives: "I haven't presented to anyone above regional level." No slot |
| Has coached branch supervisors on escalations | Inflated form of F6 | F6's sentence at its own scope. The pack's observation: the material says new tellers and a script, not supervisors and not coaching. C3's slot stays with the tellers |

## Sources

**Provided documents:** the JD as you pasted it; Ashgrove's four values, copied by you on 17 November 2026 from ashgrovecu.org/about/values; the recruiter's email on the three rounds; the four strategy points from the 2026 strategy brief published in July 2026, as you pasted them (the full brief is not in hand); your own background message. No dossier was present. No searches or fetches were sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | Could not have moved the values cheat sheet: the four values and their definitions are in hand, pasted this morning |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | Could not have moved the persona weights: the recruiter's email establishes three sessions and who runs each |
| 3. `Ashgrove Credit Union strategy` | skipped | Could not have moved the CO bank: the four points from the July 2026 brief are in hand and fix G1 to G4 and E4 |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- A CV, or any document describing your work → the fit snapshot rests on one message, so nothing is above medium; a CV could surface evidence you did not mention and move rows toward high
- A copy of the monthly complaints spreadsheet with member details removed, and the complaints procedure the branch worked under → rows F3, F4 and F5, which are the ones an interviewer can test, could be graded against something inspectable
- Your answers to the answer slots, in your own words, outside a drill → rows F1, F3, F4, F5, F6 and F7 regenerate, and the stories in D1 to D6 may become mapped instead of scaffolds
- The full text of the July 2026 strategy brief → the grounding brief currently holds four points
- The interviewers' names once assigned → persona weights per person, a tailored reverse question, and an interviewer read
- The format of the round 3 case (sent in advance or not, written or spoken) → the E2 and E3 structure could be fitted to it
- How many hours you have before 26 November → a prioritized prep schedule
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a fuller grounding brief, interviewer footprints once names exist, reports on this kind of loop, and recent organisation context
- A tuesday-dossier.md from an earlier session → a stronger objection ranking and a confirmed-evidence list in place of the inferred ones
