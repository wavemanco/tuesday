# Interview prep pack: Product Manager, Platform APIs at Quartzline

**Round:** a 45-minute conversation with the hiring manager, on Thursday. Interviewer unnamed. This is one session, so this is a session-mode pack.
**Built from:** your dossier (version 1.1, dated 2026-08-14). No outside research ran, because search was refused in this session. See Sources.

## How to use this pack

- **Personas** are how a question gets asked. **Types** are what the question scores.
- Type key: **VAL** is values alignment from past behavior. **EXP** is a deep-dive on your own experience and what was actually yours. **JD** tests a stated requirement or responsibility. **CO** tests company and strategy knowledge. **CASE** is a live problem from the role.
- Guidance is scaffolding, not a script. Every claim about your past rests on a sentence quoted in the same row. An **answer slot** is an instruction for the interview, not a question for you now. Answer it from your own experience, or say plainly that the practice was not yours.
- Provenance labels: `[grounded]` is traceable to your dossier. `[inferred]` is this pack's derivation, named in the row. `[generic]` is a role-family pattern with no claim about you or Quartzline.
- All wording below is proposed language, pending your approval. Change anything that does not sound like you.

## Prep triage (two days to Thursday)

1. Say A1 aloud until it is boring. It is the highest-ROI prep in this pack: your dossier names it as the objection you will face, and every other gap question is a variant of it. Do it three times, then once in sixty seconds (E1).
2. Say A2 and A3 aloud, then C1 and C2. These are the other gaps and the two numbers-and-metrics probes.
3. Do B2 and then B1 aloud with a timer, thinking out loud as you go.
4. Pick three reverse questions. Take the first two from the dossier's own risks.
5. Read Quartzline's own public site and developer docs for D2. This pack could not research the company.

Everything else is insurance.

## Fit snapshot

Requirement lines are quoted from your dossier's `role_profile`. Evidence cells hold only your confirmed claims, quoted exactly from the dossier. The proposed bridge wording is pending your approval.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [grounded] | transferability | The dossier's strategy is bridge, positioned as adjacent and never as PM experience. Words at the quote's scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs, through scoping, requirements, architecture, UAT and go-live." The limit is the pack's observation: your material shows integration leadership, not a product manager title or role. Let the interviewer draw the inference |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibilities | none given | none | [grounded] | capability | The dossier records this as acknowledge_gap and lists prohibited_claims: "Having owned a product roadmap" and prohibited_claims: "Having set prioritization for an engineering squad". No bridge. Words, sourced by those fields: "I haven't owned a product roadmap." Then a ramp plan said as a plan, never as a past: how you would learn where roadmap decisions sit |
| F3 | "Shipped API or platform products" — dossier role_profile R2 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [inferred] | transferability | The dossier handoff lists R2 as high priority but its weak-area list does not grade it, so this grade is the pack's reading of the quote against the requirement. The quote says integrations of the vendor's APIs, not shipping a product. Words stay at its scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Any wider claim comes from you, outside this pack |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | low | [inferred] | discovery | The quotes touch the requirement without showing API docs or schemas. Answer slot: the JD's wording makes a probe on docs and schemas likely. If you have read or written API docs or schemas, say which and for what, in your own words; if not, say so plainly and return to the playbook you wrote |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [inferred] | transferability | The client side and the product side have quotes; the engineering and sales sides have none. The second quote is confirmed with limited inspectable proof, so expect a probe and volunteer that limit yourself. Answer slot: if engineering or sales were part of those integrations or sessions, say how and what you did; if not, or if that was not your side, say so plainly and stay with the clients and product |
| F6 | "Agile delivery experience" — dossier role_profile R5 | none given | low | [grounded] | discovery | The dossier's strategy is clarify. Answer slot: the JD's wording makes a probe on how you have worked in a delivery cadence likely. If you have worked in one, say how, in your own words; if you have not, say so plainly and say what you would want to confirm about how the squads define it |
| F7 | "Run discovery with integration partners" — dossier role_profile responsibilities | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [inferred] | transferability | Words at the quote's scope: "I ran quarterly roadmap-input sessions that fed client evidence to product." Confirmed with limited inspectable proof, so name that limit before it is extracted. Answer slot: if you shaped what those sessions asked clients, say how; if the agenda was set elsewhere, or there was none, say so plainly and stay with the sessions you ran |
| F8 | "Write specs and drive delivery with two engineering squads" — dossier role_profile responsibilities | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [inferred] | transferability | The quote carries requirements and go-live on client integrations, not specs for squads. Words stay at its scope. Answer slot: if you wrote any of the requirements for an integration, say what they covered; if they came from elsewhere, or were not written down, say so plainly and return to the integrations you led |
| F9 | "Define and track adoption metrics" — dossier role_profile responsibilities | none given | none | [grounded] | discovery | The dossier leaves the current baseline as an open risk. Answer slot: if you defined or tracked any measure of how clients used what you integrated, say what it counted; if not, say so plainly and say what you would want to know first |

## Persona table

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the title and roadmap gap | 5 questions. Hiring-manager prior, plus the dossier names this objection, plus F2 is a recorded capability gap | Rehearse A1 until boring; concede first and specifically; bridge only at the quotes' scope; a ramp plan, never a past |
| Case/Strategist | Live problems on the partner API roadmap | 4 questions. Hiring-manager prior; the role's responsibilities give the case material | Clarify, then structure, then answer; think aloud; challenge one premise respectfully |
| Data-Driven Prober | Asks how the 30+ was counted and what adoption means | 3 questions. F9 is a stated responsibility and the figure in F1 is a magnet | Know what you can say about how the figure was counted; say plainly where you do not know |
| Conversational | Friendly opener, casual questions that are still scored | 3 questions. A 45-minute conversation opens with a biography question | A 90-second arc built only from your three confirmed claims; treat casual questions as scored |
| Pressure | Time-boxes you, repeats the objection in sixty seconds | 2 questions. A hiring manager is a low prior for this, but the objection invites a time-boxed version | Pause, restate, hold through two follow-ups, concede specifically |
| Peer Evaluator | Seam questions about the two squads' leads | 2 questions. The dossier's authority question is open, so a seam probe is plausible | Propose seam principles and never claim to know the seam; reciprocity framing |

No values-style round is detected: your words establish one hiring-manager conversation, and no source names a values round. A Values/Behavioral bank and a values cheat sheet are therefore not included. No interviewer profile exists, so there is no interviewer read.

## Question banks

### A. Skeptic (highest weight)

Proposed language, pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | **The highest-ROI rehearsal in this pack; your dossier names this objection, so it is not inferred.** Order: (1) concede first, plainly. The dossier's prohibited_claims lists "Having held a product manager title or role" and "Having owned a product roadmap", so the words are "I haven't held the product manager title and I haven't owned a roadmap." (2) The bridge, at the quote's scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs, through scoping, requirements, architecture, UAT and go-live." (3) Name the limit yourself: that is adjacent work, not PM experience. Let them draw the inference. (4) A ramp plan, said as a plan: in your first weeks you would learn where decisions sit between you and the squad leads, and what the adoption baseline is. Follow-up one, "so you'd be learning on our time": hold by returning to the quote, concede that yes, there is a ramp, and say what the plan is. Follow-up two, "what would make you ready": say what you would learn and from whom, and promise no outcome | The dossier's likely_interviewer_objections item, word for word. F1 is the bridge and F2 is the part that gets conceded. JD because it scores the PM requirement; the delivery is Skeptic |
| A2 | "When have you shipped an API or platform product?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold only what the quote carries: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Do not relabel that as shipping a product; the pack's observation is that your material says integrations, not a shipped product (section 13). Answer slot: the JD's must-have line makes a probe on which parts of those integrations were yours to decide likely. If you decided any of the scoping, requirements or architecture, say which and how, in your own words; if those were set elsewhere, say so plainly and return to the integrations you led. If you pressed on a product you shipped, repeat the quote and add nothing | R2 is a must-have and F3 shows how thin the match is, so this is likely early. JD because it scores the stated requirement |
| A3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] prohibited_claims: "Having owned a product roadmap" | Say it first, plainly: "I haven't owned a product roadmap." The source is the dossier's prohibited_claims and its acknowledge_gap area. Then the ramp plan: who you would learn decision rights from and what you would ask. Do not pick a weakness you cannot back, and do not soften this one into a strength. Candor on the part the interviewer personally owns reads as judgment | F2 is the biggest gap and the question names it. JD because the answer scores against the role's own roadmap line; Skeptic delivery |
| A4 | "Your background is integrations. Why product, and why now?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Start with the quote at its own scope. The reason you want the product side is yours, and nothing in your material states it. Answer slot: say in your own words what drew you toward product; if one specific thing from the integrations you led pointed you there, name it; if no single thing did, say so plainly and say what you want to build next. Do not borrow the JD's wording as your motive | Motivation consistency is what a Skeptic scores. F1 is the evidence for the background the question presumes. EXP because it tests your own story |
| A5 | "Tell me about working inside an agile delivery cadence." | JD | [grounded] | An open prompt from the JD's R5 line, with no claim about your past written here. Answer slot: if you have worked in a delivery cadence, say how and what your part was, in your own words; if you have not, or only alongside one, say so plainly and say what you would want to confirm about how these squads define it. The dossier's strategy for this area is clarify, so a question-shaped answer is correct | F6 is a discovery gap and the dossier's allowed strategy is clarify. JD because it scores a preferred requirement |

### B. Case/Strategist

Proposed language, pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Suppose partner adoption of one of our APIs has stalled. What do you need to know first, and what do you do?" | CASE | [generic] | No claim about your past. Clarify first: what adoption means here, what the baseline is, which partners and where in the path they stop. Then structure: hypotheses, who you would talk to, what you would measure, risks. Challenge one premise respectfully, for example that "stalled" has a defined baseline. Think aloud | A live problem built from the role's adoption-metrics line (F9), asked as a decision, not a record. `[generic]` because it is a pattern for the problem, not a fact about Quartzline |
| B2 | "Two squads, one quarter, and more partner and sales requests than they can build. How do you decide what goes on the roadmap?" | CASE | [generic] | No claim about your past. Say your assumption aloud: that you do not yet know which decisions are yours alone and which belong to the squad leads, and that you would ask. Then propose principles rather than a verdict: how you would weigh partner impact, effort and risk, and who you would involve. Ask the question the dossier left open, the seam, as part of the answer | F2 is the gap and the dossier's open question on decision authority. CASE because it is a live roadmap problem; it needs no claim about owning prioritization |
| B3 | "Walk me through how you would run discovery with an integration partner." | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Lead with the plan: what you would ask, how you would test it, how you would turn it into a requirement. Then, where it applies, the quote at its scope: "I ran quarterly roadmap-input sessions that fed client evidence to product." Name the limit before it is probed: it is confirmed, with limited inspectable proof. Answer slot: if you shaped what those sessions asked clients, say how; if the agenda was set elsewhere, or there was none, say so plainly and stay with the sessions you ran | F7 is confirmed but thin, so a prober will find the seam. JD because the responsibility is stated; the question is phrased as an approach |
| B4 | "How would you write a spec for a new endpoint so two squads can build from it?" | JD | [grounded] "Wrote the internal integration playbook her team uses" | The structure of a good answer is a generic pattern: the problem and the partner need, the request and response contract, error cases, versioning and deprecation, how success is measured, open questions. Say that you would ask the squads what they need to see. The one piece of writing your material shows is the playbook, at its scope: "I wrote the internal integration playbook my team uses." Answer slot: if you have read or written API docs or schemas, say which; if not, say so plainly and return to the playbook | Covers the specs responsibility (F8) and technical fluency (F4). JD because both are stated; CASE-style delivery |

### C. Data-Driven Prober

Proposed language, pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You led 30+ integrations. How was that number counted?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The figure counts integrations, and the quote's verb is "led". Answer slot, in your own words: how the 30+ was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. Say the weakest assumption before they do; it turns a gotcha into credibility. Do not describe a counting method you cannot repeat under a second question | A headline figure is the first thing a prober tests. F1 holds the number. EXP because it tests whether the claim survives scrutiny |
| C2 | "The role defines and tracks adoption metrics. What would you track for a partner API, and what do you need to know before you pick?" | JD | [grounded] | The question is about an approach, so the guidance makes no claim about your past. Say what you would want first: what adoption means here and what the baseline is today (the dossier leaves it open). Then a few measures, in your own words, and what each would and would not tell you. Answer slot: if you have defined or tracked any measure of how clients used what you integrated, say what it counted; if not, say so plainly and go to what you would want first | F9 is a discovery gap on a stated responsibility. JD because the line is the JD's own |
| C3 | "What does your integration playbook cover, and who uses it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | The one artifact the dossier marks inspectable. Say it at its scope: "I wrote the internal integration playbook my team uses." Answer slot: describe what is in it, in your own words, and if a section was written by someone else, or the playbook is not yours to share, say so plainly. Offer to walk through it only if it is yours to share | An inspectable artifact is where a prober tests evidence. EXP because it tests what was actually yours |

### D. Conversational

Proposed language, pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc in three beats, each at its quote's scope: the 30+ integrations you led, the playbook you wrote, the sessions you ran that fed client evidence to product. "We" for context, "I" for contribution. Answer slot: why you are moving toward product is yours to say, in your own words. Do not add a title, a team size or an outcome the quotes do not carry | The biography question opens most conversations and is scored. F1, F5 and F7 supply the beats. EXP because it tests your own story |
| D2 | "What draws you to Quartzline?" | CO | [generic] | No company research ran, so the pack supplies no Quartzline facts. Selection criteria: one specific thing you have read in Quartzline's own public material, and one connection to the work in your quotes. If nothing specific has come up yet, say so plainly, then say what draws you to a partner-facing API platform and ask them a question. Do the reading before Thursday (triage item 5) | A casual company question that rapport-style interviewers score. `[generic]` because the pack could not research; it becomes grounded if you add a source |
| D3 | "What are you playing with in API tooling or docs these days?" | JD | [generic] | Casual register, still scored against the JD's technical-fluency line. Answer slot: say what you are actually using or reading, in your own words; if nothing, say so plainly and name what you would look at first. Do not name a tool you have not used | A casual question on a hot JD topic. F4 is the discovery gap behind it |

### E. Pressure

Proposed language, pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a PM who has done this job for three years?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | A1 compressed. Pause, restate, then three beats: concede the title and roadmap plainly, the quote at its scope, the ramp plan. Hold through two follow-ups by returning to the quote, never by adding to it. Concede the limit explicitly and specifically | The time-boxed version of the objection; F1 and F2 again. EXP because it tests what you will stand behind |
| E2 | "Those 30+ integrations — how much of that was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold on the quote's own verb: "I led them." Answer slot: say which parts were yours and which were the team's or the client's, in your own words; if you do not know, say so plainly. Concede specifically and keep the core claim: you led them | The attribution probe the pressure persona exists for. F1 is the claim being tested |

### P. Peer Evaluator

Proposed language, pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Tell me about a time you had to keep engineering, sales and a customer pointed at one plan." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | An open prompt from the JD's R4 line. Pick an integration where more than one side had a stake, and tell it at the quote's scope. Answer slot: if engineering or sales were part of it, say how and what you did; if one of those sides was not, or was not yours to coordinate, say so plainly and stay with the client and the integration. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry | F5 has quotes for clients and product but none for engineering or sales. EXP because it tests the story behind the line |
| P2 | "Where is the seam between you and a squad lead on what gets built, and what happens when you disagree?" | JD | [generic] | No claim about your past. Propose seam principles rather than pretending to know the seam: what you bring to the squad leads, what you need from them, how a disagreement gets resolved. Ask where the line sits today; it is the dossier's own open question. Do not imply you have set priorities for a squad | The dossier leaves decision authority unevidenced. F2 is the gap. JD because the responsibility is stated; Peer delivery |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "3+ years product management experience" (F1) | A1, A3, A4, E1, E2 |
| "Own the roadmap for the partner-facing API platform" (F2) | A1, A3, B2, P2 |
| "Shipped API or platform products" (F3) | A2 |
| "Technical fluency: API docs, schemas" (F4) | B4, D3 |
| "Stakeholder management across engineering, sales, customers" (F5) | P1, P2 |
| "Agile delivery experience" (F6) | A5 |
| "Run discovery with integration partners" (F7) | B3, D1 |
| "Write specs and drive delivery with two engineering squads" (F8) | B4, P2 |
| "Define and track adoption metrics" (F9) | B1, C2 |

## Reverse questions

Two come straight from the dossier's open risks.

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | Decision authority is asserted in the JD and not evidenced. It reads as diligence, and you need the answer before you accept |
| R2 | "How is partner API adoption measured today, and what is the current baseline?" | Adoption metrics are named as a responsibility with no baseline stated. It sizes the job and shows a metrics mindset |
| R3 | "What do the people who ramp fastest in this role have in common?" | It invites the manager to say what they actually screen for, which is the part of the bridge you cannot see |
| R4 | "How do the two squads get partner input into their work today, and what would you change about it?" | It tests the discovery side of the role and shows you are thinking about the work, not the title |
| R5 | "Is there anything about my background you would want more evidence on before you could say yes?" | It hands the manager the A1 objection while you are still in the room, so you can answer it live |
| R6 | "What would you want to see from this PM in the first ninety days?" | It turns the ramp plan from A1 into their stated expectation |

## Prohibited claims

The first three come from the dossier's `prohibited_claims`. The last three are inflated forms of wording in the fit snapshot, built here. Nothing in this pack asserts, softens or implies any of them.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims | F1's quote at its own scope, plus "I haven't held the product manager title", sourced by that field |
| Having owned a product roadmap | Dossier prohibited_claims, and the acknowledge_gap area on F2 | "I haven't owned a product roadmap", sourced by that field. The sessions in F7 are sessions that fed client evidence to product, not roadmap ownership: that limit is the pack's observation |
| Having set prioritization for an engineering squad | Dossier prohibited_claims | Same plain acknowledgment, sourced by that field. B2 and F2 stay at principles and never claim a past |
| Shipped an API or platform product | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says integrations of the vendor's APIs. A2's slot stays inside those integrations |
| Ran discovery with integration partners | Inflated form of F7 | F7's quote at its own scope. B3's slot asks only what the sessions asked clients |
| Wrote specs and drove delivery with the squads | Inflated form of F8 | F8's quote at its own scope. B4's slot asks only whether you read or wrote API docs or schemas |

## Sources

**Provided:** `tuesday-dossier.md`, dossier_version 1.1, dated 2026-08-14. It supplied the `role_profile` section (the job-description equivalent) and `handoff_to_mock_interview`: verified candidate evidence, uncertain and weak areas, the likely objection, opportunity risks, employer questions and prohibited claims. The `decision` section was read as context only. The dossier carried no `evidence_map`, `evidence_state` or `risk_register`, so those were not used.

**Searches sent:**

- "Quartzline company values" — refused
- "Quartzline interview process product manager" — refused
- "Quartzline API platform strategy news" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Every call was refused. It would have fed the names of published values. No values-style round is detected anyway, so no values cheat sheet was moved |
| 2. `Quartzline interview process product manager` | unavailable | Every call was refused. It would have documented the loop. Your own words establish this one conversation, so persona weights rest on that and the hiring-manager prior |
| 3. `Quartzline strategy` / recent news | unavailable | Every call was refused. It would have grounded a CO or CASE question in current strategy. D2 and the cases are `[generic]` for that reason |
| 4. interviewer name and company | n/a | No name was given, so there was no query to form. There is no interviewer read |
| 5. representative Product Manager, Platform APIs JD | skipped | The dossier's `role_profile` supplies the requirement lines the fit snapshot and JD questions quote |

## Upgrade menu

- A name for the hiring manager → a tailored reverse question and persona weights read from their public footprint
- Search access, or Quartzline's own careers, about or developer-docs pages pasted in → D2 and the cases B1 and B2 become `[grounded]`, and the loop and any values round get a source. A deeper pass is also available: up to 6 more searches and 2 more fetches, several more minutes
- The recruiter's note on format → coverage of anything pre-declared, such as a case or a deliverable
- The current posting → a check that the dossier's requirement lines (dated 2026-08-14) still match what is live; F-row requirements quote them
- Anything you have shipped as an API or platform product, beyond the integrations → F3 and A2 regenerate with your sentence quoted
- A deck or notes from one of the quarterly roadmap-input sessions → F7 and F5's second quote move from medium toward high, and B3 becomes story-mapped
- Your answers to the slots in A2, A4, A5, B3, C1, C2 and P1, said outside a drill → those rows regenerate with your own sentences quoted
