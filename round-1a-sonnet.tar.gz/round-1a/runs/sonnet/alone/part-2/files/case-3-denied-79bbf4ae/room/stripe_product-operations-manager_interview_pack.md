# Interview prep pack: Product Operations Manager at Stripe (final round)

Interviewer: not given. Relationship: not given. Built as a blended final-round pack with flat persona weights, which is noticeably weaker than a pack built for a known interviewer. Nothing about the candidate's own past was supplied, so every answer-guidance cell is a story-selection scaffold, not a story map.

## How to use this pack

- Personas describe how a question is asked. Types describe what is being scored.
- Types: VAL (behavioral or values alignment), EXP (work-experience deep-dive), JD (role and responsibilities), CO (company and strategy knowledge), CASE (live problem).
- Provenance labels: `[grounded]` traces to something you provided or a cited source; `[inferred]` is derived from an adjacent source; `[generic]` is a role-family pattern with no claim about you or Stripe. Every row here is `[generic]`, because no CV, no JD and no research were available.
- Guidance is scaffolding, not a script. Where it says to pick a story, the story must be one you actually lived, told in your own words. Where nothing comes to mind, the honest branch is to say so plainly, then give the nearest thing you did do, or how you would handle it.
- Answer-slot style instructions are for the live interview; they ask nothing of you here.

## Fit snapshot (worksheet variant)

No CV or background was provided and no JD could be fetched, so each row is a role-family requirement, written as plain prose and labeled `[generic]`, with no evidence yet. Replace these with the JD's own lines when you have it. No eligibility or location terms are established by anything provided, so there are no gate rows.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinate launches or releases across several functions | none given | none | [generic] | discovery | Strong evidence is one named launch, the teams involved, and exactly which part was yours versus a PM's or program manager's. Selection scaffold: pick a launch where you can name the teams and your own part; if no such launch comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would run one |
| F2 | Run a recurring operating cadence or planning process that teams follow | none given | none | [generic] | discovery | Strong evidence is a process you set up or ran, who used it, and what changed because it existed. Selection scaffold: pick a recurring review, planning cycle or intake process where you can say what was yours to design versus inherited; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would build one |
| F3 | Use metrics to drive product or program decisions | none given | none | [generic] | discovery | Strong evidence is a number you can explain end to end: how it was counted, what it is sensitive to, the assumption you would defend least. Selection scaffold: pick one figure you can explain that way; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would set up the measurement |
| F4 | Influence and align stakeholders without direct authority | none given | none | [generic] | discovery | Strong evidence is a case where a group changed how it worked and you can say what you did versus what others did. Selection scaffold: pick a time you needed buy-in from people who did not report to you, with a named stake and a moment of friction; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach it |
| F5 | Carry customer or field-team feedback into product decisions | none given | none | [generic] | discovery | Strong evidence is a feedback channel or a specific piece of feedback and what happened to it. Selection scaffold: pick an instance where input from customers or customer-facing teams reached a product decision and you can name your link in the chain; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would build that loop |
| F6 | Improve process and tooling as the organization scales | none given | none | [generic] | discovery | Strong evidence is a process or tool you changed, why, and how you knew it worked. Selection scaffold: pick a change where you can state the before, the change and how you checked it; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or what you would change first |

## Persona table

No loop source established Stripe's final round, so these weights rest on a generic fallback (flat, tilted by the hiring-manager and peer relationship priors), not on Stripe's documented process. If your final is several back-to-back sessions, the weights hold for the blend, not for any single session.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (A) | Live problems: plan this, diagnose that | High. A hiring-manager prior, and product operations is process-and-judgment work that is easy to test live | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic (B) | Probes motivation and the owned-versus-influenced line | High. Same hiring-manager prior; a final round is where gaps get cross-examined | Rehearse the most predictable objection (B2) until it is boring; calibrated candor over bluffing |
| Values/Behavioral (C) | Scenario and story probes | Medium. No values-style round is detected, because no loop source was available; the generic fallback does not assume one | Pick stories where you can say what was yours; use I for contribution and we for context |
| Peer Evaluator (D) | Seam-splitting, credit, collaboration | Medium. Product operations sits between teams, so peers are plausible in a multi-session final | Reciprocity framing; propose seam principles, not a made-up seam |
| Data-Driven Prober (E) | Walks a number back to its assumptions | Medium. Operations roles are scored on metrics literacy | Know what you can and cannot say about how a number was counted; say plainly when you do not know |
| Pressure (F) | Time-boxes and devil's advocate | Low to medium. Composure test, more likely from a senior or skip-level interviewer | Pause, restate, hold a position through two follow-ups before conceding anything real |
| Conversational (G) | Friendly, loose, still scored | Low to medium. Casual openers are common; the danger is treating them as unscored | A 90-second arc for the biography question; never answer the reverse-question slot with nothing |

Highest-ROI prep: B2, the owned-versus-influenced probe. It is inferred from the role family, not from your material, because no CV was available. Product operations work routinely depends on people the hire does not manage, so some form of "how much of that was actually you" is the question most likely to arrive.

## Question banks

### A. Case/Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A product is shipping in six weeks across engineering, sales, support and legal, and nobody is sure who owns launch readiness. Sketch the plan. What do you need to know first?" | CASE | [generic] | Clarify first: what ships, to whom, what decides done, who can say no. Then objective, the owners and gaps, a readiness checklist and checkpoints, metrics for readiness, risks. Say your hypothesis early. This asks about no past of yours, so the guidance makes no claim about it | F1's requirement as a live problem; CASE because it scores structure, not a recalled story; `[generic]` because it is a pattern, not a fact about Stripe |
| A2 | "A usage metric for a core product dropped 20% week over week. Diagnose it." | CASE | [generic] | Clarify definition, time window and whether the data pipeline changed before touching causes. Segment by customer type, region, platform and release timing. Separate real change from measurement change. State what you would check first and what would change your mind | F3's requirement; CASE because the scoring is structure and reasoning |
| A3 | "Three product teams each plan their quarters differently and leadership cannot see across them. Design a lightweight operating cadence." | CASE | [generic] | Clarify what leadership needs to decide and what teams will tolerate. Propose the smallest shared rhythm (inputs, review points, one shared view), how you would pilot it with one team first, and how you would know it helped. Name the cost to the teams out loud | F2's requirement; CASE with a JD flavor because it is the core of the role family |
| A4 | "Support and sales both complain that product ignores their feedback. How would you fix the loop?" | CASE | [generic] | Clarify what feedback exists, where it lives and who decides. Offer a structure: capture, triage, route, close the loop with the person who raised it. Challenge one premise, such as whether product actually ignores it or lacks a way to rank it | F5's requirement; CASE because it presupposes nothing about your past |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Pick one real area from F1 to F6 where your material is thinnest and say so plainly, then a concrete ramp plan with the first two things you would do. Calibrated candor beats naming a fake weakness; if nothing comes to mind, say so plainly, then name what you would verify in the first weeks | A standard Skeptic stem; JD because it scores honest self-assessment against the role |
| B2 | "Pick the result you're proudest of. How much of it was actually you?" | EXP | [generic] | The highest-ROI rehearsal in this pack. Choose a result where you can separate your part from the team's. Name your part in the verbs you actually did, and name the part that was others'. Hold your position through two follow-ups by returning to what you did, never by adding to it; concede specifically what you do not know. If no such result comes to mind, say so plainly, then give the nearest thing your material does carry | Product operations leans on influence, so attribution is the likeliest probe; EXP because it checks what was actually yours |
| B3 | "Why product operations, rather than product management or program management?" | JD | [generic] | A short, honest account of what draws you to the role, in your own words, with one concrete thing you have done or want to do that shows it. Do not borrow the job description's vocabulary for your history. If your reasons are mixed, say so plainly | Motivation consistency is the Skeptic's core test; JD because it scores whether you understand the role |
| B4 | "Why Stripe, and why now?" | CO | [generic] | This pack could not research Stripe, so no company facts are supplied. Name two things you verified yourself on Stripe's own published pages and why each matters to you, plus why this moment in your career. If you have not done that reading, do it before the interview | CO because it tests homework depth; `[generic]` because no research was available |

### C. Values/Behavioral (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time with a named stake, what you said, how it landed and what happened to the relationship. Use I for your contribution and we for context. Choose one where the hard truth actually landed; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard Values stem; VAL because it scores behavior, not slogans |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick an instance with the metric named, the customer need named and your own decision named. Say what it cost and what you would do differently. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would weigh it | Standard Values stem; VAL because it scores a specific decision |
| C3 | "Ahead of a launch review in an hour, a teammate shares a draft you believe is wrong. What do you do?" | VAL | [generic] | A live problem, so no story is needed. Say what you would check first (are you sure), how you would raise it (privately, specifically, with a fix on offer), and what you would do if they disagree. Show spine and tact together | A behavioral probe set as a hypothetical; VAL with CASE delivery; presupposes nothing about your past |

### D. Peer Evaluator (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles instead of pretending to know the seam: who owns decisions, who owns the process, who is consulted. For disagreement, name how you would surface it early and what you would escalate and when | A standard Peer stem; JD because it scores partnership fit with the role |
| D2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Say your actual practice in your own words and, if you have one, a short instance where you can name who did what. If no instance comes to mind, say so plainly, then say how you would approach it | Credit-sharing is a Peer probe; VAL because it scores behavior toward equals |
| D3 | "What would you need from me in your first month, and what could you do for my team?" | JD | [generic] | Answer both halves: needs stated as specific access or context, and a give that is modest and real, such as a first-month listening pass that produces a written map of the seam. No overclaiming | Reciprocity framing is what the Peer persona scores |

### E. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Pick a number you've reported to leadership. Walk me through how it was counted." | EXP | [generic] | Choose a figure you can explain end to end. Say what was counted, over what period, and what it is sensitive to, in your own words. If you do not know how part of it was counted, say that plainly instead of guessing. If no such number comes to mind, say so plainly, then give the nearest thing your material does carry | Standard Prober stem; EXP because it checks whether a number survives scrutiny |
| E2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | The weakest-assumption move: name, in your own words, the assumption you would defend least before they find it. Where you do not know, say so plainly | The Prober's second level, asked as a follow-up to E1; EXP |
| E3 | "A dashboard shows adoption up 20% while support tickets are also up. What do you check first?" | CASE | [generic] | Clarify what each measure counts and over what window. Check for a common cause (a launch, a tracking change), then segment, then decide what each reading would mean for the product | A data probe set as a live problem; presupposes nothing about your past |

### F. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, restate the question, then give two or three reasons you can back with things you have actually done. Do not run down the internal candidate. Hold the core point through a challenge and concede specifically what you cannot claim | Standard Pressure stem; JD because it scores fit with composure |
| F2 | "Product operations is overhead. Convince me it isn't." | JD | [generic] | Hold your position without getting defensive: state what the function is for in a sentence, then one example from your own work if you have one. Concede where it can become overhead and what keeps it from doing so. If you have no example, say so plainly and argue from how you would measure the function's value | A devil's-advocate probe of the role's value; hold-then-concede |

### G. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc told in your own words: where you started, the two or three turns that matter, and why this role is the next one. Build it only from what you actually did; rehearse it aloud to time | The biography opener is scored even when it sounds casual |
| G2 | "What have you been trying lately that changed how you think about running a product organization?" | JD | [generic] | Name one real thing you have actually tried or read and what it changed for you. If nothing comes to mind, say so plainly and name what you are curious about | A casual question that tests genuine interest and communication economy |

## Requirement coverage

| Requirement | Questions |
|---|---|
| F1 Coordinate launches across functions | A1, B1 |
| F2 Run an operating cadence or planning process | A3, D1 |
| F3 Metrics-driven decisions | A2, E1, E2, E3 |
| F4 Influence without authority | B2, C1, C3, D1, D2 |
| F5 Customer and field feedback into product | A4, C2 |
| F6 Improve process and tooling at scale | A3, F2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a successful first 90 days look like, and what would you most want settled by then?" | It shows you think in outcomes and gives you the interviewer's own scoring sheet |
| R2 | "What is the most important thing product operations does here that people outside the function would not notice?" | It invites a real answer about the function and signals you care about the job, not the title |
| R3 | "Where does the function's work tend to get stuck: process, tooling, or people's attention?" | It tests how they diagnose and surfaces risks you may inherit |
| R4 | "How do you decide when a process the team built should be retired?" | It shows judgment about overhead, which is the F2 and F6 tension |
| R5 | "What is one thing you changed your mind about in this role in the last year?" | A candid, personal question that builds rapport and reveals how they think |
| R6 | "If a peer is in the room: what could a new person do in their first month that would genuinely help your team?" | The reciprocity question a Peer persona weights heavily |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| None built yet | No CV or background was provided, so there is no quoted sentence whose stretched form this pack could list | Supply a CV and this section is built from it before the banks are rewritten |

## Sources

Provided documents: none. Your message gave the company, the role and the round.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | Would have fed a values cheat sheet and the VAL and CO banks with the official principle names; the search was refused, so none are named |
| 2. `Stripe interview process product operations` | unavailable | Would have set the loop structure and persona weights; refused, so weights use the generic fallback |
| 3. `Stripe strategy` and recent news | unavailable | Would have grounded at least one CO or CASE question in current strategy; refused, so B4 and the CASE bank are generic |
| 4. `{interviewer name} Stripe` | n/a | No name was given, so there was no query to form |
| 5. representative `Product Operations Manager` JD | unavailable | Would have turned F1 to F6 into quoted `[inferred]` requirements; refused, so they are plain `[generic]` prose |

Queries sent, all refused: "Stripe operating principles values"; "Stripe interview process product operations manager"; "Stripe strategy news 2026 stablecoins agentic commerce tender offer"; "Stripe Product Operations Manager job description".

## Upgrade menu

- The job description text → F1 to F6 become quoted `[grounded]` requirements, and the JD-tagged questions are rebuilt against its real list
- Your CV or a few lines on what you actually did → the fit snapshot becomes real evidence, story-selection scaffolds become story maps, and the prohibited-claims section is built from it
- The interviewer's name and title, and who they are to you → persona weights tuned to the person, the interviewer read added, and a reverse question tied to their path
- The recruiter's prep email or guidance → coverage of any pre-declared deliverable, with its own build section
- Permission for web search → Stripe's published values, documented loop and current strategy replace the `[generic]` CO, VAL and CASE rows; a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) would add a strategy brief and role-family loop reports
- A `tuesday-dossier.md` from an earlier evidence review, if you have one → verified evidence, the objection worth the deepest rehearsal, and absolute limits on what may be claimed
- Your prep time → a prioritized schedule ordering what to rehearse first
