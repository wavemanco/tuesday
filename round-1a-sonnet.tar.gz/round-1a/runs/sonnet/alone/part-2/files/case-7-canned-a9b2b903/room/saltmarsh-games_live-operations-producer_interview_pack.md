# Interview prep pack — Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations — assumed to be the hiring manager running the Outage Hour (the careers page's single 60-minute hiring-manager interview). **Candidate:** Femi. **Interview:** Friday.

## How to use this pack

Personas describe how a question arrives; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows Saltmarsh's published values |
| EXP | Whether your background survives scrutiny; what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you can think at the company's altitude, using its current strategy |
| CASE | Structure and reasoning on a live problem from the role |

An answer slot is an instruction for the interview. It names what the interviewer will likely probe, and it always has a second branch: if the practice was not yours, or never existed, say so plainly and return to what you did say.

## Prep triage

Interview is Friday; today is Tuesday. Four short sessions, in this order.

| When | Do | Where |
|---|---|---|
| Tuesday | Say A1, A2 and A3 aloud, structure first; then read the full Larkspur news page and the values page, because the pack only had search snippets of the first | A1 to A3, A5, Sources |
| Wednesday | Rehearse the highest-ROI question until it is boring: C1, then C3 and E1 | C1, C3, E1 |
| Thursday | Choose one real story each for B1, B2 and B4, or decide you have none and rehearse the honest branch; run the drill | B1 to B4 |
| Friday morning | Run your 90-second arc (F1) once, and pick three reverse questions | F1, Reverse questions |

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar on your main title, with nothing inspected behind it, and the words stay at that scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's two-title wording makes a probe on what the calendar held and how many titles it covered likely. If it held anything beyond the weekly drops, say what and how you ran it, in your own words; if it held only the weekly drops, or covered only your main title, say so plainly and stay there |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team, and never worked on a game with in-app purchases." — your message | low | [grounded] | discovery | Your message says you have not led a team, and the material does not show either way whether the weekly drops involved coordinating other disciplines. Words from your message: "I haven't led a team." Answer slot: expect a probe on which of design, art, engineering and community your work touched and what your part was. If you worked with any of them, say which and how, in your own words; if you did not, or it was not yours, say so plainly |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | The sentence stays at its own scope: "I presented the monthly retention numbers to the studio head." Your material says presenting numbers, not owning a review or choosing what it reports. Answer slot: the JD's own-the-review line makes a probe on who chose what the numbers covered, and on whether a review followed each drop, likely. If any of that was yours, say what; if not, say so plainly and stay with the monthly presentation |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | Lead with the sentence in its own terms: "I wrote the release checklist our QA team still uses." It is a statement with nothing inspected behind it, so expect a probe on what is on it. Add nothing about running releases |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message, "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | The material gives four years as an associate producer and does not say whether the game was a live-service title. A years requirement is a risk to name, not a gate. Answer slot: expect a probe on the live-service wording and on associate versus producer. If the game was updated continuously, say how, in your own words; if it was not live-service for some of those years, say so plainly and stay with the four years you stated |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead in the sentence's own terms: weekly, your main title, two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap on the requirement's face. The sentence says presenting, not how the numbers were derived, so expect a probe on how they were counted; D1 rehearses it. Lead with "I presented the monthly retention numbers to the studio head" |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | Name it as the written artifact, in the sentence's own terms: "I wrote the release checklist our QA team still uses." The material says nothing about how it was received beyond QA still using it, so the words go no further |
| F9 | The season-pass model Project Larkspur announces for both titles — Saltmarsh news, September 2026 (search result; page not read in full) | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [inferred] | capability | A gap wording cannot close, and you stated it. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. The JD does not mention purchases; the pack infers the requirement from the news item |

## Reading the interviewer

Public professional footprint only, from one search result about his GDC 2026 talk; the full talk was not read.

| Public fact | Source | What it suggests for prep | Provenance |
|---|---|---|---|
| Head of Live Operations at Saltmarsh Games; GDC 2026 talk "Patch Notes Are a Promise" | Search result, talks.gdconf.example | The talk is his own framing of live work, so it is fair material for a reverse question (R2) | [grounded] |
| His stated argument: a live team is judged by how often its patch notes describe what actually shipped | Same result | Say what shipped, not what was planned, in every answer, which also fits the value "Ship the Patch Not the Promise" | [inferred] |
| Previously a QA lead at a console studio | Same result | Shared professional ground with F4: "I wrote the release checklist our QA team still uses." Expect specifics on what is on it (D2), and R1 asks about his own path | [inferred] |

## Persona table

The loop is documented, so no archetype fallback applies. The careers page says every loop is a recruiter call, then the Outage Hour: "a single 60-minute interview with the hiring manager — a live-incident tabletop on a simulated outage during a live event, then a values conversation. There is no take-home." The page gives no time split between the two parts.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | The tabletop: a simulated outage during a live event | Highest: named on the careers page, and the hiring-manager prior is Case plus Skeptic | Clarify, objective, who to pull in, what players hear, what you record. Think aloud, challenge one premise |
| Values/Behavioral | The values conversation after the tabletop | High: named on the careers page; three published values to cover | Choose a real story per value or use the honest branch; "we" for context, "I" for contribution |
| Skeptic | Your gaps, aimed at the Larkspur season pass and cross-team coordination | Medium-high: hiring-manager prior, plus stated gaps and the news item | Rehearse C1 until boring: plain acknowledgment, hold what your sentences carry, ramp plan said as a plan |
| Data-Driven Prober | Your retention numbers and checklist, line by line | Medium: his talk's theme is precision about what shipped, and your material has quotable lines to probe | Say plainly what you can and cannot say about how a number was counted |
| Pressure | Time-boxed pushes inside the tabletop | Lower: no source says the format is adversarial; a timed tabletop could squeeze answers | Pause, restate, hold the sentence you said |
| Conversational | The opening biography question | Lower: no source describes the opener, but biography questions are common | A 90-second arc built from your own sentences (F1) |

No peer persona: the page lists no peer round, and Tobias is the hiring manager.

## Requirement coverage

| Requirement | Covered by |
|---|---|
| Live-events calendar for two titles | A5, C2, D3, F1 |
| Coordinate design, art, engineering and community | A1, C3 |
| Post-event review and KPIs | A4, D1 |
| Release checklist with QA | B3, D2 |
| 3+ years live-service | E2, F1 |
| Content calendar | D3, E1 |
| Player-retention metrics | D1 |
| Clear written communication | A2, F2 |
| Season pass (inferred, not in JD) | A5, C1 |

## Question banks

**Highest-ROI prep: C1.** Larkspur makes the season pass central and you have said you have no in-app-purchase experience, so it will arrive in some form. A rehearsed, non-defensive answer changes the interview.

### A. Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It's mid-event and players are telling community that reward claims are failing. What do you do in the first thirty minutes?" | CASE | [generic] | Say your structure aloud. Clarify first: how many players, which event and title, since when, what engineering already knows. Then the objective, who you pull in from design, art, engineering, community and QA, what players are told and when, and what you record for the review. Challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | The careers page names a tabletop on a simulated outage during a live event; CASE because it scores structure, and F2's requirement is the cross-team pull-in |
| A2 | "Engineering says the fix is probably a couple of hours out. Community wants to post now. What do players hear, and when?" | CASE | [grounded] | Use the value's own line, "we announce what is built, not what is hoped": say what is known, what is not, and when the next update comes. Give no ETA you cannot back. Say the message aloud as if you were writing it. The question needs no claim about your past, so the guidance makes none | Tests "Ship the Patch Not the Promise" live and F8's written-communication requirement; CASE because it is a decision under uncertainty |
| A3 | "The fix lands, but the top-reward window was cut short for some players, and another drop is booked into the same slot. Extend, compensate, or move on?" | CASE | [grounded] | The value is "when the calendar and the players disagree, the players win", so lead with players, then show the trade-off: what extending costs the next drop and which teams have to agree. Ask what Saltmarsh's compensation policy is rather than inventing one. The question needs no claim about your past, so the guidance makes none | Tests "Players Before Plans" as a decision, not a slogan; CASE because it forces a trade-off |
| A4 | "Two days after the event ends, you own the review. What's in it, and which KPIs does it report?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Structure: the event's objective as set beforehand, what players did, what shipped versus what was announced, the incident timeline, decisions for the next event; pick KPIs from the objective. Answer slot: the JD's own-the-review line makes a follow-up on a review you have run likely. If you ran one, say what it covered and what changed because of it, in your own words; if reviews were not part of your work, say so plainly and stay with the monthly presentation | F3 is the thinnest JD row; JD because it scores the stated responsibility, CASE in delivery |
| A5 | "We're moving Tidepool Tactics and Lantern Row to one shared events calendar from February 2027. What should one calendar across two titles protect, and what could it break?" | CO | [grounded] | Think aloud: protect what players see and each title's rhythm; what could break is colliding drops, shared team capacity and QA bandwidth. Stay inside what the announcement says: a season-pass model, one shared calendar, one live-ops group. Say what you would want to know, and read the full page before Friday. The question needs no claim about your past, so the guidance makes none | Grounded on the Larkspur search result; CO because it asks for the company's own current frame |

### B. Values/Behavioral (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the plan and the players pulled in different directions. Which won?" | VAL | [grounded] | Selection scaffold, since none of your quoted sentences carries this story: choose a time with a named stake, a decision you made or influenced and what part was yours, and what changed afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it using A3's structure | "Players Before Plans" is the published value; VAL because it scores past behaviour against it |
| B2 | "Tell me about a time you announced something, or held back from announcing it, because of what was actually built." | VAL | [grounded] | Selection scaffold: choose a time when what was said and what shipped lined up or did not, and say what you did about it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | "Ship the Patch Not the Promise" is the published value, and Tobias's public talk is on the same theme; VAL |
| B3 | "Tell me about a time a release left a process or checklist better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4: you wrote it, and QA still uses it; tell those beats in your own words. Answer slot: the value is about leaving the checklist better after releases, so expect a probe on whether it changed after any. If it did, say what changed and who asked for it; if it was written once and left, or the changes were not yours, say so plainly and stay with having written it and QA still using it | F4 is your best-carried story and the value names the checklist; VAL |
| B4 | "Tell me about a time you gave leadership a number or a date they didn't want to hear." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Selection scaffold, with one candidate from F3: choose a time with a named stake, a moment you did not soften it, and a relationship intact after. Answer slot: if any monthly presentation carried a number the studio head did not want, say what happened and what part was yours; if none did, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem for the values round; VAL because it tests whether a hard truth landed, and F3 is the only row near it |

### C. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "We're moving both titles to a season pass, and you've never worked on a game with in-app purchases. How would you plan events inside that model?" | CO | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." | The deepest rehearsal here, and the limit comes first: this gap cannot be closed with wording. Say "I haven't worked on a game with in-app purchases." Hold only what your sentence carries: "I ran the weekly content-drop calendar for our main title for the last two years." Then a plan, said as a plan: ask how the pass is built, who owns its economy and what an event may touch, before proposing anything. Follow-up 1, what changes under a pass: name what you would need to learn, and bluff no pricing or economy knowledge. Follow-up 2, would you be comfortable not knowing the economy for the first season: concede specifically and say what you would ask for. Follow-up 3, why take the risk: hold the calendar sentence and the plan, adding nothing | F9 is the one gap no bridge closes; CO because the question comes from the Larkspur announcement |
| C2 | "You've run one title's weekly content drops. This role runs events across two titles. What's different about what we're asking?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold the sentence: "For the last two years I ran the weekly content-drop calendar for our main title." Say its limits plainly: one title, a weekly cadence. Answer slot: if anything on your calendar was shaped like a time-limited event, say what and how you ran it; if not, say so plainly. Then principles, not claims: for two titles you would start by asking for each one's constraints and how collisions get decided | F1's scope gap, in the hiring manager's words; JD because it tests the stated role |
| C3 | "This job coordinates design, art, engineering and community on every update, and you haven't led a team. Why would they work to your calendar?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." | Say "I haven't led a team." Answer slot: say which of the four disciplines your calendar work involved and what your part was; if none, or it was not yours, say so plainly and stay with the calendar sentence. Then what you would do, said as a plan: one named owner per deliverable, the calendar visible to all four teams, changes brought with reasons | F2's stated negative meets the JD's coordination line; JD because it tests the responsibility, and the premise is yours |

### D. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the monthly retention numbers you presented: how were they counted, and which assumption would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Keep to the sentence: you presented them. Answer slot, in your own words: how they were counted, what they are sensitive to, the assumption you would defend least, and which part was yours. If you do not know how they were counted, say so plainly | F7 is a presented figure with nothing inspected behind it; EXP because it tests attribution |
| D2 | "You wrote the release checklist QA still uses. What's on it, and how does QA use it today?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Tell the sentence's beats: you wrote it, QA still uses it. Answer slot: name the items you actually wrote, and how QA uses it in their words; if QA's use differs from what you wrote, or someone else owns it now, say so plainly. Expect detail: the interviewer read (F4) notes a QA background | F4 is your most concrete line, so it is the one a prober presses; EXP |
| D3 | "Take me through how an item got onto your weekly calendar, from idea to ship." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Start with the sentence. Answer slot: the JD's plan-and-run wording makes a probe on how items were chosen and who agreed likely. If you decided what went in and when, say how; if content was set elsewhere and you scheduled it, or there was no formal flow, say so plainly and describe what you did | F6 and F1 are the calendar claim, and this is where it is tested; EXP |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That calendar — how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Pause, restate, then hold: "I ran the weekly content-drop calendar for our main title for the last two years." Return to that sentence through two follow-ups. Concede only specifically. Answer slot: if others set the content or approved items, say so plainly and name what you did do | Attribution pressure on F6; EXP because it scores honesty about the share |
| E2 | "Sixty seconds: why you, over someone who has run live events on two titles under a season pass?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | Concede first: they may have more on events, two titles and passes. Then say your sentences and let the interviewer draw the conclusion: the four years, the calendar, the checklist, the retention presentation. Close with the plan from C1. Claim no equivalence | F1, F5 and F9 together; JD because it tests fit against the listed job |

### F. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So — walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc in your own words, in first person, built from those four sentences in that order. Close on why this role: your own reason, in your own words; if it is simpler than a story, say that plainly | The biography opener is scored even when it feels casual; EXP because it is the CV told aloud |
| F2 | "When have you had to write something other teams relied on?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F8: you wrote it, and QA still uses it. Answer slot: expect a probe on how you knew it was understood or how it changed. If you gathered feedback or revised it, say so; if not, say so plainly | The JD's written-communication line; use different beats from B3 and D2 for the same document |

## Values cheat sheet

A values conversation is documented on the careers page, and the values come from the published page.

| Value | Working meaning | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and players disagree, players win | Selection scaffold (B1): none of your sentences carries it; if no time comes to mind, say so plainly |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | Selection scaffold (B2): if no time comes to mind, say so plainly, then give the nearest thing you do have |
| Leave the Build Greener | Every release leaves the codebase and the checklist better | F4: "Wrote the release checklist our QA team still uses." — your message; the slot in B3 covers whether it improved |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You moved from QA lead at a console studio into running live operations. What from QA do you still bring to how a release checklist gets run here?" | Ties to his own path and to F4, converting a probe into a peer conversation |
| R2 | "Your GDC talk argues a live team is judged by how often its patch notes describe what actually shipped. How does the team track that now?" | Shows you read his argument; read the talk first, since the pack saw only a summary |
| R3 | "With per-title event teams moving into one live-ops group, how will this role's remit divide between Tidepool Tactics and Lantern Row?" | Shows you read Larkspur and asks what the job will be |
| R4 | "What would a producer who's new to in-app purchases and the season-pass model need to learn first, and who would they learn it from?" | Turns C1 into a plan question and asks for what you need |
| R5 | "How is the post-event review used: who reads it, and what decision has it changed?" | The JD has you owning it; the answer shows what its KPIs are for |
| R6 | "What would you want this role to have changed by the first month of the shared calendar in February 2027?" | Ties your first months to a dated milestone from the announcement |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live events across two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says a weekly content-drop calendar on your main title. C2's slot stays inside that calendar |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope; the material says presenting numbers, not owning a review. A4's slot stays inside the monthly presentation |
| Led or managed a team across design, art, engineering and community | Negative you stated, F2 | The plain acknowledgment: "I haven't led a team." C3's slot asks only which disciplines your work touched |
| Experience with in-app purchases or the season-pass model | Negative you stated, F9 | The plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot |
| Managed the release process with QA | Inflated form of F4 | F4's quote at its own scope: you wrote the checklist, and QA still uses it |
| Four years producing live-service games | Inflated form of F5 | F5's quote at its own scope: four years as an associate producer at a puzzle-game studio |
| Built or analysed the retention numbers | Inflated form of F7 | F7's quote at its own scope: you presented them. D1's slots ask how they were counted |

## Sources

**Provided documents:** your message (the JD text and your background). No dossier was provided.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet; B1 to B4 and A2, A3 use the three value names and meanings from the fetched page |
| 2. Saltmarsh interview process, live operations | yes | Persona table and weights; the Outage Hour structure (tabletop, then values conversation; no take-home) comes from the fetched careers page |
| 3. Saltmarsh strategy and recent news | yes | A5, C1, R3, R6 and F9 rest on a search snippet for Project Larkspur (September 2026); the page itself was not fetched because both fetches went to targets 1 and 2 |
| 4. Tobias Wrenfield, Saltmarsh | yes | Reading the interviewer and R1, R2 rest on one search snippet; the talk page was not fetched |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

Queries and what came back:

- "Saltmarsh Games values" — https://saltmarshgames.com/values
- "Saltmarsh Games interview process live operations producer" — https://saltmarshgames.com/careers/interviewing
- "Saltmarsh Games mobile studio news strategy" — https://saltmarshgames.com/news/project-larkspur
- "Tobias Wrenfield Saltmarsh Games Head of Live Operations" — https://talks.gdconf.example/2026/patch-notes-are-a-promise

Fetches: https://saltmarshgames.com/values and https://saltmarshgames.com/careers/interviewing.

## Upgrade menu

- The full Project Larkspur news page and the GDC talk text → A5, C1, R2, R3 and R6 move from search-snippet grounding to page grounding, and the interviewer read gets sharper
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a grounding brief on Saltmarsh's strategy, role-family loop reports and recent org context
- Your CV text, or the release checklist itself, a calendar export or a retention deck → F4 and F8 (the checklist), F1 and F6 (the calendar) and F3 and F7 (the deck) could rise from `medium` toward `high`
- Your answers to the answer slots in F1, F2, F3 and F5 → those rows become story-mapped instead of slots
- Anything the recruiter said about the Outage Hour, such as its format or what to prepare → coverage tuned to it; usually one email to the recruiter
- A `tuesday-dossier.md` from an earlier evaluation of this role → a named highest-ROI objection and strategy per weak area, in place of the ones inferred here
