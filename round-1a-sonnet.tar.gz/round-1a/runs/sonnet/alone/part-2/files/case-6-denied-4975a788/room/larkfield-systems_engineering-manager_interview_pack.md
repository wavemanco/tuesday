# Interview prep pack — Engineering Manager, Larkfield Systems (three-round loop)

Candidate: Yusuf. Role as you described it: "Engineering Manager — Larkfield Systems (industrial IoT, ~600 people). Lead two squads building device-management services; own delivery, hiring and growth for 11 engineers; partner with hardware and product on roadmap."

| Round | When | Who | Relationship | Format |
|---|---|---|---|---|
| 1 | Tuesday | Director of Engineering, your would-be boss (name not given) | Hiring manager | 45 min |
| 2 | The Thursday after | Two staff engineers and a product manager (names not given) | Panel | 60 min |
| 3 | The following Monday | VP Engineering (name not given) | Skip-level and executive | 30 min, described by the recruiter as "values and leadership philosophy" |

Built in loop mode: one shared fit snapshot, then a mini-pack per round. Persona weights rest on the relationships you stated; no source on Larkfield's own interview process was reachable (see Sources).

## How to use this pack

Personas describe how a question arrives; types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values and leadership, not generic virtue |
| EXP | Whether your own claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge (none in this pack; see Sources) |
| CASE | Structure and reasoning on a live problem set in the role |

Fit-snapshot rows are F1 to F7. Question IDs run A to M across the three rounds and skip F so the two never collide. An answer slot is an instruction for the interview, not a question for you now.

## Prep triage

| Order | Do this | Where |
|---|---|---|
| 1 | Rehearse the hardware-roadmap objection until it is boring — this is the highest-ROI prep in the pack, because it arrives in rounds 1 and 2 in different packaging | A2, then E4 and G1 |
| 2 | Rehearse the step from one team of 6 to two squads, and the plain "never managed managers" line | A1, L1 |
| 3 | Be able to defend the 60% and the "about 40 interviews" line, including saying plainly what you do not know about how they were counted | C1, C2, H1, L2 |
| 4 | Before Monday, choose your stories for the leadership round from your own material, or settle on the honest "nearest thing" branch | K1 to K5 |
| 5 | Type your answers to the answer slots in F1, F4, F5 and F7 back to me; each one upgrades a row | Fit snapshot |

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — your role description | "9 years engineering, 3 as a team lead of 6" — your message | medium | [grounded] | transferability | Words stay at the quote: "Three of my nine years in engineering have been as a team lead of 6." Your material says one team of 6, not two squads and not device-management. Answer slot: expect a probe on the step from one team to two squads. If any of your current work spans more than one team, say what it is and which part was yours, in your own words; if none does, or it was not yours, say so plainly and stay with the team of 6 |
| F2 | "own delivery" — your role description | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | Words are the quote itself, keeping "after" as "after". It carries a reliability quarter and a 60% drop in on-call burden, not delivery of a roadmap. Expect probes on the figure. Answer slot: say in your own words how the 60% was counted, what it is most sensitive to, the assumption behind it you would defend least, and which part was yours; if you do not know how it was counted, say so plainly |
| F3 | "own delivery, hiring and growth for 11 engineers" — your role description (the hiring part) | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | none | No gap on hiring as a topic, but a line with nothing inspected behind it, so expect a probe. Lead with it in its own terms: you run the loop for backend roles. The 40 counts interviews, not hires. Your material says backend roles, and the role description does not say what these squads hire for. Answer slot: say which parts of the loop were yours and how the 40 was counted; if you do not know how it was counted, or parts were set by others, say so plainly |
| F4 | "own delivery, hiring and growth for 11 engineers" — your role description (the growth part) | none given | none | [grounded] | discovery | Your material does not show anything on growth. Answer slot: if you have had a hand in an engineer's growth, say what it was and which part was yours, in your own words; if not, or it was not yours, say so plainly and stay with the hiring loop you run |
| F5 | "partner with hardware and product on roadmap" — your role description | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | discovery | Words you gave: "I've never owned a hardware-adjacent roadmap." That speaks to owning, not partnering. Answer slot: if you have worked alongside hardware or product people on a roadmap, say what it was and which part was yours; if not, or it was not yours, say so plainly, and give how you would learn it as a plan, never as a past |
| F6 | Leading through other managers — plain prose; not in the role description, you raised it — your message | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never managed managers." Then how you would learn it, said as a plan. Never a claim to have managed managers, and "team lead of 6" is not restated as managing managers |
| F7 | "Lead two squads building device-management services" — your role description (the device-management part) | none given | none | [grounded] | discovery | Your material does not show device or hardware-adjacent work beyond what F5 records. Answer slot: if any of your work touched devices or the people who build them, say what and which part was yours, in your own words; if none did, say so plainly, and say how you would learn it as a plan |

## Round 1 — Tuesday, Director of Engineering (hiring manager, 45 min)

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of F1, F5, F6, F7: scale, hardware, "why leave, why now" | High: the hiring-manager relationship derisks gaps, and the four rows above are gaps you stated or the material does not close | Rehearse A2 until boring; bridge only from the quotes; say limits plainly with a ramp plan |
| Case/Strategist | Live problems from the real roadmap | High: hiring-manager prior; a boss-to-be tests how you think on his or her own problems | Clarify, objective, options, metrics, risks; think aloud; challenge one premise politely |
| Conversational | Opening "walk me through the journey" and casual follow-ups | Medium: first fifteen minutes of a 45-minute round usually set tone; still scored | A 90-second arc from F1's quote only |
| Prober | Line-by-line reading of the 60% and the 40 interviews | Medium: both figures are in your own words and invite counting questions | Know what you can say about counting; say plainly where you do not know |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This role is two squads and eleven engineers; you've led a team of six. Where's the gap?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6" | Hold: "Three of my nine years in engineering have been as a team lead of 6." Name the step yourself before they do: your material says one team, the role says two squads. Then a ramp plan, said as a plan: spend time with each squad's engineers and the current plan before changing anything. Answer slot: if any of your current work spans more than one team, say what and which part was yours; if none does, or it was not yours, say so plainly and stay with the team of 6 | F1 is the headline requirement and the first place a hiring manager derisks; JD because it scores the stated lead-two-squads line |
| A2 | "You've never owned a hardware-adjacent roadmap, and this role partners with hardware and product on roadmap. How do you handle that?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | The deepest rehearsal in the pack. Step 1, concede the fact you stated: "I've never owned a hardware-adjacent roadmap." Step 2, the nearest thing, at its own scope and named as not hardware: "The nearest thing I can point to is a reliability quarter I pushed through against roadmap pressure." Step 3, a plan, never a past: ask who sets the hardware dates and which of them the squads depend on, and spend time with your hardware counterpart. Follow-ups: "That's not hardware" — concede it is a different roadmap and return to the plan. "Why take the risk?" — hold on the plan, add nothing to the past. "What would you get wrong first?" — name, in your own words, the assumption you would most likely carry from a software-only roadmap; if you do not know, say so plainly. Answer slot: if you have worked alongside hardware or firmware engineers on any plan, say what and which part was yours; if not, say so plainly | F5 is where your stated limit meets the role's roadmap-partner line, and it returns from the PM in round 2 and the VP in round 3, so a boring answer here pays three times; JD because it scores the stated requirement, with the Skeptic's delivery |
| A3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Choose one limit you can say plainly in the quote's own words, then give the plan. Do not pick a limit you have not stated unless it is true; if you are unsure which of your limits is the real one, say so and name the one you would ask the team about first | F5 and F6 are the stated limits; JD because it asks about the listed job, asked in the Skeptic's register |
| A4 | "Why leave a payments company for industrial IoT, and why now?" | EXP | [grounded] "currently at a payments company" | Answer slot: give your actual reasons for leaving and for choosing this role, in your own words; if they are not settled, say so plainly and say what you want to find out here. Test each reason against A2: if it collapses on that question, it is not ready | F1 and F7 are why the move needs a story; EXP because it tests whether the career story coheres rather than a listed requirement |
| B1 | "A hardware milestone slips three weeks and product wants the squads' date held. What do you do first?" | CASE | [generic] | Clarify first: what depends on the milestone, which dates are firm, who decides. Then objective, options (hold the date with less scope, move it, remove the dependency), the metric you would watch, the risk of each. Challenge one premise politely. Say what you would need from the hardware lead; no past claim is needed | A live problem from the role's partner-with-hardware line (F5), asked as a decision; `[generic]` because it is a pattern for the problem, not a fact about this employer |
| B2 | "Both squads are behind and there is room to fix one reliability problem or ship the next feature. Walk me through the decision." | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Structure it as a case first: what is failing, who feels it, what the feature is worth, how you would decide and what you would watch. Then, only if it helps, one sentence at the quote's scope: "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." Say "after", never "because of". Do not extend it to any other outcome | F2 is the closest evidence to owning delivery trade-offs; CASE because the decision is live, JD content for the own-delivery line |
| B3 | "You'd be hiring into two squads. How would you decide what to hire for and how to run the loop?" | CASE | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Structure: what each squad is short of, what the role must do in the first months, which stages test it. One sentence of your own: "I run our hiring loop for backend roles." Your material says backend, so say plainly what you would ask a hardware colleague to help with for a hardware-adjacent role. Answer slot: if you have screened outside backend roles, say what; if not, say so plainly | F3 is the strongest row and the one where you can be concrete; CASE because it is a live hiring decision |
| C1 | "Walk me through how that 60% was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Use the quote at its scope, with "after". Answer slot: say in your own words how the 60% was counted, what it is most sensitive to, the assumption behind it you would defend least, and which part was yours; if you do not know how it was counted, say so plainly. Name the weakest assumption before they do | F2 carries a headline figure, and figures are what probers go to first; EXP because it tests attribution |
| C2 | "You say you run the hiring loop. Which parts of it are yours?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Say it as stated: you run the loop for backend roles, with about 40 interviews. The 40 is interviews, not hires. Answer slot: say which parts were yours and how the 40 was counted; if parts were set by others, or you do not know how it was counted, say so plainly and describe how you run your part | F3 invites a "what does run mean" probe; EXP because it tests what was actually yours |
| D1 | "So — walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | A 90-second arc with only the beats the sentence states: nine years in engineering, three as a team lead of 6, currently at a payments company. Close with why this role, in your own words; give your actual reason and do not borrow one from A4's draft. Do not add promotions, projects or titles | F1 is the arc's whole evidence; EXP because it is the CV walk-through in a casual register |
| D2 | "Tell me about an engineer you helped grow." | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Pick one engineer whose development you had a hand in; it needs a person you can describe, something they did differently afterwards, and your part. If no such case comes to mind, say so plainly, then give the nearest thing your material carries — "I run our hiring loop for backend roles" — or how you would approach growth. Never describe a development effort you did not make | F4 is silent on growth, so this is a scaffold; JD because the role description names growth, asked casually |

### Reverse questions

| # | Ask | Why it lands |
|---|---|---|
| R1.1 | "What would success look like for the two squads six months in?" | It sets the bar you will be held to and shows you think in outcomes before you arrive |
| R1.2 | "Where do hardware dates and service dates meet today, and where do they collide?" | It turns A2 from your gap into your curiosity, and asks the person who knows |
| R1.3 | "How are the eleven engineers split across the two squads, and what would you change?" | It treats the role as a real inheritance rather than a title |
| R1.4 | "What do you most want from me in the first 30 days?" | It signals you are building the working relationship with your future boss, not only passing a screen |
| R1.5 | "What has separated managers who did well here from those who struggled?" | It asks for the honest unwritten criteria, which is the best preparation for rounds 2 and 3 |

## Round 2 — the Thursday after, panel: two staff engineers and a product manager (60 min)

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Seam between staff engineers and an EM, credit, disagreement, "what would you need from me" | High: staff engineers and a PM are sideways relationships; each is pricing what your arrival does to their load | Reciprocity first: what you bring them; propose principles for the seam, not a pretended map |
| Case/Strategist | The PM puts a roadmap trade-off; a staff engineer puts an incident | Medium: the PM is the roadmap partner, and F5 is the likeliest thread | Clarify then structure; use the quotes only where a sentence carries them |
| Prober | The staff engineers read the 60% and the 40 closely | Medium: technical seniors probe attribution and counting | Name the weakest assumption first; say plainly what you do not know |
| Values/Behavioral | The PM's cross-functional stories | Medium: a PM is outside the function, so stories matter more than structure | A story only where your quoted material carries one; otherwise the honest branch |

Panel members are not named, so personas are not assigned per member; send names and I will assign them.

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Where's the seam between a staff engineer and an engineering manager, and what happens when we disagree?" | JD | [generic] | Propose principles rather than a map: say what you would expect each of you to own, say you would want to hear where Larkfield draws the line before proposing one, and say how a disagreement would be resolved when it cannot be settled between you. No past claim is needed | F1's "own delivery" meets technical authority here; JD because it scores the stated role, Peer in delivery |
| E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | State the principle you actually hold, in your own words: who did what is named. Do not describe a past case unless you can name it; if asked for one, use the selection approach in E3 | A staff engineer or PM checks you are not a credit-taker; VAL because it scores a behavior, asked of a peer |
| E3 | "Tell me about a time you disagreed with a senior engineer about a technical call. How did it end?" | VAL | [generic] | Pick a disagreement with an engineer you respected; it needs a named stake, the position you held, and a relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | The Peer persona's disagreement probe, in a role where staff engineers hold technical opinions |
| E4 | "What would you need from me as your product partner, and what would I get from you?" | JD | [generic] | Lead with what you offer, as a plan: a plain view of delivery state and the trade-offs the squads face. Then what you need, framed as learning how product and hardware plans meet. Do not claim you have run a product-partner relationship | F5 returns here from the person who sets the roadmap; JD because it scores partner-on-roadmap, with Peer's reciprocity |
| G1 | "Product wants a feature next quarter, the squads want a reliability quarter, and the hardware roadmap is moving. How do you decide?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." "I've never managed managers and never owned a hardware-adjacent roadmap." | Clarify first: what the feature is worth, what reliability debt is costing, which hardware dates are firm. Structure the options and the risk of each. Then one sentence at the quote's scope about the reliability quarter, with "after". If pressed on hardware, the plain line from A2: "I've never owned a hardware-adjacent roadmap," then the plan | F2 and F5 meet in a single question; CASE because it is a live decision, with the objection's hold inside it |
| G2 | "A device-management service you own fails across a fleet in the field and customers are calling product. Walk me through the first hour." | CASE | [generic] | Clarify first: what is failing, how wide, what can be rolled back, who is on call. Then who leads the incident and what the EM does around it, how product and customers are kept informed, and what you would want reviewed afterwards. No past claim is needed; a past claim would need a quote | F7 is silent on devices, so the case is a pattern for the problem; CASE because it is a live problem set in the role |
| G3 | "You inherit two squads with different habits. What do you change in the first sixty days?" | CASE | [generic] | Say what you would learn first and from whom before changing anything, then what you would change only once the facts are in. State the first thing you would not touch. No past claim is needed | F1 and F2 meet the first-quarter question every panel asks; CASE because it is a plan on a hypothetical |
| H1 | "Which assumption behind that 60% would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Answer slot: name, in your own words, the assumption you would defend least; if you do not know how the 60% was counted, say so plainly. Keep "after", not "because". Say which part was yours | F2's figure is the Prober's target and staff engineers will ask it technically; EXP because it tests assumption-awareness |
| H2 | "You run the backend hiring loop. What does it check for, and what would you change for hardware-adjacent roles?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Answer slot: if you set what the loop checks, say what and how you decided; if the content was set by others, or there was no fixed set, say so plainly and describe how you run your part. For the hardware half, say what you would ask a hardware colleague to help design, as a plan | F3 is a row staff engineers probe, because they will be in your loops; EXP because it tests what was actually yours |
| J1 | "Tell me about a time you said no to a stakeholder and kept the relationship." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | If the reliability quarter is the story you choose, the beats the sentence carries are the quarter, the roadmap pressure, and the drop in on-call burden after; tell the rest in your own words only if it happened. If no such time comes to mind, or this was not one, say so plainly, then give the nearest thing your material carries or how you would handle it | F2's roadmap pressure is the only quoted story near this theme; VAL because it scores behavior |
| J2 | "Tell me about a time you worked with product or another function on something you disagreed about." | VAL | [generic] | Pick a case with a named disagreement and a result you can state. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would approach it. Never write the result in advance | The role description's partner-with-hardware-and-product line raises it, and F5 is silent on any such case |

### Reverse questions

| # | Ask | Why it lands |
|---|---|---|
| R2.1 | "Where does the engineering manager's call end and the staff engineers' begin on these squads today?" | It asks the staff engineers for the seam they live with rather than guessing at it |
| R2.2 | "What could a new manager do in the first month that would genuinely help your team?" | The reciprocity question for peers; it makes you the one reducing their load |
| R2.3 | "How does the roadmap conversation between product, hardware and the squads run, and who is in the room when dates move?" | It asks the PM about the exact process F5 is about |
| R2.4 | "What was the last feature-versus-reliability trade-off that went well, and what made it go well?" | It tests how the panel treats the trade-off you care about |
| R2.5 | "What would you most want an engineering manager here to do differently from what you've seen?" | It invites candor and tells you what to avoid |

## Round 3 — the following Monday, VP Engineering (values and leadership philosophy, 30 min)

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Leadership philosophy; what you stand for under pressure | High: the recruiter described the round as "values and leadership philosophy" | A story only where a quoted sentence carries one; otherwise a scaffold ending in the honest branch |
| Pressure | "You've never managed managers. Why should I trust you?" | Medium: executive and skip-level prior, and F6 is a limit you stated | Pause, restate, hold the position through two follow-ups, concede specifically |
| Conversational | The first and last few minutes | Medium: a 30-minute round leaves little room, so the casual opener is still scored | Your 90-second arc from D1; never reply "I think you've covered everything" to the closing slot |
| Case/Strategist | Not expected | Low: the recruiter's description points at values, and no company-strategy source was reachable | Keep B2 and G1 as insurance only |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "What's your leadership philosophy?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The pack cannot write your philosophy and will not. Answer slot: name two or three principles you actually hold, in your own words, and tie each to something you did using only your own sentences; if a principle has no story behind it, say so plainly and present it as how you intend to lead, not as a record | The recruiter's words raise this directly; VAL because it scores values, with F2 and F3 as the only quoted stories |
| K2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Only if the reliability quarter involved telling leadership something unwelcome is it the story; the sentence carries the quarter, the roadmap pressure, and the drop after, nothing about who was told what. Tell the rest in your own words only if it happened. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | F2 is the only quoted story near the theme; VAL because it scores whether the hard truth landed |
| K3 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a case with a named customer need, the metric given up, and what happened to the relationship. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it. Do not borrow F2 unless it truly fits | A standard values-round prompt; the material has no sentence that carries it, so this is a scaffold |
| K4 | "What have you got wrong as a lead, and what did you change?" | VAL | [generic] | Choose a mistake that was yours, say what it cost, and say what you changed. Never pick a mistake that makes the answer sound humble but costs nothing. If nothing comes to mind, say so plainly, then give how you would handle it | Leadership philosophy rounds weigh self-awareness; no quoted sentence carries a mistake |
| K5 | "What do you expect of the engineers in your squads, and what can they expect of you?" | VAL | [generic] | State the two or three expectations you actually hold, in your own words, then what you would commit to in return. No past claim is needed; if you use one, it needs a quote | A leadership-philosophy question that asks for commitments, not history |
| L1 | "You've never managed managers. Why should I trust you with two squads?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." "9 years engineering, 3 as a team lead of 6" | Hold-then-concede. Concede first, in your stated words: "I've never managed managers." Hold on what the sentence carries: "Three of my nine years in engineering have been as a team lead of 6." Do not turn "team lead" into "managed". Then a plan: agree with the VP how you would check in during the first months and what they would want to hear. Hold through two follow-ups by returning to the quote, never by adding to it | F6 is the stated limit and F1 the only quoted scope, so this is the VP's likeliest challenge; JD with Pressure's delivery |
| L2 | "That 60% — how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold the sentence: you pushed the quarter through; the on-call burden dropped after. Answer slot: say which part was yours and which was not, in your own words; if you do not know how the 60% was counted, say so plainly. Concede the "after" is not "because" if pressed | F2's attribution is the cleanest Pressure probe in the loop; EXP because it tests what was actually yours |
| L3 | "Sixty seconds: why you for this role?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6" "I run our hiring loop for backend roles — about 40 interviews last year." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Three beats, each a sentence you said: nine years in engineering, three as a team lead of 6; you run the hiring loop for backend roles; the reliability quarter with the on-call drop after. Close with the one limit you stated, plainly, and what you would do about it. Do not add a claim of impact beyond the quotes | The stem asks you to compress F1 to F3; JD because it scores fit |
| M1 | "What drew you to Larkfield?" | CO | [generic] | Answer slot: give your actual reasons, in your own words. This pack could not reach Larkfield's strategy or values (see Sources), so no company facts are supplied; use only what you have read yourself, and if you have read little, say what attracted you in the role as described | A VP will ask, and it must not sound archival; CO but `[generic]` because the research did not run |
| M2 | "If I asked your team what you are like to work for, what would they say?" | VAL | [generic] | Answer only with feedback you have actually received, in your own words; do not invent what they would say. If you have received none, say so plainly and say what you would want them to say | A rapport-style opening to values, and a place where inflated answers are easy |

### Reverse questions

| # | Ask | Why it lands |
|---|---|---|
| R3.1 | "What do engineering managers here most underestimate about the job in their first year?" | It asks the VP for the honest failure mode and signals you are planning for it |
| R3.2 | "How does engineering leadership here balance roadmap against reliability and technical debt?" | It lets you connect your reliability story to their stance without claiming more |
| R3.3 | "Where do you see hardware and software ways of working pulling in different directions?" | It addresses F5 from curiosity rather than defensiveness |
| R3.4 | "How are engineers developed into leadership at a company of this size?" | It addresses F4 and F6 by asking how the company grows leaders |
| R3.5 | "What would tell you in a year that hiring me was the right call?" | It asks for the bar you will actually be held to |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | Negative you stated, F6 | The plain acknowledgment: "I've never managed managers." No slot |
| Has owned a hardware-adjacent roadmap | Negative you stated, F5 | The plain acknowledgment: "I've never owned a hardware-adjacent roadmap." The slot in F5 asks only about working alongside, never owning |
| Led two squads, or a team of eleven | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says one team of 6 |
| Owned delivery of a roadmap | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: your material says a reliability quarter, not a roadmap |
| The reliability quarter caused the 60% drop | Inflated form of F2 | The quote's own word: "after" |
| Made about 40 hires | Inflated form of F3 | F3's quote at its own scope: about 40 interviews. The limit is the pack's observation: your material says interviews, not hires |

## Sources

Provided documents: your message, containing the role description, the three round descriptions and your background statements. No CV, no full job description and no dossier were provided.

Searches sent, all refused by the host, none returned anything:

- "Larkfield Systems values industrial IoT" — refused
- "Larkfield Systems interview process engineering manager" — refused
- "Larkfield Systems strategy news device management" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Would have moved the values cheat sheet and the VAL themes for round 3; no published values are in hand, so none was built and K1 to K5 use scaffolds |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Would have moved the loop structure; the three rounds and their relationships rest only on your description, and the persona weights follow relationship priors |
| 3. `Larkfield Systems strategy` and recent news | unavailable | Would have moved CO and CASE questions grounded in company strategy; none are in this pack and M1 is generic |
| 4. `{interviewer name} Larkfield Systems` | n/a | No names were given, so there was no query to form; there is no interviewer read |
| 5. representative `Engineering Manager` JD | skipped | The role description you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Permission to search the web → values for the round-3 cheat sheet, the company's documented loop for weights, and recent strategy for CO and CASE questions
- A deeper research pass, offered once → a grounding brief: up to 6 more searches and 2 more fetches, several more minutes
- The full job description → F-row requirements become quoted from the JD, and any requirement missing from your summary gets its own row
- Your CV → fit-snapshot evidence quoted from it, and several scaffold questions become story-mapped answers
- The interviewers' names → a reading of each, per-member personas for the panel, and reverse questions tied to their own paths
- The recruiter's notes on what each round will cover, or any deliverable → coverage tuned to the stated focus and a build section for any announced assignment
- Your typed answers to the answer slots in F1, F2, F3, F4, F5 and F7 → those rows move from slot to quote, and the guidance regenerates
- A `tuesday-dossier.md` from an earlier evidence check → verified evidence and absolute prohibited claims, replacing the inferred objection ranking
