# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship to the role not stated; this pack assumes a hiring-manager round, 60 minutes, on Friday.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Behavioral or values alignment: whether past behavior shows the behavior asked about |
| EXP | Work-experience deep-dive: whether your claims survive scrutiny and what was actually you |
| JD | Role and JD-driven: the stated responsibilities and qualifications, gaps included |
| CO | Company and strategy knowledge: homework depth |
| CASE | Hypothetical or live problem: structure and reasoning on a problem from the role |

Question IDs run by persona (A, B, C...) so a drill can point at one. Answer slots (instructions that begin "Answer slot") are for the interview itself: they ask nothing of you here, and either honest branch is a good answer.

## Prep triage

Three days remain before Friday. Adjust to the hours you actually have.

1. Tuesday: say B1 aloud, with its three follow-ups, until it is boring. It is the highest-ROI prep in this pack. Then B3 and B4.
2. Wednesday: A1, A3 and A4 aloud, as structured thinking out loud. Play both of Saltmarsh's titles yourself, because this pack could not research them.
3. Thursday: C1, C2 and E2 (what was actually yours), then the D1 arc, then pick three reverse questions.
4. Friday: nothing new.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for the main title, with nothing inspected behind it, and the words stay at that scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's two-titles line makes a probe on the scope of your calendar likely. Say what it covered and which title it was for, in your own words; if any part of it was not yours to set, say so plainly and stay with the calendar you ran |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a claim with nothing inspected behind it, so expect a probe on it. Lead with the quote's own terms: you ran it, it was weekly, it was for the main title, and it lasted two years. E2 rehearses the attribution probe |
| F3 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | low | [inferred] | discovery | The calendar sentence touches this requirement without showing which teams you worked with. Answer slot: the JD names four teams, so expect a probe on each. Say which of them you worked with on the drops and what you did with each, in your own words; if some were not part of it, say so plainly and stay with what the calendar covered |
| F4 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented the numbers, not that you owned a review or its KPIs, and the words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's ownership line makes a probe on where the numbers came from likely. Say which part of what you presented was yours to build or choose, in your own words; if none was, say so plainly and stay with presenting them |
| F5 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | Your material says you wrote the checklist and that QA still uses it, not how it is run release to release. The words stay at that scope: "I wrote the release checklist our QA team still uses." D3 holds the slot on how QA uses it |
| F6 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says four years as an associate producer and two years on the calendar. Words at that scope: "I spent four years as an associate producer at a puzzle-game studio, and for the last two I ran the weekly content-drop calendar for our main title." Answer slot: expect the years to be counted. Say which of the four years the calendar covered, in your own words; if it was only the last two, say so plainly |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap, but nothing inspected stands behind it. Lead with the quote's own terms: presented, monthly, to the studio head. C1 holds the how-it-was-counted probe |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | A written document another team still uses is the evidence, and it already reaches the requirement. Reword only that: "I wrote the release checklist our QA team still uses." A sanitised copy of the checklist is the artifact that would raise this row to high |
| F9 | Experience leading a team: role-family expectation, no JD line names it | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | You stated this one. Words: "I haven't led a team." Then how you would coordinate teams that do not report to you, said as a plan and never as a past. The JD's lines say coordinate, not lead, so a probe here comes from the interviewer's own concern |
| F10 | Familiarity with in-app purchases: role-family expectation, no JD line names it | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | You stated this one too. Words: "I haven't worked on a game with in-app purchases." Then what you would learn first, said as a plan and never as a past. Nothing is added to make the gap feel smaller |

No row is a gate: the 3+ years line is a length-of-experience requirement, graded like any other.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems from the role: plan a calendar, diagnose a drop, handle a slipped release | High. Relationship prior for a hiring manager is Case/Strategist plus Skeptic; the JD's plan, coordinate and release lines all convert naturally into cases | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully per case |
| Skeptic | Quiet probing of the gaps: in-app purchases, team leadership, the associate-producer title | High. Same prior; F9 and F10 are gaps you stated, and F6 invites a count of the years | Rehearse B1 until it is boring; bridge only from the rows above; give a concrete ramp plan |
| Data-Driven Prober | Line-by-line on the retention numbers: what was in them, how they were counted, what changed | Medium. The JD names retention metrics and F7 is a line in your material, so a probe is likely even though the prior ranks it below the top two | Know what you can and cannot say about how the numbers were counted, and say plainly when you do not know |
| Conversational/Rapport | Opening biography, what you play, a casual ask about writing or the checklist | Medium. Any 60-minute conversation opens this way, and casual questions are still scored | A 90-second arc built from your own sentences (D1); treat the casual questions as scored |
| Pressure | Time-boxed challenges: why you, how much was actually you | Low to medium. Not the prior for a hiring manager, but F1 and F9 invite attribution and comparison pressure | Pause, restate, anchor in what you said, hold through two follow-ups, concede specifically |
| Peer Evaluator | Seam-splitting between teams, credit-sharing | Low. Nothing in your note says a peer is in the room, though the JD's four-team coordination line makes it plausible | Offer seam principles rather than pretending to know the seam; show spine and tact together |
| Values/Behavioral | Scenario probes on behavior | Low. Your note describes one session with Tobias, and no source says this loop has a values round; Saltmarsh's published values could not be researched | Pick stories from your real work by the scaffold; where none fits, say so plainly |

Weights rest on the relationship prior and your own note (one 60-minute session). No interviewer-signal adjustment was possible: only Tobias's name and title are known, and his public footprint could not be researched.

## Question banks

### Bank A: Case/Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You take over the live-events calendar for two mobile titles that share one design team and one QA team, and a big event for each lands in the same week. What do you need to know first, and how do you decide what ships?" | CASE | [generic] | Clarify before structuring: what each event is for, what is already committed, what each team can take on that week, what a slip costs. Then the objective, a way to compare the two events, the approach, the metrics you would watch, the risks. Challenge one premise out loud, such as whether both events must ship in the same week. The question needs no claim about your past, so the guidance makes none | Built from the JD's two-titles and coordination lines (F1, F3). CASE because it scores structure under a live trade-off |
| A2 | "A weekend event's retention comes in well under forecast on Monday morning. Diagnose it." | CASE | [generic] | Clarify first: which retention measure, which players, compared with what, and whether anything else shipped or broke that weekend. Then split into causes you can test quickly and ones you cannot. Name the assumption in your own diagnosis that you would defend least, and say what a single weekend of data cannot tell you | Tests the JD's retention-metrics and KPI lines (F4, F7) as a live problem rather than a CV probe |
| A3 | "On Wednesday, engineering says Thursday's update cannot clear the last gate on the release checklist. Art and community have already promoted the event. Walk me through the next hour." | CASE | [generic] | Ask what failed and how severe it is, then lay out the options (slip, ship in part, ship with a known issue) and who decides each. Say how QA is brought in, what is told to art, engineering and community and by when, and what gets recorded afterwards. Say the framework aloud before using it | The JD's release-checklist and coordination lines (F3, F5) as a decision under pressure; CASE because it scores judgement, not recall |
| A4 | "Sketch how you would plan the first eight weeks of a live-events calendar for two titles. What do you need from me?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Start from what you ran, in those words, then the shape of a plan: fixed dates, dependencies between teams, buffers, review points. "What do you need from me" is a reciprocity beat: say what you would ask Tobias to decide and what you would own. Answer slot: the JD's two-titles line makes a probe on the scope of your calendar likely. Say what it covered and which title it was for; if any part was not yours to set, say so plainly and stay with the calendar you ran | F1 and F2 are the evidence behind the planning requirement. JD because it scores the first listed responsibility; CASE is the delivery |
| A5 | "How would you set up the review after an event, so that a team could trust what it says?" | JD | [generic] | Name what you would decide before the event ships: what success means, what it is compared against, which measures are reported and who owns each. Then the review's shape, what would change the next event, and how it is shared. Ask which measures the studio already reports for events, which is a fair clarifying question and assumes nothing | Covers the JD's post-event review and KPI line (F4). JD because it scores that responsibility; the question is deliberately about the design of the review, not your history |

### Bank B: Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't worked on a game with in-app purchases. How would you own the KPIs for an event on one of ours?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." and "Presented the monthly retention numbers to the studio head." | **The highest-ROI prep in this pack.** Hold-then-concede, built only from your own words. Open with the plain acknowledgment, no preamble: "I haven't worked on a game with in-app purchases." Then what you do have, at its scope: "I presented the monthly retention numbers to the studio head." Then the plan, said as a plan: which numbers the event review reports today and who owns each is the first thing you would ask. Follow-up 1, "what would you ask first?": return to the plan. Follow-up 2, "that is a real gap for a KPI role": concede in specifics, that the in-app-purchase side is the part you have not done, and hold what you did do. Follow-up 3, "how fast can you close it?": give your own honest estimate and no date you cannot back. Never describe how in-app purchases behave as if you had seen it | F10 is a gap you stated and F4 is where the JD asks for KPI ownership, so this question is the likeliest in some form; the pack infers it from those two rows. JD because it scores a stated responsibility; the deepest rehearsal because it is aimed where the material is thinnest |
| B2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Name one thing plainly and stop. If it is the one from B1, use the same plain words: consistency across questions reads as credibility. The JD's lines say coordinate teams, not lead them, so the in-app-purchase gap is the more direct answer. Then one first-month step. Do not pick a strength dressed as a weakness, and do not list everything | F10 and F9 are the two stated limits; this stem asks which one you will own. JD because it scores honest self-assessment against the listed role |
| B3 | "You haven't led a team, and this role coordinates design, art, engineering and community on each update. How do you coordinate teams you haven't led?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." and "I ran the weekly content-drop calendar for our main title for the last two years." | Open with the plain acknowledgment: "I haven't led a team." Then the calendar, at its scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: expect a probe on each of the four named teams. Say which of them you worked with on the drops and what you did with each, in your own words; if some were not part of it, say so plainly and stay with what the calendar covered. Then a plan for first contact with each team, said as a plan | F9 is the stated limit and F3 is the requirement it presses on. JD because the coordination line is a listed responsibility |
| B4 | "Your experience is as an associate producer, and this is a producer role asking for three years of producing live-service games. Where do you sit against that?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" and "I ran the weekly content-drop calendar for our main title for the last two years." | Say the facts as you gave them: "I spent four years as an associate producer at a puzzle-game studio, and for the last two I ran the weekly content-drop calendar for our main title." Answer slot: the years will be counted. Say which of the four the calendar covered, in your own words; if it was only the last two, say so plainly and let the number stand. Hold through two follow-ups by returning to what you ran, never by adding to it | F6 is the row where the JD's years line meets the title in your material. JD because it scores the first listed requirement |
| B5 | "What draws you to this role, and to us, after four years at a puzzle-game studio?" | CO | [grounded] "4 years as an associate producer at a puzzle-game studio" | Give your own actual reasons, in two parts: why this kind of work, and why Saltmarsh. The second part needs homework this pack could not do: play both of the studio's titles before Friday and name one thing about each you noticed. If you have not played them, say so plainly rather than guess. Never claim knowledge of the studio's plans | Motivation consistency is a standing Skeptic probe, and F6 is the history it will lean on. CO because "why here" scores homework |

### Bank C: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the monthly retention numbers you presented to the studio head. What was in them, and how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Beats the quote states: they were retention numbers, monthly, presented to the studio head. Answer slot: the JD asks about retention metrics, so expect the how-counted probe. Say which retention measures were in them and how they were counted, in your own words; if you did not build them, or do not know how a part was counted, say so plainly and stay with presenting them. Name the assumption behind them that you would defend least, if you know one | F7 is the evidence for the retention requirement. EXP because it scores what the CV line survives |
| C2 | "Did those retention numbers ever change what the team did? Walk me through one case, or tell me if they didn't." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if one case comes to mind, say what the numbers showed, what was decided, and which part was yours, in your own words. If none comes to mind, or the decision was someone else's, say so plainly and stay with presenting the numbers. Do not rank the case for importance; give it at its real size | F4 is where the JD asks for ownership, so the probe asks what the numbers did. EXP because it scores attribution and outcome |
| C3 | "A weekly content drop and a live event both lift retention on the day. How would you tell whether either moved the longer-term number?" | CASE | [generic] | Clarify which measure and which players. Say what you would compare against, what else shipped in the same window, and what you could not separate. Name the weakest assumption in your own method, and say what the data cannot show. No claim about your past is made here | The JD's retention line (F7) as a measurement problem. CASE because it scores method and the limits of the data |

### Bank D: Conversational/Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey. How did you end up in live production?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" and "I ran the weekly content-drop calendar for our main title for the last two years." and "Wrote the release checklist our QA team still uses." and "Presented the monthly retention numbers to the studio head." | A 90-second arc whose beats are these four sentences, in your own words: the four years as an associate producer, the weekly calendar for the last two, the checklist QA still uses, the monthly retention numbers presented. Answer slot: how you came into games and production is not in your material. Give your own actual reason; if there is no tidy story, say what actually happened. End on why this role, in the JD's own terms | F6, F2, F5 and F4 supply the beats. EXP because it scores whether the arc survives being checked against the CV |
| D2 | "What are you actually playing these days, especially anything with a live-events calendar?" | CO | [generic] | Name a game you actually play and one thing you noticed about how its events are paced or announced. If you have not yet played Saltmarsh's titles, say so plainly and say you plan to. Never claim a game you have not played | A casual question about a JD topic, still scored. CO because it scores genuine interest and homework |
| D3 | "Tell me about the release checklist you wrote." | EXP | [grounded] "Wrote the release checklist our QA team still uses." | The beats the quote states: you wrote it and QA still uses it. Answer slot: the JD asks you to manage the release checklist with QA. Say which parts of it were yours to set and how QA uses it today, in your own words; if you do not know how QA uses it now, say so plainly and stay with having written it | F5 and F8 rest on this one sentence, so this is where it gets probed. EXP because it scores what you actually did |
| D4 | "If you had to tell design, art, engineering and community in a few sentences that Thursday's event is slipping, what would you say?" | JD | [generic] | Say it aloud in four or five sentences: what is slipping, what is known and not yet known, what you need from each team, when the next update comes. Plain words, nothing softened to the point of hiding the slip. Offer to send it in writing straight afterwards | The JD's clear-written-communication line (F8) tested in a spoken register. JD because it scores that stated requirement |

### Bank E: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has run events on a game with in-app purchases?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." and "I ran the weekly content-drop calendar for our main title for the last two years." and "Wrote the release checklist our QA team still uses." and "Presented the monthly retention numbers to the studio head." | Pause and restate the question. Answer about yourself only, in the quotes' terms: the calendar you ran, the checklist QA still uses, the retention numbers you presented. Concede the specific point: "I haven't worked on a game with in-app purchases." Hold through two follow-ups; do not compare yourself with anyone | F10 is the stated gap this stem aims at. JD because it scores fit against the role; the pressure is delivery |
| E2 | "That calendar: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold first: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's plan-and-run line makes the follow-ups likely, on who set dates, who signed off, who decided what waited. Say which parts were yours, in your own words; where a decision was someone else's, say whose and what you did with it, and if there was no such step, say so plainly. Never fold on the core claim just to restore harmony, and never add to it | F2 is a claim with nothing inspected behind it, which is what attribution probes target. EXP because it scores what was yours |

### Bank F: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "How do you handle credit when an update spans design, art, engineering and community?" | VAL | [generic] | Offer principles, not a claimed history: who is named, in what words, and where. Keep "we" for context and "I" for what you did. If you want to use an example, pick it by the scaffold in F2 | The JD's four-team coordination line (F3) as a collaboration probe. VAL because it scores behavior toward peers |
| F2 | "Tell me about a time two teams disagreed about what could ship and you were in the middle." | VAL | [generic] | Selection scaffold: pick a time two teams disagreed about scope or timing, with a named stake, something specific you did, and a working relationship intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The theme comes from the JD's coordination line (F3). VAL because it scores disagreement style with equals |

### Bank G: Values/Behavioral

Saltmarsh's published values could not be researched, so these two come from standard behavioral prompts, not from the studio's own principles.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to a team that had worked hard on something." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not soften the message into nothing, and a relationship still intact. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioral stem; the loop's values content is unknown (see Sources). VAL because it scores behavior, not knowledge |
| G2 | "When did you put the player experience ahead of a number you had been asked to hit?" | VAL | [generic] | Selection scaffold: pick a time where the two pulled apart, with something you chose and something it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioral stem, relevant to a live-service role. VAL because it scores judgement between two goods |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A1, A4, E2 |
| "coordinate design, art, engineering and community teams on each update" | A1, A3, B3, D4, F1, F2 |
| "own the post-event review and the KPIs it reports" | A2, A5, B1, C2 |
| "manage the release checklist with QA" | A3, D3 |
| "3+ years producing live-service games or apps" | B4, D1 |
| "experience running a content calendar" | A4, E2 |
| "comfortable with player-retention metrics" | A2, C1, C2, C3 |
| "clear written communication" | D4 — and F8's evidence is the checklist, probed in D3 |

Your material gives no figures, so no defend-the-number question was written; C1 carries the how-counted probe the retention requirement raises.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a good first ninety days look like in this role, and what would you want produced in them?" | Shows you think in deliverables, and gives you the success bar in his words |
| R2 | "How do the two titles differ in cadence and in what their events are meant to achieve?" | Shows interest in the actual product, and fills the research this pack could not do |
| R3 | "Which measures does the post-event review report today, and who owns each?" | Targets the JD's KPI line directly, and lets you learn the studio's terms without pretending to have them |
| R4 | "Where does the release checklist process with QA work well, and where does it strain?" | Invites a real answer on the checklist part of the JD |
| R5 | "When design, art, engineering and community want different things for an update, who sets the priority, and where does the producer sit?" | Clarifies authority for a role that coordinates teams, and shows you are thinking about the seam |
| R6 | "What would make someone with my background succeed here, and what would make them struggle?" | Invites the objection into the open, where you can answer it; listen to the answer rather than defend |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live events, or a live-events calendar, across two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says a weekly content-drop calendar for the main title, not live events across two titles. A4 and E2 stay inside the calendar you ran |
| Owned the post-event review and its KPIs | Inflated form of F4 | F4's quote at its own scope. The pack observes that your material says you presented the numbers, not that you owned a review or its KPIs. C2 stays inside presenting them |
| Managed releases with QA | Inflated form of F5 | F5's quote at its own scope. The pack observes that your material says you wrote the checklist and QA still uses it, not that you managed releases. D3 stays inside the checklist |
| Four years producing live-service games | Inflated form of F6 | F6's quotes at their own scope. The pack observes that your material says four years as an associate producer and two years on the calendar. B4 stays inside those two facts |
| Led a team | Negative you stated, F9: "Never led a team, and never worked on a game with in-app purchases." — your message | The plain acknowledgment: "I haven't led a team." No slot |
| Experience with in-app purchases, or with monetization KPIs | Negative you stated, F10: "Never led a team, and never worked on a game with in-app purchases." — your message | The plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot |

## Sources

Provided documents: the JD text and your background, both pasted in your message. No dossier was present.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | The one call was refused. It would have fed a values cheat sheet; that section is dropped and Bank G uses standard stems |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | The one call was refused. It would have named the loop's rounds; weights rest on your note and the relationship prior instead |
| 3. `Saltmarsh Games strategy news` | unavailable | The one call was refused. It would have grounded CO and CASE questions in current strategy; they are labelled generic instead |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | The one call was refused. It would have fed an interviewer read and a reverse question tied to his path; both are absent |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

Queries sent, all refused:

- `Saltmarsh Games mobile studio values` — refused
- `Saltmarsh Games interview process live operations producer` — refused
- `Saltmarsh Games strategy news mobile` — refused
- `Tobias Wrenfield Saltmarsh Games Head of Live Operations` — refused

## Upgrade menu

- How Tobias relates to the role (manager, peer, skip-level) and anything the recruiter said about focus areas, a case, or something to bring → persona weights recomputed, and a build section for any announced deliverable
- Tobias's public talks or writing, or a profile summary pasted in → an interviewer read and a reverse question tied to his own path
- Saltmarsh's careers or values page and anything on its interview process, pasted or fetched with search allowed → a values cheat sheet, loop-based persona weights, and CO and CASE questions grounded in the studio's current strategy in place of the generic ones
- A sanitised copy of the release checklist, or any write-up you wrote → F5 and F8 move from medium to high
- Your own answers to the answer slots in A4, B3, B4, C1, C2, D3 and E2 → F1, F3, F4 and F6 move from slots to grounded rows
- A prior `tuesday-dossier.md`, if you have one → verified evidence and a per-gap strategy that sharpen the Skeptic bank
