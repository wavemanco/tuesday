# Mock interview pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

- **Candidate:** Priya
- **Interviewer:** Dan Kovac, Director of Sales Strategy. A peer: both report to the same VP.
- **Round:** one 60-minute conversation with Dan.
- **Built on:** the JD highlights, the candidate notes, the interviewer profile and the research note in your message. Not a full JD, not her CV. Web research was refused (see Sources), so nothing here comes from outside your message.

## How to use this pack

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did. An answer slot is an instruction for the interview. Where it offers two branches, either one is a good answer.

| Type tag | Meaning |
|---|---|
| VAL | Behavioral: does past behavior show the company's published values (none were obtainable here, so VAL questions here test behavioral fit generally) |
| EXP | Work-experience deep-dive: do the claims survive scrutiny, and what was actually yours |
| JD | Role-driven: can you do the stated job, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem from the actual role |

Highest-ROI prep in this pack: **C1**, the "no sales-ops or quota-setting" objection. It will arrive from a Sales Strategy director in some form, probably as A1, G1 or C1 itself. Rehearse it until it is boring.

## Fit snapshot

Requirements are quoted from your "JD highlights", which are highlights and not the full posting. Evidence is quoted from your notes on the candidate, not from her CV, so Confidence stops at `medium` while nothing has been inspected.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [inferred] | transferability | Your material says product strategy and ops, with consulting before it, and nothing inspected behind it. Words stay at the quote: "For nine years I was in product strategy and ops at a large consumer-tech company." Answer slot: the JD's line on owning strategy for new product lines makes a probe on which strategy decisions were yours likely. If any were yours to set, say which and how you decided, in your own words; if none were, or they were not yours, say so plainly and describe the work you did |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | low | [inferred] | discovery | The quote shows a proposal credited with an ARR uplift; it does not show whether that work looked across stages of a customer lifecycle. Words at scope: "I proposed a store-surface change credited with a ~$400M ARR uplift." Answer slot: the JD's land/adopt/expand/renew line makes a probe likely on whether that work looked at where users or customers sat in a lifecycle. If it did, say how and what part was yours; if it did not, or it was not yours, say so plainly and stay with the proposal |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | No gap, but a skills line with nothing inspected behind it, so expect a probe from an interviewer who self-describes as data-driven. Lead with the line in its own terms: "I'm skilled in SQL/Tableau." A named query or workbook beats the adjective (see upgrade menu) |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [inferred] | transferability | The quote carries a revenue model used in negotiations; your material does not say whether any of that work set how a partner goes to market. Words at scope: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: the JD says experience is required, so expect a probe on which parts of the carrier work were yours to set. If any were, say which and how you decided; if the work was the model and its use in the negotiations, or none of it was yours to set, say so plainly and return to the model |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | presentation | The quote already reaches the requirement in other terms. Reword only it: "I set annual volume targets, and they were agreed across the organizations involved." Nothing about who disagreed or how is in the material, so those are slots in A3 and B4 |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — the coach's notes | medium | [grounded] | presentation | The quote reaches the requirement as use of tools. Words at scope: "I use AI tools daily." The material says use, not building or launching, and the words stay there |
| F7 | Fluency in sales-ops mechanics such as quota-setting, which a Sales Strategy peer is likely to test (role-family expectation, no source quoted) | "No classic sales-ops or quota-setting experience" — the coach's notes | none | [grounded] | capability | A gap the candidate stated, and wording cannot close it. Words: "I haven't had classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |

F7's requirement is `[generic]` prose and raises no slot of its own. The pack includes it because the candidate stated the absence and Dan's role puts him on the other side of it.

## Reading the interviewer

Public professional footprint only, and only what you relayed: no search could be run.

| Signal | Source | What it means for the conversation | Provenance |
|---|---|---|---|
| "relentlessly data-driven" | Dan's profile self-description, relayed in your message | Expect each number probed down to its assumptions; the Prober bank (B) is sized up for this. Say plainly where you do not know how a figure was counted | [inferred] |
| "pricing and monetization roles, with one early-stage-startup chapter" | Dan's career spine, relayed in your message | Case questions likely tilt to pricing, packaging and unit economics (D3, A5). The startup chapter makes a builder or scrappiness probe plausible; no quote in the material carries her side of that, so no shared jump is offered | [inferred] |
| Shared vocabulary: revenue and monetization | F4 evidence: "built a partner-level revenue model used in carrier negotiations" | A natural bridge into his language. Use the quote at its own scope and let him draw the inference | [grounded] |
| Peer, same VP | Your message | He is weighing what the hire adds to or takes from his work. Offer what you bring, not only what you need (A2) | [generic] |

## Persona table

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| A. Peer Evaluator | Seam-splitting, "what would you need from me", credit and disagreement probes | **High.** Relationship prior for a peer, and the same VP means the seam is a live issue | Reciprocity; propose seam principles, not a seam you have not seen; hold quotes at their own scope |
| B. Data-Driven Prober | Line-by-line scrutiny of the numbers and the model | **High.** The peer prior, raised by the self-described "relentlessly data-driven" signal | Name the weakest assumption before he does; say plainly when you do not know how a figure was counted |
| C. Skeptic | The background mismatch, the missing competency, why leave and why now | **Medium.** F7 is a stated gap and F4 is only adjacent; a skeptic's questions arrive collegially from a peer | Rehearse C1 until boring; bridges only from the quotes, with the limit said plainly |
| D. Case / Strategist | Live problems on the two new lines, pricing and bundling | **Medium.** Peers ask role problems less than managers do, but the pricing spine and the stated priorities make them likely | Clarify, objective, segmentation, approach, metrics, risks; challenge one premise respectfully |
| E. Conversational | The journey question, "what are you playing with in AI" | **Low-medium.** Likely as openers and as the casual form of the JD's AI plus; casual questions are still scored | A 90-second arc built from the quote; treat the AI question as scored |
| F. Values / Behavioral | Open "tell me about a time" probes | **Low.** No values-style round is detected: one 60-minute conversation with a peer, and no published values were obtainable | Selection scaffolds, ending in the honest branch |
| G. Pressure | Time-boxed or devil's-advocate challenges | **Low.** Not a peer prior, but the F7 gap and the $400M figure invite it | Pause, restate, hold through two follow-ups, concede specifically |

Weights follow the loop your message establishes: a single session, so blended persona depth (5 / 5 / 3 / 3 / 2 / 2 / 2).

## Question banks

### A. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our teams sit side by side. Where's the seam between Sales Strategy and this role, and what happens when we disagree?" | JD | [generic] | Offer principles, not a seam you have not seen. One: say you would learn how the seam works today before proposing one. Two: one owner per decision, the other consulted, with the data both teams trust agreed in advance. Three: when you disagree, put both numbers side by side, agree what would change each of your minds, and only then take it to the shared VP. End by asking where the seam hurts today. The guidance makes no claim about your past | The peer prior puts seam-splitting first, and the JD's cross-functional line (F5) makes it a scored requirement. JD because it tests the stated role; it is generic because it is a pattern, not a fact about Northwind |
| A2 | "What would you want from me in your first ninety days, and what would I get from you?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" "skilled in SQL/Tableau" | Two halves. Asks, kept small and specific: a walk-through of how Sales Strategy plans today, said as a plan to learn. Gives, only what the quotes carry: "I built a partner-level revenue model used in carrier negotiations" and "I'm skilled in SQL/Tableau". Let him decide what those are worth to his team. No slot | Reciprocity is the peer evaluator's real question, and the reverse-question bank repeats the idea (see below). F3 and F4 supply the offer; JD because it tests how the role plugs into his work |
| A3 | "How do you handle credit when work spans teams?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Use "we" for the context and "I" for your contribution. The beats the quote states: annual volume targets, set, with consensus across the orgs. Answer slot: expect a probe on which parts of getting that consensus were yours. If you led particular conversations or steps, say which; if the consensus came through others, or none of those steps were yours, say so plainly and return to the targets you set | A peer's standard credit probe, and F5 is the only evidence of work across teams. EXP because it tests attribution, not values |
| A4 | "Tell me about a time you disagreed with a peer in another org. How did it end?" | VAL | [generic] | Selection scaffold. Pick a disagreement with an equal, not a report: it needs a named stake, the position you held, what you conceded, and the relationship intact at the end. Context in "we", your contribution in "I". If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The persona's disagreement-with-equals stem. VAL is the closest tag for a behavioral probe, though no published value is in hand, so it is scored on spine and tact. Generic because the pack holds no quoted disagreement |
| A5 | "We'll both touch packaging and pricing for the new lines. Where do you want my view, and where would you decide alone?" | JD | [generic] | Ask before assuming. Offer a division in principle: pricing, his native ground, he leads and you bring the adoption and partner implications; motion and partner choices lead from your side with him consulted. Close by asking how pricing decisions get made today. No claim about your past | His pricing and monetization spine (see Reading the interviewer) makes this the likeliest seam topic. JD because it tests the stated GTM mandate |

### B. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "That ~$400M ARR uplift: walk me through how it was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Open at the quote's scope: "I proposed a store-surface change, and it was credited with a ~$400M ARR uplift." Then the four slots a figure raises, each in your own words: how the figure was counted; what it is sensitive to; the assumption behind it you would defend least, named before he asks; and which part was yours. If you do not know how any of that was counted, say so plainly rather than reconstructing it | The headline number on the CV, so every figure-probing interviewer reaches for it (F2). EXP because it tests whether a claim survives scrutiny and what was actually hers |
| B2 | "Walk me through the partner-level revenue model end to end." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Beats the quote states: partner-level, revenue, used in carrier negotiations. Answer slot: expect a probe on what went into the model and what it was sensitive to. If you set the inputs, say which and where they came from; if some were supplied by others, or you do not know how one was set, say so plainly and return to how the model was used in the negotiations. Offer to go deeper on any piece | The one analysis a data-driven interviewer can have walked end to end (F4). EXP because it checks that she built what she says she built |
| B3 | "Tell me about an analysis where you wrote the queries and built the view yourself." | JD | [grounded] "skilled in SQL/Tableau" | Selection scaffold. Pick an analysis you can narrate in order: the question, the data you asked for, the queries or view you produced, what it changed. Say it at the scope you did it, and bring the artifact if one can be shared. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would do it. Lead with "I'm skilled in SQL/Tableau" and let the example prove it | The JD requires independent analysis, and F3 has nothing inspected behind it, which is exactly what a data-driven peer tests |
| B4 | "How were those annual volume targets derived, and where did the orgs push back?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Beats the quote states: annual volume targets, set, agreed across the orgs. Answer slot: expect a probe on how the targets were derived and whether the orgs differed. If you derived them, say how and from what inputs, in your own words; if the orgs did not differ, or the derivation was not yours, say so plainly and return to the targets you set. Name the assumption behind the targets you would defend least | F5's evidence is thin on mechanism, and a prober presses on mechanism. EXP because it tests what she actually did |
| B5 | "Two quarters into a new GTM motion, how do you know it is working? Which metric would you trust least?" | CASE | [generic] | Structure aloud: what the motion is meant to change, a leading and a lagging measure for each stage, then name the metric you would trust least and why before he does. Say what data you would pull and how. No claim about your past | JD territory delivered as a prober's question: he scores whether you know a metric's weakest assumption. CASE because it is a live problem; generic because no quote carries it |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You haven't set quotas or run sales ops, and this role sits next to mine. Why should I trust you on the parts of GTM that run through them?" | EXP | [grounded] "No classic sales-ops or quota-setting experience" "set annual volume targets with cross-org consensus" | **Highest-ROI rehearsal.** Hold-then-concede, four levels. (1) Say it before he does: "I haven't had classic sales-ops or quota-setting experience." (2) Name the limit with the quote at its own scope: "I set annual volume targets with cross-org consensus", and say plainly that this is adjacent and not the same. (3) Follow-up "Then why you?": return to the role's own ask and the quotes in A2, adding nothing. (4) Follow-up "Targets are just quotas by another name": concede exactly, for example "They may rhyme, and I haven't set quotas, so I'd want your team to show me where they differ." Do not fold on what the quote carries and do not stretch it. (5) Follow-up "What would you get wrong first?" Answer slot: name, in your own words, the one place the gap would most likely show; if you cannot name it, say what you would ask first. Close with the ramp, as a plan: ask to be walked through how quotas are set and which inputs the team trusts least, and learn before proposing | F7 is the candidate's own stated gap, and Dan's job sits on its other side, so this is the likeliest probe in the conversation. EXP because it tests candor about a stated absence, not a JD line |
| C2 | "You've spent nine years at one large consumer company. Why leave for B2B data infrastructure, and why this role now?" | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | The reason is yours and this pack does not supply one. Structure it: what pulls you to this role, specific to what the JD asks; what you are not running from; one sentence on what you want to learn. Selection criteria: the reason has to be one you would still give after a second question. If no clear reason comes to mind, say so plainly and say what you are testing | The skeptic's classic motivation probe, sharpened by the long single-company tenure and the sector jump (F1). EXP because it tests whether the career story survives cross-examination |
| C3 | "The role needs partner-motion design. Which part of your carrier work comes closest to that?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Answer at the quote's scope: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: expect a probe on which parts of that work were yours to set. If any were, say which and how you decided, in your own words; if the work was the model and its use in the negotiations, or none of it was yours to set, say so plainly and return to the model. Say what you would want to learn about the partner side before proposing anything | The JD says experience is required and F4 is adjacent, so the limit is the likely probe. JD because it scores the stated requirement; asked "which comes closest" so it presupposes nothing |

### D. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Two new product lines, no customer history. How would you size whitespace across land, adopt, expand and renew?" | CASE | [generic] | Clarify first: what the two lines are, who buys, what data exists. State the objective. Segment by lifecycle stage and ask one question per stage: who is not landing, what is not being adopted, where expansion stalls, what risks renewal. Say which data you would pull, then your metric for each stage and the biggest risk to the sizing. Use the JD's own words for the stages | The JD's whitespace line is the stage-by-stage frame, and F2 is only adjacent, so this tests the capability live. CASE because it is a live problem; generic because no quote carries it |
| D2 | "A much larger platform vendor bundles a competing feature into its suite. What does that change for Compass?" | CO | [grounded] | Clarify: what is bundled, at what price, in which segments, and whether Compass is one of your two lines. Offer one consensus option to show grounding (compete on depth), then your own thesis, for example treating Compass pricing as a packaging decision rather than a discount response, and name the segment you would not fight for. Frame everything as hypotheses to test | Your research note names bundling by a much larger platform vendor as the main competitive threat and the Compass launch as a priority. CO because it tests company altitude; CASE delivery. The anti-pick is where a peer scores judgment |
| D3 | "Enterprise expansion and profitability are both priorities. How would you decide where scarce GTM effort goes across the core product and the new lines?" | CASE | [grounded] | Clarify what profitability means here (margin, payback, or a spend cap). Set the criteria: expansion potential, cost to serve, time to payback, strategic value. Compare the options on those, and say what data would change your mind. Name what you would stop doing. Pricing and unit economics are his native vocabulary, so use them plainly | Two of your research note's three stated priorities pull against each other, and the pricing spine makes this his home turf. CASE with CO content |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc whose beats are the quote's: two years of strategy consulting at a top firm, then nine years in product strategy and ops at a large consumer-tech company. Then one sentence on why this role is next, in your own words. Keep it short; he will pick the thread he wants | The biography opener is scored for economy (F1). EXP because it frames everything he asks next |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Say it at its scope: "I use AI tools daily." Answer slot: name which tools and for what tasks, in your own words; if the use is for your own work and not something shipped to customers, say so plainly. Then, as a view and not a claim, how you would think about GTM for an AI copilot like Compass | The JD's AI plus asked in the casual register that still scores (F6). JD because the requirement is the topic |

### F. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time the data told you something leadership did not want to hear." | VAL | [generic] | Selection scaffold. Pick a time with a named stake, the number, who did not want to hear it, what you did, and what changed; the hard truth has to have landed. "We" for context, "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The persona's unpopular-truth stem, tuned to his self-described data-driven style. VAL because it tests behavior; generic because no quote carries a story like this |
| F2 | "When did a number change your mind?" | VAL | [generic] | Selection scaffold. Pick a case where you held a view, saw a number that contradicted it, and changed course, with the number named. Say what you had believed and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Pairs with the prober bank: a data-driven peer asks whether you update. VAL; generic for the same reason |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you, over a candidate who has run sales ops?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" "set annual volume targets with cross-org consensus" "No classic sales-ops or quota-setting experience" | Pause, restate the question, then three beats in order: concede first, "I haven't had classic sales-ops or quota-setting experience"; then what you did bring, as quoted: "I built a partner-level revenue model used in carrier negotiations" and "I set annual volume targets with cross-org consensus". Claim no more and do not claim to be the better candidate. Hold through two follow-ups by returning to those quotes | The time-boxed form of C1, so it tests composure on the same gap (F7). JD because it scores fit to the stated job |
| G2 | "That $400M result: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold at the verb the quote states: "I proposed the change." Answer slot: if you were involved after the proposal, in building, launching or measuring it, say which part and how; if you were not, or you do not know how credit was assigned, say so plainly and return to the proposal. Hold through two follow-ups by returning to "proposed", never adding to it | The attribution stem on the figure that most invites it (F2). EXP because it tests precise attribution |

### Requirement coverage

| JD requirement (JD highlights) | Questions |
|---|---|
| "own GTM strategy for two new product lines" | D1, D2, D3, A5, B5 |
| "identify whitespace across land/adopt/expand/renew" | D1 |
| "run independent analysis in SQL and Tableau" | B3, B5 |
| "partner-motion design experience required" | C3, B2 |
| "strong cross-functional influence" | A1, A2, A3, A4, B4 |
| "AI experience a plus" | E2, D2 |
| Stated gap: no sales-ops or quota-setting (F7, not a JD line) | C1, G1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You've worked in pricing and monetization, with a stint at an early-stage company. What from the pricing playbook transfers to a new product line with no price history, and what doesn't?" | Ties to his own path and invites him to teach, which turns a probe into a peer conversation |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer: it asks what the hire adds to his load, not only what she needs |
| R3 | "Which two lines does this role cover, and is Compass one of them? Where is each in its launch?" | Shows she has read the priorities, and the answer tells her whether D1 or D2 carries more weight |
| R4 | "Where does the seam sit today between this role and Sales Strategy on quotas and partner decisions, and what failure would you most like to avoid?" | Picks the seam she has already named as her gap, on her terms, before he can use it against her |
| R5 | "How is success for this role measured after two quarters, and which of those numbers would you trust least?" | Mirrors his data-driven stance and shows she thinks in assumptions |
| R6 | "With bundling by a larger platform vendor as the main competitive threat, which segments are you most willing to concede?" | Shows the anti-pick thinking from D2 and asks for his judgment, not a recital |
| R7 | "Which partners does the company sell through today, and what is the biggest open question about how that motion should work for the new lines?" | Goes straight at the JD's partner-motion requirement and shows she wants to learn the part she has not designed |

## Prohibited claims

Built from the fit snapshot before the banks were written. Nothing in this pack coaches these.

| Not coached | Basis | Honest form |
|---|---|---|
| Has sales-ops or quota-setting experience | A negative the candidate stated, F7 | The plain acknowledgment: "I haven't had classic sales-ops or quota-setting experience." No slot |
| That setting annual volume targets was quota-setting | Contradicted by the stated negative in F7 | F5's quote at its own scope: "set annual volume targets with cross-org consensus". The limit is the pack's observation: the material says volume targets, not quotas |
| Has designed partner motions | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the material says a revenue model used in negotiations, not a motion design. C3's slot stays inside the carrier work |
| Has owned GTM strategy for a product line | Inflated form of F1 | F1's quote at its own scope. The material says product strategy and ops, not GTM ownership. F1's slot stays inside the strategy work |
| Drove, delivered or owned the ~$400M ARR uplift | Inflated form of F2 | F2's quote at its own scope: she proposed the change, and it was credited with the uplift. B1 and G2 slots ask only how it was counted and what part she played |
| Has AI product or AI GTM experience | Inflated form of F6 | F6's quote at its own scope: "uses AI tools daily". E2's slot asks only which tools and for what |

## Sources

**Provided documents:** your message, carrying the JD highlights, the candidate notes, the interviewer profile and the research note. No dossier was present.

**Searches sent (all refused):**

- "Northwind Data B2B data infrastructure company values": refused
- "Northwind Data Compass AI copilot launch strategy": refused
- "Dan Kovac Director of Sales Strategy Northwind Data": refused

No page was fetched.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | The call was refused. Official value names would have themed the VAL questions and enabled a values cheat sheet, but no values-style round is detected anyway, so F and A4 stay behavioral and generic |
| 2. `Northwind Data interview process, GTM strategy` | skipped | Your message already establishes the loop: one 60-minute conversation with Dan. Persona weights follow it |
| 3. `Northwind Data strategy` / recent news | unavailable | The call, aimed at checking the age and accuracy of your research note, was refused. The note is used as given and its age is unverified; it feeds D2 and D3 |
| 4. `Dan Kovac Northwind Data` | unavailable | The call was refused. His published talks and writing would have deepened the interviewer read and the reverse questions; the read rests on the profile you relayed |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights you supplied fix the requirement rows and the JD-tagged questions |

## Upgrade menu

- Her CV text as written → the evidence column's "the coach's notes" quotes become "your CV" quotes, and any row whose wording differs from your summary is corrected
- A SQL query or Tableau workbook she wrote, if shareable → F3 can reach `high`, and B3 becomes a story-mapped answer
- A document, model or deck showing the carrier revenue model → F4 and B2 can reach `high`, and C3's limit becomes sharper
- The full JD text → any requirement not in your highlights becomes a fit row and a JD-tagged question, and any gate such as location, schedule or pay is surfaced; no gate row exists now because the highlights state none
- Any recruiter guidance on this conversation, such as stated focus areas or a pre-declared deliverable → a graded-deliverable build section and a sharper persona weighting; usually one email to the recruiter
- Which two product lines the role covers, and whether Compass is one → D1 and D2 retuned, and R3 answered
- Permission for web search, so the interviewer footprint, Northwind's published values and loop, and a freshness check on your research note can run → a fuller interviewer read, a values cheat sheet if a values round exists, and `[grounded]` CO questions. A further deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) would add a grounding brief; it runs only on your approval
- A story from her work of building something with few resources → a grounded answer to the scrappiness probe his startup chapter makes plausible
- A `tuesday-dossier.md` from earlier work → verified evidence and a named top objection would replace this pack's inferences
