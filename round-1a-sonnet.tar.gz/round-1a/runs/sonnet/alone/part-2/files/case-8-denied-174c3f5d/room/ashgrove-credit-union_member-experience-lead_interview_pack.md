# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara. **Loop:** three rounds on 26 November 2026, built in loop mode.

| Round | Who | Length | What the recruiter's email says |
|---|---|---|---|
| 1 | The recruiter | 30 minutes | "30 minutes with me" |
| 2 | Head of Member Services, your would-be manager | 45 minutes | "mostly behavioural" |
| 3 | Panel of two branch managers | 60 minutes | "including a 20-minute case on a complaint escalation. The panel is also the values round — they score against the four values." |

No interviewer names are assigned yet, so there is no interviewer read.

## How to use this pack, and the type key

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did. Wherever guidance says "answer slot", that is an instruction for the interview, not a question for me.

| Type | What it scores |
|---|---|
| VAL | Whether your past behaviour shows Ashgrove's published values |
| EXP | Whether your background claims survive scrutiny |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know Ashgrove's strategy and can think at its altitude |
| CASE | Structure and reasoning on a live problem from the role |

The deepest rehearsal in this pack is **C1** (Round 2, the contact-centre objection). It is the highest-ROI prep here: F2 is the gap the JD's first line presses hardest, and your future manager is the likeliest person to ask. Do C1 aloud until it is boring.

## The fit snapshot

Requirements quote the JD you pasted. Evidence quotes your own words from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says you handled the branch's log, not the process end to end, so the words stay at the log: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what happened to a complaint after the log likely. If any step after the log was yours, say which, in your own words; if your part ended at the log, say so plainly and stay with the log |
| F2 | "the contact centre" (same JD line as F1) — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You stated this absence. Words: "I've never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your material says you built the monthly complaints spreadsheet and that your regional manager uses it; it does not show what the sheet counted. Answer slot: the JD's monthly-reporting line makes a probe on what the sheet showed likely. Say what it showed, in your own words; if you are unsure how any figure in it was counted, say so plainly; if it showed less than the JD describes, say so and stay with the sheet |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | Your material says spreadsheet, not which tool. Answer slot: the JD names Excel, so expect "which tool?". Say which tool it was, in your own words; if it was not Excel, say so plainly and say what it was |
| F5 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message; "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | transferability | Your material says tellers and a script; the JD says supervisors. The words stay with tellers: "trained new tellers on our escalation script." Answer slot: if you have coached anyone who held a supervisor's role on an escalation, say how it went and what part was yours; if not, say so plainly and stay with the tellers |
| F6 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not show either way. Answer slot: if you have worked with a digital or app team on anything members use, say what and what part was yours; if you have not, say so plainly and say what you would ask that team first |
| F7 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You stated this absence. Words: "I've never presented to anyone above regional level." Then a plan, said as a plan. Your material says nothing about what you presented at regional level, so nothing is claimed about it |
| F8 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap, but a statement with nothing inspected behind it, so expect a probe. Lead with the sentence's own terms: six years in retail banking, the last three as a branch supervisor. Let the interviewer read it against the JD's line rather than relabelling it yourself |
| F9 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | Your material says a formal complaints log, not which rules it was kept under. The words stay at the log. Answer slot: the JD's complaints line makes a probe on what governed the log likely. If any deadline or rule applied to its entries, say which and what was yours to do under it, in your own words; if none you know of, or it was not yours, say so plainly and stay with the log |

## Grounding brief

You relayed these four points from Ashgrove's July 2026 strategy brief. I have not seen the brief itself.

| Point | Source | Where it can surface | Provenance |
|---|---|---|---|
| Move 40% of member service to digital channels by 2028 | Your message, from the brief the recruiter sent | E1, G4, reverse questions R2-2 | [grounded] |
| Consolidate eight branches into five hubs over 2027 | Your message, from the brief the recruiter sent | F3 and F5 in Round 3, reverse questions R1-2 and R3-3 | [grounded] |
| Launch a small-business lending product in Q1 2027 | Your message, from the brief the recruiter sent | E2 | [grounded] |
| Main competitive pressure is app-only banks | Your message, from the brief the recruiter sent | A2, G1 | [grounded] |

---

# Round 1 — the recruiter (30 minutes)

## Persona table

| Persona | How it shows up | Weight and why | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly walk-through of your background; pay, notice, location and reason for leaving | Highest, six questions. The recruiter-screen prior is conversational logistics, and the email says "30 minutes with me" | A 90-second arc you have said aloud; treat every casual question as scored |
| Skeptic (light) | Knockout checks against the JD's lines | Lighter, four questions. The recruiter screens against the JD, and F2 and F7 are absences you stated | Plain acknowledgment, then a plan; never bluff a line the next round owns |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | An arc in three beats, each at its quoted scope: six years in retail banking, the last three as a branch supervisor; handled the branch's formal complaints log and trained new tellers on our escalation script; built the monthly complaints spreadsheet your regional manager uses. Tell it in your own words and stop at 90 seconds. Add nothing about outcomes unless you can say what they were | Every recruiter screen opens this way; F1, F3 and F8 are the rows the arc must carry. EXP because it tests whether the story matches the document |
| A2 | "Why Ashgrove, and why a credit union?" | CO | [grounded] | Answer slot: give your actual reason. You can anchor it in published material without claiming anything about your past: the values as Ashgrove words them ("Members First, Always", "Plain Words", "Neighbours, Not Numbers", "Own the Fix") and the brief's point that app-only banks are the main competitive pressure. Pick the one you genuinely care about and say why | Motivation consistency is scored even in a friendly register; the values and brief are the published material to use. CO because it tests homework |
| A3 | "What's prompting you to look at a move now?" | EXP | [generic] | Logistics slot: give your actual reason for leaving, in your own words. Keep it to what you want from the role and avoid running down your current employer. No reason is supplied here because none was given | The reason-for-leaving question is a standing logistics check in a screen. EXP because it tests whether your account stays consistent across rounds |
| A4 | "What are you looking for salary-wise?" | JD | [generic] | Logistics slot: give your own number, or ask for the role's band first. This pack supplies no figure, and the JD you pasted states none | Pay is a logistics check at this stage; the JD carries no figure, so only your own answer can fill it |
| A5 | "What notice period do you have?" | JD | [generic] | Logistics slot: give your actual notice period. | A logistics check; only you hold the fact |
| A6 | "Where are you based, and how would working at our sites work for you?" | JD | [generic] | Logistics slot: give your actual location and any real constraint. The JD you pasted names no location, so ask the recruiter where the role sits if it matters | A logistics check; the JD is silent on location, so this is an open slot |
| B1 | "The role covers the contact centre as well as the branches. How do you see that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | A lighter version of C1. Plain acknowledgment: "I've never worked in a contact centre." Then what your material does carry, at its scope: "I handled the branch's formal complaints log." Then a plan in your own words: what you would want to see first about how complaints reach the contact centre. Do not claim anything about contact-centre work | F2 is the first line of the JD pressed against a stated absence; the recruiter will relay your answer. JD because it scores the stated requirement |
| B2 | "The role asks for 4+ years in financial-services customer operations. How does your background line up?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Say the sentence in its own terms: six years in retail banking, the last three as a branch supervisor. Answer slot: if they ask whether branch work counts as customer operations, describe the work itself in your own words rather than relabelling it | F8 is the cleanest row but a recruiter still needs to hear it matched to the line; JD because it is a stated requirement |
| B3 | "This role presents to senior leaders. How do you feel about that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain acknowledgment: "I've never presented to anyone above regional level." Then a plan in your own words for getting ready, such as presenting a monthly complaints report aloud to a colleague before the 26th. Say it as a plan, not as a past | F7 is a stated absence and the JD's wording is "confident presenting to senior leaders", so a short, honest answer protects the later rounds |
| B4 | "How comfortable are you with Excel reporting?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | The quote at its scope: you built the monthly complaints spreadsheet your regional manager uses. Answer slot: say which tool it was; if it was Excel, say so, and if not, say what it was. Do not name functions or features you did not use | F4's requirement is one the recruiter can tick or not; JD because it scores a named tool |

## Reverse questions for Round 1

| # | Question | Why it lands |
|---|---|---|
| R1-1 | "Who would I work most closely with across the branches and the contact centre, and how is the complaints process split between them today?" | Shows you took the end-to-end line seriously and asks what the contact-centre gap needs, without claiming experience |
| R1-2 | "How does the move from eight branches to five hubs sit with this role, and when would it start touching complaints?" | Uses the brief and shows you read it |
| R1-3 | "What do the next two rounds focus on, and can I see the format of the case in advance?" | One email's worth of guidance from the recruiter; the Round 3 case is the least predictable part of the loop |
| R1-4 | "Who reads the monthly complaints report, and what does it feed into?" | Ties to the JD's reporting line and previews the F7 audience |
| R1-5 | "What does the timeline look like after the 26th?" | A practical close that also shows you are planning |

---

# Round 2 — Head of Member Services, your would-be manager (45 minutes, mostly behavioural)

## Persona table

| Persona | How it shows up | Weight and why | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the gaps: contact centre, supervisors, senior presenting, digital | Highest, five questions. The hiring-manager prior is Case plus Skeptic, and this person is "your manager" in the recruiter's words; F2 and F7 are stated absences | Rehearse C1 until it is boring; plain acknowledgment, held position, concrete plan |
| Data-Driven Prober | Reads the log and spreadsheet claims two levels deep | Middle, three questions. "Mostly behavioural" tilts toward your past, and F3 and F9 are the rows with the least shown | Say what you know; say plainly what you do not know about how anything was counted |
| Case / Strategist | Live problems from the brief | Lower, two questions. The email says mostly behavioural, so cases are likely light here; the real case is in Round 3 | Clarify first; use Ashgrove's own words |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "This role owns complaints across the branches and the contact centre, and you haven't worked in a contact centre. What makes you the right person to own it?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The highest-ROI rehearsal in this pack. Hold-then-concede in four beats. One, plain acknowledgment: "I've never worked in a contact centre." Two, what your material carries, at its scope: you handled the branch's formal complaints log and trained new tellers on our escalation script. Three, a plan in your own words: the first two or three things you would want to learn and from whom. If you do not have that plan yet, build it before the 26th. Four, follow-up 1, "How would you earn credibility with the agents?": say what you would ask and listen for, not what you have done. Follow-up 2, "What would go wrong first?": name one real risk of coming from branches, in your own words, and what you would do about it. The limit to name before it is asked: your material carries the branch log, not the contact centre. Do not move to "I know how complaints travel across channels" | F2 is the gap the JD's opening line presses hardest and the manager owns it; the rubric's rule for the deepest rehearsal is the most follow-up levels, exact concession wording and a limit named early. JD because it scores a stated requirement, delivered as a Skeptic probe |
| C2 | "You've been a branch supervisor yourself. What changes when you're coaching branch supervisors on escalations?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Quote at scope: the last three years as a branch supervisor; trained new tellers on our escalation script. Answer slot: if you have coached anyone in a supervisor's role on an escalation, say how it went and what part was yours; if not, say so plainly and stay with the tellers. Add what you would want to learn from the supervisors first, as a plan | F5: the JD says supervisors and the evidence says tellers. JD because it tests the stated duty; Skeptic delivery because the question probes the step up |
| C3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Choose honestly and lead with the real one. Plain acknowledgment from the quote: "I've never worked in a contact centre" and "I've never presented to anyone above regional level"; pick which you say first, and say what you would do about it as a plan. Do not volunteer a gap you have not stated, and do not claim the JD's other lines are strengths beyond what your quotes carry | The Skeptic's standard stem; F2 and F7 are the answer, and an honest, ordered answer reads as self-awareness. JD because it scores the JD's own list |
| C4 | "When have you worked with a digital team on something members use?" | JD | [grounded] | Open prompt. Answer slot: if you have, say what it was, what you did and what part was yours; if you have not, say so plainly and say what you would ask a digital team first about how a member gets from self-service to a person. If nothing comes to mind, that is the honest answer | F6: the JD names digital teams and the brief's 40% target makes it live. JD because it is a stated duty |
| C5 | "Sixty seconds: why should we take a chance on you for a role this wide?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Pressure question: pause, restate it, then answer from the three quoted sentences at their scope. Hold your position through two follow-ups by returning to those sentences, never by adding to them. Concede plainly where asked: "What I can speak to directly is the branch's log, the escalation script and the monthly sheet; beyond those I'd learn how a complaint travels before I changed anything." Do not call yourself an end-to-end owner | The role is wide and the evidence is a branch's worth. JD because it scores the fit; Pressure delivery tests composure |
| D1 | "Walk me through how you handled the branch's formal complaints log." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-map on the one sentence: the log, and your handling of it, in your own words. Answer slot: say what went into the log and what happened to an entry after it was recorded; if any deadline or rule applied, say which and what was yours to do under it; if none you know of, or it was not yours, say so plainly and stay with the log | F9: the log is your strongest complaint evidence and the likeliest place to be probed. EXP because it tests what was actually yours |
| D2 | "Tell me about the monthly complaints spreadsheet you built. What did it show, and who used it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | The quote at scope: you built it, it is monthly, your regional manager uses it. Answer slot: say what the sheet showed and what the regional manager used it for, in your own words; if there is anything in it you cannot explain how it was counted, say so plainly. Say which tool it was | F3 and F4: the JD's monthly-reporting and Excel lines press here. EXP because it tests whether the artifact survives scrutiny |
| D3 | "How would you report monthly to senior leaders, and what would you put in front of them?" | CASE | [generic] | No claim about your past. Structure: what decision the reader needs to make; a small number of measures with their definitions stated first (what counts as a complaint, when the clock starts and stops); one-page view with the stuck cases named; what you would ask them to decide. Say the definitions aloud because counts and times both depend on them | F3 and F7 together: the JD's reporting line asked as a live problem. CASE because it asks about the role, not your past |
| E1 | "We want 40% of member service on digital channels by 2028. Where do complaints sit in that, and what would you want to know first?" | CO | [grounded] | No claim about your past. Clarify: what "member service" counts and which complaint types suit self-service. Then the principle: a member who starts digitally and is unhappy must reach a named person who keeps hold of it (the "Own the Fix" value). Say it in Ashgrove's own words | The brief's 40% target applied to your remit; CO because it tests whether you can think at the company's altitude |
| E2 | "We launch a small-business lending product in Q1 2027. What would you want in place in the complaints process before it does?" | CASE | [grounded] | No claim about your past. Clarify what the product is and who the members are; then what you would want ready: how a complaint about it is logged so the monthly report can separate it, who owns it at the start, and the escalation path. Ask before assuming | The brief's launch date gives a live problem; CASE because it is forward-looking and needs structure |

## Reverse questions for Round 2

| # | Question | Why it lands |
|---|---|---|
| R2-1 | "Where does a complaint most often get stuck today, from a member's point of view?" | Shows you start from the member and want the real problem before proposing anything |
| R2-2 | "How do you see the contact centre and the branches sharing ownership of a complaint, and what should I learn about the contact centre first?" | Turns F2 into a plan conversation with the person who owns it |
| R2-3 | "Which senior leaders see the monthly complaints report today, and what do they want from it?" | Addresses F7 early and tells you who your audience is |
| R2-4 | "How are you thinking about the 40% digital target in terms of complaints, and which journeys come first?" | Ties to the brief and to F6 |
| R2-5 | "What would make you say in a year that this hire worked?" | A manager-facing question that gets you the success measure |

---

# Round 3 — panel of two branch managers (60 minutes, 20-minute case, values round)

The recruiter's email says the panel scores against the four values. Several rows below lean on that.

## Persona table

| Persona | How it shows up | Weight and why | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | Scenario probes mapped to the four published values; expects stories | Highest, five questions. The email: "The panel is also the values round — they score against the four values" | Map a story to each value where your sentences carry one; a scaffold where none does; "we" for context, "I" for contribution |
| Case / Strategist | The 20-minute complaint escalation case | Second, four questions. The email: "including a 20-minute case on a complaint escalation" | Clarify, structure, think aloud, use Ashgrove's words |
| Peer Evaluator | Seam questions between branches and you; credit; what you need from them | Third, three questions. The panel are branch managers, and your role would coach the supervisors in their branches; the brief's hub plan also touches branches | Reciprocity framing; propose seam principles; do not comment on the hub plan as a judgement |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick a time with a named member situation, a decision you made, what it cost or whom it inconvenienced, and how it ended. The nearest thing your material carries is the branch's formal complaints log, at its scope; it does not show a decision. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | "Members First, Always" is the first value; the scaffold applies because no quoted sentence carries a decision. VAL because it scores a published value |
| F2 | "Tell me about a time a member needed something explained twice. What did you do?" | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: a specific explanation that did not land the first time, what you changed in the words rather than the process, and what the member did next. The nearest thing your material carries is training new tellers on the escalation script, at its scope; it does not show wording changes. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | "Plain Words" is scored on wording; no quote carries it, so the scaffold applies. VAL because it scores a published value |
| F3 | "Tell me about a time you balanced a number against what a branch or a town needed." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I built the monthly complaints spreadsheet our regional manager uses." | Selection scaffold: pick a time a figure pointed one way and the branch or town's need another, what you did, and how it ended. Your material carries the branch setting and the monthly sheet, each at its scope; neither shows a trade-off. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Answer without commenting on the hub plan as a judgement | "Neighbours, Not Numbers" is the value most tied to the brief's hub plan, which the panel may feel personally. VAL because it scores a published value |
| F4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: a problem you found, who else could have dropped it, what you did to keep hold, and how it ended. The nearest thing your material carries is handling the branch's log, which does not show a problem solved. Answer slot: if you followed a complaint through to the end, say what part was yours; if not, say so plainly and describe how you would keep hold | "Own the Fix" also matches the JD's own-the-process line; the scaffold applies because no quote shows a resolved problem. VAL because it scores a published value |
| F5 | "Which of our four values would you find hardest to live in this role?" | VAL | [grounded] | No claim about your past. Pick one honestly and say why in your own words. If it is "Neighbours, Not Numbers" because reporting counts and branches are people, say so as a tension you would manage, not as a criticism of the hub plan | The Skeptic version of a values question: it tests honest self-assessment against the published four. VAL because it scores the values |
| G1 | "A member has complained twice about the same card charge at their branch and nobody has called back. They say they are moving to an app-only bank. Walk us through what you do." | CASE | [generic] | No claim about your past. Clarify first: is it logged as a complaint, when was it first raised, what does the member want, is anything time-sensitive. Then one named person who keeps hold of it today, a plain-words call or note to the member, finding out why it fell through, and what you record so it shows in the monthly report. State assumptions aloud | The 20-minute case is a complaint escalation; this is the generic shape, and the app-only bank framing is the brief's competitive pressure. CASE because it asks for structure |
| G2 | "The branch supervisor held it for a week before escalating. How do you coach them without it feeling like blame?" | CASE | [generic] | No claim about your past. Separate fact-finding from judgement: ask what they saw and when; agree what a good handover looks like; use plain words; offer to look at the next one together. Hold the standard without making it personal | F5's coaching duty as a live problem. CASE because it asks about the role |
| G3 | "The same issue appears in the contact centre and in three branches in one week. What do you do, and what do you report?" | CASE | [generic] | No claim about your past. Clarify what counts as the same issue; one owner; stop the cause, not only the cases; report it once with definitions stated, volumes and how long members waited. Say that you would learn the contact centre's side before concluding | F2 and F3 together, as a live problem. CASE because it asks for structure |
| G4 | "A member's complaint arrives through the app's self-service form. How should it reach someone who can own it?" | CASE | [grounded] | No claim about your past. Clarify what the form captures and who sees it; the principle is that a member should not have to explain twice ("Plain Words") and that someone keeps hold of it ("Own the Fix"). Name what you would ask the digital team first | F6 and the brief's 40% target. CASE because it asks about a role problem |
| H1 | "My branch is one of the places a complaint can start. Where's the seam between us, and what happens when we disagree?" | CASE | [generic] | No claim about your past. Propose principles rather than pretending to know the seam: the branch owns the member relationship, you own the record and the standard; disagreements are settled by looking at the member's outcome. Show spine and tact | A Peer Evaluator seam stem. CASE because it tests how you would work |
| H2 | "How do you handle credit when a complaint is fixed by work across a branch and the contact centre?" | VAL | [grounded] | Selection scaffold: a time a fix needed more than one team, who did what, and how credit was shared. Your material carries no such story; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it: name the people, say what they did | "Own the Fix" and "Neighbours, Not Numbers" meet here; no quote carries a cross-team story |
| H3 | "What would you need from branch managers in your first month?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | A reciprocity answer. What you would ask: how complaints leave your branch today and what a good handover looks like. What you bring: the monthly reporting you have done, at its scope: you built the monthly complaints spreadsheet your regional manager uses. Say what you would do with it only once you know what they need | A peer question; F3 is the one thing you can offer concretely. JD because it tests how you would partner |

## Values and principles cheat sheet

The four value names and their wording are as you copied them from Ashgrove's values page on 17 November 2026.

| Value | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message. It does not show a decision from the member's side; use the selection scaffold in F1 (the question) and its honest branch |
| Plain Words | If a member needs it explained twice, we wrote it wrong | F5: "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message. It does not show wording; use the scaffold in F2 (the question) and its honest branch |
| Neighbours, Not Numbers | Every branch is part of its town | F8: "6 years in retail banking, the last 3 as a branch supervisor." — your message. It shows the branch setting only; use the scaffold in F3 (the question) and its honest branch |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message. It does not show a problem solved; use the scaffold in F4 (the question) and its honest branch |

## Reverse questions for Round 3

| # | Question | Why it lands |
|---|---|---|
| R3-1 | "What would help you most from a Member Experience Lead in the first few months, and what should I avoid doing?" | Reciprocity: it asks what the branch managers need, not only what you need |
| R3-2 | "When a complaint leaves your branch today, what does a good handover look like from your side?" | Shows you start from their side of the seam; ties to "Own the Fix" |
| R3-3 | "As the branches move towards hubs, which parts of each branch's relationship with its town do you most want kept?" | A curious question that ties to "Neighbours, Not Numbers" and the brief without judging it |
| R3-4 | "Which of the four values do you see tested most often in how a complaint gets handled?" | Shows you take the values as working tools |
| R3-5 | "What would you want me to ask you before I changed anything about how escalations work?" | Signals humility and plain-words working |

---

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Own the member complaints process end to end across branches and the contact centre | B1, C1, C5, G1, G3, H1 |
| Report monthly on complaint volumes and resolution times | D2, D3, G3 |
| Coach branch supervisors on escalations | C2, G2 |
| Work with digital teams on self-service journeys | C4, E1, G4 |
| 4+ years in financial-services customer operations | A1, B2 |
| Experience handling regulated complaints | D1 |
| Confident presenting to senior leaders | B3, C3, D3 |
| Comfortable with Excel reporting | B4, D2 |
| Values: Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix | F1, F2, F3, F4 |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says the branch's log, not the process. Slots stay inside the log |
| Has contact-centre experience | Negative you stated, F2 | "I've never worked in a contact centre." No slot, then a plan said as a plan |
| Has presented to senior leaders | Negative you stated, F7 | "I've never presented to anyone above regional level." No slot, then a plan said as a plan |
| Coached branch supervisors on escalations | Inflated form of F5 | F5's quote at its own scope: "trained new tellers on our escalation script." The slot stays inside the tellers |
| Handled regulated complaints | Inflated form of F9 | F9's quote at its own scope: "I handled the branch's formal complaints log." The slot asks only what went in the log and what happened to an entry |
| Reported complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." The slot asks only what the sheet showed |
| Built Excel reporting | Inflated form of F4 | F4's quote says spreadsheet. The slot asks only which tool it was |

## Sources

Provided documents: the JD; the values text copied from ashgrovecu.org/about/values on 17 November 2026; the recruiter's email about the process; your relay of four points from the July 2026 strategy brief (I have not seen the brief itself); your background paragraph. No dossier was present.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values text is in hand and fixes the cheat sheet and F1 to F4 |
| 2. Ashgrove interview process | skipped | The recruiter's email says three rounds, who runs each and what each holds, which fixes the loop and persona weights |
| 3. Ashgrove strategy and recent news | skipped | The four points you relayed from the July 2026 brief fix the CO and CASE questions (E1, E2, G1, G4) |
| 4. Interviewer name and Ashgrove | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative Member Experience Lead JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The names of the Head of Member Services and the two branch managers, once assigned → an interviewer read, persona weights per panel member, and a reverse question tied to each one's own path
- Your answers to the answer slots on the spreadsheet (what it showed, which tool), the log (what went in it, any deadline or rule that applied), any coaching at supervisor level, and any work with a digital team → F3, F4, F5, F6 and F9 move from `discovery` or `transferability` toward `presentation` or `none`, and the matching questions become story-mapped
- The text of the July 2026 strategy brief → the grounding brief rows are checked against the document, and E1, E2, G1 and G4 can use its own wording
- The recruiter's answer on whether the Round 3 case format is shared in advance → a build section for the case if there is a pre-declared scenario or deliverable
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes): recent organisation context, role-family loop reports and the regulator that governs Ashgrove's complaints → the grounding brief gains public sources, and the F9 probe can be tied to the real regime
- How many hours a day you can prep before the 26th → a prioritised prep triage
- A `tuesday-dossier.md` from an earlier evidence check, if you have one → verified evidence and prohibited-claim constraints in place of the ones built here
