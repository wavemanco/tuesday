# Member Experience Lead — Ashgrove Credit Union: interview prep pack (loop mode)

Candidate: Dara. Prepared 17 November 2026 for three rounds on 26 November 2026.

| Round | Length | Who | Relationship |
|---|---|---|---|
| 1 | 30 minutes | The recruiter | Recruiter screen |
| 2 | 45 minutes | Head of Member Services (named by role only) | Your prospective manager; the recruiter calls it mostly behavioural |
| 3 | 60 minutes | A panel of two branch managers (not yet named) | Panel; includes a 20-minute case on a complaint escalation; also the values round, scored against the four published values |

Interviewers beyond their roles have not been assigned, so there is no interviewer read in this pack.

## How to use this pack

- **Personas describe how a question is asked; types describe what is being scored.** Every question carries both.
- **Type key.** VAL: behaviour that shows a published value, not generic virtue. EXP: whether your own account survives a probe, and what was actually you. JD: a stated requirement of the role, including its gaps. CO: company and strategy knowledge. CASE: a live problem from the role, where structure is scored.
- **Guidance is scaffolding, not a script.** Say it in your own words. Each beat is a clause from a sentence you wrote, kept at that sentence's scope.
- **Answer slots** are instructions for the interview, not questions for me. Where one appears, answer whichever branch is true. "Say so plainly" is a full, honest answer, not a confession.
- **Labels.** `[grounded]` traces to something you or the employer supplied. `[inferred]` is this pack's derivation. `[generic]` is a pattern with no claim about you or Ashgrove.
- **Highest-ROI prep in the pack: C1** (round 2). It names the gap you stated yourself on a part of the role the JD names, and it will arrive in some form from the person who would be your manager.

## Fit snapshot (shared across all three rounds)

Where a quote is given, it is your own sentence from your message. Where the pack says something about your material, it is the pack's own observation, not words for you.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap in the years or the sector as your sentence states them. It is a message line with nothing inspected behind it, so expect a probe on what the supervisor years involved. Say it in the sentence's own terms: six years in retail banking, the last three as a branch supervisor |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | Your material says a formal complaints log you handled, and does not show what rules it sat under. Words: "I handled the branch's formal complaints log." Answer slot: the JD line makes a probe on the log's rules likely. If the log sat under rules or deadlines set outside the credit union, say which and what they required of you; if it did not, or you did not work to them, say so plainly and stay with the log |
| F3 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says one branch's log, not the process across branches, and the words stay at that scope: "I handled the branch's formal complaints log." Answer slot: the JD's across-branches line makes a probe on what happened to a complaint beyond your branch likely. If you followed any beyond it, say what and how, in your own words; if you did not, or it left your hands at the branch, say so plainly and stay with your branch's log |
| F4 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing is added to make the gap feel smaller, and no branch work is offered as a stand-in |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your sentence says you built a monthly complaints spreadsheet your regional manager uses; it does not say what the spreadsheet counted. Words: that sentence, at its scope. Answer slot: the JD names volumes and resolution times, so expect a probe on what yours counted. If it counted either, say how each was counted and who read it; if it counted something else, say so plainly and stay with what it did |
| F6 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says you trained new tellers on your escalation script, not supervisors. Words: "I trained new tellers on our escalation script." Answer slot: if you ever guided a fellow supervisor through an escalation, say what happened and what part was yours; if not, say so plainly and stay with the tellers |
| F7 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing either way. Answer slot: if you have worked with a digital or app team, or on any online feature, say what it was and which part was yours; if not, say so plainly and say which kind of complaint you would want an online route to carry first |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A stated limit. Words: "I haven't presented above regional level." The pack's observation: your material does not show whether regional level counts as senior leaders for this role. Then a plan for preparing a first presentation, never a past |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your sentence says spreadsheet, not Excel. Words: that sentence at its scope. Answer slot: say which tool it was built in, as it was; if it was Excel, say so plainly, and if it was another tool, say which and stay with that |

No requirement in the JD is a gate in the sense of a licence, location, schedule or pay term, and the four-plus-years line is an experience requirement graded in F1, so no row is a hard gate.

## Grounding brief: Ashgrove's 2026 strategy as you described it

The recruiter-sent brief was published July 2026, which is under six months before today. This pack has only the four points you pasted, not the brief itself.

| # | What it says | Source | Provenance | Where it surfaces in this loop |
|---|---|---|---|---|
| S1 | Move 40% of member service to digital channels by 2028 | 2026 strategy brief, July 2026, as pasted | [grounded] | E1, F3, A6 |
| S2 | Consolidate eight branches into five hubs over 2027 | 2026 strategy brief, July 2026, as pasted | [grounded] | G2, F3 |
| S3 | Launch a small-business lending product in Q1 2027 | 2026 strategy brief, July 2026, as pasted | [grounded] | R3 reverse questions only; no bank question rests on it |
| S4 | The main competitive pressure is app-only banks | 2026 strategy brief, July 2026, as pasted | [grounded] | E1, A6 |
| S5 | Member-owned, about 900 staff | The JD's heading | [grounded] | A6 |

**Differentiate; do not recite.** Every prepared candidate has this brief, because Ashgrove published it. Bring one brief item in a sentence to show you read it, then add one position of your own with its concession. E1 and G2 work this out.

## Requirement coverage

| JD requirement | Questions that cover it |
|---|---|
| "Own the member complaints process end to end across branches and the contact centre" | B1, C1, G1, G2 |
| "report monthly on complaint volumes and resolution times" | E2, H2 |
| "coach branch supervisors on escalations" | H1 |
| "work with digital teams on self-service journeys" | E1 |
| "4+ years in financial-services customer operations" | A1 |
| "experience handling regulated complaints" | B2, C3 |
| "confident presenting to senior leaders" | C2, C4, D1 |
| "comfortable with Excel reporting" | E2 |
| The four published values | F1, F2, F3, F4 (D2 is a second Members First story for round 2) |

## Persona table, by round

| Round | Persona | How it shows up | Weight, with the reasoning | Counter-strategy |
|---|---|---|---|---|
| 1 | Conversational (A) | A friendly 30 minutes: your journey, why Ashgrove, pay, notice, location, reason for leaving | Primary. The recruiter-screen prior is conversational plus light skeptic, and the email gives the length and the person but no stated focus | Have a 90-second arc ready; treat every casual question as scored; answer each logistics item with your own fact |
| 1 | Skeptic, light (B) | Knockout checks on the two named gaps and the JD's complaints requirement | Secondary. Prior for a screen; B1 and B2 follow your stated limit and the JD's headline requirement | Short, plain, honest answers; save the full version for round 2 |
| 2 | Skeptic (C) | Quiet, persistent probing of the contact-centre gap, the presenting gap and the log | Top. The email says this person would be your manager, which is the hiring-manager prior of case plus skeptic, and a manager who owns the outcome derisks F4 and F8 first | Rehearse C1 until it is boring: plain acknowledgment, then a plan; hold through follow-ups; concede specifically |
| 2 | Values / Behavioural (D) | Open behavioural prompts, "tell me about a time" | Second. The recruiter calls the round mostly behavioural, which lifts it above the prior | Where your sentences carry a story, use it at its scope; where none does, use the scaffold and its honest branch |
| 2 | Case / Strategist (E) | Two short live problems from the role | Third. The prior says case, but the email places the case in round 3, so only a light touch here | Clarify, then structure, then answer; think aloud; one position of your own per case |
| 3 | Values / Behavioural (F) | One story per published value, scored against the value by name | Top. The email says the panel is the values round and scores against the four values | One story per value, picked in advance; two where you can, so the panel does not hear the same story twice |
| 3 | Case / Strategist (G) | The 20-minute complaint escalation case, then variants | Second. The email gives the case 20 of the 60 minutes | Spend the first two minutes clarifying; name who owns the fix; say it in plain words |
| 3 | Peer Evaluator (H) | Branch managers asking where the seam is and what you need from them | Third. The panel is branch managers, and a role that works across branches meets them as partners; with no names yet, personas are blended | Offer seam principles rather than pretending to know the seam; say what you give them, not only what you need |

## Round 1 mini-pack: recruiter screen (30 minutes)

Weights: Conversational first, light Skeptic second. Eight questions.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Take me through your career so far in about two minutes." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Three beats, each a clause of your own sentences: six years in retail banking, the last three as a branch supervisor; you handled the branch's formal complaints log and trained new tellers on the escalation script; you built the monthly complaints spreadsheet your regional manager uses. End on why this role, which is your A6 answer. Keep it to 90 seconds | F1, F2 and F5 are the rows a screener checks against the JD in the first minutes. EXP because it tests whether the account is yours and consistent; the casual register is still scored |
| A2 | "What are you looking for salary-wise?" | JD | [generic] | A logistics slot. Choose one: say your own figure or range, or ask for the role's band first and answer after. The number is yours; the pack supplies none | A recruiter screen carries a pay question, and the JD as supplied states no figure. JD because it concerns the listed job's terms |
| A3 | "What's your notice period?" | JD | [generic] | A logistics slot. Give your actual notice period in your own words. Say it is flexible only if it truly is | Standard screen logistics. JD because it concerns the listed job's terms |
| A4 | "The role runs across branches and the contact centre. Where can you work from, and how much movement between sites is workable?" | JD | [generic] | A logistics slot. State your real location and travel limits in your own words. The JD as supplied names no site or pattern, so if you do not know where the role is based, ask the recruiter before answering | The JD's across-branches line makes travel and base a likely screen item. JD because it concerns the listed job's terms |
| A5 | "What's making you look at a move now?" | EXP | [generic] | A logistics slot. Give your actual reason, in one sentence you would stand behind if it were repeated to the Head of Member Services. Point toward what this role is, not away from where you are. The pack supplies no reason | Reason for leaving is a standing screen question. EXP because the recruiter checks that the story holds from round to round |
| A6 | "Why Ashgrove, and why a member-owned credit union?" | CO | [grounded] | Pick the one or two published values you genuinely hold, name them as Ashgrove words them, and give your own reason. Show you read the brief with one item, for example moving 40% of member service to digital channels by 2028, and do not recite the list. The reason itself has to be yours | S1, S4 and S5 are what any prepared candidate can cite; the screen scores whether the interest is real. CO because it tests homework depth |
| B1 | "The role covers the contact centre, and you haven't worked in one. How do you see that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | The light version; the full one is C1. Plain acknowledgment first: "I haven't worked in a contact centre." Then a plan, not a past: what you would do first to learn how it handles complaints, chosen from what you would actually do. Do not say your branch work was like it; your sentence does not carry that | F4 is a stated gap on a named part of the role, so a screener checks it early. JD because it scores a stated requirement |
| B2 | "Have you handled regulated complaints before?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Start with your own sentence at its scope: "I handled the branch's formal complaints log." Answer slot: if the log sat under rules or deadlines set outside the credit union, say which and what they required of you; if it did not, or you did not work to them, say so plainly and stay with the log. Do not call the log anything your sentence does not | F2 is where the JD's headline requirement presses, and a screen often treats it as a knockout. JD because it scores a stated requirement |

### Round 1 reverse questions

| # | Question | Provenance | Why it lands |
|---|---|---|---|
| R1.1 | "What is each of the three conversations meant to settle, so I can prepare for the right thing in each?" | [generic] | Shows you are preparing deliberately, and gets the recruiter's own account of the loop |
| R1.2 | "For the panel's case on a complaint escalation: what will I be given, and is there anything I should bring or read first?" | [grounded] | The recruiter's email announces the case, so this asks about its format. It might reveal a deliverable the pack could then build for |
| R1.3 | "When the interviewers are assigned for rounds two and three, could you share their names and roles?" | [grounded] | The email says they are not yet assigned; a name unlocks a tailored read |
| R1.4 | "How is the work split between branches and the contact centre in a typical week for this role?" | [generic] | Learns the real weight of the contact-centre side, which is your stated gap, without making it the topic |
| R1.5 | "What is the timeline after the 26th?" | [generic] | A practical close that signals interest |

## Round 2 mini-pack: Head of Member Services, your prospective manager (45 minutes)

Weights: Skeptic first, Values / Behavioural second, Case third. Eight questions.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "The role runs across branches and the contact centre, and you haven't worked in a contact centre. How would you own complaints there?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | **The highest-ROI rehearsal in this pack.** Open with the plain acknowledgment: "I haven't worked in a contact centre." Then a plan, not a past: the first two things you would do to learn how the contact centre handles complaints, and who you would ask to teach you. Follow-up one, "why would branch skills carry over?": do not claim they do; say you do not yet know where the two differ and that finding out is the first job. Follow-up two, "would the team follow someone who has not done their job?": concede it is a real risk and name your first move, listening before directing. Follow-up three, "what do you need from me?": have an answer; it doubles as a reverse question. Never describe your branch work as contact-centre work | F4 is the stated gap on the role's named scope, and the person who would own the result will ask it. JD because it scores a stated requirement; the guidance holds the limit before it is asked for |
| C2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Name one, honestly. Your material says two things plainly, the contact centre and presenting above regional level. Pick the one you would genuinely call weaker, say it with the plain acknowledgment, then give the plan. Do not pick a strength dressed as a weakness; a second follow-up breaks it | F4 and F8 are the two stated limits, and this is the question that invites you to choose between them. JD because it scores the listed job's requirements |
| C3 | "Walk me through how the branch's formal complaints log worked, and which parts were yours." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on the sentence's two beats: you handled the branch's formal complaints log, and you trained new tellers on your escalation script. Tell both in your own words at that scope. Answer slot: the JD's complaints requirement makes a probe on the rules the log ran under likely. If it sat under rules or deadlines set outside the credit union, say which and what they required of you; if it did not, or it was not you who worked to them, say so plainly and describe the log as you handled it | F2 is the evidence for the JD's headline requirement, and a manager who read the CV closely asks for the specifics. EXP because it tests what was actually yours |
| C4 | "This role presents to senior leaders. What's your experience of that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain acknowledgment: "I haven't presented above regional level." Say it once and do not hedge it. Then a plan, not a past: how you would prepare a first presentation, for example asking what leaders want from the report and rehearsing it with your manager. Choose what you would really do. Do not call a regional-level presentation senior-leader experience; your sentence does not say who was in the room | F8 is a stated limit, and the JD names the skill. JD because it scores a stated requirement |
| D1 | "Tell me about a time you had to give leadership an unwelcome truth." | VAL | [generic] "I built the monthly complaints spreadsheet our regional manager uses." | A selection scaffold. Pick a time a fact or figure leadership did not want to hear needed saying: it needs a named stake, what you said and how it landed, with "I" for your contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: you built the monthly complaints spreadsheet your regional manager uses, at that scope, or say how you would handle it | An unwelcome-truth prompt is the standard behavioural stem, and the role reports complaint figures upward. VAL because it tests behaviour; F5 is the nearest evidence |
| D2 | "Tell me about a time you put a member's interest ahead of an internal target or metric." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | A selection scaffold. Pick a time you chose what suited the member over what suited a target: it needs the decision, who pushed back and what it cost. If none comes to mind, say so plainly, then give the nearest thing your material carries: you handled the branch's formal complaints log, at that scope, or say how you would decide. Keep a second story for F1 in round 3 | Behavioural round, and the theme is the first published value. VAL because it tests behaviour against that value; F2 is the nearest evidence |
| E1 | "We want 40% of member service on digital channels by 2028. Which parts of complaints would you move to self-service first, and which would you keep with a person?" | CASE | [grounded] | Clarify first: what counts as a complaint rather than a query, and where members raise them today. Then objective, segments, approach, metrics (resolution time, repeat contact), risks. **Differentiate:** say the common answer in one sentence, digital for simple matters and people for complex ones, then take a position, for example that self-service should make a complaint easier to raise and to track, not resolve it without a person. Concede you do not know their volumes by channel, so you would test it; name one complaint type you would not move. Answer slot: if you have worked with a digital team, say what and what part was yours; if not, say so plainly and frame this as how you would start with them | S1 and S4 are the strategy's headline and its competitive frame, and the JD asks you to work with digital teams on self-service. F7 is the row this probes. CASE because it asks for live structure |
| E2 | "A first monthly complaints report goes to our senior leaders. What goes on page one?" | CASE | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Think aloud: who reads it and what decision it serves, then the JD's two measures, volumes and resolution times, with trend, hotspots by branch and by contact centre, and one clear ask. Name the definition of resolution time you would defend least, before they do. Answer slot: if your spreadsheet counted volumes or resolution times, say how each was counted and what your regional manager did with it; if it counted something else, say so plainly and stay with what it did. Say which tool it was built in, as it was | F5 and F9 are the reporting rows. CASE because the answer is a live structure; the weakest-assumption move is the metric rule |

### Round 2 reverse questions

| # | Question | Provenance | Why it lands |
|---|---|---|---|
| R2.1 | "What would a good first quarter look like to you, and what would you want to have seen by the end of it?" | [generic] | A manager hears a hire thinking about results, not only about fit |
| R2.2 | "Where do complaints get stuck today between branches and the contact centre?" | [generic] | Asks about the seam in the role's named scope without claiming to know it |
| R2.3 | "Who reads the monthly report, and what decision does it change?" | [grounded] | Ties to the JD's monthly reporting line and shows you think about the reader |
| R2.4 | "How do new leads usually get their first slot with the senior leaders?" | [generic] | Addresses the presenting gap honestly and invites coaching rather than concealing it |
| R2.5 | "Which self-service journeys are the digital teams working on now, and where do complaints touch them?" | [grounded] | Connects the 40% digital target to the digital-teams line in the JD |

## Round 3 mini-pack: two branch managers, values panel (60 minutes)

Weights: Values first, Case second, Peer third. Eight questions. The panel scores against the four published values.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you decided from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | A selection scaffold. Pick a decision where the member's side and another side pulled apart: it needs the decision, what the member needed and what it cost. Use a different story from D2 if you have one. If none comes to mind, say so plainly, then give the nearest thing your material carries, you handled the branch's formal complaints log, at that scope, or say how you would decide | The panel scores this value by name. VAL because it tests behaviour against Members First, Always; F2 is the nearest evidence |
| F2 | "Tell me about a time you made something clearer so a member needed it explained only once." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | A selection scaffold. Pick a time you made a script, a letter or an explanation clearer: it needs what was unclear, what you changed and how you knew it worked. If none comes to mind, say so plainly, then give the nearest thing your material carries, you trained new tellers on your escalation script. Answer slot: if you changed any wording of that script, or how you explained it, say what and why; if you did not, say so plainly and stay with the training you gave. Use short sentences; this value is also scored on how you speak | The panel scores Plain Words by name, so the delivery is part of the answer. VAL because it tests behaviour; F6 is the nearest evidence |
| F3 | "You built a monthly complaints spreadsheet. How do you keep a member, or a town, in view behind the numbers?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say what the spreadsheet is in the sentence's own words. Answer slot: if any figure on it was ever traced back to a member's story or a branch conversation, say what and what part was yours; if it only counted, say so plainly and say what you would pair with the numbers in this role. You may link to the plan for eight branches to become five hubs over 2027, in one sentence, as why the town matters | The value's own name sets up a tension with a spreadsheet of numbers, and the panel are branch managers. VAL because it tests behaviour against Neighbours, Not Numbers; F5 is the row |
| F4 | "Tell me about a time you found a problem and kept hold of it until it was fixed." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | A selection scaffold. Pick a time a problem stayed with you from the moment you found it to its fix: it needs who else could have dropped it, what you did and the outcome. If none comes to mind, say so plainly, then give the nearest thing your material carries, you handled the branch's formal complaints log, at that scope. Answer slot: if any log entry stayed with you until it was closed, say what and what you did; if entries passed to others, say so plainly and describe your part | The panel scores Own the Fix by name, and the role is itself about keeping hold of complaints. VAL because it tests behaviour against that value; F2 and F3 are the nearest evidence |
| G1 | "A member has raised the same complaint with a branch and then with the contact centre, and been given two different answers. She says she will leave and tell her neighbours. Take us through what you do." | CASE | [generic] | The case itself will differ, so rehearse the shape. Spend the first two minutes clarifying: what she has been told, by whom, what is still open, and which deadlines apply. Then objective, a first move today, and who keeps hold of it until it is fixed. Call her in plain words; find why the two answers differed; record it; tell both teams without blame; say how you would measure repeat cases. Because you have not worked in a contact centre, say what you would ask that team rather than assuming. Challenge one premise respectfully | The email announces a 20-minute case on a complaint escalation, and the JD's across-branches line is its subject. CASE because it asks for live structure; `[generic]` because the real scenario is not yet known |
| G2 | "Her branch is one of the eight due to become part of a hub next year. What changes about how you handle it, and about the town?" | CASE | [grounded] | The common answer is to tell members early; say it in a sentence, then take a position: a complaint open at a closing branch should not change hands without the member being told who now owns it. Concede you do not know which branches or when. Name the anti-pick: do not use the move as a reason to close complaints early | S2 is a headline move that lands on this panel's branches. CASE because it asks for live reasoning on the strategy |
| H1 | "You trained new tellers on the escalation script. What would be different about coaching one of our supervisors on an escalation?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say what the sentence says: you trained new tellers on your escalation script. Then a principle, not a past: a supervisor already has their own judgment, so you would begin by asking how they read the case. Answer slot: if you ever guided a fellow supervisor through an escalation, say what happened and what part was yours; if not, say so plainly and stay with the tellers. Say what you would need from the branch manager | F6 is the row the JD's coaching line presses on, and branch managers are the supervisors' managers. JD because it scores a stated requirement; the reciprocity framing is the peer counter-strategy |
| H2 | "Your monthly report will show which branches resolve slowest. How do you handle that with us before senior leaders see it?" | JD | [grounded] | Offer principles rather than a promise to know the seam: the branch manager hears it first, with the data and the story behind it, you agree a next step together, and improvement is credited to the branch. Hold the line that the numbers are reported honestly; concede that the timing will sometimes be tight and say what you would do then. Say what you give them: early notice | F5 is the reporting row, and branch managers are the ones whose branches appear in it. JD because it scores the monthly reporting line; the peer persona makes it collegial |

### Round 3 reverse questions

| # | Question | Provenance | Why it lands |
|---|---|---|---|
| R3.1 | "What could a new Member Experience Lead do in their first month that would genuinely help your branch?" | [generic] | The reciprocity question: it asks what you can give the people who work beside the role |
| R3.2 | "What do you most want the lead to know about how your branch looks after an unhappy member?" | [generic] | Shows you want the branch's view before shaping a process |
| R3.3 | "As eight branches become five hubs over 2027, what do you most want protected in how an unhappy member is looked after in your town?" | [grounded] | Ties the brief's hub plan to the Neighbours, Not Numbers value and to the panel's own branches |
| R3.4 | "How would you want to hear about complaint trends in your branch before senior leaders do?" | [generic] | Shows you will treat branch managers as partners, not as data sources |
| R3.5 | "How do you each see Neighbours, Not Numbers showing up in how complaints are reported upward?" | [grounded] | Invites the panel to talk about a value they score, and shows you read it as a working principle |

## Values cheat sheet (round 3 scores against these)

The four published values are as you copied them from ashgrovecu.org/about/values on 17 November 2026. None of your sentences carries a full values story, so each row is a selection scaffold with its honest branch, anchored to the nearest sentence you did write.

| Value (as published) | Working meaning | Your mapped story | Questions |
|---|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Selection scaffold: pick a decision where the member's side and another pulled apart. If none comes to mind, say so plainly, then offer the nearest thing your material carries, F2's "I handled the branch's formal complaints log and trained new tellers on our escalation script." | D2, F1 |
| Plain Words | If a member needs it explained twice, the wording failed | Selection scaffold: pick a time you made something clearer. If none comes to mind, say so plainly, then offer the nearest thing your material carries, F6's "I handled the branch's formal complaints log and trained new tellers on our escalation script." | F2 |
| Neighbours, Not Numbers | Every branch is part of its town | The numbers half is F5's "I built the monthly complaints spreadsheet our regional manager uses." The neighbours half is an answer slot in F3 | F3, G2 |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Selection scaffold: pick a time a problem stayed with you to its fix. If none comes to mind, say so plainly, then offer the nearest thing your material carries, F3's "I handled the branch's formal complaints log and trained new tellers on our escalation script." | F4, G1 |

## Prohibited claims

What this pack will not coach, because your material does not carry it, and the honest form of each.

| Not coached | Basis | Honest form |
|---|---|---|
| Handled regulated complaints | Inflated form of F2 | F2's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation, not words for you: your material says a formal log, not what rules it sat under. B2 and C3 keep their slots inside the log |
| Owned the complaints process across branches | Inflated form of F3 | F3's quote at its own scope. The material says one branch's log, not the process across branches |
| Has worked in, or alongside, a contact centre | Negative you stated, F4 | The plain acknowledgment: "I haven't worked in a contact centre." No slot, and no branch work offered as a stand-in |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment: "I haven't presented above regional level." The pack does not say whether regional counts as senior here |
| Coached branch supervisors on escalations | Inflated form of F6 | F6's quote at its own scope: "I trained new tellers on our escalation script." The H1 slot stays inside the tellers and a fellow supervisor |
| Reported complaint volumes and resolution times monthly | Inflated form of F5 | F5's quote at its own scope: you built the spreadsheet your regional manager uses. The material does not say what it counted |

## Sources

Provided documents: the job description you pasted; the values text you copied from ashgrovecu.org/about/values on 17 November 2026; the recruiter's email on the three rounds; the four points of the July 2026 strategy brief; your background message. The values page you named is where your pasted text came from, so it was not fetched. No dossier was present.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The four values are pasted in full, which fixes the values cheat sheet and the VAL questions |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | The recruiter's email gives the three rounds, their lengths, who runs each and the panel's scoring, which fixes the loop and persona weights |
| 3. `Ashgrove Credit Union strategy` | skipped | The four brief points, under six months old, fix the grounding brief and the CO and CASE questions |
| 4. `interviewer name Ashgrove Credit Union` | n/a | No interviewer name exists yet, so there is no query to form; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Interviewer names and titles, once assigned → a reading of each interviewer's public career, persona weights read from that footprint, and a reverse question tied to their path
- The case's format and materials from the recruiter → G1 becomes grounded in the real format, and a build section is added if a deliverable is announced
- Your answers to the slots in F2, F3, F5, F6, F7 and F9, said in your own words → those rows move from discovery to your own evidence and the banks that draw on them regenerate; an answer said inside a drill stays a lead until you say it outside one
- The anonymised complaints-log layout or the monthly spreadsheet template (without member data) → raises F2 and F5 from medium toward high, since a complaints log and a reporting pack are the inspectable artifacts in this field
- The full text of the July 2026 strategy brief → CO and CASE questions rest on its wording instead of four points
- How much prep time you have before the 26th → a prioritised prep triage tied to question IDs
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → recent organisation context and reports on loops for this role family; say "go deeper" and it runs
- A `tuesday-dossier.md` → verified evidence and constraints carried in from an earlier evaluation; the pack does not need one
