# Interview prep pack: Operations Manager, Atlas Freight

- **Role:** Operations Manager, Atlas Freight
- **Interviewer and relationship:** not known. This pack is built as a full-loop pack with flat persona weights.
- **Version:** first pass

## How to use this pack

Personas describe how a question arrives. Types describe what it is scored on. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it is scoring |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your background claims survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company and can think at its altitude |
| CASE | Structure and reasoning on a live problem from the role |

Answer slots in the guidance are instructions for the interview, not questions for this conversation. Each one has two branches, and the second branch ("say so plainly") is always an acceptable answer.

The highest-ROI rehearsal in this pack is **A1**. Its objection is the likeliest one for this role and this background, and a calm, rehearsed answer changes the interview.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "currently a senior shift manager over 3 supervisors" — your message, "7 years in warehouse and distribution ops" — your message | medium | [grounded] | transferability | Your material says a shift, a team of 3 supervisors, and warehouse and distribution ops. It does not say terminals or more than one site, and the words stay at "I'm currently a senior shift manager over 3 supervisors." Answer slot: the JD's four-sites line makes a probe on scope likely. If any of your work spanned more than one site, or took place in a terminal, say which and what was yours; if not, say so plainly and stay with the shift and the 3 supervisors |
| F2 | "drive on-time performance" — JD | "ran the site's peak-season surge plan two years running" — your message | low | [inferred] | discovery | The quote shows a surge plan you ran; it does not show whether on-time performance was measured. Answer slot: if on-time or any service measure was tracked through those seasons, say what was counted and what was yours; if none was, say so plainly and stay with "I ran the site's peak-season surge plan two years running" |
| F3 | "cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | low | [inferred] | discovery | The quote is a quality measure and does not show cost. Answer slot: if any of it was counted in cost terms, say what was counted and how; if none was, say so plainly and say what you would look at first for cost-per-shipment |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | The words stay at "I'm currently a senior shift manager over 3 supervisors." The pack's observation is that the JD's team is larger than the one in your quote. Answer slot: if you have led more people than those 3 supervisors in any role, say who and for how long; if not, say so plainly and stay with the 3 |
| F5 | "build reporting in Excel/Power BI" — JD | "solid Excel" — your message | low | [inferred] | discovery | "Solid Excel" touches the requirement without showing that you built reports. Answer slot: if you built reports in Excel, say what they showed and who used them; if not, say so plainly and stay with "solid Excel" |
| F6 | "build reporting in Excel/Power BI" — JD | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used Power BI." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F7 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message, "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | The quotes show seven years in the field and a people-leading role now; they do not show how many of the seven years involved leading people. Answer slot: if some of those years were spent leading people, say which role and for how long; if the leading years are fewer, say so plainly and stay with the seven years in ops |
| F8 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap, but a certification line with nothing inspected behind it (the certificate would be that), so expect a probe. Lead with it in the quote's own terms: you are green belt certified |

## Persona table

Relationship and round are unknown, and no source on Atlas Freight's loop could be read (see Sources), so the pack falls back to the generic archetype (screen, hiring manager, panel) with flat weights across personas. Depth differs only where the fit snapshot is thin.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Quiet probing of scale and the Power BI gap | Four questions. F1, F4 and F6 are the widest gaps in the snapshot | Rehearse A1 until it is boring. Say your quotes at their own scope, then name the step up yourself |
| Case/Strategist (B) | Live problems on on-time performance, surge and cost | Four questions. F2 and F3 have no showing evidence, so a live problem is where they get tested | Clarify, objective, segment, approach, metrics, risks. Think aloud. Challenge one premise politely |
| Data-Driven Prober (C) | Line-by-line on the 40% and on Excel reporting | Four questions. The mis-pick figure is the one number in your material | Know what you can and cannot say about how it was counted. Say plainly if you do not know |
| Pressure (D) | Time-boxed, interrupting versions of A and C | Three questions. Same gaps, harder delivery | Pause, restate, hold through two follow-ups, then concede one specific thing |
| Conversational (E) | Friendly biography and Lean chat | Three questions. Casual questions on the JD's plus-skill are still scored | A 90-second arc built only from your quotes |
| Peer Evaluator (P) | Site-to-site seam and credit-sharing | Two questions. Four sites make this plausible if a site lead sits on the panel; relationship unknown | Reciprocity framing; propose principles, not a seam you have not seen |
| Values/Behavioral (V) | Behavioral stories on unpopular truths and customer-first choices | Two questions. No loop source or published values were read, so it is held low and the questions are selection scaffolds | Pick stories you can stand behind; say so plainly if none comes to mind |

## Question banks

Requirement coverage, checked against the JD's own list:

| JD requirement | Questions |
|---|---|
| "Own daily terminal operations across 4 sites" | A1, A3, B1, P1 |
| "drive on-time performance" | B1, B2, C4 |
| "cost-per-shipment down" | B3 |
| "lead a team of 12 supervisors" | A1, D1, E3, P1 |
| "build reporting in Excel/Power BI" | A2, C3, D3 |
| "5+ years operations leadership required" | A4, E1 |
| "Lean/Six Sigma a plus" | E2 |

Defend-the-number coverage for the one headline metric: C1, C2, D2.

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You're a shift manager over three supervisors. This role leads twelve across four sites. What's the biggest jump for you?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI rehearsal in this pack. Hold at the quote: "I'm currently a senior shift manager over 3 supervisors." Name the step up yourself, in the JD's terms, before they press: twelve supervisors, four sites. Answer slot: if any of your work has spanned more than one site, or more than those 3 supervisors, say which and what was yours; if not, say so plainly and say, as a plan, how you would get to know the other sites and supervisors first. Hold through two follow-ups by returning to the quote, never by adding to it | F1 and F4 are the widest scope gaps, so this objection arrives in some form. JD because it scores the stated requirement; the hold-then-concede shape is Skeptic delivery |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never used Power BI", "solid Excel" | If Power BI is your honest answer, say it plainly: "I've never used Power BI." Then give a plan, as a plan: how you would learn it and what you would build first, in your own words, starting from "solid Excel". If scale is your honest answer instead, use A1's shape. Pick the weakness you can stand behind under a follow-up | F6 is the one gap you have stated yourself, which makes it the safest answer to rehearse. JD because the question scores self-assessment against the listed requirements |
| A3 | "This is terminal operations, not a warehouse. What carries over and what doesn't?" | JD | [grounded] "7 years in warehouse and distribution ops" | Open with the quote: seven years in warehouse and distribution ops. Answer slot: if any of your work took place in a terminal setting, say which part and what was yours; if none did, say so plainly and stay with warehouse and distribution. Then say, as a plan, what you would learn first about terminals | F1 does not show terminals. JD because it tests the role's core setting; the Skeptic delivery makes the gap the question |
| A4 | "The posting asks for five-plus years of operations leadership. How does your background meet that?" | JD | [grounded] "7 years in warehouse and distribution ops", "currently a senior shift manager over 3 supervisors" | Say both quotes at their own scope: seven years in warehouse and distribution ops, and a current role over 3 supervisors. Answer slot: if some of those seven years were spent leading people, say which role and for how long; if the leading years are fewer, say so plainly and stay with the seven years in ops. Do not merge the two numbers into one | F7 shows years in the field, not years leading. JD because it tests a stated requirement; the answer is a precise split rather than a defense |

### B. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one of your four sites has slipped over three weeks. What do you need to know first, and how would you diagnose it?" | CASE | [generic] | Clarify first: which on-time measure, over what period, which part of the operation. Then state the objective, split the problem into parts, say your approach and the metrics you would look at, and name the risks. Think aloud. Challenge one premise politely. The question needs no claim about your past, so the guidance makes none | F2 raises on-time performance. CASE because it is a live problem on a JD line; [generic] because it is a pattern for the problem, not a fact about Atlas |
| B2 | "Peak is six weeks out and volume is forecast well above last year across all four sites. Walk me through your surge plan." | CASE | [grounded] "ran the site's peak-season surge plan two years running" | You can open with what the quote carries: you ran the site's peak-season surge plan, two years running. Then work the case from structure: objective, what to confirm, approach, measures, risks. Answer slot: if there is a specific from those two seasons that bears on this plan, say it in your own words; if there is not, say so and work the case from structure | F2 is the closest evidence to this scenario. CASE with EXP delivery, because the interviewer will test whether the structure matches the claim |
| B3 | "Cost-per-shipment is up eight percent quarter on quarter. Where do you look?" | CASE | [generic] | Clarify what is in the numerator and the denominator and over what period. Split the figure into its parts, find which part moved, and name the assumption you would defend least before they do. Close with the first two things you would check. No claim about your past is needed | F3 has no showing evidence, so this is where the requirement gets tested. CASE because it is a live diagnosis; metric framing follows the prober rule |
| B4 | "What do you know about Atlas Freight, and what would you look at first in the role?" | CO | [generic] | The pack could not research Atlas (see Sources), so the facts are yours to bring. Selection scaffold: pick two facts about the company from its own site or recent news, and tie each to a line in the JD, such as regional logistics, 800 employees or four sites. If you cannot find two, say what you did look for and what you would ask | Company knowledge is a differentiator question, and no source was read; [generic] states that honestly |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say what the quote carries: mis-pick rate, 40%, the pick-path redesign. Answer slot: say what the 40% was measured against and over what period, and whether it is a relative figure, in your own words; name the assumption behind it you would defend least before they ask; if you do not know how it was counted, say so plainly | The mis-pick figure is the headline metric in the material (F3). EXP because it tests whether the number survives scrutiny |
| C2 | "What did the pick-path redesign involve, and who else was part of it?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Describe the redesign in your own words, at the scale you actually worked at. Answer slot: if others contributed, say which parts were theirs and which were yours; if it was yours alone, say so plainly | Attribution is where a prober goes after a figure (F3). EXP because it scores what was actually yours |
| C3 | "What do you build in Excel for operations reporting?" | JD | [grounded] "solid Excel" | Say "solid Excel." Answer slot: if you built reports in Excel, say what they showed and who used them; if you did not, or the work was mostly using others' reports, say so plainly and stay with "solid Excel" | F5 touches the requirement without showing it. JD because the JD names reporting; the second branch lets the premise be false |
| C4 | "What measures did you use to know the surge plan was working?" | JD | [grounded] "ran the site's peak-season surge plan two years running" | Open with the fact: you ran the site's peak-season surge plan, two years running. Answer slot: if you tracked on-time or any service measure through the surge, say what it was, how it was counted and what was yours; if no such measure was tracked, or it was not yours, say so plainly and return to that fact | F2 is thin, and the JD's on-time line makes this probe likely. JD because it maps to a stated requirement |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a candidate who has already run several sites?" | JD | [grounded] "7 years in warehouse and distribution ops", "currently a senior shift manager over 3 supervisors", "green belt certified", "cut mis-pick rate 40% by redesigning the pick path" | Pause, restate the question, then hold on those four facts, in your own words, without adding to them. Concede one thing specifically and early: the scale here is larger than the 3 supervisors you lead now. Hold through two follow-ups by returning to the four facts; concede nothing you have not said | F1 and F4 are the gap this question is built on. JD because it scores fit against the role; Pressure delivery tests composure |
| D2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold at the quote's attribution, in your own words. Answer slot: if others worked on any part, say which part and whose; if it was all yours, say so; if you do not know what share was yours, say so plainly. Concede specifically and keep the core claim | F3's metric is the likeliest attribution probe. EXP because it scores precise attribution |
| D3 | "You've never used Power BI, and we need reporting built. Why isn't that a problem?" | JD | [grounded] "never used Power BI", "solid Excel" | Start with the plain acknowledgment: "I've never used Power BI." Hold on "solid Excel" and a plan, in your own words, for how you would get to productive. Give your own realistic estimate of how long it would take rather than a number from this pack. Hold through two follow-ups; concede that it is a real gap | F6 is the stated gap, and F5 is what the hold rests on. JD because the JD names the tool |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops", "currently a senior shift manager over 3 supervisors" | A 90-second arc: seven years in warehouse and distribution ops, now a senior shift manager over 3 supervisors. Fill the middle in your own words with only what happened. Close with your own reason for this role | F7 is the spine of the story. EXP because it is a biography question; the casual register is still scored |
| E2 | "What are you actually doing with Lean and Six Sigma these days?" | JD | [grounded] "green belt certified" | Say you are green belt certified. Answer slot: if you apply it in your current work, say where and what was yours; if the certification is not something you use day to day, say so plainly and stay with the certification | F8 is the JD's plus-skill, and a casual question on it is still scored. JD because it maps to a stated plus |
| E3 | "Tell me about your team — how do you work with your three supervisors?" | EXP | [grounded] "currently a senior shift manager over 3 supervisors" | Describe the team and how you work with them in your own words, at the scale of the quote: a senior shift manager over 3 supervisors. Add only what is true; this is where the step to twelve supervisors gets tested | F4 is the step up the JD asks for. EXP because it tests what you actually do |

### P. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Two of the four sites want the same extra labor on the same day. How do you decide, and what happens if the other site lead disagrees?" | CASE | [generic] | Propose principles, not a seam you have not seen: what you would want to know about each site's need, how you would decide, and how you would take it back to the other lead. Offer what you would give the other site in return. No claim about your past is needed | F1's four-sites line makes this plausible. CASE with peer delivery; the question presupposes nothing about you |
| P2 | "How do you handle credit when a result spans teams?" | VAL | [generic] | Selection scaffold: pick a result where other people's work mattered, name who did what, and say what was yours. If no such result comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Credit-sharing is a standard peer probe; [generic] because the pack has no quote that carries a cross-team story |

### V. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time that has a named stake, a moment you did not fold, and a relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A behavioral stem for any loop that includes one. No published values were read, so it is [generic] |
| V2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where the customer's need and the internal number pulled apart, say what you chose and why. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A customer-first stem; relevant to a role that carries on-time performance. [generic] because no values page was read |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What does on-time performance look like today across the four sites, and which site is furthest from where you want it?" | It shows you read the JD's priority and gets you the baseline you would be judged against |
| 2 | "How is cost-per-shipment calculated here, and who owns each part of it?" | It asks for the denominator, the question a prober would ask of you |
| 3 | "What do the twelve supervisors need most from their next manager?" | It takes the team-size step seriously and lets them describe the real job |
| 4 | "What reporting exists today in Excel or Power BI, and what would you want built first?" | It surfaces the Power BI expectation early, from the honest position of someone who has said so |
| 5 | "What would make you say, six months in, that this hire worked?" | It makes the scoring criteria explicit and shows you think in outcomes |
| 6 | "What could a new person do in their first month that would genuinely help your team?" | A reciprocity question; it works with a peer or a manager and shifts the conversation to what you bring |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owns or has run terminal operations across several sites | Inflated form of F1 | F1's quote at its own scope: "currently a senior shift manager over 3 supervisors". The limit is the pack's observation: the material says a shift and 3 supervisors, not terminals or several sites. A1's slot stays inside what was yours |
| Has led a team of 12 supervisors | Inflated form of F4 | The quote "currently a senior shift manager over 3 supervisors" at its own scope. A1 and E3's slots stay inside that team |
| Drove on-time performance | Inflated form of F2 | "ran the site's peak-season surge plan two years running" at its own scope. The material says the plan, not on-time results; C4's slot stays inside the plan |
| Reduced cost-per-shipment | Inflated form of F3 | "cut mis-pick rate 40% by redesigning the pick path" at its own scope. The material says a quality measure, not cost |
| Has Power BI experience | Negative the candidate stated, F6 | The plain acknowledgment: "I've never used Power BI." No slot |
| Has five-plus years of leading operations | Inflated form of F7 | "7 years in warehouse and distribution ops" at its own scope. The material says years in ops, not years leading; A4's slot stays inside the seven years |
| Used Lean or Six Sigma to cut the mis-pick rate | Inflated form of F3 and F8 combined | The two quotes kept separate: "cut mis-pick rate 40% by redesigning the pick path" and "green belt certified" |

## Sources

Provided documents: the job description text and the background note, both in your message.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

Queries sent, all refused by the host (no permission to search):

- `Atlas Freight regional logistics company values` — refused
- `Atlas Freight interview process operations manager` — refused
- `Atlas Freight regional logistics strategy news` — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Would have fed VAL questions with the company's published value names; V1 and V2 are [generic] instead, and no values cheat sheet was built |
| 2. `Atlas Freight interview process operations manager` | unavailable | Would have fixed the loop structure and persona weights; the pack uses the generic archetype with flat weights |
| 3. `Atlas Freight strategy` / recent news | unavailable | Would have grounded B4 and the CASE bank in current priorities; B4 is [generic] and tells you to bring two facts yourself |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Operations Manager` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Who the interview is with (future manager, peer, recruiter, panel) → persona weights re-cut and the banks re-ordered, instead of flat
- The interviewer's name → an interviewer read and a reverse question tied to their own path
- The recruiter's prep email (focus areas, any presentation or take-home) → coverage of anything pre-declared
- Search permission, so the three refused lookups can run → real values, loop structure and strategy for B4, V1, V2 and the persona weights; a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) is available on request
- Your own answers to the slots → F1 (any work beyond one site or in a terminal), F2 and F3 (any on-time or cost measure), F4 (any larger team), F5 (any Excel reports), F7 (how many years were leading people); each upgrades the matching rows and banks from discovery to grounded guidance
- The green belt certificate → F8 from medium to high confidence
- A `tuesday-dossier.md` from an earlier evaluation → verified evidence, the objection to rehearse deepest, and per-gap strategy constraints, in place of what this pack infers
