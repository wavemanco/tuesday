# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations (assumed to be the hiring manager running the Outage Hour; unconfirmed)
**Round:** Friday, 60 minutes. Saltmarsh's careers page describes one 60-minute interview with the hiring manager, the "Outage Hour": a live-incident tabletop on a simulated outage during a live event, then a values conversation. No take-home.

## How to use this pack

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows Saltmarsh's published values |
| EXP | Whether your background claims survive follow-ups, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company's current strategy |
| CASE | A live problem from the role, scored on structure and reasoning |

"Answer slot" lines are instructions for the interview: answer from your own experience, or say plainly it was not yours.

## Prep triage

Three days to Friday. In order:

1. Say C1 (no in-app-purchase experience, season-pass titles) out loud until it is boring. It is the highest-ROI prep in this pack.
2. Run A1 to A3 aloud, twice, as if in the Outage Hour. Think aloud, clarify first.
3. Fill the answer slots in C2, D2 and B3 from your own memory, in writing.
4. Read B1 to B3 and the values cheat sheet; pick your stories.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your sentence carries a weekly content-drop calendar for one title, and the words stay there: "I ran the weekly content-drop calendar for our main title for the last two years." Your material does not show time-limited events or a second title. Answer slot: the JD's two-titles line makes a probe likely. If any of your drops were time-limited events, or you ran any part of a second title's schedule, say which and what part was yours, in your own words; if not, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team" — your message | low | [inferred] | discovery | Coordinating and leading are different things, and the JD asks for coordination; that is the pack's observation. Your words: "Never led a team." Answer slot: say which of the design, art, engineering and community groups you worked with on updates and how, in your own words; if some were not part of your work, or someone else coordinated them, say so plainly and stay with what you did |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | The quote stands at its own scope: presenting. Your material says presented, not reviewed after events or owned the KPIs. Answer slot: if you took part in a review after drops, or chose which numbers were reported, say which and what was yours; if no such review was held, or the numbers were chosen by others, say so plainly and stay with presenting them |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | none | No gap in terms, but a line with nothing inspected behind it, so expect a probe on how much was yours. Lead in the quote's own terms: you wrote it, and QA still uses it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio", "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [inferred] | discovery | A years requirement is graded on evidence, not treated as a gate. Neither sentence says the title was a live service; the pack infers it from weekly drops. Your words stay as quoted. Answer slot: if the puzzle title ran as a live service with ongoing updates, say how, in your own words; if it did not, say so plainly and stay with the calendar you ran |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | The strongest row. Lead with the quote's terms: ran, weekly, main title, two years. A line with nothing inspected behind it, so expect a probe |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | The quote reaches the requirement. Say it as written; expect a follow-up on how the numbers were counted (D1) |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | The checklist is a written artifact in use. Name it in the quote's words and nothing more; the checklist itself, if you can show it, is the inspectable proof |
| F9 | Not a JD line: the Project Larkspur announcement, as search returned it, moves two titles to a season-pass model from February 2027 | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I have never worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past |

## Reading the interviewer

| Public fact | Source | Provenance | What it means for you |
|---|---|---|---|
| Head of Live Operations at Saltmarsh | Your message, and the talk page | [grounded] | He owns the function you would join |
| Previously a QA lead at a console studio | GDC 2026 talk page, as search returned it | [grounded] | Expect QA-literate follow-ups on release checklists. The vocabulary overlap is F4: "Wrote the release checklist our QA team still uses." This is shared vocabulary, not a shared career jump, and none is offered |
| GDC 2026 talk "Patch Notes Are a Promise": a live team is judged by how often its patch notes describe what actually shipped | Talk page snippet | [grounded] | Player-facing accuracy is his stated theme. It sits beside the value "Ship the Patch Not the Promise"; the pairing is the pack's reading, not his statement. Use it in A2 and B2 |

Public footprint only; nothing about his personal life or temperament is inferred.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (A) | The Outage Hour tabletop: a simulated outage during a live event | Highest. The hiring-manager prior leans Case, and the careers page names the tabletop as half the session | Clarify, then objective, who is in the room, decision points, update cadence, review. Think aloud; challenge one premise |
| Values/Behavioral (B) | The second half of the hour, against Saltmarsh's three published values | High. The careers page names a values conversation in the loop | Map a story to each value where your own words carry one; otherwise pick a real instance or say none comes to mind |
| Skeptic (C) | Quiet probing of F2, F9 and the one-title scope | Medium-high. The hiring-manager prior includes Skeptic, and you have stated two gaps | Rehearse the plain acknowledgment and a ramp plan until it is boring |
| Data-Driven Prober (D) | Retention numbers and the post-event review | Medium-low. The JD names retention metrics; nothing public says he is data-driven | Say how the numbers were counted, or plainly that you do not know |
| Pressure (E) | Time-boxed challenges inside the tabletop | Low. The tabletop is time-pressured, but no source says he interrupts | Pause, restate, hold through two follow-ups, concede specifically |
| Conversational (F) | The opening biography, the closing chat | Low. It is always present at the edges and still scored | A 90-second arc built from your own sentences |
| Peer Evaluator | Not included | The loop source describes one session with the hiring manager, so a peer seam is unlikely. If Tobias is not the hiring manager, this changes | n/a |

## Question banks

### A. Case/Strategist (weight 1)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It's day three of a live event. Reward grants are failing for some players, support tickets are climbing, and engineering has a suspected cause but no confirmed fix. Where do you start?" | CASE | [grounded] | A practice scenario, not Saltmarsh's. Clarify first: who is affected, since when, what is confirmed, when the event ends. State the objective: protect players, keep the event trustworthy ("Players Before Plans"). Name who is in the room. Lay out options with the decision you would need for each, how often you would update players, and what you would review afterward. Think aloud and challenge one premise | The careers page names a simulated-outage tabletop. CASE because it scores structure on a problem from the role |
| A2 | "Draft the first player notice for that incident. What does it say?" | CASE | [grounded] | Say what is confirmed, what is not yet known, and when the next update comes. No promised fix date. Echo the published value: "we announce what is built, not what is hoped." Keep it to a few lines | Tests F8 live. His GDC talk is about patch notes matching what shipped; JD content, CASE delivery |
| A3 | "Design wants to extend the event to make up for the outage, art says the next event's assets will slip, and QA says the checklist doesn't cover an out-of-cycle fix. You have one hour. What do you do?" | CASE | [grounded] | Ask who decides. Give each group's trade-off in one line. Name what the checklist would skip for an urgent fix and who accepts that risk, rather than skipping silently. Say what you would add to the checklist afterward ("Leave the Build Greener") | The JD's coordination line (F2) and checklist line (F4), asked as a decision |
| A4 | "From February 2027 two titles share one events calendar under a single live-ops group. What do you want to know first before merging two event calendars, and what would you refuse to compromise?" | CO | [grounded] | Say you know this from the announcement only. Clarify the objective, what is shared between the two player bases, how collisions and season boundaries are handled, and who owns each event once per-title teams retire. Name the metrics you would watch before and after. Do not assert how Saltmarsh does it today | The one CO question from research, labeled CO with CASE delivery. Source is the announcement as returned by search, not fetched |
| A5 | "The retention number for the last event came back lower than the event before it. Diagnose it." | CASE | [generic] | Clarify the definition: which retention, which cohort, which window. Check comparability first: event length, type, rewards, overlapping releases or incidents. Segment new against returning players. Check measurement before behavior, and name the assumption you would defend least | F7's requirement as a live problem; it asks about no past |

### B. Values/Behavioral (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed. What won?" | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Selection scaffold: pick a time a scheduled drop and what players needed pulled apart. It needs a named stake, the moment you chose, and where it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the calendar you ran, or how you would handle it | Tests "Players Before Plans". F6 carries a calendar but no conflict, so this is a scaffold, not a story |
| B2 | "Tell me about a time you reported what had actually happened when the plan said otherwise." | VAL | [grounded] "Presented the monthly retention numbers to the studio head" | Selection scaffold: choose a moment the real numbers and the plan differed, with someone senior listening, and say how it landed. If none comes to mind, say so plainly, then give the nearest thing: you presented the retention numbers monthly, in your words, or say how you would handle it | Tests "Ship the Patch Not the Promise". F3 shows presenting, not a hard-truth moment, so nothing is supplied |
| B3 | "Tell me about a time you left a process or a checklist better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Story-mapped on F4: you wrote it, and QA still uses it; tell those beats in your own words. Answer slot: the value's wording ("every release leaves the codebase and the checklist better than it found them") makes a probe on what it changed likely. If it replaced something or changed after a release, say what, in your own words; if it was written from nothing, or the change was not yours, say so plainly and stay with the sentence | Tests "Leave the Build Greener". Your strongest story, and the likeliest place to be asked how much was yours |
| B4 | "Which of our three values is closest to how you already work, and which would stretch you?" | VAL | [grounded] | Pick honestly. Name a real instance for the close one, and for the stretch one say plainly what you have not done and how you would build it. If no instance comes to mind for either, say so, then speak to how you would handle it | Covers all three values at once and invites the F9 conversation on your terms |

### C. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You haven't worked on a game with in-app purchases, and our titles are moving to a season pass. How do you get up to speed?" | JD | [grounded] "never worked on a game with in-app purchases" | The highest-ROI rehearsal. Open with the plain acknowledgment: "I have never worked on a game with in-app purchases." Then a plan, said as a plan: what you would learn first about how events and the season pass interact, who you would ask, and which numbers you would want to see. Follow-up one: what you would not touch until you understood it. Follow-up two: what you do if an event choice costs revenue. Hold the acknowledgment and the plan; concede what you do not yet know, specifically | The objection most likely aimed at you, from F9. JD because the role runs events for monetized mobile titles; the season-pass fact is from research |
| C2 | "The role coordinates design, art, engineering and community on every update. You've never led a team. Where does that bite?" | JD | [grounded] "Never led a team", "I ran the weekly content-drop calendar for our main title for the last two years" | Plain acknowledgment: "I have never led a team." The JD asks for coordination, which is not leadership; say so without arguing. Answer slot: say which of the four groups you worked with on updates and how, in your own words; if some were not part of your work, or someone else coordinated them, say so plainly and stay with the calendar you ran | F2 is where this objection is sharpest. Hold through two follow-ups by returning to what you did |
| C3 | "This role covers two titles, and you've run the calendar for one. Why would that carry over?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Keep the scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if you ran any part of a second title's schedule, or worked alongside someone who did, say how, in your own words; if not, say so plainly and stay with the calendar you ran. Say what you would ask first about running two | F1's scope gap, asked directly. Do not claim a second title |

### D. Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the monthly retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Start with what you presented and to whom, in the quote's words. Answer slot: the JD's retention line makes a probe on how the numbers were counted likely. If you know, say how, and name the assumption you would defend least; if someone else produced them, or you do not know how they were counted, say so plainly and return to presenting them | F7's headline claim, so the weakest-assumption move applies. EXP because it tests what was actually yours |
| D2 | "The role owns the post-event review and the KPIs it reports. What did the review after a content drop look like where you worked?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Answer slot: if a review took place after drops, say what happened and what part was yours, in your own words; if there was none, or it was someone else's, say so plainly and return to presenting the monthly retention numbers | The JD line is F3's requirement; the premise may be false, so the slot allows it |

### E. Pressure (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you, with one title and no in-app-purchase experience, over someone who has run live events at scale?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years", "Wrote the release checklist our QA team still uses", "Presented the monthly retention numbers to the studio head", "never worked on a game with in-app purchases" | Pause and restate. Hold what the quotes carry: the weekly calendar, the checklist QA still uses, the monthly retention presentations. Concede specifically: "I have never worked on a game with in-app purchases." Do not claim scale you did not state. Hold through two follow-ups | F1, F4, F7 and F9 in one challenge; the test is composure |
| E2 | "That checklist. How much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Hold: "I wrote the release checklist our QA team still uses." Answer slot: if QA or others contributed, say which parts were yours and which were theirs, in your own words; if it built on an earlier document, say so plainly. Do not enlarge it | F4 is a line with nothing inspected behind it; attribution probes target exactly that |

### F. Conversational (weight 6)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through your path into live ops." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio", "I ran the weekly content-drop calendar for our main title for the last two years", "Wrote the release checklist our QA team still uses", "Presented the monthly retention numbers to the studio head" | A 90-second arc from those four sentences and nothing else. Add your own reason for wanting this role, in your own words; reference only what Saltmarsh publishes, such as its values page | The opener is scored; F5 and F6 are what it rests on |
| F2 | "What's a live event in a mobile game you admired recently, and what made it work?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Selection scaffold: pick one you actually followed, say what you saw and what you would have watched. If none comes to mind, say so plainly, then talk about the calendar you ran, or how you would assess one | The JD's live-events line asked casually; it is still scored |

## Requirement coverage

| Requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two titles | C3, F2, A4 |
| Coordinate design, art, engineering and community | C2, A1, A3 |
| Own the post-event review and the KPIs | D2, D1, A5 |
| Manage the release checklist with QA | B3, E2, A3 |
| 3+ years producing live-service games or apps | F1, E1 |
| Experience running a content calendar | F1, B1, F2 |
| Comfortable with player-retention metrics | D1, A5 |
| Clear written communication | A2, B3 |
| Published value: Players Before Plans | B1, A1 |
| Published value: Ship the Patch Not the Promise | B2, A2 |
| Published value: Leave the Build Greener | B3, A3 |
| Season-pass and in-app purchases (not a JD line) | C1, A4 |

## Values cheat sheet

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | A scheduled plan gives way to what players need | No quote carries a conflict. Selection scaffold: pick a real time a drop and player needs diverged; if none comes to mind, say so, then give the nearest thing, F6: "I ran the weekly content-drop calendar for our main title for the last two years" |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | No quote carries a hard-truth moment. Selection scaffold as in B2; if none comes to mind, say so, then give the nearest thing, F3: "Presented the monthly retention numbers to the studio head" |
| Leave the Build Greener | Each release leaves the code and the checklist better | F4: "Wrote the release checklist our QA team still uses" |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You moved from QA lead into running live ops. Which QA habits did you keep, and which didn't survive a live event?" | Ties to his own path, drawn from public material, and invites a peer conversation |
| R2 | "Your GDC talk argued a live team is judged by whether patch notes describe what shipped. How do you measure that here?" | Shows you read his work, and moves the talk to how the team operates |
| R3 | "From February 2027 events move to one shared calendar under a single live-ops group. Where does this role sit in that, and does it still cover two titles?" | Tests the JD against the announcement without asserting anything about either |
| R4 | "What did the last post-event review change?" | Connects to "Leave the Build Greener" and the JD's review line |
| R5 | "What separates the strongest answers in the Outage Hour from the rest?" | Shows you treat it as a skill and asks for the bar directly |
| R6 | "What would a good first ninety days look like in this role?" | A standard close, but a prepared one beats "I think you've covered everything" |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Planned and ran a live-events calendar across two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: one title, content drops. C3's slot stays inside the calendar you ran |
| Owned the post-event review and the KPIs | Inflated form of F3 | F3's quote at its own scope: presenting. D2's slot stays inside presenting |
| Managed releases with QA | Inflated form of F4 | F4's quote: you wrote the checklist, and QA still uses it. E2's slot stays inside that sentence |
| Led or managed design, art, engineering or community | Negative you stated, F2 | The plain acknowledgment, sourced to F2's quote: "I have never led a team." |
| Has in-app-purchase or monetization experience | Negative you stated, F9 | The plain acknowledgment, sourced to F9's quote: "I have never worked on a game with in-app purchases." |

## Sources

Provided: the JD text and your background message. No dossier was present.

Searches:

- "Saltmarsh Games values": https://saltmarshgames.com/values
- "Saltmarsh Games interview process live operations producer": https://saltmarshgames.com/careers/interviewing
- "Saltmarsh Games strategy news mobile": https://saltmarshgames.com/news/project-larkspur (search snippet only, not fetched)
- "Tobias Wrenfield Saltmarsh Games": https://talks.gdconf.example/2026/patch-notes-are-a-promise (search snippet only, not fetched)

Fetches: the values page and the interviewing page, both read.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh values | yes | Values cheat sheet and B1 to B4: three values by name |
| 2. Interview process, live-ops producer | yes | The Outage Hour structure; persona weights and banks A and B follow it |
| 3. Strategy and recent news | yes | A4 and R3; the Larkspur facts come from the search snippet only |
| 4. Tobias Wrenfield, Saltmarsh | yes | The interviewer read, A2, R1 and R2; both facts come from the search snippet |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Confirmation that Tobias is the hiring manager for this role → persona weights stay as built, or Peer and Skip-level banks are added or reweighted
- The recruiter's note on the Outage Hour (format, any materials in advance, which title or event it uses) → A1 to A3 become specific to that scenario
- Your own answers to the slots in F1, F2, F3 and F5 (which groups you coordinated with, whether a post-event review existed, who counted the retention numbers, whether any drops were timed events) → those rows upgrade from discovery or transferability, and C2, C3, D1 and D2 become story-mapped
- The release checklist itself, or a content-calendar export, or a retention review document → F4, F6 and F7 move from medium toward high confidence, since these are the inspectable artifacts in producing work
- Deeper research (up to 6 more searches and 2 more fetches, several more minutes) → fetch the Larkspur page and the talk page themselves, add a grounding brief on Saltmarsh's strategy, and check role-family loop reports and recent org context
- A tuesday-dossier.md from an earlier evaluation → verified evidence and absolute prohibited-claims, replacing this pack's locally built list
