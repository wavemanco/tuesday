# Interview prep pack: Live Operations Producer, Saltmarsh Games

- **Candidate:** Femi
- **Interviewer:** Tobias Wrenfield, Head of Live Operations
- **Round:** one 60-minute interview on Friday. Relationship assumed to be hiring manager; this is unconfirmed, and if it changes the persona weights and banks change with it.
- **Built on:** your message and the JD you pasted. Company research did not run (see Sources), so nothing here is a fact about Saltmarsh beyond the JD text.

## How to use this pack

Personas describe how a question arrives; types describe what it scores. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

| Type tag | What it scores |
|---|---|
| VAL | Whether past behavior shows how you work with people, not generic virtue |
| EXP | Whether your own claims survive scrutiny, and what was actually you |
| JD | A stated responsibility or requirement in the posting |
| CO | Homework on the company and its games |
| CASE | A live problem from the role, reasoned aloud |

Labels: `[grounded]` rests on something you or the JD supplied, `[inferred]` is this pack's derivation, `[generic]` is a role-family pattern with no claim about you or Saltmarsh.

An **answer slot** is an instruction for the interview, not a question for you now. It names a probe the interviewer is likely to make and gives two honest branches: say what you did in your own words, or say plainly it was not yours or never existed, and return to what you stated.

## Prep triage

Interview is Friday, three days out. In this order:

1. Rehearse B1 aloud, with all three follow-ups. It is the pack's highest-ROI prep.
2. Write down your honest answers to the slots in F1, F3, F4, F5 and F6, one or two lines each. Those are the likeliest probes on your own history, and your answers will upgrade those rows.
3. Run D1, your 90-second arc, until it fits in 90 seconds.
4. Do A1 and A5 out loud once each, to feel the structure.
5. Play both Saltmarsh titles for a few sessions (the JD says two; their names were not supplied) so A4 and D3 have real observations behind them.
6. Pick three reverse questions.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message | medium | [grounded] | discovery | Your material gives four years as an associate producer, and does not show what that title covered or which of the years were on the title whose calendar you ran. A years requirement is graded on evidence, not a gate. Answer slot: expect a probe on the scope of the associate role. Say which years were on the title whose calendar you ran and what the role covered, in your own words; if it covered less than a producer's would, say so plainly and stay with the four years as stated |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it, so expect a probe. Lead in the quote's own terms: you ran the weekly content-drop calendar, for the main title, for two years |
| F3 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for one title, with nothing inspected behind it; the JD says live events and two titles. The words stay at the quote's scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's live-events line makes a probe on whether the drops included timed events likely. If any did, say which and what part was yours; if they were content releases only, say so plainly. If you ever ran another title's calendar, say so; if not, say so and stay with the one calendar |
| F4 | "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team" — your message | low | [inferred] | discovery | Never leading a team is not the same as never coordinating, and the material has no quote on which teams the weekly drops involved. Answer slot: the JD names four disciplines, so expect a probe on which of them you worked with on a drop. Say which, how the work reached them and what was yours to decide, in your own words; if some were not part of your drops, or someone else coordinated them, say so plainly and stay with the calendar you ran |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your material says you presented monthly retention numbers, not that you ran a post-event review or owned KPIs, and the words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's own-the-review line makes a probe likely on whether any review followed a content drop. If one did, say what it covered and what part was yours; if there was no such review, or the numbers were not yours, say so plainly and stay with the monthly presentation |
| F6 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | transferability | Writing the checklist is what the quote says; managing it at each release is not stated. The words: "I wrote the release checklist our QA team still uses." Answer slot: if you ran it at releases, say how, with QA, in your own words; if QA ran it, or it was not used at every release, say so plainly and stay with the checklist you wrote |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | presentation | The quote already reaches the requirement in other terms, and the words stay in them: "I presented the monthly retention numbers to the studio head." Expect a probe on how those numbers were counted; C1 rehearses it, and "I don't know how that was counted" is an honest branch |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | low | [inferred] | discovery | The pack derives this from F6's quote being a written artifact; the material does not show whether it was clear or who relied on it. Answer slot: expect a request to describe something you wrote. If there is a written piece other than the checklist, say what it was and who read it; if the checklist is the main one, say so plainly and stay with it |
| F9 | (not in the JD) experience of a game with in-app purchases — role-family expectation, unquoted | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. The words: "I've never worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. The JD does not name in-app purchases, so this row is the pack's anticipation, and it raises no answer slot; B1 rehearses it |

## Persona table

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems from the role: plan a month, resolve a clash, diagnose a retention dip | High (5 questions). The relationship prior for a hiring manager is Case plus Skeptic, and the JD's duties (calendar, coordination, review) are all things a live problem can test | Clarify first, then objective, approach, metrics, risks; think aloud; challenge one premise politely (A1 to A5) |
| Skeptic | Quiet probing of the thin spots: in-app purchases, the associate title, no team led | High (5 questions). Same prior; the thin rows are F1, F4 and F9, and F9 has no adjacent evidence | Rehearse B1 until it is boring; acknowledge stated gaps plainly, hold what you stated, add a plan (B1 to B5) |
| Data-Driven Prober | Goes line by line on the retention numbers and the checklist | Medium (3 questions). The JD names retention metrics and KPIs; no interviewer signal is available to adjust this up or down | Know what you can and cannot say about how the numbers were counted; say plainly when you do not know (C1 to C3) |
| Conversational | Opens with the journey, then casual questions about games and writing | Medium (3 questions). Most 60-minute interviews open this way; casual questions are still scored | A 90-second arc built only from your stated lines; treat the game question as scored (D1 to D3) |
| Peer Evaluator | Seam-splitting with design and engineering, credit across teams | Low (2 questions). The role coordinates four disciplines, but a head of function is less likely to play peer | Propose seam principles, not a claimed seam; credit others by name (E1, E2) |
| Pressure | Time-boxed, attribution challenges | Low (2 questions). No signal either way; included so the style is not new live | Pause, restate, hold through two follow-ups, concede specifically (F1, F2) |
| Values/Behavioral | Not weighted | No published values were in hand and no loop source documents a values round; E2 covers the nearest behavioral ground | Add when values or a round structure are known |

These weights rest on the relationship prior and the JD, not on a documented Saltmarsh process: the only loop source is your own note of one 60-minute session with Tobias.

## Question banks

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how you'd plan the next four weeks of live events for one of our titles. What do you need to know first?" | JD | [generic] | Clarify before structuring: what the month must achieve and which number measures it, which dates are fixed (builds, store or holiday moments), what each discipline can deliver and by when, and what players were already promised. Then one-sentence objective, the weeks with an owner each, the measures you would watch, and the two risks most likely to move a date. Think aloud and challenge one premise politely. The question asks about no past, so the guidance makes none | F3 is the JD's headline duty, so a live version of it is likely; JD content with CASE delivery, and generic because it is a pattern for the problem rather than a fact about Saltmarsh |
| A2 | "Two of our titles want a big event in the same fortnight and they share one art team. How do you decide?" | CASE | [generic] | Ask first: what each event is meant to move and by when, whether either date is fixed, how much art is new versus reused, who else the fortnight touches. Options to weigh aloud: stagger, trim one event, reuse assets. State the principle you would decide on, who you would take the decision to, and that you would write the trade-off up so design, art, engineering and community see the same thing. No claim about your past | F3 shows one title in the material and the JD says two, so two-title trade-offs are where this gets tested; CASE because it is a live decision in the role |
| A3 | "An event launched on Tuesday, and by Thursday retention is below what the team expected. What do you do?" | CASE | [generic] | Clarify: below what, measured how; all players or one segment; one platform or build; how much data exists yet. Hypotheses in order of cost to check: a technical fault, tuning or difficulty, reward pacing, how it was communicated, audience fit. For each, who you would pull in. Decide by when: leave it running, tune, communicate, or escalate. Say what you would not conclude from two days of data, and name the assumption in your read you would defend least | F5 and F7 are the review and retention duties; a diagnosis case tests both live, and the weakest-assumption move is the type's own bar |
| A4 | "What have you noticed about how our games run their live events?" | CO | [generic] | Selection scaffold: after playing both titles, pick one or two specific things you noticed from play, such as a cadence, a kind of event or a reward, and say what you would ask about it rather than what you would change. If you have not played them, say so plainly and say what you would look at first. The pack supplies no company facts because research did not run | Strategy research did not run, so the CO bank is thin by design; F3's two-title scope is why knowing the games matters |
| A5 | "How would you run the post-event review for an event, and which numbers would it report?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Structure: the decision the review supports; targets agreed before the event; results against those targets; what you think happened and how sure you are; what changes next; who reads it, in writing. The only claim about your past this row rests on is "I presented the monthly retention numbers to the studio head." Answer slot: the JD's own-the-review line makes a probe likely on whether you ran any review after a drop. If you did, say what it covered and what part was yours; if there was no such review, or it was not yours, say so plainly and stay with the monthly presentation | F5 is the JD's review-and-KPI duty with the thinnest bridge; JD content, asked as a method question so the honest branch is available |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "I don't see in-app purchases anywhere in your background. How would you handle that in this role?" | JD | [grounded] "never worked on a game with in-app purchases" "I ran the weekly content-drop calendar for our main title for the last two years" "Presented the monthly retention numbers to the studio head" | **Highest-ROI prep in the pack.** The limit first: the material shows no in-app purchases and no adjacent work for them, so the hold is only the rest. Pause and restate. Acknowledge plainly: "I've never worked on a game with in-app purchases." Hold at scope: "I ran the weekly content-drop calendar for our main title for the last two years" and "I presented the monthly retention numbers to the studio head"; say them and stop, and do not call them monetization experience. Plan, said as a plan: in week one you would ask which revenue measures an event reports, who owns them and how the team reads them. Follow-up one, "that is a big gap": concede it is one, hold the two lines. Follow-up two, "how long until you are useful on it": give your own honest estimate and what you would do to shorten it; do not give a figure you cannot stand behind. Follow-up three, "why take the risk on you": say what you bring at its scope, concede the learning curve, never say retention work is the same thing. Answer slot: if you have learned anything about how these measures work outside your job, say what, in your own words; if not, say so plainly and say what you would read or ask first | F9 is a stated gap with no adjacent evidence, which makes it the objection most likely to be asked in some form; JD because it scores whether the role's KPI duty (F5) can be done |
| B2 | "You haven't led a team, and this role coordinates design, art, engineering and community on each update. How do you plan to handle that?" | JD | [grounded] "Never led a team" "I ran the weekly content-drop calendar for our main title for the last two years" | Acknowledge plainly: "I've never led a team." Note that the JD's wording is coordinate, and say that as the JD's wording, not as a claim about your experience. Plan, said as a plan: get each discipline's owner and date agreed in writing, keep one place where the update plan lives, and check in before a date slips. Answer slot: expect a probe on which disciplines you worked with on the weekly drops. Say which, how the work reached them and what was yours to decide, in your own words; if some were not part of your drops, or someone else coordinated them, say so plainly and stay with "I ran the weekly content-drop calendar for our main title for the last two years" | F4 is the coordination duty where the material is thinnest; JD content, Skeptic delivery |
| B3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never worked on a game with in-app purchases" | Pick the answer you would actually give, name it plainly, give one sentence of reason and the first step you would take. Your stated limit is "never worked on a game with in-app purchases"; if that is your pick, say "I've never worked on a game with in-app purchases." The other thin places are in F3 and F4; choose the one you believe and do not pick a weakness for show | The stem is near-certain from a skeptical hiring manager, and F9 is the stated gap; JD because the question scores the posting's duties |
| B4 | "The role asks for three-plus years producing live-service games, and you've been an associate producer. How do you see the fit?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" "I ran the weekly content-drop calendar for our main title for the last two years" | Start from what is stated: "4 years as an associate producer at a puzzle-game studio," and of those the last two running "the weekly content-drop calendar for our main title." Answer slot: say which years were on the title whose calendar you ran and what the associate role covered, in your own words; if it covered less than a producer's would, say so plainly. Concede the title is associate; do not restate it as something larger | F1 is the years requirement, and the title is the visible mismatch; JD because it scores the stated qualification |
| B5 | "Why live operations, and why now?" | EXP | [grounded] | Give your actual reason in your own words. It lands best with one thing you want that your current role does not give, and one thing in the JD you can point to, such as the two mobile titles or owning the post-event review and the KPIs it reports. No criticism of your current studio. If a reason does not come easily, say so plainly and say what draws you to this role | F3 and F5 are the JD hooks a reason can attach to; EXP because it tests whether the motivation is yours and consistent |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You presented the retention numbers each month. Walk me through how those numbers were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | The four slots a figure raises, each in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know how a figure was counted, say so plainly; that beats a method you cannot repeat under a second question. The pack supplies no method | F7's line is the one a prober goes at first; EXP because it tests attribution and whether you know your own numbers |
| C2 | "It's the morning after an event launches. Which retention numbers do you want in front of you, and what would make you doubt them?" | JD | [generic] | Name the measures you would actually use, in your own terms, and say what each is for. Say what you would compare against (before the event, against plan) and what would make you hold back: too little data, old and new players mixed, a build or store change the same day. Name the assumption you would defend least. No claim about your past | F7 is the retention requirement; JD content, CASE delivery, and generic because it is a pattern for the problem |
| C3 | "Walk me through the release checklist you wrote. What's on it, and how does QA use it today?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | The quote carries two beats: you wrote it, and QA still uses it. Answer slot: the JD's manage-with-QA line makes a probe on what is on it and who runs it at a release likely. Say what is on it as you remember it; if you ran it at releases, say how, with QA; if QA ran it, or you no longer know what is on it, say so plainly and stay with the checklist you wrote | F6 is the release-checklist duty; JD because it scores the stated responsibility, with the artifact as the probe |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" "I ran the weekly content-drop calendar for our main title for the last two years" "Wrote the release checklist our QA team still uses" "Presented the monthly retention numbers to the studio head" | A 90-second arc built only from those four lines: where you worked, the calendar you ran, the checklist QA still uses, the retention numbers you presented. Close with why this role, in your own words (B5). Add no title, team size or result beyond them | F1 to F7 all draw on these lines; the opener is the one question every interview asks, so a scripted arc buys the most |
| D2 | "If I asked you to write up next month's event plan for design, art, engineering and community, what would be in it?" | JD | [generic] | Describe a one-page plan: the goal and the number that measures it, dates and an owner per discipline, what needs deciding and by when, the risks, and what changed since the last version, in plain language and in one place. Say you would ask each team what it needs to see. No claim about your past | F8 is the written-communication requirement; JD content, CASE delivery, asked casually because rapport interviewers score it too |
| D3 | "Which mobile games do you follow for how they run live events?" | CO | [generic] | Selection scaffold: choose one or two you genuinely play, say one thing you noticed about their calendar or events and what you would ask about it. If you follow none, say so plainly and say which you would look at first | A casual question on a hot JD topic is still scored; CO because it tests homework, and F3's scope is why it matters |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Where does your job end and design's or engineering's begin on an update, and what happens when you disagree?" | JD | [generic] | Propose seam principles rather than claiming to know their seam: who decides content, who decides dates, who decides scope, written down per update. When you disagree, put the options and their cost in writing, take it to the person who owns the decision, and accept the call. Ask what their seam is today. No claim about your past | F4 is the coordination duty; JD because it scores the role's cross-team job |
| E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time work crossed teams where you named others' parts by name, with a named stake, what you said and what the others took from it. If none comes to mind, say so plainly, then say how you would handle it: name others' contributions in the write-up before your own | Persona stem for the peer style; VAL because it scores how you work with other disciplines, and F4 is the duty it touches |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "That calendar: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Pause and restate. Hold: "I ran the weekly content-drop calendar for our main title for the last two years." Follow-up one, who else touched it. Answer slot: say who else contributed and what they did, in your own words; if it was yours throughout, say so. Follow-up two, what you decided versus what you were told. Answer slot: say which decisions were yours and which came from others; if you do not remember, say so plainly. Concede specifically that it was one title. Add nothing the quote does not say | F2 and F3 rest on this line, so an attribution probe lands here; EXP, delivered under pressure |
| F2 | "Sixty seconds: why you over someone who has already run live events with in-app purchases?" | JD | [grounded] "never worked on a game with in-app purchases" "I ran the weekly content-drop calendar for our main title for the last two years" | Hold-then-concede in one minute. Say it plainly: "I've never worked on a game with in-app purchases." Hold at scope: "I ran the weekly content-drop calendar for our main title for the last two years." Do not claim equivalence. Close with what you would do first, said as a plan | F9 under time pressure; JD because it scores fit against the role as posted |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| "3+ years producing live-service games or apps" | B4, D1 |
| "experience running a content calendar" | A1, F1, D1 |
| "Plan and run the live-events calendar for two of our mobile titles" | A1, A2, A4, F1 |
| "coordinate design, art, engineering and community teams on each update" | B2, D2, E1, E2 |
| "own the post-event review and the KPIs it reports" | A3, A5 |
| "manage the release checklist with QA" | C3 |
| "comfortable with player-retention metrics" | A3, C1, C2 |
| "clear written communication" | D2 |
| Not in the JD: in-app purchases (your stated gap) | B1, B3, F2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which two titles would I be working on, and what does the next quarter of events need to do for each?" | Turns the JD's two-title scope into a planning conversation and shows you are already thinking in calendars |
| R2 | "What does a good post-event review lead to here? Can you give an example of a decision one changed?" | Tests whether review ownership is real, and shows you care about the decision, not the report |
| R3 | "Which measures does an event report against, and who sets the targets?" | Surfaces what the KPIs actually are, including anything commercial, without you claiming ground you lack |
| R4 | "How do design, art, engineering and community each hear about an update today, and where does it slip?" | Shows you think about the seam, and the answer tells you what the job really is |
| R5 | "Who owns the release checklist today, and how do QA and producers split it?" | Ties to the checklist you wrote and tells you whether you would inherit or build it |
| R6 | "What would a strong first ninety days look like, and what would worry you at ninety days?" | Invites the gaps to be named by the person who scores them, which is the safest place for them to surface |

No interviewer profile was available, so none of these is tied to Tobias's own path; the upgrade menu says what a profile would add.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has produced live-service games for 3 or more years | Inflated form of F1 | F1's quote at its own scope. The pack's observation: the material says four years as an associate producer, not what the role covered. B4's slot stays inside the associate role |
| Owned the live-events calendar for two titles | Inflated form of F3 | F3's quote at its own scope. The pack's observation: the material says a weekly content-drop calendar for one title |
| Owned the post-event review and its KPIs | Inflated form of F5 | F5's quote at its own scope. The pack's observation: the material says presenting monthly retention numbers, not reviews or KPI ownership. A5's slot stays inside the presentation |
| Managed the release process with QA | Inflated form of F6 | F6's quote at its own scope: you wrote the checklist QA still uses. C3's slot asks only what is on it and who ran it |
| Led or managed a team | Negative you stated, F4 | The plain acknowledgment: "I've never led a team." No slot; B2's slot is about which disciplines you worked with, not leading |
| Has worked with in-app purchases or monetization | Negative you stated, F9 | The plain acknowledgment: "I've never worked on a game with in-app purchases." No slot |

## Sources

Provided documents: the JD text and the background you pasted. No dossier was in hand.

Searches sent, all refused (permission to use web search was not granted):

- "Saltmarsh Games mobile studio company values": refused
- "Saltmarsh Games interview process Live Operations Producer": refused
- "Saltmarsh Games news strategy mobile titles": refused
- "Tobias Wrenfield Saltmarsh Games Head of Live Operations": refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Would have fed a values cheat sheet if a values-style round were detected; none is, so the omission costs little now |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | Would have given loop structure and moved the persona weights; they rest on the relationship prior instead |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | Would have grounded A4 and D3 in current strategy; both are generic |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Would have produced the interviewer read and a reverse question tied to his path; both are absent |
| 5. representative `Live Operations Producer` JD | skipped | The JD you pasted fixes the fit snapshot and every JD-tagged question |

## Upgrade menu

- Web search permission, then a rerun of targets 1 to 4 → company values, documented loop structure, current strategy and Tobias's public footprint; A4 and D3 become grounded, persona weights follow the loop, and a reverse question can tie to his path
- Deeper research (L2: up to 6 more searches and 2 more fetches, several more minutes) → a strategy brief and recent org context for sharper CO and CASE questions; it needs search permission first
- Whether Tobias is your manager, plus the recruiter's guidance on focus areas, any take-home and who else you meet → the persona weights are re-set, and a deliverable would get its own build section
- The names of the two titles → A4, A2 and D3 stop being generic and you can rehearse against the real games
- Your written answers to the slots in F1, F3, F4, F5, F6 and F8 → those rows move from discovery or transferability toward grounded bridges, and the banks that draw on them are regenerated
- The release checklist itself, or a retention deck you presented → inspectable artifacts that can raise F6, F7 and F8 from medium or low toward high
- A tuesday-dossier.md from an earlier evidence review → verified evidence and a prohibited-claims list that would replace the ones built here from your message
