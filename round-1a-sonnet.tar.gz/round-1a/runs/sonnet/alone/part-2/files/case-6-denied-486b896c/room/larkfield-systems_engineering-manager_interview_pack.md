# Engineering Manager — Larkfield Systems: three-round interview pack (loop mode)

Candidate: Yusuf. Role as you described it: lead two squads building device-management services, own delivery, hiring and growth for 11 engineers, partner with hardware and product on roadmap.

| Round | Interviewer(s) and relationship | Length | Position in loop |
|---|---|---|---|
| 1. Tuesday | Director of Engineering, the hiring manager and your would-be boss (name not given) | 45 min | First |
| 2. The Thursday after | Panel: two staff engineers and a product manager (names not given) | 60 min | Second |
| 3. The following Monday | VP Engineering, described by the recruiter as "values and leadership philosophy" (name not given) | 30 min | Third |

The loop rests on your own words, not on a Larkfield source: no search could be run (see Sources). Persona weights follow the relationship priors and what you told me about each round.

The highest-ROI prep in this pack is **A2**, the hardware-roadmap objection. It is built from your own sentence about hardware, it comes from the person who would manage you, and the same gap returns in D2 and H1.

## How to use this pack

Personas describe how a question is asked (who, in what style). Types describe what is being scored. The guidance in each row is scaffolding, not a script: say it in your own words, and rehearse only what you actually did. An "Answer slot" is an instruction for the interview itself: it marks something your material does not show, and it has an honest branch if the thing never happened.

| Type | What it is scoring |
|---|---|
| VAL | Whether past behavior shows the values or leadership principles being asked about |
| EXP | Whether the claims about your work survive scrutiny, including what was actually you |
| JD | The stated responsibilities of the role, gaps included |
| CO | Knowledge of the company and its strategy (none in this pack, see Sources) |
| CASE | Structure and reasoning on a live problem from the role |

## Prep triage

Two weeks, three rounds. The few things done well, in order:

| When | Do | IDs |
|---|---|---|
| Before round 1 | Say A2 aloud until it is boring, then A4 and A3. Write your reasons for the move in your own words once, because rounds 1 and 3 both ask for them | A2, A4, A3, I1 |
| Before round 1 | Think aloud through one case, and settle the 90-second arc | B1, C1 |
| Between rounds 1 and 2 | Write out the four slots a figure raises for the 60% and the 40 interviews: how it was counted, what it is sensitive to, the assumption you would defend least, what was yours | E1, E2 |
| Between rounds 1 and 2 | Settle which instance you would use for growth and for working with product | E3, F2, D1 |
| Between rounds 2 and 3 | Rehearse the held position and the concession on your own results and your stated gaps | H2, H1, G3 |
| Between rounds 2 and 3 | Choose the instances behind your leadership principles | G1, G2, G4 |

Everything else is insurance.

## Fit snapshot (shared across all three rounds)

Role lines are quoted from the role description in your message. Evidence is quoted from your message and nothing else. No row is a gate: the role as you described it states no authorization, location, pay or credential term.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role description in your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | medium | [grounded] | transferability | Words stay at the quote's scope: team lead of 6. The pack's observation is that your material shows one team of six where the role names two squads and 11 engineers, and A4 rehearses that step. Answer slot: the two-squad line makes a probe on running more than one team likely. If you have worked across more than one team, say how, in your own words; if not, say so plainly and stay with the team of six where you were team lead |
| F2 | "building device-management services" — role description in your message | none given | none | [grounded] | discovery | Your material does not show device-management work, and the quote in F1 names a payments company as your current employer. Answer slot: if any of your work touched services that manage devices, say what and what part was yours, in your own words; if it did not, say so plainly and say how you would get up to speed |
| F3 | "own delivery, hiring and growth for 11 engineers" (the delivery part) — role description in your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | Words stay at the quote's scope: a reliability quarter you pushed through, against roadmap pressure, after which the on-call burden dropped 60%. Keep "after" as "after". The pack's observation is that the sentence shows one quarter, not ownership of a roadmap's delivery. Answer slot: if delivery of the team's roadmap was yours, say what was yours, in your own words; if it was shared or someone else's, say so plainly and stay with the reliability quarter. The 60% raises the four figure slots, rehearsed in E1 |
| F4 | "own delivery, hiring and growth for 11 engineers" (the hiring part) — role description in your message | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | transferability | Words stay at the quote's scope: you run the hiring loop for backend roles, about 40 interviews last year. The pack's observation is that the sentence shows the loop and an interview count, not decisions on a team's headcount. Answer slot: the hiring line makes a probe on which decisions in the loop were yours likely. If any were yours, say which and how you decided; if none were, say so plainly and describe how you run the loop |
| F5 | "own delivery, hiring and growth for 11 engineers" (the growth part) — role description in your message | none given | none | [grounded] | discovery | Your material has no sentence on developing engineers. Answer slot: the role names growth, so expect E3. If you supported an engineer's growth, say what you did and what changed, in your own words; if you did not, or it was not yours, say so plainly and say how you would approach it |
| F6 | "partner with hardware and product on roadmap" (the hardware part) — role description in your message | "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | low | [grounded] | discovery | The stated negative is about owning a hardware-adjacent roadmap, and the role says partner; your material is silent on whether you have worked alongside hardware people. Words you can say: "I've never owned a hardware-adjacent roadmap." Answer slot: if you have worked alongside hardware people, say how, in your own words; if not, say so plainly and say how you would learn |
| F7 | "partner with hardware and product on roadmap" (the product part) — role description in your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | low | [grounded] | discovery | The sentence touches roadmap pressure without showing where it came from. Answer slot: if the pressure came from product, say who and how you handled it, in your own words; if it came from elsewhere, say so plainly and stay with what you did |
| F8 | Leading through other leads, if the squads have them — not in the role description; raised by your own sentence | "I've never managed managers" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't managed managers." Then how you would learn it, said as a plan and never as a past. The role description does not say whether the squads have their own leads, which is the first reverse question in round 1 |

## Requirement coverage

| Requirement or headline figure | Question IDs |
|---|---|
| Lead two squads | A4, B1, D4 |
| Device-management services | A3, B2, F1 |
| Own delivery | B2, B3, C2 |
| Own hiring | E2, G4 |
| Own growth | E3 |
| Partner with hardware on roadmap | A1, A2, B1, D2 |
| Partner with product on roadmap | B3, D1, F2 |
| The 60% on-call figure | E1, H2 |
| The 40 interviews figure | E2 |
| Not a requirement, but stated by you: never managed managers | A1, G3 |
| Company strategy (CO) | none, because no search could run; see Upgrade menu |

## Round 1 — Director of Engineering, 45 min

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (weight 4) | Quiet probing of the gaps: hardware, domain, scale, why now | Highest. The relationship prior for a hiring manager is Case plus Skeptic, and this person is buying capability and derisking your stated gaps (F6, F8) and unshown ones (F1, F2) | Rehearse A2 until it is boring; say a limit once, in your own words, then stop; hold through two follow-ups |
| Case/Strategist (weight 3) | Live problems on the squads' own roadmap, thinking aloud | High. Same prior; third on weight because 45 minutes leaves room for roughly one case | Clarify, objective, segmentation, approach, metrics, risks; challenge one premise respectfully |
| Conversational (weight 2) | The opening biography and a proudest-of question | Likely but short. A future boss often opens loosely, and casual questions are still scored | A 90-second arc; treat the casual questions as scored |

### Bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Name one weakness, not three, and name it first. Your own sentence supplies it for hardware: "I've never owned a hardware-adjacent roadmap." Then give the ramp as a plan in your own words (what you would learn first and from whom), never as a past. Answer slot: if you have worked alongside hardware people, say how; if not, say so plainly and stay with the plan | F6 and F8 are the plainest gaps and the likeliest to be asked for directly; JD because it scores the role's roadmap line against the person |
| A2 | "You've said you've never owned a hardware-adjacent roadmap, and this role partners with hardware on the roadmap. Why should I take that risk?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure"; "9 years engineering, 3 as a team lead of 6, currently at a payments company" | The highest-ROI rehearsal in this pack. Name the limit first, in your sentence's own words, and stop: "I've never owned a hardware-adjacent roadmap." Follow-up one will be that owning is not partnering, and a probe on what you have done with hardware teams. Answer slot: if you have worked alongside hardware people, say how and what part was yours; if not, say so plainly and return to your sentence. Follow-up two will be why you. Hold on what your sentences carry, at their own scope: "I pushed a reliability quarter through against roadmap pressure" and "team lead of 6". Claim no hardware fluency. Concession slot: name, in your own words, the first thing about working with hardware you would need to learn; if you already know it, say how | F6 is where the role's roadmap-partnership line presses hardest, and the person who would manage you will ask it in some form; JD because it scores a stated line of the role; the limit is named here before it is asked for |
| A3 | "You're at a payments company today. Why device-management services, and why now?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Your material does not carry your reasons, so these are selection criteria: a reason that points at something in the role (it names device-management services, two squads and 11 engineers) rather than away from your current job, and the same reason in all three rounds, because the panel and the VP will ask again. Answer slot: give your actual reasons, in your own words; if the reason is the work itself, say so, and if it is something else, say that. Claim no device-management experience | F2 and F1: the domain and the move are what a Skeptic checks for consistency; JD because the role line is the premise |
| A4 | "You'd lead two squads and eleven engineers. You were team lead of six. What changes?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | State your scope at its own size: team lead of 6. Then say, in your own words, the first thing you expect to change at the larger size. Answer slot: if you have worked across more than one team, say how; if not, say so plainly and stay with the team of six. Do not claim a span you have not had | F1 is the scale step between what is shown and what is asked; JD because it scores the two-squad line |
| B1 | "You inherit two squads with eleven engineers, and hardware and product each want to steer the roadmap. What do you need to know first?" | CASE | [generic] | Clarify before structuring: what is in flight, what each squad owns, who decides when hardware and product disagree, what commitments already exist. Then objective, segmentation, approach, metrics, risks. Challenge one premise respectfully. The case asks nothing about your past, so the guidance claims nothing | A live problem from the role's partner-on-roadmap line (F6, F7); CASE because it scores structure; generic because it is a pattern, not a fact about this employer |
| B2 | "A change to a device-management service has to ship before a hardware release, and the on-call rota is already stretched. How do you decide whether it ships?" | CASE | [generic] | Think aloud: what is at risk and how reversible it is, who is affected, the options (ship narrow, stage it, hold it), who you would bring in, what you would record. State the hypothesis early. Claim nothing about past decisions | F2 and F3: a live problem set in the role's own domain; CASE because the answer is reasoning |
| B3 | "Product wants a feature this quarter, and the on-call load says reliability needs the quarter. Make the call." | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Decision first, then the reasoning. The one past instance your material carries is "I pushed a reliability quarter through against roadmap pressure"; say it at that scope if you use it. Answer slot: if the quarter involved something you traded away, say what; if nothing was traded, say so plainly. Do not add an outcome beyond the sentence | F3 and F7: the case is built on the tension your quote touches; CASE because it asks for a decision under pressure |
| C1 | "So — walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | A 90-second arc made from the beats the sentence states: nine years in engineering, three of them as team lead of six, now at a payments company. End on why this role (A3). Answer slot: what came before the team lead years is not in your material; add it in your own words or leave it out | F1: the arc is the first thing scored; EXP because it tests what the CV line carries |
| C2 | "What's the piece of work you're proudest of?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The beats the sentence states: a reliability quarter, pushed through, against roadmap pressure, and the on-call burden dropping 60%. Tell them in your own words. Answer slot: who applied the pressure and what you did about it, if you did something; if it was not a fight, say so plainly. The figure raises the four slots rehearsed in E1 | F3 is your one result sentence and a boss will reach for it; EXP because it tests what was actually yours |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Do the two squads have their own tech leads, or would the eleven engineers report to me directly?" | Settles whether the role leads through other leads, which your material says you have not done (F8), and shows you are sizing the job |
| 2 | "Is this a new role or a backfill, and what changed to open it?" | Tells you what the role is really for and signals you are thinking about what you would inherit |
| 3 | "Where does the roadmap conflict between hardware and product show up today, and how has it been settled?" | Turns the hardware gap (F6) into a conversation about the seam you would actually work |
| 4 | "What does success look like for me at 90 days and at a year, and how would you tell?" | A boss-relationship question that shows you want a measurable bar |
| 5 | "How do you want to hear bad news from me, and how often should we talk?" | Rapport-style interviewers weight the reverse slot as a preparation signal; this one is about working with them |

## Round 2 — Panel: two staff engineers and a product manager, 60 min

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator (weight 4) | Seam-splitting, "what would you need from us", disagreement and credit | Highest. The staff engineers and the product manager would each work alongside you, and the panel prior blends the top personas of each member's relationship. Names are unknown, so I cannot assign personas per member | Reciprocity framing: what you bring as well as what you need; offer seam principles instead of pretending to know the seam |
| Data-Driven Prober (weight 3) | Line-by-line on your figures: how counted, which assumption, what was yours | High for the staff engineers, who sit in the technical-specialist prior. You have two figures, the 60% and the 40 interviews | Know what you can and cannot say about how each number was counted, and say plainly when you do not know |
| Conversational (weight 2) | Friendly questions on the domain and on working with product | Likely from the product manager; casual questions on the role's hot topics are still scored | Treat them as scored; answer in your own words |

### Bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Where does the line between engineering management and product sit on the roadmap, and what happens when you and the product manager disagree?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Offer seam principles instead of claiming to know the seam: who owns which decision, how a disagreement is settled, how it is recorded. Answer slot: if the roadmap pressure in your reliability quarter came from product, say how you handled that disagreement; if it came from elsewhere, say so plainly and use a principle instead | F7 and the role's partner-with-product line; JD because it scores that line; the panel's product manager is the likeliest asker |
| D2 | "You'd partner with hardware on the roadmap. What would you need from us, and what would you bring?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Ask first what they would need from a manager, then say what you bring. Say what you bring only at the scope your own work carries, and use your sentence for the limit: "I've never owned a hardware-adjacent roadmap." Answer slot: what you bring, in your own words, from work you did; if you cannot yet name any that bears on hardware, say so plainly | F6 again, in collegial packaging; JD because it scores the role line; the reciprocity framing is the peer counter-strategy |
| D3 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick an instance where work crossed a team boundary and credit had to be assigned, with a named choice you made and a relationship that was intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A stock peer probe; VAL because it scores collaboration behavior rather than a role line; generic because it presupposes nothing about you |
| D4 | "A staff engineer on your squad disagrees with your call on the technical direction. What do you do?" | CASE | [generic] | Structure it: hear the objection out, separate what is being decided from the direction, say who decides and how, record it, and say when you would change your mind. Show spine and tact together. The question needs no claim about your past, so the guidance makes none | F1: the two staff engineers on this panel are the people it describes; CASE because it is a live scenario in the role |
| E1 | "Walk me through how the 60% was counted, and what share of it was you." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Your sentence says "after I pushed", and that is the attribution to hold: keep "after" as "after". Four slots, each in your own words: how the 60% was counted, what it is sensitive to, the assumption behind it you would defend least, and what part was yours. Where you do not know how it was counted, say so plainly. Name your weakest assumption before they do | F3: a headline figure is a magnet for probers; EXP because it tests attribution |
| E2 | "You mention about 40 interviews last year. How was that counted, and which decisions in the loop were yours?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Say it at its own scope: you run the hiring loop for backend roles, about 40 interviews last year. Slots, in your own words: how the 40 was counted, what it is sensitive to, the assumption you would defend least. Answer slot: if any decision in the loop was yours, say which and how you decided; if none was, say so plainly and describe how you run the loop | F4: the second figure and the role's hiring line; EXP because it tests what was yours |
| E3 | "Tell me about a time you helped an engineer grow." | JD | [grounded] "own delivery, hiring and growth for 11 engineers" — role description in your message | Selection criteria: an instance with a named change, what you did, and what you would do differently; the choice is yours, because your material carries none. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach growth | F5 is a row with no evidence, so the guidance is a scaffold; JD because it scores the growth line |
| F1 | "What are you playing with in device management or IoT these days?" | JD | [grounded] "building device-management services" — role description in your message | A casual question about a hot topic of the role, and scored. Answer slot: if you have anything hands-on in this area, say what, in your own words; if you do not, say so plainly and say what you would start with. Claim no device-management work | F2: the domain gap asked in a friendly register; JD because the role line is the premise |
| F2 | "Tell me about a time you worked closely with a product manager." | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | An open prompt: choose the instance. The one instance your material touches is the reliability quarter, and it does not say who the pressure came from. Answer slot: if it was product, say what the working relationship was and what part was yours; if not, say so plainly and use another instance, or say no such time comes to mind and describe how you would work with a product partner | F7 and the role's partner-with-product line; JD because it scores that line |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What could a new manager do in their first month that would genuinely help your work?" | The peer reciprocity question: it asks what you can do for them |
| 2 | "What do staff engineers on these squads expect from their manager, and where has that gone wrong before?" | For the two staff engineers: invites candor about the failure mode and shows you plan to listen first |
| 3 | "How are roadmap decisions between product, hardware and engineering made today, and which was the hardest recently?" | For the product manager: the seam from F6 and F7 asked from their side |
| 4 | "Where does reliability and on-call work sit relative to roadmap work right now?" | Ties to your reliability quarter (F3) without claiming anything about it |
| 5 | "What would you change about how the squads work if you could?" | Invites the panel to tell you the real problems |

## Round 3 — VP Engineering, 30 min

A values-style round is detected here on the recruiter's own words ("values and leadership philosophy", as you relayed them). Larkfield's published values could not be read, so there is no values cheat sheet; the values questions below take their theme from the recruiter's words and the persona stems. If you paste Larkfield's values page, the cheat sheet is added (see Upgrade menu).

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral (weight 4) | Scenario probes on leadership philosophy; stories scored on what you actually did | Highest. The recruiter named values and leadership philosophy, and the skip-level prior is altitude and composure | Map an instance to each principle you state; "we" for context, "I" for contribution; pick stories where the hard truth landed, and where your material shows none, say so |
| Pressure (weight 2) | Time-boxed challenges to your results and your fit | Moderate. It is part of the skip-level prior, and 30 minutes limits how much of it there is room for | Pause, restate the question, hold a challenged position through two follow-ups before conceding anything real |
| Conversational (weight 2) | A short opener and a reflective question | Likely at the start and the end of a 30-minute round | Pre-script the arc once and keep it consistent with round 1 |

### Bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "How would you describe your philosophy of leading engineers?" | VAL | [grounded] "values and leadership philosophy" — recruiter's description in your message; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Selection scaffold: two or three principles in your own words, each followed by the instance behind it. The one instance your material carries is "I pushed a reliability quarter through against roadmap pressure"; which principle it shows is yours to say. If no instance comes to mind for a principle, say so plainly, then give the nearest thing your material does carry, or how you would act on it | The recruiter's framing makes this near-certain; VAL because it scores principles against behavior; F3 is the only instance your material carries |
| G2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The beats the sentence states: a reliability quarter, pushed through, against roadmap pressure. Answer slot: if the pressure was leadership's, say what you told them and what happened; if it was not, say so plainly and use another instance, or say no such time comes to mind and describe how you would do it | A stock values stem under the recruiter's framing; F3 and F7 are the only candidate instance; VAL because it scores whether the hard truth landed |
| G3 | "You've said you haven't managed managers. How would you lead leaders?" | VAL | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Plain acknowledgment first: "I haven't managed managers." Then a plan in your own words: what you would want to learn and from whom. Never describe leading leaders as something you have done. The role as you described it does not say whether the squads have leads; round 1's first reverse question settles that. Hold through two follow-ups by returning to your sentence | F8 is a gap you stated, so the plain acknowledgment is sourced; VAL because leadership philosophy is the VP's frame |
| G4 | "Tell me about a hiring decision that was hard." | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | An open prompt: choose the instance. Your material carries the loop and the interview count, not a decision. Answer slot: if a hiring call was yours, say what made it hard and how you decided; if no call was yours, say so plainly and describe how you run the loop | F4 and the role's hiring line; EXP because it tests what was yours |
| H1 | "Sixty seconds: why you over a manager who has already run device-management teams?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure"; "I run our hiring loop for backend roles — about 40 interviews last year"; "I've never managed managers and never owned a hardware-adjacent roadmap" | Pause, restate the question, and hold. What you hold is only what your sentences carry: you pushed a reliability quarter through against roadmap pressure, and you run the hiring loop for backend roles. Concede the stated limit plainly, "I've never owned a hardware-adjacent roadmap", and do not fold on the rest. Answer slot: anything else you bring, in your own words, from work you did | The skip-level pressure stem; F3, F4 and F6 are the three rows the hold and the concession draw on; VAL because the VP scores composure against your values |
| H2 | "That result — how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold what the sentence carries, "after I pushed", and concede specifically. Answer slot: say which parts of the drop were others' or came from other causes, in your own words; if you do not know how the figure was attributed, say so plainly. Do not turn "after" into "because" | F3 again, as a pressure probe; EXP because it tests attribution under challenge |
| I1 | "Why engineering management, and why now?" | VAL | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Use the same reasons you gave in A3. Your material does not carry them. Answer slot: give your actual reasons, in your own words; if the reason is the work itself, say so, and if it is something else, say that | F1 and F2: a skip-level opener, and an inconsistency with round 1 is the risk |
| I2 | "What's a mistake you made as a lead that changed how you work?" | VAL | [grounded] "values and leadership philosophy" — recruiter's description in your message | Selection scaffold: a mistake that was yours, a change in how you work afterwards, and something you could point to as evidence of the change. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The recruiter's framing makes a reflective question likely at the end; VAL because it scores self-assessment |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "How are engineering managers developed here, especially first-time managers of leads?" | Addresses F8 as a learning question rather than a defensive one |
| 2 | "When reliability work and roadmap work compete, how do you decide which wins?" | Connects to your reliability quarter (F3) and invites the VP's own philosophy |
| 3 | "What does the engineering org most need to get better at over the next year?" | An altitude question that shows you are thinking about the org, not only the role |
| 4 | "What would make you regret this hire a year from now?" | Invites the VP to name the risk, which you can then address |
| 5 | "What do you look for in a manager when two strong candidates differ in background?" | Lets the VP say how they weigh the gaps in F2 and F6 |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led two squads, or a multi-team engineering organization | Inflated form of F1 | The quote at its own scope: team lead of 6. The limit is the pack's observation: your material shows one team of six. A4's slot stays inside that scope |
| Owned delivery of a roadmap | Inflated form of F3 | The quote at its own scope: you pushed a reliability quarter through against roadmap pressure. The limit is the pack's observation: the sentence shows one quarter, not roadmap ownership |
| Reduced on-call burden by 60% through your own work | Inflated form of F3: the sentence says the burden dropped "after I pushed" | The quote with "after" kept as "after". The attribution slots in E1 and H2 stay inside your words |
| Owned hiring for a team, or made the hiring decisions | Inflated form of F4 | The quote at its own scope: you run the hiring loop for backend roles, about 40 interviews last year. G4 and E2 ask only which decisions were yours |
| Owned, or partnered on, a hardware-adjacent roadmap | Negative you stated, F6 | The plain acknowledgment: "I've never owned a hardware-adjacent roadmap." A1's slot asks only about working alongside hardware people, and the answer may be that you have not |
| Managed managers | Negative you stated, F8 | The plain acknowledgment: "I haven't managed managers." No slot |

## Sources

Provided documents: your message (the role description, the three rounds, the recruiter's description of round 3, and your background).

Searches sent (all refused by the host, so nothing returned):
- "Larkfield Systems industrial IoT company values" — refused
- "Larkfield Systems engineering manager interview process" — refused
- "Larkfield Systems industrial IoT device management news" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Would have fed a values cheat sheet for round 3 and the VAL themes; neither is in this pack |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Would have checked the loop; your own words establish the three rounds, so the loop and persona weights stand on them |
| 3. `Larkfield Systems strategy` or recent news | unavailable | Would have fed CO and company-grounded CASE questions; the banks hold none |
| 4. `{interviewer name} Larkfield Systems` | n/a | No interviewer name was given, so no query could be formed; there is no interviewer read |
| 5. Representative engineering manager JD | unavailable | The host refused search; it would have added `[inferred]` requirement rows beyond the three role lines you gave |

## Upgrade menu

- Search permission in this session → I rerun targets 1 to 3: Larkfield's published values page, its loop, and recent news, which add a values cheat sheet to round 3 and the first CO questions. A deeper pass would add up to 6 more searches and 2 more fetches, several more minutes, and runs only if you ask for it
- Larkfield's published values page pasted in → the round 3 values cheat sheet, without needing search
- The full job description → rows F1 to F8 take their requirement lines from the posting, and any mid-list requirement gets a question
- Your CV → evidence cells beyond your message, and stories for the scaffold questions (D3, E3, G1, G4, I2) where a CV line carries one
- The interviewers' names → an interviewer read, per-member personas for the panel, and a reverse question tied to an interviewer's own path
- The recruiter's prep email → stated focus areas for each round, and a build section for any pre-declared deliverable
- Your answers to the answer slots (F2, F4, F5, F7 above all) → each becomes a quoted sentence in the fit snapshot and regenerates the rows that draw on it
- An inspectable artifact for the 60%, such as the paging or on-call report from before and after the reliability quarter → F3 can move from medium toward high
- A tuesday-dossier.md from an earlier evaluation of this role → verified evidence, per-gap strategy constraints and a named most-likely objection in place of the one inferred here
