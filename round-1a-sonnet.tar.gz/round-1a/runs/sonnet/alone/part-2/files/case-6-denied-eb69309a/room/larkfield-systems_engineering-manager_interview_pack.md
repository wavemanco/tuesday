# Interview pack (loop mode): Engineering Manager, Larkfield Systems

For Yusuf. Three scheduled rounds, one shared fit snapshot, one mini-pack per round.

| Round | When | Who | Length | Relationship |
|---|---|---|---|---|
| 1 | Tuesday | Director of Engineering (hiring manager, your would-be boss) | 45 min | Hiring manager |
| 2 | The Thursday after | Two staff engineers and a product manager | 60 min | Panel: technical peers plus cross-functional |
| 3 | The following Monday | VP Engineering | 30 min | Skip-level, described by the recruiter as "values and leadership philosophy" |

No interviewer names were given, so there is no interviewer read. Panel personas are assigned by role, not by person.

## How to use this pack

- Personas describe how a question is asked. Types describe what is being scored. Every question carries both a persona (its bank) and a type tag.
- Type key: VAL is behavioral and values alignment. EXP is a work-experience deep-dive. JD is role and requirement driven. CO is company and strategy knowledge. CASE is a live problem from the role.
- Guidance is scaffolding, not a script. Every sentence about your past in this pack is one of your own sentences, quoted. Where the pack could not honestly go further, it leaves an answer slot: an instruction for the interview with two honest branches, either of which is a good answer.
- IDs run round, then persona letter, then number: 1A1 is round 1, persona A, question 1.

## Prep triage

You gave two weeks and three rounds, not hours, so this is ordered by calendar and by value.

1. Before Tuesday: 1A1, then 1A4 and 1C1 said aloud until they are boring. 1A1 is the highest-ROI prep in the whole pack: it is the objection your own words hand the Director.
2. Before Tuesday, if time remains: 1A3 and 1B1.
3. Before Thursday: 2A1 and 2A2 (your two numbers), 2A3, then one CASE aloud, 2B3 or 2C1.
4. Before Monday: 3A1, 3B1, 3B3, 3A2. A 30-minute round has room for perhaps four questions, so these four are the ones to have ready.
5. Everything else is insurance.

## Fit snapshot (shared across all three rounds)

Requirements are quoted from the role description you gave. Evidence is your own words from your message. Rows split the "own delivery, hiring and growth" clause so each part gets its own grade.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role description, your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message; "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | medium | [grounded] | transferability | Your material shows a team lead of six, with nothing inspected behind it, and a stated negative on managing managers. The pack's observation is that it does not show the step to the size of this role. Words at the quote's own scope: "Three of my nine years in engineering have been as a team lead of six." Plain acknowledgment, from your own sentence: "I've never managed managers." Answer slot: the role's size makes a probe on the step up likely. If you have worked at anything near that scale, say how, in your own words; if not, say so plainly and stay with the team of six |
| F2 | "own delivery" — role description, your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | The sentence carries a reliability quarter pushed through against roadmap pressure, and a 60% drop that came after it. It does not say how delivery was planned or tracked. Words stay in the sentence's order: the quarter, then the drop. Answer slot: expect a probe on the 60% and on the pressure. Say how the figure was counted, what it is sensitive to, the assumption you would defend least, and what part was yours, in your own words; if you do not know how it was counted, say so plainly |
| F3 | "hiring" — role description, your message | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | none | No gap in wording, but a one-line claim with nothing inspected behind it, so expect a probe. Lead with the loop in the quote's own terms, backend roles, and give the count as the quote gives it. Answer slot: if the loop's stages or criteria were yours to set, say which, in your own words; if they were not, or none existed, say so plainly and stay with running the loop |
| F4 | "growth" — role description, your message | none given | none | [grounded] | discovery | Your material says nothing on developing engineers, and the pack does not fill the silence. Answer slot: if you have helped an engineer grow into more, say what you did and what part was yours, in your own words; if you have not, say so plainly and answer as a plan |
| F5 | "partner with hardware and product on roadmap" — role description, your message | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | low | [grounded] | discovery | The stated negative is about owning a hardware-adjacent roadmap; the requirement is to partner on one, and the material does not show whether you have. Plain acknowledgment, from your own sentence: "I've never owned a hardware-adjacent roadmap." Answer slot: if you have worked alongside a hardware team in any form, say what and what your part was; if you have not, say so plainly and answer as a plan |
| F6 | "building device-management services" — role description, your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | low | [grounded] | discovery | Your material shows payments, and nothing about devices or fleets. Answer slot: if you have built or run anything that managed remote devices, say what and your part, in your own words; if not, say so plainly and say how you would learn the domain, as a plan and never as a past |

No row is a gate: the role description states no authorization, licence, location or schedule term.

## Round 1: Tuesday, the Director of Engineering

### Persona weights, with reasoning

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet probing of what your background lacks | Highest. A hiring manager is buying capability and pricing the gaps, and you named two gaps yourself (F1, F5) | Rehearse 1A1 until it is boring; bridge only from what your sentences carry; give plans as plans |
| B. Case / Strategist | Live problems from the manager's own roadmap | High. Hiring managers tend to test on the real role, and the role description names squads, delivery and hardware | Clarify, then objective, options, decision, risks; think aloud; challenge one premise respectfully |
| C. Conversational | Friendly opener, then casual questions that are still scored | Medium. It opens most first meetings with a would-be boss | Ninety-second arc for the biography; treat casual questions as scored |

### Bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1A1 | "You haven't managed managers and you haven't owned a hardware-adjacent roadmap. Which of those worries you more for this role, and what would you do about it in your first ninety days?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | The highest-ROI rehearsal in this pack. Hold-then-concede. First answer plainly in the sentence's own terms: "I've never managed managers, and I've never owned a hardware-adjacent roadmap." Then pick the one that worries you more and say why, in your own words, and hold that position through two follow-ups, conceding only what is true. Give the ninety days as a plan, said as a plan: who you would sit with first and what you would ask them. Answer slot: if you have any experience near either one, say what it was and what your part was; if you have none, say so plainly and stay with the plan | F1 and F5 are the widest gaps and you named both, so the Director will reach them in some form. JD because it scores the role's own requirements, delivered as a Skeptic probe |
| 1A2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] | Choose one gap from F1, F5 or F6 and say it first, before they do. Pair it with how you would close it, said as a plan and never as past experience. Do not choose a requirement you have no honest ramp for, and do not pick a gap so small it sounds like a dodge | A standard Skeptic stem, and F1, F5 and F6 make it hard to avoid. JD because it asks you to rank the listed requirements |
| 1A3 | "You've been a team lead of six. Here it's eleven across two squads. What changes in how you work?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Start with what the sentence carries: three of your years as a team lead of six. Then answer as a plan: what you would keep doing and what you would hand over. Answer slot: the step in size is the likely probe. If you have already worked at anything near that scale, say how, in your own words; if not, say so plainly and answer as a plan | F1 is the evidence for the leadership requirement and its limit is the size step. JD because the premise comes from the role's own scope |
| 1A4 | "What's pulling you from payments to industrial IoT, and why now?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Give your own reasons, in your own words: one that is about the role description, such as devices, the squads or the hardware partnership, and one about why now. Do not give a reason you could not defend if asked what you know about industrial IoT. Answer slot: if you have any exposure to device or fleet work, say what it was; if you have none, say so plainly and say how you would learn it | F6 is the domain gap and motivation consistency is what a Skeptic scores. JD because it tests fit to the stated domain |
| 1B1 | "You have two squads. Hardware has slipped a milestone one squad depends on, and the other squad is carrying a reliability problem. How do you decide where each squad's quarter goes?" | CASE | [generic] | Clarify first: what slipped and by how much, what the reliability problem is costing, who is waiting on each. State the objective, lay out two or three options, say how you would decide and who you would talk to, then what you would tell each squad. Think aloud and challenge one premise respectfully. The question asks about no past, so the guidance makes no claim about yours | Tests the delivery and hardware-partnership lines (F2, F5) as a live decision. CASE because it is a live problem; `[generic]` because the pattern is not a fact about this employer |
| 1B2 | "It's your first ninety days. What do you need to learn before you change anything?" | CASE | [generic] | Structure it: the people and their current load, what is committed and to whom, where the squads depend on hardware, how on-call and incidents run today. Say who you would ask for each and what you would deliberately leave unchanged for now. Said as a plan throughout | A Director buying a ramp plan will ask it in some form; it also answers 1A1's ninety days. CASE with JD content |
| 1B3 | "You inherit eleven engineers and two open seats. How do you run the hiring, and what do you want to know about the team first?" | CASE | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | The quote is your anchor, in its own terms: "I run our hiring loop for backend roles." Then structure the plan: what the team lacks, what the seats need to do, how the loop would be shaped, who sits on it. Answer slot: if the stages or criteria of your current loop were yours to set, say which, in your own words; if they were not, or none existed, say so plainly and answer the rest as a plan | F3 is the strongest row you have and the one the Director can test with a live problem. CASE because it is a hypothetical; JD because hiring is a listed responsibility |
| 1C1 | "Walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | A ninety-second arc with only the beats your sentence states: nine years in engineering, three of them as a team lead of six, now at a payments company. Then one beat for why this role, in your own words. The middle of the arc, what you did in those years, is yours to supply aloud; the pack does not write it for you | The standard Conversational opener, and a casual question that is still scored. EXP because it tests whether the claimed history survives a first telling |
| 1C2 | "What do you need from your manager to do your best work?" | VAL | [generic] | Pick two things that are true of you and say each in your own words. Pair each with what you give back: what the Director can expect from you. The question asks about no past, so the guidance makes no claim about yours. If nothing comes to mind, say so plainly and say how you would find out | Doubles as the Director sizing how you would work with him. VAL because it is working-style fit, with no published Larkfield values in hand to anchor it, hence `[generic]` |

### Reverse questions, round 1

| # | Question to ask | Why it lands |
|---|---|---|
| 1R1 | "What would make the first six months a clear success for whoever takes these two squads, and what would make you worry?" | It turns his expectations into something checkable, and the answer tells you which gap in F1 or F5 he weighs most |
| 1R2 | "Where do the squads depend on hardware today, and where does that dependency cost you the most?" | F5 is the row where your material is thinnest; asking shows you are mapping it before day one |
| 1R3 | "How do you want to hear about a squad that is slipping, and how early?" | He is your would-be boss; this is how you would work together |
| 1R4 | "How does the org settle a call between roadmap commitments and reliability work?" | F2 is the evidence behind your interest, and it asks about the decision rule, not for reassurance |
| 1R5 | "What do you know now about this role that you wish you had known when you took yours?" | It invites candor and gives you the Director's own path without presuming it |

## Round 2: The Thursday after, the panel

### Persona weights, with reasoning

Assigned by role, because no names were given. The weights blend the top two personas of each member's relationship.

| Persona | Who it is likely to be | Likelihood and why | Counter-strategy |
|---|---|---|---|
| A. Data-Driven Prober | Staff engineers | High. Technical specialists tend to verify depth, and you have two figures in your own words: 60% and about 40 interviews | Know what you can and cannot say about how each number was counted; say plainly when you do not know; name the weakest assumption before they do |
| B. Peer Evaluator | Staff engineers and the PM | High. A manager is a peer to the staff engineers' work and to the PM's roadmap, so seam and credit questions are likely | Offer seam principles instead of pretending to know the seam; lead with what you bring them |
| C. Case / Strategist | The PM, and a staff engineer on the technical case | Medium. The role description names delivery and hardware partnership, which is natural case material | Clarify, structure, think aloud; keep your role as manager, not the debugger |
| D. Values / Behavioral | The PM, as an interviewer outside engineering | Low in this round. The recruiter put the values conversation on Monday | One story ready and a selection scaffold behind it |

### Bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2A1 | "Your on-call burden dropped 60% after the reliability quarter. Walk me through how that number was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Defend-the-number. Say, in your own words, how the 60% was counted, what it is sensitive to, the assumption you would defend least, and what part was yours; name the weakest assumption before they do. Keep to the sentence's own order, the quarter and then the drop. Answer slot: if you do not know how it was counted, say so plainly, and say what you would look at to find out | F2 holds a headline figure, and figures are what Probers go to first. EXP because it tests whether the claim survives scrutiny |
| 2A2 | "Walk me through how you run the hiring loop for backend roles." | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | The beats the quote states: the hiring loop, backend roles, about 40 interviews last year. Defend the count in your own words: how it was reached, what it is sensitive to, the assumption you would defend least, and what part was yours. Answer slot: if you set the loop's stages or criteria, say which and how you decided; if you did not, or none existed, say so plainly and describe how you run it | F3 is a one-line claim the panel's staff engineers can probe from their own side of the table, since they sit on hiring loops. EXP because it tests what was actually yours |
| 2A3 | "How much of that on-call result was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Pressure-style. Hold the sentence as it is: you pushed the reliability quarter through against roadmap pressure. Hold through two follow-ups, and concede specifically what you do not know about the rest. Answer slot: if others did parts of the work, say which, in your own words; if none did, say so plainly. Never add to "pushed through" | F2 is where an attribution probe lands hardest. EXP with Pressure delivery; the concession is the part worth rehearsing |
| 2B1 | "Staff engineers and engineering managers sit side by side here. Where's the seam, and what happens when we disagree on technical direction?" | JD | [grounded] | Offer principles instead of claiming to know their seam: who decides what, who is consulted, how a disagreement is raised and settled. Lead with what you would bring to their work, then what you would need from them. The question asks about no past | A Peer Evaluator seam question, and the staff engineers are the people the role works beside. JD because it tests the stated partnership |
| 2B2 | "Tell me about a time you disagreed with a senior engineer on technical direction." | VAL | [generic] | An open prompt, so choose your instance: it needs a named stake, how you disagreed, how it ended and the state of the working relationship after. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Disagreement with equals is the Peer Evaluator's core score. VAL because it scores behaviour, though no Larkfield values are in hand |
| 2B3 | "Product wants a feature that the next hardware revision can't support yet. How do we work through it?" | CASE | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Clarify the need behind the feature, then what is fixed in hardware and what is software, options such as interim, cut scope or sequencing, how you would decide together and what you would tell stakeholders. If it fits, say early that you have not owned a hardware-adjacent roadmap and would want hardware in the room, in the sentence's own terms. Think aloud | F5 is the thinnest row and the PM is the person who lives on that seam. CASE because it is a live problem from the role description |
| 2C1 | "A firmware update rolled out to part of a fleet and devices in the field have stopped reporting. What do you do in the first hour, and what do you want from your squad?" | CASE | [generic] | Structure: what is known, the extent of the effect, whether the rollout can be halted or reversed, who needs to hear and when, and what you would ask the squad for. Keep your role as the manager running the incident while the engineers decide technically, then close with the review afterwards. The guidance makes no claim about your past | F6 is the domain gap, and a staff engineer will test it with a live scenario. CASE; `[generic]` because it is a pattern, not a Larkfield fact |
| 2C2 | "Product says no reliability work this quarter, and your squad says on-call is wearing people out. Where do you land?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Ask first: what product's constraint is, what the on-call evidence shows, what each option costs. Then lay out options and how you would decide with the PM. You may anchor on the sentence at its own scope: you pushed a reliability quarter through against roadmap pressure. Answer slot: if you can say who the pressure came from and what you set aside, do so in your own words; if you cannot, say so plainly and stay with the decision structure | F2 is the story the PM can turn into a live decision. CASE because it is hypothetical; the quote is optional anchoring |
| 2C3 | "An engineer on your squad wants to reach staff. How do you help them get there?" | CASE | [grounded] | Structure as a plan: ask what they want, what the next level requires here, where they are now, the work they would need and how you would check progress. Answer slot: if you have helped anyone's step up, say what you did and what part was yours, in your own words; if you have not, say so plainly and answer as a plan | F4 has no evidence, so this is a likely probe from staff engineers who care about their own ladder. CASE with JD content |
| 2D1 | "Tell me about a time you and a product partner wanted different things from the same quarter." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | If the reliability quarter is the story, its sentence carries these beats: a reliability quarter pushed through against roadmap pressure, and the drop that came after. Answer slot: who the pressure came from and how it ended are yours to supply, in your own words; if the pressure was not from a product partner, or this is not your story, say so plainly and pick another instance: a named stake, how you disagreed, and the relationship afterwards | The PM is the cross-functional scorer; F5 and F2 meet here. VAL because it scores behaviour with a partner |

### Reverse questions, round 2

| # | Question to ask | Why it lands |
|---|---|---|
| 2R1 | "What could a new engineering manager do in their first month that would genuinely help your team?" | The reciprocity question for the staff engineers: it asks what you can give, not only what you need |
| 2R2 | "Where do technical decisions get stuck between staff engineers and managers here?" | It asks for the seam itself, which you may not guess |
| 2R3 | "How is the roadmap negotiated today between product, hardware and engineering, and where does it bite?" | Asked of the PM, it goes straight at F5 without claiming expertise |
| 2R4 | "What would you want from engineering that you are not getting today?" | Another reciprocity question, aimed at the PM |
| 2R5 | "What is the part of the device-management stack you would most like fixed?" | Asked of the staff engineers, it shows you are thinking about F6, the domain, as something to learn |

## Round 3: The following Monday, the VP Engineering

### Persona weights, with reasoning

The recruiter's words for this round are "values and leadership philosophy", so a values conversation is detected here. Larkfield's published values are not in hand, so there is no values cheat sheet; the VAL questions below use the recruiter's wording as their theme.

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| A. Values / Behavioral | Scenario probes on leadership and values | Highest. It is what the recruiter named | Map a story where one of your sentences carries one; use a selection scaffold with an honest branch where none does; "we" for context, "I" for contribution |
| B. Pressure | Time-boxed challenge and motive questions | High. A skip-level conversation tests altitude and composure, and 30 minutes forces short answers | Pause, restate, anchor in what your sentences say, hold through two follow-ups |
| C. Case / Strategist | Strategy-flavoured case at the VP's altitude | Medium. Company strategy fluency separates candidates at this level, but no research could be run here, so these are honest `[generic]` | Clarify before structuring; say what you would need to know instead of reciting facts you do not have |

### Bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3A1 | "Tell me about a time you told leadership something they didn't want to hear." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The reliability quarter is your candidate story, with the beats the sentence states: roadmap pressure, a reliability quarter pushed through anyway, and a drop in on-call burden after. Answer slot: who you said it to, what you said and how it landed are yours to supply, in your own words; if the pressure did not come from leadership, or this is not your story, say so plainly and pick another from the scaffold: a named stake, a moment you did not fold, and an intact relationship at the end. Do not supply an ending | F2 is the one hard-truth story your material carries. VAL because it scores whether the hard truth actually landed |
| 3A2 | "How would you describe your leadership philosophy?" | VAL | [grounded] | An open prompt. Choose two or three things you actually act on and give each with one thing you did that shows it, in your own words. Do not claim a principle you cannot back with an example. If nothing comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would lead the people in this role | The recruiter's own words for the round are "values and leadership philosophy", so this is nearly certain. VAL because it scores values, not skill |
| 3A3 | "When have you given an engineer feedback that was hard to hear?" | VAL | [grounded] | Selection scaffold: a named person's situation, what you said, what you would do differently, and how the relationship stood afterwards. The role names growth, and your material says nothing on it, so there is no sentence to map. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4 has no evidence; a VP on leadership philosophy often goes through growth. VAL because it scores candour with people |
| 3A4 | "When did you change your mind about how to lead?" | VAL | [generic] | Selection scaffold: pick a real change, name what prompted it and what you do differently now. Do not invent a turning point. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A philosophy question's usual follow-up, to test self-awareness. VAL; `[generic]` because it is a pattern |
| 3B1 | "Sixty seconds: why you over someone who has already run two squads?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I run our hiring loop for backend roles — about 40 interviews last year."; "I've never managed managers and never owned a hardware-adjacent roadmap." | Pause, restate, then sixty seconds that stay inside your sentences: three of your years as a team lead of six, and that you run your hiring loop for backend roles. Concede in the sentence's own terms: "I've never managed managers, and I've never owned a hardware-adjacent roadmap." Hold your position through two follow-ups; do not claim what the person who has run two squads has | F1 is where a comparison with a candidate who has run two squads is aimed. JD with Pressure delivery; the concession is the beat to rehearse |
| 3B2 | "You went against roadmap pressure for a reliability quarter. Would you do it again, and what would change your mind?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold the sentence as it is. Say plainly whether you would, in your own words, and what would change your mind: that is yours to supply, and it is the point of the question. Concede uncertainty specifically; do not fold on the core claim just to restore harmony. Do not supply a cost or consequence your sentence does not state | F2 again, as a motive probe. VAL because the VP scores judgement, Pressure in delivery |
| 3B3 | "You've never managed managers. Does that matter for this job, and how would you find out?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Acknowledge plainly in your own sentence's terms: "I've never managed managers." Then answer as a question you would put back: how the squads are structured and who leads what. Say what you would do either way, as a plan and never as a past | F1 carries your own stated negative, and the VP can see the role's structure from above. JD with Pressure delivery |
| 3C1 | "Where should device management be in two years, and what part should engineering play?" | CO | [generic] | No research on Larkfield could be run for this pack, so do not recite facts you do not have. Structure: what you would need to know first (customers, fleet scale, reliability, hardware pace), then a view stated as a hypothesis, then what you would ask the VP. Asking is the strong move here | The VP's altitude. CO because it tests strategy fluency; `[generic]` because that is the honest cost of no research |
| 3C2 | "A large customer wants a feature that would pull both squads off the roadmap for a quarter. How do you decide?" | CASE | [generic] | Clarify what the customer needs and what is at stake, what each squad would drop, the options, and how you would decide and with whom. Think aloud; challenge one premise respectfully. The guidance makes no claim about your past | A decision at the VP's altitude. CASE |

### Reverse questions, round 3

| # | Question to ask | Why it lands |
|---|---|---|
| 3R1 | "What does leadership look like at Larkfield when it is working well, in your own words?" | The recruiter named the round as values and leadership philosophy, so this asks for the VP's answer to the thing being scored |
| 3R2 | "What is the hardest tradeoff engineering leadership has made this year?" | It invites a real story and shows you think in tradeoffs, which F2 is your evidence for |
| 3R3 | "How do you want engineering managers to disagree with you?" | It is the other half of 3A3 and 3B1: how a leader holds a position under pressure |
| 3R4 | "Where do you want device management to be in two years?" | It mirrors 3C1 and gives you the strategy you could not research |
| 3R5 | "What is one thing new leaders here get wrong about the values?" | It asks for the unwritten part of the values, which a published page cannot give you |

## Requirement coverage

| Requirement | Questions that cover it |
|---|---|
| F1 Lead two squads | 1A1, 1A2, 1A3, 1B1, 3B1, 3B3 |
| F2 Own delivery | 1B1, 2A1, 2A3, 2C2, 2D1, 3A1, 3B2, 3C2 |
| F3 Hiring | 1B3, 2A2 |
| F4 Growth | 2C3, 3A3 |
| F5 Partner with hardware and product | 1A1, 1B1, 2B3, 2D1 |
| F6 Device-management services | 1A4, 2C1, 3C1 |

## Prohibited claims

What this pack will not coach, and why. Built from the fit snapshot before any bank was written.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | Negative you stated, F1 | The plain acknowledgment from your own sentence: "I've never managed managers." No slot |
| Has owned a hardware-adjacent roadmap | Negative you stated, F5 | The plain acknowledgment from your own sentence: "I've never owned a hardware-adjacent roadmap." No slot |
| Has led two squads or eleven engineers | Inflated form of F1 | F1's quote at its own scope: three of your years as a team lead of six. The limit is the pack's observation, not words for you: the material shows a team of six |
| Caused the 60% drop in on-call burden | Inflated form of F2 | F2's quote at its own scope: the drop came after the quarter was pushed through. The limit is the pack's observation: the sentence gives the order of events |
| Hired or personally interviewed about 40 people | Inflated form of F3 | F3's quote at its own scope: you run the hiring loop for backend roles, and there were about 40 interviews last year. The limit is the pack's observation: the sentence gives a count for the loop |

## Sources

Provided documents: your message, containing the role description, the round list and your background. No dossier was present. No interviewer profile, JD text or CV file was provided.

Searches sent, all refused by the host before returning anything:

- "Larkfield Systems industrial IoT company values" — refused
- "Larkfield Systems engineering manager interview process" — refused
- "Larkfield Systems industrial IoT device management strategy news" — refused

Nothing about Larkfield in this pack comes from research. The loop structure comes from your own words, which establish all three sessions: who runs each, how long, and what each holds.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | All calls were refused. It would have fed a values cheat sheet for round 3; that section is dropped, and the VAL bank uses the recruiter's wording instead |
| 2. Larkfield Systems interview process, engineering manager | unavailable | The call was refused. It would have checked the three rounds against a documented loop; persona weights rest on your account of the rounds |
| 3. Larkfield Systems strategy and recent news | unavailable | The call was refused. It would have fed the CO bank; 3C1 is `[generic]` for that reason |
| 4. Interviewer name and company | n/a | No names were given, so no query could be formed; there is no interviewer read |
| 5. Representative engineering manager JD | unavailable | No call was sent, because search was refused on every earlier call. It would have supplied further requirements to quote; the fit snapshot rests on the one-sentence role description |

## Upgrade menu

- The full job description text: rows F1 to F6 would tie to the posting's own lines instead of a one-sentence summary, and any mid-list requirement the summary omits would get a JD question
- Your CV: evidence cells beyond your message, and more material for F3, F4 and F6
- The on-call or paging dashboard export behind the 60%: the artifact an engineering team keeps for such a figure, which could lift F2 from medium confidence to high
- The interviewers' names: an interviewer read, persona weights tuned from their public footprint, and a reverse question tied to each one's own path
- The recruiter's prep notes on the Thursday panel's format and any pre-declared deliverable: coverage assumed from round-type priors becomes coverage grounded in what the recruiter said, and a deliverable would get its own build section
- Larkfield's published values page, pasted or linked: a values cheat sheet for Monday, mapping each value to a story your sentences carry
- Working search access for Larkfield's values, loop and recent strategy: the three refused targets, and CO questions that stop being `[generic]`
- Hours available per day: the prep triage resized to your time
- A `tuesday-dossier.md` from an earlier evidence-check session: verified evidence in place of the evidence quoted here, and a sourced list of claims to avoid
