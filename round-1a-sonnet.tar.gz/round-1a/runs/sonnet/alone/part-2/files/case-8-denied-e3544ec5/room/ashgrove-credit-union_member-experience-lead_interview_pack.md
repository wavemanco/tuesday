# Member Experience Lead — Ashgrove Credit Union — interview pack for Dara

**Loop:** three rounds on 26 November 2026 (nine days from 17 November). Round 1: recruiter, 30 minutes. Round 2: Head of Member Services, your future manager, 45 minutes, mostly behavioural. Round 3: panel of two branch managers, 60 minutes, including a 20-minute complaint-escalation case; the panel is also the values round. Interviewers beyond their roles are not yet assigned, so no interviewer read is included.

Built in loop mode: one shared fit snapshot, then a mini-pack per round with its own persona weights, question bank and reverse questions.

## How to use this pack

- **Personas describe how a question arrives; types describe what it scores.** Rehearse both: the same question comes friendly from a recruiter and sharp from a panel.
- **Type key.** VAL: behaviour against Ashgrove's published values. EXP: whether your background survives scrutiny. JD: a stated requirement of the role. CO: company and strategy knowledge. CASE: a live problem from the role.
- **Guidance is scaffolding, not a script.** Say it in your own words. Every claim about your past is a sentence you wrote, quoted in the row; where the material is silent, the cell holds an **answer slot**: an instruction for the interview, not a question for me. Pick the branch that is true.
- **Use their words.** The JD says "members" and the strategy brief says "hubs"; Ashgrove's values include "Plain Words".
- IDs run by persona: A, B for round 1; C, D, E for round 2; F, G, H for round 3.

## Prep triage

Built on the nine days to 26 November. A few things done well, in this order:

1. **D1 aloud, daily, with B2 as its 60-second version.** This is the highest-ROI prep in the pack: the objection that you have run one branch's log and have not worked in a contact centre will arrive in some form in all three rounds. Rehearse the two plain acknowledgments (F4, F8) until they are boring.
2. **G1 to G3 aloud with a timer.** Run the 20-minute case twice, structure first. The panel scores structure and reasoning over a "right" answer.
3. **Choose your real stories for C2 and F1 to F4.** Each value needs a real example from your life, or the honest branch. Decide now, not in the room.
4. **Settle the facts only you hold:** whether your complaints log fell under a regulator's rules (B3), what your spreadsheet counted and whether it was Excel (E1, E3). Send them to me and I will regenerate the affected rows.
5. **Write your own answers to A3 to A6** (pay, notice, location, reason for moving).

Everything else is insurance.

## Fit snapshot (shared across all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | presentation | Your sentence reaches the years in other terms: retail banking, the last three as a branch supervisor. Say it as it stands: "I've spent six years in retail banking, the last three as a branch supervisor." Nothing inspected stands behind it, so expect a probe on dates and roles |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [inferred] | discovery | Your sentence says formal complaints log; it does not show whether that log fell under a regulator's rules. Answer slot: the JD's word "regulated" makes a probe likely. If the log was governed by regulator rules, say which and what they required of you, in your own words; if it was not, or you are not sure how it was classed, say so plainly and stay with the log you handled |
| F3 | "Own the member complaints process end to end across branches and the contact centre" — JD (the branches part) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your words stay at the branch: "I handled the branch's formal complaints log." End to end across branches is the JD's wider step and the sentence does not reach it. Answer slot: if any of your complaints work reached beyond your own branch, say what and which part was yours; if none did, say so plainly and stay with the log |
| F4 | "Own the member complaints process end to end across branches and the contact centre" — JD (the contact centre part) | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | Your sentence says you built a monthly complaints spreadsheet; it does not say what it counted. Answer slot: the JD names volumes and resolution times, so expect a probe on what yours held. If it counted either, say how each was counted, in your own words; if it did not, say so plainly, say what it did hold, and name what you would add |
| F6 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | Your sentence says spreadsheet, not Excel. Answer slot: if it was in Excel, say so and describe what you built in it; if it was another tool, name it plainly and say how that carries over |
| F7 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your sentence has you training new tellers on the escalation script; the JD's coaching is of supervisors. Words: "I trained new tellers on our escalation script." Answer slot: if any supervisors were among those you trained or advised on escalations, say who and how; if none were, say so plainly and stay with the tellers |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap you stated: "I've never presented to anyone above regional level." Say it plainly, then how you would build toward it, as a plan and never as a past. Never a claim to presenting to senior leaders |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing either way. Answer slot: if you have worked with a digital or app team on something members use, say what and which part was yours; if you have not, say so plainly and say how you would start, as a plan |

No row is a gate: the JD states no term such as location, schedule, pay or a credential, and the four-plus years is experience, graded like any requirement.

## Grounding brief (from the 2026 strategy brief the recruiter sent)

The facts are as you gave them to me; I have not read the brief itself. It was published in July 2026, so about four months old today.

| Item | What the brief says, as you gave it | Where it is used | Provenance |
|---|---|---|---|
| Digital shift | move 40% of member service to digital channels by 2028 | D3, G1 | [grounded] |
| Branch consolidation | consolidate eight branches into five hubs over 2027 | H2, H3 | [grounded] |
| New product | launch a small-business lending product in Q1 2027 | A2 | [grounded] |
| Competition | the main competitive pressure is app-only banks | A2, D3 | [grounded] |
| Organisation | member-owned, about 900 staff (the JD's own description) | A2 | [grounded] |

Because the recruiter sent the brief to you, treat it as shared reading: bring one item from it to show you read it, then one view of your own with its limits (see H2).

# Round 1 — Recruiter, 30 minutes

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Conversational / Rapport | Friendly walk-through of your journey, motivation and logistics | High: a recruiter screen is mostly logistics and motivation in a friendly register, and the recruiter named a 30-minute conversation | Short arcs; treat casual questions as scored; ask the pay and format questions you need answered |
| B. Skeptic (light) | Knockout-style checks on the JD's main requirements, politely | Medium: the recruiter holds the JD, and your material states two gaps against it (F4, F8) | Say the plain acknowledgment once, add the plan, and move on without apologising |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your journey in banking." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Three beats in about 90 seconds, each a clause your sentences carry: six years in retail banking, the last three as a branch supervisor; handling the branch's formal complaints log and training new tellers on the escalation script; building the monthly complaints spreadsheet your regional manager uses. Close on why this role, in your own words; the material gives no reason of yours, so the pack supplies none | The opener of every screen, and the one place all three of your sentences meet; F1, F2 and F5 are the rows it draws on. EXP because it tests whether the sentences hold up when spoken |
| A2 | "What drew you to Ashgrove?" | CO | [grounded] | Choose one thing Ashgrove has published that you would genuinely want to work on: one of its four values or one line of the 2026 strategy, named in its own words. Then say why it matters to you, in your own words; the material gives no reason of yours, so the pack supplies none. Do not recite the whole brief | Motivation is the screen's standard probe, and the values and brief give a published anchor. CO because the strong answer shows homework, not enthusiasm |
| A3 | "What salary are you looking for?" | JD | [generic] | Logistics slot. Give your own figure or range, or ask for the role's band first. The material gives you no figure and the JD states none, so the pack supplies none | First of four logistics rows for a recruiter screen; JD because pay is a term of the listed job. Generic because it is a pattern, not a fact about Ashgrove |
| A4 | "What's your notice period?" | JD | [generic] | Logistics slot. Give your actual notice period, in your own words. The material states none, so the pack supplies none | Second logistics row; JD because notice is a term of the job on offer |
| A5 | "Where would you be based, and are you comfortable travelling between sites?" | JD | [generic] | Logistics slot. Say where and how often you can work, in your own terms. The JD names no office pattern; it places the role across branches and the contact centre, so the question is a fair one to expect | Third logistics row; JD because location is a term of the job |
| A6 | "What's prompting a move now?" | EXP | [generic] | Logistics slot. Give your actual reason, in your own words. The material states none, so the pack supplies none. Speak about what you are moving toward | Fourth logistics row, the reason for moving. EXP because it tests consistency between your story and your move |
| B1 | "The role asks for four or more years in financial-services customer operations. Where do yours show?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Say it as it stands: six years in retail banking, the last three as a branch supervisor. Stop there and let them ask for detail; answer detail from those roles, in your own words | F1 is the row this requirement lands on; JD because it scores a stated requirement directly |
| B2 | "The role covers branches and the contact centre. You haven't worked in a contact centre, so how do you see that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The 60-second version of D1. Pause, then concede plainly: "I've never worked in a contact centre." Then a plan in your own words for how you would learn it, said in the future tense. Then what you have, at its own scope: you handled the branch's formal complaints log and trained new tellers on the escalation script | F4 is the likeliest knockout in a screen and your own words supply the premise. JD because it scores the stated scope of the role |
| B3 | "The JD asks for experience handling regulated complaints. What have you handled?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say what your sentence says: you handled the branch's formal complaints log. Answer slot: if that log was governed by a regulator's rules, say which and what they required of you, in your own words; if it was not, or you are not sure how it was classed, say so plainly and stay with the log | F2 is the thin row behind the JD's "regulated"; rehearsing the honest branch now keeps you from stretching it later. JD because the premise is the JD's |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "Is the complaints process today run separately in branches and the contact centre, or already under one owner?" | The JD gives this role both; the answer shows where the seam you would own actually is |
| R1.2 | "Can you tell me anything about the 20-minute case: branch-based, contact-centre-based, or both?" | The recruiter named the case but not its setting; one answer tunes the whole G bank |
| R1.3 | "What is the salary band for the role?" | Gives you a number to react to if A3 is asked before you have named a figure |

# Round 2 — Head of Member Services, your future manager, 45 minutes

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| C. Values / Behavioural | "Tell me about a time…" questions tied to the JD's duties | High: the recruiter described the round as mostly behavioural | Pick real examples; "we" for context, "I" for what you did; where nothing comes to mind, use the honest branch |
| D. Skeptic | Quiet probing of the gaps: contact centre, senior presenting, digital | High: a manager is buying capability and weighing the gaps, and your material states two (F4, F8) | Rehearse D1 until it is boring: hold, concede specifically, add the plan |
| E. Data-Driven Prober | Asks what your spreadsheet counted and how resolution times are defined | Medium: monthly reporting on volumes and resolution times is a named duty, and you built a monthly report | Know what you can and cannot say about how things were counted, and say plainly when you do not know |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you coached someone through a difficult escalation." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Your sentence has you training new tellers on the escalation script; start there and keep that scope. Answer slot: the JD's coaching of supervisors makes a probe on real cases likely. If you coached someone through an actual escalation, say what the case was and what part was yours; if the training stayed with the script, say so plainly and stay with the training | F7 is where the JD's coaching duty meets your material. JD because it scores a stated duty, in a behavioural shape |
| C2 | "Tell me about a time you kept hold of a member's problem until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The log is your anchor: you handled the branch's formal complaints log. Answer slot: Own the Fix says whoever finds the problem keeps hold of it until it is solved, so expect a probe on one case. If a case comes to mind where you stayed with it until it was resolved, tell it in your own words: what was wrong, what you did, how it ended. If none does, say so plainly and describe how you kept hold of the log | F2 is the nearest evidence for Own the Fix. VAL because the theme is the published value, in a behavioural shape |
| C3 | "Tell me about a time you worked with a digital or technology team to change something members use." | JD | [grounded] | Selection scaffold. Pick a time you worked with a digital or technology team on something members used: it needs a named change, your part in it, and what happened to members. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach it. The material gives no such story, so the pack supplies none | F9 is silent in your material, so the pack gives a selection scaffold, not a story. JD because the theme is the JD's digital-teams duty |
| C4 | "Tell me about a time you explained a complaints problem to someone more senior than you." | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I built the monthly complaints spreadsheet our regional manager uses." | Say it plainly first: "I've never presented to anyone above regional level." Then give the nearest thing your material carries, at its scope: you built the monthly complaints spreadsheet your regional manager uses. Answer slot: if you took its results to the regional manager yourself, say how that went in your own words; if it was sent and not presented, say so plainly and stay with what you built | F8 is a stated gap and this question presses on it; the nearest evidence is F5, which does not show presenting. JD because the theme is the JD's senior-leaders line |
| D1 | "You've handled your branch's complaints log and you haven't worked in a contact centre. This role owns the whole process across both. Convince me." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." "Never worked in a contact centre, and I've never presented to anyone above regional level." | **Highest-ROI prep in the pack.** Pause and restate. Hold what the sentences carry: you handled the branch's formal complaints log and trained new tellers on the escalation script; you built the monthly complaints spreadsheet your regional manager uses. Concede specifically: "I've never worked in a contact centre," and what you have sits at the branch. Follow-up one, "how would you learn the contact centre?": a plan in your own words, in the future tense. Follow-up two, "what if that team doesn't want a branch person leading?": hold your position, concede what you do not know, return to the quoted sentences at their own scope. Follow-up three, "what do you bring that a contact-centre person wouldn't?": answer only from those sentences. Answer slot: if any of your complaints work reached beyond your own branch, say what and which part was yours; if none did, say so plainly and stay with the branch | F3 and F4 together are the most predictable objection to this candidate, and it will arrive in some form in every round. JD because the premise is the stated scope; deepest rehearsal means the most follow-ups and a concession worded before it is asked for |
| D2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Choose the truer of the two you told me and say it in your own words: "I've never worked in a contact centre" or "I've never presented to anyone above regional level." Then say how you would close it, as a plan. Do not name a safe weakness to dodge these two | The Skeptic's standard question, and F4 and F8 are the answers your own material already gives. JD because it asks about the listed job |
| D3 | "40% of member service moves to digital channels by 2028, and this role works with the digital teams on self-service journeys. What in your background says you can?" | JD | [grounded] | Answer slot: if you have worked with a digital or app team on something members use, say what and which part was yours, in your own words; if you have not, say so plainly, then say how you would start, as a plan. The plan can begin from where complaints would arise in a self-service journey; hold your view with its limits | F9 is silent in your material and the brief makes it a live priority. JD because it scores the digital-teams duty; the premise is the JD's and the brief's |
| E1 | "Walk me through the monthly complaints spreadsheet you built. What did it count?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Start from your sentence: you built the monthly complaints spreadsheet your regional manager uses. Answer slot: the JD names volumes and resolution times, so expect a probe on what yours held. If it counted either, say how each was counted and the assumption you would defend least, before they ask; if it did not, say so plainly, say what it did hold, and name what you would add | F5 is where the JD's reporting duty meets your only quoted reporting work. EXP because it tests what you actually built |
| E2 | "How would you define a complaint's resolution time, and what could make it misleading?" | JD | [generic] | Think aloud. Where the clock starts: when the member raised it, when it was logged, when it reached you. Where it stops: when the fix was made, when the member was told, when the member accepted it. Whether time spent waiting on the member counts. Whether you report an average or the spread. Name the assumption you would defend least, your start point, before they do. This rehearses a definition, not your past. Answer slot: if you tracked a resolution time yourself, say which start and stop points you used; if not, say so plainly and say how you would define it | The JD names resolution times, and a metric question needs the weakest-assumption move. JD because it scores the reporting duty; generic because it makes no claim about this employer |
| E3 | "How comfortable are you with Excel reporting? What have you built?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say what your sentence says: you built the monthly complaints spreadsheet your regional manager uses. Answer slot: if it was in Excel, say so and describe what you built in it, in your own words; if it was another tool, name it plainly and say how that carries over | F6 is the row; your sentence says spreadsheet, not Excel, and the honest branch is the safer one to have ready. JD because it scores the stated tool requirement |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "What would tell you, at 90 days, that this role is working?" | Turns the monthly reporting duty into the manager's own success measure |
| R2.2 | "Where do complaints reach you today, and what is hardest to see from where you sit?" | Shows you are thinking about the reporting view the JD asks you to own |
| R2.3 | "Which part of the shift to digital do you expect to reach complaints first?" | Ties the role to the brief's 40% digital goal without reciting it |
| R2.4 | "What would you most want a new lead from outside the contact centre to learn fast, and who could help me with it?" | Takes the F4 gap into a practical conversation rather than leaving it as an objection |

# Round 3 — Panel of two branch managers, 60 minutes, with a 20-minute case

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| F. Values / Behavioural | One scored question per published value, with follow-ups | High: the recruiter said the panel scores against the four values | Map a real example to each value, or use the honest branch; do not recite the slogans |
| G. Case / Strategist | The 20-minute escalation case, with follow-ups on structure | High: 20 of the 60 minutes are the case, per the recruiter | Clarify first, then objective, approach, metrics, risks; think aloud; challenge one premise respectfully |
| H. Peer Evaluator | Where the role meets the branches: what you need from them, how you would disagree | Medium: the panel members manage branches whose supervisors you would coach. Names are unassigned, so this rests on their roles | Reciprocity: what you bring their branches, and principles for the seam rather than pretending to know it |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] | Selection scaffold. Pick a decision where the member's side and the bank's side pulled apart: it needs a named decision, what the bank-side choice would have been, and what yours cost or changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. The material gives no such story, so the pack supplies none | Members First, Always is the first value on their page, and none of your quoted sentences carries a story for it. VAL because it scores the published value |
| F2 | "Tell me about a time a member, or a colleague, needed something explained twice. What did you do?" | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Plain Words says that if a member needs it explained twice, they wrote it wrong. Your sentence has you training new tellers on the escalation script; if the story sits there, begin with that sentence only. Answer slot: if a teller needed something explained twice and you changed how you explained it, say what you changed, in your own words; if that did not happen, say so plainly, then give the nearest thing your material carries or how you would write it plainly | F7 is the nearest quoted ground for Plain Words and says nothing of rewriting. VAL because it scores the published value |
| F3 | "You built the monthly complaints spreadsheet. Tell me about a time the numbers said one thing and a member or a branch needed another." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Neighbours, Not Numbers pulls against the work of reporting, and the panel may press on that. Start from your sentence: you built the monthly complaints spreadsheet your regional manager uses. Answer slot: if there was a time the numbers pointed one way and a member or branch needed another, say what happened and what you did, in your own words; if there was none, say so plainly, then say how you would keep a branch's situation in view alongside the figures | F5 is your only quoted reporting work, and reporting is where the value is likeliest to bite. VAL because it scores the published value |
| F4 | "Tell me about a time you found a problem that sat in someone else's area. What did you do?" | VAL | [grounded] | Selection scaffold. Own the Fix says whoever finds the problem keeps hold of it until it is solved. Pick a time you found a problem that was not yours: it needs the problem, who it belonged to, what you did to keep hold of it, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. The material gives no such story, so the pack supplies none | Completes the four values, and C2 covers its complaint-log form. VAL because it scores the published value |
| G1 | "A member first raised a complaint at a branch, then rang the contact centre twice and was told something different each time. They now say they will leave Ashgrove. How do you handle it, and what changes afterwards?" | CASE | [generic] | Structure it aloud. Clarify first: what has the member been told and by whom, what do they want, is anything time-bound. Objective: one owner for the member and one clear answer, today. Approach: contact the member, reconcile the record across both channels, then decide. Metrics: how long it took and whether the member was satisfied. Risks: the member told a third version. Afterwards: what you would change in how the branch and contact centre share a record. Challenge one premise respectfully. The panel's case will differ; this rehearses the structure, and the guidance makes no claim about your past | Your material cannot be the answer to a live case; structure is what is scored. CASE because it is a live problem from the role; generic because it is a pattern for the problem, not Ashgrove's case |
| G2 | "The supervisor on that branch says the script doesn't fit this case and wants to handle it their own way. What do you do?" | CASE | [generic] | Ask for their read first, aloud. Hold the part that is not negotiable: the member hears one answer and the record is complete. Concede where the script may be wrong, and carry that back into how it is taught. Name what you would need to know before deciding: what the script says and where it stops. This rehearses coaching a supervisor without taking the case from them; it claims nothing about your past | Coaching supervisors on escalations is a stated duty and the panel manages supervisors. CASE because it extends the live problem |
| G3 | "Sixty seconds: what do you tell senior leaders about this one case?" | CASE | [generic] "Never worked in a contact centre, and I've never presented to anyone above regional level." | A time-boxed summary in plain words: what happened, what we did, what has changed, what we need from them. Pause before answering; do not hurry. This rehearses a format, not your past; the material states that you have never presented above regional level, and the case is where you show how you would explain a problem to leaders | F8 is a stated gap and the case is a safe place to show the skill. CASE because it is a time-boxed live task; the pressure comes from the clock |
| H1 | "What would you need from us as branch managers, and what would we get from you?" | CASE | [generic] "6 years in retail banking, the last 3 as a branch supervisor." | Reciprocity first: what branches get from you, such as a clear monthly view of their own complaints. Then principles for the seam, not a claim to know it: who keeps hold of the member until it is solved, who decides when a complaint is closed, how you disagree. One honest line from your own material: you spent the last three years as a branch supervisor | The panel prices what the hire costs and contributes to their branches. CASE because it is a live seam problem; generic because it needs no claim about your past beyond the quoted line |
| H2 | "Every branch is part of its town, and eight branches are becoming five hubs over 2027. How do you keep both true for complaints?" | CO | [grounded] | Bring one item from the brief to show you read it, then your own view with its limits. Treat the question as the tension it is; do not speculate on which branches change. Ask what members and staff in affected towns will need. Thesis to test aloud: complaints are a signal of where a change hurts, so keep a human route open as digital grows; concede that you lack the data to size it. Anti-pick: do not push every complaint into self-service | Both the brief and the values name this tension and the panel will feel it. CO because it needs the company's current strategy; the guidance differentiates from a text any prepared candidate has |
| H3 | "A branch manager and you disagree about whether a complaint is closed. What happens?" | CASE | [generic] | Say what you would ask first and what decides it: the member's confirmed outcome, not either party's view. Show spine and tact: hold the position on what counts as closed, and concede what the branch knows that you do not. Say how you would stop the disagreement recurring | Disagreement with equals is what the peer persona scores. CASE because it is a live problem; it asks about no past |

## Values cheat sheet

| Value (official name) | Working meaning | Mapped story or scaffold | Questions |
|---|---|---|---|
| Members First, Always | Decisions are made from the member's side of the counter | Selection scaffold: pick a decision where member and bank sides pulled apart, with a named decision and cost. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | F1 |
| Plain Words | If a member needs something explained twice, the wording was wrong | F7: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Slot: if a teller needed something explained twice and you changed how you explained it, say what; if not, say so plainly | F2 |
| Neighbours, Not Numbers | Every branch is part of its town, not a line in a report | F5: "I built the monthly complaints spreadsheet our regional manager uses." The value pulls against reporting; slot: if the numbers and a branch's need ever pointed apart, say what you did; if not, say so plainly | F3, H2 |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F2: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Slot: if one case comes to mind that you stayed with to the end, tell it; if none does, say so plainly and describe how you kept hold of the log | C2, F4 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "What could a new complaints lead do in their first month that would genuinely help your supervisors?" | Reciprocity for a peer panel: it asks what you can give, not only what you need |
| R3.2 | "When an escalation goes badly in your branch, what usually gets in the way?" | Shows you want to learn the branch's view before designing anything |
| R3.3 | "How are branches hearing about the move to hubs, and what would you want complaints reporting to tell you through it?" | Connects your reporting duty to the strategy and to their stake in it |
| R3.4 | "What do you hope this role changes for your branch in its first year?" | Lets the panel name their own success measure |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| "4+ years in financial-services customer operations" | A1, B1 |
| "experience handling regulated complaints" | B3 |
| "Own the member complaints process end to end across branches and the contact centre" | B2, D1, G1 |
| "report monthly on complaint volumes and resolution times" | E1, E2 |
| "coach branch supervisors on escalations" | C1, G2, H1 |
| "work with digital teams on self-service journeys" | C3, D3 |
| "confident presenting to senior leaders" | C4, G3 |
| "comfortable with Excel reporting" | E3 |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Handled regulated complaints | Inflated form of F2 | F2's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: your material says a formal log, not that it fell under a regulator's rules |
| Owned the complaints process end to end across branches | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says the branch's log and the training, not the process across branches |
| Has worked in a contact centre | Negative you stated, F4 | The plain acknowledgment F4 gives: "I've never worked in a contact centre." No slot |
| Presented to senior leaders | Negative you stated, F8 | The plain acknowledgment F8 gives: "I've never presented to anyone above regional level." No slot |
| Coached branch supervisors on escalations | Inflated form of F7 | F7's quote at its own scope: "I trained new tellers on our escalation script." The limit is the pack's observation: your material says tellers, not supervisors |
| Reported complaint volumes and resolution times monthly | Inflated form of F5 | F5's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." The limit is the pack's observation: your material does not say what it counted |
| Built Excel reports | Inflated form of F6 | F6's quote at its own scope. The limit is the pack's observation: your material says spreadsheet, not Excel |

## Sources

**Provided documents:** the JD as pasted; Ashgrove's four values as pasted, copied by you on 17 November 2026 from ashgrovecu.org/about/values; the recruiter's email on the three rounds; the 2026 strategy brief of July 2026 as you summarised it; your own account of your background. No `tuesday-dossier.md` was present. No search or fetch was sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | Could not have moved the values cheat sheet: the pasted values already supply the four names and their wording |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | Could not have moved the loop: the recruiter's email already gives three sessions, who runs each, the 20-minute case and the values scoring |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | Could not have moved the CO and CASE rows: the July 2026 brief you provided, under six months old, already supplies the priorities |
| 4. interviewer name and company | n/a | No name was given, only roles, so there was no query to form; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Interviewers' names, once assigned → an interviewer read, persona weights from their public footprint, and a reverse question tied to their own path
- Your CV or role history → the discovery rows (F2, F5, F6, F9) become grounded with quoted lines in place of slots
- Plain statements of the facts behind the answer slots (whether your complaints log was governed by regulator rules; what your spreadsheet counted and whether it was Excel; whether any supervisors were among those you trained; any digital-team work) → F2, F3, F5, F6, F7 and F9 regenerate and the matching bank cells become story maps
- The recruiter's answer on the 20-minute case's setting, branch or contact centre, and whether there is a pre-read → the G bank tuned to the real case
- The strategy brief itself, pasted → the grounding brief checked against the document instead of your summary
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → interviewers' public footprint once names exist, role-family loop reports, recent organisation context; the gain is smaller here because the brief is already in hand
- A `tuesday-dossier.md` from job-underwriter → verified evidence and a named top objection in place of the one this pack infers; the pack stands without it
