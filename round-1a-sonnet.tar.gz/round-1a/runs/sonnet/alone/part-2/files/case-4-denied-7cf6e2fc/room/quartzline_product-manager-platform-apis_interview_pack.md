# Interview pack: Product Manager, Platform APIs at Quartzline

- **Round:** one 45-minute conversation with the hiring manager, Thursday. Hiring manager's name not given.
- **Built from:** your pasted tuesday-dossier.md (version 1.1, dated 2026-08-14) and nothing else. Web research was refused by this host, so company-specific material is labeled `[generic]`.
- **Highest-ROI prep in this pack:** A1. The dossier's underwriter named that objection; it was not inferred here.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your claims survive scrutiny and attribution is honest |
| JD | The stated responsibilities and requirements, gaps included |
| CO | Knowledge of the company and its strategy |
| CASE | Structure and reasoning on a live problem from the role |

Provenance labels: `[grounded]` traces to your dossier or a document you gave; `[inferred]` is this pack's derivation, named; `[generic]` is a pattern with no claim about you or Quartzline. Where a Provenance cell holds a quote, the guidance claims nothing about your past beyond that quote. An answer slot is an instruction for the interview, not a question for you now.

## Prep triage

| Order | Do | Where |
|---|---|---|
| 1 | Say A1 aloud until it is boring: concede, hold the quote, ramp plan, three follow-ups | A1, then F1 as the 60-second version |
| 2 | Write your own answers to the four defend-the-number slots for the 30+ integrations | C1, F2 |
| 3 | Rehearse the roadmap case and the disagreement-with-a-squad-lead case, structure first | B4, E1 |
| 4 | Choose which two reverse questions you will ask, and in what order | Reverse questions 1 and 2 |
| 5 | Time your 90-second opening arc | D1 |

Everything else in this pack is insurance.

## Fit snapshot

No gate rows: the dossier lists no hard gates, and none of R1 to R5 is a term the candidate meets or does not. Requirements are quoted from the dossier's role_profile. F1, F3, F4, F5 and F6 are R1 to R5, with the dossier's priorities (R1 and R2 must_have, R3 and R4 important, R5 preferred); F2, F7, F8 and F9 are role_profile responsibilities.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [grounded] | transferability | The underwriter's positioning: adjacent, never PM experience. Words at the quote's scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Plain acknowledgment, sourced to the dossier prohibited_claims field: "I haven't held a product manager title." The limit, as the pack's observation: your verified entries show integration leadership, carry no product-management role and carry no tenure figure, so no years figure appears anywhere in this pack |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibilities | none given | none | [grounded] | capability | The dossier records this as an acknowledge_gap area (R1 sub-claim, confidence none), so no bridge. Words, sourced to the dossier acknowledge_gap and prohibited_claims fields: "I haven't owned a product roadmap." Then a ramp plan said as a plan: who decides what between the PM and the two squad leads, and how the current roadmap was set. Never a claim to roadmap work |
| F3 | "Shipped API or platform products" — dossier role_profile R2 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | low | [inferred] | transferability | The dossier names R2 high priority but gives it no allowed strategy, so this row follows the evidence: adjacent work. Confidence grades how far the quotes reach this requirement; the quotes are high confidence for what they say. Words at their scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs" and "I wrote the internal integration playbook my team uses." The limit, as the pack's observation: the quotes show integration delivery on the vendor's APIs and do not show building or releasing an API product. Answer slot: the requirement's emphasis on delivery makes a probe on go-live likely. If any go-live was yours to call, say which and how you decided, in your own words; if there was no such decision, or it was not yours, say so plainly and stay with the integrations you led |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [inferred] | discovery | The quote touches REST APIs and architecture without showing whether API docs or schemas were read, written or reviewed. Answer slot: the requirement names API docs and schemas, so expect a probe on them. If you read, wrote or reviewed either in those integrations, say which and what you did with it, in your own words; if you did not, say so plainly and stay with the REST integrations you led |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4 | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence; "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | medium | [inferred] | transferability | Words at the first quote's scope: "I ran quarterly roadmap-input sessions feeding client evidence to product." Caveat: confirmed with limited inspectable proof, so expect a probe and volunteer the limit before it is extracted. The limit, as the pack's observation: the sentence says the sessions fed client evidence to product and does not say what product did with it. Engineering and sales appear in neither quote. Answer slot: if you worked with either on an integration, say how and what part was yours; if not, say so plainly and stay with clients and product |
| F6 | "Agile delivery experience" — dossier role_profile R5 | none given | none | [grounded] | discovery | The dossier's allowed strategy is clarify. Answer slot: the requirement's own words are the likely probe. If you have worked in agile delivery, say how and with whom, in your own words; if you have not worked that way, say so plainly, and say what you would want to confirm about how Quartzline defines it |
| F7 | "Run discovery with integration partners" — dossier role_profile responsibilities | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | medium | [inferred] | transferability | The quote carries scoping and requirements for client integrations; the pack's observation is that it does not say whether that was partner discovery for a product. Answer slot: if the scoping involved open questions to a client about what they needed, say how you ran it; if there was no such step, or it was not yours, say so plainly and stay with the integrations you led |
| F8 | "Write specs and drive delivery with two engineering squads" — dossier role_profile responsibilities | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | low | [inferred] | discovery | The quotes touch requirements and delivery stages without showing specs or work with an engineering squad. Answer slot: if you wrote specs or requirement documents for an engineering team, say which and for whom; if you did not, or they were not yours, say so plainly and stay with the playbook you wrote and the integrations you led |
| F9 | "Define and track adoption metrics" — dossier role_profile responsibilities | none given | none | [grounded] | discovery | Silence, not a stated absence. Answer slot: if any integration uptake was counted, say what and how; if none was, say so plainly, and say what you would measure first |

## Persona table

Loop reading: your words establish this session, one 45-minute conversation with the hiring manager. Nothing here assumes the rest of the loop, and no values-style round is detected, so there is no values cheat sheet.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Quiet, persistent probing of the missing PM title and roadmap | 5 questions. Hiring-manager prior puts Skeptic first; the dossier names an objection that is Skeptic-shaped | Rehearse A1 until boring; concede in the dossier's sourced words, hold only the quotes, ramp plan as a plan |
| Case/Strategist (B) | Live problems on the actual roadmap: partners, two squads, adoption | 5 questions. Hiring-manager prior puts Case second; the JD responsibilities are all decisions to reason through | Clarify, objective, segmentation, approach, metrics, risks; ask who decides between PM and squad leads before answering |
| Data-Driven Prober (C) | Line-by-line on the dossier's three quoted claims | 3 questions. The 30+ figure is a headline number; the roadmap-input sessions entry is medium confidence | Answer the four defend-the-number slots in your own words; say plainly what you do not know |
| Conversational (D) | Opening arc, how you read an API doc, what you know about the company | 3 questions. A 45-minute round opens and closes conversationally and these questions are still scored | A 90-second arc built only from the quotes; read what Quartzline publishes yourself |
| Peer Evaluator (E) | Seam between you and the two squad leads, credit across teams | 2 questions. The interviewer is a manager not a peer, but the JD makes the squad seam central | Propose seam principles, do not pretend to know the seam |
| Pressure (F) | Time-boxed challenges to the same objection | 2 questions. No interviewer signal either way | Pause, restate, hold through two follow-ups, concede specifically |
| Values/Behavioral (G) | Open prompts about hard conversations and customer-first choices | 2 questions. No values round detected and no published values read | Selection scaffolds ending in the honest branch; no story supplied |

## Question banks

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence. Negatives sourced to the dossier prohibited_claims field: "Having held a product manager title or role" and "Having owned a product roadmap" | The deepest rehearsal in the pack. One: concede first, in the sourced words: "I haven't held a product manager title and I haven't owned a roadmap." Two: hold only what the quote carries: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Say it is adjacent work and let them judge how far it transfers; never call it PM experience. Three: a ramp plan, said as a plan: who decides what between you and the two squad leads, how adoption is measured today, how the current roadmap was set. Rehearse three follow-ups. (1) What would a PM with three years do better on day one: name one item from the JD's own list that you would be learning, plainly. (2) How long until you are at their level: answer slot, if you have an estimate you would stand behind, say it and what it rests on; if not, say what you would need to see in the first weeks to give one. (3) Why take the risk: return to the integrations you led and add nothing. Hold through two follow-ups, concede specifically on the third | The underwriter named this objection from evidence you confirmed; it is the question this candidate will most predictably face. JD because it scores the must_have R1 directly; F1 and F2 are the rows it presses |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] dossier acknowledge_gap area: "Owning a roadmap and prioritization authority (R1 sub-claim)"; dossier prohibited_claims: "Having set prioritization for an engineering squad" | Name it plainly from the JD's list: the roadmap. "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then the plan: your first conversations are with the two squad leads about how they prioritize today and where the PM's decisions start and stop. Do not reach for the roadmap-input sessions as cover; candor about a competency the interviewer owns beats a bluff | Skeptic stem aimed at F2, the one row with no evidence. JD because it scores the roadmap responsibility; the honest-ramp answer is the only one that survives a follow-up |
| A3 | "The role asks for API or platform products shipped. Walk me through the work of yours that is nearest to that." | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | Tell the quote in your own words: the integrations, the 30+, and the stages it names. Say it is integration delivery on the vendor's APIs. Answer slot: if any go-live was yours to call, say which and how you decided; if there was no such decision, or it was not yours, say so plainly and describe how you took an integration from scoping to go-live | F3 is a must_have with adjacent evidence and no dossier strategy; this is the likeliest place the gap is probed. JD because it scores R2 |
| A4 | "What is your experience of agile delivery?" | JD | [grounded] | Answer slot, in the clarify form: the JD's wording is Agile delivery experience. If you have worked in agile delivery, say how and with whom, in your own words; if you have not worked that way, say so plainly, and say what you would want to confirm about how Quartzline defines it. Nothing about your past goes into this answer beyond what you say in the slot | F6 is a clarify area: the evidence may exist and was never established. Preferred, not must_have, so it earns one question. JD because it scores R5 |
| A5 | "Why this move, and why now?" | EXP | [generic] | Selection scaffold: your own reason, in your own words, in three parts: what draws you to a partner-facing API product, what you want to do that your current work does not, and why this role rather than another integration job. If a part has no honest answer yet, say so plainly rather than fill it. Nothing in your material supplies the reason, so the pack does not | The standing Skeptic question about motivation consistency; EXP because it tests whether your story holds together across the CV and the move. F1 is why it is asked |

### B. Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A partner says an authentication problem is blocking their launch, and the other squad needs the same engineering time for a different release. What do you need to know first, and how do you decide?" | CASE | [generic] | Clarify first: who decides between a partner escalation and a planned release, what the partner's launch date depends on, what the other release is worth. Objective, options, trade-off, what you would tell the partner and the squad leads, how you would know it worked. Challenge one premise respectfully. Say aloud that you would confirm decision rights before deciding. The case asks for no past, so the guidance makes none | The JD's two-squad delivery line, set as a live decision. CASE because it scores structure under a trade-off; F8 and F2 are why decision rights matter |
| B2 | "Partner API adoption is flat. Diagnose it." | CASE | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | First clarify what adoption means here and how it is measured today, which the dossier lists as unknown. Then segment partners, and use the stages of an integration from your own quote as a funnel to ask where partners drop out: scoping, requirements, architecture, UAT, go-live. That is a framing device, not a claim that you measured a funnel. Metrics, hypotheses, what you would test first | JD responsibility on adoption metrics, set as a diagnosis. CASE because the structure is scored; F9 is the row it covers |
| B3 | "Outline the first page of a spec for a new partner webhook. What goes on it?" | CASE | [generic] | Problem and partner need first, then who is affected, scope and non-scope, the API contract and schema questions to settle with engineering, how partners are migrated or informed, success metric, open questions. Say which parts you would write and which you would draft with the squad. No claim about specs you wrote; F8 stays a slot | JD line on writing specs, asked as a live exercise because no past is needed. CASE; also touches R3's schemas |
| B4 | "We have one quarter and two squads. How would you build the first roadmap?" | CASE | [generic] | Start by earning the inputs, not the answer: the current roadmap and why it looks as it does, squad capacity, partner evidence, decision rights. Then themes, a proposal, what you would validate before committing. If asked, the sourced acknowledgment from the dossier acknowledge_gap area: "I haven't owned a product roadmap, so here is how I would earn the first one." Say what you would not decide alone | The central responsibility, asked as a plan because you have no roadmap to point to. CASE; F2 is why the plan, not a past, carries the answer |
| B5 | "You will be running discovery with our integration partners. How would you start in your first month?" | CASE | [generic] | A plan: who you would speak to and in what order, what you would ask to learn rather than confirm, how you would record what you hear, how you would bring it to the two squads. Say what you would want from the hiring manager in week one. A plan is not a past; it claims no discovery you have done | The discovery responsibility, asked forward. CASE; F7 is why it is planned, not remembered |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 30+ integrations were counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | The figure attaches to integrations, so keep it there. Four answer slots, each in your own words: how they were counted; what the count is sensitive to; the assumption behind it you would defend least; which part was yours. If you do not know how something was counted, say so plainly. Say "led" only as far as you can back it through a second question | A headline figure; the dossier rates the claim high confidence and inspectable, so a prober checks it against that. EXP because it tests defensible attribution; F1 and F3 rest on it |
| C2 | "You wrote the integration playbook. What is in it, and who uses it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | Beats the quote states: you wrote it, your team uses it. Answer slot: say what it covers and how you know your team uses it, in your own words; if you do not know how often it is used, say so plainly. If you are free to share it, offering to walk through it end to end is the counter-strategy for a prober | The playbook is the one inspectable artifact in the dossier, so expect a request to see it. EXP; F3 draws on it |
| C3 | "You ran quarterly roadmap-input sessions. What did product do with the input?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | The dossier rates this medium: confirmed, limited inspectable proof. Volunteer the limit: "I ran quarterly roadmap-input sessions feeding client evidence to product." Answer slot: if you know what product did with the evidence, say what you know and how you know it; if you do not, or it was not yours to see, say so plainly and stay with the sessions you ran. Do not describe an influence you cannot back | The seam a prober finds first in a medium row. EXP; F5 is the row, and the hold is only the quote |

### D. Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" — all dossier verified_candidate_evidence | A 90-second arc with three beats, each a clause from the quotes: the integrations you led, the playbook you wrote, the sessions you ran. Then, in your own words, why this role. Include the limit yourself: "I haven't held a product manager title." That sentence is sourced to the dossier prohibited_claims field. Do not add a beat that no quote carries | The biography question sets the frame for everything after it; say the limit before they ask. EXP; F1 and F5 |
| D2 | "When you open a new API's docs, what do you look at first?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | Answer in your own words, from what you actually look at. Answer slot: if you read, wrote or reviewed API docs or schemas in those integrations, say which; if you did not, say so plainly and stay with the REST integrations you led | Casual register, scored question on R3; F4 is a discovery row, so nothing here is supplied |
| D3 | "What do you know about Quartzline, and why this team?" | CO | [generic] | Selection scaffold: say only what you have read yourself. The posting's own lines you can quote: "Own the roadmap for the partner-facing API platform" and "Run discovery with integration partners". If Quartzline publishes API docs or a changelog, read them before Thursday and say what you saw. If you found no public source, say what you read and what you would want to learn | Web research was refused, so the pack holds no company knowledge and supplies none. CO because it scores homework |

### E. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Suppose you and one of the two squad leads disagree about what ships next. How does that get settled?" | CASE | [generic] | Propose principles, not the seam: what each of you owns, what evidence each brings, who decides when you cannot agree. Ask first which decisions belong to the PM and which to the squad leads, since the posting does not say. If asked about your own authority, the dossier prohibited_claims field sources: "I haven't set prioritization for an engineering squad." | The squad-lead seam is an unknown in the dossier. CASE; F2 and F8 are why the answer is principles and a question |
| E2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | We for context, I for contribution: "I wrote the internal integration playbook my team uses." Answer slot: if others contributed to it, say who and what; if you wrote it alone, say so plainly. Never take credit for a share you cannot name | A peer-flavored credit probe; the playbook is the only quote that fits. VAL because it scores behavior rather than a skill; F3 |

### F. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over a PM who has done this job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence. Dossier prohibited_claims: "Having held a product manager title or role" | Pause, restate. One breath each: concede, sourced to the dossier field: "I haven't held a product manager title." Hold: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Plan: what you would learn first. Stop; do not fill the silence with more claims | A1 compressed into a time-box. JD because it scores R1; F1 |
| F2 | "That result — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | Hold the sentence: "I led 30+ end-to-end client integrations." Through two follow-ups, return to it. Answer slot: say which of the stages the quote names, scoping, requirements, architecture, UAT, go-live, were yours alone and which were shared, in your own words; if you do not know a share, say so plainly. Concede specifically, never on the core | The attribution probe the dossier's high-confidence claim invites. EXP; F1 and F3 |

### G. Values/Behavioral (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something they did not want to hear. It needs a named stake, what you said, and the relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | No values were published to the pack and none were found, so this is a persona stem. VAL; no fit row carries a story, so none is supplied |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a decision where a customer's need and an internal target pulled apart, what you chose, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | R4 names customers; this is the persona stem for it. VAL; F5 carries client work but no such decision |

### Requirement coverage

| Requirement | Questions |
|---|---|
| R1 3+ years product management experience | A1, A2, F1 |
| R2 Shipped API or platform products | A3, C1, F2 |
| R3 Technical fluency: API docs, schemas | D2, B3 |
| R4 Stakeholder management across engineering, sales, customers | C3, E1, E2, G2 |
| R5 Agile delivery experience | A4 |
| Own the roadmap | A2, B4 |
| Run discovery with integration partners | B5 |
| Write specs and drive delivery with two engineering squads | B3, B1, E1 |
| Define and track adoption metrics | B2 |

## Reverse questions

| # | Ask | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The dossier's first risk: decision authority is asserted in the posting and not evidenced. It reads as diligence and tells you whether the role is the one described |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | The dossier's second risk: adoption metrics are named as a responsibility with no baseline stated. The answer sizes the job you would be accepting |
| 3 | "What would a strong first 90 days look like, and where would you want me to learn fastest?" | It shows your ramp plan to the person who set the role, and it makes the plan theirs as well as yours |
| 4 | "What does each of the two squads own today, and where do they overlap?" | It surfaces the seam before you stand in it; it is also what E1 depends on |
| 5 | "Where do partners most often get stuck between first conversation and go-live?" | It uses the stages of integration work you already know, and it is the question a discovery-minded PM asks |
| 6 | "What would make you confident in six months that hiring from the integration side was the right call?" | It turns the A1 objection into the criteria they will use, and lets you hear them |

## Prohibited claims

Built before the banks; no cell above asserts, softens or implies any of these. The first three are the dossier's prohibited_claims, verbatim.

| Not coached | Basis | Honest form |
|---|---|---|
| prohibited_claims: "Having held a product manager title or role" | Dossier prohibited_claims | F1's quote at its own scope, plus the sourced acknowledgment: "I haven't held a product manager title." |
| prohibited_claims: "Having owned a product roadmap" | Dossier prohibited_claims, and the dossier acknowledge_gap area on R1 | "I haven't owned a product roadmap." No bridge, no slot; a ramp plan said as a plan |
| prohibited_claims: "Having set prioritization for an engineering squad" | Dossier prohibited_claims | "I haven't set prioritization for an engineering squad." No bridge, no slot |
| Shipped an API or platform product | Inflated form of F3 | F3's quotes at their own scope. The limit is the pack's observation: the quotes show integration delivery on the vendor's APIs |
| Shaped what product built | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation: the sentence says the sessions fed evidence to product, not what product did with it |
| Ran product discovery with partners | Inflated form of F7 | F7's quote at its own scope: scoping and requirements for client integrations |

## Sources

Provided: tuesday-dossier.md, pasted by the candidate: dossier_version 1.1, dated 2026-08-14, stage interviewing. Sections consumed: role_profile (the JD equivalent), handoff_to_mock_interview (verified evidence, weak areas with allowed strategies, the named objection, risks, employer questions, prohibited claims) and decision (context only). The dossier is dated 2026-08-14, so requirements and evidence are as of that date. Nothing else was supplied: no CV, no job posting, no interviewer profile.

Searches sent, all refused by this host with no results returned:

- Quartzline company values: refused
- Quartzline interview process product manager: refused
- Quartzline partner API platform strategy news: refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Would have themed VAL questions with Quartzline's named principles; G1 and G2 stay persona stems |
| 2. Quartzline interview process product manager | unavailable | Would have fixed the loop and persona weights from a documented process; weights rest on your words and the hiring-manager prior |
| 3. Quartzline strategy and recent news | unavailable | Would have grounded D3 and a CO case in current priorities; they stay generic |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative Product Manager Platform APIs JD | skipped | The dossier's role_profile fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Web search allowed in this host → Quartzline's published values, a documented loop and current strategy: D3 and the CO case stop being `[generic]`, G1 and G2 gain named principles, persona weights follow a source. A deeper pass would add up to 6 more searches and 2 more fetches over several more minutes.
- The hiring manager's name → an interviewer read, persona weights tuned to their public footprint, and a reverse question tied to their own path.
- Anything the recruiter said about Thursday: focus areas, or a presentation or case to bring → a graded-deliverable section, or reweighted personas.
- Your own answers to the answer slots in A3, A4, C1, C2, C3, D2, E2 and F2, stated here in this conversation → they are quoted into F3 to F8 and those rows regenerate with real evidence.
- Agendas or notes from the roadmap-input sessions → F5 and C3 can move from medium toward high.
- The current Quartzline posting → a check of R1 to R5 against the dossier dated 2026-08-14.
- An updated tuesday-dossier.md giving an allowed strategy for R2 and R3, which the current one leaves without one → bridge or clarify constraints that bind F3 and F4 and A3, D2.
