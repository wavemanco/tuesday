# Interview pack: Product Manager, Platform APIs at Quartzline

Round: hiring-manager conversation, 45 minutes, Thursday. Interviewer: the hiring manager, name not given. Built on `tuesday-dossier.md` (decision: conditional_go).

## How to use this pack

Personas describe how a question arrives; types describe what it scores. Guidance is scaffolding for your own words, not a script. Any sentence about your past rests on a quote in that row's Provenance cell, or it is an answer slot: an instruction to answer from your own experience, with an honest second branch if the practice was never yours.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your background claims survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | Structure and reasoning on a live problem from the role |

No VAL or CO questions appear: no values-style round is detected and no company research ran (see Sources).

## Prep triage

Sized to the two days before Thursday, which is an assumption; the order matters more than the length.

| Order | Do | Where | Why |
|---|---|---|---|
| 1 | Say the concede-bridge-ramp answer aloud until it is boring | A1, then E1 as the 60-second version | The underwriter named this as the objection you will meet |
| 2 | Rehearse the plain acknowledgment on roadmap and prioritization, with the ramp plan | A2, F6 | The one area with no bridge; it has to come out calmly |
| 3 | Say your three evidence lines, then the limit on each | C1, C3, D1 | The count and the sessions are where a prober looks for a seam |
| 4 | One case aloud, clarifying questions first | B1 | Hiring-manager rounds lean on live problems from the role |
| 5 | Pick your reverse questions | Reverse questions 1, 2, 3, 5 | Two of them settle risks the dossier could not |

Everything else is insurance.

## Fit snapshot

Requirements are the dossier's `role_profile` lines, quoted. Evidence is quoted from the dossier's `verified_candidate_evidence`. The dossier carries no `evidence_map`, so grades for R2, R3, R4 and the responsibilities are this pack's, from the evidence cells; the dossier's own grades are used for R1, R5 and the roadmap row.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — JD (dossier R1, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | low | [inferred] | transferability | Derived from the dossier's weak area for R1: allowed strategy bridge, positioned as adjacent and never as PM experience. The quotes carry client integration work and input-feeding work, not PM-titled work, and that limit stays in the answer. Words: "I haven't held a product manager title" (source: dossier prohibited_claims), then the first quote at its own scope: you led 30+ end-to-end client integrations of the vendor's REST APIs, scoping through go-live |
| F2 | "Shipped API or platform products" — JD (dossier R2, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | high | [grounded] | transferability | The dossier did not flag R2 as a weak area; this pack grades it from the quote, which carries integrations of the vendor's APIs through go-live, and the material does not show shipping an API or platform product itself. Answer slot: the JD's shipped-products line makes a probe on whether you shipped the API itself likely. If you shipped changes to the API or platform, say what and how, in your own words; if the work was integrating clients onto the vendor's APIs, or the shipping was not yours, say so plainly and stay with the integrations you led |
| F3 | "Technical fluency: API docs, schemas" — JD (dossier R3, important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | medium | [grounded] | discovery | The quotes touch REST APIs, architecture and a written playbook, and do not show whether API docs or schemas were part of the work. Answer slot: the JD names API docs and schemas, so expect a probe on what you worked from. If the integrations or the playbook involved API docs or schemas, say which and how, in your own words; if they did not, or that was not your work, say so plainly and stay with the integrations you led and the playbook you wrote |
| F4 | "Stakeholder management across engineering, sales, customers" — JD (dossier R4, important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [grounded] | transferability | The quotes name clients and product; neither names engineering or sales colleagues, and the second is confirmed with limited inspectable proof, so expect a probe. Answer slot: if engineering or sales colleagues were part of any of those integrations or sessions, say who and what you did, in your own words; if they were not, or it was not yours, say so plainly and stay with the clients and product you worked with |
| F5 | "Agile delivery experience" — JD (dossier R5, preferred) | none given | low | [grounded] | discovery | Dossier weak area for R5 ("Agile delivery inside a product org"), strategy clarify; no quote speaks to it. Answer slot: the JD lists agile delivery experience, so expect a probe on how you worked with engineers. If you worked in sprints or a similar rhythm, say how, in your own words; if you never worked that way, say so plainly and say what you would want to confirm about how the two squads define it |
| F6 | "Own the roadmap for the partner-facing API platform" — JD (dossier role_profile responsibilities) | none given | none | [grounded] | capability | Dossier weak area "Owning a roadmap and prioritization authority (R1 sub-claim)", strategy acknowledge_gap, plus prohibited_claims. Words: "I haven't owned a product roadmap", then a plan and never a past: in the first weeks, learn which roadmap decisions sit with this role and which with the squad leads. Nothing is added to make the gap feel smaller, and no bridge is coached here |
| F7 | "Define and track adoption metrics" — JD (dossier role_profile responsibilities) | none given | none | [grounded] | discovery | No quote speaks to it, and the dossier notes no adoption baseline is stated. Answer slot: if you counted or reported adoption of anything, say what was counted and how, in your own words; if you did not, say so plainly and say what you would measure first, as a hypothesis until the baseline is confirmed |
| F8 | "Run discovery with integration partners" — JD (dossier role_profile responsibilities) | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [grounded] | transferability | The quote carries feeding client evidence to product, which is adjacent to discovery and not the same work, and it is confirmed with limited inspectable proof. Answer slot: if the sessions or your scoping work involved learning what clients need, say how, in your own words; if that was not the work, say so plainly and stay with the sessions you ran |
| F9 | "Write specs and drive delivery with two engineering squads" — JD (dossier role_profile responsibilities) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [inferred] | discovery | The quote lists requirements and architecture as stages of integrations you led, and does not show who wrote what or who built from it. Answer slot: if you wrote requirements that engineers built from, say what and how, in your own words; if they were written elsewhere or by others, or there was no such document, say so plainly and stay with the integrations you led |

## Persona table

Weights rest on this skill's relationship priors, adjusted by the dossier; the loop is the one session you described, not a documented Quartzline process.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (5 questions, bank A) | Quiet, persistent probing of title, roadmap and why-now | Highest. Prior for a hiring manager is Case plus Skeptic; the dossier names a specific objection and three weak areas (F1, F5, F6) | Concede first, bridge at the quotes' scope with the limit named, then a ramp plan; rehearse A1 until boring |
| Case / Strategist (5, bank B) | Live problems from the role: onboarding, adoption, a spec, a squad conflict | Equal top. The JD's responsibilities are discovery, specs, delivery with two squads and adoption metrics, which are case material | Clarify, objective, segments, approach, metrics, risks; think aloud; ask for the adoption baseline the dossier lacks |
| Data-Driven Prober (4, bank C) | Walks the 30+ count, the playbook, the sessions | Mid-high. Verified evidence holds one figure and one medium-confidence item | Know what you can say about how the count was made and say plainly what you do not know; volunteer the sessions' limit |
| Conversational (3, bank D) | Biography opener, then casual JD topics | Mid. A 45-minute conversation has an opening; casual questions are still scored | A 90-second arc built only from three quoted lines |
| Pressure (2, bank E) | Time-boxed challenge of the A1 objection | Low. No stress-style signal in the material | Pause, restate, hold through two follow-ups, concede only what is specific |
| Peer Evaluator (2, bank F) | Seam between you and the squad leads | Low. The squad leads are not stated to be in this session, but the JD's authority claim is the open question | Offer seam principles, not claimed authority; ask which decisions are yours |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | The highest-ROI rehearsal in the pack, and the underwriter named this objection. Concede first, in plain words sourced to the dossier's prohibited_claims and its acknowledge_gap area: you haven't held the PM title and you haven't owned a roadmap. Then bridge at the quotes' scope, as adjacent work: you led 30+ end-to-end client integrations of the vendor's REST APIs, scoping through go-live, and you ran quarterly roadmap-input sessions feeding client evidence to product. Name the limit before it is asked for: that is integration and input work next to the PM job, not the PM job. Follow-up 1, what did you decide about what got built: return to the quotes; the answer on roadmap and prioritization is the concession already given, and nothing is added. Follow-up 2, so the experienced PM is the safer hire: concede that on roadmap ownership and prioritization that PM has done what you have not, then close on the ramp, which is learning in the first weeks which decisions sit with this role and which with the squad leads. Hold the bridge through both; fold nothing you cannot back | F1 and F6 are the widest gap and the one the underwriter expects to be asked; JD because it scores R1 directly |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Owning a roadmap and prioritization authority (R1 sub-claim)" — dossier acknowledge_gap area | Choose the gap the underwriter found rather than a safe one. Say it plainly: you haven't owned a roadmap, and you haven't set prioritization for an engineering squad (sources: the acknowledge_gap area above and prohibited_claims). Then the ramp plan, said as a plan: in the first weeks, learn which roadmap decisions sit with this role and which with the two squad leads, and how adoption is measured today. No bridge and no story here; the underwriter looked and found none, and a bridge invented live is how a candidate gets caught. Stop after the plan and let them respond | F6 is the capability row; the Skeptic's own stem lands exactly on it, so a calm answer here protects the rest of the interview |
| A3 | "The JD asks for shipped API or platform products. What have you shipped?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Say what the quote carries, in your own words: you led 30+ end-to-end client integrations of the vendor's REST APIs, scoping through go-live. Answer slot: the JD's shipped-products line makes a probe on whether you shipped the API itself likely. If you shipped changes to the API or platform, say what and how; if the work was integrating clients onto the vendor's APIs, or the shipping was not yours, say so plainly and stay with the integrations you led. Do not call the integrations product launches | F2 is a must-have and the dossier did not grade it, so this is where an unrehearsed seam would show; JD because it scores R2 |
| A4 | "Tell me about a time you delivered inside an agile cadence with an engineering team." | JD | [grounded] "Agile delivery experience" — dossier role_profile requirement R5 | No quoted sentence speaks to agile delivery, so shape the answer as a question back. Answer slot: the JD lists agile delivery experience, so expect a probe on how you worked with engineers. If you worked in sprints or a similar rhythm, say how, in your own words; if you never worked that way, say so plainly and say what you would want to confirm about how the two squads define it. Ask one clarifying question about their cadence rather than claiming familiarity | F5 is a discovery gap with the clarify strategy; JD because R5 is a stated requirement, preferred |
| A5 | "Why this move, and why now?" | EXP | [generic] | Your material says nothing about why you want the move, so this is a selection scaffold. Pick the JD responsibility that pulled you; the lines you can react to are "Run discovery with integration partners" and "Define and track adoption metrics". Say why in your own words, with one true reason you can defend under a second question. If no specific reason comes to mind, say so plainly, then say what you want to find out in this conversation | The Skeptic scores motivation consistency against the gap in F1; EXP because it tests whether the move reads as coherent with the work shown |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Partners tell us onboarding to the API platform is slow and some give up before their first successful call. You have two squads and one quarter. What do you need to know first, and what would you do?" | CASE | [generic] | No claim about your past is needed. Clarify before structuring: how onboarding and adoption are measured today and the current baseline, which partner segments are affected, and what giving up looks like in the data. Then objective, segments, options, a first metric offered as a hypothesis and flagged for confirmation, risks, and what you would ask each squad lead for. State assumptions aloud and challenge one premise respectfully | F7 and the dossier's unknown on how adoption is measured; CASE because it is a live problem from the role |
| B2 | "Adoption of a partner-facing endpoint has been flat for two quarters. Diagnose." | CASE | [generic] | Separate a measurement problem from a discoverability problem (docs, schemas), a fit problem and a partner-readiness problem, name the first data you would pull, and say you would confirm the baseline before trusting any trend. No claim about your past | F7 and F3; CASE with JD content because it exercises adoption metrics and API docs |
| B3 | "Two partners want conflicting changes to the same API, and one squad lead says it will push their committed work. Walk me through how you decide." | CASE | [generic] | Offer a decision principle, not authority you have not been shown to have: gather the evidence behind each request, size the impact on each partner, bring both to the squad lead with the trade-off, and ask who decides at which threshold. The dossier flags authority over the squads as unverified, so say how you would find out. Present it as how you would work, never as something you have done | F6 and the dossier's squad-authority risk; CASE because it asks about no past |
| B4 | "Outline a spec for a change to how partners authenticate to the API. What goes in it, and who needs to sign off?" | CASE | [generic] | Structure aloud: the problem and which partners it touches, the success measure, scope and non-goals, the API contract and schema changes, docs, migration and deprecation, rollout, risks, and which squad lead reviews what. Name one assumption you would check first. No claim about your past | F9 and F3; CASE with JD content because the JD lists writing specs with two squads |
| B5 | "You start Monday. How do you run discovery with integration partners in your first month?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Plan it aloud: who you would talk to, what you would ask, how it is recorded, how it reaches the squads. You may point to one thing at its own scope: you ran quarterly roadmap-input sessions feeding client evidence to product. That line is confirmed with limited inspectable proof, so expect a probe on what came of it. Answer slot: if you saw what happened to the evidence, say what, in your own words; if you did not see, or nothing visible came of it, say so plainly and stay with the sessions you ran. Do not present the sessions as a discovery practice you owned | F8 is adjacent, not direct; JD because "run discovery with integration partners" is a stated responsibility |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the 30+ integrations — how was that number counted?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Say what the quote says, in your own words: led, 30+, end-to-end, with scoping, requirements, architecture, UAT and go-live. The figure raises four slots, each in your own words: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which parts were yours. Where you do not know how something was counted, say that plainly. If some integrations were handed over or co-led, say which; if all 30+ were led by you, say so plainly. Add no client list, timeline or count you cannot repeat under a second question | F2 carries the pack's one headline figure, and a count is where a prober presses; EXP because it tests attribution |
| C2 | "Tell me about the integration playbook — what's in it, and how does your team use it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | This is the best-evidenced line in the dossier: confirmed, with the playbook provided, so offer to walk through it end to end. Say what the quote says: you wrote the internal playbook your team uses. Describe its contents as they actually are, and share only what you are free to share. Answer slot: if asked what changed because of it, say what you know, in your own words; if you do not know, or nothing measurable came of it, say so plainly and return to having written it | F3 rests partly on this line, and an inspectable artifact is the strongest thing you can offer a prober; EXP because it tests what was yours |
| C3 | "Tell me about the quarterly roadmap-input sessions you ran — what did you bring to them?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Medium confidence, confirmed with limited inspectable proof, so volunteer the limit before it is extracted. Say what the quote says: you ran quarterly sessions that fed client evidence to product. Expect the follow-up on what product did with it. Answer slot: if you saw what happened to the evidence, say what, in your own words; if you did not see, or nothing visible came of it, say so plainly and return to the sessions you ran. Keep the line between input and ownership: the sessions fed client evidence to product, which is input, not ownership of a roadmap (sources: prohibited_claims and the acknowledge_gap area) | F1, F4 and F8 all lean on this line, and the dossier marks it as the one to expect a probe on; EXP because it tests what the sessions actually were |
| C4 | "You'd define and track adoption metrics here. What have you counted before?" | JD | [grounded] "Define and track adoption metrics" — dossier role_profile responsibilities | Answer slot: the JD names adoption metrics, so expect a probe on what you have counted. If you counted or reported adoption of anything, say what was counted and how, in your own words; if you did not, say so plainly and say what you would measure first, as a hypothesis until the baseline is confirmed. Do not borrow a metric name you did not use | F7 has no evidence and the dossier lists the baseline as unknown; JD because it scores a stated responsibility |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the journey — how did you get to wanting this role?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc with three beats, each only what its quote states: you led 30+ end-to-end client integrations of the vendor's REST APIs; you wrote the internal playbook your team uses; you ran quarterly roadmap-input sessions feeding client evidence to product. Let the interviewer draw the inference. Close with why this role, in your own words, reacting to the JD line that pulled you. Do not narrate the move as a step up from a PM title you did not hold | F1 and F8: this is the biography question every conversational interviewer asks; EXP because it tests whether the story hangs together |
| D2 | "Tell me about a time you wrote requirements that an engineering team had to build from." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Pick one integration and keep to what the quote states: the end-to-end work included requirements and architecture stages. Answer slot: the JD's specs line makes a probe on who wrote the requirements and who built from them likely. If you wrote requirements that engineers built from, say what and how, in your own words; if they were written elsewhere or by others, or there was no such document, say so plainly and return to the integrations you led. Describe the engineers you worked with, not a squad you directed | F9 is a discovery gap on a stated responsibility; JD because it scores "write specs" |
| D3 | "Tell me about a time you had to bring engineering, sales and a customer to one decision." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | Selection criteria: choose an occasion where you can name who wanted what, what you did, and how it ended. Answer slot: the quotes name clients and product, not engineering or sales colleagues, so expect a probe on them. If engineering or sales colleagues were part of it, say who and what you did, in your own words; if they were not, say so plainly and tell the client-and-product version. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry | F4 is the stakeholder requirement with the thinnest named evidence; JD because R4 is stated |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a PM who has done this job for three years?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | The time-boxed form of A1: pause, restate the question, answer in three beats. Concession first: you haven't held the PM title or owned a roadmap (prohibited_claims; the acknowledge_gap area). Bridge at its scope: you led 30+ end-to-end client integrations of the vendor's REST APIs, and you ran quarterly roadmap-input sessions feeding client evidence to product. Ramp: the first weeks go to learning which decisions are this role's and which are the squad leads'. If interrupted, finish the beat you are on and repeat the concession in the same words. Hold, then concede specifically; claim nothing about outperforming anyone | F1 under time pressure; JD because it scores the same requirement as A1 |
| E2 | "The 30+ integrations — how much of that was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | Pause and anchor in the quotes: you led the integrations, and you wrote the playbook. Hold through two follow-ups by returning to that scope. Answer slot: if others worked on the integrations or the playbook, say who and what they did, in your own words; if you did it all, say so plainly. Concede only what is specific, and keep the core claim | F2 and F3; EXP because attribution is the probe |

### F. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "We have two squads, each with a lead. Where's the seam between what you would decide and what they would decide, and what happens when you disagree?" | JD | [generic] | No claim about your past. Offer seam principles rather than pretending to know the seam: the squad leads own how it is built, you bring partner evidence and the case for what matters, disagreements go to a named owner with the evidence in front of them. Then ask which decisions are meant to be this role's alone. Do not describe any past authority over a squad | F6 and the dossier's unverified squad-authority risk; JD because the JD asserts the authority |
| F2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | Answer slot: if others contributed to the integrations or the playbook, say who and how you credit them, in your own words; if it was only you, say so plainly. Keep "we" for context and "I" for what the quotes state you did | F2 and F3: peers price whether a hire shares credit; EXP because it tests attribution habits |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "3+ years product management experience" (R1) | A1, A2, E1, D1 |
| "Shipped API or platform products" (R2) | A3, C1 |
| "Technical fluency: API docs, schemas" (R3) | C2, B2, B4 |
| "Stakeholder management across engineering, sales, customers" (R4) | D3, F1, F2 |
| "Agile delivery experience" (R5) | A4 |
| "Own the roadmap for the partner-facing API platform" | A1, A2, B3, F1 |
| "Run discovery with integration partners" | B5, C3 |
| "Write specs and drive delivery with two engineering squads" | D2, B4 |
| "Define and track adoption metrics" | C4, B1, B2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The dossier's own question: the JD asserts squad authority without evidencing it, and the answer tells you what you would actually be accepting |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | The dossier's second question: the JD names adoption metrics but no baseline, so this reads as diligence and answers what you need to know |
| 3 | "Could you walk me through a recent trade-off between the two squads' priorities and how it was decided?" | Tests the unverified authority claim through a concrete case rather than an audit of the org chart |
| 4 | "How do the two squads hear from integration partners today?" | Ties to discovery as a stated responsibility and shows whether partner evidence has a route to the squads |
| 5 | "Where would you want to see me prove myself in the first ninety days?" | Invites the hiring manager to name their own doubt, which lets you answer it on your terms instead of guessing at it |
| 6 | "What would a strong first quarter look like in this seat?" | Gives you a success measure to rehearse against and shows you are thinking about delivery, not title |

## Prohibited claims

Taken from the dossier's `prohibited_claims`. The banks above are written against them, and a probe on any of them gets the honest form, not a stretch.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims | "I haven't held a product manager title." The limiting quote at its own scope: "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live". Position it as adjacent work, never as PM experience |
| Having owned a product roadmap | Dossier prohibited_claims, and the acknowledge_gap area on the R1 sub-claim | "I haven't owned a product roadmap." The limiting quote: "Ran quarterly roadmap-input sessions feeding client evidence to product", which is input and not ownership. Then the ramp plan; no slot and no bridge |
| Having set prioritization for an engineering squad | Dossier prohibited_claims, and the acknowledge_gap area on the R1 sub-claim | "I haven't set prioritization for an engineering squad." Then the ramp plan: learn which decisions sit with this role and which with the squad leads |

## Sources

Provided documents: `tuesday-dossier.md`, dossier_version 1.1, generated by job-underwriter, stamped 2026-08-14. Consumed: `role_profile` (requirements and responsibilities as the JD's lines; its unknowns inform the reverse questions), `handoff_to_mock_interview` (verified evidence, weak areas with allowed strategies, the named objection, risks, employer questions, prohibited claims). `decision` was read as context only. The dossier has no `evidence_map`, `evidence_state` or `risk_register`, so those were not consumed. Round type and relationship come from your own words: one 45-minute conversation with the hiring manager.

Searches sent, each refused by this host (no result returned):

- `Quartzline company values principles` — refused
- `Quartzline interview process product manager platform APIs` — refused
- `Quartzline partner API platform strategy news` — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Every call was refused. It would have fed a values cheat sheet; none is built, and no values-style round is detected |
| 2. `Quartzline interview process product manager` | unavailable | Every call was refused. It would have fixed persona weights on a documented loop; they rest on your description of the round and the hiring-manager prior |
| 3. `Quartzline strategy` / recent news | unavailable | Every call was refused. It would have grounded a CO or CASE question in current strategy; the CASE bank is `[generic]` instead |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's `role_profile` supplies the requirements and responsibilities, which fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Search permission for Quartzline research → the three unavailable targets: values and loop structure from official pages, plus a current strategy sweep that would turn the `[generic]` cases into company-grounded ones
- A deeper research pass (L2: up to 6 more searches and 2 more fetches, several more minutes) → strategy brief, interviewer footprint, role-family loop reports and recent org context, if you want it
- The hiring manager's name → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to their own path
- Your answers to the slots in F2, F3, F4, F5, F7, F8 and F9 (what you shipped, which docs or schemas, who the engineers and sales colleagues were, whether you worked in sprints, what you counted) → those rows move from slots to quoted evidence and the matching bank cells become story-mapped
- The session deck, notes or roadmap document where the roadmap-input sessions' evidence landed → the "Ran quarterly roadmap-input sessions feeding client evidence to product" line can rise from medium confidence, which is the inspectable proof the dossier says is missing
- Whether the posting has changed since the dossier's 2026-08-14 stamp → rows built on its requirement lines stay current
- The recruiter's prep email → any stated focus areas or pre-declared deliverable for this conversation
