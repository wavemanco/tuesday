# Interview prep pack: Live Operations Producer, Saltmarsh Games

Candidate: Femi. Interviewer: Tobias Wrenfield, Head of Live Operations. One 60-minute session on Friday 20 November 2026. Relationship assumed: hiring manager, since your note did not say. No company research is in this pack (see Sources), so everything about Saltmarsh itself is absent rather than guessed.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Behavioral or values alignment |
| EXP | Work-experience deep-dive: do your claims survive scrutiny |
| JD | Role and JD-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live hypothetical from the actual role |

An answer slot is an instruction for the interview, not a question for you now. Meet it with either branch: say what you did, or say plainly it was not yours or did not exist, then return to what your own words already carry.

## Prep triage (Tuesday to Friday)

1. A1, the highest-ROI rehearsal in this pack. Say it aloud until it is boring.
2. D1 (your 90-second arc) and C1 (how the retention numbers were counted).
3. B1 to B5 once each, aloud, thinking out loud and clarifying first.
4. F1 and F2, held through two follow-ups.
5. Pick three reverse questions from section 11.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for the main title, with nothing inspected behind it, and the words stay there: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's two-title line makes a probe on the step up likely. If any of that calendar covered more than the main title, say which and how, in your own words; if none did, say so plainly and stay with the main title |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message; "Never led a team, and never worked on a game with in-app purchases." — your message | low | [inferred] | discovery | The calendar line does not show which teams were involved, so the material is silent on coordination. Answer slot: the JD names four disciplines, so expect a probe on each. If any of them worked with you on a drop, say which and how you worked together; if the drops did not involve them, or that was not your part, say so plainly and stay with the calendar. If asked about leading people, the words are yours already: "I haven't led a team." |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | The pack's observation: your material says presenting monthly retention numbers, not post-event reviews or owning KPIs. The words stay at that scope: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's line makes a probe on reviews and KPI ownership likely. If you set, tracked or reviewed anything after a drop, say what and which part was yours; if not, or it was not yours, say so plainly and stay with presenting the monthly numbers |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | Lead with the artifact in the quote's own terms: you wrote it, and your QA team still uses it. The verb stays "wrote". Answer slot: the JD's verb is manage, so expect a probe on running releases against it. If you ran releases with QA using it, say how; if you did not, or that was not yours, say so plainly and stay with the checklist you wrote |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | medium | [grounded] | discovery | The quote reaches the years and the producer track at its own title, associate. It does not say whether the main title was a live-service game. Answer slot: if the game was updated on an ongoing basis, describe it in your own words; if it was not live-service, say so plainly and stay with the years and the weekly calendar |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a message line with nothing inspected behind it, so expect a probe. Lead with it in the quote's own terms: weekly, main title, two years, because a named cadence beats an adjective |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap, but expect a probe on how the numbers were counted (see C1). Lead with what you presented and to whom, in the quote's own terms |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | A checklist your QA team still uses is writing, but the material shows no other written work. Answer slot: if you wrote update notes, reviews or summaries, say which, in your own words; if the checklist is the main written work, say so plainly and say what other writing you could show |
| F9 | Monetized-event familiarity typical of mobile live ops (not in the JD) — role-family requirement, no source | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |

## Persona table

Weights start from the hiring-manager relationship prior, adjusted by the gaps in the fit snapshot. No interviewer profile or loop source exists, so there are no further adjustments. Change them if you know something I do not.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Quiet probing of the gaps: scale, team coordination, in-app purchases, readiness for the title | High. Hiring-manager prior, plus F2, F3 and F9 are the thinnest rows | Rehearse A1 until boring; state limits plainly, then your ramp plan |
| Case/Strategist (B) | Live problems from the role: calendar, a slipped build, a retention dip, a QA blocker | High. Hiring-manager prior; the JD is built around planning, coordinating and reviewing | Clarify, then structure, then answer; think aloud; challenge one premise politely |
| Data-Driven Prober (C) | Pushes on the retention numbers and the KPIs the JD says the role reports | Medium. The JD names retention metrics and KPIs; no profile says this interviewer is numbers-led | Know what you can and cannot say about how the numbers were counted; say plainly when you do not know |
| Conversational (D) | Friendly opener, then casual questions that are still scored | Medium. A 60-minute session usually opens this way; no source says how this one will | A 90-second arc; treat casual questions as scored |
| Peer Evaluator (E) | Seam-splitting between design, art, engineering, community and QA | Medium. The JD's coordination line makes the cross-team seam a likely theme | Propose seam principles rather than pretending to know the seam |
| Pressure (F) | Time-boxes you and tests whether you hold a position | Low. No signal that this interviewer is a stress interviewer | Pause, restate, hold through two follow-ups, concede specifically |
| Values/Behavioral (G) | Scenario probes on conduct | Low. No values round is documented and no published values are in hand | Use the selection scaffolds; say plainly when no story comes to mind |

## Question banks

### A. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Your background is a puzzle-game studio. What's your experience with in-app purchases?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." and "4 years as an associate producer at a puzzle-game studio." | The highest-ROI rehearsal in this pack. Hold-then-concede. Open with the plain words: "I haven't worked on a game with in-app purchases." Then stop and let them respond. If they press, return to what you did: "I ran the weekly content-drop calendar for our main title for the last two years" and "I presented the monthly retention numbers to the studio head", and leave the inference to them. Follow-up 1, "so what makes a paid event work?": do not bluff; say what you would want to learn and from whom. Follow-up 2, "how long until you're useful on that side?": give only a timeframe you would really commit to, and name the ramp as a plan, in your own words, covering what you would read and who you would sit with | F9 is the gap you stated and the likeliest place the interview turns; JD because it tests fit with the listed work, Skeptic because it targets a gap. The JD itself does not raise it, so the pack's reasoning here is inference and you can reweight it |
| A2 | "Tell me about a time you coordinated design, art, engineering and community on an update." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Story-map only what the quote states: a weekly calendar, the main title, two years, in your own words. Answer slot: the JD names these four teams, so expect a probe on who you worked with. If any of them worked with you on a drop, say which, what you needed from them and how you worked it out; if none did, or you were not the one working with them, say so plainly and describe how you ran the calendar. If asked about leading people: "I haven't led a team." | F2 is the row with the least behind it, so this is where the JD's coordination line presses hardest. EXP because it tests what was actually yours |
| A3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." and "Never led a team, and never worked on a game with in-app purchases." | Choose one real answer and say it first, plainly, then your plan. The pack's observation is that F9 and F3 are the thinnest rows: in-app purchases, and owning KPIs and post-event reviews where your material says presenting the monthly numbers. If you choose F3, the words are "I presented the monthly retention numbers to the studio head." Answer slot: if you also set or tracked KPIs, say which; if not, say so plainly. End with what you would do in your first weeks, as a plan | Standard Skeptic stem; calibrated candor beats a manufactured weakness. JD because it scores the listed responsibilities |
| A4 | "You've been an associate producer for four years. Why are you ready for the producer title now?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." and "I ran the weekly content-drop calendar for our main title for the last two years." | Start from the quotes at their own scope: four years as an associate producer, and two years of the weekly calendar. Answer slot: give your own reason for the step now, in your own words, and what has changed in your work; if nothing changed except your readiness, say that plainly. Answer slot: say what draws you to this role and to Saltmarsh, using only what you have actually looked at | F5 and F1 carry the years and the calendar. EXP because it tests the story behind the title; the motivation half is the Skeptic's why-here probe |
| A5 | "The role runs the calendar for two titles. How does your calendar experience carry over?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Say what you ran, in the quote's words. Answer slot: if any of that calendar covered more than the main title, say which and how; if none did, say so plainly and stay with the main title. Then a plan, not a past: what you would need to know first about the second title and how you would avoid collisions between the two calendars | F1 is transferability: the quote reaches a calendar, not two titles. JD because the two-title line is stated in the posting |

### B. Case/Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "An event launches Thursday and engineering says one title's build will slip two days. Walk me through what you do." | CASE | [generic] | Clarify first: what slipped, whether the date is tied to anything outside the team, whether scope can be cut. Then options with their costs, who must be told (design, art, community, QA) and when, what changes in the calendar and the checklist, and what goes into the post-event review. Say your recommendation and what would change your mind. The question needs no claim about your past, so the guidance makes none | A live problem from the JD's coordination and calendar lines (F1, F2) asked as a decision. Generic because it is a pattern, not a fact about this employer |
| B2 | "Sketch next month's live-events calendar across our two titles. What do you need to know first?" | CASE | [generic] | Clarify: the objective of the month, the KPIs it should move, team capacity, lead times for art and QA, anything fixed in advance. Then structure: cadence per title, avoiding collisions between titles, buffers before each release, review points after each event. Think aloud and name one assumption you would check | The JD's lead responsibility (F1) as a case. CASE because it scores structure and the right first questions, not a right answer |
| B3 | "Retention dipped after last week's event. Diagnose it." | CASE | [generic] | Verify the metric and the cohort first, then segment (new against returning, platform, version), then line the dip up against the release and the event content, compare with earlier events, form two or three hypotheses, say what you would check for each and who you would ask. State your weakest assumption aloud. No numbers are supplied here; use none you do not have | F7 and the JD's retention line as a live problem; the stem is a standard Case form. CASE because it scores diagnosis structure |
| B4 | "How would you structure a post-event review, and what would you report?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | A structure: what the event set out to do, the KPIs reported against that aim, what happened and why, what changes next time, who gets it. Answer slot: if you have reviewed a drop afterwards, say what it covered and what part was yours; if there was no such step, or it was not yours, say so plainly, describe how you would structure one, and stay with presenting the monthly numbers | F3 is where ownership of review and KPIs presses hardest; JD because it scores the listed responsibility, CASE in delivery |
| B5 | "QA flags a serious blocker the day before a scheduled release. Who decides, and how do you handle it?" | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Clarify severity and who owns the go or no-go. Options: delay, ship with a fix, ship with the feature off. Who is told and what the player-facing consequence is; what gets recorded afterwards. You may say you wrote the release checklist your QA team still uses, in those words, and nothing about how it was applied unless you did it | F4 as a live problem. CASE because it asks for a decision under constraint; the quote only supports the checklist, so the decision structure is generic |

### C. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the monthly retention numbers you presented. How were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Defend-the-number slots, each in your own words. Answer slot: how the numbers were counted. Answer slot: what they were most sensitive to. Answer slot: the assumption behind them you would defend least, named before they ask. Answer slot: which part of the numbers was yours. If you do not know how something was counted, say so plainly; that is an honest branch. The pack supplies no method, baseline or definition | F7 is the evidence for the retention requirement; EXP because quantified claims are what probers test |
| C2 | "Which retention measures would you look at first for a new event, and why?" | JD | [generic] | Name the measures you would use and what each tells you, and when you would look. Answer slot: say which ones you actually presented in your monthly numbers, in your own words; if they differed from these, say so plainly. State the limitation of whichever measure you lead with | The JD's retention line (F7) as a method question. JD because it scores comfort with the metrics |
| C3 | "How would you tell whether an event moved retention or just coincided with something else?" | CASE | [generic] | Compare against a baseline and against earlier events, separate cohorts, check for other releases or changes in the same window, state what evidence would convince you and what would not. Name your weakest assumption. Answer slot: if you have done such a comparison, say how and what it showed; if not, say so plainly and walk through how you would | Probers go two levels deep on any retention claim. CASE because it is a reasoning problem, with a JD tie to F3's KPIs |

### D. Conversational (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." and "I ran the weekly content-drop calendar for our main title for the last two years." and "Wrote the release checklist our QA team still uses." and "Presented the monthly retention numbers to the studio head." | A 90-second arc built only from those four sentences: the years and the studio, the weekly calendar, the checklist, the retention numbers. Answer slot: end with why this role, in your own words, from what you have actually looked at | F5, F1, F4 and F7 carry the arc; EXP because it is the CV walk-through, delivered casually |
| D2 | "What mobile games do you follow, and what do their event calendars do well?" | CO | [generic] | Name games you genuinely play or have studied, and one or two specific things about their event pacing you would take or avoid. Say plainly if you follow few. No Saltmarsh facts are in this pack, so do not claim any | Casual questions on the genre are still scored for real interest. CO because it tests homework depth; generic because no company research ran |
| D3 | "What do you enjoy about running a content calendar, and what wears you down?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Answer from your own experience of the weekly calendar in your own words. Answer slot: if there is a part you would hand to someone else, say which, plainly. The pack supplies neither the enjoyment nor the burden | F6 is the strongest row, so the interviewer can go deep on it; EXP because it tests what the work was like |

### E. Peer Evaluator (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Design wants a bigger event than engineering says is possible. Where's the seam, and what do you do?" | CASE | [generic] | Propose principles rather than a fixed seam: put the constraint and the player impact on the table, let each owner state their cost, decide who decides, record it. Name one thing you would not trade. The question makes no claim about your past, so the guidance makes none | The JD's four-team coordination line (F2) as a live disagreement. CASE because it asks for a decision |
| E2 | "How do you handle credit and blame when work spans teams?" | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Selection scaffold: pick a time work crossed teams, with a named stake and an intact relationship at the end; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry. The nearest sentence at its own scope is "I wrote the release checklist our QA team still uses." Answer slot: if others contributed to it, say who and how, plainly | A standard Peer stem. VAL in delivery; F4 supplies only the nearest sentence |
| E3 | "My weekly update lands with design, art, engineering, community and QA. What's in yours?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Say what each reader needs: what is shipping, what changed, what is at risk, what you need from them and by when. One page, scannable. Answer slot: if you have written such updates, say what they contained; if not, say so plainly and describe what you would write. The checklist line is the written work your material carries | F8 is the writing row and the thinnest; JD because it scores the clear-writing requirement |

### F. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over someone who has run monetized live events?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." and "I ran the weekly content-drop calendar for our main title for the last two years." and "Presented the monthly retention numbers to the studio head." | Pause, restate. Hold what the quotes carry: the weekly calendar and the retention numbers, in those words. Then concede specifically: "I haven't worked on a game with in-app purchases." Hold through two follow-ups by returning to the calendar and the numbers, never by adding to them | The Pressure stem aimed at F9. JD because it scores fit; hold-then-concede is the type's bar |
| F2 | "That release checklist: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold at "I wrote it." Answer slot: if others contributed to it, say who and what, plainly; if you wrote it alone, say so; do not extend to how releases were run unless you did. After two follow-ups, concede only what is true | F4's attribution probe; EXP because it tests what was yours |

### G. Values/Behavioral (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not fold, and an intact relationship at the end. Nearest sentence: "Presented the monthly retention numbers to the studio head." Answer slot: if any month's numbers were unwelcome, say what happened and what you did; if none were, say so plainly | No values round is documented, so this is a standard Values stem. F7 supplies only the nearest sentence |
| G2 | "When did you put the player ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where the player's experience and a number pulled apart; it needs the decision, the trade-off you named and what followed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard Values stem for a live-service role. No company values are in hand, so it is not mapped to any |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two titles | A5, B2, D3 |
| Coordinate design, art, engineering and community on each update | A2, B1, E1, E2 |
| Own the post-event review and its KPIs | A3, B4, C1 |
| Manage the release checklist with QA | B5, F2 |
| 3+ years producing live-service games or apps | A4, D1 |
| Experience running a content calendar | B2, D1, D3 |
| Comfortable with player-retention metrics | B3, C1, C2, C3 |
| Clear written communication | E3 |
| Not in the JD, covered because you stated the gaps: in-app purchases and leading a team | A1, A2, A3, F1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good first 90 days look like for the producer on these two titles?" | It shows you are planning your ramp and gives you the scoring sheet in his words |
| R2 | "How is the live-events calendar planned today, and which part would you want me to take over first?" | It signals you want to own the calendar, and tells you where you start |
| R3 | "Which KPIs does the post-event review report today, and who reads it?" | It ties to the JD's review and KPI line and shows you care about what the report changes |
| R4 | "Where do releases tend to get squeezed, and how does the release checklist work with QA when they do?" | It connects your checklist to their reality without claiming how they run it |
| R5 | "Given I haven't worked on a game with in-app purchases, what would you want me to learn first, and how would you suggest I learn it?" | It turns your biggest gap into a coaching conversation and shows candor |
| R6 | "What would make you say, six months in, that this hire worked?" | It asks for the success criterion directly; interviewers weigh this slot as a preparation signal |

No reverse question ties to Tobias Wrenfield's own path, because no profile of him is in this pack.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran a live-events calendar across two titles | Inflated form of F1 | F1's quote at its own scope. The pack's observation: your material says the main title, not two |
| Owned post-event reviews or the KPIs they report | Inflated form of F3 | F3's quote at its own scope. The pack's observation: your material says presenting monthly retention numbers, not reviews or KPI ownership |
| Managed releases with QA | Inflated form of F4 | F4's quote at its own scope: "Wrote the release checklist our QA team still uses." |
| Improved or drove retention | Inflated form of F7 | F7's quote at its own scope: presenting the monthly retention numbers |
| Led or managed a team, or the design, art, engineering or community teams | Negative the candidate stated, F2 | The plain acknowledgment: "I haven't led a team." No slot |
| Has in-app purchase or monetized-event experience | Negative the candidate stated, F9 | The plain acknowledgment: "I haven't worked on a game with in-app purchases." Then a plan, never a past |

## Sources

Provided documents: the job description pasted in your message, and your background in the same message. No dossier was present.

Searches sent, all refused by the host before returning anything:

- "Saltmarsh Games values" — refused
- "Saltmarsh Games interview process live operations producer" — refused
- "Saltmarsh Games mobile studio strategy news" — refused
- "Tobias Wrenfield Saltmarsh Games Head of Live Operations" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Would have fed a values cheat sheet; none is built because no published values are in hand |
| 2. Saltmarsh Games interview process, live operations | unavailable | Would have fixed loop structure; your own words establish one 60-minute session with Tobias Wrenfield, so persona weights rest on the hiring-manager prior |
| 3. Saltmarsh Games strategy and recent news | unavailable | Would have fed company-strategy CO and CASE questions; D2 and the cases are generic instead |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Would have fed an interviewer read and a reverse question tied to his path; both are absent |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Search permission, or the company's values or about page pasted → a values cheat sheet if a values round is documented, and strategy-grounded CO and CASE questions replacing the generic ones
- Tobias Wrenfield's public profile or talks, or a note from the recruiter → an interviewer read, tuned persona weights and a reverse question tied to his path
- The recruiter's prep email or any stated focus areas → coverage of any pre-declared deliverable and a corrected round type
- Your answers to the answer slots in F1 to F5 and F8 (second title, teams involved, post-event review, how releases ran, live-service status, other written work) → those rows move from `discovery` or `transferability` toward `presentation` or `none`, and the matching banks get story maps
- A writing sample, such as the release checklist itself or a retention summary → F8 and F4 move from inferred to grounded, and E3 gets a mapped example
