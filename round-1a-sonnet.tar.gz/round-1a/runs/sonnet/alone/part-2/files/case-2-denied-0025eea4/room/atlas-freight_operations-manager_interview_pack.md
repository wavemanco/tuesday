# Interview prep pack: Operations Manager, Atlas Freight

- **Role:** Operations Manager, Atlas Freight (regional logistics, 800 employees), per the JD you pasted
- **Interviewer and relationship:** not known. The persona weights below rest on a generic screen, hiring manager and panel loop, not on this company's documented process, and they are flatter than they would be with a name or a round type
- **Research:** none ran (searches were refused; see Sources), so there are no company-strategy or values questions, and the case questions are `[generic]`

## How to use this pack

Personas describe how a question is asked; types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values (none were read for this pack) |
| EXP | Whether your CV claims survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge (none in this pack: no research ran) |
| CASE | Structure and reasoning on a live problem from the role |

The single highest-ROI rehearsal in this pack is **A2**: the jump from three supervisors to twelve is in the JD's own numbers, so it will be asked in some form.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "currently a senior shift manager over 3 supervisors" — your message; "7 years in warehouse and distribution ops" — your message | medium | [grounded] | transferability | Your material says a shift-manager role and seven years in warehouse and distribution ops, not terminals and not several sites, and the words stay there: "I'm currently a senior shift manager over 3 supervisors." Answer slot: the JD's four sites make a probe on span likely. If any of your work covered more than one site, say which and what part was yours; if it did not, say so plainly and stay with your current role |
| F2 | "drive on-time performance" — JD | "ran the site's peak-season surge plan two years running" — your message | low | [inferred] | discovery | Your material says a peak-season surge plan, and does not show whether on-time performance was measured. Answer slot: the JD's on-time line makes a probe on how the plan was judged likely. If it was judged against on-time delivery, say how, in your own words; if it was judged otherwise, or not measured, say so plainly and stay with the plan you ran |
| F3 | "cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Your material says mis-pick rate, not cost-per-shipment, and the words stay at that scope: "I cut the mis-pick rate 40% by redesigning the pick path." Answer slot: the JD's cost line makes a probe on what else the change moved likely. If anything else was measured, say what and who measured it; if nothing else was, say so plainly and stay with the mis-pick rate. The figure itself raises the four defend-the-number slots (C1) |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material says three supervisors, not twelve, and the words stay at three. Answer slot: if any work put you in charge of, or coordinating, more than three supervisors, say how many, when and what was yours; if none did, say so plainly and stay with the three |
| F5 | "build reporting in Excel/Power BI" — JD (Excel half) | "solid Excel" — your message | low | [inferred] | discovery | Your material says your Excel is solid and does not show whether you built reports. Answer slot: if you have built reports, say what they showed and who read them, in your own words; if you have used Excel for other things, say so plainly and name them |
| F6 | "build reporting in Excel/Power BI" — JD (Power BI half) | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used Power BI." Then how you would learn it, said as a plan and never as a past. Never a claim to Power BI work, and nothing added to make the gap feel smaller |
| F7 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [inferred] | discovery | Your material says seven years in ops and a current supervisory role, and does not show how many of the years were in leadership. Answer slot: give the years you held a leadership role and the roles, in your own words; if only part of the seven was leadership, say so plainly with the real figure, and do not round up |
| F8 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap on the stated plus, but a certification with nothing inspected behind it, so expect a probe on what it covered. Lead with it in its own terms: you are green belt certified |

None of the eight rows is a gate: the 5+ years line is a length-of-experience requirement, graded like any other.

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of scope and the years requirement | High: F1, F4 and F7 are where the JD's numbers outrun the material | Rehearse A2 until it is boring; bridge only from what you stated; concede the jump plainly |
| Case / Strategist | Live problems on on-time, cost and peak | High: the JD's first two lines are measurable problems (F2, F3), and round type is unknown | Clarify, then objective, segmentation, approach, metrics, risks; think aloud |
| Data-Driven Prober | Asks how your 40% was counted and what the plan covered | High: F3 holds the one headline figure | Know what you can and cannot say about how it was counted; say plainly when you do not know |
| Pressure | Time-boxes and asks how much was really you | Medium: F3's figure and the F1 gap invite it | Pause, restate, hold the quoted sentence through two follow-ups, concede specifically |
| Values / Behavioral | Unpopular-truth and supervisor-change stories | Medium: no round documented, so only the supervisor theme is raised by the JD (F4) | Selection scaffolds with the honest branch; no values read for this pack |
| Conversational | The journey question; the green belt asked casually | Medium: asked casually, scored anyway (F7, F8) | A 90-second arc built only from your sentences |
| Peer Evaluator | Seam between terminals and credit-sharing | Low: appears only if a terminal manager sits in the loop (F1) | Seam principles, reciprocity, a disagreement story only if you have one |

Depth follows weight: 4 questions for the top three, 3 for the next three, 2 for Peer. If you learn the round type, the weights change.

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of owning four sites would you be weakest at on day one?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "7 years in warehouse and distribution ops" | Name the weakest part yourself before they do, and keep it inside what your quotes carry: 7 years in warehouse and distribution ops, currently a senior shift manager over 3 supervisors. Answer slot: if any of your work covered more than one site, say which and what part was yours; if it did not, say so plainly and stay with your current role. Then say, as a plan and never as past work, what you would want to see at each site before changing anything | F1 is the widest gap between the JD's scope and the material, so a Skeptic opens here; JD because it scores a stated requirement |
| A2 | "This role leads twelve supervisors and you lead three today. What makes you ready for four times that?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI rehearsal in this pack. Hold only the sentence: "Right now I'm a senior shift manager over 3 supervisors." Concede the size of the jump plainly and specifically, and do not argue it away. Answer slot: if any work put you in charge of, or coordinating, more than three supervisors, say how many, when and what was yours; if none did, say so plainly and stay with the three. Follow-up 1, what would you do differently with twelve: answer as a plan, not past work. Follow-up 2, how would you know who needs the most support: say what you would look at first. Follow-up 3, what if I think the jump is too big: concede the risk specifically and say what you would want agreed for the first ninety days. Never add to the three | F4 puts a three-to-twelve mismatch in the JD's own numbers, and F1 compounds it, so this objection arrives in some form; JD because it scores a stated requirement |
| A3 | "The posting requires 5+ years of operations leadership. How many of your years were in a leadership role?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Answer slot: give the number of years you held a leadership role and the roles, in your own words. If only part of the seven was leadership, say so plainly with the real figure, and do not round up; if all of it was, say so and name the roles. Then return to the two quotes and add nothing to them | F7: the JD marks the line required and the material shows operations years, not leadership years, so the probe is likely; JD because it scores the stated requirement |
| A4 | "Why are you looking to leave your current role, and why Atlas?" | EXP | [generic] | Two slots, both yours. Give your actual reason for leaving in your own words, and make it about what you are moving toward. For Atlas, use only what you can point to: the JD's four sites, twelve supervisors, on-time performance and cost-per-shipment. No research ran for this pack, so add one fact you found yourself on the company's own site | A motivation probe every Skeptic runs; EXP because it tests the story behind your own move, and no quote speaks to it |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance has slipped at one of your four terminals over the past month. Walk me through your first week." | CASE | [generic] | Clarify first: how on-time is defined and measured here, and what changed and when. Then the objective, a segmentation (by site and shift, inbound versus outbound, cause), your approach (data first, then the floor), the metrics, the risks. Think aloud and challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | F2's JD line as a live problem; CASE because it scores structure, `[generic]` because it is a pattern, not a fact about this employer |
| B2 | "Cost-per-shipment is rising across your four sites. How do you break that down?" | CASE | [generic] | Ask how the figure is defined here: what sits in it and what it is divided by. Then decompose it into components, separate mix and volume effects from real cost, rank by size and by how controllable each is, and pick one to test first. Name the assumption you would defend least. No claim about your past | F3's JD line as a live problem; CASE |
| B3 | "Peak season is five weeks out and the volume forecast just jumped. What do you do in the first two days?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Structure it: what you need to know first, the objective, the plan across four sites, the metrics, the risks. If you reach for your own experience, use it at its own scope, "I ran the site's peak-season surge plan two years running", and then answer for four sites as a plan, not as something you have done | F2: peak is your strongest operational story and a live case is where it surfaces; CASE because it is asked as a decision |
| B4 | "You inherit twelve supervisors across four sites with different habits and uneven results. What do you do before you change anything?" | CASE | [generic] | Say what you would want to learn first about each supervisor and site, what data you would pull, how you would set expectations, what early win you would look for, and the risk of moving too fast. Plan language only. No claim about your past | F4 as a live problem, the same gap as A2 rehearsed as a case; CASE |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say the sentence at its own scope: "I cut the mis-pick rate 40% by redesigning the pick path." Then the four slots, each in your own words: how the figure was counted; what it is sensitive to; the assumption behind it you would defend least, named before they do; which part was yours. If you do not know how some of it was counted, say so plainly. This pack supplies no baseline, period or method, and neither should you unless you can repeat it under a second question | F3 holds the one headline figure, and headline figures are what Probers go to; EXP defend-the-number |
| C2 | "What did the pick-path redesign change, and which part of it was yours?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Describe what changed in your own words. Answer slot: if others shared the work, say what theirs was and what yours was; if you did the redesign yourself, say so plainly. Return to the sentence, never beyond it | F3: the attribution follow-up to the figure; EXP |
| C3 | "What was in the peak-season surge plan, and did anything about it differ between the two years?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Answer slot: say what the plan covered, in your own words. The quote says you ran the plan, not that you wrote it: if you wrote or changed parts, say which; if you ran a plan set by others, or it did not differ between years, say so plainly and describe what running it involved. If you have outcome figures, the four figure slots apply: how counted, what it is sensitive to, the assumption you would defend least, which part was yours | F2: the Prober tests the one operational story with no figure on it; EXP |
| C4 | "Where does Excel fit in how you run a shift?" | JD | [grounded] "solid Excel" | Say it at its own scope: "My Excel is solid." Answer slot: the JD raises reporting, so expect a probe on it. If you have built reports, say what they showed, who read them and how often, in your own words; if you have used Excel for other things, or have not built reports, say so plainly and name what you use it for | F5: the quote does not show reporting, so the slot lets the premise be false; JD because it scores a stated requirement |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Pause and restate the question. Hold the sentence through two follow-ups: "I cut the mis-pick rate 40% by redesigning the pick path." Then concede specifically. Answer slot: if others shared the work, name what was theirs; if you did it alone, say so plainly. If you do not know how some of the figure was counted, say that too. Never fold on the sentence, and never add to it | F3's figure under pressure; EXP because it tests attribution |
| D2 | "Sixty seconds: why you over a candidate who has already run several terminals?" | JD | [grounded] "7 years in warehouse and distribution ops"; "green belt certified"; "cut mis-pick rate 40% by redesigning the pick path" | Time-box it to sixty seconds. Choose from those three sentences, in those terms, and add nothing to them. Concede the multi-site gap in one clause and move on. Hold through two follow-ups by returning to the same sentences | F1 is the gap this question presses, and F3 and F8 are the strongest quotes to answer it with; JD because it scores fit to the role |
| D3 | "The job builds reporting in Power BI, and you've never used it. Why should I take the risk?" | JD | [grounded] "never used Power BI"; "solid Excel" | Plain acknowledgment first, without softening: "I've never used Power BI." Then, as a plan and never as past work, how you would learn it and what you would report first. Offer the other quote at its scope: "My Excel is solid." Hold the acknowledgment through two follow-ups and concede that it is a real gap on day one. Do not say it will transfer easily, and do not name a course or tool you have not started | F6 is a gap you stated, and F5 is the quote beside it; JD because it scores a stated requirement |

### E. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you stated the hard thing plainly, and what happened to the relationship afterwards; "we" for context, "I" for contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioral stem; no published values were read, so it is not mapped to this company's. VAL because it scores past behavior |
| E2 | "Tell me about a time you got a supervisor to change how they worked." | VAL | [generic] | Selection scaffold: pick a time with a named change, what you said, what the supervisor did and where things stood after. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach it | The JD's twelve supervisors (F4) raise the theme; `[generic]` because no quote carries a story |
| E3 | "When did you put a customer's need ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time where the two pulled apart, what you chose and why, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioral stem for a service business; no quote speaks to it. VAL |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So — walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | A 90-second arc: open with the 7 years in warehouse and distribution ops, land on your current role as a senior shift manager over 3 supervisors, and close with why this role, in your own reason. Anything between is your own words and only roles you held | F7 and F1: the casual opener sets the frame every later probe tests; EXP |
| F2 | "What does your green belt mean for how you'd run four terminals?" | JD | [grounded] "green belt certified" | Say it as stated: "I'm green belt certified." Answer slot: the JD lists Lean/Six Sigma as a plus, so expect a probe on use. If you have applied the training to any work, say which and what part was yours; if you have not, say so plainly and say what the certification covered | F8: a casual question about a JD plus is still scored; JD |
| F3 | "If you had one screen for four terminals each morning, what would be on it?" | CASE | [generic] | Start from the decisions the screen supports. The JD's two measures, on-time performance and cost-per-shipment, come first, each defined; then the leading indicators behind them and who reads it. Say plainly that Power BI would be the part you would be learning. No claim about your past | F5, F6, F2 and F3 in one live problem; CASE |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Two terminal managers disagree about who gets the extra labour at peak. How do you handle it?" | CASE | [generic] | Propose seam principles rather than pretending to know the seam: agree a rule before the crunch, use shared data, decide who escalates and when. Say what you would offer the other terminal, not only what you need. No claim about your past | F1: multi-terminal coordination is new ground in the material; CASE |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time credit was shared, say what was whose, "we" for context and "I" for contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard peer stem; no quote carries a story. VAL |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "Own daily terminal operations across 4 sites" | A1, B1, D2, G1 |
| "drive on-time performance" | B1, B3, C3, F3 |
| "cost-per-shipment down" | B2, C1, F3 |
| "lead a team of 12 supervisors" | A2, B4, E2 |
| "build reporting in Excel/Power BI" | C4, D3, F3 |
| "5+ years operations leadership required" | A3, F1 |
| "Lean/Six Sigma a plus" | F2, D2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which of the four sites has the biggest on-time gap today, and what do you think is behind it?" | It asks at four-site altitude and gets you a real baseline for the case questions |
| R2 | "How is cost-per-shipment calculated here today, and how has it trended?" | The definition decides everything in B2; asking it shows you know that |
| R3 | "How would you describe the supervisor bench: who is strong, who is new, who needs support?" | It turns the three-to-twelve question into a conversation about the team, not about you |
| R4 | "What reporting exists today in Excel or Power BI, and what would you want built in the first ninety days?" | It surfaces how much Power BI the role needs on day one, which F6 makes your largest unknown |
| R5 | "What would make the first ninety days a success for you?" | It tells you what the interviewer is scoring and gives you the next conversation's agenda |
| R6 | "What are the next steps, and who else will I meet?" | It tells you the loop and round type, which would restructure this pack's persona weights |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team of 12 supervisors | Inflated form of F4 | F4's quote at its own scope: "currently a senior shift manager over 3 supervisors". The limit is the pack's observation: the material says three supervisors, not twelve |
| Owned terminal operations across several sites | Inflated form of F1 | F1's quotes at their own scope. The material says a shift-manager role and warehouse and distribution ops, not terminals or several sites |
| Reduced cost-per-shipment | Inflated form of F3 | F3's quote at its own scope: "cut mis-pick rate 40% by redesigning the pick path". The material says mis-pick rate, not cost-per-shipment |
| Drove on-time performance | Inflated form of F2 | F2's quote at its own scope: "ran the site's peak-season surge plan two years running". The material does not show on-time performance was measured |
| Seven years of operations leadership | Inflated form of F7 | F7's quote at its own scope: "7 years in warehouse and distribution ops". The material says ops years, not leadership years |
| Has built Power BI reports | Negative you stated, F6 | The plain acknowledgment F6 gives: "never used Power BI", said as "I've never used Power BI." No slot |
| The pick-path redesign was a green belt or Six Sigma project | Inflated form of F3 and F8 read together | Each quote at its own scope; question F2 in the banks holds only the certification, and its slot asks what the certification covered |

## Sources

- **Provided:** the JD text and your background, both pasted in your message. No CV, no interviewer information, no recruiter guidance
- **Queries sent:** `Atlas Freight regional logistics company values` — refused; `Atlas Freight interview process operations manager` — refused; `Atlas Freight strategy news terminals` — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Every call was refused. It would have moved a values cheat sheet, section 10, and named published values for the VAL bank |
| 2. `Atlas Freight interview process operations manager` | unavailable | Every call was refused. It would have moved the loop structure and the persona weights, which now rest on the generic archetype |
| 3. `Atlas Freight strategy` / recent news | unavailable | Every call was refused. It would have moved a strategy-grounded CO or CASE question |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Operations Manager` JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The round type and who you are meeting (hiring manager, peer, HR) → persona weights recomputed from the generic loop to the real one, and a reverse question tuned to them
- An interviewer name and title → an interviewer read, and a reverse question tied to their own path
- Anything the recruiter said about focus areas or a task to prepare → coverage tuned to it, and a build section if a deliverable was announced
- Your answers to the slots in F1, F2, F3, F4, F5 and F7 (sites covered, how on-time was judged, what else the redesign moved, supervisors coordinated, reports built, leadership years) → those rows upgrade from discovery or transferability, and the matching guidance cells become story-mapped
- The green belt certificate, and a before-and-after mis-pick report if you have one → F8 and F3 move from medium toward high confidence
- Search access, which was refused here, so targets 1 to 3 can run → published values, the loop and current strategy; and a deeper pass of up to 6 more searches and 2 more fetches, several more minutes, can follow if you want it
- A `tuesday-dossier.md` from an earlier session, if you have one → verified evidence and any prohibited claims, so the highest-ROI objection is taken from evidence instead of inferred
