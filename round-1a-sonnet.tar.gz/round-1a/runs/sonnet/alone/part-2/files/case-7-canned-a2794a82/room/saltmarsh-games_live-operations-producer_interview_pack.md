# Interview pack: Live Operations Producer, Saltmarsh Games

For Femi. Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship: assumed hiring manager, because Saltmarsh's careers page says its single 60-minute interview is run by the hiring manager and your note did not say otherwise. Session: the Outage Hour (a live-incident tabletop, then a values conversation).

## How to use this pack

Personas describe how a question arrives; types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows Saltmarsh's published values |
| EXP | Whether your own claims survive scrutiny: what was actually you |
| JD | A stated requirement of the job, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem from the role, scored on structure |

Answer slots in the guidance are instructions for the interview, not questions for you now. Where a slot offers two branches, either honest branch is a good answer.

**The highest-ROI prep in this pack is C1**: your own message says you have not worked on a game with in-app purchases, and Saltmarsh's September 2026 announcement moves its titles to a season-pass model. Expect that question in some form. Rehearse C1 first, then F1, then the A bank.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for one main title, with nothing inspected behind it, and the words stay there: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's two-title line makes a probe on scale likely. Describe the calendar you ran as you ran it, say which parts you would expect to carry across two titles and which you would need to learn; if some part was not yours to set, say so plainly |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [inferred] | discovery | Your material does not show which teams you worked with. Answer slot: the JD names four disciplines. If any of them were people you worked with on your weekly drops, say which and what you needed from each, in your own words; if you did not work with some, or someone else handled it, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | The words stay at their scope: "Presented the monthly retention numbers to the studio head." Your material says presenting monthly numbers, not a review or its KPIs. Answer slot: expect a probe on which part of those numbers was yours; say in your own words, and if it was only the presenting, say so plainly |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | The quote reaches the requirement in other terms, and the words are the quote's: "I wrote the release checklist our QA team still uses." Expect a probe, since a CV-style line has nothing inspected behind it. Answer slot: say in your own words what QA did with it; if you were not in the releases that used it, or do not know how QA used it day to day, say so plainly and stay with wrote it and still uses it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | low | [inferred] | discovery | Four years producing is stated; whether the main title was run as a live service is not. Answer slot: the JD says live-service. If your main title was a live game with players receiving updates, say what that meant week to week, in your own words; if it was not run that way, say so plainly and stay with the weekly content-drop calendar. This is a titled-years requirement, a risk to rehearse and not a gate |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a message line with nothing inspected behind it, so expect a probe. Lead with the calendar in the quote's own terms: weekly, your main title, the last two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | presentation | The quote reaches the requirement in other terms. Say it as it stands: "I presented the monthly retention numbers to the studio head." Nothing about how they were counted is in your material, so D1 holds a slot for it |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | A written artifact is stated; whether your writing went to players or other teams is not. Answer slot: if you wrote anything that reached players, other teams or leadership besides the checklist, say what, in your own words; if the checklist is the main written work you can point to, say so plainly |
| F9 | a season-pass monetisation context for the titles (Saltmarsh news post, September 2026, read as a search result) | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap your own words state, and no wording closes it. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. The same sentence says you have not led a team; the JD's verb is coordinate, and C2 handles it |

## Reading the interviewer

Public footprint only, and read from search snippets: I did not open the talk page.

| Observation | Provenance | What it means for you |
|---|---|---|
| Tobias Wrenfield is Head of Live Operations at Saltmarsh Games, previously a QA lead at a console studio (GDC 2026 talk listing) | [grounded] | He has seen release checklists and outages from the QA side; D3 and B3 are likelier than usual |
| His GDC 2026 talk, "Patch Notes Are a Promise", argues that a live team is judged by how often its patch notes describe what actually shipped | [grounded] | Precision about what shipped versus what was promised is his own theme and Saltmarsh's second value; say only what is built, in tabletop answers and in your history |
| Saltmarsh's published value "Ship the Patch Not the Promise" reads: "we announce what is built, not what is hoped" | [grounded] | Overclaiming in a tabletop (promising a fix time you do not know) costs more here than elsewhere |

Mirror opportunity: his path runs through QA. Your side is a touchpoint, not a shared jump: F4's "Wrote the release checklist our QA team still uses." That is the sentence to offer if QA comes up, and no more.

## Persona table

The careers page says the loop is a recruiter call, then the Outage Hour: a single 60-minute interview with the hiring manager, a live-incident tabletop on a simulated outage during a live event, then a values conversation, with no take-home. That establishes your session, so weights follow it. It does not say how the hour splits.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | The tabletop: a simulated outage during a live event | High: the careers page names the tabletop as the interview's first part | Clarify, objective, who you pull in, what players are told, how you know it is resolved; say the structure aloud; challenge one premise respectfully |
| Values/Behavioral | The values conversation after the tabletop | High: the careers page names it as the second part; three published values to map | Map a story to each value where a sentence of yours carries one; where none does, pick a story by the scaffold and take the honest branch if none comes to mind |
| Skeptic | Probing the in-app-purchase and team-lead gaps | Medium: a hiring-manager prior, plus two negatives your own message states | Rehearse C1 until it is boring: concede plainly, hold what your quotes carry, give a plan |
| Data-Driven Prober | The retention numbers and the release checklist | Medium: both are on your list, and his published theme is shipped-versus-promised precision | Know what you can and cannot say about how your numbers were counted, and say plainly when you do not know |
| Conversational | Opening biography and why-Saltmarsh | Low to medium: any interview opens this way, but the page names no rapport round | Script a 90-second arc from your own sentences |
| Pressure | Time-boxed challenge during the tabletop | Low to medium: tabletops can be time-boxed, though the page does not say | Pause, restate, hold the position, concede only what is true |

## Question banks

### A. Case/Strategist (weight: highest, with B)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Twenty minutes into a live event, players report the reward won't claim, and you're the producer on call. Talk me through your first ten minutes." | CASE | [generic] | Say your structure aloud before using it. Clarify first: how many players, which platforms, since when, what engineering already knows, whether the event can be paused. Then the objective (stop the harm, keep players informed), who you pull in (engineering for cause, community for what players see, design for whether to pause), what players are told and when, and how you will know it is resolved. Challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | The careers page documents the tabletop as part of this interview; this is a pattern for the format, not a prediction of the scenario. CASE because it scores structure |
| A2 | "Engineering says the fix is two hours out. Community wants to announce compensation now; design wants to extend the event. What do you do, and who decides?" | CASE | [generic] | Ask who owns the call on compensation and on extension before choosing. Separate what is known from what is hoped, in the company's own words: "we announce what is built, not what is hoped". Announce only what is confirmed, plus when the next update comes. Name the trade-off you chose and what would change your mind. No claim about your past | Tests the JD's coordination line across four disciplines (F2's requirement); uses the published value's vocabulary. CASE because it is a decision under conflict |
| A3 | "The outage is resolved. What goes in the post-event review, and which numbers do you report?" | CASE | [generic] | Structure it: timeline, player impact, cause, decisions and who made them, what changes in the checklist, owners and dates. Pick a few numbers, say how each would be counted, and name the assumption you would defend least before he does. No claim about your past | Covers the JD's post-event review and KPI line (F3's requirement) as a live problem, so it needs no premise about your history |
| A4 | "Project Larkspur puts both titles on one shared events calendar from February 2027. How would you plan the first two months of it?" | CO | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Clarify first: what the shared calendar must guarantee when two titles' events hit the same players, who signs off a slot, what the season pass needs from events. Ask these; do not assume answers. If the talk turns to monetisation, say "I haven't worked on a game with in-app purchases" and return to structure. Do not state which two titles the JD role covers; ask | The only CO question grounded in current strategy: the Saltmarsh post dated September 2026, read as a search result only. F9 is the limit. CO with CASE delivery |
| A5 | "This role runs the events calendar for two titles. How would you run it?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Story-mapped on F1: the weekly calendar, your main title, two years, told in your own words. Answer slot: the JD's two-title line makes a probe on scale likely. Describe the calendar as you ran it, say which parts you would expect to carry across two titles and which you would need to learn; if some part was not yours to set, say so plainly | F1 is where the two-title line presses hardest; JD because it scores the stated requirement |

### B. Values/Behavioral (weight: high, with A)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed. Which one won?" | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | No quoted sentence of yours carries this story, so choose one: a time a scheduled drop and what players needed pulled apart. It needs a named stake, the decision you made and what followed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I ran the weekly content-drop calendar for our main title for the last two years", or how you would handle it. The value reads: "when the calendar and the players disagree, the players win" | Maps the first published value; open prompt whose theme comes from the values page |
| B2 | "Tell me about a time you had to say that something people were waiting for wasn't ready." | VAL | [grounded] | Selection scaffold: pick a time you held back an announcement or a drop, with the stake, what you said and how it was received. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Use "we" for context and "I" for what you did | Maps "Ship the Patch Not the Promise"; the theme comes from the values page |
| B3 | "Tell me about a time you left a process better after a release than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4: you wrote the checklist, and your QA team still uses it. Answer slot: the value says every release leaves "the checklist better than it found" it, so expect a probe on whether yours changed after releases. If it did, say what prompted a change, in your own words; if it did not, or changing it was not yours to do, say so plainly and stay with "Wrote the release checklist our QA team still uses." | Maps "Leave the Build Greener" to the one sentence of yours that carries a process; F4 is the evidence |
| B4 | "Tell me about a time you delivered an unwelcome truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Story-mapped on F7: the monthly retention numbers, presented to the studio head. Answer slot: if any month's numbers were unwelcome, say what they showed and how it landed, in your own words; if none were, or the numbers were prepared by others, say so plainly and describe how you present them. If no time comes to mind, say so, then give the nearest thing your material carries | A persona-stem prompt that fits the JD's KPI-reporting line; VAL because it scores the behaviour, not the number |

### C. Skeptic (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You haven't worked on a game with in-app purchases, and our titles are moving to a season-pass model. How do you handle the monetisation side of an events calendar?" | JD | [inferred] "Never led a team, and never worked on a game with in-app purchases." | **Highest-ROI rehearsal.** Concede first, plainly: "I haven't worked on a game with in-app purchases." Then hold what your quotes carry: "I ran the weekly content-drop calendar for our main title for the last two years" and "Presented the monthly retention numbers to the studio head." Hold through two follow-ups by returning to those, never by adding to them. Likely follow-up one, which monetisation numbers you have reported: say plainly that you have not. Follow-up two, how fast you can learn: answer with a plan, what you would ask for in the first weeks (recent post-event reviews, which numbers the producer reports, how the season pass uses events), never a claim about speed. Never claim familiarity with revenue or conversion metrics | F9 is the biggest gap and is stated in your own words; the season-pass link is this pack's derivation from the September 2026 post, hence inferred. JD because the interviewer scores whether you can do the job with this gap |
| C2 | "You've never led a team. This role coordinates design, art, engineering and community on every update. Where does that get hard for you?" | EXP | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." | Acknowledge plainly: "I haven't led a team." The JD's verb is "coordinate design, art, engineering and community teams on each update"; say so and let him judge how far apart the two are. Answer slot: expect a probe on which of the four you worked with on your weekly drops. Say which and what you needed from each, in your own words; if you did not work with some, or someone else handled it, say so plainly and stay with the calendar you ran | F2 has no evidence behind it, and your message states the team-lead gap; EXP because it tests what was actually yours |
| C3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Choose from what you actually stated, not a polished fake weakness: "I haven't worked on a game with in-app purchases." Then a plan, said as the future: what you would read and ask first. Keep it to two sentences and stop | Persona-stem Skeptic question; F9 is the likeliest honest answer, and rehearsing it prevents a vague one |

### D. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You presented the monthly retention numbers to the studio head. Walk me through how those were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | The beats the quote states: monthly, the numbers, the studio head. Answer slot: expect a probe on how the numbers were counted and which part was yours. Say in your own words how they were defined and what they are sensitive to, and name the assumption you would defend least before he asks; if you do not know how they were counted, or the numbers came from someone else's report, say so plainly and return to presenting them monthly to the studio head | F7 and F3 rest on this one sentence, and the JD asks for comfort with retention metrics; EXP because it tests attribution |
| D2 | "Players who joined during an event are mostly gone a week after it ends. Diagnose it." | CASE | [generic] | Clarify: new versus returning players, platform, how this compares with earlier events, whether the numbers are instrumented correctly. Segment, give two or three hypotheses, say what you would check first, and name the assumption you would trust least. No claim about your past | JD asks for comfort with retention metrics (F7's requirement); CASE because it is a live diagnosis |
| D3 | "Walk me through the release checklist you wrote." | EXP | [grounded] "Wrote the release checklist our QA team still uses." | The beats the quote states: you wrote it, and your QA team still uses it. Answer slot: the JD's QA line, and his QA background, make a probe on how it worked with QA likely. Say in your own words what QA did with it; if you were not in the releases that used it, or do not know how QA used it day to day, say so plainly and stay with that you wrote it and that it is still used | F4 is the likeliest place for a former QA lead to probe; JD and EXP dual: the requirement and the attribution |

### E. Conversational (weight: low to medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." | A 90-second arc with only these beats: four years as an associate producer at a puzzle-game studio, the weekly content-drop calendar you ran for your main title for the last two years, the release checklist your QA team still uses. End on why this role, in your own words; give your actual reason | Every interview opens with this question, and it is scored even though it sounds casual |
| E2 | "What pulled you to Saltmarsh?" | CO | [grounded] | Name one thing you have actually read: the values page, the Larkspur announcement or his GDC talk, and say what you honestly make of it. Do not claim a reaction you did not have; if you have not read them yet, read them before Friday | Rapport-style questions carry company-knowledge scoring; the sources are listed below |

### F. Pressure (weight: low to medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds. You've never worked on in-app purchases and never led a team. Why should I hire you?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | Pause and restate the question. Concede both plainly: "I haven't worked on a game with in-app purchases, and I haven't led a team." Then hold: the weekly calendar, the checklist, the monthly retention numbers, each at the quote's own scope. Hold through two follow-ups; do not add to the quotes to win the exchange. Close with one sentence of plan, what you would ask first | C1 under time pressure; scores composure, and holding the position without becoming defensive |
| F2 | "Write the player-facing message for that outage. Out loud, now." | CASE | [generic] | Say the structure: what we know, what we do not, what players can do, when the next update lands. Promise nothing that is not built. Keep it short, without blame, and say the actual words you would use. No claim about your past | Tests the JD's written-communication line (F8's requirement) live; fits the published value and his talk theme |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two titles | A5, A4, B1 |
| Coordinate design, art, engineering and community on each update | A2, C2 |
| Own the post-event review and the KPIs it reports | A3, D1, B4 |
| Manage the release checklist with QA | D3, B3 |
| 3+ years producing live-service games or apps | E1, C3 |
| Experience running a content calendar | A5, E1 |
| Comfortable with player-retention metrics | D1, D2 |
| Clear written communication | F2, A3 |

## Values cheat sheet

The careers page documents a values conversation, so every published value gets a row.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Players Before Plans | When the schedule and the players disagree, the players take priority | No row carries a story. Selection scaffold (B1): pick a time a scheduled drop and player need pulled apart; if none comes to mind, say so plainly, then give the nearest thing, F1's "I ran the weekly content-drop calendar for our main title for the last two years.", or how you would handle it |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | No row carries a story. Selection scaffold (B2): pick a time you held something back; if none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it |
| Leave the Build Greener | Each release leaves the code and the checklist better than it found them | F4: "Wrote the release checklist our QA team still uses." (B3 holds the slot on whether it changed after releases) |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You moved from QA lead to heading live operations. What from QA do you still lean on during a live incident?" | Tied to his own path; it turns the interview into a conversation about the craft you share a border with. Ask it only if you want his answer |
| R2 | "Your GDC talk argues patch notes are a promise. How does the team check afterwards that the notes matched what shipped?" | Shows you read him; the answer tells you what the producer is held to |
| R3 | "How does Project Larkspur change this role: do the two titles sit under the single live-ops group, and who does the producer report to?" | Shows you read the September 2026 announcement, and surfaces scope and reporting line, which the JD leaves open |
| R4 | "How are post-event reviews run today, and which KPIs does the producer report under a season-pass model?" | Addresses your in-app-purchase gap by asking for the ramp, not hiding it |
| R5 | "What does a strong first ninety days look like for this producer?" | Generic, and it gets him describing success criteria you can then work toward |
| R6 | "What do the strongest tabletop answers have in common?" | Invites him to describe what the Outage Hour rewards, and shows you take the format seriously |

## Prohibited claims

Built from the fit snapshot before the banks. Not coached, and the honest form of each:

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team | Negative you stated, F9 | "I haven't led a team." No slot |
| Worked on a game with in-app purchases, or reported monetisation figures | Negative you stated, F9 | "I haven't worked on a game with in-app purchases." No slot |
| Ran a live-events calendar for two titles | Inflated form of F1 | F1's quote at its own scope; the pack's observation is that your material says one main title and a weekly content-drop calendar. A5's slot stays inside the calendar you ran |
| Owned post-event reviews or their KPIs | Inflated form of F3 | F3's quote at its own scope; the material says presenting monthly retention numbers. D1's slot asks only what part of the numbers was yours |
| Managed the release checklist with QA | Inflated form of F4 | F4's quote at its own scope; the material says wrote it and QA still uses it. D3's slot asks only what QA did with it |

## Sources

Provided documents: the job description and your background, both in your message. No CV file.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet, B1 to B3, A2 and F2 vocabulary: three values by name, from the fetched values page |
| 2. `Saltmarsh Games interview process live operations producer` | yes | Loop and persona weights: a recruiter call, then one 60-minute Outage Hour with the hiring manager, tabletop then values, no take-home; values-style round detected |
| 3. `Saltmarsh Games strategy news mobile` | yes | A4, C1 and R3: the September 2026 Larkspur announcement, read as a search result and not opened |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | Reading the interviewer, R1 and R2: a GDC 2026 talk listing, read as a search result and not opened |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

Queries and what came back:

- `Saltmarsh Games values` returned https://saltmarshgames.com/values
- `Saltmarsh Games interview process live operations producer` returned https://saltmarshgames.com/careers/interviewing
- `Saltmarsh Games strategy news mobile` returned https://saltmarshgames.com/news/project-larkspur
- `Tobias Wrenfield Saltmarsh Games` returned https://talks.gdconf.example/2026/patch-notes-are-a-promise
- Fetched https://saltmarshgames.com/values and https://saltmarshgames.com/careers/interviewing; both returned text.

## Upgrade menu

- The recruiter's prep email or any note on the tabletop's format and the split of the hour → persona weights between the A and B banks become grounded in what Saltmarsh told you, and a confirmation that Tobias is your hiring manager
- Your CV, plus the release checklist and a retention report you presented → F1, F3, F4 and F7 move from medium toward high confidence, since those are the inspectable artifacts in this field
- Your answers to the slots in F2 (which teams you worked with), F3 (which part of the numbers was yours) and F5 (whether the main title was run as a live service) → those rows regenerate from your own words
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a grounding brief on Larkspur and Tobias's talk, replacing the two snippet-only reads
- Prep time available before Friday → a prioritised schedule sized to it
- A tuesday-dossier.md from an earlier evidence check → confirmed evidence rows and absolute do-not-claim items, in place of the ones this pack inferred
