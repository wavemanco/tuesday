# Member Experience Lead — Ashgrove Credit Union: interview prep pack for Dara

Built 17 November 2026, in loop mode: three rounds on 26 November 2026, taken from the recruiter's email.

| Round | Who | Length | What it is | Pack IDs |
|---|---|---|---|---|
| R1 | The recruiter | 30 minutes | Screen | R1-A1 to R1-B2 |
| R2 | The Head of Member Services, who would be your manager | 45 minutes | "Mostly behavioural" | R2-B1 to R2-F2 |
| R3 | A panel of two branch managers | 60 minutes | Includes a 20-minute complaint-escalation case; also the values round, scored against the four values | R3-C1 to R3-F1 |

Interviewer names are not assigned yet, so there is no interviewer read; personas rest on each round's role and on what the recruiter wrote.

## How to use this pack

Personas describe how a question arrives; types describe what it scores. Persona letters are fixed across the pack: A Conversational, B Skeptic, C Values/Behavioral, D Case/Strategist, E Peer Evaluator, F Data-Driven Prober. An ID such as R2-B1 reads round 2, Skeptic, question 1.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the published values, not generic virtue |
| EXP | Whether your own account of your work survives follow-up questions |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you have done the homework on Ashgrove and can think at its level |
| CASE | Structure and reasoning on a live problem from the role |

Provenance labels: `[grounded]` traces to a document you gave me; `[inferred]` is derived from an adjacent source, with the derivation named; `[generic]` is a role-family pattern with no claim about Ashgrove or about you. Guidance is scaffolding, not a script.

An answer slot is an instruction for the interview, not a question for me. Fill it only with what is true. Both branches are good answers: "I did this, this is how" and "that was not mine, or did not exist" score better than a stretched answer, because the follow-up question is built to find the stretch.

## Prep triage

Nine days from today to 26 November. Do these in order; they are the few things that move the three rounds most.

| Order | When | Do | Tied to |
|---|---|---|---|
| 1 | Day 1 | Write your true answers to the answer slots in F1, F3, F4, F5, F7 and F9, in your own words, and send them to me. They become quoted material and the guidance regenerates around them | Fit snapshot |
| 2 | Days 1 to 3 | Say R2-B1 aloud against a timer, three follow-ups deep, until it is boring. It is the highest-ROI prep in the pack | R2-B1 |
| 3 | Day 2 | Settle your own answers to pay, notice, location and reason for leaving. The reason for leaving is heard in all three rounds; keep one version | R1-A3 to R1-A6 |
| 4 | Days 3 to 5 | Pick one real story per value and say each in about 90 seconds; the panel scores against all four | R3-C1 to R3-C4 |
| 5 | Days 5 to 7 | Say the three cases aloud twice each, stating your structure before you use it | R3-D1 to R3-D3 |
| 6 | Days 7 to 8 | Prepare your plain acknowledgment and plan for presenting above regional level | R2-B2 |

Everything else is insurance.

## Fit snapshot

Shared across all three rounds. Each requirement is quoted from the JD you pasted; each evidence cell holds only your own sentences from your message. Nothing here comes from a CV document, because none was provided.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says the branch's log, not the process end to end and not across branches, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's first line makes a probe on how far a complaint's path ran through you likely. If any step of that path was yours to do or decide, say which and how, in your own words; if none was, or it was not yours, say so plainly and describe how the log worked |
| F2 | "across branches and the contact centre" — JD (the contact-centre half of F1's requirement) | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I have never worked in a contact centre." Then a plan, said as a plan and never as a past: what you would want to learn first about how a complaint reaches and moves through the contact centre. Nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The sentence says you built a monthly complaints spreadsheet that your regional manager uses; it does not show what the spreadsheet counted or who produced each month's figures. Answer slot: the JD names volumes and resolution times, so expect a probe on what yours showed. If it counted either, say how each was counted and the assumption you would defend least, in your own words; if it did not, or you did not produce the monthly figures, say so plainly and stay with the spreadsheet you built |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [grounded] | discovery | The sentence says spreadsheet, not which tool, and nothing about how it was built. Answer slot: if it was in Excel, say so and say what you did in it, in your own words; if it was another tool, or part of it was built by someone else, say so plainly and stay with the spreadsheet you built |
| F5 | "coach branch supervisors on escalations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message; "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says you trained new tellers on the escalation script, and the words stay there: "I trained new tellers on our escalation script." Answer slot: the JD's escalation line makes a probe on how that carries over likely. If teaching the script ever meant helping someone through a live escalation, say what you did and what part was yours; if it did not, say so plainly and stay with how you trained the tellers |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | The quote carries the years; lead with it in your own terms: six years in retail banking, the last three as a branch supervisor. A CV line has nothing inspected behind it, so expect a probe on what the supervisor years involved, and do not relabel your work in the JD's words |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [grounded] | discovery | The sentence says a formal complaints log; it does not show whether those complaints carried regulatory rules or deadlines. Answer slot: if they did, say which rules you worked to and what each required of you, in your own words; if you do not know, or the log was not tied to such rules, say so plainly and stay with the log |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You have stated the limit. Words: "I have never presented to anyone above regional level." Then a plan, as a plan: how you would prepare a monthly report for that audience. The material does not show who counts as senior at Ashgrove, and the pack does not guess |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent on this, which is not the same as having no experience. Answer slot: if you have had any contact with digital teams or self-service journeys, say what and what part was yours, in your own words; if none, say so plainly and say what you would ask digital teams first |

## Grounding brief

The strategy points you were sent in the July 2026 brief, as you gave them to me. I have not seen the brief itself; these are your four points, and the brief is about four months old, inside the six-month freshness window.

| # | What it says | Where it feeds | Provenance |
|---|---|---|---|
| G1 | "move 40% of member service to digital channels by 2028" — strategy brief, as you reported it | R2-D2, R1-A2, and F9 | [grounded] |
| G2 | "consolidate eight branches into five hubs over 2027" — strategy brief, as you reported it | R3-C5 and the R3 reverse questions | [grounded] |
| G3 | "launch a small-business lending product in Q1 2027" — strategy brief, as you reported it | The R2 reverse questions | [grounded] |
| G4 | "the main competitive pressure is app-only banks" — strategy brief, as you reported it | R1-A7, R2-D2 | [grounded] |
| G5 | The JD, values and brief say "member", not "customer"; the values say "counter" and the brief says "hubs" | Use their words in every answer | [grounded] |

## Persona table

### Round 1 — recruiter

| Persona | How it shows up | Weight, with the reasoning | Counter-strategy | Provenance |
|---|---|---|---|---|
| A Conversational | Friendly, unstructured; logistics, biography, motivation | Primary. The prior for a recruiter screen is Conversational plus a light Skeptic, and the email gives this round only as "30 minutes with me", which adds nothing to move it | A 90-second arc quoted from your own sentences; treat casual questions as scored | [grounded] |
| B Skeptic, light | Knock-out checks on the stated gaps, in a friendly register | Second. The prior says "light"; the two limits you stated (F2, F8) are the likeliest knock-outs | One plain acknowledgment, then the plan, then stop | [grounded] |

### Round 2 — Head of Member Services

| Persona | How it shows up | Weight, with the reasoning | Counter-strategy | Provenance |
|---|---|---|---|---|
| B Skeptic | Quiet, persistent probing of the ownership claim and the two stated limits | First, 4 questions. The email says this person "would be your manager"; the hiring-manager prior is Case plus Skeptic, because they are buying capability and de-risking gaps, and F1, F2 and F8 are where the JD presses hardest | Rehearse R2-B1 until it is boring: hold the quote's scope, concede the limit before it is asked for | [grounded] |
| C Values/Behavioral | "Tell me about a time" questions | Second, 2 questions. The email says the round is "mostly behavioural", which lifts this above its place in the hiring-manager prior | One real story per question, or the honest branch; "we" for context, "I" for contribution | [grounded] |
| D Case/Strategist | A live problem on the role's own first months, and one on the 2028 digital target | Third, 2 questions. It is in the hiring-manager prior but the "mostly behavioural" description pulls it down | Clarify, structure, metrics, risks; think aloud | [grounded] |
| F Data-Driven Prober | Line-by-line questions on the spreadsheet and the Excel line | Fourth, 2 questions. The JD makes monthly reporting part of the job, so this manager has a reason to ask; the email does not say they will | Say what you know about how it was counted, and say plainly where you do not | [inferred] |

### Round 3 — panel of two branch managers

| Persona | How it shows up | Weight, with the reasoning | Counter-strategy | Provenance |
|---|---|---|---|---|
| C Values/Behavioral | Scenario probes scored against the four published values | First, 5 questions. The email says "The panel is also the values round — they score against the four values" | Each value gets a story or the honest branch; hard truths that actually landed | [grounded] |
| D Case/Strategist | The 20-minute complaint-escalation case | Second, 3 questions. The email puts a 20-minute case in this round and does not say what it contains, so the pack prepares the pattern, not the case | Clarify first, structure aloud, challenge one premise | [grounded] |
| E Peer Evaluator | Seam and disagreement questions between a branch and a central owner | Third, 2 questions. The JD has the role coach branch supervisors and work across branches, so these panelists are the people on the other side of that seam | Reciprocity: what you bring their branch; offer seam principles, not a claimed knowledge of the seam | [inferred] |
| F Data-Driven Prober | Detail questions on a complaint you handled | Fourth, 1 question. Branch managers know the branch side of a complaint, so a thin account would be noticed | Choose a complaint you can tell without a detail you cannot stand behind | [inferred] |

## Question banks

### Round 1 — recruiter

#### A Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc with three beats the quotes state, in your own words: six years in retail banking, the last three as a branch supervisor; handled the branch's formal complaints log and trained new tellers on the escalation script; built the monthly complaints spreadsheet your regional manager uses. Then say why this role, in your own words; your material states no reason for moving, so the pack supplies none | F6 is the knock-out check this screen scores first, and F1, F3 and F5 supply the beats; EXP because it tests whether the spoken story matches the CV line by line |
| R1-A2 | "The role works with digital teams on self-service journeys. When have you come across that side of things?" | JD | [grounded] | This is F9's silence in a friendly register, and it is scored. Answer slot: if you have had any contact with digital teams or self-service journeys, say what and what part was yours, in your own words; if none, say so plainly, then say what you would ask digital teams first | F9 is the one requirement with no quote behind it; JD because it scores a stated responsibility, delivered casually |
| R1-A3 | "What are you looking for, salary-wise?" | JD | [generic] | Logistics slot: give your own figure in your own words, or ask for the role's band first. The pack supplies no figure and no history; decide yours before the call | Recruiters cover pay in the screen, so it is a row; JD because it concerns the listed job's terms |
| R1-A4 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period, in your own words. If you are unsure of your contract's terms, read them before 26 November | Notice is a standard screen item; JD for the same reason as R1-A3 |
| R1-A5 | "The role spans branches and the contact centre. Where can you work, and how often?" | JD | [grounded] | Logistics slot: say plainly where you can work and how often, in your own terms. If you have no constraint, say so; if you do, state it once rather than apologising for it | The JD line "across branches and the contact centre" makes location a live term; JD because it is the listed job's terms |
| R1-A6 | "What's prompting you to look at a move now?" | EXP | [generic] | Logistics slot: give your actual reason in one or two sentences, in your own words, covering what you are moving toward as well as away from. Keep one version; rounds 2 and 3 will hear it again | The reason for leaving is a recruiter-screen staple and the likeliest place for inconsistency across rounds; EXP because it is about your own history |
| R1-A7 | "Why Ashgrove, and why a member-owned credit union?" | CO | [grounded] | Bring one published item to show you have read the material, such as a value by name or the brief's point on app-only banks, then say your own reason in your own words. The pack states no reason of yours. Do not recite all four values; any prepared candidate can | CO because it tests homework depth; the recruiter is also checking that your motive holds up in rounds 2 and 3 |

#### B Skeptic, light

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-B1 | "This role covers the contact centre too. How do you see that, given your background?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The light version of R2-B1. Say plainly: "I have never worked in a contact centre." Then what your material carries, at its scope: "I handled the branch's formal complaints log." Then a plan, as a plan: what you would want to learn first about how a complaint reaches and moves through the contact centre. Stop after the plan; do not fill the silence | F2 is a stated negative and the screen's likeliest knock-out; JD because the contact centre is named in the role's first line |
| R1-B2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Choose from what you have said yourself: the contact centre (F2) or presenting above regional level (F8). Name one plainly in your own words, then say the order in which you would close it. Do not offer a gap you have not stated, and do not dress a strength up as a weakness | F2 and F8 are the two stated limits, so a candid pick is available; JD because it scores honest self-assessment against the listed requirements |

### Round 2 — Head of Member Services

#### B Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-B1 | "You'd own this end to end across branches and the contact centre. What part of that have you owned yourself?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "Never worked in a contact centre, and I've never presented to anyone above regional level." | The highest-ROI rehearsal in this pack. Hold what the quote carries: "I handled the branch's formal complaints log." Concede before you are asked: "I have never worked in a contact centre." Answer slot: if any step of a complaint's path was yours to do or decide, say which and how, in your own words; if none was, or it was not yours, say so plainly and describe how the log worked. Hold through three follow-ups (what that included; what about the contact centre; why should we believe you can take it on) by returning to the log and a plan, never by adding to the log | F1 and F2 are where the JD's first line presses, and this person would manage the hire, so this objection will arrive in some form; JD because it scores the stated responsibility |
| R2-B2 | "The role presents to senior leaders. What's your experience of that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I built the monthly complaints spreadsheet our regional manager uses." | Plain acknowledgment: "I have never presented to anyone above regional level." Answer slot: if you have presented at regional level, say to whom, about what and how it went, in your own words; if you have not, or the spreadsheet was shared rather than presented, say so plainly. Then your plan, said as a plan: how you would prepare a monthly report for that audience | F8 is a stated limit and a headline requirement; JD because it scores a stated requirement, and the honest answer is the rehearsed one |
| R2-B3 | "You trained new tellers on the escalation script. How would that carry over to coaching branch supervisors?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "6 years in retail banking, the last 3 as a branch supervisor." | Hold the quote at its scope: "I trained new tellers on our escalation script," and the last three years were as a branch supervisor. Answer slot: if teaching the script ever meant helping someone through a live escalation, say what you did and what part was yours, in your own words; if it did not, say so plainly and stay with how you trained the tellers. Do not describe training new staff as the same work as coaching supervisors | F5 is adjacent evidence; JD because it scores the coaching line, and the question's premise is the interviewer's own, so the guidance does not adopt it |
| R2-B4 | "The role needs experience handling regulated complaints. What did that look like in your branch?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Start from the quote at its scope: "I handled the branch's formal complaints log." Answer slot: if the complaints in that log carried regulatory rules or deadlines, say which and what each required of you, in your own words; if you do not know, or the log was not tied to such rules, say so plainly and stay with the log | F7 is the JD's phrase and your material does not settle it; the question presupposes it, so the slot allows that the premise is false |

#### C Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-C1 | "When did you put a member ahead of an internal metric?" | VAL | [grounded] | Selection scaffold: pick a time a named member's need and a number or target pulled apart. It needs the choice you made, what it cost, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. No quote carries this story, so the pack supplies none | A standard behavioural stem that matches the published "Members First, Always"; VAL because it scores behaviour against a value |
| R2-C2 | "Tell me about a time you had to give someone senior an unwelcome truth." | VAL | [generic] | Selection scaffold: pick a time someone senior to you needed to hear something unwelcome. It needs a named stake, what you actually said, and what happened next. If no such time comes to mind, say so plainly, then say how you would do it. Choose a story where the truth landed; where yours did not, say that | The role reports monthly and F8 is a stated limit, so this tests whether you can say hard things upward; VAL because it scores behaviour |

#### D Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-D1 | "Imagine your first 90 days owning complaints across branches and the contact centre. What do you need to know first, and what would you do?" | CASE | [grounded] | Makes no claim about your past. Clarify first: where complaints enter, how they move between branch and contact centre, what the monthly report shows today, who holds each step. Then objective, a split by channel, approach, the JD's own metrics (volumes and resolution times), risks. Say your structure aloud and challenge one premise | The hiring-manager prior gives this a place, and F1 and F2 are where it presses; CASE because it is a live problem from the role |
| R2-D2 | "The plan is to move 40% of member service to digital channels by 2028. What does that change about how complaints are found and handled?" | CO | [grounded] "move 40% of member service to digital channels by 2028" — strategy brief, as you reported it | Clarify before you structure: which journeys move first, and what member help will exist at the point of complaint. Then channels, risks and the metrics. The brief as you gave it states the target, not the design, so do not assert what Ashgrove plans; ask. Use "member" throughout | The strategy brief makes this a likely CO question; it also meets F9's requirement without claiming any past work |

#### F Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-F1 | "Walk me through the monthly complaints spreadsheet you built. What does it show?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on the quote's own beats: you built it, it is monthly, it is about complaints, and your regional manager uses it. Answer slot: the JD names volumes and resolution times, so expect a probe on what yours showed. If it counted either, say how each was counted and the assumption you would defend least; if you do not know how something was counted, say so plainly | F3 is the only reporting evidence; EXP because it tests whether your account of the spreadsheet survives follow-up |
| R2-F2 | "How comfortable are you with Excel reporting?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Start at the quote's scope: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if it was in Excel, say so and say what you did in it, in your own words; if it was another tool, or part of it was built by someone else, say so plainly. Name no function or feature you did not use | F4's evidence does not name the tool; JD because it is a stated requirement and an easy one to bluff |

### Round 3 — panel of two branch managers

#### C Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-C1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold for "Members First, Always": pick a decision where the member's need and the easier route differed. It needs the decision, what it cost you or the branch, and how the member was left. "We" for context, "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, at its scope: "I handled the branch's formal complaints log" | The value's own wording is the question's theme; VAL because the panel scores it against the published value |
| R3-C2 | "Tell me about a time something you explained didn't land the first time." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on the quote's beat: "I trained new tellers on our escalation script." Answer slot: "Plain Words" tests whether something needed explaining twice. If any part of training the tellers did, say what, and what you changed in how you explained it; if none did, say so plainly and describe how you taught the script | F5 is the one sentence that carries teaching; VAL because it scores a published value |
| R3-C3 | "Tell me about a time you weighed what a number said against what your branch's town needed." | VAL | [grounded] | Selection scaffold for "Neighbours, Not Numbers": pick a time a figure and a community need pointed different ways. It needs the figure, the need, the call you made and how it ended. If no such time comes to mind, say so plainly, then say how you would weigh the two. No quote carries this story, so the pack supplies none | The value's own wording is the theme; the panel are branch managers, and VAL because it scores a published value |
| R3-C4 | "Tell me about a time you found a problem and stayed with it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold for "Own the Fix": pick a problem you found, who else could have let it drop, what you did next, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, at its scope: "I handled the branch's formal complaints log" | The role's first line and the value make the same demand; VAL because it scores a published value, and the nearest quote carries a log, not an ending |
| R3-C5 | "Eight branches are becoming five hubs over 2027. What does 'Neighbours, Not Numbers' mean for a member whose branch is folded into a hub and who then has a complaint?" | VAL | [grounded] "consolidate eight branches into five hubs over 2027" — strategy brief, as you reported it | Makes no claim about your past. Start from the member, then the town, then the escalation path and what you would measure (volumes and resolution times). The brief as you gave it states the consolidation, not the plan for any town, so ask which towns and when rather than asserting. Do not guess how the panel feels about it | G2 is the strategy item closest to a branch manager's own job, and the question joins it to a value; VAL first because the panel scores values, CO second |

#### D Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-D1 | "Case, twenty minutes: a complaint is escalated from the branch counter to a formal complaint. The member says the branch and the contact centre gave different explanations. How do you handle it?" | CASE | [generic] | An example built from the recruiter's "complaint escalation" line; the real case is not known. No claim about your past. Clarify first: what the member wants, what each channel said, what is recorded, and which deadlines apply. Then objective (the member understands what happened, and someone keeps hold of the fix), what is needed now versus the cause versus the record, approach, metrics, risks. Structure aloud; challenge one premise | The email names a 20-minute escalation case in this round; CASE because it is a live problem from the role |
| R3-D2 | "The supervisor who first handled that complaint disagrees with how you've taken it forward. What do you do?" | CASE | [generic] | A follow-up on D1. No claim about your past. Hear their account first; separate what the member needs from who was right; agree what changes and who tells the member; leave the supervisor able to handle the next one. Ask what they saw that you did not | The JD makes coaching supervisors part of the role (F5), and cases usually branch; CASE because it is a live problem |
| R3-D3 | "Your monthly report shows resolution times rising in two branches. What do you do?" | CASE | [generic] | No claim about your past. Clarify: how far, since when, which complaint types, whether volumes moved, anything one-off. Segment by branch, channel, type and stage; form hypotheses; call the branch managers before the report goes up; say in plain words what the report should show. Name your assumptions | The JD makes monthly volumes and resolution times a core output (F3); CASE because it is a diagnosis problem |

#### E Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-E1 | "Where is the seam between what a branch handles and what you would own centrally, and what happens when we disagree?" | JD | [grounded] "Own the Fix — whoever finds the problem keeps hold of it until it is solved." — the published value, as you pasted it | Offer seam principles, not claimed knowledge of the seam. A reading to test, put as a question to them: the JD has you own the process end to end while the value has whoever finds the problem keep hold of it, so the branch might keep hold of the member's problem and you might own the process it runs through. Then reciprocity: what your ownership would give their branch, said as a plan | The panel are the people on the branch side of the role; JD because it scores the shape of the job; the reading is the pack's inference, not Ashgrove's practice |
| R3-E2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Selection scaffold: pick a time work spanned teams. It needs what each side did, how credit was shared, and what you would do differently. "We" for context, "I" for your part. If no such time comes to mind, say so plainly, then say how you would share credit | A standard Peer Evaluator stem; EXP because it tests attribution honesty |

#### F Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-F1 | "Take us through a formal complaint you handled, from the first contact to the end." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on the quote's one beat: "I handled the branch's formal complaints log." Answer slot: choose a complaint you can tell without a detail you cannot stand behind, and leave out anything that identifies the member. If you cannot recall the steps, or the log was only part of how the complaint was handled, say so plainly and describe how the log worked | F1 and F7 rest on the log; branch managers know the branch side of a complaint, so a thin account would be noticed; EXP because it tests your account |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "Own the member complaints process end to end across branches and the contact centre" | R1-B1, R2-B1, R2-D1, R3-D1, R3-F1 |
| "report monthly on complaint volumes and resolution times" | R2-F1, R3-D3 |
| "coach branch supervisors on escalations" | R2-B3, R3-D2, R3-E1 |
| "work with digital teams on self-service journeys" | R1-A2, R2-D2 |
| "4+ years in financial-services customer operations" | R1-A1 |
| "experience handling regulated complaints" | R2-B4, R3-F1 |
| "confident presenting to senior leaders" | R1-B2, R2-B2, R2-C2 |
| "comfortable with Excel reporting" | R2-F2 |
| Defend-the-number on a headline figure | None. Your material carries tenure (6 and 3 years), not a result figure, so no figure raises a defend-the-number slot |
| Pay, notice, location, reason for leaving | R1-A3, R1-A4, R1-A5, R1-A6 |
| Four published values | Members First, Always: R3-C1, R2-C1; Plain Words: R3-C2; Neighbours, Not Numbers: R3-C3, R3-C5; Own the Fix: R3-C4 |

## Values cheat sheet

Detected: the recruiter's email says the panel "is also the values round". The value names are as you pasted them from the Ashgrove values page on 17 November 2026.

| Value | Working meaning | Your mapped story | Provenance |
|---|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Selection scaffold, R3-C1: a decision where the member's need and the easier route differed, what it cost, how the member was left. If none comes to mind, say so plainly, then the nearest thing F1 carries: "I handled the branch's formal complaints log." | [grounded] |
| Plain Words | If a member needs something explained twice, the wording is what failed | F5: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Its beat is training the tellers; whether anything needed explaining twice is R3-C2's slot | [grounded] |
| Neighbours, Not Numbers | Every branch is part of its town | Selection scaffold, R3-C3: a figure and a community need pointing different ways. If none comes to mind, say so plainly, then say how you would weigh the two | [grounded] |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Selection scaffold, R3-C4: a problem you found, who else could have let it drop, how it ended. If none comes to mind, say so plainly, then the nearest thing F1 carries: "I handled the branch's formal complaints log." | [grounded] |

## Reverse questions

| Round | Question | Why it lands | Provenance |
|---|---|---|---|
| R1 | "Will the panel's case be shared in advance, and in what form?" | The email says the case is 20 minutes and does not say whether materials come first; the recruiter is the one person who can say, and it tells you how to spend the nine days | [grounded] |
| R1 | "What does the process look like after the panel, and when would you expect a decision?" | A plain process question that shows you are planning, and it is the recruiter's to answer | [generic] |
| R1 | "Which of the four requirements will the Head of Member Services weigh most?" | It tells you where to put your hold in R2-B1 and R2-B2, and the recruiter can answer without breaching anything | [grounded] |
| R2 | "Where does a complaint change hands today between a branch and the contact centre, and what goes wrong at that point?" | It asks the manager for the seam in F1 and F2 directly, from someone who has already conceded the contact-centre gap | [grounded] |
| R2 | "What would the first 90 days need to have shown by the end?" | It turns the case in R2-D1 into a shared plan | [generic] |
| R2 | "How do you expect complaints to change as 40% of member service moves to digital?" | It uses G1 and invites the manager's own view of the digital target | [grounded] |
| R2 | "When the small-business lending product launches in Q1 2027, who will own the complaints it generates?" | It uses G3 and tests how far "end to end" is meant to stretch | [grounded] |
| R3 | "What does Own the Fix look like when a branch finds a problem whose cause sits with another team?" | It reuses the value in the panel's own terms and asks for their practice, not your theory | [grounded] |
| R3 | "How are branch managers expected to work with the people in this role once eight branches become five hubs?" | It uses G2 and asks about the panel's own working life without presuming how they feel | [grounded] |
| R3 | "What could a new person in this role do in the first month that would genuinely help your branch?" | The reciprocity question for a peer-side panel; it puts what you give before what you need | [generic] |
| R3 | "What would make you say the case went well?" | It asks for the scoring standard directly | [generic] |

## Prohibited claims

Built locally from the fit snapshot, before any question was written. This pack will not coach these claims.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation, not words for you: the material says the branch's log, not the process end to end and not across branches. R2-B1's slot stays inside the log |
| Coached branch supervisors on escalations | Inflated form of F5 | F5's quote at its own scope: "I trained new tellers on our escalation script." The material says tellers, not supervisors. The slots on R2-B3 stay inside the training of the tellers |
| Has worked in a contact centre, or handled complaints across channels | Negative you stated, F2 | The plain acknowledgment F2 gives: "I have never worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment F8 gives: "I have never presented to anyone above regional level." The slot on R2-B2 asks only about regional level |

## Sources

Provided documents:

- The JD you pasted for Member Experience Lead at Ashgrove Credit Union.
- The four values you pasted, copied on 17 November 2026 from ashgrovecu.org/about/values. That URL is where your text came from; it was not fetched.
- The recruiter's email on the three rounds of 26 November, which establishes the loop: three sessions, who runs each, and what each holds.
- The strategy points from the July 2026 brief, as you gave them. The brief itself was not seen.
- Your background, in your message. No CV document was provided, and no dossier was present.

Searches and fetches sent: none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove Credit Union values | skipped | The four values are pasted and in hand, so the values cheat sheet and the VAL questions rest on them |
| 2. Ashgrove interview process, member experience role | skipped | The recruiter's email fixes the loop (rounds, who runs them, what each holds), so the persona weights rest on it and no archetype fallback was used |
| 3. Ashgrove strategy or recent news | skipped | The four brief points are in hand and under six months old, so the grounding brief and the CO questions rest on them; the brief itself was not seen |
| 4. Interviewer name and Ashgrove | n/a | No interviewer has a name yet, so there was no query to form; the interviewer read is absent |
| 5. Representative Member Experience Lead JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV, or your answers to the answer slots in F1, F3, F4, F5, F7 and F9 → each answer enters the fit snapshot as quoted material and the rows and bank cells that draw on it regenerate; the guidance becomes story-mapped instead of slotted
- An anonymised copy of the monthly complaints spreadsheet, or a screenshot of its layout → the inspectable artifact that can lift F3 and F4 from `medium` and `low`
- The name of the complaint rules or timeframes your branch's formal complaints followed, if any → settles F7 and R2-B4
- The interviewers' names once assigned → an interviewer read, persona weights tuned to each person's public footprint, and a reverse question tied to their own path
- The recruiter's guidance on the case (whether materials are shared in advance, how much reading time) → a build section for the case in place of the pattern in R3-D1 to R3-D3
- The strategy brief itself, pasted → the grounding brief and the CO questions move from your four reported points to the brief's own wording
- A deeper research pass, up to 6 more searches and 2 more fetches, several more minutes → a fuller picture of Ashgrove's strategy, recent organisation changes and reports of its interview loop; say the word and I will run it
- A tuesday-dossier.md from an earlier evaluation of this role → verified evidence and a prohibited-claims list that tighten the guidance cells
