I'll start by reading the skill's reference files.
I'm reading the skill's persona, question-rubric and research references so the pack follows its rules. Then I'll research Stripe and build it.
Web search was refused in this session, so I'm building the pack from your message alone. Anything about Stripe will be labeled as unresearched rather than filled in from memory.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a/runs/sonnet/alone/part-2/rooms/case-3-denied-c0fe1bba/stripe_product-operations-manager_interview_pack.md`. It has 21 questions across seven interviewer styles, a fit worksheet, requirement coverage, six reverse questions and an upgrade menu.

It rests on thin inputs:
- **No Stripe research:** web search was refused in this session, so the pack has no Stripe values, loop structure or strategy. I used nothing from memory. The two company questions (B3, F3) are generic until you paste Stripe's own material or allow search.
- **No CV or JD:** the fit snapshot is a worksheet, with six role-family requirements instead of Stripe's actual ones.
- **Flat weights:** I didn't know who you're meeting, so all seven styles carry equal weight.
- **Provisional top prep:** B1, "Which part of this role would you be weakest at on day one?", is the highest-ROI rehearsal for now. Without your CV I can't tell where your material is thinnest.

Say the word and I'll run a live drill, playing the interviewer on B1 or any question you pick. I can also save a `tuesday-dossier.md` recording the gaps this prep exposes, or convert the pack to a Word document.

Two questions would restructure the pack:
1. Who is your final round with, one session or several, and did the recruiter name any focus areas or a presentation or take-home?
2. Can you paste the job description and your CV, or should I proceed without them?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe — Product Operations Manager: final-round prep pack

Interviewer(s): not given. Relationship: not given. Built for a final round of unknown structure, so persona weights are flat. No CV or JD was supplied, so the fit snapshot is a worksheet, and no web research was available, so nothing here is a fact about Stripe.

## How to use this pack

- **Personas** describe how a question is asked (who is asking, in what style). **Types** describe what is being scored.
- Type key: **VAL** = behavioral and values alignment; **EXP** = work-experience deep-dive and attribution honesty; **JD** = role and responsibility fit, including gaps; **CO** = company and strategy knowledge; **CASE** = a live problem solved aloud.
- Guidance is scaffolding, not a script. Every answer is built from your own experience, in your own words. Where a cell says "answer slot" or "selection scaffold", the content has to come from you.
- Question IDs run by persona (A1, A2, B1 …) so a drill can name one.
- Highest-ROI prep, provisional: B1. With no CV, the pack cannot see where your material is thinnest. Re-point this once you send one.

## Fit snapshot (worksheet)

No CV or background was given, so every evidence cell is empty. The requirements are role-family patterns for product operations, not Stripe's posting, which is why each is labeled generic. Each row says what strong evidence would look like, then gives a selection scaffold.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Runs cross-functional launches or programs across several teams (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a named launch or program, your specific role in it, and what happened. Selection scaffold: pick one that had a date, more than one team and a real stake. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Builds or runs an operating rhythm: planning, reviews, process (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a recurring process you set up or ran, who used it, and what it replaced. Selection scaffold: pick one that outlasted the first version. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Uses metrics and analysis to inform product decisions (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a figure you can explain end to end: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Selection scaffold: pick the number you know best. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Influences teams that do not report to you (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a case where you changed what another team did without authority over it, and how. Selection scaffold: pick one where there was real resistance. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Prioritizes and makes progress under ambiguity (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a decision made with incomplete information, what you assumed, and what you did when the assumption was tested. Selection scaffold: pick one where you were wrong in some part. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Clear reasons for this role and this company (every final round asks, in some form) | none given | none | [generic] | discovery | Strong evidence is reasons specific enough that they would not fit any other employer. Selection scaffold: pick reasons you hold today, in your own words. If your reasons are mixed, say so plainly, then give the nearest thing your material does carry |

No row is a gate: nothing supplied states a location, schedule, authorization or credential term.

## Persona table

No loop source was read, and your message says only "final round". The pack does not assume how Stripe structures its final, so it falls back to the generic archetype with flat weights. If your final is several sessions, send the schedule and the pack will be split per session.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy (rehearsal method) |
|---|---|---|---|
| Case / Strategist | Live problems set in the role: plan this, diagnose that | Equal. Product operations work is cross-team by nature, so live problems are plausible; nothing in the material says which interviewer asks them | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic | Quiet probing of day-one weaknesses and why this role, why now | Equal. Any final round can probe motivation; the material has no CV to aim it at | Rehearse the single most predictable objection until it is boring; calibrated candor over bluffing |
| Pressure | Time-boxed, interrupting, challenges attribution | Equal. Whether the final includes a stress style is unknown | Pause, restate, anchor in what you actually did, hold through two follow-ups, then concede specifically |
| Values / Behavioral | Scenario probes on how you behave with leadership, customers and peers | Equal. No published Stripe values were retrieved, so no values-style round is detected or assumed | Story per question where your material carries one, a selection scaffold where it does not; "we" for context, "I" for contribution |
| Data-Driven Prober | Goes two levels deep on any figure | Equal. Metrics are central to the role family | Know how each number was counted; say plainly when you do not know; name the weakest assumption first |
| Conversational | Friendly, unstructured openers that are still scored | Equal. Finals often open this way, but nothing here confirms it | A 90-second arc for the biography question; treat casual questions as scored |
| Peer Evaluator | Seam-splitting with adjacent teams, collaboration scenarios | Equal. A product operations hire sits between teams, so a peer is plausible | Reciprocity framing; propose seam principles rather than pretending to know the seam |

## Question banks

Every question is generic: none rests on a sentence of yours, so Provenance carries the label alone. Types and counts follow the flat weights, three per persona.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two product teams want the same launch week and the same support capacity. How do you decide — what do you need to know first?" | CASE | [generic] | Clarify before structuring: what each launch is tied to, what slipping costs each, what the capacity actually is. State the objective, list two or three options, name the metric you would use to choose, and name the risk of your pick. Challenge one premise, for instance whether the week and the capacity really are fixed. The question asks about no past, so the guidance makes no claim about yours | Tests structure before answer on a cross-team trade-off (F1, F5); CASE because it is a live problem |
| A2 | "A metric the product org reviews every week has dropped 20%. Diagnose it." | CASE | [generic] | Say your order aloud: first rule out the measurement (definition, instrumentation, data delay), then segment (who, where, when), then look for causes, then say what you would check next. Name what you would not conclude yet. No claim about your past | A persona-stem diagnosis case (F3); CASE because it is solved live |
| A3 | "Design the operating rhythm for a product org whose teams each plan in their own way. What do you standardize and what do you leave alone?" | CASE | [generic] | State a hypothesis early. Offer principles rather than a calendar: standardize what other teams need to read, leave alone what only the team needs. Say what standardizing costs. Ask one clarifying question about the org before you commit | Tests judgment about process weight (F2); CASE with JD content |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Highest-ROI rehearsal, provisional. Selection scaffold: choose a real weakness from your own material, one the role would actually test. Say it plainly in one sentence, say what you would do about it in the first thirty days, and say how you would know it was closing. Rehearse three follow-ups: "and if that did not work?", "who would you ask?", "why is that your weakest and not something else?". If no honest weakness comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Never name a weakness that is a strength in disguise | The one question this pack expects in some form whatever the CV says (F1–F5); JD because it scores the role's stated demands, delivered as a Skeptic probe |
| B2 | "Why product operations, and why now?" | JD | [generic] | Your actual reasons, in your own words, in two or three sentences: what pulled you toward the work and why the timing is yours. Test each reason by asking whether it would be true for any employer; keep the ones that would not. If your reasons are mixed, say so plainly | Motivation consistency (F6); JD because it scores fit with the role |
| B3 | "Why Stripe, rather than another company?" | CO | [generic] | This pack could not research Stripe, so it supplies no company fact. Before the interview, read Stripe's own current published material and choose one thing from it you can speak to from your own experience. Say only what you read. If your honest reason is mostly the role, say so plainly, then give the nearest thing your material does carry | Company-specific motivation (F6); CO because it tests homework, and it stays generic until research or a pasted brief exists |

### C. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause and restate the question. Give one reason from your own material, not a list. Hold it through two follow-ups. Concede specifically what an internal candidate knows that you do not yet, and say how you would close that. Never disparage the other candidate | Composure and hold-then-concede (F6); JD because it scores role fit |
| C2 | "Pick the project you are proudest of. How much of it was actually you?" | EXP | [generic] | Selection scaffold: pick a project where you can separate your part from the team's. Say "we" for the team and "I" for your part, and be exact about the line. Hold that line through two follow-ups. Concede what you did not do or did not know. If no project comes to mind where you can say that cleanly, say so plainly, then give the nearest thing your material does carry | Attribution honesty under pressure (F1, F4); EXP because it tests what was the candidate's |
| C3 | "You will be pushing on teams that do not report to you. Why would they listen?" | JD | [generic] | Answer as a plan first: what you would learn about each team's goals, what you would offer before asking, how you would handle a no. If your material carries a time you did this, tell it in your own words; if not, say so plainly and answer from how you would handle it | Influence without authority (F4); JD because it scores the role's mandate |

### D. Values / Behavioral

No Stripe values were retrieved, so these use general behavioral themes. They are not mapped to Stripe's named values.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: a named stake, a moment you said it plainly, and what happened to the relationship and the decision afterward. Choose a story where the truth actually landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona-stem prompt (F4); VAL because it scores behavior, not content |
| D2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a case where the two really conflicted and you can name what each was. Say what you chose, what it cost, and what you would do differently. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona-stem prompt (F5); VAL |
| D3 | "How do you handle credit when work spans teams?" | VAL | [generic] | Say your principle first, in one sentence. Then an example if your material carries one: what you said, to whom, and the effect. "We" for the group, "I" for your part. If no example comes to mind, say so plainly and answer from the principle | Persona-stem prompt, collegial in tone (F4); VAL |

### E. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Choose one number from your work. Walk me through how it was counted." | EXP | [generic] | Answer slot for the figure you choose: say how it was counted, what it is sensitive to, which assumption behind it you would defend least, and which part was yours, each in your own words. Name the weak assumption before they do. If you do not know how part of it was counted, say that plainly rather than reconstructing it | Defend-the-number rehearsal (F3); EXP because it tests whether a claim survives scrutiny |
| E2 | "How would you tell whether a product operations function is working? Which two measures, and what would you distrust about each?" | CASE | [generic] | Pick two measures, say what decision each would inform, and name its weakest point yourself, for example what it would reward or hide. No claim about your past | Metric judgment with the weakest-assumption move built in (F3); CASE because it is posed as a design problem |
| E3 | "Two dashboards show different numbers for the same metric in a review. What do you do?" | CASE | [generic] | In the room: do not pick a number. Ask for each definition and source, find where they diverge, agree on one definition with the owner, and say who would record it. Name the risk of settling it live. No claim about your past | Data-trust scenario (F3, F2); CASE |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So — walk me through the journey." | EXP | [generic] | A 90-second arc in three beats from your own career: where you started, what pulled you toward product operations, why this role. Rehearse it aloud with a timer. Each beat has to be something you can be asked about in detail | The biography opener, scored despite the casual register (F6); EXP |
| F2 | "What have you been experimenting with lately in how teams plan or work?" | JD | [generic] | Casual, but scored. Give your real answer in your own words: what you tried and what you learned. If you have not tried anything lately, say so plainly and say what you are curious about | Probes live interest in the craft (F2, F5); JD |
| F3 | "What do you already know about what Stripe's product teams are working on?" | CO | [generic] | This pack has no Stripe research, so it supplies no answer. Read Stripe's own current published material before the interview and speak only to what you read. If you have not, say so plainly rather than guessing | Homework signal (F6); CO, generic until research or a pasted brief exists |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our teams sit side by side — where is the seam, and what happens when we disagree?" | JD | [generic] | Offer seam principles rather than a map you cannot know yet: who owns a decision, who is consulted, who is told. Name how you would raise a disagreement and when you would escalate. Show spine and tact together. Ask what the seam is today | Seam awareness (F2, F4); JD |
| G2 | "What would you need from me in your first month?" | JD | [generic] | Reciprocity framing: one or two specific things you would ask for, plus one thing you would bring to their team's work in the same month. Keep it to what you can honestly offer | Partnership fit (F4); JD |
| G3 | "A team you support keeps skipping the process you have set up. What do you do?" | CASE | [generic] | Ask why before you enforce: is the process costing them more than it returns? Then choose between changing the process, making it easier to follow, or escalating, and say how you would decide. No claim about your past | Tests whether a process is a means or an end (F2, F4); CASE |

## Requirement coverage

| Requirement | Covered by | Note |
|---|---|---|
| F1 cross-functional launches | A1, B1, C2 | |
| F2 operating rhythm | A3, E3, F2, G1, G3 | |
| F3 metrics and analysis | A2, E1, E2, E3 | |
| F4 influence without authority | C3, D1, D3, G1, G2, G3 | |
| F5 ambiguity and prioritization | A1, D2, F2 | |
| F6 role and company motivation | B2, B3, C1, F1, F3 | The company-specific part (B3, F3) stays generic until research exists |

CO coverage is thin: B3 and F3 are the only company-knowledge questions. Without research or a pasted brief, any CO question about Stripe's current strategy would be invented.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does success look like in this role at six months, and how would you know?" | Moves the conversation to measurable outcomes, and the answer tells you what you would be held to |
| R2 | "Which teams does this role work with most, and where do those partnerships currently hurt?" | Shows you think in seams and friction, and surfaces the real problem to solve |
| R3 | "How has this role changed since it was opened?" | Reveals whether the scope is settled or still being decided |
| R4 | "What do the strongest people on this team do in their first ninety days that others do not?" | Gives you a concrete bar to aim at |
| R5 | "What is hardest to see about this role from the outside?" | Invites candor and signals you want the unvarnished version |
| R6 | "What would you want to be different about how product work is run here a year from now?" | Surfaces the interviewer's own priorities and where you could help |

None is tied to an interviewer's own path, because no interviewer profile was given. With a peer in the room, add: "What could a new person do in their first month that would genuinely help your team?"

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| None listed | No CV or background was given, so there is no sentence of yours to inflate and no negative you have stated | Every selection scaffold and answer slot above stays in your own experience, and ends with an honest branch. A claim enters this pack only after you state it |

## Sources

Provided documents: your message (company, role title, "final round"). No dossier was present.

Searches sent, all refused by the session's permission setting, so none returned anything:

- "Stripe operating principles values" — refused
- "Stripe interview process Product Operations Manager" — refused
- "Stripe strategy 2026 news" — refused
- "Stripe Product Operations Manager job description" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | Every call was refused. It would have fed a values cheat sheet and the VAL bank's mapping to named values; neither is in this pack |
| 2. `Stripe interview process Product Operations Manager` | unavailable | Every call was refused. It would have fixed the loop structure and persona weights; the pack uses the generic archetype instead |
| 3. `Stripe strategy` / recent news | unavailable | Every call was refused. It would have fed CO and CASE questions grounded in current strategy; B3 and F3 stay generic |
| 4. `{interviewer name} Stripe` | n/a | No interviewer name was given, so there was no query to form |
| 5. representative `Product Operations Manager` JD | unavailable | Every call was refused. It would have replaced the six generic requirement rows with quoted ones |

## Upgrade menu

- Your CV → the six worksheet rows in the fit snapshot become quoted evidence, the guidance cells become story maps, and the highest-ROI objection is chosen from your actual gaps. For this field, the artifacts that raise confidence from medium to high are a launch plan, an operating-review document or a dashboard you built and can show
- The job description text → the six `[generic]` requirement rows become `[grounded]`, and every mid-list requirement gets a question
- The recruiter's prep email, naming focus areas, a presentation or take-home, and whether your final is one session or several → a build section for any announced deliverable, and per-session mini-packs if the final is several sessions
- The interviewers' names and roles → an interviewer read, persona weights tuned to them, and a reverse question tied to their own path
- Stripe's own published values or principles page, or a strategy brief, pasted here, or search permission → a values cheat sheet, grounded CO questions, and a grounding brief. A deeper research pass is also available: up to 6 more searches and 2 more fetches, several more minutes
- How much prep time you have → a prioritized schedule sized to it
- A tuesday-dossier.md from a job-underwriter run → verified evidence and an evidence-derived top objection in place of the inferred one
