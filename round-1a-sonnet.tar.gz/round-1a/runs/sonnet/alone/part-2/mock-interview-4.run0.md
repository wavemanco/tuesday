I'll read the skill's reference files first.
I've saved the prep pack and am running a formatting check on it before I send it over.
Your prep pack is saved as `quartzline_product-manager-platform-apis_interview_pack.md`. I built it for a hiring-manager round, from your note and the Tuesday dossier. The one thing missing is anything about Quartzline itself: the host refused all three of my web searches, so nothing in the pack comes from research on the company. The Sources section lists the refused queries. The company-knowledge question (D3) is generic, and you'd need to read their public developer docs yourself before Thursday.

My last formatting check was inconclusive, and I haven't read the pack again since writing it. A stray-bracket count came back at 30, which is probably just the `[grounded]` / `[inferred]` / `[generic]` labels, but I didn't separate those out.

Two things worth knowing before you open it:

- **Highest-ROI prep:** A1 is the objection the underwriter named: "You have never held the PM title or owned a roadmap…". It gets the deepest rehearsal, with a concession, the quoted adjacent work with its limit named, a ramp plan, and two follow-up levels. E1 is the 60-second version of the same objection.
- **What the pack won't coach:** the dossier's three prohibited claims (PM title, roadmap ownership, setting squad prioritization), plus "shipped an API product", which stretches your integration evidence. Roadmap ownership gets a plain acknowledgment and a ramp plan, never a bridge.

Say the word and I'll play the Skeptic on A1, with follow-ups that react to what you actually say.
I can also save an updated `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

Round: 45-minute conversation with the hiring manager, Thursday. Interviewer name and profile: not given, so there is no interviewer read. Built on your tuesday-dossier.md (version 1.1, 2026-08-14) and your note on the round.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for your own words, not a script, and each cell is sized to speak in about two minutes or less.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values (none in this pack: no values-style round was detected) |
| EXP | Whether claims from your background survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | How well you know the company and its strategy |
| CASE | Structure and reasoning on a live problem from the role |

`[grounded]`, `[inferred]` and `[generic]` label where each question and fit row comes from. Answer slots are instructions for the interview: they ask you for nothing here, and every branch of one is a legitimate answer.

## Prep triage

You have two days. Do these in order:

1. Say A1 and E1 out loud five times each, until the concession and the limit come out without flinching. A1 is the highest-ROI prep in the pack: the underwriter named this objection, and it will be asked in some form.
2. Build the D1 arc from the three quoted sentences, and write down your own reason for the move into product, since the pack cannot supply one.
3. Settle your honest answers to the slots in C1, C2 and C3, because those probe your own claims.
4. Run B3 and B5 once each as live cases.
5. Choose which two reverse questions you will ask, starting with reverse questions 1 and 2.

Everything else is insurance.

## Fit snapshot

Requirement text is the dossier's `role_profile`, quoted. Evidence cells hold only your own confirmed sentences from the dossier. No row is a gate: the dossier's `hard_gates` is empty, and a years-of-experience requirement is not a gate.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — JD (dossier role_profile R1) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence 3 | low | [grounded] | transferability | The dossier's bridge is adjacent, never PM experience, and the limit is said aloud. Words: "I led 30+ end-to-end client integrations of the vendor's REST APIs" and "I ran quarterly roadmap-input sessions feeding client evidence to product", then: that is adjacent work, not PM experience. Plain acknowledgment, sourced to `prohibited_claims: "Having held a product manager title or role"`: "I haven't held a product manager title." The sessions are confirmed with limited inspectable proof, so expect a probe on them |
| F2 | "Own the roadmap for the partner-facing API platform" — JD (dossier role_profile responsibilities) | none given | none | [grounded] | capability | The dossier's strategy here is `acknowledge_gap`, requirement text `uncertain_or_weak_areas`: "Owning a roadmap and prioritization authority (R1 sub-claim)", with `prohibited_claims: "Having owned a product roadmap"`. Words: "I haven't owned a product roadmap." Then a ramp plan said as a plan, never as a past: what you would learn first about how the squads decide, the adoption baseline and the partner backlog. No bridge and nothing added to make the gap feel smaller |
| F3 | "Shipped API or platform products" — JD (dossier role_profile R2) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence 2 | low | [inferred] | transferability | The pack's observation: your material says integrations of the vendor's APIs and a playbook, not shipping an API or platform product, so the words stay at "I led 30+ end-to-end client integrations of the vendor's REST APIs". Answer slot: the JD's R2 line makes a probe on what you shipped likely. If any part of what you shipped was an API or platform product, say what and your part; if it was integration work rather than shipping, or the shipping was not yours, say so plainly and stay with the integrations |
| F4 | "Technical fluency: API docs, schemas" — JD (dossier role_profile R3) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence 2 | medium | [inferred] | transferability | The quotes carry REST APIs, architecture and a playbook you wrote, which is adjacent to docs and schemas and does not say you worked with them. Answer slot: the JD names API docs and schemas, so expect a probe on them. If you read or wrote API documentation or worked with schemas in that work, say which and how; if you did not, say so plainly and stay with the REST integrations and the playbook |
| F5 | "Stakeholder management across engineering, sales, customers" — JD (dossier role_profile R4) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence 3 | medium | [inferred] | transferability | The quotes carry clients and product. They do not say engineering or sales. Answer slot: expect a probe on the engineering and sales strands. If you worked with either in that work, say how and what was yours; if you did not, say so plainly and stay with the clients and the product side |
| F6 | "Agile delivery experience" — JD (dossier role_profile R5) | none given | low | [grounded] | discovery | The dossier's strategy is `clarify`: the evidence may exist and was not established. Answer slot: the JD asks for agile delivery experience, so expect that wording as the probe. If you have worked inside an agile delivery process, say how and your part, in your own words; if you have not, say so plainly, and say what you would want to confirm about how Quartzline defines it |
| F7 | "Define and track adoption metrics" — JD (dossier role_profile responsibilities) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1 | low | [inferred] | discovery | The quote has a count and a go-live step and does not show anything defined or tracked. Answer slot: if you counted or tracked any of it, say what was counted and how; if you did not, say so plainly and say what you would want to measure first |
| F8 | "Run discovery with integration partners" — JD (dossier role_profile responsibilities) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence 3 | medium | [inferred] | transferability | Scoping and requirements on integrations you led, and sessions feeding client evidence to product, sit next to discovery and do not say it. Answer slot: expect a probe on whether those client conversations were discovery. If some were, say how you went about them; if they were delivery conversations, or no such step existed, say so plainly and stay with the scoping and requirements |
| F9 | "Write specs and drive delivery with two engineering squads" — JD (dossier role_profile responsibilities) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1 | low | [inferred] | discovery | The quote has requirements and go-live, and does not show specs or work with engineering squads. Answer slot: if you wrote specs engineers built from, or worked through delivery with an engineering team, say what and what was yours; if none of that was yours, say so plainly and stay with the integrations you led |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the PM-title gap, the roadmap gap and the motive for moving | High. The hiring-manager prior is Case/Strategist plus Skeptic. The dossier then names a likely objection and three weak areas (F1, F2, F6), which pushes this to the top | Rehearse the A1 objection until it is boring. Bridges use only the quoted adjacent work, with the limit named. Acknowledge what the dossier says is a gap and offer a ramp plan |
| Case/Strategist | Live problems from the role: partner integration friction, flat adoption, roadmap trade-offs, the squad seam | High. Same hiring-manager prior; the JD's responsibilities are the natural case material. The user's note establishes one 45-minute conversation, so no loop fallback is used | Clarify first, then objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise per case |
| Data-Driven Prober | Reads your claims line by line: the 30+ figure, the sessions, the playbook | Medium. The figure is a defend-the-number target, and the sessions carry a medium-confidence caveat the dossier says to expect probed | Know what you can and cannot say about how each claim was counted or shown, and say plainly where you do not know |
| Conversational | Opens with the journey question and keeps a friendly register | Medium. A 45-minute conversation usually opens this way, and your transition story has to land there | Prepare a 90-second arc and treat casual questions about the JD's topics as scored |
| Pressure | Time-boxes and challenges: why you over a three-year PM, how much was you | Low. Not a hiring-manager prior; it appears only as the A1 objection delivered with force | Pause, restate the question, hold the position through two follow-ups, then concede specifically |

No interviewer signals were available, no loop source beyond your own note was read, and no values-style round was detected. The Peer Evaluator and Values personas are left out for those reasons, and the squad-seam question sits in the Case bank as B5.

## Question banks

### A. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs" "Ran quarterly roadmap-input sessions feeding client evidence to product" | The deepest rehearsal in this pack, and the underwriter's own objection. Open with the concession, sourced to `prohibited_claims: "Having held a product manager title or role"` and `prohibited_claims: "Having owned a product roadmap"`: "That's right: I haven't held a product manager title, and I haven't owned a product roadmap." Then the adjacent case at its own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs, and I ran quarterly roadmap-input sessions feeding client evidence to product. That's adjacent work, and I'm not presenting it as PM experience." Say what you can show from the sessions and what you can't, before they ask, because the dossier marks them confirmed with limited inspectable proof. Stop there and let them draw the inference. Then give the ramp plan as a plan: what you would learn first about how the squads decide, the adoption baseline and the partner backlog. Follow-up 1, "a PM with three years has made the actual trade-offs": hold by returning to the same two sentences, and concede specifically: "Yes, I haven't made those calls on a roadmap, and that's the part I'd be learning." Follow-up 2, "so what makes you think you can": do not reach for a stronger claim. Give the ramp plan again and then your own reason for the move, in your own words | Named by the underwriter as the likeliest objection, from F1 and F2, so it gets the most follow-up levels. JD because it scores R1; Skeptic because it presses exactly where the material is thin |
| A2 | "Tell me about a time you were part of shipping something on an API platform." | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs" "Wrote the internal integration playbook her team uses" | An open prompt, so the beats come only from the two quotes: you led client integrations of the vendor's REST APIs, and you wrote the integration playbook your team uses. Answer slot: the JD's R2 line makes a probe on what you shipped likely. If any part of what you shipped was an API or platform product, say what and your part; if it was integration work rather than shipping, or the shipping was not yours, say so plainly and stay with the integrations. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry | F3 is a must-have requirement with adjacent evidence only, so the probe is certain. JD because it scores R2 directly; Skeptic because it tests whether the bridge holds |
| A3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] | Name the roadmap part, which the underwriter marked `acknowledge_gap` with requirement text `uncertain_or_weak_areas`: "Owning a roadmap and prioritization authority (R1 sub-claim)". Say it plainly: "That's the part I haven't done: I haven't owned a product roadmap." Then the ramp plan as a plan: you would first learn how the two squads decide and where decisions sit, the adoption baseline and the partner backlog, and you would ask what they want first. Do not volunteer a second weakness unless your own honest assessment names one | F2 is the largest gap and this question asks for it directly. Candor beats bluffing a competency the interviewer owns; JD because it scores fit against the listed job |
| A4 | "What's your experience of agile delivery, and of writing specs for engineers?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Clarify strategy, per the dossier. The one quoted fact is that you led integrations including requirements and go-live. Answer slot: the JD lists agile delivery experience and specs with two squads, so expect those words as the probe. If you have worked inside an agile process or wrote specs engineers built from, say which and what was yours; if you never worked that way, say so plainly, say what you would want to confirm about how Quartzline defines it, and return to the requirements and go-live work you led | F6 and F9 are discovery rows: the evidence may exist and was not established, so the honest form is a slot. JD because it scores R5 and a responsibility |
| A5 | "Why move from integration work to product, and why here, why now?" | JD | [generic] | Say your actual reason in your own words, since the pack has none and invents none. Keep it consistent with what you say at D1 and A1. For "why here", use only what you have read of Quartzline yourself, because this pack holds no research on the company. Keep it under a minute | The Skeptic scores motive consistency, and a mismatch between this answer and the arc is what gets noticed. JD because it tests role fit |

### B. Case/Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A partner says the API's authentication flow is why their integration slipped. What do you do first?" | CASE | [generic] | Clarify before structuring: what slipped and against what plan, how many partners are affected, what engineering already knows. Then objective, segmentation of partners, approach, a metric, risks. Challenge one premise aloud: is authentication the cause or the symptom. Say what you would ask engineering rather than pretending to know Quartzline's flow | A live problem from the partner-facing platform and the R3 requirement; the guidance makes no claim about your past. CASE because it scores structure |
| B2 | "Partner API adoption has been flat for two quarters. Diagnose it." | CASE | [generic] | Start by asking how adoption is defined and measured and what the baseline is. The dossier lists that as an unknown, so the question is also real diligence. Then segment, form hypotheses, say which data would separate them. Challenge whether flat is bad against expectations | F7's responsibility, and the dossier's unresolved measurement risk, as a live case. CASE because it scores diagnosis |
| B3 | "Two partners ask for conflicting changes and both squads are full. How do you decide what goes on the roadmap?" | CASE | [generic] | Clarify who decides, since decision authority is an open question on the squad side. State criteria aloud: partner impact, adoption effect, cost to the squads, risk. Then name the limit, sourced to `prohibited_claims: "Having set prioritization for an engineering squad"`: "I haven't set prioritization for an engineering squad, so here is how I'd reason and what I'd want to learn." Propose principles rather than pretending to know the seam | F2 is the gap this case probes. CASE because it asks for a decision under constraint; the honest concession is built in |
| B4 | "How would you run discovery with a new integration partner?" | CASE | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" "Ran quarterly roadmap-input sessions feeding client evidence to product" | Give the method as a plan: objectives, what you would ask, what you would listen for, how the evidence reaches the squads. You can point to scoping and requirements on integrations you led, and to the sessions feeding client evidence to product, at those scopes. Answer slot: expect a probe on whether those client conversations were discovery. If some were, say how you went about them; if they were delivery conversations, or no such step existed, say so plainly and stay with the scoping and requirements | F8 as a case, so a plan is the honest form and your own past only enters at the quoted scope. CASE because it asks for an approach |
| B5 | "You'd work with two squad leads. Where does your call end and theirs begin?" | JD | [generic] | Do not pretend to know the seam: say you would want to learn it, and offer principles you would propose. Add the reciprocity side: what you would bring the squads. Disagreement with equals: spine and tact together. Then turn it back with reverse question 1 | The dossier flags decision authority versus the squad leads as unevidenced (F9 and the risks). JD because it scores R4 and the role's structure, with CASE delivery |

### C. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You say you led 30+ integrations. How was that number counted?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The defend-the-number rehearsal. The number attaches to integrations, so keep it there. Answer slot: say in your own words how the 30+ was counted, what it is sensitive to, and the assumption behind it you would defend least. Then which part of each was yours and which was others, and what "end-to-end" covered in each. If you don't know how any part was counted, say so plainly | The quoted figure is the headline metric and a prober's first target. EXP because it tests attribution and counting |
| C2 | "Walk me through the quarterly roadmap-input sessions you ran." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | The beats the quote states: quarterly, you ran them, client evidence went to product. Tell them in your own words. The dossier marks this medium: confirmed, limited inspectable proof. Volunteer the limit first: say what you can show from the sessions and what you can't. Do not claim anything about what product did with the evidence beyond what you can stand behind | F1's sessions evidence carries the caveat a prober will find. EXP because it tests whether a claim survives scrutiny |
| C3 | "Tell me about the integration playbook you wrote." | EXP | [grounded] "Wrote the internal integration playbook her team uses" | The beats the quote states: you wrote it, and your team uses it. The dossier marks it high and inspectable, so offer to walk through it end to end, sharing only what you are free to share. Answer slot: R3 names API docs and schemas, so expect a probe on the technical content. If the playbook covers API documentation or schemas, say how; if it doesn't, say so plainly and describe what it does cover | F4 is rehearsed on your strongest inspectable evidence. EXP because it tests what was actually yours |

### D. Conversational (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" "Wrote the internal integration playbook her team uses" "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc with three beats, one per quoted sentence, in your own words, naming the work as adjacent to product and not as product. Close on your own reason for the move, which only you can supply. Keep it identical in substance to A1 and A5 | A 45-minute conversation usually opens here, and F1's bridge has to land in the first two minutes. EXP because it checks the story against the background |
| D2 | "What's the most interesting API problem you've worked on lately?" | JD | [generic] | A selection scaffold: pick a real problem with a named stake, what you did and what you learned. The JD's R3 is the raising source, so expect it asked casually and scored. If no such problem comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach one | R3 asked in a casual register. JD because the theme comes from the requirement |
| D3 | "What do you know about our API platform so far?" | CO | [generic] | This pack holds no research on Quartzline, because search was refused in this session. Before Thursday, read their public developer documentation and site yourself, and say only what you read, attributed. Say plainly what you looked at and what you still don't know, which turns a gap into interest | The one company-knowledge question, kept generic because nothing about Quartzline was verified. CO because it tests homework |

### E. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a PM with three years in the seat?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs" "Ran quarterly roadmap-input sessions feeding client evidence to product" | Pause and restate the question. In sixty seconds: the concession in one clause, then the two sentences at their own scope, then the limit. Hold that position through two follow-ups by returning to those two sentences, and concede specifically: you haven't held the title or owned a roadmap, sourced to `prohibited_claims: "Having held a product manager title or role"` and `prohibited_claims: "Having owned a product roadmap"`. Never fold on the quoted work, and never add to it | The A1 objection, time-boxed. JD because it scores R1; the hold-then-concede structure is the rehearsal |
| E2 | "On those integrations you led, how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold "led" at its own scope. Answer slot: say who else was involved and what part was theirs, in your own words; if it was all yours, or you can't separate it, say so plainly. Use "we" for context and "I" for contribution, and don't defend a share you can't back under a second question | A pressure form of C1's attribution check on F1's lead claim. EXP because it tests attribution |

### Requirement coverage

| Requirement or responsibility | Questions | Note |
|---|---|---|
| R1 3+ years product management experience | A1, A3, A5, E1 | F1 |
| Own the roadmap | A1, A3, B3, E1 | F2 |
| R2 Shipped API or platform products | A2 | F3 |
| R3 Technical fluency: API docs, schemas | C3, D2, B1 | F4 |
| R4 Stakeholder management | B5, B3, C2 | The sales strand has no separate question: nothing in the dossier points to a sales probe, and F5's slot covers it |
| R5 Agile delivery experience | A4 | F6 |
| Run discovery with integration partners | B4, C2 | F8 |
| Write specs and drive delivery with two squads | A4, B5 | F9 |
| Define and track adoption metrics | B2 | F7 |
| Headline figure (30+) | C1, E2 | Defend-the-number |

## Reverse questions

Two are the underwriter's own, carried in. No interviewer profile exists, so none is tied to their path.

| # | Question | Why it lands | Source |
|---|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The job description asserts squad authority without evidencing it. It reads as diligence and answers what you need to know before accepting | Dossier questions_for_employer |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | Adoption metrics are a named responsibility with no stated baseline. Asking shows you start from the measure | Dossier questions_for_employer |
| 3 | "What would you want to see from me in the first ninety days for this hire to have worked?" | It turns the ramp plan into a shared target and shows you expect to be measured | Pack |
| 4 | "How do you run discovery with integration partners today, and how often do you hear from them directly?" | It tests the discovery responsibility in your own terms and tells you what you would inherit | Pack |
| 5 | "How do the two squads split the platform, and where do their backlogs collide?" | It maps the seam B5 asked about and shows you are thinking about the work, not the title | Pack |
| 6 | "Given I haven't owned a roadmap before, where would you expect me to need the most support?" | Candor that matches A3, said as a question that invites coaching | Pack |

## Prohibited claims

Built from the dossier's `prohibited_claims`, plus one inflated form from F3. No answer slot, hold, bridge or rationale in this pack asserts, softens or implies any of these.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | `prohibited_claims` (dossier) | "Led 30+ end-to-end client integrations of the vendor's REST APIs" at its own scope, and the plain acknowledgment: "I haven't held a product manager title." |
| Having owned a product roadmap | `prohibited_claims` (dossier), and the `acknowledge_gap` area | "Ran quarterly roadmap-input sessions feeding client evidence to product" at its own scope, and the plain acknowledgment: "I haven't owned a product roadmap." No slot, no bridge |
| Having set prioritization for an engineering squad | `prohibited_claims` (dossier) | The same sessions sentence at its own scope, and the plain acknowledgment: "I haven't set prioritization for an engineering squad." |
| Shipped an API or platform product | Inflated form of F3 | The F3 quotes at their own scope. The limit is the pack's observation: your material says integrations of the vendor's APIs and a playbook, not shipping a product. A2's slot stays inside that scope |

## Sources

Provided documents: tuesday-dossier.md, version 1.1, generated by job-underwriter on 2026-08-14. A dossier was consumed. It supplied `role_profile` (the requirement and responsibility text, standing as the JD), `handoff_to_mock_interview` (verified evidence, weak areas and their allowed strategies, the objection, risks, employer questions, prohibited claims) and `decision` (context only). The dossier carries no `evidence_map`, `evidence_state` or `risk_register`. Round type came from your note.

Searches sent, all refused by the host (permission not granted):

- "Quartzline company values": refused
- "Quartzline interview process product manager": refused
- "Quartzline platform API strategy news": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Every call was refused. It would have moved a values cheat sheet and VAL questions if a values-style round existed; none is in this pack |
| 2. `Quartzline interview process product manager` | unavailable | Every call was refused. It would have confirmed the loop and adjusted persona weights beyond your own note |
| 3. `Quartzline strategy` / recent news | unavailable | Every call was refused. It would have grounded D3 and a CASE question in Quartzline's current priorities and produced a grounding brief |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's `role_profile` fixes the fit snapshot and the JD-tagged questions |

Nothing in this pack about Quartzline itself comes from research, so company-specific cells are `[generic]`.

## Upgrade menu

- The interviewer's name and title → an interviewer read, persona weights read from their public footprint, and a reverse question tied to their path
- The recruiter's prep email → confirmation of the loop and any stated focus areas, so persona weights rest on a source and not a prior
- Quartzline's public developer docs or site text pasted in, or search permission granted → D3 and a CASE question grounded in their platform, and `[generic]` rows become `[grounded]`
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes, if search is enabled) → a strategy brief, the interviewer's public talks, and recent org context; offered once
- Your answers to the slots in F3 to F9 and C1 to C3 → those rows regenerate from your own words, outside a drill
- The session agendas or notes from the roadmap-input sessions → the medium band on the sessions evidence could rise to high
- The full job description text → requirement cells would quote the posting directly instead of the dossier's `role_profile` text
- Anything that has changed since the dossier was generated on 2026-08-14 → the fit snapshot regenerates from it
