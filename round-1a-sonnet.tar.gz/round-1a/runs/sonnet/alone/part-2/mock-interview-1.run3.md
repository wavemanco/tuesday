I've read the skill's reference files. Now I'm running a small research pass on Northwind Data's values, its strategy and Compass, and Dan's public profile, before I build the pack.
I've saved the prep pack for Priya's conversation with Dan at `/var/tmp/tuesday-measure/1a/runs/sonnet/alone/part-2/rooms/case-1-denied-f8320cef/northwind-data_senior-gtm-strategy-lead_interview_pack.md`.

I built it for a single 60-minute conversation with a peer. It has 22 questions across six personas, each tagged by type, with answer guidance and a rationale:
- **Personas:** A Peer Evaluator, B Data-Driven Prober, C Case/Strategist, D Skeptic, E Conversational, P Pressure.
- **Types:** VAL, EXP, JD, CO and CASE.
- **Weighting:** Peer and Prober carry the most weight, because Dan is a peer who calls himself "relentlessly data-driven". The cases lean toward pricing and packaging because of his monetization background. Pressure is lowest.
- **Highest-ROI prep:** D1, the "no classic sales-ops or quota-setting" objection, with a three-level follow-up ladder. Second is B1, defending the ~$400M figure.
- **Other sections:** a fit snapshot, a reading of Dan, a requirement-coverage table, seven reverse questions, a prohibited-claims list and sources.

- **Research was refused.** The host refused all three searches I tried (Northwind's values, Compass and strategy, and Dan's public profile). Everything about Northwind and Dan comes from your message and is unverified. The sources section says which pack sections that affects.
- **The evidence is only what you described.** Priya's evidence is quoted from your description, not from her CV. Where the quote doesn't reach a requirement, the guidance is an answer slot for her to fill in her own words, not a claim I made up.
- **No values cheat sheet.** The skill only includes one when a values round is documented, and none is.

Say the word and I'll play Dan as the Skeptic on D1, the question the pack names as the highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Mock-interview pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

Candidate: Priya. Interviewer: Dan Kovac, Director of Sales Strategy, her peer (both would report to the same VP). Format: one 60-minute conversation.

## How to use this pack

Personas describe how a question arrives (who is asking, in what register). Types describe what is being scored. Every question carries both, plus a Provenance cell, answer guidance and a rationale.

| Type | What it scores |
|---|---|
| VAL | Behavioral and values alignment: whether past behavior shows how you work with others. No Northwind values were fetched, so VAL here is behavioral, not mapped to published values |
| EXP | Work-experience deep-dive: whether your claims survive scrutiny, and what was actually yours |
| JD | Role and JD-driven: the stated responsibilities, including the gaps |
| CO | Company and strategy knowledge: whether you can think at Northwind's altitude |
| CASE | Live problem set in the role: structure and reasoning |

Guidance is scaffolding, not a script. Where a cell says "Answer slot", it is an instruction for the interview: answer from your own experience, or say plainly the practice was not yours. Nothing in this pack supplies a fact about your past that you did not give.

Question IDs run by persona: A Peer Evaluator, B Data-Driven Prober, C Case/Strategist, D Skeptic, E Conversational, P Pressure (P, because F is taken by the fit-snapshot rows).

**Highest-ROI prep: D1.** The gap you named, no classic sales-ops or quota-setting experience, is the objection a peer who owns sales strategy will reach for. D1 has the deepest follow-up ladder. Second: B1, the defend-the-number drill on the ~$400M figure, because the interviewer self-describes as data-driven.

## Fit snapshot

The requirements are the JD highlights as you gave them, quoted; the evidence is quoted from your message about Priya. Neither the full JD nor her CV was supplied, so every evidence cell has nothing inspected behind it.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — your message | medium | [grounded] | transferability | Your material says product strategy and ops at a consumer-tech company, not a go-to-market for a product line. Words at that scope: "For nine years I worked in product strategy and ops at a large consumer-tech company." Answer slot: the JD's two-new-product-lines line makes a probe on go-to-market work likely. If any of your work set how a product reached customers, say what and what part was yours, in your own words; if none did, say so plainly and stay with product strategy and ops |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — your message | medium | [grounded] | discovery | The sentence says proposed and credited, and does not show which stage of a customer lifecycle it touched. Words at that scope: "I proposed a store-surface change that is credited with a ~$400M ARR uplift." Answer slot: the JD's land/adopt/expand/renew line makes a probe on which stage that work sat in likely. If it sat in one, say which; if it did not map to those stages, say so plainly and stay with the change you proposed |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — your message | medium | [grounded] | none | No gap in terms, but a one-line claim with nothing inspected behind it, so expect a probe. Lead with the quote's own terms: you are skilled in SQL and Tableau. Answer slot: be ready to walk one analysis end to end; if you wrote the queries or built the dashboards yourself, say which analysis and how, in your own words; if others wrote them, say so plainly and say what you did |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — your message | medium | [grounded] | transferability | The sentence carries a revenue model used in negotiations, which sits next to partner-motion design and does not show it. Words at that scope: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: the JD's partner-motion line makes a probe on whether you shaped how a partner relationship worked likely. If you did, say what and what part was yours; if the model fed others' decisions, or no partner motion was yours to design, say so plainly and return to the model |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — your message | medium | [grounded] | none | The sentence already speaks to the requirement in role-relevant terms: targets, set with consensus across organisations. Lead with it as written. Expect a probe on where the organisations disagreed, which is an answer slot at A1 |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — your message | low | [inferred] | transferability | Daily use of AI tools is adjacent to AI experience, and the sentence does not say what for or whether anything was built. Words at that scope: "I use AI tools daily." Answer slot: if you can name what you use them for, say it in your own words; if it is general use rather than work on an AI product, say so plainly. The derivation is the pack's: a plus-skill probe is typical for the role |
| F7 | Sales-ops and quota-setting fluency, as a peer to a sales-strategy function — role-family prose, no JD line says it | "No classic sales-ops or quota-setting experience" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I don't have classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past: learn how quotas are set and reviewed here before proposing changes. Never a claim to quota work, and nothing added to make the gap feel smaller |

## Reading the interviewer

Everything here is the profile as you described it. A public-footprint search was attempted and refused, so none of it is independently verified. Public professional footprint only.

| Observation | Provenance | What it means for you |
|---|---|---|
| Self-describes as "relentlessly data-driven" | [grounded] your message | Every number you cite gets walked to its assumptions. Rehearse B1 and B2 until "I don't know how that was counted" and "here is the assumption I'd defend least" both come out calmly |
| Career spine is pricing and monetization roles | [grounded] your message | His native language is packaging, price metrics and unit economics. Expect the cases to lean there (C3), and do not bluff on ground he owns: state hypotheses as hypotheses, ask what he has seen |
| One early-stage-startup chapter | [grounded] your message | Expect pace and scrappiness probes (D4): a 3,000-person company building two new lines may have thin playbooks, and he has lived the other end of that |
| He is a peer, not your manager | [grounded] your message | He is pricing what you cost and contribute to his work: seam, credit, disagreement (A1 to A5). Offer reciprocity, not just needs |

Mirror opportunity: shared vocabulary. Your sentence "built a partner-level revenue model used in carrier negotiations" (F4) and his monetization path both live in revenue-model language. Use his terms when you describe the model, at the sentence's own scope. No shared career jump is offered: nothing in your material carries your side of one.

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Seam-splitting between his team and yours, "what would you need from me", credit and disagreement | High. A peer relationship prices partnership fit first; this is a single conversation with the one person whose team sits beside the role | Reciprocity framing; propose seam principles rather than pretending to know the seam; disagreement stories with spine and tact (A1 to A5) |
| Data-Driven Prober | Line-by-line probes on the numbers, the model, the tools | High. Relationship prior for a peer, raised by his "relentlessly data-driven" self-description | Know what you can and cannot say about how each figure was counted; name the weakest assumption you know of before he does; offer to walk one analysis end to end (B1 to B5) |
| Case/Strategist | Live problems on the two new lines, Compass, bundling, with a pricing tilt | Medium-high. Not a hiring manager, so less prior weight, but his pricing and monetization spine tilts any case toward pricing, packaging and unit economics | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully per case (C1 to C4) |
| Skeptic | Probes on the sales-ops and quota gap, partner-motion design, B2B and big-company transition | Medium-high. The one gap you named is exactly where a sales-strategy peer is expert, and his startup chapter adds a pace probe | Rehearse D1 until it is boring; bridges only from adjacent evidence you stated, the limit said plainly, plus a ramp plan (D1 to D4) |
| Conversational | Biography opener, an informal AI question | Medium. Openers are near-certain in any 60-minute conversation, but two questions cover it | A 90-second arc; treat the casual AI question as scored (E1, E2) |
| Pressure | Time-boxed "why you over someone who has carried a quota" | Low. Nothing in the profile signals a stress style; the pressure is likely to arrive through the Skeptic's ladder instead | Pause, restate, anchor on what you stated, hold through two follow-ups before conceding anything real (P1, P2) |

Loop basis: your words establish one session with Dan, so persona weights rest on the relationship prior plus his signals, not on an archetype. No values-style round is detected, so there is no values cheat sheet.

## Question banks

### A. Peer Evaluator (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our teams sit side by side. Where's the seam between Sales Strategy and Emerging Products GTM, and what happens when we disagree?" | JD | [grounded] "set annual volume targets with cross-org consensus" | Lead with seam principles, not a map you cannot know: who owns the question, who owns the decision, what data settles it. Then your own sentence at its scope: you set annual volume targets with cross-org consensus. Answer slot: if the organisations disagreed on the way, say where, how it was resolved and what part was yours, in your own words; if consensus came without disagreement, or the process was not yours, say so plainly and stay with the sentence | F5 is the evidence for the JD's cross-functional-influence line, and a peer's first move is to test it on the seam between his team and the role. JD because it scores a stated requirement; delivered as a peer probe |
| A2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Selection scaffold: pick an instance with a named other team, a moment the credit could have gone either way, and an intact relationship at the end. If you use the proposal sentence, keep its words: you proposed it, and it is credited with the uplift. Answer slot: if others' work was part of what the change is credited with, say whose and what they did; if you cannot say, say so plainly. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Credit is the stem a peer uses to test turf awareness, and the ~$400M line in F2 invites it. VAL because it scores behavior with equals; it is not mapped to a published value, since none was fetched |
| A3 | "What would you need from me, and what would you bring to my team?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Answer both halves, bring first. What you bring, at the quote's scope: a partner-level revenue model that was used in carrier negotiations. What you need: access to how his team sets targets and reviews them, and the data definitions behind them. Ask what he is modeling now rather than guessing it | F4 is the nearest evidence for the partner requirement, and a peer is judging whether the hire reduces or adds to his load. JD because it scores the partner and cross-functional lines through reciprocity |
| A4 | "Suppose the sales team I support wants to fold your new product into existing reps' quotas, and you think it needs a dedicated motion. How do we settle it?" | CASE | [grounded] "No classic sales-ops or quota-setting experience" | Structure it: clarify the product's buyer and sales cycle; lay out options (existing reps, overlay, dedicated, partner-led); state the criteria; name the evidence that would settle it, such as a pilot; say who decides. Hold-then-concede on the gap: say plainly that you don't have classic sales-ops or quota-setting experience, then ask how his team would test it | This is the sales-ops gap (F7) arriving as a collegial case instead of an accusation. CASE because it is a live problem with no claim about your past; the concession is the quote's own |
| A5 | "Tell me about a time you changed a decision you did not have authority over." | JD | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Story map from the sentence: you proposed a change, and it is credited with the uplift. Answer slot: the JD's cross-functional-influence line makes a probe on who had to agree likely. If anyone resisted, say who and what you did, in your own words; if the proposal went through without resistance, or others made the decision, say so plainly and stay with the proposal | F5 is the JD evidence and the proposal in F2 is the only influence story in the material. JD because the theme is the JD's influence line; EXP-style delivery |

### B. Data-Driven Prober (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | The four defend-the-number slots, each in your own words. How it was counted. What it is sensitive to. The assumption behind it you would defend least. Which part was yours. Keep the sentence's words: proposed, credited with, approximately. If you do not know how the figure was counted, say so plainly and say what you would ask to find out. Do not supply a method you cannot repeat under a second question | The headline figure of F2 is the magnet for a self-described data-driven interviewer. EXP because it tests attribution and counting, not the role |
| B2 | "Walk me through the revenue model you built for carrier negotiations. What did it have to answer?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations", "skilled in SQL/Tableau" | Say what the sentence says: a partner-level model, used in negotiations. Answer slot: the JD's independent-analysis line makes a probe on who built it and in what tool likely. If you built it yourself, say how, in your own words; if others contributed, or SQL and Tableau were not what you used for it, say so plainly and say what you did | F4 and F3 meet here: the model is both the partner evidence and the analysis evidence. EXP because he will check what was actually yours |
| B3 | "How do you use SQL and Tableau day to day? Show me you can run an analysis on your own." | JD | [grounded] "skilled in SQL/Tableau" | The sentence at its scope: skilled in SQL and Tableau. Offer to walk through one analysis from question to result. Answer slot: if you wrote the queries and built the views yourself, name the analysis and the steps; if others did that part, say so plainly and say what you did | The JD names SQL and Tableau, and F3 has the thinnest backing of any JD tool line. JD because it scores a named requirement |
| B4 | "Renewal rate is flat but expansion revenue is down twenty percent. How do you diagnose it in the data?" | CASE | [generic] | Clarify the definitions first (gross versus net retention, how expansion is counted). Segment by customer size, product and cohort; separate volume, price and mix; check timing and one-off effects. Name the pulls you would run and the one result that would change your mind. Say what you would ask about the schema before querying | A native test for a data-driven interviewer, and it exercises the land/adopt/expand/renew language the JD uses. CASE because it is a live diagnosis, set in the role |
| B5 | "The JD talks about whitespace across land, adopt, expand and renew. For a product that has not launched, what would you measure at each stage?" | JD | [generic] | Structure by stage; for each, a leading indicator you can get before launch (analog products, pilot data, early usage). Name your weakest assumption aloud. Answer slot: if any past work of yours sat in one of those stages, name which in your own words; if none did, say so plainly and answer as the plan it is | Covers the F2 requirement as a structure rather than as history. JD because the stages are the JD's; pre-launch because both lines are new |

### C. Case/Strategist (weight: medium-high)

The company facts in this bank come from your research note and are unverified by me.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Compass is an AI copilot launching into an existing enterprise base. Sketch a GTM plan. What do you need to know first?" | CASE | [grounded] your research note: "an AI copilot launch ('Compass')" | Clarify first: which segment, what the product replaces, what data exists. Then objective, segmentation by land, adopt, expand, renew, packaging and price metric, partner role, metrics, risks. Challenge one premise respectfully, for example whether Compass is one of the two lines you would own. Do not assume it is | Compass is one of three stated priorities in the note, so a strategy peer can pose it live. CASE because it scores structure on a problem from the actual role |
| C2 | "A much larger platform vendor bundles a competing capability into its suite. How does that change your GTM for a new line?" | CO | [grounded] your research note: "bundling by a much larger platform vendor" | Bring the consensus answer to show grounding: differentiate on depth and on what a bundle will not do well. Then one divergence with reasons: a partner or integration posture toward the vendor, and where it breaks. Add the anti-pick: the segment you would stop pursuing. Name what you would need to know about how the bundle is priced | The note names bundling as the main threat, and a recited consensus answer scores as homework. CO because it scores strategy fluency; CASE delivery. The partner angle ties to the JD's partner requirement without claiming a past |
| C3 | "How would you price and package an AI copilot, by seat, by usage or by outcome? How would you test it?" | CASE | [generic] | State a hypothesis as a hypothesis, name the evidence that would change it, then propose a test and what would count as a result. Ask Dan how he has tested price metrics. He owns this ground, so candor and curiosity beat polish. This answer makes no claim about your past | His pricing and monetization spine tilts cases here. CASE because it is live and presupposes nothing about you |
| C4 | "Leadership wants enterprise expansion and profitability at once. For two new lines, where do you invest and where do you hold back?" | CO | [grounded] your research note: "enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" | Ask which two lines and what the profitability horizon is. Then criteria (payback, strategic position, risk), a sequence, and one thing you would explicitly not do yet. Say which assumption you would defend least | Two of three stated priorities pull against each other, which is the altitude question. CO because it tests homework depth; CASE delivery |

### D. Skeptic (weight: medium-high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which part of this role would you be weakest at on day one?" Follow-ups: "I don't see classic sales-ops or quota-setting in your background. How would you handle that?" Then: "Isn't setting volume targets the same thing?" Then: "Why should I trust you to partner on this?" | JD | [grounded] "No classic sales-ops or quota-setting experience", "set annual volume targets with cross-org consensus", "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | The highest-ROI rehearsal. Opener: name it first, plainly: "I don't have classic sales-ops or quota-setting experience." Level 1: add what your material does carry, at its scope: you set annual volume targets with cross-org consensus, and say you won't call that quota work. Plus a ramp plan, said as a plan: learn how quotas are set and reviewed here before proposing changes. Level 2, the target question: hold the structure, concede what you don't know, ask how his team handles it. Level 3: reciprocity, what you bring his team (A3) and what you would learn from him. Hold through two follow-ups; never fold the core claim, and never stretch the target-setting sentence into quota work. The honest limit is a limit, not a confession | F7 is the stated gap and F5 the nearest adjacent evidence. JD because the interviewer's function, not a JD line, raises it; the tag is the closest scoring category. Deepest ladder in the pack on purpose: this is the objection to rehearse until it is boring |
| D2 | "The role calls for partner-motion design experience. Tell me about partner-motion work you have done." | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Start with the sentence at its scope: a partner-level revenue model used in carrier negotiations. Answer slot: if you shaped how a partner relationship was structured, say what and what part was yours, in your own words; if the model fed others' decisions, or no partner motion was yours to design, say so plainly and return to the model. Hold your position on the model through two follow-ups | The JD says required, and F4 is adjacent rather than direct, so this is the second probe a skeptic aims at. JD because it scores a stated requirement and its gap |
| D3 | "Why leave a large consumer-tech company for a B2B data-infrastructure company, and why now?" | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | Answer slot: give your own reason, in your own words; no one else can supply it. Keep it about what the role offers, not what you are leaving. If you know a difference between the two buyers, state it as a view, not as experience. A shared sentence of context at its scope: nine years in product strategy and ops | The reason-for-leaving and why-here-why-now probe is the Skeptic's standard stem. EXP because it tests motivation consistency against the history in F1 |
| D4 | "Tell me about a time you built a plan for something that had no playbook." | EXP | [generic] | Selection scaffold: pick a time with no precedent, a named stake, a decision made on incomplete information, and what you would do differently. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach it | The JD's two new product lines raise the theme, and his startup chapter makes a pace and scrappiness probe plausible. EXP because it tests whether a large-company history transfers |

### E. Conversational (weight: lower)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc with three beats the sentence states: two years of strategy consulting at a top firm, then nine years in product strategy and ops at a large consumer-tech company, then why this role. Answer slot: the last beat is your own reason for the role. Keep it to the biography; the numbers get probed later | Casual openers are still scored on economy. F1 is the only evidence row for the arc. EXP because it is a CV walk-through |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | The sentence at its scope: you use AI tools daily. Answer slot: if you can name what you use them for, say it in your own words; if it is general use rather than work on an AI product, say so plainly. Then one hypothesis on what Compass's buyers would want, stated as a hypothesis | AI is the JD's plus-skill, asked casually, and F6 is thin. JD because it scores the plus-skill |

### P. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Sixty seconds: why you over someone who has carried a quota?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations", "set annual volume targets with cross-org consensus", "No classic sales-ops or quota-setting experience" | Pause, restate, then anchor on what you stated: the partner-level revenue model used in carrier negotiations, and annual volume targets set with cross-org consensus. Concede once, specifically: you don't have classic sales-ops or quota-setting experience. Hold the rest through two follow-ups; do not claim the other candidate's strength | The same gap as D1 in a time-boxed register. JD because it scores fit including the gap; the pressure is the delivery |
| P2 | "That ~$400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold the sentence's own words: you proposed the change, and it is credited with the uplift. Answer slot: if you carried it into delivery, say what you did; if others did, say so plainly. Concede that you cannot claim the figure as yours alone, specifically and without apology | The attribution probe that follows B1, in a harder register. EXP because it tests what was actually yours |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| "own GTM strategy for two new product lines" (F1) | C1, C4, D4, E1 |
| "identify whitespace across land/adopt/expand/renew" (F2) | B1, B4, B5, C1 |
| "run independent analysis in SQL and Tableau" (F3) | B2, B3, B4 |
| "partner-motion design experience required" (F4) | D2, A3, C2, B2 |
| "strong cross-functional influence" (F5) | A1, A2, A5 |
| "AI experience a plus" (F6) | E2, C1, C3 |
| Sales-ops and quota-setting fluency (F7) | D1, P1, A4 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "You've spent a lot of your career on pricing and monetization. What's the pricing or packaging question for the new lines you'd most like a GTM partner to help answer?" | Ties to his own path and turns the interview into a peer conversation; it shows you read him, not just the company |
| 2 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer: it signals you are thinking about his load, not just your onboarding |
| 3 | "Where do you expect Sales Strategy and this role to overlap, and where should we deliberately not?" | Invites him to draw the seam you proposed principles for in A1 |
| 4 | "As I understand it, bundling by a larger platform vendor is the main competitive threat. Which of the two new lines feels most exposed, and what would you want me to learn first?" | Shows strategy homework while asking for his read; the "as I understand it" leaves room to be corrected |
| 5 | "How much of the land, adopt, expand and renew picture can I query on day one, and where are the gaps?" | A data-driven peer will rate a candidate who asks about data readiness; it is also genuinely useful to you |
| 6 | "How is the team weighing enterprise expansion against profitability when it sets targets for products with no history?" | Engages the two stated priorities that pull against each other, and the answer shows how targets get set |
| 7 | "What does success look like six months in, from where you sit?" | Gives a peer's view of the bar, and shows you want to be measured |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has done classic sales-ops or quota-setting work | Negative stated by you, F7 | The plain acknowledgment F7 gives: "I don't have classic sales-ops or quota-setting experience." No slot |
| Set quotas (treating annual volume targets as quotas) | Inflated form of F5 | F5's quote at its own scope: you set annual volume targets with cross-org consensus. The limit is the pack's observation: the material says volume targets, not quotas |
| Owned, drove or delivered the ~$400M ARR uplift | Inflated form of F2 | F2's quote at its own scope: you proposed the change, and it is credited with the uplift. The limit is the pack's observation: the material says proposed and credited |
| Found whitespace across the customer lifecycle | Inflated form of F2 | F2's quote at its own scope. B5's slot asks only which stage your work sat in |
| Designed partner motions | Inflated form of F4 | F4's quote at its own scope: a partner-level revenue model used in carrier negotiations. D2's slot stays inside the model |
| Built or launched an AI product, or did AI go-to-market | Inflated form of F6 | F6's quote at its own scope: you use AI tools daily |
| Owned the go-to-market for a product line | Inflated form of F1 | F1's quote at its own scope: product strategy and ops at a consumer-tech company |

## Sources

Provided documents: your message, containing the JD highlights, the candidate summary, the interviewer profile as you described it, and the research note on Northwind's priorities. All of it is as you gave it, and I have not checked it independently. No dossier was present. No CV or full JD text was supplied.

Search queries sent, all refused by the host (permission not granted):

- "Northwind Data company values principles": refused
- "Northwind Data Compass AI copilot launch": refused
- "Dan Kovac Director of Sales Strategy Northwind Data": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | Every call refused. It would have fed a values cheat sheet and VAL mapping; the pack has neither, and A2 is behavioral, not value-mapped |
| 2. Northwind Data interview process | skipped | Your words establish the loop: one 60-minute conversation with a peer. Persona weights follow from that |
| 3. Northwind Data strategy and recent news | unavailable | The Compass search was refused. It would have checked your research note for freshness and fed the CO bank; the C bank rests on your note alone |
| 4. Dan Kovac, Northwind Data | unavailable | The search was refused. It would have fed the interviewer read and a tailored reverse question; both rest on your description of him alone |
| 5. Representative JD for the title | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Full JD text → the six requirement quotes in F1 to F6 stop being highlights as you relayed them, and any requirement the highlights omit becomes a row and a question
- Priya's CV text → each evidence cell becomes her own CV line, with its original wording and scope
- An artifact behind the ~$400M credit, such as the launch memo, the experiment readout or the finance sign-off that attributed it → F2 can rise from medium and B1 and P2 get exact answers instead of slots
- The revenue model or a deck that used it in the carrier negotiations → F4 can rise from medium and B2 and D2 get exact answers
- A query or dashboard sample Priya wrote herself → F3 can rise from medium and B3 gets a concrete walk-through
- Priya's own answers to the answer slots in F1, F2, F4 and F6 → those rows regenerate from her words and the slots close
- The recruiter's prep email, if there is one, with stated focus areas → coverage assumed from the peer prior is replaced by what Northwind says will be covered
- Dan's public talks or writing, or the host allowing the searches that were refused → a verified interviewer read and a sharper reverse question 1
- Northwind's published values page and a strategy brief under six months old → a values cheat sheet if a values round is documented, and C-bank facts that are checked rather than as-you-gave-them
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, adding strategy, interviewer talks, loop reports and recent org context
- A tuesday-dossier.md from an earlier evidence pass, if one exists → verified evidence and stated limits per weak area, instead of the pack inferring them
