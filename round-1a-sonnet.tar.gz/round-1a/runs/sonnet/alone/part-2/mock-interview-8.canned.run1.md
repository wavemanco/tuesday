I'll read the reference files first.
I've saved the pack and am now checking the file for stray brackets before I hand it over.
Your prep pack is saved as `ashgrove-credit-union_member-experience-lead_interview_pack.md`. I built it in loop mode for the three rounds on 26 November. Persona weights come from the round types and the recruiter's description, because no interviewer names are known yet.

- **Highest-ROI prep:** D1, the Head of Member Services' likely challenge. It says your complaints work is one branch's log, you haven't worked in a contact centre, and the role owns complaints across both. The pack has you state the limit first, hold only what you said you did, and concede the contact-centre gap specifically.
- **Answer slots:** For F2, F4, F5, F7, F8 and F9, your material doesn't show whether you did the thing, so the pack gives you slots instead of scripts. These cover what your spreadsheet counted and what tool it was built in, what governed your complaints log, and any digital-team or supervisor-coaching experience. Answer them in your own words and I'll fold them into the pack.
- **Values stories:** None of your quoted sentences carries a story for the four values, so G1 to G4 are selection scaffolds with an honest "nothing comes to mind" branch rather than invented stories.
- **Research:** I ran no searches. Your pasted values, the recruiter's email, the JD and your account of the strategy brief already cover every research target.

Say the word and I'll play the Head of Member Services on D1.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Loop mode, three rounds on 26 November 2026.

| Round | Who | Length | Shape, per the recruiter's email |
|---|---|---|---|
| 1 | The recruiter | 30 min | Screen |
| 2 | Head of Member Services (your future manager) | 45 min | Mostly behavioural |
| 3 | Panel of two branch managers | 60 min | Includes a 20-minute case on a complaint escalation; scored against the four published values |

No interviewer names are assigned beyond those roles, so persona weights come from round type and the recruiter's own description, and there is no interviewer read.

## How to use this pack

Personas describe how a question arrives; types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did. An answer slot is an instruction for the interview, not a question for now.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows Ashgrove's published values |
| EXP | Whether your own claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you can think at Ashgrove's altitude: strategy, competition |
| CASE | Structure and reasoning on a live problem |

Question IDs run by persona across the loop: A and B are round 1, C to F round 2, G to I round 3.

## Prep triage (nine days: 17 to 26 November)

1. D1, aloud, until it is boring. It is the highest-ROI prep in this pack: say the limit first, hold the two things you did, concede the one you have not done.
2. The answer slots on F2, F4, F5, F7 and F9. Write down what is true for you in your own words; whatever you write is new material I can fold into the pack.
3. Decide your actual answers to A3 to A6 (reason for leaving, notice, pay, location). They come first on the day.
4. G1 to G4: one real story per value, or the honest branch. Then H1 aloud, timed to 20 minutes.
5. F1, F2 and C4 once each, structure first.

Everything else is insurance.

## Fit snapshot (shared across all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | Say it in the quote's own terms: "For six years I worked in retail banking, the last three as a branch supervisor." A named setting beats the JD's label. A CV-level line with nothing inspected behind it, so expect a probe on what the years held |
| F2 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log" — your message; "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your material says one branch's log and the script you trained tellers on, and the words stay there: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Answer slot: the JD's scope makes a probe on what surrounded the log likely. If any step before or after the log was yours, say which and what you decided, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the log and the script training |
| F3 | "and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F4 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | Words at their own scope: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names volumes and resolution times, so expect a probe on what the spreadsheet showed. If it counted either, say which and how you counted it, in your own words; if it did not, or you do not know how a figure was counted, say so plainly and stay with the spreadsheet |
| F5 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | low | [inferred] | discovery | Derived from reading your spreadsheet as possibly Excel; the quote says spreadsheet, so the pack does not say Excel for you. Answer slot: say which tool it was built in, in your own words; if it was not Excel, or you do not know, say so plainly and stay with the spreadsheet |
| F6 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | Words: "I haven't presented to anyone above regional level." Then how you would prepare to, said as a plan and never as a past. If you have presented at regional level, that is yours to describe in your own words |
| F7 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | The words stay at "I trained new tellers on our escalation script." The JD says supervisors; your material says new tellers. Answer slot: if you have helped a fellow supervisor with an escalation, say who and what you did; if not, or it was not yours, say so plainly and stay with the tellers |
| F8 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not show this either way. Answer slot: if you have worked with a digital team or on a self-service journey in any way, say what part was yours; if not, say so plainly, then how you would start |
| F9 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | The words stay at "I handled the branch's formal complaints log." Answer slot: the JD says regulated, so expect a probe on what governed the log. If you know which rules or time limits applied, say so and what they required of you; if you do not know, or none applied, say so plainly and stay with the log |

No row is a hard_gate: the JD you pasted sets no authorisation, licence, location, schedule or pay term.

## Grounding brief

The strategy facts below are as you relayed them from the July 2026 brief; the brief itself was not pasted.

| Fact, as you relayed it | Provenance | Where it surfaces |
|---|---|---|
| "move 40% of member service to digital channels by 2028" | [grounded] | F1, reverse questions in round 2 |
| "consolidate eight branches into five hubs over 2027" | [grounded] | F2, G3, reverse questions in rounds 2 and 3 |
| "launch a small-business lending product in Q1 2027" | [grounded] | Reverse questions in round 2 |
| "the main competitive pressure is app-only banks" | [grounded] | H2, A2 |

---

# Round 1: the recruiter (30 minutes)

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Conversational | Friendly, unstructured; pay, notice, location, reason for leaving, then motivation | High: the recruiter-screen prior. A carries four logistics rows because a screen always has them | A 90-second arc for A1; treat every casual question as scored |
| B. Skeptic (light) | Knock-out checks on the two absences you have stated | Low to medium: F3 and F6 are the places a screener ticks a box | Plain acknowledgment, then a plan; the full rehearsal is D1 in round 2 |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | A 90-second arc whose beats are the four sentences: six years in retail banking, the last three as a branch supervisor; the complaints log; the tellers and the escalation script; the monthly spreadsheet. Tell them in your own words and add nothing between them. End on your own reason for this role, one you can repeat in round 2 | F1, F2, F4 and F7 are the whole evidence base, and this is the first scored answer. EXP because it tests the CV's own claims |
| A2 | "What draws you to a member-owned credit union like Ashgrove?" | CO | [grounded] | Give your own reason, in your own words. If it connects to one of the four published values, name that value only if it is true for you. The JD calls Ashgrove member-owned, and the values page puts members first; the question scores whether you did the homework | Motivation-consistency check; CO because it tests whether the answer is about this employer |
| A3 | "Why are you looking to move on?" | EXP | [generic] | Logistics slot: give your actual reason, in your own words, factual and one you could repeat to your current employer. It must also hold in round 2, where the questions are behavioural | The reason for leaving is on every screen; EXP because it is a statement about your own past |
| A4 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period | Standard screen item on the listed job's terms |
| A5 | "What salary are you looking for?" | JD | [generic] | Logistics slot: either give your own number or ask for the role's band first. Give no figure you could not stand behind | Standard screen item on the listed job's terms |
| A6 | "Where would you be working from, and how do you feel about moving between sites?" | JD | [generic] | Logistics slot: say your actual constraints, in your own words, and ask where the role is based, since the JD you pasted sets no location | The JD spans branches and the contact centre, so location and movement are likely; JD because they are the listed job's terms |
| B1 | "The role covers the contact centre, and you haven't worked in one. How do you see that?" | JD | [grounded] "Never worked in a contact centre" | Concede it first and plainly: "I haven't worked in a contact centre." Then a plan in your own words: whom you would learn from and what you would look at first. Do not offer branch work as a substitute unless you can say what carries over | F3. The screener needs to know the gap is understood, not hidden. The full version is D1 |
| B2 | "This role presents to senior leaders. Where are you with that?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain words: "I haven't presented to anyone above regional level." Then how you would prepare, as a plan. Answer slot: if you have presented at regional level, say to whom and what; if not, say so plainly | F6. A straight answer here is cheaper than being drawn out later |
| B3 | "The role asks for four years or more in financial-services customer operations. How does your background line up?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Say it as it is: "For six years I worked in retail banking, the last three as a branch supervisor." Let the screener make the match. Answer slot: if asked what those years held, answer from your own experience; if a part of the JD's label does not fit, say so plainly | F1. JD because it scores the stated requirement |

## Reverse questions (round 1)

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "Is there anything the panel would like me to read or prepare ahead of the 20-minute case?" | Shows you treat the case as a graded task; the recruiter can answer in one email |
| R1.2 | "How do the panel score against the four values, and is there a form they use?" | The recruiter's email says the panel scores against them; asking shows you have prepared against them |
| R1.3 | "Which part of the complaints process sits in the contact centre today, and who runs it?" | The contact centre is your stated gap; curiosity about it is better than avoidance |
| R1.4 | "What is the Head of Member Services most hoping this hire changes?" | Gives you round 2's agenda before round 2 |
| R1.5 | "What happens after the three rounds on 26 November, and when will I hear?" | Closes logistics so you are not chasing |

---

# Round 2: the Head of Member Services (45 minutes, mostly behavioural)

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| C. Values / Behavioural | Scenario prompts, "tell me about a time" | Highest: the recruiter described the round as mostly behavioural | A real story per prompt, or the honest branch; the same stories serve round 3 |
| D. Skeptic | Probes the gap under the headline: the log is one branch, the contact centre is new | High: the hiring-manager prior is to derisk gaps; F3 and F6 are stated absences, and the JD's scope sits right on F2 | Rehearse D1 until it is boring; concede specifically, never fold on what you did do |
| E. Data-Driven Prober | Walks through the one reporting artifact you have | Medium: the role reports monthly and F4 and F5 rest on one spreadsheet | Know what the spreadsheet showed and say plainly what you do not know |
| F. Case / Strategist | Live problems from Ashgrove's own strategy | Medium: the manager prior, and the brief gives live material | Clarify, structure, then answer; challenge one premise respectfully |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you had to deliver an unpopular truth to someone more senior." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not fold, and a relationship intact at the end, where the hard truth actually landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioural stem. VAL because it scores whether a hard message was actually delivered. F6 means "senior" may mean the regional manager |
| C2 | "When did you put a member ahead of an internal number?" | VAL | [generic] | Selection scaffold: a decision where the member's interest and a branch target pulled apart, what you chose and what it cost. Use the story you pick for G1 if it fits; do not build a second. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Members First, Always, asked in a manager's words |
| C3 | "Tell me about a time you helped someone handle an escalation they weren't sure about." | EXP | [grounded] "trained new tellers on our escalation script" | The beats the sentence carries are the new tellers and the escalation script; tell those in your own words. Answer slot: the JD's coaching line makes a probe on whether this reached supervisors likely. If you helped a fellow supervisor, say who and what you did; if not, or it was not yours, say so plainly and stay with the tellers | F7. EXP because the manager will test how far the training line goes |
| C4 | "Walk me through how you would present monthly complaint volumes and resolution times to the senior team." | CASE | [generic] | Structure it aloud: what the audience needs to decide, the headline first, what is driving it, what you want from them. The question needs no claim about your past, so the guidance makes none | Covers the JD's reporting and presenting lines as a live problem. F4 and F6 explain why a structure rehearsed aloud is worth more than a claim |
| D1 | "Your complaints work is the branch's formal complaints log, and you haven't worked in a contact centre. This role owns complaints across both. Where does that leave you?" | JD | [grounded] "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "Never worked in a contact centre" | **The highest-ROI prep in this pack.** State the limit before it is asked: "I haven't worked in a contact centre." Hold only what the quotes carry: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Follow-up 1, how you would learn the contact centre: a plan in your own words, whom you would learn from, what you would look at first, nothing in the past tense. Follow-up 2, whether that is a big gap: concede specifically that the contact-centre half is new to you; do not concede the log or the script, and do not retreat from them. Follow-up 3, what if that team does not see you as one of them: hold the plan and say what you would ask of them. Answer slot: if any step before or after the log was yours, say which; if you have worked with a contact centre team in any way, say what part was yours; if not, say so plainly | F2 and F3 are where the JD's scope presses hardest on your material, and a hiring manager is buying capability and derisking gaps, so this arrives in some form. JD because it scores the stated requirement; the hold-then-concede structure is the rehearsal |
| D2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Pick your real answer. Your material states two absences, F3 and F6; if you name one, use its plain words ("I haven't worked in a contact centre" or "I haven't presented to anyone above regional level") and pair it with a plan. Do not name a weakness you do not have as a decoy | A standard Skeptic stem; calibrated candor scores better than bluffing |
| D3 | "You handled the branch's formal complaints log. What did handling a formal complaint involve for you?" | JD | [grounded] "I handled the branch's formal complaints log" | Say what the log was and what handling it meant day to day, in your own words; the quote carries only that you handled it. Answer slot: the JD says regulated, so expect a probe on what governed the log. If you know which rules or time limits applied, say so and what they required of you; if you do not know, or none applied, say so plainly and stay with the log | F9. JD because it scores the regulated-complaints requirement |
| E1 | "Walk me through the monthly complaints spreadsheet your regional manager uses." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | The quote carries that you built it and that your regional manager uses it; say so. Answer slot: if it counted complaint volumes or how long complaints took to resolve, say how you counted each and which assumption behind the count you would defend least; if it did not, or you do not know how a figure was counted, say so plainly and stay with the spreadsheet | F4. The weakest-assumption move is the credibility gain; naming the limit before the probe is the point |
| E2 | "Which tool is it in, and what would you add to it next?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Answer slot: say which tool it is built in; if it is not Excel, or you do not know, say so plainly. What you would add is your own answer; the pack names no feature | F5. JD because the posting asks for Excel reporting |
| F1 | "We aim to move 40% of member service to digital channels by 2028. How would you work with the digital teams on self-service for complaints, and which complaints should stay with a person?" | JD | [grounded] | Clarify first: what "member service" counts, how complaints arrive today, what rules shape how a complaint must be handled. Then structure: objective, segments (type, complexity, member circumstance), approach, measures, risks; challenge one premise, such as whether one percentage suits complaints. Answer slot: if you have worked with a digital team before, say what part was yours; if not, say so plainly and move to how you would | F8 and the brief's 40% line. JD content with CASE delivery |
| F2 | "Eight branches are consolidating into five hubs over 2027. What changes for how complaints are raised and resolved?" | CO | [grounded] | Structure: who is affected (members in each town, supervisors, the contact centre), where complaints arrive, what must not be lost in a move, how you would watch volumes and resolution times through the change. Ask what Ashgrove's own plan is before proposing one | The brief's hub line meets "Neighbours, Not Numbers". CO because it tests whether you can work at Ashgrove's altitude |

## Reverse questions (round 2)

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "In the strategy, 40% of member service moves to digital by 2028. Which part of that does the complaints lead own, and which part do the digital teams?" | Asks about the seam in the JD's digital-teams line, in the strategy's own numbers |
| R2.2 | "As eight branches consolidate into five hubs over 2027, what are you watching on complaints?" | Shows you read the strategy and think about what it changes for this role |
| R2.3 | "What does the contact centre do well on complaints that the branches could learn from, and the reverse?" | Turns your stated gap into a question about their practice |
| R2.4 | "With a small-business lending product launching in Q1 2027, what do you expect the complaints process needs to be ready for?" | Strategy-aware and forward-looking; invites their view |
| R2.5 | "What would make you say in a year that this hire was a clear success?" | Gives you the manager's own measure of success to refer back to |

---

# Round 3: the panel of two branch managers (60 minutes, 20-minute case, scored against the four values)

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| G. Values / Behavioural | One scored prompt per published value | Highest: the recruiter's email says the panel scores against the four values | A real story per value, or the honest branch; see the cheat sheet below |
| H. Case / Strategist | The 20-minute complaint-escalation case | High: it is a third of the round by the recruiter's own account | Clarify, then structure, then answer; think aloud |
| I. Peer Evaluator | Seam-splitting between the role and the branch floor; credit | Medium: a reading from the JD, which has the role coaching branch supervisors, and not from anything known about these two people | Offer seam principles and ask them, rather than pretending to know the seam |

## Values cheat sheet

| Value (official name) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Nearest material is F2's "I handled the branch's formal complaints log"; no quote carries a story, so G1 is a selection scaffold. Pick a decision where the member's side and the branch's pulled apart, and say what you chose. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Plain Words | If a member needs it explained twice, the writer got it wrong | Nearest material is F7's "trained new tellers on our escalation script"; no quote says whose words the script used, so G2 is a selection scaffold with a slot. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Neighbours, Not Numbers | Every branch is part of its town | No quote carries a story, so G3 is a selection scaffold. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Own the Fix | Whoever finds a problem keeps hold of it until it is solved | Nearest material is F2's "I handled the branch's formal complaints log"; G4 is a selection scaffold with a slot. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you decided from the member's side of the counter when that was harder for the branch." | VAL | [generic] | Selection scaffold: a decision with a named stake where the member's side and the branch's pulled apart; say what you chose and what it cost; the hard truth should have landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Members First, Always, in the value's own wording |
| G2 | "Tell me about a time something you said or wrote had to be explained twice. What did you change?" | VAL | [grounded] "trained new tellers on our escalation script" | Selection scaffold: pick a time a member or colleague needed something explained twice and say what you rewrote. Answer slot: if you had a hand in the wording of the escalation script, say what; if the wording was set by others, or there was no set wording, say so plainly and stay with the fact that you trained the tellers on it. If no such time comes to mind, say so plainly | Plain Words. F7's sentence is the nearest material and says nothing about the script's wording, so it is an answer slot |
| G3 | "Tell me about a time you looked after a member, or a town, when the numbers said otherwise." | VAL | [generic] | Selection scaffold: a named member or community, the numbers that pointed the other way, and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. The hub consolidation sits close to this value; ask what the plan is before commenting on it | Neighbours, Not Numbers. The strategy's hubs make this value live |
| G4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold. Answer slot: if a complaint in the log stayed with you until it was solved, say which, what you did and who else was involved; if none did, or it passed to someone else, say so plainly. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Own the Fix. F2's log is the nearest material, and what happened after an entry was logged is not in your words |
| H1 | "A member has complained twice about the same fee. The branch says it has been handled, and the member is now at the counter asking for you. Walk us through what you do." | CASE | [generic] | Your actual case will differ; practise the shape. Clarify first: what the member has been told and by whom, what they want, what rules or time limits apply, what is already recorded, whose desk it is on. Then the immediate step from the member's side, who holds it until it is solved, what the member hears and when, in plain words. Then why it escalated twice and what would change. Challenge one premise: handled by whose standard? Rough pacing: 3 minutes clarifying, 5 on the immediate step, 5 on ownership, 4 on cause, 3 for questions | The recruiter's email describes a complaint-escalation case; this is a rehearsal pattern, not a prediction. CASE because it asks about no past |
| H2 | "The member says they will move to an app-only bank. Now what?" | CASE | [grounded] | Keep the fix and the retention separate: acknowledge, do not plead, fix the problem on its merits, and promise no outcome before the facts are known. Ask what leaving would cost the member, and what you would want to learn about why members leave. The brief names app-only banks as the main competitive pressure, so name the link without lecturing | The strategy's competitive line applied to the case. CASE with a CO angle |
| H3 | "What would you look at each month to know the escalation route is working?" | CASE | [generic] | Structure: the JD's two measures, volumes and resolution times, then what sits behind them (by branch, by channel, complaints that escalated more than once) and what would make you change the route. Say what you would not trust a number to show | Covers the JD's reporting line in a live form. F4 is the reason not to claim a method for this |
| I1 | "Our branch supervisors and you would both touch a live complaint. Where is the seam, and what happens when we disagree?" | JD | [generic] | Offer principles, not a map: who holds the member relationship, who holds the process, how you decide who leads. For disagreement: start from what the member needs, use the record, and escalate only after talking. Ask them where they see the seam | The Peer persona applied to the JD's supervisor-coaching line |
| I2 | "You trained new tellers on your escalation script. Walk us through how you trained them." | EXP | [grounded] "trained new tellers on our escalation script" | The beats the quote carries are the new tellers and the escalation script. Answer slot: the JD's coaching line makes a probe on how the training worked likely. If you set how it was run, say what and why; if someone else set it, or there was no set method, say so plainly and stay with the fact that you trained them | F7. A branch manager reading the CV will go here first |
| I3 | "How do you handle credit when a fix spans teams?" | EXP | [generic] | Selection scaffold: a time a fix needed more than one team, who did what, and how credit was shared; use "we" for context and "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A Peer stem; EXP because it tests attribution honesty |

## Reverse questions (round 3)

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "What could a new person in this role do in their first month that would genuinely help your branches?" | The reciprocity question: it asks what you can give, not only take |
| R3.2 | "When a complaint is escalated from your branch today, what is the part that frustrates you most?" | Invites their real pain point, and you hear the seam in their words |
| R3.3 | "How do you expect the hub changes in 2027 to change what your supervisors need from this role?" | Links the strategy to the people you would coach |
| R3.4 | "Which of the four values is hardest to live at the counter, and what does it look like when someone gets it right?" | Shows you took the values seriously enough to ask for practice, not slogans |
| R3.5 | "What would help a new Member Experience Lead earn your supervisors' trust fastest?" | Positions you as someone who earns standing rather than assuming it |

---

## Requirement coverage (JD requirement to question IDs)

| JD requirement | Questions |
|---|---|
| "4+ years in financial-services customer operations" | B3, A1 |
| "Own the member complaints process end to end across branches and the contact centre" | D1, D3, B1, H1, I1, A1 |
| "report monthly on complaint volumes and resolution times" | E1, C4, H3 |
| "coach branch supervisors on escalations" | C3, I1, I2 |
| "work with digital teams on self-service journeys" | F1 |
| "experience handling regulated complaints" | D3 |
| "confident presenting to senior leaders" | B2, C4 |
| "comfortable with Excel reporting" | E2, E1 |
| "member-owned" and the four published values | A2, G1 to G4, C1, C2 |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the member complaints process end to end across branches | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: your material says one branch's log and the script training, not what surrounded them. D1's slot stays inside the log |
| Has coached branch supervisors on escalations | Inflated form of F7 | F7's quote at its own scope: "I trained new tellers on our escalation script." The limit is the pack's observation: your material says new tellers, not supervisors |
| Has contact-centre experience | Negative you stated, F3 | The plain acknowledgment F3 gives: "I haven't worked in a contact centre." Then a plan. No slot beyond what D1 holds |
| Has presented to senior leaders | Negative you stated, F6 | The plain acknowledgment F6 gives: "I haven't presented to anyone above regional level." Then a plan |

## Sources

Provided documents: the job description you pasted; the four published values you copied on 17 November 2026 from ashgrovecu.org/about/values; the recruiter's email on the three rounds; your account of the July 2026 strategy brief (not pasted); your background, quoted in the fit snapshot. No tuesday-dossier.md was in hand. No searches or fetches were sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values, copied the same day, fix the cheat sheet and the VAL bank |
| 2. Ashgrove interview process, member service roles | skipped | The recruiter's email names the three rounds, who runs each and what they hold, so it fixes the loop and the persona weights |
| 3. Ashgrove strategy, recent news | skipped | Your account of the July 2026 brief supplies current priorities, and it is under six months old; it fixes the CO bank and the grounding brief |
| 4. Interviewer name and Ashgrove | n/a | No name was given beyond the title Head of Member Services and the panel's "two branch managers", so there was no query to form; the interviewer read is absent |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The two panel members' names and titles once assigned, and the Head of Member Services' name → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to each of their paths
- The recruiter's word on the 20-minute case (format, any pre-reading) → H1 to H3 move from a rehearsal pattern to the declared shape
- Your answers to the slots on F2, F4, F5, F7, F8 and F9, said outside a drill → those rows gain your quoted sentences, and the guidance that draws on them is regenerated
- What the complaints log was kept under, and what the spreadsheet counted and was built in → F4, F5 and F9 can move from discovery to a mapped story
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → interviewer footprint once names are known, recent organisational context, and role-family loop reports, which would turn more CO and CASE rows from the brief's four lines to richer ones
- A tuesday-dossier.md from earlier evidence-checking → verified evidence and any claims ruled out, which would tighten the prohibited list and the strategy for each weak area
