I'll start by reading the reference files the skill points to.
The pack is written and saved. I'm sending you the summary now.

Your prep pack is saved as `/var/tmp/tuesday-measure/1a/runs/sonnet/alone/part-2/rooms/case-7-denied-7bcea9b3/saltmarsh-games_live-operations-producer_interview_pack.md`. I built it for a hiring-manager round, since I don't know Tobias's relationship to the role. The web searches I tried (company values, interview process, strategy, Tobias) were all refused, so nothing in it comes from outside your message. That means there's no values sheet, no read on Tobias, and no company-strategy question. The upgrade menu says what each would add.

Say the word and I'll play the Skeptic on B1, the in-app-purchases question the pack names as your highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the person you'd report to, and did the recruiter say anything about the format or what he'll focus on? Either answer reweights the banks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship not confirmed; this pack is built as a hiring-manager round (60 minutes, Friday).
**Built on:** your message (the JD text and your background) alone. No web research ran, no recruiter guidance was supplied, and the loop is unknown, so persona weights rest on the hiring-manager prior and a generic loop. Sources and the upgrade menu say what each would change.

## How to use this pack

Personas describe how a question arrives; types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values (none are in hand, so no VAL questions appear) |
| EXP | Whether your background survives scrutiny; what was actually you |
| JD | A stated requirement of the role, including where you are thin |
| CO | Company and industry knowledge |
| CASE | A live problem from the role, reasoned aloud |

"Answer slot" in a guidance cell is an instruction for the interview: answer it from your own experience, and either honest branch is a good answer.

## Prep triage

You have until Friday. In order, and in your own voice, out loud:

| Order | Do | Where |
|---|---|---|
| 1 | Rehearse the single most likely objection until it is boring: three follow-up levels, with the concession worded | B1 |
| 2 | Get your own answers ready to the three questions aimed at your thinnest rows | B2, C1, F2 |
| 3 | Think through two live problems aloud: clarify, structure, then answer | A1, A2 |
| 4 | Pick your reverse questions | Reverse questions |

Everything else is insurance.

## Fit snapshot

Requirements are quoted from the JD you supplied, except F9. Evidence is your own words.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | Your material gives four years as an associate producer and a weekly calendar, and does not say whether the puzzle title ran as a live service; it says associate producer, not producer. Words: "I spent four years as an associate producer at a puzzle-game studio." Answer slot: the JD's live-service line makes a probe on what the title was likely. If it ran as a live service, say how in your own words; if it did not, or you are unsure the term fits, say so plainly and stay with the weekly drops you ran |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap in terms, but a self-reported line with nothing inspected behind it, so expect a probe. Lead with the quote's own terms: you ran the weekly content-drop calendar, for your main title, for the last two years |
| F3 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title; it does not say events, and it does not say a second title. Words: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's two-titles line makes a probe on how that would carry over likely. Say in your own words which parts of the calendar you ran would carry over unchanged; if you do not know yet, say so plainly and stay with the one calendar you ran |
| F4 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message; "Never led a team, and never worked on a game with in-app purchases." — your message | low | [grounded] | discovery | The material is silent on which teams your drops involved. The JD line asks for coordination, which is the pack's reading, and you have said you never led a team. Answer slot: if you worked with design, art, engineering or community on a drop, say which, what you asked of each and what happened, in your own words; if you worked with only some of them, or the drops did not need that, say so plainly and stay with the calendar you ran. If asked about leading people: "I've never led a team." |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented the monthly retention numbers to the studio head; it does not say you wrote a review or set KPIs. Words: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's own-the-review line makes a probe likely. Say in your own words what the studio head did with the numbers and what you did next; if nothing followed, or those decisions were not yours, say so plainly and stay with presenting |
| F6 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | Lead with the quote: "I wrote the release checklist our QA team still uses." Expect a probe on how it worked in practice. Answer slot: if you worked with QA when the checklist was used or changed, say how; if you wrote it and QA took it from there, say so plainly |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap in terms: you presented them monthly. The quote gives no figure and no method, so expect a probe on how the numbers were counted. Answer slot: say what you know of how they were counted and the assumption you would defend least; if someone else produced them, or you do not know how a figure was counted, say so plainly |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | discovery | A checklist is a written document others use, and the quote does not show how clear it is. Answer slot: say what else you have written that others relied on, in your own words; if the checklist is the main one, say so plainly |
| F9 | Mobile live-ops roles can involve monetized events, so purchases may come up; a role-family pattern, not in the JD | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. The JD does not mention purchases, so a probe on it would be the interviewer's own. Nothing added to make the gap feel smaller |

No row is a hard gate: the JD's "3+ years" is an experience requirement, graded as such.

## Persona table

Weights start from the hiring-manager prior; the loop is unknown, so the generic fallback adds no tilt. Interviewer signals are absent: no profile was researched.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist (highest) | Live problems from the role: a slipped build, a retention dip, a calendar clash, a brief to write | Hiring-manager prior puts it first, and most JD lines are things done live (F3, F4, F5). The assumption that Tobias is the hiring manager is the pack's, not a source | Clarify first, structure aloud, name the metric you would look at, challenge one premise politely |
| B. Skeptic (highest) | Quiet probing of the gaps | Hiring-manager prior, plus stated absences you have given (F4, F9) and a title that says associate producer (F1). The pack's judgment is that B1 is the most likely single objection | Rehearse B1 until it is boring; bridge only from what you stated; name the limit before it is asked |
| C. Data-Driven Prober (medium) | Line-by-line on the retention numbers | The JD names retention metrics and KPIs (F5, F7), and your material has no figure and no method to lean on | Know what you can and cannot say about how the numbers were counted; say plainly when you do not know |
| D. Conversational (medium) | Friendly biography and "what do you play" openers | Any 60-minute round opens this way; still scored | A 90-second arc built from your own lines; real answers about what you play |
| E. Peer Evaluator (low) | Seam questions with QA and design | The JD's coordination and QA lines (F4, F6) make it plausible, but nothing says a peer is in the room | Propose seam principles, not a fake map of their org |
| F. Pressure (low) | Time-boxed, "how much was you" | Nothing signals a stress style; the pack keeps two items so the register is not new | Pause, restate, hold two follow-ups, then concede exactly what is true |

No values-style round is detected (no loop source, generic fallback), so there is no values persona and no cheat sheet.

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A build slips two days the Monday before a Thursday update. Walk me through what you do." | CASE | [generic] | Clarify first: what slipped, what depends on it, what is fixed on Thursday. Then options (hold, ship reduced, move the date), who needs to hear and in what order (design, art, engineering, QA, community), and what you would record afterwards. The question needs no claim about your past, so the guidance makes none | The JD's coordination and release lines (F4, F6) turned into a decision; CASE because it scores structure |
| A2 | "Day-7 retention dipped after the last event. How do you diagnose it?" | CASE | [generic] | Clarify first (which players, which version, what else changed), then segment, then hypotheses ranked, then what you would ask for and from whom, then what you would report back. Name your weakest assumption aloud | F5 and F7 as a live problem; CASE because it scores reasoning, not recall |
| A3 | "Two titles want the same weekend for a big event. How do you decide?" | CASE | [generic] | Clarify the goals and constraints, offer decision principles rather than a ruling, say what you would want to see for each title, and who else should weigh in. No claim about the past | The JD's two-titles line (F3); a CASE because the real job decides this live |
| A4 | "How would you set up the live-events calendar for two titles in your first month?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Open with the quote at its scope: you ran the weekly content-drop calendar for your main title for the last two years. Answer slot: if anything in that calendar went beyond content drops, say what; if it held only drops, say so plainly and stay with it. Then the plan, said as a plan: what you would ask to see first for each title, and who owns what | Where F3 is probed hardest; JD because it scores the stated requirement, with a plan as the second half |
| A5 | "Talk me through the one-page brief you would send design, art, engineering and community for next Thursday's update. What is on it?" | CASE | [generic] | Structure only: what is shipping and when, who owes what, the open risks, the decision you need, the contact for changes. Keep it a design for a brief, not a story about one you wrote | F4 and F8 together: coordination and clear writing, asked as a live deliverable; CASE |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't worked on a game with in-app purchases. How would you handle that part of the role on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | **Highest-ROI prep in this pack.** Hold: "I haven't worked on a game with in-app purchases." Then say only what carries over at its own scope: you ran the weekly content-drop calendar and presented the monthly retention numbers to the studio head, and that does not make it purchases experience. Then a plan as a plan: what you would ask first, who you would learn from, what you would read before week one. Follow-up 1, "why do you think you can pick it up?": return to those two sentences and the plan, add nothing. Follow-up 2, "what would you get wrong first?": concede specifically that you would not yet know how purchase-linked events are judged, which is the limit you stated. Follow-up 3, "and if we need someone who has done it?": say plainly you do not have that experience and what you would offer instead, without stretching it | F9 is the one stated absence in your material, and the question is rehearsed first because it will arrive in some form; JD because it scores a gap against the role |
| B2 | "You've never led a team. This role coordinates design, art, engineering and community on each update. How do you get work from people you don't manage?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Say it plainly: "I've never led a team." Answer slot: if you worked with design, art, engineering or community on a drop, say which, what you asked of each and what happened; if you worked with only some of them, or not at all, say so plainly and say how you would start. Then principles, as principles: agree the date and the owner, make the ask in writing | F4's thin row; the premise is your own stated negative, so the question is allowed to use it |
| B3 | "The JD asks for three-plus years producing live-service games. Your title was associate producer. What did that cover?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." | Say it at its scope: "I spent four years as an associate producer at a puzzle-game studio." Answer slot: say which parts of producing were yours, in your own words, and whether the title ran as a live service; if the scope was narrower than the JD's, or the term does not fit, say so plainly and stay with the weekly drops you ran | F1: the title gap is the first thing a skeptic reads; JD because it scores a stated requirement |
| B4 | "You ran the calendar for your main title. This role covers two of our titles. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Quote it at its scope: you ran the weekly content-drop calendar for your main title for the last two years. Answer slot: say which parts would carry over unchanged and which you would need to learn, in your own words; if you do not know yet, say so plainly. Then what you would ask on day one about each title's cadence | F3's scale step, rehearsed so the honest answer is ready |
| B5 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Choose from what is true: you have stated two absences, and either is yours to name plainly. Say it, then the plan to close it as a plan. Do not invent a "safe" weakness, because a follow-up finds it | A standard skeptic stem; JD because it scores honest self-assessment against the role |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You presented monthly retention numbers to the studio head. Walk me through how those numbers were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | The quote gives no figure and no method, so this is a slot. Say what you know of how they were counted and the assumption you would defend least, before they ask; if someone else produced them and you presented, say so plainly; if you do not know how a figure was counted, say that | F7 and the defend-the-number rule: the numbers are the claim a prober goes at; EXP because it tests what was yours |
| C2 | "Did a retention number you presented ever change what went on the calendar?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: if a number changed a calendar decision, say which and what part of the decision was yours; if it did not, or the decision was not yours, say so plainly and stay with presenting | F5's link between the numbers and the calendar; EXP |
| C3 | "Pick three KPIs for the review of a two-week event. Which and why?" | CASE | [generic] | Clarify the event's goal first, pick measures that answer it, say what each is sensitive to and which assumption you would defend least. No claim about what you reported before | F5 as a live problem; CASE because it scores choosing and reasoning |
| C4 | "You'd own the post-event review. What does a good one look like?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Describe it as you would build it, as a plan. Answer slot: say in your own words what the studio head did with the numbers you presented; if nothing came of them, or it was not something you saw, say so plainly | F5 is where the JD's ownership language presses; JD because it scores the stated requirement |

### D. Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey. How did you get to running live content?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." | A 90-second arc from your own lines: four years as an associate producer at a puzzle-game studio, the last two running the weekly content-drop calendar for your main title. Answer slot: why this role and why now, in your own words; there is nothing in your material for the pack to supply there | The biography question is still scored; F1 and F2 give the spine |
| D2 | "What are you playing these days, and what do you notice about how it runs its live events?" | CO | [generic] | Name games you actually play and say what you actually noticed, in your own words. If you do not play mobile live games, say so plainly and say what you would look at in the two titles you are interviewing for | A casual question scored on genuine interest; CO because it tests industry fluency |
| D3 | "Tell me about the release checklist. How did it come about?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Say it at its scope: you wrote the release checklist your QA team still uses. Answer slot: what prompted it and how QA was involved, in your own words; if it was assigned, or QA shaped it, say so plainly | F6 and F8: the one written artifact in your material; EXP because it tests what was actually yours |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "QA says a build isn't ready the night before a drop and design says it must ship. How do you handle it?" | CASE | [generic] | Principles first: what each side owns, what evidence each has, who decides, what the cost of each choice is, and what you would record. No claim about the past | F6's QA seam as a live problem; CASE |
| E2 | "How do you handle credit when an update spans design, art and engineering?" | EXP | [generic] | Selection scaffold: pick a time shared work was credited across teams; it needs a named piece of work, your own part stated precisely, and others' parts named. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The Peer stem on F4's coordination line; EXP because it asks for a past instance |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over a producer who has run live events with in-app purchases?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." "Never led a team, and never worked on a game with in-app purchases." | Hold what the quotes carry: you ran the weekly content-drop calendar for two years, you wrote the release checklist your QA team still uses, you presented the monthly retention numbers. Concede the one thing true: "I haven't worked on a game with in-app purchases." Do not close with an inference about what that history proves | F9 under time pressure; EXP because it tests what you can hold |
| F2 | "That calendar — how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold the sentence through two follow-ups: you ran it. Answer slot: say which parts were yours alone and which were shared or set by others, in your own words; if others set the content and you scheduled it, say so plainly. Concede only what is true | The standard attribution probe aimed at F2; EXP |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "3+ years producing live-service games or apps" | B3, D1, F1 |
| "experience running a content calendar" | A4, B4, F2 |
| "Plan and run the live-events calendar for two of our mobile titles" | A3, A4, B4 |
| "coordinate design, art, engineering and community teams on each update" | A1, A5, B2, E1, E2 |
| "own the post-event review and the KPIs it reports" | A2, C3, C4 |
| "manage the release checklist with QA" | A1, D3, E1 |
| "comfortable with player-retention metrics" | A2, C1, C2, C3 |
| "clear written communication" | A5, D3 |

No CO question is grounded in the company's current strategy: no research ran.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a good first 90 days look like for this producer on each of the two titles?" | Shows you are already thinking about the two-titles line (F3) |
| R2 | "How is the post-event review used today, and what has one changed?" | Points at the part of the JD that says own it (F5) and asks what it is for |
| R3 | "Which KPIs does the review report now, and who set them?" | Tells you what you would inherit, and signals you will not guess |
| R4 | "How do design, art, engineering and community work with the producer on an update today, and where does it work least well?" | Asks for the real pain in the coordination line (F4) |
| R5 | "How does the release checklist run with QA today, and what would you change in it?" | Connects to the one artifact you wrote (F6) without claiming more |
| R6 | "How much of this role touches monetization, and where would a new producer learn it?" | Raises your stated gap (F9) as a learning plan on your terms rather than waiting to be probed |
| R7 | "What would make you say in six months that this hire was a success?" | Gives you the success measure to aim your answers at |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led or managed a team | Negative you stated, F4 and F9 | "Never led a team, and never worked on a game with in-app purchases." — your message. Plain words: "I've never led a team." |
| Experience with in-app purchases or monetized events | Negative you stated, F9 | The same sentence. Plain words: "I haven't worked on a game with in-app purchases." |
| Ran the live-events calendar for two titles | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says a weekly content-drop calendar for your main title |
| Owned the post-event review and the KPIs | Inflated form of F5 | F5's quote at its own scope. The limit: your material says you presented the monthly retention numbers |
| Managed releases with QA | Inflated form of F6 | F6's quote at its own scope. The limit: your material says you wrote the checklist QA uses |
| Produced the retention numbers or analysis | Inflated form of F7 | F7's quote at its own scope. The limit: your material says you presented them |
| Held a producer title or three years as a producer | Inflated form of F1 | F1's quote at its own scope. The limit: your material says associate producer, four years |

## Sources

Provided documents: your message (the JD text and your background).

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | The search was refused. It would have fed a values cheat sheet if a values round is documented; none is in this pack |
| 2. Saltmarsh Games interview process, live operations producer | unavailable | The search was refused. It would have set the loop structure and persona weights; they rest on the hiring-manager prior and a generic loop |
| 3. Saltmarsh Games strategy and recent news | unavailable | The search was refused. It would have grounded a CO question in current strategy; D2 and the CASE items are generic |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | The search was refused. It would have supplied an interviewer read and a reverse question tied to his path; both are absent |
| 5. Representative live operations producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

Searches sent, all refused, none returned a result: "Saltmarsh Games company values"; "Saltmarsh Games interview process live operations producer"; "Saltmarsh Games mobile studio news strategy"; "Tobias Wrenfield Saltmarsh Games Head of Live Operations".

## Upgrade menu

- Whether Tobias is your future manager, a skip-level or a peer → persona weights recomputed and the banks reordered
- The recruiter's note on format and focus areas (one email) → coverage of any announced deliverable, and a better guess at the loop
- Permission to run web searches → values, loop and strategy move from missing to sourced, a CO question grounded in current strategy, and an interviewer read for Tobias
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes), if you want it → a strategy brief, the interviewer's public talks and writing, and recent org context
- A sample of something you wrote that others relied on → F8 could move from `discovery` toward a firmer band, since a checklist alone shows little of your writing
- How the retention numbers were counted, and anything about the puzzle title being a live service → F1 and F7 answer slots could be filled with your own words
- A `tuesday-dossier.md`, if you already have one → verified evidence and a strategy per gap, in place of this pack's inferred grading
