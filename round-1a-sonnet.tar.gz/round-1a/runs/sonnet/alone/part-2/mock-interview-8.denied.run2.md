I'll read the reference files the skill requires before writing anything.
Checking the pack's table columns and bracket use. The check needs approval, so I'll skip it and go on from the file as I wrote it.

Your prep pack is saved as `/var/tmp/tuesday-measure/1a/runs/sonnet/alone/part-2/rooms/case-8-denied-a9270679/ashgrove-credit-union_member-experience-lead_interview_pack.md`.

I built it in loop mode, since you gave me all three rounds. It has one shared fit snapshot and a mini-pack per round, each with its own persona weights, question bank and reverse questions. The values cheat sheet sits in round 3. I sent no searches because your pasted values, the recruiter's email, the JD and the strategy summary already covered every target. The Sources section shows that row by row. I have not run a table-format check on the file, so skim the tables when you open it.

Two gaps you named yourself drive the pack. You have never worked in a contact centre, and you have never presented above regional level. D1 in round 2 is the contact-centre objection, and it is the highest-ROI rehearsal in the pack. Three rows are silent in your material (the digital teams, what the spreadsheet counted, whether the complaints were regulated), so those are answer slots: say whichever branch is true. Nothing in your material is a hard gate.

Round 3 puts the "Neighbours, Not Numbers" value in front of two branch managers, while the strategy brief has eight branches becoming five hubs. I flagged that pairing as an inference and wrote questions F3, H1 and H2 around it.

Say the word and I'll play the panel on D1, the contact-centre question the pack names as its highest-ROI prep, or on any round or question you pick.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Member Experience Lead — Ashgrove Credit Union — interview pack for Dara

Candidate: Dara. Loop: three rounds on 26 November 2026, built in loop mode (one shared fit snapshot, then a mini-pack per round).

| Round | Length | Who | Named? |
|---|---|---|---|
| 1 | 30 minutes | The recruiter | Not given |
| 2 | 45 minutes | The Head of Member Services, who would be your manager; mostly behavioural | Not given |
| 3 | 60 minutes | Panel of two branch managers; includes a 20-minute case on a complaint escalation; also the values round, scored against the four values | Not given |

Prepared 17 November 2026. Interviewers beyond their roles have not been assigned, so there is no interviewer read.

**Highest-ROI prep in the pack: D1** (round 2), the contact-centre objection. It is the one gap you named yourself that sits inside the role's first requirement, so it will arrive in some form.

## How to use this pack

Personas describe how a question is asked; types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

Where guidance says **Answer slot**, it is an instruction for the interview, not a question for you now. Answer whichever branch is true. "I did not do that" and "that was not mine" are honest answers, and they score better than a stretched one.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether your own experience holds up when probed |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company and its strategy |
| CASE | Structure and reasoning on a live problem |

Provenance labels: `[grounded]` traces to something you gave me; `[inferred]` is derived from it, with the derivation named; `[generic]` is a pattern with no claim about you or Ashgrove.

## The fit snapshot (shared by all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says your branch's log, with nothing inspected behind it, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's across-branches line makes a probe on how far the log's handling reached beyond your branch likely. If any of it reached beyond your branch, say what and how, in your own words; if none did, or it was not yours, say so plainly and stay with the log |
| F2 | the same JD line, its contact-centre half: "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would get to know it, said as a plan and never as a past (D1). Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The quote says you built the spreadsheet and that your regional manager uses it; it does not say what it counted. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD's volumes-and-times line makes a probe on what it counted likely. If it counted either, say which and how you counted it; if it counted something else, or you do not know how a figure was counted, say so plainly and stay with the spreadsheet |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | low | [inferred] | discovery | Your quote says spreadsheet, not Excel, and this pack does not assume the tool. Answer slot: the JD's Excel line makes a probe on the tool likely. Name the tool it was built in and what you did in it, in your own words; if it was not Excel, say so plainly and stay with what you built |
| F5 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your quote carries training new tellers, not supervisors, and the words stay at tellers: "I trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on how you taught the script likely. If any of it was your own design, say which part; if you delivered a script you were given, or there was no set way you taught it, say so plainly and stay with the new tellers |
| F6 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | The material is silent, so the words are a slot. Answer slot: the JD's digital-teams line makes a probe likely. If you have worked with a digital or online team, say who and what you did, in your own words; if you have not, say so plainly and say what you would look at first |
| F7 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | A self-reported line with nothing inspected behind it. Lead in the quote's own terms: six years in retail banking, the last three as a branch supervisor. The JD says customer operations and your line says retail banking and branch supervisor, so leave the match to the interviewer |
| F8 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | low | [inferred] | discovery | Your quote says a formal log; it does not show what governed those complaints. Answer slot: the JD's complaints-experience line makes a probe on what made the log's complaints formal likely. If rules or timeframes set outside your branch governed them, say which and how you worked to them, in your own words; if none did, or you are not sure what governed them, say so plainly and stay with the log |
| F9 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Then how you would prepare, said as a plan and never as a past (D3). The material does not say what you presented at regional level or to whom, so nothing is claimed there |

No requirement in the JD is a gate in the sense of a licence, location, pay or schedule term, so no row is a hard gate. Nothing in your material is a headline figure, so there is no defend-the-number question.

## Grounding brief — the July 2026 strategy, as you described it

The brief itself was not seen by this pack; these rows are your summary of it, four months old, inside the six-month freshness window.

| Item | What it says | Where it matters in this loop | Provenance |
|---|---|---|---|
| Digital shift | "move 40% of member service to digital channels by 2028" — your message | E1, H2 | [grounded] |
| Branch footprint | "consolidate eight branches into five hubs over 2027" — your message | H1, F3 values question, round 3 reverse questions | [grounded] |
| New product | "launch a small-business lending product in Q1 2027" — your message | Round 2 reverse questions | [grounded] |
| Competition | "the main competitive pressure is app-only banks" — your message | E1, H2 | [grounded] |
| A tension to expect | The values page says every branch is part of its town; the brief has eight branches becoming five hubs. Round 3 is two branch managers scoring against those values, so the pairing is worth rehearsing before it is put to you | F3 (values), H1, H2 | [inferred] from the values page and the brief together |
| A new product and complaints | A product launching in Q1 2027 is a natural place to ask how the complaints process will be ready for it | Round 2 reverse questions | [inferred] from the launch date |

## Requirement coverage

| JD requirement | Questions covering it |
|---|---|
| Own the member complaints process end to end across branches and the contact centre | B1, D1, G1, H1 |
| Report monthly on complaint volumes and resolution times | C2, E2, G3 |
| Coach branch supervisors on escalations | C1, G2, H1 |
| Work with digital teams on self-service journeys | C4, E1, H2 |
| 4+ years in financial-services customer operations | A1 |
| Experience handling regulated complaints | B2 |
| Confident presenting to senior leaders | C3, D2, D3 |
| Comfortable with Excel reporting | C2, E2 |
| Each of the four published values | F1 to F4 |
| Pay, notice, location, reason for leaving (logistics, round 1) | A2 to A5 |

---

# Round 1 — the recruiter (30 minutes)

## Persona weights

| Persona | How it shows up | Weight, with the reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly walk-through, logistics, motivation | 5 questions. The recruiter-screen prior is conversational with logistics, and nothing in the recruiter's email changes it. Casual questions are still scored | A 90-second arc built only from your own sentences (A1); each logistics question answered in your own words (A2 to A5) |
| Skeptic, light | Knock-out checks on the stated gaps | 3 questions. The screen prior includes light knock-out checks, and your two stated gaps are the obvious ones | State each gap plainly and move to what your material does carry (B1, B2); tie motivation to what Ashgrove has published (B3) |

## Question bank — round 1

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your career so far." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses" | Four beats, each a clause your sentences state: six years in retail banking; the last three as a branch supervisor; the branch's formal complaints log; the monthly complaints spreadsheet your regional manager uses. Tell them in your own words and stop at what the sentences say. Close on your reason for wanting this role, which is A2's slot | F7 is the years the JD asks about, and F1 and F3 are the two strongest rows; EXP because a walk-through tests whether the story holds together |
| A2 | "What is prompting a move now?" | EXP | [generic] | Logistics slot for the reason for leaving: give your actual reason, in your own words. If it is about the content of the role, point to what the JD itself lists (the complaints process, monthly reporting, coaching on escalations) rather than to a general view of the sector. No reason is supplied here, because only yours survives a follow-up | A reason for leaving is on every recruiter's list and is where consistency with B3 is checked; EXP because it is about your own history |
| A3 | "What are you looking for on pay?" | JD | [generic] | Logistics slot for pay: either give your own number, or ask for the role's band first. Both are legitimate. Do not volunteer a salary history you were not asked for | The JD does not state pay, so the recruiter will; JD because it concerns the listed job's terms |
| A4 | "What is your notice period?" | JD | [generic] | Logistics slot for notice: give your actual notice period, in your own words, and say plainly if it is fixed or has any flexibility you can truly offer | The recruiter needs a start date to plan the loop; JD because it concerns the job's terms |
| A5 | "Where would you be working from, and how does travel between sites sit with you?" | JD | [generic] | Logistics slot for location: give your actual location and any real travel constraints. The JD names no base, so ask the recruiter where the role is based if it has not been said | The JD's across-branches line and the brief's hub plan (grounding brief) make the base and travel a live point; JD because it concerns the job's terms |
| B1 | "The role covers the contact centre. What is your experience there?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | Short version of D1: "I haven't worked in a contact centre." Then the one thing your material carries, at its own scope: "I handled the branch's formal complaints log." One plan sentence, then stop. Do not defend it at length with a recruiter; D1 is the deep rehearsal | F2 is the gap you stated and the recruiter is the first to meet it; JD because it scores a named requirement |
| B2 | "Tell me about the complaints you handled at your branch. How formal were they?" | JD | [grounded] "I handled the branch's formal complaints log" | Say what the quote says: you handled your branch's formal complaints log. Answer slot: the JD's complaints-experience line makes a probe on what made them formal likely. If rules or timeframes set outside your branch governed them, say which and how you worked to them, in your own words; if none did, or you are not sure what governed them, say so plainly and stay with the log | F8 is the row where the material is silent, and the recruiter is where it is most likely to be checked; JD because it scores a stated requirement |
| B3 | "You have spent six years in retail banking. Why a member-owned credit union?" | CO | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Give your actual reason in your own words. Tie it to what Ashgrove has published (the JD calls it member-owned, and the first value is "Members First, Always") rather than to a general view of credit unions. If what draws you is the content of the role rather than the ownership model, say that plainly | A motivation check is the light-Skeptic move in a screen; CO because it tests whether you know what Ashgrove is |

## Reverse questions — round 1

| Question | Why it lands |
|---|---|
| "Is the round 3 case prepared in advance or set live, and can you tell me its format?" | It is process information only the recruiter holds, and it shows you are preparing for the case specifically |
| "How is the complaints function organised today between the branches and the contact centre?" | It tells you what F1 and F2 will mean in practice and shows you are thinking about the whole of the role |
| "Is there anything in my background you would want the Head of Member Services to hear about from me directly?" | It invites the recruiter to name a concern while you can still address it in round 2 |

---

# Round 2 — the Head of Member Services (45 minutes, mostly behavioural)

## Persona weights

| Persona | How it shows up | Weight, with the reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "Tell me about a time" prompts | 4 questions. The recruiter's own words call this round mostly behavioural, which lifts it above the hiring-manager prior | Story-map from your sentences where one carries it (C1, C2); scaffold where none does (C3, C4) |
| Skeptic | Probes on the gaps | 3 questions. A future manager is derisking the gaps, and you stated two yourself, so this persona stays high despite the behavioural framing | Hold-then-concede on D1; name the gap plainly before it is named for you (D2, D3) |
| Case / Strategist | A live problem on the role's own ground | 2 questions. The round is mostly behavioural, so the case share is small, but the digital line and the 2028 target make one likely | Clarify, objective, segmentation, approach, metrics, risks, aloud (E1, E2) |

## Question bank — round 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you taught someone how to handle an escalation." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script" | Story-mapped on F5, and only to the beats the sentence states: new tellers, and the escalation script. Tell it in your own words and stay at tellers. Answer slot: the JD's coaching line makes a probe on how you taught it likely. If any of the script was your own design, say which part; if you delivered a script you were given, or there was no set way you taught it, say so plainly and stay with the new tellers | F5 is the nearest evidence for the coaching requirement; EXP because it tests what was actually yours |
| C2 | "Tell me about the monthly complaints spreadsheet you built. What did it track?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | The quote carries two facts: you built it, and your regional manager uses it. Answer slot: the JD's volumes-and-times line and its Excel line make a probe on what it counted and what it was built in likely. If it counted complaint volumes or resolution times, say how you counted them; if it counted something else, or you do not know how a figure was counted, say so plainly and stay with what it did track. Name the tool it was built in, whichever it was | F3 and F4 are the rows where your strongest evidence meets two requirements at once; JD because it scores the reporting and Excel lines |
| C3 | "Tell me about a time you delivered an unpopular truth to leadership." | EXP | [grounded] "I've never presented to anyone above regional level" | Selection scaffold: pick a time with a named stake, a moment where you said the thing plainly, and a relationship that was intact afterwards. Your material says you have not presented above regional level, so a story set above it would not be yours; say the level plainly. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F9 makes the leadership audience the sharp edge; EXP because it tests a real instance, and the stem is a standard behavioural one |
| C4 | "Tell me about a time you worked with a team that was not yours to get a member-facing problem fixed." | EXP | [grounded] | Selection scaffold, built from the JD's digital-teams line: pick a time with a named team that was not yours, a member-facing problem, what you asked of them, and what changed. Your material shows no such time, so do not reach for one. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F6 has no evidence at all, and a behavioural round is where it is explored; EXP because it asks for an instance |
| D1 | "You would own complaints across the contact centre, and you have never worked in one. How do you earn credibility with that team?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | **The highest-ROI rehearsal in this pack.** Name the limit before it is asked for: your material says one branch's log, not the contact centre. Hold: "I handled the branch's formal complaints log." Concede, specifically: "I haven't worked in a contact centre." Then a plan, in the future tense and pick only what you would truly do: sit with agents and listen to complaint calls, read the centre's complaint cases, ask the team where handovers to branches go wrong. Follow-up 1 will ask why a branch process should translate: return to the log at its scope and add nothing. Follow-up 2 will ask what you would do in the first month: return to the plan. Never claim the centre is like a branch | F2 is a stated capability gap inside the role's first requirement; JD because it scores that requirement |
| D2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Name one of the two gaps you stated yourself, in your own words ("I haven't worked in a contact centre" or "I've never presented to anyone above regional level"), then say what you would do first. If something else is truly weaker for you, such as the digital-teams line, name that instead. Do not offer a third weakness your material does not show | F2 and F9 are the gaps you named; JD because the stem asks about the listed requirements |
| D3 | "You have never presented above regional level. How would you take a monthly complaints report to our senior leaders?" | JD | [grounded] "I've never presented to anyone above regional level"; "I built the monthly complaints spreadsheet our regional manager uses" | Acknowledge plainly: "I've never presented to anyone above regional level." Then the plan, as a plan: how you would prepare and who you would rehearse with. Answer slot: if you presented the spreadsheet's results to your regional manager, say what you presented, in your own words; if it was sent or used without you presenting it, say so plainly and stay with the spreadsheet. Hold through two follow-ups by returning to the plan, never by adding experience | F9 is the stated gap on the requirement that sets this role's visibility; JD because it scores that line |
| E1 | "The strategy puts 40% of member service on digital channels by 2028. A member tells us they tried self-service, got nowhere, and then bounced between the branch and the contact centre. How do you handle it, and what do you need to know first?" | CASE | [grounded] | Clarify first: what the member tried, where it failed, what they were told, who holds the complaint now, what they are asking for. Objective: this member fixed, and one named person keeps hold of it (the value "Own the Fix"), told in plain words. Segment: one case or a pattern, by journey step and by channel. Approach, metrics (complaint volumes and resolution times by journey step, repeat contacts), risks (a digital push that hides complaints rather than solving them). Challenge one premise respectfully, such as whether a share of members moved is the right measure on its own. The case needs no claim about your past, so none is made | The brief's 40% target and the JD's self-service line make this the likeliest live problem; CASE because it asks for structure on the role's own ground |
| E2 | "Sketch the monthly complaints report you would bring to this leadership team. What do you need to know first?" | CASE | [grounded] | Clarify the audience and the decisions the report feeds. Then name the two measures the JD names, complaint volumes and resolution times, and ask when the clock starts and stops, since a time without a definition cannot be compared. Split by branch, contact centre and complaint type. Lead the page with the point (the value "Plain Words"). Say plainly which tool you would build it in. The case needs no claim about your past, so none is made | The JD's reporting line and its senior-audience line meet here; CASE because it is a live design problem rather than a recollection |

## Reverse questions — round 2

| Question | Why it lands |
|---|---|
| "How do escalations move between the contact centre and the branches today, and where do they go wrong?" | It turns D1's gap into a learning agenda and shows you are already looking at the seam |
| "Which digital teams would I work with on self-service journeys, and what do they already measure?" | It addresses F6 directly and asks for the shared facts you would need |
| "What does a good monthly complaints report look like to you, and who reads it?" | It tests your picture of the audience, which D3 turns on |
| "With the small-business lending product launching in Q1 2027, how is the complaints process expected to be ready for it?" | It uses the brief's own date and signals you think ahead of the complaints, not behind them |

---

# Round 3 — the panel of two branch managers (60 minutes; 20-minute case; values round)

## Persona weights

| Persona | How it shows up | Weight, with the reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scenario probes against the four published values | 4 questions, one per value. The recruiter's own words say the panel scores against the four values | A selection scaffold per value with its honest branch (F1 to F4); no quoted sentence carries a values story, so none is invented |
| Case / Strategist | The 20-minute escalation case | 3 questions. The recruiter named the case and its length, so it is certain; the weight is 3 because one case fills the slot | Clarify, then structure aloud; say the framework before using it (G1 to G3) |
| Peer Evaluator | Seam-splitting between the role and a branch | 2 questions. Panel prior blends the top two of each member's relationship; branch managers sit beside the role you would play, not over it. Their names are not known, so weights are per round, not per member | Offer seam principles instead of pretending to know the seam; reciprocity framing (H1, H2) |

## Question bank — round 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you made a decision from the member's side of the counter." | VAL | [grounded] | Selection scaffold for "Members First, Always": pick a time with a named member situation, the decision you made, what it cost someone (a rule, a target, a colleague's time) and what the member would say. "We" for context, "I" for contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The first published value; VAL because it scores behaviour against that value by name |
| F2 | "Tell me about a time you rewrote something so a member only needed it explained once." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script" | Selection scaffold for "Plain Words": pick a time with the original wording, what was unclear, the rewrite and how you knew it worked. Answer slot: the nearest thing your sentence carries is the escalation script you trained tellers on. If the script's wording was yours to change, say what you changed and why; if it was given to you, or you did not change its wording, say so plainly. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The value's own test is whether a member needs it twice, and complaints are written communication; VAL because it scores that value by name |
| F3 | "Tell me about a time you weighed what a number said against what a branch or its town needed." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Selection scaffold for "Neighbours, Not Numbers": pick a time with a number, a branch or town need pulling the other way, the decision, and who was told what. Your sentence says you built a monthly spreadsheet; it does not say you weighed it against a town, so do not tell it as if it did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The brief has eight branches becoming five hubs and the panel is two branch managers, so this value is worth rehearsing first (grounding brief); VAL because it scores that value by name |
| F4 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold for "Own the Fix": pick a time with the problem you found, who else could have dropped it, how you kept hold of it, and how it ended. Answer slot: your sentence says you handled the log; it does not say any complaint stayed with you from finding to solution. If one did, say which and how, in your own words; if the log was about recording and the fix was someone else's, say so plainly and stay with the log. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The fourth value, and the one that mirrors the role's first line; VAL because it scores that value by name |
| G1 | "A member's complaint has bounced between a branch and the contact centre, each saying it is the other's, and the member has now written in. It lands with you. What do you do first, and what do you need to know?" | CASE | [generic] | Clarify first: what the complaint is, what the member is asking for, what each side has done, whether any deadline applies. Objective: one named holder, the member told plainly who it is, and a reply in plain words. Segment: one case or a pattern. Approach, metrics, risks. Challenge one premise respectfully, such as whether both sides mean the same step. Say the structure aloud before using it. The case needs no claim about your past, so none is made | The role's first line and the recruiter's named escalation case; CASE because it is a live problem |
| G2 | "Now the branch supervisor on that case tells you your handling is wrong and the branch's way is fine. How do you coach them?" | CASE | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Listen first; establish the facts of what the supervisor did and why; anchor on the member's outcome; separate the person from the step; agree the next action; say what you will check and when; concede at once if they are right. You may say you have sat in the supervisor's seat ("the last 3 as a branch supervisor") and add nothing about what it taught you | The JD's coaching line meets F5's limit; CASE because it is a live seam |
| G3 | "Three months on, the monthly report shows resolution times worse in branches and better in the contact centre. What do you do with that?" | CASE | [generic] | Check the data before the story: is the clock defined the same way in both, has the mix of complaints changed, is it one branch or all. Split by complaint type and by branch. Say what you would tell leaders and when, and what you would not yet conclude. The case needs no claim about your past, so none is made | The JD's reporting line carried into the panel's own world; CASE because it is a diagnosis problem |
| H1 | "Branches are consolidating into hubs through 2027, and you would be coaching our supervisors on escalations. Where is the seam between your role and a branch manager's, and what happens when we disagree?" | JD | [grounded] | Offer seam principles rather than pretending to know the seam: the branch decides how it runs; the role decides how a complaint is held and reported; the member's outcome comes first. On disagreement: raise it early, agree the facts, then take it to the Head of Member Services if it is not settled. Reciprocity: say what the branches get from one view of complaints. Say plainly that you would learn the seam rather than assume it | The brief's hub plan and the JD's coaching line put the role beside the branch managers; JD because it scores how you would work in the role |
| H2 | "The strategy puts 40% of member service on digital channels by 2028. What does that change for complaints coming through my branch?" | CO | [grounded] | Use the brief's own words and think aloud. Ask what branches handle at the counter today. Which complaint types are likely to stay human; members who cannot or will not use digital; and the pull against "Neighbours, Not Numbers", which you can name plainly rather than smooth over. Do not claim facts about Ashgrove's app or channels that the brief does not give | The brief's target and the stated competitive pressure meet the panel's own branches; CO because it tests whether you can think at the company's altitude |

## Values cheat sheet

| Value (official name) | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Members First, Always | Decisions start from how things look to the member, not to the institution | Selection scaffold (F1): a named member situation, the decision, its cost, what the member would say. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Plain Words | A member should not need it explained twice; if they do, the writer got it wrong | Nearest row F5: "I handled the branch's formal complaints log and trained new tellers on our escalation script" at its own scope, with the slot in F2. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Neighbours, Not Numbers | Each branch belongs to its own town, not to a table of figures | Nearest row F3: "I built the monthly complaints spreadsheet our regional manager uses" at its own scope, with the limit in F3. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Own the Fix | Whoever finds a problem stays with it until it is solved | Nearest row F1: "I handled the branch's formal complaints log" at its own scope, with the slot in F4. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

## Reverse questions — round 3

| Question | Why it lands |
|---|---|
| "What could a new Member Experience Lead do in their first month that would genuinely help your branch?" | The reciprocity question for a peer panel: it asks what you can add to their work, not only what you need |
| "When a complaint leaves your branch today, what works well and what do you wish were different?" | It gives you the panel's own seam in their own words, which H1 asks you to propose |
| "How will complaints be handled for members whose branch becomes part of a hub during 2027?" | It uses the brief's own plan and the value "Neighbours, Not Numbers" together, and it is a question a branch manager can answer from experience |
| "Which of the four values is hardest to live up to in a complaint?" | It invites a candid answer and shows you read the values as working rules, not slogans |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the member complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says your branch's log, not the process across branches and the contact centre. The slot in F1 stays inside the log |
| Coached branch supervisors on escalations | Inflated form of F5 | F5's quote at its own scope. Your material says new tellers and the escalation script, not supervisors. C1's slot stays inside the tellers |
| Handled regulated complaints | Inflated form of F8 | F8's quote at its own scope: a formal log. Your material does not show what governed those complaints; B2's slot stays inside the log |
| Has worked in a contact centre | Negative you stated, F2 | The plain acknowledgment F2 gives: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F9 | The plain acknowledgment F9 gives: "I've never presented to anyone above regional level." No slot |

## Sources

Provided documents: the job description text; the values text, copied on 17 November 2026 from ashgrovecu.org/about/values (pasted, not fetched); the recruiter's email on the process; your summary of the July 2026 strategy brief (the brief itself was not seen); your background in your own message. No dossier was present.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values text fixes the values cheat sheet and F1 to F4 by name |
| 2. Ashgrove interview process, member-service roles | skipped | The recruiter's email gives the number of rounds, their lengths and who runs each, so it fixes persona weights per round |
| 3. Ashgrove strategy and recent news | skipped | Your summary of a four-month-old brief fixes the grounding brief, E1, H1 and H2 |
| 4. Interviewer name and Ashgrove | n/a | No interviewer has been named, so there is no query to form; the interviewer read is absent |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV, or the CV lines on the complaints log, the spreadsheet and the escalation script → F1, F3, F4, F5 and F8 move from your summary's wording to your own CV's, and some medium rows may rise
- Your answers to the slots in F3, F4, F5, F6 and F8 (what the spreadsheet counted and was built in; whether the script was yours; any digital-team work; what governed the complaints) → those rows become grounded, and the matching bank slots become real beats
- The recruiter's answer on the round 3 case format, and whether any materials come in advance → a build section for any pre-declared deliverable, and a sharper G bank
- Interviewer names once assigned → an interviewer read, persona weights per person, and a reverse question tied to each one's career path
- How many hours you have before 26 November → a prioritised prep schedule sized to it
- Deeper research (up to 6 more searches and 2 more fetches, several more minutes) → Ashgrove's own public material on the hub plan and digital move, a view of the app-only competitor set, and reports of the loop for similar roles
- A prior evaluation of this role saved as tuesday-dossier.md → verified evidence behind F3 to F8 and a recorded objection in place of the inferred one in D1
