I'll read the reference files the skill requires before writing anything.
Web search was denied, so I'll build the pack without research. I'll mark the research rows unavailable and keep every fact about Larkfield out of the banks.
Your prep pack for all three rounds is saved at `/var/tmp/tuesday-measure/1a/runs/sonnet/alone/part-2/rooms/case-6-denied-8a1738cc/larkfield-systems_engineering-manager_interview_pack.md`.

The pack has one shared fit snapshot and a mini-pack per round. Each mini-pack has its own persona weights, a question bank with answer guidance (11 questions for Tuesday, 10 for the panel, 8 for the VP) and five reverse questions.

I couldn't research Larkfield. Web search was denied, so I didn't look up its values, interview process or strategy. The VP-round values questions take their themes from the recruiter's "values and leadership philosophy" description, and there is no values cheat sheet. The company-strategy question (C8) is generic and flagged as such.

I built the pack on these assumptions:
- **Evidence:** it comes only from your message, since I have no CV or full JD.
- **Round types:** I treated the Director as a hiring manager, the staff engineers as peer and depth evaluators, the product manager as cross-functional, and the VP as a skip-level values round.
- **Highest-ROI prep:** the biggest objection I expect is the hardware-roadmap gap, rehearsed in A1 and returning in B4 and C7.
- **Second most likely:** the "how much of the 60% was you" challenge, covered in A8, B5 and C6.

Say the word and I'll play the Director on A1, the hardware-gap question the pack names as the highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Can you paste your CV and the full JD, or tell me to go ahead without them? They would turn several selection scaffolds into story-mapped answers.
2. Did the recruiter say anything about what the panel or the VP round will cover, or whether you should bring a case or presentation?
3. If you allow web search, should I run the standard research pass on Larkfield's values, interview process and recent strategy and fold it in?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview pack (loop mode): Engineering Manager, Larkfield Systems

Candidate: Yusuf. Three rounds, one shared fit snapshot, a mini-pack per round.

| Round | When | Who and how long | Relationship used for weighting |
|---|---|---|---|
| 1 | Tuesday | Director of Engineering, 45 min | Hiring manager, your would-be boss |
| 2 | The Thursday after | Two staff engineers and a product manager, 60 min panel | Panel: staff engineers weighted as peer and depth evaluators, the product manager as cross-functional |
| 3 | The following Monday | VP Engineering, 30 min, described by the recruiter as "values and leadership philosophy" | Skip-level executive, values-style round |

The role, from your message: "Engineering Manager — Larkfield Systems (industrial IoT, ~600 people). Lead two squads building device-management services; own delivery, hiring and growth for 11 engineers; partner with hardware and product on roadmap."

## How to use this pack

Personas describe how a question arrives (who is asking, in what style). Types describe what the question is scored on. Every question carries both.

| Tag | Name | What it is testing |
|---|---|---|
| VAL | Behavioral and values | Whether past behavior shows the values being asked about |
| EXP | Work-experience deep-dive | Whether your claims survive scrutiny, and what was actually yours |
| JD | Role-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy | Homework depth and altitude |
| CASE | Live problem | Structure and reasoning on a problem from the role |

Answer guidance is scaffolding, not a script. Where it says answer slot, the guidance is an instruction for the interview: say your own answer to the branch that is true for you, and if neither branch is true, say so plainly. Provenance labels: `[grounded]` traces to what you told me, `[inferred]` is derived from it, `[generic]` is a pattern with no claim about you or Larkfield.

## Prep triage

You have about two weeks and three rounds. In this order, each tied to its IDs:

1. The hardware-roadmap gap, said aloud until it is boring: A1, then B4. This is the highest-ROI prep in the pack (see Round 1).
2. The reliability-quarter sentence in three registers: counting it (A8), attributing it (B5), conceding on it under pressure (C6).
3. One team to two squads: A2, then C5.
4. The case structures, spoken aloud: A5, A7, B7, B8.
5. Finding a real growth story, or deciding to say there is none: A11, B10, C4.
6. The hiring-loop sentence and its number: A9, B6, C3.

Everything else is insurance.

## Fit snapshot (shared across all three rounds)

The role description you gave is the only requirements source, so every requirement below is quoted from it. Evidence cells hold only your own sentences. The role description as given states no eligibility terms (location, pay, authorization, credential), so there are no gate rows; a full JD would show whether it has any.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services", the lead-two-squads strand — role description in your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message | medium | [grounded] | transferability | Your material says one team of six, not two squads, and the words stay there: "For three years I've been a team lead of six." Answer slot: the role description puts eleven engineers across two squads under you, so expect a probe on the step from one team to two. If any of your lead work already reached beyond your own team, say what and how much of it was yours, in your own words; if none did, say so plainly and stay with the team of six, then say as a plan how you would approach two squads |
| F2 | "building device-management services", the domain strand — role description in your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message | low | [inferred] | discovery | Your material says nine years of engineering and a payments company today, and does not show device-management or industrial IoT work. Answer slot: if any of your engineering touched devices, fleets or connected hardware, say what and what your part was, in your own words; if none did, say so plainly and say what you would study first |
| F3 | "own delivery, hiring and growth for 11 engineers", the delivery strand — role description in your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | Your material carries one decision about delivery under pressure and its result, at its own scope: the burden dropped after the quarter, and the sentence does not say the quarter caused it. It does not say how delivery was run week to week. Answer slot: if you run delivery for your team in some regular way, say how, in your own words; if delivery was run by someone else or there was no set routine, say so plainly and stay with the reliability quarter. The number's own slots are on A8 |
| F4 | "own delivery, hiring and growth for 11 engineers", the hiring strand — role description in your message | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | none | No gap on the strand as written, but a figure with nothing inspected behind it, so expect a probe on it. Lead with the loop in the quote's own terms: you run it, for backend roles, and about 40 interviews happened last year. The figure counts interviews, so it stays attached to interviews. The quote names backend roles; the squads' roles may differ, which is the pack's observation and not words for you |
| F5 | "own delivery, hiring and growth for 11 engineers", the growth strand — role description in your message | none given | none | [grounded] | discovery | Your material says nothing about growing engineers. Answer slot: the role description names growth, so expect a probe. If there is an engineer you helped develop, say what they could not yet do, what you did and what changed, in your own words; if there is no such case, or it was not yours, say so plainly and say how you would approach it |
| F6 | "partner with hardware and product on roadmap", the product strand — role description in your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | Your material says a reliability quarter was pushed through against roadmap pressure; it does not say who stood on the other side of that roadmap. Answer slot: if you worked it through with product or another team, say who and what each side wanted; if the decision was taken another way, or not with anyone else, say so plainly and stay with the sentence |
| F7 | "partner with hardware and product on roadmap", the hardware strand — role description in your message | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. The pack's observation: your material is silent on whether you have worked alongside hardware or firmware teams without owning their roadmap, and the upgrade menu asks |

### Requirement coverage

| Requirement strand | Covered by |
|---|---|
| Lead two squads (F1) | A2, A5, B1, C5 |
| Device-management domain (F2) | A3, A4 |
| Delivery (F3) | A6, A8, B5, B7, C7 |
| Hiring (F4) | A7, A9, B6, C3 |
| Growth (F5) | A11, B10, C4 |
| Partner with product (F6) | A6, B2, B8, B9 |
| Partner with hardware (F7) | A1, A5, B4, C7 |
| Managing managers | none, and why: the role description names engineers, not managers; the Prohibited claims section covers what you would say if asked |

---

# Round 1: Tuesday, Director of Engineering (45 min)

Highest-ROI prep in the pack: A1, the hardware-roadmap gap. It is the question a would-be boss is most likely to ask in some form, F7 is where your material is thinnest against the role, and the same gap returns in B4 and C7 in other packaging. A rehearsed, non-defensive answer here changes the whole loop.

## Persona weights

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the hardware gap, the one-team-to-two step, the domain switch | High (4 questions). A hiring manager is buying capability and derisking gaps, and F1, F2 and F7 give a Director three places to probe | Rehearse A1 until boring; bridge only from what you stated; say the limit before it is asked |
| Case / Strategist | Live problems on the squads' actual situation | Medium (3 questions). Hiring-manager prior; a 45-minute slot with a future boss usually holds at least one live problem | Clarify, then structure, then answer; think aloud; challenge one premise politely |
| Data-Driven Prober | Reads your message line by line and tests the two figures | Low to medium (2 questions). A boss will test the 60% and the 40 because they are the only numbers you gave | Know what you can and cannot say about how each was counted; say plainly when you do not know |
| Conversational | Opens with the journey, drifts into how you develop people | Low (2 questions). Likely at the start and end of a one-to-one, and still scored | A 90-second arc built only from what you said |

No interviewer name was given, so there is no interviewer read; weights rest on the relationship prior alone.

## Question bank

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | The deepest rehearsal here. Say it before they do, in the sentence's own words: "I haven't owned a hardware-adjacent roadmap." Then give a plan, not a past: what you would ask the hardware lead in week one and what you would not decide until you had the answer. Hold through two follow-ups by returning to the plan. Name the limit before it is asked for: you cannot speak from experience about hardware release constraints, and should not try by analogy. Concede specifically what you do not know; never fold into implying you have it | F7 is the biggest gap against the role and this is the open Skeptic stem that exposes it; JD because it scores the stated hardware-partnership requirement |
| A2 | "You've led a team of six. This is two squads and eleven engineers. What changes for you?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Hold only what the sentence carries: "For three years I've been a team lead of six." Concede that the step from one team to two is real. Answer slot: if any of your lead work already reached beyond your own team, say what and how much of it was yours; if none did, say so plainly and stay with the team of six. Then say as a plan what you would do in the first two weeks, labelled as a plan | F1 is the scope jump; the Question's figures come from your sentence and the role description, and the slot lets the premise of prior breadth be false |
| A3 | "Why leave a payments company for industrial IoT?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Selection scaffold: give the reason you actually have, in your own words, and test it against "and why not do that where you are now". Do not script a reason you do not hold. If no reason beyond the role's scope comes to mind, say so plainly, then give the nearest true thing about what draws you to this work | Motivation consistency is what a Skeptic scores; F2 is the domain switch it presses on |
| A4 | "You're at a payments company today. What makes you think you'd be useful in device management?" | JD | [inferred] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Low-confidence row, so this is a clarify answer, not a claim. Answer slot: if any of your engineering touched devices, fleets or connected hardware, say what and what your part was, in your own words; if none did, say so plainly and say what you would study first and who you would ask | F2 is thin on evidence; inferred because the domain match is the pack's derivation, not something your sentence shows |

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A5 | "You inherit two squads you haven't met. A hardware release date is slipping. What do you do in your first two weeks?" | CASE | [generic] | Clarify first: whose date, what slipping costs, what is already known. Then structure: who you talk to, what you decide now versus defer, what you tell the squads. Challenge one premise politely, for example whether the date is movable. The question needs no claim about your past, so the guidance makes none | A live problem set in the role that touches F1 and F7 together without assuming anything about you; generic because it is a pattern for the problem |
| A6 | "Product wants a new feature next quarter and one squad's on-call load is high. How do you decide?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Structure the decision first: cost of each, who is affected, what you would ask product, what you would ask the squad. If your reliability quarter is your nearest example, tell it only at its own scope: your team's on-call burden dropped 60% after you pushed a reliability quarter through against roadmap pressure. Answer slot: expect a probe on how that call was made; if you made a case for it, say how, in your own words; if there was no such case, or it was not yours, say so plainly and stay with the sentence | F3 and F6 both draw on this sentence; CASE because it asks for a decision, with your own story as optional support |
| A7 | "You can add one engineer to one squad. How do you decide where, and what do you look for?" | CASE | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Structure first: what each squad is short of, what the hire must do, how you would test for it. Where you refer to your loop, use the sentence: you run it, for backend roles, about 40 interviews last year. Anything about how you score or what you look for is for you to say in your own words, and is not supplied here | F4 is your strongest-evidenced strand; CASE because the Director will want to see the reasoning, not only the claim |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A8 | "Walk me through how that on-call number was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Four slots, each in your own words: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. "I don't know how it was counted" is an honest branch. The sentence says the burden dropped after the quarter; do not say it caused the drop unless you know it did | F3 is the only row with a figure the Director can test, and a figure is where a Prober starts; EXP because it scores attribution |
| A9 | "About forty interviews last year. How many were yours, and what happened to the candidates?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Slots in your own words: whether the 40 were interviews you conducted or the loop's total, how it was counted, which part was yours. On outcomes, say what you know and say plainly what you do not; the sentence gives a count of interviews and no outcome, so none is supplied here | F4's figure counts interviews and invites the denominator question; EXP because it tests what was yours |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A10 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | A 90-second arc whose stated beats are the sentence's own: nine years in engineering, three as a team lead of six, a payments company today. What you did between those beats and your actual reason for this role are for you to say in your own words; the pack supplies neither | A one-to-one with a future boss almost always opens here; F1 and F2 are the rows it sets up |
| A11 | "How do you help engineers grow?" | JD | [grounded] | Selection scaffold: pick a real case with a named starting point, something you did, and a change that followed, and say which part was theirs. If no such case comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Do not invent a mentee story | F5 has no evidence, and the role description names growth; JD because it scores the stated responsibility |

## Reverse questions (Round 1)

| # | Question to ask | Why it lands |
|---|---|---|
| 1 | "What does a strong first ninety days look like in this role, and where would you expect me to need the most help?" | Puts the hardware gap on the table on your terms and shows you plan to close it rather than hide it |
| 2 | "How do priorities between hardware, product and engineering get set for the two squads today, and where does that strain?" | Tests the real roadmap partnership, which the role description names and your material does not cover |
| 3 | "Is this a new role or a backfill, and what did that teach you about what the role needs?" | Diligence you genuinely need, and it surfaces the Director's hopes for the seat |
| 4 | "How do you like to be kept informed, and how do you want to hear about a disagreement with you?" | A would-be boss answers this about themselves, and you learn how to push back safely |
| 5 | "In a year, what would make you say this hire was a mistake?" | Converts the hidden objection into a stated criterion you can plan against |

---

# Round 2: The Thursday after, panel of two staff engineers and a product manager (60 min)

Names were not given, so no per-member interviewer read.

## Persona weights

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Staff engineers pricing what you cost and contribute to their work; seams, disagreement, credit | High (4 questions). Staff engineers will work under your leadership but with deep standing; the panel prior blends the top two personas of each member's relationship | Reciprocity framing; seam principles, not pretended knowledge; disagreement stories with spine and tact |
| Data-Driven Prober | Technical depth and attribution from the staff engineers | Medium (2 questions). Staff engineers verify depth, and your two figures are the testable claims | Say what you know and do not know about each number; precise attribution |
| Case / Strategist | A live on-call problem and a roadmap trade-off with the product manager in the room | Medium (2 questions). Panels with a product partner usually test the joint decision | Clarify, structure, think aloud; give the product manager something, not just a request |
| Conversational | The product manager's partnership questions; growth for senior engineers | Medium (2 questions). Cross-functional prior; friendly register, still scored | Short arcs; ask a real question back |

## Question bank

### Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our staff engineers will know these systems better than you on day one. How do you make a call when we disagree with you?" | CASE | [generic] | Offer principles, not a history: who decides, who must be heard before the decision, how a decision gets written down, how a disagreement is revisited. Say plainly that on technical depth you would lean on them. The question needs no claim about your past, so the guidance makes none | F1 and F2 mean a new leader with domain catching up; this is the Peer stem on spine and tact |
| B2 | "Tell me about a time another team wanted something different from you. How did it end?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The nearest sentence you have is this one, so keep to its beats: a reliability quarter, roadmap pressure, a 60% drop in on-call burden. Answer slot: if another team or function was on the other side, say who, what they wanted and how it ended; if the pressure was not from another team, or it did not end in a way you can describe, say so plainly and stay with the sentence | F6 is where this panel's product partner presses; the theme comes from the role description's partnership line and the Peer stem |
| B3 | "How do you handle credit when work spans squads?" | VAL | [generic] | Selection scaffold: give the principle you actually hold and, if you have one, a real instance with what you did and what the other side got. If no instance comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | The Peer stem on credit; generic because no quoted sentence of yours speaks to it |
| B4 | "You haven't owned a hardware-adjacent roadmap. What would you want from us to cover that?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Plain acknowledgment first: "I haven't owned a hardware-adjacent roadmap." Then reciprocity: say what you would ask the staff engineers to teach you, what you would bring them in return, and the seam principle you would propose, all as plans. Do not pretend to know the seam | F7 returning in collegial packaging, as the Peer persona does; JD because it scores the hardware-partnership requirement |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B5 | "You said you pushed a reliability quarter through. What did you do, and what did the team do?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Keep the verb you used: "I pushed it through". Answer slot: if there were specific things you did, say what, in your own words; if others did most of the work, or the sentence is a shorthand for something smaller, say so plainly. Name the assumption behind the 60% you would defend least, or say you do not know how it was counted | F3 and F6 rest on this sentence, and attribution is what a technical panel verifies; EXP because it tests what was yours |
| B6 | "How do you decide a candidate is a yes in your loop?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Start with the sentence: you run the loop, for backend roles, about 40 interviews last year. Answer slot: if you set the criteria or the scoring, say how, in your own words; if they were set elsewhere or you applied someone else's, say so plainly and stay with running the loop. The staff engineers may sit in your loops, so ask what they would want in one | F4 again, from the people who would interview with you; EXP because it tests what was actually yours |

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B7 | "A squad's service pages the on-call engineer twice a night for a week. What do you ask first?" | CASE | [generic] | Clarify before structuring: which service, what changed, who is carrying the load, what is already known. Then structure: stop the bleeding, find the cause, decide what to defer. Whether to tell your own reliability story is optional, and if you do, keep to its sentence | A live on-call problem is the staff engineers' native ground; no claim about your past is needed |
| B8 | "Product has three feature asks and engineering has one reliability item. Walk us through choosing, with the product manager in the room." | CASE | [generic] | Say your criteria aloud before ranking: customer impact, risk, cost of delay, who is carrying load. Ask the product manager one real question, and name what you would give them in return. Challenge one premise, for example that the four items compete for the same people | The joint decision this panel exists to test; generic because it asks about no past |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B9 | "What do you need from product to run two squads well, and what do you bring them?" | JD | [grounded] | Reciprocity answer: two or three things you would ask for and two or three things you would offer, all as principles. Do not describe a past product partnership unless you can say, in your own words, who it was with and what you did | The role description names product partnership; the product manager is scoring whether you reduce or add to their load |
| B10 | "How would you help a staff engineer keep growing if they don't want to manage?" | JD | [grounded] | Selection scaffold: if you have a real case, tell what they wanted, what you did and what changed, and which part was theirs. If no such case comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | F5 again, aimed at senior engineers; growth is in the role description |

## Reverse questions (Round 2)

| # | Question to ask | Why it lands |
|---|---|---|
| 1 | To the staff engineers: "What do you wish engineering managers did less of, and more of?" | Gives them the floor on the thing they care about and tells you the real bar |
| 2 | To the staff engineers: "Where does on-call pain concentrate today, and what has already been tried?" | Shows you start from the problem, and it is information you need |
| 3 | To the product manager: "When a roadmap commitment is made or unmade, who has the last word between product, hardware and engineering?" | Tests the partnership the role description names and shows you are thinking about the seam |
| 4 | Reciprocity, to the panel: "What could a new engineering manager do in the first month that would genuinely help your work?" | Peer reciprocity: it prices your value to them, not just their value to you |
| 5 | To the panel: "Where do the two squads step on each other today?" | Surfaces the boundary problem before you inherit it |

---

# Round 3: The following Monday, VP Engineering (30 min, "values and leadership philosophy")

The recruiter's description is the loop source for this round, so a values-style round is detected. Larkfield's published values could not be researched (see Sources), so there is no values cheat sheet in this pack. The VAL questions below take their themes from the recruiter's description and from the Values persona stems, and mapped stories are marked where your sentences carry one.

## Persona weights

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scenario probes on leadership philosophy, hard truths, bars, people | High (4 questions). The recruiter's own words name the round values and leadership philosophy | Map a story where your sentence carries one; "we" for context, "I" for contribution; say plainly where the material shows no such story |
| Pressure | Time-boxed challenge on scope and credit | Medium (2 questions). Skip-level executive prior, and 30 minutes forces short answers | Pause, restate, hold through two follow-ups, concede specifically |
| Case / Strategist | A question at the VP's altitude on trade-offs and the business | Medium (2 questions). Executive prior; company-strategy fluency separates candidates here and could not be researched | Say what you actually know; do not recite what you have not read |
| Conversational | Philosophy questions asked casually | Low, no separate bank. C2 carries it | Treat the casual ones as scored |

## Question bank

### Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The nearest sentence is this one, so keep to its beats: a reliability quarter, roadmap pressure, a 60% drop in on-call burden. Answer slot: if the pressure came from leadership and you had to say something unwelcome, say what you said and how it landed; if the pressure was not from leadership, or nothing unwelcome had to be said, say so plainly and stay with the sentence | Values round, Values persona stem; F6 and F3 rest on this sentence and it is your best story, so it needs the honest branch ready |
| C2 | "How would you describe your leadership philosophy, and where did it come from?" | VAL | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Selection scaffold: name two or three ways you actually lead, and for each point to one thing you did that shows it, drawing on your quoted sentences where one carries it. If a principle has no instance you can point to, say so plainly. Do not recite principles you do not hold | The recruiter's own words name leadership philosophy; F1 is the three years it grew from |
| C3 | "Tell me about a time you held a hiring bar when it meant a seat stayed empty." | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Answer slot: if there was such a time, say what the bar was, what it cost and what you did, in your own words; if there was none, or the call was not yours, say so plainly and stay with the sentence: you run the loop, for backend roles, about 40 interviews last year | F4 is your strongest strand, and the role description names hiring; VAL because holding a bar is a values test |
| C4 | "Tell me about a time an engineer you were responsible for was struggling. What did you do?" | VAL | [generic] | Selection scaffold: pick a real case with a named stake, what you did, and an honest ending, including if it did not end well. If no such case comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. Do not supply an ending you did not see | F5 has no evidence, and a values round is where growth and difficulty are probed |

### Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C5 | "You've led one team of six. Why should I trust you with two squads?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Hold-then-concede. Hold: "For three years I've been a team lead of six." Concede specifically: the step to two squads is real and what you have is a plan. Through two follow-ups, return to the sentence and the plan; do not stretch the sentence to cover the gap | F1 under time pressure; an executive tests composure and whether you hold a position without bluffing |
| C6 | "That 60%. How much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold-then-concede. Hold the sentence: the burden dropped after you pushed the quarter through. Concede specifically what you do not know, whether how it was counted, what else may have changed, or what part others did, as true for you. Never claim sole credit; never fold on having pushed it through | The Pressure stem on attribution; F3 is the second most predictable objection after F7 |

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C7 | "Product and hardware both want your squads' time. Where does an engineering manager push back?" | CASE | [generic] | Say your decision rule aloud before applying it: what you protect, what you trade, who you talk to first. Name what you do not know about how hardware commitments work here and how you would find out. The question needs no claim about your past | F7 and F6 at the VP's altitude; generic because it presupposes nothing about you |
| C8 | "Where do you think industrial IoT device management is heading, and where would Larkfield fit?" | CO | [generic] | Research could not run, so the pack supplies no facts about Larkfield. Before Monday, read what Larkfield publishes about itself and bring one thing you learned and one question you still have. Say only what you actually read; if you have read nothing, say that plainly and ask the VP what they would want a new manager to understand | A VP round is where company altitude separates candidates; generic and flagged because the research that would ground it was refused |

## Reverse questions (Round 3)

| # | Question to ask | Why it lands |
|---|---|---|
| 1 | "What leadership behavior matters most for engineering managers here, and where do new ones most often fall short?" | Fits a values round and tells you what the VP actually scores |
| 2 | "When hardware deadlines and software quality collide, how does the company usually decide?" | Real diligence on the tension the role sits in |
| 3 | "What do you expect to look different in engineering a year from now?" | Strategy-altitude question with a forward look |
| 4 | "Can you tell me about a tough call where your leadership principles pulled in different directions?" | Invites the VP's own story, which is where a values interviewer is most open |
| 5 | "How do you develop engineering managers, as opposed to engineers?" | Shows ambition past this role without presuming it, and answers whether growth into larger scope is real |

---

## Prohibited claims

Built before the banks; no answer slot, hold, bridge or rationale in this pack asserts, softens or implies any of these.

| Not coached | Basis | Honest form |
|---|---|---|
| Led two squads, or managed eleven engineers | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says a team of six, not two squads. A2 and C5 stay inside the team of six |
| Owned a hardware-adjacent roadmap | Negative you stated, F7 | The plain acknowledgment F7 gives: "I haven't owned a hardware-adjacent roadmap." No slot |
| Has managed managers | Negative you stated, F7 | "I haven't managed managers." No slot, and no question in this pack opens that door |
| The reliability quarter caused the 60% drop, or cut on-call burden single-handedly | Inflated form of F3 | F3's quote at its own scope: the burden dropped after you pushed the quarter through. The limit is the pack's observation: the sentence does not say the quarter caused the drop or that you did it alone. A8, B5 and C6 slots stay inside the sentence |
| Hired about forty engineers, or ran hiring for the organisation | Inflated form of F4 | F4's quote at its own scope: you run the hiring loop for backend roles, and the figure counts interviews. A9 and B6 stay inside it |
| Set or co-owned the product roadmap | Inflated form of F6 | F6's quote at its own scope: a reliability quarter pushed through against roadmap pressure. B2 stays inside the sentence |

## Sources

Provided documents: your message (the role description, the three rounds as scheduled, the recruiter's description of the VP round, and your own statements about your background). No CV, no full JD, no interviewer names, no dossier.

Searches sent and what came back:

- "Larkfield Systems industrial IoT company values": refused
- "Larkfield Systems interview process engineering manager": refused
- "Larkfield Systems industrial IoT device management strategy news": refused

No page was fetched. The three searches were refused by the host's permission gate and were not retried.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Every call was refused. Would have moved: the values cheat sheet (omitted) and the Round 3 VAL themes, which now rest on the recruiter's description |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Every call was refused. Would have moved: loop structure and persona weights; the loop here rests on your own account of the three rounds, which is enough to establish the sessions and who runs each |
| 3. `Larkfield Systems strategy` / recent news | unavailable | Every call was refused. Would have moved: C8 and any CO question grounded in current strategy, which is why C8 is generic |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form; there is no interviewer read |
| 5. Representative engineering manager JD | skipped | The role description you supplied fixes the fit snapshot and the JD-tagged questions, though it is short; a full JD would sharpen them |

## Upgrade menu

- Your CV: the fit snapshot's evidence cells are your message sentences only, so F1 to F7 gain new quotes, F5 may gain evidence, and story-mapped answers replace several selection scaffolds
- The full JD text: F1 to F7 are quoted from a one-line role description; the full text would add requirements, show whether the role has leads reporting to it, and show any eligibility terms
- Larkfield's own values page (paste it, or allow search): adds the Round 3 values cheat sheet and ties C1 to C4 to published value names
- Allowing web search: runs the standard research pass on Larkfield's values, interview process and recent strategy, turns C8 from generic into a grounded question, and lets the strategy rows be checked
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, covering a strategy brief, interviewer talks and writing, role-family loop reports and recent org context
- The four interviewers' names and roles: an interviewer read from public professional footprint, per-member persona weights for the panel, and a reverse question tied to someone's own path
- The recruiter's guidance on the panel and the VP round: whether a case, presentation or take-home is expected, and what the panel will cover; one email would settle it
- Whether you have worked alongside hardware or firmware teams without owning their roadmap: F7 would split into two rows, and the partnership half would get its own answer slot
- A `tuesday-dossier.md` from an earlier opportunity check: verified evidence and flagged risks would arrive pre-graded and could sharpen the strategies on F1, F2 and F7
