Loading is done. I'm now running the L1 research searches for Kelverton Rail: values, interview process, recent strategy, the two interviewers and a comparable JD.
The web searches were refused, so I'm building the pack from your message alone, with company-specific parts labelled `[generic]`. Writing it now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a/runs/sonnet/alone/part-2/rooms/case-5-denied-02a60442/kelverton-rail_senior-partnerships-manager_interview_pack.md`. I built it for the panel you described, from your message alone. All six web searches were refused, I had no job description or CV, and I haven't seen the market report. So the company-specific parts are labelled `[generic]`.

- **POV:** the file has a 15-minute POV build with three theses, each with a concession, plus an anti-pick and a close on what it means for the operators.
- **Highest-ROI prep:** C1, "you've never carried a direct quota". You stated that gap yourself, and Ross is the one flagged to push on commercials.
- **Time plan:** the four hours are split into five ordered blocks that start with the POV and C1. Everything else is insurance.

Say the word and I'll play the Skeptic on C1, the question the pack names as its highest-ROI prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the job description and your CV, or should I stay with the background you gave me? Either would turn several `[generic]` rows into `[grounded]` ones and show whether the role has terms like location or travel that the pack can't see now.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, a 60-minute panel. Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). The first 15 minutes are your POV with no slides, landing on what it means for the operators themselves. The rest is Q&A, and Ross will push on commercials.

**What this pack was built on:** your message only. No job description, no CV, no text of the market report, and no web research (every search was refused). Rows that would have rested on those are `[generic]` and the upgrade menu says what each input would change.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script. Wherever a cell says "answer slot", the words are yours: say what you did, in your own words, or say plainly that it was not yours.

| Tag | Meaning |
|---|---|
| VAL | Whether past behaviour shows the company's published values. None in this pack: no values-style round is established by your material |
| EXP | Whether your claims survive scrutiny and attribution |
| JD | The role's stated demands, including its gaps |
| CO | Company and market knowledge, and the altitude you think at |
| CASE | A live problem, scored on structure and reasoning |

**Highest-ROI prep in this pack: C1**, the "you've never carried a direct quota" challenge. It is the objection your own message makes most likely, and Ross has been flagged as the commercial pusher.

## Prep triage (about four hours)

| Order | Time | Do this | Where |
|---|---|---|---|
| 1 | 60 min | Choose a lead thesis and one concession, write six to eight headings, say the POV aloud twice, aim to finish near 12 minutes | Graded deliverable below, A1 |
| 2 | 60 min | Rehearse C1 aloud through all four follow-up levels, then write your own answers to the answer slots in B1, B2 and D2 | C1, B1, B2, D2 |
| 3 | 45 min | The two stated gaps: C2, C4, D1, with your plain acknowledgment and your ramp plan | C2, C4, D1 |
| 4 | 45 min | Case structure out loud: A2, A3, A5; then reread the market report for one item to agree with and one to diverge from | A2, A3, A5, A4 |
| 5 | 30 min | The 90-second arc (E1) and your reverse questions | E1, reverse questions |

Everything else in the pack is insurance.

## Fit snapshot

The requirements are the recruiter's own words as quoted in your message, your role title, and plain role-family prose marked `[generic]`. No job description was supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Senior Partnerships Manager" — role title, your message | "9 years in partnerships, last 4 at a payments company running the ISV channel" — your message | medium | [grounded] | none | No gap at title level, but a line with nothing inspected behind it, so expect a probe on it. Lead with its own terms: nine years in partnerships, the last four running the ISV channel at a payments company, because a named scope beats an adjective |
| F2 | "where you'd take our operator partnerships over the next 18 months" — recruiter's email, quoted in your message | "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Your material is channel growth at a payments company. It says nothing about operator partnerships or about who set the channel's direction, and the words stay at the quote: "I took the channel from 6 partners to 40." Answer slot: the recruiter's ask for where you would take the partnerships makes a probe on who set the channel's direction likely. If any of that direction was yours to set, say what and how you decided, in your own words; if it was set elsewhere, or there was no such direction, say so plainly and stay with the growth from 6 partners to 40 |
| F3 | "Please land on what it means for the operators themselves." — recruiter's email, quoted in your message | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Your material is bus and light rail network planning. It does not say who the clients were or whether any work was with train operating companies, and the words stay at the quote: "For five years I was in transport consulting, in bus and light rail network planning." The phrase "the operator world from the other side" is yours and unexplained, so expect a follow-up on which operators and which side. Answer slot: if any of that work was with operators directly, say how, in your own words; if it was not, or the relationship was different, say so plainly and stay with the network planning |
| F4 | "Ross will push on commercials." — recruiter's email, quoted in your message | "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message; "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | medium | [grounded] | transferability | Your material is influenced revenue, and your own sentence limits it: "only influenced revenue." The words stay there: "I had roughly £4M of influenced revenue." Answer slot: because commercials are flagged, expect questions on how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. Answer each from what you know; if you do not know how it was counted, say so plainly |
| F5 | Carrying a direct revenue target `[generic]` — role-family requirement, no source supplied | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so yourself. Words: "I've never carried a direct quota; my number was influenced revenue." Then how you would take on a target, said as a plan and never as a past: what you would ask to be measured on, how it would be counted, who would confirm it |
| F6 | Credibility selling to train operating companies `[generic]` — role-family requirement; the company sells to them per your message | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | Another gap you have stated. Words: "I haven't sold into rail specifically." Then how you would learn the buyers, said as a plan: whom you would ask and what you would read first. Nothing added to make the gap feel smaller |

No gate rows: without a job description, the pack cannot tell whether the role has terms such as location, travel, pay or schedule, and it does not guess them.

## Graded deliverable: the 15-minute POV

The facts it builds on:

| Fact | Source | Provenance |
|---|---|---|
| The first 15 minutes are a short POV on where you would take Kelverton's operator partnerships over the next 18 months | Recruiter's email, quoted in your message | [grounded] |
| No slides; talk them through it | Recruiter's email, quoted in your message | [grounded] |
| Land on what it means for the operators themselves | Recruiter's email, quoted in your message | [grounded] |
| Kelverton sells scheduling software to train operating companies | Your message | [grounded] |
| The strategy team's market report was circulated internally last quarter and you have read it | Your message. Its text was not available to this pack | [grounded] |

**Where your background enters.** One sentence, no more, drawn from one row: F2 — "took it from 6 partners to 40, roughly £4M of influenced revenue" — or F3 — "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)". Say it at the scope of the quote.

**Theses.** These are positions to argue, not findings about Kelverton. Check each against the report and drop any the report contradicts.

| Thesis | Mandatory concession | What it means for the operators | Provenance |
|---|---|---|---|
| Depth before breadth: spend the 18 months on a small number of operator partnerships where a shared outcome can be named and measured | It leaves other operators waiting, and Kelverton's results then depend on few relationships. Say both before they are raised | The operators in the set get a named outcome, a named owner at Kelverton and review dates. The others are told plainly when and why not yet | [generic] |
| Operator-defined success: anchor each partnership on a measure the operator itself would report, agreed in writing early | Kelverton does not control the operator's outcomes, so part of the measure sits outside its influence. Say what would count as Kelverton's share | The operators judge the partnership on their terms, not Kelverton's | [generic] |
| Adoption over signature: treat the partnership as the route by which the operator's own teams get value, so the 18-month test is use, not contracts signed | Adoption work costs time with no immediate commercial return. Ross will ask what it is worth, so have a view on how it shows up commercially | Change is done with the operator's teams rather than to them | [generic] |

**Differentiation against the consensus.** The report is one the panel's own strategy team wrote, and a prepared candidate can assemble its shortlist. Do not recite it. Bring one item from it, to show you read it, then one thesis where you diverge, with reasons. I have not seen the report, so which item you agree with and which you diverge from is yours to choose.

**The anti-pick.** The role includes saying no, so say what you would not do: a broad partner programme, portal or event series for every operator in the first 18 months. The reason: it spreads effort before one partnership has shown the model works. The concession: if the report treats breadth as a priority, say so plainly and say what would change your mind.

**Running order for about 12 minutes.**

| Minutes | Beat |
|---|---|
| 0 to 1 | Frame it: you are working from the outside, so these are hypotheses and you will say what would change your mind |
| 1 to 3 | The one item from the report you agree with |
| 3 to 7 | Your lead thesis and the measure you would hold it to |
| 7 to 9 | The anti-pick and the concessions |
| 9 to 12 | What it means for the operators themselves. End here, on what changes for an operator, not on what Kelverton gains |

For the operator close, answer four things: what is different for them by month 6, 12 and 18; what they are asked to commit; what they stop doing; how they would know it worked.

## Persona table

The weights come from three passes. Relationship priors: Deepa is your future manager, so the hiring-manager prior (Case/Strategist and Skeptic); Ross is a Commercial Director sitting on the panel, so the executive prior (Case/Strategist and Pressure). The recruiter's words, "Ross will push on commercials", move the Data-Driven Prober up. The loop is established by the recruiter's email: one session, two panellists, a POV then Q&A. It names no values round.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | The POV itself, then "so what would you do first" follow-ups, mostly from Deepa | High: the POV is the graded opener, and a future manager's prior includes it | Clarify, objective, segmentation, approach, metrics, risks, thinking aloud; challenge one premise respectfully. Bank A |
| Data-Driven Prober | Ross on the headline figures and the commercial model | High: the recruiter flagged commercials, and your message carries a partner count and an influenced-revenue figure (F2, F4) | Know what you can and cannot say about how each figure was counted, and say plainly where you do not know. Bank B |
| Skeptic | Deepa and Ross on the two absences you stated (F5, F6) and on why this move | High: the absences are in your own message, and the hiring-manager prior includes it | Rehearse the single most predictable objection until it is boring; calibrated candour over bluffing. Bank C |
| Pressure | Ross, time-boxed challenges on "why you" and "how much was you" | Medium: the executive prior includes it, but "push on commercials" reads as probing more than as a stress style | Pause, restate, anchor in what you stated, hold through two follow-ups before conceding anything real. Bank D |
| Conversational | The opening biography question | Lower: 15 minutes of POV leave little room for chat, but an opener is likely and is still scored | A 90-second arc built from your own sentences. Bank E |

Values/Behavioral is not weighted: no values-style round is established. Peer is not weighted: neither panellist is a peer.

## Question banks

### A. Case/Strategist (weight: top, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Where would you take our operator partnerships over the next 18 months, and what does that mean for the operators themselves?" | CASE | [grounded] | This is the POV, so build it from the graded-deliverable section, not from this cell. In Q&A it returns short: the thesis in two sentences, the concession in one, the operator close in two. The question needs no claim about your past, so the guidance makes none | The recruiter's email makes this the graded opener. CASE because it is a live problem on the real roadmap with the requested operator close |
| A2 | "Before committing to a roadmap for operator partnerships, what would you need to know first?" | CASE | [generic] | Clarify first, then objective, segmentation, approach, metrics, risks. Offer three or four questions you would ask in the first 30 days, such as what each operator is trying to fix, how decisions get made, what Kelverton has already committed, and how success is measured. Say aloud that you are working from outside. The question needs no claim about your past, so the guidance makes none | The clarify-before-structure habit is what a case scores. Generic because research was refused and no strategy brief was in hand |
| A3 | "An operator partner tells you our product isn't their priority this year. What do you do in your first 30 days with them?" | CASE | [generic] | Structure it: find out what their priority is and whether there is a link; decide whether to deepen, hold or step back; agree one next step with a named owner on each side; say what you would record. The question needs no claim about your past, so the guidance makes none | A live relationship problem of the kind the role will meet, asked as a decision. Generic because it is a pattern, not a fact about Kelverton |
| A4 | "Where do you think our operator partnerships are weakest today?" | CO | [generic] | You lack the inside view, so say so, then give one hypothesis drawn from the report and the one thing that would change your mind. Bring one report item the panel will recognise, then one place you would diverge. Do not recite the report. The question needs no claim about your past, so the guidance makes none | Tests whether you can think at the company's altitude. Generic because the report's text was not available to this pack and web research was refused |
| A5 | "Which operators or segments would you deliberately not prioritise in the next 18 months?" | CASE | [generic] | Give the criterion before any names: what would make an operator wait. Then the concession: the cost of leaving them waiting and what would change your mind. Do not name segments from memory as facts. The question needs no claim about your past, so the guidance makes none | The anti-pick is where judgment shows against the consensus answer. CASE because it asks for a decision with reasons |

### B. Data-Driven Prober (weight: 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've said roughly £4M of influenced revenue. Walk me through how that figure was counted." | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Say what the quote says, "roughly £4M of influenced revenue", then the four things a figure raises, each in your own words: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. Answer slot: if you know how it was counted, say how; if you do not, say so plainly. Never describe an attribution method you did not use | F2 and F4 carry the headline figure, and Ross has been flagged as pushing on commercials. EXP because it tests the claim, not the role |
| B2 | "You took the channel from 6 partners to 40. Which part of that was you?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue"; "9 years in partnerships, last 4 at a payments company running the ISV channel" | Beats the quotes state: the last four years running the ISV channel at a payments company, and the channel going from 6 partners to 40. Answer slot: say what you did and what others did, in your own words; if you cannot separate the two, say so plainly and stay with running the channel | F2 is the second headline number, and F1 is the role it sits in. EXP because the probe is attribution |
| B3 | "How would you structure the commercials of an operator partnership: who gets what, and how would you know it is working?" | CASE | [generic] | Ask what the partnership is meant to deliver; separate what the operator gains from what Kelverton gains; propose two or three measures, leading and lagging, to agree up front. Say what you would need to learn about Kelverton's contract terms first. Claim no knowledge of their model. The question needs no claim about your past, so the guidance makes none | Ross's commercial push is the recruiter's own warning (F4). CASE because it is a live problem rather than a probe of your history |
| B4 | "What would you want to be measured on in this role?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Name the measures you would propose and why, and the order in which you would agree them. Then the plain line the quote carries: "I've never carried a direct quota." Then the plan: agree the measure, how it is counted and who confirms it, in the first 30 days. Which measures you would propose is yours to choose; the pack does not choose them | Sits directly on F5, the stated gap, from the side Ross is likely to push. JD because it concerns the role's commercial expectations as the recruiter flagged them |

### C. Skeptic (weight: 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've never carried a direct quota. Why should we trust you with commercial responsibility in this role?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue."; "took it from 6 partners to 40, roughly £4M of influenced revenue" | **Highest-ROI prep.** Name the limit before it is asked for: "I've never carried a direct quota; my number was influenced revenue." Hold only what the quotes carry: the channel went from 6 partners to 40, with roughly £4M of influenced revenue. Concede exactly this: a direct quota is a different accountability from influence, and you have not carried one. Do not concede that the channel work does not count. Follow-up 1, "So you've never been accountable for a number?": answer slot: if you were accountable for any number short of a quota, say which and to whom; if not, say so plainly and return to the influenced revenue. Follow-up 2, "Which part of that revenue was down to what you did?": answer slot: say what you did and what others did; if you cannot separate them, say so. Follow-up 3, "What would you do in your first 90 days to close the gap?": a plan, not a past: agree what you are measured on, how it is counted, who confirms it. Hold through two follow-ups by returning to the quotes, never by adding to them | F5 is your largest stated gap and F4 is where it meets the commercial push. JD because it scores a stated demand of the role; the deepest rehearsal because it will arrive in some form |
| C2 | "You've never sold into rail. Where will that cost you on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue."; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Plain acknowledgment first: "I haven't sold into rail specifically." Then the adjacent work at its own scope: five years in transport consulting, in bus and light rail network planning. Then a ramp plan, said as a plan: whom you would ask and what you would read first. Answer slot: your phrase "the operator world from the other side" invites a follow-up on which operators and which side; if any were train operators, say so; if not, say so plainly and stay with the bus and light rail planning | F6 is the stated gap and F3 the adjacent evidence. JD because it scores a demand of the role |
| C3 | "Why this move, and why now?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Tell the path in the quotes' own terms: transport consulting in bus and light rail network planning, partnerships, the ISV channel at a payments company. Answer slot: the reason for moving toward rail-tech, and for moving now, is yours; give your actual reason in your own words. If there is no single reason, say so plainly | Motivation consistency is what a Skeptic checks after the gaps. EXP because the path is the evidence; F1 and F3 hold the pieces |
| C4 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Choose one of the two limits you have stated, in your own words: "I haven't carried a direct quota" or "I haven't sold into rail specifically", whichever worries the panel more. Follow with a ramp plan, said as a plan: what you would learn first, whom you would ask, by when. Do not pick a weakness you do not have in order to look modest | The stock Skeptic stem, aimed at F5 and F6. JD because it tests honest self-assessment against the role |

### D. Pressure (weight: 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you, rather than someone who has already sold to train operators?" | JD | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"; "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Pause, restate the question, then three beats from the quotes: nine years in partnerships, the last four running the ISV channel, five years in transport consulting in bus and light rail network planning. Hold those through two follow-ups by returning to them, never adding. Concede specifically: "I haven't sold into rail specifically." Do not fold on the beats to restore harmony | F1, F3 and F6 together. JD because it tests the stated fit; Pressure because of the clock |
| D2 | "That £4M. How much of it was actually you?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Anchor on the word the quote uses, "influenced", and do not upgrade it. Answer slot: say which part was yours, in your own words; if you cannot say, say so plainly. Hold the figure at its scope through two follow-ups and concede only what you genuinely do not know about how it was counted | F2 and F4. EXP because attribution is the probe; Pressure because it is asked fast |
| D3 | "Your POV sounds like it could be about any operator. What makes it Kelverton's?" | CASE | [generic] | Hold your thesis through two follow-ups. Concede specifically that you are working from the report and from outside, not from inside data. Name the one thing you would check first and what would change your view. The question needs no claim about your past, so the guidance makes none | The natural challenge to an outside-in POV, and the place a generic POV breaks. CASE because it tests reasoning under pushback |

### E. Conversational (weight: 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"; "took it from 6 partners to 40, roughly £4M of influenced revenue" | A 90-second arc with only the beats the quotes state: transport consulting in bus and light rail network planning; partnerships; the last four years running the ISV channel, from 6 partners to 40. Answer slot: the closing sentence on why this role is next is yours to give, in your own words | The biography question is scored even when it sounds casual. F1, F2 and F3 supply every beat |
| E2 | "What have you read or noticed lately about how operators work with software suppliers?" | CO | [generic] | Say only what you have actually read or noticed. Answer slot: name your actual source; if it is mainly the report you were sent, say so plainly. If you have read little beyond it, say that, then say what you would read first | A casual question about the role's hot topic, still scored for genuine interest. Generic because it needs no claim about your past |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1: Senior Partnerships Manager | E1, C3, D1 |
| F2: where you would take the operator partnerships over 18 months | A1, A2, A3, A4, A5, D3 |
| F3: land on what it means for the operators themselves | A1, C2, E2 |
| F4: Ross will push on commercials | B1, B2, B3, B4, D2 |
| F5: carrying a direct revenue target | C1, B4, C4 |
| F6: credibility selling to train operating companies | C2, C4, D1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would you want to be true for the operators 18 months from now that is not true today?" | Puts the requested operator lens back to Deepa and shows you are pointing at their outcome, not your own |
| R2 | "Where does Partnerships' ownership of an operator relationship end and the commercial team's begin?" | Opens the seam between the two panellists in front of both, and shows you are thinking about the commercial side |
| R3 | "How is success in this role measured in the first year, and who agrees the measure?" | Turns the commercial concern into a shared definition you can be held to, which the quota gap makes valuable |
| R4 | "What has changed since the strategy team's report was circulated last quarter?" | Shows you read it, and lets you hear what has moved since without reciting it |
| R5 | "Which operator relationship would you call healthy, and which one worries you? What tells them apart?" | Gets the panel to describe the real success and failure signs, which sharpens your first 90 days |
| R6 | "Based on today, what would make you hesitate about me?" | Brings the objection into the room while you can still answer it, and shows the candour C1 has rehearsed |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Carried a quota or owned revenue | Negative you stated, F5 | The plain acknowledgment: "I've never carried a direct quota; my number was influenced revenue." Quote: "Never sold into rail specifically and never carried a direct quota, only influenced revenue." No slot |
| Sold into rail | Negative you stated, F6 | The plain acknowledgment: "I haven't sold into rail specifically." Then the ramp plan, said as a plan |
| Generated, closed or drove £4M | Inflated form of F2 and F4 | The quote at its own scope: "roughly £4M of influenced revenue". The limit is the pack's observation: your material says influenced, not closed or generated |
| Knows train operating companies from the inside | Inflated form of F3 | The quote at its own scope: five years in transport consulting, in bus and light rail network planning. The limit is the pack's observation: your material says bus and light rail, not train operating companies |
| Built the channel from scratch | Claim your own quote contradicts, F2 | The quote only: "took it from 6 partners to 40". Nothing more is added to it |

## Sources

Provided documents: your message, including the recruiter's email as quoted in it. The market report is named in your message but its text was not available to this pack and it was not read. No dossier was present, so nothing was consumed from one.

Research tier: L1 — searches 6 of 6, fetches 0 of 2

Searches sent, all refused, so nothing came back:

- "Kelverton Rail company values" — refused
- "Kelverton Rail interview process partnerships manager" — refused
- "Kelverton Rail scheduling software train operating companies strategy news" — refused
- "Deepa VP Partnerships Kelverton Rail" — refused
- "Ross Commercial Director Kelverton Rail" — refused
- "Senior Partnerships Manager rail technology job description train operators" — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Search refused. Would have supplied the company's published values for a values cheat sheet and VAL questions. Neither is in this pack |
| 2. Kelverton Rail interview process, partnerships | unavailable | Search refused. Would have documented the loop. Persona weights rest on the recruiter's email and relationship priors instead |
| 3. Kelverton Rail strategy and recent news | unavailable | Search refused. Would have grounded A4 and E2 in current priorities. Both are `[generic]` |
| 4. Interviewers: Deepa and Ross at Kelverton Rail | unavailable | Both searches refused. Would have fed an interviewer read and a reverse question tied to a path. Neither is in this pack |
| 5. Representative Senior Partnerships Manager JD | unavailable | Search refused. Would have supplied inferred requirement rows and any gate terms. The snapshot uses the recruiter's words and `[generic]` prose instead |

## Upgrade menu

- The job description → F1, F5 and F6 requirements become quoted and `[grounded]`; any gate terms (location, travel, right to work, pay, schedule) can be checked and shown as rows; the coverage table keys to the posting's own list
- Your CV → evidence cells can quote CV lines, and the F2 and F4 figures can be tied to a named source
- An inspectable artifact behind the £4M, if you can share one without breaching confidentiality, such as a partner-influenced revenue report or the partner programme deck → F2 and F4 can move from medium toward high, and B1 and D2 get sharper
- The market report's headline findings or section headings → a grounding brief section, a named consensus item for the POV, and A4 and A5 become `[grounded]`
- Working web search → Kelverton's published values, interview process, strategy and the two interviewers' public footprints, feeding the CO bank, persona weights and a reverse question tied to an interviewer's path
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → strategy brief, interviewer talks and writing, loop reports, recent organisational context
- The recruiter's answer on what "commercials" means to Ross (pricing, contract terms, targets or something else), usually one email → reweights Bank B
- A tuesday-dossier.md from an earlier evaluation of this role → confirmed evidence and a recorded list of claims to avoid; this pack was built without one
