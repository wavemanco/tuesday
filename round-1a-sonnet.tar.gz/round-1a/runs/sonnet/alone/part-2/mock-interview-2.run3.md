I'll read the reference files the skill points to before building the pack.
The prep pack is saved as `/var/tmp/tuesday-measure/1a/runs/sonnet/alone/part-2/rooms/case-2-denied-52d02435/atlas-freight_operations-manager_interview_pack.md`. It has a fit snapshot against the JD, 22 questions in seven interviewer styles, a requirement-coverage table, six reverse questions and a list of claims it won't coach.

- **Assumption:** you didn't say who is interviewing you, so I built it for a hiring-manager round. That puts the heaviest prep on a skeptic probing scale and on live case problems.
- **Highest-ROI prep (A1):** your material says you're over 3 supervisors at one site, and the JD wants 12 across 4 sites. Expect "what makes you ready for that jump?" in some form. The pack coaches you to state what you did, concede the scale difference plainly, and offer a ramp plan.
- **Other likely probes:**
  - How the 40% mis-pick figure was counted and which part was yours.
  - How many of your 7 years were spent leading, against the JD's "5+ years operations leadership".
  - Your Power BI gap, which the pack answers with the plain "I've never used Power BI" and a learning plan, never a claim.
- **No Atlas research:** web search wasn't permitted, so nothing here comes from the web. There are no values, loop or strategy sections, and the "why Atlas" answer is left to you. Read their website and careers page before the interview.
- **Answer slots:** where your material is silent, such as multi-site work, on-time or cost tracking, or Excel reports you built, the guidance gives you a slot to fill truthfully. It never fills it for you.

Say the word and I'll play the Skeptic on A1 as a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, and convert the pack to Word if you'd like.

Who is interviewing you: your future manager, a peer, or a skip-level? Did the recruiter mention focus areas or an assignment? Either answer reweights the banks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

Role: Operations Manager, Atlas Freight (regional logistics, 800 employees). Interviewer: unknown. Round and relationship: not stated, so this pack is built for a hiring-manager round and says where that assumption moves things.

## How to use this pack

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether your background claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge (none in this pack, see Sources) |
| CASE | A live problem from the actual role |

Labels: `[grounded]` traces to your message or the JD you pasted; `[inferred]` is this pack's derivation; `[generic]` is a role-family pattern with no claim about you or Atlas. The JD names no eligibility, credential, location or schedule term, so the snapshot has no gate rows. The highest-ROI prep is A1, the jump from three supervisors to twelve across four sites.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "ran the site's peak-season surge plan two years running" — your message, "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material says one site's surge plan and three supervisors, in warehouse and distribution ops, not four sites. The words stay at that scope: "I ran the site's peak-season surge plan two years running." Answer slot: the JD's four-site line makes a probe on work beyond your own site likely. If any of your work reached other sites, say which and what part was yours, in your own words; if none did, say so plainly and stay with the site you work at |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | The quote is a mis-pick rate, not on-time performance or cost per shipment, and the words stay there: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: the JD's two measures make a probe on them likely. If either was tracked where you work, say how it was measured and what part was yours; if neither was, or it was not yours, say so plainly and stay with the mis-pick figure |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | The sentence at its own scope is "I'm a senior shift manager over three supervisors." The JD's twelve is four times the number in that sentence, and your material shows nothing between the two. Answer slot: if you have been over more than three supervisors at any point, say how many and when; if you have not, say so plainly and stay with the three |
| F4 | "build reporting in Excel/Power BI" — JD (the Excel half) | "solid Excel" — your message | low | [inferred] | discovery | The quote says Excel skill, not which reports were built, and the material does not show it. Answer slot: the JD's reporting line makes a probe on what you have built likely. If you built reports, say what they tracked and who read them, in your own words; if you did not, say so plainly and stay with "solid Excel" as you said it |
| F5 | "build reporting in Excel/Power BI" — JD (the Power BI half) | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used Power BI." Then how you would learn it, said as a plan and never as a past. The JD writes the two tools with a slash, and whether either one satisfies it is not clear from the JD alone |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message, "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | A length-of-experience line, graded like any other row and not a gate. The first quote says seven years of operations; your material does not show how many of them were leading. Answer slot: if five or more of the years were spent leading, give the figure from your own record; if fewer, say so plainly and return to the seven years and the role you hold now |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap on the words: "I'm green belt certified." Nothing inspected sits behind it, so expect a probe on who awarded it; the certificate is the artifact that would raise this row |

## Persona table

The relationship is assumed to be a hiring manager (prior: Case/Strategist and Skeptic). No loop source was read, so the loop archetype is Generic and adds no tilt; weights rest on the relationship prior alone.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet probing of scale: three supervisors against twelve, one site against four | High: a hiring manager is buying capability and de-risking gaps, and F1, F3 and F6 are where the material is thinnest | Rehearse A1 until it is boring: hold the quote, concede scale, give a ramp plan |
| B. Case/Strategist | Live problems from the role: a site slipping, cost rising, a surge across sites | High: the relationship prior puts live problems on a hiring manager's own roadmap | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise |
| C. Data-Driven Prober | Line-by-line on the 40% figure | Medium: the figure is a headline number, and probers go two levels deep | Know how it was counted and say plainly where you do not (C1) |
| D. Conversational | Friendly walk-through of the journey | Medium: openers are near-certain in any round, and are still scored | A 90-second arc built from your own sentences (D1) |
| E. Pressure | Time-boxed, interrupting, "how much was you" | Low to medium: more likely if a skip-level joins; unknown here | Pause, restate, hold two follow-ups, then concede specifically (E1, E2) |
| F. Peer Evaluator | Seams between sites and teams, credit-sharing | Low: it matters only if a site peer is in the loop, which nothing here says | Offer principles for the seam, not a claim to know it (F1, F2) |
| G. Values/Behavioral | Scenario probes on judgment under pressure | Low: no loop source documents a values round and no published values were read | Selection scaffolds with an honest branch (G1, G2) |

## Question banks

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You're a senior shift manager over three supervisors today, and this role has twelve across four sites. What makes you ready for that jump?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI rehearsal in this pack. Hold only what the quote carries: "I'm a senior shift manager over three supervisors." Concede in your own words that the role is larger than that sentence covers, before the interviewer says so. Answer slot: if any of your work has reached supervisors or sites beyond your own three, say what and which part was yours; if none has, say so plainly and stay with the three. Then a ramp plan, said as a plan and never as a past: what you would learn about each site and supervisor before changing anything. Hold through two follow-ups, such as how you would split your time across four sites, by returning to the sentence, never by adding to it | F3 and F1 are the widest distance between your material and the role, so this objection arrives in some form. JD because it scores a stated requirement; Skeptic because it is aimed at the gap |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never used Power BI" | Pick the gap you actually judge widest, say it plainly, then give a ramp plan. Do not choose a small one to look candid. The pack's observation is that the widest distance is scale (F1 and F3) and the narrowest one you stated is Power BI (F5), in your words "never used Power BI". If no single gap stands out, say so plainly, then name the nearest thing your material does carry | The stem is a standard Skeptic probe and every row with a gap is a candidate answer. JD because the answer is scored against the posting |
| A3 | "The JD asks for five or more years of operations leadership. How many of your seven years were spent leading?" | JD | [grounded] "7 years in warehouse and distribution ops" | Answer slot: give the figure from your own record, in your own words; if it is fewer than five, say so plainly and return to the seven years and the role you hold now. Never round up | F6 is the row where the material is silent on duration, so the interviewer's arithmetic is the likeliest follow-up. JD because the requirement is stated in the posting |
| A4 | "Why leave a senior shift manager role for this one, and why Atlas?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Give your own reasons for leaving and for this move, in your own words; the pack supplies none. For the Atlas half, read Atlas's own website and careers page before the interview, because this pack could not research them. If no clear reason comes to mind, say so plainly and name the nearest true thing | The Skeptic's motivation probe: why leave, why here, why now. JD because it tests fit to this posting, though EXP-style consistency is also scored |
| A5 | "The role builds reporting in Excel and Power BI, and you've said you've never used Power BI. How will you get to speed?" | JD | [grounded] "solid Excel" "never used Power BI" | Plain acknowledgment: "I've never used Power BI." Then "My Excel is solid", at that scope. Answer slot: if you built reports in Excel, say what they tracked; if not, say so plainly. The plan is future tense: what you would learn first and how you would check it. If you spend the days before the interview learning the basics, say so only once that is true | F5 is a gap you stated, so the interviewer will use your own words. JD because it scores the reporting requirement |

### B. Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one of the four sites has dropped noticeably over a month. Diagnose it." | CASE | [generic] | Clarify first: how on-time is defined and measured, which site, what changed, over what window. Then split the drop by where it arises, name the first two checks and what each would rule out, say what you would watch, and name the risk of fixing a symptom. Think aloud and challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | The JD's on-time line, asked as a decision. Generic because it is a pattern for the problem, not a fact about Atlas |
| B2 | "Cost per shipment is rising. Where do you look first?" | CASE | [generic] | Clarify what the measure includes and whether the movement is in the cost or the mix. Split it into components, find where the change sits, and state the trade-off with on-time performance before proposing a fix. Close with the metric you would watch and one risk | The JD's cost line as a live problem. CASE because the structure is what is scored |
| B3 | "Sketch a peak-week plan across four sites. What do you need to know first?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Your own surge plan is usable only at the sentence's scope: the plan, the site, two years running, told in your own words with nothing added. The case itself: clarify the demand picture and constraints at each site, decide what is set once for all four and what each site decides, name trigger points and escalation, and name the metrics and risks | F1 and F3 are about scale, and this is the scale problem asked live. CASE because it scores clarify-then-structure |
| B4 | "You have twelve supervisors across four sites and one site lags the others. How do you tell whether it is the site, the supervisor or the process?" | CASE | [generic] | Clarify what lags and since when. Compare like with like before comparing people, look at process before person, say what evidence would separate the three, and say how you would raise it with the supervisor as a plan. No claim about your past is made | The JD's twelve supervisors across four sites as a diagnostic. CASE because the reasoning matters more than the answer |
| B5 | "What would you put on the daily and weekly reporting page for a four-site manager?" | JD | [grounded] "solid Excel" "never used Power BI" | Start from the decisions the page supports, then the measures the JD names, on-time performance and cost per shipment, then cadence and who reads it. Say the tool plainly: Excel is your stated strength, and you have never used Power BI. If you have built reports before, say what they tracked; if not, say so plainly | The reporting line of the JD as a design problem. JD primary, CASE delivery |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold the sentence: "I cut mis-pick rate 40% by redesigning the pick path." Answer slots, each in your own words: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. Never explain a method you cannot repeat under a second question | F2 holds your only quantified result, and a prober starts there. EXP because it tests what was actually yours |
| C2 | "Mis-pick rate is a quality measure. How would you connect it to on-time performance and cost per shipment?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer as reasoning, not as history: walk the chain from a pick error to a shipment in your own words. Answer slot: if you tracked either measure, say how it was measured; if neither, say so plainly and return to the mis-pick figure | F2's gap is the distance between this quote and the JD's two measures. JD because it scores the requirement |
| C3 | "How would you define on-time performance, and measure it the same way at four sites?" | JD | [generic] | Ask what promise on-time is measured against and at which handoff, then say why one definition across sites matters before any comparison. No claim about your past is made | The JD's lead measure, and a definition question is how a prober finds whether you know what you would own |

### D. Conversational/Rapport (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey from warehouse to here." | EXP | [grounded] "7 years in warehouse and distribution ops" "currently a senior shift manager over 3 supervisors" | A 90-second arc with three beats the sentences state: seven years in warehouse and distribution ops, now a senior shift manager over three supervisors, and why this role in your own words. Roles and years in between are yours to supply; the pack supplies none | Nearly every loop opens here and a casual register is still scored. EXP because it checks the story against the CV |
| D2 | "Lean and Six Sigma are listed as a plus. Where do you stand on them?" | JD | [grounded] "green belt certified" | Say it at its scope: "I'm green belt certified." Answer slot: say who awarded it and when, in your own words; if you have applied it at work, say where; if you have not, say so plainly | F7 is the cleanest row, and a casual question on a plus-skill is still scored. JD because it scores the stated plus |
| D3 | "Tell me about a time you had to change how a supervisor worked." | EXP | [generic] | Selection scaffold, theme from the JD's supervisor-team line: pick an occasion with a named change, your own part, and a result you can state. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F3 asks about leading a team, and a team lead is asked for an occasion. EXP because it tests what was yours |

### E. Pressure/Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who already runs several sites?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" "ran the site's peak-season surge plan two years running" "green belt certified" | Pause and restate the question. Hold what the sentences carry, in your own words and without claiming to be better. Concede specifically that someone else may have run more sites. Close with the ramp plan from A1, as a plan | F1 and F3 make the comparison with a multi-site candidate unavoidable. JD because it scores fit, Pressure because it is time-boxed |
| E2 | "That 40%. How much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: say exactly which part was yours; if others contributed, say who and how; if you cannot separate it, say so plainly. Hold through two follow-ups by returning to the sentence, then concede only what is true | The standard Pressure stem on your one headline number. EXP because it probes attribution |

### F. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Our sites sit side by side. Where is the seam between us, and what happens when we disagree?" | JD | [generic] | Offer principles for the seam rather than claiming to know it: which decisions belong to a site and which to the network, and how you would raise a disagreement. Add what you would bring to the peer's site, not only what you would need | A peer prices what the hire costs their own work. Generic because it makes no claim about your past |
| F2 | "How do you handle credit when an improvement spans teams?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: if others contributed to the redesign, say who and what; if it was yours alone, say so plainly. Then your principle for credit, in your own words | The standard peer stem, and the mis-pick figure is the improvement it is most likely to land on. EXP because it tests attribution |

### G. Values/Behavioral (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick an occasion with a named stake, a moment you did not soften the message, and an intact working relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard values stem. Generic because no published Atlas values were read |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick an occasion where the two conflicted, the choice was yours, and you can state what it cost. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A freight business is judged on the customer's shipment, so the stem is plausible; the pack has no source for how Atlas frames it |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| "Own daily terminal operations across 4 sites" | A1, B1, B3, B4, F1 |
| "drive on-time performance and cost-per-shipment down" | B1, B2, C2, C3 |
| "lead a team of 12 supervisors" | A1, B4, D3 |
| "build reporting in Excel/Power BI" | A5, B5 |
| "5+ years operations leadership required" | A3, D1 |
| "Lean/Six Sigma a plus" | D2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How is on-time performance defined here, and does every site measure it the same way?" | It shows you want the definition before claiming to move the number |
| R2 | "What does reporting look like today: what lives in Excel, what in Power BI, and who maintains it?" | It raises the Power BI gap on your terms and reveals whether the JD's slash means either tool |
| R3 | "What would a strong first ninety days look like: which site, which measure?" | It answers the scale objection by asking where to start |
| R4 | "How does a practice that works at one site get decided on for the other three?" | It shows network thinking, the altitude the role is pitched at |
| R5 | "Is there a continuous-improvement structure here, or would I be helping build one?" | It gives your green belt a place to matter without claiming past work |
| R6 | "What do you most want to be different in this team in a year?" | It invites the manager's own priority and the answer shapes your follow-up |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned terminal operations across four sites | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation: your material says one site's surge plan and three supervisors, not four sites. A slot stays with the site |
| Led a team of twelve supervisors | Inflated form of F3 | F3's quote at its own scope: "currently a senior shift manager over 3 supervisors". The slot asks only whether you have been over more than three |
| Brought down on-time performance or cost per shipment | Inflated form of F2 | F2's quote at its own scope: a mis-pick rate. The slot asks only whether either measure was tracked |
| Built Excel or Power BI reports | Inflated form of F4 | F4's quote at its own scope: "solid Excel". The slot asks only what, if anything, you built |
| Has used Power BI | Negative you stated, F5 | The plain acknowledgment F5 gives: "I've never used Power BI." No slot |
| Has five or more years of operations leadership | Inflated form of F6 | F6's quote at its own scope: "7 years in warehouse and distribution ops". The limit is the pack's observation: your material does not say how many were leading |
| Applied Lean or Six Sigma to the pick-path redesign | Inflated form of F2 and F7 | Each quote at its own scope, separately. The limit is the pack's observation: your material does not connect them |

## Sources

Provided documents: the JD text as pasted in your message; your background as stated in your message. No dossier was present. No interviewer information, assessment or recruiter guidance was provided.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

Queries sent, all refused (permission to search was not granted), so nothing from the web is used anywhere in this pack:

- `Atlas Freight regional logistics company values` — refused
- `Atlas Freight interview process operations manager` — refused
- `Atlas Freight regional logistics terminals news strategy` — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Would have fed a values cheat sheet and mapped VAL questions to published value names; both are absent and G1 and G2 are generic |
| 2. `{company} interview process {role family}` | unavailable | Would have fixed the loop and persona weights; weights rest on the assumed hiring-manager prior and a Generic archetype |
| 3. `{company} strategy` / recent news | unavailable | Would have fed CO questions and a why-Atlas answer; the pack has no CO question |
| 4. `{interviewer name} {company}` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `{role title}` JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The interviewer's name and title, and whether they are your future manager, a peer or a skip-level → persona weights reset, an interviewer read, and a reverse question tied to their path
- The recruiter's guidance (focus areas, any assignment, the round format) → coverage matched to what is announced, and a build section for any pre-declared deliverable
- Search access, or Atlas's values page and careers page pasted in → a values cheat sheet, loop-based persona weights, a CO question and a researched why-Atlas answer; a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) is on offer once search is permitted
- Your CV text, or answers to the answer slots (F1, F2, F3, F4 and F6) → the rows that rest on one sentence become quoted lines with fuller evidence, and guidance regenerates from them
- The green belt certificate (issuer and date) → F7 moves toward high; records of how the mis-pick figure was counted (before and after) → F2 and C1 become grounded in an inspectable artifact
- A `tuesday-dossier.md` from an earlier evaluation of this role → verified evidence replaces this pack's single-sentence quotes, and the objection to rehearse deepest comes from evidence rather than inference
