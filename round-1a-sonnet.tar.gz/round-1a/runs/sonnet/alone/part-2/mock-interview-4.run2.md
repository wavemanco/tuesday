I'll read the references this skill requires before writing anything.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a/runs/sonnet/alone/part-2/rooms/case-4-denied-12a2976f/quartzline_product-manager-platform-apis_interview_pack.md`. I built it for a 45-minute hiring-manager conversation, from the dossier alone.

The three company searches (values, interview process, strategy) were refused, so the pack has no company research. The one company question, D2, is labeled `[generic]` and you'd answer it from your own reading of Quartzline.

- **Most important prep:** A1 is the objection the dossier names: no PM title, no roadmap ownership, so why hire you over a PM with three years. The structure is to concede in the dossier's sourced words, hold on your quoted integration work and playbook, say it's adjacent, then give a ramp plan. F1 is a 60-second version for an interviewer who interrupts.
- **No bridge on roadmap and prioritization:** the dossier marks this as a gap to acknowledge, so A2 and F2 coach a plain acknowledgment and a ramp plan.
- **Medium-confidence claim:** the roadmap-input sessions are medium confidence, so A4 has you volunteer the limit before it's probed.
- **Answer slots:** A3, A4, C1, D3 and E3 are slots only you can fill from memory, for example whether anything you were part of reached release, or whether you worked from API docs or schemas.

I can play the Skeptic on A1 now, with follow-ups, then give feedback against that question's guidance.
I can also save an updated `tuesday-dossier.md` with what this prep exposed (`pack_feedback`), for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

- **Round:** one 45-minute conversation with the hiring manager, Thursday. The hiring manager is not named, so there is no interviewer read.
- **Built on:** your `tuesday-dossier.md` (version 1.1). Its `role_profile` stands as the job description and its `verified_candidate_evidence` as your background. Company research was refused in this session, so company rows are labeled `[generic]` rather than filled in (see Sources).

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values (none asked for in this pack, see Sources) |
| EXP | Whether your own claims survive scrutiny and attribution |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company and its strategy |
| CASE | Structure and reasoning on a live problem from the role |

Guidance is scaffolding, not a script. Every block of proposed wording below is pending your approval: say it only if it is true in your own words. An answer slot is an instruction for the interview, not a question for me. If you answer a slot to me outside a drill, I will treat it as new material and regenerate the rows that draw on it.

## Prep triage

Two days out. Do these in order; everything else is insurance.

1. Say A1 aloud three times, then F1, which is its sixty-second form. This is the highest-ROI prep in the pack.
2. Decide your own answers to the slots in A3, A4 and C1, from memory, before Thursday.
3. Talk B2 and B3 through aloud once each, structure only.
4. Pick two reverse questions (reverse 1 and 2 are the ones the dossier flags) and know why you are asking them.
5. Thursday morning: say A1 once more. Everything else is insurance.

## The fit snapshot

Proposed language, pending your approval. Requirements are quoted from the dossier's `role_profile`; evidence is quoted from the dossier's `verified_candidate_evidence`, which are the three confirmed claims.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence, item 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence, item 3 | low | [grounded] | transferability | The underwriter's frame is a bridge that is adjacent, never PM experience. The words stay at the quotes' scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs: scoping, requirements, architecture, UAT, go-live." Your material shows no product manager title or time in the role, and the dossier lists "Having held a product manager title or role" under `prohibited_claims`, so the plain acknowledgment is sourced there: "I haven't held a product manager title or role." The bridge never claims that time as PM experience |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibilities | none given | none | [grounded] | capability | The dossier's `uncertain_or_weak_areas` marks owning a roadmap and prioritization authority as `acknowledge_gap`, and lists "Having owned a product roadmap" and "Having set prioritization for an engineering squad" under `prohibited_claims`. Words: "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then a ramp, said as a plan and never as a past: "In my first weeks I'd want to learn how the two squads prioritize today and which roadmap decisions this role makes alone." No bridge and no slot here |
| F3 | "Shipped API or platform products" — dossier role_profile R2, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence, item 1; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence, item 2 | low | [inferred] | transferability | Integrating a vendor's APIs for clients is adjacent to shipping an API product, and your material does not show the second. Words stay at the quotes: the integrations you led and the playbook you wrote. Answer slot: R2's wording makes a probe on what you shipped likely. If any product or platform capability you were part of reached release, say what it was and what part was yours, in your own words; if none did, or none was yours, say so plainly and stay with the integrations you led |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence, item 1 | low | [inferred] | discovery | The quote names REST APIs and architecture and does not show whether you worked from API docs or schemas. Answer slot: R3's wording makes a probe likely. If you worked from API docs or schemas in those integrations, say how and which part was yours; if not, say so plainly and stay with the REST APIs and the architecture step you named |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence, item 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence, item 3 | medium | [grounded] | transferability | Item 3 is confirmed with limited inspectable proof, so expect a probe and volunteer its limit first. The quotes show clients and product; your material does not name engineering or sales as groups you worked with. Words: "I ran quarterly roadmap-input sessions feeding client evidence to product." Answer slot: R4 names engineering and sales. If you worked with either in those integrations, say how and what part was yours; if not, say so plainly and stay with the clients and product |
| F6 | "Agile delivery experience" — dossier role_profile R5, preferred | none given | low | [grounded] | discovery | The dossier's strategy for this area is `clarify`, and no confirmed entry speaks to it. Answer slot: R5's wording makes a probe on how you have worked with delivery teams likely. If you worked that way, say how and which part was yours; if you never worked that way, say so plainly and say what you would want to confirm about how the two squads here define it |

Unresolved from the dossier, not requirements: decision authority versus the two squad leads, and how adoption is measured today. Both go to the reverse questions.

## Persona table

Loop: your own words (one 45-minute conversation with the hiring manager) establish the session. No loop source documents a values-style round, so none is assumed. Weights start from the hiring-manager prior, then adjust for the dossier.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy (a rehearsal method, not a claim) |
|---|---|---|---|
| A. Skeptic | Quiet, persistent probing of the gap between your background and the PM title | High, weight 5. A hiring manager is buying capability and derisking gaps, and the dossier names the objection | Rehearse A1 until it is boring: concede first in the sourced words, hold on the quoted work, state the ramp as a plan |
| B. Case / Strategist | Live problems from the role: partner breakage, prioritization, adoption, discovery, a spec outline | High, weight 5. A hiring manager tends to use live problems from the actual roadmap, and the JD supplies four responsibilities to draw from | Clarify, then objective, then segmentation, then approach, metrics, risks; think aloud and challenge one premise respectfully |
| C. Data-Driven Prober | Goes line by line through the headline number and what you did | Medium, weight 3. "30+" is the one headline figure; nothing tells me whether this manager reads that closely | Know what you can and cannot say about how the count was made; name the assumption you would defend least before they do |
| D. Conversational | Open "walk me through your journey" start that is still scored | Medium, weight 3. In 45 minutes the opener sets the frame, and the interviewer's style is unknown | A 90-second arc built only from your three confirmed claims and your own reasons |
| E. Peer Evaluator | The seam with the two squad leads; who decides when you disagree | Medium-low, weight 3. The squad-lead seam is an open item in the dossier, and a hiring manager may probe it from the squads' side | Propose seam principles rather than pretending to know the seam; ask where decision rights sit |
| F. Pressure | Time-boxed challenge: sixty seconds, "how much of that was you" | Low, weight 2. Nothing says this interviewer is a stress interviewer, but A1 gets a short form in case | Pause, restate, hold the sourced position through two follow-ups, concede specifically |

## Question banks

Question IDs are letter-by-persona so a drill can name them. The deepest rehearsal is A1: the underwriter named this objection from evidence you confirmed.

### A. Skeptic (weight 5)

Proposed language, pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; named by field: `prohibited_claims` | The highest-ROI rehearsal in this pack. (1) Concede first, naming the limit before it is asked: "I haven't held a product manager title or role, and I haven't owned a product roadmap." (2) Hold on the quoted work and go no wider: "What I have done is lead 30+ end-to-end client integrations of the vendor's REST APIs: scoping, requirements, architecture, UAT, go-live, and write the internal integration playbook my team uses." (3) Name it as adjacent: "So I'm coming at this from the integration side, and I'd rather say that than oversell it." (4) Ramp as a plan: "In my first weeks I'd want to learn how the two squads prioritize today." Follow-up levels: a) "That's delivery, not product." Go back to (1) and (2); add nothing. b) "What did your roadmap-input sessions change?" Use A4's slot. c) "So why not the PM with three years?" Concede specifically: "A PM with three years has done the part I haven't, owning a roadmap." Do not fold on (2) and do not add to it | F1 and F2 are the widest gaps against the must-have, and the underwriter named this objection, so it arrives in some form. JD because it scores R1 directly |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] named by field: `acknowledge_gap` (owning a roadmap and prioritization authority); `prohibited_claims`: "Having owned a product roadmap"; "Having set prioritization for an engineering squad" | Pick the weakest from the JD's own list and say it plainly: "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then the ramp as a plan. Do not reach for a bridge; the underwriter looked and found none for this area, and an invented one is how a candidate gets caught | F2 is the one capability gap, and this question is the Skeptic's stem aimed at it. JD because the weakest-area question scores the stated responsibilities |
| A3 | "This role needs someone who has shipped API or platform products. What have you shipped?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | Say what the quotes carry: the integrations you led and the playbook you wrote. Answer slot: the JD's "Shipped API or platform products" makes a probe likely. If any product or platform capability you were part of reached release, say what it was and what part was yours; if none did, or none was yours, say so plainly and stay with the integrations you led. Do not say the integrations were shipping a product | F3 is a must-have with only adjacent evidence. The question's premise is the JD's, and the guidance does not adopt it. JD because it scores R2 |
| A4 | "You ran quarterly roadmap-input sessions. How did that work, and what happened to what clients told you?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Volunteer the limit before it is extracted: this claim is confirmed with limited inspectable proof, so expect a probe. Tell the beats the quote states: the sessions were quarterly, you ran them, they fed client evidence to product. Answer slot: if anything came of what clients told you, say what it was and what part was yours, in your own words; if nothing did, or you do not know, say so plainly and stay with the sessions you ran. If you can point to anything that shows how a session ran, say what; if nothing, say so | F5 and F1 rest on this claim, and F1's bridge breaks if it is stretched into influence. EXP because it tests what was actually yours |
| A5 | "Why move from integration work into product, and why now?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Your material states no reason, so the pack supplies none. Answer slot: give your actual reasons, in your own words, starting from the integration work you led; if the reason is partly practical, say that plainly. Keep it consistent with A1's "adjacent" framing | The Skeptic always asks why leave, why here, why now, and a stated motive that contradicts A1 is the easiest thing to break. EXP because it tests consistency of your own story |

### B. Case / Strategist (weight 5)

Proposed language, pending your approval. None of these asks about your past, so the guidance makes no claim about it.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A partner reports that a change to an API response format broke their integration, and two other partners say they want it left as it is. What do you do?" | CASE | [generic] | Clarify first: who is affected, how many partners, whether there is a stated deprecation commitment. Then objective, options (revert, version, migrate with notice), who you would inform and in what order, what you would measure, and the main risk. Challenge one premise aloud, for example whether the change was documented | A live problem from the JD's "partner-facing API platform" and "integration partners" lines. `[generic]` because it is a pattern for the problem, not a fact about this employer |
| B2 | "We have two engineering squads and room for one big item next quarter. One partner wants a feature for a large deal and another is at risk of leaving. How do you decide, and who decides?" | CASE | [generic] | Structure criteria first (impact, reach, evidence quality, cost, reversibility), then say what you would need to know. On "who decides", say that you would want to know which of these calls are yours and which belong to the squad leads, and that you would work inside whichever it is. Do not claim you would simply decide | Tests the roadmap and squad responsibilities, with the dossier's open item on decision authority built in. CASE because the format is a live prioritization problem |
| B3 | "Partner API adoption has been flat for two quarters. How do you diagnose it?" | CASE | [generic] | Start by asking how adoption is defined and measured today, since the dossier lists that as unknown. Then segment partners, name the stages from first contact to sustained use, and form hypotheses at each stage before choosing a metric. Say what you would look at first and why | The JD's "Define and track adoption metrics" line, turned into a diagnosis. `[generic]` for the same reason as B1 |
| B4 | "Sketch how you would run discovery with integration partners in your first 60 days." | CASE | [generic] | Clarify what is already known, then who to talk to (a spread across partner sizes and stages), what you want to learn, how you would record it, and how it would feed the roadmap. State it as a plan. Do not describe your past sessions as discovery here | The JD's "Run discovery with integration partners" responsibility. CASE because it asks for a plan, not a past |
| B5 | "Outline the spec for a new partner webhook feature. What goes in it?" | CASE | [generic] | A skeleton you can say aloud: the problem and which partners feel it, the success measure, scope and explicit non-goals, the API contract and schema changes (this is where R3 shows), error and retry behavior, rollout and docs, open questions. Say which squad you would write it with and what you would need from them | The JD's "Write specs and drive delivery with two engineering squads" line, and R3's API docs and schemas. CASE because it asks you to produce structure live |

### C. Data-Driven Prober (weight 3)

Proposed language, pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You led 30-plus integrations. How was that number counted, and which part of each was yours?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Use the quote's own verb and scope: you led 30+ integrations, from scoping to go-live. Answer slot: say how the count was made, what it is sensitive to, which assumption behind it you would defend least, and which parts were yours, each in your own words; if you do not know how a figure was counted, say so plainly. Never round it up | "30+" is the headline figure in F1, F3 and F5, and probers go after those. EXP because it is a defend-the-number question |
| C2 | "Pick one of those integrations and take me through it from scoping to go-live." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The beats the quote states are scoping, requirements, architecture, UAT and go-live; tell them in that order in your own words. Any client, timeline, problem or outcome inside them comes from your memory, and none is supplied here. If you cannot recall detail on one integration, choose another rather than fill it in | A prober tests whether the claim survives one concrete instance. EXP because it checks what was actually yours |
| C3 | "You wrote the integration playbook. What is in it, and who uses it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | The quote carries three things: you wrote it, it is internal, and your team uses it. Say what is in it in your own words, since the dossier records it as the one inspectable artifact. Answer slot: if asked how the team's use of it changed their work, say what you know; if you do not know, say so plainly | The playbook is the claim with inspectable proof behind it, so it is the strongest ground to be probed on. EXP because it tests authorship |

### D. Conversational (weight 3)

Proposed language, pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey. How did you get from where you started to wanting this role?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc with only these beats: you led the integrations, you wrote the playbook, you ran the quarterly sessions that fed client evidence to product. Your earlier history and your reason for wanting product come from your own words; your material states neither, so none is supplied. Keep it consistent with A1 and A5 | An open start is still scored, and a loose arc is where inflation creeps in. EXP because it checks the story against your confirmed claims |
| D2 | "What do you know about Quartzline and the partner API platform?" | CO | [generic] | Research was refused in this session, so this pack holds no company facts. Answer slot: say what you have read yourself, in your own words; if you have read little, say so plainly and say what you would want to find out. The only sentence you can safely rest on is the JD's own: a partner-facing API platform with two engineering squads | The one company-knowledge question a hiring manager is likely to ask. `[generic]` because nothing about the company was established |
| D3 | "Tell me about a time you worked from API docs or schemas." | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The quote names REST APIs and an architecture step and does not show docs or schemas. Answer slot: if you worked from API docs or schemas in those integrations, say how and which part was yours; if not, say so plainly and stay with the REST APIs and the architecture step you named. If no instance comes to mind, say that, then say what you would read first in this role | Covers R3, which appears once in the JD and is easy to miss. JD because it scores a stated requirement |

### E. Peer Evaluator (weight 3)

Proposed language, pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "You'd partner with two squad leads. Where is the seam between your decisions and theirs, and what happens when you disagree?" | JD | [generic] | Offer seam principles, not a map: you would want product to own the what and why and the squads the how, and you would want to confirm that with them. Then say how you would handle disagreement: bring the evidence, name the trade-off, escalate only after both sides have heard each other. Then ask where decision rights sit today. Do not describe having had that arrangement before | The seam is the dossier's open item on decision authority, so asking it back is part of the answer. JD because the JD asserts the authority without evidence |
| E2 | "Tell me about a time sales, engineering and a customer all wanted different things." | JD | [generic] | Selection criteria: pick a time with a named disagreement, your part in it, and a relationship intact afterward. Your confirmed claims show clients and product, not sales or engineering as named groups; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is the client evidence you fed to product, or say how you would handle it | Covers R4 with an open prompt whose theme the JD supplies. `[generic]` because no confirmed sentence carries this story |
| E3 | "Tell me how delivery worked on a team you were part of." | JD | [generic] | Answer slot: the JD's "Agile delivery experience" makes a probe on how you have worked with delivery teams likely. If you worked that way, say how and which part was yours; if you never worked that way, say so plainly and say what you would want to confirm about how the two squads here define it. Nothing in your material speaks to this, so no past is supplied | Covers R5, a preferred requirement the dossier marks `clarify`. JD because it scores a stated requirement |

### F. Pressure (weight 2)

Proposed language, pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over a PM who has done this job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; named by field: `prohibited_claims` | Hold-then-concede in sixty seconds. Pause and restate the question. Concede in the sourced words: "I haven't held a product manager title or role, and I haven't owned a product roadmap." Hold on the quote: "I've led 30+ end-to-end client integrations of the vendor's REST APIs." Close on the ramp as a plan. Hold through two follow-ups by returning to the quote, never by adding to it | The time-boxed form of A1 for an interviewer who interrupts. JD because it scores R1 |
| F2 | "Of those 30-plus integrations, how much was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold the quote's verb: you led them. Answer slot: say which parts were yours and which belonged to others, in your own words; if some parts were not yours, say so plainly and return to what you led. Do not upgrade "led" and do not shrink it to look modest | An attribution probe is the standard stress test of a headline claim. EXP because it tests attribution |

### Requirement coverage

| Requirement (dossier role_profile) | Questions |
|---|---|
| R1 "3+ years product management experience" | A1, A2, A5, F1 |
| R2 "Shipped API or platform products" | A3 |
| R3 "Technical fluency: API docs, schemas" | D3, B5 |
| R4 "Stakeholder management across engineering, sales, customers" | E1, E2, A4 |
| R5 "Agile delivery experience" | E3 |
| "Own the roadmap for the partner-facing API platform" | A1, A2, B2 |
| "Run discovery with integration partners" | B4, A4 |
| "Write specs and drive delivery with two engineering squads" | B5, E1, E3 |
| "Define and track adoption metrics" | B3 |

## Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The dossier flags decision authority as asserted in the JD but not evidenced. It reads as diligence and answers what you need to know before accepting |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | Adoption metrics are named as a responsibility with no baseline stated. The answer tells you what you would be judged against |
| 3 | "How do the two squads run delivery today, and where does the PM sit in that rhythm?" | It resolves R5's wording from the inside and shows you want to learn their process before proposing yours |
| 4 | "What does a strong first 90 days look like for someone coming from the integration side?" | It names your starting point plainly and is consistent with A1's adjacent framing. The answer shows how much ramp the manager expects |
| 5 | "How does partner evidence reach the roadmap today, and who runs those conversations?" | It points at the part of the role closest to your confirmed work without claiming it, and tells you how much of discovery is already owned |

## Prohibited claims

This pack will not coach these. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| "Having held a product manager title or role" | Dossier `prohibited_claims` | F1's quotes at their own scope, plus the plain acknowledgment the field sources: "I haven't held a product manager title or role" |
| "Having owned a product roadmap" | Dossier `prohibited_claims`; `acknowledge_gap` area on F2 | The plain acknowledgment: "I haven't owned a product roadmap." No bridge and no slot |
| "Having set prioritization for an engineering squad" | Dossier `prohibited_claims`; `acknowledge_gap` area on F2 | The plain acknowledgment: "I haven't set prioritization for an engineering squad." No bridge and no slot |
| Shaped the roadmap through the roadmap-input sessions | Inflated form of F1 and F5 | The quote at its own scope: "Ran quarterly roadmap-input sessions feeding client evidence to product." The limit is the pack's observation: your material says the sessions fed client evidence to product, not what product did with it. A4's slot stays inside the sessions |
| Ran product discovery with integration partners | Inflated form of F5 (the JD's wording borrowed for your history) | The same quote at its own scope. B4 is a plan for the role, not a claim about your past |
| Shipped an API product | Inflated form of F3 | F3's quotes at their own scope: the integrations you led and the playbook you wrote. A3's slot asks only whether anything reached release |

## Sources

- **Provided:** `tuesday-dossier.md`, version 1.1, generated by job-underwriter on 2026-08-14. Consumed: `role_profile` (requirements and responsibilities, which stand as the job description), and `handoff_to_mock_interview` (`verified_candidate_evidence`, `uncertain_or_weak_areas`, `likely_interviewer_objections`, `opportunity_risks_to_validate`, `questions_for_employer`, `prohibited_claims`). `decision` was read as context only. The dossier carries no `evidence_map`, `evidence_state` or `risk_register`, so nothing here rests on them.
- **Searches sent:** `Quartzline company values` — refused. `Quartzline interview process product manager` — refused. `Quartzline strategy news partner API platform` — refused. No fetches.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | The call was refused. It would have supplied official value names for VAL questions and a values sheet if a values round were documented. None is in the pack |
| 2. `Quartzline interview process product manager` | unavailable | The call was refused. It would have documented the loop. Persona weights rest on your own description of the round and the hiring-manager prior |
| 3. `Quartzline strategy news partner API platform` | unavailable | The call was refused. It would have grounded a CO question in current strategy. D2 is `[generic]` |
| 4. interviewer name and company | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's `role_profile` already fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The hiring manager's name → an interviewer read, persona weights tuned to their public footprint, and a reverse question tied to their own path
- The recruiter's prep email or stated focus areas → coverage of anything pre-declared, such as a case or presentation
- Search access, or a pasted values page, careers or interview page, or strategy brief → D2 becomes `[grounded]`, and a values sheet appears if a values round is documented
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes, also needing search access) → a grounding brief on the company's current priorities
- An agenda, deck or notes from one roadmap-input session → F5 and A4 can move from `medium` toward `high` (inspectable proof for item 3)
- Your own account, outside a drill, of whether anything you were part of reached release, whether you worked from API docs or schemas, how you worked with engineering and sales, and how delivery was run → F3, F4, F5 and F6 can become story-mapped instead of slots
- Your raw CV behind the three confirmed claims → more `[grounded]` rows and possibly more evidence quotes
