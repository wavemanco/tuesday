I'll read the reference files the skill requires before building the pack.
Your prep pack is saved as `stripe_product-operations-manager_interview_pack.md`, in the working directory. Web search wasn't permitted in this session, so I built it from your note alone and nothing in it is researched. Stripe's published values, the actual interview loop and current strategy are all missing, and the Sources section lists each refused search. With no CV or job description, the fit snapshot is a worksheet, and every answer guide is a "pick a story" scaffold, not a story built from your experience. I assumed a hiring-manager final round, blended with cross-functional and peer conversations. The persona weights are the weakest part of the pack until I know who you're meeting.

The most important rehearsal is question B1: how you get a product or engineering lead to change course when product operations owns none of their teams.

Say the word and I'll play the Skeptic on B1 as a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions, and I can convert the pack to Word if you'd like.

Two answers would restructure the pack. Who are you meeting in the final round (hiring manager, peer, skip-level or cross-functional), and did the recruiter mention focus areas or a deliverable like a presentation or case? And can you paste the job description and your CV or a few paragraphs of background, or tell me to proceed without them? Your background would turn the scaffolds into answers built from your own words.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Interview pack: Product Operations Manager, Stripe

Final round. Interviewer and relationship: not given. Built for a conversation with the hiring manager, blended with cross-functional and peer sessions, because your note says only "final round". Candidate material (CV) and job description: not given, so the fit snapshot is a worksheet and every answer guide is a selection scaffold, not a story map.

## How to use this pack

Personas describe how a question arrives (who is asking, in what style). Types describe what is being scored. Guidance is scaffolding for a spoken answer of 90 to 120 seconds, not a script. Nothing here claims anything about your past: where an answer needs a story, the guide tells you what to look for, and ends with the honest branch for when none comes to mind.

| Type | What it is really testing |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether your claims survive scrutiny; what was actually you |
| JD | The stated job: can you do it, including its gaps |
| CO | Homework depth and thinking at the company's altitude |
| CASE | Structure and reasoning on a live problem from the role |

Highest-ROI prep in this pack: B1. It is the objection most likely to reach any Product Operations candidate (an operations role that owns none of the teams it works with, asked how you change what a product or engineering lead does). It is inferred from the role family, not from your CV, so it sharpens a lot once you share your background.

## Fit snapshot

No CV and no JD were supplied, so this is the worksheet variant. Requirements are role-family patterns written as plain prose, not quotes, because no posting was available. Evidence cells are empty because you have given none. In each bridge, the first sentence says what strong evidence looks like and the rest is a selection scaffold.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinating launches or programs across product, engineering and go-to-market teams (role-family pattern, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a named launch or program, the teams involved and what you personally coordinated. Pick one where a handoff between teams was at risk; it needs a named stake, what you did and what happened. If no such time comes to mind, say so plainly, then give the nearest work your background does carry, or how you would approach it |
| F2 | Designing and running operating rhythms and processes for product teams (role-family pattern, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a process you set up or changed, who used it and what you would drop from it. Pick one where you can say what you built versus what you inherited. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would design one |
| F3 | Using data and metrics to guide product decisions (role-family pattern, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a decision a number informed, with how the number was counted and what you trust least about it. Pick one figure you can defend end to end. If none comes to mind, say so plainly, then say what you would measure first and why |
| F4 | Influencing stakeholders who do not report to you (role-family pattern, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a named disagreement, what you asked for, and what changed. Pick one where the other person had competing priorities. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it |
| F5 | Structuring ambiguous problems and communicating clearly, in writing and aloud (role-family pattern, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a document or decision you wrote or presented for a mixed audience, and what the audience did with it. Pick one that is real and recent. If none comes to mind, say so plainly, then show the structure on a live case instead |
| F6 | Motivation and fit for this company and this role (role-family pattern, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is reasons only you can give, consistent with your own career story. Write your own three sentences before reading anything else in this pack |

### Requirement coverage

| Requirement | Questions that cover it |
|---|---|
| F1 | A1, B1, D1, D3 |
| F2 | A3, B4, C2 |
| F3 | A2, C1, C2, C3, E2, F2 |
| F4 | B1, B4, D2, D3, E1, E2, F1 |
| F5 | A1, A4, E3, G1, G2 |
| F6 | A4, B2, B3, F1, G1 |

Company-strategy coverage: none, and why. Web research was refused in this session, so no question here rests on Stripe's current strategy; A4 is the only company-knowledge question and it is `[generic]`.

## Persona table

Your note does not say who you are meeting, and no loop source establishes Stripe's final round, so these weights rest on a pattern and not on a documented process. Read them as the weakest part of this pack until you tell me the relationship.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | Live problems from the role: diagnose, design, plan | High: a hiring-manager conversation is the case I assumed, and this role is about structure | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| B. Skeptic | Quiet probing of gaps and motivation | High: same assumed hiring-manager session; a role that owns no teams invites it | Rehearse B1 until it is boring; calibrated candor over bluffing |
| C. Data-Driven Prober | Inputs, denominators, assumptions | Medium: Product Operations leans on metrics, but nothing I hold says this interviewer does | Know how each figure you cite was counted and say plainly where you do not know |
| D. Peer Evaluator | Seams between teams, credit, collaboration | Medium: likely if any session is with a team peer; unknown | Reciprocity framing; propose seam principles rather than pretending to know the seam |
| E. Values / Behavioral | Scenario probes on how you behave | Medium: no values-style round is established for this loop, and Stripe's published values were not read, so themes come from standard stems only | Pick stories where the hard truth actually landed; if none, say so |
| F. Pressure | Interruptions, time boxes, motives | Low to medium: a final round can include it; no signal either way | Pause, restate, hold a position through two follow-ups, concede specifically |
| G. Conversational | Friendly, unstructured, still scored | Medium: openers and wrap-ups in most conversations | A 90-second arc from your own material; never answer "I think you've covered everything" to the reverse-question slot |

## Question banks

Every row is labeled `[generic]` with no quoted sentence, because no candidate material was given. Where a guide says to pick a story, it is a selection scaffold ending in its honest branch.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A product group ships through five teams and launches keep slipping at the handoffs. You have just joined. What do you need to know first, and what do you do in your first month?" | CASE | [generic] | Clarify before structuring: what slipped, where in the handoff, who feels it, what is already tried. Then objective, a short list of hypotheses, one small first action, how you would know it worked, and the main risk. Say your structure aloud before using it. The question needs no claim about your past, so the guide makes none | F1 and F5 in a live setting. CASE because it scores structure on a problem from the role, with no history asked |
| A2 | "A launch-readiness metric dropped 20 percent month on month. Diagnose it." | CASE | [generic] | Ask what the metric measures and how it is counted before anything else. Split into definition change, population change and real change, name what data would separate them, and say which you would check first and why | F3 under time pressure. CASE because the premise is a hypothetical and no experience is presupposed |
| A3 | "Design the operating rhythm for a product organization of twelve teams. What would you put in it, and what would you refuse to add?" | CASE | [generic] | Start from the decisions the rhythm must serve, then cadence, artifacts and owners, then what you would not add and why. The refusal is the differentiator: name one thing you would leave out and the cost of leaving it out | F2. The anti-pick is the part candidates skip, and a Product Operations role is partly about saying no |
| A4 | "What do you think is the hardest product operations problem at a company like this one, and how would you test that view?" | CO | [generic] | Use only what you have actually read or used about the company; I could not research it, so nothing here supplies a fact. Offer one view, how you would test it in your first weeks, and what would change your mind. If you have not formed a view, say what you would ask first | F6 and F5. CO because it checks whether you can think at the company's altitude, and `[generic]` because no company research ran |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Product operations sits between teams and owns none of them. How do you get a product or engineering lead to change what they are doing?" | JD | [generic] | Highest-ROI rehearsal. Hold a position through two follow-ups: say what you would ask the lead about their priorities first, what you would offer, and where you would escalate. Then the story: pick a time you moved someone you did not manage, with a named competing priority, what you asked for and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Concede specifically what you could not have done without their agreement | F1 and F4. The role-family objection most likely to arrive in some form; JD because it scores a core stated job demand |
| B2 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Pick one real gap, not a disguised strength, name it in a sentence and give a specific ramp plan: who you would ask, what you would read, what you would do in the first weeks. Calibrated candor beats bluffing a skill the interviewer owns | F6. This is the stock Skeptic stem and tests honest self-assessment |
| B3 | "Why this role, and why now?" | EXP | [generic] | Give your own reasons in your own words, consistent with the career story you will tell in G1. No invented backstory; if a reason is partly personal, say the part you are comfortable saying | F6. EXP because it tests motivation consistency against the rest of your story |
| B4 | "What would make you say no to a request from a senior product leader?" | JD | [generic] | Give your decision rule first: what makes a request worth refusing, and how you refuse so the relationship survives. A story is optional: if a real instance comes to mind, tell it at its true scope; if none does, say so plainly and walk through how you would decide | F2 and F4. The anti-pick question for a role that sets process for others |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Pick one result you have reported with a number. How was it counted?" | EXP | [generic] | Say how the number was counted, what it is sensitive to, which assumption behind it you would defend least, and which part was yours. Say the weakest assumption before they do. If you do not know how a figure was counted, say so plainly and name who would. Never describe a method you did not use | F3. Every headline figure in your background is a probe target; EXP because it scores attribution honesty |
| C2 | "How would you tell whether a product operations program actually improved anything?" | JD | [generic] | Baseline, comparison, what counts as success, and what you would distrust in the result. Name one measure you would reject and why. No past is presupposed | F2 and F3. JD because it tests the role's measurement mandate |
| C3 | "What data would you want in your first month, and what would you do if it does not exist?" | CASE | [generic] | Name two or three questions the data must answer, then where it likely lives, then the cheapest way to get a rough answer if nothing exists. Say what decision each would change | F3. Tests whether you start from decisions rather than dashboards |

### D. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where is the seam between us, and what happens when we disagree?" | CASE | [generic] | Propose seam principles instead of pretending to know the real seam: who decides, who is consulted, who is informed. Ask where they feel friction today. For disagreement, say how you would surface it early and when you would escalate | F1. CASE because it is a live problem about the seam, with no history asked |
| D2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Pick a time credit was shared across teams; use we for context and I for your contribution, and say what you did to make others visible. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | F4. Peer stem; scores whether you add or reduce load |
| D3 | "What would you need from me in your first month, and what could you do for my team?" | JD | [generic] | Lead with what you offer, then one or two specific asks. Reciprocity beats a list of needs | F1 and F4. Peer sessions price what the hire costs and contributes |

### E. Values / Behavioral

Stripe's published values were not read, so these themes come from standard behavioral stems and not from Stripe's own principles. Check them against the values page yourself.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time with a named stake where the truth landed and the relationship held. Use we for context and I for your contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4. Standard behavioral stem; selects for candor |
| E2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a time with a real metric on the line and a decision you made; say what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would think about the trade | F3 and F4. Another standard stem |
| E3 | "A launch is at risk. The data says delay and the team is excited. What do you do?" | VAL | [generic] | Treat it as a live problem: what you would check about the data first, who you would talk to, how you would put the delay to the team, and what you would offer in place of the launch date | F5. A decision-under-pressure scenario with no past presupposed |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over an internal candidate?" | EXP | [generic] | Pause and restate. Give the reasons only you can give, in your own words, and stop. No claim you could not defend on a follow-up | F4 and F6. Time-boxed motive question that scores composure |
| F2 | "Pick a result you are proud of. How much of it was actually you?" | EXP | [generic] | Hold-then-concede: state what you did, hold it through two follow-ups, and concede specifically what others did. Never fold on the core claim just to restore harmony, and never claim more than was yours | F3. Pressure form of attribution honesty |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc built from your own CV: every beat a sentence you can stand behind, ending on why this role. Without your CV I cannot map it; share it and I will rebuild this row | F5 and F6. A casual opener that is still scored |
| G2 | "Tell me something you have been experimenting with lately that relates to this role." | JD | [generic] | Name something you really did, what you learned and what you would do differently. If nothing comes to mind, say so plainly, then say what you would try and why | F5. Casual questions about the role's hot topics are scored |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a great first ninety days look like, and what would make you say it went badly?" | Shows you think in outcomes and gives you the scoring sheet |
| R2 | "Where does product operations get pulled in too late, and what would you change if you could?" | Signals you already see the seam problem from B1 and D1 |
| R3 | "What decisions does this team own, and which does it only advise on?" | Tests the authority question directly and shows you plan around it |
| R4 | "How is success for this role measured, and by whom?" | Tells you the metrics the role will be judged on |
| R5 | "What is the hardest thing about working here that someone from outside would not expect?" | Invites candor and shows genuine curiosity |
| R6 | If the person is a peer: "What could a new person do in their first month that would genuinely help your team?" | Reciprocity framing for the peer session; the interviewer gets to say what they need |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Any result, figure, title, team size or ownership you have not said yourself | No candidate material was supplied, so nothing in this pack can be stretched, and nothing here can supply facts on your behalf | Each answer guide ends in an honest branch: say what is yours in your own words, or say plainly it was not yours |

## Sources

Provided: your message, which gave the company, the role and the round only. No JD, CV, interviewer information or recruiter notes were supplied.

Searches sent, all refused (the session did not grant web search):

- `Stripe operating principles values` — refused
- `Stripe interview process product operations manager` — refused
- `Stripe strategy news 2026` — refused
- `Stripe Product Operations Manager job description` — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Would have fed a values cheat sheet by official name; with it absent, section 10 is dropped and E-bank themes are standard stems |
| 2. Stripe interview process for this role family | unavailable | Would have named Stripe's actual rounds; persona weights rest on a pattern instead |
| 3. Stripe strategy and recent news | unavailable | Would have grounded A4 and added strategy cases and a grounding brief |
| 4. Interviewer name and company | n/a | No name was given; the interviewer read is absent |
| 5. Representative Product Operations Manager JD | unavailable | Would have turned the F1 to F6 requirements into quoted, inferred rows |

## Upgrade menu

- Your CV or background (even a few paragraphs) → the fit snapshot's evidence cells fill with your own quoted sentences, rows move from `discovery` to real gap types, and G1, B1, C1, F2 become story-mapped instead of scaffolds
- The job description → F1 to F6 become quoted `[grounded]` requirements and every JD-tagged question maps to a real line
- Who you are meeting and their name or profile → persona weights reweight, and a reverse question is tied to their path
- The recruiter's email or notes (focus areas, any presentation, case or take-home) → build sections for any declared deliverable and coverage tuned to what is announced
- If your final is several sessions, the schedule → per-session mini-packs
- Permission for web search → Stripe's values by official name, the documented loop, and a current-strategy brief; a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) would add interviewer talks and role-family loop reports
- A tuesday-dossier.md from an earlier evidence review, if you have one → verified evidence, constraints on weak areas and prohibited claims arrive ready to use
