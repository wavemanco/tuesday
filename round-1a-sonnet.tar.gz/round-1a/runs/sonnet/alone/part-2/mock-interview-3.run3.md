I'll start by reading the skill's reference files.
Your prep pack is saved as stripe_product-operations-manager_interview_pack.md in the working directory. I wrote it for a final round with an unknown interviewer and no job description or CV from you. That makes the fit snapshot a worksheet, and every question is marked `[generic]`. Search access was refused for all four lookups, so nothing in it comes from current Stripe research. That means no values cheat sheet, no strategy brief, and persona weights that are close to flat. The pack doesn't state any Stripe facts from memory.

Say the word and I'll play the Skeptic on B1, the question the pack names as its highest-ROI prep: "Product Ops owns no roadmap and no engineers. Why would a product team change how it works because you asked?"
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Who are you meeting in this final round (future manager, peer, skip-level or cross-functional), and has the recruiter said anything about focus areas or a deliverable? The answer reweights every bank.
Can you paste the job description and your CV, or a few lines on your background? I'll proceed without them if you'd rather, but the answer guidance only becomes specific to you once I have your material.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe — Product Operations Manager — final-round interview pack

Interviewer: not given. Relationship: not given. Built as a blended final round with no job description, no CV and no interviewer information. Every row that would normally rest on your material is a worksheet row, and every question carries `[generic]`.

## How to use this pack

- Personas describe how a question is asked. Types describe what is being scored.
- Type key: VAL = values and behavioral alignment. EXP = work-experience deep-dive. JD = role and responsibilities. CO = company and strategy knowledge. CASE = live hypothetical problem.
- Guidance is scaffolding, not a script. Where it says to pick an instance from your own work, the instance and its details must be yours. Where nothing comes to mind, the honest branch is to say so plainly.
- Rehearse out loud. Each guidance cell is meant to be speakable in 90 to 120 seconds.

## Fit snapshot

Worksheet variant. No job description was supplied and the research that would have fetched a representative one was refused (see Sources), so the requirements below are role-family prose, not quotations from a Stripe posting. No CV was supplied, so every evidence cell is empty. Paste either one and these rows regenerate.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Drive programs and launches across product, engineering and customer-facing teams (role family, no source) | none given | none | [generic] | discovery | Strong evidence is a named program or launch, who it spanned, and what you were responsible for. Selection scaffold: pick one cross-team effort where you can say plainly what was yours and what was others. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Design and run operating cadences and processes such as planning, reviews and escalation (role family, no source) | none given | none | [generic] | discovery | Strong evidence is a recurring process, why it existed and whether people kept using it. Selection scaffold: pick a process you set up or changed, with a stated reason and a stated outcome. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Use data to diagnose problems, prioritize and define success measures (role family, no source) | none given | none | [generic] | discovery | Strong evidence is a figure you can explain: how it was counted, what it is sensitive to, which assumption you would defend least, which part was yours. Selection scaffold: pick one figure you could defend under those four questions. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Communicate clearly to senior leaders in writing and live (role family, no source) | none given | none | [generic] | discovery | Strong evidence is a document or review you wrote or ran and who read or attended it. Selection scaffold: pick one communication to senior people where the audience and the ask were clear. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Influence teams you do not manage (role family, no source) | none given | none | [generic] | discovery | Strong evidence is a case where a team changed how it worked and you can say what you did to earn that and what the team did. Selection scaffold: pick a case where you had no authority over the people involved. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Improve and scale how product teams work, including tooling and automation (role family, no source) | none given | none | [generic] | discovery | Strong evidence is a before and after you can describe without inflating scale. Selection scaffold: pick one improvement where you can state the starting problem and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F7 | Bring customer and field feedback into product decisions (role family, no source) | none given | none | [generic] | discovery | Strong evidence is a specific piece of feedback, where it went and what happened next. Selection scaffold: pick one instance where customer or field input reached a product decision. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

## Persona table

No loop source was read, so Stripe's final-round structure is not established. Persona weights rest on a generic pattern, not on Stripe's documented process, and the relationship to your interviewer is unknown. Weights are close to flat. The one tilt is toward Case/Strategist and Skeptic, the hiring-manager prior, which is a working assumption you can correct.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy (a rehearsal method, not a claim) |
|---|---|---|---|
| A Case/Strategist | Live problems about running a product org: fix this process, diagnose this drop | High: working assumption of a hiring-manager prior, and the role's job is mostly problems of this shape | Clarify, objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully |
| B Skeptic | Quiet probing of why Product Ops, why Stripe, and what you would be weakest at | High: same hiring-manager prior; a loosely defined function invites the question of what it is for | Rehearse the single objection in B1 until it is boring. Concede limits specifically |
| C Values/Behavioral | Scenario probes tied to published principles | Medium: a values-style round is not detected, because no loop source was read and the fallback archetype is generic, so this stays possible but unconfirmed | Pick stories only from your own experience. We for context, I for your contribution |
| D Peer Evaluator | Seam-splitting with adjacent teams, credit questions | Medium: final rounds often include a cross-functional conversation, but this pack cannot confirm that for Stripe | Offer seam principles rather than pretending to know the seam. Lead with what you bring them |
| E Data-Driven Prober | Pushes on the number behind any claim | Medium: any product-ops candidate who quotes a figure meets this | Know what you can and cannot say about how a figure was counted. Say plainly when you do not know |
| F Conversational | Friendly, unstructured, still scored | Medium: present in most loops | Prepare a 90-second arc. Never answer the closing slot with nothing to ask |
| G Pressure | Interrupts, time-boxes, tests composure | Low: no signal in the material that this style is coming | Pause, restate, anchor in what you stated, hold through two follow-ups |

## Question banks

Question counts follow the weights above: A 4, B 4, C 3, D 3, E 3, F 3, G 2. No question here asks you to confirm anything about your past that you have not told me. Where a question asks you to pick an instance, the guidance is a selection scaffold ending in its honest branch.

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A product team ships a major launch every quarter and each one ends in a scramble across support, sales and engineering. You are asked to fix that. What do you need to know first?" | CASE | [generic] | Clarify before structuring: what counts as a scramble, which launches and which functions, what has been tried. Then objective, segmentation, approach, metrics, risks, thinking aloud. Challenge one premise, for example whether the problem is process or prioritization. The question needs no claim about your past, so the guidance makes none | A live problem of the shape this role faces, tied to F1 and F2. CASE because it scores structure, not history |
| A2 | "Adoption of a new internal planning process is low two months in. Diagnose it." | CASE | [generic] | Ask who is meant to use it, what they do instead and what changed for them. Separate awareness, usefulness and cost of use. Name one measure you would look at first and what would make you stop. No past claim is needed | Tests F2 and F6 as reasoning. CASE because the premise is hypothetical and presupposes nothing about you |
| A3 | "How would you describe what Stripe's products do and for whom, and where does product operations add the most?" | CO | [generic] | Research was refused, so this pack cannot supply current Stripe facts and will not guess them. Before the interview, read Stripe's own site and recent announcements, then give a 60-second product map using only what you read, naming where you read it. State where Product Ops could help as a view, not as knowledge of Stripe's internals | The company-knowledge slot. `[generic]` because no research ran; it becomes grounded if the upgrade menu's search access is granted or you paste material. CO because it scores homework depth |
| A4 | "You have one day to prepare a leadership product review. What goes in and what stays out?" | CASE | [generic] | Start with the decision the review should enable and who is deciding. Then inputs, ordering, what you would leave out and why, and how you would pre-wire disagreement. Say it as a plan, not as a past | Tests F4 as judgment under constraint. CASE with JD flavor |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Product Ops owns no roadmap and no engineers. Why would a product team change how it works because you asked?" | JD | [generic] | Highest-ROI prep in this pack: the objection to the function itself arrives in some form in almost every interview for it, and no material of yours is yet quoted to build on. Rehearse three levels. Level one: how you would earn the right to change a process in your own words. Level two: if a team has adopted something you proposed, say what you did and what the team did; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would start. Level three: they say no. Say what you would do next. Concede specifically what you cannot know yet, such as how this team already works, and say how you would learn it in the first weeks. Never add to your history to sound stronger | The most predictable objection, tied to F5. JD because it scores the role's definition, and `[generic]` because it is a pattern for the role, not a finding about you; a CV would sharpen it |
| B2 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Choose a real one, in your own words, and name how you would close it. Calibrated candor beats a disguised strength. If you cannot name one, say so plainly and name what you would ask your first month's colleagues | Persona stem for the Skeptic. JD because it scores honest self-assessment against the role |
| B3 | "Why product operations, why Stripe, and why now?" | EXP | [generic] | Three parts, each in your own words. The Stripe part must rest on pages you have actually read, not on general reputation. If one part is weaker than the others, say which and give your honest reason | Scores motivation consistency across F1 to F7. EXP because it tests whether your story survives cross-examination |
| B4 | "What would you do in your first 30 days?" | CASE | [generic] | A plan, said as a plan: listen first, map the people and processes, pick one small thing to fix, agree how success is measured. Name what you do not yet know. No past claim is needed | Converts the Skeptic's doubt into a concrete ramp, tied to F2 and F5. CASE because it asks for structure |

### C. Values/Behavioral

No published Stripe principles were retrieved, so these questions use the Values persona's standard themes and not named Stripe values.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick an instance with a named stake, a moment you did not fold, and an outcome you can state truthfully. We for context, I for your contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Standard Values stem, tied to F4. VAL because it scores behavior, not knowledge |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick an instance where the customer cost and the internal cost were both real and you can say what was decided. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Standard Values stem, tied to F7 |
| C3 | "Which of Stripe's published principles do you most identify with, and what decision of yours shows it?" | VAL | [generic] | Read Stripe's principles page first and use the exact names, which this pack could not fetch. Do not recite them from memory. Then one story from your own experience; if no decision of yours shows it, say so plainly and describe how you would act | A candidate can be quizzed on the names, so this is rehearsed after you read the source. VAL because it scores demonstrated values |

### D. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles rather than pretending to know the seam: who decides, who is consulted, how disagreement escalates. Ask where it sits today. Show spine and tact together | The Peer stem, tied to F1 and F5 |
| D2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick an instance of shared work where you can say which part was yours and which was others. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Peer stem for credit-sharing, tied to F1 |
| D3 | "What would you need from me in your first month?" | JD | [generic] | Lead with what you bring their team, then what you need: context, introductions, access to existing processes. Reciprocity framing | Peer stem in reciprocity form, tied to F5. JD because it scores partnership fit |

### E. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Pick one figure you would put on a Product Ops resume. Walk me through how it was counted." | EXP | [generic] | Answer the four slots in your own words: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. "I don't know how it was counted" is an honest branch. If no figure comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Defend-the-number rehearsal, tied to F3. It becomes specific once a CV supplies real figures |
| E2 | "How would you decide whether a process change worked?" | CASE | [generic] | Baseline before the change, one leading and one lagging measure, what would make you reverse it, who reads the result. A plan, not a past | Tests F3 and F6 as reasoning |
| E3 | "A dashboard says adoption is up 30 percent but support tickets are also up. What do you check?" | CASE | [generic] | Check definitions and denominators first, then segments, timing and instrumentation changes, then what each explanation would predict. Say which check is cheapest | Prober-style diagnosis tied to F3. Figures here are the interviewer's hypothetical, not yours |

### F. Conversational/Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc in three beats, each in your own words: where you started, the turns, why this role. Every beat should be a fact you could support if asked. Write it once your CV is in hand | Rapport-builder stem; scored even though it feels casual. Tied to F1 to F7 |
| F2 | "What do you read or follow to keep up with how product teams work?" | JD | [generic] | Name one or two real sources and one thing you took from them. If you follow none, say so plainly and say what you would start with | Casual but scored; tests genuine interest |
| F3 | "Anything you would like to ask me?" | JD | [generic] | Never answer that you think they have covered everything. Use two or three of the reverse questions below | Heavily weighted by rapport-style interviewers as a preparation signal |

### G. Pressure/Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, restate the question, answer in your own words from what you have actually done, hold through two follow-ups, and concede specifically what you cannot know, such as internal context. Do not fold on the core claim to restore harmony | Tests composure under time-boxing |
| G2 | "Take the result you are proudest of. How much of it was actually you?" | EXP | [generic] | Selection scaffold: pick a result where you can separate your part from others. Say your part in your own words, hold it through two follow-ups, concede what was not yours. If no result comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The attribution probe in its pressure form, tied to F1 and F3 |

### Requirement coverage

These are the role-family rows above, not lines from a Stripe posting.

| Requirement | Questions |
|---|---|
| F1 Programs and launches | A1, D1, D2, D3, F1, G2 |
| F2 Cadences and processes | A1, A2, B4 |
| F3 Data and measures | A2, E1, E2, E3 |
| F4 Senior communication | A4, C1 |
| F5 Influence without authority | B1, B4, D1, D3 |
| F6 Scaling and tooling | A2, E2 |
| F7 Customer feedback | C2 |
| Company knowledge (no requirement row) | A3, B3, C3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "How does the product organization decide what Product Operations works on, and who can say no to a request?" | Shows you are thinking about the function's boundary, the same issue B1 probes |
| 2 | "What would a successful first six months look like, and how would you and I both know?" | Makes success measurable, which a metrics-minded interviewer notices |
| 3 | "Where does Product Ops help most today, and where do teams route around it?" | Invites candor about the real state of the function |
| 4 | "What was the last process change that did not stick, and what did the team learn?" | Signals you expect change to fail sometimes and care about why |
| 5 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question, strongest if the interviewer is a peer |
| 6 | "Which cross-functional relationship is hardest right now, and what would make it easier?" | Points at the seam work a Product Ops manager actually does |

No interviewer profile was given, so none of these is tied to an interviewer's own path. A name would unlock one.

## Prohibited claims

None listed. Nothing here rests on a sentence of yours, so there is no wording to stretch, and you have stated no gap that a plain acknowledgment would need. Once a CV or JD is in hand this section is rebuilt against it, before the banks are rewritten.

## Sources

Provided documents: your message only, which gave the company, the role and that this is a final round.

Searches sent, all refused, so nothing returned and nothing in this pack comes from them:

- Stripe operating principles values: refused
- Stripe Product Operations Manager interview process: refused
- Stripe strategy news 2026: refused
- Stripe Product Operations Manager job description responsibilities requirements: refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Would have moved the values cheat sheet, which is dropped, and C3's exact principle names |
| 2. Stripe interview process, product operations | unavailable | Would have moved the loop structure and persona weights; weights rest on a generic pattern instead |
| 3. Stripe strategy and recent news | unavailable | Would have moved A3 and the grounding brief; A3 is generic and the brief is dropped |
| 4. Interviewer name and company | n/a | No name was given, so the interviewer read is absent |
| 5. Representative Product Operations Manager JD | unavailable | Would have moved the fit snapshot rows from role-family prose to inferred requirements and the JD-tagged questions |

## Upgrade menu

- The job description text → the seven role-family rows become quoted requirements, JD-tagged questions become grounded, and any location, schedule or work-authorization term gets its own gate row
- Your CV or a few lines on your background → the evidence cells fill with your own sentences, the selection scaffolds become story maps where a sentence carries the story, and B1 gets a rehearsal built on your real material
- Who you meet and in what relationship, plus the recruiter's guidance on focus areas → persona weights stop being flat and the banks reorder
- If your final is several sessions, the schedule → per-session mini-packs with their own persona weights
- The interviewer's name → an interviewer read and a reverse question tied to their own career path
- A pasted copy of Stripe's published principles and a recent strategy brief, or permission to run search → the values cheat sheet, a grounding brief, and current CO and CASE questions in place of the generic ones; a deeper pass would add up to 6 more searches and 2 more fetches and take several more minutes
- A working-style assessment, only if you already have one → a delivery-coaching section
- A tuesday-dossier.md from an earlier session → verified evidence and prohibited claims would replace the locally built list
