I'm reading the last reference files (output rules, evidence conventions, reframing audit, research checklist) before I write the pack.
Priya's prep pack is saved at `/var/tmp/tuesday-measure/1a/runs/sonnet/alone/part-2/rooms/case-1-denied-70faa957/Northwind-Data_senior-gtm-strategy-lead_interview_pack.md`. It has 22 questions across seven personas, tagged by type, each with answer guidance, provenance and rationale. It also has the fit snapshot, a read of Dan, the prohibited-claims list and six reverse questions.

I built it for a peer round with Dan, using only what you gave me. The host refused all four web searches (values, interview process, strategy news, Dan's public footprint), so nothing comes from outside research. Your research note stands in for the strategy view, and the values questions are generic.

- **Weighting:** The Data-Driven Prober and Peer Evaluator lead, because Dan is a peer and calls himself "relentlessly data-driven". The case work tilts toward pricing and packaging because of his monetization background.
- **Biggest objection:** D1 is the question to rehearse first. It asks about the missing sales-ops and quota-setting experience, which Dan is the person most likely to probe. The pack gives her the honest acknowledgment, the adjacent evidence she can actually claim, and a ramp plan.
- **Next biggest:** D2 and the defend-the-number set A1 to A3. D2 covers partner-motion design, which the JD requires and her revenue model only touches. A1 to A3 cover the ~$400M ARR uplift and the volume targets.
- **Gaps in the material:** Where her material doesn't show something, the guidance is an "answer slot", not invented detail. Her own words fill those slots, for example on the partner motion and on how the uplift was counted.

Say the word and I'll play Dan as the Prober on A1 or the Skeptic on D1, and give feedback against the guidance cell.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the full JD text and Priya's CV bullets? The pack currently rests on your summaries, and the full text would exactly quote the requirements and may add mid-list requirements or gates.
Did the recruiter say anything about what Dan will cover? A stated focus would reweight the banks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Northwind-Data_senior-gtm-strategy-lead_interview_pack.md -----
# Interview pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

- **Candidate:** Priya
- **Interviewer:** Dan Kovac, Director of Sales Strategy. A peer: both of you would report to the same VP.
- **Round:** one 60-minute conversation with Dan.
- **Built on:** the JD highlights, the candidate summary, Dan's profile summary and your research note, as given in your message. Web searches were refused by the host, so nothing here comes from outside research.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding for a spoken answer, not a script: say it in Priya's own words, and where a cell says "answer slot", the answer has to come from what she actually did.

| Tag | Name | What it tests |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the values the company publishes, not generic virtue |
| EXP | Work-experience deep-dive | Whether the CV claims survive scrutiny, and what was actually hers |
| JD | Role / JD-driven | Whether she can do the listed job, gaps included |
| CO | Company and strategy knowledge | Whether she can think at the company's altitude |
| CASE | Hypothetical / live problem | Structure and reasoning on a live problem from the role |

Highest-ROI prep: **D1**, then **D2**, then the defend-the-number set A1 to A3.

## Fit snapshot

Requirements are quoted from the JD highlights you supplied, not the full JD. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — your message; "proposed a store-surface change credited with a ~$400M ARR uplift" — your message | medium | [grounded] | transferability | Your material says product strategy and ops, and a proposal credited with an uplift. It does not say GTM for a product line, and the words stay at that scope: "I proposed a store-surface change credited with a ~$400M ARR uplift." Answer slot: the JD's own-the-GTM line makes a probe on launch work likely. If any of your work took a product or surface to customers, say what and which part was yours, in your own words; if none did, or it was not yours, say so plainly and stay with product strategy |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — your message | low | [inferred] | discovery | The quote touches revenue but does not show whether it reached the stages the JD names. Answer slot: expect a probe on whether any of your analysis split revenue or partners by stage of relationship. If it did, say how, in your own words; if it did not, or it was not yours, say so plainly and stay with the model |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights | "skilled in SQL/Tableau" — your message | medium | [grounded] | none | The sentence names both tools in the JD's terms. Lead with it as written. Nothing inspected sits behind it, and Dan's profile makes a probe by example likely, which A4 rehearses |
| F4 | "partner-motion design experience required" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — your message | medium | [grounded] | transferability | The quote is a model used in negotiations, which is adjacent to motion design and does not reach it, and the words stay there: "I built a partner-level revenue model used in carrier negotiations." Answer slot: the JD marks this requirement as required, so expect a probe. If you also shaped how partners were engaged, say which part and how you decided, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights | "set annual volume targets with cross-org consensus" — your message | medium | [grounded] | presentation | The sentence already reaches the requirement in other terms. Say it as written: "I set annual volume targets with cross-org consensus." Nothing is added to it here, and B5 rehearses the likely follow-up |
| F6 | "AI experience a plus" — JD highlights | "uses AI tools daily" — your message | medium | [grounded] | presentation | The sentence says use, so the words are: "I use AI tools daily." Your material does not show building AI products, and the bridge does not go further than the sentence |
| F7 | Working fluency with sales-ops mechanics such as quota-setting. Not in the JD highlights: a role-family expectation for a role beside Sales Strategy | "No classic sales-ops or quota-setting experience." — your message; "set annual volume targets with cross-org consensus" — your message | none | [grounded] | capability | A gap the material states, and wording cannot close it. Words: "I don't have classic sales-ops or quota-setting experience." Then a plan for learning it, said as a plan and never as a past. Your material says volume targets set by consensus, not quotas, and the two are not equated here |
| F8 | Selling-side context: "B2B data-infrastructure SaaS" — your message | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — your message | low | [inferred] | discovery | The quote shows a consumer-tech employer and does not show whether any work faced business buyers. Selection scaffold, used in D3: pick the work of yours closest to a business buyer or a partner; it needs a named stake and what you did yourself. If no such work comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would ramp |

## Reading the interviewer

Public professional footprint only, taken from the profile summary you supplied. Searches for talks or writing were refused, so nothing beyond it is used.

| Signal | What it implies for this session | Provenance |
|---|---|---|
| Profile self-describes as "relentlessly data-driven" | Every number gets probed to its assumptions. Expect A1 to A3 in some form, and expect a request for an analysis she ran herself | [inferred] |
| Career spine in pricing and monetization roles | Case questions tilt toward pricing, packaging and unit economics, which is his native vocabulary. Speak in unit economics, and do not claim pricing work her quotes do not carry | [inferred] |
| One early-stage-startup chapter | Builder stories may land well. Expect a light probe on pace and scrappiness; one chapter is a weak signal | [inferred] |
| Title: Director of Sales Strategy, same VP as the role | He is pricing what this hire adds to or takes from his work. Expect seam questions with his function and collegial packaging of the sales-ops gap | [inferred] |
| Mirror opportunity: his monetization spine and F4's quote "built a partner-level revenue model used in carrier negotiations" | A shared revenue-modeling vocabulary. Use it to ask how his team models partner or channel revenue, never to imply she has done pricing | [inferred] |

## Persona table

Priors for a peer round are Peer Evaluator and Data-Driven Prober. Dan's signals raise the Prober and tilt the case work toward pricing. The session is one conversation with him, so there is no loop to adjust for, and no round that assesses published values is documented for it.

| Persona | Weight | How it shows up with Dan | Why this weight | Counter-strategy |
|---|---|---|---|---|
| Data-Driven Prober | 1 | Line-by-line probing of the CV numbers and of how analyses were run | Peer prior, raised by "relentlessly data-driven" | Say plainly how each number was counted, or that she does not know; name the weakest assumption first |
| Peer Evaluator | 1 | Seam-splitting with Sales Strategy, "what do you need from me", credit across teams | Peer prior; same VP | Reciprocity framing; offer seam principles rather than pretending to know the seam |
| Case/Strategist | 2 | Live problems on partner motion, whitespace and bundling | JD asks her to own GTM strategy; pricing spine tilts cases | Clarify, objective, segmentation, approach, metrics, risks; challenge one premise |
| Skeptic | 2 | The sales-ops gap, domain jump, why leave consumer tech | Stated gap in F7, plus F8 | Rehearse D1 until it is boring; adjacent evidence only; calibrated candor |
| Conversational | 3 | Opening "walk me through the journey" and casual AI question | Every conversation starts here; AI is a JD plus | Pre-script a 90-second arc; treat casual questions as scored |
| Pressure | 3 | A single time-boxed "how much was you" | Peers rarely stress-test, but F1 invites it | Pause, restate, hold through two follow-ups, concede specifically |
| Values/Behavioral | 3 | Behavioral prompts inside the conversation | No values-style round is documented for this session; a later round may have one | Select stories by the scaffold in G1 and G2 |

## Question banks

### A. Data-Driven Prober (weight 1)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | The words stay at the quote: "I proposed a store-surface change credited with a ~$400M ARR uplift." Defend-the-number slots, each in your own words: how the uplift was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly, then return to what you proposed | F1 holds the headline number, and a data-driven peer will go straight to it. EXP because it tests attribution and counting, not the role |
| A2 | "Which assumption behind that uplift would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Name the assumption before he does, in your own words. The pack supplies none. If you do not know which assumption is weakest, say so plainly and say what you would check first | The weakest-assumption move turns a probe into a credibility gain. Separate from A1 so each can be drilled. F1 |
| A3 | "Walk me through setting the annual volume targets." | EXP | [grounded] "set annual volume targets with cross-org consensus" | Tell it at the quote's scope: you set annual volume targets with cross-org consensus. Answer slot: his profile makes a probe on what the targets were based on and where the orgs disagreed likely. If the orgs disagreed, say how it resolved, in your own words; if they did not, or you did not see it, say so plainly and stay with the targets | F5 is her clearest cross-functional evidence, and the nearest thing to quota work in her material. EXP because the claim is what gets tested |
| A4 | "Tell me about an analysis you ran yourself in SQL or Tableau." | JD | [grounded] "skilled in SQL/Tableau" | Open prompt, so pick the instance. Choose one where you wrote the queries or built the views yourself, and which you can walk end to end, offering the walkthrough before he asks. Say "skilled in SQL/Tableau" at its own scope. If no such analysis comes to mind, say so plainly, then give the nearest work your material carries, or how you would approach a first analysis here | F3 is a requirement in the JD highlights and he describes himself as data-driven. JD because it scores a listed skill |
| A5 | "Which metrics would tell you whether Compass adoption is real, and what in that data would you distrust?" | CASE | [inferred] derived from your research note naming the Compass launch as a priority | Clarify first: what counts as adoption, which accounts, over what period. Then segment, name two or three metrics, and name what could mislead (usage that follows a bundle rather than a choice, accounts that were already engaged). Challenge one premise politely. Think aloud and use his unit-economics vocabulary | A live problem on the company's stated AI priority, with the data skepticism his profile suggests. Guidance is a generic structure and makes no claim about her past |

### B. Peer Evaluator (weight 1)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | JD | [generic] | Do not claim to know the seam. Offer principles: one named owner per decision, data definitions agreed once, disagreements shown to the VP with both views side by side. Then ask him where he sees the seam. The question needs no claim about your past | The peer relationship makes this the likeliest peer question. JD because the role's remit sits beside his. No fit row, since it asks about the future |
| B2 | "What would you need from me in your first month?" | JD | [generic] | Pair a need with an offer: what you would ask for (definitions, historical data, a walkthrough of how plans are built) and what you would bring his team. Reciprocity beats a shopping list | A peer is pricing the load a hire adds. Generic: it asks about the future, not her past |
| B3 | "How do you handle credit when work spans teams?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Anchor in the quote: you set annual volume targets with cross-org consensus. Answer slot: if credit was shared or contested, say how it was handled, in your own words; if credit never came up, or it was not yours to handle, say so plainly and stay with the targets | Credit-sharing is a stock peer probe, and F5 is her only cross-team quote. EXP because the answer is her own conduct |
| B4 | "Tell me about a time you disagreed with a peer team on a number." | VAL | [generic] | Open prompt, so selection criteria: a named stake, a position you held, a resolution, and an intact relationship. Your quote shows consensus reached and does not show a disagreement, so whether one existed is yours to say. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Disagreement style with equals is what the persona scores. VAL because it tests behavior, tagged generic since no published value was retrieved |
| B5 | "Tell me about a time you influenced a team that did not report to you." | JD | [grounded] "set annual volume targets with cross-org consensus" | Story-map on the quote: the annual volume targets and the cross-org consensus are the beats it states. Answer slot: the JD asks for strong cross-functional influence, so expect a probe on how the consensus was built. If you took specific steps, say which, in your own words; if consensus did not need any step of yours, say so plainly and stay with the targets | F5 against the JD's influence requirement. Open prompt because he will want the instance |

### C. Case/Strategist (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "For a new product line with no sales history, how would you decide whether a partner motion is worth building? What do you need to know first?" | CASE | [generic] | Clarify (what the product sells, to whom, through whom), set the objective, segment partners, compare economics of a partner route against direct, define the metrics, list the risks. Pricing and unit economics are his native ground, so use them. If you reference your revenue model, say it only as: you built a partner-level revenue model used in carrier negotiations | Partner-motion design is required in the JD highlights (F4). CASE delivery of a JD requirement, labeled generic since the structure is a pattern |
| C2 | "Where would you look for whitespace across land, adopt, expand and renew for a newly launched product, and what would you trust in the data?" | CASE | [generic] | Clarify what is known about customers and usage, then segment by lifecycle stage, name the data you would pull in SQL, the view you would build, and what is too noisy to trust early. Think aloud and state the hypothesis first | The JD names these four stages (F2). The data question speaks to his profile |
| C3 | "A much larger platform vendor starts bundling something competitive. How does that change your GTM plan for the new lines?" | CO | [inferred] derived from your research note on the bundling threat | Use the company's own three priorities from your note: enterprise expansion, Compass, profitability. Frame the trade-off: compete on packaging and price, differentiate on what a bundle cannot do, or partner. Do not claim knowledge of Northwind's numbers; ask him what he is seeing | The research note names bundling as the main threat, so he will want to see her think at that altitude. CO with CASE delivery |

### D. Skeptic (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You don't have classic sales-ops or quota-setting experience. Which part of this role would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience."; "set annual volume targets with cross-org consensus" | **Highest-ROI prep.** Beat 1, the plain acknowledgment: "I don't have classic sales-ops or quota-setting experience." Beat 2, the adjacent quote: "I set annual volume targets with cross-org consensus." Your material says volume targets, not quotas, so do not call them quotas. Beat 3, a plan said as a plan: you would ask his team to walk you through how plans are built before proposing anything that touches them. Follow-ups to rehearse: if he asks how a target differs from a quota, say what you know and say plainly what you do not; if he asks why not hire someone from sales-ops, return to beat 2 and the plan. Never bluff a competency he owns | F7 is the largest stated gap, aimed at the person who owns that ground. JD because it scores a listed requirement and a skeptic's quiet probe is how it arrives |
| D2 | "The JD asks for partner-motion design experience. What have you designed?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Say the quote at its scope: you built a partner-level revenue model used in carrier negotiations. Answer slot: if you also shaped how partners were engaged, say which part and how you decided, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the model. Hold through two follow-ups by returning to the model, never by adding to it | F4 is the second-biggest objection: the requirement is marked required and the quote is adjacent to it |
| D3 | "Why leave a large consumer-tech company for B2B data infrastructure, and why now?" | EXP | [inferred] derived from F8 and the role's company description in your message | Give your actual reasons in your own words; the pack supplies none. Selection scaffold: connect the reason to work you have said you did and to something specific you learned about Northwind, which your research note can supply. If you cannot yet say what draws you to B2B, say so plainly and say what you want to learn | Motivation consistency is what a skeptic scores. EXP because it is a reason for moving, which only she can give. F8 |

### E. Conversational / Rapport Builder (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc on the beats the quote states: two years of strategy consulting at a top firm, then nine at a large consumer-tech company in product strategy and ops. Answer slot: why each move happened, in your own words; if a move was not a choice you made, say so plainly | The opening question of nearly every conversation, and scored. F1 and F8 |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Say which tools and what for, in your own words. The sentence says you use AI tools daily, so describe use; if you have done more than use, say what, and if not, say plainly that it is use. If you can, tie it to what a copilot like Compass needs to prove | AI experience is a JD plus, asked casually. F6 |

### F. Pressure / Stress (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "That ARR uplift. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause and restate. Hold: "I proposed a store-surface change credited with a ~$400M ARR uplift." Hold that through two follow-ups. Concede specifically: say what you do not know about how the credit was assigned. Answer slot: which part was yours, in your own words; if you do not know how credit was split, say so plainly and return to the proposal | An attribution probe is the standard pressure test of a headline number. F1 |
| F2 | "Sixty seconds: why you over someone who has done this in B2B SaaS?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus"; "skilled in SQL/Tableau" | State three things at their quote scope: you built a partner-level revenue model used in carrier negotiations, you set annual volume targets with cross-org consensus, and you are skilled in SQL/Tableau. Let him draw the inference. Concede the limit plainly: you do not have classic sales-ops or quota-setting experience | A time-boxed motive question. JD because it scores fit to the role. F4, F5, F3, F7 |

### G. Values / Behavioral (weight 3)

No values-style round is documented for this session, and the company's published values were not retrieved, so both prompts come from persona stems.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Open prompt, so selection criteria: a named stake, a moment you did not fold, and an intact relationship afterwards. Your material does not show one. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | The stem tests spine, which a cross-org consensus story can hide. Generic until the values page is read |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Open prompt, so selection criteria: the metric, the customer or user, what you chose and what it cost. Your material does not show one. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | The second stock behavioral stem. Generic for the same reason |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| "own GTM strategy for two new product lines" | C1, C2, C3, F2 |
| "identify whitespace across land/adopt/expand/renew" | C2, A5 |
| "run independent analysis in SQL and Tableau" | A4 |
| "partner-motion design experience required" | D2, C1 |
| "strong cross-functional influence" | B1, B3, B4, B5, A3 |
| "AI experience a plus" | E2, A5 |
| Sales-ops mechanics (not a JD line, a peer expectation) | D1, B1, B2 |

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R1 | "You've spent most of your career in pricing and monetization roles and had an early-stage chapter. What from the early-stage chapter do you use most when you plan GTM here?" | Ties to his own path and turns the session into a peer conversation | [grounded] your message, Dan's profile summary |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer | [generic] |
| R3 | "Where do you see the seam between your team and this role, and where do you expect us to disagree?" | Shows she plans for the working relationship, not just the job | [generic] |
| R4 | "How is the larger vendor's bundling showing up in the deals your team sees?" | Uses the competitive frame in your research note and invites his data | [inferred] your research note |
| R5 | "Which metrics does our VP review for the new lines, and how are they defined?" | A data-driven peer will rate a question about definitions | [generic] |
| R6 | "What would good look like at six months?" | Gives her the bar she will be measured against | [generic] |

## Prohibited claims

Built from the fit snapshot before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Has quota-setting or sales-ops experience | Negative stated, F7 | The plain acknowledgment F7 gives: "I don't have classic sales-ops or quota-setting experience." No slot |
| The annual volume targets were quotas | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation, not words for her: the material says volume targets, not quotas |
| Drove or owned the ~$400M ARR uplift | Inflated form of F1 | F1's quote at its own scope: "proposed", and "credited with". A1 and F1 slots stay inside it |
| Designed a partner motion or partner GTM | Inflated form of F4 | F4's quote at its own scope. D2's slot stays inside the model |
| Owned GTM for a product line | Inflated form of F1 | F1's quote at its own scope: product strategy and ops |
| Has built AI products | Inflated form of F6 | F6's quote at its own scope: uses AI tools daily |
| Describing her past in the JD's words (land, adopt, expand, renew; whitespace) | Vocabulary borrowed from the JD, F2 | Her own terms, from F2's quote |

## Sources

Provided documents: your message (role and company, JD highlights, candidate summary, interviewer profile summary, your research note on Northwind's three priorities and the bundling threat).

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data company values` | unavailable | Search refused by the host. Would have fed a values cheat sheet and VAL themes; G1 and G2 are generic instead |
| 2. `Northwind Data interview process strategy lead` | unavailable | Search refused. Would have documented the loop and the persona weights; weights rest on the peer relationship and your words |
| 3. `Northwind Data strategy news Compass AI copilot` | unavailable | Search refused. Would have refreshed the strategy frame; your research note stands in, its age unknown |
| 4. `Dan Kovac Director of Sales Strategy Northwind Data` | unavailable | Search refused. Would have added talks or writing to the interviewer read and R1; it uses only your profile summary |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions |

Queries sent, all refused: `Northwind Data company values`; `Northwind Data interview process strategy lead`; `Northwind Data strategy news Compass AI copilot`; `Dan Kovac Director of Sales Strategy Northwind Data`.

## Upgrade menu

- The full JD text → the highlights become exact quotes, mid-list requirements I could not see get questions, and any gate (location, pay, travel) becomes its own row
- Priya's CV bullets and the artifacts behind them — the revenue model, the store-surface proposal write-up, a Tableau view she built → medium rows F1, F3, F4 and F5 can become high
- Priya's own answers to the slots in F1, F2, F4 and D2, and to the defend-the-number slots in A1 to A3 → those rows regenerate with her words in place of slots
- The recruiter's guidance on what Dan will cover → coverage reweighted; usually one email
- Search permission → rerun the four refused targets: Northwind's published values (VAL bank and a values cheat sheet if a values round exists), the documented loop, current strategy news, and Dan's public footprint (R1 sharpened). A deeper pass, up to 6 more searches and 2 more fetches and several more minutes, is available once on your say-so
- A `tuesday-dossier.md` from an earlier evaluation of this role → verified evidence and any prohibited claims carried in directly
