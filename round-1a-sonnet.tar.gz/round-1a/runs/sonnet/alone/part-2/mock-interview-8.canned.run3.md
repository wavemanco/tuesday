I'll read the reference files before building the pack.
Dara, your prep pack is saved as `ashgrove-credit-union_member-experience-lead_interview_pack.md`. I built it as a three-round loop from the recruiter's email: A is the recruiter screen, B is the Head of Member Services, and C is the branch-manager panel. It runs from your message alone, with no CV and no interviewer names, so the persona weights come from the round types.

Each round has its own persona weights, question bank (8 to 11 questions) and reverse questions. There is also a fit snapshot against the JD, a values cheat sheet for the panel, and a list of claims the pack won't coach.

- **Highest-ROI prep:** B1, the jump from one branch's complaints log to a role across every branch and the contact centre. It also holds your two stated gaps, no contact-centre experience and no presenting above regional level, with a plain acknowledgment and a plan for each.
- **Values:** none of your sentences carries a story for the four values, so the cheat sheet gives a selection scaffold for each. If none of your real examples fits, the scaffold says so plainly.
- **Research:** I sent no searches. The JD, the pasted values, the recruiter's email and your strategy points already cover what the pack needs.

Say the word and I'll play the Skeptic on B1. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Loop mode, three rounds on 26 November 2026: A is the recruiter screen (30 minutes), B is the Head of Member Services, your future manager (45 minutes, mostly behavioural), C is a panel of two branch managers (60 minutes, with a 20-minute complaint-escalation case, and the values round). Interviewer names are not yet assigned. Built from your message; no CV was supplied.

Highest-ROI prep in the pack: question B1, the jump from one branch's complaints log to a role across every branch and the contact centre. Do it first and most often.

## How to use this pack

Personas say how a question arrives; types say what is being scored. Guidance is scaffolding for a spoken answer, not a script. Where guidance says "answer slot", it is an instruction for the interview: answer from your own experience, or say plainly the thing was not yours, and never rehearse a detail you cannot repeat under a second question.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether your experience survives scrutiny, and what was actually yours |
| JD | The stated responsibilities and requirements, gaps included |
| CO | How well you know the company's strategy and competition |
| CASE | A live problem from the role, structured aloud |

Labels: `[grounded]` traces to a document you gave me, `[inferred]` is derived from one with the derivation named, `[generic]` is a role-family pattern with no claim about Ashgrove or you.

## Fit snapshot

Shared across all three rounds. Evidence cells hold your own sentences and nothing else.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says one branch's log and a script for new tellers, not the process across branches, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what sat around the log likely. If any part of the log or the script was yours to set, say which and how you decided, in your own words; if none was, or it was not yours, say so plainly and stay with the log and the script |
| F2 | "and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The words stay at the quote's scope: "I built the monthly complaints spreadsheet our regional manager uses." Your material does not show what the spreadsheet held. Answer slot: the JD's reporting line makes a probe on what it held each month likely. Say what it held, in your own words; if you do not know all of it, say so plainly and describe what you do know |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message; "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | transferability | Your material says new tellers, and the words stay there: "trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on who you have coached likely. Say who they were and what you did with them, in your own words; if you did not coach beyond the tellers, say so plainly and stay with the tellers |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent here. Answer slot: expect a probe on any work alongside a digital or product team. If you have some, say what it was and which part was yours, in your own words; if you have none, say so plainly and say how you would approach it, as a plan and never as a past |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap in years, but a one-line claim with nothing inspected behind it, so expect a probe on what the six years held. Lead in the quote's own terms: six years in retail banking, the last three as a branch supervisor |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | discovery | A formal complaints log touches the requirement; your material does not say what rules the log was kept to. Words at the quote's scope: "I handled the branch's formal complaints log." Answer slot: the JD's wording makes a probe on what rules the log was kept to likely. If you know them, say what they were and how you worked to them; if you do not know, or there were none you worked to, say so plainly and stay with the log you handled |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't presented to anyone above regional level." Then how you would prepare, said as a plan and never as a past |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your material says spreadsheet, not Excel, and the words stay at "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names Excel, so expect a probe on the tool. If it was built in Excel, say so; if it was another tool, say so plainly and name it |

No row is a gate: the JD states no authorization, licence, location or pay term, and its four-years line is experience, which keeps its own tier.

## Grounding brief

Company facts you supplied, in rows. The strategy brief is dated July 2026, four months before the loop; nothing in your material contradicts it.

| Item | What it says | Provenance | Where it bites |
|---|---|---|---|
| Size and ownership | Member-owned, about 900 staff | [grounded] | Tone: members are owners, which the values lean on |
| Digital shift | Move 40% of member service to digital channels by 2028 | [grounded] | A8, B6; JD's self-service line (F5) |
| Branch hubs | Consolidate eight branches into five hubs over 2027 | [grounded] | C3, C-round panel of branch managers; the pack does not know which branches |
| Small-business lending | New product launching Q1 2027 | [grounded] | A light touch: know it exists; ask whether complaints will cover it |
| Competition | Main pressure is app-only banks | [grounded] | B6; a reason digital complaint journeys matter |

## Round A: recruiter screen (30 minutes)

Persona weights, with reasoning:

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly, short, scored on economy and logistics | High: the recruiter screen's relationship prior, and the email names a 30-minute conversation with the recruiter | A 90-second arc for the journey question; treat casual questions as scored |
| Skeptic (light) | Knockout checks on the biggest gap | Medium: relationship prior, and the JD names the contact centre while your message says you have not worked in one | Say the one-line acknowledgment and the plan, calmly, once |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through your journey in retail banking." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F6 in about 90 seconds: six years in retail banking, the last three as a branch supervisor. Then the two things you did beside complaints, each at its own scope: you handled the branch's formal complaints log and trained new tellers on the escalation script; you built the monthly complaints spreadsheet your regional manager uses. Stop there and add no stages between | The four-years line is the recruiter's first screen and F6 carries it; EXP because it scores what the years held |
| A2 | "What made you look at Ashgrove, and at this role?" | CO | [grounded] | Your own reason, in your own words; the pack supplies none. If you anchor it in something Ashgrove published, pick one thing you actually care about from the values or the strategy brief, and say why it matters to you | Motivation consistency is the recruiter's main non-logistic probe; CO because a specific, current reason beats a general one |
| A3 | "What's behind the move?" | EXP | [generic] | Logistics slot: give your actual reason for leaving, in your own words. Say it the way you would say it to your future manager | The reason for leaving is asked at every recruiter screen; EXP because it concerns your own path |
| A4 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period. Nothing here supplies a figure | Pay, notice and location are the recruiter's knockout logistics; JD because it is a term of the listed job |
| A5 | "What salary are you looking for?" | JD | [generic] | Logistics slot: give your own figure, or ask what the role's band is first and say you would like to hear it. The JD states no pay, so the pack names none | Same logistics rule as A4; guarding against an unforced figure |
| A6 | "Where are you based, and how do you feel about travelling between sites?" | JD | [inferred] | Logistics slot: give your own constraints, in your own words. Derived from the JD's "across branches and the contact centre", which implies more than one site | Location is a standing recruiter check; the travel angle comes from the JD's scope line |
| A7 | "This role covers the contact centre as well as branches. What's your exposure there?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Hold the stated limit plainly: "I haven't worked in a contact centre." Then a plan, in your own words: who you would sit with and what you would ask to see first. Add no past you did not state | F2 is a stated gap and the likeliest knockout in a screen; JD because the contact centre is in the JD's first line |
| A8 | "What have you read about where Ashgrove is heading?" | CO | [grounded] | Bring one point from the brief to show you read it, such as the 40% digital goal by 2028, the move from eight branches to five hubs, the small-business lending launch in Q1 2027, or app-only banks as the main pressure. Then one view of your own, put as a question you would want answered rather than a fact | The brief is shared, so reciting it scores as homework; one point plus one divergence scores as judgment; CO because it tests altitude |

Reverse questions for Round A:

| # | Question | Why it lands |
|---|---|---|
| RA1 | "How is the complaints process owned today across branches and the contact centre, and what is this role changing?" | It goes to the JD's end-to-end line and shows you think in ownership terms |
| RA2 | "The brief sets a 40% digital goal for 2028. Which part of that does this role touch first?" | It joins the JD's self-service line to the strategy |
| RA3 | "Has anything in the July brief moved since it was published?" | Checks freshness of the one source the pack leans on, and signals you read it |

## Round B: Head of Member Services, your future manager (45 minutes)

Persona weights, with reasoning:

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the scope jump and the two stated gaps | High: relationship prior for a hiring manager, and F1, F2 and F8 give a lot to probe | Rehearse B1 until it is boring; hold the quote, concede the limit, give a plan |
| Values / Behavioral | Open "tell me about a time" prompts | High: the recruiter's email says this round is mostly behavioural | Selection scaffold per prompt, each ending in the honest branch |
| Data-Driven Prober | Line-by-line on the log and the spreadsheet | Medium: your two concrete artifacts are both reporting-shaped | Know what you can and cannot say about each; say where your knowledge stops |
| Case / Strategist | A live digital-journey problem | Medium: hiring-manager prior, tempered by the recruiter's "mostly behavioural" | Clarify, structure, think aloud |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role owns complaints across every branch and the contact centre. You handled a branch's formal complaints log. What's the jump for you, and how would you make it?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "Never worked in a contact centre, and I've never presented to anyone above regional level." | The deepest rehearsal in the loop. Hold the quote at its own scope: you handled a branch's formal complaints log and trained new tellers on the escalation script. Name the limit before it is asked: "I haven't worked in a contact centre." Then the plan, in your own words: what you would learn first and from whom. Follow-up 1, on what else around the log was yours. Answer slot: if any part of the log or the script was yours to set, say which and how you decided; if none was, or it was not yours, say so plainly and return to the log and the script. Follow-up 2, "so the contact centre is new?": "I haven't worked in a contact centre," then the plan, without folding on the log. Follow-up 3, on the senior team: "I haven't presented to anyone above regional level," then how you would prepare. Hold by returning to the quote, never by adding to it | F1, F2 and F8 are the widest distance between what the role asks and what the material shows, and this interviewer would carry the decision about that gap as your manager; JD because it scores the stated scope, Skeptic in delivery |
| B2 | "Walk me through how you handled your branch's formal complaints log." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F7: you handled the log, and you trained new tellers on the escalation script, which are the beats the sentence states; tell them in your own words. Answer slot: the JD's wording makes a probe on what rules the log was kept to likely. If you know them, say what they were and how you worked to them; if you do not know, or there were none you worked to, say so plainly and stay with the log you handled | F7 is where the JD presses hardest on evidence that touches the requirement without showing it; EXP because it tests what was actually yours |
| B3 | "How much of that monthly complaints spreadsheet was actually you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Hold the sentence through two follow-ups: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if anyone else contributed, say who and what they did; if nobody did, say so plainly. Concede only where your knowledge stops, and say exactly where | F3 and F9 both rest on this one sentence, so attribution is the likeliest probe; EXP because it is attribution, delivered under pressure |
| B4 | "What did the spreadsheet show each month, and who used it?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say what you can from the sentence: monthly, about complaints, used by your regional manager. Answer slot: the JD's reporting line makes a probe on what it held likely. Say what it held, in your own words; if you do not know all of it, say so plainly and describe what you do know. On the tool: if it was Excel, say Excel; if it was another tool, name it plainly | F3 and F9 are the JD's reporting and Excel lines; JD because it scores both stated requirements together |
| B5 | "Tell me about a time you coached someone through an escalation." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Open prompt, theme from the JD's coaching line. Story-mapped on F4: new tellers, and the escalation script, which are the beats the sentence states. Answer slot: the JD's coaching line makes a probe on who you have coached likely. Say who they were and what you did with them, in your own words; if you did not coach beyond the tellers, say so plainly and stay with them. Add no teller mistake and no result you did not state | F4 is the closest evidence for the coaching line; EXP because it scores what you did |
| B6 | "Ashgrove wants 40% of member service on digital channels by 2028. Sketch how you'd want complaints to work in that world, and what you'd need to know first." | CASE | [grounded] | No claim about your past, so none is made. Clarify first: what counts as service moved, and which complaint types already arrive digitally. Then objective, segments by channel and complaint type, approach, metrics, risks, thinking aloud. For metrics use the volumes and resolution times the JD says you will report on. Risks to weigh: members who cannot or will not go digital, the hub consolidation, app-only competitors. Challenge one premise respectfully, such as whether 40% counts members or volume. Say it in plain words, which is one of their values | The strategy brief and the JD's self-service line meet here; CASE because it is a live problem from the real role |
| B7 | "Tell me about a time you worked with a digital or product team on something members would use." | EXP | [grounded] | Open prompt, theme from the JD's digital line. None of your sentences carries a story here, so this is a selection scaffold: choose a time you worked beside a team that built or changed something members use, with a named problem, your own part, and what changed for members. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach it | F5 has no evidence in your material; EXP because it scores what you did, and the scaffold keeps the honest branch open |
| B8 | "What's your experience presenting to senior leaders?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Hold-then-concede: "I haven't presented to anyone above regional level." Then your own plan for how you would prepare and what feedback you would ask for. Do not claim ease, and add no occasion you did not state | F8 is a stated gap and the JD names the requirement; JD because it scores it directly |
| B9 | "When did you put a member ahead of an internal metric?" | VAL | [grounded] | Open prompt from the Members First value. No sentence of yours carries this story, so choose one with a named decision, a cost to you or the branch, and an outcome you can state without embellishing. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Behavioural round, and the first value is the likeliest theme; VAL because it scores values, not generic virtue |
| B10 | "Tell me about a time you delivered an unpopular truth to someone senior." | VAL | [generic] | Selection scaffold: a named stake, a moment you did not fold, and a relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioural stem for a manager round; VAL because it scores candour with seniors |
| B11 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pick the one you would honestly name from what you have said: the contact centre, or presenting above regional level. The pack does not pick for you. Name it plainly, then the plan | F2 and F8 are the answers this question invites; JD because it is the Skeptic's standard probe on the listed job |

Reverse questions for Round B:

| # | Question | Why it lands |
|---|---|---|
| RB1 | "What does good look like for this role at six months, and what would you want from my first monthly report?" | Ties to the JD's monthly reporting line and asks your manager to define the measure |
| RB2 | "How does the contact centre handle complaints today compared with the branches?" | Moves straight to the gap you have named, and shows you want to learn it |
| RB3 | "Which parts of the 40% digital goal are decided and which are still open?" | Brings the strategy brief into a working question |
| RB4 | "What would you want me to learn from you in my first month?" | Invites your manager to teach; signals coachability |

## Round C: panel of two branch managers, values round, with a 20-minute case (60 minutes)

Persona weights, with reasoning. Names are not assigned, so weights are for the panel as a whole:

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scored against the four published values | Highest: the recruiter's email says the panel is the values round and scores against the four values | One question per value; selection scaffold each, with the honest branch |
| Case / Strategist | The 20-minute complaint-escalation case | High: the email names a 20-minute case on an escalation | Clarify, structure, one challenged premise, think aloud |
| Peer Evaluator | What the hire does to their branch | Medium: branch managers are the supervisors' managers, so the role touches their branches | Reciprocity: what you bring, what you need; propose principles rather than pretend to know the seam |
| Skeptic | The contact centre and scope jump again | Medium-low: it returns from Round B in collegial packaging | Same one-line acknowledgment, same plan |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A member has raised the same fee complaint at their branch three times. The supervisor has logged it as a formal complaint and it is still open. The member now says they will go to the contact centre and outside Ashgrove. You have twenty minutes: what do you do?" | CASE | [generic] | No claim about your past. Structure aloud: ask first what the member has been told each time, what the fee dispute is, and what time limits apply to a formal complaint, without assuming any. Then the objective (member heard, right outcome, complaint closed properly), one named person who keeps hold of it until it is solved, actions today and this week, what you would record and report, how you would stop a third visit happening, and risks. Challenge one premise respectfully | The email says the case is on a complaint escalation and its content is unknown, so this is a pattern; CASE because it is a live problem from the role |
| C2 | "The same complaint reaches the contact centre and the branch in the same week, and the member has been given two different answers. What happens next?" | CASE | [generic] | No claim about your past. Clarify which answer is right and who gave each, then name one owner, give the member one voice, and record the cause so it cannot repeat. Speak in their words: whoever finds the problem keeps hold of it | The role spans both channels, so the seam is the likeliest case; CASE because it asks for structure, not history |
| C3 | "Eight branches are becoming five hubs over 2027. How do you stop escalations falling between sites while that happens?" | CASE | [grounded] | No claim about your past. Clarify the timetable, which sites, and who owns complaints during handover. Then principles: one owner per complaint across the move, a handover rule, and what each town keeps. Ask rather than guess which branches are affected | Panel members may work in branches that change; CASE with CO content because it uses the brief's own numbers |
| C4 | "A branch supervisor escalates every complaint to you the day it arrives. How do you coach them?" | CASE | [generic] | No claim about your past. Diagnose before prescribing: ask what they are worried about and what they are missing. Agree together where their own authority ends, practise on live cases, and check back. Say it as the approach you would take | The JD's coaching line, asked as a live problem; CASE because it presupposes nothing about you |
| C5 | "Tell me about a time you decided something from the member's side of the counter when that was the harder choice." | VAL | [grounded] | Open prompt from the Members First, Always value. No sentence of yours carries this story, so choose one with a named decision, who disagreed, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The first value, asked in its own wording; VAL because the scoring sheet is the four values |
| C6 | "Tell me about a time a member needed something explained more than once. What did you change?" | VAL | [grounded] | Open prompt from the Plain Words value. No sentence of yours carries this story, so choose one where you can name what was unclear and what you did differently. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The value's own test is "if a member needs it explained twice, we wrote it wrong"; VAL because it scores that specific value |
| C7 | "Tell me about a time local knowledge of a community changed how you handled something." | VAL | [grounded] | Open prompt from the Neighbours, Not Numbers value. No sentence of yours carries this story, so choose one with a named local factor and a decision it changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Branch managers will weigh this value heavily, and the hub plan sharpens it; VAL because it scores that specific value |
| C8 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Open prompt from the Own the Fix value. No story is carried by your sentences, so choose one with a named problem, the moment it could have passed to someone else, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: "I handled the branch's formal complaints log." | The role is itself to own the process, so this is the value closest to the JD; VAL because it scores the value |
| C9 | "As a branch manager I'll have supervisors and members in front of me. What do I get from you, and what will you need from me?" | JD | [grounded] | Reciprocity, said as principles and not as a past: a clear route for escalations, agreement on where branch decisions end and escalations begin, and honest early warning; and from them, time with their supervisors and candour about where it is not working. Propose the seam; do not pretend to know it | The Peer Evaluator's core probe, and the JD's coaching line seen from the branch; JD because it scores the working relationship the role needs |
| C10 | "You come from a branch. How would you win over a contact centre team who don't know you?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "Never worked in a contact centre, and I've never presented to anyone above regional level." | Open with the limit: "I haven't worked in a contact centre." Then a plan in your own words: listen before you change anything, and learn how they work from them. Claim no past with that team | F2 again in collegial packaging; JD because the contact centre is in the JD's first line |
| C11 | "Sixty seconds: why you, rather than someone who has run a contact centre?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "Never worked in a contact centre, and I've never presented to anyone above regional level." | Three beats in 60 seconds. What you did, at its own scope: you handled the branch's formal complaints log and trained new tellers on the escalation script. The limit: "I haven't worked in a contact centre." Then what you would do about it. Hold through two follow-ups by returning to the first beat, never by widening it | The Pressure stem aimed at F1 and F2; JD because it scores fit against the stated job, with hold-then-concede in delivery |

Reverse questions for Round C:

| # | Question | Why it lands |
|---|---|---|
| RC1 | "What could a new complaints lead do in their first month that would genuinely help your branch?" | Reciprocity: it asks what you can do for them |
| RC2 | "What happens today when one of your supervisors escalates a complaint?" | Gets the panel talking about their own experience of the process |
| RC3 | "As the hubs take shape, what would you most want kept the same for members in your town?" | Speaks to Neighbours, Not Numbers in their terms |
| RC4 | "Which of the four values is hardest to live up to on a busy day, and what does it look like when someone does?" | Invites stories and shows you take the scoring seriously |

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| "Own the member complaints process end to end across branches" | B1, B2, C1, C2, C3, C11 |
| "and the contact centre" | A7, B1, B11, C2, C10, C11 |
| "report monthly on complaint volumes and resolution times" | B3, B4, B6 |
| "coach branch supervisors on escalations" | B5, C4, C9 |
| "work with digital teams on self-service journeys" | B6, B7 |
| "4+ years in financial-services customer operations" | A1 |
| "experience handling regulated complaints" | B2, C1 |
| "confident presenting to senior leaders" | B8, B1 |
| "comfortable with Excel reporting" | B3, B4 |

## Values cheat sheet

Belongs to Round C, the round the recruiter says scores against the four values. Names are as published on the page you copied on 17 November 2026.

| Value (official name) | Working meaning | Your mapped story or scaffold | Questions |
|---|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No sentence of yours carries a story. Scaffold: a decision where the member's side cost something, with who disagreed and how it ended. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | C5, B9 |
| Plain Words | If a member needs it explained twice, the wording was at fault | No sentence of yours carries a story. Scaffold: a time you changed wording because a member needed it twice. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | C6 |
| Neighbours, Not Numbers | Treat every branch as part of its town, not a line on a report | No sentence of yours carries a story. Scaffold: a time local knowledge changed a decision. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | C7, RC3 |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." is the nearest your material carries, and it shows the log, not a fix kept to the end. Scaffold: a problem you kept hold of past the point it could have passed on. If none comes to mind, say so plainly, then give the log at its own scope | C8, C2 |

Reading, not finding: the role reports numbers monthly while one value says "Not Numbers", so expect the panel to test whether you can hold both.

## Prohibited claims

What this pack will not coach, with basis and the honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says one branch's log and a script for new tellers, not the process across branches. Slots stay inside the log and the script |
| Has worked in a contact centre | Negative you stated, F2 | The plain acknowledgment: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment: "I haven't presented to anyone above regional level." No slot |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: new tellers and the escalation script. B5's slot asks only who you coached |
| Handled complaints under regulator rules | Inflated form of F7 | F7's quote at its own scope: the branch's formal complaints log. The limit is the pack's observation: your material does not say what rules it was kept to |
| Reported complaint volumes and resolution times to leaders | Inflated form of F3 | F3's quote at its own scope: the monthly spreadsheet your regional manager uses. The slot asks only what it held |

## Sources

Provided: the JD text, the values text you copied on 17 November 2026 from ashgrovecu.org/about/values, the recruiter's email on the three rounds, the strategy points you relayed from the July 2026 brief, and your message about your background. No searches or fetches were sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove values` | skipped | The pasted values text is in hand and fixes the cheat sheet |
| 2. `Ashgrove interview process member experience` | skipped | The recruiter's email gives sessions and who runs each; it fixes the loop and persona weights |
| 3. `Ashgrove strategy` / recent news | skipped | The four strategy points you relayed, dated July 2026, fix the CO and CASE questions |
| 4. `{interviewer name} Ashgrove` | n/a | No interviewer name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD questions |

## Upgrade menu

- Interviewer names and titles, once assigned → an interviewer read, persona weights read from their public footprint, and reverse questions tied to their paths
- One real example per value, in your own words → the four scaffolds in the cheat sheet and C5 to C8, B9 and B10 become mapped stories
- Whether the log's entries followed external rules, and what you know of them → F7 rises from `low` and B2's slot gets a real answer
- What the monthly spreadsheet held and the tool it was built in → F3 and F9 move from `discovery` and B3 and B4 firm up
- Whether any coaching reached beyond new tellers → F4's slot is answered and B5 gets a story map
- Any work you did beside a digital or product team → F5 and B7 move off silence
- An anonymised copy of the spreadsheet's layout or a report it produced, with member data removed → F3 and F9 can rise from `medium`
- The recruiter, in one email: the case's format and whether materials come in advance → C1 to C4 can be narrowed to the real case
- Hours you can prep per day between now and 26 November → a prioritised schedule
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, for the strategy brief, recent organisation context and loop reports → the CO and CASE rows become less dependent on your four relayed points
- A `tuesday-dossier.md` from an earlier evaluation of this role, if you have one → verified evidence and a named deepest-rehearsal objection in place of this pack's inferred one
