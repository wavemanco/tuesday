I'll read the reference files the skill requires before building the pack.
I've saved your prep pack and checked it against the template. It's built for a round and interviewer you don't know yet, so the persona weights are generic.

My three company-research searches were refused (search permission wasn't granted in this session). So the pack has no Atlas Freight values, loop structure or strategy, and it makes no claims about the company beyond your JD. The Sources section lists the three refused searches.

The full pack is saved at `/var/tmp/tuesday-measure/1a/runs/sonnet/alone/part-2/rooms/case-2-denied-1a7b6521/atlas-freight_operations-manager_interview_pack.md`. It has 23 questions, a fit snapshot against the JD, reverse questions and a list of claims it won't coach.

- **The gap to rehearse first:** your material says 3 supervisors, and the JD says 12 across 4 sites. Question A1 is the one to practice until it feels boring. I inferred it from your material, not from anyone at Atlas.
- **Power BI:** you said you've never used it, so the pack coaches you to say that plainly and follow with a learning plan. Questions A4, D3 and G2 cover it.
- **The 40% mis-pick cut:** it's the one number you gave, so questions B1 and B2 drill how it was counted and how much was you.
- **Answer slots:** where the JD asks for something your material doesn't show (terminal work, on-time and cost tracking, how many years were spent leading people), the pack leaves a slot. You answer from your real experience or say plainly it wasn't yours.

Say the word and I'll play the skeptical hiring manager on A1 and push back live. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions. If you'd like the pack as a Word document, I'll convert it.

Do you know the round type (recruiter screen, hiring manager or panel), and has the recruiter mentioned any focus areas or something to prepare? That would reweight every question bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

Interviewer: not known. Round type and relationship: not known, so persona weights rest on a generic screen, hiring-manager, panel pattern and are flat-ish. They are not read from this company's documented process.

## How to use this pack

- Personas describe how a question is asked. Types describe what is being scored.
- Type key: **VAL** is behavioral or values alignment. **EXP** is a work-experience deep-dive. **JD** is a stated role requirement. **CO** is company and strategy knowledge. **CASE** is a live problem from the role.
- Guidance is scaffolding, not a script. Say it in your own words.
- An answer slot is an instruction for the interview, not a question for you now. Answer it from your own experience, or say plainly that the practice was not yours or did not exist, then return to a fact you can stand behind.
- The single highest-ROI rehearsal in this pack is **A1** (the jump from 3 supervisors to 12 across 4 sites). It is inferred from the fit snapshot, not reported by anyone at Atlas Freight. Start there.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material says warehouse and distribution operations and a senior shift manager role, not terminals and not four sites, and the words stay there: "I'm a senior shift manager over 3 supervisors, with 7 years in warehouse and distribution ops." Answer slot: the JD's four sites and terminal wording make a probe on scope likely. If any of your work reached beyond your own shift, or touched terminal operations, say what it was and what part was yours, in your own words; if none did, or it was not yours, say so plainly and stay with the shift you run |
| F2 | "drive on-time performance" — JD | none given | none | [grounded] | discovery | Your material does not show on-time performance. Answer slot: if any of your work was tracked against on-time measures, say what was tracked and what part was yours, in your own words; if none was, say so plainly and say what you would measure first |
| F3 | "cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Your material says mis-pick rate, not cost per shipment, and the words stay there: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if any cost was counted at your site, say what was counted and what part was yours; if no cost was tracked, or it was not yours, say so plainly and stay with the mis-pick rate |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material says 3 supervisors and the words stay at that number: "I'm a senior shift manager over 3 supervisors." Answer slot: the JD's 12 makes a probe on span of control likely. If you have led or coordinated more supervisors than those 3, in any role, say how many and what part was yours; if not, say so plainly and stay with the 3 |
| F5 | "build reporting in Excel/Power BI" — JD (Excel half) | "solid Excel" — your message | low | [grounded] | discovery | Your material says Excel skill, not reports built. Answer slot: if you built reports in Excel, say what they covered and who used them, in your own words; if you used Excel in other ways, or built no reports, say so plainly |
| F6 | "build reporting in Excel/Power BI" — JD (Power BI half) | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used Power BI." Then how you would learn it, said as a plan and never as a past. Never a claim to Power BI work, and nothing added to make the gap feel smaller |
| F7 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message | medium | [grounded] | discovery | Not a gate: it is a length-of-experience requirement. Your material says seven years in operations, not how many of them were spent leading people. Answer slot: the JD's "5+ years operations leadership" makes a probe on that split likely. Say in your own words how many of the seven years were leading people; if fewer than five, say so plainly and say what the other years were |
| F8 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | The quote already reaches the plus: "I'm green belt certified." It does not say what was applied, so expect a probe on that, answered only by what you actually did |

## Persona table

Loop structure for Atlas Freight is not established (research was refused, see Sources), so this is the generic screen, hiring-manager, panel archetype with a flat tilt. If you learn the round type, the weights change.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Quiet probing of scale, terminal experience and tooling | High. F1, F4 and F6 show gaps on the face of the JD, so this persona has the most to work with | Rehearse A1 until it is boring: say what the quote carries (F4: "currently a senior shift manager over 3 supervisors"), concede the size difference plainly, give a plan |
| Data-Driven Prober (B) | Reads your headline number to its assumptions; asks for cost and on-time figures | High. The JD is metric-driven (on-time, cost-per-shipment) and F3 carries the one number you gave | Know what you can and cannot say about how the figure was counted: "cut mis-pick rate 40% by redesigning the pick path" (F3); say plainly when you do not know |
| Case/Strategist (C) | Live problems on running four terminals | Medium-high. A hiring manager for an operations-ownership role tends to test live decisions | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Conversational (D) | Friendly biography and tools questions | Medium. Early rounds often open this way; casual questions about Excel and Lean are still scored | A 90-second arc built only from your own sentences; treat casual tool questions as scored |
| Peer Evaluator (E) | Seam-splitting between sites and shifts, credit-sharing | Medium. You would sit beside four site peers; the JD does not say who interviews | Offer seam principles instead of pretending to know the seam; reciprocity framing |
| Pressure (G) | Time-boxed, devil's advocate | Low-medium. Possible at a skip-level or final round; nothing here signals it | Pause, restate, hold through two follow-ups, concede specifically |
| Values/Behavioral (H) | Published-values scenarios | Low. No values-style round is detected: no loop source was read, and the generic archetype reads no | Two selection scaffolds only, because the persona's stems may still arrive |

## Question banks

### A. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You oversee three supervisors today. This role has twelve across four sites. What is the biggest difference between what you run and this job?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI rehearsal in this pack. Hold what the quote carries: "I'm a senior shift manager over 3 supervisors." Name the difference plainly: the JD says 12 and four sites, and your material says 3. Answer slot: if you have led or coordinated more supervisors than those 3, in any role, say how many and what part was yours; if not, say so plainly and stay with the 3. Then give a ramp plan as a plan, never a past: what you would ask each site lead and look at in your first weeks, in your own words. Hold through two follow-ups by returning to the 3, never by adding to it | F4 is the widest gap between the JD and your material, so this objection arrives in some form in nearly any round. JD because it scores the stated requirement |
| A2 | "Your background is warehouse and distribution. What do you not know yet about terminal operations?" | JD | [grounded] "7 years in warehouse and distribution ops" | Start with the quote at its own scope: "I have 7 years in warehouse and distribution ops." Answer slot: the JD says terminal operations. If any of those years touched terminal work, say what it was and what part was yours; if none did, say so plainly. Then say what you would want to learn first as a plan, in your own words | F1 is where scope and setting both differ from the JD. JD because it scores a stated requirement, and the probe is on the gap |
| A3 | "The JD asks for five or more years of operations leadership. How many of your seven years were leading people?" | JD | [grounded] "7 years in warehouse and distribution ops" | Answer slot: give the number in your own words. If fewer than five of the seven were leading people, say so plainly and say what the other years were. If five or more, say what the role was in each case, in your own words. Do not round up | F7 is a stated, titled-years requirement and is likely screened literally. JD because it tests a listed qualification |
| A4 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "solid Excel, never used Power BI" | Pick your own honest answer; the material shows two candidates. The one you have stated: "I've never used Power BI." Follow it at once with your plan for learning it, in your own words and with no past claimed. The other candidate is the size of the team (A1); choose whichever you would actually say | F6 is a stated negative, so naming it first converts a gotcha into candor. JD because it is the standard weakness probe on the role's own list |
| A5 | "Why are you leaving your current role, why Atlas Freight, and why now?" | EXP | [generic] | Give your actual reason in your own words, and one concrete thing about the job as the JD states it (daily terminal operations across 4 sites, on-time performance, cost-per-shipment). If no real reason comes to mind for leaving, say so plainly and give what pulls you toward this role. Say nothing about the company that the JD does not say | The skeptic's motivation-consistency check, and the one question every round asks. EXP because it tests whether your story holds together |

### B. Data-Driven Prober (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say the sentence at its own scope: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: in your own words, say how the figure was counted, what it is sensitive to, the assumption you would defend least, and what part was yours. If you do not know how it was counted, say so plainly. Never explain a method you cannot repeat under a second question | F3 carries your only number, so a prober starts here. EXP because it tests whether the CV claim survives scrutiny |
| B2 | "How much of that redesign was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Quote at scope. Answer slot: if others contributed to the pick-path redesign, say who and what they did; if it was yours throughout, say so plainly. Hold the sentence through two follow-ups; concede only the specific part that was not yours | F3 again, as an attribution probe, which is the most common way that number is tested. EXP because it scores attribution honesty |
| B3 | "The JD asks you to drive cost-per-shipment down. What have you measured about cost?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Start from the quote: it speaks of mis-pick rate. Answer slot: if any cost was counted at your site, say what was counted and what part was yours; if no cost was tracked, or it was not yours, say so plainly and stay with the mis-pick rate. Then say what you would measure first as a plan | F3 is adjacent to the JD's cost-per-shipment line and does not reach it. JD because it scores a stated requirement |
| B4 | "What did you track on on-time performance at your site?" | JD | [grounded] "ran the site's peak-season surge plan two years running" | Quote at scope: "I ran the site's peak-season surge plan two years running." Answer slot: the JD names on-time performance, so expect a probe on whether the surge plan was measured against it. If it was, say what was counted and what part was yours; if no such measure existed, say so plainly and say what you would track first | F2 has no evidence in your material, and the surge plan is the nearest thing it carries. JD because it scores a stated requirement |

### C. Case/Strategist (weight: medium-high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You take over four terminals on Monday. What do you need to know first, and what do you do in your first two weeks?" | CASE | [generic] | Clarify first: what the JD's own two measures, on-time performance and cost-per-shipment, look like at each site today and how they are reported. Then objective, segmentation by site, approach, metrics, risks. Think aloud; challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | The daily-ownership line of the JD asked as a decision (F1's requirement). `[generic]` because it is a pattern, not a fact about this employer |
| C2 | "On-time performance at one of your terminals drops eight points in a month. Diagnose it." | CASE | [generic] | Clarify what counts as on-time, over which lanes and shifts, and when it started. Form hypotheses by stage, say which data would separate them, and name the first thing you would check. Say your structure aloud before using it | F2's requirement as a live problem, so the answer does not depend on past experience you may not have. CASE because it scores structure |
| C3 | "Cost-per-shipment is flat and on-time is slipping. You cannot add headcount. What do you do?" | CASE | [generic] | State the trade-off, ask what has changed, pick the lever you would pull first and name the risk of pulling it. Challenge one premise, for example whether the two measures are moving for the same reason | F2 and F3 together, since the JD asks for both. CASE because the trade-off is the point |
| C4 | "Peak season hits two of your four sites at once. How do you plan for it?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Structure it first, as a live problem. If asked about your own experience, the beats are the ones the quote states: the site's peak-season surge plan, run two years running, told in your own words. Anything further about what that plan contained or achieved is what the interviewer will ask next, so decide beforehand what you can say about it truthfully | F1's four-site scope applied to the one operational story you gave. CASE with EXP content, because the quote makes it your strongest live-problem anchor |

### D. Conversational (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | A 90-second arc using only these sentences: the seven years, the current role, the pick path, the surge plan, the certification, then why this role. Answer slot: your material does not show the roles between the start and now; fill them in your own words, or say there were none to add | The biography question is scored, and F1, F3 and F8 all enter through it. EXP because it tests whether the CV arc is coherent |
| D2 | "What are you actually playing with in Lean or Six Sigma these days?" | JD | [grounded] "green belt certified" | Say "I'm green belt certified." Answer slot: the JD marks Lean/Six Sigma a plus. If you have applied it, say where and what you did, in your own words; if the certification is the extent of it, say so plainly | F8 is the plus; the probe is on what sits behind the certificate. JD because it is a listed, if optional, requirement |
| D3 | "You mention solid Excel. What do you use it for?" | JD | [grounded] "solid Excel" | Say "I'm solid in Excel." Answer slot: the JD asks to build reporting in Excel and Power BI. If you built reports, say what they covered and who used them; if you used Excel in other ways, or built none, say so plainly. Then, if Power BI comes up: "I've never used Power BI," and your plan | F5 and F6 together: the one tool you have and the one you stated you lack. JD because it scores the listed tools |

### E. Peer Evaluator (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our four sites run side by side. When one is backed up and another has slack, where is the seam, and what happens when two site leads disagree?" | CASE | [generic] | Offer seam principles instead of claiming to know the seam: who decides, on what data, how fast, and what gets escalated. Add what you would need from the other site leads, and what you would bring them. The question needs no claim about your past, so the guidance makes none | F1's four-site scope as a collaboration problem. CASE because it is a live seam decision |
| E2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Quote at scope. Answer slot: if others contributed to the pick-path redesign, say who and what they did, in your own words; if it was yours throughout, say so plainly. Credit by naming what each person did | F3 is your one result, so it is where credit-sharing gets tested. EXP because it scores attribution under collegial packaging |
| E3 | "How do you decide what your supervisors handle themselves and what comes to you?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Quote at scope: "I'm a senior shift manager over 3 supervisors." Answer slot: if you set a rule or habit for this, say what it is, in your own words; if there was none, or it was not yours, say so plainly and describe how you worked with the 3. Then say how you would adapt it for 12 as a plan | F4's team-leadership requirement as a day-to-day question. JD because it scores the leadership line |

### G. Pressure (weight: low-medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over a candidate who has run more sites?" | JD | [grounded] "7 years in warehouse and distribution ops"; "ran the site's peak-season surge plan two years running"; "cut mis-pick rate 40% by redesigning the pick path" | Pause, restate the question, then use only what these sentences carry, in your own words. Hold through two follow-ups. Concede specifically: the JD asks for four sites and 12 supervisors, and your material says 3 supervisors. Do not fold on what you did to restore harmony | F1 and F4 under time pressure. JD because the content is the role's scale requirement; Pressure because of the delivery |
| G2 | "You've said you've never used Power BI. This job builds reporting in it. Is that a problem?" | JD | [grounded] "solid Excel, never used Power BI" | Hold: "I'm solid in Excel." Concede plainly: "I've never used Power BI." Then give your first learning step as a plan, in your own words, with no past claimed. Do not minimize | F6 is a stated negative, so the concession is sourced. JD because it scores the listed tool |

### H. Values/Behavioral (weight: low)

Atlas Freight's published values are not in hand, so these two use the persona's stems and stay generic.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not soften the message, and a relationship that was intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A stem this persona commonly uses. VAL because it scores behavior against a value, not a number |
| H2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where the two pulled apart, with what you chose and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A stem this persona commonly uses, and a natural fit for a freight role. VAL for the same reason |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "Own daily terminal operations across 4 sites" | A1, A2, C1, C4, E1 |
| "drive on-time performance" | B4, C2, C3 |
| "cost-per-shipment down" | B3, C3 |
| "lead a team of 12 supervisors" | A1, E3 |
| "build reporting in Excel/Power BI" | A4, D3, G2 |
| "5+ years operations leadership required" | A3, D1 |
| "Lean/Six Sigma a plus" | D2 |
| Company and strategy knowledge (CO) | none: no research on Atlas Freight succeeded, so a CO question would be unsourced |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Across the four sites, how are on-time performance and cost-per-shipment reported today, and which site would you want me to look at first?" | Uses the JD's own two measures and shows you are thinking about where to start, not asking for a tour |
| 2 | "Which tools does the reporting run on today, and what support is there for learning them?" | Puts the Power BI gap on the table as a plan, on your terms, before it is raised for you |
| 3 | "What would the twelve supervisors tell me needs fixing first?" | Signals you will listen to the team before changing it, and gets you the real problem list |
| 4 | "What does success look like at 90 days, and what would worry you at that point?" | Gets the measure you will be judged against, and the interviewer's own risk |
| 5 | "What is the hardest part of this seat for whoever holds it?" | Invites candor, and tells you which of A1 to A4 is the live concern |
| 6 | "What could someone new do in their first month that would genuinely help the sites?" | A reciprocity question: it frames you as adding to their load, not drawing on it |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed or ran multi-site terminal operations | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation, not words for you: the material says warehouse and distribution operations and a senior shift manager role. A2's slot stays inside that |
| Led a team of 12 supervisors, or a large leadership team | Inflated form of F4 | F4's quote at its own scope: "currently a senior shift manager over 3 supervisors". A1's slot asks only whether more supervisors than those 3 were ever led |
| Reduced cost per shipment | Inflated form of F3 | F3's quote at its own scope: "cut mis-pick rate 40% by redesigning the pick path". B3's slot asks only what was counted |
| Built reporting or dashboards in Excel | Inflated form of F5 | F5's quote at its own scope: "solid Excel". D3's slot asks only what it was used for |
| Used or built anything in Power BI | Negative you stated, F6 | The plain acknowledgment F6 gives: "I've never used Power BI." No slot |
| Has five or more years of operations leadership | Inflated form of F7 | F7's quote at its own scope: "7 years in warehouse and distribution ops". A3's slot asks only how many of those years were leading people |
| Led Lean or Six Sigma projects | Inflated form of F8 | F8's quote at its own scope: "green belt certified". D2's slot asks only what was applied |

## Sources

Provided documents: the job description text and the candidate's background, both in the user's message.

Searches sent (all refused; this session had not granted search permission):

- "Atlas Freight regional logistics company values": refused
- "Atlas Freight interview process operations manager": refused
- "Atlas Freight regional logistics terminals news strategy": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Every call was refused. Would have moved the values cheat sheet and the VAL bank; none is built and H1 and H2 are generic |
| 2. `Atlas Freight interview process operations manager` | unavailable | Every call was refused. Would have moved the loop structure and persona weights; the weights here follow the generic archetype and say so |
| 3. `Atlas Freight strategy` / recent news | unavailable | Every call was refused. Would have moved a CO question and strategy-grounded cases; C1 to C4 are generic or built from your sentences |
| 4. `{interviewer name} Atlas Freight` | n/a | No interviewer name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Operations Manager` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Round type (recruiter screen, hiring manager, panel, site visit) and who you meet → reweights every bank; weights are flat-ish now
- The interviewer's name and role → an interviewer read, persona weights from their public footprint, and a reverse question tied to their path
- Anything the recruiter said about focus areas or a deliverable (a site tour, a presentation, a case) → a build section for any graded deliverable
- Atlas Freight's careers or values page pasted in, or search permission granted → the values cheat sheet, a documented loop structure, and CO questions
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, which needs search permission to be granted first
- Your answers to the slots in F1, F2, F3, F4, F5 and F7 (scope beyond your shift, anything tracked on on-time or cost, supervisors led beyond 3, reports built in Excel, years spent leading people) → those rows move from slots to quoted evidence and the guidance firms up
- The green belt certificate (F8) and the before-and-after pick-path report (F3) → the two artifacts that could lift those rows toward `high`
- A `tuesday-dossier.md` from job-underwriter → verified evidence, per-gap strategy limits, and an evidence-derived highest-risk objection in place of the one inferred in A1
