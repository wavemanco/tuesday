I'll read the reference files the skill requires before building the pack.
Searches are back: values, loop format, strategy news and Tobias's talk all returned results. I'm writing the prep pack to a file now.
Your prep pack is saved at `/var/tmp/tuesday-measure/1a/runs/sonnet/alone/part-2/rooms/case-7-canned-cff0790b/saltmarsh-games_live-operations-producer_interview_pack.md`. It has 18 questions across six interviewer styles, plus a fit snapshot, a values cheat sheet, five reverse questions and a prep schedule for Tuesday to Thursday.

I built it for the format on Saltmarsh's careers page. Every loop is a recruiter call, then the "Outage Hour": one 60-minute interview with the hiring manager. It's a live-incident tabletop on a simulated outage, then a values conversation, with no take-home. I assumed Tobias is that hiring manager.

- **Highest-ROI prep:** question C1. You said you haven't worked on a game with in-app purchases, and Saltmarsh's Project Larkspur announcement moves both titles to a season pass from February 2027. Expect to be asked about it. The pack gives you a plain acknowledgment, what you can honestly hold onto, and follow-ups to rehearse.
- **Tobias's public footprint:** his GDC 2026 talk is "Patch Notes Are a Promise", and he was previously a QA lead. That fits Saltmarsh's published value "Ship the Patch Not the Promise" and makes your release checklist a likely line of probing.
- **Research gaps:** I read the values and careers pages in full. The Larkspur announcement and Tobias's talk page I saw only as search snippets, so reading both in full is on Thursday's list. The careers page is undated.
- **Your background:** I used only what you wrote, and the pack's answer slots mark where your own details would go. It doesn't coach you to claim leading a team, owning the KPIs or running a calendar for two titles.

Say the word and I'll play Tobias on C1, or open with the tabletop (A1). I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Two things would change the pack: did the recruiter say anything about the Outage Hour beyond the careers page, such as whether you get the scenario in advance or are scored against a rubric? And is Tobias the person you'd report to?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

- **Candidate:** Femi
- **Interviewer:** Tobias Wrenfield, Head of Live Operations
- **Round:** a 60-minute interview on Friday 20 November 2026. This pack assumes it is the Outage Hour on Saltmarsh's careers page, run by the hiring manager, and that Tobias is that hiring manager. Persona weights follow that assumption.
- **Version:** first pack, no changes yet

## How to use this pack

- **Personas are how a question is asked. Types are what it scores.** Each question carries one persona (its bank letter) and one type tag. A second type, where there is one, is named in the rationale.
- **Type key:** VAL is behavioral or values alignment against published values. EXP is a deep-dive on your own past work. JD is a stated responsibility or requirement of the role. CO is company and strategy knowledge. CASE is a live problem.
- **Guidance is scaffolding, not a script.** Say it in your own words. Every claim about your past rests on a sentence you wrote, quoted in the row's Provenance cell.
- **Answer slots are instructions for the interview, not questions for you here.** Each has two honest branches. If you did the thing, say how, in your own words. If you didn't, or it wasn't yours, say so plainly. Both are good answers.
- **Provenance labels:** `[grounded]` is traceable to your message, the JD you gave me, or research listed in Sources. `[inferred]` is derived from those, with the derivation named. `[generic]` is a role-family pattern that makes no claim about Saltmarsh or about you.

## Prep triage

Today is Tuesday and the interview is Friday, so the order matters more than the volume. Do these in order.

1. **Tuesday: C1, then C2 and E1, aloud until boring.** C1 is the highest-ROI rehearsal in the pack. This objection will arrive in some form, and a calm, specific answer changes the hour.
2. **Tuesday or Wednesday: A1, A2, A3, aloud with a timer.** The careers page says the interview opens with a live-incident tabletop. Rehearse the structure, not a script.
3. **Wednesday: find real stories for B1, B2 and B4.** If no true story comes to mind, the honest branch in each cell is ready. Don't borrow one.
4. **Wednesday: D1.** Find out, if you can, how the monthly retention numbers were counted. If you can't, rehearse saying plainly that you don't know.
5. **Thursday: play Tidepool Tactics and Lantern Row, and read the Project Larkspur announcement and Tobias's talk page in full.** I saw only search snippets of both. This feeds A4, F2 and reverse questions 1 and 2.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title, and the words stay there: "I ran the weekly content-drop calendar for our main title for the last two years." The JD says two titles and live events, and nothing is inspected behind the quote. Answer slot: the JD's two-title line makes a probe likely on whether you have planned for more than one title. If you did, say which and how, in your own words. If your calendar covered one title, say so plainly and stay with that calendar |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show which teams the calendar involved. Answer slot: the JD lists four disciplines, so expect a probe on who each drop needed. If you worked with any of design, art, engineering or community on a drop, say which and what you handled, in your own words. If the drops involved none of them, or someone else did the coordinating, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented the monthly retention numbers to the studio head, and the words stay there. It does not say a post-event review or who chose the numbers. Answer slot: if you chose or defined any of the numbers you presented, say which and how you decided. If someone else produced them and you presented them, say so plainly and stay with the presenting. If a review of a drop ever followed and you took part, say what it covered. If none did, say that too |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap in the words, but a message line with nothing inspected behind it, so expect a probe. Lead with the quote's own terms: you wrote it and QA still uses it. Add nothing about what it changed or how often it was run |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | The material gives the years and the studio, and does not show whether the puzzle game was a live service. A years requirement is a risk to name, not a gate. Answer slot: if your main title kept receiving updates after launch, say so in your own words. If any part of that is not true, say so plainly and stay with the weekly content-drop calendar |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | The quote reaches the requirement in its own terms. Lead with it and keep its scope: weekly, your main title, two years. Expect a probe on how the calendar was kept, which is F1's slot |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | The quote names retention numbers and a senior audience. Lead with it. Answer slot: expect "how were those numbers counted". If you know, say it in your own words and name the assumption you would defend least. If you don't know how they were counted, say so plainly |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | Derived from the one written artifact your material mentions. Whether it shows clear writing is not established. Answer slot: if other written work of yours was read by players, the studio head or other teams, say what it was and who read it. If there is none beyond the checklist, say so plainly and stay with the checklist |
| F9 | Working fluency with a monetised live game. Not in the JD; derived from the season-pass move in Saltmarsh's Project Larkspur announcement (search snippet, page not read) and the JD's KPI line | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [inferred] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Your retention-numbers quote (F7) is the nearest thing in your material, and the pack's observation is that it is not revenue work |
| F10 | Leading people. Not a JD requirement; the JD's verb is "coordinate" | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | Words: "I haven't led a team." Nothing added. Whether you have coordinated teams is F2's question, and the answer there is yours |

## Reading the interviewer

Public professional footprint only. The facts are quotes from a search snippet. I did not read the talk page itself.

- **Source (search result for "Tobias Wrenfield Saltmarsh Games"):** "Patch Notes Are a Promise, a GDC 2026 talk by Tobias Wrenfield, Head of Live Operations at Saltmarsh Games, previously a QA lead at a console studio. His argument: a live team is judged by how often its patch notes describe what actually shipped."
- **Reading 1:** the talk's argument sits beside the company's second published value, "Ship the Patch Not the Promise". Expect probes on the gap between what was announced and what was built. They show up in A2, B2 and the reverse questions.
- **Reading 2:** his public path includes QA lead, so the release checklist is native ground for him. Expect the F4 line to be tested as a QA person would test it: what it covers, who owns it, what happens when it is skipped.
- **Reading 3:** attribution is where this theme bites. Say plainly what was yours, and don't round up (E2).
- **Shared vocabulary, a professional path and not an identity.** His public path includes QA lead. Your F4 line is "Wrote the release checklist our QA team still uses." The checklist is common ground you can speak to precisely. Don't build on it beyond what the line carries.

## Persona table

The weights rest on the careers page. Source (search result and fetched page, https://saltmarshgames.com/careers/interviewing): "Every Saltmarsh loop is a recruiter call, then the Outage Hour: a single 60-minute interview with the hiring manager — a live-incident tabletop on a simulated outage during a live event, then a values conversation. There is no take-home." The page is undated.

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | The live-incident tabletop, plus the shared-calendar problem | Highest. The page names the tabletop as the first half of the session, and the hiring-manager prior is Case plus Skeptic. 5 questions | Clarify, then objective, then who needs to know, then what players are told, then what is recorded. Think aloud and challenge one premise respectfully |
| B. Values / Behavioral | The "values conversation" that closes the session | High. The page names it as the second half, so it is guaranteed in this session. Three published values to cover. 4 questions | For each value, a story only where one of your quoted sentences carries it. Otherwise a selection scaffold with its honest branch |
| C. Skeptic | Quiet probing of F9, F10 and the two-title scope | Medium. Hiring-manager prior, and your own stated limits give it material. It is woven through both halves rather than a block of its own. 3 questions | Rehearse the most predictable objection (C1) until it is boring. Bridge only from what you have stated |
| D. Data-Driven Prober | Retention numbers and post-event review | Lower. The JD names KPIs and retention, and the talk's theme (what was announced against what shipped) points at precision. 2 questions | Know what you can and cannot say about how the numbers were counted, and say plainly when you don't know |
| E. Pressure | A time-boxed challenge on why you, and on attribution | Lower. The tabletop carries time pressure, but nothing published suggests a stress style. 2 questions | Pause, restate, hold the position through two follow-ups, concede specifically |
| F. Conversational | The opening "walk me through" and a casual question about the games | Lower. Opening minutes of a 60-minute session. 2 questions | A 90-second arc from your own sentences. Treat casual questions as scored |

Not included: the Peer Evaluator. The careers page lists no peer session in this loop.

## Question banks

### A. Case / Strategist (weight 1)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It's day two of a live event. Players can't claim the event reward and the support queue is filling. You have ten minutes. What do you do, and what do you need to know first?" | CASE | [generic] | Say your structure aloud before you use it. Clarify first: how many players, which platform, when it started, whether it is the event or the build. Objective: stop harm to players, then restore. Who you pull in: engineering for cause and fix estimate, community for what players are told, design for whether the event can pause or extend, QA for whether a fix can ship. What players are told now: only what is known, with what is not yet known named. What you record: times, decisions and who made them, for the post-event review. The question needs no claim about your past, so the guidance makes none | The careers page says the interview opens with a live-incident tabletop, so a scenario of this shape is the most likely opener. CASE because it scores structure and clarifying instincts. It touches the JD's four disciplines, so it is also a JD item |
| A2 | "Engineering says the fix can't ship until after the event ends. Community wants to tell players a compensation is coming. What do you say, and write me the two lines players will see." | CASE | [generic] | Separate what is built or decided from what is hoped. The two lines say what happened, what is known and when the next update comes. They promise nothing that is not yet granted. Say who has to approve any compensation and ask whether it has been approved. Concede what you do not know about the fix. The question needs no claim about your past | Tobias's public talk is about patch notes matching what shipped, and the published value says "we announce what is built, not what is hoped". CASE for delivery, with the written-communication requirement scored live. Gets two lines because a short message is the cleanest evidence of clear writing |
| A3 | "A hotfix has to go out tonight. QA says the full release checklist can't finish before the event window closes. What goes through the checklist, and who decides?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | You can name the checklist you wrote, in the quote's own words, and no more. Then reason as a plan: ask QA what each part guards against, which parts cannot be skipped for a hotfix and which can follow, who signs off, and how what was skipped is recorded for the post-event review. Answer slot: if you have shortened or split a release process under time pressure, say how you decided and who agreed. If you haven't, say so plainly and answer as a plan | JD because it scores the release-checklist-with-QA requirement (F4). CASE in delivery. The interviewer's public QA background makes this the likeliest place for a close probe |
| A4 | "Project Larkspur puts both titles on one shared events calendar from February 2027. What do you want to know first about running one calendar across two titles?" | CO | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Open with what you would ask: who owns each title's constraints today, what is already committed, how clashes are resolved, how incidents are absorbed. Tie it to your calendar at its own scope: your weekly calendar was for your main title. Answer slot: the JD's two-title line makes a probe on multi-title planning likely. If you have planned across more than one title, say how, in your own words. If your calendar covered one title, say so plainly and stay with it | The one CO question grounded in current strategy. The fact rests on Saltmarsh's September 2026 announcement as a search snippet, so read the page in full before Friday. CO because it tests whether you can think at the company's altitude |
| A5 | "Plan the first four weeks of a shared events calendar for two titles. What do you need to know before you put a date in it?" | CASE | [generic] | Clarify before dating anything: what is already committed per title, engineering and art lead times, QA windows, who approves. Then principles: no two big events in the same communications window, a held buffer for incidents, one owner per date. Challenge one premise respectfully, for example whether one calendar must mean one cadence. Close with how you would review it. The question needs no claim about your past | The two-title scope is the JD's and Larkspur's. CASE because Tobias will score clarifying before structuring. Pairs with A4 so that CO and CASE rehearse the same ground at different altitudes |

### B. Values / Behavioral (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players wanted different things. What happened?" | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Selection scaffold: pick a time a date, scope or plan and what players were experiencing pulled apart. It needs a named player-facing issue, who decided, what happened to the date, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry (your weekly content-drop calendar) or how you would handle it | Published value "Players Before Plans": "when the calendar and the players disagree, the players win". F1 and F6 carry a calendar and no conflict, so this is a scaffold and not a mapped story. The page names a values conversation in this session |
| B2 | "Tell me about a time an announcement got ahead of what was built. What did you do?" | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Selection scaffold: pick a time something was said that the build did not yet back. It needs what was said, who said it, how you found out, what you did, and what was corrected. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry (the checklist you wrote, which QA still uses) or how you would handle it | Published value "Ship the Patch Not the Promise". Tobias's talk argues the same point. VAL, and scaffold because no quote carries an announcement story |
| B3 | "Tell me about the release checklist your QA team still uses." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4: you wrote it, and QA still uses it. Those are the beats the quote states. Answer slot: the published value says every release leaves "the checklist better than it found" it, so expect a probe on changes. If the checklist has changed since you wrote it, say what changed and who changed it. If it has not, or the changes were not yours, say so plainly and say what you would keep | Published value "Leave the Build Greener". Also the JD's checklist-with-QA line (F4). VAL because the question scores how the work was kept up, not only what it was |
| B4 | "Tell me about a time you told someone something about a date or scope that they didn't want to hear." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not fold, and a working relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry or how you would handle it. Say "we" for context and "I" for what you did | A standard values-round stem that the first two published values invite. VAL. Keep the "hard truth landed" test: choose a story where it did, or say it didn't |

### C. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've said you haven't worked on a game with in-app purchases. Both our titles are moving to a season pass. What do you do about that?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." "Presented the monthly retention numbers to the studio head." "Wrote the release checklist our QA team still uses." | **Highest-ROI prep in this pack.** Pause, then give the plain acknowledgment: "I haven't worked on a game with in-app purchases." Hold only what your quotes carry: the weekly content-drop calendar for your main title, the retention numbers you presented, and the checklist you wrote. Don't present them as revenue work. Follow-up 1, "what would you look at first on the season pass?" Answer slot: if you know which revenue or season-pass measures a team like this watches, say how you know, in your own words. If you don't, say so plainly and say who you would ask and what you would ask. Follow-up 2, "why not hire someone who has?" Concede specifically that the monetised side is a real gap, and rest your case on the work you have quoted. Follow-up 3, "how fast do you close it?" Give your own plan, with no date you cannot back | F9 is the largest gap and the one the season-pass move makes live. JD because it scores whether you can do the listed job, gap included. Deepest rehearsal because it will be asked in some form, and a calm, specific concession changes the hour |
| C2 | "You've never led a team. This role coordinates design, art, engineering and community. How do you get four disciplines to move on your calendar?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." | Plain acknowledgment: "I haven't led a team." The JD's verb is coordinate, and that is the question. Hold the calendar quote at its own scope. Answer slot: if you worked with any of design, art, engineering or community on a drop, say which and what you handled. If the drops involved none of them, or someone else coordinated, say so plainly and stay with the calendar you ran. Then your approach as a plan | F10 is the stated limit and F2 is the unknown. JD because the coordination line is the role's core. The question can carry the negative because you stated it |
| C3 | "Why this role at Saltmarsh, and why now?" | JD | [generic] | Selection scaffold: give two reasons in your own words, one about the work and one about something Saltmarsh has published that you have actually read. If no strong reason comes to mind beyond the next step in your career, say so plainly and say what you want to learn here. Don't borrow a reason from the values page | The standard motivation probe. JD because it scores fit to this role and company, and the published values and Larkspur give honest hooks |

### D. Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the monthly retention numbers you presented to the studio head." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Open with the quote's own scope: you presented them, monthly, to the studio head. Answer slot: say which numbers they were, how they were counted, what they are sensitive to, and the assumption you would defend least, but only the parts you know. If you don't know how they were counted, or someone else produced them, say so plainly and say what you did with them | F7 and F3 meet here. EXP because it tests whether the CV line survives a second question. The pack names no method or number |
| D2 | "After a live event ends, what do you look at first, and what do you report?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Answer as a plan, since the post-event review is a JD line the quote does not carry. Say what you would want to know before looking, what you would report and to whom, and what would change the next event. Answer slot: if you have run or joined a review of a drop, say what it covered. If you haven't, say so plainly and say what you would set up first | The JD says "own the post-event review and the KPIs it reports" (F3). JD because it scores that requirement directly |

### E. Pressure (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has already run live events for two titles?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Never led a team, and never worked on a game with in-app purchases." | Pause and restate the question. Hold: the calendar you ran for two years and the checklist QA still uses, at those scopes. Concede specifically: "I haven't worked on a game with in-app purchases" and "I haven't led a team." Don't claim two titles. Hold through two follow-ups and don't fold on what the quotes carry | F1, F9 and F10 together. JD because it scores the comparison against the role. Time-boxed because a pressure persona tests composure, not content |
| E2 | "That calendar — how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if anyone shared the running of it, or parts were set by others, say so plainly and say which part was yours. If it was all yours, say that. Don't round up | Attribution is where a talk about announcements matching what shipped bites. EXP because it tests precision about your own work |

### F. Conversational (weight 6)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc in your own words: four years as an associate producer at a puzzle-game studio, the weekly content-drop calendar for your main title, the checklist QA still uses, the retention numbers you presented. Close with your own reason for this role. That sentence is yours to write | Opens most sessions. The arc uses only sentences you wrote. Scored even though it sounds casual |
| F2 | "Have you played Tidepool Tactics or Lantern Row?" | CO | [grounded] | Answer slot: if you have played either, say what you noticed as a player and what you would want to ask the team. If you haven't, say so plainly and say what you would look at first. Do this before Friday, because it is on Thursday's list | The titles are named in the Larkspur announcement snippet. CO because it tests homework in a casual register |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two titles | A4, A5, E2 |
| Coordinate design, art, engineering and community | A1, A2, C2 |
| Own the post-event review and the KPIs | D1, D2 |
| Manage the release checklist with QA | A3, B3 |
| 3+ years producing live-service games or apps | F1, E1 |
| Experience running a content calendar | A4, E2, F1 |
| Comfortable with player-retention metrics | D1, D2 |
| Clear written communication | A2 (the two player-facing lines) |
| Not in the JD: monetised-game fluency | C1 |

## Values / principles cheat sheet

A values-style round is detected because the careers page names "a values conversation". Value names are from https://saltmarshgames.com/values.

| Value | Working meaning (paraphrased) | Mapped story or scaffold |
|---|---|---|
| Players Before Plans | When the schedule and the players' experience disagree, the players win | Scaffold, no quote carries it. Pick a time a date and the players' experience pulled apart, with a named issue, who decided and what happened to the date. If none comes to mind, say so plainly and give the nearest thing your material carries, F6: "I ran the weekly content-drop calendar for our main title for the last two years." Or say how you would handle it. B1 |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | Scaffold, no quote carries it. Pick a time something was said that the build did not yet back. If none comes to mind, say so plainly and give the nearest thing your material carries, F4: "Wrote the release checklist our QA team still uses." Or say how you would handle it. B2, A2 |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | Story-mapped on F4: "Wrote the release checklist our QA team still uses." The beats are that you wrote it and QA still uses it. Whether it was changed afterwards is B3's answer slot. B3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Your GDC talk, 'Patch Notes Are a Promise', argues a live team is judged on whether patch notes describe what actually shipped. How does the team check an event before it is announced, and what did your time as a QA lead change about how you run live ops?" | Tied to his own path and published theme (snippet: "previously a QA lead at a console studio"). Shows you looked at him and not only the company, and turns an interview into a conversation about his craft |
| 2 | "The Larkspur announcement says per-title event teams are retired in favour of a single live-ops group (snippet wording: 'retires per-title event teams in favour of a single live-ops group'). Where does this role sit in that, and does the JD's 'two of our mobile titles' still hold?" | Names the tension between the JD and the announcement without accusing anyone. Shows current awareness and lets Tobias say what the role really is |
| 3 | "What does a good post-event review look like here, and which numbers are the headline for an event versus the season pass?" | Directly addresses the F3 and F9 gaps by asking how the team measures, and signals that you want to learn the monetised side |
| 4 | "What would you want this person to have changed by day 90?" | Standard, but it makes him describe the job as he sees it, and gives you the yardstick you will be held to |
| 5 | "Which of the three values has been hardest to hold in the last year, and what did the team do?" | Follows the values conversation. A candidate who asks it is listening to the values, not reciting them |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has worked on a game with in-app purchases | Negative you stated, F9 | The plain acknowledgment from your own sentence: "I haven't worked on a game with in-app purchases." No slot |
| Has led a team | Negative you stated, F10 | "I haven't led a team." Whether you have coordinated teams is F2's answer slot, and the answer is yours |
| Ran the live-events calendar for two titles | Inflated form of F1 | F1's quote at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." The pack's observation is that your material says one main title and weekly content drops |
| Owned the post-event review or the KPIs it reports | Inflated form of F3 | F3's quote at its own scope: "Presented the monthly retention numbers to the studio head." The pack's observation is that your material says presented, not owned or defined |
| Managed the release process with QA | Inflated form of F4 | F4's quote at its own scope: "Wrote the release checklist our QA team still uses." The pack's observation is that "still uses" says adoption continues and no more |
| The checklist improved release quality | Outcome not stated, F4 | F4's quote at its own scope. B3's slot asks only what changed and who changed it |

## Sources

**Provided documents:** the JD text and the background summary in your message. No CV file was provided.

**Searches and fetches sent:**

- Search "Saltmarsh Games values" returned https://saltmarshgames.com/values. Fetched, read in full.
- Search "Saltmarsh Games interview process live operations producer" returned https://saltmarshgames.com/careers/interviewing. Fetched, read in full.
- Search "Saltmarsh Games mobile studio news strategy" returned https://saltmarshgames.com/news/project-larkspur. Search snippet only, page not read. Snippet: "September 2026: Project Larkspur moves Tidepool Tactics and Lantern Row to a season-pass model with one shared events calendar from February 2027, and retires per-title event teams in favour of a single live-ops group."
- Search "Tobias Wrenfield Saltmarsh Games" returned https://talks.gdconf.example/2026/patch-notes-are-a-promise. Search snippet only, page not read.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet: three values by name. B1 to B3 |
| 2. `Saltmarsh Games interview process live operations producer` | yes | Loop structure: one 60-minute session, tabletop then values conversation, no take-home. Persona weights and the values-round detection |
| 3. `Saltmarsh Games` strategy and recent news | yes | A4, reverse question 2 and F9. Snippet only, so the full announcement is on Thursday's list |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | Reading the interviewer, reverse question 1, B2. Snippet only |
| 5. Representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Confirmation that Tobias is the person the producer would report to: if he is more senior than the hiring manager, the persona weights shift towards the executive pattern.
- Anything the recruiter told you about the Outage Hour (whether the scenario is given in advance, whether it is scored against a rubric): the A bank is reweighted and the cases tightened.
- Your answers to the answer slots, in a message, for F1 (more than one title), F2 (which teams), F3 (who chose the numbers, any review), F5 (whether the main title was live) and F8 (other written work): each becomes a quoted row, and the C, D and E guidance cells regenerate.
- Your full CV, or the artifacts themselves (the calendar, the checklist document, a retention report): medium confidence on F1, F3, F4, F6 and F7 can rise to high where an inspectable artifact is behind the line.
- A deeper research pass: up to 6 more searches and 2 more fetches, several more minutes. It reads the Larkspur announcement and Tobias's talk in full and adds a grounding brief section. Say the word and I'll run it.
- A tuesday-dossier.md from an earlier evidence check: verified evidence rows and prohibited claims arrive pre-graded, so the objection to rehearse is evidence-derived and not inferred.
