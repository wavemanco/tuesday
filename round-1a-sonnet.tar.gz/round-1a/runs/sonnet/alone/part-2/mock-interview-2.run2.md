I'll read the skill's reference files before building the pack.
The pack is built and saved. Here is the delivery message.

Your prep pack is saved as `atlas-freight_operations-manager_interview_pack.md`. It covers 20 questions across seven interviewer styles, plus a fit snapshot against the JD, reverse questions and a list of claims the pack won't coach.

I built it without knowing the round type or the interviewer, so every interviewer style is covered, with more questions where your material is thinnest. All three company-research searches were refused, so nothing in the pack comes from the web. The Atlas Freight questions are generic, and the pack says so.

The question it names as your highest-ROI prep is A1: "Today you're a senior shift manager over 3 supervisors; this role has twelve across four sites. What's the hardest part of that step?" Your 40% figure and the Power BI answer come next.

Say the word and I'll play the Skeptic on A1.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Who is interviewing you, and in what round: your future manager, a peer, a skip-level, a recruiter or a panel? Did the recruiter mention any focus areas or something to prepare in advance? The answer reweights the question banks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

Role: Operations Manager, Atlas Freight (regional logistics, 800 employees, per the JD you pasted).
Interviewer and round: not known. This pack is built as a full-loop pack with all seven personas covered, and depth follows the gaps in your material rather than a round type.

## How to use this pack

- **Personas** are how a question arrives (who is asking, in what style). **Types** are what is being scored. Every question carries one of each.
- Type key: **VAL** = past behavior against values or principles; **EXP** = whether your claims survive scrutiny; **JD** = whether you can do the listed job, gaps included; **CO** = homework on the company; **CASE** = a live problem from the role.
- Provenance key: `[grounded]` traces to your JD or your own words; `[inferred]` is this pack's derivation, named; `[generic]` is a rehearsal pattern with no claim about you or Atlas Freight.
- Guidance is scaffolding, not a script. Every line about your past is one of your own sentences, quoted. Where the pack could not know something, it gives an **answer slot**: an instruction for what you say in the interview. A slot has two honest branches, and either one is a good answer. A slot is not a question to me.

## Prep triage

You have about a week. In this order:

1. **A1**, the highest-ROI prep in this pack. Say it aloud until it is boring.
2. **B1 and D2**: know what you can and cannot say about how the 40% was counted and which part was yours.
3. **A2 and A3**: one plain sentence on Power BI, then the plan.
4. **C1**: the structure for an on-time and cost case.

Everything else is insurance.

## Fit snapshot

Requirements are quoted from the JD you pasted. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material says warehouse and distribution ops and a shift-manager role, and it does not show terminal work or more than one site. The words stay at that scope: "I'm currently a senior shift manager over 3 supervisors," and "I ran the site's peak-season surge plan two years running." Answer slot: if any decisions on the site's operations beyond your own shift were yours, say which, in your own words; if none were, say so plainly and stay with your shift and the surge plan |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | The JD asks about on-time performance and cost per shipment; your material says mis-pick rate and the pick path. The words stay there: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if you tracked any measure beyond mis-pick rate at your site, say which and what it showed, in your own words; if you did not, say so plainly and stay with the pick path |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | The JD number is twelve and your material says three, so the size gap is visible to both sides of the table. The words are your stated scope: "I'm currently a senior shift manager over 3 supervisors." Answer slot: say which decisions on your shift sit with your supervisors and which with you, in your own words; if the split is not clear-cut, say so plainly and describe how you run the shift |
| F4 | "build reporting in Excel/Power BI" — JD (Excel half) | "solid Excel" — your message | low | [inferred] | discovery | Derived from the JD's reporting line; "solid Excel" says a skill level and nothing about what it was used for. Answer slot: say what you use Excel for, in your own words; if none of it is reporting for others, say so plainly and stay with "solid Excel" |
| F5 | "build reporting in Excel/Power BI" — JD (Power BI half) | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used Power BI." Then how you would learn it, said as a plan and never as a past. Never a claim to Power BI work, and nothing added to make the gap feel smaller |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | low | [inferred] | discovery | Derived from the JD's leadership-years line: your material states seven years in ops and a current supervisory role, and it does not say when supervising began. Answer slot: say when you first supervised others and in what role, in your own words; if that was recent, or most of the 7 years were not supervisory, say so plainly and stay with the 7 years as you stated them |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap, but a certification with nothing inspected behind it, so expect a probe on it. Lead with it in your own terms: "I'm green belt certified." The certificate itself is the inspectable artifact that would lift this row |

The JD states no gate (a licence, location, schedule, pay or similar term). The five-years line is a length-of-experience requirement, so it is graded as F6 and is not a gate.

## Persona table

No round type or interviewer relationship is known, so relationship priors cannot be applied. No loop source was read (see Sources), so the loop falls back to the Generic archetype (screen, hiring manager, panel) with flat weights. This is a pattern, not Atlas Freight's documented process. Depth follows the fit snapshot instead: more questions where your material is thinnest.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. The Skeptic | Quiet, persistent probing of span, scale and tools | high: F1, F3, F5 and F6 are the rows where your material and the JD sit furthest apart, and a skeptic reads exactly those | Rehearse A1 until it is boring; bridges only from your quoted sentences; a plan, never a past, where you have none |
| B. The Data-Driven Prober | Goes two levels into the 40% | high: F2's figure is the one number in your material, and it is the CV-style claim probers go to | Know what you can and cannot say about how it was counted; say plainly when you do not know |
| C. The Case / Strategist | Live problems from the role: on-time, cost, surge | medium: the JD's on-time, cost and four-site lines are all natural live problems | Clarify, objective, segmentation, approach, metrics, risks; think aloud |
| D. The Pressure Interviewer | Time-boxes, interrupts, tests composure | medium: no round information, so no basis to raise or lower it | Pause, restate, anchor in what you stated, hold through two follow-ups, then concede specifically |
| E. The Peer Evaluator | Seams between sites or teams; disagreement | low: depends on whether a peer is in the loop, which is unknown | Reciprocity framing; propose seam principles rather than pretending to know the seam |
| F. The Conversational / Rapport Builder | Casual openers that are still scored | medium: a screen or an opener from any interviewer arrives this way | A 90-second arc built only from your own lines |
| G. The Values / Behavioral Interviewer | Stories mapped to published values | low: no values page was read and no values round is documented, so the stems below are persona stems and not Atlas Freight's values | Selection scaffolds ending in the honest branch |

## Question banks

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| "Own daily terminal operations across 4 sites" | A1, C2, C3 |
| "drive on-time performance and cost-per-shipment down" | B2, C1, C4 |
| "lead a team of 12 supervisors" | A1, C2, D3 |
| "build reporting in Excel/Power BI" | A2, A3 |
| "5+ years operations leadership required" | F1, F2 |
| "Lean/Six Sigma a plus" | B3 |

Company-specific CO and CASE questions are `[generic]` because research could not run. That is the honest cost, and the upgrade menu says what would change it.

### A. The Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Today you're a senior shift manager over 3 supervisors; this role has twelve across four sites. What's the hardest part of that step?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | **The highest-ROI prep in this pack.** Start from what is stated: "I'm currently a senior shift manager over 3 supervisors." Answer slot: say which decisions on your shift sit with your supervisors and which with you, in your own words; if the split is not clear-cut, say so plainly and describe how you run the shift. Then the step as a plan, not a past: what you would want to learn at each site before changing anything, and how you would decide where your time goes, in your own words. Hold through the follow-ups by returning to what you stated; concede the size gap plainly, because the JD's number and yours are both visible. Likely follow-ups: how would you split a week across four sites; what would you leave alone in the first month; what if one site's supervisors resist | F3 is the biggest visible gap between the JD and your material, and F1 sits beside it, so this objection arrives in some form. JD because it scores the stated requirement; deepest rehearsal because it is the most predictable question |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never used Power BI" | Hold-then-concede, and the concession is already yours: "I've never used Power BI." Say it once, plainly, then the plan in your own words, without a course name or date the pack cannot supply. If the interviewer pushes toward another thin area, answer from that row's quote at its own scope and add nothing to it | F5 is the one gap you have stated yourself, so it is the safe, true answer to a question designed to find one. JD because it scores fit against the listed job |
| A3 | "The role builds reporting in Excel and Power BI. Where are you today on each?" | JD | [grounded] "solid Excel", "never used Power BI" | Keep the two answers apart. Excel: "I'm solid in Excel." Answer slot: say what you use Excel for, in your own words; if none of it is reporting for others, say so plainly and stay with solid Excel. Power BI: "I've never used Power BI," then the plan in your own words | F4 and F5 are one JD line with two different answers; separating them stops the Excel answer being stretched to cover the Power BI one |
| A4 | "Why Atlas Freight, and why now?" | CO | [generic] | The pack has nothing on Atlas Freight, because research could not run, and your material says nothing about why you are looking. So there are no words here. Give your own reason for moving, about the work and not about leaving, and name one thing about Atlas Freight you have actually read yourself. If you have read nothing yet, read their site before the interview | Motivation and homework are asked together; `[generic]` because no company fact was established. CO because it tests the homework |

### B. The Data-Driven Prober (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You cut mis-pick rate 40% by redesigning the pick path. Walk me through how that number was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say the sentence at its own scope. Then four answer slots, each in your own words: how it was counted; what the 40% is sensitive to; the assumption behind it you would defend least; which part was yours and which part was others'. For any you cannot answer, say plainly that you do not know how it was counted. Naming your weakest assumption before they do turns a gotcha into credibility. Do not supply a method or a starting point you do not have | F2 is your one headline figure, and defend-the-number is where probers go first. EXP because it tests attribution and counting |
| B2 | "Beyond mis-pick rate, what else did you see move when you changed the path?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: if you tracked any measure beyond mis-pick rate at your site, say which and what it showed, in your own words; if you did not, say so plainly and stay with "I cut mis-pick rate 40% by redesigning the pick path." Never describe an effect on something you did not measure | The JD's on-time and cost lines make this probe likely; F2's bridge stops at the pick path, so the honest second branch has to be ready. JD because it scores the stated requirement |
| B3 | "Tell me about a time you used Lean or Six Sigma methods on the floor." | JD | [grounded] "green belt certified" | Start with what is stated: "I'm green belt certified." Answer slot: if the pick-path redesign came out of that training, or any other work used its methods, say which and how, in your own words; if the certification and the redesign were separate, or you have not applied it on the floor, say so plainly and say who certified you and what it covered, in your own words | F7 carries the certification and nothing links it to any project. JD because the JD lists it; the open prompt asks you to choose the instance |

### C. The Case / Strategist (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "On-time performance at one of our four sites has slipped over the last month and cost per shipment is rising. What do you want to know first, and what do you do in the first two weeks?" | CASE | [generic] | Clarify first: how each measure is defined here, which site, what changed. Then objective, segmentation (hypotheses to check, such as site, shift, lane or customer, and not facts), approach, the few metrics you would watch, risks. Think aloud, and challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | The JD's on-time and cost lines turned into a live problem; `[generic]` because it is a pattern, not a fact about Atlas Freight. F2 is why it matters |
| C2 | "Your first 30 days: four sites, twelve supervisors. How do you spend them?" | CASE | [generic] | Structure it: what you would need to know before choosing, how your time splits, what you would leave unchanged for now, who you would listen to first, what you would report back and when. No claim about your past | The same size gap as A1, asked as a decision rather than a challenge. CASE because it asks for structure; F1 and F3 are the rows it rests on |
| C3 | "Peak season is eight weeks out, the four sites' volume forecasts disagree, and capacity is fixed. Walk me through the surge plan." | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Structure first: what the disagreement is and why, the objective, priorities when capacity is fixed, trigger points, people and communication, what you would report. Where it helps, one line from your own history at its stated scope: "I ran the site's peak-season surge plan two years running." Tell only what you did; the pack supplies no detail of those plans and none is needed | Your surge plan is your strongest operations-at-scale line (F1), and this case lets you use it without claiming more. CASE because it is a live planning problem |
| C4 | "On-time is slipping and cost per shipment looks flat. What explanations do you rule out first?" | CASE | [generic] | Organise by category and say they are categories: how each measure is defined, one site or all, volume mix, labor availability, handoff delays. Say what data would separate them. These organise a diagnosis and are not claims about Atlas Freight | A diagnosis case from the JD's two measures; F2 is why it is here. `[generic]` because no company facts were established |

### D. The Pressure Interviewer (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "7 years in warehouse and distribution ops", "cut mis-pick rate 40% by redesigning the pick path", "green belt certified", "never used Power BI" | Pick one or two of the first three lines and say each at its scope; stop at sixty seconds. Hold through two follow-ups by returning to those lines, never adding to them. Concede one thing specifically, in your stated words: "I've never used Power BI." Do not compare yourself to the internal candidate; you know nothing about them | F2, F5 and F7 give the hold and the concession. JD because it asks for fit against the role; pressure is the delivery |
| D2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Pause, restate the question, anchor in the sentence. Answer slot: say which parts of the redesign were yours and which were others', in your own words; if it was shared, say so plainly. Hold through two follow-ups by returning to the sentence; concede specifically anything you do not know about how it was counted (B1) | Attribution under pressure is the stem for F2's figure. EXP because it tests what was actually yours |
| D3 | "Two minutes: one site is behind and its supervisors say your changes are the cause. What do you do?" | CASE | [generic] | Do not fold and do not defend. Ask what changed and when, check the data before anyone's story, talk to the supervisors, decide, say what you would tell them and by when. Use the two minutes; the structure is what is scored | A supervisor-resistance case for a role over twelve supervisors (F3). `[generic]` because it asks about no past |

### E. The Peer Evaluator (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our teams sit side by side — where's the seam, and what happens when we disagree?" | CASE | [generic] | Do not pretend to know the seam. Offer principles: what each side owns, who decides on a shared issue, how a disagreement is escalated, which data both sides trust. Then reciprocity: what you would bring to their team, and not only what you would need. No claim about your past | A seam-splitting stem; CASE because it asks for a structure. `[generic]` because nothing about the peer or the seam is known |
| E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time work crossed teams. It needs a named other team, what each side did, and how credit was said aloud. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A peer stem asking for an instance; no sentence of yours carries a story here, so the pack does not supply one |

### F. The Conversational / Rapport Builder (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So — walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops", "currently a senior shift manager over 3 supervisors", "cut mis-pick rate 40% by redesigning the pick path", "ran the site's peak-season surge plan two years running", "green belt certified" | A 90-second arc using only those lines, each at its own scope: the seven years in warehouse and distribution ops, the shift manager role over 3 supervisors, the pick-path result, the surge plan, the green belt. Close with one sentence on why this role, in your own words; the pack has none. Answer slot: say when and how you moved into supervising; if the seven years were not a straight line, say so plainly | Casual openers are scored, and this one is the F-row spine in order. EXP because it is a CV walk-through |
| F2 | "The role asks for five-plus years of operations leadership. How long have you been leading people?" | JD | [inferred] "7 years in warehouse and distribution ops", "currently a senior shift manager over 3 supervisors" | Answer slot: give the actual number of years you have supervised others and in what role, in your own words. If it is fewer than the JD's number, say so plainly, and say what the 7 years in warehouse and distribution ops covered, as you stated them. Do not round up | F6 is the row where your material does not show the answer, so the number has to come from you. JD because the JD states it |

### G. The Values / Behavioral Interviewer (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something they did not want to hear. It needs a named stake, what you said, how it landed, and the relationship intact afterwards. Choose a time the hard truth actually landed; if the ending is not clear, say so rather than supplying one. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem; no published Atlas Freight value was read, so this is a pattern and not a values mapping |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time a customer's need and an internal number pulled apart. It needs the two named, your call, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem; shipment-based work makes the customer-versus-metric tension a natural one to rehearse. `[generic]` because no values page was read |

## Reverse questions

| # | Question to ask them | Why it lands |
|---|---|---|
| 1 | "How are on-time performance and cost per shipment defined here, and where do the four sites stand on each today?" | Asks for the definitions F2 hinges on, and shows you pin down a measure before changing anything |
| 2 | "How do the twelve supervisors divide across the four sites, and who would I lean on first?" | Opens the span question (F3) on your terms and shows you are already thinking in teams |
| 3 | "What does reporting look like today: what lives in Excel, what is in Power BI, and who builds it?" | Brings up the Power BI gap (F5) yourself and learns whether you would inherit the building |
| 4 | "What would you want the person in this seat to have changed by day 90?" | Gets the interviewer's own scorecard in their words |
| 5 | "What would give you pause about my background for this role?" | Invites the objection while you can still answer it; pairs with the A1 rehearsal |
| 6 | "Which of the four sites is hardest to run, and why?" | Shows you expect the sites to differ; the answer tells you where the work is |
| 7 | If the interviewer is a peer: "What is one thing a new operations manager could do in the first month that would take weight off your team?" | Reciprocity: it asks what you can give, and not only what you need |

## Prohibited claims

What this pack will not coach, built from the fit snapshot before the question banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned daily operations across multiple sites or terminals | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation, not words for you: your material says a shift-manager role and the site's surge plan. A1 and C2 stay inside that |
| Improved on-time performance or lowered cost per shipment | Inflated form of F2 | F2's quote at its own scope: mis-pick rate and the pick path. B2's slot asks only what else you tracked at your site |
| Led a team of twelve supervisors | Inflated form of F3 | "I'm currently a senior shift manager over 3 supervisors." The size gap is the pack's observation |
| Built reporting in Excel | Inflated form of F4 | "Solid Excel" at its own scope; A3's slot asks only what you use it for |
| Has used Power BI | Negative you stated, F5 | The plain acknowledgment F5 gives: "I've never used Power BI." No slot |
| Has five or more years of operations leadership | Inflated form of F6 | The 7 years as you stated them; the material does not show when supervising began. F2's slot asks for your own number |
| The pick-path redesign was a Lean or Six Sigma project | Inflated form of F2 and F7 | Each quote at its own scope; your material states both and does not link them. B3's slot lets the link be absent |
| Designed the peak-season surge plan | Inflated form of F1's surge-plan quote | "I ran the site's peak-season surge plan two years running," and no more |

## Sources

Provided documents: the JD text you pasted; your background paragraph, quoted throughout as "your message". No dossier, CV file, interviewer profile or recruiter guidance was provided.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

Searches sent (all three refused, so nothing came back and nothing from them is used):

- "Atlas Freight regional logistics company values" — refused
- "Atlas Freight interview process operations manager" — refused
- "Atlas Freight regional logistics strategy news 2026" — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | The search was refused. It would have fed a values cheat sheet and the VAL bank; none is in this pack, and G1 and G2 are persona stems |
| 2. `Atlas Freight interview process operations manager` | unavailable | The search was refused. It would have named the real rounds and set persona weights; the loop here is the Generic archetype fallback |
| 3. `Atlas Freight strategy` / recent news | unavailable | The search was refused. It would have grounded CO and CASE questions in current priorities; A4, C1 and C4 are `[generic]` |
| 4. `{interviewer name} Atlas Freight` | n/a | No interviewer name was given, so no query could be formed; there is no interviewer read |
| 5. representative `Operations Manager` JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Who is interviewing you and in which round (future manager, peer, skip-level, recruiter, panel) → real persona weights instead of flat ones, and an interviewer read if you give a name or profile
- The recruiter's prep email or process notes → coverage assumptions replaced by their stated focus areas, plus a build section for any deliverable they announce
- Search access, or Atlas Freight's values or careers page pasted → a values cheat sheet if a values round is documented, the real loop structure, and CO and CASE questions grounded in current priorities (`[generic]` rows A4, C1, C4 and G1 to G2 would become `[grounded]` where the source supports it)
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes; only on your say-so) → a strategy brief and recent organisation context for the Atlas Freight questions, if search access is granted
- Your answers to the answer slots: when you first supervised others (F6, F2 in bank F), what the pick-path figure counted (B1, D2), what else you tracked (B2), what you use Excel for (F4, A3) and who certified your green belt (B3, F7) → those rows move from `[inferred]` or a slot to `[grounded]` quotes
- The artifacts that would lift confidence from medium: your green belt certificate (F7), a before-and-after mis-pick count (F2, B1), and a sample Excel report you built (F4)
- A `tuesday-dossier.md` from an earlier session → verified evidence and prohibited claims carried in, and the strongest objection named for you rather than inferred
