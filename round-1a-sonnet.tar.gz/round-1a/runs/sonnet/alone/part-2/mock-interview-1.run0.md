I'll read the reference files the skill requires before writing anything.
Your prep pack is saved as /var/tmp/tuesday-measure/1a/runs/sonnet/alone/part-2/rooms/case-1-denied-019e3e71/northwind-data_senior-gtm-strategy-lead_interview_pack.md. I built it for a single 60-minute peer conversation with Dan. It runs on your summary of Priya, not her CV or the full JD, so every quote about her comes from your notes. I ran it without web research because you said you had everything. I didn't check your research note on Northwind's priorities against any source.

The pack has 24 questions across seven personas, each tagged by type with answer guidance, a provenance label and a rationale. It also has a fit snapshot, a read of Dan, a requirement-coverage table, six reverse questions, a prohibited-claims list and an upgrade menu. Highest-ROI prep is C1: her stated gap in sales-ops and quota-setting, which Dan's role sits next to. After that come A1 and F1, the ~$400M figure asked once collegially and once hostilely.

Say the word and I'll play Dan on C1 as a skeptical peer, with reactive follow-ups.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Did the recruiter give any guidance, such as focus areas, a case or presentation to prepare, or who else is in the loop? An announced deliverable would add a build section.
Can you paste the full JD and Priya's actual CV lines? That would replace the quotes taken from your notes with her own words.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Northwind Data — Senior GTM Strategy Lead, Emerging Products: interview pack

- **Candidate:** Priya
- **Interviewer:** Dan Kovac, Director of Sales Strategy at Northwind Data — a peer, both reporting to the same VP
- **Round:** one 60-minute conversation with Dan
- **Built from:** the JD highlights and the candidate and interviewer notes in your message, plus the research note on Northwind. No CV text and no full JD were supplied, so every quote about Priya comes from your notes ("the coach's notes").

## How to use this pack

Personas describe how a question arrives; types describe what it scores. Guidance is scaffolding for a spoken answer, not a script: say it in Priya's own words, and rehearse out loud.

| Type | What it scores |
|---|---|
| VAL | Behavioral and values alignment. No Northwind values page was read, so VAL questions here score behavior, not value names |
| EXP | Whether a claim in the background survives scrutiny, and what was actually hers |
| JD | Whether she can do the listed job, gaps included |
| CO | Company and strategy knowledge, and thinking at the company's altitude |
| CASE | A live problem from the role, scored on structure and reasoning |

Provenance labels: `[grounded]` traces to your message; `[inferred]` is this pack's derivation from it; `[generic]` is a rehearsal pattern with no claim about Priya or Northwind. Where guidance rests on something Priya said or did, her quoted sentence sits beside the label.

An **answer slot** is an instruction for the interview, not a question for you. It has two honest branches: if she did the thing, say how in her own words; if there was no such step, or it was not hers, say so plainly and return to what her material does carry. The second branch is a limit, not a confession.

**Highest-ROI prep: C1** (the day-one gap on sales-ops and quota-setting), then A1 and F1 (the ~$400M figure, once collegial and once hostile). C1 gets the deepest follow-up ladder because the notes state the gap outright and Dan's job sits next to it.

## Fit snapshot

Requirements are the JD highlights as quoted in your message. Evidence is quoted exactly from your notes on Priya.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | Your material says strategy and ops work at a consumer-tech company, with nothing inspected behind it, and the words stay there: "For nine years I worked in product strategy and ops at a large consumer-tech company." Answer slot: the JD's own-GTM line makes a probe on how far that work reached likely. Say which part of it was yours, in your own words; if the work was advisory, or your part was narrower, say so plainly and stay with the strategy and ops work |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | The quote is a proposal credited with an uplift; it does not show work on what happens to a paying customer after the first sale, and the words stay at its scope: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." Answer slot: the JD's land/adopt/expand/renew line makes a probe on renewal or expansion work likely. If any of your work touched what happens after a customer first buys, say what and which part was yours; if none did, say so plainly and say what you would look at first. The figure raises its own probe: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | No gap in the tools, but a one-line claim with nothing inspected behind it, so expect a probe. Say it in the quote's terms: "I'm skilled in SQL/Tableau." "Independent" is the JD's word and the quote does not carry it. Answer slot: if you ran the analyses yourself, say which; if others pulled the data or built the dashboards, say so plainly and say what you did |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | The quote is a revenue model used in negotiations; your material does not show the design of a partner motion, and the words stay at its scope: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: the JD's required-experience line on partners makes a probe on how far that model reached likely. If you can say what the model was used to decide and which part of that was yours, say so in your own words; if it informed the numbers and nothing beyond, or the decisions were made by others, say so plainly and return to the model |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | none | The quote already states cross-org consensus, but it is a one-line claim with nothing inspected behind it, so expect a probe on how consensus was reached. Lead in its terms: "I set annual volume targets with cross-org consensus." Answer slot: say how consensus was reached and which part was yours, in your own words; if your part was narrower, say so plainly and describe the targets |
| F6 | Sales-ops and quota-setting fluency, a role-family expectation for a GTM strategy seat; the JD highlights do not state it | "No classic sales-ops or quota-setting experience" — the coach's notes | none | [grounded] | capability | A gap wording cannot close, and your notes state it. Words: "I don't have classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. Never a claim to quota or sales-ops work, and nothing added to make the gap feel smaller |
| F7 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — the coach's notes | medium | [grounded] | transferability | The quote is daily use of AI tools; it does not show building, launching or selling an AI product, and the words stay at its scope: "I use AI tools daily." Answer slot: expect "what for" — name the tools and what you use them for, in your own words; if your use is narrower than the question assumes, say so plainly |

## Reading the interviewer

Public-profile facts only, as you described them. Nothing here comes from a search.

| Signal | Source | What it means for the conversation | Provenance |
|---|---|---|---|
| Self-description: "relentlessly data-driven" | Dan's profile, via your message | Expect every figure to be taken to its assumptions. Rehearse the weakest-assumption move on A1 and A2 before he asks | [grounded] |
| Career spine: "pricing and monetization roles, with one early-stage-startup chapter" | Dan's profile, via your message | Pricing, packaging and unit economics are his native language, so D2 and D3 are likely; builder stories land with him, and a nine-year large-company background can draw a pace probe (C3) | [inferred] |
| Director of Sales Strategy, a peer under the same VP | Your message | His title suggests quota-setting and sales ops sit close to his work, so a bluff there is the fastest way to lose him; calibrated candor on C1 | [inferred] |
| Shared vocabulary: monetization and revenue | Dan's spine; F2 and F4 quotes | Speak in revenue terms when you describe the two proof points: "proposed a store-surface change credited with a ~$400M ARR uplift" and "built a partner-level revenue model used in carrier negotiations" | [inferred] |

No shared career jump is offered: your material gives his spine, not a transition, and no fit-snapshot row carries Priya's side of one.

## Persona table

The loop is established by your own words: one 60-minute session with a peer, so persona weights follow the peer relationship, adjusted by Dan's signals. No archetype fallback applies.

| Persona | How it shows up with Dan | Questions | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|---|
| A. Data-Driven Prober | Takes the two headline items to their inputs and assumptions | 5 | High. A peer prior, plus his own "relentlessly data-driven" self-description | Know what you can and cannot say about how the ~$400M was counted; say plainly where you do not know; offer a full SQL walkthrough only if you have one (A3) |
| B. Peer Evaluator | Seam-splitting between his team and the role, reciprocity, credit across teams | 5 | High. The relationship prior for a peer; he is pricing what this hire costs and adds to his work | Offer seam principles instead of pretending to know the seam; lead with what you bring his team, as far as the quotes carry it (B5) |
| C. Skeptic | The consumer-to-B2B gap, sales-ops and quota-setting, partner experience, why now | 4 | High. Your notes state the sales-ops and quota gap, and his title puts him near it | Rehearse C1 until it is boring; plain acknowledgment, then the nearest sentence at its scope, then a ramp plan |
| D. Case / Strategist | A live problem, probably on pricing, packaging or bundling | 3 | Medium. His pricing spine tilts cases toward his native ground, but a peer conversation weights cases below a hiring-manager round | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise |
| E. Conversational | The opener ("walk me through the journey"), the AI question, "what caught your eye" | 3 | High for E1, lower for the rest. A 60-minute conversation opens this way almost by default, and casual questions are still scored | A 90-second arc built only from the quotes; treat the AI question as scored |
| F. Pressure | Time-boxed "why you" and "how much was actually you" | 2 | Low to medium. Peers rarely interrupt, but the two attribution challenges can arrive in a flat, skeptical tone | Pause, restate, hold the sentence you said, concede specifically |
| G. Values / Behavioral | Behavioral prompts on disagreement and on data | 2 | Low. No values round is documented in your description of the single session; these arrive as stems, not as a scored values round | Choose stories where the hard truth landed; where none comes to mind, say so |

## Question banks

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| own GTM strategy for two new product lines | C4, D1, D2, D3 |
| identify whitespace across land/adopt/expand/renew | A4, A5 |
| run independent analysis in SQL and Tableau | A3 |
| partner-motion design experience required | C2 (A2 and D2 touch it) |
| strong cross-functional influence | B2, B3, B4, B1 |
| AI experience a plus | E2 |
| Sales-ops and quota-setting fluency (F6, not stated in the JD highlights) | C1, F2, B5 |

### A. Data-Driven Prober (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The notes have a store-surface change tied to roughly $400M of ARR. Walk me through how that number was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Say the sentence at its scope: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." Then name the four things a prober asks, in your own words. Answer slot: how the figure was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you know, say it plainly; if you do not know how it was counted, or who assigned the credit, say that — it beats a guess. Keep the verb "proposed" unless you can say what else you did | F2 is the headline figure, and a self-described data-driven peer takes headline figures to their assumptions. EXP because it tests what the claim rests on and what was hers |
| A2 | "You built a partner-level revenue model that was used in carrier negotiations. What went into it, and which assumption would you defend least?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Lead with the quote: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: if you can say what went into the model and where its output was used, say it in your own words, and name the assumption you would defend least before he asks. If you do not know how an input was sourced, or a part was not yours, say so plainly. Stay at "built" and "used in" | F4 is the only evidence on the partner requirement, so it will be probed from the data side as well as the role side. EXP because it checks the claim, not the JD fit |
| A3 | "Tell me about an analysis you ran yourself in SQL, start to finish." | JD | [grounded] "skilled in SQL/Tableau" | Your material says only "skilled in SQL/Tableau", so it carries no analysis story. Selection scaffold: pick one analysis that was yours from the question to the chart someone acted on — it needs the question asked, where the data came from, what you found and what changed because of it. If no such analysis comes to mind, say so plainly, then give the nearest thing your material carries, the quote above at its scope, or how you would structure the first analysis here. If you do have one, offer to walk through it end to end | F3 and the JD's independent-analysis line. A data-driven peer will test the tool claim with a worked example. JD because it scores the stated requirement |
| A4 | "A new line's trials look strong but adoption stalls around day 30. What do you pull first?" | CASE | [generic] | Clarify before structuring: what counts as adopted for this product, which segments, and how long since the land. Cut the stalled accounts by segment, entry channel, plan or contract, and by who inside the account is using it. Say your hypotheses aloud — an onboarding problem, a fit problem, a packaging problem — and the data that would separate them, then the metric that shows a fix is working. Challenge one premise respectfully: is day 30 the right clock for this product? Close on the risk that the instrumentation itself is incomplete. The guidance makes no claim about your past | R2's adopt stage as a live problem, in his data-first register. CASE because it asks for structure on a scenario; generic because it is a pattern, not a fact about Northwind |
| A5 | "Your nine years were at a consumer-tech company. What do you expect to be different when you look for whitespace across land, adopt, expand and renew in B2B?" | JD | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | Say it at its scope: "I spent nine years in product strategy and ops at a large consumer-tech company." Then answer as a thinking problem, in questions you would ask rather than findings you claim: who buys and who uses, how long contracts run, what a renewal event would reveal. Answer slot: the JD's land/adopt/expand/renew line makes a probe on renewal or expansion work likely; if any work of yours touched what happens after a customer first buys, say what it was and which part was yours; if none did, say so plainly and say what you would learn first | F2 and F1 together are the consumer-to-B2B seam. JD because it scores the whitespace requirement; the transfer is the real test |

### B. Peer Evaluator (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam between sales strategy and emerging-products GTM, and what happens when we disagree?" | CASE | [generic] | Do not pretend to know the seam. Propose principles: agree decision rights per decision type up front (who decides, who is consulted); shared definitions for any metric you both report; disagreements go to the data first and to your shared VP only after that. Close with reciprocity: what you would bring his team and what you would ask of it (B5). The guidance makes no claim about your past | The peer relationship prior. CASE because it asks for a design under ambiguity; the persona's stem is nearly verbatim |
| B2 | "You set annual volume targets with cross-org consensus. How did you get to consensus, and what was your part in it?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Start with the sentence at its scope: "I set annual volume targets with cross-org consensus." Answer slot: if you can say how consensus was reached and which part was yours, say so in your own words; if the targets were set by a group and your part was narrower, or you cannot speak to how agreement was reached, say so plainly and describe the targets. Call them what your notes call them: volume targets | F5 is the evidence for influence, and a peer decides whether you reduce or add to his load from how you got agreement. EXP because it tests what was actually hers; JD content |
| B3 | "Tell me about a time a peer team disagreed with your recommendation and you still had to land something together." | VAL | [generic] "set annual volume targets with cross-org consensus" | Selection scaffold: pick a time with a named stake, the other team's position stated in its best light, what you changed or held, and the relationship afterward. Show spine and tact together. If no such time comes to mind, say so plainly, then give the nearest thing your material carries — the quote above, at its scope — or how you would handle it | The persona's "what happens when we disagree" probe in behavioral form. VAL because it scores behavior with an equal; generic because no quoted sentence carries a disagreement |
| B4 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a result that spanned teams and separate the parts. Use "we" for context and "I" for your contribution, and name the other team's contribution specifically. If no instance comes to mind, say so plainly and describe how you handle it today | The persona's credit-sharing stem. It pairs with A1: the same quote is scored for attribution once he knows the work crossed teams |
| B5 | "What would you need from my team in your first ninety days, and what could you give it?" | JD | [grounded] "skilled in SQL/Tableau", "built a partner-level revenue model used in carrier negotiations", "No classic sales-ops or quota-setting experience" | Reciprocity first, in your own words and at the scope of the quotes: you are skilled in SQL/Tableau, and you built a partner-level revenue model. Then the ask, behind the plain acknowledgment: "I don't have classic sales-ops or quota-setting experience, so I'd want to learn how your team does it." Anything you offer beyond those two sentences is a proposal for the future, said as one | The reciprocity question a peer asks to see whether the hire lightens his load. JD because it scores cross-functional fit; it also turns F6 into an ask |

### C. Skeptic (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You come from consumer product strategy, and classic sales-ops and quota-setting aren't in your background. What's weakest on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience", "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops", "set annual volume targets with cross-org consensus" | **Highest-ROI rehearsal in this pack.** Beat 1, the limit first: "I don't have classic sales-ops or quota-setting experience." Beat 2, the nearest sentence at its scope: "I set annual volume targets with cross-org consensus." Say what the targets were in your own words and stop there. Beat 3, a ramp plan said as a plan: what you would learn first and from whom, with your own realistic timeline. Follow-up 1, "Volume targets are basically quotas": do not argue it either way; say plainly what you set, and that you have not done the classic work. Follow-up 2, "How long until you're useful on it?": give your own estimate, or say what it depends on. Follow-up 3, "Why not hire someone who's done it?": offer what B5's quotes carry and name the area where you would lean on a peer who has done it. Never fill the gap with a past you did not have | The notes state this gap, F6, and the interviewer's role sits next to it, so some form of this question is near-certain. JD because it scores a requirement the seat implies; the Skeptic delivery is the quiet follow-up ladder |
| C2 | "The JD asks for partner-motion design experience. What's yours?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Hold only what the quote carries: "I built a partner-level revenue model that was used in carrier negotiations." Your material says a model used in negotiations, not the design of a partner motion, so do not stretch it. Answer slot: if you can say what the model was used to decide and which part of that was yours, say so in your own words; if it informed the numbers and nothing beyond, or the decisions were made by others, say so plainly and return to the model. Then, as a plan and not a past, say how you would learn partner mechanics fast and from whom | F4 is the JD's one required-experience item and the evidence is adjacent. JD because it scores the stated requirement; the probe lands on the stretch |
| C3 | "You've spent nine years at a large consumer-tech company. Why leave, why a B2B data company, and why now?" | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | Answer slot: give your actual reasons in your own words; this pack supplies none. Two checks for what you say: it should be a pull toward this work, not a push away from your last job, and it should survive a second "why" without changing. You may connect it to what your research note gives for Northwind — enterprise expansion, the Compass launch, reaching profitability — only as far as you actually find those interesting | Motivation consistency is the Skeptic's core score, and a startup-chapter interviewer may probe large-company pace. EXP because reason-for-leaving tests the background's story |
| C4 | "This role owns GTM strategy for two new product lines. What have you owned, as opposed to advised on or proposed?" | JD | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops", "proposed a store-surface change credited with a ~$400M ARR uplift", "built a partner-level revenue model used in carrier negotiations", "set annual volume targets with cross-org consensus" | Sort your own sentences by verb before you answer: "proposed" for the store-surface change, "built" for the revenue model, "set ... with cross-org consensus" for the targets. Use those verbs and no stronger ones. Answer slot: the JD's own-GTM line makes a probe on whether any of it was yours to decide likely; for each item, if the decision was yours, say so in your own words; if you proposed and others decided, or it was shared, say so plainly. A proposal stays a proposal | F1 against the JD's ownership language. JD because it scores the headline responsibility; the owned-versus-advised wording is the attribution probe |

### D. Case / Strategist (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Enterprise expansion, the Compass launch and profitability are all priorities. Where do you put GTM effort for the two new lines, and what do you say no to?" | CO | [inferred] | Company facts come from your research note; the thesis is this pack's derivation. Clarify first: which segments each line targets, what profitability means at product-line level, and where Compass sits relative to the two lines (you do not know whether it is one of them). Mention the three priorities once to show you did the homework — Dan knows them, so reciting them scores nothing. Then take a position: name the tension you see between two of the priorities as a thesis, state the concession (what would change your mind), and give one anti-pick, something you would not do first. Think aloud and challenge one premise | The strategy-altitude question, grounded in the three stated priorities. CO because it scores company-level reasoning; CASE delivery. The consensus answer is the shared source, so the divergence and the anti-pick are the differentiation |
| D2 | "A much larger platform vendor starts bundling a competing capability into its suite. What does that do to your GTM for a new line?" | CASE | [inferred] | Clarify: how much the bundled capability overlaps ours, which segments are exposed, and what price anchor buyers now hold. Then options in pricing and packaging terms he will recognize: lead where the bundle is weakest; position around integration or depth rather than the bundled feature; protect expansion inside existing accounts; consider partners as a channel, said as a plan. Metrics to watch: win rate in bundle-exposed deals, discount depth, time to land. Name the risk of answering with discounts that cost profitability | The research note names bundling as the main competitive threat, and monetization is his home ground. CASE because it is a live scenario; CO content |
| D3 | "Suppose a new line launches on one pricing metric and early enterprise buyers keep asking for a different one. How do you decide?" | CASE | [generic] | Clarify what exactly buyers object to and in which segment. Separate signal from noise: how many deals, how consistent. Look at willingness to pay, discount patterns, margin by metric and what each metric does to expansion. Test the alternative on a subset before changing the list price. Name decision rights up front — pricing sits close to his work, so say where you would lean on his team's experience. The guidance makes no claim about your past | His pricing and monetization spine pulls the case to this ground. CASE because it scores structure; generic because it is a pattern, not a fact about Northwind's pricing |

### E. Conversational / Rapport Builder (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops", "built a partner-level revenue model used in carrier negotiations", "proposed a store-surface change credited with a ~$400M ARR uplift" | A 90-second arc on the beats the quotes carry: two years in strategy consulting at a top firm; nine years in product strategy and ops at a large consumer-tech company; two proof points at their own scope, the revenue model used in carrier negotiations and the store-surface change you proposed that was credited with a ~$400M ARR uplift. End on why this role. Answer slot: give your actual reason in one sentence, in your own words; this pack supplies none. Do not narrate the nine years chronologically | The near-certain opener. EXP because it scores the background's story; the quotes keep the arc inside what the notes say |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Say it at its scope: "I use AI tools daily." Answer slot: name the tools and what you use them for, in your own words, and one honest observation about where they helped or fell short; if your use is narrower than the question assumes, say so plainly. Stay at use: your material does not show building or launching AI products. Treat this as scored, given the JD's AI line and Northwind's Compass launch | F7 and the JD's AI plus, asked in the casual register the persona uses for hot JD topics. JD because it scores the stated plus |
| E3 | "What caught your eye about Northwind when you looked at it?" | CO | [grounded] | Answer slot: say what actually caught your eye, in your own words. Material you may draw on, from your research note: enterprise expansion, the Compass launch and reaching profitability as the three stated priorities, and bundling by a much larger platform vendor as the main competitive threat. Pick the one you can say something specific about, and put it as a question or a view rather than a fact you have verified | The homework check in a friendly register. CO because it scores whether you can think at the company's altitude |

### F. Pressure / Stress (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "That $400M — how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold-then-concede. Pause, restate the question, then hold the sentence: "I proposed the change, and it was credited with the uplift." Follow-up 1, "So someone else built it": answer slot — if others built or shipped it, say so plainly; if you did part of it, say which part; add nothing else. Follow-up 2, "Then why is it on your CV?": return to the same sentence without escalating. Concede specifically where you must, for example how the credit was assigned if you do not know, and say what you do know. Do not fold on the core sentence just to restore harmony | The attribution challenge on the one headline figure; the same objection as A1 in a hostile delivery. EXP because it tests what was hers; Pressure delivery because it scores composure |
| F2 | "Sixty seconds: why you over someone who has carried a quota?" | JD | [grounded] "No classic sales-ops or quota-setting experience", "built a partner-level revenue model used in carrier negotiations", "skilled in SQL/Tableau" | Pause, restate, concede first: "I don't have classic sales-ops or quota-setting experience." Then offer what the quotes carry, at their scope: you built a partner-level revenue model that was used in carrier negotiations, and you are skilled in SQL/Tableau. Stop inside the minute. Follow-up "That's not a reason": return to those two sentences and the ramp plan from C1, and do not add a claim to win the exchange | C1 under a time box. JD because it scores the stated gap against the seat; Pressure delivery tests whether the concession holds without folding |

### G. Values / Behavioral (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time where the hard truth actually landed. It needs what the truth was, who did not want it, what you said, and what changed. If your own material shows no such time, say so rather than supplying an ending. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The persona's standard stem; low weight because no values round is documented in the single session you described. VAL because it scores behavior |
| G2 | "Tell me about a time the data disagreed with your recommendation." | VAL | [generic] | Selection scaffold: pick a time with a named recommendation, what the data showed, what you did with the disagreement, and what happened to the recommendation. Show that you can change your mind without losing the thread. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | His self-description as "relentlessly data-driven" is the raising source for the theme. VAL because it scores a behavior he cares about |

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R1 | "You've spent your career in pricing and monetization, with a stretch at an early-stage startup. What did that stretch change about how you think about go-to-market here?" | Tied to his own path. It converts the interrogation into a peer conversation and shows you researched him, not just the company | [grounded] |
| R2 | "What could a new person on the strategy side do in the first month that would genuinely help your team?" | The reciprocity question for a peer: it shows you are thinking about his load, not only your own onboarding | [generic] |
| R3 | "Where does the line sit today between your team's work and what this role would own, and where is it still being drawn?" | Takes the seam from B1 into the real organization, and signals you will propose principles rather than assume a boundary | [generic] |
| R4 | "How is the bundling threat showing up in deals today, and what would you want data on that you don't have?" | Speaks to the stated competitive threat in a data-driven interviewer's terms, and invites him to name a gap you could help with | [grounded] |
| R5 | "Where do enterprise expansion and profitability pull against each other for the new lines, in your view?" | Shows you see the tension D1 names, and asks for his pricing-side view of it | [grounded] |
| R6 | "How does our VP decide when the two of us see a trade-off differently?" | A peer-appropriate question about decision rights, drawn from the shared reporting line you described | [grounded] |

## Prohibited claims

What this pack will not coach, and why. Each entry's basis decides its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Has carried or set quotas, or has sales-ops experience | A negative your notes state, F6 | The plain acknowledgment: "I don't have classic sales-ops or quota-setting experience." Its source is the quote "No classic sales-ops or quota-setting experience". No slot |
| That the annual volume targets were quotas | Inflated form of F5 | F5's quote at its own scope: "set annual volume targets with cross-org consensus". The limit is the pack's observation: the material says volume targets |
| That Priya drove, delivered or generated the ~$400M uplift | Inflated form of F2 | F2's quote at its own scope: "proposed a store-surface change credited with a ~$400M ARR uplift". The limit is the pack's observation: proposed, and credited with |
| That Priya designed or ran partner motions, or led carrier negotiations | Inflated form of F4 | F4's quote at its own scope: "built a partner-level revenue model used in carrier negotiations". The limit is the pack's observation: a model used in negotiations. C2's slot stays inside the model |
| That Priya owned go-to-market strategy for product launches | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: strategy and ops work at a consumer-tech company |
| That Priya has built, launched or sold an AI product | Inflated form of F7 | F7's quote at its own scope: "uses AI tools daily" |

## Sources

Provided documents: your message (the role and company, the JD highlights, the notes on Priya, the notes on Dan, and the research note on Northwind's priorities and competitive threat). The research note's own sources and date were not supplied, so its facts are used as given and not independently checked. No dossier was supplied.

Searches and fetches sent: none.

Research tier: L0 — no searches

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | You said you had everything needed, so this ran as L0. It would have supplied published value names for VAL themes; section 10 stays out because no values-style round is documented in your description of the single session |
| 2. Northwind interview process, GTM strategy roles | skipped | Your own words establish the loop: one 60-minute conversation with a peer. That fixes the persona weights |
| 3. Northwind strategy and recent news | skipped | Your research note supplies the three priorities and the main threat; it feeds D1, D2, E3 and R4 to R5 |
| 4. Dan Kovac, Northwind | unavailable | A name was given, but this ran as L0. A search would have fed the interviewer read and a sharper R1 from his public talks or writing |
| 5. Representative Senior GTM Strategy Lead JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions, though they are highlights, not the full text |

## Upgrade menu

- The full JD text → the six highlight requirements become the JD's exact lines, and any requirement beyond the highlights gets a row and a question
- Priya's CV text → fit-snapshot quotes come from her own lines instead of your notes, which can raise a row from medium once an inspectable artifact is named, such as the revenue model or the memo behind the ~$400M credit
- Priya's own answers to the answer slots on F1, F2, F3, F4, F5 and F7 → those rows' bridges and the guidance on A1 to A3, B2, C2, C4 and E2 become her stories, quoted, instead of slots
- The recruiter's guidance (focus areas, whether a case or presentation is expected, who else is in the loop) → coverage reweighted, and a build section for any announced deliverable
- A research pass, offered once → up to 6 searches and 2 fetches for Northwind's published values and loop, a freshness check on the research note, and Dan's public footprint, which would sharpen R1 and the interviewer read; a deeper pass adds up to 6 more searches and 2 more fetches and several more minutes, for the strategy brief and recent org context
- Northwind's published values, only if the loop turns out to include a values round → a values and principles cheat sheet mapped to Priya's stories
- The prep time available → a prioritized schedule sized to it
- A tuesday-dossier.md, if you have one → verified evidence and per-gap strategy constraints in place of the notes-level evidence used here
