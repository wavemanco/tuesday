I'll read the skill's reference files before building the assessment.
## Decision snapshot

**Yes, this is worth applying for. Status: `conditional_go`.** R1 and R2, the hard gates, are met, and the posting gives its own reason to expect a fair look from someone who has not held a caseload (RR4, RR5).

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3 · unclear: R4 (Clear, timely written records)
- `important` — direct: R5a, R7 · adjacent: R5b (Leg-ulcer care), R6 (Catheter and continence care), R9 (Small caseload of your own, care planning) · unclear: R8 (End-of-life visits)
- `preferred` — absent: R10 (Doppler assessment)

R9 — a real bridge in the discharge-to-assess home visits, its limit named; R4 — a CV silence to close, not a capability concern; R10 — preferred, and you have said you have not done it.

**Opportunity ledger.** Calderbrook is attributable as a real employer, but I could not confirm the vacancy is live (RR1). The pay range sits across a market survey's middle spread (RR2). The supported caseload and the team lead's published interest in training new community staff are positives (RR4, RR5). The working pattern is unstated (RR3).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the vacancy confirmed live and open, RR1; (2) record-keeping evidence from you for R4, so the CV can say it truthfully; (3) the working pattern checked against whatever you need it to be, RR3.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015, 410 staff, four locality hubs | `[grounded]` its About page, from search |
| Mandate | A district nursing post caring for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin administration, care planning | `[grounded]` posting |
| Caseload and support | A small caseload of your own, with a senior community nurse supporting | `[grounded]` posting |
| Pay and car | £31,050–£37,800 plus mileage; pool cars provided | `[grounded]` posting |
| Team lead | Rhiannon Mabbott leads the Halifax district nursing team after eleven years as a district nurse; at the 2025 forum she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` forum speaker page, search snippet only, not fetched |
| Scope read | An ordinary Band 5 community post: one nurse's caseload, no management duties stated | `[inferred]` from the posting listing no supervisory duties |
| Market calibration | Survey of community staff nurses at Band 5 in England: median £34,300, middle range £32,400–£36,600. The posting's range spans that middle range. The survey is England-wide, not Calderbrook's offer | `[generic]` Wardround 2026 pay guide, one search; `[grounded]` posting figures |
| Unknowns | Rota, weekends and on-call; how the caseload is built up; whether Doppler training is provided; whether the vacancy is open | — |
| Contradictions | None found. My one fetch of a guessed careers address returned no page, which is not evidence the posting is absent | `[grounded]` fetch result |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | CV states registration active, revalidation due March 2028. Self-reported, nothing inspected; checking the public register is yours to do | `[grounded]` CV | none |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | CV states full licence, category B; pool cars are provided. Self-reported, not inspected | `[grounded]` CV and posting | none |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward. Experience length is graded as fit, not a gate | `[grounded]` CV | none |
| R4 | Clear, timely written records (on the electronic patient record) | must_have | unclear | low | discovery | CV says nothing on documentation or electronic records. Ward nursing normally involves records, but that is a pattern, not your evidence | `[grounded]` CV silence; `[generic]` ward practice | Question G1 |
| R5a | Wound care | important | direct | medium | presentation | CV lists pressure ulcers and surgical wounds. It sits in a skills list; the role leads with wound care | `[grounded]` CV | E2 pending approval |
| R5b | Leg-ulcer care | important | adjacent | medium | transferability | Pressure-ulcer and surgical-wound care carries over. Limit: nothing in the CV on leg ulcers or compression | `[inferred]` adjacency from the wound care listed | Bridge case G5 |
| R6 | Catheter and continence care | important | adjacent | medium | discovery | CV states catheter care only. Continence care is not mentioned | `[grounded]` CV | Question in G4 below; no question asked this turn |
| R7 | Insulin administration | important | direct | medium | none | Stated in the CV. The posting pairs it with care planning, which sits in R9 | `[grounded]` CV | none |
| R8 | End-of-life visits | important | unclear | low | discovery | CV silent. Palliative work may have occurred on an acute ward but nothing says so | `[grounded]` CV silence | Question G2 |
| R9 | A small caseload of your own, with care planning | important | adjacent | medium | transferability | You said you have never held your own caseload. Bridge: 18 months on discharge-to-assess, visiting patients at home in their first week. Limit: those visits were not a standing caseload, and care planning is not in the CV | `[grounded]` CV and your statement; `[inferred]` the bridge | Question G3 |
| R10 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You said you have not done one. It is desirable, not essential | `[grounded]` your statement and posting | Closure path in G6 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Written records (R4, must_have) | discovery | The CV is silent on documentation and electronic records | An essential criterion with nothing behind it; closing it is the most likely route from `conditional_go` to `go` | Using an electronic patient record on the ward; discharge documentation; audits or feedback on record quality | An audit result, a line from an appraisal or reference | `[grounded]` CV silence; `[inferred]` that closing it moves the status |
| G2 | End-of-life care (R8, important) | discovery | Nothing in the CV | End-of-life visits are named in the posting, and the team lead's background is district nursing | Caring for dying patients on the ward; anticipatory prescribing or symptom control; family conversations; rapid discharges home for end of life | A reference line, a thank-you card kept for training, a training certificate | `[grounded]` CV silence; `[generic]` that district nursing posts probe this |
| G3 | Own caseload (R9, important) | transferability | Home visits on discharge-to-assess; no caseload held | Likely the main objection at interview | Planning your own visit list; deciding when to escalate; following patients through the first week | A discharge-to-assess service description or visit log, anonymised | `[inferred]` bridge; `[generic]` that this is the likeliest objection |
| G4 | Continence care (R6, important) | discovery | Catheter care stated, continence not | Named in the posting | Bladder and bowel care plans; continence assessments; catheter trials without catheter | A training record or care plan template | `[grounded]` CV |
| G5 | Leg-ulcer care (R5b, important) | transferability | Wound care is strong; leg ulcers not stated | The team lead has published interest in nurse-led leg-ulcer clinics | Compression bandaging, venous ulcer dressings, wound reviews on medical patients | Training certificate or wound assessment form | `[grounded]` CV, forum page |
| G6 | Doppler (R10, preferred) | capability | None, as you said | Desirable only | A Doppler or leg-ulcer course would be the closure path | A course booking or certificate | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Vacancy not confirmed live | unknown | — | "Community Staff Nurse, Band 5 — Calderbrook Community Health CIC, Halifax" | The posting may sit on a careers page or jobs board I did not reach, or may have closed | `[inferred]` from the About page pointing to a careers page I could not load | Is this vacancy still open, and when does it close? | unresolved |
| RR2 | Pay sits within market range | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The range is in line with a national survey of Band 5 community nurses | `[grounded]` posting; `[generic]` survey is England-wide | Where in the range would my experience place me at appointment? | noted |
| RR3 | Rota and hours unstated | unknown | — | "end-of-life visits, insulin administration" | Insulin and end-of-life visits may bring evening or weekend work | `[generic]` district nursing pattern; not a claim about Calderbrook | What is the working pattern: weekends, late visits, on-call? | unresolved |
| RR4 | Supported caseload and a named contact | positive_signal | — | "supported by a senior community nurse"; "informal chat" | The role is built for a nurse building up a caseload | `[grounded]` posting | How is the caseload built up for someone new to community work, and for how long is it supervised? | noted |
| RR5 | Doppler desirable; team lead has spoken on training new staff | positive_signal | — | "Desirable: Doppler assessment for leg ulcers" | Training may be available | `[grounded]` posting and speaker page; `[inferred]` that training may be offered | Is Doppler training provided to new starters, and how soon? | noted |

## Application plan

Everything here, the table and the prose beneath it alike, is proposed. Nothing is applied until you approve it. The CV edits are `resume_edits_pending_approval`.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with the secondment. Proposed line: "Registered Nurse (Adult); five years as a staff nurse on an acute medical ward, the last 18 months seconded to the discharge-to-assess team, visiting patients at home in their first week after discharge." | Every clause is from your CV; it puts your home-visiting work first (R9) | `[grounded]` CV | pending your approval |
| E2 | Move wound care ("pressure ulcers and surgical wounds") out of the skills list into an experience bullet | R5a | `[grounded]` CV | pending your approval |
| E3 | Add a records line only after you answer G1 | R4 | `[grounded]` row R4 | pending your approval |
| A1 | Take up the informal chat with Rhiannon Mabbott. Proposed framing: "I have not held my own caseload or done a Doppler assessment; my home visiting has been on a discharge-to-assess secondment. How is a new nurse brought onto a caseload, and is Doppler training provided?" | Covers R9, R10, RR4, RR5, and states the gaps as you gave them | `[grounded]` your statements and posting | pending your approval |
| A2 | Confirm the vacancy is live before drafting anything (RR1) | Cheapest check first | `[grounded]` RR1 | pending your approval |
| A3 | Ask the RR3 question in the chat or interview | Rota affects whether the role works for you | `[grounded]` RR3 | pending your approval |

## Evidence status

Verified: none yet. Your National Insurance number is not needed for this and I have not used it; there is no need to send it again.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax district nursing", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about); fetched calderbrookhealth.example/careers, a guessed address, which returned no page. Role reality's organization row; RR1 |
| 2. Role-family sweep | yes | Searched "community staff nurse Band 5 district nursing Agenda for Change pay 2026/27 Doppler training requirement", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Market calibration and RR2; nothing came back on Doppler |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Role reality's team lead row; A1, RR5 |

If you'd like me to save this as a dossier file, I can write `tuesday-dossier.md`.

## Upgrade menu

- A link to the live posting or Calderbrook's careers page → RR1 closes and the first condition clears.
- Your answer on records (G1) → R4 moves from `unclear` toward `direct`, and `go` becomes likely.
- A record-quality audit, appraisal or reference line → R4 could reach `high`.
- Your answer on end-of-life care (G2) → R8 moves.
- A discharge-to-assess service description → R9's bridge strengthens.
- Your pay floor, preferred hours and any rota limits → hard-gate checks against you stop being unknown.
- A deeper research pass on Calderbrook (up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

G1 — On the ward, did you use an electronic patient record, and has anyone ever commented on the quality or timeliness of your notes (audit, appraisal, reference)?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G2 — Have you cared for patients at the end of life on the ward, and what was your part (symptom control, family conversations, rapid discharge home)?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G3 — On the discharge-to-assess secondment, did you plan your own visit list and decide when to escalate, or did someone else direct it?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.