I'm reading the rest of the skill's reference files and loading the search tools. I'll then check whether Fernquay can be found online before writing the assessment.
**Worth applying to and worth taking the call, on conditions. I can't confirm Fernquay is a real, live employer from here. Status: `conditional_go`.**

I tried four web searches to check the company and its co-founder, and the host refused all of them. So the legitimacy question rests on what you pasted, not on anything I looked up.

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Salary €52,000–€60,000 plus equity)
- `must_have` — direct: R3, R4, R5, R6 · adjacent: R7 (Own the booking flow end to end)
- `important` — adjacent: R8 (First designer, no design peers)

R7 — checkout is a real bridge, its limit named; R8 (`low`) — never the only designer, so the bridge is thin.

**Opportunity ledger.** Plausible but unverified: the employer is not established from here (RR1), the first-contact route is unverified (RR2), and the equity terms are unstated (RR3). The scope carries some sole-designer risk (RR5). One entry runs the other way: the pay band and work pattern are stated openly (RR6).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Fernquay verifies as a real employer with this role live on its own site, RR1; (2) the invite email and the WhatsApp number tie back to Fernquay, RR2; (3) the pay band clears your own floor, R2; (4) the checkout bridge is framed as adjacent, never as owning a whole booking flow, R7 and R8.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: six people in Galway, booking software for sea-kayak and surf schools; two engineers, a CTO named Saoirse, and a co-founder named Ronan Kehoe | `[grounded]` posting and message you pasted; existence not checked |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship alongside two engineers | `[grounded]` posting |
| Working pattern | Hybrid, two days a week in the Galway office | `[grounded]` posting |
| Pay | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting |
| First-year outcomes | Not stated | `[grounded]` posting is silent |
| Scope read | One person covering design, research and shipping, reporting closely to a co-founder, which is a bundled-specialisation pattern at a small company | `[inferred]` from the posting's list of duties against the team size it gives |
| Market calibration | Not run. The role-family search was refused, so I give no salary band and won't use memory for one | no source |
| Contact route | The co-founder wrote to you on WhatsApp and sent the invite by email. The call is on video, and it's the CTO and co-founder who will be on it | `[grounded]` your message |
| Unknowns | Equity terms; first-year outcomes; whether the role is live on a Fernquay site; the sender domain of the invite | — |
| Contradictions | None visible between the posting and the message. The posting wasn't compared against a careers page | `[grounded]` provided text only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week at the Galway office | hard_gate | direct | medium | none | You said you moved back to Galway last year, so the commute term is met on your own statement. Intake prose is self-report, so it stays at `medium` | `[grounded]` your intake message | Confirm which days, and whether they're fixed |
| R2 | Salary €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | You haven't given a pay floor, so nothing settles whether the band meets it. Confidence grades your statement of a floor, and none exists yet | `[grounded]` posting states the band; your floor not given | Question 1 |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company, which exceeds the three the posting asks for. CV-equivalent prose, no artifact read | `[grounded]` your stated background | none |
| R4 | Strong Figma | must_have | direct | medium | none | You use Figma daily. No file or portfolio has been inspected, so `medium`. A linked case study would raise it | `[grounded]` your stated background | Offer a link to the checkout case study |
| R5 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. "Run" is yours by your statement; the posting's school-owner calls are a similar format with a different audience | `[grounded]` your stated background | none |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your stated background | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | transferability | Adjacent: you redesigned a travel company's checkout. Limit: checkout is one stage of a booking flow, and nothing you've said covers the stages before it or the ones around it. The strengthener is any work you owned beyond checkout | `[inferred]` bridge from the checkout redesign you described | G1 |
| R8 | Be the first and only designer | important | adjacent | low | transferability | Your design work was always inside a team with other designers. You owned a flow redesign, which is the nearest evidence. Low, because the claim to bridge is thin and no solo work is evidenced | `[inferred]` requirement from "you would be our first designer"; `[grounded]` your statement | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning the flow beyond checkout (R7, must_have) | transferability | A checkout redesign, nothing on the stages around it | The posting's duty is the whole booking flow, so scope beyond checkout is the likeliest probe | Search or availability screens you shaped; payment or confirmation emails; an amends-and-cancellations flow; anything you led end to end rather than in one slice | A case-study page or a Figma flow screenshot with your role marked | `[grounded]` your background names checkout only; `[generic]` that the whole flow is what a booking-software role probes |
| G2 | Working with no design peers (R8, important) | transferability | You've never been the only designer | A first-designer role means setting your own priorities and standards | Setting a design-system convention yourself; running a project where you made all the design calls; a side or freelance project | A solo project, even a messy one: the posting says it prefers one real project to a polished deck | `[grounded]` your statement and the posting's wording; `[generic]` that sole-designer roles hinge on self-direction |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools" | You couldn't find much online, and my own searches were refused. The company may be too new or small to have a footprint, the posting may be stale, or it may not be a real hiring employer; none of these is ranked as likely | `[generic]` pattern for six-person companies, not a claim about Fernquay | Can you point me at this role on your own careers site, and who exactly I'd be interviewing with? | unresolved |
| RR2 | First contact on WhatsApp, with an emailed invite for a video call | unknown | — | "I have emailed you a calendar invite with the video link" | The message asks you for nothing but a call time, and scheduling by chat for an interview held elsewhere is not a signal in itself. The sender is still unverified until the invite comes from a Fernquay domain and matches the posting | `[inferred]` from the message you pasted | Can you confirm the invite comes from your company email and that Saoirse will be on the call? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "0.5–1% equity" | A range with no vesting, strike price, share class or latest valuation is hard to value; startups of this size often set these later in the process | `[generic]` how early-stage equity offers are commonly structured | What are the vesting schedule, strike price and share class, and what is the current fully diluted share count? | unresolved |
| RR4 | Market fit of the pay band | unknown | — | "€52,000–€60,000" | Not calibrated, because the role-family search was refused. The band is the posting's own figure, not my reading of the market | `[grounded]` posting states it; no market source read | How was the band set, and does it move with experience? | unresolved |
| RR5 | Solo scope across design, research and shipping | risk_signal | low | "own the booking flow end to end, run research calls with school owners, and ship alongside our two engineers" | Three jobs in one title with a co-founder as the nearest design reviewer; a first hire often has no design mentor. Low, because the posting is explicit about it and names who you'd work with | `[inferred]` from the posting's duties against the team size it states | Who gives design feedback today, and what happens when the co-founder and the engineers disagree on the flow? | unresolved |
| RR6 | Pay band, work pattern and work-sample ask all stated openly | positive_signal | — | "we would rather see one messy real project than a polished deck" | The posting is transparent on pay, location and what they want to see | `[grounded]` posting | What would success look like at six and twelve months? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, open the invite email and check the sender's domain, then look for the role on Fernquay's own website or careers page. Do this independently, not through the WhatsApp thread | see RR1, RR2 | `[grounded]` RR1, RR2 | pending your approval |
| A2 | Ask RR1, RR3, RR5 and RR6's questions verbatim during the call. Ask Saoirse about equity terms and how the engineers work | the register doubles as call preparation | `[grounded]` register | pending your approval |
| P1 | Describe the checkout project as checkout, with its stages and outcomes, and say plainly that you haven't owned a whole booking flow or been the sole designer | see R7, R8 | `[grounded]` R7, R8 rows | pending your approval |
| W1 | A short write-up of one real project you shaped end to end, in whatever state it's in, since the posting says it prefers that to a polished deck | see R7, R8, RR6 | `[grounded]` posting wording | pending your approval |
| A3 | Don't send any documents, personal details or payment information until A1 is done | see RR1, RR2 | `[generic]` ordinary caution while a new employer is unverified | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | A search for the company was sent and refused. It would have settled whether Fernquay exists as described and whether the role is live, and so RR1 and the contradictions row |
| 2. Role-family sweep | unavailable | A search for product-designer pay in Ireland was sent and refused. It would have given the market calibration line and let RR4 be judged |
| 3. Hiring manager's public footprint | unavailable | The co-founder's name was given and a search for his public professional background was sent and refused. It would have fed the scope read and which story to lead with on the call |

## Dossier offer

If you want a saved `tuesday-dossier.md` with all of this, I can produce it. Nothing above depends on it.

## Upgrade menu

- Allowing web searches → RR1 and the contradictions row can be settled, RR4 gets a calibrated band, and the co-founder's public background feeds the scope read.
- The invite email's sender domain, and the link where you first saw the posting → RR1 and RR2.
- Your pay floor and any other non-negotiables → R2 resolves, and the hard-gates line stops flagging unknown constraints.
- A link or screenshots of the checkout case study → R4 and R7 can rise to `high`, and the bridge to the full flow can be checked.
- One real project you owned beyond checkout, or alone → G1 and G2 narrow.

## Questions

1. **R2** — What is the lowest salary and the minimum days in the office you'd accept, and is there anything else that's a hard no for you?
2. **RR1, RR2** — Where did you find and apply to this posting (their site, a job board, email), and does the invite email come from an address on Fernquay's own domain?
3. **G1, G2** — Have you owned any part of a booking flow beyond checkout, or any project where you made all the design calls yourself? What did you own, and what happened?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.