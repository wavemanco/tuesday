**Decision snapshot: no-go on the opportunity. Don't send anything, and don't lodge the cheque.**

- **Opportunity verdict:** `no_go`. This matches a known pattern, a fake-job scam combining identity theft with a cheque overpayment fraud. `[inferred]` from the messages. I did not verify the company.
- **Fit verdict:** separate and irrelevant here. Your background (courier customer service, Zendesk, Excel tracking, training new starters) would suit a real order-processing role, but a real role isn't what's on offer.
- **Hard gates:** your €30,000 floor is unknown against this role. The posting says "up to €26 an hour" for 15–30 hours and gives no guaranteed figure. This is moot given the red flags below.
- **Research tier: L0, no searches.** I judged this from the text you pasted and did not check Velloway Logistics.

## Role reality `[inferred]`

| What they said or did | Why it's a red flag |
|---|---|
| The whole process runs on Telegram, with no call or video, and you "passed screening" immediately | Real employers interview you, and they don't hire through a chat handle |
| They asked for your IBAN, PPS number and passport photo before any contract | This is identity theft material. A real employer collects these after a signed offer, through an HR system. |
| They asked you to pay €349 for a "work kit", to be refunded later | Advance-fee fraud. Legitimate employers don't make you buy equipment and wait for a refund. |
| They are posting you a €2,850 cheque and want you to keep €350 and send on the rest | This is the classic overpayment scam. The cheque looks fine at first, and you send them real money. Days or weeks later it bounces and you owe the bank the full amount. |
| The HR contact is a free-style "postmail" address and the hiring contact is a Telegram handle | No verifiable company presence |
| The job is "no experience needed" at up to €26/hr plus commission | Pay far above what the work is worth is a standard lure |

The €350 "bonus" is the bait. The €2,500 you'd transfer is your own money by the time the cheque is returned unpaid.

## What to do now

1. **Send nothing.** That means no IBAN, no PPS number and no passport photo. Don't pay the €349, and don't lodge any cheque that arrives. If one does arrive, don't pay anything out against it.
2. **Stop replying.** Don't argue with them. Block the Telegram account after you've saved screenshots.
3. **Report it.** Tell your bank's fraud team, report it to the Gardaí, and report the account to Telegram and to the jobs site that hosted the posting.
4. **If any details did go out,** tell your bank straight away. For a PPS number or passport, contact the relevant agency about identity-fraud protection. You said you haven't sent anything, so this shouldn't apply.

Your instinct to check before pasting your IBAN was right.

## If you want a real job like this

Your actual strengths point to openings in customer operations, order processing, dispatch or support-team lead roles. They'd pay toward your €30k floor, and the employer would be one you can verify. Look for ones with a named company, a careers page you can reach independently, a video or phone interview, and a signed contract before any bank or ID details are requested.

I can offer a written record of this assessment as a `tuesday-dossier.md` file if you'd like one. It's optional.

Upgrade menu: if you share the posting link, the jobs-site name, or the recruiter's email domain, I can run research on whether Velloway Logistics exists. That wouldn't change the verdict, since the messages are enough on their own.

Questions:
1. Has anything arrived by post yet, or have you replied to the €349 request?
2. Would you like me to look for real order-processing or customer-operations roles that match your experience and your €30k floor?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.