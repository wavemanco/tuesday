I'll read the skill's reference files before building the assessment.
Duinvaart is worth your time and Kroonhaven isn't. The assessment follows, in the skill's fixed order.

## Decision snapshot

**Duinvaart Cold Chain, Operations Analyst: yes, worth applying to · `conditional_go`.**
**Kroonhaven Foods, Supply Planner: no, not worth your time. K2, K4 and K6, must-haves with no planning evidence behind them, are `absent` · `no_go`.**

### Duinvaart (D rows)

**Fit ledger.**
- `hard_gate` — unclear: D1 (Hybrid, three days a week in Rotterdam)
- `must_have` — direct: D2, D3, D4, D5a; unclear: D5b (Temperature compliance tracking)
- `important` — direct: D6
- `preferred` — adjacent: D7 (Dutch a plus)

D5b — temperature compliance, not yet seen in your background; D7 — conversational Dutch against a "plus", its limit named.

**Opportunity ledger.** The scope is concrete (DR4), but the employer isn't verified (DR1), the salary is absent from the posting (DR2) and the commute against your base is unknown (DR3).
- **Hard gates:** none failed; unconfirmed: D1 (Hybrid, three days a week in Rotterdam); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) D1 is workable for you; (2) the temperature-compliance gap closes or proves small (D5b, G1); (3) Duinvaart is confirmed as a live, real employer (DR1).

### Kroonhaven (K rows)

**Fit ledger.**
- `hard_gate` — unclear: K1 (On-site in Utrecht)
- `must_have` — adjacent: K5 (Fluent Dutch); unclear: K3 (Advanced Excel); absent: K2 (3+ years FMCG supply or demand planning), K4 (SAP IBP or similar planning system), K6 (Own the 13-week supply plan)
- `important` — adjacent: K7 (Run the weekly S&OP meeting)

K2, K4, K6 — you told me you've never worked in planning; K5 — conversational Dutch against fluent; K7 — a credible bridge, its limit named.

**Opportunity ledger.** The role looks coherent, but the employer is unverified (KR1) and the salary is absent from the posting (KR2).
- **Hard gates:** none failed; unconfirmed: K1 (On-site in Utrecht); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **What would have to be different for `no_go` to change:** K2, K4 and K6 would need real planning evidence. Wording can't supply it, and nothing in what you've told me points to it.

## Role reality

**Duinvaart**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam; runs a refrigerated fleet | `[grounded]` posting header; existence not checked (DR1) |
| Mandate | Track on-time delivery and temperature compliance, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` posting |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` posting |
| First-year outcomes | Not stated | `[grounded]` posting silent |
| Scope read | A reporting-and-advising analyst post; the posting doesn't say who decides route changes | `[inferred]` from "work with depot managers on route changes" |
| Market calibration | Not run, because the role-family sweep was refused (see Evidence status) | — |
| Unknowns | Salary, contract type, reporting line, source of the temperature data | `[grounded]` posting silent |
| Contradictions | None inside the posting; not checked against a careers page | `[grounded]` posting only |

**Kroonhaven**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, Utrecht; chilled ready-meals range | `[grounded]` posting header; existence not checked (KR1) |
| Mandate | Own the 13-week supply plan, balance production capacity against forecast, run the weekly S&OP meeting | `[grounded]` posting |
| Working pattern | On-site in Utrecht | `[grounded]` posting |
| Scope read | A planning-owner post, not a support post | `[inferred]` from "own" and "run" |
| Market calibration | Not run (sweep refused) | — |
| Unknowns | Salary, contract type, which planning system is actually in use | `[grounded]` posting silent |
| Contradictions | None inside the posting; not checked against a careers page | `[grounded]` posting only |

## Evidence map

Your background is typed self-report, which has the same standing as a CV. That caps your claims at `medium` until something inspectable backs them.

**Duinvaart**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| D1 | Hybrid, three days a week in the Rotterdam office | hard_gate | unclear | none | hard_gate | You haven't stated a base or a commute limit. Your current job is in Amsterdam, which says nothing about where you live | `[grounded]` posting; your base not given | Question Q2 |
| D2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | 4 years as an operations analyst at a parcel carrier, from your own account, with no artifact inspected | `[grounded]` your background | none |
| D3 | Strong SQL | must_have | direct | medium | none | You use SQL daily; the depth of your queries hasn't been seen | `[grounded]` your background | none |
| D4 | Power BI or Tableau | must_have | direct | medium | presentation | Power BI daily, including the on-time delivery dashboard depot managers use. Your exact role in building it isn't stated, so no ownership verb is safe yet | `[grounded]` your background | Q3, then edit E1 |
| D5a | Track on-time delivery across the fleet | must_have | direct | medium | none | The dashboard you work on is an on-time delivery dashboard; the setting is parcels, not a refrigerated fleet | `[grounded]` your background | none |
| D5b | Track temperature compliance | must_have | unclear | none | discovery | Nothing you've told me touches temperature or chilled service. It may exist, so this is not yet `absent` | `[grounded]` silence in your background | Q1 |
| D6 | Work with depot managers on route changes | important | direct | medium | none | You ran the weekly route-performance review and your dashboard is used by depot managers | `[grounded]` your background | none |
| D7 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational Dutch, which is not fluent. The posting only asks for it as a plus, and the limit stays named wherever it's used | `[grounded]` your statement | none |

**Kroonhaven**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| K1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | Your base isn't known and the posting offers no remote option | `[grounded]` posting; your base not given | Surface only; see G4 |
| K2 | 3+ years of supply or demand planning in FMCG | must_have | absent | none | capability | You said you've never worked in planning, and a parcel carrier isn't FMCG | `[grounded]` your statement | Closure path in G4 |
| K3 | Advanced Excel | must_have | unclear | low | discovery | Analyst work makes it plausible, but you named only SQL and Power BI | `[grounded]` silence in your background | G3 |
| K4 | SAP IBP or a similar planning system | must_have | absent | none | capability | SQL and Power BI are reporting tools, not planning systems | `[grounded]` your background | Closure path in G4 |
| K5 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational Dutch is the adjacent evidence. The limit is that it isn't fluent, and the posting says fluent. Planning meetings are probably held in Dutch | `[grounded]` your statement; `[inferred]` about meeting language |  none |
| K6 | Own the 13-week supply plan, balancing capacity and forecast | must_have | absent | none | capability | No planning ownership in your background | `[grounded]` your statement | Closure path in G4 |
| K7 | Run the weekly S&OP meeting | important | adjacent | medium | transferability | You ran a weekly route-performance review, which is the same chairing skill. The limit is that S&OP reconciles demand, supply and finance, and your review covered route performance | `[grounded]` your background; `[inferred]` bridge | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Temperature compliance (D5b, must_have) | discovery | Nothing about temperature-controlled or time-critical service in your background | It's the one core duty of this role your evidence doesn't yet touch, and resolving it could move D5b | Chilled or pharma-grade parcel lanes at your carrier; any delivery-condition measure you tracked (damage, time-window, cold-pack failures); a service-level breach report | A sanitized report, a screenshot of the metric, a KPI definition | `[grounded]` silence on temperature; `[inferred]` that it decides the positioning |
| G2 | Ownership of the on-time dashboard (D4, must_have) | presentation | The dashboard is yours to use; whether you built, maintained or consumed it is unstated | The bullet can only carry a verb you can defend in an interview | Designing the data model, writing the SQL behind it, or changes depot managers made because of it | A dashboard screenshot with figures sanitized | `[grounded]` your wording; `[inferred]` that ownership is the open point |
| G3 | Advanced Excel (K3, must_have) | discovery | Excel isn't mentioned | It matters only if you pursue Kroonhaven | Pivot or modelling work, macros, forecasting sheets | A sanitized workbook | `[grounded]` silence in your background |
| G4 | Planning capability (K2, K4, K6, must_have) | capability | No credible direct evidence, by your own account | No wording closes it. A realistic closure path is a planning-adjacent role first, or formal S&OP and planning-system training | Nothing in your history, as stated | A planning certification or coursework | `[grounded]` your statement; `[generic]` that a first planning role normally comes before one that owns the plan |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| DR1 | Employer not established from attributable sources | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | The employer may be too small to have a footprint, the posting may be stale, or it may not represent a live hire. The check was refused here, so none of these is ranked | `[generic]` pattern, not a claim about this company | Can you point me to this role on your careers site, and who would I interview with? | unresolved |
| DR2 | Salary absent from the posting | unknown | — | (The pasted posting has no salary line) | The posting may withhold pay or the figure may not have been copied | `[inferred]` from the pasted text | What salary range is budgeted for this post? | unresolved |
| DR3 | Hybrid office days against your base (D1) | unknown | — | "three days a week in our Rotterdam office" | The commute may or may not suit you | `[inferred]` from the posting against your Amsterdam employer | Is the three-day pattern fixed, and which days? | unresolved |
| DR4 | Scope is concrete | positive_signal | — | "Track on-time delivery and temperature compliance ... build weekly dashboards" | The duties are specific and measurable | `[grounded]` posting | Who owns the temperature data source today? | noted |
| KR1 | Employer not established from attributable sources | risk_signal | medium | "Kroonhaven Foods, Utrecht" | Same possibilities as DR1, none ranked | `[generic]` pattern, not a claim about this company | Can you point me to this role on your careers site? | unresolved |
| KR2 | Salary absent from the posting | unknown | — | (The pasted posting has no salary line) | As DR2 | `[inferred]` from the pasted text | What salary range is budgeted for this post? | unresolved |

## Application plan

**Duinvaart only.** All rows are proposals.

**resume_edits_pending_approval**

| # | Proposed line | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | "On-time delivery dashboard in Power BI and SQL, used by depot managers" (no ownership verb until Q3 is answered) | D4, G2 | `[grounded]` your words | pending your approval |
| E2 | "Ran the weekly route-performance review with depot managers" | D6 | `[grounded]` "I ran our weekly route-performance review" | pending your approval |
| E3 | "Dutch: conversational" (never "fluent") | D7 | `[grounded]` your statement | pending your approval |

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check the live posting on Duinvaart's own careers page before investing | DR1 | `[grounded]` register | pending your approval |
| A2 | Put a line about delivery-condition tracking in the cover note only if G1 turns up real evidence | D5b | `[grounded]` row D5b | pending your approval |
| A3 | Ask the DR2 and DR3 questions verbatim in the first call | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A4 | Skip Kroonhaven, and look for roles that ask for analysis rather than planning ownership | K2, K4, K6 | `[grounded]` rows K2, K4, K6 | pending your approval |

## Evidence status

Verified: none yet. Your background is self-report that I haven't confirmed or inspected.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Duinvaart Cold Chain Rotterdam" and "Kroonhaven Foods Utrecht chilled ready meals"; both were refused. It would have confirmed whether each employer exists and the posting is live (DR1, KR1) |
| 2. Role-family sweep | unavailable | Searched "operations analyst logistics Rotterdam salary Netherlands" and "supply planner FMCG Netherlands salary SAP IBP requirements"; both were refused. It would have set market calibration, and DR2 and KR2 against a pay band |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I haven't retried the searches.

I can write this up as a `tuesday-dossier.md` whenever you like.

## Upgrade menu

- Allowing web search → targets 1 and 2 run: DR1 and KR1 resolve, and role reality gets a market calibration.
- An answer to G1 → D5b moves off `unclear`.
- A sanitized dashboard screenshot → D4 can rise toward `high`, and E1 can carry an ownership verb.
- A hiring manager's name for either role → role reality's scope read and the plan's positioning.
- Your base and commute limit → D1 resolves, and K1 resolves if Kroonhaven is ever revisited.

## Questions

1. **G1** — Did your carrier have any chilled or time-critical service? Did you ever track a delivery-condition or temperature-type measure, and what was yours to do?
2. **D1** — Where are you based, and is three days a week in Rotterdam workable?
3. **G2** — On the on-time delivery dashboard, did you build it, maintain it, or mainly use it? Did depot managers change anything because of it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.