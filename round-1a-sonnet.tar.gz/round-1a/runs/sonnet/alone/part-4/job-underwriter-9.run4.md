**Yes, for the data requests: asking for bank details, PPS number and passport after a written offer that names the role and pay is routine onboarding (RR2). Your rule is right for the stage before an offer, or when you can't tell who is asking. So verify the sender and the portal link first (RR1, RR2). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: R2 (Hybrid, two days in Limerick office), R3 (Salary €38,000–€42,000)
- `must_have`: direct: R4, R7, R9, R11 · adjacent: R6 (Run monthly payroll for 240 staff) · unclear: R5 (Irish PAYE, PRSI and USC)
- `important`: unclear: R10 (Answer staff payroll queries) · absent: R8 (Process pension changes)

R5 — Irish tax knowledge isn't shown in what you pasted; R8 — a real gap, one you've already named; R6 (`medium`) — a step up in scale, not a new skill.

**Opportunity ledger.** A routine onboarding request sits beside a sender domain I couldn't check (RR1, RR2) and contract terms the offer doesn't state (RR3). The offer matches the ad on the points that can be compared (RR4, RR5).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Hybrid, two days in Limerick office), R3 (Salary €38,000–€42,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the sender's email domain and the portal address are confirmed as Marrowgate's own (RR1, RR2); (2) you have the written terms before you accept (RR3); (3) you tell them early that you haven't done pension changes (R8), and you confirm the Irish PAYE, PRSI and USC knowledge is yours to claim (R5).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick; its existence and the email domain are not confirmed from outside what you pasted | `[grounded]` ad and offer as pasted |
| Mandate | Monthly payroll for 240 staff, starters, leavers, pension changes, payroll-to-ledger reconciliation, staff queries | `[grounded]` ad |
| Reports to | Declan Garvagh, Finance Manager | `[grounded]` offer |
| Working pattern | Permanent, hybrid, two days a week in the Limerick office; start date agreed after your notice period | `[grounded]` offer |
| Scope read | Looks like a one-person payroll function: no payroll team or peer is mentioned, so nobody visible would handle the pension changes you haven't done | `[inferred]` from the ad listing every duty under one role |
| Market calibration | Not established. €40,000 sits inside the ad's own €38,000–€42,000 range, and I have no market band to set against it | `[grounded]` ad and offer for the figures |
| Unknowns | Probation, pension scheme, leave, payroll software, portal address, written contract | — |
| Contradictions | None between ad and offer on title, hybrid pattern or salary band | `[grounded]` pasted ad against pasted offer |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Payroll qualification or working towards one | hard_gate | direct | medium | none | Payroll Technician certificate, 2024; stated by you, certificate not seen | `[grounded]` your background | none |
| R2 | Hybrid, two days a week in the Limerick office | hard_gate | unclear | low | hard_gate | You interviewed in person at the office, but your constraints on commuting weren't given | `[grounded]` offer; constraints not given | Q2 |
| R3 | Salary €38,000–€42,000 | hard_gate | unclear | low | hard_gate | The offer is €40,000, inside the ad's range; your floor wasn't given | `[grounded]` ad and offer; floor not given | Q2 |
| R4 | 2+ years running payroll | must_have | direct | medium | none | Three years of fortnightly payroll for 90 staff | `[grounded]` your background | none |
| R5 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | Your background doesn't say whether the hotel-group payroll or the certificate was Irish | `[grounded]` silence in what you pasted | Q1 |
| R6 | Run monthly payroll for 240 staff | must_have | adjacent | medium | transferability | Same work at 90 staff and fortnightly; scale and frequency are the differences | `[grounded]` your background | name the scale step honestly |
| R7 | Process starters and leavers | must_have | direct | medium | none | Stated directly | `[grounded]` your background | none |
| R8 | Process pension changes | important | absent | none | capability | You say your manager handled these | `[grounded]` your statement | tell them early; ask about handover or training |
| R9 | Monthly payroll-to-ledger reconciliation | must_have | direct | medium | none | Stated directly | `[grounded]` your background | none |
| R10 | Answer staff payroll queries | important | unclear | low | discovery | Nothing pasted about handling staff queries | `[grounded]` silence in what you pasted | see G3 |
| R11 | Strong Excel | must_have | direct | medium | none | Daily use, pivot tables, XLOOKUP; no inspectable sample | `[grounded]` your background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Irish PAYE, PRSI, USC (R5, must_have) | discovery | Payroll experience and a certificate, with no country or tax regime stated | A must-have the whole role runs on; a small gap now is a big one in month one | Irish payroll runs, Revenue submissions, the certificate's Irish tax modules | The certificate's syllabus | `[grounded]` silence in your background |
| G2 | Pension changes (R8, important) | capability | You've never done them | You'd be the only payroll person, so no one may be there to take them | Only what is true: preparing or checking changes for your manager's sign-off, or answering pension queries | None inspectable | `[grounded]` your statement; `[inferred]` single-person function |
| G3 | Staff payroll queries (R10, important) | discovery | Nothing stated | Part of the daily job | Any payslip or deduction queries you handled at the hotel group | None needed | `[grounded]` silence in your background |
| G4 | Scale and frequency (R6, must_have) | transferability | 90 staff fortnightly against 240 monthly | A reasonable bridge, but the size difference is real | Peak-season or multi-site runs | A sanitized run summary | `[grounded]` your background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and email domain not confirmed from here | risk_signal | low | "Marrowgate Housing, a housing association in Limerick" | I couldn't check the entity or the `marrowgate.example` domain; your two in-person interviews point the other way, so I rate it low rather than medium | `[grounded]` checks refused; `[generic]` small employers are often thin online | Can you confirm the People Team's contact details so I can check them against your website? | unresolved |
| RR2 | Bank, PPS and passport requested via a portal after acceptance | unknown | — | "Once you accept, we will send you a link to our onboarding portal, where you add your bank details for salary payments, your PPS number for Revenue, and a scan of your passport for our right-to-work check." | Routine after a written offer naming role and pay; what's open is whether the link, when it comes, is Marrowgate's own system | `[generic]` onboarding pattern; `[grounded]` offer text | Can you confirm the portal's web address and that it's on Marrowgate's own domain? | unresolved |
| RR3 | Contract terms not stated | unknown | — | "starting on a date we agree once your notice period ends" | The offer says permanent but gives no probation, pension scheme, leave or written contract | `[grounded]` offer silence | Can you send the written contract or statement of terms before I accept? | unresolved |
| RR4 | Salary inside the advertised range | positive_signal | — | "€40,000 a year" | The offer matches the ad's €38,000–€42,000 | `[grounded]` ad and offer | Is the pension scheme employer-contributory? | noted |
| RR5 | Offer consistent with the ad and the process | positive_signal | — | "bring the original passport on your first day" | Title, hybrid terms, named manager, two in-person interviews, and an in-person ID check all fit a real hire | `[grounded]` your account and the offer | Who else is on the finance team? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check the sender's domain against any earlier emails from them, and contact them through details you already hold, not the offer email | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | When the portal link arrives, check its address and use it only through that route; don't email documents | see RR2 | `[generic]` standard practice | pending your approval |
| A3 | Ask for written terms before replying; ask for a short extension if they take longer than the five working days | see RR3 | `[grounded]` RR3 | pending your approval |
| A4 | Say plainly you haven't done pension changes and ask about training or cover; don't describe it as experience | see R8, G2 | `[grounded]` R8 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search "Marrowgate Housing Limerick housing association" was refused. It would have moved role reality's organization row and RR1 |
| 2. Role-family sweep | unavailable | Search "Payroll Administrator salary Ireland 2026 Limerick" was refused. It would have given the market calibration row a band |
| 3. Hiring manager's public footprint | unavailable | Search "Declan Garvagh Finance Manager Marrowgate Housing" was refused. It would have moved the scope read |

I can offer a `tuesday-dossier.md` of this assessment whenever you want one.

**Upgrade menu**

- Allowing web search → RR1 and role reality's organization row could close, and R3 would get a market band.
- The offer email's full sender address and an earlier email from them → RR1 closes either way.
- The certificate's syllabus or a note on whether your payroll was Irish → R5 goes to `direct` or stays a flagged risk.
- Your salary floor and commute limits → R2 and R3 resolve.

**Questions**

1. (R5, G1) Was the hotel-group payroll run under Irish PAYE, PRSI and USC, and was the 2024 certificate an Irish course?
2. (R2, R3) Are €40,000 and two days a week in Limerick both acceptable to you, or is there a non-negotiable I haven't got?
3. (RR1) Does the offer email's sender domain match the address on the ad or on the emails that arranged your interviews?

Answer in text, attach a document, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.