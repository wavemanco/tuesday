Searches were denied, so I'm treating this as L0 and still need the worked report format and the reframing audit. Reading those, then I'll write the assessment.
**Is it worth it, and is it legit?** Yes, take the call, but check that Fernquay exists as described first. The status is `conditional_go`. On your background you fit the core asks (R3, R4, R5, R6, R7a are `direct`). I couldn't establish the company myself, and nothing in the posting or the WhatsApp message asks for money, ID or a chat-only process (RR3).

## Decision snapshot

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Salary €52,000–€60,000)
- `must_have` — direct: R3, R4, R5, R6, R7a · adjacent: R7b (Own the booking flow end to end)
- `important` — adjacent: R8 (Research calls with school owners), R9 (First designer, no design peers)

R7b — the stretch is whole-flow ownership, its limit named; R9 (`low`) — the real question is whether you want to be the only designer; R2 — depends on your pay floor.

**Opportunity ledger.** Nothing asks you for payment, ID or a chat-only process (RR3), and the WhatsApp channel alone isn't a signal (RR2). Open items: the employer is unverified by me (RR1), the equity terms are unstated (RR4), the sole-designer scope is untested (RR5), and the salary is uncalibrated (RR6).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Fernquay verifies as a real, hiring company (RR1, RR2); (2) the pay and equity terms meet your floor (R2, RR4, RR6); (3) the sole-designer scope is something you want, and decision rights are clear (R9, RR5).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, booking software for sea-kayak and surf schools. This is the posting's own description, not checked by me | `[grounded]` JD |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship with two engineers, work most closely with co-founder Ronan Kehoe | `[grounded]` JD |
| Terms | €52,000–€60,000 plus 0.5–1% equity; hybrid, two days a week in the Galway office | `[grounded]` JD |
| Outcomes | No first-90-days or first-year outcomes and no success measures stated | `[grounded]` JD silent |
| Scope read | Design, research and flow ownership are folded into one first-hire post | `[inferred]` from the JD's three duties against the "first designer" line |
| Market calibration | Not done. The role-family search was refused, so there is no band to set the salary against | `[grounded]` search refused, see Evidence status |
| Unknowns | Stage and funding, equity terms, decision rights, how success is measured | — |
| Contradictions | None found between the posting and the message. "Loved the checkout case study" fits your having applied with one | `[grounded]` posting and message as pasted |

## Evidence map

Your background is self-report, so claims sit at `medium` at most until something inspectable is attached.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week in the Galway office | hard_gate | direct | medium | none | You live in Galway and gave no constraint against office days. Confidence is `medium` because you haven't stated a constraint either way | `[grounded]` your move back to Galway | none unless office days are a problem for you |
| R2 | Salary €52,000–€60,000 | hard_gate | unclear | none | hard_gate | You gave no pay floor, so there is nothing to check the band against | `[grounded]` JD; no floor stated | Q3 below |
| R3 | 3+ years of product design | must_have | direct | medium | none | 4 years as a product designer at a Dublin travel-booking company, self-reported | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | Daily use, no portfolio inspected. A design portfolio is the inspectable proof in this field | `[grounded]` your background | share the portfolio or case study link |
| R5 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. That is evaluative testing, so what it shows about discovery interviews is limited (see R8) | `[grounded]` your background | none |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | Worked in a squad with four engineers | `[grounded]` your background | none |
| R7a | Booking-flow design: the checkout | must_have | direct | medium | none | You redesigned checkout at a travel-booking company, and the message names your checkout case study | `[grounded]` your background and the WhatsApp message | none |
| R7b | Own the booking flow end to end | must_have | adjacent | medium | transferability | Checkout is one part of a booking flow. Limit: your history doesn't show you owning the whole flow, from search to confirmation. A case study showing the scope you held would narrow it | `[grounded]` your background; `[inferred]` that checkout is only part of the flow | see G1 |
| R8 | Research calls with school owners | important | adjacent | low | transferability | You've run customer sessions, but your role gives no sign of calls with the owners of small businesses. Limit: owner interviews are a different kind of research from usability testing | `[inferred]` from your described sessions against the JD | see G2 |
| R9 | First designer, no design peers | important | adjacent | low | transferability | You have never been the only designer. Limit: nothing shows you setting design direction unreviewed or building process from scratch | `[inferred]` from "first designer" in the JD; `[grounded]` your statement | see G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Sole-designer and whole-flow ownership (R9, R7b) | transferability | Strong squad and checkout work. No evidence of unreviewed design decisions or whole-flow scope | The JD makes this the core of the job, and it is the likeliest probe on the call | A side or freelance project where you were the designer; a component library or pattern set you started; a decision you made with no senior designer reviewing it | A case study that shows the decisions you took and the messy parts | `[grounded]` your statement; `[inferred]` that this is the likeliest probe |
| G2 | Research with business owners (R8) | transferability | Usability sessions with customers, nothing with the businesses behind the bookings | The role is B2B research with school owners | Calls with tour operators, hotels or suppliers on your old platform; sitting in on support or sales calls; interviewing partner operators | A research summary or a session guide | `[inferred]` from the JD against your described sessions |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools." | The company may be too new or small to have a footprint, the posting may be stale, or it may not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | First contact on WhatsApp, with the invite sent by email | unknown | — | "I have emailed you a calendar invite with the video link." | Interviews held on video with a named CTO is a normal process. The sender of the invite isn't checked, and I don't know how your number reached them | `[grounded]` message text; `[inferred]` that the sender is unchecked | Could you send the invite from your company address, and which video platform will we use? | unresolved |
| RR3 | The ask is only a video call with two named people | positive_signal | — | "Could you do a 45-minute video call with me and Saoirse, our CTO?" | No payment, ID, bank details or chat-only process is requested | `[grounded]` message as pasted | Who else will I meet, and what are the stages after this call? | noted |
| RR4 | Equity stated as a range with no terms | unknown | — | "0.5–1% equity" | Vesting, share class and strike terms may be undefined | `[inferred]` from the posting's silence | What are the vesting schedule and share class, and what does 0.5–1% mean on the current cap table? | unresolved |
| RR5 | Scope without stated authority or success measures | unknown | — | "own the booking flow end to end, run research calls with school owners" | The first hire may carry three jobs without decision rights or research access | `[inferred]` from the JD's duties against its silence on authority | Who decides when design and engineering disagree, and what research access to school owners exists today? | unresolved |
| RR6 | Salary band not calibrated | unknown | — | "€52,000–€60,000" | The band may sit above, in line with, or below the norm for this seniority; I can't say which | `[grounded]` search refused, no band in hand | Is the band fixed, and where would my experience place me in it? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, check Fernquay from your side: its product site, its company registration, and Ronan's and Saoirse's professional profiles. Confirm the invite's sender domain matches the company's own site. Share no payment or ID details with anyone | see RR1, RR2 | `[generic]` ordinary checks on a small employer | pending your approval |
| A2 | Take the call and ask the verification questions of RR1, RR2, RR4, RR5 and RR6 verbatim | The register doubles as call prep | `[grounded]` register | pending your approval |
| A3 | Lead with the checkout redesign and your monthly usability sessions, worded as you gave them: you redesigned the checkout flow, ran monthly usability sessions with customers, and worked in a squad with four engineers. Say plainly that you haven't been the only designer. Don't claim whole-flow ownership | see R7a, R5, R7b, R9 | `[grounded]` your own sentences | pending your approval |
| W1 | Prepare one honest, messy-real-project write-up of the checkout work: what went wrong, what you cut, and what was yours versus the squad's | The posting says "we would rather see one messy real project than a polished deck" | `[grounded]` JD quote | pending your approval |

No CV edits are proposed, because I haven't seen your CV.

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Fernquay booking software sea kayak surf schools Galway"; the call was refused (permission not granted). It would have moved RR1 and role reality's organization and contradictions rows |
| 2. Role-family sweep | unavailable | Searched "product designer salary Ireland 2026 first designer startup equity"; the call was refused. It would have moved the market calibration row and RR6 |
| 3. Hiring manager's public footprint | unavailable | Searched "Fernquay Ronan Kehoe co-founder"; the call was refused. It would have moved the scope read and the positioning in A3 |

I can write this up as `tuesday-dossier.md` if you'd like to keep it.

## Upgrade menu

- Permission for web search, or the text of Fernquay's site or careers page pasted here → RR1 clears or hardens, and the market calibration and Ronan's published professional background become available.
- Your portfolio or the checkout case study link → R4, R3 and R7a can rise to `high`, and G1 and G2 get a sharper read.
- The domain the calendar invite came from → RR2 settles. I don't need the full address.
- Equity terms or a written offer outline → RR4 and R2 settle against your floor.

## Questions

**G1** — Is there a project, paid, side or volunteer, where you made design decisions with no other designer reviewing them, and what did you own?
**G2** — Did you ever speak with the businesses behind the bookings (operators or suppliers), rather than end customers?
**R2 / R1** — What is your minimum salary, and are two office days a week in Galway fine for you?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.