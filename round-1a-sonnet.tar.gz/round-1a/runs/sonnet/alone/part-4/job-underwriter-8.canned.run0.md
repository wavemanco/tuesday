**Decision snapshot**

**Not worth applying to, and do not send anything. Status: `no_go`.** This is a scam. The messages follow a known pattern: they harvest your identity, then run a fake-cheque overpayment. The IBAN, PPS number and passport photo are what a fraudster needs to impersonate you or use your account.

**Fit ledger.**

- `hard_gate` — unclear: R1 (€30,000 a year minimum)
- `must_have` — direct: R2, R3
- `important` — direct: R4

- **Hard gates:** none failed; unconfirmed: R1 (€30,000 a year minimum). The pay terms can't be relied on because the employer can't be.
- **Severe red flags:** RR1, RR2, RR3 and RR4. Any one of them is enough to stop.

Your background fits the posting well (R2–R4). That fit is why you were targeted, and it is not a reason to proceed.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics". I have not checked whether it exists, and nothing in the messages points to a real company. | `[grounded]` posting and chat; existence unchecked |
| Role | Remote order processing, 15–30 hours a week, up to €26 an hour plus commission, no experience needed | `[grounded]` posting |
| Hiring process | Telegram only, no calls or video, "passed" screening and interview with no real assessment | `[grounded]` your messages |
| Contact | A generic webmail-style address, not a company domain | `[grounded]` message; `[inferred]` that it isn't a company domain |
| Market calibration | Genuine order-processing and customer-service-adjacent roles are normally advertised with a named employer, a company email domain and a video or phone interview. Pay is usually a flat hourly or salaried rate. | `[generic]` role-family pattern |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Your floor of €30,000 a year | hard_gate | unclear | low | hard_gate | At €26 an hour you'd need about 22 hours a week all year to reach €30,000. "Up to €26" is a ceiling, 15 hours a week would give about €20,000, and nothing in the posting guarantees hours or a rate. | `[grounded]` posting and your stated floor; `[inferred]` arithmetic | Moot unless the employer is verified |
| R2 | Attention to detail, confident with spreadsheets | must_have | direct | medium | none | You keep the team's weekly Excel tracker. | `[grounded]` your account | none |
| R3 | Good written English | must_have | direct | medium | none | Three years of written customer support in Zendesk at about 60 tickets a day. | `[grounded]` your account | none |
| R4 | Order handling and training | important | direct | medium | none | Parcel-courier tickets and training two new starters. | `[grounded]` your account | none |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Guaranteed income (R1) | hard_gate | Pay is described only as "up to" a rate, with a 15–30 hour range | Your floor can't be checked | None needed | A written contract from a verifiable employer | `[grounded]` posting |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | ID and bank details requested before any real interview | red_flag | severe | "send your IBAN, your PPS number and a clear photo of your passport" | Identity theft or mule-account setup. Real payroll needs these only after a signed contract. | `[inferred]` from the sequence; `[generic]` that this is a standard fraud pattern | None worth asking | resolved: stop |
| RR2 | You pay the employer for equipment | red_flag | severe | "Please pay €349 by bank transfer to our equipment partner" | Advance-fee fraud. Legitimate employers don't charge staff for equipment. | `[generic]` | None worth asking | resolved: stop |
| RR3 | A cheque to bank in, with most of it forwarded on | red_flag | severe | "keep €350... transfer the rest to our equipment partner" | Fake-cheque scam. The cheque looks like it clears and the money shows in your account. Days or weeks later it bounces, and you owe the bank the €2,500 you sent, plus you may be drawn into money laundering. | `[generic]` | None worth asking | resolved: stop |
| RR4 | Telegram-only hiring, no calls, instant "passed" | red_flag | high | "no calls or video interviews", "you passed the interview" | There was no real vetting, and the scammer wanted to avoid being identified or recorded. | `[inferred]` | None worth asking | resolved: stop |
| RR5 | Unrealistic terms | risk_signal | medium | "No experience needed", "up to €26 an hour plus commission" | Bait aimed at people with exactly your skills | `[generic]` | None | noted |

**Application plan**

This role has no application plan, because I'm not recommending you apply. What to do:

1. **Send nothing:** no IBAN, no PPS number, no passport photo, no €349. Don't paste your IBAN into the chat.
2. **Don't lodge the cheque** if one arrives. If you already did, tell your bank at once.
3. **Stop replying**, then block and report @VellowayHiring on Telegram and report the posting to the jobs site.
4. **Report it** to An Garda Síochána or your bank's fraud team if any money or documents have gone out. Your bank can also advise you if you want to be careful about your IBAN. You only shared it with me, not with them.
5. **Keep searching for real roles.** Your Zendesk, Excel and training experience is genuine and sellable for customer-operations and logistics coordination roles. Check the employer's own careers page and a company email domain before sharing anything, and expect a live interview.

**Evidence status**

Research tier: L0 — no searches

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Official site and careers page | skipped | The verdict rests on the messages themselves. A website wouldn't change it, because the requests alone are disqualifying. |
| 2 | Role-family sweep | skipped | The posting's pay is moot once the employer is rejected. |
| 3 | Hiring manager's footprint | n/a | No hiring manager was named. |

I can offer a `tuesday-dossier.md` of this assessment if you'd like to keep it.

**Upgrade menu**

- A link to the live posting would let me check whether the jobs site still lists it, and help you report it.
- A CV or LinkedIn profile would let me point you at roles that fit your skills, rather than relying on your summary.
- A permission to run L1 research, up to 5 searches and 2 page fetches, would check whether Velloway Logistics exists at all. It won't change the verdict.

**Questions**

1. (RR1–RR3) Have you sent or paid anything so far, such as ID details in the chat or any money? If so, what, and when?
2. (Upgrade menu) Shall I run the L1 research on Velloway, or is the verdict enough?
3. (Application plan) Do you want help finding genuine customer-operations roles, given your €30,000 floor?

You can answer briefly, skip any of them, or ask for something different.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.