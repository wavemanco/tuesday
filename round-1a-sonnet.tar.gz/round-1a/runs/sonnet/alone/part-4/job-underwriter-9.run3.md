Checking that Marrowgate Housing exists as described, and what Irish payroll roles usually pay. Both searches are running now.
## Decision snapshot

**Yes, this is normal. Worth accepting on the conditions below. Status: `conditional_go`.**

Asking for bank details, PPS number and passport after you accept, through a portal, is standard for a payroll role. Your rule against handing these over is right for unsolicited requests, such as before any offer, by email or WhatsApp, or alongside a fee. This request doesn't look like that. It comes after two in-person interviews and a written offer, and each item has a clear use: bank details for salary, PPS for Revenue, and the passport for the right-to-work check. You're also being asked to run exactly this process for 240 colleagues. `[generic]`

**Fit ledger.**

- `hard_gate`: unclear: R1 (Hybrid, two days in the Limerick office)
- `must_have`: direct: R2, R4, R5, R7, R8 · adjacent: R6 (Monthly payroll for 240 staff) · unclear: R3 (Irish PAYE, PRSI, USC)
- `important`: absent: R9 (Pension changes) · unclear: R10 (Answering staff payroll queries)

- **Hard gates:** none failed; unconfirmed: R1 (Hybrid, two days in the Limerick office). Your own constraints weren't given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. Confirm the portal link really comes from Marrowgate before entering anything (RR1, RR2).
  2. Get the full terms in writing before you give notice anywhere (RR3).
  3. Raise pension changes (R9) as a handover or training point, not as something you'll quietly cope with.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick | `[grounded]` JD and offer as pasted. Existence not independently confirmed (RR2). |
| Mandate | Monthly payroll for 240 staff, starters and leavers, pension changes, payroll-to-ledger reconciliation, staff queries | `[grounded]` JD |
| Reports to | Declan Garvagh, Finance Manager | `[grounded]` offer email |
| Pay | €40,000, against a posted €38,000–€42,000 | `[grounded]` JD and offer |
| Working pattern | Permanent, hybrid, two office days a week | `[grounded]` offer |
| Scope read | The duties are ordinary for a payroll administrator. The 240 headcount is about 2.7 times your current 90. | `[inferred]` from your stated 90-staff scope |
| Market calibration | Not established. The pay search was refused, so I can't say where €40k sits. | `[generic]` |
| Unknowns | Probation, notice, pension scheme, leave, start date, who handles pension changes today, portal data-retention terms | — |
| Contradictions | None between the JD and the offer | `[grounded]` both texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in the Limerick office | hard_gate | unclear | low | hard_gate | The term is stated. Your location and commute constraints weren't given. | `[grounded]` offer, constraints unknown | Question 2 |
| R2 | 2+ years running payroll | must_have | direct | medium | none | You have 3 years, with fortnightly payroll for 90 staff. This is your own account, not an inspectable document. | `[grounded]` your background | none |
| R3 | Working knowledge of Irish PAYE, PRSI, USC | must_have | unclear | low | discovery | You didn't say the hotel payroll was Irish. It's likely, but I won't assume it. | `[grounded]` your background is silent on jurisdiction | Question 1 |
| R4 | Strong Excel | must_have | direct | medium | none | You use it daily, with pivot tables and XLOOKUP. | `[grounded]` your background | none |
| R5 | Payroll qualification or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024. The certificate itself wasn't shown. | `[grounded]` your background | none |
| R6 | Run monthly payroll for 240 staff | must_have | adjacent | medium | transferability | You have the same process at 90 staff on a fortnightly cycle. The limit is scale and frequency. | `[inferred]` from your stated scope | Say it plainly if asked. |
| R7 | Process starters and leavers | must_have | direct | medium | none | You do this in your current role. | `[grounded]` your background | none |
| R8 | Reconcile payroll to the general ledger monthly | must_have | direct | medium | none | You do the monthly reconciliation now. | `[grounded]` your background | none |
| R9 | Process pension changes | important | absent | none | capability | Your manager handled these, so there's no hands-on evidence. This is the real gap. | `[grounded]` your own statement | Question 3 and plan A4 |
| R10 | Answer staff payroll queries | important | unclear | low | discovery | You didn't mention staff queries. This is probably covered by your current duties. | `[grounded]` background silent | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pension changes (R9, important) | capability | You've never processed them. Your manager did. | It's a named duty, and mistakes affect staff pensions. | Preparing pension deduction inputs, checking scheme contributions on payslips, or handling AVC or opt-out forms for the manager | A sanitized example of a payroll check that included pension lines | `[inferred]` that you saw some of this work indirectly |
| G2 | Irish statutory knowledge (R3, must_have) | discovery | The CV doesn't say the payroll was Irish | It's the core technical requirement | The payroll jurisdiction, and Revenue filing or RPN handling | Payslip layout with details removed, or the payroll software name | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Data collection comes after acceptance, via a portal | positive_signal | — | "Once you accept, we will send you a link to our onboarding portal" | A legitimate employer needs these items only once you're hired. Scammers usually ask before any offer. | `[generic]` hiring-scam pattern | Is the portal address on Marrowgate's own website or the one HR gives you by phone? | noted |
| RR2 | Employer existence not confirmed, and the sender domain is `marrowgate.example` | unknown | — | "people@marrowgate.example" | `.example` is a reserved placeholder domain, so this may just be how the text was anonymized for me. If your real email shows that domain, treat it as a serious warning. | `[inferred]` from the domain, `[generic]` on what `.example` is | Does the offer in your inbox come from the same domain as the company's website? | unresolved |
| RR3 | The offer omits core contract terms | unknown | — | "starting on a date we agree once your notice period ends" | No probation, notice, pension scheme, leave or hours are stated in the email. A contract may follow. | `[inferred]` from the email's silence | Can you send the full contract and terms before I accept and give notice? | unresolved |
| RR4 | Passport scan held in a portal | unknown | — | "a scan of your passport for our right-to-work check" | Employers must check the right to work, but how long the scan is kept depends on their policy. | `[generic]` | Is there a privacy notice covering retention for the passport scan and PPS? | unresolved |
| RR5 | Pay position against the market is unknown | unknown | — | "€40,000 a year" | €40k is mid-band against a posted €38–42k. I can't say how that compares to Limerick market rates. | `[grounded]` JD band, `[generic]` market unestablished | none for now | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Phone the People Team on a number from Marrowgate's own website, not one in the email. Confirm the offer and the portal link. | RR1, RR2 | `[grounded]` risk register | your call |
| A2 | Ask for the written contract and full terms before you accept or give notice. | RR3 | `[grounded]` risk register | your call |
| A3 | Enter the details only in the portal, once the A1 check passes. Don't email the passport or PPS. Take the original passport on day one as asked. | RR1, RR4 | `[generic]` | your call |
| A4 | Tell Declan you haven't processed pension changes yourself and ask who supports the first few cycles. | R9, G1 | `[grounded]` R9 | your call |
| A5 | Ask for the privacy notice that covers the retention of your ID and PPS. | RR4 | `[generic]` | your call |

## Evidence status

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company official site and careers page | `unavailable` | The search "Marrowgate Housing Limerick housing association" was refused, so the employer is unverified. It would have moved RR2, the decision status and role reality. |
| 2 | Role-family sweep | `unavailable` | The search "payroll administrator salary Ireland Limerick 2026" was refused. It would have moved the market calibration and RR5. |
| 3 | Hiring manager's public footprint | `skipped` | You already hold the offer, so positioning for this reader changes nothing in the rows or the plan. |

## Dossier offer

If you'd like it, I can write all of this up as a `tuesday-dossier.md` file.

## Upgrade menu

- Permission for a search on Marrowgate Housing would confirm or fail RR2 and could lift the decision from `conditional_go`.
- A pay search would settle RR5 and show whether there's room to negotiate.
- A look at the real sender address in your inbox, with the domain only and nothing personal, would resolve RR2 directly.
- A sanitized sample of a payslip or pension-related check from your current job would lift R3 and G1 to `medium`.

## Questions

1. **(R3)** Was the hotel group's payroll Irish, with PAYE, PRSI and USC, and Revenue filing?
2. **(R1)** Do you have any non-negotiables, such as a salary floor, a maximum commute or a notice period?
3. **(R9)** Have you ever prepared or checked pension deductions, even without final sign-off?

You can answer, say "skip" on any of them, or ask me to proceed with what I have.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.