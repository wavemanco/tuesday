Still reading the skill's reference files (evidence model, risk and decision rules) before I write the assessment. I'll have it for you shortly.
**Yes, it's worth applying, on conditions. Status: `conditional_go`.** R1 and R2, the hard gates, are met on what you've told me. R4 and R10 are the rows the CV doesn't settle, and RR1 is the posting I couldn't confirm is live.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3 · unclear: R4 (Clear, timely written records)
- `important`: direct: R5, R8 · adjacent: R6 (Leg-ulcer care), R7 (Catheter and continence care), R9 (Own small caseload and care planning) · unclear: R10 (End-of-life visits)
- `preferred`: absent: R11 (Doppler assessment)

R9 — the main bridge: home visiting without caseload ownership; R4, R10 — CV silent, recoverable by a question; R11 — a real gap that the advert marks as desirable, not essential.

**Opportunity ledger.** The role reads as sound and transparent: pay is stated (RR3), support is named (RR2), and the team lead has a public record on Doppler training (RR6). Three things are unstated or unconfirmed: the posting's liveness (RR1), the visiting rota (RR4) and when mileage applies (RR5).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) R4 and R10 confirmed from your own experience; (2) the vacancy confirmed open (RR1); (3) the caseload and leg-ulcer bridges stated as adjacent, never as caseload or leg-ulcer experience you don't have (R9, R6).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC: adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015; 410 staff; four locality hubs | `[grounded]` About page (search result; page not fetched) |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin, care planning, on an electronic patient record | `[grounded]` JD |
| Support | A small caseload of your own, supported by a senior community nurse | `[grounded]` JD |
| Essential terms | NMC Adult registration, full UK driving licence, at least one year post-registration, clear and timely records | `[grounded]` JD |
| Scope read | An entry-level community post: a small own caseload under named senior support, not an independent-practitioner role | `[inferred]` from "small caseload" plus "supported by" |
| Team lead | Rhiannon Mabbott leads the Halifax district nursing team after eleven years as a district nurse; spoke in 2025 on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` Community nursing forum speaker page (search result) |
| Market calibration | Community staff nurse, Band 5, England: survey median basic pay £34,300, interquartile range £32,400 to £36,600. The posting's £31,050–£37,800 spans that range, so no pay mismatch shows. This is a role-family band, not this employer's offer | `[generic]` Wardround 2026 UK Community Nursing Pay Guide (search result); `[grounded]` JD for the posted range |
| Unknowns | Visiting rota and weekend or on-call cover; caseload size; when mileage is paid; whether the vacancy is live | `[grounded]` JD silent |
| Contradictions | None between the JD and the About page. The careers page was not located (RR1) | `[grounded]` About page; fetch result |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | CV states Registered Nurse (Adult), registration active, revalidation due March 2028. Self-reported; the NMC register is the inspectable artifact, and checking it is yours | `[grounded]` CV | none |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | CV states a full UK licence, category B. Pool cars are provided, so the licence is the gate, not owning a car | `[grounded]` CV; `[grounded]` JD | none |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward. A length-of-experience term is graded as a requirement, not a gate | `[grounded]` CV | none |
| R4 | Clear, timely written records, on an electronic patient record | must_have | unclear | low | discovery | The CV is silent on documentation and on any record system. Ward nursing involves records, but you haven't stated what you used or how, so I don't credit it | `[grounded]` CV silence | G1 question |
| R5 | Wound care | important | direct | medium | none | CV: wound care including pressure ulcers and surgical wounds | `[grounded]` CV | none |
| R6 | Leg-ulcer care | important | adjacent | medium | transferability | Pressure-ulcer and surgical-wound care is credible adjacent work. Limit: you haven't stated leg-ulcer or compression therapy experience | `[grounded]` CV; `[inferred]` adjacency | G4 question |
| R7 | Catheter and continence care | important | adjacent | medium | discovery | Catheter care is stated; continence care is not. The lower reading holds until you say more | `[grounded]` CV | G5 |
| R8 | Insulin administration | important | direct | medium | none | CV: insulin administration | `[grounded]` CV | none |
| R9 | A small caseload of your own; care planning for housebound adults at home | important | adjacent | medium | transferability | Strongest bridge: 18 months seconded to a discharge-to-assess team, visiting patients at home in their first week after discharge. Limit, in your words: you've never held your own caseload. Care planning isn't stated in your CV | `[grounded]` CV and your message; `[inferred]` adjacency | G3, E1 |
| R10 | End-of-life visits | important | unclear | low | discovery | The CV is silent. Acute medical wards often care for dying patients, but that is a pattern and not your history | `[grounded]` CV silence; `[generic]` ward pattern | G2 question |
| R11 | Doppler assessment for leg ulcers (desirable) | preferred | absent | none | capability | You've said you have never done one. The advert lists it as desirable, not essential. The team lead has spoken on Doppler training for staff new to community work, so training may be offered | `[grounded]` your message; `[grounded]` speaker page; `[inferred]` that training may be available | Ask in the informal chat (A1) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Records and electronic patient record (R4, must_have) | discovery | No record system or documentation practice stated | A `must_have` row at `unclear`; the one that could move the status most easily | Using an electronic patient record on the ward or in the discharge team; written visit notes after home visits; handover documentation | The name of the system used; an audit result or a reference mentioning documentation | `[grounded]` CV silence; `[inferred]` that it is quickly recoverable |
| G2 | End-of-life visits (R10, important) | discovery | The CV is silent on palliative or end-of-life care | End-of-life visits are a named duty | Caring for dying patients on the ward; anticipatory prescribing or syringe-driver involvement, if any; family conversations; rapid discharges home to die | A competency record or training certificate | `[grounded]` CV silence |
| G3 | Caseload and care planning (R9, important) | transferability | Home visiting in discharge-to-assess; no caseload ownership; care planning unstated | The main bridge, and the one an interviewer will test | Planning follow-up visits; deciding visit priority; liaising with GPs or social care; writing discharge care plans | A description of the discharge-to-assess service; a reference from the team's lead | `[grounded]` CV and your message; `[generic]` that interviews for this kind of post probe the caseload step |
| G4 | Leg-ulcer care (R6, important) | transferability | Wound care stated; leg ulcers and compression not | A core duty, and linked to the desirable Doppler skill | Applying compression bandaging; assessing venous or arterial ulcers; leg-ulcer clinics | A training certificate or a competency sign-off | `[grounded]` CV |
| G5 | Continence care (R7, important) | discovery | Catheter care stated; continence care not | A named duty | Bladder and bowel care plans; continence assessment | A competency record | `[grounded]` CV; not asked this turn, to stay within the question budget |
| G6 | Doppler assessment (R11, preferred) | capability | None; confirmed by you | A desirable skill, not an essential | A short accredited Doppler course; shadowing a leg-ulcer clinic | A course booking or completion | `[grounded]` your message |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Vacancy not confirmed live on the employer's careers page | unknown | — | "Community Staff Nurse, Band 5 — Calderbrook Community Health CIC, Halifax" | The employer exists as described, but I could not open its careers page at the address I tried, so liveness is unverified. The address may simply be wrong | `[grounded]` About page result; `[grounded]` fetch returned no page | Can you confirm this vacancy is open and give me its reference? | unresolved |
| RR2 | Named support for a new caseload | positive_signal | — | "supported by a senior community nurse" | Support exists in the structure, though its form is unstated | `[grounded]` JD | How does the senior nurse's support work in the first months: joint visits, a staged caseload? | noted |
| RR3 | Pay stated | positive_signal | — | "£31,050–£37,800 a year plus mileage" | Transparent pay, in line with the role-family band | `[grounded]` JD; `[generic]` band | Where in the range would five years' acute experience start? | noted |
| RR4 | Visiting rota unstated | unknown | — | "caring for housebound adults in their own homes" | The post may include weekend or evening cover; hours are not stated | `[grounded]` JD silence; `[generic]` pattern for district nursing | What does the weekly and weekend visiting rota look like for this post? | unresolved |
| RR5 | Mileage and pool cars both mentioned | unknown | — | "pool cars are provided"; "plus mileage" | Unclear when mileage is paid if pool cars are provided, and whether a car is always available | `[inferred]` from the two terms side by side | When is mileage paid, and is a pool car available on every shift? | unresolved |
| RR6 | Team lead with a public record on Doppler training for new community staff | positive_signal | — | "Doppler training for staff new to community work" (speaker page) | The team may train new starters in Doppler, which would close R11 | `[grounded]` speaker page; `[inferred]` that this means training here | Is Doppler training provided to new starters in this team? | noted |

## Application plan

All rows are proposed; none is final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Move the discharge-to-assess secondment up the CV and describe it in your own terms: "Seconded for 18 months to the hospital's discharge-to-assess team, visiting patients in their own homes in the first week after discharge." Every clause traces to your message; no caseload or care-planning claim is added | R9 | `[grounded]` your CV | `resume_edits_pending_approval` |
| A1 | Take up the advert's invitation to an informal chat with Rhiannon Mabbott. Ask the RR1, RR2, RR4 and RR6 questions in it, and ask about Doppler training | RR1, RR2, RR4, RR6 | `[grounded]` JD invitation | pending your approval |
| A2 | Say plainly in your supporting statement that you've not held your own caseload and have not done Doppler assessment, and lead with the home-visiting work you have done | R9, R11 | `[grounded]` your message | pending your approval |
| A3 | Add wound-care detail, catheter care and insulin administration from your CV as separate outcome statements, once you've confirmed what you did in each | R5, R7, R8 | `[grounded]` CV | pending your approval |

## Evidence status

Verified: none yet. Your National Insurance number isn't needed for this assessment; I haven't used or repeated it.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about); fetched calderbrookhealth.example/careers, which returned no page. Role reality: the organization row; the register: RR1 |
| 2. Role-family sweep | yes | Searched "community staff nurse district nursing Band 5 Agenda for Change pay scale 2026/27 salary", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Role reality: the market calibration row; RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Role reality: the team lead row; RR6 |

I can write up the full assessment as `tuesday-dossier.md` for you to keep, if you'd like it.

## Upgrade menu

- A link to the live posting or the vacancy reference → RR1 closes.
- The name of the record system you've used, and anything showing documentation standards → G1, R4 can reach `medium`.
- Any palliative-care training certificate or competency record → G2, R10.
- A description of the discharge-to-assess service, or a line from its lead → G3, R9 can reach `high`.
- Compression or leg-ulcer training records → G4, R6.
- Your pay floor, hours limits and any weekend or on-call limits → hard-gate checks against your constraints, which are unknown for now.
- A deeper research pass on Calderbrook (public staff and patient reports, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

Three questions, kept to the ones most likely to move the status:

G1 — Which electronic patient record or documentation system have you used, and how did you keep your notes accurate and timely on the ward and on home visits?
G2 — Have you cared for patients at the end of life, on the ward or after discharge home? What did you do yourself, and was it supported by training or sign-off?
G4 — Have you applied compression bandaging or assessed leg ulcers, even under supervision? If so, what did you do, and was it signed off?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.