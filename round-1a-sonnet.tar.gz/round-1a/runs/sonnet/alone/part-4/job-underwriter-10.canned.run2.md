I'll read the reference files first, then check whether search is available.
Research is done and the tables are built, so here is the assessment.

## Decision snapshot

**Yes, worth applying to and worth taking the call. The employer matches its own pages (RR5), and the WhatsApp message asks only for a video call (RR1). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Salary €52,000–€60,000)
- `must_have` — direct: R3, R4, R5, R6 · adjacent: R7 (Own the booking flow end to end)
- `important` — absent: R8 (Be the first and only designer)

R7 — checkout is part of booking, whole-flow ownership unconfirmed; R8 — no evidence, named plainly; R2 — waiting on your own pay floor.

**Opportunity ledger.** The posting agrees with the company's own pages and the stated pay sits inside a published band (RR4, RR5). Three things are unverified: who sent the WhatsApp message (RR1), what the equity is (RR2), and who decides product direction (RR3).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your pay floor is met by the band, R2; (2) the invite's sender is confirmed as a Fernquay address, RR1; (3) you are open on the call that you have not been the only designer, and RR3 gets a concrete answer, R8.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, Galway: makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland; six people; founded 2023 by Ronan Kehoe and Saoirse Doyle; funded by its customers | `[grounded]` search result "About Fernquay" (fernquay.example/about), page not fetched |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship with two engineers | `[grounded]` posting you pasted |
| Working pattern | Hybrid, two days a week in the Galway office; €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting; the careers page snippet repeats the pay, the hybrid pattern and "first design hire" |
| Hiring manager | Ronan Kehoe, co-founder and CEO, previously product lead at a Galway travel-software company for five years | `[grounded]` search result "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe); public professional footprint only |
| Scope read | A generalist single-designer remit: flow ownership, research and shipping with no design peer, reporting into a founder with a product background | `[inferred]` from the posting's "first designer" and "work most closely with our co-founder" against the search result on Ronan's background |
| Market calibration | Ireland, 2026, product designers with 3 to 5 years: median base €57,000, interquartile range €51,500 to €62,000. The posted band sits inside that range. The survey is national and not specific to startups or Galway | `[generic]` search result "Tillerby 2026 Ireland Design Salary Report" (n=520); `[grounded]` posting for the figure |
| Unknowns | Equity form and terms; decision rights over the booking flow; first-year outcomes (not stated); the source of the WhatsApp number; Saoirse's CTO title (the About page snippet says co-founder only) | `[grounded]` posting silence; `[grounded]` About page snippet |
| Contradictions | None found between the posting and the careers page or About page snippets | `[grounded]` search results named above |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week at the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year, so the office days are workable. You have not stated a constraint about them, and prose background is self-report | `[grounded]` your message | none |
| R2 | Salary €52,000–€60,000 (a pay term; your floor is not given) | hard_gate | unclear | none | hard_gate | The band is stated, but with no floor from you it cannot be called met or failed | `[grounded]` posting; no floor supplied | Question R2 |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company. A years requirement is graded as ordinary fit, not a gate | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily". Nothing inspectable has been read yet | `[grounded]` your background | Case study link would raise to high |
| R5 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. Limit: those were travel-booking customers, while this role's calls are with school owners, a different customer type with the same method | `[grounded]` your background; `[inferred]` the audience difference from the posting | none |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your background | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | discovery | You redesigned your company's checkout flow. Checkout is part of a booking flow, and your message does not say how much of the flow before and after it you owned | `[grounded]` your background; `[inferred]` that whole-flow ownership is the likely probe, from the posting's "end to end" | Question G1 |
| R8 | Be the first and only designer | important | absent | none | capability | You have never been the only designer anywhere. The posting says "our first designer"; this is derived from that phrase and is not a listed requirement | `[grounded]` your statement; `[inferred]` requirement from the posting | Closure path in G2; carried as a risk |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Whole-flow ownership (R7, must_have) | discovery | A checkout redesign confirmed; nothing yet on search, availability, pricing, amendments or cancellations | A `must_have` at `adjacent`; the answer decides whether it moves to `direct` | Owning steps before checkout; changes to amend or cancel a booking; a flow with timed slots or capacity limits | The checkout case study Ronan has already seen, before-and-after flows, usability session notes | `[grounded]` your message; `[generic]` that interviewers probe scope on end-to-end claims |
| G2 | Solo-designer role (R8, important) | capability | Squad experience and self-run research sessions, but no sole-designer post | Wording cannot close it; it is carried as a risk and named on the call | A small self-directed project where you set the research cadence and the priorities yourself | A one-page plan for how you would run research on Fernquay's booking flow (the posting asks for one messy real project, not a polished deck) | `[grounded]` your statement and the posting's preference; `[inferred]` the closure path |
| G3 | Pay floor (R2, hard_gate) | hard_gate | Band stated; your floor unknown | A gate that stays unconfirmed until you state it | Not applicable, since this is a term you meet or do not | None needed; your own statement settles it | `[grounded]` posting and your message |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Sender of the WhatsApp message not yet tied to the company | unknown | — | "I have emailed you a calendar invite with the video link." | The message asks only for a 45-minute video call and no money, documents or personal details. Small teams often schedule over chat, so this is probably ordinary. The sender is still unverified until the invite arrives from a company address | `[grounded]` the message text; `[generic]` that small teams often schedule by chat | Could you confirm which address the invite comes from and who will be on the call? | unresolved |
| RR2 | Equity form and terms unstated | unknown | — | "plus 0.5–1% equity" | A percentage of a customer-funded private company gives no value on its own. The form (shares or options) and the vesting are not stated | `[grounded]` posting and About page snippet ("funded by its customers"); `[inferred]` that the terms matter to value | Is the equity shares or options, and what are the vesting terms? | unresolved |
| RR3 | Decision rights over the booking flow unstated | unknown | — | "own the booking flow end to end ... work most closely with our co-founder" | With no design peer and a co-founder from product, authority over the flow may sit with Ronan | `[inferred]` from the posting's silence on decision rights and the search result on Ronan's background | Which booking-flow decisions would I make myself, and which go through you? | unresolved |
| RR4 | Pay stated and inside a published band | positive_signal | — | "Salary €52,000–€60,000" | The posting shows its figure, and that figure sits within the interquartile range for 3 to 5 years' experience | `[grounded]` posting; `[generic]` Tillerby 2026 Ireland band, national and not startup specific | Does the band flex with experience, and when are reviews? | noted |
| RR5 | Posting agrees with the company's own pages | positive_signal | — | "We are six people in Galway making booking software for sea-kayak and surf schools." | The About and careers page snippets match the team size, location, hybrid pattern, pay and first-design-hire framing | `[grounded]` search results "About Fernquay" and "Product Designer — Fernquay careers", pages not fetched | Who else would I meet in the loop besides you and Saoirse? | noted |

## Application plan

All rows are proposed. No CV edits are proposed.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, check that the invite's sender address matches the company's own domain | See RR1 | `[grounded]` RR1 and the careers page address | pending your approval |
| A2 | On the call, ask the questions in RR1 to RR3 verbatim | The register doubles as call preparation | `[grounded]` register | pending your approval |
| A3 | Say plainly that you have not been the only designer, and lead with what you have said you did: redesigned checkout, ran monthly usability sessions with customers, worked in a squad with four engineers. Do not describe setting up a research practice, which you have not told me | See R8, G2 | `[grounded]` your own sentences | pending your approval |
| A4 | Build the call around the checkout case study they already liked, which fits their stated preference for a real project over a polished deck | See R7, R4 | `[grounded]` posting and Ronan's message | pending your approval |
| A5 | Ask Ronan how his five years of product work at a travel-software company shapes how he scopes the booking flow | Ronan's background makes booking-flow reasoning a likely topic | `[inferred]` from the search result on his background | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway" (result: "About Fernquay", fernquay.example/about) and "Fernquay Product Designer job Galway" (result: "Product Designer — Fernquay careers", fernquay.example/careers/product-designer). Snippets only, no page fetched. Moved role reality's organization and contradictions rows, and RR5 |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland 2026 startup first designer Galway" (result: "Tillerby 2026 Ireland Design Salary Report", tillerby.example/2026-ireland-design-salary-report). Moved the market calibration row and RR4 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder" (result: "Ronan Kehoe — Co-founder, Fernquay", linkedin.example/in/ronan-kehoe). Moved role reality's hiring-manager and scope rows, RR3, and A5 |

## Closing

I can save this as `tuesday-dossier.md` if you want a record to keep.

**Upgrade menu**
- Your pay floor, plus any other firm lines such as the two office days → R2 resolves and the hard-gates line stops flagging it.
- A link to the checkout case study, or screenshots → R3, R4, R5 and R7 can move toward `high`, and R7 may reach `direct`.
- The address the invite came from → RR1 closes.
- The equity terms in writing → RR2 closes.
- A deeper pass on Fernquay (funding, hiring pattern, news; up to 5 more searches and 2 more fetches) → RR2 and RR5 could firm up. Say the word and it runs.

**Questions**
1. R2 — What is the lowest base salary you would accept?
2. RR1 — Which email address did the calendar invite come from?
3. G1 — How much of the booking flow beyond checkout did you personally own, such as search, availability or amendments, and what changed after your redesign?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.