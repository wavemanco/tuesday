I've read most of the skill's rules. Next I'll load the web tools so I can check whether Fernquay exists, then write the assessment.
**Short answer: yes, it's worth applying, and on the public evidence Fernquay looks legit. Status: `conditional_go`. The one condition is that the calendar invite comes from a Fernquay email address (RR3).**

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R7 (Hybrid, two days in Galway), R8 (Pay €52,000–€60,000)
- `must_have`: direct: R1, R2, R3, R4 · adjacent: R5 (Own the booking flow end to end)
- `important`: adjacent: R6 (First designer, no design peer)

R5: a close bridge via the checkout redesign, with end-to-end scope still to show; R6: the real stretch, since you've never been the only designer; R7, R8: unclear only because your constraints weren't given.

**Opportunity ledger.** The employer is established, the posting is live and the salary is stated (RR4, `positive_signal`). Open items: how equity works (RR2), what support a first designer gets (RR1), and who is on the other end of the WhatsApp thread (RR3).

- **Hard gates:** none failed; unconfirmed: R7 (Hybrid, two days in Galway), R8 (Pay €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the invite arrives from a Fernquay address and the sender matches the careers page (RR3); (2) pay and the two Galway days work for you (R7, R8); (3) you get answers on equity terms and on design support (RR1, RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. Six people, Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle, funded by its customers | `[grounded]` fernquay.example/about, from the search result |
| Posting | Live on the company's careers page with the same title, hybrid pattern, salary range and equity as your copy. The page says to apply with one real project to a Fernquay email address | `[grounded]` fernquay.example/careers/product-designer |
| Mandate | First design hire: own the booking flow, run research with school owners, ship with two engineers | `[grounded]` JD |
| Hiring manager | Ronan Kehoe is listed as co-founder and CEO, with five years before that as product lead at a Galway travel-software company. His background is close to yours, which suggests he will understand booking-flow work | `[grounded]` LinkedIn search result; `[inferred]` the closeness |
| Market calibration | €52,000–€60,000 sits inside the interquartile range of a 2026 Irish survey for designers with 3–5 years (median €57,000, IQR €51,500–€62,000). That is a market pattern, not Fernquay's offer | `[generic]` Tillerby survey; `[grounded]` JD for the posted range |
| Scope read | The scope is common for a sole designer at a small company: design, research and engineering partnership under one title. The mandate is not unusually broad | `[inferred]` from the responsibilities listed |
| Unknowns | Equity terms (vesting, strike, share count); any design mentorship; the company's revenue and runway; whether Saoirse Doyle is the CTO named in the message (the about page gives no roles) | — |
| Contradictions | None between the posting, the careers page and the about page. The only open point is the CTO title | `[grounded]` the three sources compared |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years of product design | must_have | direct | medium | none | You describe 4 years at a Dublin travel-booking company. This is self-reported; the title is not yet probed | `[grounded]` your background, self-reported | none |
| R2 | Strong Figma | must_have | direct | medium | none | You use Figma daily. An inspectable file or case study would raise it | `[grounded]` your background, self-reported | share the checkout case study (they have already seen it) |
| R3 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers, which is first-hand | `[grounded]` your background, self-reported | none |
| R4 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers, against two here | `[grounded]` your background, self-reported | none |
| R5 | Own the booking flow end to end | must_have | adjacent | medium | transferability | The checkout redesign is booking-domain, but checkout is one stage. Discovery-to-confirmation ownership isn't evidenced yet | `[inferred]` checkout covers part of the flow | see G1 |
| R6 | First designer, no design peer or lead (implied by "first designer") | important | adjacent | medium | transferability | You've always had design peers. Running your own research and redesigning checkout show initiative, not solo ownership | `[inferred]` from "first design hire" against your history | see G2 |
| R7 | Hybrid: two days a week in the Galway office | hard_gate | unclear | low | hard_gate | You live in Galway, so it is plausible. You haven't said whether two fixed office days work | `[grounded]` JD; `[inferred]` from your move back | confirm with Q1 |
| R8 | Pay €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | low | hard_gate | No floor was given, so it can't be checked against your needs. The range sits inside the survey band | `[grounded]` JD; `[generic]` survey band | confirm with Q1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Booking flow end to end (R5, must_have) | transferability | Checkout redesign only | Ownership of the whole flow is the first listed responsibility | Any work on search, availability, pricing or confirmation emails, or on cross-team journey mapping | The case study they liked, plus any journey map | `[inferred]` from the JD against your account |
| G2 | Sole-designer scope (R6, important) | transferability | Always in a design team | A sole designer sets standards, tooling and priorities with no one to check them | Setting up a component library, deciding research cadence, saying no to a request | A short example of a decision you made without review | `[inferred]` from "first design hire" |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Support for a first designer unstated | unknown | — | "You would be our first designer" | No design peer or mentor may exist, so quality calls and growth depend on you | `[generic]` common for first design hires | Who reviews your design work, and how will you get design feedback outside the team? | unresolved |
| RR2 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | The percentage may be a placeholder: no vesting, strike or share-count terms are given | `[generic]` early-stage pattern, not a claim about this employer | What are the vesting schedule, strike price and total shares outstanding? | unresolved |
| RR3 | First contact by WhatsApp | risk_signal | low | "I have emailed you a calendar invite with the video link" | Scheduling over WhatsApp is common at small companies, but I can't tell from here that the sender is Ronan, and the careers page names email as the way to apply. The message asks for no money, no documents and no ID | `[inferred]` from the message and the careers page; I can't verify the sender from here | Could you confirm the invite's sender address, and that it matches the Fernquay address on your careers page? | unresolved |
| RR4 | Salary and scope stated openly | positive_signal | — | "€52,000–€60,000", "own the booking flow end to end" | The posting is concrete about pay and responsibilities | `[grounded]` JD matches the careers page | What does success look like in your first six months? | noted |
| RR5 | Customer-funded company | positive_signal | — | "funded by its customers" | The business may not depend on outside investors, but I have no revenue or runway data | `[grounded]` about page, from the search result | What is the current customer count and revenue trend? | noted |

RR3 is a check, not an accusation. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the call with the checkout case study and your usability-session cadence, claiming adjacency for R5 and no more | R3, R5 | `[grounded]` your background | pending your approval |
| E2 | Prepare one honest example of a decision you made with no peer review, framed as growth toward sole ownership, not as past experience | R6, G2 | `[inferred]` | pending your approval |
| Q1 | Ask RR1, RR2 and RR5's questions on the call | the register doubles as call prep | `[grounded]` register | pending your approval |
| A1 | Check the invite's sender address before you accept it | RR3 | `[grounded]` RR3 | pending your approval |
| A2 | Offer to do the research and design work on one real project as they invite, instead of a polished deck | the posting asks for a "messy real project" | `[grounded]` JD | pending your approval |

Everything above, the rows and this note, is a proposal. Nothing goes to Fernquay until you approve it. Because the call is coming up, mock-interview can drill you on it.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway", which returned "About Fernquay" (fernquay.example/about), and "Fernquay product designer Galway careers", which returned "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer). Role reality (organization, posting, contradictions) and RR4–RR5. I read the search snippets only |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland startup first designer 2026", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Market calibration and R8 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe). Role reality's hiring-manager row and E1 |

I'll turn this into `tuesday-dossier.md` if you want a saved copy.

**Upgrade menu**

- Your salary floor and how firm the two Galway days are → R7 and R8 close and the hard-gates line firms up.
- The invite's sender address → RR3 closes.
- A link to the checkout case study → R2 and R5 move toward `high`.
- Equity terms from Ronan → RR2 closes.
- A deeper research pass on Fernquay (customer reviews, founder history, recent news; up to 5 more searches and 2 more fetches) → fills the gaps in RR5. Say the word and it runs.

**Questions**

1. (R7, R8) What is your minimum salary, and are two fixed days a week in the Galway office fine for you?
2. (G2) Have you ever made a design decision with no other designer reviewing it? If so, what was it?
3. (RR3) What email address did the calendar invite come from?

You can answer in text, paste a link or document, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.