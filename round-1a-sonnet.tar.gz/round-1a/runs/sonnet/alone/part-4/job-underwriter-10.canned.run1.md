I'll read the reference files the skill points to before building the assessment.
Research is done: 4 searches and 2 page reads. Here is the assessment.

# Job Underwriting — Product Designer at Fernquay

## Decision snapshot

**Yes, worth taking the call, and Fernquay checks out so far. Status: `conditional_go`.** Ronan's message says "thanks for applying", so you've already applied. The live decision is whether to take the call.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Hybrid, two days a week in Galway)
- `must_have` — direct: R2, R3, R4, R5
- `important` — adjacent: R6 (Own the booking flow end to end), R7 (First designer, no design peers)

R6 — the checkout redesign is a credible bridge to the whole flow, its limit named; R7 (`low`) — no solo-designer evidence, carried as a risk.

**Opportunity ledger.** The employer is corroborated by its own pages (RR2) and the stated pay is inside the market band (RR3). Three items are open: who the invite comes from (RR1), the equity terms (RR4), and the success measures and decision rights for a sole designer (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Hybrid, two days a week in Galway); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the calendar invite comes from a fernquay address and matches the message — RR1; (2) the call shows who sets design priorities and what success looks like for a first designer — RR5, R7; (3) the equity terms are explained — RR4; (4) two office days a week in Galway work for you — R1.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. It is six people in Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle, and funded by its customers | `[grounded]` fetched About page |
| Posting vs. careers page | Both say first design hire, hybrid with two days a week in Galway, and €52,000–€60,000 plus equity. The careers page asks for applications by email with one real project | `[grounded]` JD and fetched careers page |
| Mandate | Own the booking flow end to end, run research calls with school owners, and ship alongside two engineers | `[grounded]` JD |
| Hiring-side people | Ronan Kehoe is listed as co-founder and CEO, and was previously product lead at a Galway travel-software company for five years. The About page names Saoirse Doyle as co-founder, but not a title | `[grounded]` search snippet of his profile and the About page; his profile page was not fetched |
| First-90-days outcomes | Not stated in the posting | `[grounded]` JD silence |
| Scope read | Booking flow, research and shipping for one product at a six-person company is a coherent single-designer remit. The risk is the absence of any design peer, not bundled roles | `[inferred]` from the JD's three duties against its team size |
| Market calibration | For product designers with 3–5 years in Ireland, the Tillerby 2026 survey gives a median base of €57,000 and an interquartile range of €51,500–€62,000. The posting's range sits inside that range. This is a band, not Fernquay's offer | `[generic]` role-family sweep, one salary search; `[grounded]` JD for the posted figure |
| Unknowns | Equity terms; who sets design priorities; how success is measured; how you applied versus the careers page's email route | `[grounded]` JD and careers page silence |
| Contradictions | None found between the posting and the careers page | `[grounded]` fetched pages |

## Evidence map

Your background was typed into the chat, so it is self-report and every row is capped at `medium` until something is inspected.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in the Galway office | hard_gate | unclear | medium | hard_gate | You live in Galway, having moved back last year. You haven't said whether two office days a week suit you, so the gate is not established | `[grounded]` your statement of living in Galway; JD for the term | Question R1 below |
| R2 | 3+ years of product design | must_have | direct | medium | none | 4 years as a product designer at a Dublin travel-booking company, stated in your own words | `[grounded]` your background statement | none |
| R3 | Strong Figma | must_have | direct | medium | none | "Figma daily" across those 4 years. Ronan's message says they liked your checkout case study, which I haven't seen | `[grounded]` your statement and Ronan's message | send the case study link to raise to `high` |
| R4 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. The role's calls with school owners may be more discovery-style than usability testing | `[grounded]` your statement; `[inferred]` that the role's calls differ in style from usability sessions | none |
| R5 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your statement | none |
| R6 | Own the booking flow end to end | important | adjacent | medium | transferability | You redesigned the checkout flow, which is a stage of a booking flow. The limit is that checkout is one stage, and you haven't said you owned the whole flow | `[grounded]` your statement; limit `[inferred]` from the scope of "checkout" | see G1 |
| R7 | Work as the first designer, with no design peers | important | adjacent | low | transferability | The requirement is derived from "first designer". You have said you've never been the only designer. Squad work with engineers carries over, but you haven't said whether a design lead or peers set your priorities | `[inferred]` from the JD's "first designer"; `[grounded]` your statement | see G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Ownership of the whole booking flow (R6, important) | transferability | A checkout redesign. Nothing yet on the stages before it, or on who owned the outcome | It decides how the checkout story is framed for a role that says "end to end" | Search or selection screens you changed, confirmation or amend-booking steps, a metric you tracked after launch | The checkout case study Ronan saw; before/after screens; a research-session summary | `[grounded]` your statement; `[generic]` that "end to end" invites this probe |
| G2 | Working without a design lead or peers (R7, important) | transferability | You were never the only designer. It isn't clear whether others set or reviewed your priorities | A first-designer role is a different job from a seat in a design team, and interviewers on both sides will ask | Decisions you made without sign-off, setting your own research cadence, defending a design choice to engineers | A project where you set direction with little review | `[grounded]` your statement; `[generic]` that first-designer roles tend to probe this |
| G3 | Two office days a week (R1, hard_gate) | hard_gate | Lives in Galway; acceptance of the schedule not stated | A term, so it can only be met or not | Not applicable | Your own confirmation | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | First contact came by WhatsApp, and the interview link arrives by email | unknown | — | "Ronan from Fernquay here, thanks for applying … I have emailed you a calendar invite with the video link." | A six-person company may simply use WhatsApp for quick scheduling. The invite's sender address isn't known yet. The message asks for no money, documents or personal details | `[generic]` small-company pattern; `[grounded]` the message contains no such request | Could you confirm which address the invite comes from, and who else will be on the call? | unresolved |
| RR2 | Employer corroborated | positive_signal | — | "We are six people in Galway making booking software for sea-kayak and surf schools." | The company exists as described and the posting is live | `[grounded]` About page and careers page fetched | How many schools use Kelproster today? | noted |
| RR3 | Pay stated and inside the market band | positive_signal | — | "Salary €52,000–€60,000 plus 0.5–1% equity" | Transparent pay, in line with the range for 3–5 years of experience | `[grounded]` JD figure; `[generic]` Tillerby band | Is the range fixed, or does it depend on level? | noted |
| RR4 | Equity terms unspecified | unknown | — | "0.5–1% equity" | The vesting schedule, share class and dilution terms aren't given, so the equity can't be valued | `[inferred]` from the JD's silence | What are the vesting schedule, share class and strike terms behind the 0.5–1%? | unresolved |
| RR5 | Success measures and decision rights unstated for a sole designer | unknown | — | "own the booking flow end to end" | Ronan may set priorities, with no stated measure of success in the first months | `[inferred]` from the JD's silence on outcomes and on who decides | What would a good first six months look like, and who decides design priorities? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, check that the invite comes from a fernquay address. If it doesn't, write to the jobs address on the careers page to confirm the call | see RR1 | `[grounded]` careers page lists the address | pending your approval |
| A2 | Lead with the checkout redesign and the monthly usability sessions, worded exactly as you described them to me: "redesigned our checkout flow", "ran monthly usability sessions with customers" | see R6, R4 | `[grounded]` your statements; the role's duties | pending your approval |
| A3 | Say plainly that you've never been the only designer, then ask the RR5 question. Say it as it is, without presenting squad work as sole ownership | see R7, RR5 | `[grounded]` your statement | pending your approval |
| A4 | Ask the RR4 equity question verbatim, and confirm the two office days work for you | see RR4, R1 | `[grounded]` register | pending your approval |
| A5 | Ronan's background is product lead at a Galway travel-software company, so your travel-booking years may land with him. Mention them as the 4 years you stated, not as domain expertise | see R2 | `[grounded]` his profile snippet and your statement | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway" and "Fernquay careers Product Designer Galway". Fetched "About Fernquay" (fernquay.example/about) and "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer). Moved role reality's organization and contradictions rows, and RR2 |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland startup first designer equity 2026", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Moved the market calibration row and RR3. It had nothing on equity norms, so RR4 stays open |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe). Snippet only; the page wasn't fetched. Moved the hiring-side people row and A5 |

## Dossier offer

I can write all of this up as `tuesday-dossier.md` if you'd like a copy to keep.

## Upgrade menu

- The checkout case study link Ronan saw → R3 and R6 can rise to `high`, and G1 may close.
- Your answers to G1 and G2 → R6 and R7 firm up.
- The invite's sender address → RR1 resolves.
- Any pay floor or other non-negotiable, such as days in the office → the hard-gate check against you moves from unknown.
- Equity terms from the call → RR4 closes.
- A deeper research pass on Fernquay and Saoirse's role, since the About page doesn't give a title (up to 5 more searches and 2 more fetches) → RR1 and RR5 may firm up. Say the word and it runs.

## Questions

1. **G1 / R6:** In the checkout redesign, what did you personally own, and did it touch any stage before checkout? What changed afterwards?
2. **G2 / R7:** At the Dublin company, who set your design priorities and reviewed your work? Was there ever a stretch where you made design calls without that?
3. **G3 / R1:** Do two office days a week in Galway work for you, and is there a pay floor or any other non-negotiable I should check this role against?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.