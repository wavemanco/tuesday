**Decision snapshot**

**Yes, worth applying to. R1, R2 and R3 are met on your own account, and R4 needs one line of evidence on your CV. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3 · unclear: R4 (Clear, timely written records)
- `important` — direct: R5a, R6a, R7 · adjacent: R5b (leg-ulcer care), R10 (housebound adults in their own homes), R11 (small caseload of your own) · unclear: R6b (continence care), R8 (end-of-life visits), R9 (care planning)
- `preferred` — absent: R12 (Doppler assessment)

R11 (`medium`) — a credible bridge via your home visiting, its limit named; R4, R6b, R8, R9 — CV silent, not shown absent; R12 — a gap, but preferred-tier and the team lead has spoken publicly on training for it.

**Opportunity ledger.** Sound on what is visible: pay, mileage and pool cars are stated, and a named team lead with district nursing experience offers a chat (RR3, RR4). Three points are open: whether the post is live (RR1), how much support a Band 5 caseload carries (RR2), and which terms apply at a CIC (RR5).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the post is confirmed open (RR1); (2) your CV shows records or electronic-record evidence for R4 (G1); (3) R11 is framed as adjacent and R12 as not yet done, never the other way round.

Stage assumed: evaluating. Your National Insurance number isn't needed for this, and I haven't used or repeated it.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC: adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract, founded 2015, 410 staff, four locality hubs | `[grounded]` search result from the employer's About page (snippet only, page not fetched) |
| Role | Band 5 community staff nurse in the Halifax district nursing team: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin and care planning, on an electronic patient record | `[grounded]` JD |
| Support | A small caseload of your own, supported by a senior community nurse | `[grounded]` JD |
| Scope read | A developmental step into district nursing, not a senior solo post | `[inferred]` from the JD pairing "small caseload" with senior support and a one-year experience floor |
| Team lead | Rhiannon Mabbott leads the Halifax district nursing team after eleven years as a district nurse. At a 2025 forum she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` speaker page (public professional footprint only) |
| Pay | £31,050–£37,800 plus mileage, pool cars provided | `[grounded]` JD |
| Market calibration | A community Band 5 survey (England, n=1,240) gives median £34,300, interquartile range £32,400–£36,600. The posting's range spans that interquartile range. In that survey 61% were paid mileage and 24% had a pool or lease car. This is a pattern, not this employer's offer | `[generic]` Wardround 2026 pay guide result |
| Unknowns | Whether the post is live; caseload size and supervision; induction; Doppler training; employment terms | — |
| Contradictions | None found between the JD and the About page. The careers page was not reached, so the posting itself is unchecked | `[grounded]` search result; fetch returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration, Adult Nurse | hard_gate | direct | medium | none | You state active adult registration, revalidation due March 2028. Confirmed prose, nothing inspected. Checking the NMC register is yours to do | `[grounded]` CV and your message | Check your register entry before applying |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | You state a full category B licence. Pool cars are provided, so no own vehicle is needed | `[grounded]` your message; JD | none |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward. A length of experience, so not a gate | `[grounded]` CV | none |
| R4 | Clear, timely written records | must_have | unclear | low | discovery | The CV is silent on documentation and on electronic records, though the JD says all care is recorded on one. A ward nurse's records work is plausible but not stated | `[grounded]` CV silence; `[inferred]` plausibility from five ward years | G1 |
| R5a | Wound care | important | direct | medium | none | Wound care including pressure ulcers and surgical wounds is stated | `[grounded]` CV | none |
| R5b | Leg-ulcer care | important | adjacent | medium | transferability | Pressure-ulcer and surgical wound care carries over. Leg-ulcer care, including compression, is not stated | `[grounded]` CV; `[inferred]` adjacency | Name the limit plainly; ask about training (RR3) |
| R6a | Catheter care | important | direct | medium | none | Catheter care is stated | `[grounded]` CV | none |
| R6b | Continence care | important | unclear | low | discovery | The CV does not mention it | `[grounded]` CV silence | G4, not asked this turn |
| R7 | Insulin administration | important | direct | medium | none | Insulin administration is stated | `[grounded]` CV | none |
| R8 | End-of-life visits | important | unclear | low | discovery | Silent on the CV. Not assumed from an acute medical ward | `[grounded]` CV silence | G2 |
| R9 | Care planning | important | unclear | low | discovery | The CV does not mention it | `[grounded]` CV silence | G4, not asked this turn |
| R10 | Caring for housebound adults in their own homes | important | adjacent | medium | transferability | Home visits in the first week after discharge are real home-based work. Limit: that is a short post-discharge window, not ongoing care of long-term housebound patients | `[grounded]` CV | Make the bridge and its limit explicit |
| R11 | A small caseload of your own | important | adjacent | medium | transferability | You have never held your own caseload. Limit: home visiting is not caseload ownership. The JD pairs the caseload with senior support | `[grounded]` your message and CV | G3 |
| R12 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You have not done it. Desirable only, so a minor risk | `[grounded]` your message | Ask about training (RR3) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Records (R4, must_have) | discovery | Nothing on documentation or electronic records | The only `must_have` row not at `direct`; one line likely closes it | Electronic care records on the ward or in discharge-to-assess; audited notes; handover or discharge documentation | A line on the CV, or an audit or feedback note | `[grounded]` CV silence; `[generic]` that records are screened in community nursing |
| G2 | End-of-life care (R8, important) | discovery | Not stated | Named visits in the role; answers whether you bring this or must learn it | Anticipatory or palliative care on the ward; care after death; family conversations; link with palliative teams | A training record or reflective note | `[grounded]` CV silence |
| G3 | Caseload (R11, important) | discovery | Home visits, but unclear whether you planned your own visit list | Decides how far the caseload bridge can be pushed | Planning your own visits in the discharge-to-assess team; deciding visit frequency; escalating without a senior present | A team rota or a role description from the secondment | `[grounded]` CV; `[inferred]` that it narrows the R11 limit |
| G4 | Continence and care planning (R6b, R9, important) | discovery | Neither is stated | Part of the role's duties | Bladder and bowel care; writing or updating care plans on the ward | A care-plan example, sanitised | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed live | unknown | — | "Join our district nursing team" | The page for the posting was not reachable from here, which says nothing either way on whether the post is open | `[grounded]` fetch of the guessed careers address returned no page | Is this post currently open, and what is the closing date? | unresolved |
| RR2 | Support behind a Band 5 caseload | unknown | — | "a small caseload of your own, supported by a senior community nurse" | Support may range from daily to occasional | `[inferred]` from the JD, which gives no figures | How many patients, how much senior time, and what induction before I carry a caseload? | unresolved |
| RR3 | Named lead with relevant public footprint | positive_signal | — | "informal chat… Rhiannon Mabbott, Community Nursing Team Lead" | Doppler training for newcomers may be available here; her talk topic does not establish it | `[grounded]` speaker page; `[inferred]` that training may be offered | Is Doppler training offered to nurses new to community work, and when? | noted |
| RR4 | Pay and car stated | positive_signal | — | "£31,050–£37,800 a year plus mileage"; "pool cars are provided" | The pay is stated and not withheld, and sits within the survey's range | `[grounded]` JD; `[generic]` survey band | Where in the range would my experience sit? | noted |
| RR5 | Terms at a CIC | unknown | — | "Community Health CIC… Band 5" | Terms such as pension and leave may differ between a CIC and a directly employed post | `[generic]` pattern, not a claim about this employer | Which terms apply, and does the post follow NHS Agenda for Change terms and pension? | unresolved |

## Application plan

`resume_edits_pending_approval` — nothing below is final until you approve it, and that covers the CV lines and the framing advice together.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | CV opening line: "Registered Nurse (Adult), NMC registered; five years on an acute medical ward at a district general hospital, the last 18 months seconded to its discharge-to-assess team, visiting patients at home in their first week after discharge." Every clause is your own wording | R3, R10 | `[grounded]` CV | pending your approval |
| E2 | Directly beneath it, a skills line in your own words: "Wound care including pressure ulcers and surgical wounds; catheter care; insulin administration." No leg-ulcer, continence or end-of-life claim, since none is evidenced | R5a, R6a, R7 | `[grounded]` CV | pending your approval |
| E3 | A records or electronic-record line, written only once you answer G1 | R4 | `[grounded]` gap queue | pending your approval |
| F1 | Positioning to say aloud: "I haven't held my own caseload, and I haven't done Doppler assessment. My home-based work was visiting patients in their first week after discharge." State the limits before they are asked | R10, R11, R12 | `[grounded]` your message and CV | pending your approval |
| A1 | Take up the informal chat with Rhiannon Mabbott before applying, and ask the RR1, RR2, RR3 and RR5 questions verbatim | The JD invites it | `[grounded]` JD | pending your approval |

## Evidence status

Verified: none yet. Your CV and message claims are self-reported, with no document or register entry inspected.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about). Fetched calderbrookhealth.example/careers, which returned no page. Moved: the organization row and RR1; the employer exists as described, the posting is unchecked |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse district nursing salary Agenda for Change 2026/27 pay scale", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved: the market calibration and RR4 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Moved: the team lead row, RR3, and the plan's Doppler framing |

I'd like to save this as `tuesday-dossier.md` if you want it kept.

## Upgrade menu

- An NMC register check, a driving-licence check, or a reference or appraisal naming your ward skills → R1, R2 and the R5a, R6a, R7 claims toward `high`.
- A confirmed live posting link, or the careers-page address → RR1 closes.
- An answer to G1 → R4 closes and E3 can be drafted.
- An answer to G2 → R8 resolves.
- An answer to G3 → R11's limit narrows or is confirmed.
- Your own non-negotiables (minimum pay, travel distance, hours) → the hard-gates line stops reading "checks unknown".
- A deeper research pass on Calderbrook (leadership, staffing, public reports, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

G1 — On the ward or in discharge-to-assess, did you use electronic records or keep notes you'd call clear and timely, and is there any audit, feedback or example you could point to?
G2 — On the acute ward, have you cared for patients at the end of life, and what was your part in it?
G3 — In the discharge-to-assess team, did you plan your own visit list and decide visit frequency, or were visits allocated to you?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.