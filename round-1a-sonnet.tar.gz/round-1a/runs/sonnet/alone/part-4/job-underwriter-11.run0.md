I'm reading the underwriting rules for this skill, and I've finished that. Next I'll check whether both employers exist and look up pay norms for each role. After that I'll write up the assessment.
# Decision snapshots

**Are either worth your time? Duinvaart: yes, apply, once the posting checks out (`conditional_go`). Kroonhaven: no (`no_go`), because the must-haves R2, R3 and R6 are `absent` and R7 is only `adjacent`.**

## A. Operations Analyst, Duinvaart Cold Chain (Rotterdam)

**Fit ledger.**

- `hard_gate`: unclear: R1 (hybrid three days in Rotterdam)
- `must_have`: direct: R2, R3, R4
- `important`: direct: R5, R7 · adjacent: R6 (temperature compliance)
- `preferred`: adjacent: R8 (Dutch a plus)

R6 is a domain bridge with its limit named; R8 is conversational Dutch against a "plus".

**Opportunity ledger.** Clear, coherent duties (RR3). The employer is not yet established (RR1) and the salary is withheld (RR2).

- **Hard gates:** none failed; unconfirmed: R1 (hybrid three days in Rotterdam); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify (RR1); (2) the Rotterdam commute works for you (R1); (3) the temperature-compliance bridge is framed as adjacent, never as cold-chain experience (R6).

## B. Supply Planner, Kroonhaven Foods (Utrecht)

**Fit ledger.**

- `hard_gate`: unclear: R1 (on-site in Utrecht)
- `must_have`: adjacent: R4 (run weekly S&OP meeting), R7 (fluent Dutch) · unclear: R5 (advanced Excel) · absent: R2 (3+ years planning in FMCG), R3 (own 13-week supply plan), R6 (SAP IBP or similar)

R2, R3 and R6 have no planning evidence; R4 is a review habit, not S&OP; R7 is conversational against fluent.

**Opportunity ledger.** The scope is well defined (RR6). The employer is not yet established (RR4) and the salary is withheld (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (on-site in Utrecht); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **What would change this:** you would need planning evidence you haven't described (R2, R3, R6) and Dutch at working fluency (R7). Nothing in the posting suggests it would relax those.

---

# A. Duinvaart: detail

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam; a refrigerated-fleet operator by the posting's description | `[grounded]` JD header |
| Mandate | Track on-time delivery and temperature compliance, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` JD |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` JD |
| Scope read | An ordinary analyst scope: three duties, named tools, no people management | `[inferred]` from the duty list |
| Market calibration | Not established. The pay-band search was refused, and the posting withholds salary | `[grounded]` JD silent on pay; no `[generic]` band available |
| Unknowns | Salary; team size and reporting line; how temperature data is collected | — |
| Contradictions | None between the JD and your background; the posting could not be checked against the company's own site | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, three days a week in the Rotterdam office | hard_gate | unclear | low | hard_gate | The term is stated, but your location and commute tolerance weren't given. Your last employer was in Amsterdam, which doesn't settle it | `[grounded]` JD; constraints not given | Closing question on R1 |
| R2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier. A years requirement is a screening risk, never a gate, and you clear it by a wide margin. CV-stated, no artifact seen | `[grounded]` your stated background | none |
| R3 | Strong SQL | must_have | direct | medium | none | Daily SQL use is stated; there is no inspectable query or artifact yet | `[grounded]` your stated background | A sanitized query would raise it to high |
| R4 | Power BI or Tableau; weekly dashboards | must_have | direct | medium | presentation | Daily Power BI use and a dashboard your depot managers use. That is the strongest evidence you have for this posting and should lead the CV | `[grounded]` your stated background | CV edit E1 pending approval; a sanitized screenshot would raise it to high |
| R5 | Track on-time delivery | important | direct | medium | none | Your own on-time delivery dashboard is the same metric | `[grounded]` your stated background | none |
| R6 | Temperature compliance across a refrigerated fleet | important | adjacent | low | transferability | You have tracked a delivery-performance metric against targets. Nothing described touches temperature, cold chain or excursion handling. Limit: exercised none of those | `[inferred]` adjacency from compliance-style metric tracking | See gap G1 |
| R7 | Work with depot managers on route changes | important | direct | medium | none | You ran a weekly route-performance review, and depot managers use your dashboard | `[grounded]` your stated background | E2 pending approval |
| R8 | Dutch a plus | preferred | adjacent | medium | capability | Conversational Dutch, self-stated. Preferred priority, so a minor risk | `[grounded]` your stated level | State it as it is |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Temperature compliance (R6, important) | transferability | Delivery-performance tracking; no temperature or cold-chain content | The likeliest probe in an interview; a concrete bridge narrows it | Tracking breach or exception rates against a threshold; time-sensitive or temperature-sensitive parcels such as pharma or perishables; an SLA-compliance report | A sanitized exception-rate report or dashboard view | `[inferred]` bridge; `[generic]` that this is the likeliest probe |
| G2 | Commute and location (R1, hard_gate) | hard_gate | Location not given | A gate, not a wording problem | Not applicable: it is a fact about your situation | Your answer to the closing question on R1 | `[grounded]` constraints not given |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | The posting may be live and ordinary, or the entity may be small or the listing stale; research was unavailable, so nothing is confirmed either way | `[generic]` pattern, not a claim about this company | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Salary withheld | unknown | — | (no figure given) | The pay may sit anywhere in the role-family range; the withholding is itself worth a question | `[grounded]` JD silent | What salary range is budgeted for this post? | unresolved |
| RR3 | Concrete duties, named tools, defined collaborators | positive_signal | — | "build weekly dashboards in Power BI, and work with depot managers on route changes" | Scope looks real and measurable | `[grounded]` JD | What does a good first quarter look like for this role? | noted |

## Application plan

Every row and every piece of advice in this section is proposed and not final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with the on-time delivery dashboard: who used it, how often, what changed because of it | See R4, R5, R7 | `[grounded]` your stated background | pending your approval |
| E2 | In the cover note, name the weekly route-performance review and your work with depot managers, since this is the posting's third duty | See R7 | `[grounded]` your stated background | pending your approval |
| A1 | Verify the posting on the company's own careers page before spending effort | See RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Say "conversational Dutch", not working fluency, and do not claim cold-chain or temperature-compliance experience | See R8, R6; these claims are prohibited | `[grounded]` your stated level and background | pending your approval |
| Q1 | Ask RR1 to RR3's questions verbatim in the screen | The register doubles as interview preparation | `[grounded]` register | pending your approval |

---

# B. Kroonhaven: detail

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, Utrecht; a chilled ready-meals producer by the posting's description | `[grounded]` JD header |
| Mandate | Own the 13-week supply plan, balance capacity against forecast, run the weekly S&OP meeting | `[grounded]` JD |
| Working pattern | On-site in Utrecht | `[grounded]` JD |
| Scope read | A genuine planning-owner role: the plan and the meeting are both yours, so there is little room to learn on the job | `[inferred]` from "own" and "run" in the JD |
| Market calibration | Not established. The pay-band search was refused, and the posting withholds salary | `[grounded]` JD silent on pay; no `[generic]` band available |
| Unknowns | Salary; planning system in use; team size | — |
| Contradictions | None found within the posting | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Utrecht | hard_gate | unclear | low | hard_gate | The term is stated; your location and tolerance weren't given | `[grounded]` JD; constraints not given | Closing question on R1 |
| R2 | 3+ years of supply or demand planning in FMCG | must_have | absent | none | capability | You have said you have never worked in planning, and FMCG is a different sector from parcel delivery. The requirement is a screening risk and not a gate, but you are far from it | `[grounded]` your stated background | none; closure would take a role change |
| R3 | Own the 13-week supply plan, balancing capacity against forecast | must_have | absent | none | capability | No planning ownership in what you described | `[grounded]` your stated background | none |
| R4 | Run the weekly S&OP meeting | must_have | adjacent | low | transferability | You ran a weekly route-performance review. Limit: nothing says it was cross-functional or tied to a demand and supply plan, so it must not be presented as S&OP | `[inferred]` adjacency from the review's cadence | See gap G3 |
| R5 | Advanced Excel | must_have | unclear | low | discovery | Your daily tools were SQL and Power BI; Excel depth wasn't mentioned | `[grounded]` background silent on Excel | Low value to ask given R2, R3 and R6 |
| R6 | SAP IBP or a similar planning system | must_have | absent | none | capability | No planning-system use in what you described; SQL and Power BI are analytics tools, not planning systems | `[grounded]` your stated background | none |
| R7 | Fluent Dutch | must_have | adjacent | medium | capability | Your Dutch is conversational, which is below fluent; the posting also lists it as a requirement, not a plus | `[grounded]` your stated level and the JD | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G3 | Planning experience (R2, R3, R4, must_have) | capability | Analytics and performance review, no plan ownership | The core of the role; the status turns on it | Producing a forecast, capacity plan or volume plan that others scheduled against | A forecast or capacity-plan document you authored | `[inferred]` that this would be the deciding gap |
| G4 | Planning system (R6, must_have) | capability | None named | The tool is named in the JD | Any planning or scheduling system you configured or operated | A system name and your role in it | `[grounded]` JD against your background |
| G5 | Advanced Excel (R5, must_have) | discovery | Not mentioned | Cheap to confirm, but it cannot offset R2, R3 and R6 | Models, lookups, scenario sheets built beyond routine use | A sanitized model | `[grounded]` background silent |
| G6 | Dutch fluency (R7, must_have) | capability | Conversational | Stated as a requirement | A formal assessment level or working-meeting experience in Dutch | A certificate level, if you hold one | `[grounded]` your stated level |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR4 | Employer not established from attributable sources | risk_signal | medium | "Kroonhaven Foods, Utrecht" | The posting may be live and ordinary, or stale or aggregated; research was unavailable | `[generic]` pattern, not a claim about this company | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR5 | Salary withheld | unknown | — | (no figure given) | The pay may sit anywhere in the role-family range | `[grounded]` JD silent | What salary range is budgeted for this post? | unresolved |
| RR6 | Clear ownership and a named cadence | positive_signal | — | "Own the 13-week supply plan ... run the weekly S&OP meeting" | The role is genuinely defined; success is checkable | `[grounded]` JD | Who currently owns the plan, and how is it measured? | noted |

## Application plan

Every row and every piece of advice in this section is proposed and not final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A3 | Don't spend application effort on this role | See R2, R3, R6 | `[grounded]` evidence map | pending your approval |
| A4 | If you apply anyway, don't describe your route-performance review as S&OP, and don't claim planning or FMCG experience; these claims are prohibited | See R4, R2 | `[grounded]` R2, R4 rows | pending your approval |
| Q2 | If you proceed, ask RR4 to RR6's questions verbatim | The register travels with you | `[grounded]` register | pending your approval |

---

# Evidence status

Verified: none yet. Everything above rests on your own description of your background; the job descriptions are quoted as pasted.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Duinvaart Cold Chain Rotterdam" and "Kroonhaven Foods Utrecht"; both refused. It would have confirmed the employers and the live postings (RR1, RR4, and both contradictions rows) |
| 2. Role-family sweep | unavailable | Searched "operations analyst logistics Netherlands salary Rotterdam 2026" and "supply planner FMCG Netherlands salary SAP IBP 2026"; both refused. It would have set the market-calibration lines and the pay-band checks (RR2, RR5) |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

# Closing

If you'd like, I can write this up as `tuesday-dossier.md`, with both roles, so you can reuse it.

**Upgrade menu**

- Links to the two live postings, or each company's own careers page → RR1 and RR4 close, and the conditional on Duinvaart can lift.
- A sanitized on-time delivery dashboard view or screenshot, or a sample query → R3 and R4 rise from `medium` to `high`.
- Your answer on R1 → G2 resolves for Duinvaart and the Kroonhaven gate is settled.
- Any exception-rate or threshold report you've built → G1's bridge strengthens (R6).
- The budgeted salary for either role → RR2 and RR5 close.
- A deeper research pass on either employer (funding, leadership churn, public employee reports; up to 5 more searches and 2 more fetches). It needs search permission, which was refused this time. Say the word if you grant it.

**Questions**

1. **R1 (both roles):** Where do you live, and is travelling to Rotterdam three days a week, or to Utrecht five days a week, workable for you?
2. **G1 (R6):** Have you ever tracked deliveries against a time or temperature threshold, such as perishables, pharma or an SLA breach rate? If so, what was your part in it?
3. **RR1 (both roles):** Can you drop links to the two live postings so I can check them against each company's own page?

You can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.