I'm still reading the skill's reference files so the assessment follows its required format. Next I'll read the remaining ones, then deliver the verdict.
Research is mostly done: three searches and one failed careers-page fetch so far. I'm making one last fetch of the company's About page to look for a vacancy link, then I'll write up the assessment.
## Decision snapshot

**Yes, this one is worth applying for, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1, R2, R3
- `must_have`: direct: R4 · unclear: R5 (clear, timely written records)
- `important`: direct: R6, R8, R10 · adjacent: R7 (leg-ulcer care), R13 (home visits to housebound adults) · unclear: R9 (continence care), R11 (care planning), R12 (end-of-life visits), R14 (own small caseload)
- `preferred`: absent: R15 (Doppler assessment)

R14: whether any of your discharge-to-assess visits were yours to plan; R7 (`medium`): a bridge from pressure-ulcer and surgical-wound care; R15: a stated gap on a preferred row.

**Opportunity ledger.** Sound on what is visible, with two things unverified: the posting could not be matched to the employer's careers page (RR1), and terms beyond salary are unstated (RR2). The pay is transparent (RR3), and the support is stated (RR5). Caseload size is not given (RR4).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`, R3 `direct`); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the vacancy is confirmed live on Calderbrook's own careers page (RR1); (2) the non-salary terms and caseload support are acceptable once asked in the informal chat (RR2, RR4); (3) the leg-ulcer bridge is presented as adjacent and the Doppler gap is stated plainly (R7, R15).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC runs adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract. It was founded in 2015 and has 410 staff across four locality hubs. | `[grounded]` About page fetched |
| Role | Band 5 community staff nurse in the district nursing team, Halifax. You would care for housebound adults at home and hold a small caseload supported by a senior community nurse. | `[grounded]` advert |
| Duties | Wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin administration and care planning, all on an electronic patient record. | `[grounded]` advert |
| Essential | NMC registration (Adult), a full UK driving licence (pool cars provided), at least one year post-registration, and clear, timely records. The only desirable item is Doppler assessment. | `[grounded]` advert |
| Scope read | An entry-level community post: a small caseload with a senior nurse in support, with no first-90-day or first-year outcomes stated. | `[inferred]` from "small caseload... supported by a senior community nurse" |
| Market calibration | The posted £31,050–£37,800 brackets a survey median of £34,300 and an interquartile range of £32,400–£36,600 for Band 5 community staff nurses in England. In that survey 61% were paid mileage and 24% had a pool or lease car. This is a pattern for the role family, not this employer's offer, and I saw only the survey's summary text. | `[generic]` Wardround survey; `[grounded]` advert for the posted figure |
| Named contact | Rhiannon Mabbott is described as leading the Halifax district nursing team after eleven years as a district nurse. She spoke at a 2025 forum on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work. | `[grounded]` forum speaker page, search result text only |
| Unknowns | Caseload size, hours and rota, pension and leave terms, the closing date, and which electronic record system is used. | `[grounded]` advert silent |
| Contradictions | None between the advert and the About page. The careers page returned no page, so the advert could not be matched to it. | `[grounded]` fetches |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration, Adult | hard_gate | direct | medium | none | Your CV states active registration, with revalidation due March 2028. Nothing has been inspected. The register lookup is yours to do. | `[grounded]` CV | none |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | The CV states a full UK licence, category B. Pool cars are provided, so no own car is needed. | `[grounded]` CV, advert | none |
| R3 | Based in Halifax | hard_gate | direct | medium | none | The advert is Halifax-based and the CV says you live in Halifax. Which hub or patch is not stated. | `[grounded]` CV, advert | ask which patch (RR4) |
| R4 | At least one year post-registration | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward. | `[grounded]` CV | none |
| R5 | Clear, timely written records on an electronic record | must_have | unclear | low | discovery | The CV is silent on records and on which system you used. Ward work implies documentation, but that is not a stated fact. | `[grounded]` CV silence | see G3 |
| R6 | Wound care | important | direct | medium | none | Wound care including pressure ulcers and surgical wounds. | `[grounded]` CV | none |
| R7 | Leg-ulcer care | important | adjacent | medium | transferability | Pressure-ulcer and surgical-wound care carry over in part. Limit: nothing states leg ulcers, compression or Doppler. | `[inferred]` from the wound-care line | see G4 |
| R8 | Catheter care | important | direct | medium | none | The CV states catheter care. | `[grounded]` CV | none |
| R9 | Continence care | important | unclear | low | discovery | The CV is silent beyond catheter care. | `[grounded]` CV silence | see G3 |
| R10 | Insulin administration | important | direct | medium | none | The CV states insulin administration. | `[grounded]` CV | none |
| R11 | Care planning | important | unclear | low | discovery | The CV is silent. The discharge-to-assess role may have involved it, but that is not stated. | `[grounded]` CV silence | see G3 |
| R12 | End-of-life visits | important | unclear | low | discovery | The CV states no end-of-life work. Acute ward context is indirect only. | `[grounded]` CV silence | see G2 |
| R13 | Visiting housebound adults in their own homes | important | adjacent | medium | transferability | The setting matches: 18 months visiting patients at home in their first week after discharge. Limit: that is a time-limited post-discharge cohort, not a long-term housebound caseload. | `[grounded]` CV; `[inferred]` adjacency | name the limit in the application |
| R14 | Holding a small caseload of your own | important | unclear | low | discovery | You said you have never held your own caseload. The CV does not say whether your discharge-to-assess visits were planned and made alone. | `[grounded]` your statement, CV | see G1 |
| R15 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You said you have never done one. It is desirable, not essential. | `[grounded]` your statement | closure path in G5 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Own caseload (R14, important) | discovery | You have never held a caseload. The CV shows 18 months of home visiting but not who planned the visits or whether you saw patients alone. | The caseload is the advert's headline responsibility, so the answer decides whether this row stays unclear or becomes adjacent. | Planning your own day's visits; choosing who to see first; escalating a concern to a GP or senior colleague on the spot; making a visit decision with no senior present. | A secondment letter or outline of the discharge-to-assess team's role | `[grounded]` CV, your statement; `[inferred]` that an answer could lift the row to adjacent |
| G2 | End-of-life visits (R12, important) | discovery | Nothing on end-of-life care. | The advert lists it as a duty, and a silent CV leaves it open. | Caring for dying patients on the ward; working with a palliative care team; supporting a fast-track discharge so someone could die at home; writing end-of-life care plans. | An end-of-life study-day certificate, or anonymised ward end-of-life documentation | `[grounded]` CV silence |
| G3 | Continence care, care planning, records (R9, R11, R5) | discovery | The CV is silent on all three. | R5 is a must-have. The other two are listed duties. Not asked this turn, because the question budget went to higher-impact gaps. | Bladder and bowel care on the ward; discharge care plans in the discharge-to-assess role; the name of the electronic record you used and how you kept it current. | A documentation audit result, or the name of the record system | `[grounded]` CV silence |
| G4 | Leg-ulcer care (R7, important) | transferability | Pressure-ulcer and surgical-wound care, with nothing on venous leg ulcers or compression. | The adjacent evidence carries over in part, and the limit is what an interviewer is likely to probe. | Assessing or dressing a leg ulcer; applying compression bandaging in any setting; time with a tissue viability or vascular team. | A competency record, or a tissue viability training note | `[inferred]` bridge; `[generic]` that interviews probe the limit of a bridge |
| G5 | Doppler assessment (R15, preferred) | capability | No evidence, and you confirm none exists. | It is preferred, so a minor risk. No question is needed. Closure is training. The named contact's public talk on Doppler training for staff new to community work suggests training may be available, which is worth asking. | none | none | `[grounded]` your statement; `[inferred]` from the contact's talk topic |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Vacancy not matched to the employer's careers page | unknown | — | "Join our district nursing team caring for housebound adults in their own homes" | The posting may be live and my fetch simply failed, or it may be closed or from an aggregator. | `[grounded]` the careers URL returned no page while the About page points vacancies there; `[inferred]` the cause is unknown | Is this vacancy live on your careers page, and what is the closing date? | unresolved |
| RR2 | Non-salary terms unstated | unknown | — | "£31,050–£37,800 a year plus mileage" | Independent providers delivering NHS-contracted services may or may not mirror NHS terms. | `[generic]` pattern, not a finding about this employer | Are pension, leave and sick pay on NHS terms? | unresolved |
| RR3 | Pay stated openly, in line with the survey | positive_signal | — | "£31,050–£37,800 a year plus mileage"; "pool cars are provided" | Pay is transparent, and the range brackets the survey median and interquartile range. | `[grounded]` advert; `[generic]` survey band | Where in the range would a nurse with five years' post-registration experience be placed? | noted |
| RR4 | "Small caseload" undefined | unknown | — | "You will hold a small caseload of your own" | Size, daily visit volume and hours may differ from what you expect. | `[inferred]` from the advert's silence on numbers | How many patients and visits a day make up a typical caseload, and what are the hours and rota? | unresolved |
| RR5 | Support structure and a named contact | positive_signal | — | "supported by a senior community nurse"; "informal chat" | The role is built for a nurse new to caseload-holding. | `[grounded]` advert | What does the senior nurse's support look like in a new starter's first three months, and is Doppler training offered? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Open the CV summary with: "Registered Nurse (Adult), NMC registration active. Five years as a staff nurse on an acute medical ward at a district general hospital, the last 18 months seconded to its discharge-to-assess team, visiting patients at home in their first week after discharge." This reorders your own sentences and adds nothing. | See R13: it puts the home-visiting evidence first. | `[grounded]` CV | `resume_edits_pending_approval` |
| E2 | In any supporting statement, say in your own words that Doppler assessment is the one desirable item you have not done, and add nothing about training unless you tell me it is true. | See R15: the gap is stated, not implied. | `[grounded]` your statement | pending your approval |
| A1 | Take up the informal chat with Rhiannon Mabbott and ask the questions in RR1, RR2, RR4 and RR5 verbatim. | The advert invites contact, and the register doubles as preparation. | `[grounded]` advert, register | pending your approval |
| A2 | Remove the National Insurance number from the CV and send it only if a form asks for it. | A CV does not normally need it. | `[generic]` common practice | pending your approval |

None of these rows is final until you approve it. That covers the CV line, the Doppler wording and the advice rows alike.

## Evidence status

Verified: none yet. Every claim above comes from your CV and message, so none is inspected. A National Insurance number appeared in your message. It isn't needed for this and I haven't used or repeated it. Stage was not stated, so I assumed you are evaluating.

Research tier: L1 — searches 4 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Calderbrook Community Health CIC community staff nurse Band 5 district nursing vacancy". Both returned "About Calderbrook Community Health" (calderbrookhealth.example/about). I fetched that page and fetched calderbrookhealth.example/careers, which returned no page. Moved: role reality's organization and contradictions rows, and RR1. The employer is established as described, so there is no failed-attribution entry. |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse district nursing role scope Agenda for Change pay Band 5 2026". It returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide), summary text only. Moved: the market calibration row and RR3. It returned nothing on scope norms. |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook". It returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott), result text only. Moved: the named-contact row, G5 and A1. |

I can also save this as `tuesday-dossier.md` if you'd like to keep it.

## Upgrade menu

- Your answers to G1, G2 and G4 could move R14, R12 and R7.
- A link to the live vacancy with its closing date would close RR1.
- A secondment letter or discharge-to-assess role outline would firm up R13 and R14.
- Your own NMC register lookup and licence details would let R1 and R2 be recorded as inspected rather than CV-stated.
- Your own constraints (pay floor, hours, travel radius, part-time or rota limits) would turn the hard-gates line from unknown into a real check.
- The contact's answers on caseload, hours and terms would close RR2 and RR4.
- A deeper pass on Calderbrook (staff and leadership changes, public staff reports, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

G1 — In the discharge-to-assess team, did you plan your own visits and see patients alone, and what could you decide on the spot without a senior present?

G2 — Have you cared for patients at end of life, on the ward or in discharge-to-assess, and what did you personally do?

G4 — Have you assessed or dressed leg ulcers, or applied compression bandaging, in any setting?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.