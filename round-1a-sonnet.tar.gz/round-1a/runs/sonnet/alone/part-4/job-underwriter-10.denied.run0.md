I'll read the reference files the skill requires before building the assessment.
## Decision snapshot

**Yes, worth pursuing: take the call, after two checks you can do yourself. Neither the posting nor Ronan's message asks you for money, documents or ID. I couldn't establish Fernquay as a company from here (RR1). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: R2 (Salary €52,000–€60,000)
- `must_have`: direct: R3, R4, R5a, R7 · adjacent: R6 (own the booking flow end to end)
- `important`: adjacent: R5b (research calls with school owners), R8 (first designer)

R6 — checkout is one part of a booking flow, limit named; R8 — you've owned work, but always beside other designers; R2 — your pay floor wasn't given.

**Opportunity ledger.** Plausible but unverified. The employer couldn't be established from here (RR1), and the WhatsApp contact is an unknown to check against the emailed invite (RR2). The scope bundles design, research and delivery into one first hire (RR3), and equity terms and funding are unstated (RR4, RR5). The posting is open about pay, equity and working pattern (RR6).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1 and RR2 check out: Fernquay's own site matches the posting, and the invite arrives from its domain. (2) R2: the band clears your floor, and RR4's equity terms are explained. (3) R6 and R8 are framed as the adjacent evidence they are, and RR3's support questions get concrete answers.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, booking software for sea-kayak and surf schools. Existence as described is not confirmed | `[grounded]` JD; existence unverified (research refused) |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship alongside two engineers | `[grounded]` JD |
| Closest collaborator | Co-founder Ronan Kehoe. His message adds Saoirse as CTO, who is not named in the JD | `[grounded]` JD and WhatsApp message |
| Compensation | €52,000–€60,000 plus 0.5–1% equity; equity terms not stated | `[grounded]` JD |
| Working pattern | Hybrid: two days a week at the Galway office, the rest flexible | `[grounded]` JD |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Scope read | A first-designer remit that combines product design, user research and ownership of the core flow, with no design lead named | `[inferred]` from the JD's responsibilities and its silence on design leadership |
| Market calibration | Not established. The role-family sweep was refused, so no salary band is given and the posted range is not set against the market | `[grounded]` research refused |
| Unknowns | Equity terms, funding and runway, who reviews design work, what the hiring process involves | `[grounded]` JD silent on each |
| Contradictions | None between the posting and the message. The posting names Ronan Kehoe, the message is from Ronan, and "checkout case study" matches your application. Whether the message came from the company is unchecked | `[grounded]` the two texts you pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week at the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year, so the office days fit. Your own statement, nothing inspectable | `[grounded]` your intake | none |
| R2 | Salary €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | The posting states the band, but your floor wasn't given, so it can't be called met. Confidence is `none` because no constraint was stated. The market comparison didn't run | `[grounded]` JD; no constraint stated | G4 |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company. Years are graded as experience, not as a gate | `[grounded]` your intake | A CV or portfolio link would raise to high |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" across four years. No artifact inspected | `[grounded]` your intake | Portfolio or Figma file would raise to high |
| R5a | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. That is research you ran yourself, of one kind (usability) | `[grounded]` your intake | A session guide or findings write-up would raise to high |
| R5b | Research calls with school owners | important | adjacent | medium | transferability | Your sessions were with travel-booking customers. Limit: no stated interviews with small-business owners or discovery-style research | `[grounded]` your intake; `[inferred]` that owner interviews differ from customer usability sessions | G3 |
| R6 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned the checkout flow of a travel-booking product, which is close to the domain. Limit: checkout is one stage, and sole ownership of the whole flow isn't stated | `[grounded]` your intake; `[inferred]` that checkout is one part of an end-to-end flow | G1 |
| R7 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your intake | none |
| R8 | You would be our first designer | important | adjacent | medium | transferability | You have owned a redesign and your own research cadence. Limit: you have never been the only designer, so setting up design practice alone is untested | `[grounded]` your intake | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Whole-flow ownership (R6, must_have) | transferability | A checkout redesign is confirmed. The rest of the booking journey (search, availability, changes, confirmation) isn't described | R6 is a `must_have` at `adjacent`, and the posting's headline duty is the whole flow | Owning decisions across stages before or after checkout, or choosing which part of the flow to redesign first | The checkout case study already sent, plus any flow map | `[grounded]` the intake shows checkout only; `[generic]` that "end to end" is likely to be probed |
| G2 | Working as the only designer (R8, important) | transferability | Always with design colleagues | The role has no design peer in the posting, so this limit is the likeliest follow-up | Building or maintaining a component library others used, deciding design direction without a lead, or presenting research to non-designers | A Figma library link or a decision log | `[grounded]` your statement; `[generic]` that first-designer roles probe this |
| G3 | Research with business owners (R5b, important) | transferability | Customer usability sessions are confirmed. Owner interviews are not | The role centres on school owners as the users | Interviews with partners, suppliers or small-business customers, or discovery calls beyond testing a prototype | A discussion guide or a findings summary | `[grounded]` the intake; `[inferred]` that owners differ from consumers |
| G4 | Pay floor and equity view (R2, hard_gate) | hard_gate | The band is stated; your floor isn't | A gate row can't be called met without your number | n/a | n/a | `[grounded]` JD states the band; your floor wasn't given |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | low | "We are six people in Galway making booking software for sea-kayak and surf schools" | The company may be too new or small for much public trace, or the posting may be stale. The check didn't run. Severity is `low` because thin footprints are common at this size | `[generic]` pattern for companies of this size, not a claim about this one; `[grounded]` you found little online | Can you point me to this role on your own careers page, and tell me who I'd be interviewing with? | unresolved |
| RR2 | Contact by WhatsApp, invite by email | unknown | — | "I have emailed you a calendar invite with the video link." | Chat is used for scheduling and the interview itself sits elsewhere, which is not a sign by itself. Whether the invite's sender domain matches the company's is unchecked | `[inferred]` from the message; `[generic]` that small-company founders often schedule over chat | Can you confirm the invite will come from your Fernquay email address, and who else is on the call? | unresolved |
| RR3 | Bundled first-designer scope | risk_signal | low | "own the booking flow end to end, run research calls with school owners, and ship alongside our two engineers" | Design, research and delivery are folded into one hire with no design lead named, which can be a heavy load | `[inferred]` from the JD; `[generic]` common pattern for first design hires | Who reviews design work today, and what support does the first designer get: tools, research budget, access to school owners? | unresolved |
| RR4 | Equity terms unstated | unknown | — | "0.5–1% equity" | The percentage can't be valued without vesting, strike price and the current valuation | `[grounded]` JD silent on terms | What are the vesting terms, strike price and last valuation behind the 0.5–1%? | unresolved |
| RR5 | Funding and runway unstated | unknown | — | "We are six people in Galway" | A six-person team's stability depends on its funding, which the posting doesn't mention | `[grounded]` JD silent | How is Fernquay funded, and how long is the runway? | unresolved |
| RR6 | Pay, equity and working pattern stated openly | positive_signal | — | "Salary €52,000–€60,000 plus 0.5–1% equity. Hybrid: two days a week at our Galway office" | The posting gives its terms up front | `[grounded]` JD | Does the band flex with experience? | noted |

## Application plan

Every row below, and the suggested phrasing in A3, is a proposal pending your approval. No CV edits are proposed.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, check that Fernquay's own website lists the role and the team, and that the invite's sender domain matches the site | See RR1, RR2 | `[grounded]` RR1, RR2 | pending your approval |
| A2 | On the call, ask the RR1–RR5 questions verbatim, and ask Ronan how the process runs after this call | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A3 | Lead with three facts in your own words: "I redesigned our checkout flow", "I ran monthly usability sessions with customers", and "I worked in a squad with four engineers". Then state the limit plainly: "I've never been the only designer" | These trace to your own sentences and cover R3, R5a, R6, R7. Naming the limit up front answers R8 | `[grounded]` your intake | pending your approval |
| A4 | Ask whether any work exercise is time-boxed and paid, if one comes up | The posting says they "would rather see one messy real project than a polished deck", so an exercise may follow | `[inferred]` from that JD line | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Fernquay booking software sea kayak surf schools Galway" and "Fernquay product designer job Galway"; both were refused for lack of permission. It would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | Searched "product designer salary Ireland startup first designer Galway 2026"; refused. It would have moved the market calibration row and a salary-versus-market check on R2 |
| 3. Hiring manager's public footprint | unavailable | Searched "Ronan Kehoe Fernquay co-founder", limited to public professional footprint; refused. It would have moved the scope read and A3's positioning |

## Dossier offer

I can write all of this up as `tuesday-dossier.md` for you to keep, if you'd like it.

## Upgrade menu

- The link to Fernquay's website or careers page, or its text pasted → RR1 and the organization row can move toward established, and the contradictions row gets a real check.
- Your pay floor → R2 closes as met or failed.
- A portfolio or Figma link → R3 and R4 rise to `high`.
- Your checkout case study, which they've already seen → G1 and R6 get inspected, not just stated.
- A session guide or findings write-up → R5a rises to `high`, and G3's bridge to owner research gets stronger.
- Search permission, with one search and two fetches left in the L1 budget → rows 1–3 above could run, which would add a salary band and Ronan's public work history.

## Questions

G4 (R2) — What is the lowest salary you'd accept, and how do you weigh 0.5–1% equity against it?

G1 (R6) — Beyond checkout, which other stages of the booking journey did you personally make design decisions on, and where was someone else deciding?

G2 (R8) — Have you ever made design decisions without a design lead or peer to review them, even on a side project? What was it, and what happened?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.