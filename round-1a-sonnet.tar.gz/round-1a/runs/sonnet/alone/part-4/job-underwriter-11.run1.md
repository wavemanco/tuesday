I'm reading the skill's rules for evidence bands, questions and output format. Then I'll write the full assessment of both roles.
## Decision snapshots

**Duinvaart Cold Chain, Operations Analyst: yes, worth your time. Status: `conditional_go`.**

- **Fit ledger.**
  - `hard_gate` — unclear: D1 (Hybrid, three days a week in Rotterdam)
  - `must_have` — direct: D2, D3, D4, D5 · unclear: D6 (Temperature compliance on a refrigerated fleet)
  - `important` — direct: D7
  - `preferred` — adjacent: D8 (Dutch a plus)

  D6 — the one duty your background doesn't show yet; D8 — conversational Dutch against a "plus".
- **Opportunity ledger.** The duties and tools are plainly stated, and they match what you do now (DR2). The employer is unchecked (DR1) and the pay is not stated (DR3).
- **Hard gates:** none failed; unconfirmed: D1 (Hybrid, three days a week in Rotterdam); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the Rotterdam three-days-a-week pattern works for you from Amsterdam (D1); (2) the employer and live posting are confirmed (DR1); (3) your carrier's work touches temperature-sensitive or compliance-type tracking, or you present D6 honestly as a gap you'd learn (DG1).

**Kroonhaven Foods, Supply Planner: no, not worth your time as written. Status: `no_go`.**

- **Fit ledger.**
  - `hard_gate` — unclear: K1 (On-site in Utrecht)
  - `must_have` — adjacent: K2 (Fluent Dutch), K5 (Run the weekly S&OP meeting) · unclear: K6 (Advanced Excel) · absent: K3 (3+ years supply or demand planning in FMCG), K4 (Own the 13-week supply plan)
  - `important` — absent: K7 (SAP IBP or a similar planning system)

  K3, K4 — the planning work itself, with no evidence either way; K2 — conversational Dutch against "fluent"; K5 — a credible bridge, its limit named.
- **Opportunity ledger.** The role is clearly scoped, which is a positive (KR2), but the employer is unchecked (KR1).
- **Hard gates:** none failed; unconfirmed: K1 (On-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** planning work in your history (forecasting, capacity or volume plans, S&OP inputs) that you haven't mentioned (KG1). Without it, K3 and K4 are each a main requirement with no evidence, and the Dutch gap (K2) sits on top.

## Role reality

**Duinvaart Cold Chain**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Refrigerated-fleet logistics operator, Rotterdam | `[grounded]` JD header |
| Mandate | Track on-time delivery and temperature compliance, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` JD |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` JD |
| Scope read | A normally scoped analyst post: reporting plus advising depot managers, with no people management or ownership claims | `[inferred]` from the JD's duty list |
| Market calibration | Not established: the role-family sweep did not run | — |
| Unknowns | Salary; team size; who consumes the dashboards; whether "Dutch a plus" means daily Dutch with depot staff | `[grounded]` JD silence |
| Contradictions | None found between the JD and your background; the posting was not checked against the company's own site | `[grounded]` pasted JD only |

**Kroonhaven Foods**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Food producer in Utrecht, chilled ready-meals range | `[grounded]` JD header |
| Mandate | Own the 13-week supply plan, balance production capacity against the forecast, run the weekly S&OP meeting | `[grounded]` JD |
| Working pattern | On-site in Utrecht | `[grounded]` JD |
| Scope read | A full ownership role, not an analyst-support one. S&OP chairing also implies Dutch-language meetings | `[inferred]` from "own", "run" and the fluent-Dutch requirement |
| Market calibration | Not established: the role-family sweep did not run | — |
| Unknowns | Salary; team size; planning system in use; how many languages the S&OP runs in | `[grounded]` JD silence |
| Contradictions | None found within the JD; not checked against the company's own site | `[grounded]` pasted JD only |

## Evidence map

**Duinvaart Cold Chain**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| D1 | Hybrid, three days a week in the Rotterdam office | hard_gate | unclear | none | hard_gate | The posting states the term. You live in or work from Amsterdam, but you haven't said whether this commute works, so there's no candidate claim to grade | `[grounded]` JD; your constraints not given | Ask the question tagged D1 in the closing block |
| D2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | 4 years as an operations analyst at a parcel carrier is the same field and well over the stated length. It's your CV claim with no artifact inspected yet | `[grounded]` your background | A job title letter or LinkedIn role entry would raise to high |
| D3 | Strong SQL | must_have | direct | medium | none | You use SQL daily. "Strong" is unmeasured by anything inspectable | `[grounded]` your background | A sanitized query sample would raise to high |
| D4 | Power BI or Tableau | must_have | direct | medium | none | You use Power BI daily and built the on-time delivery dashboard your depot managers use | `[grounded]` your background | Screenshots of a sanitized dashboard would raise to high |
| D5 | Track on-time delivery | must_have | direct | medium | presentation | This is the dashboard you built. It's the closest match in the JD, so it should lead the CV | `[grounded]` your background | CV edit DA1 pending approval |
| D6 | Track temperature compliance across a refrigerated fleet | must_have | unclear | low | discovery | Nothing you've said covers temperature data. Monitoring service-level compliance at a parcel carrier is related work, but I can't tell if it touched chilled freight | `[grounded]` silence in your background; `[inferred]` adjacency | Ask the question tagged DG1 |
| D7 | Work with depot managers on route changes | important | direct | medium | presentation | You ran the weekly route-performance review, and depot managers use your dashboard | `[grounded]` your background | CV edit DA1 pending approval |
| D8 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational Dutch is real but short of fluent. The posting calls it a plus, not a requirement | `[grounded]` your background and JD | State your level plainly; don't round it up |

**Kroonhaven Foods**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| K1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | The posting states the term. Your willingness to commute is unstated | `[grounded]` JD; your constraints not given | Ask the question tagged D1 and K1 |
| K2 | Fluent Dutch | must_have | adjacent | medium | transferability | You have conversational Dutch, the posting says fluent. The job runs a weekly meeting, where fluency matters more than in analyst work | `[grounded]` your background and JD; `[inferred]` that the S&OP meeting runs in Dutch | Carry as a stated limit |
| K3 | 3+ years supply or demand planning in FMCG | must_have | absent | none | capability | You've never worked in planning, and the parcel carrier isn't FMCG. A years-of-experience line is a screening risk, not a legal gate | `[grounded]` your background; `[generic]` that such lines are often screened literally | Ask the question tagged KG1 |
| K4 | Own the 13-week supply plan, balancing capacity against forecast | must_have | absent | none | capability | No planning ownership in your history | `[grounded]` your background | None unless KG1 reveals planning work |
| K5 | Run the weekly S&OP meeting | must_have | adjacent | medium | transferability | You ran a weekly route-performance review with depot managers. That is a credible bridge on running a recurring cross-functional meeting. The limit: it covered delivery performance, not a demand-versus-supply plan | `[grounded]` your background; `[inferred]` adjacency | Name the limit wherever the bridge is used |
| K6 | Advanced Excel | must_have | unclear | low | discovery | You listed SQL and Power BI, not Excel, though analysts at your level often use it heavily | `[grounded]` silence; `[generic]` analyst norm | Ask if it matters after KG1 |
| K7 | SAP IBP or a similar planning system | important | absent | none | capability | No planning-system experience | `[grounded]` your background | None |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| DG1 | Temperature compliance (D6, must_have) | discovery | No mention of temperature or chilled freight | It's the one job duty with no match, and the one that makes this a cold-chain role | Chilled or pharma parcels, a temperature-excursion report, any compliance KPI you tracked | A sanitized report or dashboard page | `[grounded]` CV silence |
| KG1 | Planning exposure (K3, K4, must_have) | capability | No planning work stated | Without it K3 and K4 stay absent and the status stays `no_go` | Volume forecasts, capacity plans, headcount or fleet-size planning, inputs you gave to a planner | A sanitized forecast file | `[grounded]` your statement that you've never worked in planning |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| DR1 | Employer not yet checked (Duinvaart) | unknown | — | "Duinvaart Cold Chain, Rotterdam" | The posting may be live and genuine, or stale or aggregated. Web search was not permitted, so this is untested | `[generic]` pattern for any unchecked posting | Can you point me to this role on your own careers site, and who I'd interview with? | unresolved |
| DR2 | Clear duties and tools matching your stack | positive_signal | — | "build weekly dashboards in Power BI" | Scope is concrete and measurable | `[grounded]` JD | Who uses the weekly dashboards today? | noted |
| DR3 | Salary not stated | unknown | — | no salary in the posting as pasted | The pay may sit anywhere in a normal analyst range, or the posting may just not publish it | `[inferred]` from silence; no market band ran | What is the budgeted salary range? | unresolved |
| KR1 | Employer not yet checked (Kroonhaven) | unknown | — | "Kroonhaven Foods, Utrecht" | Same as DR1: untested because search was not permitted | `[generic]` pattern for any unchecked posting | Can you point me to this role on your own careers site? | unresolved |
| KR2 | Clearly scoped ownership role | positive_signal | — | "Own the 13-week supply plan" | The role is real and defined, just not yours as written | `[grounded]` JD | What planning system and team sit behind this plan? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| DA1 | Lead your CV for Duinvaart with the on-time delivery dashboard your depot managers use and the weekly route-performance review you ran. Don't mention temperature compliance unless DG1 turns up real work | See D5, D7 | `[grounded]` your background | pending your approval |
| DA2 | Confirm the posting on Duinvaart's own careers page before spending time on a tailored application | See DR1 | `[grounded]` DR1 | pending your approval |
| DA3 | Ask the DR3 question early, ideally with the recruiter | See DR3 | `[grounded]` DR3 | pending your approval |
| KA1 | Don't apply to Kroonhaven as written. If KG1 turns up real planning work, I'll re-run this | See K3, K4, K7 | `[grounded]` K-rows | pending your approval |
| KA2 | Look for planner-adjacent analyst roles at food or chilled-goods firms where your SQL and Power BI work is the core | A route that uses your strengths | `[generic]` how people usually move into planning | pending your approval |

## Evidence status

Verified: none yet. Everything above rests on what you wrote, and none of it has been confirmed against a document.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both searches were refused: "Duinvaart Cold Chain Rotterdam Operations Analyst" and "Kroonhaven Foods Utrecht Supply Planner chilled ready-meals". It would have confirmed each employer and whether the posting is live (DR1, KR1) |
| 2. Role-family sweep | unavailable | No search was sent because search was not permitted. It would have supplied a salary band and a scope norm for role reality's market calibration and DR3 |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Dossier offer

I can write all of this up as a `tuesday-dossier.md` file you can keep and add to, if you want one.

## Upgrade menu

- Permission to run web search → DR1 and KR1 resolve, and a salary band can be set against DR3.
- A sanitized dashboard screenshot or query sample → D3, D4, D5 move to `high`.
- Any chilled-freight or compliance-tracking example → D6 moves from `unclear`.
- Any planning or forecasting example → K3 and K4 can move off `absent`, and Kroonhaven's status could change.
- A hiring manager's name → role reality's scope read and which story to lead with.

## Questions

1. (D1, K1) What are your non-negotiables on commute, office days and pay floor? Is Rotterdam three days a week from Amsterdam workable, and is five days on-site in Utrecht?
2. (DG1) Did your parcel carrier handle temperature-sensitive or chilled shipments, or did you track any compliance-style metric?
3. (KG1) Have you ever built or maintained a forecast, or fed volume or capacity numbers into a plan?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.