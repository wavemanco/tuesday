I ran two web searches while checking this. Short answer: it isn't legit, so don't go ahead.

## Decision snapshot

**Not worth applying to — this is a fraud pattern, not a job. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Earn at least €30,000 a year)
- `must_have` — direct: R2, R3, R4
- `important` — adjacent: R5 (Order-processing experience) · unclear: R6 (A quiet place to work)

Your fit isn't the problem: your Zendesk volume, Excel tracker and training experience match what the posting asks for. The role is the problem.

**Opportunity ledger.** The posting asks for your passport, PPS number and IBAN before any real interview (RR1). It asks you to pay €349 up front (RR2). It also sends a cheque and asks you to forward most of it (RR3). The last is the classic overpayment scam. The employer can't be found online (RR4), and everything runs through Telegram with no calls (RR5).

- **Hard gates:** unconfirmed: R1 (Earn at least €30,000 a year), because the pay is "up to" a figure and the hours are 15–30 a week.
- **Severe red flags:** RR1, RR2, RR3.
- **Conditions for go:** none. No answer from them would fix RR2 or RR3.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics": no website, careers page or company record found | `[grounded]` search returned nothing (not-established) |
| Mandate | "Order Processing Coordinator", remote, 15–30 hours a week, up to €26/hr plus commission | `[grounded]` posting |
| Hiring process | Telegram only, no calls or video. "Interview" was a chat, then an instant offer | `[grounded]` posting and messages |
| Pay vs. your floor | At the top rate, 15 hours a week is about €20k a year. You'd need about 22 or more hours a week at the full €26 to pass €30k. "Up to" guarantees none of it | `[grounded]` posting figures, arithmetic; `[inferred]` that the pay is bait |
| Market calibration | Genuine remote order-processing and customer-ops roles are usually contracted hours with a fixed rate. Employers don't ask for payment, identity documents before an interview, or money forwarded from a cheque | `[generic]` |
| Contact | Support goes to a free-mail-style address (velloway.hr@postmail.example), not a company domain | `[grounded]` message |
| Contradictions | Posting says "no experience, full training provided". The messages then require you to buy a laptop and headset | `[grounded]` posting vs messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Earn at least €30,000 a year (your constraint) | hard_gate | unclear | high | hard_gate | Confidence grades your constraint. Fit is `unclear`: the pay is "up to", the hours are 15–30, and the commission is unspecified. The arithmetic shows it can fall well short | `[grounded]` your constraint; posting figures | Moot given the risk register |
| R2 | Confident with spreadsheets | must_have | direct | medium | none | You keep a weekly team tracker in Excel | `[grounded]` your account | none |
| R3 | Strong attention to detail | must_have | direct | medium | none | About 60 Zendesk tickets a day at a parcel courier | `[grounded]` your account | none |
| R4 | Good written English | must_have | direct | medium | none | Written ticket work is the job; no sample seen | `[grounded]` your account | none |
| R5 | Order processing (implied by the title) | important | adjacent | medium | transferability | Parcel-courier ticket handling sits next to order handling, though you haven't processed orders as such | `[inferred]` from your courier work | none |
| R6 | A quiet place to work | important | unclear | low | discovery | You haven't said | `[grounded]` not stated | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Earn at least €30,000 (R1) | hard_gate | Pay is capped and variable; no contract or payslip terms exist | Only a genuine employer's written contract could settle it | Not applicable to this employer | A signed contract from a verifiable company | `[grounded]` posting terms |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Identity documents requested before any real interview | red_flag | severe | "send your IBAN, your PPS number and a clear photo of your passport" | Aimed at identity theft or account fraud. Real payroll collects these after a signed contract | `[generic]` fraud pattern; `[inferred]` fit to this case | Would a registered company collect these before a contract? No | unresolved |
| RR2 | Upfront payment to the "employer" | red_flag | severe | "Please pay €349 by bank transfer to our equipment partner" | An advance-fee scam. The refund "with your first wages" never comes | `[generic]` fraud pattern | Why would an employer need you to pay it first? | unresolved |
| RR3 | Cheque sent, then most of it forwarded | red_flag | severe | "keep €350... transfer the rest to our equipment partner" | A fake or stolen cheque. It can look cleared for days, then the bank reverses it. The roughly €2,500 you forwarded is your loss, and you may be accused of laundering | `[generic]` well-documented overpayment scam | Why would an employer overpay you and ask for change back? | unresolved |
| RR4 | Employer can't be found | risk_signal | high | "Velloway Logistics" | The name and the Telegram handle are throwaways | `[inferred]` from no results | Is there a company registration, website or live posting? | unresolved |
| RR5 | Telegram-only process, instant "pass" | risk_signal | high | "no calls or video interviews" | It avoids anything that could identify the people behind it | `[generic]` | Can you speak to a named person on a company line? | unresolved |

## Application plan

1. **Don't send anything.** That means no passport photo, no PPS number, no IBAN and no money. Your IBAN isn't needed to apply for anything. `[generic]`
2. **If the cheque arrives, don't lodge it.** Never forward money from a cheque, however official it looks. `[generic]`
3. **Stop replying.** Block and report the Telegram account, and report the posting to the jobs site.
4. **Report it.** Tell the Gardaí and your bank. Fraud reports like this help, even if you lost nothing. `[generic]`
5. **Redirect your search.** Your background supports genuine customer-ops, order-management and support-team roles, which usually pay at or above your €30k floor. Look for a named company, a contract, a call or video interview, and no payment asked. `[generic]`

## Evidence status

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | yes | Search "Velloway Logistics" returned no results, so the employer is not-established |
| 2 | Role-family sweep | unavailable | Search "fake cheque overpayment job scam equipment purchase Telegram remote order processing Ireland" returned no results; the calibration line is `[generic]` |
| 3 | Hiring manager's footprint | n/a | No name was given |

## Dossier offer

I can write all of this up as a `tuesday-dossier.md` if you'd like a record for your bank or the Gardaí.

## Upgrade menu

- A link to the live posting and the jobs site's name: lets me check whether the listing is still up and what else it posted.
- The cheque, once it arrives, with sensitive numbers hidden: lets me check for the usual forgery signs.
- Your CV: lets me tailor a search to genuine roles at €30k or more.
- L2 research (up to 5 more searches and 2 more fetches): could surface public reports of this handle, which would only add to a verdict that doesn't need it.

## Questions

1. Have you already sent anything to them, such as documents, bank details or money? If so, tell me what and when, and I'll give you the specific steps to take.
2. Which jobs site was the posting on, and do you have a link? (Ties to RR4.)
3. Would you like help finding real roles that fit your Zendesk and Excel experience and the €30k floor?

You can answer any of these briefly, say "skip", or just ask me to move on.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.