**Yes, worth applying to, on three conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3, R5a, R6a, R7, R8 · adjacent: R5b (leg-ulcer care) · unclear: R4 (clear, timely written records), R6b (continence care)
- `important` — adjacent: R10 (own small caseload) · unclear: R9 (end-of-life visits), R11 (care planning)
- `preferred` — absent: R12 (Doppler assessment)

R10 — a caseload never held, bridged by home visiting; R12 — Doppler never done, a preferred row; R4, R6b, R9, R11 — CV silent, worth a line if true.

**Opportunity ledger.** The role looks sound, and the pay and support entries run in its favour (RR2, RR5). Two items are unconfirmed: the live posting (RR1) and the terms and rota (RR3, RR4).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the post is confirmed live on Calderbrook's own channel (RR1); (2) the caseload step-up is framed as adjacent, never as caseload experience (R10); (3) the terms and rota are acceptable to you (RR3, RR4).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015, 410 staff, four locality hubs | `[grounded]` company About page |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin and care planning, on an electronic patient record | `[grounded]` JD |
| Support | A small caseload of your own, supported by a senior community nurse | `[grounded]` JD |
| Essential / desirable | Essential: NMC Adult registration, full UK licence (pool cars provided), one year's post-registration experience, clear timely records. Desirable: Doppler assessment | `[grounded]` JD |
| Pay | £31,050–£37,800 plus mileage | `[grounded]` JD |
| Scope read | A conventional entry-level community post: small caseload, senior support, one named desirable skill | `[inferred]` from the JD's caseload and support wording |
| Market calibration | A survey of community staff nurses at Band 5 in England puts median basic pay at £34,300 (interquartile range £32,400–£36,600); the posted range spans that. The survey is a sample, not the official pay scale | `[generic]` Wardround 2026 survey (n=1,240) |
| Team lead | Rhiannon Mabbott has been a district nurse for eleven years and leads the Halifax team. A 2025 forum page lists her talks on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` forum speaker page, public professional footprint only |
| Unknowns | Hours, weekend and on-call rota; caseload size; contract terms (RR3, RR4) | — |
| Contradictions | None found between the JD and the About page. The vacancy itself was not found on the company's site (RR1) | `[grounded]` About page; careers fetch returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | CV states Registered Nurse (Adult), registration active, revalidation due March 2028. Checking the register is yours, not mine | `[grounded]` CV | none |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | CV states a full UK licence, category B; pool cars are provided | `[grounded]` CV, JD | none |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a ward staff nurse at a district general hospital | `[grounded]` CV | none |
| R4 | Clear, timely written records (on an electronic patient record) | must_have | unclear | low | discovery | CV says nothing about records or the systems you used. Five years on a ward suggests documentation was part of the job, but that is not evidence | `[inferred]` from ward tenure | see G4 |
| R5a | Wound care | must_have | direct | medium | presentation | Pressure ulcers and surgical wounds are on the CV, in a skills list rather than outcome lines | `[grounded]` CV | E1 pending approval |
| R5b | Leg-ulcer care | must_have | adjacent | medium | transferability | Pressure-ulcer and surgical wound care carry over. Leg-ulcer work, such as compression therapy, is not evidenced. Teams that run leg-ulcer clinics often assess before dressing | `[grounded]` CV; `[generic]` clinic practice | see G2 |
| R6a | Catheter care | must_have | direct | medium | presentation | On the CV skills list only | `[grounded]` CV | E1 pending approval |
| R6b | Continence care | must_have | unclear | low | discovery | The CV does not mention it | `[grounded]` CV silence | see G4 |
| R7 | Insulin administration | must_have | direct | medium | none | On the CV | `[grounded]` CV | none |
| R8 | Home visits to housebound adults | must_have | direct | medium | presentation | 18 months on the discharge-to-assess team, visiting patients at home in their first week after discharge. Limit: post-discharge patients, not long-term housebound ones | `[grounded]` CV | E1 pending approval |
| R9 | End-of-life visits | important | unclear | low | discovery | CV silent | `[grounded]` CV silence | see G3 |
| R10 | Holding a small caseload of your own, with senior support | important | adjacent | medium | transferability | You confirm you have never held one. The adjacent evidence is the home-visiting secondment. Limit: no evidence of owning a list or planning your own day | `[grounded]` your statement, CV | see G1 |
| R11 | Care planning | important | unclear | low | discovery | CV silent | `[grounded]` CV silence | see G1 |
| R12 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You confirm you have never done one. It is a desirable, not an essential | `[grounded]` your statement, JD | G5 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Own caseload and care planning (R10, R11) | transferability | Home visits confirmed. Nothing on who set your visit list or wrote the care plans | R10 is the real step up; a stronger bridge is the likeliest thing interviewers press on | Planning your own day's visits; writing or updating discharge care plans; deciding visit priority | A sanitised care-plan template; a role description for the secondment | `[inferred]` bridge from the secondment; `[generic]` that caseload ownership is the usual interview probe for a first community post |
| G2 | Leg-ulcer care (R5b) | transferability | Other wound types only | Leg ulcers are named in the JD | Applying compression, tissue-viability study days, shadowing a leg-ulcer clinic | A training record or certificate | `[grounded]` CV; `[inferred]` bridge |
| G3 | End-of-life visits (R9) | discovery | Nothing either way | Named in the JD's duties | Rapid discharges home for end-of-life care; symptom and family support on the ward; anticipatory prescribing | A training or palliative study-day record | `[grounded]` CV silence |
| G4 | Records and continence (R4, R6b) | discovery | Not mentioned | R4 is an essential in the JD | The electronic record systems you used; continence assessments or product choices on the ward | System names; an audit result | `[grounded]` CV silence |
| G5 | Doppler (R12) | capability | No direct or adjacent evidence | Preferred only | A course, or training once in post, if the employer offers it. Rhiannon Mabbott's public talk on Doppler training for staff new to community work suggests the team thinks about it, which is not a promise it is offered | A course booking | `[inferred]` from the speaker page |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not found on the company's site | unknown | — | "Join our district nursing team" | The About page says vacancies are on a careers page. My fetch of /careers returned no page, so that URL may simply be wrong. The post may also be listed elsewhere | `[grounded]` About page, failed fetch; `[generic]` that small providers often list on external job boards | Can you point me to this role on your own careers page? | unresolved |
| RR2 | Pay stated and within the survey range | positive_signal | — | "£31,050–£37,800 a year plus mileage" | Pay is transparent and in line with comparable posts | `[grounded]` JD; `[generic]` survey band | Where on the range does a nurse with five years' ward experience usually start? | noted |
| RR3 | Hours, rota and on-call unstated | unknown | — | "end-of-life visits" | Visits for dying patients may mean weekend or out-of-hours work | `[inferred]` from the JD's duties and its silence on hours | What are the working hours, and what weekend or on-call rota applies? | unresolved |
| RR4 | Contract terms unstated | unknown | — | "Band 5" | Band 5 usually signals NHS pay-scale terms, but a community interest company may set its own pension and sick pay | `[generic]` pattern, not a claim about this employer | Are terms on the NHS Agenda for Change scale, including pension and sick pay? And when is mileage paid, given that pool cars are provided? | unresolved |
| RR5 | Senior support and a named lead who offers a chat | positive_signal | — | "supported by a senior community nurse" | The post is built for someone new to holding a caseload | `[grounded]` JD | How much supervised caseload do new starters get, and for how long? | noted |

## Application plan

Nothing here is final CV or outreach language until you approve it. That covers the prose in the rows as well as the table.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Make the home visiting a lead bullet. Draft: "Visited patients in their own homes in their first week after discharge, on the hospital's discharge-to-assess team (18-month secondment)". Move wound, catheter and insulin work out of the skills list into outcome lines you can support | See R5a, R6a, R8 | `[grounded]` CV | pending your approval |
| E2 | Describe the secondment for what it was and do not use the word caseload. Finalise after your G1 answer | See R10 | `[grounded]` your statement | pending your approval |
| A1 | Take up the advert's invitation to an informal chat with Rhiannon Mabbott before applying, and ask about caseload ramp-up and Doppler training | See R10, R12, RR3, RR4 | `[grounded]` JD, speaker page | pending your approval |
| A2 | Confirm the post is live on Calderbrook's own channel before investing effort | See RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask the register's verification questions in the chat or interview | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Stage was not stated, so I assumed you are evaluating. Your National Insurance number isn't needed for this and I haven't used it. Your NMC registration and licence are taken as you stated them, and I sent no identifier in any search.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax district nursing Community Staff Nurse" and "Calderbrook Community Health careers vacancies Community Staff Nurse Band 5 Halifax"; both returned "About Calderbrook Community Health" (calderbrookhealth.example/about). A fetch of calderbrookhealth.example/careers returned no page. Role reality: the organization confirmed as described. The live posting was not found (RR1) |
| 2. Role-family sweep | yes | Searched "NHS Agenda for Change Band 5 pay scale 2026/27 community staff nurse district nurse", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Market calibration and RR2. It did not return the official pay scale |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Role reality's team-lead row; G5; plan row A1 |

If you want, I can write this up as `tuesday-dossier.md` to keep.

## Upgrade menu

- Your answer to G1 → R10 and R11 can move from adjacent or unclear, and E2 gets finalised.
- A training record or study-day certificate (compression, tissue viability, palliative care) → R5b, R9 firmed up.
- The electronic record systems you've used → R4 resolved.
- The vacancy on Calderbrook's own careers page, or the recruiter's email domain → RR1 closed.
- Rhiannon's answers on hours, rota and terms → RR3, RR4 closed.
- A deeper research pass on Calderbrook (inspection and regulator reports, leadership changes, recent news; up to 5 more searches and 2 more fetches), if you say so.

## Questions

1. G1 — In the discharge-to-assess team, who decided which patients you visited each day, and did you write or update care plans yourself? What did you own?
2. G3 — Have you been involved in end-of-life care, on the ward or in discharges home, and in what part?
3. G2 — Have you dressed or compressed leg ulcers, or done any compression or tissue-viability training?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.