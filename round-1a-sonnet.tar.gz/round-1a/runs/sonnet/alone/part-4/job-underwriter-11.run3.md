I've read the underwriting rules and am now loading the search tool so I can check that both employers and postings are real before I write the assessment.
**Decision snapshot**

Sorry about the layoff. **First (Duinvaart Cold Chain): yes, worth your time. Status: `conditional_go`. Second (Kroonhaven Foods): no, not worth a tailored application. Status: `no_go`. B2, B4 and B6, all `must_have` rows, are `absent` — you have no planning work, no planning system and no plan ownership to show.**

**Fit ledger, First (rows A1–A9).**

- `hard_gate` — unclear: A1 (Hybrid, three days in Rotterdam)
- `must_have` — direct: A2, A3, A4
- `important` — direct: A5 · adjacent: A7 (Work with depot managers on route changes) · unclear: A6 (Temperature compliance on refrigerated fleet)
- `preferred` — adjacent: A8 (Dutch a plus)

A6 — cold-chain compliance is untested in what you've told me; A7 — a route-performance review is close to route changes, but I can't see that yours produced any.

**Fit ledger, Second (rows B1–B7).**

- `hard_gate` — unclear: B1 (On-site in Utrecht)
- `must_have` — adjacent: B5 (Fluent Dutch) · unclear: B3 (Advanced Excel) · absent: B2 (3+ years FMCG planning), B4 (SAP IBP or similar), B6 (Own the 13-week supply plan)
- `important` — adjacent: B7 (Run the weekly S&OP meeting)

B2, B4, B6 — planning work, system and plan ownership are all missing; B5 — your conversational Dutch against "fluent".

**Opportunity ledger.** First: the duties are concrete (RA3), but the employer is unverified (RA1), no pay is stated (RA2), and how much Dutch the depot work needs is unknown (RA4). Second: the scope is concrete (RB3), but the employer is unverified (RB1), no pay is stated (RB2) and decision rights over the plan are unclear (RB4).

- **Hard gates:** First: none failed; unconfirmed: A1 (Hybrid, three days in Rotterdam); candidate constraints not given — checks against them unknown. Second: none failed; unconfirmed: B1 (On-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found, in either posting.
- **What would change this:** First — conditions for go: (1) A1 is workable for you; (2) the posting shows on Duinvaart's own careers page (RA1); (3) A6 stays framed as adjacent unless you have real temperature-tracking work. Second — `no_go` would flip only if you had FMCG planning work and system experience you haven't mentioned (B2, B4, B6). Wording can't create that.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| First: organization | Duinvaart Cold Chain, Rotterdam; the posting says it runs a refrigerated fleet. Whether it exists as described is not checked (target 1) | `[grounded]` JD as pasted |
| First: mandate | Track on-time delivery and temperature compliance, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` JD |
| First: working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` JD |
| First: scope read | A single-analyst post with three named duties and no stated reporting line or team | `[inferred]` from the three duties against the JD's silence on reporting |
| Second: organization | Kroonhaven Foods, Utrecht; chilled ready-meals range. Existence not checked (target 1) | `[grounded]` JD as pasted |
| Second: mandate | Own the 13-week supply plan, balance capacity against forecast, run the weekly S&OP meeting | `[grounded]` JD |
| Second: working pattern | On-site in Utrecht | `[grounded]` JD |
| Second: scope read | A planner-owned role, not an analyst role: the plan and the meeting sit with the post | `[inferred]` from "own" and "run" in the duties |
| Market calibration | Not available for either: the role-family search was refused, so no band is given and the pay gap can't be assessed | `[generic]` none run |
| Unknowns | Both: pay, reporting line, employer verification. First: Dutch needed day to day. Second: authority over production | `[grounded]` JD silence |
| Contradictions | None between the two postings as pasted; no careers pages could be checked | `[grounded]` JD as pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| A1 | Hybrid, three days a week in Rotterdam office | hard_gate | unclear | none | hard_gate | You haven't stated where you live or what commute you accept, so I can't call it met | `[grounded]` JD; no candidate constraint given | Confirm it works (question 1) |
| A2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | 4 years as an operations analyst at a parcel carrier, as you stated. No document yet, so expect a probe | `[grounded]` your account | none |
| A3 | Strong SQL | must_have | direct | medium | none | You use SQL daily, as stated; no inspectable sample | `[grounded]` your account | Optional: a sanitized query example would raise to `high` |
| A4 | Power BI or Tableau, weekly dashboards | must_have | direct | medium | none | Daily Power BI, including the on-time dashboard depot managers use. Whether it ran weekly isn't stated | `[grounded]` your account | Optional: a dashboard screenshot would raise to `high` |
| A5 | Track on-time delivery | important | direct | medium | none | Your on-time delivery dashboard is the same metric, for a parcel network | `[grounded]` your account | none |
| A6 | Track temperature compliance on a refrigerated fleet | important | unclear | low | discovery | Nothing you've said touches temperature or cold chain; parcel work may have had temperature-controlled lanes, but I have no evidence | `[grounded]` silence in your account; `[generic]` that some carriers run temperature-controlled lanes | Question 2 |
| A7 | Work with depot managers on route changes | important | adjacent | medium | discovery | You ran a weekly route-performance review and built the depot managers' dashboard. Limit: nothing says the review produced route changes | `[grounded]` your account | Question 3 |
| A8 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational Dutch. Limit: not working-level; state it as conversational | `[grounded]` your account | Say "conversational Dutch" and nothing stronger |
| B1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | No stated location or constraint, so I can't call it met | `[grounded]` JD; no candidate constraint given | Only matters if you pursue it |
| B2 | 3+ years supply or demand planning in FMCG | must_have | absent | none | capability | You've never worked in planning, and a parcel carrier isn't FMCG, so no direct or adjacent evidence exists | `[grounded]` your account | Closure path in G5 |
| B3 | Advanced Excel | must_have | unclear | low | discovery | Excel isn't mentioned; you may well have it as an analyst | `[grounded]` silence in your account | Optional only; doesn't change the decision |
| B4 | SAP IBP or a similar planning system | must_have | absent | none | capability | SQL and Power BI are reporting tools, not planning systems | `[grounded]` your account | Closure path in G5 |
| B5 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational Dutch is credible but not fluent. Limit: no wording closes that, and a "fluent" requirement may be screened literally | `[grounded]` your account; `[generic]` that language requirements are often screened literally | Don't claim fluency |
| B6 | Own the 13-week supply plan, balancing capacity against forecast | must_have | absent | none | capability | No plan ownership, forecast or capacity work in your history | `[grounded]` your account | Closure path in G5 |
| B7 | Run the weekly S&OP meeting | important | adjacent | medium | transferability | You ran a weekly route-performance review. Limit: nothing shows it covered forecast against capacity or included commercial and production teams | `[grounded]` your account | Not needed for the decision |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Temperature compliance (A6, important) | discovery | Nothing on temperature or cold chain | It's the one duty with no evidence behind it, and the likeliest probe | Pharma or fresh/frozen lanes at your carrier, spoilage or claims analysis, any temperature-excursion reports | A sanitized report or dashboard screenshot | `[grounded]` your account |
| G2 | Route changes with depot managers (A7, important) | discovery | A review and a dashboard, not a stated outcome | It decides whether A7 is `direct` | A route or schedule change that came out of the weekly review | A review summary or before/after metric | `[grounded]` your account |
| G3 | Hybrid commute (A1, hard gate) | hard_gate | No stated constraint | A gate unconfirmed can't be treated as met | — | — | `[grounded]` JD |
| G4 | Dutch level (A8, B5) | transferability | Conversational Dutch | Credible for First's "a plus"; short of Second's "fluent" | Meetings or written work you do in Dutch | A short work sample in Dutch, if any | `[grounded]` your account |
| G5 | Planning experience (B2, B4, B6) | capability | No planning work | Three `must_have` rows with no evidence and no realistic closure for this posting | — | — | `[grounded]` your account; closure path `[generic]`: roles titled planning analyst or S&OP analyst, where analytics is the way in |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RA1 | First: employer not established | risk_signal | medium | "Operations Analyst — Duinvaart Cold Chain, Rotterdam" | The company may be small with a thin footprint, the posting may be stale, or I simply couldn't check: the search was refused | `[generic]` pattern, not a claim about this company | Can you point me to this role on your own careers site, and who I'd interview with? | unresolved |
| RA2 | First: pay not stated | unknown | — | (posting states no pay) | Pay may sit anywhere in the market range; no band could be checked | `[inferred]` from the posting's silence | What salary range is budgeted for this post? | unresolved |
| RA3 | First: duties are concrete | positive_signal | — | "Track on-time delivery and temperature compliance across our refrigerated fleet" | The role is defined by named, measurable outputs | `[grounded]` JD | What does a good first quarter look like? | noted |
| RA4 | First: Dutch need unknown | unknown | — | "Dutch a plus" | Depot managers may work in Dutch, making your conversational level matter day to day | `[inferred]` from depot work against "a plus" | Which language do depot managers and weekly reviews run in? | unresolved |
| RB1 | Second: employer not established | risk_signal | medium | "Supply Planner — Kroonhaven Foods, Utrecht" | Same possibilities as RA1 | `[generic]` pattern, not a claim about this company | Can you point me to this role on your own careers site? | unresolved |
| RB2 | Second: pay not stated | unknown | — | (posting states no pay) | As RA2 | `[inferred]` from the posting's silence | What salary range is budgeted? | unresolved |
| RB3 | Second: scope is concrete | positive_signal | — | "Own the 13-week supply plan for our chilled ready-meals range" | The role is clearly defined | `[grounded]` JD | Who owns the forecast the plan is built on? | noted |
| RB4 | Second: decision rights unclear | unknown | — | "balance production capacity against the forecast" | The post may own the plan without authority over production | `[inferred]` from "balance" against silence on decision rights | Who can change production, and who decides when plan and capacity conflict? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | First: CV line restating your work, e.g. "Built and ran the on-time delivery dashboard (SQL, Power BI) used by depot managers; ran the weekly route-performance review." No cold-chain or temperature claim | See A2–A5, A7 | `[grounded]` your account | pending your approval |
| E2 | First: list Dutch as "conversational" | See A8 | `[grounded]` your account | pending your approval |
| A1 | First: confirm the posting on Duinvaart's own careers page before applying | See RA1 | `[grounded]` RA1 | pending your approval |
| Q1 | First: ask RA2 and RA4's questions verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A2 | Second: skip it; if you want a planning path, aim at planning analyst or S&OP analyst roles instead | See B2, B4, B6, G5 | `[generic]` role-family pattern | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches "Duinvaart Cold Chain Rotterdam" and "Kroonhaven Foods Utrecht chilled ready meals" were refused. They would have settled whether each employer exists as described and the posting is live: role reality, RA1 and RB1 |
| 2. Role-family sweep | unavailable | Search "operations analyst logistics Netherlands salary Power BI SQL" was refused. It would have given a pay band and scope norm: market calibration and RA2/RB2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- Permission to run the searches that were refused → employer checks for both, a pay band, and a pay-gap check for RA2.
- A sanitized SQL query or dashboard screenshot → A3, A4 to `high`.
- Any temperature-related report from your carrier → A6 from `unclear` toward `direct` or `adjacent`.
- Your location and the commute you'd accept → A1 settled.
- The posting's link → a live-posting check for RA1.

I can also save all this as `tuesday-dossier.md` if you'd like to keep it.

Questions, as many or as few as you like:

1. **A1:** Is three days a week in Rotterdam workable for you?
2. **A6:** Did your carrier track anything temperature-sensitive (pharma, fresh or frozen parcels, spoilage claims)?
3. **A7:** Did your weekly route-performance review lead to route changes you proposed or ran with depot managers?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.