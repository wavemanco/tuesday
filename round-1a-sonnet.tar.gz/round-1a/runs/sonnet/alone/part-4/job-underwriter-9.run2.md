Quick status: the skill told me to check Marrowgate and the Irish rules online, but the web searches were refused, so I'm working only from what you pasted. Here's the assessment.

## Decision snapshot

**Worth accepting, on conditions. Status: `conditional_go`.** The requests are normal in themselves. Two things need checking before you hand anything over.

**Fit ledger.**

- `hard_gate`: unclear: R10 (Hybrid, two days in Limerick), R11 (Pay at €40,000)
- `must_have`: direct: R1, R3, R4, R6, R8 · adjacent: R5 (Monthly payroll for 240 staff) · unclear: R2 (Irish PAYE, PRSI, USC)
- `important`: absent: R7 (Pension changes) · unclear: R9 (Staff payroll queries)

R5 and R7 are the gaps to know about. The first is a step up in scale, and the second is new to you.

**Opportunity ledger.** The process looks ordinary and well sequenced. You had two in-person interviews, the offer matches the ad, and the manager is named. It asks for sensitive documents only after acceptance and says why for each one. The open points are that I couldn't confirm the employer exists as described (RR1), that the onboarding link needs checking (RR2), and that the offer leaves out terms you'd want in writing (RR3).

- **Hard gates:** none failed; unconfirmed: R10 (Hybrid, two days in Limerick), R11 (Pay at €40,000). Your constraints weren't given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) verify the onboarding link and sender through a channel you already trust, see RR2; (2) get the written contract before you hand over documents, see RR3; (3) confirm your own location and pay limits, R10 and R11.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick | `[grounded]` ad and offer text; not independently confirmed |
| Mandate | Monthly payroll for 240 staff; starters, leavers and pension changes; monthly payroll-to-ledger reconciliation; staff queries | `[grounded]` ad |
| Terms | Permanent, €40,000 (ad band €38–42k), hybrid 2 days a week, reporting to Declan Garvagh, Finance Manager | `[grounded]` offer |
| Scope read | A one-person payroll role, but the ad lists three years' worth of tasks and no payroll team | `[inferred]` from the ad naming no colleagues |
| Market calibration | I couldn't check pay or scope this session. The salary band and the document requests are consistent with an ordinary mid-level Irish payroll job | `[generic]` from memory, not verified |
| Unknowns | Payroll software, probation, notice terms, pension scheme, start date | None given |
| Contradictions | None between the ad and the offer | `[grounded]` |

## Your question: are the requests normal?

- **Bank details.** Yes. Employers can't pay you without them. `[generic]`
- **PPS number.** Yes. An Irish employer needs it to register you with Revenue and file your payroll. It's reasonable to give it once you've accepted. `[generic]`
- **Passport.** Mostly. Employers do identity and right-to-work checks, and asking for the original on day one is the strongest sign of a real employer. A scan before you've started is common but goes slightly beyond what's needed for an Irish or EU citizen. You can ask whether bringing the original on day one is enough. `[generic]`

Your instinct is right for the wrong moment, though. Never send these in reply to an unsolicited email, a recruiter who hasn't interviewed you, or a link you can't verify. Here you've had two in-person interviews and a named manager, and the request comes after acceptance. That is the normal order. None of the Irish-law points above could be checked against Revenue or the Data Protection Commission this session, so treat them as general knowledge.

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 2+ years running payroll | must_have | direct | medium | none | 3 years, fortnightly, 90 staff | `[grounded]` your account; no document read | none |
| R2 | Irish PAYE, PRSI, USC | must_have | unclear | low | discovery | You didn't say your hotel payroll was Irish, though the PPS context suggests it | `[grounded]` silence on this | question Q2 |
| R3 | Strong Excel | must_have | direct | medium | none | Daily use, pivot tables, XLOOKUP | `[grounded]` your account | none |
| R4 | Payroll qualification or working towards | must_have | direct | medium | none | Payroll Technician certificate, 2024 | `[grounded]` your account | none |
| R5 | Monthly payroll for 240 staff | must_have | adjacent | medium | transferability | You've run 90 staff, so 2.7× the headcount, and monthly where you ran fortnightly | `[inferred]` from the two payroll descriptions | frame as scale-up, not equivalence |
| R6 | Starters and leavers | must_have | direct | medium | none | Done in your hotel role | `[grounded]` your account | none |
| R7 | Pension changes | important | absent | low | capability | Your manager handled these, so none done hands-on | `[grounded]` your account | question Q3; ask for onboarding on it |
| R8 | Monthly payroll-to-ledger reconciliation | must_have | direct | medium | none | Done monthly | `[grounded]` your account | none |
| R9 | Answering staff payroll queries | important | unclear | low | discovery | Not mentioned either way | `[grounded]` silence | none; likely recoverable from your hotel work |
| R10 | Hybrid, 2 days in Limerick | hard_gate | unclear | low | hard_gate | You attended in person, but your constraints weren't given | `[grounded]` | question Q1 |
| R11 | Pay: €40,000 within the €38–42k band | hard_gate | unclear | low | hard_gate | In band; your floor isn't known | `[grounded]` offer | question Q1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pension changes (R7, important) | capability | You've seen them handled, and haven't done them | It's a named duty from day one | Preparing the inputs your manager actioned, or checking pension deductions in a payroll run | A short description of what you did around them | `[inferred]` from your account |
| G2 | Scale and monthly cadence (R5, must_have) | transferability | 90 fortnightly vs 240 monthly | The step up is real but modest | Any month-end process you ran | The hotel reconciliation workflow | `[inferred]` |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer existence not confirmed | unknown | — | "Marrowgate Housing, a housing association in Limerick" | Probably real, given two in-person interviews. The search was refused. The sender domain `marrowgate.example` is a reserved placeholder, likely anonymised in your paste | `[inferred]` from your interviews; `[generic]` for the domain note | Does the offer come from the same domain as the people who set up your interviews? | unresolved |
| RR2 | Document link not yet sent | unknown | — | "we will send you a link to our onboarding portal" | A fake portal is the usual way a scam harvests PPS, bank and passport details | `[generic]` fraud pattern | Does the link match the company's own website domain, and does the People Team confirm by phone or through Declan? | unresolved |
| RR3 | Terms missing from the offer | risk_signal | low | "starting on a date we agree" | No contract, probation, notice period or pension terms in the email | `[inferred]` from what the email omits | Can I see the written contract before I send documents? | unresolved |
| RR4 | Sensitive data requested only after acceptance, with a stated purpose | positive_signal | — | "bank details for salary payments, your PPS number for Revenue" | The reasons given match the real purposes | `[grounded]` offer text | Does the portal have a privacy notice? | noted |
| RR5 | Two in-person interviews, named manager, offer matches ad | positive_signal | — | "reporting to Declan Garvagh, Finance Manager" | A genuine hiring process | `[grounded]` your account and the offer | None needed | noted |

## Application plan

All of these wait on your approval.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Accept in writing, subject to receiving the full contract | See RR3 | `[grounded]` RR3 | pending your approval |
| A2 | Before using the portal link, check that its domain matches Marrowgate's own site, or phone the number from your interview arrangements | See RR1, RR2 | `[generic]` standard fraud check | pending your approval |
| A3 | Ask whether the passport can be verified in person on day one instead of scanned | Data minimisation | `[generic]` | pending your approval |
| A4 | Ask Declan for an induction on pension changes | See R7 | `[grounded]` R7 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5 (all refused, no permission), fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Marrowgate Housing Limerick housing association" was refused. It would have tested RR1 and the consistency of the ad |
| 2. Role-family sweep | unavailable | Not sent as a pay search. Pay and scope calibration stay `[generic]` |
| 3. Hiring manager's footprint | skipped | I didn't search for Declan Garvagh. It wasn't needed to answer your question |

Two further searches, on Revenue's PPS rules and on Irish identity-check guidance, were also refused. They fit none of the declared targets, so they have no row.

I can write this up as `tuesday-dossier.md` if you want a file to keep.

## Upgrade menu

- A link to Marrowgate's own website, or the careers page where the ad appeared → RR1 closes.
- The onboarding link itself, with the sender address → RR2 closes (don't paste any document or number).
- The written contract → RR3, plus start date, probation and notice.
- Your pay floor and travel limits → R10 and R11 move from unclear.
- Permission for web searches → the company check and Irish-rules check could run.

## Questions

1. **R10, R11:** Is €40,000 at or above your minimum, and is two days a week in Limerick workable for you?
2. **R2:** Was your hotel group's payroll Irish PAYE, PRSI and USC?
3. **R7:** Did you ever prepare or check pension-related inputs, even if your manager did the changes?

Answer any, say "skip", or tell me to move on.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.