Loaded the search tool. I'm now checking whether Velloway Logistics exists as described, then I'll write up the assessment.
**No, don't go ahead, and don't send your IBAN, PPS number or passport photo. Status: `no_go`.** This is a fake-job scam. The cause is the messages themselves (RR1, RR2, RR3), not any hard gate, and your pay gate R1 is moot.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (pay of €30,000+ a year)
- `must_have` — direct: R2, R3
- `important` — direct: R4
- `preferred` — unclear: R5 (a quiet place to work)

R2, R3 and R4 — your background matches the stated tasks, which is exactly what a scam posting is built to flatter.

**Opportunity ledger.** The role fails on its own terms. It charges you money (RR1), sends a cheque for you to forward on (RR2), and collects your identity documents before any contract (RR3). The employer can't be verified (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (pay of €30,000+ a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would change this:** a verified Velloway entity with its own domain, a signed contract, and no request for money, forwarded funds or ID up front. The first three messages already rule that out.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics": no web presence found under that name | `[grounded]` two searches, nothing attributable |
| Role | Remote order processing, 15–30 hrs/week, up to €26/hr plus unspecified commission | `[grounded]` posting |
| Hiring process | Telegram only, no calls or video | `[grounded]` posting |
| Pay against your floor | €26 × 30 hrs × 52 weeks is about €40,500 at the very top. You need about 22 hrs/week at the top rate to reach €30,000, and at 15 hrs it's about €20,300. "Up to" and unstated commission make it unknowable. | `[inferred]` arithmetic on the posting's figures |
| Market calibration | Legitimate no-experience, set-your-own-hours roles at this rate are not the norm, and genuine employers don't run the whole hiring process through a chat account | `[generic]` pattern; role-family sweep returned nothing |
| Contradictions | Posting says "interview"; the "interview" was chat answers. Contact email is a generic mail domain, not a Velloway domain | `[grounded]` your messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay of at least €30,000 a year (your constraint) | hard_gate | unclear | high | hard_gate | Confidence grades your own constraint. Fit is unclear because hours are a range and "up to" and commission are unquantified | `[grounded]` your statement and the posting | moot; see RR1–RR4 |
| R2 | Strong attention to detail | must_have | direct | medium | none | About 60 Zendesk tickets a day at a parcel courier | `[grounded]` your account | none |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly Excel tracker | `[grounded]` your account | none |
| R4 | Good written English | important | direct | medium | none | Ticket-based written support for three years | `[grounded]` your account | none |
| R5 | A quiet place to work | preferred | unclear | low | discovery | You haven't said | `[grounded]` silence | none |

## Gap recovery queue

| ID | Gap | What would close it |
|---|---|---|
| G1 | Whether any identifying detail, money or address has gone out already | Your confirmation of what you have and haven't shared (asked below as Q1, RR3) |
| G2 | Whether a cheque has been posted to you | Your confirmation (asked below as Q2, RR2) |

## Opportunity risk register

| ID | Class | Severity | What it is | Provenance |
|---|---|---|---|---|
| RR1 | Red flag | high | Advance fee: you're asked to pay €349 for a "work kit" to an "equipment partner" with a promised refund. Real employers supply equipment or reimburse through payroll, not through a transfer to a third party first. | `[grounded]` message 2; `[generic]` pattern |
| RR2 | Red flag | high | Cheque overpayment: a €2,850 cheque, you keep €350 and send the rest on. A cheque can appear as credit in your account and later bounce, and you'd then owe the bank the money you sent. | `[grounded]` message 3; `[generic]` how cheques clear |
| RR3 | Red flag | high | Identity harvesting: IBAN, PPS number and passport photo requested straight after a "first screening", before any interview or contract. That set is enough for identity fraud or for using your account to move other people's money. | `[grounded]` message 1 |
| RR4 | Failed attribution | high | The employer isn't established. Searches found nothing attributable to Velloway Logistics or the handle, so the posting and the company are unverified. | `[grounded]` two searches, no results |
| RR5 | Mismatch | medium | Pay and conditions (no experience, own hours, €26/hr) sit far above the usual market for entry-level processing work. | `[generic]` |
| RR6 | Red flag | medium | The "hired" message comes straight after chat answers, with the cheque arriving before any contract or onboarding. | `[grounded]` message 3 |

## Application plan

**Don't apply.** Do these now:

1. Send nothing: no IBAN, PPS number, passport photo or money, and don't lodge or forward any cheque.
2. Stop replying to @VellowayHiring and don't use the email address.
3. Report the account to Telegram and to the jobs site where you found the post.
4. If a cheque arrives, don't lodge it; tell your bank's fraud team. Reporting to the Gardaí is also reasonable. `[generic]` guidance.

You were right to check first. Your actual background (courier customer service, Zendesk volume, training two new starters, the Excel tracker) is real, saleable evidence for genuine roles at your €30,000 floor. Wording proposals for your CV are pending your approval, and nothing here is final until you approve it:

- E1: "Resolved about 60 customer tickets a day in Zendesk at a parcel courier."
- E2: "Trained two new starters."
- E3: "Maintain the team's weekly performance tracker in Excel."

## Evidence status

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | yes | Searched "Velloway Logistics Order Processing Coordinator Telegram @VellowayHiring": no results, so the entity is not established (RR4) |
| 2 | Role-family sweep | yes | Searched "fake job Telegram cheque overpayment equipment laptop headset scam Ireland remote order processing": no results, so the market line stays `[generic]` and moved nothing |
| 3 | Hiring manager footprint | n/a | No named person, only a chat handle |

If you want the thread checked against known scam reports or recent news, I can run a deeper pass. It would take up to 5 more searches and 2 more fetches.

I can also save all of this as `tuesday-dossier.md` if you want a record to keep.

**Upgrade menu**

- The jobs-site name and the posting link would let me check whether the listing is still live and who posted it.
- A screenshot of the Telegram profile (not any ID) would show when the account was made.
- The cheque, if it arrives, would let me describe exactly what to tell your bank.
- Your target titles and location would let me look for genuine roles at €30,000+.

**Questions** (answer, say "skip", or say "not sure")

1. **RR3:** Have you sent anything to them yet: any number, document, address or money, including inside the chat?
2. **RR2:** Has a cheque actually arrived, or have they only said it's coming?
3. **R1:** Would you like help targeting real customer-service or logistics roles at €30,000 or more?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.