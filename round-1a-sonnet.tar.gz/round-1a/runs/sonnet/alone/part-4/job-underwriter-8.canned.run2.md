I searched the web for the company, found nothing, and have now put the full assessment together.

## Decision snapshot

**No, don't go ahead. This is a fake job built to get your money and identity documents. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Income of at least €30,000 a year)
- `must_have` — direct: R2, R3, R4
- `important` — adjacent: R6 (Order processing) · unclear: R5 (A quiet place to work)

**Opportunity ledger.** Three severe red flags, each a standard step in an advance-fee and cheque-overpayment scam: a "refundable" payment for equipment (RR1), a cheque you are asked to forward money from (RR2), and your passport, PPS number and IBAN requested before any contract (RR3). The Telegram-only hiring (RR4) and the employer I couldn't find online (RR5) point the same way.

- **Hard gates:** none failed; unconfirmed: R1 (Income of at least €30,000 a year)
- **Severe red flags:** RR1, RR2, RR3
- **Conditions for go:** none. No wording, reply or fix makes this legitimate.

**Do not:**
- send your passport photo, PPS number or IBAN;
- pay the €349;
- lodge the cheque, or transfer anything from it.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics" — no web presence found under that name | `[grounded]` search returned no results |
| Role | Remote order processing, 15–30 hours a week, up to €26 an hour plus commission | `[grounded]` posting |
| Hiring channel | Telegram only, no calls or video, offer reached after a text chat | `[grounded]` posting and messages |
| Pay arithmetic | €26 an hour is the top rate, and €30,000 a year needs about 22 hours a week at that rate. The posting says "up to", so reaching your floor depends on hours and rate it doesn't guarantee | `[inferred]` from the posting's figures |
| Market calibration | Genuine employers don't ask candidates to pay for equipment or to forward money from a cheque. Legitimate order-processing roles are typically employed or contracted, with ID collected after a signed offer | `[generic]` |
| Unknowns | Registered company, address, who "payroll" or the "equipment partner" are, and who owns the HR mailbox | `[grounded]` none provided |
| Contradictions | "No experience needed" alongside up to €26 an hour, and an offer made within a chat with no real interview | `[inferred]` from the posting against the messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Income of at least €30,000 a year (your constraint) | hard_gate | unclear | high | hard_gate | Confidence grades your stated constraint. Fit is unclear because pay is "up to" and hours are variable. Moot given the red flags | `[grounded]` user-stated constraint; posting figures | none, role rejected |
| R2 | Strong attention to detail | must_have | direct | medium | none | Around 60 tickets a day at a courier is the volume and care this implies, though the claim is CV-level only | `[grounded]` your background | none |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep the team's weekly tracker in Excel | `[grounded]` your background | none |
| R4 | Good written English | must_have | direct | medium | none | Written Zendesk work for three years is the evidence | `[grounded]` your background | none |
| R5 | A quiet place to work | important | unclear | low | discovery | You haven't said, and it doesn't matter here | `[grounded]` not stated | none |
| R6 | Order processing | important | adjacent | medium | transferability | Parcel customer service touches orders and tracking, but you haven't described order entry | `[inferred]` from your courier role | none |

The role asks for little you couldn't do. That is part of why it works as bait.

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | A quiet place to work (R5, important) | discovery | Not stated | Irrelevant to this posting, and useful only for real remote roles | Your home setup | None needed | `[grounded]` not stated |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Upfront payment for "equipment", promised back later | red_flag | severe | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages" | Advance-fee fraud. The money goes to an account the scammers control and is never refunded | `[generic]` a widely documented job-scam pattern | Would a real employer ever ask this? (No: employers supply equipment or reimburse after you buy it) | resolved, reject |
| RR2 | Cheque you deposit, keep a slice of, and send the rest on | red_flag | severe | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350... transfer the rest" | Fake or stolen cheque. The bank may credit it provisionally, then reverse it when it fails, leaving you owing the money you sent | `[generic]` the standard overpayment scam pattern | Why would an employer send a new hire money to forward to a third party? | resolved, reject |
| RR3 | Passport, PPS number and IBAN requested before any contract | red_flag | severe | "send your IBAN, your PPS number and a clear photo of your passport" | Identity theft, or use of your account to move stolen money | `[generic]` a common step in job scams | Real employers collect this after a signed offer, through their own HR system. Is that the case here? (No) | resolved, reject |
| RR4 | Telegram-only hiring, no calls or video | risk_signal | high | "no calls or video interviews" | Avoids any real identity check or traceable interview | `[inferred]` | Who is the named hiring manager, and can they join a call? | resolved, reject |
| RR5 | Employer not found online | unknown | — | "Velloway Logistics" | No verifiable company exists. This stays unresolved, as one search is no proof either way | `[grounded]` search returned nothing | Is there a registered company with an address and a company-registry entry? | unresolved |
| RR6 | HR contact is a webmail-style address, not a company domain | risk_signal | medium | "velloway.hr@postmail.example" | Throwaway mailbox rather than a company mail system | `[inferred]` | Does the company's own website list this address? (No site found) | unresolved |
| RR7 | Offer issued after chat only, in the first stage | risk_signal | high | "you passed the interview and the job is yours" | Nobody is evaluating you, since the "interview" exists to reach the payment step | `[inferred]` | What assessed your candidacy? | resolved, reject |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Stop replying. Don't send documents, money or your IBAN, and block the Telegram account | RR1–RR3 | `[grounded]` register | pending your approval |
| A2 | Don't lodge the cheque. If it arrives, don't deposit it or send money on, and tell your bank if you have already | RR2 | `[grounded]` register | pending your approval |
| A3 | Report the posting to the jobs site, and the contact to Telegram and the Gardaí | Helps stop others being targeted | `[generic]` standard reporting practice | pending your approval |
| A4 | If you have already sent your passport, PPS number or IBAN, contact your bank and ask about identity-fraud protection | Limits misuse | `[generic]` | pending your approval |
| A5 | Look for genuine roles in courier, logistics or customer operations, where your Zendesk, training and Excel tracker work are direct evidence | R2–R4, R6 | `[inferred]` from your background | pending your approval |

## Evidence status

Verified: none yet. Your background claims are unverified leads. Everything about the posting comes from your own paste.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics", which returned no results. Entity not established, so RR5 stays unresolved |
| 2. Role-family sweep | skipped | A salary band would not change a decision that rests on RR1–RR3 |
| 3. Hiring manager's public footprint | n/a | No hiring manager name was given, only a Telegram handle |
| Outside declared targets | yes | Searched "remote job scam Telegram cheque overpayment equipment fee passport IBAN PPS number", which returned no results. The scam-pattern entries are `[generic]` |

## Upgrade menu

- I can write up this posting and the exchange as a report for the jobs site, Telegram or the Gardaí, without your IBAN or other personal details in it, if you want one.
- A link to the original posting, or the company page it pointed to, would let me check whether the listing is still live and who posted it.
- Your CV would let me check R2–R4 against real wording and underwrite genuine roles for you.
- A dossier of this assessment can be saved as `tuesday-dossier.md` if you want a record. It is optional, and probably of little use for a rejected role.
- A deeper research pass on the company name and handle (up to 5 more searches and 2 more fetches) is available on request. It is unlikely to change the decision.

Questions:
1. (RR1–RR3) Beyond answering their chat questions, have you sent them any documents, details or money? If you have, say exactly what, and I'll tailor A4.
2. (RR5) Which jobs site was the posting on, and does it still show the listing?
3. (A5) What sort of role would you like me to look at next? Share a posting or a title, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.