I'll read the reference files before building the assessment.
**Yes, worth pursuing, and Fernquay checks out as a real employer (RR1, RR2). The WhatsApp message alone isn't a warning sign (RR3). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: R2 (Salary €52,000–€60,000)
- `must_have`: direct: R3, R4, R5, R6
- `important`: adjacent: R7 (Own the booking flow end to end), R8 (Research calls with school owners), R9 (First designer, no design peers)

R9 (`medium`): the real stretch, in your own words "never the only designer"; R7: checkout is a credible bridge to the full flow, ownership scope unconfirmed; R2: the band against your minimum isn't known yet.

**Opportunity ledger.** The employer exists as described and the posting is transparent (RR1, RR2). Open items: how the WhatsApp and invite channel checks out (RR3), equity terms (RR4), decision rights for a first designer (RR5) and funding runway (RR6).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the band in R2 clears your own minimum; (2) the invite arrives from a Fernquay address and the call is as described, per RR3; (3) decision rights between you, Ronan and the engineers turn out to be concrete, per RR5. The answers to RR4 and RR6 should be in hand before you accept any offer.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: six people in Galway, makes Kelproster booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. Founded 2023 by Ronan Kehoe and Saoirse Doyle, funded by its customers | `[grounded]` About Fernquay page (search result) |
| Posting status | Live on the company's own careers page. Salary, hybrid pattern and "first design hire" agree with the posting you pasted | `[grounded]` careers page fetched |
| Mandate | Own the booking flow, run research calls with school owners, ship alongside two engineers | `[grounded]` JD |
| Who you'd work with | Ronan Kehoe, co-founder and CEO, previously a product lead at a Galway travel-software company for five years. His profile is public; your reporting line isn't stated | `[grounded]` profile page; `[grounded]` JD silent on reporting line |
| Scope read | One core flow, no design peers, no design-leadership scope. Coherent for a six-person company | `[inferred]` from the JD's "first designer" and its scope list |
| Market calibration | €52,000–€60,000 sits inside the middle range for product designers with 3–5 years in Ireland (median €57,000, interquartile €51,500–€62,000), with equity on top. This is a market band, not Fernquay's offer | `[generic]` one 2026 Ireland salary report, found in a single search, salary only, no remit data; `[grounded]` the posting's own figure |
| Unknowns | Reporting line; equity type and vesting; who has the final say on design; runway; how Ronan came to have your WhatsApp number; Saoirse's title (not shown in the page text I retrieved) | `[grounded]` absent from JD, careers page and About page |
| Contradictions | None found. The About page lists sailing schools as well, a harmless widening of the posting's "sea-kayak and surf" | `[grounded]` About page against JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week at the Galway office | hard_gate | direct | medium | none | You said you moved back to Galway last year, and the office is in Galway. Your willingness for two office days is unconfirmed | `[grounded]` your intake text and the JD | none |
| R2 | Salary €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | The JD states the band, but you haven't given a minimum, so it can't be met or failed yet. The band sits near the market median, which suggests it is not a lowball | `[grounded]` JD figure; `[generic]` salary report calibration | R2 question below |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company, in your words. Confirmed in text, nothing inspectable yet | `[grounded]` your intake text | none |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" shows heavy use. "Strong" is shown by a file or prototype, not by a statement | `[grounded]` your intake text | A Figma file or prototype link would raise it to `high` |
| R5 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. What you planned, ran and synthesised yourself is unconfirmed, and the kind is usability testing | `[grounded]` your intake text | See G2 |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | Worked in a squad with four engineers, against two here | `[grounded]` your intake text | none |
| R7 | Own the booking flow end to end | important | adjacent | medium | discovery | Redesigning checkout is a stage of a booking flow. Whether you owned the stages around it (search, availability, changes, confirmation) is not stated. Fernquay told you they liked the checkout case study | `[grounded]` your intake text and the WhatsApp message | See G1 |
| R8 | Run research calls with school owners | important | adjacent | medium | transferability | Usability sessions with customers carry over. The limit: whether those customers were operators or consumers is unstated. Research with business owners is a different kind of conversation | `[grounded]` your intake text; `[inferred]` limit from the JD's "school owners" | See G2 |
| R9 | Work as the first designer, with no design peers | important | adjacent | medium | transferability | Your statement that you've never been the only designer is specific. Squad work with engineers carries over, but setting your own process and critique loop does not. First-designer roles generally mean doing this without peer review | `[grounded]` your intake text; `[inferred]` requirement from "You would be our first designer"; `[generic]` what such roles involve | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Ownership beyond checkout (R7, important) | discovery | A checkout redesign. Nothing on who owned it, what shipped, or the flow before and after | "Own the booking flow end to end" is the headline of the role | Owning a flow from research through shipped design; designing availability or change-booking screens; working through edge cases after launch | Your checkout case study, before/after screens, release notes | `[grounded]` JD wording and intake text; `[generic]` that this is the claim an interviewer tests first |
| G2 | Research with business users (R5, R8) | discovery | Monthly usability sessions with customers, with no detail on participants or your part | Research calls with school owners are one of the three stated duties | Recruiting participants, writing the discussion guide, running sessions, synthesising and presenting findings; sessions with partners or operators, not just end customers | A sanitised discussion guide or synthesis summary | `[grounded]` intake text silent on participants |
| G3 | Sole-designer operation (R9, important) | transferability | Squad work, never the only designer | A first-designer role means setting your own standards with no peer to check them | Starting a shared Figma library or conventions; covering for a colleague's flows; being the only researcher in the squad | A component library, process note or critique template | `[inferred]` bridge from squad work; `[generic]` that peer-less operation is the likely probe |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer exists as described | positive_signal | — | "six people in Galway making booking software for sea-kayak and surf schools" | Real, small, customer-funded company. Ronan Kehoe is a named co-founder on the About page and in the posting. The limit: the sources I retrieved are Fernquay's own pages and one profile page, with no independent coverage | `[grounded]` About page, careers page and profile page; `[generic]` thin footprints are common at six-person companies | Can you share the names of one or two customer schools I could speak to? | noted |
| RR2 | Posting is concrete and transparent | positive_signal | — | "€52,000–€60,000 plus 0.5–1% equity … Apply with one real project" | Salary, hybrid terms and the application ask are stated, and the careers page matches | `[grounded]` JD and careers page | What does a good first six months look like for this role? | noted |
| RR3 | WhatsApp contact and emailed invite | unknown | — | "I have emailed you a calendar invite with the video link. Just shout here if the time does not suit." | The message asks for a video call only: no money, ID or off-platform interview. Whether the sender is Ronan Kehoe, and whether the invite comes from a Fernquay address, I can't establish from here. Chat scheduling by a small team is common | `[grounded]` message content; `[generic]` small-company scheduling pattern | Can you confirm the invite will come from your Fernquay email address? | unresolved |
| RR4 | Equity terms unstated | unknown | — | "0.5–1% equity" | Type (shares or options), vesting, and the share count the percentage is measured on are missing | `[grounded]` JD silent on terms | Are these options or shares, what is the vesting schedule, and what is the percentage based on? | unresolved |
| RR5 | Decision rights for a first designer | unknown | — | "own the booking flow end to end … work most closely with our co-founder" | You may own the outcome while product decisions sit with Ronan, with no design peer to weigh in | `[inferred]` from the JD's ownership wording against its silence on decision rights | Who has the final say on design decisions between the designer, you and the engineers? | unresolved |
| RR6 | Funding runway for a new hire | unknown | — | "funded by its customers" | A customer-funded company has no investor cushion, so a first design hire depends on revenue continuing | `[grounded]` About page; `[inferred]` dependence on revenue | How is this hire funded, and how far ahead is the budget planned? | unresolved |

## Application plan

Every row below is a proposal. Approve, change or drop each one.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before opening the video link, check the calendar invite came from an address at the domain on Fernquay's careers page (`jobs@fernquay.example`), and reply on the channel you already use if the time needs changing | See RR3 | `[grounded]` careers page address | pending your approval |
| A2 | Lead the call with your own sentences: "redesigned our checkout flow" and "ran monthly usability sessions with customers". Say plainly that you have not been the only designer, and say what you'd put in place first. Add nothing about outcomes, metrics or business-owner research that you haven't told me | See R7, R8, R9 | `[grounded]` your intake text | pending your approval |
| A3 | Ask the verification questions of RR3, RR4, RR5 and RR6 verbatim, and decide your salary minimum before the call | See R2 | `[grounded]` register | pending your approval |
| A4 | Bring one real project in its working state, since the posting says they would rather see "one messy real project than a polished deck" | See R7 | `[grounded]` JD | pending your approval |

No CV edits are proposed in this pass.

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway", which returned "About Fernquay" (fernquay.example/about), and "Fernquay Product Designer Galway careers". Fetched "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer). Moved role reality's organization, posting status and contradictions rows and RR1; the fetch repeated the search snippet and added nothing beyond confirming the page is live |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland first designer startup Galway", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Moved the market calibration row and R2's reasoning. It covers salary only, not scope norms for first designers |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe). Moved role reality's "who you'd work with" row |

I can also write this up as `tuesday-dossier.md` if you'd like to keep it.

**Upgrade menu**
- Your current CV or portfolio link: lets me check presentation gaps and propose edits for approval; a Figma file would raise R4 to `high`.
- Your checkout case study and a before/after view: raises R7 and narrows G1.
- A sanitised discussion guide or research synthesis: raises R5 and R8.
- A process note or component library from past squad work: strengthens the R9 bridge.
- Your minimum base salary: closes R2.
- The sender address on the invite: closes RR3.
- A deeper research pass on Fernquay (funding, hiring patterns, public customer or employee reports, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

**Questions**

R2 — Does €52,000–€60,000 base clear your minimum, and would you trade any base for equity?

G2 — In your monthly usability sessions, who took part (end customers, partners or operators), and which parts did you personally own: recruiting, the guide, running them, synthesis?

G3 — Have you ever carried design responsibility with no other designer to review it, for example covering a colleague or setting up shared Figma conventions for your squad?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.