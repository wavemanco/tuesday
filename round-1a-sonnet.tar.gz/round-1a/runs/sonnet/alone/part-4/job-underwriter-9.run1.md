**Yes, this is normal, and the timing is the reassuring part.** The "never hand those over" rule is right for unsolicited requests, or for anyone asking before you've been hired. Here, you've done two in-person interviews at their office, the offer names your manager, and they ask for these details only after you accept.

**Why each item is standard**
- **Bank details:** they need these to pay you.
- **PPS number:** the employer needs it to register you with Revenue and run your PAYE. You'd also be asking for it if you were the one running payroll.
- **Passport:** employers in Ireland routinely check right to work. Asking you to bring the original on day one is standard.

**What I'd check before using the portal**
- **Don't enter anything via a link in the email.** Once you accept, confirm the portal link with Declan or the People Team by phoning the office. Use a number from their official website or one you got at the interviews. The link should sit on a Marrowgate domain.
- **I haven't verified Marrowgate or that email domain.** I ran no searches. Your interviews at their office are better evidence than anything I'd find online.
- **Walk away if you see any of these:** requests for card details, fees or equipment purchases, or a push to send details by email, WhatsApp or text.

**Ways to limit what you share**
- **Ask whether they can view your original passport on day one** instead of taking a scan beforehand. Many employers accept that. If they need a scan, ask for their data privacy notice and how long they keep it.
- **Ask whether bank details and PPS can wait until nearer your start date.** Your start date depends on your notice period, so there's no rush for payroll.
- **Never send any of it by plain email.**

**Before you resign from your current job**
- **Get the written contract first.** It should cover pay, probation, pension scheme, leave and notice terms. The offer email doesn't include any of these, and in Ireland you're entitled to written core terms.
- **Accept subject to contract if you need to.** You have five working days.

**On the role itself**
- **The match is good.** You have the payroll, reconciliation and Excel experience, plus a current certificate.
- **The gaps are pension changes, 240 staff instead of 90, and monthly instead of fortnightly runs.** Tell Declan plainly that you haven't run pension changes yourself and ask what support you'd get. Don't overstate it.
- **The ad asks for Irish PAYE, PRSI and USC knowledge.** Your CV should show you've used those in your hotel role. I'm assuming you have.

I can do a fuller assessment of the offer if you'd like, covering requirement-by-requirement fit, risks and questions to ask them.