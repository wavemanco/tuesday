I'll read the reference files the skill points to before building the assessment.
**Yes, apply and take the call. As for legit, I can't establish Fernquay from here, and nothing you pasted asks for anything beyond 45 minutes of your time. `conditional_go` (RR1, R2, R8).**

## Decision snapshot

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: R2 (Salary €52,000–€60,000 plus 0.5–1% equity)
- `must_have`: direct: R3, R4, R5a, R6 · adjacent: R7 (Own the booking flow end to end)
- `important`: adjacent: R5b (Run research calls with school owners), R8 (Be the first designer)

R7 (`medium`) — checkout is one part of a booking flow, and how much of it you owned is unconfirmed; R8 — a gap you named yourself, bridged by adjacent work with its limits stated.

**Opportunity ledger.** The register shows an employer I couldn't establish (RR1), equity terms and runway left blank (RR3, RR4), and first-designer support and success measures left undefined (RR2, RR5). On the other side, the message asks only for a call (RR6), and the posting is specific and states its pay (RR7).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000 plus 0.5–1% equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Fernquay verifies as a real, live employer: RR1, plan rows A1 and A2. (2) The pay and the office days work for you: R1, R2. (3) The "first designer" gap is raised and answered on the call: R8, RR2, RR5.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, booking software for sea-kayak and surf schools. Not verified from here | `[grounded]` posting, as pasted |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship alongside two engineers | `[grounded]` posting |
| Closest collaborator | Co-founder Ronan Kehoe, named in the posting and the sender of the WhatsApp message | `[grounded]` posting and message agree |
| Pay | €52,000–€60,000 plus 0.5–1% equity; equity terms not stated | `[grounded]` posting |
| Working pattern | Hybrid: two days a week in the Galway office, otherwise flexible | `[grounded]` posting |
| Scope read | One product surface with a research remit and a direct line to a founder. The "first designer" part is the real stretch for someone who has always had design peers | `[inferred]` from the posting's scope against your background |
| Market calibration | Not run, so no band is given. Pay and title fit against Irish norms are unchecked | `[grounded]` no research ran |
| Process so far | A 45-minute video call with the co-founder and the CTO, invite by email. Nothing is asked of you beyond time | `[grounded]` WhatsApp message |
| Unknowns | Equity terms, funding and runway, success measures, decision rights, whether the invite comes from a company address | `[grounded]` posting and message are silent |
| Contradictions | None between the posting and the message on company or co-founder name | `[grounded]` the two texts as pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week at the Galway office | hard_gate | direct | medium | none | You live in Galway, so the location term is met. You haven't said whether two office days suit you, and the question at R2 covers it | `[grounded]` your statement and the posting | settled by the question at R2 |
| R2 | Salary €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | The posting states the pay. You haven't given a floor, so whether it meets one is unknown. Confidence is `none` because no constraint was stated | `[grounded]` posting figure; no candidate constraint supplied | the question at R2 |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company. Prose self-report, so `medium` with no inspected proof | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" is a specific usage claim, but nothing inspectable has been read | `[grounded]` your background | a link to the case study you sent would let this be read |
| R5a | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. Limit: usability testing is one kind of research, and discovery interviews aren't stated | `[grounded]` your background | none |
| R5b | Research calls with school owners | important | adjacent | medium | transferability | Your sessions were with consumers of a booking product. Calls with small-business owners, who are the buyers here, weren't mentioned | `[grounded]` your background against the posting | G3 |
| R6 | Works directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers. Whether you're happy doing so is your call, but the evidence of doing it is there | `[grounded]` your background | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | discovery | You redesigned a checkout flow at a booking company. That is one stage of a booking journey, and your ownership beyond it is unconfirmed. It sits close to what the role does, and the case study they praised is likely relevant | `[grounded]` your checkout redesign; `[inferred]` that the stages beyond checkout are the open part | G1 |
| R8 | Work as the first and only designer | important | adjacent | medium | transferability | Inferred from "you would be our first designer". You have never been the only designer, so direct experience is absent. Adjacent: you ran the usability sessions and redesigned the checkout flow. Limit: no evidence of making design calls with no design peer to review, direct or share the load | `[grounded]` your statement; `[inferred]` requirement from the posting | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Span of booking-flow ownership (R7, must_have) | discovery | A checkout redesign is confirmed. Nothing says whether you also shaped search, selection, confirmation, or changes and cancellations | R7 is the role's core responsibility, and a wider span moves it toward `direct` | Flow mapping across steps, redesigning a confirmation or rebooking step, deciding what the flow should include and not only how it looked | The checkout case study, a flow map, a usability report | `[grounded]` background gives checkout only; `[inferred]` that the wider span is what "end to end" will be probed on |
| G2 | Designing without design peers (R8, important) | transferability | Strong squad experience with engineers; no stated experience setting direction without a design lead or peer | It is the largest difference between this role and your history, and it decides how to frame the call | Making a design call with no designer to review it, setting up how research or usability sessions run, owning a design decision engineers then built | Any note, decision record or session plan you authored | `[grounded]` your own statement; `[inferred]` from the posting's "first designer" |
| G3 | Research with business owners (R5b, important) | transferability | Usability sessions with customers; no business-owner or buyer interviews mentioned | The posting names school owners as the research audience | Calls with partners, suppliers or B2B accounts; research where the person paying differed from the person using it | A discussion guide or research summary | `[grounded]` background silent on this; no question asked this turn, because of the question budget |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools." | The firm may be too new or small to have much public footprint, or the posting may be stale. This is a standing check and not a finding about Fernquay | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | First designer with no stated support or decision rights | risk_signal | low | "You would be our first designer: own the booking flow end to end" | The role may carry the whole design remit without a peer or a clear say over product decisions. Severity is low because the posting names a working partner | `[inferred]` from the posting's scope language against its silence on authority | Who has the final call on product decisions between the co-founder, the engineers and the designer? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | The instrument, vesting and share count are not given, so the value can't be judged | `[generic]` equity percentages are not interpretable without those terms | What is the instrument, the vesting schedule and cliff, and the fully diluted share count behind 0.5–1%? | unresolved |
| RR4 | Funding and runway unstated | unknown | — | "We are six people in Galway" | A salary for a seventh hire depends on money the posting doesn't describe | `[inferred]` from the posting's silence | How is the company funded, and how many months of runway does the current plan give? | unresolved |
| RR5 | No success measures stated | unknown | — | "own the booking flow end to end" | The mandate is broad and states no outcome | `[inferred]` from the posting's scope against its silence on success | What would success look like for this role at six and twelve months? | unresolved |
| RR6 | Message asks only for a call | positive_signal | — | "Could you do a 45-minute video call with me and Saoirse, our CTO? I have emailed you a calendar invite" | The message asks for time and nothing else: no money, documents, bank or ID details. The channel alone doesn't distinguish a real employer from a fake one; what the message asks does | `[grounded]` the message text; `[generic]` that small teams often schedule over messaging apps | Could you confirm the address the invite was sent from? | noted |
| RR7 | Specific, transparent posting | positive_signal | — | "Salary €52,000–€60,000 plus 0.5–1% equity" | A stated pay range, a named co-founder and a concrete scope are consistent with a real hiring team, and the message matches the posting on names | `[grounded]` posting and message as pasted | Who is Saoirse's counterpart on the design side, if anyone? | noted |

## Application plan

All rows below, the positioning advice in A4 included, are proposals. Nothing is final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, check that the calendar invite came from a company-domain email and that the video link is a standard meeting link tied to it | see RR1, RR6 | `[grounded]` RR1 and RR6 | pending your approval |
| A2 | Look up Fernquay yourself: its own website and careers page with this role listed, the Companies Registration Office register for a registered entity, and public work histories for Ronan Kehoe and Saoirse | see RR1; cheap checks that need no one's reply | `[generic]` a registered Irish company would normally appear on that register | pending your approval |
| A3 | Ask RR1 to RR5 as written on the call. RR3 and RR4 matter most before any offer | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A4 | Lead with the checkout redesign and the monthly usability sessions. Say plainly that you haven't been the only designer, and describe adjacent work only after G2 is confirmed | see R7, R8 | `[grounded]` your own sentences, each traced | pending your approval |
| A5 | If a take-home or "messy real project" is requested, ask about scope, time limit, and whether it is paid or uses their live problem | The posting says they prefer a real project to a polished deck | `[generic]` standard check on unpaid design exercises | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches "Fernquay booking software sea kayak surf schools Galway" and "Fernquay product designer Galway careers" were refused. It would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | Search "product designer salary Ireland 2026 startup mid-level equity" was refused. It would have moved the market calibration line and any pay-mismatch entry |
| 3. Hiring manager's public footprint | unavailable | Search "Ronan Kehoe Fernquay co-founder" was refused. It would have moved the scope read and A4 |

Everything above rests on what you pasted. Nothing about Fernquay itself is established.

I can also write this up as `tuesday-dossier.md` if you want a copy to keep.

## Upgrade menu

- Permission to run web search would run targets 1 to 3: whether Fernquay and this role exist as described, an Irish product-designer pay band for the calibration line, and the two co-founders' public professional histories.
- A link to the live posting or Fernquay's own site, and the sender address of the invite → RR1 and A1.
- A link to the checkout case study → lets R3, R4, R5a and R7 be read, and can raise them toward `high`.
- Your salary floor and any office-days limit → R1 and R2 settle, and the hard-gates line loses its flag.
- A deeper pass on the company (funding, leadership changes, news; up to 5 more searches and 2 more fetches) → RR4 and RR1 firm up. Say the word and it runs.

## Questions

R2 (also settles R1) — Is there a salary floor, or a limit on office days, that would rule this role out for you?

G1 — Beyond checkout, which parts of the booking journey did you personally own or shape, and what did you decide yourself?

G2 — Have you made a design call, or set up how research or testing ran, without a design lead or peer reviewing it? What was it, and what happened?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.