I'll read the skill's reference files first.
Search was denied, so this runs on your text and the two postings only.

## Decision snapshot

### Duinvaart Cold Chain, Operations Analyst

**Yes, this one is worth your time. Apply, with conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: D7 (Hybrid, three days Rotterdam office)
- `must_have`: direct: D1, D2, D3, D4a
- `important`: adjacent: D5 (Depot managers on route changes); unclear: D4b (Temperature compliance)
- `preferred`: adjacent: D6 (Dutch a plus)

D4b: cold-chain compliance isn't evidenced yet. D5: adjacent, its limit named.

**Opportunity ledger.** Concrete weekly deliverables (RR3). The employer is unverified (RR1) and the salary isn't stated (RR2).

- **Hard gates:** none failed; unconfirmed: D7 (Hybrid, three days Rotterdam office); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting and employer verify (RR1); (2) the three-day Rotterdam commute works for you (D7, G3); (3) D4b is bridged honestly, never as cold-chain experience (G1).

### Kroonhaven Foods, Supply Planner

**No, I'd skip this one as written. K2, K3 and K4, three must-haves, are absent. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: unclear: K7 (On-site in Utrecht)
- `must_have`: adjacent: K1 (Fluent Dutch); unclear: K5 (Advanced Excel); absent: K2 (3+ years FMCG planning), K3 (13-week supply plan), K4 (SAP IBP or similar)
- `important`: adjacent: K6 (Running weekly S&OP meeting)

K2, K3 and K4 have no stated evidence and no near bridge. K6 and K1 are bridges with real limits.

**Opportunity ledger.** The employer is unverified (RR4) and the salary isn't stated (RR5).

- **Hard gates:** none failed; unconfirmed: K7 (On-site in Utrecht); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **What would have to be different:** a record of supply or demand planning you haven't mentioned (G4), plus fluent Dutch.

## Role reality

| Job | Element | What it is | Provenance |
|---|---|---|---|
| Duinvaart | Organization | Duinvaart Cold Chain, Rotterdam, with a refrigerated fleet. Existence not established | `[grounded]` JD header; research unavailable |
| Duinvaart | Mandate | Track on-time delivery and temperature compliance, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` JD |
| Duinvaart | Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` JD |
| Duinvaart | Scope read | An individual-contributor analyst post with no stated seniority or reports | `[inferred]` from the JD naming duties and no line management |
| Duinvaart | Market calibration | Not established; the role-family sweep was unavailable | `[generic]` fallback: none stated |
| Duinvaart | Unknowns | Salary; who the depot managers report to; whether route changes are this role's decision or a recommendation | `[grounded]` JD silent |
| Kroonhaven | Organization | Kroonhaven Foods, Utrecht, chilled ready meals. Existence not established | `[grounded]` JD header; research unavailable |
| Kroonhaven | Mandate | Own the 13-week supply plan, balance capacity against forecast, run weekly S&OP | `[grounded]` JD |
| Kroonhaven | Working pattern | On-site in Utrecht | `[grounded]` JD |
| Kroonhaven | Scope read | The post owns the plan and chairs the meeting, so it is an ownership role rather than a support role | `[inferred]` from "Own" and "run" in the JD |
| Kroonhaven | Market calibration | Not established; the role-family sweep was unavailable | `[generic]` fallback: none stated |
| Kroonhaven | Unknowns | Salary; the size of the planning team; whether S&OP runs in Dutch | `[grounded]` JD silent |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| D1 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | You stated 4 years as an operations analyst at a parcel carrier. It is your own statement with no artifact read yet, so `medium` | `[grounded]` your background | none |
| D2 | Strong SQL | must_have | direct | medium | none | SQL daily in that role, by your account | `[grounded]` your background | none |
| D3 | Power BI or Tableau | must_have | direct | medium | none | Power BI daily, including the on-time delivery dashboard depot managers use. Whether you built it or maintained it is not stated | `[grounded]` your background | confirm your role in the dashboard |
| D4a | Track on-time delivery (responsibility) | must_have | direct | medium | none | The dashboard and the weekly route-performance review are on-time delivery work | `[grounded]` your background | none |
| D4b | Track temperature compliance across a refrigerated fleet | important | unclear | low | discovery | Nothing stated about temperature-controlled or compliance-threshold work. It may exist and be unmentioned | `[grounded]` background silent | see G1 |
| D5 | Work with depot managers on route changes | important | adjacent | medium | transferability | You ran the weekly route-performance review and depot managers use your dashboard. Limit: nothing stated about proposing or making route changes | `[grounded]` your background; `[inferred]` the limit | see G2 |
| D6 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational Dutch, not fluent. It is a plus in the JD, not a requirement | `[grounded]` your background and JD | none |
| D7 | Hybrid, three days a week in Rotterdam | hard_gate | unclear | low | hard_gate | You gave no constraints. You worked in Amsterdam; your current location and acceptable commute are unknown | `[grounded]` no constraints given | see G3 |
| K1 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational Dutch, below the stated level. Limit: fluency is the requirement and conversational is not | `[grounded]` your background and JD | none; the level can't be bridged by wording |
| K2 | 3+ years of supply or demand planning in FMCG | must_have | absent | none | capability | You said you have never worked in planning, and a parcel carrier is not FMCG | `[grounded]` your statement | see G4 |
| K3 | Own the 13-week supply plan, capacity against forecast | must_have | absent | none | capability | No planning ownership stated | `[grounded]` your statement | see G4 |
| K4 | SAP IBP or a similar planning system | must_have | absent | none | capability | You named SQL and Power BI, and no planning system | `[grounded]` background silent | see G4 |
| K5 | Advanced Excel | must_have | unclear | low | discovery | Excel isn't mentioned. Daily SQL and Power BI use makes it plausible but is not evidence of advanced Excel | `[grounded]` background silent | see G6 |
| K6 | Run the weekly S&OP meeting | important | adjacent | medium | transferability | You ran a weekly route-performance review. Limit: it was an operational review, and S&OP typically reconciles supply, demand and finance | `[grounded]` your background; `[generic]` what S&OP involves | none |
| K7 | On-site in Utrecht | hard_gate | unclear | low | hard_gate | No constraints given | `[grounded]` no constraints given | see G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Temperature compliance (D4b, important) | discovery | Nothing on temperature-sensitive freight or compliance reporting | It is half of the posting's first named duty, so an interviewer will probe it | Chilled, pharma or food parcels; threshold or SLA pass/fail reporting; exception reports for out-of-spec or late deliveries | A sanitized KPI screenshot or report | `[grounded]` CV silence; `[generic]` that interviewers probe a named duty |
| G2 | Route changes with depot managers (D5, important) | transferability | A weekly review and a dashboard depot managers use, and no stated route changes | It separates "reports on routes" from "works with depot managers on route changes" | A depot or route adjustment you proposed from review data; a depot manager acting on a finding of yours | A sanitized review deck or email thread | `[grounded]` your background; `[inferred]` the limit |
| G3 | Location and commute (D7 and K7, hard_gate) | hard_gate | No constraints given | It decides whether either role is workable regardless of fit | Where you live and what commute, pay floor or other non-negotiables apply | Nothing to attach | `[grounded]` no constraints given |
| G4 | Planning experience (K2, K3 and K4, must_have) | capability | No credible direct or adjacent evidence after your own account. I won't bridge it with wording. Closure paths: a scoped-down target role, or a planning course and system training. Otherwise carry it as a material risk | Three absent must-haves is why the status is `no_go` | Only if you've done forecasting or capacity balancing you haven't mentioned | A forecast model or capacity plan you owned | `[grounded]` your statement; `[generic]` the closure paths |
| G6 | Advanced Excel (K5, must_have) | discovery | Silent | Only matters if Kroonhaven is reconsidered | Pivot-heavy or model-building work in Excel | A sanitized workbook | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Duinvaart not established | risk_signal | low | "Duinvaart Cold Chain, Rotterdam" | Most likely the search was not run. Nothing suggests a problem, so severity stays low | `[generic]` pattern, not a claim about this firm | Can you point me at the role on your own careers site, and who I'd interview with? | unresolved |
| RR2 | Duinvaart salary unstated | unknown | — | (no salary stated) | The figure may sit anywhere in the market band, or the firm may not publish salaries | `[inferred]` from the posting's silence | What salary range is budgeted for this post? | unresolved |
| RR3 | Concrete weekly deliverables and named tools | positive_signal | — | "build weekly dashboards in Power BI" | The role is genuinely defined, and the work matches what you do | `[grounded]` JD | Which depots does the first dashboard cover? | noted |
| RR4 | Kroonhaven not established | risk_signal | low | "Kroonhaven Foods, Utrecht" | Same as RR1 | `[generic]` pattern, not a claim about this firm | Can you point me at the role on your own careers site? | unresolved |
| RR5 | Kroonhaven salary unstated | unknown | — | (no salary stated) | Same as RR2 | `[inferred]` from the posting's silence | What salary range is budgeted for this post? | unresolved |

## Application plan

**Proposed edit: `resume_edits_pending_approval`**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Add a bullet: "Worked daily in SQL and Power BI, including the on-time delivery dashboard used by depot managers" | D3, D4a | `[grounded]` your words, traced clause by clause | pending your approval |
| E2 | Add a bullet: "Ran the weekly route-performance review" | D5 | `[grounded]` your words | pending your approval |
| E3 | Add the line "Dutch: conversational" | D6 | `[grounded]` your words | pending your approval |

**Other proposed actions**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check Duinvaart's own careers page for the live posting before applying | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Lead with the dashboard and the weekly review, since they match the posting's two named tasks | D3, D4a, D5 | `[inferred]` from the map | pending your approval |
| A3 | Put RR2's salary question to the recruiter early | RR2 | `[grounded]` RR2 | pending your approval |
| A4 | Don't apply to Kroonhaven. Spend the time on analyst roles in your current lane | G4 | `[inferred]` from the K2, K3 and K4 rows | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches refused: "Duinvaart Cold Chain Rotterdam refrigerated transport" and "Kroonhaven Foods Utrecht chilled ready meals". Would have moved the organization rows and RR1 and RR4 |
| 2. Role-family sweep | unavailable | Searches refused: "operations analyst logistics Rotterdam salary Netherlands" and "supply planner FMCG Netherlands salary SAP IBP Dutch required". Would have moved the market calibration rows and RR2 and RR5 |
| 3. Hiring manager's public footprint | n/a | No name was given |

I'll offer a `tuesday-dossier.md` of this assessment if you want to keep or build on it.

## Upgrade menu

- The links to each posting on the company's own careers page: I can read them as documents and may close RR1 and RR4.
- Permission for web search: it would run targets 1 and 2, which would fill the market calibration rows and close or confirm RR1 and RR4.
- Your answer to G1 and a sanitized compliance-style report: D4b moves toward `adjacent` or `direct`.
- Your answer to G2: D5 firms up.
- Your answer to G3: D7 and K7 close.
- A hiring manager's name for Duinvaart: it feeds the scope read and which story to lead with.

G1 — Have you tracked any temperature-sensitive or compliance-threshold deliveries, such as chilled or pharma parcels, or pass/fail SLA reporting, and what did you own?
G2 — Did your route-performance review lead to route or depot changes you proposed or made, and who decided?
G3 — What are your non-negotiables for a role: commute, pay floor, anything else?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.