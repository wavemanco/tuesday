**Yes, this is normal, and the offer reads as legitimate.** Your caution is still right, because the risk is in who asks, when, and where you send the data.

**Why each item is standard**
- **Bank details:** They can't pay you without them. Giving them is safe as long as it's only account name, IBAN and BIC. Never share online banking logins, card numbers, PINs or codes.
- **PPS number:** Employers need it to register you with Revenue and operate PAYE, PRSI and USC correctly. You'd be asking the same of your own staff.
- **Passport:** Employers routinely check identity and right to work, and a scan plus seeing the original on day one is a common way to do it.

**Why this looks genuine**
- They asked after the offer and acceptance, not at application stage.
- You had two in-person interviews at their office.
- The offer names a real reporting line and matches the ad on pay band, hybrid arrangement and duties.
- Nothing asks you to pay anything, move money or buy equipment.

**What would make me worried (none of it is here)**
- Requests before you've interviewed or been offered.
- Details requested over WhatsApp, a personal email address or a text message.
- Fees for "equipment", "training" or "background checks".
- A sudden change in who is contacting you, or pressure to send things today.

**Do these before you upload anything**
1. **Check the link.** Phishing copies real job offers, and the portal link arrives by email. Make sure it sits on Marrowgate's own domain. If you're unsure, ring the office or Declan on a number from their official website, not from the email, and ask them to confirm the portal and the sender address.
2. **Get the contract first.** The email gives pay, role and location but no probation period, notice terms, pension, leave or hours. Ask for the written contract or terms of employment before you accept and before you resign from your current job.
3. **Ask how they handle your data.** A housing association should have an employee privacy notice covering how long the passport scan is kept and who can see it. It's reasonable to ask for it. They hold a lot of staff data, so their security matters.
4. **Keep records.** Note when you uploaded and to what, and keep a copy of the offer email.

**On the job itself**
- €40,000 is inside the advertised band.
- You meet most of the requirements: payroll experience, the ledger reconciliation, Excel and a recent qualification.
- Two points differ from your current role: 240 staff versus 90, and monthly versus fortnightly runs. You also haven't done pension changes yourself.
- Say the pension gap openly and ask what training or handover they'll give. Declan, as your manager, will probably expect it to be a short ramp-up rather than a blocker.

I haven't been able to check Marrowgate's website or the sender domain myself. Everything above rests on the text you pasted. If you want, I can do a fuller review of the role and its risks next, but I don't think you need one to settle this question.