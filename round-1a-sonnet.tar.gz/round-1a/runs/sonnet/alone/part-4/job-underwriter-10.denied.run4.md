**Yes, take the call. Status: `conditional_go`.** You already applied, so the live question is whether to go forward with them. Fit is solid (R1, R3, R4, R5a and R7 `direct`; R5b, R6 and R8 are stretches). I can't establish Fernquay as a real, hiring company from here, and R2 (pay against your floor) is unconfirmed. Nothing in the WhatsApp asks for money, documents or personal details.

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Pay €52,000–€60,000 plus equity)
- `must_have` — direct: R3, R4, R5a · adjacent: R5b (research calls with school owners), R6 (own the booking flow end to end)
- `important` — direct: R7 · adjacent: R8 (first designer, no design peers)

R5b and R6 — credible bridges, limits named; R8 — the real stretch; R2 — waiting on your floor.

**Opportunity ledger.** The posting is specific about scope and states its pay (RR5). The employer is not established from here (RR1), the way the invite reached you is unresolved (RR2), and the equity and funding terms are unstated (RR3, RR4).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Pay €52,000–€60,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the company verifies independently before you invest further — RR1, RR2; (2) the pay and equity terms meet your floor — R2, RR3; (3) your sole-designer stretch is framed honestly, never as prior experience of working alone — R8.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, booking software for sea-kayak and surf schools. The posting's own description, not confirmed as a real entity (RR1) | `[grounded]` posting text as pasted |
| Role | Product Designer, first designer. Owns the booking flow, runs research calls with school owners, ships with two engineers, works most closely with co-founder Ronan Kehoe | `[grounded]` posting |
| Terms | €52,000–€60,000 plus 0.5–1% equity; hybrid, two days a week in the Galway office | `[grounded]` posting |
| First-year outcomes | Not stated; no success measures given | `[grounded]` posting is silent |
| Scope read | Design, research and flow ownership sit in one seat, with two engineers as the only named teammates. Decision rights against the co-founder are not stated | `[inferred]` from the responsibilities list against the posting's silence on authority |
| Market calibration | Not established. The role-family sweep did not run, so no market band is offered for this title and pay. €52,000–€60,000 is the posting's figure only | `[grounded]` posting figure; research did not run |
| Unknowns | Contract type, funding and runway, equity terms, who set the current design, how decisions split with the co-founder | `[grounded]` posting silent on each |
| Contradictions | None between the posting and the message: Ronan appears in both, and the CTO Saoirse appears only in the message | `[grounded]` the two texts you pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week at the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year, so the location term is met. You haven't said two office days suit you, so this is `medium` | `[grounded]` your background and the posting | Confirm the schedule on the call |
| R2 | Pay €52,000–€60,000 plus 0.5–1% equity, against your floor | hard_gate | unclear | none | hard_gate | No floor stated, so there is nothing to compare the posted band against. No market band was checked either | `[grounded]` posting figure, no constraint given | G1 |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company. Titled years are graded as experience, not as a gate. Self-reported, so `medium` | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" is a self-report. The checkout case study Ronan praised is a design artifact, but I haven't seen it, so I can't read depth of skill from it | `[grounded]` your background | Share the case study or a Figma file |
| R5a | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. Limit: this is usability testing | `[grounded]` your background | none |
| R5b | Research calls with school owners | must_have | adjacent | medium | transferability | Usability sessions carry over to talking with users. The limit: the posting's calls are with business owners (the schools), and you haven't said you've done discovery interviews with business customers | `[grounded]` your background; `[inferred]` that owners are business customers from the posting | G3 |
| R6 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned your company's checkout flow, which is one stage of a booking journey. Whether you owned the stages before and after it isn't stated | `[grounded]` your background | G2 |
| R7 | Work directly with engineers | important | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your background | none |
| R8 | Be the first and only designer | important | adjacent | medium | transferability | Requirement derived from "You would be our first designer". Bridge: you ran your own research sessions and redesigned checkout. Limit: you've never been the only designer, so setting up process and standards without design peers is untested | `[inferred]` from the posting's "first designer"; `[grounded]` your statement that you've never been the only designer | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay floor against the posted band (R2, hard_gate) | hard_gate | Posted band and equity given; your floor unknown | A pay gate you fail would make this `no_go` whatever the fit | A term you meet or don't, not experience | Your own stated floor | `[grounded]` no constraint given |
| G2 | Ownership beyond checkout (R6, must_have) | transferability | Checkout redesign confirmed; the flow before and after it isn't described | The role is "end to end", so the limit of your ownership is the likeliest probe | Owning search or availability, confirmation, cancellations or amendments, or post-booking emails; designing for the operator side of a booking tool | Your case study, a flow diagram, a before/after result you may share | `[inferred]` from checkout being one stage; `[generic]` that "end to end" invites this probe |
| G3 | Research with business owners (R5b, must_have) | transferability | Customer usability sessions; no business-owner discovery stated | The posting centres on calls with school owners | Interviewing partner suppliers or operators, B2B discovery, or turning support calls into design input | A sanitized research plan or synthesis | `[grounded]` your background silent on it |
| G4 | Sole-designer work (R8, important) | transferability | Always worked with other designers | Bridges the stretch, and the posting invites "one messy real project" | A side project, freelance job, or stretch covering for a missing designer, where you set the process | A real, permitted, sanitized project | `[grounded]` your statement; `[inferred]` that it matters most here |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools." | A six-person company may have a thin public footprint, the posting may be stale, or the entity may not be what it describes. Most small companies are simply small | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own site, and tell me what stage the company is at? | unresolved |
| RR2 | Contact by WhatsApp, invite by email | unknown | — | "I have emailed you a calendar invite with the video link." | The chat message only schedules a video call, and the invite arrives by email. Whether it comes from a Fernquay domain is not something I can see | `[grounded]` the message; `[generic]` that small teams often schedule by chat | Could you send the invite from your Fernquay address so I can match it to your site? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | Percentage given without vesting, strike price, or share class | `[grounded]` posting silent on terms | What vesting and strike terms attach to the equity, and what share class? | unresolved |
| RR4 | Funding and runway unstated | unknown | — | "We are six people in Galway" | A first design hire with equity is a bet on the company, and its funding is unknown | `[inferred]` from first hire plus equity against the posting's silence | How is the company funded, and how long is the runway? | unresolved |
| RR5 | Posting is specific on scope, pay and working pattern | positive_signal | — | "Salary €52,000–€60,000 plus 0.5–1% equity. Hybrid: two days a week at our Galway office" | Pay and working pattern are stated, not withheld. The message asks only for a 45-minute video call, with no payment, ID or bank details | `[grounded]` posting and message | Who will I be interviewing with besides Ronan and Saoirse? | noted |

## Application plan

Both blocks below are proposed, each `pending your approval`.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, look for Fernquay's own website and check the invite's sender domain against it. Use contact details you find independently, not only the chat | see RR1, RR2 | `[grounded]` register | pending your approval |
| A2 | Lead with the checkout redesign and the monthly usability sessions, in your own words. Call the checkout work "redesigned our checkout flow", not the whole booking journey, and the research "usability sessions with customers" | see R5b, R6 | `[grounded]` your background | pending your approval |
| A3 | Offer one real project in the spirit of "one messy real project", only if your employer permits sharing it | see R8 | `[grounded]` posting | pending your approval |
| A4 | On the call, ask the register questions verbatim: RR1 (stage and live posting), RR3, RR4, and who decides what with the co-founder | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were refused (permission not granted): "Fernquay booking software sea kayak surf schools Galway" and "Fernquay product designer job Galway". It would have moved role reality's organization row and RR1 |
| 2. Role-family sweep | unavailable | One search was refused: "product designer salary Ireland startup first designer 3+ years Galway". It would have moved the market calibration row and R2 |
| 3. Hiring manager's public footprint | unavailable | One search was refused: "Ronan Kehoe Fernquay co-founder". It would have moved the scope read and A2's choice of story |

I'd rather offer a dossier file (`tuesday-dossier.md`) than assume one: want one when this settles?

## Upgrade menu

- Your salary floor → R2 and G1 close, which decides the pay gate.
- The case study Ronan praised, or a Figma file → R4 and R6 can reach `high`, since a design portfolio piece is the inspectable artifact here.
- Search permission → targets 1–3 run, which would test RR1, calibrate pay, and read Ronan's public professional footprint. The Fernquay site link, a link to the live posting, or the invite's sender domain would settle RR1 too.
- Deeper diligence on funding, leadership churn and recent news (up to 5 more searches and 2 more fetches) → RR3 and RR4 sharpen. Say the word and it runs.
- Ronan's answers on contract type, equity terms and funding → RR3 and RR4 close.

G1 — What's your salary floor, and does €52,000–€60,000 plus the equity clear it?
G2 — In your checkout redesign, which parts of the booking journey did you own before and after checkout, and what changed?
G4 — Have you ever been the only designer on anything (side project, freelance, covering a gap), and what did you set up yourself?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.