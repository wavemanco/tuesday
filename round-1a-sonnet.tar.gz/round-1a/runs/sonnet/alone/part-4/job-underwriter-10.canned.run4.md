I'll read the skill's reference files first.
Reading is done; now I'm running the company, salary and founder searches, then I'll write the assessment.
**Yes, take the call. Nothing I could check says Fernquay isn't real, and the posting matches their own site (`conditional_go`).**

## Decision snapshot

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: R2 (Pay €52–60k vs your floor)
- `must_have`: direct: R3, R4, R5, R7 · adjacent: R8 (Own the booking flow end to end)
- `important`: adjacent: R6 (Research calls with school owners) · absent: R9 (First designer, no design lead)

R8: your checkout redesign is part of a booking flow, not all of it. R9: never having been the only designer is your main fit risk.

**Opportunity ledger.** The company is established and its posting is consistent (RR5). Pay is posted and sits in the market band (RR3). Open items are the first-contact channel (RR1), what "first designer" means in practice (RR2), and the equity terms (RR4).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Pay €52–60k vs your floor); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the invite comes from a Fernquay address (RR1); (2) the salary clears your floor (R2); (3) you find out how much support a first designer gets (R9, RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway. Founded 2023 by Ronan Kehoe and Saoirse Doyle, funded by its customers. Makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland | `[grounded]` About page |
| Mandate | First design hire. Own the booking flow, run research calls with school owners, ship with two engineers | `[grounded]` posting |
| Pay and terms | €52,000–€60,000 plus 0.5–1% equity. Hybrid, two days a week in Galway. Same on the careers page, which asks for one real project by email | `[grounded]` careers page and posting |
| Working with | Ronan Kehoe is co-founder and CEO, and was a product lead at a Galway travel-software company for five years. Your travel-booking background is close to his | `[grounded]` LinkedIn result |
| Scope read | Research, design and shipping in one seat, with no design lead above you. Normal for a first designer at this size, and wide | `[inferred]` from "first designer" plus "end to end" |
| Market calibration | Product designers with 3–5 years in Ireland: median base €57,000, interquartile range €51,500–€62,000. The posted range sits inside that. This is the market, not a promise about this employer | `[generic]` Tillerby 2026 report (n=520); `[grounded]` posting figure |
| Unknowns | Equity terms; company finances; what the designer decides alone; whether the WhatsApp number and invite tie to Fernquay | — |
| Contradictions | None between the posting and the careers page | `[grounded]` both pages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in the Galway office | hard_gate | direct | medium | none | You said you moved back to Galway last year. Your willingness for set office days is not stated | `[grounded]` your statement | confirm office days are fine |
| R2 | Salary €52,000–€60,000 against your floor | hard_gate | unclear | low | hard_gate | The posting states the pay. You haven't given a floor, so I can't say whether it clears | `[grounded]` posting; floor not given | question R2 |
| R3 | 3+ years of product design | must_have | direct | medium | none | You have 4 years at a Dublin travel-booking company. I haven't inspected anything beyond your description | `[grounded]` your statement | none |
| R4 | Strong Figma | must_have | direct | medium | none | You use Figma daily. I haven't seen the files | `[grounded]` your statement | none |
| R5 | Has run own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. Whether you planned and synthesised them yourself is not stated | `[grounded]` your statement | be ready to say what you personally ran |
| R6 | Research calls with school owners | important | adjacent | medium | transferability | Usability sessions with customers carry over. Interviewing business owners was not mentioned, and that is a different kind of research | `[grounded]` your statement; `[inferred]` the limit | see G2 |
| R7 | Works directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your statement | none |
| R8 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned the checkout. Search, selection and post-booking were not mentioned | `[grounded]` your statement; `[inferred]` the limit | see G3 |
| R9 | First designer, no design lead | important | absent | low | discovery | You've never been the only designer. Self-directed work may still exist in your history | `[grounded]` your statement | question G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | First designer (R9, important) | discovery | You've always had a design team around you. Nothing says whether you set your own process or priorities | This is the likeliest probe on the call, because the whole role is solo | Choosing what to research without being told; deciding priorities with engineers or a PM; making design calls with no reviewer | A case study or note showing a decision you made alone | `[grounded]` your statement; `[generic]` that first-designer interviews probe this |
| G2 | Research with school owners (R6, important) | transferability | Customer usability sessions. Not shown: interviews with business owners about how they run things | Owners are the research audience here | Calls with customers who run businesses; any discovery interview, not just usability testing | A discussion guide or a sanitised synthesis | `[inferred]` bridge from your sessions; limit named so you don't present them as the same work |
| G3 | End-to-end booking flow (R8, must_have) | transferability | You redesigned checkout. Whether you also touched earlier or later steps is unknown | "End to end" is the role's headline | Search or availability screens; confirmation and change flows; booking-related emails | The checkout case study, or other flow screens | `[grounded]` your statement; `[inferred]` the limit |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | First contact by WhatsApp, invite by email | unknown | — | "I have emailed you a calendar invite with the video link." | A six-person firm may simply message informally. I can't tie the number or invite to Fernquay from here. Scheduling by chat for a video call is not itself a warning sign | `[generic]` small firms often use chat; `[grounded]` the message | Could you send the invite from your Fernquay address so I can match it to your careers page? | unresolved |
| RR2 | First designer, scope wide, no stated support | risk_signal | low | "own the booking flow end to end, run research calls with school owners, and ship alongside our two engineers" | You may get no design mentorship and a heavy remit. Ronan's product background may help | `[inferred]` from the posting; `[generic]` pattern for first-design hires | What does the designer decide alone, and what goes to you or Saoirse? | unresolved |
| RR3 | Salary posted and in band | positive_signal | — | "Salary €52,000–€60,000" | The pay is transparent and inside the market range | `[grounded]` posting; `[generic]` band | Is the range fixed, or does it move with experience? | noted |
| RR4 | Equity and finances unstated | unknown | — | "plus 0.5–1% equity" | "Funded by its customers" means no outside investor. Stability and what the equity is worth are unknown | `[grounded]` About page and posting; value is `[inferred]` | Percent of what, on what vesting schedule, and how long is the runway? | unresolved |
| RR5 | Employer exists as described | positive_signal | — | "six people in Galway making booking software for sea-kayak and surf schools" | Company, size, product, location, pay and role are consistent across sources | `[grounded]` About page, careers page | Who else will I meet beyond you and Saoirse? | noted |

Neither the posting nor the message asks you for money, a deposit, or ID details. That is why I'm not flagging RR1 higher.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, check the invite's sender domain matches the careers page | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Open with the checkout redesign and the monthly usability sessions, saying what you personally did in each | Ronan said he liked the checkout case study. See R5, R8 | `[grounded]` your statements; `[inferred]` that his product background means he'll probe it | pending your approval |
| A3 | Say it plainly: "I've worked in a squad with four engineers and haven't been the only designer" | A candid line beats being found out. See R9. This is your own sentence | `[grounded]` your statement | pending your approval |
| A4 | Ask the RR2 and RR4 questions verbatim | The register is your question list | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway" and "Fernquay careers Product Designer Galway". Results: "About Fernquay" (fernquay.example/about) and "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer). I read the result snippets, not full pages. Moved the organization row, the contradictions row, RR5 |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland 3+ years startup equity". Result: "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Moved the market calibration row and RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder". Result: "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe). Moved the "Working with" row and A2 |

I only found Ronan's role from the result snippet. I found nothing confirming Saoirse's title is CTO.

I can write up this assessment as a `tuesday-dossier.md` if you want to keep it.

## Upgrade menu

- Your pay floor: closes R2 and settles the hard-gate line.
- The checkout case study you sent, or any flow screens: could lift R3, R4, R5 and R8 toward `high`. A design portfolio is the inspectable proof for this field.
- A discussion guide or synthesis from any research with business owners: strengthens R6.
- The invite's sender address: closes RR1.
- A deeper pass on Fernquay (customer reviews, leadership and funding history; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

R2 — What is the lowest base salary you would accept for this role?

G1 — Have you ever set your own priorities or research plan without a design lead or PM telling you what to work on? What did you decide, and what happened?

G3 — Besides checkout, did you work on any other step of a booking flow at your Dublin company, such as search, availability or post-booking?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.