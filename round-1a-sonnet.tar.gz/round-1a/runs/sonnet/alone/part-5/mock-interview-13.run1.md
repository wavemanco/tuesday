I'll read the reference files the skill points to before building the pack.
Your pack is saved. I'm checking the file for stray formatting before I present it.
Your prep pack is saved as `quillmoor-diagnostics_operations-coordinator_interview_pack.md`. I built it for the recruiter screen with Hannah, from the advert, her message and your notes. There is no CV in the pack, so every quote about your past comes from your message.

Web search was refused, so I couldn't look up the company's values, interview process or news, or anything about Hannah. All company facts in the pack come from the advert only, and the interviewer section rests on her own message. Read Quillmoor's own site before Thursday.

- **Her four topics:** pay, notice, hybrid and why you're moving are rows A2 to A5, in her order. You're asked for £42,000, which is inside the £38,000 to £44,000 band, and the Reading story is rehearsed in your own words.
- **Biggest prep:** B2 is the one to rehearse most. It's about production scheduling across planning, the warehouse and QA. Your material says you schedule deliveries for three depots, not production schedules, so the pack coaches you to hold exactly that and say plainly what wasn't yours.
- **SAP:** you said you've never used it. The advert lists it as a plus, so B3 and D1 give you a plain "I've never used SAP" and then what your in-house system does, in your own words.
- **Not coached:** the pack lists wording to avoid because your quotes don't support it. Examples are "made redundant" (you have an offer to relocate), "£42,000 is my minimum" (you said "hoping for") and "caused the one-third drop" (you said you rebuilt the spreadsheet and discrepancies fell).

Say the word and I'll play Hannah on B2 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

What is your notice period? Your material doesn't say, and your answer fills the notice question A3.
Can you paste your CV? It would replace the quotes from your message in rows F1 to F8 with CV lines.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor-diagnostics_operations-coordinator_interview_pack.md -----
# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

- **Role:** Operations Coordinator, Quillmoor Diagnostics
- **Interviewer:** Hannah Lowther, Talent Partner. Recruiter screen, a 30-minute phone call on Thursday at 2pm, from her LinkedIn message
- **Built from:** the advert, Hannah's message and your own notes, all as you pasted them. There is no CV in hand, so every quote about your past comes from your message

## How to use this pack

Personas are how a question is asked; types are what it scores. Guidance is scaffolding for your own words, not a script. Where it says answer slot, it is an instruction for the interview: answer from what you actually did, and where the practice was not yours or did not exist, say so plainly.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether what you say about your past survives follow-up, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | How well you know the company and why you chose it |
| CASE | How you structure a live problem from the role |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | none | No gap, but a line from your message with nothing inspected behind it. Lead with it in its own terms: four years as a logistics coordinator at a building-supplies wholesaler |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material says delivery scheduling for three depots, not production schedules, and the words stay there: "I schedule deliveries for our three depots." Answer slot: the advert's production-schedule line makes a probe on who you coordinated with likely. If any of your scheduling involved production or teams like planning or QA, say which and what was yours, in your own words; if it did not, say so plainly and stay with the depots |
| F3 | "track supplier deliveries and chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | The quote reaches the requirement in near-identical terms. Use its own words: you chase suppliers when orders slip. Expect a request for a specific example |
| F4 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | The quote reaches the requirement. Say it as the sentence has it: you rebuilt the stock-count spreadsheet, and discrepancies fell by about a third over a year. A figure raises the defend-the-number slots in C1 and D2 |
| F5 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material does not show whether you report on dispatch or delivery performance. Answer slot: the advert's weekly-reporting line makes a probe likely. If you report on it today, say what, to whom and how often; if you do not, say so plainly and stay with the scheduling and chasing |
| F6 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | The quote says spreadsheet and does not name the tool. Answer slot: if the spreadsheet was in Excel, say so and say in your own words what you did in it and how confident you are; if it was another tool, say so plainly |
| F7 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system." — your message | none | [grounded] | capability | A gap you stated, and the advert marks the line a plus. Words: "I've never used SAP." Then how you would learn a new system, said as a plan and never as a past |
| F8 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system." — your message | low | [inferred] | discovery | The advert says "or similar", and your material does not show what you do in the in-house system, only that your company runs it. Answer slot: if you work in it, say what you do in it, in your own words; if you do not, say so plainly and stay with the fact that the company runs it |
| F9 | "£38,000–£44,000" — advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | Your figure sits inside the advertised range. Say it at its own scope, as hoping for that figure |
| F10 | "your notice period" — Hannah's message | none given | none | [grounded] | hard_gate | Your material does not establish your notice period, and it is a term she has said she will ask about |
| F11 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | The advert's pattern is met by your own statement. Keep "wouldn't want more than three" as the preference it is |
| F12 | "what's prompting a move" — Hannah's message | "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | medium | [grounded] | none | Give it in the quote's own terms: the office is closing next year, the only offer is relocating to Reading, and you don't want that. It says nothing yet about why this role, which B4 rehearses |

## Reading the interviewer

Built only from what Hannah wrote. Her public footprint is not established.

| What her message says | Implication for the call |
|---|---|
| "salary expectations, your notice period, how the hybrid pattern would work for you and what's prompting a move" | Four logistics topics, in that order. A2 to A5 follow her order, and each is scored even in a friendly register |
| "a 30-minute phone call with me. I'll ring the mobile number on your application" | She calls you, so be reachable on that number at 2pm |
| "then I'll tell you about the team and the next steps" | Your questions fit after her description, so choose from the reverse questions the call has not already answered |
| "If anything changes, message me here." | LinkedIn is the channel for any change to the booking |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly logistics and motivation questions, as in her own list | Top weight. Her message names pay, notice, hybrid and the reason for the move, which are the recruiter-screen logistics | Give your own answer to each of the four, in your own words, and treat the casual register as scored |
| Skeptic | Quiet probing of what is new to you: production scheduling, SAP, why this role | Raised above the recruiter-screen prior. F2 and F7 are visible gaps in the advert-to-material match, and F8 and F5 are open | Rehearse B2 until it is boring: hold only what the quotes carry and name the limit before it is asked |
| Data-Driven Prober | Asks how the stock-count result was counted and what you report today | Mid. You have one figure and one tool-shaped line, and a screen can still ask about them | Know what you can and cannot say about how the figure was counted, and say plainly when you do not know |
| Pressure | Time-boxes you on why you rather than someone with SAP | Low for a recruiter call | Pause, restate, hold on the quotes, concede the specific limit |
| Case / Strategist | Live problem from the advert's duties | Low on this call. Kept so the style is not met first live | Clarify, structure, think aloud. The questions need no claim about your past |
| Peer Evaluator | Collaboration and credit-sharing across teams | Low on this call | Describe what you did and what others did, and propose principles rather than pretending to know their seam |
| Values / Behavioral | Not banked | No published values source is in hand and no values round is documented, so no bank is built | Not applicable until a values source exists |

## Question banks

The highest-ROI prep in this pack is **B2**: it is aimed at the widest gap between the advert's first duty and your material, and it will be asked in some form.

### A. Conversational (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey. What do you do now, and what's brought you to this role?" | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | A short arc built only from clauses those sentences state: four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots and chasing suppliers when orders slip; rebuilding the stock-count spreadsheet, with discrepancies down by about a third over a year; then the reason, in A5's words. Tell it in your own words, add no beat the quotes do not carry, and stop so she can steer | The biography opener is scored even when it sounds casual. F1, F3, F4 and F12 supply the beats |
| A2 | "What salary are you looking for?" | JD | [grounded] "I'm hoping for £42,000." | Logistics slot, filled by your own figure at its own scope: "I'm hoping for £42,000." If you would rather hear her view first, ask where in the advertised range they expect to land. Give the figure and stop | It is the first item on her list, and F9 holds your figure. JD because pay is a term of the listed job |
| A3 | "What's your notice period?" | JD | [grounded] | Logistics slot: give your actual notice period, as your contract states it. If there is any flexibility, say so in your own words; if you do not know, say so plainly and say you will confirm it | F10 is a gate row the material does not establish, and it is on her list. JD because it is a term of the job's start |
| A4 | "How would two days a week at Avonmouth work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Logistics slot, filled by your own words: you live in north Bristol and two days at Avonmouth is fine for you. If she asks how flexible you are, "I wouldn't want more than three" is your statement, so say it as a preference | F11 meets the advert's pattern, and she has said she wants to cover it. JD because it is the listed job's location term |
| A5 | "What's prompting a move?" | EXP | [grounded] "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Say it in the quote's terms, in three clauses: the Bristol office is closing next year, the only offer is relocating to Reading, and you don't want that. Then stop. Why this role is B4's job, so keep the two apart | F12 is the stated reason. EXP because it tests whether your reason stays the same across rounds |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this advert would you be weakest at on day one?" | JD | [generic] | Selection scaffold: look at the advert's list of duties and pick the one you would find newest, say why in your own words, and say how you would get up to speed, as a plan. If no part comes to mind, say so plainly, then name the advert line your own material covers least. The question needs no claim about your past, so the guidance makes none | F2, F5 and F6 are the rows where the material is thinnest, so this arrives in some form. JD because it scores the advert's list |
| B2 | "You'd be coordinating production schedules across planning, the warehouse and QA. What have you scheduled that was production rather than deliveries?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | The deepest rehearsal. Hold only what the quote carries: "I schedule deliveries for our three depots and chase suppliers when orders slip." Answer slot: if any of your scheduling involved production, or teams like planning or QA, say which and what part was yours, in your own words; if it did not, or it was not yours, say so plainly and stay with the depots' deliveries and the chasing. Follow-up one, "who did you work with": name only the teams you actually worked with, or say there were none. Follow-up two, "how would you start here": say how you would find out how schedules get agreed on site, as a plan and not a past. Follow-up three, "so that's a gap": the limit is that your material says deliveries, not production schedules, and the words for it are the second branch of the slot, said plainly. Return to the delivery sentence each time and never add to it | F2 is the widest distance between the advert's first duty and the evidence, so some form of this question is likely. JD because it scores the first stated duty, and the pressure is in the follow-ups |
| B3 | "Have you used SAP or a similar system?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Say it plainly: "I've never used SAP." Then the second half at its own scope: "we run our own in-house stock system." Answer slot: the advert says "or similar", so expect a probe on the in-house system. If you work in it, say what you do in it, in your own words; if you do not, say so plainly and stay with the fact that the company runs it | F7 is a gap you stated and F8 is the open part. JD because the advert lists it as a plus |
| B4 | "What made you apply here rather than somewhere else in Bristol?" | CO | [grounded] "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Why you are looking is the quote, at its scope. Why this role is an answer slot: pick the part of the advert that draws you, in your own words, from its own list of duties; if the main driver is not relocating, say so plainly and then name what in the advert you would want to do. Company facts beyond the advert are not in this pack, because research did not run, so read the company's own site before the call | F12 explains the search but not the choice of employer. CO because it tests homework, and the pack cannot supply any beyond the advert |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Keeping stock records accurate is part of this role. How was the one-third fall in discrepancies counted?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Say it at the sentence's scope: you rebuilt the stock-count spreadsheet, and discrepancies fell by about a third over a year. Answer slots, each in your own words: how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. Name that weakest assumption before she does. If you do not know how it was counted, say so plainly | F4 is the one figure in your material, and probers go to figures. JD content with a defend-the-number delivery |
| C2 | "The advert asks for confidence with Excel. What do you actually do in it?" | JD | [inferred] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Start with the sentence: you rebuilt the stock-count spreadsheet. Answer slot: if it was in Excel, say so, say what you did in it and how confident you are, in your own words; if it was another tool, say so plainly and say which | F6 is open because the quote says spreadsheet, not Excel. JD because the advert lists it |
| C3 | "The role reports weekly on on-time dispatch. What do you report on now?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Start from the sentence: you schedule deliveries for three depots and chase suppliers when orders slip. Answer slot: if you report on deliveries or dispatch today, say what, to whom and how often; if there is no such report, say so plainly and stay with the scheduling and chasing | F5 has no evidence, and the advert raises weekly reporting. JD because it scores a stated duty |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you rather than someone who already knows SAP?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "Never used SAP — we run our own in-house stock system." | Pause and restate the question. Hold on what the quotes carry: four years as a logistics coordinator at a building-supplies wholesaler, and you schedule deliveries for three depots and chase suppliers when orders slip. Hold it through two follow-ups by returning to those facts and never adding to them. Concede the specific limit: "I've never used SAP." Do not add a strength the quotes do not carry | F7 and F1 set the hold and the concession. JD because it presses the advert's plus |
| D2 | "That drop in discrepancies — how much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Hold on your own verb: "I rebuilt our stock-count spreadsheet." Keep the two parts of the sentence as it has them. Answer slot: say in your own words which part of the fall you can attribute to your work and which you cannot; if you cannot separate them, say so plainly. Concede that specifically and do not retreat from the rebuild | F4 is a headline metric, and attribution probes exist to catch inflation. EXP because it tests what was yours |

### E. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A supplier tells you on Monday that a delivery your production schedule depends on will be a week late. What do you do?" | CASE | [generic] | Structure it: what you would ask first, such as what is affected and by when; who needs to know, with the advert naming planning, the warehouse and QA; the options and what each costs; what you would record; when you would come back to it. The question needs no claim about your past, so the guidance makes none | A live problem from the advert's supplier-tracking and scheduling duties, which are F2 and F3. CASE because it asks for a decision |
| E2 | "Planning wants a batch released earlier, and QA says it isn't ready. How do you coordinate that?" | CASE | [generic] | Structure it: clarify what each side needs and what the gap is; separate what you can decide from what someone else owns, and say who; make the trade-off visible to both; record the decision. Do not pretend to authority the role may not carry | The advert names the planning, warehouse and QA coordination as the first duty, which is F2. CASE because it is a live seam problem |

### F. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "When you chase a supplier on a late order, who else do you need to bring in?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Story-map from the sentence: you chase suppliers when orders slip. Answer slot: if other people or teams had to be brought in, say who and what you did, in your own words; if you chased on your own, or there was no one else to bring in, say so plainly and stay with the chasing | F3 is the supplier-chasing duty, and the peer style asks about the people around it. JD because it scores the stated duty |
| F2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Selection scaffold: pick a time work spanned teams and credit was shared; it needs a named piece of work, what you did, what others did and how credit was said. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Peer evaluators probe collaboration and credit. EXP because the answer must separate what was yours |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "2+ years in operations or logistics coordination" | A1, D1 |
| "Coordinate production schedules between planning, the warehouse and QA" | B1, B2, E1, E2 |
| "track supplier deliveries and chase late orders" | F1, E1 |
| "keep stock records accurate" | C1, D2 |
| "report weekly on on-time dispatch" | C3 |
| "confident with Excel" | C2 |
| "ERP experience (SAP or similar) a plus" | B3, D1 |
| "£38,000–£44,000" | A2 |
| "Hybrid: two days a week at our Avonmouth site in Bristol" | A4 |
| "your notice period" and "what's prompting a move" (Hannah) | A3, A5, B4 |

## Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| R1 | "How does the week split between planning, the warehouse and QA, and who does the role report to?" | It uses the advert's own three functions, so it shows you read the duties |
| R2 | "What would you want on-time dispatch reporting to show in the first three months?" | It turns the advert's weekly-reporting line into a concrete expectation you can work to |
| R3 | "What system does the team work in day to day, and how is onboarding handled for it?" | It asks about the system the advert's ERP line points at without making a claim about yourself |
| R4 | "Are the two Avonmouth days fixed or agreed with the team?" | It follows from the hybrid line she has said she wants to cover |
| R5 | "What does the next stage involve, and who would I meet?" | She has said she will cover next steps, so this goes only where her answer leaves a gap |
| R6 | "Is this a new role or a replacement, and what changed to open it?" | It tells you what the role is meant to fix |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has used SAP | Negative you stated, F7 | The plain acknowledgment: "I've never used SAP." No slot |
| Has ERP experience through the in-house stock system | Inflated form of F8 | F8's quote at its own scope: "we run our own in-house stock system." The limit is the pack's observation: the material says the company runs a system, not what you do in it. B3's slot stays inside that |
| Coordinated production schedules across planning, the warehouse and QA | Inflated form of F2 | F2's quote at its own scope: "I schedule deliveries for our three depots." The limit is the pack's observation: the material says deliveries, not production schedules. B2's slot stays inside the deliveries |
| Cut discrepancies by a third by rebuilding the spreadsheet | Inflated form of F4 | F4's quote with its two parts as the sentence has them: you rebuilt the spreadsheet, and discrepancies fell by about a third over a year. The limit is the pack's observation: the sentence does not say the first caused the second |
| Is being made redundant | Inflated form of F12 | F12's quote at its own scope: the office is closing next year and the only offer is relocating to Reading. The limit is the pack's observation: the material says an offer exists, not that your role ends |
| £42,000 is a firm minimum | Inflated form of F9 | F9's quote: "I'm hoping for £42,000." The limit is the pack's observation: the material says hoping, not a floor |
| Can work no more than three days a week on site | Inflated form of F11 | F11's quote: "I wouldn't want more than three." The limit is the pack's observation: the material says a preference, not a cap |

## Sources

Provided: the advert, Hannah Lowther's LinkedIn message, and your own background notes, all pasted in the conversation.

Searches sent, all refused, none returned a result:

- "Quillmoor Diagnostics values" — refused
- "Quillmoor Diagnostics interview process operations coordinator" — refused
- "Hannah Lowther Quillmoor Diagnostics" — refused
- "Quillmoor Diagnostics news strategy Avonmouth" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | Every call was refused. It would have named the published values for B4 and for a values bank |
| 2. `Quillmoor Diagnostics interview process operations coordinator` | unavailable | Every call was refused. Hannah's message fixes this session, and the search would have shown later rounds for persona weights |
| 3. `Quillmoor Diagnostics strategy` and recent news | unavailable | Every call was refused. B4 and the case questions stay at what the advert supplies |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | Every call was refused. The interviewer read rests on her own message alone |
| 5. representative `Operations Coordinator` JD | skipped | The advert you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV → rows F1 to F8 get CV quotes in place of message quotes, and confidence can rise where a line has an artifact behind it
- Your notice period, stated outside this file → F10 and A3 fill in your own words
- What you report on deliveries or dispatch today, and which tool the stock-count spreadsheet was built in → rows F5 and F6 become quoted evidence, and C2 and C3 gain story maps
- How the one-third fall in discrepancies was counted, and the stock-count discrepancy reports before and after → F4 can move from medium toward high, and C1 and D2 get your own words
- Permission to search the web → the company's published values, a documented interview process and recent news, which would ground B4 and the case questions; a deeper pass, up to 6 more searches and 2 more fetches over several more minutes, would add a strategy brief
- A tuesday-dossier.md from an earlier evidence review → verified evidence, allowed strategies per weak area and any prohibited claims arrive pre-checked
