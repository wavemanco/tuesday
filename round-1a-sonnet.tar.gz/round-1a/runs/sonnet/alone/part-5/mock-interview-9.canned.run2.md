Your prep pack is saved as `halvering-elementary_fourth-grade-teacher_interview_pack.md`. I built it for a panel with Principal Vantongeren as the hiring-manager seat and the two fourth-grade teachers as peers, with no job posting yet. It has 22 questions and an answer-guidance cell for each. A1, "You've taught third grade. What makes you ready for fourth?", is the one to rehearse first.

You pasted a Social Security number. I don't need it, so I haven't used or repeated it. It's worth removing from anything you share.

Your license is covered in the pack as you stated it, and your licence number appears nowhere. Checking your licence record before Thursday is yours to do.

Say the word and I'll play the Skeptic on A1, the question the pack names as its highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Can you paste the full job posting, or tell me there isn't one? Pasting it would turn the "typical for the role" rows into quoted ones.
2. Did HR or anyone tell you what the panel will focus on, or ask you to bring a demo lesson or sample? And do you know whether Principal Vantongeren decides, or the team does? Either answer would change the question banks.
3. Do you want a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes)? It would add a grounding brief on the district's current direction.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: halvering-elementary_fourth-grade-teacher_interview_pack.md -----
# Interview pack: Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)

Panel interview, 45 minutes, Thursday. Panel: Principal Dolores Vantongeren and two members of the fourth-grade team. Built for one session; the principal is treated as the hiring-manager seat and the two teachers as peers, because the invite does not say who decides.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the district's published beliefs |
| EXP | Whether the résumé's claims survive scrutiny, and what was actually yours |
| JD | The stated role and its requirements, gaps included |
| CO | Knowledge of the district's current direction |
| CASE | A live classroom or team problem, reasoned aloud |

The highest-ROI prep in the pack is A1: the question about never having taught fourth grade will arrive in some form, and a plain, rehearsed answer changes the interview. Answer slots (instructions that begin "Answer slot") are for the interview itself; they ask nothing of you here.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — the invite (S1) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | The term is shown met as you state it, and the grades 1–6 span includes fourth grade. Nothing has been inspected behind it, and checking your own licence record is yours to do. Say it in the quote's own terms |
| F2 | "Fourth Grade Teacher position" — the invite (S1) | "Six years teaching third grade at a public elementary school in Joliet" — your CV; "I've never taught fourth grade" — your message | medium | [grounded] | transferability | Words: "I've never taught fourth grade." Then, "For six years I taught third grade at a public elementary school in Joliet." Answer slot: if the reading club or the curriculum move touched fourth-grade students or content, say what; if not, say so plainly and give a plan for learning the grade, never a past |
| F3 | "reading instruction" — the district's hiring page, "Panels ask about reading instruction, classroom routines and how you work with families." (S4) | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | transferability | Your material carries a curriculum move and a club, not how you teach reading in your own classroom. Words: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: if you taught reading in your third-grade classroom, say how, in your own words; if it was organised some other way or was not yours, say so plainly and stay with the move and the club |
| F4 | "classroom routines" — the district's hiring page (S4) | none given | none | [grounded] | discovery | Your material does not show your routines. Answer slot: if you run routines you would bring to fourth grade, say which and why, in your own words; if none comes to mind, say so plainly and say how you would build them |
| F5 | "how you work with families" — the district's hiring page (S4) | "I write a weekly email to families." — your message | medium | [grounded] | none | No gap, but a one-line record with nothing inspected behind it, so expect a probe. Lead with it in the quote's own terms: weekly, an email, to families |
| F6 | "each teacher speaks with every family each term" — the district's published belief Families Are Partners (S3) | "I write a weekly email to families." — your message | low | [inferred] | discovery | The belief asks for speaking with families; your quote says a weekly email, and your material does not show whether any contact beyond the email happened. Answer slot: if there was, say what and how often, in your own words; if the email was the extent of it, say so plainly and stay with the email |
| F7 | "no student leaves third grade without a reading plan" — the district's published belief Every Child a Reader (S3) | "Six years teaching third grade at a public elementary school in Joliet" — your CV; "I've run the after-school reading club for the last two years" — your CV | low | [inferred] | discovery | The belief names third grade, the grade you have taught, and your material does not show whether any of your students had a reading plan or whether you had a part in one. Answer slot: if any did and you had a part, say what part, in your own words; if none did or it was not yours, say so plainly and stay with the club |
| F8 | "assessments inform teaching and never replace it" — the district's published belief Teach for Tomorrow, Not for the Test (S3) | none given | none | [grounded] | discovery | Your material says nothing on assessment. Answer slot: if there was a time an assessment result changed what you taught, say which and what changed, in your own words; if there was not, say so plainly and say how you would use results |
| F9 | Work with the grade-level team: typical for the role in a K12 Jobs Board listing, seen as a search result only (S7) | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your message | medium | [inferred] | transferability | Words: "I've never been a team lead." and the move at its own scope. The pack's observation is that your material says the grade level's move you led, not leading a team, and the two sentences will be read side by side |

## Reading the interviewer

Public professional footprint only. The two teachers are not named, so there is nothing to read for them.

| Fact | Source | Provenance | What it means for you |
|---|---|---|---|
| Dolores Vantongeren has been principal of Halvering Elementary School since 2022, after nine years as a reading specialist | S5 (search result, page not opened) | [grounded] | Reading instruction questions (E3, B2) are likely to go a level deeper than the surface. Prepare each reading practice you name at the depth you can defend under a second question |
| Her 2025 forum talk, Small Groups, Big Readers, covered weekly reading conferences in grades 3 to 5 | S5 (search result, page not opened) | [grounded] | Fourth grade sits inside the range her talk covered. Read the page before using it in R2, and do not claim a practice of yours that you did not use |
| No career jump of hers matches a sentence in your fit snapshot | F-rows above | [grounded] | No shared jump is offered. Her path is used only for reverse question R1 |

## Persona table

The principal is weighted as a hiring manager and the two teachers as peers (the invite states the panel's makeup, S1); the district states what panels ask about (S4).

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A, 5 questions) | The principal probing the fourth-grade and team-lead gaps; why leave, why here | Highest: F2 is visible in the invite's title against your résumé, and a hiring-manager seat buys capability and derisks gaps | Rehearse A1 until it is boring. Use the plain sentence from your own message, hold through two follow-ups, concede specifically |
| Case/Strategist (bank B, 4 questions) | Live classroom problems: a struggling reader, routines, a parent email, the new curriculum | High: the district's page says panels ask about reading instruction, routines and families (S4), and the board plan adds a new curriculum (S6) | Clarify before structuring, structure aloud, and make no claim about your past that a quote does not carry |
| Peer Evaluator (bank C, 4 questions) | The two fourth-grade teachers: seams, credit, what you would need from them | High: two of three panelists are teammates-to-be, and F9 is thin | Reciprocity first, seam principles instead of pretending to know their seam, stories where you can say which part was yours |
| Values/Behavioral (bank D, 3 questions) | Questions themed on the three published beliefs | Medium: the beliefs guide hiring (S3), but no source names a values round, so this is not a dedicated one | Map a story where a quote carries one, otherwise pick a specific child or decision you can tell start to end |
| Data-Driven Prober (bank E, 3 questions) | Depth on the curriculum move and on how you teach reading | Medium: your résumé gives no figures to defend, but the principal's reading-specialist background (S5) points at reading depth | Tell the move at its own scope, stop where your facts stop, and say plainly what you do not know |
| Conversational (bank F, 3 questions) | The opening arc, the licence check, the reading club | Medium: every panel opens warmly, and these are still scored | A 90-second arc from your own sentences, and the licence line word for word |

Not weighted: a pressure interviewer and a recruiter screen. Nothing in the invite or the district's page suggests either.

## Question banks

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 licence | F2 |
| F2 fourth grade | A1, A2, A3, F1 |
| F3 reading instruction | E1, E2, E3, B1, B2, F3 |
| F4 classroom routines | B3 |
| F5 families | B4, C4, D2 |
| F6 speaking with families | D2 |
| F7 Every Child a Reader | D1, B2 |
| F8 Teach for Tomorrow | D3 |
| F9 grade-level team | A4, C1, C2, C3 |

F3 to F5 come from the district's own page and F6 to F8 from its published beliefs; F9 is typical-for-the-role only, because no posting was supplied.

### A. Skeptic (principal)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've taught third grade for six years. What makes you ready for fourth?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" "I've never taught fourth grade" | The highest-ROI rehearsal in this pack. Say the limit first, plainly: "I've never taught fourth grade." Then hold on what the quote carries: "For six years I taught third grade at a public elementary school in Joliet." Answer slot: if the reading club or the curriculum move touched fourth-grade students or content, say what, in your own words; if neither did, say so plainly and say how you would learn the grade, as a plan and never as a past. Rehearse three follow-ups: what will be hardest; what you would want from the team in your first month; and "so you haven't taught it?", answered with the same plain sentence, not a longer one. Hold through two follow-ups by returning to the six third-grade years, never by adding to them. Concede specifically; never say the two grades are the same | F2 is the gap the panel can see from the invite's title and your résumé, so this arrives in some form. JD because it scores the stated position; Skeptic because it probes the gap |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" "I've never been a team lead" | Choose one gap you can describe precisely. Your material names two, in your own words: "I've never taught fourth grade" and "I've never been a team lead." Say the one you choose in those words, then one sentence on how you would learn it, as a plan you would follow. Do not offer a weakness that is really a strength, and do not pick one you could not back under a second question | The Skeptic's stock stem, aimed at F2 and F9. JD because it scores readiness against the role |
| A3 | "You've spent six years in third grade. Why leave now, and why Halvering?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | Answer slot: give your real reason for moving, in your own words, in one or two sentences, without criticising colleagues; then what drew you to Halvering specifically, from what you actually know. The district's published beliefs and literacy plan (S3, S6) are public, so read them before Thursday and use only what you have read. If the reason is about fourth grade itself, say what, in your own words | Motivation consistency is what the Skeptic scores; F2 makes "why now" the natural form. EXP because it tests whether your story holds together |
| A4 | "You haven't been a team lead. How would you contribute to a team that already works together?" | EXP | [grounded] "I've never been a team lead" "I led our grade level's move to a new reading curriculum in 2024" "I've run the after-school reading club for the last two years" "I write a weekly email to families." | Hold, then concede. Plain acknowledgment: "I've never been a team lead." Hold on the move at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Do not widen it to the school or to leading a team. For what you would bring, use the club and the weekly email in the quotes' own terms, then say what you would ask the team for first, in your own words | F9 sits on a stated negative beside a "led" sentence, and a peer-heavy panel will read them together. EXP because it tests attribution |
| A5 | "Looking back on the move to the new reading curriculum, what would you do differently?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Answer slot: if something comes to mind, say what and what you learned, in your own words; if nothing does, say so plainly and say what you would watch for next time. Never supply a setback to sound reflective | The Skeptic tests honest self-assessment on the one item in F3 and F9 that carries "led". EXP because it probes what you saw first-hand |

### B. Case/Strategist (principal)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The board's literacy plan brings a new grades 3–5 reading curriculum from fall 2027. How would you get ready, and how would you help a team through it?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Clarify first: what the fourth-grade team has been told, what has been chosen, and the timeline. Then structure: learn the curriculum, find what the team already does well, sequence your own preparation, and decide how families hear about it. If you draw on 2024, the quote carries only that you led your grade level's move; any detail of how is your own account and must be something you can repeat under a second question. Do not present the 2024 move as the same experience as a different curriculum | The one CO item grounded in current strategy: the board's August 2026 plan (S6, search result, page not opened, so read it first). CO because it tests altitude, CASE in delivery. F3 is the row it draws on |
| B2 | "A fourth grader is reading well below the rest of the class in week three. Walk me through what you'd do." | CASE | [generic] | Clarify: what the assessments show, what the student has had before, and what supports this school has. Then objective, steps, and how you will know it is working, and where you would ask for help. Involve the team and the family. The question needs no claim about your past, so the guidance makes none | A live problem from the district's reading focus (S4) and the Every Child a Reader belief (F7). CASE because it scores structure |
| B3 | "How would you set up the first two weeks of fourth grade, routines and expectations included?" | CASE | [generic] | Structure it: what each routine is for, how you would teach it, how you would check it is holding, and how you would adjust for fourth graders. Answer slot: if you already run routines you would bring, say which and why, in your own words; if none comes to mind, say so plainly and say how you would build them | F4 raises it: the district's page says panels ask about classroom routines (S4). CASE because it is a plan, JD in content |
| B4 | "A parent writes twice in one week, upset about a grade. How do you respond?" | CASE | [grounded] "I write a weekly email to families." | Structure: acknowledge first, check the facts before replying, answer in plain words, offer a conversation, and ask what this school's process is for involving the team or principal rather than assuming one. Your existing habit goes in in those words only: "I write a weekly email to families." | F5 and the families focus in S4. CASE because it is a live problem |

### C. Peer Evaluator (two fourth-grade teachers)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our team plans together. Where's the seam between what you'd bring and what we've already built, and what happens when we disagree?" | CASE | [generic] | Use reciprocity and principles, not pretended knowledge of their seam: you would ask what the team does and why before proposing anything, and you would say how you disagree about the work rather than the person. Concede that you do not yet know where their seam is | F9 is thin, and this is where a peer prices it. CASE because it is a live collaboration problem |
| C2 | "When has credit for shared work been a question for you, and what did you do?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Pick a time where you can say plainly which part was yours: we for context, I for contribution. If you pick the 2024 move, the quote's beats are your grade level's move, the new reading curriculum, 2024, and that you led it; which parts were yours and which were shared is your own account. If credit was shared or never came up, say so plainly. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The Peer's credit-sharing probe, aimed at F9. EXP because it tests attribution |
| C3 | "What would you need from us in your first month, and what could you do that would genuinely help us?" | EXP | [grounded] "I've run the after-school reading club for the last two years" "I write a weekly email to families." | Lead with what you offer, in the quotes' terms: you run the club, and you write the weekly email. Then what you would want from them, named in your own words: what you actually need to see or ask | The reciprocity question for a peer panel; F5 and F3 supply what you offer. EXP because it tests partnership fit |
| C4 | "Tell us about the weekly email you send to families." | EXP | [grounded] "I write a weekly email to families." | The quote carries weekly, an email, and families, and nothing else. Describe it in your own words and stop where your facts stop; what it contains, who reads it and whether anyone replies must be things you can repeat under a second question. "I don't know" is an honest answer to a figure you never tracked | F5 is a one-line record with nothing inspected behind it. EXP because it checks what the line stands on |

### D. Values/Behavioral (published beliefs, S3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our first belief is Every Child a Reader. Tell me about a time you made sure a child was becoming a reader." | VAL | [grounded] "Six years teaching third grade at a public elementary school in Joliet" "I've run the after-school reading club for the last two years" | No sentence of yours carries a child's story, so choose one: a specific child, a decision you made, and what happened, told start to end, with the stake named. The club and the third-grade years are where your material touches reading. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F7 raises it, and the belief names third grade, the grade you have taught. VAL because it scores a published belief |
| D2 | "Families Are Partners is another of our beliefs. How do you work with families?" | VAL | [grounded] "I write a weekly email to families." | Say what the quote carries: "I write a weekly email to families." Answer slot: say what goes in it and who it reaches, in your own words; if any families answered or you met with families, say what happened and what part was yours; if the email is the extent of it, say so plainly and stay with the email | F5 and F6; the slot stays inside the email so it cannot imply a wider claim. VAL because it scores the second published belief |
| D3 | "Teach for Tomorrow, Not for the Test means assessments inform teaching and never replace it. Tell me about a time assessment results changed what you did in the classroom." | VAL | [grounded] | Choose a specific assessment, the decision it led to, and what changed, told start to end. Your material carries nothing on this, so there is no story to map. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would use results | F8 has no evidence, so the honest answer is prepared before the probe. VAL because it scores the third published belief |

### E. Data-Driven Prober (depth on reading)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through how your grade level's move to the new reading curriculum went." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | The quote carries your grade level, the new reading curriculum, 2024, and that you led it. Tell it in your own words and stop where your facts stop. The second question will ask for more, so say only what you can repeat, and "I don't remember" or "I don't know" is better than a detail you cannot back | F3's strongest line and the likeliest to be probed. EXP because it tests what you did |
| E2 | "How much of that move was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Hold, then concede. Hold on the sentence at its scope: "I led our grade level's move to a new reading curriculum in 2024." Concede specifically, in your own words: which parts others owned, or that you owned all of it, or that you cannot now separate the parts. Never fold on "I led" if it is true, and never widen it | The attribution probe F3 and F9 invite. EXP because the question exists to catch inflation |
| E3 | "How do you teach reading in your classroom?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | No sentence of yours says how you teach reading. Answer slot: describe what you actually do, in your own words, at the depth you can defend; if reading was organised differently in your classroom, or was not yours, say so plainly and stay with the move and the club. Expect follow-ups, given the principal's reading background (S5), and name only practices you can describe a second time | F3's gap, raised by the district's page (S4). JD because it scores the role's core |

### F. Conversational (opening)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through your journey to teaching, and to this role." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" "I led our grade level's move to a new reading curriculum in 2024" "I've run the after-school reading club for the last two years" "I write a weekly email to families." | A 90-second arc from those four sentences, in that order of weight: the third-grade years, the move, the club, the weekly email, then why fourth and why here in your own reason (see A3). You may name the gap yourself, using "I've never taught fourth grade," then one sentence on why you want to learn the grade. How you came to teaching is not in your material, so it is yours to add or leave out | An unscored-feeling opener that is scored. EXP because it sets the story every later question tests |
| F2 | "Before we go further, can you confirm your licensure?" | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | Say it as written: "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029." Add nothing. Check your own licence record before Thursday so what you say matches it; if anything differs, say it as it is | F1 is the invite's one stated requirement. JD because it scores a stated requirement |
| F3 | "Tell us about the after-school reading club." | EXP | [grounded] "I've run the after-school reading club for the last two years" | The quote carries after-school, a reading club, two years, and that you ran it. Say it in your own words and stop where your facts stop. Connect it to Every Child a Reader only as far as your own account supports | F3 and a natural warm-up for the principal. EXP because it checks what the line stands on |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You came to the principalship after nine years as a reading specialist. How does that shape what you hope to see in fourth-grade reading instruction?" | Tied to the principal's own public path (S5); it turns the reading probe into a conversation about what she values |
| R2 | "I read about your forum talk on weekly reading conferences in grades 3 to 5. How does that look in fourth grade here?" | Only ask it after you have read the page; it shows you researched her work, not just the school |
| R3 | "The board's plan adds a new grades 3–5 reading curriculum from fall 2027. How is the fourth-grade team preparing, and where would a new teacher fit?" | Shows current homework (S6) and moves toward what the team needs; read the board page first |
| R4 | "What could a new person on the fourth-grade team do in their first month that would genuinely help you?" | The reciprocity question for a peer panel: it asks what you can give them first |
| R5 | "What support does a teacher who is new to fourth grade get here?" | Names the F2 gap without apologising and asks what the school does about it |
| R6 | "How do fourth-grade teachers keep families informed here, and what is shared across the team?" | Draws on the Families Are Partners belief (S3) and invites a comparison to your weekly email without claiming more |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | Negative you stated, F2 | The plain acknowledgment from your message: "I've never taught fourth grade." A1 and A2 give the plan, not a past |
| Has been a team lead | Negative you stated, F9 | The plain acknowledgment from your message: "I've never been a team lead." A4 holds on the move at its own scope |
| Led the school's or the district's reading curriculum adoption | Inflated form of F3 and F9 | The quote at its own scope: "I led our grade level's move to a new reading curriculum in 2024." The limit is the pack's observation: your material says your grade level's move, not the school's or the district's |
| Speaks with every family each term | Inflated form of F5 and F6 | The quote at its own scope: "I write a weekly email to families." The limit is the pack's observation: your material says a weekly email, not conversations with each family. D2's slot stays inside the email |

## Sources

Provided: your invite (S1) and your résumé details (S2).

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Orrinsford Community School District values` | yes | Fetched the page: three named beliefs. Fit rows F6 to F8 and bank D; no dedicated values round is documented, so no values cheat sheet |
| 2. `Orrinsford Community School District interview process teacher` | yes | Fetched the page: one 45-minute building panel, principal and two grade-level teachers, asking about reading instruction, classroom routines and families. It sets the persona weights and F3 to F5 |
| 3. `Orrinsford Community School District strategic plan news` | yes | Search result only, page not opened: a 2026–2029 literacy plan. It feeds B1 and R3; read the page before using either |
| 4. `Dolores Vantongeren Halvering Elementary School` | yes | Search result only, page not opened: her public path and a 2025 talk. It feeds the interviewer read and R1 and R2 |
| 5. representative `fourth grade teacher` JD | yes | Search result only, truncated: the team-work line behind F9, `[inferred]`. Its qualifications line was cut off and is not used |

Queries and what came back:

- S3: "Orrinsford Community School District mission values" returned https://orrinsfordschools.example/about/mission-and-beliefs, then fetched
- S5: "Halvering Elementary School Orrinsford principal Dolores Vantongeren" returned https://ilprincipalsforum.example/speakers/dolores-vantongeren
- S4: "Orrinsford Community School District teacher hiring interview process" returned https://orrinsfordschools.example/careers/how-we-hire-teachers, then fetched
- S6: "Orrinsford Community School District strategic plan news" returned https://orrinsfordschools.example/news/board-adopts-literacy-plan
- S7: "fourth grade teacher job description Illinois elementary school responsibilities qualifications" returned https://k12jobsboard.example/listings/fourth-grade-teacher

No search query contained your name or any licence number.

## Upgrade menu

- The full job posting text → F9 and the unquoted role-family requirements become quoted `[grounded]` rows, and the coverage table can be checked against the posting's own list
- Anything the recruiter or HR told you about panel focus, or a demo lesson or teaching sample to bring → a build section for it, if one was declared
- Whether Principal Vantongeren decides or the team does → persona weights recomputed and the banks reordered
- The two team members' names → an interviewer read for each, from public professional footprint only, and a tailored reverse question
- Your own answers to the slots in F2, F3, F4, F6, F7 and F8 → those rows move from discovery or transferability to quoted evidence and the banks regenerate
- A look at your own licence record before Thursday → F1 can rise from medium to high once you have inspected it
- A `tuesday-dossier.md` from an earlier evaluation of this job → verified evidence and a prohibited-claims list to build the banks against, never required to use this pack
