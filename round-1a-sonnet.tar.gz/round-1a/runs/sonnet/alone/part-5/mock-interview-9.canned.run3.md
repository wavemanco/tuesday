I'll read the reference files first.
I've read the skill's rules, and I'm now running a few targeted searches on the district's values, its recent priorities, the principal, and a typical fourth-grade posting. Then I'll write the pack.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a/runs/sonnet/alone/part-5/rooms/case-9-canned-65324cee/Halvering-Elementary_fourth-grade-teacher_interview_pack.md`. I built it for a panel round: Principal Vantongeren plus two fourth-grade teammates, as the invite says. It has 21 questions across seven personas, and your licence matches the invite's one stated requirement.

- **Your biggest objection:** "I've never taught fourth grade." Question A1 is the pack's top rehearsal, and P1 is its harder-pressure version. Your other stated limit, never being a team lead, is covered in A2 and P2.
- **Licence:** You said it's active through June 30, 2029. Before Thursday, confirm in the state's licensing system that it shows active.
- **Sensitive details:** Your resume included a Social Security number. I don't need it and left it, and your licence number, out of the pack and every search. I'd take the SSN off any copy of the resume you send out.
- **Research:** I looked up the district's three published beliefs, its August 2026 literacy plan, and the principal's public background. I also found a typical fourth-grade posting, so some job requirements are labeled as inferred until you have the real one.

Say the word and I'll play the Skeptic on A1, the pack's top rehearsal. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed. If you'd like the pack as a Word document, say so and I'll convert it.

1. Do you have the full Halvering posting? I built this without it.
2. Has HR said whether you'll teach a sample lesson or bring anything to the panel?
3. Do you want a deeper research pass? It's up to 6 more searches and 2 more fetches, several more minutes, and would add a district background section.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering-Elementary_fourth-grade-teacher_interview_pack.md -----
# Interview pack: Fourth Grade Teacher, Halvering Elementary School

**Employer:** Orrinsford Community School District (Halvering Elementary School)
**Round:** 45-minute panel on Thursday: Principal Dolores Vantongeren and two members of the fourth-grade team (the two team members are unnamed in the invite)
**Candidate:** Grace

## How to use this pack

Personas describe how a question arrives; types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did. Where a cell reads "Answer slot", it is an instruction for the interview: answer from your own experience, or say plainly that the practice was not yours or did not exist.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the district's published beliefs |
| EXP | Whether your CV's claims hold up, and what was actually yours |
| JD | The stated role requirements, including where you are thin |
| CO | Whether you know the district's current direction |
| CASE | Structure and reasoning on a live classroom problem |

## Prep triage (Thursday)

1. Say A1 aloud until it is boring, then P1. They are this pack's highest-ROI prep: the fourth-grade limit is the question you will most likely get.
2. Say D1, your 90-second arc, aloud twice, and D4, your licence line.
3. Rehearse A2 and P2 together: both press on how much of the curriculum move was yours.
4. Work out your own honest answer to the answer slots in A5 and E3. No quote in your material carries them.
5. Choose three of the reverse questions.

Everything else is insurance.

## Fit snapshot

Requirements come from the invite (quoted), from a representative fourth-grade posting found by search (quoted from the search snippet, so `[inferred]`: it is not necessarily Halvering's own posting), and from the district's published beliefs page.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — your invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | A gate your material shows met: the kind of licence, the issuer, the endorsement and its grade range, and the expiry are all stated. It is a CV line with nothing inspected behind it, so say it in the quote's own terms. Confirming that your registration shows as active is yours to do before Thursday, through the state's own licensing system. Your licence number is not needed here and is left out of this pack |
| F2 | "plan and teach reading, writing, math, science and social studies" — K12 Jobs Board listing, search snippet | "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [inferred] | transferability | Your material says six years of third grade, and it does not say which subjects were yours. The words stay there: "For six years I taught third grade at a public elementary school in Joliet." Answer slot: expect a probe on subjects beyond reading. If you planned and taught them, say which, in your own words; if some were taught by others, or were not yours, say so plainly and stay with the third-grade year |
| F3 | "Fourth Grade Teacher position" — your invite | "I've never taught fourth grade" — your CV | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't taught fourth grade." Then, beside it, the quote at its own scope: "For six years I taught third grade at a public elementary school in Joliet." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F4 | "work with the grade-level team" — K12 Jobs Board listing, search snippet | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead." — your CV | medium | [inferred] | none | The first quote already reaches the requirement in role-relevant terms: you led your grade level's move. The second is a limit you stated, so the acknowledgment is yours to give: "I haven't been a team lead." Expect a probe on what leading the move involved; nothing inspected sits behind the line. Keep it at "led the move", never the curriculum's choice or its training, unless you say those were yours |
| F5 | "communicate regularly with families" — K12 Jobs Board listing, search snippet | "I write a weekly email to families." — your CV | medium | [inferred] | none | A named, regular practice in your own words beats an adjective. Lead with it exactly as written. The quote says an email, not conferences or calls |
| F6 | "differentiate instruction using assessment data" — K12 Jobs Board listing, search snippet | none given | none | [inferred] | discovery | Your material is silent on assessment practice, and silence is not an absence. Answer slot: the posting line and the district's belief that "assessments inform teaching and never replace it" make a probe likely. If you use assessment results to change how you teach, say what you look at and what you change; if you do not, or it was not yours to do, say so plainly and say how you would start |
| F7 | "Every Child a Reader: no student leaves third grade without a reading plan." — district Mission and Beliefs page | "I've run the after-school reading club for the last two years."; "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [grounded] | transferability | Your quotes say a club and a curriculum move, not reading plans. Words: "I've run the after-school reading club for the last two years." Answer slot: if reading plans were part of your third-grade year, say whose they were and what you did; if they were not, or were not yours, say so plainly and stay with the club and the move |
| F8 | "Families Are Partners: each teacher speaks with every family each term." — district Mission and Beliefs page | "I write a weekly email to families." — your CV | medium | [grounded] | transferability | An email is writing to families, not speaking with each one. Words: "I write a weekly email to families." Answer slot: if you also speak with families directly, say how and how often; if you do not, say so plainly and stay with the email |

## Reading the interviewer

Public professional footprint only. The two team members are not named, so nothing is read for them.

| Fact | Source | Provenance | What it means for you |
|---|---|---|---|
| Dolores Vantongeren has been principal of Halvering Elementary since 2022, after nine years as a reading specialist | Illinois Principals Forum speaker page | [grounded] | Expect reading questions to be asked with a specialist's ear; the district's reading focus and her background point the same way. A1 and A5 are where thin material shows |
| Her 2025 forum talk, Small Groups, Big Readers, covered weekly reading conferences in grades 3 to 5 | Illinois Principals Forum speaker page | [grounded] | Her own published theme is reading practice in grades 3 to 5, so C1 and D2 are likely. Do not adopt her vocabulary as your practice; use it only for what is actually yours |

Mirror opportunity: her path runs through reading, and your side of it is F7's quote, "I've run the after-school reading club for the last two years." Use it as it stands, and do not stretch it to match her specialism. Reverse questions 1 and 2 are built on her path.

## Persona table

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the two limits you stated, and of why now | High. A panel blends the top two personas of each member's relationship, and the principal sits in the hiring-manager seat, where Skeptic is a prior. F3 and F4 are stated limits, which is exactly what a Skeptic probes | Rehearse A1 until it is boring. Bridge only with what your quotes carry, and say the limit plainly first |
| Peer Evaluator | The two fourth-grade teachers asking what you would need and bring, and how you would disagree | High. Two of the three panelists are teammates, and the invite makes them a majority of the panel | Reciprocity: what you bring their team as well as what you need. Propose principles for working together without pretending to know their routines |
| Case/Strategist | A live classroom problem, possibly built on the district's literacy plan | Medium. Hiring-manager prior, and the board's August 2026 plan gives a ready scenario. The invite names no case or demo | Clarify, then objective, then approach, then how you would know it is working, then risks; think aloud |
| Conversational | Panel opener, "walk us through your journey", licence confirmation, "anything else" | Medium. Panels open this way, and casual questions are still scored | A 90-second arc built only from your quotes (D1); never answer "I think you've covered everything" to the closing slot |
| Values/Behavioral | Questions themed on the district's three published beliefs | Medium-low. The beliefs page says they "guide every hire", but the invite names no values round, so none is detected and there is no values cheat sheet. The beliefs still raise E-bank questions | For each belief, pick a real instance of your own; where none comes to mind, say so plainly and give the nearest thing you did |
| Pressure | A time-boxed "why you" | Low. Nothing in the invite signals it; a panel seldom runs this way | Pause, restate, hold two follow-ups on what you actually said, then concede specifically |
| Data-Driven Prober | Numbers and denominators | Low. Your CV carries no figures to defend; its follow-up style appears inside A2 and P2 | Say how you know what you know, or say you do not know |

## Question banks

### Bank A: Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't taught fourth grade. What changes for you in this classroom?" | JD | [grounded] "I've never taught fourth grade" "Six years teaching third grade at a public elementary school in Joliet." | **The highest-ROI rehearsal in this pack.** Open with the plain acknowledgment: "I haven't taught fourth grade." Then the quote at its own scope: "For six years I taught third grade at a public elementary school in Joliet." Then a ramp plan, said as a plan and not a past: what you would ask the team for first, in your own words. Follow-up 1, what is different about fourth: answer slot: if you know specific differences from your own work with third graders, say them; if you do not, say so plainly and say what you would ask the team. Follow-up 2, why take the risk on you: hold on the same two sentences and add no experience | F3 is the objection that arrives in some form, and F2 is the adjacent material. JD because it scores the role as posted, with Skeptic delivery |
| A2 | "You haven't been a team lead. This role works inside a grade-level team, so what has your leadership looked like?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" "I've never been a team lead." | The acknowledgment first: "I haven't been a team lead." Then the sentence at its scope: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: the representative posting lists working with the grade-level team, so expect a probe on what leading the move involved. If particular steps were yours, say which and how you decided, in your own words; if the work was shared or the steps were someone else's, say so plainly and stay with the move itself | F4 pairs a stated limit with a real line, and the interviewer's premise here is the candidate's own words |
| A3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" "I've never been a team lead." | Choose your true answer; the two limits you stated are the candidates in your material. Pick the one you can pair with a concrete first step, and give the step as a plan. If neither is your real answer, say what is. Candor here reads as self-knowledge, so do not name a strength dressed as a weakness | Standard Skeptic stem; F3 and F4 supply the likely answers |
| A4 | "Why leave third grade, and why Halvering, and why now?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." | Logistics slot: give your actual reason for the move, in your own words, about what you want rather than what you are leaving. One published hook, if it is true for you: the board's August 2026 plan brings a new grades 3–5 reading curriculum from fall 2027. Whether that draws you is yours to say. Do not claim interest you do not have | Reason-for-moving questions are asked of nearly every candidate who changes grade levels; EXP because it tests consistency with the record |
| A5 | "How do you use assessment data to differentiate your instruction?" | JD | [inferred] | Answer slot: the posting line and the district's belief that assessments inform teaching and never replace it make this probe likely, and your material does not show an assessment practice. If you use results to change how you teach, say what you look at and what you change, in your own words; if you do not, or it was not yours to do, say so plainly and say how you would start | F6 is a discovery row, so the honest answer is one only you can supply. JD because it scores a posted requirement, and `[inferred]` because the requirement comes from a representative posting |

### Bank B: Peer Evaluator (high weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our team plans together. What do you need from us in your first month, and what would you bring?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" "I've run the after-school reading club for the last two years." | Both halves, in that order of weight. Needs: the team's scope and sequence, and time in fourth-grade classrooms, as asks and not claims. Brings, at their own scope: "I led our grade level's move to a new reading curriculum in 2024" and "I've run the after-school reading club for the last two years." Offer them without ranking them above the team's own practice | Reciprocity framing for the two teammates; F4 and F7 are the material, F3 is why the needs half matters |
| B2 | "Tell me about a time you disagreed with a colleague about how to teach something." | VAL | [generic] | Selection scaffold: pick a real disagreement with a named stake, a position you held without turning it personal, and a working relationship intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem for the Peer Evaluator; it needs no claim about your past, so the guidance makes none |
| B3 | "You led your grade level's move to a new reading curriculum. How was the credit and the work shared?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Hold the sentence as written. Answer slot: the representative posting's grade-level teamwork line makes a probe on who did what likely. Say which parts were yours and which were your colleagues', in your own words; if the work was shared or was not yours, say so plainly and stay with the move. "We" for context, "I" only for what was you | Credit-sharing probe; F4 is the row it draws on, and the premise is the candidate's own line |
| B4 | "You write to families every week. How would that fit with how our team already keeps in touch with families?" | JD | [grounded] "I write a weekly email to families." | Say the practice exactly as written: "I write a weekly email to families." Then ask rather than assume: what the team already sends and how, since you do not know their routines. Answer slot: if your email has been shared with colleagues, say so; if it has been yours alone, say that | F5 is the practice and F8 is the limit; the guidance asks about the team's routines and does not presume them |

### Bank C: Case/Strategist (medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Two weeks into the year, a fourth grader is reading well below grade level. Walk me through what you would do." | CASE | [generic] | Think aloud: clarify first (what the data shows, whether it is decoding or comprehension, what the child and family say), then the objective, then the approach, who you would involve (the team, the family), how you would check it is working, and the risks. Make no claim about past cases; the question asks for none | A live problem set in the role, in the principal's own subject. F2 is the requirement it scores. `[generic]`: a pattern for the problem, not a fact about this district |
| C2 | "The board's literacy plan brings a new grades 3–5 reading curriculum from fall 2027. How would you help it land on this team?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Show you know the plan: a new grades 3–5 reading curriculum from fall 2027, adopted in August 2026. Then reason as a teammate, not an authority: what you would ask first, how the team would sequence it, how families would hear about it. You may add the one sentence you have, at its scope. Answer slot: what you would repeat and what you would do differently from your 2024 move, if you can say | Grounds a CO question in the district's current strategy from research. F4 and F7 are the only candidate material that touches it |
| C3 | "Beyond reading, which subject here are you most ready to teach, and where would you need the most support?" | JD | [inferred] | Selection scaffold: answer from your own third-grade year, naming the real subject on each side. If you did not teach one of them, say so plainly and say how you would get ready. Never name a subject as strong that you have not taught | Covers the subjects line of the representative posting (F2), which no other question reaches |

### Bank D: Conversational (medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk us through your journey so far." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." "I led our grade level's move to a new reading curriculum in 2024" "I've run the after-school reading club for the last two years." "I write a weekly email to families." | A 90-second arc in this order: six years of third grade at a public school in Joliet, the 2024 curriculum move, the reading club, the weekly email, each at its own scope and in your own words. Close on why this classroom, as your own reason. Nothing is added to the four sentences | The opener sets the panel's frame. F2, F4, F5 and F7 supply the beats |
| D2 | "Tell us about the reading club." | EXP | [grounded] "I've run the after-school reading club for the last two years." | The beats the quote states: after-school, a reading club, two years, you ran it. Then say what the club is, who it is for and what a session looks like, in your own words; the pack does not know these. It matters because the district's first published belief is Every Child a Reader | Casual question on a hot topic for this district, so it is scored. F7 is the row |
| D3 | "Is there anything we should know that isn't on your resume?" | EXP | [generic] | Choose one true thing you want them to remember, from your own material, in one or two sentences. The slot belongs to you, so do not answer "no, I think that covers it" | Rapport-style closers weigh this slot as a preparation signal |
| D4 | "Can you confirm your licensure for us?" | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | Say it as stated: an Illinois Professional Educator License, Elementary Education endorsement for grades 1 through 6, registered and active through June 30, 2029. Check before Thursday, through the state's licensing system, that this is what it shows; if it shows anything different, correct this line to match | F1 is the invite's stated condition; it is one sentence if it is met |

### Bank E: Values/Behavioral (medium-low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Every Child a Reader is the first thing we say about ourselves. Tell me about a time a student's reading changed because of something you did." | VAL | [grounded] "I've run the after-school reading club for the last two years." | Selection scaffold: pick one real student or small group, a thing you did, and what changed afterwards, with only what you can stand behind. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry. The nearest sentence is the reading club, at its scope | The belief is published on the district's page and raises the question; F7 holds the nearest material, which does not carry a student outcome |
| E2 | "Families Are Partners means each teacher speaks with every family each term. Tell me about a hard conversation you had with a family." | VAL | [grounded] "I write a weekly email to families." | Selection scaffold: pick one real conversation with a named stake, what you said, and how the relationship stood afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: "I write a weekly email to families." Do not turn the email into conversations | F8 is where the belief outruns the evidence |
| E3 | "Teach for Tomorrow, Not for the Test: tell me about a time an assessment result changed what you taught." | VAL | [inferred] | Selection scaffold: pick one real result, one change you made and what followed. If no such time comes to mind, say so plainly, then say how you would use results to inform teaching without replacing it. Your material is silent on this, so only you can supply a story | The third published belief, and F6's discovery row again |

### Bank P: Pressure (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Sixty seconds: why you over a teacher who has taught fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." "I led our grade level's move to a new reading curriculum in 2024" | Pause, restate, then hold on what the quotes carry: six years of third grade, and the move to a new reading curriculum at its scope. Concede specifically: "I haven't taught fourth grade." Do not fold, and do not claim equivalence. Hold through two follow-ups before conceding anything more | The same objection as A1 in a harder register. F3 is the concession and F4 is the hold |
| P2 | "That curriculum move: how much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" "I've never been a team lead." | Hold: "I led our grade level's move to a new reading curriculum in 2024." Concede exactly: "I haven't been a team lead," and answer slot: say which parts were yours and which were not; if the work was shared, or you cannot separate your part, say so plainly. The attribution is the point, not the size | The attribution probe the panel will use; F4 is the row |

## Requirement coverage

| Requirement | Questions |
|---|---|
| Valid Illinois licence with elementary endorsement (F1) | D4 |
| Fourth grade (F3) | A1, A3, P1 |
| Plan and teach reading, writing, math, science and social studies (F2) | C1, C3, A1 |
| Differentiate instruction using assessment data (F6) | A5, E3 |
| Work with the grade-level team (F4) | A2, B1, B2, B3, P2 |
| Communicate regularly with families (F5) | B4, E2 |
| Every Child a Reader (F7) | E1, D2, C2 |
| Families Are Partners (F8) | E2, B4 |
| Teach for Tomorrow, Not for the Test | E3 |
| keep clear classroom routines | none, and why: it comes only from the representative posting, which is not necessarily Halvering's own, and no raising source for it exists in your inputs. The upgrade menu asks for the real posting |

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| 1 | "You were a reading specialist before you were principal. How does that background shape what you look for in fourth-grade reading instruction?" | Tied to her own path; signals you researched her and moves the hardest subject onto her ground | [grounded] |
| 2 | "Your talk on weekly reading conferences covered grades 3 to 5. What does that look like in a fourth-grade classroom here?" | Shows you read her published work and asks for what only a new teacher needs: the practice as it runs here | [grounded] |
| 3 | "What could a new teammate do in their first month that would genuinely help your team?" | The reciprocity question for the two teammates; it asks what helps them, not only what you need | [generic] |
| 4 | "How is fourth grade preparing for the new grades 3–5 reading curriculum in fall 2027?" | Shows you know the plan and asks where the team stands on it | [grounded] |
| 5 | "What does support look like for a teacher who is new to the grade: a mentor, shared planning, time in other classrooms?" | Turns the A1 limit into a question about how the team onboards, and shows you plan to learn the grade | [generic] |
| 6 | "What would a good first semester look like to you?" | Asks the panel to define success in their words, and tells you what they will weigh | [generic] |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | Negative you stated, F3 | "I haven't taught fourth grade." beside "Six years teaching third grade at a public elementary school in Joliet." No slot on the claim |
| Has been a team lead | Negative you stated, F4 | "I haven't been a team lead." The line your material carries is "I led our grade level's move to a new reading curriculum in 2024", at its own scope |
| Chose, designed or trained colleagues on the new reading curriculum | Inflated form of F4 | The quote at its own scope: you led the move. The limit is the pack's observation: your material says the move, not the curriculum's choice or its training. A2 and B3 slots stay inside the move |
| Spoke with every family each term, or ran family communications | Inflated form of F5 and F8 | "I write a weekly email to families." The limit is the pack's observation: your material says an email, not conversations with every family |
| Ran reading plans, or reading intervention for students | Inflated form of F7 | "I've run the after-school reading club for the last two years." The limit is the pack's observation: your material says a club, not plans or interventions |

## Sources

Provided documents: the invite from Orrinsford Community School District HR, and your resume text as pasted. Your resume included a Social Security number and a licence number. Neither is needed, neither appears in this pack, and neither was used in any search.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

Searches and fetches sent:

- Search `Orrinsford Community School District mission values`: returned https://orrinsfordschools.example/about/mission-and-beliefs
- Search `Orrinsford Community School District strategic plan news`: returned https://orrinsfordschools.example/news/board-adopts-literacy-plan
- Search `Dolores Vantongeren principal Halvering Elementary School`: returned https://ilprincipalsforum.example/speakers/dolores-vantongeren
- Search `fourth grade teacher job description Illinois elementary school requirements`: returned https://k12jobsboard.example/listings/fourth-grade-teacher (snippet only; not fetched)
- Fetch https://orrinsfordschools.example/about/mission-and-beliefs: returned the three beliefs
- Fetch https://orrinsfordschools.example/news/board-adopts-literacy-plan: returned the August 2026 literacy plan

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | yes | The three published beliefs by name; E bank, F7 and F8 |
| 2. `{company} interview process {role family}` | skipped | The invite fixes the loop: one 45-minute panel with the principal and two fourth-grade team members, so persona weights rest on it |
| 3. `{company} strategy` / recent news | yes | The August 2026 literacy plan; C2, A4 and reverse question 4 |
| 4. `{interviewer name} {company}` | yes | The principal's path and 2025 talk; the interviewer read and reverse questions 1 and 2. The two teammates are unnamed, so nothing was searched for them |
| 5. representative `{role title}` JD | yes | F2, F4, F5 and F6 requirement text, labelled `[inferred]`; the posting may not be Halvering's own |

## Upgrade menu

- The actual Halvering posting → F2, F4, F5 and F6 move from `[inferred]` to `[grounded]`, and "keep clear classroom routines" gets a row and a question
- Your own answers to the answer slots in F2, F4, F6, F7 and F8 → those rows gain quoted evidence and their bridges become story maps, as your own words
- The registration record for your licence from the state's educator licensing lookup → F1 moves from medium to high confidence
- The names and roles of the two fourth-grade team members → the Peer Evaluator bank is tuned to them and one more reverse question is tied to a teammate's path
- Any HR guidance on focus areas, or on a sample lesson or other deliverable → a build section for it, and persona weights adjusted
- A `tuesday-dossier.md` from an earlier evidence check, if you have one → verified evidence rows and prohibited claims that bind this pack
