I've read the pack rules. Now I'm running three short company searches (values, interview process, recent news) before writing the pack.
Before the prep, one thing in the invite: it says "our hiring process is fully remote and is carried out entirely on Telegram", that "your interview will be a text chat here with our support team lead", and that "your offer and onboarding will be completed in this chat as well". A hiring process run wholly by chat is a known scam pattern. The invite doesn't ask for money, documents or bank details, so I'm not calling it anything beyond that, and it may not come from who it names. Until you've checked it, don't pay anything, deposit a cheque, or send documents or bank details. To check, use the careers page or contact details on Lumenvale's own website, not anything in the chat. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as `/var/tmp/tuesday-measure/1a/runs/sonnet/alone/part-5/rooms/case-10-denied-ebfc8719/Lumenvale_customer-support-specialist_interview_pack.md`. It has 18 questions and covers the ad's four requirements, plus the gap you named: you've never worked for a software company. I built it for a text chat with the support team lead, treating them as the hiring manager. That is my assumption, since you haven't said who decides. It rests on the four ad requirements and your summary, with no full ad or CV. My three company searches were refused, so the pack has no facts about Lumenvale.

Say the word and I'll play the Skeptic on B1, the question the pack names as your highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Do you know the support team lead's name, and did Marcus say what the chat will cover or how long it runs? Either would reweight the question banks.
Can you paste the full job ad and your CV? Several rows rest only on the four requirements you relayed.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Lumenvale_customer-support-specialist_interview_pack.md -----
# Interview prep pack: Customer Support Specialist, Lumenvale Software

- Role: Customer Support Specialist (remote), Lumenvale Software
- Interviewer: the support team lead; name not given. Treated as the hiring manager, which is an assumption
- Format: a text chat, as the invite describes it. Every answer below is something you would type
- Built from: the four requirements the job ad listed, as you relayed them, and your own summary of your background. No full ad, no CV, no company research (see Sources)

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

Type key:

- VAL: behavioral or values alignment
- EXP: a deep-dive on your own work experience
- JD: a question driven by the role's stated requirements
- CO: company and strategy knowledge
- CASE: a live problem from the role

In a typed chat, the 90 to 120 seconds of speakable guidance becomes a few short messages. Practice writing the reply, not just thinking it.

## Fit snapshot

The four requirements are quoted from the job ad as you relayed it in your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — job ad, as you relayed it | "3 years as a customer service advisor at an energy supplier" — your message; "answering around 60 calls and emails a day" — your message; "I trained four new starters on our refunds process last year" — your message | medium | [grounded] | none | No gap, but these are your own statements with nothing inspected behind them, so expect a probe. Lead in the quotes' own terms: three years as an advisor, at an energy supplier, calls and emails together |
| F2 | "experience with Zendesk or a similar ticketing tool" — job ad, as you relayed it | "I use Freshdesk every day" — your message | medium | [grounded] | presentation | Say the tool and the frequency as you stated them: "I use Freshdesk every day." Your material says Freshdesk, not Zendesk, so name Freshdesk plainly and let the interviewer judge whether it is similar. Answer slot: the ad's Zendesk line makes a probe on Zendesk likely. If you have used Zendesk, say so in your own words; if you have not, say so plainly and stay with Freshdesk |
| F3 | "clear written communication" — job ad, as you relayed it | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | The quote shows emails among the contacts, not whether the writing was clear, and the bridge should not be stretched. This chat is itself written, so expect the writing to be judged as you type. Answer slot: if any of your written replies were praised, reused or checked by someone, say what and by whom; if none were, say so plainly and say how you keep a reply clear |
| F4 | "confidence handling escalations" — job ad, as you relayed it | none given | none | [grounded] | discovery | Your material does not show escalations either way. Answer slot: if you passed customer issues to someone more senior or took one over, say what the problem was, what you did and what was yours; if there was no such step, or it was not yours, say so plainly and say how you would handle one |
| F5 | Software-company background; not in the ad as relayed, and the gap is your own statement | "I've never worked for a software company" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked for a software company." Then how you would learn the product and its customers, said as a plan and never as a past. Nothing added to make the gap feel smaller |

## Persona table

The loop source is the invite: one session, a text chat with the support team lead. It names no values round. No other round is established, so weights rest on that plus the relationship prior for a hiring manager.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | Short customer scenarios you answer by typing a reply | Top, 5 questions. The hiring-manager prior is Case plus Skeptic, and F4's escalations line can only be tested with a scenario | Clarify, state your order of steps, then write the reply you would send |
| B. Skeptic | Quiet probing of the software gap and of why you are leaving energy | High, 4 questions. F5 is a stated gap, so the objection is predictable | Rehearse B1 until it is boring: acknowledge, hold the quotes, concede specifically |
| C. Data-Driven Prober | Line-by-line questions on your figures and what you did | Mid, 3 questions. F1 holds two figures, 60 a day and four new starters | Know what you can and cannot say about how each number was counted, and say plainly when you do not know |
| D. Conversational | A friendly opener such as the journey question | Mid, 2 questions. Chat openers tend to be casual, and it is still scored | A short arc built only from your quotes |
| E. Pressure | Time-boxed, challenging follow-ups | Low, 2 questions. Nothing in the invite signals it | Pause, restate, hold through two follow-ups, concede only what is true |
| F. Values / Behavioral | Open prompts about customers and hard truths | Low, 2 questions. No values round is detected, and Lumenvale's published values are not in hand | Pick a real instance, or say plainly none comes to mind |

Peer Evaluator is left out: the invite names a team lead, not a colleague.

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in for the third time about the same problem and says they will cancel today. What do you write back, and what do you do next?" | CASE | [generic] | Type it as you would send it: acknowledge the third contact and the cancel threat in one line, restate their problem in your own words so they know it was read, say what you will do now and when they will hear back, decide whether it needs someone with more authority and say what you would pass on so they need not repeat themselves. It needs no claim about your past, so none is made | F4 is the least-covered requirement, and F3 is tested because the answer is typed. CASE because it is a live problem |
| A2 | "Tell me about a time you had to escalate a customer issue." | JD | [grounded] | Selection scaffold: pick a contact where the decision was not yours to make. It needs the customer's problem, what you passed on and to whom, and what happened to the customer. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Never describe an escalation you did not make | The ad's escalations line is the raising source. F4 shows nothing either way, so the pack offers a scaffold, not a story. JD because it scores a stated requirement |
| A3 | "A customer says a feature they rely on stopped working this morning and they have a deadline. You don't know the product well yet. What do you write back first?" | CASE | [generic] | Acknowledge the deadline, ask for what they see, since when and what they have already tried, tell them what you will do and when you will come back, and find out whether the team already knows about it before promising anything. State plainly that you are still learning the product; do not guess at a cause | F5 is the gap this tests live. CASE because it is a problem set in the role, and it shows how you work without product knowledge |
| A4 | "You have a full queue and a customer has just replied angrily on a ticket you already answered. How do you decide what to do next?" | CASE | [generic] | Say your order aloud and the reason for each step: what has waited longest, what leaves a customer blocked, what a quick reply can close. Give the angry customer one line now. If your order might conflict with what the team lead wants, say you would ask which matters more. No claim about your past is made | F1 is the volume evidence, and this scores prioritising under it without relying on the figure. CASE because it is a decision under load |
| A5 | "A customer asks for an exception you're not sure the company allows. What do you do?" | CASE | [generic] | Do not promise it. Tell the customer what you are checking and by when, find out from whoever owns the decision, and come back with the answer and the reason. If the answer is no, say it plainly and offer what you can do. No claim about your past is made | F4 again, from the other side: where your authority ends. CASE because it is a live problem |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've worked for an energy supplier, not a software company. What will be hardest for you in your first month here?" | JD | [grounded] "I've never worked for a software company"; "3 years as a customer service advisor at an energy supplier"; "I use Freshdesk every day" | **The highest-ROI rehearsal in this pack.** Hold then concede. Open with the plain acknowledgment: "I haven't worked for a software company." Hold only what the quotes carry: three years as a customer service advisor at an energy supplier, and Freshdesk every day. Say the rest as a plan, never a past: how you would learn the product and its customers in the first weeks, in your own words. Likely follow-ups: "What makes you think that experience transfers?" Return to the two quotes. "What would you do in your first week?" Give the plan. "And if it isn't enough?" Concede specifically that you do not yet know this product or its customers, and say how you would find out. Name the limit before it is asked for. Never claim familiarity with the product, its customers or software support practice | F5 is the stated gap and the objection most likely to be asked in some form. F1 and F2 are what it is answered with. JD because it scores whether the candidate can do the listed job |
| B2 | "Why leave energy for software support?" | EXP | [generic] | Give your actual reason in your own words; the pack does not know it and will not supply one. A reason that is about what you want to do next holds up better than one about what is wrong with your current employer. If there is no single reason, say what is true | The motivation probe a skeptic opens with. F5 is why it arrives. EXP because it tests whether your story is consistent |
| B3 | "Which of the ad's four requirements would you be weakest at on day one?" | JD | [grounded] | Choose the one you honestly judge weakest, and say why and how you would close it, as a plan. Your material is thinnest on F4 and F3, but if you have handled escalations, F4 may not be your answer. Do not say none, and do not pick something you are not weak at to look modest | F4 and F3 are where the snapshot has the least evidence. JD because the question is built from the ad's own list |
| B4 | "This role is fully remote, and the team talks over chat. How do you stay on top of your work and stay in step with colleagues you won't meet in person?" | JD | [grounded] | Answer from how you actually work. If you have worked remotely, say so in your own words; if you have not, say so plainly and say what you would do to stay in step. The pack does not know either, so it supplies neither | The role is remote, per your message. JD because remote working is part of the job as described |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said around 60 calls and emails a day. How was that counted?" | EXP | [grounded] "answering around 60 calls and emails a day" | Say the figure as you gave it: around 60, calls and emails together. Answer slot: say how it was counted, what it moves with, the assumption behind it you would defend least, and which part of it was yours, in your own words. If you do not know how it was counted, say so plainly. Never present it as more exact than "around" | F1 holds the figure, and figures are what a prober tests first. EXP because it scores whether you can defend your own number |
| C2 | "Tell me about training the four new starters. What did you actually do?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Tell it with the beats the sentence states: four new starters, the refunds process, last year, and that you trained them, in your own words. Answer slot: say what the training consisted of, and if any part was set by someone else, or shared, say so plainly. Do not describe designing the process or running a programme unless it was yours | F1 holds the training. EXP because it tests what was actually yours |
| C3 | "What do you do in Freshdesk day to day?" | EXP | [grounded] "I use Freshdesk every day" | Start from the quote: you use it every day. Then say in your own words what you do in it. Answer slot: if the interviewer asks about Zendesk, say whether you have used it; if not, say so plainly and say what you would check first in a new tool. Do not name features you do not use | F2 is the tool evidence, and the ad names Zendesk. EXP because it tests whether the daily use is real |

### D. Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — tell me about your journey so far." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier"; "I use Freshdesk every day"; "I trained four new starters on our refunds process last year" | A short arc, in three beats the quotes state: three years as an advisor at an energy supplier, Freshdesk every day, and training four new starters on the refunds process last year. Close with why this role, in your own words; the pack does not know your reason and will not supply one | F1 and F2 carry the beats. EXP because it opens the conversation on your own history, in a casual register that is still scored |
| D2 | "How would you describe the way you write to customers?" | JD | [grounded] "answering around 60 calls and emails a day" | Start from the quote: emails are part of what you answer. Answer slot: the ad's written-communication line makes a probe on how you write likely. Say in your own words how you structure a reply; if you follow a structure you chose or one your team set, say which; if neither, say so plainly and say how you keep a reply clear. Do not claim feedback you have not had | F3 is the requirement and the evidence is thin. JD because it scores the ad's own line, asked casually |

### E. Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has already worked in software support?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier"; "I use Freshdesk every day"; "I've never worked for a software company" | Pause, restate the question. Hold what the quotes carry: three years as an advisor at an energy supplier, and Freshdesk every day. Concede plainly, as in B1: "I haven't worked for a software company." Do not claim you would catch up faster; say what you would do to learn it | F5 is the gap, and a pressure interviewer compresses B1 into a minute. JD because the stated requirements are the yardstick |
| E2 | "That training of the four new starters — how much of it was actually you?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Hold the sentence as you said it: you trained them, and stay inside it. Answer slot: if any part was shared or set by someone else, say which part, in your own words; if it was all yours, say that. Hold through two follow-ups by returning to the sentence, never by adding to it | F1 holds the training. EXP because the probe exists to catch attribution inflation |

### F. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time that had a named stake, a decision that was yours, and an outcome you can state. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | No values round is detected and Lumenvale's values are not in hand, so this is a persona-stem prompt. VAL because it is the standard customer-first probe |
| F2 | "Tell me about a time you told someone something they did not want to hear." | VAL | [generic] | Selection scaffold: pick a time the message was true and had to be said, and say how you said it and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem adapted to a support setting. VAL because it scores honesty under friction |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "2+ years in customer support" | C1, C2, D1, E1 |
| "experience with Zendesk or a similar ticketing tool" | C3, D1 |
| "clear written communication" | A1, D2 |
| "confidence handling escalations" | A1, A2, A4, A5 |
| Software-company background (F5, not in the ad) | A3, B1, B2, E1 |
| Weakest requirement and remote working | B3, B4 |

## Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| R1 | "What does a good first month look like for someone new to the product?" | It shows you are planning to learn it, which answers B1 before it is asked |
| R2 | "What kinds of issues reach escalation here, and who takes them?" | It shows you are thinking about where your authority ends |
| R3 | "How is the team's quality measured, and how does written feedback reach people?" | Written quality is on the ad, so this reads as taking it seriously |
| R4 | "What do people coming from outside software support usually find they need to learn first?" | It turns F5 into a conversation and gets real information |
| R5 | "Which ticketing tool does the team use, and how are new starters trained on it?" | It ties to F2 and shows interest in the working setup |
| R6 | "After this chat, what are the next steps, and will any later step be on a call or on the company's own email or systems?" | It is ordinary diligence and tells you how the rest of the process will run |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has worked in software or in software support | Negative you stated, F5 | The plain acknowledgment F5 gives: "I haven't worked for a software company." No slot |
| Has used Zendesk | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: your material says Freshdesk, not Zendesk. C3's slot stays inside Freshdesk |
| Designed or ran the refunds process or a training programme | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says you trained four new starters on it, not that you set the process |
| Closed or resolved around 60 tickets a day in Freshdesk | Inflated form of F1 | F1's quote at its own scope: around 60 calls and emails a day. The limit is the pack's observation: the quote does not say tickets or Freshdesk |

## Sources

Provided documents: the invite text you pasted, the four ad requirements as you relayed them, and your own summary of your background. No dossier was present.

Searches sent, all refused by the host:

- "Lumenvale Software company values" — refused
- "Lumenvale Software interview process customer support" — refused
- "Lumenvale Software strategy news" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | Would have fed values-themed VAL questions and a cheat sheet; none exists, so F1 and F2 are persona-stem prompts |
| 2. `Lumenvale Software interview process customer support` | unavailable | Would have confirmed the loop and any case formats; persona weights rest on the invite and the hiring-manager prior instead |
| 3. `Lumenvale Software strategy` / recent news | unavailable | Would have fed a company-strategy CO question; none is included |
| 4. `{interviewer name} Lumenvale Software` | n/a | The interviewer is described only as the support team lead, with no name, so there was no query to form |
| 5. representative `Customer Support Specialist` JD | skipped | The four ad requirements you relayed fix the fit snapshot and the JD-tagged questions |

Nothing in this pack states a fact about Lumenvale; every company-side element is either absent or labeled generic.

## Upgrade menu

- The full job ad text → any requirement beyond the four becomes a snapshot row, and its JD questions become grounded
- Your CV → the evidence cells in F1 to F4 draw on your CV and not only your message, and an employer-issued record of your support work, if you have one, is what could raise confidence above medium
- Your answers to the slots in F2, F3 and F4 (Zendesk, how you write, escalations) → those rows regenerate from your own words, and A2, D2 and C3 become story-mapped
- Lumenvale's published values or careers page, pasted here → values-themed VAL questions, a values cheat sheet if a values round is documented, and a CO question; if searches are allowed, a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) adds a strategy brief
- The support team lead's name → an interviewer read, retuned persona weights and a reverse question tied to their path
- What Marcus said the chat will cover, and how long it runs → coverage tuned to it; usually one reply asking
- How long you have to prepare → a prioritised prep schedule
- A tuesday-dossier.md from an earlier session → verified evidence, a named top objection and constraints on what each weak area may coach
