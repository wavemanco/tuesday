# Interview pack: Operations Coordinator, Quillmoor Diagnostics

Interviewer: Hannah Lowther, Talent Partner (recruiter screen). Thursday 2pm, a 30-minute phone call to your mobile. Built on her own stated agenda: salary expectations, notice period, how the hybrid pattern would work for you, what is prompting a move, then the team and next steps.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did. Where a cell says "answer slot", it is an instruction for the interview, not a question for now.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values (none banked here, see persona table) |
| EXP | Whether your claims survive scrutiny; what was actually you |
| JD | Whether you can do the listed job, gaps included, and the job's terms (pay, notice, location) |
| CO | Company and strategy knowledge |
| CASE | A live problem from the role, reasoned aloud |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots" — your message | medium | [grounded] | transferability | Your material says delivery scheduling across three depots; it does not show production scheduling or work with a QA team, and the words stay at the quote: "I schedule deliveries for our three depots." Answer slot: the advert's planning, warehouse and QA line makes a probe on who you worked with likely. If any of that scheduling meant working with other teams, say which and what you did, in your own words; if it did not, say so plainly and stay with the three depots |
| F2 | "track supplier deliveries and chase late orders" — advert | "chase suppliers when orders slip" — your message | medium | [grounded] | none | No gap on chasing. Lead with the quote's terms: you chase suppliers when orders slip. Your material has nothing on how late orders are noticed, so expect that probe. Answer slot: if you track deliveries in a particular way, say how, in your own words; if there is no such step, or it was not yours, say so plainly and return to chasing suppliers |
| F3 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | medium | [grounded] | none | The quote reaches the requirement, but it is a figure with nothing inspected behind it, so expect a defend-the-number probe. Your sentence sets the rebuild and the fall side by side and does not say one caused the other; say it as you said it. Answer slots: how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours; if you do not know how it was counted, say so plainly |
| F4 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material says nothing either way. Answer slot: the advert's weekly on-time dispatch line makes a probe likely. If you have reported on deliveries, say what and how often, in your own words; if you have not, say so plainly and stay with chasing suppliers when orders slip |
| F5 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | The quote reaches the requirement in its own terms; lead with it. Length of experience is a requirement, not a gate. A line from your message has nothing inspected behind it, so expect dates to be confirmed |
| F6 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet" — your message | low | [grounded] | discovery | The quote shows a spreadsheet and does not name the tool. Answer slot: if it was in Excel, say so and what you did in it, in your own words; if it was another tool, say which; if you used no Excel at all, say so plainly |
| F7 | "ERP experience (SAP or similar) a plus" — advert, the SAP half | "Never used SAP" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used SAP." Then how you would learn it, said as a plan and never as a past. The advert lists it as a plus. Nothing added to make the gap feel smaller |
| F8 | "ERP experience (SAP or similar) a plus" — advert, the "or similar" half | "we run our own in-house stock system" — your message | low | [inferred] | discovery | Your sentence names an in-house stock system and does not show whether it is an ERP or what you did in it. Answer slot: if you work in it to record or look up stock or orders, say what you do, in your own words; if you only read from it, or it is only a stock list, say so plainly |
| F9 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" — your message | high | [grounded] | none | A term you have stated you can meet. Say both halves as you said them: two days is fine, and three is your ceiling. The advert says two, so the ceiling is a limit to hold if the pattern is raised, not a thing to volunteer |
| F10 | "£38,000–£44,000" — advert | "I'm hoping for £42,000" — your message | high | [grounded] | none | A term you have stated, inside the advertised band. Keep it as "hoping", exactly as you said it |

## Persona table

Weights start from the recruiter-screen prior (Conversational plus a light Skeptic), adjusted by Hannah's own message, which names this one 30-minute call with her as the session and lists its agenda. No interviewer-signal adjustment was possible: her public footprint was not established, because the searches were refused (see Sources). No source documents a values round, so none is detected; Values and Peer are not banked.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder (A1 to A7) | Friendly, chatty; the four logistics questions and motivation arrive in this register | High: her message lists pay, notice, hybrid and reason for moving as the agenda, and the recruiter-screen prior is this persona | Treat casual questions as scored; say your own terms plainly, once, without hedging them away |
| Skeptic (B1 to B5) | Quiet probing of the gaps: SAP, manufacturer versus wholesaler, production and QA coordination, dispatch reporting | Medium: a light version fits a screen, and F1, F4, F7 and F8 are where your material is thinnest against the advert | Rehearse B2 until it is boring; hold at what you said, say plainly what you have not done, then give how you would learn it |
| Data-Driven Prober (C1 to C3) | Asks how the one-third was counted and what the spreadsheet and system actually were | Low to medium: a recruiter may check a headline number, and the hiring manager later will certainly | Know what you can and cannot say about how the figure was counted; say plainly when you do not know |
| Case / Strategist (D1, D2) | A short live problem on a late supplier or a stock mismatch | Low in this call: the advert's duties make these likelier with the hiring manager, so this is early rehearsal | Clarify first, then structure, then answer; think aloud |
| Pressure (E1, E2) | A sixty-second pitch or "how much was actually you" | Low: a friendly screen rarely applies pressure, but the second question follows from F3 | Hold the position through two follow-ups, concede only what is true |

## Question banks

### A. Conversational (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" "I schedule deliveries for our three depots" "chase suppliers when orders slip" "I rebuilt our stock-count spreadsheet" | Story-mapped on F5, F1, F2 and F3: the four years as a coordinator at a building-supplies wholesaler; scheduling deliveries for three depots; chasing suppliers when orders slip; the stock-count spreadsheet you rebuilt. Those are the beats, in your own words. Answer slot: anything before the four years is yours to add, only what you did | The opening biography question in a screen; EXP because it checks the CV story hangs together, which F5 supports |
| A2 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000" | Logistics slot, in your own words: "I'm hoping for £42,000." It sits inside the advertised band. Keep "hoping"; do not turn it into a minimum or a deadline. If she asks what you earn now, give your actual figure or say you would rather talk about this role's pay; the pack has no figure for it | Pay is first on her agenda; F10 holds your stated number; JD because it is the posting's term |
| A3 | "What's your notice period?" | JD | [grounded] | Logistics slot: give your actual notice period, taken from your contract. If you are not sure of the wording, say you will confirm it and say by when | Her agenda item; your material gives no notice period, so the honest answer is your own |
| A4 | "How would two days a week at Avonmouth work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | Say it as you said it: two days is fine, and three is your ceiling. If she asks about the journey or your arrangements, answer from your own actual situation; the pack has none | F9 is a term you have stated; JD because the advert sets the pattern. Her agenda names how the hybrid pattern would work for you |
| A5 | "What's prompting a move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Say it plainly from your own sentence: the Bristol office is closing next year, the only offer is relocating to Reading, and you do not want that. Answer slot: say what about this role draws you, in your own words; if nothing specific comes to mind, say so plainly and name the duties in the advert you would want to do | A recruiter checks motivation is consistent; the stated reason is what pushes you away, so the slot covers the pull toward this role. EXP because it is your own history |
| A6 | "What interests you about Quillmoor and this role?" | CO | [grounded] | Use the advert's own words: it describes coordinating production schedules between planning, the warehouse and QA, tracking supplier deliveries, stock records and weekly dispatch reporting. Say which of those you would most want to do and why, in your own words. No company research ran, so nothing beyond the advert is claimed here | CO at the level the advert supports; without research it cannot go deeper, and a generic answer is the risk |
| A7 | "What does a typical week look like in your job at the moment?" | EXP | [grounded] "I schedule deliveries for our three depots" "chase suppliers when orders slip" | Two beats, from your own sentence: scheduling deliveries for three depots, and chasing suppliers when orders slip. Answer slot: the advert's track-and-chase line makes a probe on how you spot a late order likely. If you do that in a particular way, say how; if there is no such step, or it was not yours, say so plainly and return to chasing suppliers when orders slip | F1 and F2 are the day-job evidence for the advert's core duties; EXP because it tests what is actually yours |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this advert would you be weakest at on day one?" | JD | [grounded] "Never used SAP" "we run our own in-house stock system" | Name it plainly: "I've never used SAP." Then your plan for learning it, said as a plan. Answer slot: if your in-house system gives you anything comparable, say what you do in it; if not, say so plainly and stay with the plan | The stem a Skeptic uses; F7 is a stated gap and F8 is where it may be bridged. JD because it scores the advert's ERP line |
| B2 | "The role coordinates production schedules between planning, the warehouse and QA. What have you done that's like that?" | JD | [grounded] "I schedule deliveries for our three depots" | The highest-ROI rehearsal in this pack. Hold at what the quote carries: "I schedule deliveries for our three depots." Answer slot: if any of that scheduling meant working with other teams, say which and what you did; if it did not, say so plainly and stay with the three depots. Hold through two follow-ups by returning to the depots, never by adding to them. Then say how you would learn the planning, warehouse and QA side, as a plan | F1 is the headline duty and the thinnest evidence against it, so this objection arrives in some form. JD because it scores a stated requirement |
| B3 | "Why a diagnostic-test manufacturer after four years at a wholesaler?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" | Anchor in the quote: four years as a logistics coordinator at a building-supplies wholesaler. Answer slot: say what about a manufacturer interests you, in your own words; if nothing specific, say so plainly and name the duties in the advert you want | Tests the sector change that A5's reason does not answer; F5 is what you bring |
| B4 | "Are you speaking to other employers at the moment?" | EXP | [generic] | Answer with your actual situation; the pack has nothing on it. Nothing invented about other offers or interviews | A standard screen question; included because the answer needs to be consistent with A5, whatever it is |
| B5 | "The role reports weekly on on-time dispatch — how would you go about that?" | JD | [grounded] "chase suppliers when orders slip" | Answer slot: if you have reported on deliveries, say what and how often; if you have not, say so plainly and stay with "chase suppliers when orders slip", then say how you would start, thinking aloud | F4 has no evidence either way, so the premise stays open. JD because it scores the advert's reporting line |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that one-third was counted." | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Say your sentence as it stands. Answer slots: how the figure was counted; what it is sensitive to; the assumption behind it you would defend least; which part was yours. If you do not know how it was counted, say so plainly | The defend-the-number question for F3, your one headline figure |
| C2 | "Tell me about the stock-count spreadsheet you rebuilt." | JD | [grounded] "I rebuilt our stock-count spreadsheet" | Say you rebuilt it. Answer slot: say which tool it was in and what you did in it, in your own words; if it was not Excel, say so and name the tool | F6 and the advert's Excel line; JD because it scores the stated skill |
| C3 | "Tell me about the in-house stock system you use." | JD | [grounded] "we run our own in-house stock system" | Say you run an in-house stock system. Answer slot: say what you do in it, in your own words; if you only look things up, or it is only a stock list, say so plainly | F8 against the advert's "SAP or similar"; JD because ERP is a listed plus |

### D. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A key supplier tells you on Monday that a delivery will be a week late, and QA needs the material for a batch due Friday. What do you do?" | CASE | [generic] | Clarify first: what is affected, what stock exists, who needs to know. State the objective, list your options, say who you would tell in planning, the warehouse and QA, and what you would record. Think aloud. The question asks about no past, so the guidance makes no claim | The advert's supplier and QA duties as a live decision; a pattern for the problem, not a fact about this employer |
| D2 | "Stock records say 120 units and the warehouse counts 104. How would you work out why?" | CASE | [generic] | Confirm the count, then check recent movements, timing of records against the count, and where the gap first appears. Say what you would fix and what you would report. Think aloud | The advert's stock-accuracy duty as a live problem; also lets F3's subject come up without a claim about your past |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you for this role?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" "I schedule deliveries for our three depots" "chase suppliers when orders slip" "I rebuilt our stock-count spreadsheet" "Never used SAP" | Pause, restate the question, then the beats the quotes carry: the four years, the depots, chasing suppliers, the stock-count spreadsheet. If challenged on SAP, concede plainly: "I've never used SAP." Hold the rest through two follow-ups | Hold-then-concede on F5, F1, F2, F3 and F7; JD because it scores fit to the advert |
| E2 | "That drop in discrepancies — how much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Hold on "I rebuilt our stock-count spreadsheet." Answer slot: say what else was going on over that year, if you know; if you do not know how much of the fall was down to the rebuild, say so plainly | The attribution probe on F3; EXP because it tests what was yours |

### Requirement coverage

| Advert requirement | Questions |
|---|---|
| Coordinate production schedules between planning, the warehouse and QA | B2, D1, E1 |
| Track supplier deliveries and chase late orders | A7, D1 |
| Keep stock records accurate | C1, C3, D2, E2 |
| Report weekly on on-time dispatch | B5 |
| 2+ years in operations or logistics coordination | A1, B3, E1 |
| Confident with Excel | C2 |
| ERP experience (SAP or similar) a plus | B1, C3 |
| Hybrid: two days a week at Avonmouth | A4 |
| £38,000–£44,000 | A2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What systems does the team work in day to day, and how is someone new brought up to speed on them?" | Asks about ramp-up on systems without asserting anything about your past; F7 is where the advert presses |
| R2 | "How is on-time dispatch measured today, and what does the weekly report look like?" | Shows you read the reporting duty; F4 has no evidence either way, so asking is honest |
| R3 | "How do planning, the warehouse and QA hand work to each other today, and where is the hardest handoff?" | Gets at the day-to-day reality of the F1 duty and shows you think about the seams |
| R4 | "How are the two Avonmouth days usually set — fixed days, or agreed with the team?" | Clarifies the pattern without volunteering flexibility beyond your stated ceiling (F9) |
| R5 | "What would success look like in the first three months?" | A standard question that shows you are thinking about results; generic by design |
| R6 | "Who would I meet next, and roughly when?" | She said she will cover next steps; this gets the people and timing |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has used SAP | Negative you stated, F7 | "I've never used SAP." No slot |
| Has ERP experience | Inflated form of F8 | F8's quote at its own scope: "we run our own in-house stock system." The pack's observation is that your material names a stock system and does not show it is an ERP. The slot stays inside what you do in that system |
| Coordinated production schedules across planning, the warehouse and QA | Inflated form of F1 | F1's quote at its own scope: "I schedule deliveries for our three depots." The pack's observation is that your material says delivery scheduling, not production scheduling |
| That your spreadsheet cut stock discrepancies by a third | Inflated form of F3 | Your sentence as it stands. The pack's observation is that it sets the rebuild and the fall side by side without saying one caused the other |
| Advanced Excel skills | Inflated form of F6 | F6's quote at its own scope: "I rebuilt our stock-count spreadsheet." The pack's observation is that the tool is not named; the slot asks only which tool it was |
| Flexible on office days | Contradicted by F9's quote | "I wouldn't want more than three" |
| £42,000 as a minimum | Inflated form of F10 | "I'm hoping for £42,000" |
| Leaving for growth or a new challenge | Contradicted by the reason you gave | Your own sentence: "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" |

## Sources

Provided documents: Hannah Lowther's LinkedIn message, the advert text, and your own notes. No dossier. No CV file; your message's description of your background supplied the evidence quotes.

Searches sent, all refused (no permission granted):

- "Quillmoor Diagnostics company values" — refused
- "Quillmoor Diagnostics interview process operations coordinator" — refused
- "Quillmoor Diagnostics Avonmouth news strategy" — refused
- "Hannah Lowther Talent Partner Quillmoor Diagnostics" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor values | unavailable | All four calls were refused. It would have moved published value names for VAL themes; none are claimed here |
| 2. Quillmoor interview process | unavailable | Refused. It would have moved later-round persona weights; this session's structure comes from Hannah's own message |
| 3. Quillmoor strategy and recent news | unavailable | Refused. It would have moved A6 from advert-only to something current; A6 stays generic |
| 4. Hannah Lowther at Quillmoor | unavailable | Refused. It would have supported an interviewer read and a reverse question tied to her path; both are absent |
| 5. Representative Operations Coordinator advert | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Permission for web search → published values, strategy and loop structure for Quillmoor, plus Hannah's public professional footprint for an interviewer read and a reverse question tied to her path. A deeper pass (up to 6 more searches and 2 more fetches, several more minutes) would add a strategy brief and later-round reports; offered once, here
- Your actual notice period → A3 can quote it in your own words
- What the stock-count spreadsheet was built in → F6 and C2 move from discovery toward a grounded Excel answer
- What you do in your in-house stock system → F8 and C3 become grounded, and the advert's "or similar" line gets a real answer
- Whether your delivery scheduling involves other teams → F1 and B2 get a stronger hold
- Whether you report on deliveries today → F4 and B5 move from an open slot to a grounded answer
- The stock-count spreadsheet or discrepancy log itself, or any record of the one-third → F3 confidence rises from medium to high
- A tuesday-dossier.md from an earlier evidence review → verified evidence and a sourced objection list in place of the objection inferred here
