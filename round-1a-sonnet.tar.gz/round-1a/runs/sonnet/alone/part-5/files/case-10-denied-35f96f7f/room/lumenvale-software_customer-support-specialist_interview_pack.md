# Interview prep pack: Customer Support Specialist, Lumenvale Software

Candidate: Imani. Round: a text chat on Telegram with the support team lead, as the invite describes it. Relationship assumed: the person who would lead the team you join, so hiring-manager style. Research tier: no web research ran (searches were refused), so company facts are absent rather than guessed.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding, not a script: say things in your own words, and say only what you actually did.

Type key:

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the values the company publishes |
| EXP | Whether your background claims hold up under follow-up |
| JD | Whether you can do the listed job, gaps included |
| CO | How well you know the company and its product |
| CASE | How you structure a live problem from the role |

Where guidance says "answer slot", it is an instruction for the interview, not a question for you now: give whichever branch is true for you. Where it says "plan", it is what you would do, never what you did.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — job ad, as you listed it | "3 years as a customer service advisor at an energy supplier" — your message | medium | [grounded] | none | No gap, but a line from your message with nothing inspected behind it, so expect a probe. Lead with it in its own terms: the three years, the role, the energy supplier |
| F2 | "experience with Zendesk or a similar ticketing tool" — job ad, as you listed it | "I use Freshdesk every day" — your message | medium | [grounded] | none | The quote names Freshdesk, not Zendesk, and the ad says Zendesk or a similar tool. Say Freshdesk, say every day, and do not describe features or reports your message does not mention. Expect "what do you actually do in it" |
| F3 | "clear written communication" — job ad, as you listed it | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | The quote shows emails answered, not how the writing was judged. Answer slot: the ad's written-communication line makes a probe on your emails likely. If any of your written replies were checked, scored or praised, say by whom and what was said; if none were, say so plainly and stay with the calls and emails you answered |
| F4 | "confidence handling escalations" — job ad, as you listed it | none given | none | [grounded] | discovery | Your material does not show escalations either way. Answer slot: the ad's escalation line makes a probe likely. If you handled cases that went beyond what you could resolve, say what happened and what part was yours; if there were none, or they were not yours, say so plainly and stay with the calls and emails you answered |
| F5 | Familiarity with a software company's product and customers — role-family expectation, no source quoted | "I've never worked for a software company" — your message | none | [generic] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked for a software company." Then how you would learn the product, said as a plan and never as a past |
| F6 | No requirement in the ad speaks to training others — role-family expectation, no source quoted | "I trained four new starters on our refunds process last year" — your message | medium | [generic] | none | An extra strength. Keep it at its scope: four new starters, the refunds process, last year. It does not say you ran a training programme or wrote materials |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live customer scenarios typed into the chat, including a reply you write on the spot | High. The invite says a support team lead runs the chat, and a lead for a support team has live cases to test. In a text chat your writing is also what they read | Clarify first, then answer in order: acknowledge, next step, timing, what you need. Bank A |
| Skeptic | Quiet probing of the software gap, escalations and the Freshdesk-to-Zendesk step | High. F5 is a stated gap, F4 is silent, F2 is not Zendesk | Rehearse B1 until it is boring: plain acknowledgment from F5, adjacent evidence from F1 and F2 at their own scope, then a plan. Bank B |
| Conversational / Rapport | Friendly openers: walk me through your journey, what is a day like | Medium. A chat opens with small talk, and casual questions are still scored | Short arc built from F1 and F6 quotes only; the motivation is an answer slot. Bank C |
| Data-Driven Prober | Asks how "around 60 a day" was counted | Medium. It is your one figure | Say what you know of how it was counted and say plainly what you do not. Bank D |
| Values / Behavioral | Tell me about a time you put a customer first | Low to medium. No published values or documented loop were read, so these rest on the persona stems only | Selection scaffolds with an honest fallback. Bank E |
| Pressure | Time-boxed challenge on why you, with no software background | Low. A text chat gives less room for interruption | Hold your quoted position through two follow-ups, then concede the gap plainly. Bank F |

The weights rest on the invite's own description of the process, one text chat with the team lead. If that changes, the weights change.

## Question banks

### Bank A: Case / Strategist (weight highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in for the third time about the same unresolved problem and is clearly angry. What is your next reply, and what do you do behind the scenes?" | CASE | [generic] | Structure it aloud: what you would check first in the case history, a reply that acknowledges the repeat contact, names the next step and a time, and what you would record. Say when you would hand it to someone else and why. The question needs no claim about your past, so the guidance makes none | Live problem from F4's requirement, asked as a decision; [generic] because it is a pattern, not a fact about this employer |
| A2 | "A customer says something stopped working after an update, and you do not know our product yet. What do you do in your first ten minutes?" | CASE | [generic] | Clarify the symptom, check what is already written down, ask a colleague, tell the customer what you know and when you will come back. Do not guess an answer you cannot back. No claim about your past | Tests the F5 gap directly as a live problem rather than a history question |
| A3 | "Tell me about a time you handled an escalation." | JD | [grounded] | Open prompt from the ad's escalation line. Selection scaffold: pick a case that went beyond what you could resolve; it needs what you did, who it went to, and what happened next. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4 is silent, so this question is the one most likely to arrive in some form |
| A4 | "The ad mentions Zendesk or a similar tool. You use Freshdesk. How would you get up to speed on whatever we use?" | JD | [grounded] "I use Freshdesk every day" | Say the quote in your own words: Freshdesk, every day. Then a plan, never a past: what you would open first, who you would ask, how you would check you had it right. Do not claim Zendesk | F2 reaches the requirement through a similar tool, and the interviewer will test the step to theirs |
| A5 | "Write me the reply you would send: a customer was charged twice and wants the money back today." | JD | [generic] | The chat is the test. Short and plain: acknowledge, say what you will do and by when, say what you need from them. Do not promise a refund you cannot authorise; say what happens next instead. No claim about your past | Scores the ad's written-communication line live, which F3's quote cannot show |

### Bank B: Skeptic (weight high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have never worked for a software company. Why will this be different?" | JD | [grounded] "I've never worked for a software company" | The highest-ROI prep in this pack. Step one, the plain acknowledgment: "I've never worked for a software company." Step two, only what your quotes carry, in your own words: "3 years as a customer service advisor at an energy supplier" and "I use Freshdesk every day". Step three, a plan for learning the product, said as a plan. Follow-up one, "what would be hardest?": name the product knowledge itself and what you would do about it. Follow-up two, "how do you know it carries over?": say you do not know yet, and say how you would find out. Follow-up three, "so why you?": return to the two quotes, add nothing | F5 is the biggest stated gap and the objection is aimed at it; the likeliest question in this loop |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company" | Pick the one you honestly think it is. Your material shows no software-company experience and does not show escalations or Zendesk use, so any of the three is a defensible answer if it is true for you. Name it, then the plan to close it | Standard Skeptic stem; calibrated candour beats a bluffed strength |
| B3 | "Why move from energy to software support?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" | Your real reason, in your own words. Nothing in your material states one, so this is a motivation slot: give your actual reason. Keep the three years and the role at their stated scope | A motivation-consistency probe on the F1 background |
| B4 | "What do you do when a customer asks something you do not know the answer to?" | JD | [generic] | Check what is written down, ask a colleague, tell the customer you will come back with a time, and do not guess. As a method, not a claim about your past | Tests the F5 gap and confidence at once |
| B5 | "You use Freshdesk. Have you used Zendesk?" | JD | [grounded] "I use Freshdesk every day" | Answer slot: if you have used Zendesk, say where and for what, in your own words; if not, say so plainly and return to "I use Freshdesk every day" | F2's quote names Freshdesk only |

### Bank C: Conversational / Rapport (weight medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey. How did you get into customer service, and what brought you here?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier"; "I trained four new starters on our refunds process last year" | A short arc with only these beats: the three years in the role at the energy supplier, and training four new starters on the refunds process last year. The reason you want this job is a motivation slot: give your actual reason in your own words | F1 and F6 are the two quotes an arc can stand on |
| C2 | "What does a typical day look like for you now?" | EXP | [grounded] "answering around 60 calls and emails a day"; "I use Freshdesk every day" | Use these two quotes in their own terms and stop. Anything about how a day is organised is yours to say only if it is true | F1, F2 and F3 are all in a day, so this is where they are likely to be probed |
| C3 | "Have you had a look at what we do? What stood out?" | CO | [generic] | Answer slot: say what you actually looked at; if you looked at nothing yet, say so plainly and ask them a question about the product. Look at the company's own website before the chat, reached on your own rather than through the chat | No company research could run, so this question cannot be answered for you |

### Bank D: Data-Driven Prober (weight medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You said around 60 calls and emails a day. How was that counted?" | EXP | [grounded] "answering around 60 calls and emails a day" | Say the figure with its own hedge, "around". Answer slots: how it was counted; what it moves with; the assumption you would defend least; which part was yours. If you do not know how it was counted, say so plainly | F3's only figure, so a defend-the-number question |
| D2 | "Tell me about training the four new starters." | EXP | [grounded] "I trained four new starters on our refunds process last year" | Tell it with the beats the sentence states: four new starters, the refunds process, last year. Tell it in your own words and say only what you did | F6 is a likely follow-up on the CV-style summary |
| D3 | "Talk me through how you would write up a case so a colleague could pick it up." | JD | [generic] | A method: what happened, what has been done, what is outstanding, what the customer was told. No claim about your past | The ad's written-communication line as a work-product question |

### Bank E: Values / Behavioral (weight low to medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you put a customer ahead of an internal target." | VAL | [generic] | Open prompt. Selection scaffold: a named situation, the choice you made, what it cost, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem; no company values were read |
| E2 | "Tell me about a time you told a customer something they did not want to hear." | VAL | [generic] | Open prompt. The same scaffold: what they wanted, what you said, how they took it. Same honest fallback | A common support probe, asked casually |

### Bank F: Pressure (weight low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you, with no software background?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier"; "I use Freshdesk every day"; "I've never worked for a software company" | Hold the two experience quotes through two follow-ups, in your own words. Then concede the gap plainly: "I've never worked for a software company." Do not fold on the experience to restore harmony | B1 under time pressure |
| F2 | "That figure, around 60 a day. How much of it was actually you?" | EXP | [grounded] "answering around 60 calls and emails a day" | Hold what the quote says. Answer slot: if any of those were shared or passed on, say which part was yours; if all were yours, say so plainly | The attribution probe on F3's figure |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| 2+ years in customer support (F1) | B3, C1, C2, F1 |
| Zendesk or a similar ticketing tool (F2) | A4, B5, C2 |
| Clear written communication (F3) | A1, A5, D1, D3 |
| Confidence handling escalations (F4) | A1, A2, A3, B4 |
| Software-company familiarity (F5, not in the ad) | A2, B1, B2, F1 |

There is no CO question grounded in Lumenvale's strategy, because no research ran. C3 is the only CO row and is an answer slot.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good first month look like for someone new to the product?" | It shows you are planning your ramp, which answers B1 before it is asked |
| R2 | "Which cases reach you as team lead, and what does a good escalation note look like?" | It shows you think about handoffs from the receiving side |
| R3 | "How is the team's work reviewed: replies, response times, customer feedback?" | It shows you want your writing checked, which supports F3 |
| R4 | "Which ticketing tool does the team use, and how is it taught?" | It is a practical question about the F2 step, and the answer tells you what to look at beforehand |
| R5 | "How does the team cover hours and handovers when everyone is remote?" | A practical question that shows you are thinking about how the work runs |
| R6 | "What are the next steps after this chat, and will a later one be on a call or video with a named colleague?" | A normal process question, and the answer tells you whether you can speak to a person at the company |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has used Zendesk | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: your material says Freshdesk, not Zendesk. B5's slot stays inside what you have used |
| Handled 60 tickets a day in a ticketing system | Inflated form of F3 | F3's quote at its own scope: "answering around 60 calls and emails a day" |
| Ran or designed a training programme | Inflated form of F6 | F6's quote at its own scope: four new starters, the refunds process, last year |
| Has worked for a software company or supported software customers | Negative you stated, F5 | The plain acknowledgment F5 gives: "I've never worked for a software company." No slot |

## Sources

Provided documents: the invite as you pasted it, the ad's four requirements as you listed them, and your background as you described it. No dossier was provided.

Searches sent, all refused:

- "Lumenvale Software company values" — refused
- "Lumenvale Software interview process customer support specialist" — refused
- "Lumenvale Software careers recruitment Telegram" — refused

No pages were fetched.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | The search was refused. It would have supplied published values for a values sheet; none was read |
| 2. `Lumenvale Software interview process customer support` | unavailable | The search was refused. It would have supplied documented rounds; the loop rests on the invite's own description |
| 3. `Lumenvale Software strategy` / recent news | unavailable | No search was sent after the refusals. It would have supplied CO questions |
| 4. interviewer name and company | n/a | The support team lead is not named, so there was no query to form; the sender's name is not the interviewer's |
| 5. representative Customer Support Specialist JD | skipped | The ad's requirements you listed fix the fit snapshot and the JD-tagged questions |
| Outside the declared targets: `Lumenvale Software careers recruitment Telegram` | unavailable | Refused; it would have shown whether the company's own pages describe this process |

## Upgrade menu

- The full job ad text → F1 to F4 quote the ad's own wording, and any mid-list requirement gets a question
- Your answers to the slots: any escalation you handled (F4), whether you have used Zendesk (B5), what the 60 a day figure covers (D1) → those rows move from discovery to graded evidence
- An anonymised written reply or a quality-check or customer-feedback report from your current role, if you have one → F3 can move from low toward high
- Text from Lumenvale's own website, reached on your own → grounded CO questions and a product vocabulary section
- A deeper research pass, up to 6 more searches and 2 more fetches, several more minutes, if search is permitted → strategy, loop reports and values
- The sender's confirmed role and any recruiter guidance, once verified through the company's own channels → persona weights keyed to the real round
- Your prep time → a prioritised schedule
- A `tuesday-dossier.md` from an earlier evidence check → an evidence-derived top objection and a sourced prohibited list
