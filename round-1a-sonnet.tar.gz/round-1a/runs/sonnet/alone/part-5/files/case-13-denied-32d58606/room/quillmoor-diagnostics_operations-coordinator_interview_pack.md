# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** recruiter screen, a 30-minute phone call, Thursday 2pm
**Interviewer:** Hannah Lowther, Talent Partner. She will ring the mobile number on your application.
**Her stated agenda (her message):** salary expectations, notice period, how the hybrid pattern would work for you, and what's prompting a move. Then she tells you about the team and the next steps.

## How to use this pack

- **Personas describe how a question arrives; types describe what it is scoring.** Each question carries one of each, so you can see the pack's coverage at a glance.
- **Type key:**
  - VAL: whether past behaviour shows the company's published values.
  - EXP: whether the claims in your background survive scrutiny, and what was actually you.
  - JD: whether you can do the listed job, gaps included.
  - CO: how well you know the company and its strategy.
  - CASE: a live problem from the role, scored on structure and reasoning.
- **Guidance is scaffolding, not a script.** Say it in your own words. Where a cell says "answer slot", it is an instruction for the interview: answer from what you actually did, or say plainly that the step was not yours or did not exist.
- **Provenance:** `[grounded]` rests on something you or the advert supplied, `[inferred]` is this pack's derivation, and `[generic]` is a pattern with no claim about you or Quillmoor. Where guidance rests on your words, they are quoted beside the label.
- **Built on this assumption:** web research was refused when I tried it, so nothing here is drawn from Quillmoor's own site or the web. It is built from the advert, your background and Hannah's message alone.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — JD | "I schedule deliveries for our three depots" — your message | medium | [grounded] | transferability | Your material says delivery scheduling across three depots, not production scheduling, and the words stay there: "I schedule deliveries for our three depots." Answer slot: the JD names planning, the warehouse and QA, so expect a probe on who your scheduling works with. If any of it involved coordinating with functions like those, say which and how, in your own words; if not, or if it was not yours, say so plainly and stay with the depots |
| F2 | "chase late orders" — JD | "chase suppliers when orders slip" — your message | medium | [grounded] | none | No gap on the chasing, but a self-reported line with nothing inspected behind it, so expect a probe on it. Lead in the quote's own terms: you chase suppliers when orders slip |
| F3 | "track supplier deliveries" — JD | none given | none | [grounded] | discovery | Your material does not show how supplier deliveries are followed before they slip. Answer slot: if you follow them in some way, say how, in your own words; if you act only once an order has slipped, or someone else tracks them, say so plainly and stay with the chasing |
| F4 | "keep stock records accurate" — JD | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | medium | [grounded] | none | The quote already reaches the requirement: the record, and the result. Keep "about a third over a year" exactly as you said it. The figure raises the defend-the-number slots: how discrepancies were counted, what the figure is sensitive to, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so plainly |
| F5 | "report weekly on on-time dispatch" — JD | none given | none | [grounded] | discovery | Your material does not show any regular reporting. Answer slot: if you produce any regular report on deliveries, say what it covers and how often, in your own words; if you do not, say so plainly and stay with what you schedule |
| F6 | "2+ years in operations or logistics coordination" — JD | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | The quote reaches the requirement in role-relevant terms. A self-reported line with nothing inspected behind it; state it plainly, as you gave it |
| F7 | "confident with Excel" — JD | "I rebuilt our stock-count spreadsheet" — your message | low | [inferred] | discovery | The quote says a spreadsheet, not which tool. Answer slot: if it was Excel, say so and say what you did in it, in your own words; if it was another tool, say so plainly and say what you have used |
| F8 | "ERP experience (SAP or similar) a plus" — JD | "Never used SAP" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used SAP." Then how you would learn it, said as a plan and never as a past. The advert marks it a plus |
| F9 | "ERP experience (SAP or similar) a plus" — JD | "we run our own in-house stock system" — your message | low | [inferred] | discovery | Your material says your employer runs the system, not that you work in it or that it is an ERP. Answer slot: if you work in it yourself, say what you do in it, in your own words; if you do not, or it is not an ERP, say so plainly |
| F10 | "£38,000–£44,000" — JD | "I'm hoping for £42,000" — your message | high | [grounded] | none | Inside the advert's band, as the pack's observation. The words are yours, at the scope you gave them: hoping for £42,000. A hope is not a floor, and the pack does not turn it into one |
| F11 | "two days a week at our Avonmouth site in Bristol" — JD | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" — your message | high | [grounded] | none | Your stated limit sits above the advert's two days, and no conflict shows. Keep "wouldn't want" as the preference you stated it to be |
| F12 | "what's prompting a move" — Hannah Lowther's message | "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" — your message | medium | [grounded] | none | A clear reason in your own words, and a self-reported one with nothing inspected behind it. Say it as you gave it and stop |

## Persona table

The loop here is one session: Hannah's message establishes a single 30-minute phone call with her. No source I could read describes later rounds, so the weights rest on her stated agenda and the recruiter-screen prior, and nothing is assumed about the rest of the process.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational (bank A) | A friendly phone call that works through her listed items: pay, notice, hybrid, reason for moving | High. Her message lists these four items herself, and the recruiter-screen prior is Conversational first | Answer each logistics item from your own facts in your own words; prepare a 90-second arc built on your quoted sentences (A5) |
| Skeptic (bank B) | Quiet probing of why you are leaving and where your background differs from the advert | Medium. "What's prompting a move" is hers to ask, and F1 and F8 are the gaps she can reach if she asks about fit; light because her agenda lists no skills probe | Rehearse B2 until it is boring: hold what your sentences carry, concede the limit specifically |
| Data-Driven Prober (bank C) | A recruiter checking one number or one claim on the CV | Low to medium. She has not said she will go through your background line by line, and the stock-count figure is the only number in it | Know what you can and cannot say about how the figure was counted, and say plainly where you do not know |
| Case / Strategist (bank D) | One short live problem from the role | Low. Not on her stated agenda; kept so the style is not new if it arrives, in this call or later | Clarify, then structure, then answer; think aloud |
| Pressure (bank E) | A brisk "why you" or "how much was you" challenge | Lowest. Nothing in her message signals it; kept as insurance on the two spots your material is thinnest | Pause, restate, hold through two follow-ups, concede specifically |

## Question banks

Highest-ROI prep in this pack: **B2**, the question that sets your delivery-scheduling background against the advert's production-scheduling duty. It is the first duty the advert lists and the one your material reaches least directly, so it arrives in some form.

### A. Conversational (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What salary are you looking for?" | JD | [grounded] "I'm hoping for £42,000" | Logistics slot. Give your own number, in your own words, at the scope you gave it: you are hoping for £42,000. The alternative is to ask for the role's band first. Say nothing about your current pay unless you choose to | F10 is the pay row, and Hannah named salary expectations in her agenda. JD because the advert states a band |
| A2 | "What's your notice period?" | JD | [grounded] | Logistics slot. Give your actual notice period, as your contract has it. If you do not know it exactly, say so and say you will confirm it | Hannah named notice period in her agenda. The material here does not state it, so the guidance supplies no figure |
| A3 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | Logistics slot. Say it as you gave it: two days at Avonmouth is fine, and you wouldn't want more than three. Keep the second half as a preference, as you stated it | F11 is the location row, and Hannah named the hybrid pattern. JD because the advert sets two days |
| A4 | "What's prompting a move?" | EXP | [grounded] "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Logistics slot. Give the reason as you gave it: the Bristol office is closing next year, and the only offer is relocating to Reading, which you don't want. Then stop; add no complaint, and describe nothing about your employer beyond what you said | F12 is the reason-for-leaving row, and Hannah named it. EXP because it tests whether your account stays consistent |
| A5 | "So — walk me through the journey." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler", "I schedule deliveries for our three depots and chase suppliers when orders slip", "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Story-mapped on F6, F1, F2 and F4, in this order: four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots; chasing suppliers when orders slip; rebuilding the stock-count spreadsheet, with discrepancies falling by about a third over a year. Tell each beat in your own words and add nothing between them. Ninety seconds, then hand the conversation back | The open biography question is the most likely opener on a phone screen, and the beats are the ones your sentences state. EXP because it tests the account |
| A6 | "Any exposure to SAP or anything like it?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | Say it plainly: "I've never used SAP." Then your in-house system, at its own scope: your company runs its own in-house stock system. Answer slot: if you work in it yourself, say what you do in it, in your own words; if you do not, or it is not an ERP, say so plainly | F8 and F9 are the ERP rows. JD because the advert lists ERP as a plus |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | Selection scaffold: pick the part you would actually feel weakest at, not the part that sounds safest. If it is SAP, the words are yours: "I've never used SAP." Then say how you would learn it, as a plan and not a past. If no single part comes to mind, say so plainly, then give the nearest thing your material does carry | A standard Skeptic stem, aimed at F8, the one gap you have stated yourself. JD because it scores the listed requirements |
| B2 | "The advert asks you to coordinate production schedules between planning, the warehouse and QA. Your background is scheduling deliveries. What would you need to learn?" | JD | [grounded] "I schedule deliveries for our three depots" | Highest-ROI rehearsal. Level 1: hold what the sentence carries: "I schedule deliveries for our three depots." Level 2, after "that's not the same thing": agree that the advert's work is production scheduling and your sentence says deliveries; do not add anything to the sentence. Answer slot: if any of your scheduling involved coordinating with functions like planning, the warehouse or QA, say which and how; if not, or if it was not yours, say so plainly and return to the depots. Level 3, "so how would you get up to speed?": a plan, never a past: what you would ask first about how the schedules are built here, and who you would ask. Hold through the two follow-ups by returning to the depots, never by adding to them | F1 is where the advert's first duty presses against your material. JD because it scores a listed requirement; the premise about your background is limited to what F1's quote says |
| B3 | "What makes this role the one you want, rather than the move to Reading?" | EXP | [grounded] "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want", "I live in north Bristol" | Hold your reason as the quote carries it: the office is closing next year, and the only offer is relocating to Reading, which you don't want. Answer slot: if something in this role draws you beyond that, say what it is, in your own words; if the closure is the whole prompt, say so plainly, then name the duties in the advert you would be doing, such as the chasing of late orders. Never criticise your employer beyond what you said | The Skeptic's motivation probe: why leave, why here. F12 is the reason; the question's premise comes only from that row's quote. EXP because it tests consistency |
| B4 | "The advert wants someone confident with Excel. How confident, and with what?" | JD | [inferred] "I rebuilt our stock-count spreadsheet" | Start from the sentence: you rebuilt your stock-count spreadsheet. Answer slot: if it was Excel, say so and say what you did in it, in your own words; if it was another tool, say so plainly and say what you have used. Do not rate yourself with an adjective you cannot back with a named task | F7 is the Excel row. JD because the advert lists it; `[inferred]` because the quote does not name the tool |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that fall in discrepancies was counted." | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Answer slot. Say how discrepancies were counted, in your own words, and keep the figure at "about a third over a year". If you do not know exactly how it was counted, say so plainly and say what you do know | F4 carries the only number in your material, so it is the likeliest to be probed. EXP because it tests whether the figure survives |
| C2 | "Which assumption behind that figure would you defend least?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Name, before she does, the assumption you would defend least, in your own words. If you cannot name one, say so plainly. Do not pick an assumption you do not actually hold doubts about | The weakest-assumption move for F4; it turns a probe into a credibility gain. EXP because it tests honesty about the number |
| C3 | "The role tracks supplier deliveries. How do you keep on top of them?" | JD | [grounded] "chase suppliers when orders slip" | Start from the sentence: you chase suppliers when orders slip. Answer slot: if you follow supplier deliveries before they slip, say how, in your own words; if you act once an order has slipped, or someone else tracks them, say so plainly and stay with the chasing | F2 and F3 are the supplier rows, and the advert names tracking. The question's premise comes from the advert, not from your sentence |
| C4 | "The role reports weekly on on-time dispatch. What do you report on now?" | JD | [grounded] "I schedule deliveries for our three depots" | Answer slot. If you produce any regular report on deliveries, say what it covers and how often, in your own words; if you do not, say so plainly, then return to what you schedule: "I schedule deliveries for our three depots." Do not describe a report you do not produce | F5 is the weekly-reporting row, which no sentence of yours reaches. JD because the advert lists it |

### D. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A supplier tells you on Monday that a delivery the production schedule depends on will be a week late. What do you do?" | CASE | [generic] | Structure it aloud: what you would ask first (what is due, who is waiting, how late, whether any of it can come early); the objective; who you would tell and when, with planning, the warehouse and QA the three teams the advert names; what you would record; how you would follow up. The question needs no claim about your past, so the guidance makes none | A live problem built from the advert's duties on production schedules and supplier chasing (F1, F2). `[generic]` because it is a pattern for the problem, not a fact about this employer |
| D2 | "The stock record and the physical count disagree on a line that is due out this morning. Where do you start?" | CASE | [generic] | Structure it aloud: what you would check first, what you would do about this morning's dispatch, how you would record the difference, and what you would look at afterwards. Make no claim about having done this before | A live problem from the advert's stock-records duty (F4). `[generic]` for the same reason as D1 |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who already knows SAP?" | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler", "I schedule deliveries for our three depots and chase suppliers when orders slip", "Never used SAP — we run our own in-house stock system" | Hold-then-concede. Pause and restate. Hold what your sentences carry: four years as a logistics coordinator, scheduling deliveries for three depots, chasing suppliers when orders slip. Through two follow-ups, return to those sentences; never add to them. Concede specifically: "I've never used SAP." Then a plan for learning it, never a past | F8 is the stated gap a pressure interviewer goes straight to. EXP because it tests what you hold and what you concede |
| E2 | "That drop in discrepancies — how much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Hold-then-concede. The part that is yours is the sentence: you rebuilt your stock-count spreadsheet. Answer slot: if you can say what else bore on the fall, say it in your own words; if you cannot separate the spreadsheet from anything else, say so plainly and return to the sentence. Concede that exactly, and no more | F4's number is the one a pressure interviewer tests for attribution. EXP because it scores precise attribution |

### Requirement coverage

| Requirement (source) | Covered by |
|---|---|
| "Coordinate production schedules between planning, the warehouse and QA" — JD | B1, B2, D1 |
| "track supplier deliveries" — JD | C3 |
| "chase late orders" — JD | A5, C3, D1 |
| "keep stock records accurate" — JD | A5, C1, C2, D2, E2 |
| "report weekly on on-time dispatch" — JD | C4 |
| "2+ years in operations or logistics coordination" — JD | A5, E1 |
| "confident with Excel" — JD | B4 |
| "ERP experience (SAP or similar) a plus" — JD | A6, B1, E1 |
| "£38,000–£44,000" — JD | A1 |
| "two days a week at our Avonmouth site in Bristol" — JD | A3 |
| Notice period — Hannah Lowther's message | A2 |
| "what's prompting a move" — Hannah Lowther's message | A4, B3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does the process look like after this call: how many stages, who would I meet, and over what timescale?" | Next steps are on her agenda, so this asks for the detail behind them and signals you are planning |
| R2 | "How is the hybrid pattern set: are the two Avonmouth days fixed days, or agreed with the team?" | She asked how the pattern would work for you; this asks how it works for them |
| R3 | "Which systems does the team use for stock and supplier orders, and what training is there for ones a new starter hasn't used?" | Shows you have read the ERP line and are asking how you would close it, rather than hoping it goes unmentioned |
| R4 | "How do planning, the warehouse and QA hand schedules to each other today, and where is that hand-off hardest?" | Shows you understood the advert's first duty, and asks for the thing you would be working on |
| R5 | "What does the weekly on-time dispatch report look like now, and who reads it?" | Turns the advert's reporting line into a practical question about what your first reports would feed |
| R6 | "What would a good first three months look like in this role?" | A closing question that asks what success is, so you can see whether the role matches what you want |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated production schedules | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says scheduling deliveries for three depots, not production scheduling. B2's slot stays inside the depots |
| Confident or expert with Excel | Inflated form of F7 | F7's quote at its own scope: you rebuilt your stock-count spreadsheet. B4's slot asks only what you did in it |
| Has ERP experience | Inflated form of F9; and a negative you stated for SAP, F8 | The plain acknowledgment F8 gives: "I've never used SAP." The in-house system stays at its own scope: your company runs it. The material does not say you work in it |
| Cut discrepancies by a third, or by a third through your work alone | Inflated form of F4 | F4's quote at its own scope: "about a third over a year", after you rebuilt the spreadsheet. C1, C2 and E2 ask only how it was counted, which assumption you would defend least, and which part was yours |
| Pay of £42,000 is a minimum or non-negotiable | Inflated form of F10 | "I'm hoping for £42,000", the scope you gave it |
| Was made redundant, or was forced out | Inflated form of F12 | F12's quote at its own scope: the Bristol office is closing next year, and the only offer is relocating to Reading, which you don't want |

## Sources

Provided: the advert (pasted), your background and what you'd tell Hannah (your message), Hannah Lowther's LinkedIn message (pasted). No dossier was present, and no document was pasted beyond these.

Searches sent, all refused: `Quillmoor Diagnostics values`, `Quillmoor Diagnostics interview process operations coordinator`, `Quillmoor Diagnostics Avonmouth news`, `Hannah Lowther Quillmoor Diagnostics`. No fetches were sent.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | Refused. Would have supplied published value names for VAL themes. No values-style round is detected here, so no cheat sheet was due either way |
| 2. `Quillmoor Diagnostics interview process operations coordinator` | unavailable | Refused. Would have documented later rounds; the persona weights rest on Hannah's own message instead |
| 3. `Quillmoor Diagnostics Avonmouth news` | unavailable | Refused. Would have fed a CO question grounded in current strategy; none is in the banks |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | Refused. Would have fed an interviewer read and a reverse question tied to her path; both are absent |
| 5. representative Operations Coordinator JD | skipped | The advert you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your notice period → fills A2 in your own words instead of an instruction
- Whether the stock-count spreadsheet was Excel, and what you did in it → F7 and B4 upgrade from a slot to a grounded row
- Whether you produce any regular report on deliveries → F5 and C4 upgrade from a slot to a grounded row
- How the fall in discrepancies was counted, and which part was yours → F4, C1, C2 and E2 gain your real answers in place of slots
- Whether you work in the in-house stock system yourself → F9 and A6 upgrade from a slot to a grounded row
- Whether any of your delivery scheduling involves other teams, and which → F1 and B2 upgrade from a slot to a grounded row
- Web search permission → re-runs the four refused searches (values, interview process, recent news, Hannah's public professional footprint): adds an interviewer read, a tailored reverse question, and any company-specific CO question. A deeper pass of up to 6 more searches and 2 more fetches, several more minutes, can follow if you want it
- A `tuesday-dossier.md` from an earlier evidence review → would grade the fit rows from verified evidence and add a stated list of claims to avoid
