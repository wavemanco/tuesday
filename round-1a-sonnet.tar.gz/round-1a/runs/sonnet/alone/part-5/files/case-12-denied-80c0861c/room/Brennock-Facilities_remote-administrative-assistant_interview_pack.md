# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

Candidate: Aoife. Interviewer: the office manager, name not given. Format: one 30-minute video call, from your message. Relationship assumed: a manager-style evaluator who would also work alongside you, because the note did not say whether they are your future manager or a peer. If that is wrong, the persona weights in section 8 are the part that changes.

## How to use this pack

Personas are how a question is asked. Types are what it is scoring. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did. An answer slot is an instruction for the interview, not a question for you to answer here.

| Type | What it scores |
|---|---|
| VAL | Past behaviour against the company's published values. No values-style round was detected, so no VAL questions are in this pack |
| EXP | Whether your background survives scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Knowledge of the company and its strategy. None in this pack: no company research was possible, see Sources |
| CASE | A live, role-shaped problem, scored on structure and reasoning |

The single highest-ROI rehearsal is A2, the supplier-invoice question: the ad lists "processing supplier invoices" and your material carries chasing unpaid invoices, so this question will arrive in some form.

## 4. Fit snapshot

Requirements are quoted from the ad as you described it in your message. Evidence is your own words from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — ad, per your message | "I ran the appointment book for four physios" — your message | medium | [grounded] | presentation | A self-reported line with nothing inspected behind it. Reword only the quote: "I ran the appointment book for four physios." Let the interviewer connect it to calendars; do not widen it to other kinds of calendar or other people |
| F2 | "booking travel" — ad, per your message | none given | none | [grounded] | discovery | Your material does not show travel booking, and has not said there was none. Answer slot: if any booking of travel or similar arrangements was part of a past job, say what and for whom, in your own words; if there was none, say so plainly and say how you would go about it, as a plan |
| F3 | "preparing documents in Word and Excel" — ad, per your message, Word part | "I'm good with Word" — your message | low | [grounded] | discovery | A self-rating with no documents named, so the interviewer will ask what you made. Answer slot: name the documents you have prepared yourself, if any; if none comes to mind, say so plainly and say how you would show your level on the day |
| F4 | "preparing documents in Word and Excel" — ad, per your message, Excel part | "okay with Excel" — your message | low | [grounded] | discovery | You rated yourself "okay", and the words stay there: "I'm okay with Excel." Answer slot: if there are Excel tasks you have done, name them; if there are none, say so plainly. Never rate yourself higher than you said |
| F5 | "processing supplier invoices" — ad, per your message | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Your material says chasing unpaid invoices, and the words stay there: "I chased unpaid invoices." Answer slot: the ad's "processing" makes a probe on whether you entered, checked or paid invoices likely, and on whether the ones you chased were owed to the clinic or by it. If any of that was yours, say which, in your own words; if none was, or it was not yours, say so plainly and stay with the chasing |

Background used: "two years as a receptionist at a physiotherapy clinic" — your message.

No requirement in the ad as you described it is an eligibility gate, so the snapshot has no gate row. If the full ad names one, such as a right to work in Ireland or a required location, send it and the row is added.

### Requirement coverage

| Requirement | Questions |
|---|---|
| managing calendars | A5, B1, F2 |
| booking travel | A4, B2 |
| preparing documents in Word | D3, B5, C1 |
| preparing documents in Excel | A1, C2, B4 |
| processing supplier invoices | A2, B3, D2 |
| remote working (from the role title) | A3, C3 |

## 8. Persona table

Your own words establish the loop: one 30-minute video call with the office manager. So the weights below rest on that and not on an archetype.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet probing of the gap between a receptionist's background and an admin role | High. The ad's four tasks each sit a step from your quoted evidence (F2, F4, F5), and a 30-minute screen has room for few topics | Rehearse A2 until it is boring: say what the quote says, return to it under follow-up, name the limit plainly, then give a plan |
| B. Case / Strategist | Small live problems from the job: a clash, a trip to book, an invoice problem | High. A manager hiring an assistant tests judgment on the real tasks, and your material is thin on two of them | Clarify first, then structure, then answer; think aloud |
| C. Conversational | A friendly walk through your background, casual Word and Excel questions | Medium. Thirty minutes with an office manager is likely to open this way, and casual questions are still scored | A 90-second arc built only from your quoted sentences |
| D. Data-Driven Prober | Presses on your figures and on what "good with Word" means | Medium. Your material carries one figure, four physios, and two self-ratings | For each figure and rating, know what you can and cannot say about it, and say so plainly |
| E. Peer Evaluator | Asks how you would work with them day to day | Medium-low. They may be a future colleague as much as a manager | Reciprocity: what you bring them, not only what you need |
| F. Pressure | Time-boxed "why you" and "how much was you" | Low. Nothing in the note suggests a stress style | Pause, anchor in the quote, hold through two follow-ups, concede specifically |

## 9. Question banks

### A. Skeptic (5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "okay with Excel" | Choose from your own list, not a rehearsed humble-brag. If Excel is your choice, the words are "I'm okay with Excel." Answer slot: name Excel tasks you have done, if any; if none, say so plainly. Then give a plan for closing the gap, said as a plan and never as a past | F4 is the thinnest-rated requirement and this is the standard way a Skeptic reaches it; JD because it scores the listed job including its gaps |
| A2 | "Part of this role is processing supplier invoices. What have you done with invoices?" | JD | [grounded] "chased unpaid invoices" | The highest-ROI rehearsal in this pack. Hold only what the quote carries: "I chased unpaid invoices." Answer slot: if you entered, checked or paid any invoices, say which, in your own words; if you did not, or it was not yours, say so plainly and describe the chasing. Say whether the invoices you chased were owed to the clinic or by it, only if you know. Hold through two follow-ups by returning to the chasing, never by adding to it. The concession is specific: you have done the chasing part, and you would learn the rest, said as a plan | F5 is where the ad presses hardest on your material, so this objection arrives in some form. JD because it scores a stated requirement |
| A3 | "You've been a receptionist. Why an admin assistant role, and why remote?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | Open with the quote's own terms, "I spent two years as a receptionist at a physiotherapy clinic." Answer slot: why this step and why remote, in your own words; the pack supplies neither reason | Motivation consistency is a Skeptic's core test; F1 and F5 are the background the move starts from. EXP because it tests whether your story holds together |
| A4 | "Have you booked travel for anyone before?" | JD | [grounded] | Answer slot: if any booking of travel or similar arrangements was part of a past job, say what and for whom; if none was, say so plainly and say how you would approach a booking, as a plan. The question needs no claim about your past from this pack | F2 has no evidence behind it and the ad names the task, so this is a near-certain probe. JD because it scores a listed duty |
| A5 | "You ran a four-physio appointment book. How would managing calendars here differ?" | JD | [grounded] "I ran the appointment book for four physios" | Tell it at the quote's scope: "I ran the appointment book for four physios." Answer slot: the ad's "managing calendars" makes a probe on handling changes and clashes likely. If you handled those, say how, in your own words; if there were none, or they were not yours, say so plainly and stay with the book | F1 is the strongest row and the likeliest place to be tested for transfer. JD because the question is about the listed duty |

### B. Case / Strategist (5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Two people you support both need the same 2pm slot on Thursday. What do you do?" | CASE | [generic] | Structure it: ask who needs it and why, check whether either can move, offer alternatives, confirm the outcome in writing to both, record it. The question needs no claim about your past, so the guidance makes none | The ad's calendar duty (F1's requirement) as a decision. Generic because it is a pattern for the problem, not a fact about this employer |
| B2 | "Your manager asks you to book a two-day trip to Cork for three people by tomorrow. Walk me through it." | CASE | [generic] | Clarify first: dates, who is travelling, budget, preferences, any approval needed. Then options, a recommendation, confirmation, and an itinerary sent to everyone. Think aloud. No claim about your past | F2's requirement as a live task; it lets you show method where you may have no history. Generic for the same reason as B1 |
| B3 | "A supplier invoice arrives and doesn't match the order. What do you do?" | CASE | [generic] | Clarify what does not match, check it against the order and the delivery, tell the person who approved the purchase, hold it until it is resolved, record the outcome. No claim about your past | F5's requirement set as a problem. It tests judgment without needing invoice-processing history |
| B4 | "Here is a list of 200 invoices with due dates. I need the overdue ones by Friday. How would you approach it?" | CASE | [generic] | Say what you would ask first: what the columns are and what counts as overdue. Then describe the approach in your own plain words. If you would look up how to do a step, say so; do not name a function you have not used | F4's requirement set as a task, so the honest answer is a method, and a limit said plainly scores better than a bluff |
| B5 | "You need a one-page summary for the manager's meeting in an hour. What do you ask before you start?" | CASE | [generic] | Ask who it is for, what decision it supports, what to include and the format. Draft, check against the source, send with time to spare. No claim about your past | The Word duty (F3's requirement) as a live problem, where clarifying beats formatting skill |

### C. Conversational (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic", "I ran the appointment book for four physios", "chased unpaid invoices" | A 90-second arc with only the beats those sentences state: two years as a receptionist at a physiotherapy clinic, running the appointment book for four physios, chasing unpaid invoices. Answer slot: why you are applying for this role, in your own words | The likeliest opener in a friendly 30-minute call, and a place candidates ramble. F1 and F5 are the beats; EXP because it is your own history |
| C2 | "Tell me how you use Excel." | JD | [grounded] "okay with Excel" | Start with your own rating: "I'm okay with Excel." Answer slot: name what you have used it for, if anything; if you have not used it for much, say so plainly and say what you would do to get up to speed, as a plan | Casual questions on a listed tool are scored. F4 is the evidence; JD because Excel is in the ad |
| C3 | "How would you keep on top of requests when you're working from home?" | JD | [generic] | Describe your own method in plain words: one list, a way to rank by urgency, confirming receipt. The pack supplies no past example. Say it as how you would work, not as something you have done | The role title says remote, so working method is likely to be asked; generic because it is a pattern for the problem |

### D. Data-Driven Prober (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the appointment book for four physios. Was it yours alone?" | EXP | [grounded] "I ran the appointment book for four physios" | Say "four physios" and the book as the quote has them. Answer slots for the figure: how you know it was four, what it depended on, which part you would defend least, and which part was yours, each in your own words; if you do not know how something was counted, say so plainly | The one figure in your material; a Prober will take it apart, so the rehearsal is exact attribution. F1 is the row; EXP because it tests what was yours |
| D2 | "How many unpaid invoices were you chasing, and how many got paid?" | EXP | [grounded] "chased unpaid invoices" | Answer slot: if you know a count, give it as you know it and say how it was counted; if you never tracked one, say so plainly and describe the chasing as you did it. Never offer a number to fill the gap | F5 has no figure, so the Prober supplies the demand. EXP because it scores attribution |
| D3 | "You said you're good with Word. What documents have you produced?" | EXP | [grounded] "I'm good with Word" | Start with your words: "I'm good with Word." Answer slot: name documents you have prepared yourself, if any; if none comes to mind, say so plainly and say what you would do to show your level | F3 is a rating with nothing named behind it, and "good" invites a request for examples |

### E. Peer Evaluator (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "I'll often be the one you ask when something's unclear. How do you like to work with someone in my seat?" | JD | [generic] | Answer in reciprocity terms: what you will do to make their load lighter, and how you prefer to be asked for and given work. Your own words; the pack supplies no past example | They may be a colleague as much as a manager, and this tests whether you reduce or add to their load. Generic because it needs no claim about your past |
| E2 | "Tell me about a time you and a colleague saw a job differently." | EXP | [generic] | Pick a time with a named job, a real difference, and a relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard collegial probe on disagreement style. Generic because no quoted sentence of yours carries this story, so this is a selection scaffold |

### F. Pressure (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over someone who already has an office admin job?" | JD | [grounded] "I ran the appointment book for four physios", "chased unpaid invoices" | Pause and restate the question. Hold the two things your words carry: "I ran the appointment book for four physios" and "I chased unpaid invoices." Concede specifically if pushed: you are okay, not expert, with Excel, and you would learn what the ad lists beyond that, said as a plan | Tests composure rather than content; F1 and F5 are what you hold, F4 is what you concede |
| F2 | "That appointment book. How much of it was actually you?" | EXP | [grounded] "I ran the appointment book for four physios" | Hold the quote: "I ran the appointment book for four physios." Answer slot: if any part was shared with others or set by someone else, say which; if it was yours throughout, say so. Hold through two follow-ups by returning to the sentence, then concede only what is true | The standard attribution probe, and F1 is the claim it targets. EXP because it scores what was actually yours |

## 11. Reverse questions

No interviewer profile exists, so none of these is tied to their path.

| # | Question to ask | Why it lands |
|---|---|---|
| 1 | "Which takes most of the week: calendars, travel, documents or invoices?" | It shows you read the four duties as separate jobs, and tells you where to focus |
| 2 | "Whose calendars and travel would I manage, and who would I report to?" | A concrete picture of the role, and a check that your picture of the interviewer's relationship to you is right |
| 3 | "Which systems would I use for invoices and calendars, and what training would I get?" | Treats your Excel and invoice gaps as a ramp-up question, not an admission |
| 4 | "How is a new remote hire equipped: laptop, software and desk, and who buys them?" | An ordinary question for any remote role. A plain, specific answer you can get in writing is what you want to hear |
| 5 | "Could I see the written contract, and the pay and start date terms, before the next step?" | A normal professional request, and the answer shows how the company handles hiring |
| 6 | "What could a new person do in their first month that would genuinely help you?" | The reciprocity question; it moves the call to a peer conversation |

## 13. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed calendars across a team or for executives | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios." The limit is the pack's observation: your material says the appointment book, not other kinds of calendar |
| Processed supplier invoices, or handled accounts payable | Inflated form of F5 | F5's quote at its own scope: "I chased unpaid invoices." Your material says chasing, not processing. A2's slot stays inside the chasing |
| Proficient or advanced in Excel | Inflated form of F4 | F4's quote at its own scope: "I'm okay with Excel." D3 and C2 slots ask only what you have done |

## 14. Sources

Provided documents: the invitation email, the ad as you described it, and your background as you described it. All of it is quoted from your message. No dossier was present.

Research tier: L1 attempted — searches 0 of 6 run (3 sent, all refused), fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Brennock Facilities Ltd values` | unavailable | Search refused. It would have moved a values cheat sheet, but no values-style round is documented either way, so only the upgrade menu changes |
| 2. `Brennock Facilities Ltd interview process administrative assistant` | unavailable | Search refused. Your own words establish the loop (one 30-minute call), so persona weights are unchanged; it would have shown whether there is a further round |
| 3. `Brennock Facilities Ltd Ireland news` | unavailable | Search refused. It would have fed CO questions; there are none, and the pack is generic on company knowledge |
| 4. Interviewer name | n/a | No name was given, so there was no query to form |
| 5. Representative Remote Administrative Assistant JD | skipped | The ad as you described it fixes the fit snapshot and the JD questions |

## 15. Upgrade menu

- The full ad text → the five rows quoted from your summary become rows quoted from the ad itself, and any duty or requirement the summary left out gets a row and a question
- The recruiter's or interviewer's own words about what the call will cover → the persona weights stop resting on the assumption in the title block
- The interviewer's name → an interviewer read, tuned persona weights, and a reverse question tied to their path
- Answers to the slots in F2 to F5 → each row regenerated from what you actually did, with an upgraded bridge
- A reference from the clinic, or the clinic's description of your job → the artifact that would lift F1 and F5 from `medium` toward `high`
- Permission to search the web → company values, loop and recent news for the CO questions and a values cheat sheet if one is documented
- A deeper research pass — up to 6 more searches and 2 more fetches, several more minutes → a strategy brief and loop reports for the company
- A `tuesday-dossier.md` from an earlier evidence check → verified evidence and absolute no-claim lines in place of the ones this pack inferred
