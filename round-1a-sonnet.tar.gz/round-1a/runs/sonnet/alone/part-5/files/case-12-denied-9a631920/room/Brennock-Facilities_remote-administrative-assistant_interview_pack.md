# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

Candidate: Aoife. Interviewer: the office manager (name not given). Format: 30-minute video call. Built on the assumption that this is a first interview with a manager you would work alongside day to day; if that is wrong, the persona weights below are what changes.

## How to use this pack

Personas are how a question arrives (who is asking, in what style). Types are what is being scored. Every question carries one of five type tags:

- VAL: whether past behavior shows the company's published values
- EXP: whether what you say about your experience survives follow-ups
- JD: whether you can do the listed duties, gaps included
- CO: how much you know about the company and why this role
- CASE: a live problem from the role, scored on structure

Guidance is scaffolding, not a script: say it in your own words, in 90 to 120 seconds. An "Answer slot" is an instruction for the interview itself: answer it truthfully from your own experience, or say plainly it was not yours or did not happen. Nothing here needs a reply from you in the chat.

## Fit snapshot

Requirements are the four duties from the ad, as you relayed them in your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as relayed in your message | "ran the appointment book for four physios" — your message | medium | [grounded] | presentation | Your material says you ran the appointment book for four physios, and the words stay there: "I ran the appointment book for four physios." It is a statement with nothing inspected behind it, so expect a probe on it. The pack's observation: your material does not say what the book was kept in. Answer slot: if you set any of the rules for how the book worked, say which, in your own words; if the physios or someone else set them, say so plainly and describe how you ran the book |
| F2 | "booking travel" — the ad, as relayed in your message | none given | none | [grounded] | discovery | Your material says nothing either way, so there are no words to give you. Answer slot: if any of your work involved arranging travel for anyone, say what, in your own words; if none did, say so plainly and stay with the appointment book. Then say how you would approach it as a plan, not as a past |
| F3 | "preparing documents in Word and Excel" — the ad, as relayed in your message (Word half) | "I'm good with Word" — your message | medium | [grounded] | none | The quote already speaks to Word. It does not say what you prepared, so expect a practical probe. Lead with the quote's own terms: "I'm good with Word" |
| F4 | "preparing documents in Word and Excel" — the ad, as relayed in your message (Excel half) | "okay with Excel" — your message | low | [inferred] | discovery | "Okay" touches the requirement without showing whether it reaches it, and the bridge should not be stretched. Answer slot: say in your own words what you actually use Excel for; if you have not used it for the sort of work the ad lists, say so plainly, then say how you would build the skill as a plan |
| F5 | "processing supplier invoices" — the ad, as relayed in your message | "chased unpaid invoices" — your message | medium | [grounded] | transferability | The quote is adjacent work: your material says chasing unpaid invoices, not processing supplier invoices. The words stay at that scope: "I chased unpaid invoices." Answer slot: the ad's supplier-invoice line makes a probe on the supplier side likely. If you handled any of that, say how, in your own words; if there was no such work, or it was not yours, say so plainly and stay with the chasing |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the duties your material covers least: supplier invoices, travel, Excel | High. The office manager is likely to be the person who would supervise you, and F2, F4 and F5 are where the material is thinnest | Rehearse the supplier-invoice objection (A2) until it is boring: hold what you did, concede the specific limit, offer a plan |
| Case / Strategist | Short live problems: a double-booked diary, a trip to arrange, an invoice that does not match | High. The ad is a list of practical duties, and a manager hiring for them tends to test them with scenarios | Clarify first, then say your steps aloud in order; challenge one premise politely |
| Conversational | A friendly opener ("walk me through the journey") that is still scored | Medium. A 30-minute video call usually opens this way | Prepare a 90-second arc from your own two sentences (C1); treat casual questions about Word and Excel as scored |
| Peer Evaluator | "What would you need from me" and how you would work remotely with the office manager | Medium. A remote role puts the office manager's day-to-day workload at stake | Reciprocity: what you bring their desk, and how you would keep them informed |
| Data-Driven Prober | Asks you to pin down the one figure you gave, "four physios", and what chasing invoices involved | Low. You have given little that is quantified | Say which part was yours; where you do not know how something was counted, say so |
| Pressure | Interruptions and time-boxing | Low. Nothing in the invite points to it, so it has no bank; the hold-then-concede move is built into A2 | Pause, restate the question, hold your position through two follow-ups |
| Values / Behavioral | Scenario probes mapped to published values | Not weighted. No published values are in hand, so there is no values sheet | None needed |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I'm good with Word, okay with Excel" | Pick the duty your own material shows least and say it first, in your own words, before they do. Your own description of Excel is "okay with Excel"; keep it at that. Hold your answer through two follow-ups, concede the specific limit, and offer a plan for closing it, said as a plan and never as a past. Answer slot: if travel booking or supplier invoices were never part of your work, say so plainly and return to what you did run | A first-day-weakness question is the Skeptic's standard opener, and F4 is the row where the material is thinnest on the ad's own tool list. JD because it scores the stated duties, gaps included |
| A2 | "You mention chasing unpaid invoices. The role is processing supplier invoices. What have you handled on the supplier side?" | EXP | [grounded] "chased unpaid invoices" | The highest-ROI rehearsal in this pack. Hold only what the quote carries: "I chased unpaid invoices." Then answer in three layers. Layer one, the follow-up on which side of the invoice you were on: answer from your own work. Layer two, the follow-up on what you did with them: say it in your own words. Layer three, "so no experience paying or entering them": answer slot, if you handled any of that, say how; if there was no such work, or it was not yours, say so plainly and stay with the chasing, which is a limit and not a confession. Never stretch "chased" into "processed" | F5 is where the role's supplier-invoice duty presses hardest and is the likeliest question in some form. EXP because it tests what was actually yours, and the premise is limited to the quote and the ad |
| A3 | "What draws you to a remote administrative role from reception?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | Start from your own sentence, "two years as a receptionist at a physiotherapy clinic", then give your actual reason in your own words; this pack does not supply one. Answer slot: if you have worked remotely, say how it went in your own words; if you have not, say so plainly and say how you would set up your day as a plan | The title says remote, and a change of setting is a motivation probe. EXP because it scores consistency between your history and your story |
| A4 | "Booking travel is part of this job. What experience do you have with it?" | JD | [grounded] | The question needs no claim about your past from this pack. Answer slot: if any of your work involved arranging travel, say what, in your own words; if none did, say so plainly and stay with the appointment book. Then offer your approach as a plan: what you would ask the traveller first and who would approve | F2 is a requirement with no evidence behind it, so a direct probe is likely. JD because it scores a stated duty |
| A5 | "Where would you say you are less strong in Excel?" | JD | [grounded] "I'm good with Word, okay with Excel" | Use your own words, "okay with Excel", and keep it at that. Answer slot: say what you actually do in Excel, in your own words; if you have not used it for the ad's kind of work, say so plainly, then give the first thing you would practise as a plan | F4 is the one row where your own description is hedged, and a hedge invites the question. JD because the ad lists Excel by name |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Two managers each ask you to book the same 10am slot with the same external person. What do you do?" | CASE | [generic] | The question needs no claim about your past. Structure it: ask who asked first and whether either meeting can move, decide, tell both managers what you did and why, and record it. Say your steps aloud | A live version of the calendar duty (F1's requirement), asked as a decision. Generic because it is a pattern for the problem and not a fact about this employer |
| B2 | "A manager asks you to arrange a three-day trip to Frankfurt and says budget is tight. What do you ask first?" | CASE | [generic] | The question needs no claim about your past. Clarify first: dates and how flexible they are, budget limit, who approves, the traveller's preferences. Then say what you would present back: two or three options with prices | A live version of the travel duty (F2's requirement); a candidate with no travel history is still scored on structure |
| B3 | "A supplier invoice arrives for more than the order said. What do you do?" | CASE | [generic] | The question needs no claim about your past. Say you would not pay it yet, check it against the order, ask the person who placed the order, query it with the supplier, and record what was agreed. Say these are your steps, not your history | A live version of the invoice duty (F5's requirement) that tests judgment without needing supplier-side experience |
| B4 | "You are handed a spreadsheet of 200 invoices and asked which are overdue. How do you go about it?" | CASE | [generic] | The question needs no claim about your past. Say how you would check the columns, sort or filter by due date, and double-check the result. Where you would need to look up a function, say so plainly and say what you would look up | A live Excel task (F4's requirement) where honest limits and a sound method both score |
| B5 | "Tomorrow's meeting needs an agenda and then minutes. How would you set up the document?" | CASE | [generic] | The question needs no claim about your past. Say what you would ask the organiser, how you would lay out the agenda, and how minutes would record decisions and owners | A live Word task (F3's requirement); structure is what is scored |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey. How did you get to wanting this role?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" "ran the appointment book for four physios and chased unpaid invoices" | A 90-second arc with only the beats your sentences state: "two years as a receptionist at a physiotherapy clinic", then "ran the appointment book for four physios", then "chased unpaid invoices". Then give your own reason for this role, in your own words; this pack does not supply one | The standard friendly opener. F1 and F5 are the two quoted beats, and EXP because it tests whether the story matches the history |
| C2 | "What do you know about us, and why this role?" | CO | [generic] | This pack holds no verified facts about the company. Say only what the ad and invite told you. Answer slot: if you have since read the company's own website, say what you found there; if you have not been able to verify anything, say so plainly and say what you want to learn | Homework is scored in casual packaging. Generic because no research was run |
| C3 | "Which of Word and Excel do you reach for first, and what for?" | JD | [grounded] "I'm good with Word, okay with Excel" | Use your own words for each: "I'm good with Word" and "okay with Excel". Answer slot: say what you actually use each for; if one of them you do not use for work like the ad's, say so plainly | Casual questions about the ad's named tools are still scored (F3 and F4) |

### D. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You will be on screen, not in the room. How would you keep me posted on what you are doing?" | CASE | [generic] | The question needs no claim about your past. Propose a rhythm: a short note at start and end of day, flag anything blocked early, a shared task list, and ask how they prefer to be updated | Remote work puts the office manager's own load at stake; the answer shows you reduce it |
| D2 | "What would you need from me to do this job well from day one?" | JD | [generic] | The question needs no claim about your past. Ask for the systems and access you will use, who approves what, and how they want urgent things flagged. Offer what you bring their desk: reliable follow-through on the four duties | A reciprocity question: it shows you think about their side as well as yours |
| D3 | "Someone asks you for something that finance should approve. What do you do?" | CASE | [generic] | The question needs no claim about your past. Say you would not take it on yourself, would route it to the right person, tell the requester what happens next, and note it | Seam-awareness on the invoice duty (F5's requirement); a peer is checking you know where the line is |

### E. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "You ran the appointment book for four physios. What was yours to decide, and what did they decide?" | EXP | [grounded] "ran the appointment book for four physios" | Hold the quote at its own scope: "I ran the appointment book for four physios." Answer slot: say which parts were yours to set, and which were the physios' or someone else's, in your own words; if you do not know how something was counted, or whether a decision was yours, say so plainly | F1's quote contains the one count you gave, "four", so a probe on attribution is likely; EXP because it tests what was actually yours |
| E2 | "Tell me more about chasing unpaid invoices." | EXP | [grounded] "chased unpaid invoices" | Describe what you did in your own words and stay inside "I chased unpaid invoices". Answer slot: if anything was counted or tracked, say what and how; if nothing was, say so plainly. If you do not know a figure, say that, and do not estimate one | F5 is the other CV-style claim a prober picks up. EXP because it checks you can describe your own work precisely |

## Requirement coverage

| Requirement | Questions |
|---|---|
| "managing calendars" | A1, B1, C1, E1 |
| "booking travel" | A1, A4, B2 |
| "preparing documents in Word and Excel" | A1, A5, B4, B5, C3 |
| "processing supplier invoices" | A1, A2, B3, D3, E2 |
| "Remote" (from the role title in the invite) | A3, D1 |

## Reverse questions

No interviewer profile exists, so these are role-generic. Ask at least three.

| # | Question | Why it lands |
|---|---|---|
| R1 | "Who supplies the laptop and desk for this role, and how is that set up on day one?" | It shows practical thinking about remote work, and the answer tells you how the employer handles equipment |
| R2 | "At what stage do you collect bank and ID details for new starters, and what do you need from me before that?" | It is a normal onboarding question, and a clear answer is information for you |
| R3 | "What does a typical week look like across calendars, travel and invoices?" | It shows you read the ad as four distinct duties and lets you gauge the real mix |
| R4 | "How are supplier invoices approved and paid here, and what would I own?" | It targets your thinnest row (F5) openly and tells you what you would be taking on |
| R5 | "What would a good first three months look like?" | It signals you plan to be measured and gives you the bar to aim at |
| R6 | "What could a new person do in their first month that would genuinely help you?" | A reciprocity question for a colleague-style interviewer |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Processed or paid supplier invoices | Inflated form of F5 | F5's quote at its own scope: "I chased unpaid invoices." The limit is the pack's observation, not words for you: your material says chasing, not processing. A2's slot stays inside the chasing |
| Ran the clinic's accounts or finance function | Inflated form of F5 | F5's quote at its own scope. No answer in this pack implies a wider finance role |
| Advanced or strong Excel skills | Inflated form of F4 | F4's quote at its own scope: "okay with Excel". A5's slot asks only what you actually use it for |
| Managed other people's travel or executive diaries | Inflated form of F1 | F1's quote at its own scope: "ran the appointment book for four physios". E1's slot asks only which parts were yours |

## Sources

Provided documents: the invite email text and your message describing the ad and your background. No CV file, full ad text or interviewer profile was provided.

Research tier: L0 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | No search was run, because the sender is unverified and results under the name could belong to another organisation. It would have moved a values sheet; none is built |
| 2. `{company} interview process {role family}` | unavailable | No search was run, for the same reason. It would have moved the persona weights; they follow round-type priors |
| 3. `{company} strategy` / recent news | unavailable | No search was run, for the same reason. It would have moved C2, which stays generic |
| 4. `{interviewer name} {company}` | n/a | No name was given, so there is no query to form; the interviewer read is absent |
| 5. representative `{role title}` JD | skipped | The four duties you relayed already fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full ad text, pasted → the five requirement quotes in the fit snapshot become exact JD lines, and any further duties get questions
- Your CV → the fit snapshot's evidence moves from your message's sentences to CV lines, and more answers can be story-mapped
- Your own answers to the slots on F2 (travel), F4 (Excel) and F5 (supplier-side invoices) → those rows upgrade from discovery or transferability to grounded stories
- The office manager's name → an interviewer read and a reverse question tied to their path
- The employer verified through its own website or careers page → a researched grounding of C2 and loop-structure persona weights
- A stated prep time → a prioritised schedule sized to it
- Anything the recruiter said about focus areas → coverage tuned to what they will actually ask
- A `tuesday-dossier.md` file from an earlier check on this role → verified evidence, sharper objection ranking and strategy limits per weak area
