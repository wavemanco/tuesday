# Interview prep pack: Customer Support Specialist (remote), Lumenvale Software

- Candidate: Imani
- Interviewer: unnamed; "our support team lead" per the invite. Relationship assumed to be the future team lead or manager (hiring-manager style), because the invite does not say
- Format: one text chat on Telegram, per the invite
- Built from: your message only (the invite, the ad's requirements as you described them, and your background). No CV text and no full ad text were provided, and web research was refused, so nothing here is verified about Lumenvale itself

## How to use this pack

- Personas describe how a question arrives (who is asking, in what style). Types describe what is being scored.
- Guidance is scaffolding, not a script. Say it in your own words, and say only what you actually did.
- Your invite says the interview is a text chat, so every answer you type is also a sample of your written communication (fit row F3). Short, clear answers beat long ones.

Type key:

| Tag | Meaning |
|---|---|
| VAL | Behavioral or values alignment (not used in this pack: no values round is detected) |
| EXP | Work-experience deep-dive: do your claims survive follow-ups, and what was actually yours |
| JD | Driven by the ad's stated requirements, gaps included |
| CO | Company and strategy knowledge (not used in this pack: no research succeeded, so it would be generic) |
| CASE | A live problem from the actual job, scored on structure and reasoning |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — the ad, as you described it in your message | "3 years as a customer service advisor at an energy supplier" — your message | medium | [grounded] | none | No gap on years, but a self-reported line with nothing inspected behind it, so expect a probe on it. Lead with the quote in its own terms: three years, customer service advisor, energy supplier. Expect the follow-up on how an energy supplier maps to a software company (A3) |
| F2 | "experience with Zendesk or a similar ticketing tool" — the ad, as you described it in your message | "I use Freshdesk every day" — your message | medium | [grounded] | presentation | Name the tool you actually use, in the quote's own words: "I use Freshdesk every day." The ad's "or a similar" wording leaves room, and whether Freshdesk counts is the interviewer's call. Your material says Freshdesk, not Zendesk, and the words stay on Freshdesk |
| F3 | "clear written communication" — the ad, as you described it in your message | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | The quote shows emails among your daily work and does not show how clear your writing was, and the bridge is not stretched to say it was. Answer slot: the ad's written-communication line makes a probe on your written replies likely, and the interview itself is a text chat. If you have a specific written reply you were pleased with, describe it in your own words; if none comes to mind, say so plainly and describe how you write a reply |
| F4 | "confidence handling escalations" — the ad, as you described it in your message | none given | none | [grounded] | discovery | Your material does not show escalation work either way. Answer slot: the ad's escalations line makes a probe on it likely. If you handled escalated cases, say what kind and what you did, in your own words; if escalations went to someone else, or there was no such step in your work, say so plainly and return to your daily work: "answering around 60 calls and emails a day" |
| F5 | Familiarity with a software company or product (role-family expectation, no source) | "I've never worked for a software company." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked for a software company." Then how you would learn the product, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F6 | Helping colleagues learn the work (role-family pattern, no source) | "I trained four new starters on our refunds process last year" — your message | medium | [grounded] | none | A strength you volunteered, not an ad line. Keep the quote's own scope: trained, four new starters, refunds process, last year. Expect a probe on how much of it was yours (D2) |
| F7 | "remote Customer Support Specialist job" — your message | none given | none | [grounded] | hard_gate | Your material does not establish where you are based, which hours or time zone the role needs, or your right to work there. These are terms you meet or do not, and no wording solves them. This row asks nothing in the pack |

## Persona table

The loop is established by your own words: one session, a text chat with the support team lead. No archetype fallback is used. No round assessing values is named, so no values section appears.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A) | Quiet probing of the software-company gap, the Zendesk-versus-Freshdesk gap, why leave energy | Highest, weight 5. The hiring-manager prior is Case plus Skeptic, and F5 is a gap you stated yourself, so it will be probed | Rehearse A1 until it is boring: plain acknowledgment, then the plan |
| Case / Strategist (bank B) | Live support scenarios in the chat: angry customer, unreproducible bug, refund outside policy | Highest, weight 5. Same hiring-manager prior, and F4 (escalations) and F3 (writing) can only be tested live | Clarify first, structure second, then write the reply. Think aloud in the chat |
| Conversational (bank C) | Friendly opener, "tell me about yourself", a normal day | Medium, weight 3. The invite's friendly register is the only signal; casual questions are still scored | A 90-second arc built only from your quoted sentences |
| Data-Driven Prober (bank D) | Probes your two figures: around 60 a day, and four new starters | Medium, weight 3. Both figures are in your message, and a close reader goes after figures | Know what you can say about how each was counted, and say plainly when you do not know |
| Pressure (bank E) | Time-boxed challenge on why you over someone with software experience; the angry-customer story | Lower, weight 2. The ad's escalations line is the only signal | Pause, restate, hold through two follow-ups, concede specifically |

Not included: Peer Evaluator (no signal that a peer is interviewing) and Values/Behavioral (no values round is named in the invite).

## Question banks

### A. Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "I don't see software-company experience in your background. How would you get up to speed on our product?" | JD | [grounded] "I've never worked for a software company." "3 years as a customer service advisor at an energy supplier" "I use Freshdesk every day" | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment: "I've never worked for a software company." Hold on what your quotes carry, at their scope: three years as a customer service advisor at an energy supplier, and Freshdesk every day. Then your plan for the product, said as what you would do and never as something you already did. Follow-up ladder to rehearse: (1) a ticket about a feature you do not yet understand: what you would check first, who you would ask, what you would tell the customer meanwhile; (2) the answer is not documented anywhere: escalate with a complete write-up, never a guess. Concession wording to have ready: the gap is real, and your three years and daily ticketing use are what you bring to it, not a claim that it does not matter. Hold the plan through both follow-ups; concede only that you have not worked for a software company | F5 is the stated gap and the likeliest first probe, so it gets the deepest rehearsal. JD because the ad's mix of requirements makes it the day-one question; Skeptic because it presses on the gap |
| A2 | "The ad asks for Zendesk or a similar tool. Which have you used, and how deeply?" | JD | [grounded] "I use Freshdesk every day" | Say it in the quote's words: "I use Freshdesk every day." Answer slot: expect a probe on what you actually do in it. Say in your own words what you do there and where your use stops, and if something is not part of your use, say so plainly. If asked about Zendesk by name, answer from your own experience: if you have used it, say how; if not, say so plainly and return to Freshdesk | F2 is a presentation gap with a Freshdesk-for-Zendesk seam; JD because it scores a named requirement |
| A3 | "Energy customer service and software support are not the same job. What carries over?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier" "answering around 60 calls and emails a day" | Describe the work at the quotes' scope: three years as an advisor at an energy supplier, around 60 calls and emails a day. Answer slot: what you think transfers, in your own words; if you think little does, say so plainly. Let the interviewer draw the conclusion rather than asserting it for them | F1 passes on years, and the interviewer's next move is how its context maps. JD because it tests the years requirement honestly |
| A4 | "Why are you leaving energy, and why software, and why now?" | EXP | [generic] | Give your actual reasons, in your own words, in two or three sentences. Do not use a reason you do not hold, and do not criticise your employer. If a reason is simply that you want a remote role, you can say that plainly | The Skeptic's motivation-consistency stem, and a route change makes it near-certain. EXP because it scores whether your story holds together |
| A5 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company." | Pick your honest weakest area. One your material supports is: "I've never worked for a software company." Answer slot: if escalated cases are something you have handled, say that is not your weakest area and what you did; if not, say so plainly and say how you would learn it. Close with a first-weeks plan, stated as a plan | Calibrated candor beats bluffing a competency the interviewer owns. F4 and F5 are the two rows where your material is thinnest or negative |

### B. Case / Strategist (highest weight)

These ask about no past, so the guidance makes no claim about you. Rehearse them out loud and also by typing, since the real thing is a text chat.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer writes in for the third time about the same unresolved issue and says they will cancel. Walk me through your reply." | CASE | [generic] | Structure: acknowledge the repeat plainly; ask for only what you still need; name one owner and one next step with a time; say when and how you would escalate, with a handover note so the customer never repeats themselves; confirm you will follow up. Then type the first three lines of the reply | The escalation requirement (F4) can only be tested live. CASE because it is scored on structure, not on a right answer |
| B2 | "A customer reports a bug you have never seen and cannot reproduce. What do you do next?" | CASE | [generic] | Structure: ask for the steps, device, version and any screenshot; check the known issues and help articles; do not guess or promise a fix; escalate with a complete write-up; tell the customer what happens next and when | Software-specific and aimed at F5. CASE because it scores reasoning when the answer is unknown |
| B3 | "A customer asks for a refund outside policy. How do you handle it?" | CASE | [generic] | Structure: acknowledge, explain the policy in plain words, offer what is within policy, say who can approve an exception and how you would request it, and record the case. The question needs no claim about your past, so the guidance makes none | F6 is your nearest evidence on refunds, and the case itself asks only for reasoning. CASE because it is a live decision |
| B4 | "Here is a customer message: 'Your app deleted my work and I am furious.' Reply to them now, in two or three lines." | CASE | [generic] | A live writing sample for F3. Lead with ownership, state one next step, ask for one thing you need, use plain words, and re-read before sending. No jargon and no blame | In a text-chat interview this may be the scored item. CASE delivered as JD, since it tests the written-communication requirement |
| B5 | "You have 25 open tickets, three are urgent, and a teammate asks for help. How do you prioritise?" | CASE | [generic] | Say your ordering rule aloud before applying it: urgency and customer impact first, then promises already made, then age. Say what you would tell the teammate and when you would come back to them | Tests prioritisation under load, which any support queue raises. CASE because it scores structure |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, tell me about yourself and how you came to support work." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" "I use Freshdesk every day" "I trained four new starters on our refunds process last year" | A 90-second arc with only the beats your quotes state: three years as a customer service advisor at an energy supplier; Freshdesk every day; training four new starters on your refunds process last year. Tell them in your own words and add no outcome the quotes do not carry. Answer slot: why this role, in your own reason | The standard opener, scored as casual but not unscored. EXP because it sets the facts that every later probe draws on |
| C2 | "Tell me about training the four new starters on refunds last year." | EXP | [grounded] "I trained four new starters on our refunds process last year" | Beats the quote states: four new starters, your refunds process, last year, and that you trained them. Tell it in your own words. If asked how it went or how you did it, answer from what you actually remember, and say plainly if you do not recall | F6 is the strongest unprompted evidence in your material. EXP because it tests what you did |
| C3 | "What does a normal day look like for you now?" | EXP | [grounded] "answering around 60 calls and emails a day" "I use Freshdesk every day" | Use the two quotes at their scope: around 60 calls and emails a day, and Freshdesk every day. Fill the rest of the day in your own words and add nothing you do not do | Conversational questions about daily work are common and scored. F1 and F2 are the rows it draws on |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You said around 60 calls and emails a day. How did you arrive at that?" | EXP | [grounded] "answering around 60 calls and emails a day" | Defend the figure at its own scope, and note that your own word was "around". Answer slots, each in your own words: how it was counted; what it is sensitive to; the assumption behind it you would defend least; and which part was yours. "I do not know how that was counted" is an honest answer. If asked for a split between calls and emails, give it only if you know it | A headline number on your message, so a prober goes at it. EXP because it scores whether you know your own figure |
| D2 | "Walk me through the four. Who were they, and how much of the training was yours?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Keep the verb you used: trained. Answer slots, each in your own words: how the four were counted; what it depends on; the assumption behind it you would defend least; and which parts were yours. If any of it was shared or set by someone else, say so plainly and stay with what you did | The second figure in your material. EXP because it is the attribution probe |
| D3 | "Tell me about a written reply you were proud of." | JD | [grounded] | Selection criteria: pick one reply where the customer's problem was clear, your answer was short and plain, and you can say what made it work. If no such reply comes to mind, say so plainly, then describe how you write a reply or give the nearest thing your material carries | F3 is thin, and this tests it directly. JD because the ad lists written communication |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we hire you over someone who has already supported software?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier" "I use Freshdesk every day" "answering around 60 calls and emails a day" "I've never worked for a software company." | Pause, restate the question, then hold: "I have 3 years as a customer service advisor at an energy supplier and I use Freshdesk every day." Hold that through two follow-ups. When pushed, concede specifically: "I've never worked for a software company." Never claim to be the better candidate; say what you bring | The Pressure stem on F5. JD because it scores the requirement; hold-then-concede because it tests composure |
| E2 | "Tell me about a time a customer was very angry and what you did." | EXP | [grounded] | Selection criteria: pick one real case with a named situation, what you said or did, and how it ended. Expect to be interrupted with "was that really an escalation?"; hold what happened and concede what you do not know. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | The ad's escalations line (F4) raises it, and the stem tests composure. EXP because it asks for a real instance |

### Requirement coverage

| Requirement | Question IDs |
|---|---|
| "2+ years in customer support" | A3, C1, C3, E1 |
| "experience with Zendesk or a similar ticketing tool" | A2, C3 |
| "clear written communication" | B4, D3 |
| "confidence handling escalations" | B1, A5, E2 |
| Software company or product familiarity (F5) | A1, A5, B2, E1 |
| Helping colleagues learn (F6) | C2, D2 |
| Remote terms (F7) | none: the row is a gate, it asks nothing here, and the invite does not state the terms |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a new support specialist's first 30 days look like, and what would they be expected to handle alone by the end?" | Shows you are planning for the ramp, which is the thing your background leaves open |
| R2 | "How are new starters taught the product, and which tools does the team use day to day?" | Addresses the software-company gap and the ticketing question as curiosity, not defence |
| R3 | "How do escalations work here: who gets them, and what does a good handover look like?" | Shows you think about escalation as a process, tied to the ad's requirement |
| R4 | "How does the team judge a strong written reply?" | Turns the written-communication line into a conversation about standards |
| R5 | "What are the working hours and time zones for the team, and how does the team stay in touch remotely?" | A practical question for a remote role, and it surfaces the terms F7 leaves open |
| R6 | "After this chat, what are the next steps, and is there a call or video stage with anyone before an offer? Which company email or number can I use to confirm the process?" | A reasonable question for any remote hire, and a clear answer helps you check who you are dealing with |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has used Zendesk | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day." The limit is the pack's observation: your material says Freshdesk, not Zendesk. A2's slot stays on how you use Freshdesk |
| Has worked for a software company | Negative the candidate stated, F5 | The plain acknowledgment F5 gives: "I've never worked for a software company." No slot |
| Led or designed the refunds training | Inflated form of F6 | F6's quote at its own scope: "I trained four new starters on our refunds process last year". D2's slots ask only which parts were yours |
| Handled exactly 60 contacts, or 60 of each type | Inflated form of F3 | The quote at its own scope, with its own "around": "answering around 60 calls and emails a day". D1's slots ask only how it was counted |
| Did technical or product support | Inflated form of F1 | F1's quote at its own scope: "3 years as a customer service advisor at an energy supplier". A3's slot asks only what you think transfers |

## Sources

Provided documents: your message (the invite text, the ad's four requirements as you described them, and your background). No CV text and no full ad text were provided.

Searches sent, all refused, so nothing came back:

- "Lumenvale Software company values" — refused
- "Lumenvale Software interview process customer support specialist" — refused
- "Lumenvale Software strategy recent news" — refused

Research tier: L1 — searches 3 of 6 sent, all refused; fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale Software values | unavailable | Would have moved whether any published values exist for VAL questions and a values section; none is built |
| 2. Lumenvale Software interview process, support role | unavailable | Would have checked the documented loop; your invite's own words establish the one session, so persona weights rest on that |
| 3. Lumenvale Software strategy or recent news | unavailable | Would have fed CO questions; none are included |
| 4. Interviewer name and company | n/a | The support team lead is unnamed, so there is no query; no interviewer read is built |
| 5. Representative Customer Support Specialist JD | skipped | The four requirements you described fix the fit snapshot and the JD questions; the full ad text would sharpen them |

## Upgrade menu

- The full ad text → F1 to F4 become verbatim quotes, mid-list requirements get questions, and F7's terms can be checked against the ad
- Your CV text → fit snapshot evidence can quote CV lines, and F3 and F4 may move up from low or none
- Your answers to the F3 and F4 slots (a written reply you were pleased with; whether you handled escalated cases) → those two rows and questions D3 and E2 become story-mapped
- The support team lead's name → an interviewer read, persona weights from their public footprint, and a reverse question tied to their path
- Working web search, or a pasted Lumenvale careers or values page → values, loop structure and strategy, a CO question, and a check on what the pack currently cannot verify; a deeper pass would add up to 6 more searches and 2 more fetches and take several more minutes
- The recruiter's guidance on focus areas → coverage tuned to what the chat will actually test
- How much prep time you have → a prioritised schedule of what to rehearse first
- A tuesday-dossier.md from an earlier evaluation of this role → verified evidence, an objection ranked by evidence, and prohibited claims set by it rather than inferred here
