# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

- **Role:** Operations Coordinator, Quillmoor Diagnostics (diagnostic-test manufacturer, about 400 staff, per the advert)
- **Round:** recruiter screen, a 30-minute phone call on Thursday at 2pm with Hannah Lowther (Talent Partner), who will ring the mobile number on your application
- **Her stated agenda:** salary expectations, notice period, how the hybrid pattern would work for you, what is prompting a move; then the team and next steps
- **Built on:** the advert, your background notes and Hannah's LinkedIn message. No company research ran (see Sources), so company-specific content is limited to the advert

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether your background claims hold up; what was actually yours |
| JD | Whether you fit the advert's stated requirements and terms, gaps included |
| CO | Knowledge of the company and its strategy |
| CASE | A live problem from the role, reasoned aloud |

An answer slot (an instruction in the guidance column) is for the interview, not for this chat: answer whichever branch is true for you. "I didn't do that" is always an acceptable branch.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | No gap on the stated years, but it is a self-description with nothing inspected behind it, so expect a probe. Lead in the quote's own terms: the role, the kind of employer, the four years |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots" — your message | medium | [grounded] | transferability | Your material says delivery scheduling across three depots, not production scheduling, and nothing about planning or QA. Words stay at that scope: "I schedule deliveries for our three depots." Answer slot: the advert's planning, warehouse and QA line makes a probe on who you work with while scheduling likely. If the depot scheduling involved working with other teams, say which and what part was yours; if it did not, or none of it was yours, say so plainly and stay with the depots |
| F3 | "track supplier deliveries and chase late orders" — advert | "chase suppliers when orders slip" — your message; "I schedule deliveries for our three depots" — your message | medium | [grounded] | discovery | The chasing half is in your own words. The material does not show whether you also track supplier deliveries. Answer slot: if you track them, say how and where, in your own words; if you do not, or it is not yours, say so plainly and stay with chasing suppliers when orders slip |
| F4 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | medium | [grounded] | none | The quote already speaks to stock accuracy. Expect a probe on the figure: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours, each in your own words. The quote pairs the rebuild with the fall and does not say the rebuild caused it; "I don't know how it was counted" is an honest branch |
| F5 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | low | [inferred] | discovery | The quote says spreadsheet, and does not show which program or what you did in it. Answer slot: say which program it was and what you built or changed in it, in your own words; if your use was lighter than the advert implies, or someone else built parts, say so plainly and stay with what you did |
| F6 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system" — your message | low | [grounded] | transferability | You stated the SAP gap, so the plain words are yours: "Never used SAP." The in-house system stays at its own scope: "we run our own in-house stock system." Answer slot: say what you do in that system, in your own words; if you only view it or others do the entries, say so plainly. Then how you would learn SAP, said as a plan and never as a past |
| F7 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material says nothing on reporting. Answer slot: if you produce regular reports on deliveries or stock, say what and how often; if you do not, say so plainly and say what you would track first |
| F8 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" — your message | high | [grounded] | none | The term is met on your own statement. Say it as you said it: two days is fine; three is the most you would want. Keep "wouldn't want more than three" as the preference it is |
| F9 | "£38,000–£44,000" — advert | "I'm hoping for £42,000" — your message | high | [grounded] | none | Your figure sits inside the advert's band. Say it as "hoping for", as you did |
| F10 | "your notice period" — Hannah Lowther's LinkedIn message | none given | none | [grounded] | hard_gate | Your material does not establish your notice period, and Hannah has said she will ask. The message closing this turn asks for it |
| F11 | "what's prompting a move" — Hannah Lowther's LinkedIn message | "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" — your message | medium | [grounded] | none | Your reason is stated and specific. Say it plainly and factually, and add nothing about terms, timing or how it was handled |

## Persona table

Weights start from the relationship prior for a recruiter screen (conversational, with a light Skeptic), then adjust for the loop. Hannah's own message establishes one session: a 30-minute call. It names no later rounds, and no interviewer footprint was found, so nothing moves the prior.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly walk-through plus Hannah's four logistics items | Highest: her message lists pay, notice, hybrid and motivation, all in a conversational register | A 90-second background arc built from your quoted lines (A1); a plain answer to each logistics item in your own words; treat casual questions as scored |
| Skeptic | Quiet probes on the gaps and on why you are leaving | Medium: the advert's production-scheduling and SAP lines sit against your material (F2, F6), and "why move" is a standard screen check | Rehearse B1 until it is boring: hold your real scope, concede only what is true |
| Data-Driven Prober | Pressure on the stock-count figure and the Excel claim | Low to medium: a recruiter screen rarely goes deep, but the one-third figure is a magnet if it comes up | Know what you can and cannot say about how the figure was counted; say plainly when you do not know |
| Case / Strategist | One light situational question on late orders or stock mismatches | Low: it is a screen, but the role is operational and a hiring-manager call may follow | Clarify, structure, then answer; think aloud |

Pressure, Values and Peer styles are not expected on a recruiter call, and no values round is documented, so they have no bank.

## Question banks

Highest-ROI prep in this pack: B1. It aims at the biggest gap between the advert and your material, and some form of it is likely to come up.

### A. Conversational (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, tell me about your background and what you do now." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots"; "chase suppliers when orders slip" | A 90-second arc with three beats, each a clause the quotes state: the four years in the coordinator role at a building-supplies wholesaler; scheduling deliveries for three depots; chasing suppliers when orders slip. Tell them in your own words and add no further beats. End by pointing at the advert's own lines | F1 to F3 are the evidence rows; EXP because it tests what your background actually is |
| A2 | "What's prompting a move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Say what you told me: the Bristol office is closing next year and the only offer is relocating to Reading, which you don't want. Keep it factual and neutral about your employer, and add no terms, dates or detail beyond that. Then say in one sentence what in this role appeals to you, taken from the advert's own lines. Answer slot: if she asks what you considered about Reading, answer in your own words; if you considered nothing beyond not wanting it, say so plainly | F11 is the evidence; Hannah named this item, so it is near-certain. EXP because it tests your account of your own situation |
| A3 | "What salary are you looking for?" | JD | [grounded] "I'm hoping for £42,000" | Logistics slot filled with your own words: "I'm hoping for £42,000." Say it once, plainly, without justifying it by claims your material does not carry. If she asks about current pay, answer in your own words | F9; JD because it scores the advert's stated pay band against your expectation |
| A4 | "What's your notice period?" | JD | [grounded] | Logistics slot: give your actual notice period in your own words. If you do not know the exact terms, say so and that you will confirm. Do not offer a shorter period than you owe | F10 is a gate the material does not settle; JD because notice is a term of the job offer process |
| A5 | "How would two days a week at Avonmouth work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | Say it as stated: you live in north Bristol and two days at Avonmouth is fine. If she asks about flexibility, say you wouldn't want more than three, as the preference it is. Answer slot: if asked about the journey, answer from what you actually know of it, or say you would check | F8; JD because the hybrid pattern is an advert term and Hannah named it |
| A6 | "Why Quillmoor?" | CO | [grounded] | No company research ran, so use only the advert: it describes a diagnostic-test manufacturer of about 400 staff, with coordination across planning, the warehouse and QA. Pick one or two things in the advert you actually care about and say why, in your own words. If nothing specific comes to mind, say so plainly and talk about the work the advert describes | A motivation question is routine on a screen; CO because it tests homework, and it stays advert-only because no research ran |

### B. Skeptic (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role coordinates production schedules between planning, the warehouse and QA. What have you coordinated that's closest to that?" | JD | [grounded] "I schedule deliveries for our three depots" | The highest-ROI rehearsal in this pack. Hold only what the quote carries: "I schedule deliveries for our three depots." Answer slot: if scheduling for the depots involved working with other teams, say which and what part was yours, in your own words; if it did not, or none of it was yours, say so plainly and stay with the depots. Hold through two follow-ups by returning to the depots, never by adding to them. Concede only what is true: you can say the advert's coordination is wider than what you have described, without claiming or denying anything your material is silent on | F2 is where the advert presses hardest against your material; JD because it scores the stated responsibility, Skeptic because it is aimed at the gap |
| B2 | "Which part of this role would be your weakest on day one?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | Name the gap you stated, in your own words: "Never used SAP." Say the in-house system at its own scope: "we run our own in-house stock system." Answer slot: say what you do in that system; if you only view it or others do the entries, say so plainly. Then give a plan for learning SAP, said as a plan and never as a past | F6; JD because the ERP line is in the advert, and a stated gap is better named by you than found by her |
| B3 | "Why not take the Reading offer?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Hold what you said: it is the only offer and you don't want it. Do not criticise your employer. Answer slot: if you have a reason you want to give, give it in your own words, you do not owe more than you choose to say; if there is no particular reason beyond not wanting it, say so plainly | F11 again, in the pushback form; EXP because it tests the consistency of your own account |
| B4 | "How much of the delivery scheduling is actually down to you?" | EXP | [grounded] "I schedule deliveries for our three depots" | The quote is first person, so state it as it is: you schedule deliveries for the three depots. Answer slot: if others take part in the scheduling, say who and what part is yours; if it is all yours, or none of the parts you are asked about are, say so plainly | F2; EXP because attribution probes exist to catch inflation, and the honest answer is the exact scope |
| B5 | "Tell me about a time you had to chase a late order." | EXP | [grounded] "chase suppliers when orders slip" | The quote gives the routine, not an occasion. Choose one real occasion and say what slipped, what you did and what happened, in your own words. If no single occasion comes to mind, say so plainly, then describe how you generally chase suppliers when orders slip | F3 and the advert's chasing line; EXP because it asks for a specific instance |

### C. Data-Driven Prober (weight: low to medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "What did you rebuild in the stock-count spreadsheet?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Say it as stated: you rebuilt the stock-count spreadsheet. Answer slot: say what you changed, in your own words; if others built parts of it, or you rebuilt less than the word suggests, say so plainly and stay with your part | F4 is the headline claim; EXP because it tests what you actually did |
| C2 | "How was that one-third fall in discrepancies counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | The defend-the-number slots, each in your own words: how the figure was counted; what it is sensitive to; the assumption you would defend least, named before she does; which part was yours. If you do not know how it was counted, say so plainly. Do not state a cause the quote does not give | F4; EXP because a prober scores whether you know your own figure |
| C3 | "How confident are you with Excel?" | JD | [inferred] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Stay at the quote's scope: you rebuilt a stock-count spreadsheet. Answer slot: say which program it was and what you did in it; if your use is lighter than the advert implies, say so plainly and stay with what you did | F5; JD because Excel is a stated requirement, labelled inferred because the quote does not name the program |
| C4 | "The role reports weekly on on-time dispatch. What reporting have you done?" | JD | [grounded] | Answer slot: if you produce regular reports on deliveries or stock, say what and how often, in your own words; if you do not, or it was not yours, say so plainly and say what you would track first | F7; JD because it is a stated duty your material is silent on |

### D. Case / Strategist (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A supplier says a key delivery will be two days late and production is due to start. What do you do first?" | CASE | [generic] | Structure it aloud: what you would ask first, what the delay affects, which teams need to know, what options you would raise, and what you would record. It needs no claim about your past, so the guidance makes none | Live problem from the advert's supplier-chasing and scheduling lines; generic because it is a pattern, not a fact about this employer |
| D2 | "Stock records show more than the shelf holds. How do you find out why?" | CASE | [generic] | Structure it: confirm the count, then look for what could explain the difference, then fix the record and the cause, and say what you would track afterwards. No claim about your past | Advert's stock-accuracy line as a decision; generic for the same reason |
| D3 | "On-time dispatch dropped last week. How would you look into it?" | CASE | [generic] | Clarify what is being measured, break the drop down by where it happened, form hypotheses, say how you would test them and who you would tell. No claim about your past | Advert's weekly dispatch reporting line as a diagnostic; generic |

### Requirement coverage

| Requirement | Questions |
|---|---|
| 2+ years in operations or logistics coordination | A1, B4 |
| Coordinate production schedules between planning, the warehouse and QA | B1, D1 |
| Track supplier deliveries and chase late orders | B5, D1 |
| Keep stock records accurate | C1, C2, D2 |
| Confident with Excel | C3 |
| ERP experience (SAP or similar) a plus | B2 |
| Report weekly on on-time dispatch | C4, D3 |
| £38,000–£44,000 | A3 |
| Hybrid, two days at Avonmouth | A5 |
| Notice period (Hannah's agenda) | A4 |
| What is prompting a move (Hannah's agenda) | A2, B3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Who would I be coordinating with day to day across planning, the warehouse and QA?" | It uses the advert's own lines and shows you read the role, not just the title |
| R2 | "What does a good first three months look like in this role?" | It signals you are thinking about delivering, and gets you the manager's yardstick |
| R3 | "Which ERP does the team work in, and how are new starters trained on it?" | It addresses your SAP gap openly and finds out what ramp-up support exists |
| R4 | "How is the two-day pattern set: fixed days, or agreed with the team?" | It is the practical follow-up to your own hybrid answer |
| R5 | "How is on-time dispatch doing now, and who would I report it to?" | It shows interest in the advert's weekly reporting line and gets the real starting point |
| R6 | "Is there anything in my background you would want the hiring manager to see more of?" | It invites her to surface a concern while you can still answer it |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Describing the move as redundancy or a lost job | Inflated form of F11 | F11's quote at its own scope. The limit is the pack's observation: your material says the office is closing and Reading is the only offer, nothing more |
| Having coordinated production schedules between planning, the warehouse and QA | Inflated form of F2 | F2's quote at its own scope: "I schedule deliveries for our three depots." The pack observes that your material says deliveries, not production, and nothing about QA. B1's slot stays inside the depots |
| Any SAP experience | Negative you stated, F6 | "Never used SAP — we run our own in-house stock system." Then a plan for learning it, never a past |
| That your rebuild cut discrepancies by exactly a third | Inflated form of F4 | The quote at its own scope: you rebuilt the spreadsheet and discrepancies fell by about a third over a year. The pack observes that it does not say the rebuild caused the fall |
| That £42,000 is your minimum | Inflated form of F9 | "I'm hoping for £42,000." |
| That three days a week is a hard limit | Inflated form of F8 | "I wouldn't want more than three," as the preference it is |

## Sources

Provided documents: the advert (pasted), your background notes, and Hannah Lowther's LinkedIn message (pasted).

Searches sent, all refused (search permission was not granted, so I did not retry):
- "Quillmoor Diagnostics values": refused
- "Quillmoor Diagnostics interview process operations coordinator": refused
- "Quillmoor Diagnostics Avonmouth news strategy": refused
- "Hannah Lowther Talent Partner Quillmoor Diagnostics": refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | unavailable | Every call was refused. It would have fed a values cheat sheet and VAL questions; none is built, and no values-style round is detected from the material |
| 2. Interview process and loop | unavailable | The call was refused. The one session this pack prepares for comes from Hannah's own message; later rounds would have moved the persona weights |
| 3. Strategy and recent news | unavailable | The call was refused. It would have fed a grounding brief and strategy-based CO questions; A6 stays advert-only |
| 4. Interviewer footprint (Hannah Lowther) | unavailable | The call was refused. It would have fed an interviewer read and a reverse question tied to her path; both are absent |
| 5. Representative JD | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your notice period → F10 and A4 filled in your own words
- Your answers to the slots in F2, F3, F5, F6 and F7 (what the depot scheduling involved, whether you track supplier deliveries, which spreadsheet program, what you do in the in-house system, any reporting you do) → those rows gain quoted evidence and their gap types and confidence bands are regenerated
- The stock-count spreadsheet itself, or before and after discrepancy counts → F4 and F5 could move from medium or low to high, because an inspectable artifact is what raises the band
- Web search permission → company values, strategy and any documented process become grounded, A6 and the CASE bank can be rebuilt on them, and the interviewer read becomes possible; a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) is available if you grant it and want it
- A note from Hannah on whether later rounds follow, such as a hiring-manager call → persona weights and banks recomputed for those rounds
- A tuesday-dossier.md from an earlier evaluation of this role → a verified-evidence list, a named top objection and a prohibited-claims list in place of the ones this pack inferred and built locally
