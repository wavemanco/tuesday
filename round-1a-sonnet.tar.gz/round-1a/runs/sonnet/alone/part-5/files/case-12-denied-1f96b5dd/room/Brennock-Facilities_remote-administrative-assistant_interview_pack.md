# Interview pack — Remote Administrative Assistant, Brennock Facilities Ltd

Interviewer: the office manager (name not given), a 30-minute video call. Built assuming the office manager would be your day-to-day supervisor, so persona weights follow a hiring-manager round. If that is wrong, the weights change.

## How to use this pack

Personas describe how a question arrives; types describe what it scores. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values (none built here: no values source was available) |
| EXP | Whether your background survives scrutiny; what was actually you |
| JD | Whether you can do the listed duties, gaps included |
| CO | Company and strategy knowledge (none built here: no company research was available) |
| CASE | A live problem from the role, scored on structure and reasoning |

An answer slot is an instruction for the interview, not a question for now: say which branch is true for you, in your own words, and say plainly if the practice was not yours or never existed.

## Fit snapshot

The ad's duties are quoted as you relayed them in your message, not from the ad's own text.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as you described it | "I ran the appointment book for four physios" — your message | medium | [grounded] | presentation | The quote reaches the requirement in other terms. Say it as it stands: "I ran the appointment book for four physios." Nothing inspected sits behind it, so expect a probe on what running it involved. Answer slot: if any part of running it was yours to decide, say what and how; if none was, say so plainly and stay with the book you ran |
| F2 | "booking travel" — the ad, as you described it | none given | none | [grounded] | discovery | Your material does not show whether you have booked travel. Answer slot: if you have arranged travel for anyone, at the clinic or elsewhere, say what, in your own words; if you have not, say so plainly and say how you would go about it, as a plan and never as a past |
| F3 | "preparing documents in Word and Excel" — the ad, as you described it (Word part) | "I'm good with Word" — your message | low | [inferred] | discovery | Derived from your one self-rating, which names the program and not the documents, so the bridge stays at its scope: "I'm good with Word." Answer slot: expect a request for examples. If you have prepared particular kinds of document, name them; if the use was lighter than that, say so plainly |
| F4 | "preparing documents in Word and Excel" — the ad, as you described it (Excel part) | "okay with Excel" — your message | low | [inferred] | discovery | Derived from your one self-rating, and it stays "okay": the pack adds no level above it. Answer slot: expect a probe on what you have done in Excel. If you have built or edited particular spreadsheets, say what; if little, say so plainly, then say what you would learn first, as a plan |
| F5 | "processing supplier invoices" — the ad, as you described it | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Your material says chasing unpaid invoices, not processing supplier invoices, and does not show which side of the transaction they were on. Words stay at "I chased unpaid invoices." Answer slot: if any invoices you dealt with were ones the clinic had to pay, say what you did with them; if all were invoices owed to the clinic, or none of it was processing, say so plainly and stay with the chasing |
| F6 | "Remote Administrative Assistant" — the invite | none given | none | [grounded] | hard_gate | Your material does not establish whether working remotely suits your situation. Surfaced as a gate; no wording is offered because wording cannot settle it |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (A) | Live problems from the job: a calendar clash, a travel plan, a stray invoice, an Excel task | Highest. Prior for a hiring-manager round is Case plus Skeptic, and every duty in the ad is a ready-made scenario. Rests on the relationship prior only, since no documented loop for this company was available beyond the one 30-minute call | Clarify first, then structure, then answer; think aloud. These need no claims about your past |
| Skeptic (B) | Quiet probing of F5, F4 and F2, plus why a remote admin job | High. Same prior, and F5 to F2 are where the material is thinnest | Rehearse B1 until it is boring; bridge only from the quotes; give a concrete ramp plan |
| Conversational (C) | Friendly opener, "walk me through your journey", casual questions about Word | Medium. A 30-minute video call usually opens this way, and casual questions are still scored | A 90-second arc built only from your stated facts |
| Pressure (D) | "How much of that was actually you", "why you over others" | Low-medium. A short office-manager call is less likely to run stress tactics, but attribution probes arrive in any register | Hold the quote through two follow-ups, concede specifically, never fold on the core |
| Data-Driven Prober (E) | Counts and outcomes behind the appointment book and the invoice chasing | Low. Small team and a short call; probes would be quick | Say what you know and plainly say what you do not; never estimate a number |

## Question banks

### A. Case / Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Three people ask you to hold the same 10:00 slot for a client call, and one of them is your manager. How do you decide, and what do you tell the other two?" | CASE | [generic] | Structure it aloud: what each meeting is and whether any can move, who has to be told, which rule or person settles priority, how you confirm the outcome in writing. The question needs no claim about your past, so the guidance makes none | The ad's calendars duty (F1) as a live decision; CASE because it scores structure |
| A2 | "Your manager has to be in another city for a morning meeting and back for a 4pm call. What do you ask before you book anything, and what do you book?" | CASE | [generic] | Clarify first: budget, preferences, how flexible the times are, which booking channel is approved. Then the outline, a held option, a confirmed itinerary, and a plan if something runs late. Makes no claim about your past | The ad's travel duty (F2) without presupposing any travel experience |
| A3 | "Tell me about a time you arranged travel or a multi-part booking for someone." | JD | [generic] | Selection scaffold: pick an occasion with a named person, more than one moving part, and something that changed or nearly went wrong. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F2 is a discovery row, so the honest rehearsal is choosing a real story or saying plainly there is none |
| A4 | "A supplier invoice for 2,400 euro arrives and nobody can say who ordered the work. What do you do?" | CASE | [generic] | Structure: do not process it yet; check it against order or approval records; ask who could have commissioned it; log it as a query; tell the supplier it is under review; escalate to your manager if it stays unresolved. Makes no claim about your past | The ad's invoice duty (F5) as a decision; avoids presupposing you have processed invoices |
| A5 | "Here is a sheet of 200 supplier invoices with a date column and an amount column. How would you find the ones more than 30 days overdue and total them?" | CASE | [generic] | Clarify what overdue means (from the invoice date or the due date) and whether the data is clean. Then say how you would do it, naming only what you could do from memory, and say plainly what you would look up. The honest ramp plan beats a bluff | The ad's Excel duty (F4) in the form it is most likely to be tested |

### B. Skeptic (high weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Chasing unpaid invoices and processing supplier invoices are different jobs. What have you handled on the supplier side?" | JD | [grounded] "chased unpaid invoices" | **Highest-ROI prep in this pack.** Hold only what the quote carries: "I chased unpaid invoices." Answer slot: if any invoices you dealt with were ones the clinic had to pay, say what you did with them, in your own words; if all were owed to the clinic, or none of it was processing, say so plainly. Hold through two follow-ups by returning to the chasing, never by adding to it. Concede specifically: say where the supplier side would be new to you, only if that is true, then give a plan for learning it | F5 is where the ad's invoice duty presses hardest against the material, so this objection arrives in some form |
| B2 | "How would you rate your Excel, and where does it run out?" | JD | [grounded] "okay with Excel" | Say it at its word: "I'm okay with Excel." Answer slot: say what you have actually done in it, in your own words; if it has been light, say so plainly. Then the ramp plan: what you would learn first and how. Never use a higher word than the one you gave. Hold, then concede specifically | F4 is a self-rating alone, and the ad names Excel in the duties |
| B3 | "Which part of this job would you be weakest at on day one?" | JD | [inferred] from F2, F4 and F5; "okay with Excel", "chased unpaid invoices" | Pick the weakest part from your own honest view, name it in one plain sentence, and follow with a 30-day plan for it. If travel booking is where you have least, say that; if the invoice side is, say that. Never answer "nothing" | The Skeptic's standard stem, aimed at the three thinnest rows |
| B4 | "You've been a receptionist at a clinic. Why a remote admin role at a facilities company?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | Answer slot: give your actual reason for the move, in your own words; the pack supplies none. Keep it to one reason and one forward-looking sentence about the role, and do not disparage the clinic | Motivation consistency is what the Skeptic scores; the reason has to be yours |
| B5 | "Remote means nobody is next to you to ask. How do you work when you are stuck?" | JD | [generic] | Describe a plan, not a past: what you try first, how long before you ask, how you phrase the question so it includes what you tried. Do not claim a remote-working record; the pack has none from you | The ad's remote setting (F6) as a working-style probe |

### C. Conversational (medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey: what's brought you here?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | A 90-second arc using only the stated facts: two years as a receptionist at a physiotherapy clinic, the appointment book you ran, the unpaid invoices you chased. Close with your own reason for this role, in your own words | The near-certain opener; F1 and F5 supply the beats |
| C2 | "Tell me about the appointment book. What was a typical week like?" | EXP | [grounded] "I ran the appointment book for four physios" | Story-mapped on F1: the book, and the four physios, which are the beats the quote states. Answer slot: the ad's calendars duty makes a probe on what running it involved likely. If any part of it was yours to decide, say what; if none was, say so plainly and describe the book as you ran it | Casual register, scored content; F1 is the pack's strongest row |
| C3 | "How are you with Word? What do you make in it?" | JD | [grounded] "I'm good with Word" | Say it at its scope: "I'm good with Word." Answer slot: name the kinds of document you have prepared, in your own words; if the use was lighter than that, say so plainly | F3 says the program, not the documents, so the follow-up is predictable |
| C4 | "How do you keep on top of things when a lot lands at once?" | EXP | [generic] | Selection scaffold: pick a real busy stretch with a named set of competing demands and what you did to order them. If no such time comes to mind, say so plainly, then say the method you would use | An open prompt on a theme the ad's calendars and invoices duties raise (F1, F5) |

### D. Pressure (low-medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That appointment book: how much of it was actually you?" | EXP | [grounded] "I ran the appointment book for four physios" | Hold: "I ran the appointment book for four physios." Answer slot: say which parts were yours alone and which were shared, in your own words; if you do not know how to split it, say so. Hold through two follow-ups and concede only specifically | Attribution probe on F1 in a hard register |
| D2 | "Sixty seconds: why you, over someone with office admin experience?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic"; "I ran the appointment book for four physios" | Hold on the quotes only: the two years, the book. Answer slot: if you have not worked in a company office, say so plainly rather than talking around it. Then one forward-looking sentence in your own words. Pause before answering; restate the question | The Pressure stem, aimed at the background gap |

### E. Data-Driven Prober (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Four physios: roughly how many appointments a week was that, and who else touched the book?" | EXP | [grounded] "I ran the appointment book for four physios" | Defend-the-number slots, in your own words: how the "four" was counted, what it depends on, which part of it was yours. If you know the weekly volume, say it; if you do not, say you do not, and never estimate. If others touched the book, say who; if you were the only one, say so | The one figure on your side is "four" |
| E2 | "On the unpaid invoices: how much was outstanding and how many did you get paid?" | EXP | [grounded] "chased unpaid invoices" | Answer slot: if you tracked amounts or outcomes, say what, in your own words; if nobody tracked them, or you do not know, say so plainly and do not estimate. Return to "I chased unpaid invoices" | The Prober presses F5 for denominators the quote does not carry |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "managing calendars" | A1, C2, D1, E1 |
| "booking travel" | A2, A3 |
| "preparing documents in Word and Excel" | C3, A5, B2 |
| "processing supplier invoices" | A4, B1, E2 |
| Remote working | B5; F6 is a gate and asks nothing |

No CO or VAL questions: no company research or values page was available, and a generic version would add nothing to rehearse.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a good first month look like for this role?" | Shows you are thinking about delivery, and lets you hear what they weight |
| R2 | "Which calendars would I manage, and who sets priority when requests clash?" | Ties to the ad's calendars duty and shows you know clashes are the real work |
| R3 | "How are supplier invoices approved and processed today: what system, who signs off, and which part would be mine?" | Turns your thinnest row (F5) into a question about scope instead of a confession |
| R4 | "How does the team stay in touch day to day when everyone is remote?" | A practical question about the setting in F6 |
| R5 | "Who is the employing company, and what are the contract, payroll and equipment arrangements: does the company supply equipment directly?" | Ordinary diligence for any remote job, and the answer tells you how the hire actually works |
| R6 | "What would make you say in six months that this hire was a success?" | Gets the interviewer to describe their own scoring sheet |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Processed or managed supplier invoices, or worked in accounts payable | Inflated form of F5 | F5's quote at its own scope; your material says chasing unpaid invoices, not processing supplier invoices. B1's slot stays inside the chasing |
| Proficient, advanced or strong in Excel | Inflated form of F4 | "okay with Excel", the quote at its own word. B2's slot asks only what you have done in it |
| Managed calendars across a team or for executives | Inflated form of F1 | "I ran the appointment book for four physios", at that scope. C2 and D1 stay with the book |

## Sources

Provided documents: the invitation email you pasted; your message describing the ad and your background.

Searches sent: "Brennock Facilities Ltd" (refused); "Brennock Facilities Ltd values interview process administrative assistant" (refused). Nothing from the web is used anywhere in this pack.

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Brennock Facilities Ltd values` | unavailable | Search refused; would have fed a values cheat sheet |
| 2. `Brennock Facilities Ltd interview process administrative assistant` | unavailable | Search refused; would have documented the loop. The persona weights rest on the relationship prior and the one call the invite names |
| 3. `Brennock Facilities Ltd strategy` / recent news | unavailable | Search refused; would have fed CO questions |
| 4. `{interviewer name} Brennock Facilities Ltd` | n/a | No name was given |
| 5. representative `Administrative Assistant` JD | skipped | The duties you relayed fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The ad's full text → the four duty rows move from "as you described it" to the ad's own words, and any further duties get questions
- The office manager's name → a reading of their public footprint and a reverse question tied to their path (once the invite is checked and the person is confirmed)
- Whether the office manager would be your supervisor → persona weights recomputed
- A real example from you for F2, F3, F4 or F5 (travel you have booked, documents you have prepared, a spreadsheet you have used, which side the invoices were on) → those rows move from discovery slots to quoted evidence and become story-mapped answers
- Company details from the employer's own website or careers page → values, loop and CO questions
- A deeper research pass: up to 6 more searches and 2 more fetches, several more minutes, needs search permission → a strategy brief and CO bank
- A `tuesday-dossier.md` → carries this prep's gaps into later sessions
