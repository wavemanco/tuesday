# Interview pack: Customer Support Specialist (remote), Lumenvale Software

- **Role:** Customer Support Specialist, remote, Lumenvale Software
- **Interviewer:** "our support team lead", name not given. Relationship assumed hiring-manager style (the lead may be your future manager); not confirmed
- **Format:** one text chat on Telegram, per the invite: "your interview will be a text chat here with our support team lead"
- **Research:** none ran (all three searches were refused), so this pack has no verified facts about Lumenvale. See Sources

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values. No question here carries it: no values round is documented and no published values are in hand |
| EXP | Whether claims about your work survive follow-up questions |
| JD | Whether you can do the listed job, gaps included |
| CO | How much homework you have done on the company |
| CASE | A live problem from the role, answered with structure |

- **Answer slots.** Where guidance says "Answer slot", it is an instruction for the interview, not a question for you now. Answer either branch truthfully: say how it went, or say plainly it was not yours or never happened.
- **Text chat.** Every answer, however casual, is also a writing sample. Rehearse by typing.
- **Provenance.** `[grounded]` rests on something you supplied. `[inferred]` is a derivation, named in the rationale. `[generic]` is a role-family pattern with no claim about you or Lumenvale.
- **Highest-ROI prep: A1.** The software-company gap is one you stated, and it will be asked in some form. Rehearse it until it is boring.

## Fit snapshot

Requirements are the four lines of the ad as you relayed them in your message. F5 and F6 are role-family expectations the ad does not state, so they are plain prose and `[generic]`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — the job ad, as you relayed it | "3 years as a customer service advisor at an energy supplier" — your message; "answering around 60 calls and emails a day" — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it, so expect a probe. Lead with the three years in the quote's own terms. The ad says customer support and your sentence says customer service advisor, so keep your own title as written |
| F2 | "experience with Zendesk or a similar ticketing tool" — the job ad, as you relayed it | "I use Freshdesk every day" — your message | medium | [grounded] | none | The words stay at the quote: "I use Freshdesk every day." Your material names Freshdesk, not Zendesk, so expect a probe on the difference. A3 holds the slot |
| F3 | "clear written communication" — the job ad, as you relayed it | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | Emails show volume of writing, not clarity, and nothing is inspected behind it. Answer slot: if you have anything showing how your written replies were received, say what it was, in your own words; if there is nothing, say so plainly and describe how you structure a reply. B3 and D3 test this live |
| F4 | "confidence handling escalations" — the job ad, as you relayed it | none given | none | [grounded] | discovery | Your material does not mention escalations. Answer slot: the ad's line makes a probe likely. If you passed cases up or brought someone in, say what kind and what part was yours, in your own words; if you did not, or it was not yours, say so plainly and stay with the calls and emails you answered |
| F5 | Working for a software company, a role-family expectation the ad does not state | "I've never worked for a software company" — your message | none | [generic] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked for a software company." Then how you would learn the product, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F6 | Helping new colleagues get up to speed, a role-family expectation the ad does not state | "I trained four new starters on our refunds process last year" — your message | medium | [generic] | none | The sentence at its own scope: you trained four new starters on the refunds process. Nothing inspected behind it, so expect a probe on what was yours |

## Persona table

Weights: relationship prior first, then the loop. No interviewer profile exists, so no signal adjustments. The loop rests on the invite's own words, which establish one session (a text chat with the support team lead), so no archetype fallback is used.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A, 5 questions) | Quiet probing of the software-company gap, the tool gap and escalations | High. A team lead running the session reads as hiring-manager style, which weights Skeptic and Case; unconfirmed. F5 is a gap you stated and F4 has no quote | Rehearse A1 until boring: plain acknowledgment, adjacent evidence at its own scope, a first-month plan. Never bluff a competency the lead owns |
| Case/Strategist (bank B, 5 questions) | Live support scenarios put to you as typed prompts | High. Same prior. In a text chat the scenario arrives in writing and your answer is read as written | Clarify, acknowledge, gather, decide, set expectations, follow up. Say your assumptions aloud |
| Data-Driven Prober (bank C, 3 questions) | Pulls on your two figures | Medium. "around 60" a day and "four" new starters are the lines a prober presses | Know what you can and cannot say about how each was counted, and say plainly where you do not know |
| Conversational (bank D, 3 questions) | Friendly opener, casual questions that are still scored | Medium. The chat register invites it, and the biography question is near-certain | Prepare the D1 arc from your own quoted sentences. Treat casual questions on hot ad topics as scored |
| Pressure (bank E, 2 questions) | "Why you" and "how much was you" challenges | Low. The hiring-manager prior does not weight it and a text chat has no interruptions, but a blunt challenge can still arrive | Pause, restate the question, hold through two follow-ups, concede specifically |
| Values/Behavioral (no bank) | Not weighted | No values-style round is documented by the invite, and no published values are in hand, so no VAL questions | None needed |
| Peer Evaluator (no bank) | Not weighted | The lead's relationship to you is unconfirmed. If the lead is a peer rather than a future manager, this bank returns and the weights change | None needed |

## Question banks

### Bank A: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never worked for a software company. What will be hardest for you in your first month?" | EXP | [grounded] "I've never worked for a software company"; "3 years as a customer service advisor at an energy supplier"; "answering around 60 calls and emails a day"; "I use Freshdesk every day" | Three beats, in order. One: the plain acknowledgment, short: "I've never worked for a software company." Two: the adjacent evidence at its own scope, in your own words: the three years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day, Freshdesk every day. Say nothing about those years the sentences do not say. Three: how you would learn the product in your first month, said as a plan, your own choices. Hold through two follow-ups by returning to beats one and two, never by adding to them. Concede exactly what you would not yet know. Answer slot: if asked how software support differs from your work, give a view from the outside if you have one; if you have none yet, say so plainly and say what you would ask | F5 is the gap you stated and the likeliest thing a lead sees first. This is the objection most likely to arrive in some form, so it carries the deepest rehearsal. EXP because it tests whether the background survives cross-examination |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [inferred] "I've never worked for a software company" | Name one that is truthfully weakest for you and do not invent a modest-sounding one. Your material states one candidate, the software-company gap, and says nothing on escalations (F4). Say which is real for you, then how you would close it, as a plan. If no true answer comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would find out | Persona stem, aimed at F5 and F4. JD because it scores the ad's requirements including their gaps. `[inferred]` because the choice of rows is the pack's derivation |
| A3 | "The ad names Zendesk, and you use Freshdesk. What would you expect to be different?" | JD | [grounded] "I use Freshdesk every day" | Begin with the sentence at its own scope: "I use Freshdesk every day." Answer slot: the ad's tool line makes a probe on tool differences likely. Say what you expect to differ from your own use of Freshdesk; if you do not know how the ad's tool differs, say so plainly and say what you would check first, as a plan. Name no feature of a tool you have not used | F2 is the row where the ad's tool and your quote do not match by name. JD because it scores the stated tooling requirement |
| A4 | "You've spent three years at an energy supplier. Why move into software support?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" | Give your own reasons: the pack supplies none. Aim for one reason about this job and one about your own path, each true, said in a few plain sentences. If part of the reason is practical, say so plainly rather than dressing it up. Say nothing negative about the last employer | The "why leave, why here, why now" probe, built on F1's background. EXP because it is the reason for leaving |
| A5 | "Tell me about a time a customer's problem went beyond what you could settle yourself." | JD | [grounded] "answering around 60 calls and emails a day" | Selection scaffold: pick one real case where you passed something on or brought someone in. It needs what the customer was waiting for, what you had done before passing it on, what you told the customer, and what happened next. Name exactly what was yours and what was someone else's. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, answering around 60 calls and emails a day, or how you would handle one | F4 has no quote and the ad's escalation line raises this prompt. JD because it scores that stated requirement; the open prompt supplies no event |

### Bank B: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer writes in: a feature that worked yesterday has stopped, they have a deadline, and you cannot make it fail on your side. What do you do?" | CASE | [generic] | Structure it: acknowledge and say you are on it; ask what they saw, when it started and what changed on their side; check whether it is already known; decide whether you can fix it, offer a workaround, or hand it on with a written summary a stranger could act on; tell the customer what happens next and when you will write again, without promising a fix time you do not control. The question needs no claim about your past, so the guidance makes none | A live problem of the kind a support role meets. CASE because it scores structure under uncertainty. `[generic]` because it is a pattern for the problem, not a fact about Lumenvale |
| B2 | "A customer has written to you three times about the same problem and now wants a manager. Walk me through your next ten minutes." | CASE | [generic] | Read the whole history first. Apologise for the specific failure, not generically. Decide what you can fix now. If you must hand it on, summarise the history so the customer does not repeat it, and tell them who will contact them and by when. Say what you would not decide alone. The guidance makes no claim about your past | The ad's escalation line, F4, asked as a decision instead of a past event. CASE because it is a live problem |
| B3 | "Write me the first reply to this ticket, here in the chat: its broken again!!! fix it" | CASE | [generic] | Write it live. One line acknowledging the frustration without grovelling; the two or three things you need (what is broken, what happened, when it started); what you will do next; a plain sign-off. Short, plain words, no jargon. The interviewer reads this directly, so it is the clearest evidence of F3 you can give | F3's requirement, tested in the medium the interview already uses. CASE because it is delivered live; the JD content is the ad's written-communication line |
| B4 | "Your queue shows a billing question, a bug report from a customer on their third contact, a how-do-I question and an angry one-liner. What order do you answer in, and why?" | CASE | [generic] | State the principle before the order: what is time-sensitive, who has waited longest, what clears quickly. Say your assumptions aloud, including that the team may already have a priority rule you would follow. Then the order and the reason. The guidance makes no claim about your past | Prioritisation under load in the role's own terms. CASE because it scores structure and reasoning, not a right answer |
| B5 | "A customer asks when a known bug will be fixed. You do not know. What do you tell them?" | CASE | [generic] | Say what you do know, say plainly that you do not know the date, say what you will do to find out and when you will come back to them, and offer a workaround only if one exists. Never guess a date. The guidance makes no claim about your past | A calibrated-honesty problem that sits near the ad's escalation line, F4. CASE because it is a live scenario |

### Bank C: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said you answer around 60 calls and emails a day. Walk me through how that number was counted." | EXP | [grounded] "answering around 60 calls and emails a day" | Keep the figure at its own scope: "around 60", "calls and emails", and "answering", not resolving or closing. Answer slot: how it was counted, and by whom, if you know; what it moves with; the assumption behind it you would defend least; which part of the work was yours. Say each in your own words. The sentence can be read as 60 in total or 60 of each, so say which, and if unsure give the smaller. "I don't know exactly how it was counted" is an honest answer | F1 carries the pack's headline figure, and a prober presses on it. EXP because it tests attribution and honesty about the number |
| C2 | "You use Freshdesk every day. What do you use it for?" | JD | [grounded] "I use Freshdesk every day" | The sentence at its own scope first. Answer slot: the ad's tool line makes a probe on which parts you personally use likely. Say which, in your own words; if you use only part of it, say which part and describe only that; if someone else sets it up and you only work in it, say so plainly | F2 is the only evidence for the ticketing-tool requirement. JD because it scores that stated requirement |
| C3 | "You trained four new starters on your refunds process. Walk me through that." | EXP | [grounded] "I trained four new starters on our refunds process last year" | Tell the beats the sentence states, in your own words: four new starters, your refunds process, last year. Answer slot: what part was yours and what part was not, including anything set by others; "trained" is the word, not "led" or "managed". If there is a part you cannot speak to, say so plainly and return to the four starters | F6 holds a second figure, "four", and a prober presses it. EXP because it tests what was actually yours |

### Bank D: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "The ad asks for 2+ years in customer support. So, walk me through the journey." | JD | [grounded] "3 years as a customer service advisor at an energy supplier"; "answering around 60 calls and emails a day"; "I use Freshdesk every day"; "I trained four new starters on our refunds process last year" | A 90-second arc from the four sentences, in that order, in your own words: the three years as a customer service advisor at an energy supplier; the calls and emails you answered; Freshdesk every day; training four new starters on your refunds process. Finish with your own sentence on why this move, now: the pack supplies none | F1 is the ad's first requirement, and the opener is near-certain in a friendly register. JD because it scores the 2+ years line, delivered as a biography question |
| D2 | "What do you know about what we make?" | CO | [generic] | The pack has no verified facts about Lumenvale, so it supplies none. Before the chat, read what the company publishes about itself on its own website, reached by typing the address yourself rather than through a link in the chat. Say only what you read and where. If you have not had the chance, say so plainly and ask what the team would most want you to know | Homework depth, scored even when asked casually. `[generic]` because company research was refused and nothing about Lumenvale is in hand |
| D3 | "What makes a written reply to a customer clear?" | JD | [grounded] "answering around 60 calls and emails a day" | Give two or three criteria you actually apply, one sentence each, and make your own answer an example: short, plain, structured. If you want to anchor in your work, use "answering around 60 calls and emails a day" at its scope. If you do not consciously apply criteria, say so plainly and describe how you write a reply | F3's requirement asked as an open prompt. JD because the ad's written-communication line raises it |

### Bank E: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we pick you over someone who has already worked in software support?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier"; "I use Freshdesk every day"; "I've never worked for a software company" | Hold only what the first two sentences carry, in your own words: the three years, Freshdesk daily. Concede in one clause: "I've never worked for a software company." Do not claim to be stronger than that candidate; say what you would bring from those sentences and what you would still have to learn. Hold through two follow-ups by returning to the sentences, never by adding to them | F5 under time pressure. JD because it scores fit against the role, including its gaps |
| E2 | "That training of the four new starters: how much of it was actually you?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Hold on the sentence: "I trained four new starters on our refunds process last year." Answer slot: if any part was shared, set by others or signed off by someone else, say which; if it was all yours, say so; if unsure, take the smaller reading. Concede specifically, and do not widen it to running a programme or managing the starters | Attribution probe on F6. EXP because it tests precisely what the candidate did |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "2+ years in customer support" | D1, E1, A4, C1 |
| "experience with Zendesk or a similar ticketing tool" | A3, C2 |
| "clear written communication" | D3, B3 |
| "confidence handling escalations" | A5, B2, B5 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good first month look like for someone coming from outside software?" | It shows you are planning your ramp and turns the A1 gap into a forward-looking conversation |
| R2 | "How do escalations work here: what does the team expect me to settle, and when do I pass it on?" | The ad names escalations, and asking where the line sits shows you take it seriously |
| R3 | "Which ticketing tool does the team use, and how is the queue organised?" | The ad says Zendesk or a similar tool, and the answer tells you how big the F2 difference really is |
| R4 | "How does the team review the quality of written replies?" | It ties to the ad's written-communication line and signals you want feedback |
| R5 | "Is there a way I can confirm the next steps through your careers page or a company email address?" | Any real employer expects the request, and how the answer comes back is itself useful information |
| R6 | "What is the team most trying to improve over the next six months?" | It invites the lead's own priorities, and it is the question a prepared candidate asks |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has used Zendesk | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day". The limit is the pack's observation: your material says Freshdesk, not Zendesk. A3's slot stays on what you would check first |
| Has worked in software or software-company support | Negative you stated, F5 | The plain acknowledgment F5 gives: "I've never worked for a software company". No slot |
| Led, managed or ran training for a team | Inflated form of F6 | F6's quote at its own scope: "I trained four new starters on our refunds process last year". The limit is the pack's observation: your material says you trained four starters, not that you led them or the training. C3 and E2 stay inside that sentence |
| Resolved or closed around 60 tickets a day | Inflated form of F1 | F1's quote at its own scope: "answering around 60 calls and emails a day". The limit is the pack's observation: your material counts answering, not resolving. C1's slot stays on how the number was counted |

## Sources

Provided documents: your message. It holds the Telegram invite as pasted, the four requirements you relayed from the job ad, and your background. The ad's own text and a full CV were not supplied.

Searches sent, all refused (permission to search was not granted), no results returned:

- `Lumenvale Software company values`: refused
- `Lumenvale Software interview process customer support specialist`: refused
- `Lumenvale Software strategy news`: refused

No page fetches were sent.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | The search was refused. It would have fed a values cheat sheet, which is dropped, since no values-style round is documented either |
| 2. `Lumenvale Software interview process customer support specialist` | unavailable | The search was refused. The loop rests on the invite's own words alone, and no values-style round is detected |
| 3. `Lumenvale Software strategy news` | unavailable | The search was refused. It would have grounded a CO or CASE question in the company's strategy; D2 is `[generic]` instead |
| 4. interviewer name | n/a | The interviewer is described only as the support team lead, so no query could be formed. The interviewer read is absent |
| 5. representative Customer Support Specialist JD | skipped | The four requirements you quoted from the ad fix the fit snapshot rows and the JD-tagged questions |

## Upgrade menu

- The full job ad text → any further requirements and terms (hours, location, pay, tools) become quoted fit rows, and gate rows appear where the ad states one
- Your full CV → more quoted evidence for F1 to F6, and rows now `none given` may move
- A reference or review from the energy supplier → could lift F1 above `medium`; an anonymised sample of a written reply → could lift F3 above `low`
- Your own answers to the answer slots on F3 and F4, said outside a practice run → those rows become quoted evidence and A5, B3 and D3 are regenerated around them
- The support team lead's name and whether they would be your manager → persona weights re-read from their public footprint, and a reverse question tied to their own path
- Lumenvale's own published values or interview page, pasted → a values cheat sheet and company questions grounded in the page. A deeper research pass of up to 6 more searches and 2 more fetches, several more minutes, can add a strategy brief, once search permission is granted
- A tuesday-dossier.md, if you have one from earlier work → verified evidence and sharper gap strategies for the rows above
