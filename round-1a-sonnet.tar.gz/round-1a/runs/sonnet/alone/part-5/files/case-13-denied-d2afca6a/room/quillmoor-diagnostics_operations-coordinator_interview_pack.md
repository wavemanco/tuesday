# Interview pack: Operations Coordinator, Quillmoor Diagnostics

**Interviewer:** Hannah Lowther, Talent Partner. **Round:** recruiter screen, a 30-minute phone call on Thursday at 2pm; she will ring the mobile number on your application. **Topics she named:** salary expectations, notice period, how the hybrid pattern would work for you, and what is prompting a move. Then she tells you about the team and the next steps.

## How to use this pack

- Personas are how a question is asked. Types are what it is scored on.
- Type key: **VAL** is values alignment. **EXP** is a work-experience deep-dive. **JD** is role and requirement fit. **CO** is company knowledge. **CASE** is a live problem.
- No values-style round is detected, so there are no VAL questions. Hannah's own words fix this session as one phone call, so the weights below are for this call only.
- Guidance is scaffolding, not a script. Say it in your own words. The quotes in the Provenance column are the only things this pack knows about your past.
- Lines marked "Answer slot" are instructions for the call, not questions for you now. The honest answer to each is either branch, including "that was not my task" or "there was no such step".

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material says deliveries for three depots, not production schedules, and the words stay there: "I schedule deliveries for our three depots." Answer slot: the advert names planning, the warehouse and QA, so expect a probe on which of those you have worked with. If you worked with any of them, say which and how, in your own words; if none, or it was not yours, say so plainly and stay with the depots |
| F2 | "chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | Lead in the quote's own terms: you chase suppliers when orders slip. A CV-style line with nothing inspected behind it, so expect a probe on it |
| F3 | "track supplier deliveries" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | low | [inferred] | discovery | The sentence covers chasing, and does not show whether supplier deliveries were tracked. Answer slot: if you kept a record of supplier deliveries, say how, in your own words; if there was no such record, or it was not yours, say so plainly and stay with chasing suppliers |
| F4 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | Use the sentence at its own scope: you rebuilt the spreadsheet, and discrepancies fell by about a third over a year. A headline figure, so expect to be asked how it was counted (C1, C2) |
| F5 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material does not show this. Answer slot: if you have reported on delivery or dispatch performance, say what and how often; if you have not, say so plainly and return to scheduling deliveries |
| F6 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | none | The quote already reaches the requirement in the advert's terms. Say it as written |
| F7 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | The sentence says spreadsheet, not Excel, so the pack reads it down. Answer slot: if the spreadsheet was in Excel, say so; if it was another tool, name it plainly. Do not rate yourself beyond what you can show |
| F8 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system." — your message | low | [grounded] | transferability | Words: "I've never used SAP. We run our own in-house stock system." Call it the in-house stock system, as you did, not an ERP. Then how you would learn SAP, said as a plan and never as a past. The advert marks this a plus, not a requirement |
| F9 | "Hybrid: two days a week at our Avonmouth site in Bristol." — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | A term you state yourself, and it meets the advert's two days. Say both halves as you said them. Do not turn the second half into "flexible" or "up to three is fine" |
| F10 | "£38,000–£44,000" — advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | Your figure sits inside the advert's band (the pack's observation). Say it as a hope, as you said it |
| F11 | "your notice period" — Hannah Lowther's message | none given | none | [grounded] | hard_gate | Your material does not establish your notice period |
| F12 | "what's prompting a move" — Hannah Lowther's message | "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | medium | [grounded] | none | Tell it as stated: the office closes next year, and the only offer is relocating to Reading, which you don't want. Add no label to it that you did not use |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Conversational / Rapport Builder | Friendly, structured around her four topics | Highest. A recruiter screen is mostly logistics in a friendly register, and she listed the topics herself | Pre-scripted 90-second arc for the journey question. Treat every casual question as scored (A1 to A6) |
| B. Skeptic | Light probing of the gaps and the motivation | High. The advert's production-schedule and SAP lines sit against delivery-scheduling evidence (F1, F8), and the reason for leaving invites "why not Reading" | Rehearse B2 until it is boring. Hold what the quotes carry, name the limit plainly (B1 to B5) |
| C. Data-Driven Prober | Asks how the discrepancy figure was counted | Medium. A recruiter may not dig, but a figure on the record is the likeliest follow-up (F4) | Know what you can and cannot say about how it was counted, and say plainly if you don't know (C1 to C3) |
| D. Case / Strategist | A short live problem | Low. She is screening, not testing, but a coordinator role invites a quick "what would you do" | Clarify first, then structure, then say who you would tell (D1, D2) |
| E. Pressure | A time-boxed "why you" or a pay challenge | Low. She said she wants to cover your expectations, not to test composure | Pause, restate, hold what you said, concede the one thing that is true (E1, E2) |

**Highest-ROI prep: B2.** The advert's centre of gravity is production schedules across planning, the warehouse and QA, and your material says deliveries for three depots (F1). Some form of this question is the likeliest one you will face. A rehearsed, non-defensive answer changes the call.

## Question banks

### A. Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey. What have you been doing for the last few years?" | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Story-mapped on F6, F1 and F4. The beats are the sentences' own: four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots; chasing suppliers when orders slip; rebuilding the stock-count spreadsheet, with discrepancies falling by about a third over a year. Tell them in your own words in about 90 seconds, then end on why this role | The opening biography question is the most reliable opener on a screen. EXP because it tests what was yours, F6, F1 and F4 being the evidence |
| A2 | "What's prompting a move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Say it as stated: the Bristol office is closing next year, the only offer is relocating to Reading, and you don't want that. Add no label you did not use, and keep it matter-of-fact. Then one forward clause on what draws you to this role, in your own words | Hannah named it as a topic, and F12 is the answer. EXP because it tests consistency of your account |
| A3 | "What are you looking for, salary-wise?" | JD | [grounded] "I'm hoping for £42,000." | Say your figure in your own words: you are hoping for £42,000. The advert's band is £38,000–£44,000, so it sits inside. Do not add a floor you have not set, and do not offer salary history | The first topic she listed. F10 is the evidence, and the figure raises no further slot |
| A4 | "What's your notice period?" | JD | [grounded] | Logistics slot: give your actual notice period, as your contract states it. If you do not yet know whether it can be shortened, say so rather than guess | She listed it. F11 is a gate your material does not establish, so the only safe answer is your own |
| A5 | "How would two days a week at Avonmouth work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Say both halves as you said them: two days is fine from north Bristol, and you wouldn't want more than three. Answer any commute detail from what you actually know, and say if you would need to check | The advert fixes two days and she named the pattern. F9 is the evidence. JD because it scores a term of the listed job |
| A6 | "What do you know about us, and what drew you to the role?" | CO | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | The pack could not research Quillmoor, so use the advert only: a diagnostic-test manufacturer of about 400 staff, with a role that tracks supplier deliveries and chases late orders. Connect that line to your own sentence in your words. Spend ten minutes on Quillmoor's own website before Thursday and add only what you have read | The advert is the raising source and F2 is the match. CO because it tests homework; the pack is generic on anything beyond the advert |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Why not take the Reading offer?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Hold what you said: the only offer is relocating to Reading, which you don't want. Answer slot: if there is a further reason, say it in your own words; if there is not, say so plainly rather than inventing one | Motivation consistency is what a skeptic scores (F12). EXP because it tests your own account |
| B2 | "The role is about production schedules across planning, the warehouse and QA. Your background is delivery scheduling. Which part would be weakest on day one?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | The highest-ROI rehearsal in this pack. Hold only what the quote carries: "I schedule deliveries for our three depots." The limit is the pack's observation: your material says deliveries, not production schedules. Answer slot: if you have worked with planning, the warehouse or QA, say which and how; if you have not, or it was not yours, say so plainly and stay with the depots. Then concede specifically and give a ramp plan as a plan, not a past. Hold through two follow-ups by returning to the depots, never by adding to them | F1 is where the advert presses hardest. JD because it scores a stated requirement and its gap |
| B3 | "You haven't used SAP. How would you get up to speed?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Say it plainly: "I've never used SAP. We run our own in-house stock system." Then your plan to learn it, in your own words, as a plan. The advert marks ERP a plus, not a requirement | F8 stated by you, so the plain acknowledgment has a source. JD because it scores a listed plus |
| B4 | "The advert wants weekly reporting on on-time dispatch. What reporting have you done?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Answer slot: if you have reported on delivery or dispatch performance, say what and how often, in your own words; if you have not, or it was not yours, say so plainly and return to scheduling deliveries and chasing suppliers | F5 is silent in your material, so the slot lets the premise be false |
| B5 | "How confident are you in Excel?" | JD | [inferred] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer from the sentence: you rebuilt the stock-count spreadsheet. Answer slot: if it was in Excel, say so; if it was another tool, name it plainly. Do not rate yourself beyond what you can demonstrate | F7 is low: the sentence says spreadsheet, not Excel |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Keep the sentence's own terms: discrepancies, about a third, over a year. Answer slot: say how it was counted, what it is sensitive to, and which assumption behind it you would defend least, all in your own words; if you do not know how it was counted, say so plainly. The pack's observation is that the sentence credits the rebuild with the setting, not necessarily the cause | F4 is a headline figure and the likeliest follow-up. EXP because it tests defend-the-number honesty |
| C2 | "Which part of that was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | The sentence's own attribution is the rebuild, so start there: "I rebuilt our stock-count spreadsheet." Answer slot: if others did the counts or changed other things in that year, say so plainly | The attribution probe exists to catch inflation (F4). EXP |
| C3 | "Tell me about the three depots. How are deliveries scheduled across them?" | EXP | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Tell it at the sentence's scope: you schedule deliveries for three depots and chase suppliers when orders slip. Answer slot: if tools, volumes or rules shaped the scheduling, say what, in your own words; if none did, say so plainly | F1 and F2 are your core. The slot lets the specifics be yours or absent |

### D. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A key supplier tells you on Monday that a delivery QA needs for Wednesday's run will be three days late. What do you do first?" | CASE | [generic] | Clarify first: what is affected, how firm the delay is, whether there is an alternative. Then say who you would tell (planning, the warehouse, QA) and what you would ask the supplier. End with what you would record. It makes no claim about your past | A live problem from the advert's supplier-chasing and three-way coordination lines. Generic because it is a pattern, not a fact about Quillmoor |
| D2 | "The stock record says 40 and the shelf has 32. Walk me through it." | CASE | [generic] | Recount first, then check recent movements, find the cause, correct the record with a note, tell the stock owner, and say what would stop a repeat. No claim about your past | From the advert's stock-records line (F4's requirement), asked as a decision |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you, over someone who has used SAP and planned production?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "Never used SAP — we run our own in-house stock system." | Pause, restate, hold: four years as a logistics coordinator, scheduling deliveries for three depots, chasing suppliers when orders slip. Concede the true thing in the quote's words: "I've never used SAP." Do not claim to be better than anyone | The Pressure stem for the gaps in F1 and F8. Hold-then-concede, two follow-ups |
| E2 | "If we offered £38,000, would you walk away?" | JD | [grounded] "I'm hoping for £42,000." | Hold your figure: you are hoping for £42,000. Answer slot: if you have a minimum you would walk away at, say it; if you have not decided, say so plainly rather than inventing one, and decide before Thursday | F10 tested at the band's floor. JD because it scores the listed pay |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does the first month look like, and which of planning, the warehouse and QA would I work with most?" | It uses the advert's own three groups and shows you read it |
| R2 | "Which systems does the team use for stock records and supplier deliveries, and what training comes with them?" | It addresses the SAP gap by asking, not by hiding it |
| R3 | "How is on-time dispatch reported today, and who reads the weekly report?" | It picks up the advert's reporting duty |
| R4 | "How does the two-day Avonmouth pattern work in practice: which days, and is it set for the whole team?" | It clarifies a term you care about without pressing |
| R5 | "What would make someone stand out at the next stage?" | It draws out criteria she would otherwise leave unsaid |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated production schedules with planning and QA | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says deliveries for three depots, not production schedules |
| Has ERP or SAP experience | Negative you stated, F8 | The plain acknowledgment: "I've never used SAP." Call the in-house system an in-house stock system |
| Advanced Excel skills | Inflated form of F7 | F7's quote at its own scope: you rebuilt the stock-count spreadsheet. Whether it was Excel is an answer slot (B5) |
| Cut discrepancies by a third | Inflated form of F4 | The sentence as you wrote it: discrepancies fell by about a third over a year, after the rebuild |
| Flexible on office days, or fine with up to three | Inflated form of F9 | F9's quote: two days is fine, and you wouldn't want more than three |
| Was made redundant | Inflated form of F12 | F12's quote: the Bristol office is closing next year and the only offer is relocating to Reading, which you don't want |

## Requirement coverage

| Requirement | Questions |
|---|---|
| Coordinate production schedules between planning, warehouse and QA | B2, D1, E1 |
| Track supplier deliveries and chase late orders | A6, C3, D1 |
| Keep stock records accurate | C1, C2, D2 |
| Report weekly on on-time dispatch | B4 |
| 2+ years in operations or logistics coordination | A1, E1 |
| Confident with Excel | B5 |
| ERP experience (SAP or similar) a plus | B3, E1 |
| Hybrid, two days a week at Avonmouth | A5 |
| £38,000–£44,000 | A3, E2 |
| Notice period (Hannah's topic) | A4 |
| What is prompting a move (Hannah's topic) | A2, B1 |

## Sources

- Provided: Hannah Lowther's LinkedIn message, the Quillmoor advert, and your own notes. No dossier was present.
- Searches sent, all refused: "Quillmoor Diagnostics values", "Quillmoor Diagnostics Avonmouth news", "Hannah Lowther Talent Partner Quillmoor Diagnostics". Nothing from them is used anywhere in this pack.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor Diagnostics values | unavailable | The call was refused. It would have themed any values questions; no values round is detected, so none are included |
| 2. Quillmoor interview process, operations roles | skipped | Hannah's message fixes this session as one 30-minute call with her topics named, which fixes the persona weights |
| 3. Quillmoor strategy or recent news | unavailable | The call was refused. It would have moved A6 from advert-only to grounded in current company news |
| 4. Hannah Lowther, Quillmoor | unavailable | The call was refused. The interviewer read is absent and R1 to R5 are role-generic |
| 5. Representative Operations Coordinator advert | skipped | You supplied the advert, which fixes the fit snapshot and the JD questions |

## Upgrade menu

- Your notice period → A4 becomes your own words rather than an instruction, and F11 is settled
- Which tool the stock-count spreadsheet was built in → F7 moves from low and A5/B5 stop being slots
- How the discrepancy figure was counted, and what part of it was yours → C1 and C2 become story-mapped
- Whether you have worked with planning, the warehouse or QA, and whether you have reported on delivery performance → F1, F3 and F5 turn from slots into grounded rows (B2, B4)
- Permission for web search → the three refused searches rerun, giving a grounded A6, an interviewer read and a retuned R1 to R5. A deeper pass (up to 6 more searches and 2 more fetches, several more minutes) is also available once, if you want it
- A `tuesday-dossier.md` from an earlier evaluation of this role → verified evidence and per-gap strategy in place of the inferred objection in B2
