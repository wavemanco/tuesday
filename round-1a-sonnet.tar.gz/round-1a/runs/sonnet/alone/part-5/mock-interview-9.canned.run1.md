I'll read the reference files the skill requires before building the pack.
Now the evidence conventions (gate rules), research checklist, interaction grammar, and reframing audit.
Your prep pack is saved as `Halvering-Elementary_fourth-grade-teacher_interview_pack.md`. It has 21 questions across the likely panel styles, plus reverse questions and a short prep schedule for Thursday. I built it for the 45-minute panel the district's careers page describes: the principal plus two grade-level teachers.

**Before the pack:** your message included a Social Security number. I don't need it, I haven't used it, and it isn't in the pack. I also left your licence's IEIN out of everything. Consider deleting both from anywhere you've pasted them.

- **Highest-ROI prep:** A2 ("You've taught third grade for six years. Why should we think you're ready for fourth?"). The pack holds only what you stated: six years of third grade, and your grades 1–6 elementary endorsement. It then has you concede in one sentence, "I've never taught fourth grade", and give your plan. A3 does the same for team lead.
- **Licence:** your Illinois PEL with the elementary endorsement matches the invite's requirement. I took it as you stated it and haven't checked it, so confirm the record yourself before Thursday.
- **Research:** the district's three published beliefs, the one-panel hiring format, an August 2026 literacy plan (including a new grades 3–5 reading curriculum from fall 2027), and the principal's reading-specialist background all came from searches. Three of those, including the literacy plan and her bio, are from search snippets only, because my fetches ran out. The Sources section lists each one.
- **Gaps:** I had no job posting. The requirements in the pack come from the invite, the district's beliefs and a typical listing, and the pack labels them that way.

Say the word and I'll play the principal on A2 with live follow-ups.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Do you have the full job posting? Paste it and the rows built from a typical listing will be rebuilt from the district's own words.
2. Did HR say anything about what the panel will focus on, or ask you to bring something such as a sample lesson? That would add a build section.
3. Do you want a deeper research pass on the district's plan and the principal's talks? It would take up to 6 more searches and 2 more fetches, and several more minutes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering-Elementary_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

| Item | Detail |
|---|---|
| Role | Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District) |
| Candidate | Grace |
| Round | 45-minute panel on Thursday: Principal Dolores Vantongeren and two members of the fourth-grade team (names not given) |
| Version | First build, from the invite, your résumé text, and research at L1 (see Sources) |

## How to use this pack

Personas are how a question is asked; types are what it scores. Guidance is scaffolding for your own words, not a script: say only what you actually did. Where guidance says "answer slot", it is an instruction for the interview, not a question for you to answer here.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the district's published beliefs |
| EXP | Whether your claims survive scrutiny, and what was actually yours |
| JD | The role and its stated requirements, gaps included |
| CO | Whether you know the district's current direction |
| CASE | Structure and reasoning on a live problem from the role |

## Prep triage

Sized to the days left before Thursday, assuming Thursday is this week's.

| Order | Do this | Where |
|---|---|---|
| 1 | Say A2 aloud three times with its follow-ups, until the concession is boring | A2 |
| 2 | Say A1 and A3 once each; keep the two plain acknowledgments to one sentence | A1, A3 |
| 3 | Choose your own real stories for the three belief questions and decide your answer to each slot | D1, D2, D3 |
| 4 | Practice the 90-second arc, then the district-plan question | E1, C1 |
| 5 | Run the four case questions once each, clarifying before answering | C1 to C4 |
| 6 | Pick three reverse questions; keep your licence details to hand | Reverse questions |

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — the invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | A gate your material shows met, in the invite's own terms: kind, Illinois, class, endorsement and status as you stated them. It is a statement with nothing inspected behind it, and this pack has not checked it; confirming the record is yours to do before Thursday. Say it as stated. The pack's observation: grades 1–6 includes fourth grade |
| F2 | "Fourth Grade Teacher position" — the invite | "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [grounded] | transferability | Your material says third grade, not fourth, and the words stay there: "For six years I taught third grade at a public elementary school in Joliet." The pack adds no step from that sentence to the fourth-grade classroom |
| F3 | "Fourth Grade Teacher position" — the invite | "I've never taught fourth grade" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never taught fourth grade." Then how you would learn the grade, said as a plan about the future and never as a past. Never a claim to fourth-grade teaching, and nothing added to make the gap feel smaller |
| F4 | "Every Child a Reader: no student leaves third grade without a reading plan." — district mission and beliefs page | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years." — your CV | medium | [grounded] | transferability | Your material says the curriculum move and the club, with nothing inspected behind either, and the words stay there: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: the district's belief makes a probe on individual students likely. If any part of the club or the move was set up for individual students, say how and whose decision it was; if no part was, or it was not yours, say so plainly and stay with the club and the move |
| F5 | "Families Are Partners: each teacher speaks with every family each term." — district mission and beliefs page | "I write a weekly email to families." — your CV | medium | [grounded] | transferability | Your material says a weekly email to families, and the words stay there. Answer slot: the district's belief makes a probe on speaking with families likely. If any of your family communication went beyond the email, say what it was and how it came about; if it did not, say so plainly and stay with the email |
| F6 | "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it." — district mission and beliefs page | none given | none | [grounded] | discovery | The material is silent on assessment. Answer slot: if you have changed what you taught because of an assessment, say what it showed and what you changed; if you have not, say so plainly and say how you would use one |
| F7 | "classroom routines" — district careers page | none given | none | [grounded] | discovery | The material is silent on routines. Answer slot: if you have set routines in your own classroom, name them in your own words; if they were set by the school, or you ran it differently, say so plainly |
| F8 | Work with the grade-level team — a K12 Jobs Board listing for the title, seen as a search result and not fetched, so typical for the role and not this team's practice | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your message | medium | [inferred] | transferability | Your material holds both sentences and they stay as written: "I led our grade level's move to a new reading curriculum in 2024" and "I've never been a team lead." The first is about a move, not a team role. The pack's observation: neither sentence says how colleagues' work was arranged |

## Persona table

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the fourth-grade gap and the team-lead gap | High. The principal's relationship prior is hiring manager (Case/Strategist plus Skeptic); F3 and F8 are two gaps you stated yourself; and the panel includes fourth-grade team members who know the grade | Rehearse A2 until it is boring: hold the six years, concede the grade in one sentence, give your plan |
| Peer Evaluator | Two fourth-grade teachers asking what you would bring and how you work with equals | High. Panel rule: blend the top personas of each member's relationship, and the peer prior applies to two of the three seats | Reciprocity framing: what you bring them, not only what you need (B2); principles for the seam, not a pretence of knowing theirs |
| Case/Strategist | Live problems: routines, a reading block, a struggling reader, the district plan | Medium-high. The careers page says panels ask about reading instruction, classroom routines and families; the hiring-manager prior adds Case | Clarify, then objective, approach, how you'd know, one risk; use the district's own words for its plan |
| Values/Behavioral | Open prompts on the three published beliefs | Medium. The careers page names no values round, so no dedicated values round is detected; the beliefs still theme questions on reading and families | Pick your own real stories now; where none exists, say so plainly and use the nearest thing |
| Conversational | Opening biography, casual questions about the reading club | Medium. No seat's relationship carries it as a prior; included because the careers page does not say how the panel opens | A 90-second arc built only from your own sentences (E1); treat casual questions as scored |
| Data-Driven Prober | Pressing on how you know the curriculum move worked and what was yours | Low. A peer prior, but your material carries no figures, so only the one quoted move gives it purchase | Know what you can and cannot say about the move; say plainly when you do not know |
| Pressure | Interrupting, devil's advocate | Low. No seat's relationship carries it as a prior; no separate bank, and A2's follow-ups carry the hold-then-concede practice | Pause, restate, hold the position through two follow-ups |

## Reading the interviewer

Public professional footprint only. Two panelists are unnamed, so there is no read for them.

| Signal | Source | Provenance | What it means for you |
|---|---|---|---|
| Principal of Halvering Elementary School since 2022, after nine years as a reading specialist | Search result from the Illinois principals' forum speaker page, not fetched | [grounded] | Expect reading instruction to be probed closely and by someone who knows it; answer from what you did and say plainly where your material is silent |
| Gave a 2025 forum talk, "Small Groups, Big Readers", covering weekly reading conferences in grades 3 to 5 | Same search result | [grounded] | Likely theme for C3 and for casual reading questions; your material does not say whether you run reading conferences, so do not claim them. R1 asks about it |
| Mirror opportunity: shared professional ground in reading instruction | Pairs her path above with F4's evidence: "I've run the after-school reading club for the last two years." | [grounded] | Say the sentence as written and let her draw the connection; it is not a shared career jump and should not be framed as one |

## Question banks

### A. Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet." | Lead with the limit in your own words and stop: "I've never taught fourth grade." Then the adjacent fact at its scope: you taught third grade for six years at a public elementary school in Joliet. Then your plan for the first weeks, said as a plan about the future in your own words. Do not offer third grade as proof you can teach fourth; let them draw the inference | F3 is the plainest gap and the panel's first reach, with F2 beside it. JD because it scores fit to the role |
| A2 | "You've taught third grade for six years. Why should we think you're ready for fourth?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet."; "I've never taught fourth grade"; "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | The highest-ROI prep in this pack. The hold is only what the quotes carry: six years of third grade at a public elementary school in Joliet, and an Elementary Education endorsement for grades 1–6, registered and active through June 30, 2029. Follow-up 1, "But you haven't taught fourth": concede in one sentence, "That's right, I've never taught fourth grade", then return to the six years, never to anything added. Follow-up 2, "What would you do differently on day one?": your plan, in your own words, as a plan. Follow-up 3, "What if it's harder than you expect?": say plainly what you do not yet know and how you would find out. Never fold on the six years; never claim fourth-grade teaching | F3 is where this panel is most likely to press, and F1 and F2 are the only quoted ground to stand on. JD because it scores the posting's title, with pressure delivery in the follow-ups |
| A3 | "Have you ever been a team lead, and how would you see yourself on our fourth-grade team?" | JD | [grounded] "I've never been a team lead"; "I led our grade level's move to a new reading curriculum in 2024" | Say it plainly: "I've never been a team lead." Then the other sentence at its own scope: "I led our grade level's move to a new reading curriculum in 2024", a move, not a team role, and do not call it team leadership. If asked what part was yours, answer in your own words, saying what was not yours as well. For fitting in, say what you would ask the team first, as in B2; no claim about their practices | F8 holds both sentences and the panel includes two team members. JD because it scores working with the grade-level team, asked with a skeptic's edge |
| A4 | "Why fourth grade, why now, and why Halvering?" | EXP | [grounded] | No sentence in your material gives your reason, so the pack writes none: say your actual reason in your own words. If the district's literacy plan or one of its three beliefs is genuinely part of that reason, name which and why; if none is, do not borrow one | Motivation consistency across A2: the panel checks whether the story holds under cross-examination. EXP because it tests whether your account of yourself survives |
| A5 | "Which of our three beliefs would be hardest for you to live up to?" | VAL | [grounded] | Choose honestly. The pack's observation: F6 is the row where your material says least. If you choose it, answer slot: if you have changed what you taught because of an assessment, say what it showed and what you changed; if you have not, say so plainly and say how you would use one. If you choose another belief, state the plain limit and what you would do next, as a plan | A skeptic's stem reworded around the published beliefs. VAL because it scores fit with the three beliefs by name |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "How do you handle credit when a piece of work spans classrooms?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Choose a real time work spanned classrooms; your sentence "I led our grade level's move to a new reading curriculum in 2024" may be that time. If it is, tell only what it states: you, the grade level, a new reading curriculum, 2024, in your own words. Answer slot: if credit came up, say how it was shared; if it never came up, or it was not yours to share, say so plainly and stay with the sentence. If another time fits better, use it; if none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | F8 is where the peers test collaboration. EXP because it asks you to choose a real instance |
| B2 | "What would you need from us in your first month, and what could you bring us?" | JD | [grounded] "I've run the after-school reading club for the last two years."; "I write a weekly email to families."; "I led our grade level's move to a new reading curriculum in 2024" | Two halves. What you bring: one or two of your own sentences at their scope, such as the club for two years or the weekly email to families, told as stated and not as proof of anything. What you need: your own list, in your own words, and ask where the team's seams are rather than assuming them | The reciprocity question a peer panel weighs; F4, F5 and F8 supply the sentences. JD because it scores whether the hire adds to or lightens the team's load |
| B3 | "What happens when we disagree about how to teach something?" | CASE | [generic] | A principle, in your own words: what you would do first, how you would keep it on students' needs, when you would defer to the team, when you would go to the principal. This asks about no past, so the guidance makes no claim about yours; tell a real disagreement only if you have one | Peers price how a new colleague handles disagreement, which sits beside F8. CASE because it is a live scenario with no past premised |
| B4 | "Where does a third-grade teacher's work end and a fourth-grade teacher's begin?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." | Answer in principles and ask where their handoff sits. Speak from the third-grade side only as far as the sentence goes: six years teaching third grade at a public elementary school in Joliet. Do not claim to know what fourth grade expects of incoming students | F2 is the evidence and F3 the limit; the question turns the gap into a seam conversation. JD because it scores the grade move |

### C. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "The board adopted a three-year literacy plan in August 2026. Which part would reach a fourth-grade classroom first, and what do you need to know before you answer?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Clarify first: what the new grades 3–5 reading curriculum is, when the team sees it, and what the family reading night each term asks of fourth grade. Use the plan's pieces by name: structured phonics in kindergarten to second grade, the new grades 3–5 reading curriculum from fall 2027, a family reading night at every school each term. Then one thing you would do, as a plan. If natural, mention that you led your grade level's move to a new reading curriculum in 2024, at that scope; do not say it prepared you | The strategy question from research, tied to F4. CO because it scores homework on the district's current direction |
| C2 | "It's the second week of school and transitions between subjects are eating the day. Walk us through what you would do." | CASE | [generic] | Clarify what the transitions look like and what students are doing during them. Objective: get the time back for instruction. Then your own approach in steps, how you would know it worked, one risk. Name only routines you would really use | F7 is the district's own named panel topic with nothing in your material behind it. CASE because it is a live problem with no past premised |
| C3 | "How would you organize a reading block so each student gets time with you?" | CASE | [generic] | Clarify first: class size, block length, the spread of reading levels, and whether the school already has a block structure. Then your design in your own steps, what you would watch, and one risk. Describe what is truly your own experience as yours and nothing else as such | The principal's public reading footprint makes reading structure a likely theme, and F4 sits behind it. CASE because it asks for a design |
| C4 | "A fourth grader joins your class reading well below the others. What do you do in the first two weeks?" | CASE | [generic] | Clarify what is already known and in place. Then first steps, who you would involve, what you would watch, and how you would reach the family, since the district's belief is that every teacher speaks with every family each term. All as plan | F4 and F5 are the beliefs this scenario touches. CASE because it is a live problem |

### D. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Every Child a Reader. Tell us about a time you helped a student become a stronger reader." | VAL | [grounded] "I've run the after-school reading club for the last two years."; "I led our grade level's move to a new reading curriculum in 2024" | Story-mapped on "I've run the after-school reading club for the last two years.": the club, after school, two years, told in your own words. The curriculum sentence can follow if it fits. Answer slot: if any part of the club or the move was set up for individual students, say how and whose decision it was; if no part was, or it was not yours, say so plainly and stay with the club | F4 is the evidence and the likeliest place to be probed. VAL because it scores a published belief by name |
| D2 | "Families Are Partners. Tell us about a time communicating with families mattered." | VAL | [grounded] "I write a weekly email to families." | Story-mapped on "I write a weekly email to families.": weekly, email, families, in your own words, with no outcome the sentence does not state. Answer slot: if any of your family communication went beyond the email, say what it was and how it came about; if it did not, say so plainly and stay with the email | F5 is the evidence. VAL because it scores a published belief by name |
| D3 | "Teach for Tomorrow, Not for the Test. Tell us about a time an assessment changed how you taught." | VAL | [grounded] | No sentence in your material carries this, so choose your own. Criteria: a named assessment, what it showed, what you changed, what you did afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would use an assessment so it informs teaching and does not replace it | F6 is the thinnest row against a published belief. VAL because it scores that belief; the guidance is a scaffold because nothing quoted carries the story |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell us about yourself and how you came to apply." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet."; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years."; "I write a weekly email to families." | A 90-second arc in this order, each beat one of your sentences in your own words: six years teaching third grade at a public elementary school in Joliet; leading your grade level's move to a new reading curriculum in 2024; the after-school reading club for two years; the weekly email to families. Close on your own reason for this role, which A4 asks you to write yourself | The biography prompt is scored whatever its register. EXP because it tests whether your account of yourself is consistent |
| E2 | "What is the reading club reading these days?" | EXP | [grounded] "I've run the after-school reading club for the last two years." | Name the titles the club is actually on now; if it is between books or you are not running it this term, say so plainly. Nothing about why students like it unless you can say it in your own words | A casual question on the principal's own subject, resting on F4. EXP because it tests whether the club is as you describe it |
| E3 | "What would we see if we walked into your classroom on an ordinary day?" | JD | [grounded] | Choose three things you would truly point to, in your own words; one can be a routine you really keep. Nothing here is supplied by the pack, and a routine that is not yours should not be claimed | F7: the district names classroom routines as a panel topic. JD because it scores that topic |

### F. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "When your grade level moved to the new curriculum, what did you look at to see how it was going?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Answer slot: if you looked at assessments or student work, say what you looked at and what you did with it; if you did not, or that was not yours, say so plainly and return to the sentence. Hold the sentence at its own scope | F4 and F6 meet here: the belief on assessment gives the probe its edge. EXP because it tests what was actually yours |
| F2 | "Which part of that move was yours, and which belonged to others?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Say the sentence as written, then say in your own words what you did and what others did. If "led" covers less than the question assumes, say so plainly and describe what you did. Hold through two follow-ups and never add to it | F8: the sentence sits beside a stated gap, so attribution is the likeliest follow-up. EXP because it tests attribution honesty |

### Requirement coverage

| Requirement | Questions |
|---|---|
| Valid Illinois Professional Educator License with an elementary endorsement (F1) | None, and why: a gate your material shows met, a status and not a story; confirm the record yourself |
| Fourth Grade Teacher position (F2, F3) | A1, A2, B4 |
| Every Child a Reader (F4) | D1, F1, C3, C4 |
| Families Are Partners (F5) | D2, C4 |
| Teach for Tomorrow, Not for the Test (F6) | D3, A5, F1 |
| Classroom routines (F7) | C2, E3 |
| Work with the grade-level team (F8) | A3, B1, B2, B3, F2 |
| The district's literacy plan (research) | C1, A4 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your 2025 forum talk was on weekly reading conferences in grades 3 to 5. How does reading time run in fourth grade at Halvering now?" | Ties to the principal's own published path and shows you read her work, not only the district's |
| R2 | "The board's plan brings a new grades 3–5 reading curriculum from fall 2027. How will the fourth-grade team be involved in choosing and rolling it out?" | Shows current homework and asks about the work, not the perks |
| R3 | "Each school will hold a family reading night each term. What would fourth grade's part look like?" | Connects the plan to the belief on families and to your weekly email without claiming more |
| R4 | "What could a new teammate do in their first month that would genuinely help the fourth-grade team?" | The reciprocity question for the two peers on the panel |
| R5 | "For someone new to the grade, what does a strong first year look like, and how does the team help them get there?" | Turns your stated limit on A2 into a conversation about support |
| R6 | "What happens after the panel, and when should I expect to hear?" | A practical close; the careers page says references are taken up after the panel |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Having taught fourth grade | Negative you stated, F3 | The plain acknowledgment F3 gives: "I've never taught fourth grade." No slot |
| Having been a team lead, or having led the fourth-grade team | Negative you stated, F8 | The plain acknowledgment: "I've never been a team lead." The sentence "I led our grade level's move to a new reading curriculum in 2024" stays at its own scope and is not called team leadership |
| Having written or run individual students' reading plans | Inflated form of F4 | The club and the move at their own scope. The pack's observation, not words for you: your material says the move and the club, not what was set up for individual students. D1's slot stays inside the club |
| Having spoken with every family each term | Inflated form of F5 | The weekly email at its own scope. The pack's observation: your material says an email, not conversations. D2's slot stays inside the email |

## Sources

Provided: the invite; your résumé text (a personal identifier in it was not used).

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Query or fetch | What came back |
|---|---|
| Search: Orrinsford Community School District mission values | https://orrinsfordschools.example/about/mission-and-beliefs |
| Fetch: that page | The three beliefs by name and their definitions |
| Search: Orrinsford Community School District teacher hiring interview process | https://orrinsfordschools.example/careers/how-we-hire-teachers |
| Fetch: that page | One 45-minute building panel, principal and two grade-level teachers; panels ask about reading instruction, classroom routines and families; references after the panel |
| Search: Orrinsford Community School District improvement plan news | https://orrinsfordschools.example/news/board-adopts-literacy-plan (search result only, page not fetched) |
| Search: Dolores Vantongeren principal Halvering Elementary School | https://ilprincipalsforum.example/speakers/dolores-vantongeren (search result only, page not fetched) |
| Search: fourth grade teacher job description Illinois elementary school | https://k12jobsboard.example/listings/fourth-grade-teacher (search result only, truncated, page not fetched) |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Orrinsford Community School District values | yes | The three beliefs by name; F4 to F6, the D bank and A5. No values-style round is detected, so there is no values cheat sheet |
| 2. Orrinsford Community School District interview process, teacher | yes | The careers page establishes the loop: one 45-minute panel of principal plus two grade-level teachers; persona weights follow it |
| 3. Orrinsford Community School District strategy or recent news | yes | The August 2026 literacy plan from a search result; C1, A4, R2 and R3. The page itself was not fetched |
| 4. Dolores Vantongeren, Halvering Elementary School | yes | The interviewer read, C3, E2 and R1, from a search result; the page was not fetched. The two team members are unnamed, so no query could be formed for them |
| 5. Representative Fourth Grade Teacher job description | yes | F8 only, from a truncated search result; no JD was supplied |

## Upgrade menu

- The full job posting → F8 and any other rows built from the typical listing become grounded in the district's own words, and any requirement it lists that has no question gets one
- HR's note on what the panel will focus on, or any item they asked you to bring → a build section for it, and the persona weights re-read against it
- The two fourth-grade teachers' names → a read of each, per-seat persona weights and a tailored reverse question
- Your own answers to the slots on D1, D2, D3 and F1, given outside a drill → F4, F5 and F6 regenerate with your words quoted
- Your licence record as issued → F1 moves from medium toward high; checking it is yours
- A document from the 2024 curriculum move, such as a team email or rollout plan → F4 and F8 move from medium toward high
- A sample of your weekly family email → F5 moves from medium toward high
- A `tuesday-dossier.md` from an earlier evaluation of this role → verified evidence and the gaps already recorded would replace the inferred strategy on F3 and F8
