I'm reading the rest of the skill's reference files (personas, research rules, evidence conventions) so I can build your prep pack correctly. I'll write it next.
Your prep pack is built and saved. I'm checking nothing else is needed, then I'll summarize.

Your prep pack is saved as /var/tmp/tuesday-measure/1a/runs/sonnet/alone/part-5/rooms/case-9-canned-3c49d84d/halvering-elementary_fourth-grade-teacher_interview_pack.md. You pasted a Social Security number. I haven't used it and don't need it, and I left your license number out of the pack too. I built it as a panel round with the principal and two fourth-grade teachers, as the invite describes, and without the full job posting.

Your license meets the invite's requirement as you've written it. I didn't check the registration itself, so confirm its status yourself before Thursday.

The most likely question is about fourth grade. You've said you've never taught it and have never been a team lead. The pack's highest-ROI prep is A2, "Your six years are in third grade. Why should we trust you with fourth?" A3 and G1 are close relatives, so rehearse those next.

District research (5 searches, 2 page fetches) found:
- **Hiring process:** one 45-minute building panel, asking about reading instruction, classroom routines and how you work with families.
- **District beliefs:** Every Child a Reader, Families Are Partners, and Teach for Tomorrow, Not for the Test. The pack's values questions are built on them.
- **Literacy plan:** the board's August plan includes a new grades 3–5 reading curriculum from fall 2027. I only saw a search snippet of that news item, so check the district site before Thursday.
- **The principal:** Dolores Vantongeren was a reading specialist for nine years before becoming principal, so expect her to listen closely to reading answers.

Say the word and I'll play the Skeptic on A2, with follow-up questions, and then give feedback.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Do you have the full text of the posting? It would replace the two rows built from a generic fourth-grade posting (F3 and F10) with the district's own wording.
Did HR or anyone mention a sample lesson, materials to bring or a scenario to prepare? Either would add a build section for it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: halvering-elementary_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

- **Role:** Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)
- **Round:** 45-minute panel on Thursday: Principal Dolores Vantongeren and two members of the fourth-grade team (names not given)
- **Built on:** your invite and the résumé text you pasted, with no full posting. Research tier L1 (see Sources)

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did. Where a cell says "answer slot", it is an instruction for the interview, not a question for you to answer now.

| Type | What it scores |
|---|---|
| VAL | Whether your past behavior shows the district's published beliefs |
| EXP | Whether what you have said about your work holds up under follow-up |
| JD | The listed job, including its gaps |
| CO | Whether you know the district's current direction |
| CASE | How you structure a live classroom problem |

**Highest-ROI prep in this pack: A2**, "Your six years are in third grade. Why should we trust you with fourth?" It will be asked in some form. A calm, specific, rehearsed answer changes the interview. A3 and G1 are its close relatives; rehearse them next.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | No gap in your words, and the endorsement range you wrote is grades 1–6. This pack has not checked the registration, and checking it is yours: confirm its status yourself before Thursday. Say it as your CV says it: the license, the endorsement, and the date it is active through |
| F2 | "Fourth Grade Teacher position" — invite | "Six years teaching third grade at a public elementary school in Joliet" — your CV; "I've never taught fourth grade" — your CV | low | [grounded] | transferability | The negative is yours and the words stay yours: "I've never taught fourth grade." The six years stay at their own scope, as third-grade teaching. Never a claim to fourth-grade work. How you would learn fourth grade is said as a plan, never as a past |
| F3 | Work with the grade-level team: a typical duty from a representative posting (K12 Jobs Board, a search result), not this district's wording | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your CV | medium | [inferred] | transferability | The negative is yours: "I've never been a team lead." The move stays at its own scope: you led your grade level's move. Your material does not show what leading it involved, and this pack does not fill that in. Answer slot: if asked what leading it involved, answer from what you actually did, in your own words; if your part was smaller than leading, say so plainly and return to the quote |
| F4 | "reading instruction" — district hiring page, as a topic panels ask about | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | discovery | Your quotes carry the curriculum move and the club, not what happens in your own classroom's reading time. Answer slot: the district's belief that every child is a reader makes a probe on your own reading teaching likely. If you taught from that curriculum in your own class, say how, in your own words; if you did not, or it differed, say so plainly and return to the move you led |
| F5 | "classroom routines" — district hiring page, as a topic panels ask about | none given | none | [grounded] | discovery | Your material says nothing about your routines. Answer slot: expect a probe on them. Say which routines are yours and how you set them up, in your own words; if you have none to describe, or they were shared across your team, say so plainly and say how you would set them up here |
| F6 | "how you work with families" — district hiring page, as a topic panels ask about | "I write a weekly email to families" — your CV | medium | [grounded] | none | No gap in your words, but a CV line with nothing inspected behind it, so expect a probe on it. Lead with it in the quote's own terms, a weekly email to families, because a named practice beats an adjective. Answer from what you actually do |
| F7 | "Families Are Partners: each teacher speaks with every family each term." — district Mission and Beliefs page | "I write a weekly email to families" — your CV | medium | [grounded] | transferability | Your material says the email, not conversations with each family, and the words stay at the email. Answer slot: if you speak with families directly, say how, in your own words; if the email is how you reach families, say so plainly and say what you would add |
| F8 | "Every Child a Reader: no student leaves third grade without a reading plan." — district Mission and Beliefs page | "Six years teaching third grade at a public elementary school in Joliet" — your CV | low | [grounded] | discovery | Your quote shows third-grade teaching, and does not show whether reading plans were part of it. Answer slot: if reading plans were part of your third-grade work, say how, in your own words; if there were no such plans, or they were not yours, say so plainly and return to the six years in third grade |
| F9 | "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it." — district Mission and Beliefs page | none given | none | [grounded] | discovery | Your material is silent on assessment. Answer slot: if a result ever changed what you taught next, say what it was and what you changed, in your own words; if none did, say so plainly and say how you would use one |
| F10 | Plan and teach across subjects: a typical duty from a representative posting (K12 Jobs Board, a search result), not this district's wording | "Six years teaching third grade at a public elementary school in Joliet" — your CV | low | [inferred] | discovery | Your quote does not say which subjects your classroom covered. Answer slot: if you taught subjects beyond reading, say which and what you planned, in your own words; if you did not, say so plainly and return to the six years in third grade |

## Reading the interviewer: Principal Dolores Vantongeren

Public professional footprint only. The two fourth-grade team members are not named, so nothing is read about them.

| Signal | Source | What it means for you | Provenance |
|---|---|---|---|
| Principal of Halvering Elementary since 2022, after nine years as a reading specialist | Illinois principals forum speaker page (search result) | Expect her to listen closely to reading answers. Answer from what you do, in your own words, and no more | [grounded] |
| 2025 forum talk "Small Groups, Big Readers", on weekly reading conferences in grades 3 to 5 | Same page (search result) | Reading in grades 3 to 5 is her own subject. Do not claim a practice of hers, such as weekly reading conferences, unless it is yours | [grounded] |

Mirror opportunities:

- **Shared vocabulary: reading.** Your side of it is F4's row: "I've run the after-school reading club for the last two years." Say it in the quote's own terms and stop.
- **Shared jump: none offered.** Her path runs from reading specialist to principal. No row's evidence carries a matching step of yours, so none is claimed.
- **Reverse question tied to her path:** R1.

## Persona table

The loop is established by the district's hiring page: one 45-minute building panel of the principal and two grade-level teachers, asking about reading instruction, classroom routines and how you work with families. For a panel, the pack blends the top two personas of each member's relationship: the principal as hiring manager (Case and Skeptic), the two grade-level teachers as peers (Peer Evaluator and Prober).

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A) | Quiet, persistent probing of fourth grade and team leadership | High. The principal sits in the hiring-manager seat, and your own two negatives (F2, F3) are where probing lands | Rehearse A2 until it is boring: plain negative, scope held, plan said as a plan |
| Peer Evaluator (bank B) | Two teachers who would work beside you: seams, disagreement, what you need from them | High. The invite names two members of the fourth-grade team, and F3 is a stated gap in team work | Reciprocity: what you bring at the quotes' own scope, and what you would ask of them |
| Case / Strategist (bank C) | Live classroom problems and the board's literacy plan | Medium. The hiring page names classroom routines as a panel topic, and the board plan gives a CO question | Clarify, objective, approach, how you would know it is working, what you would ask the team |
| Values / Behavioral (bank D) | Questions themed on the district's three published beliefs | Medium. The Mission and Beliefs page says they guide every hire, but no loop source names a values round, so the pack has no values cheat sheet | Where a quote carries a story, map it; where none does, say so plainly and give the nearest thing you do have |
| Conversational (bank E) | Friendly opener and closer, still scored | Medium. A 45-minute panel has an opening biography question and a closing slot for your questions | A 90-second arc built only from your own sentences |
| Data-Driven Prober (bank F) | "How do you know it worked?" on the curriculum move and the club | Low. Your résumé text has no figures, so there is nothing to defend by number; the probe lands on how you would know | Say what was checked, or say plainly that nothing was |
| Pressure (bank G) | Time-boxed challenge on fourth grade and on what was actually yours | Low. Nothing in the sources points to a stress style, but the fourth-grade gap invites a time-boxed version | Pause, restate, hold the quote, concede the specific limit |

## Question banks

Provenance carries every sentence of yours that a guidance cell rests on. Where a cell makes no claim about your past, it carries its label alone.

### Bank A: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this fourth-grade job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet" | Pick one specific thing you honestly expect to be weakest at, in your own words. The pack does not know which, and does not choose for you. Say what you would do in the first weeks to close it and who on this team you would ask. Begin with "I've never taught fourth grade" if it is the true reason, and end on the six years at their own scope | F2 is the stated gap, so this opener is likely; JD because it scores fit to the listed job |
| A2 | "Your six years are in third grade. Why should we trust you with fourth?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I've never taught fourth grade" | The highest-ROI rehearsal in this pack. Pause and restate the question. Hold: "Six years teaching third grade at a public elementary school in Joliet", said at that scope. Concede, specifically: "I've never taught fourth grade." Then a plan in the future tense: what you would learn first, from whom, by when, all your own choices. Follow-up 1, "What is different about fourth grade?": say what you know and do not know, and that you would ask the team. Follow-up 2, "What if it takes a term to catch up?": return to the quote and the plan, and add no experience. Never describe fourth-grade work as yours | F2 is the biggest gap and the question arrives in some form; JD because it tests fit to the posted job |
| A3 | "Have you ever been a team lead?" | EXP | [grounded] "I've never been a team lead"; "I led our grade level's move to a new reading curriculum in 2024" | Answer plainly with your own sentence: "I've never been a team lead." Then, as a separate fact, the quote: "I led our grade level's move to a new reading curriculum in 2024", at that scope and not called team leadership. If asked what leading it involved, answer from what you actually did; if your part was smaller than leading, say so plainly and return to the quote | F3 holds the stated negative and the one adjacent quote; EXP because it tests attribution |
| A4 | "A fourth-grade teacher plans and teaches across subjects. What did that look like in your third-grade classroom?" | JD | [inferred] "Six years teaching third grade at a public elementary school in Joliet" | Answer slot: this duty comes from a representative posting, so treat it as likely rather than certain. If your third-grade classroom covered subjects beyond reading, say which and what part of the planning was yours, in your own words; if it did not, say so plainly and return to the six years in third grade | F10 is a typical duty your material does not address; JD because it scores a listed duty |
| A5 | "Why fourth grade, why Halvering, why now?" | JD | [generic] | The reason is yours and this pack has none from you, so it supplies none. Write two sentences you can say without effort: what draws you to fourth grade, and what draws you to this school. If your reason connects to something you have read about the district, say that only if it is true for you. If the reason is practical, give it plainly | F2 is the gap a skeptic tests for motivation consistency; JD because it is about this role |

### Bank B: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell us about a time you disagreed with a colleague on your grade-level team." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Selection scaffold: pick a time with a named disagreement, your position, how it was settled, and a working relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, the quote at its own scope without adding a disagreement it did not contain, or how you would handle one | F3 is the team-work gap and peers test disagreement style; EXP because it tests what actually happened |
| B2 | "Walk us through how your grade level moved to the new reading curriculum." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Story-mapped on the quote: your grade level, the move to a new reading curriculum, 2024, and that you led it. Tell those beats in your own words. For anything beyond them, answer from what you did; if a step was not yours, say so plainly and return to the quote | F3 and F4 both rest on this quote, so a panel will go to it; EXP because it tests attribution |
| B3 | "What would you need from us in your first month, and what would you bring to our team?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families" | Reciprocity framing. Need: name what you would ask the team for to learn fourth grade, in your own words. Bring: the curriculum move, the club and the weekly email, each at its own scope. Say them as what they are, and let the team decide what they are worth | F2 sets the need; F3, F4 and F6 set what you can honestly offer; JD because it scores fit with the team |
| B4 | "A teammate teaches the same unit very differently from you. Where do consistency and your own judgment meet?" | CASE | [generic] | Makes no claim about your past. Ask what differs and what the students need. State the principle you would propose: what should be shared and what can differ. Say how you would raise it with the teammate and when you would take it to the team. Concede that you do not yet know this team's agreements | The seam between teachers is the peer persona's home ground (F3's requirement); CASE because it is a live problem |

### Bank C: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "It is the second week of school and transitions are chaotic. What do you look at first?" | CASE | [generic] | Makes no claim about your past. Clarify first: which transitions, when, which students. Then the objective, one small first change, how you would tell it is working, and what you would ask the team. Your own routines are F5's answer slot, so say only what is true | F5 is a topic the hiring page names; CASE because it is a live problem |
| C2 | "In October a few students are reading well below the rest of the class. What do you do over the next month?" | CASE | [generic] | Makes no claim about your past. Find out what is going on before choosing a plan. Then the plan, how families are involved, how you would check it, and when you would change it. Concede what you would need to ask the team | The district belief on reading plans (F8) is the source of the theme; CASE because it is a live problem |
| C3 | "Most of the class missed the same question on a unit test. What do you do with that?" | CASE | [generic] | Makes no claim about your past. Say what you would look at first, what you would change in the next lesson, and how you would check the change. Keep the test in service of the teaching | F9's belief is the source of the theme; CASE because it is a live problem |
| C4 | "The board adopted a three-year literacy plan in August. What do you know about it, and what would you ask?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Know the three parts the pack found: structured phonics from kindergarten to second grade, a new grades 3–5 reading curriculum from fall 2027, and a family reading night at every school each term. Say what you know and stop there. Connect it only at the quote's scope: you led your grade level's move to a new reading curriculum in 2024. Do not say it is the same work. Then ask where the fourth-grade team is in it. The pack read only a search snippet of the news item, so check the district site before Thursday | F4 is the reading row the plan touches; CO because it scores knowledge of the district's current direction |

### Bank D: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Every Child a Reader: no student leaves third grade without a reading plan. You taught third grade. What did that look like for you?" | VAL | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | Answer slot: if reading plans were part of your third-grade work, say how, in your own words; if there were no such plans, or they were not yours, say so plainly and return to the six years in third grade | F8 is the published belief your quote does not reach; VAL because it scores a named belief |
| D2 | "Families Are Partners: each teacher speaks with every family each term. How do you work with families?" | VAL | [grounded] "I write a weekly email to families" | Start with your own sentence: "I write a weekly email to families." Answer slot: if you speak with families directly, say how, in your own words; if the email is how you reach families, say so plainly and say what you would add to meet the belief | F6 and F7 are the two rows this question reads; VAL because it scores a named belief |
| D3 | "Teach for Tomorrow, Not for the Test: tell us about a time what you learned from an assessment changed what you taught next." | VAL | [generic] | Selection scaffold: pick a time with a named assessment, what it showed, what you changed, and what followed. If no such time comes to mind, say so plainly, then say how you would use an assessment to shape the next lesson | F9 has no evidence, so the answer is a scaffold; VAL because it scores a named belief |

### Bank E: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk us through your journey. How did you get to this application?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families" | A 90-second arc built from those four sentences and nothing else: the six years, the curriculum move, the club, the weekly email. The order is yours. End on your own reason for fourth grade (A5). Add no dates, roles or outcomes that are not in those sentences | F2, F3, F4 and F6 are the evidence an opener draws on; EXP because it tests what you say about your own path |
| E2 | "Tell us about the reading club." | EXP | [grounded] "I've run the after-school reading club for the last two years" | Beats from the quote: after school, a reading club, run by you, the last two years. Tell anything further only as you actually know it, and say plainly if you have not tracked something you are asked | F4 holds the club; EXP because the friendly register is still scored |
| E3 | "Is there anything you would like us to know that is not on your résumé?" | EXP | [generic] | Selection scaffold: pick one fact about your work you can stand behind that bears on fourth grade or this school. If nothing comes to mind, say so plainly and use the moment for your best reverse question | An open closer is scored and often leads into the reverse-question slot; EXP because it tests what you choose to say |

### Bank F: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "How did your grade level know the new curriculum was working?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Answer slot: the district's belief that assessments inform teaching makes a probe on this likely. If your grade level looked at anything to tell whether it was working, say what and what it showed, in your own words; if nothing was checked, or it was not yours to check, say so plainly and return to the quote | F3 and F9 meet here; EXP because it tests whether you know what was done |
| F2 | "What did the club's students get out of it, and how do you know?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Answer slot: if you tracked anything about the club, say what and what it showed, in your own words; if you did not, say so plainly and return to the quote | F4 holds the club and the probe goes to how you would know; EXP because it tests attribution |

### Bank G: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over a candidate who has taught fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I've never taught fourth grade" | Pause and restate the question. Hold: the six years, at their own scope. Concede: "I've never taught fourth grade", as a specific limit rather than an apology. Through two follow-ups, return to what you have said and add no fourth-grade work. Close with the plan from A2 | F2 again, time-boxed; JD because it tests fit to the listed job |
| G2 | "How much of that curriculum move was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Hold: "I led our grade level's move to a new reading curriculum in 2024." If asked which parts were others', answer from what happened; if part belonged to others, say so plainly. Hold the quote through two follow-ups by returning to it, never by adding to it | F3's quote is the attribution target; EXP because it tests what was actually yours |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 license and endorsement | none, and why: your CV shows the gate met, and confirming the registration is yours |
| F2 fourth grade | A1, A2, A5, G1 |
| F3 grade-level team | A3, B1, B2, B3, B4, G2 |
| F4 reading instruction | B2, C2, C4, E2, F1, F2 |
| F5 classroom routines | C1 |
| F6 and F7 families | D2 |
| F8 reading plans | C2, D1 |
| F9 assessment | C3, D3, F1 |
| F10 subjects | A4 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You were a reading specialist before you became principal. What do you hope a fourth-grade reading time looks like here?" | Tied to her own path, which signals you researched her and not only the school |
| R2 | "What could a new fourth-grade teacher do in the first month that would genuinely help your team?" | The reciprocity question for the two teachers on the panel |
| R3 | "The board's literacy plan includes a new grades 3–5 reading curriculum from fall 2027. Where is the fourth-grade team in that work, and how would a new teacher join it?" | Shows you read the plan and asks about the work, not the slogan |
| R4 | "How does the team plan together, and who decides when teachers differ?" | Asks about the seam B4 rehearses, from the team's side |
| R5 | "What does support look like for someone new to fourth grade in the first term?" | Turns the gap into a plan you want help with, which is how A2 ends |
| R6 | "What would you want to see from a new teacher by the end of the first term?" | Lets the panel name its own bar |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade, or has fourth-grade experience | Negative you stated, F2 | The plain acknowledgment your sentence gives: "I've never taught fourth grade." Then the third-grade years at their own scope. No slot |
| Has been a team lead, or led the grade-level team | Negative you stated, F3 | The plain acknowledgment: "I've never been a team lead." Then the curriculum quote at its own scope. No slot |
| Chose, designed or owned the new reading curriculum | Inflated form of F3's quote | The quote at its own scope: you led your grade level's move. The limit is the pack's observation: your material says the move, not who chose the curriculum |
| Speaks with every family each term | Inflated form of F6's quote | The quote at its own scope: a weekly email to families. The limit is the pack's observation: your material says the email, not conversations with each family |

## Sources

Provided documents: the invite text and the résumé text you pasted. No dossier was present.

Searches sent:

1. `Orrinsford Community School District mission values` returned https://orrinsfordschools.example/about/mission-and-beliefs
2. `Halvering Elementary School Orrinsford district strategic plan` returned https://orrinsfordschools.example/news/board-adopts-literacy-plan (snippet only, not opened)
3. `Dolores Vantongeren principal Halvering Elementary` returned https://ilprincipalsforum.example/speakers/dolores-vantongeren (snippet only, not opened)
4. `Orrinsford Community School District teacher interview process` returned https://orrinsfordschools.example/careers/how-we-hire-teachers
5. `Fourth Grade Teacher job posting Illinois elementary school responsibilities` returned https://k12jobsboard.example/listings/fourth-grade-teacher (snippet only, cut off mid-sentence, so its qualifications were not read)

Pages fetched: the Mission and Beliefs page and the How we hire teachers page.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | yes | The three published beliefs themed D1 to D3 and F7 to F9. No loop source names a values round, so there is no values cheat sheet |
| 2. `{company} interview process {role family}` | yes | Established the loop: one 45-minute panel of the principal and two grade-level teachers, and its topics. Persona weights follow it |
| 3. `{company} strategy` / recent news | yes | One result, the board's literacy plan, feeding C4 and R3 |
| 4. `{interviewer name} {company}` | yes | The interviewer read for the principal. The two teachers are unnamed, so nothing was read about them |
| 5. representative `{role title}` JD | yes | F3 and F10, both labelled `[inferred]`, and A4. The snippet was cut off, so it moved less than a full posting would |

## Upgrade menu

- The full posting text → F3 and F10 move from the representative posting's wording to the district's own, and the JD-tagged questions retune
- Anything HR said about a sample lesson, materials to bring or a scenario → a build section for that deliverable
- The names and roles of the two fourth-grade team members → per-member persona weights and a tailored reverse question
- Your answers to the answer slots, said outside a drill → F3, F4, F5, F7, F8, F9 and F10 become story-mapped rows with higher confidence
- One sample weekly family email, and a document from the 2024 curriculum move such as the grade level's plan or notes → F4, F6 and F7 can reach high confidence, since there would be something inspectable behind the quotes
- How many hours you have before Thursday → a prep triage sized to it
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a grounding brief on the board's literacy plan and more of the principal's public talks, and a sharper CO bank
- A tuesday-dossier.md from an earlier evidence check → verified evidence and sourced prohibited claims in place of this pack's local inference
