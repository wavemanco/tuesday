I'm reading the skill's remaining reference files (personas, evidence rules, research checklist) before I write your pack. The invite has several scam warning signs, so I'll flag those first.
Before the prep, a warning about the invite. It asks you to "transfer the €95 equipment registration fee to our supplier's account, IBAN IE00 ...", then to "reply with a photo of your passport and your bank details before the interview". It also says you'll get "a cheque for €1,850" and should "deposit the cheque and send the balance on to the vendor".

Asking for money, ID and bank details before any offer is a known scam pattern. So is a cheque you deposit and then send part of on. This job is very likely a scam. If a cheque like that later bounces, the money you sent on is gone.

Hold all of it until you've checked the invite with the employer. Do the payment, the cheque, the passport photo and the bank details. Use contact details you find yourself on the company's own website or careers page, not the email or any number in the invite. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite's requests weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as `/var/tmp/tuesday-measure/1a/runs/sonnet/alone/part-5/rooms/case-12-denied-0f132e69/Brennock-Facilities_remote-administrative-assistant_interview_pack.md`. It has 19 questions, a fit snapshot and reverse questions. Reverse question R5 asks how equipment and payroll paperwork work, and what you hear back lets you compare it with the invite. The heaviest rehearsal is A1: which of travel, supplier invoices and Excel you have actually done yourself.

The pack assumes the office manager is a hiring-manager type who will work alongside you, and that the ad says what you described. My web searches on the company were refused, so it has no company research, only generic rehearsal on values and strategy. Your clinic experience is quoted exactly, and nothing in the pack goes beyond those words.

- Word version: I can convert the pack to .docx if you want it.
- Drill: I can run a live mock interview on any question, with follow-ups.
- Dossier: I can write `tuesday-dossier.md` with this pack's feedback.

Can you paste the full text of the job ad (or say if you'd rather skip that)? It would let me quote the duties directly and add any I've missed.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Brennock-Facilities_remote-administrative-assistant_interview_pack.md -----
# Interview pack: Remote Administrative Assistant, Brennock Facilities Ltd

Candidate: Aoife. Interviewer: the office manager (name not given). Format: 30-minute video call, one session. Built on the ad as you described it, since the full text was not supplied.

## How to use this pack

Personas are how a question arrives (who is asking, in what style). Types are what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did. Where a cell says "answer slot", it is an instruction for the interview itself: answer from your real experience, or say plainly that you have not done it.

Type key:

- VAL: whether your past behaviour shows the values the employer publishes
- EXP: whether your background survives scrutiny; what was actually you
- JD: the stated duties, including the gaps
- CO: knowledge of the company and its strategy
- CASE: a live problem from the job, reasoned aloud

## Fit snapshot

Requirements are the duties as you described the ad ("managing calendars, booking travel, preparing documents in Word and Excel, and processing supplier invoices") and are labelled with that source.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as you described it | "I ran the appointment book for four physios" — your message | medium | [grounded] | presentation | A message line with nothing inspected behind it, so expect a probe on it. Say it in the quote's own terms: "I ran the appointment book for four physios." Say nothing wider about what a calendar or diary involves |
| F2 | "booking travel" — the ad, as you described it | none given | none | [grounded] | discovery | Your material does not show travel booking either way. Answer slot: the ad names it, so expect a probe on travel you have booked. If you have booked any, say what, in your own words; if you have not, say so plainly and stay with the appointment book |
| F3 | "preparing documents in Word" — the ad, as you described it | "I'm good with Word" — your message | low | [inferred] | discovery | A self-rating with no document behind it. Keep it at its scope: "I'm good with Word." Answer slot: the ad names document preparation, so expect a probe on what you have prepared. If you prepared documents, say which, in your own words; if you did not, say so plainly and say what you have used Word for |
| F4 | "preparing documents in Excel" — the ad, as you described it | "okay with Excel" — your message | low | [inferred] | discovery | Your own rating is "okay", and the words stay there: "I'm okay with Excel." Answer slot: expect a probe on what you have done in it. If you used it for something, say what, in your own words; if you did not, say so plainly. A learning plan may be said as a plan, never as a past |
| F5 | "processing supplier invoices" — the ad, as you described it | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Your material says chasing unpaid invoices at the clinic, not supplier invoices, and the words stay at that scope: "At the physiotherapy clinic, I chased unpaid invoices." Answer slot: if you handled any supplier invoices, say what you did with them, in your own words; if you did not, say so plainly and stay with the chasing |

## Persona table

The loop is one session with the office manager, a source you gave. No relationship was stated beyond that title, so the weights assume someone who will work alongside you and judge whether you can do the listed duties. If you know more, the weights should move.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Quiet probing of travel, supplier invoices and Excel | Highest: F2 to F5 are the thin rows, and a 30-minute call has no room to look elsewhere | Rehearse A1 until it is boring; say the limit before it is asked for |
| Case/Strategist (B) | Small live problems from the job: clashes, rebookings, mismatched invoices | High: an admin role is scored on how you handle a problem live | Clarify first, then state your order of steps aloud |
| Conversational (C) | Friendly walk through your background | High: office managers often open this way, and it is still scored | A short, true arc built from your own sentences |
| Data-Driven Prober (D) | How you actually ran the appointment book and chased invoices | Medium: the CV lines are short and easy to follow up | Describe only what you did, and say so when you do not remember how something was done |
| Peer Evaluator (E) | How you would work with the office manager and the team remotely | Medium-low: the office manager may be a day-to-day colleague | Offer what you bring, and ask what they need |
| Pressure (F) | A blunt "why you" or "is okay enough" | Low: a short call, but one blunt question is likely | Hold through two follow-ups, then concede the specific limit |

## Question banks

The highest-ROI prep in this pack is A1: it asks which of the duties you have done yourself, and the answer is probable in some form.

### A. Skeptic (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which of these duties, if any, have you done yourself: travel, supplier invoices, Excel?" | JD | [grounded] "I ran the appointment book for four physios" "chased unpaid invoices" "okay with Excel" | Go duty by duty. Calendar side: "I ran the appointment book for four physios." Invoice side: you chased unpaid invoices, at that scope. Excel: you said "okay", keep it there. Answer slot: for travel and for supplier invoices, if you did any, say what, in your own words; if you did not, say so plainly and return to the appointment book and the chasing. Hold through two follow-ups by returning to those words, never by adding to them | F2, F4 and F5 are where the ad presses hardest, so this arrives in some form. JD because it scores the stated duties |
| A2 | "How would you rate your Excel, and what have you used it for?" | JD | [inferred] "okay with Excel" | Your rating is "okay", so say that. Answer slot: if you used it for something, say what; if you did not, say so plainly. Then say what you would learn first, as a plan | F4 is a low-confidence row and Excel is named in the ad |
| A3 | "You chased unpaid invoices. Processing supplier invoices is different work. What would you need to learn?" | JD | [grounded] "chased unpaid invoices" | Say what you did, at its scope. Answer slot: if you handled any supplier invoices, say what you did with them; if not, say so plainly. Then a plan for learning it, said as a plan | F5 is transferability: adjacent work, not the same work |
| A4 | "Why this job, and why now?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | Selection scaffold: your own real reasons, in your own words. If you have no settled reason, say so plainly, then give the nearest honest thing | Motivation consistency is the Skeptic's score; EXP because it tests your story |

### B. Case/Strategist (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A manager wants a 90-minute meeting with five people this week, and two have no free slot. What do you do?" | CASE | [generic] | Clarify what is fixed (who is essential, how flexible the time), propose two options, say what you would tell the two who cannot make it. The question needs no claim about your past, so the guidance makes none | Calendar management is the first named duty |
| B2 | "You booked a flight for Tuesday and the meeting moves to Wednesday. Walk me through it." | CASE | [generic] | Check the change terms and cost first, confirm the new date with the traveller, then rebook or cancel and tell them what changed. No claim about your past | Travel booking is a named duty and F2 has no evidence |
| B3 | "A supplier invoice arrives that does not match the order. What do you do?" | CASE | [generic] | Say what you would check, who you would ask, and that you would not pay or approve until it is resolved. No claim about your past | F5 is thin, so a live problem tests reasoning without needing a past |
| B4 | "Someone gives you a rough 12-page document to turn into something presentable in Word, due this afternoon. How do you start?" | CASE | [generic] | Ask what it is for and who reads it, fix structure before polish, and say what you would check before sending | Document preparation is a named duty |

### C. Conversational (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your journey." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | A short arc in your own words: the two years, the clinic, the appointment book and the invoices, then why this role. Use only the quoted sentences and your own real reasons | The most likely opener; casual questions are still scored |
| C2 | "What did a normal day running the appointment book look like?" | EXP | [grounded] "I ran the appointment book for four physios" | Describe the day as it was. Answer slot: if you remember particular routines or tools, name them, in your own words; if not, say so plainly and describe what you remember | Premised on F1's quote; a chatty way to probe it |
| C3 | "What do you like about admin work?" | VAL | [generic] | Your honest answer only. If nothing comes quickly, say so plainly, then give the nearest true thing | Genuine interest is scored |
| C4 | "Tell me about a time several people wanted your time at once." | EXP | [grounded] "I ran the appointment book for four physios" | Open prompt, theme from the ad's calendar duty. Story map: the appointment book for four physios. Answer slot: if there was a moment of competing requests, say what happened and what part was yours; if there was none, say so plainly and describe how you ran the book | F1 is your only multi-person evidence |

### D. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how you ran the appointment book for four physios." | EXP | [grounded] "I ran the appointment book for four physios" | Tell it in your own words, at the quote's scope. Answer slot: if you used a particular system, say which; if you do not remember, say so plainly | F1 is the most inspectable evidence you have |
| D2 | "Take me through how you chased unpaid invoices." | EXP | [grounded] "chased unpaid invoices" | Describe what you did, step by step as you remember it. Answer slot: if you remember how much was owed or how long it took, say so; if you do not know, say so plainly | F5; probers ask how, and the honest branch is "I don't remember" |
| D3 | "How do you check a document or an invoice is right before it goes out?" | JD | [generic] | Your actual habit, in your own words. If you have no fixed routine, say so plainly and say what you would do | Accuracy is the core of invoice and document work |

### E. Peer Evaluator (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "When two people both say their request is urgent, how do you decide?" | CASE | [generic] | Ask what each deadline is, tell both what you are doing and why, escalate if you cannot decide. No claim about your past | A peer-style load question |
| E2 | "This role is remote. How do you stay in touch and keep work visible?" | JD | [generic] | Your own honest habits. If you have not worked remotely, say so plainly and say what you would do | The invite names the role as remote |

### F. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "You have two years of reception. Why you over someone with more office experience?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" "I ran the appointment book for four physios" | Pause, then hold: two years, the appointment book for four physios, in those words. Hold through two follow-ups. Concede the specific thing: what you have not done is not covered by those words, so say you would learn it | Hold-then-concede on what the quotes carry |
| F2 | "The job involves preparing documents in Excel. You describe yourself as okay with it. Is that enough?" | JD | [inferred] "okay with Excel" | Pause. Say your rating is "okay", then what you would do to close the gap as a plan. Hold through two follow-ups, concede the limit specifically, never claim more | F4 is a low row; this is where a candidate overclaims |

## Requirement coverage

| Requirement | Questions |
|---|---|
| managing calendars | A1, B1, C2, C4, D1, E1 |
| booking travel | A1, B2 |
| preparing documents in Word | B4, D3 |
| preparing documents in Excel | A1, A2, F2 |
| processing supplier invoices | A1, A3, B3, D2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would my first month look like, and which tasks would I own first?" | Shows you are thinking about doing the work |
| R2 | "Which calendar, travel and invoice tools does the team use, and what training is there?" | Honest about learning, aimed at your thin rows |
| R3 | "Who would I support, and who sets my priorities when requests clash?" | Connects to the clash questions in B and E |
| R4 | "What does good look like at three months?" | Gives you a standard to work to |
| R5 | "How do new starters get their equipment and complete payroll paperwork, and when in the process is that done?" | Ordinary onboarding talk, and the answer lets you compare what you are told with what the invite asked of you |
| R6 | "Is there a written job description and an employment contract I can read before the next step?" | A reasonable request that also gives you something to check |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed senior staff calendars or diaries | Inflated form of F1 | F1's quote at its own scope. Limit, as the pack's observation: your material says the appointment book for four physios |
| Processed supplier invoices | Inflated form of F5 | F5's quote at its own scope. Limit, as the pack's observation: your material says chasing unpaid invoices |
| Advanced or confident Excel | Inflated form of F4 | F4's quote at its own scope: you said "okay" |

## Sources

Provided: the invite email text, your description of the ad, your background in your message.

Searches sent, all refused (the host did not grant permission): "Brennock Facilities Ltd values"; "Brennock Facilities Ltd interview process administrative assistant"; "Brennock Facilities Ltd strategy news". Nothing came back, so nothing about the company's values, loop or strategy is in this pack. Loop structure rests on the invite's own words: one 30-minute video call with the office manager.

Research tier: L1 — searches 3 of 6 sent, all refused; fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. company values | unavailable | Would have fed a values cheat sheet; no values round is detected, so only VAL questions are generic |
| 2. interview process | unavailable | Would have checked the loop; the invite's own words fix this one session |
| 3. strategy / recent news | unavailable | Would have fed a CO question; none is included, and the upgrade menu says so |
| 4. interviewer name | n/a | No name was given |
| 5. representative JD | skipped | Your description of the ad fixes the requirement rows |

## Upgrade menu

- The full ad text → the five requirement rows quote the ad itself, and any duty your description left out gets a row and a question
- Anything the recruiter or office manager said about the interview's focus → coverage tuned to it instead of assumed
- The office manager's name → an interviewer read and a reverse question tied to their path
- An anonymised example of a document or spreadsheet you made → could raise F3 and F4 from low
- A permitted web search, once the employer has been verified → company values, strategy and a CO question
- Your reasons for wanting this role, and any travel, invoice or Excel work you have done → regenerates A1 to A4 and F5 with your own words
- A dossier: if you want one, I can emit tuesday-dossier.md with this pack's feedback
