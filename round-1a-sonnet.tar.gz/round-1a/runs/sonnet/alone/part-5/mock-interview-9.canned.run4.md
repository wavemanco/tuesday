Your prep pack is saved as `halvering-elementary_fourth-grade-teacher_interview_pack.md`. I couldn't run a final check that every table renders cleanly, so skim the tables when you open it. It's built for the panel round in your invite: Principal Vantongeren and two fourth-grade teachers. You didn't give me the posting text, so the requirement rows marked `[inferred]` come from a typical fourth-grade posting.

Your résumé text included a Social Security number. It isn't needed for this and I didn't use or repeat it. It also doesn't belong on a résumé you send out, so I'd remove it.

The pack has 18 rehearsal questions across five panel styles, a fit snapshot, a read on the principal's public background, reverse questions, and a short list of claims it won't coach. The one to practise first is A1, the likely "no fourth grade on your résumé" question. A2 is second, because it tests how far your "I led our grade level's move to a new reading curriculum" line stretches given you've never been a team lead.

Say the word and I'll play the Skeptic on A1 so you can rehearse it live. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

1. Did HR or the principal's office say anything about what the panel will focus on, or anything to bring, like a sample lesson?
2. Do you have the full posting text, so the inferred rows can be rebuilt against this district's own wording?
3. Do you want a deeper research pass on the district, up to 6 more searches and 2 more page fetches, taking a few more minutes?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: halvering-elementary_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**Employer:** Orrinsford Community School District. **Round:** one 45-minute panel on Thursday. **Panel:** Principal Dolores Vantongeren and two members of the fourth-grade team (names not given). **Built on:** your invite and résumé text. No posting text was supplied, so requirement rows marked `[inferred]` come from a typical fourth-grade posting.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the district's published beliefs |
| EXP | Whether your résumé lines survive scrutiny, and what was actually yours |
| JD | The listed responsibilities and qualifications, gaps included |
| CO | Whether you know the district's current direction |
| CASE | How you think through a live classroom problem |

- A sentence in quotation marks is yours, quoted from what you gave me. Guidance never says more about your past than those sentences do.
- An **answer slot** is an instruction for the interview. Answer it from your own experience. If the practice it names was not yours, or never existed, say so plainly and return to the sentence. That is an honest answer, not a failed one.
- **Highest-ROI prep in this pack: A1.** You have said you have never taught fourth grade, so some form of that question will come.

## Prep triage

1. Say A1 aloud until it is boring. It is the question most likely to be asked.
2. Say E1 and A2 aloud. They use the same three sentences of yours, and A2 tests how far "led" stretches.
3. Read C3, D1 and D2, then the three beliefs and the literacy plan in the Sources.
4. Check that your license record shows active before Thursday (E2).

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "must hold a valid Illinois Professional Educator License with an elementary endorsement" — invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | A gate your material shows met: kind, endorsement and status are your CV's own terms, and the range you state, grades 1–6, includes grade four. Nothing has been inspected behind the line, and this pack did not look the license up, so expect a request to confirm it. Checking that the state's license record shows it active is yours to do before Thursday. Say it as the CV does |
| F2 | "Fourth Grade Teacher position" — invite | "I've never taught fourth grade" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't taught fourth grade." Then how you would learn the grade, said as a plan and never as a past. Nothing added to make the gap smaller. A1 rehearses it |
| F3 | "experience in grades 3 to 5 preferred" — typical posting, K12 Jobs Board | "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [inferred] | none | Third grade sits inside the band that typical posting prefers, and your CV states it plainly, so use the sentence as written. It is a CV line with nothing inspected behind it, so expect a probe. The posting is another employer's, which is why the row is inferred until you paste this district's |
| F4 | "plan and teach reading, writing, math, science and social studies" — typical posting, K12 Jobs Board | "Six years teaching third grade at a public elementary school in Joliet." — your CV | low | [inferred] | discovery | The sentence says third grade, not which subjects. Answer slot: a typical posting lists these five areas, so expect a probe on which you taught. Name the ones you taught, and for any you did not, say so plainly and say what you would do about it |
| F5 | "differentiate instruction using assessment data" — typical posting, K12 Jobs Board | none given | none | [inferred] | discovery | Your material is silent here. Answer slot: if you have grouped or adjusted lessons from assessment results, say what you did and how you decided, in your own words. If not, or if it was not yours to do, say so plainly and say how you would start |
| F6 | "keep clear classroom routines" — typical posting, K12 Jobs Board | none given | none | [inferred] | discovery | Your material is silent here. Answer slot: if there are routines you set in your own room, name one and how you taught it. If the routines were set by others, or you had none, say so plainly and answer as a plan for a new class |
| F7 | "communicate regularly with families" — typical posting, K12 Jobs Board | "I write a weekly email to families." — your CV | medium | [inferred] | none | Lead with the email in the sentence's own terms: you write it, it is weekly, it goes to families. A named record beats an adjective. It is a CV line with nothing inspected behind it, so expect a probe on it |
| F8 | "work with the grade-level team" — typical posting, K12 Jobs Board | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your message | medium | [inferred] | presentation | The first sentence already reaches team work in other terms. Words: "In 2024 I led our grade level's move to a new reading curriculum." Keep "led" at the scope of the move, because your own second sentence says "I've never been a team lead." A2 rehearses that boundary |
| F9 | "Every Child a Reader: no student leaves third grade without a reading plan" — district Mission and Beliefs page | "I've run the after-school reading club for the last two years." — your CV; "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [grounded] | transferability | The belief names third grade, where your CV has six years, and your reading club is adjacent work, not a reading plan. The words stay at each sentence's own scope. Answer slot: if reading plans for individual students were part of your third-grade work, say how they worked and what part was yours. If they were not, say so plainly and stay with the sentences |
| F10 | "Families Are Partners: each teacher speaks with every family each term" — district Mission and Beliefs page | "I write a weekly email to families." — your CV | low | [grounded] | discovery | The sentence is an email, and the belief is worded around speaking, so the material does not show whether the two meet. Answer slot: describe the email as it is, what it holds and who it reaches. If that is the whole of it, say so plainly and say what you would add here |
| F11 | "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it" — district Mission and Beliefs page | none given | none | [grounded] | discovery | Your material is silent here. Answer slot: if assessment results ever changed what you taught, say what changed and how you decided. If they did not, or the decision was not yours, say so plainly and say how you would use results |

## Reading the interviewer

Public professional footprint only. The two fourth-grade team members are unnamed, so there is no read on them.

| Public fact | Source | What it means for you |
|---|---|---|
| "Dolores Vantongeren has been principal of Halvering Elementary School since 2022, after nine years as a reading specialist." | ilprincipalsforum.example speaker page | Expect reading questions to be asked with a specialist's ear, so describe reading work in concrete terms, not slogans |
| "Her 2025 forum talk, Small Groups, Big Readers, covered weekly reading conferences in grades 3 to 5." | ilprincipalsforum.example speaker page | Reading in grades 3 to 5 is a stated interest of hers. That is where the shared ground is: your reading club, in the words of F9's evidence, "I've run the after-school reading club for the last two years." Offer it at its own scope and let her ask |

Two practical notes. First, a shared domain is not a shared career jump, so do not frame it as one. Second, her talk is about a practice your material does not mention, so do not claim it, and if she asks about it, answer from what you have actually done or say plainly that it was not yours.

## Persona table

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | The principal's quiet probe at the gaps: fourth grade, team leadership, subjects taught | High. A principal on a hiring panel tilts toward Skeptic and Case, and F2 and F8's second sentence are gaps you stated yourself | Rehearse A1 until it is boring. Bridges come only from sentences you stated, and the ramp is a plan, not a past |
| B. Peer Evaluator | The two fourth-grade teachers asking what you add to their team and where you would disagree | High. Two of three panelists are teammates, and peers price what a hire does to their own load | Reciprocity first: what you bring, then what you need. Offer working principles, not claims about a seam you have not seen |
| C. Case/Strategist | Live classroom problems on reading, routines and assessment | Medium-high. The principal row tilts toward Case, and the district's hiring page says panels ask about reading instruction, classroom routines and how you work with families | Clarify, then objective, approach, metrics, risks. Think aloud and challenge one premise politely |
| D. Values/Behavioral | Scenarios mapped to the district's three published beliefs | Medium. The beliefs are published, but the hiring page names no values round, so there is no separate cheat sheet. The beliefs theme this bank | Where a sentence of yours carries a story, use it at its scope. Where none does, use the selection scaffold and its honest branch |
| E. Conversational | The opener and casual follow-ups | Medium. Panels usually open this way, and casual questions are still scored | A 90-second arc built only from your own sentences (E1) |
| Prober | Line-by-line questions on your résumé | Low. No headline figures appear in your material. CV-line probes are carried in A2, A4 and B4, so there is no separate bank | Know exactly what each sentence says, and say plainly when something was not yours |
| Pressure | Time-boxed or devil's-advocate challenges | Low. Nothing found in the research points to this format. Hold-then-concede is built into A1 and A5, so there is no separate bank | Pause, restate the question, hold the sentence, concede only what it concedes |

## Question banks

Bank sizes follow the weights: A 5, B 4, C 4, D 3, E 3.

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "I see third grade on your résumé and no fourth. How do you see that?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet." | The highest-ROI rehearsal in this pack. Lead with the stated fact before you are asked twice: "I haven't taught fourth grade. I've taught third grade for six years at a public elementary school in Joliet." Name the limit yourself: the sentences are what you have, and comparing them with someone who has taught fourth grade is the panel's call. Follow-up one, "what's your plan": answer slot, say what you would do first to learn this grade's expectations, in your own words and as a plan, not a past. If you have already started, say so plainly; if you have not, say that. Follow-up two, "does that worry you": hold the sentences and concede only what they concede. Follow-up three, a comparison with a fourth-grade veteran: it is their call. Never add a visit, a shadowing day or a unit you did not do | F2 is the stated gap, so this objection arrives in some form. JD because it scores the role's own title, and A1 is the pack's deepest rehearsal because it is the likeliest question |
| A2 | "You wrote that you led your grade level's move to a new reading curriculum. What part of it was yours?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead" | Say the sentence at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: expect a probe on what leading it covered. If parts of the move were yours to decide, say which and how you decided, in your own words. If they were not, or the move was shared, say so plainly and stay with the sentence. If asked about titles, say it as you wrote it: "I've never been a team lead." Keep "led" at the scope of the move and hold it through two follow-ups by repeating the sentence, never by adding to it | F8 pairs a "led" with a stated limit, and attribution probes exist to test exactly that seam. EXP because it tests what was actually yours |
| A3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" | Pick the real one. Your material states one: "I've never taught fourth grade." Answer slot: if another requirement in the posting is one you have not done, name it and say how you would get there. If none comes to mind, say so plainly, then name the stated gap. Whichever you pick, give the ramp as a plan in your own words, not as a past | Stem question for the Skeptic. F2 and F5 to F6 are where the material is thinnest, and candor here scores more than a polished non-answer |
| A4 | "The role covers reading, writing, math, science and social studies. Which of those did you teach in third grade?" | JD | [inferred] "Six years teaching third grade at a public elementary school in Joliet." | Start from the sentence as written. Answer slot: a typical posting for this role lists these five subjects, so expect this probe from any panel. Name the subjects you taught. For any you did not, say so plainly and say what you would do about it. Do not guess at a subject your record does not show | F4's evidence says third grade, not which subjects. The list is from a typical posting, not this district's, so the row stays inferred until you paste theirs |
| A5 | "Sixty seconds: why you over someone who has already taught fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet."; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years."; "I've never taught fourth grade" | Hold, then concede. Hold: say those three sentences plainly, in order, inside sixty seconds. Concede: "I haven't taught fourth grade." Do not argue that your record beats theirs, because the comparison is the panel's job. Hold through two follow-ups by repeating the sentences, never by adding to them | Pressure stem folded into the Skeptic bank, since F2 is the gap it aims at. JD because it scores fit against the role as titled |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our fourth-grade team plans together. What would you bring to that table, and what would you need from us?" | JD | [inferred] "I led our grade level's move to a new reading curriculum in 2024" | Reciprocity: what you bring first, then what you need. What you bring rests on one sentence, told at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: the posting asks about working with the grade-level team, so expect a probe on how colleagues were involved. Say what part was yours and how colleagues took part, in your own words. If the work was mostly yours, or not yours to share, say so plainly and stay with the sentence. What you need from them: offer a working principle in your own words, not a claim about how their team's seams run | F8 is the evidence for the teamwork requirement. JD because it scores that requirement, delivered collegially as peers do |
| B2 | "Tell me about a time you disagreed with a teammate about how to teach something." | VAL | [generic] | Choose a disagreement with a named subject, what you said, how it was settled, and the working relationship afterward, so spine and tact both show. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. The guidance makes no claim about your past | Peer stem on disagreement style with equals. `[generic]` because it is a pattern, not a fact about this team |
| B3 | "How do you share credit when work spans a team?" | VAL | [generic] | Give the principle first: who did what in "we", your own part in "I". If a specific time comes to mind, tell it in your own words. If not, say so plainly and say how you would handle credit | Peer stem on credit-sharing. Short and easy to drift on, so a principle ready in advance is the rehearsal |
| B4 | "Tell us about the after-school reading club." | EXP | [grounded] "I've run the after-school reading club for the last two years." | Say the beats the sentence states: you run it, it is after school, it is a reading club, and it has been two years. Answer slot: expect a probe on how it runs. If you chose the format or the books, say what and why, in your own words. If you followed one set by others, or there was no set format, say so plainly and stay with the club you run | F9's evidence is the strongest reading material you have, and peers ask about it out of curiosity as much as scrutiny. EXP because it tests what you actually ran |

### C. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A student joins your fourth-grade class with a reading plan from third grade. What do you want to see first, and what do you do in the first weeks?" | CASE | [generic] | Clarify first: what the plan says, who wrote it, what data sits behind it. Then the objective for the first weeks, your approach, how the family hears about it, and how you check progress and when you would change course. Think aloud. The question needs no claim about your past, so the guidance makes none | A live problem from the district's reading-plan belief in F9's requirement, delivered as a decision. `[generic]` because it is a pattern for the problem |
| C2 | "Your class's assessment results show readers at very different levels. How do you decide what changes in your teaching?" | CASE | [generic] | Clarify what the assessments measure and what else you know about each reader. Then the objective, grouping options and how you would keep groups flexible, and how results inform your planning without replacing your own judgment, which is how the district words its own belief. Then metrics and risks. No claim about your past | F5 and F11 are both silent in your material, so this is rehearsed as a plan. CASE because it is a decision, with JD content |
| C3 | "The board adopted a literacy plan with a new grades 3–5 reading curriculum starting fall 2027. What would you want to know about it, and where would you fit?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Bring one fact to show you read it, then your own thinking. Ask what you would want to know: timing, training, how fourth grade sits in the rollout. Where you fit: say your sentence at its own scope, "I led our grade level's move to a new reading curriculum in 2024", and do not compare it with theirs. Answer slot: if anything from that move bears on a rollout, say what and in your own words. If nothing does, say so plainly and ask instead | The strategy-grounded question this pack owes you. F8 is where your material touches the topic, and the plan is a public document any prepared candidate can recite, so the differentiator is your own question |
| C4 | "It is the first two weeks with a new class of fourth graders. Which routines do you set up, and how do you teach them?" | CASE | [generic] | Name the routine categories you would set, such as arrival, transitions, the reading block and asking for help. Say how you would teach each: model it, practice it, adjust it. Answer slot: if there are routines you have run in your own room, name one in your own words. If not, say so plainly and answer as a plan | F6 is silent in your material, and the district's hiring page says panels ask about classroom routines. CASE because it is a scenario, with JD content |

### D. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Every Child a Reader means no student leaves third grade without a reading plan. What did that look like in your third-grade classroom?" | VAL | [grounded] "Six years teaching third grade at a public elementary school in Joliet." | The beats the sentence states: six years, third grade, a public elementary school in Joliet. Answer slot: the district's belief puts a reading plan at the end of third grade, so expect a probe on your room. If plans for individual students were part of your work, say how they worked and what part was yours. If they were set by others, or there was no such step, say so plainly and stay with what the sentence states | F9 is where your third-grade record meets a published belief. The premise comes from the district's page, so the second branch lets it be false |
| D2 | "Families Are Partners: each teacher here speaks with every family each term. How do you work with families?" | VAL | [grounded] "I write a weekly email to families." | Say the sentence: "I write a weekly email to families." Answer slot: describe the email as it is, what it holds and who it reaches. If that is the whole of it, say so plainly and say what you would add here. Do not add a practice the sentence does not state | F10 is the gap between an email and the belief's wording. VAL because it scores a published belief, and the hard truth lands better said plainly |
| D3 | "Teach for Tomorrow, Not for the Test. Tell me about a time assessment results changed what you taught." | VAL | [generic] | Pick a time with a named result, what you changed, and what happened next. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would use results so that they inform your teaching and never replace it | F11 is silent in your material, so this is a selection scaffold. `[generic]` because it makes no claim about your past |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk us through your journey." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet."; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years." | A 90-second arc using only the beats your sentences state: six years teaching third grade at a public elementary school in Joliet, the 2024 move, the reading club. Answer slot: why fourth grade now. Say your own reason. If you have none beyond wanting the next grade, say so plainly. End on what you want from this role | F3's sentence opens most panels. A casual opener is still scored, and an arc made only of your own sentences leaves nothing to defend that you did not say |
| E2 | "Can you confirm your licensure for us?" | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | Say it as the CV does: Illinois Professional Educator License, Elementary Education endorsement for grades 1–6, registered and active through June 30, 2029. Give those terms and stop. Check the license record yourself before Thursday so the sentence is true on the day | F1 is the one hard requirement in the invite. JD because it scores the stated qualification, and a plain answer here is the whole rehearsal |
| E3 | "How do you keep families in the loop?" | JD | [inferred] "I write a weekly email to families." | Say the sentence: "I write a weekly email to families." Answer slot: expect a probe on what the email holds and how it reaches families. Describe it as it is, in your own words. If any part of it was set by others, say so plainly | F7 is the evidence for the families requirement. JD because it scores that requirement asked in a casual register |

## Requirement coverage

| Requirement | Questions |
|---|---|
| F1 Illinois license with elementary endorsement | E2 |
| F2 Fourth Grade Teacher position | A1, A3, A5 |
| F3 Experience in grades 3 to 5 | A1, E1 |
| F4 Plan and teach five subjects | A4 |
| F5 Differentiate using assessment data | C2, D3 |
| F6 Classroom routines | C4 |
| F7 Communicate with families | E3 |
| F8 Work with the grade-level team | A2, B1 |
| F9 Every Child a Reader | D1 |
| F10 Families Are Partners | D2 |
| F11 Teach for Tomorrow, Not for the Test | D3 |
| District literacy plan | C3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "You were a reading specialist for nine years before becoming principal. How does that shape what you look for in a fourth-grade reading block?" | Tied to her own public path, it turns an interrogation into a conversation and shows you researched her, not only the school |
| RQ2 | "The board's literacy plan brings a new grades 3–5 reading curriculum from fall 2027. What will that mean for fourth-grade planning between now and then?" | Shows you read the district's current direction, and asks about the part of it that touches this grade |
| RQ3 | "What would help your team most from a new fourth-grade teacher in the first month?" | Reciprocity for the two teachers on the panel: it asks what you can take off their plate, not only what you need |
| RQ4 | "How does the fourth-grade team plan together week to week?" | Turns the team requirement into a concrete picture of the job and shows you expect to be part of it |
| RQ5 | "How do teachers here meet the belief that every teacher speaks with every family each term? What does that look like at Halvering?" | Takes a published belief seriously and asks for the practice behind it, which is the honest way to start on F10 |
| RQ6 | "What does a good first month look like for a teacher who is new to the grade?" | Raises your stated gap on your own terms and asks what support looks like, a ramp conversation instead of a defense |
| RQ7 | "What are the next steps after the panel, and when should I expect to hear back?" | Shows interest in the process and gets the timeline, since references are taken up after the panel |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade, or has fourth-grade experience | Negative you stated, F2 | "I've never taught fourth grade" — your message. Plain acknowledgment: "I haven't taught fourth grade." |
| Has held a team-lead role | Negative you stated, F8 | "I've never been a team lead" — your message. Plain acknowledgment: "I've never been a team lead." |
| Chose or designed the reading curriculum | Inflated form of F8 | F8's quote at its own scope. The limit is the pack's observation, not words for you: your material says the move, not what the curriculum was or who chose it |
| Ran a reading program | Inflated form of F9 | F9's quote at its own scope. Your material says an after-school reading club you run, and the pack's observation is that it says nothing wider |
| Speaks with every family each term | Inflated form of F10 | F10's quote at its own scope. Your material says a weekly email, and the pack's observation is that it says nothing about conversations |

## Sources

Provided documents: the invite, and your résumé text. The personal ID number and the license number on your résumé were not used, were not searched, and are not repeated here. No dossier was consumed.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | yes | Search 1 returned the district Mission and Beliefs page, then it was fetched. It supplied the three beliefs by name for F9 to F11 and the D bank |
| 2. `{company} interview process {role family}` | yes | Search 2 returned the district hiring page: one 45-minute building panel, the principal and two grade-level teachers, panels ask about reading instruction, classroom routines and families, references after the panel. It fixes the loop and persona weights. It names no values round, so no cheat sheet is built |
| 3. `{company} strategy` / recent news | yes | Search 3 returned the board's literacy-plan news item, which grounds C3 and RQ2 |
| 4. `{interviewer name} {company}` | yes | Search 4 returned the principal's speaker page, which fixes the interviewer read and RQ1 |
| 5. representative `{role title}` JD | yes | Search 5 returned a typical fourth-grade posting, then it was fetched. It supplied the `[inferred]` requirement rows F3 to F8 and A4 |

Queries sent, and what came back:

- "Orrinsford Community School District mission values" returned https://orrinsfordschools.example/about/mission-and-beliefs
- "Orrinsford Community School District teacher interview process panel" returned https://orrinsfordschools.example/careers/how-we-hire-teachers
- "Orrinsford Community School District strategic plan news" returned https://orrinsfordschools.example/news/board-adopts-literacy-plan
- "Dolores Vantongeren Halvering Elementary principal" returned https://ilprincipalsforum.example/speakers/dolores-vantongeren
- "fourth grade teacher job posting Illinois elementary responsibilities qualifications" returned https://k12jobsboard.example/listings/fourth-grade-teacher

Fetches: the Mission and Beliefs page, and the K12 Jobs Board posting. The hiring page, the literacy-plan item and the speaker page were read from search excerpts, not fetched.

## Upgrade menu

- The full posting text → F3 to F8 and A4 become `[grounded]` in this district's own words
- Anything HR or the principal's office told you about focus areas, or something to bring such as a sample lesson → a build section for it
- The two fourth-grade teachers' names or roles → per-member persona weights and a tailored reverse question
- Your answers to the answer slots on F4 to F6, F8, F9, F10 and F11 → quoted into the snapshot, upgrading those rows and regenerating the questions that draw on them
- The state's public license record for your license → F1 moves from `medium` to `high`
- A tuesday-dossier.md from an earlier evaluation of this role → verified evidence, a prohibited-claims list and a strategy for each weak area, never required
