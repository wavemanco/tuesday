I've read the prep-pack rules and I'm now running a few quick searches on Lumenvale Software (values, interview process, recent news) before I write the pack.
Before the prep, one thing in the invite: it says the process "is carried out entirely on Telegram" and that "your offer and onboarding will be completed in this chat as well". A hiring process run wholly in a chat is a known scam pattern. The invite also can't show who is on the other end, and it may not come from who it names. Until you've checked it, send no money, documents, ID or bank details through the chat. To check it, use contact details you find yourself on Lumenvale's own website or careers page, not the chat. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. Can you find a talent-team contact on Lumenvale's own site to confirm the message? If you want the invite weighed further, job-underwriter can check it as a separate request.

Your prep pack is saved as `lumenvale-software_customer-support-specialist_interview_pack.md`. I built it for one text-chat round with the support team lead, using the hiring-manager style of interview, since you haven't said whether they'd be your manager. The web searches I tried on Lumenvale were declined. So nothing in the pack comes from their own values or process, and the company-knowledge question (D2) is generic.

The pack has 18 questions and a fit table built only from your own sentences. The two weakest spots are the one you named and one your message doesn't cover:
- **Never worked for a software company** is the likeliest objection. B1 is the highest-ROI question to rehearse.
- **Escalations** aren't covered in anything you've told me. A3 and B2 give you a way to answer honestly, whichever way it goes.

Say the word and I'll play the skeptical team lead on B1 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Could you paste the full job ad and your CV? Both would turn the paraphrased requirements and the thin rows into quoted evidence, and the ad might add terms like hours or time zone that I'd need to check.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: lumenvale-software_customer-support-specialist_interview_pack.md -----
# Interview prep pack: Customer Support Specialist, Lumenvale Software

Interviewer: the support team lead, unnamed. Format: one text chat on Telegram, as your invite message describes it. Relationship assumed: a team lead who runs the work you would join, so the pack uses the hiring-manager weights.

## How to use this pack

- Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding, not a script.
- This is a text chat, so every answer is typed. Read the guidance as the shape of four to eight short lines, not a speech.
- Type key: VAL is values alignment (none in this pack: no values-style round is detected and no published values were in hand). EXP is a deep-dive on your own experience. JD is a requirement from the ad. CO is company knowledge. CASE is a live problem.
- Provenance labels: `[grounded]` rests on something you or the ad supplied, `[inferred]` is derived from that, `[generic]` is a pattern with no claim about you or Lumenvale.
- Highest-ROI prep: B1, the question about never having worked for a software company. It will be asked in some form, and it is the one place the material is thin where you have said so yourself.

## Fit snapshot

The ad's full text was not supplied. Requirements are quoted from your description of the ad, so they are only as exact as that summary.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — the ad, as you described it | "3 years as a customer service advisor at an energy supplier" — your message; "answering around 60 calls and emails a day" — your message | medium | [grounded] | none | No gap, but self-reported with nothing inspected behind it, so expect a probe. Lead with the quote's own terms: three years as a customer service advisor at an energy supplier. Keep the volume at "around", at "calls and emails" and at "a day" |
| F2 | "experience with Zendesk or a similar ticketing tool" — the ad, as you described it | "I use Freshdesk every day" — your message | medium | [grounded] | presentation | Say Freshdesk by name, as the quote does: "I use Freshdesk every day." The ad names Zendesk or a similar tool and your message names Freshdesk, so the words stay on Freshdesk and imply no other tool |
| F3 | "clear written communication" — the ad, as you described it | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | The quote carries emails, not how well they were written, and a text chat makes the interview itself a writing sample. Answer slot: the ad names clear written communication, so expect a probe on your writing. If something specific shows it, say what, in your own words; if nothing does, say so plainly and stay with the calls and emails you answer |
| F4 | "confidence handling escalations" — the ad, as you described it | none given | none | [grounded] | discovery | Your material does not show escalations either way. Answer slot: the ad names escalations, so expect a probe. If you handled escalations, say what they were and which part was yours, in your own words; if you did not, or they went to someone else, say so plainly and say how you would handle one |
| F5 | Not in the ad as you described it; the likeliest probe, since the employer is Lumenvale Software — your message | "I've never worked for a software company" — your message | none | [grounded] | capability | A gap wording cannot close, and you stated it. Words: "I've never worked for a software company." Then how you would learn the product, said as a plan and never as a past. Never a claim to software experience, and nothing added to make the gap feel smaller |
| F6 | Not a stated requirement: a strength in your own account | "I trained four new starters on our refunds process last year" — your message | medium | [grounded] | none | Nothing to close. Keep it at its own scope: four new starters, your refunds process, last year, and the verb "trained". It stays at that scope in every answer |

No row is a gate: nothing you shared states a term such as hours, time zone, location or pay. A full ad could add one.

## Persona table

| Persona | How it shows up | Weight, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | Live customer scenarios typed into the chat | First, 5 questions. Your invite describes one text chat with the support team lead, the hiring-manager prior is Case plus Skeptic, and in a text chat each reply you type is also a sample of F3 | Clarify, then say what you would check, then write the reply, then the next step. Keep each reply short. A1 to A5 |
| B. Skeptic | Quiet probing of the gaps | Second, 4 questions. F5 is a gap you stated and F4 is silent, and the prior pairs Skeptic with Case | Rehearse B1 until it is boring: acknowledge plainly, give a plan, hold what the quotes carry, concede the rest |
| C. Data-Driven Prober | Checks the claims in your application line by line | Third, 4 questions. The invite says the team was impressed by your CV, so the claims in it are the natural probe targets: F1, F2 and F6 | Know how each number was counted and say plainly when you do not. C1 to C4 |
| D. Conversational / Rapport | A friendly opener and a why-us question | Fourth, 3 questions. Nothing in your material points to it, and every style should still be met once before the live chat | Keep the arc short and built from your own sentences. D1 to D3 |
| E. Pressure | Short time limits and challenges to your motives | Fifth, 2 questions. No signal in your material points to it; it is kept so B1 and F6 are rehearsed under pressure | Pause, restate, hold through two follow-ups, concede specifically. E1, E2 |

Loop: the one session you described comes from your own words, so no archetype fallback applies. No values-style round is detected.

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in angry: they say they were charged twice this month and they want to cancel today. What do you type back?" | CASE | [generic] | Type it as you would send it, in four moves: acknowledge the problem in one plain sentence, say what you are checking on their account, say what you can do and what needs someone else to approve, then give the next step and when they will hear from you. Short enough to read in one pass. The question needs no claim about your past, so the guidance makes none | A live written scenario aimed at F3. CASE because it is scored on the reply itself, not on a story; generic because it is a pattern for the problem, not a fact about this employer |
| A2 | "A customer has written in three times about the same fault and says nobody has answered. What do you do in the next ten minutes?" | CASE | [generic] | Clarify first: read the history so you know what was said, and find out whether the fault is already known and who owns it. Reply to the customer before anything else, own the delay without blaming a colleague, and say what happens next. If it needs someone else, say who and what you would write so they do not have to ask again. No claim about your past | An escalation-shaped scenario for F4 that asks about no history, so it can be rehearsed before any slot is answered |
| A3 | "Tell me about a time you escalated a customer issue, or took one that had been escalated to you." | JD | [grounded] "answering around 60 calls and emails a day" | A selection scaffold, since your material does not show escalations either way. Pick one case with a clear moment where you decided to pass it on or to take it on; say what the customer needed, what you did and how it ended, in your own words and no more than you remember. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "answering around 60 calls and emails a day", or say how you would handle one | F4 is the thinnest requirement row and the ad's escalation line makes this question likely. JD because it scores a stated requirement; an open prompt, so it supplies no event |
| A4 | "It is mid-shift and a fault has doubled the queue. How do you decide what to answer first?" | CASE | [generic] | Clarify: what is affected, who has waited longest, whether there is a known cause or a holding message. Then state your ordering rule aloud and why, and what you would tell customers while they wait. No claim about your past | Turns F1's day-to-day volume into a judgement call without claiming you ever made one |
| A5 | "A customer asks for a refund the policy does not allow and is getting rude. What do you write?" | CASE | [generic] | The four moves from A1, plus one: say what you cannot do and why in a single sentence, offer what you can, and say where it goes if they want to take it further. Polite and specific, with no promise you cannot authorise. No claim about your past | Tests tone and the written side of F3. It sits near F6's refunds topic only as a scenario, not as a claim about your history |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't worked for a software company before. How would you get up to speed on a product like ours?" | JD | [grounded] "I've never worked for a software company"; "3 years as a customer service advisor at an energy supplier"; "I use Freshdesk every day" | The highest-ROI rehearsal in this pack. Open with the acknowledgment the first quote carries: "I've never worked for a software company." Then the plan, in the future tense only: what you would learn first and how you would ask for help, in your own words. Hold through two follow-ups by returning to what the other two quotes carry, three years as a customer service advisor at an energy supplier and "I use Freshdesk every day", and add nothing to them. Concede specifically that the product knowledge is new. Never describe software experience | F5 is where the role's setting presses hardest and you raised it yourself, so it arrives in some form. JD because it scores fit for the listed job, delivered as a Skeptic probe |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company" | Name the gap you stated before they do: "I've never worked for a software company." Then what you would do in week one. Answer slot: the ad's escalation line makes a follow-up likely. If escalations are also a weak area, say so plainly and how you would build it; if you have handled them, say what, in your own words | F5 and F4 are the two rows a weakness question lands on. JD because it asks you to rank the listed requirements against yourself |
| B3 | "Energy customers and software customers are not the same people. What carries over from your three years, and what does not?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier"; "I've never worked for a software company" | What carries over is what the first quote states: three years as a customer service advisor at an energy supplier. Answer slot: if something specific carries over, say what, in your own words; if nothing specific comes to mind, say so plainly and stay with the three years. What does not carry over is the second quote, said plainly | F1 against F5. EXP because it asks what the three years actually gave you |
| B4 | "Why move from energy into software support?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" | Answer slot: give your actual reason in your own words. This pack supplies none, because a reason you did not give is one you cannot defend on a follow-up. Keep it consistent with what you wrote in your application, and anchor it on the quote: three years as a customer service advisor at an energy supplier | Motivation consistency is what a Skeptic scores. EXP because it tests your own account of your path |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You say around 60 a day. How was that counted?" | EXP | [grounded] "answering around 60 calls and emails a day" | Defend-the-number. Keep the quote's own terms: "around", "calls and emails", "a day". Say in your own words how it was counted; if you do not know, say so plainly. Name the assumption you would defend least before they do. Answer slot: if asked how it splits between calls and emails, give your honest split if you know it, and say so if you do not. Never restate it as tickets | The headline number in F1 and F3. EXP because it scores how well you know your own figure |
| C2 | "Tell me about training those four new starters." | EXP | [grounded] "I trained four new starters on our refunds process last year" | The beats are only what the quote states: four new starters, your refunds process, last year, and that you trained them. Tell them in your own words. Defend-the-number: say how the four came to be four, and which part was yours; if you were one of several trainers, or the process was set by someone else, say so plainly. No further beat is added, because nothing in the ad as you described it raises one | F6 is a specific figure and a prober's natural next question. EXP because it tests what was actually yours |
| C3 | "What do you use Freshdesk for day to day?" | EXP | [grounded] "I use Freshdesk every day" | Say it in the quote's own terms, "I use Freshdesk every day", then what you do in it, in your own words. Answer slot: if you did more than use it day to day, such as setting something up or changing how it was used, say what; if you did not, say so plainly and stay with the daily use | F2 is the tool requirement. EXP because it asks what you actually did in it |
| C4 | "Have you used Zendesk?" | JD | [grounded] "I use Freshdesk every day" | Answer yes or no from your own experience, plainly. Then return to the quote: "I use Freshdesk every day". Answer slot: if you have used another tool, say which and for what, in your own words; if you have not, say so plainly | The ad names Zendesk or a similar tool, so the named one is the likeliest probe on F2. JD because it scores the listed tool requirement |

### D. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your journey so far." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier"; "I trained four new starters on our refunds process last year"; "I use Freshdesk every day" | A short arc using only what the quotes carry, in that order: three years as a customer service advisor at an energy supplier, "I trained four new starters on our refunds process last year", "I use Freshdesk every day". End on why this role. Answer slot: give your own reason in your own words; if you are unsure, say what draws you to the job as advertised and stop there. Six to eight short lines | F1, F6 and F2 packaged as the opener. EXP because it is your own account; casual wording is still scored |
| D2 | "What do you know about Lumenvale, and why this role?" | CO | [generic] | No company research could run for this pack, so this cell supplies nothing about Lumenvale and claims nothing about it. Before the chat, read the company's own website and the ad, and say what you found in your own words, plus your own reason for the role. If you found little, say what you looked at and what you would ask | A homework check. CO because it scores company knowledge; generic because no research ran |
| D3 | "How do you make sure a stressed customer can understand your reply in one read?" | JD | [grounded] "answering around 60 calls and emails a day" | Answer slot: describe how you write, in your own words and only as you actually do it; if you have no set method, say so plainly and say what you would do. The quote supports only that emails were part of your day: "answering around 60 calls and emails a day" | F3. JD because it scores the listed written-communication requirement, asked casually |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Thirty seconds: why you, with no software background?" | JD | [grounded] "I've never worked for a software company"; "3 years as a customer service advisor at an energy supplier"; "I use Freshdesk every day" | Pause and restate the question. Hold what the quotes carry, three years as a customer service advisor at an energy supplier and "I use Freshdesk every day", through two follow-ups without adding to them. Concede specifically: "I've never worked for a software company." Do not fold the core claim, and do not stretch it to win the moment | B1 under a time limit. JD because it scores the same requirement gap, in a pressure register |
| E2 | "How much of that training was actually you?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Hold "I trained four new starters on our refunds process last year" at its own scope. Answer slot: say which part was yours; if it was shared, or the process was set by someone else, say so plainly. Concede only what is true, specifically, and do not retreat from the rest | C2 under pressure. EXP because it is the attribution probe F6 invites |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| F1: 2+ years in customer support | B3, B4, D1, C1 |
| F2: Zendesk or a similar ticketing tool | C3, C4 |
| F3: clear written communication | A1, A5, D3 |
| F4: confidence handling escalations | A2, A3, B2 |
| F5: no software-company background | B1, B2, B3, E1 |
| F6: trained four new starters | C2, D1, E2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good first month look like for someone in this role?" | It shows you are planning the ramp-up that F5 makes the main question, and the answer tells you what the team measures |
| R2 | "Which ticketing tool does the team use, and how are new people trained on it?" | It follows F2 without claiming any tool you have not used, and shows you expect to learn |
| R3 | "What does an escalation look like on this team: which ones stay with the specialist and which come to you?" | It answers the F4 uncertainty from the other side and shows you think about where your authority ends |
| R4 | "How does the team judge the quality of written replies?" | It shows you take F3 seriously and tells you the standard before you are held to it |
| R5 | "What tends to be hardest for people coming from outside software?" | It turns F5 from an objection into a shared problem and invites the lead to coach you |
| R6 | "What are the next steps after this chat, who will I speak to next, and how would any offer and contract reach me?" | It is a normal practical question, and the answer shows whether the process matches what you were told |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has used Zendesk | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day." The limit is the pack's observation: your message says Freshdesk, not Zendesk. C4's slot stays on which tools you have used |
| Has worked in software or a software company | Negative you stated, F5 | The plain acknowledgment F5 gives: "I've never worked for a software company." No slot |
| Handled around 60 tickets a day | Inflated form of F1 and F3 | The quote at its own scope: "answering around 60 calls and emails a day". The limit is the pack's observation: your message says calls and emails, not tickets |
| Ran, led or designed the refunds training | Inflated form of F6 | F6's quote at its own scope: "I trained four new starters on our refunds process last year". The limit is the pack's observation: your message says you trained four, not how the training was set up. C2's slot asks only which part was yours |

## Sources

Provided documents: your message, containing the invite text and your description of the ad and your background. The full ad and a CV were not supplied.

Searches sent, all refused, so nothing from them is used:

- "Lumenvale Software company values": refused
- "Lumenvale Software interview process customer support specialist": refused
- "Lumenvale Software strategy news": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale Software values | unavailable | Every call was refused. It would have decided whether a values-style round is detected and fed section 10 and VAL questions |
| 2. Lumenvale Software interview process, support roles | unavailable | Every call was refused. It would have fed persona weights and loop structure. Your own description of one text chat with the support team lead stands in, and no archetype fallback was needed |
| 3. Lumenvale Software strategy and recent news | unavailable | Every call was refused. It would have fed CO and CASE questions grounded in current priorities; D2 stays generic |
| 4. Interviewer name and company | n/a | No interviewer name was given, so there was no query to form. The interviewer read is absent |
| 5. Representative Customer Support Specialist JD | skipped | The requirements you described fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full ad text: F1 to F4 requirement cells become quotes from the ad itself, and any term in it such as hours, time zone, location or pay becomes a fit-snapshot row
- Your CV: F1 to F6 evidence cells can quote CV lines, and F3 and F4, the two discovery rows, are the likeliest to upgrade
- Your answer to F4's slot, whether you handled escalations and which part was yours: F4, A2, A3 and B2 become story-mapped
- Permission for web searches on Lumenvale: values, interview process and recent news would move D2 and the loop from generic to grounded. A deeper pass would add up to 6 more searches and 2 more fetches and take several more minutes
- The team lead's name and any pre-interview guidance from the talent team: an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to their path
- A tuesday-dossier.md: verified evidence, claims barred outright, and a named strategy for each weak area, in place of the objections this pack infers
