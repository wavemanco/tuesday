I've read the skill's rules. Next I'm loading the web search tools to check that the employer is real and to compare the pay band. Then I'll write the assessment.
**Yes, it's worth applying, Aoife. Status: `conditional_go`.** Your hard gates R1 and R2 are met on your CV. R4 needs one answer from you first, and the posting still needs confirming on the employer's own site.

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3, R6a, R7 · adjacent: R5 (Wound and leg-ulcer care), R10 (Home-based care of housebound adults) · unclear: R4 (Clear, timely written records)
- `important` — adjacent: R11 (Own small caseload) · unclear: R6b (Continence care), R8 (End-of-life visits), R9 (Care planning)
- `preferred` — absent: R12 (Doppler assessment)

R5 and R10 — credible bridges, limits named; R11 — you have not held a caseload, and the advert says a senior community nurse supports it; R4 — the CV is silent, and one answer settles it; R12 — the advert lists it as desirable.

**Opportunity ledger.** The employer is attributable and the support is stated (RR2). The team lead's public work includes Doppler training for staff new to community work (RR3). Pay is stated openly (RR5). The listing itself is not yet confirmed on the employer's careers site (RR1), and caseload size and rota are unstated (RR4).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the vacancy is confirmed open on the employer's own site (RR1); (2) your records experience is confirmed (R4); (3) the leg-ulcer and home-working bridges (R5, R10) are framed honestly as adjacent, never as district nursing experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015, 410 staff, four locality hubs | `[grounded]` employer's "About" page, found by search |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin and care planning, on an electronic patient record | `[grounded]` JD |
| Caseload and support | A small caseload of your own, supported by a senior community nurse; pool cars provided; mileage paid | `[grounded]` JD |
| Hiring manager | Rhiannon Mabbott leads the Halifax district nursing team after eleven years as a district nurse. At the 2025 community nursing forum she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` forum speaker page |
| Scope read | An ordinary community staff nurse post for the advert's own stated tasks; the Doppler line is marked desirable, not essential | `[inferred]` from the JD's Essential and Desirable lists |
| Market calibration | £31,050–£37,800 sits across a 2026 survey of community staff nurses at Band 5 in England (n=1,240): median £34,300, interquartile range £32,400–£36,600; 61% were paid mileage and 24% had a pool or lease car. The survey is a pattern, not this employer's offer, and where you would sit in the range is unknown (RR5) | `[generic]` pay survey; `[grounded]` JD for the advertised range |
| Unknowns | Caseload size, visits per day, rota, weekend or out-of-hours duties, how Doppler training is given | `[inferred]` from the JD's silence |
| Contradictions | None between the JD and the employer's page. The vacancy itself was not confirmed, because the careers address I tried returned no page (RR1) | `[grounded]` employer page; fetch result |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | Your CV states "Registered Nurse (Adult)", registration active, revalidation due March 2028. It is specific, but I have not inspected the register. | `[grounded]` CV | Confirm the register entry matches before applying |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Your CV states a full UK licence, category B. The advert says pool cars are provided. | `[grounded]` CV and JD | none |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward, per your CV. This is an experience length, not a gate. | `[grounded]` CV | none |
| R4 | Clear, timely written records (electronic patient record) | must_have | unclear | low | discovery | Your CV is silent on records and on any electronic system. Five years of ward work is indirect context only, so it is not asserted as a claim. | `[grounded]` CV silence | Ask G1 |
| R5 | Wound and leg-ulcer care | must_have | adjacent | medium | transferability | Your CV states wound care including pressure ulcers and surgical wounds. Limit: nothing stated on leg ulcers or compression therapy. Leg-ulcer care is a named duty in the JD, so expect a probe. | `[grounded]` CV and JD; `[generic]` that interviews probe the named duties | Ask G2 |
| R6a | Catheter care | must_have | direct | medium | none | Your CV states catheter care. | `[grounded]` CV | none |
| R6b | Continence care beyond catheters | important | unclear | low | discovery | The CV states catheter care and nothing on wider continence work. | `[grounded]` CV silence | See G5 |
| R7 | Insulin administration | must_have | direct | medium | none | Your CV states insulin administration. Care planning is a separate row (R9). | `[grounded]` CV | none |
| R8 | End-of-life visits | important | unclear | low | discovery | The CV is silent on end-of-life care, and nothing here shows you delivered it at home. | `[grounded]` CV silence | Ask G3 |
| R9 | Care planning | important | unclear | low | discovery | The CV is silent on care planning. | `[grounded]` CV silence | See G5 |
| R10 | Home-based care of housebound adults | must_have | adjacent | medium | transferability | 18 months seconded to the discharge-to-assess team, visiting patients at home in their first week after discharge. Limit: a first-week-after-discharge service, not ongoing care of housebound patients. Whether you visited alone is not stated. | `[grounded]` CV | Frame as adjacent; see G4 |
| R11 | A small caseload of your own | important | adjacent | medium | transferability | You told me you have never held your own caseload. The adjacent work is the D2A visiting (R10), and how you planned your visits is not stated. | `[grounded]` your statement and CV | See G4 |
| R12 | Doppler assessment for leg ulcers (desirable) | preferred | absent | none | capability | You told me you have never done one. The closure path is on-the-job training, which RR3 suggests the team lead has spoken about. | `[grounded]` your statement | Ask in the informal chat (RR3) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Written records (R4, must_have) | discovery | The CV says nothing about documentation or electronic systems | R4 is an Essential line in the advert and is `unclear`; one answer could settle it | Using an electronic record on the ward or in the D2A team; writing discharge or visit notes; a documentation audit | An anonymised record template or audit result, with no patient data | `[grounded]` CV silence; `[inferred]` that one answer settles it |
| G2 | Leg-ulcer and compression care (R5, must_have) | transferability | Pressure-ulcer and surgical wound care are stated; leg ulcers are not | A named duty and the team lead's own area of interest | Applying compression bandaging; assessing a venous leg ulcer; a wound-care competency sign-off | A training certificate or signed competency record | `[grounded]` CV and forum page; `[inferred]` that the team lead's interest makes it likely to be probed |
| G3 | End-of-life care (R8, important) | discovery | The CV is silent | A named duty; confirming experience would move R8 | Caring for dying patients on the ward; supporting a rapid discharge home to die; syringe-driver or anticipatory-medication work | A reflective account from your revalidation portfolio, kept confidential | `[grounded]` CV silence |
| G4 | Own caseload and home working (R10, R11) | transferability | The CV states D2A visits; how you planned or prioritised them is not stated | Whether the caseload step looks like a small stretch or a leap | Planning your own visit list; deciding visit order; escalating to a doctor or nurse; working alone in the community | A D2A service description, with no patient data | `[grounded]` CV and your statement |
| G5 | Continence beyond catheters and care planning (R6b, R9) | discovery | Both are absent from the CV | Both are named duties, and the CV may be underselling you | Bladder or bowel care plans; writing or reviewing discharge care plans | An anonymised care-plan template you used | `[grounded]` CV silence |
| G6 | Doppler assessment (R12, preferred) | capability | No evidence, and you have confirmed none | Desirable only; carried as a minor risk with a training path | A short Doppler training course or in-service teaching before or after you start | The team lead's answer in the informal chat | `[grounded]` your statement; `[inferred]` from the forum page |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Vacancy not confirmed on the employer's own site | risk_signal | low | "Current vacancies are listed on our careers page" (employer's About page) | The advert may sit at a different address, or may be a repost of a closed vacancy | `[inferred]` from a guessed careers address returning no page; `[generic]` that reposted adverts can outlive the vacancy | Is this vacancy still open, and what is the closing date? | unresolved |
| RR2 | Supported caseload stated | positive_signal | — | "supported by a senior community nurse" | The post has a stated route into the caseload | `[grounded]` JD | How often will the senior community nurse review or accompany my visits in the first months? | noted |
| RR3 | Team lead's published interest in Doppler training for staff new to community work | positive_signal | — | "Doppler training for staff new to community work" (forum speaker page) | Doppler training for new starters may be available | `[grounded]` forum page | Is Doppler training provided to new starters, and when? | noted |
| RR4 | Caseload size and rota unstated | unknown | — | "You will hold a small caseload of your own" | "Small" is undefined, and weekend or out-of-hours duties are not mentioned | `[inferred]` from the JD's silence | How many patients will I carry at the start, and what are the rota and weekend commitments? | unresolved |
| RR5 | Pay stated openly | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The range spans the survey median, so no mismatch shows; where you would sit in it is unknown | `[grounded]` JD range; `[generic]` survey median | Where in the range would my five years' experience place me? | noted |

## Application plan

`resume_edits_pending_approval` — each row below is proposed, and nothing, including the wording advice, is applied until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Move your D2A secondment to the top of your experience, in your own words: "Seconded for 18 months to the discharge-to-assess team, visiting patients at home in their first week after discharge" | R10 | `[grounded]` your CV sentence | pending your approval |
| E2 | In the skills line, list "wound care (pressure ulcers, surgical wounds); catheter care; insulin administration" as your CV states them, and do not add leg ulcers, continence or care planning until G2 and G5 are answered | R5, R6a, R7 | `[grounded]` CV | pending your approval |
| P1 | In the statement and any interview, say plainly: "I have not held my own caseload and I have not done a Doppler assessment" | R11, R12 | `[grounded]` your statement | pending your approval |
| A1 | Take up the advert's invitation to an informal chat with Rhiannon Mabbott, and ask the RR2, RR3 and RR4 questions in it | RR2, RR3, RR4 | `[grounded]` JD and forum page | pending your approval |
| A2 | Confirm the vacancy is open, and the closing date, before spending time on the form | RR1 | `[grounded]` RR1 | pending your approval |

## Evidence status

Verified: none yet. Your message included a National Insurance number. It isn't needed to evaluate a role, so I haven't used it or repeated it.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax district nursing", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about). Fetched calderbrookhealth.example/careers, which returned no page. Role reality's organization and contradictions rows; RR1 |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse district nursing pay Agenda for Change 2026/27 salary", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Market calibration; RR5 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead", which returned the forum speaker page (communitynursingforum.example/speakers/rhiannon-mabbott). Role reality's hiring-manager row; RR3 and A1 |

If you want this kept, I can write it up as `tuesday-dossier.md`.

**Upgrade menu**

- Your confirmation that your licence is current → R2 firms up. Nothing needs uploading.
- An NMC register entry that matches your CV → R1 moves to `high`.
- An answer to G1, with an anonymised record template or audit result → R4 resolves.
- An answer to G2, with a signed competency record or certificate → R5's bridge strengthens.
- An answer to G3, G4 or G5 → R8, R10, R11, R6b and R9 each resolve or firm up.
- Your own constraints (hours, weekends, pay floor, travel) → the hard-gate checks beyond R1 and R2 can run; right now they are unknown.
- The employer's careers-page link or the closing date → RR1 closes.
- A deeper research pass on Calderbrook (staff and inspection reports, leadership changes; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

G1 — Which electronic or paper records did you keep on the ward and in the D2A team, and how quickly after a shift or visit did you write them up?
G2 — Have you applied compression bandaging or assessed a leg ulcer, even once, and was it signed off in a competency record?
G3 — Have you cared for a dying patient on the ward or supported a discharge home to die, and what part of that care was yours?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.