I'll read the reference files the skill requires before building the assessment.
Reading is done; now running the budgeted L1 research (employer check, role-family sweep, team lead's public footprint).
## Decision snapshot

**Yes, this one is worth applying for. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3, R5a, R6a, R7 · adjacent: R4 (Clear, timely written records on the electronic patient record) · unclear: R5b (Leg-ulcer care), R6b (Continence care)
- `important`: adjacent: R8 (Home-visiting setting), R10 (Own small caseload) · unclear: R9 (End-of-life visits)
- `preferred`: absent: R11 (Doppler assessment for leg ulcers)

R5b, R6b, R9: unclear, with the evidence possibly sitting in your history; R8, R10: adjacent, with limits named in the map; R11: absent, and desirable rather than essential.

**Opportunity ledger.** The employer is established and the role reads as a supported entry into district nursing: pay (RR2) and supervision (RR4) are stated. The posting itself is unconfirmed on the employer's own site (RR1), and the rota (RR3) and terms (RR5) are unstated.

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the vacancy is confirmed open on Calderbrook's own careers page (RR1); (2) you can evidence leg-ulcer care, or the gap is carried honestly (R5b, G1); (3) the caseload and Doppler points are framed as adjacent and absent, never as held experience (R10, R11).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015, 410 staff, four locality hubs | `[grounded]` About page fetched (calderbrookhealth.example/about) |
| Role | Band 5 community staff nurse in the Halifax district nursing team: housebound adults at home, with the wound, catheter, end-of-life and insulin work listed in the advert | `[grounded]` JD |
| Team lead | Rhiannon Mabbott leads the Halifax district nursing team after eleven years as a district nurse. At the 2025 community nursing forum she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` forum speaker page |
| Scope read | A small own caseload under a senior community nurse suggests a supported entry post, not an independent one | `[inferred]` from "small caseload of your own, supported by a senior community nurse" |
| Market calibration | The advert's £31,050–£37,800 plus mileage brackets that survey's median basic pay of £34,300 (interquartile range £32,400–£36,600, England, n=1,240). In that survey, 24% of respondents had a pool or lease car | `[grounded]` JD for the range; `[generic]` one 2026 pay survey, not this employer's offer |
| First-90-days outcomes | Not stated in the posting | `[grounded]` JD silent |
| Unknowns | Rota and weekend or on-call duty; lone-working arrangements; caseload size; whether Agenda for Change and NHS pension terms apply; mileage rate; induction and Doppler training | `[inferred]` from JD silence |
| Contradictions | None between the JD and the About page. The careers page itself was not read (RR1) | `[grounded]` About page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | CV states Registered Nurse (Adult), registration active, revalidation due March 2028; self-reported, nothing inspected | `[grounded]` CV | none |
| R2 | Full UK driving licence (pool cars provided) | hard_gate | direct | medium | none | CV states a full UK licence, category B; the posting provides pool cars | `[grounded]` CV and JD | none |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | CV states five years as a staff nurse on an acute medical ward. A length-of-experience requirement is not a gate | `[grounded]` CV | none |
| R4 | Clear, timely written records, on an electronic patient record | must_have | adjacent | low | discovery | CV is silent on records and on any electronic system. Ward and home-visit documentation is a reasonable inference, nothing confirmed | `[inferred]` from five ward years and the home-visiting secondment | Name the electronic record system(s) you have used, as a CV edit (E2) |
| R5a | Wound care | must_have | direct | medium | none | CV states wound care including pressure ulcers and surgical wounds | `[grounded]` CV | none |
| R5b | Leg-ulcer care | must_have | unclear | low | discovery | CV does not mention leg ulcers or compression; it is a named duty in the posting and the team lead's public talks | `[grounded]` CV silence, JD and forum page | G1 |
| R6a | Catheter care | must_have | direct | medium | none | CV states catheter care | `[grounded]` CV | none |
| R6b | Continence care | must_have | unclear | low | discovery | CV states catheter care only; continence care more widely is neither claimed nor ruled out | `[grounded]` CV | Carried as minor; one CV line if true, no question asked |
| R7 | Insulin administration and care planning | must_have | direct | medium | none | CV states insulin administration. Care planning is not claimed, so the row rests on administration | `[grounded]` CV | none |
| R8 | Caring for housebound adults in their own homes | important | adjacent | medium | transferability | Eighteen months seconded to discharge-to-assess, visiting patients at home in their first week after discharge. Limit: short post-discharge input, not ongoing care of long-term housebound patients. Strengthener: examples of repeat or complex home visits | `[grounded]` CV; `[generic]` that the two services differ in continuity | E1 |
| R9 | End-of-life visits | important | unclear | low | discovery | CV is silent on end-of-life care | `[grounded]` CV silence | G2 |
| R10 | A small caseload of your own, with senior support | important | adjacent | low | transferability | You have never held a caseload, so this is not direct. The bridge is the visits you made on discharge-to-assess; whether you planned your own visit list is unconfirmed. Limit: no ownership of an ongoing caseload | `[inferred]` bridge from the secondment | G3 |
| R11 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You have never done one. Desirable, not essential. Closure path: ask the team about Doppler training; the team lead has spoken on Doppler training for staff new to community work | `[grounded]` your statement and JD; `[grounded]` forum page | A2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Leg-ulcer care (R5b, must_have) | discovery | CV mentions pressure ulcers and surgical wounds, not venous or leg ulcers or compression | A named core duty, and the area the team lead has spoken on; resolving it could move the decision from `conditional_go` to `go` | Applying or reapplying compression bandaging on the ward; dressing venous leg ulcers; a tissue-viability link-nurse role; seeing a Doppler or ABPI done by a colleague | Tissue-viability training record, a competency sign-off, a ward leg-ulcer pathway you used | `[grounded]` CV silence and JD; `[inferred]` that it could change the status |
| G2 | End-of-life visits (R9, important) | discovery | CV is silent on end-of-life care | Listed in the advert's duties; an interviewer may ask for an example | Last-days care plans; anticipatory medication on the ward; supporting families; any discharge-to-assess patient who died at home or was fast-tracked home to die | End-of-life training certificate or a competency record | `[grounded]` CV silence; `[generic]` that interviews for community posts often ask for an example |
| G3 | Own caseload (R10, important) | transferability | Never held a caseload; discharge-to-assess visits are the nearest evidence | A bridge with no stated limit would be inflation; the limit is no ongoing ownership | Planning your own day's visit order; handing a patient to district nursing; escalating to a senior | A short sanitized description of how a discharge-to-assess visit day was organised | `[inferred]` bridge from the secondment |
| G4 | Doppler assessment (R11, preferred) | capability | No evidence, which you confirmed | Preferred, so a minor risk, not a barrier | Not applicable: no credible direct or adjacent evidence exists | Closure path: ask whether the role includes Doppler training | `[grounded]` your statement; `[grounded]` forum page |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not yet confirmed on the employer's own site | unknown | — | "Community Staff Nurse, Band 5 — Calderbrook Community Health CIC, Halifax" | The vacancy may be live and I could not find it: the careers address I tried returned no page, and the About page only says vacancies are on a careers page | `[grounded]` fetch returned no page; `[inferred]` that this reflects my guess at the address | Can you confirm this post is open, and give me its reference on your careers page? | unresolved |
| RR2 | Pay stated and in line with a survey median | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The range brackets a 2026 survey median; where you would sit in it is not stated | `[grounded]` JD; `[generic]` one pay survey | Where in the range would my five years' experience place me, and what is the mileage rate? | noted |
| RR3 | Rota, weekends, on-call and lone working unstated | unknown | — | "caring for housebound adults in their own homes" | District nursing posts often cover weekends and visit alone, which could matter to you | `[generic]` role-family pattern, not a claim about Calderbrook | What are the working days and hours, is there a weekend or on-call rota, and how is lone visiting supported? | unresolved |
| RR4 | Supervision is stated and the team lead is a named, experienced district nurse | positive_signal | — | "supported by a senior community nurse" | A new caseload-holder has a named route to support | `[grounded]` JD; `[grounded]` forum page | How is the senior nurse's support organised for someone new to holding a caseload? | noted |
| RR5 | Terms and training unstated: Agenda for Change, pension, induction | unknown | — | "Band 5" | A "Band 5" label from a community interest company may or may not carry NHS terms | `[generic]` pattern; the posting is silent | Do NHS Agenda for Change terms and pension apply, and what induction and Doppler training are offered? | unresolved |

## Application plan

All rows below are proposals, pending your approval: the CV wording, the call advice and the outreach points alike. Nothing is finalized until you say so.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with the eighteen-month discharge-to-assess secondment as its own headed role, using the CV's own facts: "visiting patients at home in their first week after discharge". Do not describe it as a caseload | R8, R10 | `[grounded]` CV | pending your approval |
| E2 | Add the electronic patient record system(s) you have used and one line on your documentation, once you tell me which | R4 | `[grounded]` R4 row | pending your approval |
| E3 | Add leg-ulcer, compression or end-of-life lines only if G1 or G2 confirm them | R5b, R9 | `[grounded]` gap rows | pending your approval |
| A1 | Take up the advert's invitation to chat with Rhiannon Mabbott, and use it to ask RR1, RR3 and RR5 | The register doubles as call preparation | `[grounded]` JD invitation and register | pending your approval |
| A2 | Say plainly that you have not done Doppler assessment, and ask whether the post includes training | R11 | `[grounded]` your statement; `[grounded]` forum page | pending your approval |
| A3 | Remove your National Insurance number from the CV | It is not needed to apply | `[generic]` common application practice | pending your approval |

## Evidence status

Verified: none yet. The National Insurance number in your message is not needed to evaluate a role, so I have not used it.

Research tier: L1 — searches 3 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax"; fetched "About Calderbrook Community Health" (calderbrookhealth.example/about), which repeated the search snippet, and tried calderbrookhealth.example/careers, which returned no page. Moved the organization row in role reality and set RR1 |
| 2. Role-family sweep | yes | Searched "Community Staff Nurse Band 5 district nursing salary Agenda for Change 2026 pay scale", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Moved the team lead row, the R5b and R11 reasoning and plan row A2 |

If you'd like, I can save all of this as `tuesday-dossier.md` to carry forward.

**Upgrade menu**

- A link to the live vacancy on Calderbrook's careers page closes RR1 and may turn `conditional_go` into `go`.
- Your answer on leg-ulcer care (G1) resolves R5b, the largest must-have gap. A tissue-viability or compression competency record would raise it to `high`.
- Your answer on end-of-life care (G2) resolves R9; an end-of-life training or competency record would raise it.
- Your answer on how you planned your visits (G3) strengthens or limits the R10 bridge.
- The electronic patient record system(s) you have used would raise R4.
- Rhiannon Mabbott's answers on rota, terms and training (RR3, RR5) close those unknowns.
- A deeper research pass on Calderbrook (staff and patient reports, recent news, leadership changes; up to 5 more searches and 2 more fetches) runs if you say the word.

**Questions**

G1 — Have you ever applied compression bandaging, dressed a venous leg ulcer, or been the tissue-viability link nurse on your ward? Say what you personally did.

G2 — Have you personally led end-of-life care, such as last-days care plans, anticipatory medicines or supporting families, on the ward or on a home visit? What was your part?

G3 — On discharge-to-assess, did you plan your own visit list and decide the order and priorities, or were visits allocated to you? Who did you hand patients on to?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.