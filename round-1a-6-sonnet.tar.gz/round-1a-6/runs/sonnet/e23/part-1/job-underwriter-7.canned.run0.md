I'll read the reference files before building the assessment.
Reading is done. Now I'm running the budgeted research: the employer and its careers page, a salary check for the role, and the team lead's public footprint.
**Yes, this one is worth applying for. Status: `conditional_go`.** R1 and R2 (the two hard gates) are met on your own account, and the open gaps are R10 and R11 (own caseload, Doppler), which you can state plainly.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3, R5a, R6a, R7a · adjacent: R5b (Leg-ulcer care), R9 (Housebound adults in their own homes) · unclear: R4 (Clear, timely written records), R6b (Continence care), R7b (Care planning), R8 (End-of-life visits)
- `important` — absent: R10 (Small caseload of own)
- `preferred` — absent: R11 (Doppler assessment)

R5b, R9 — credible bridges with limits named; R4, R6b, R7b, R8 — your CV is silent, so recall may close them; R10, R11 — real gaps, to be stated plainly.

**Opportunity ledger.** Sound and fairly transparent. Pool cars, named senior support and a named lead for a chat are all stated (RR3). Whether the posting is live (RR1), where pay would start (RR2), hours and caseload size (RR4) and Doppler training (RR5) are unknown.

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. The post is confirmed open on the employer's own careers page (RR1).
  2. R5b, R10 and R11 are presented as bridge or gap, never as experience.
  3. The answers on pay and hours (RR2, RR4) suit you, since your own limits weren't given.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract. Founded 2015, 410 staff, four locality hubs | `[grounded]` About page fetched |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin, care planning, on an electronic patient record | `[grounded]` advert |
| Supervision and tools | A small caseload of your own, supported by a senior community nurse; pool cars provided, plus mileage | `[grounded]` advert |
| Hiring contact | Rhiannon Mabbott leads the Halifax district nursing team after eleven years as a district nurse. At a 2025 forum she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` forum speaker page (search result only, page not opened) |
| Scope read | A core district-nursing duty set with one stated support structure; nothing bundled in beyond that list | `[inferred]` from the advert's duty list |
| First-year outcomes | Not stated | `[grounded]` advert silent |
| Market calibration | A 2026 pay survey of Band 5 community staff nurses in England (n=1,240) gives a median basic of £34,300, interquartile range £32,400–£36,600. The posting's £31,050–£37,800 spans a wider range, so it doesn't say where an offer would start. The survey found 61% were paid mileage and 24% had a pool or lease car. This is a pattern, not this employer's offer | `[generic]` Wardround survey, snippet only; `[grounded]` advert for the range |
| Unknowns | Caseload size; rota and weekend or evening working; where in the range an offer starts; whether Doppler training is provided; whether the post is live | — |
| Contradictions | None between the advert and the About page. The employer's careers page was not located | `[grounded]` About page fetched; careers address returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | You state Registered Nurse (Adult), registration active, revalidation due March 2028. Self-reported, no inspectable artifact read | `[grounded]` your CV | none |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | You state a full UK licence, category B. Self-reported | `[grounded]` your CV | none |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward. Titled years, not a gate | `[grounded]` your CV | none |
| R4 | Clear, timely written records on an electronic patient record | must_have | unclear | low | discovery | Your CV is silent on records and on any electronic system. I won't assume ward practice carries over | `[grounded]` CV silence | recall prompt G2 |
| R5a | Wound care | must_have | direct | medium | none | Pressure ulcers and surgical wounds, stated | `[grounded]` your CV | none |
| R5b | Leg-ulcer care | must_have | adjacent | medium | transferability | Wound care is credible adjacent work. Limit: leg ulcers, compression and venous assessment are not mentioned | `[inferred]` adjacency derived from your wound-care claim | bridge case G3 |
| R6a | Catheter care | must_have | direct | medium | none | Stated | `[grounded]` your CV | none |
| R6b | Continence care | must_have | unclear | low | discovery | Not mentioned | `[grounded]` CV silence | recall prompt in G2 |
| R7a | Insulin administration | must_have | direct | medium | none | Stated | `[grounded]` your CV | none |
| R7b | Care planning | must_have | unclear | low | discovery | Not mentioned | `[grounded]` CV silence | recall prompt in G2 |
| R8 | End-of-life visits | must_have | unclear | low | discovery | An acute medical ward may involve end-of-life care, but your CV doesn't say so | `[grounded]` CV silence | recall prompt G1 |
| R9 | Caring for housebound adults in their own homes | must_have | adjacent | medium | transferability | 18 months of home visits in the first week after discharge. Limit: short post-discharge episodes, not ongoing care of housebound patients | `[grounded]` your CV; `[inferred]` the limit from the advert's wording | bridge case G4 |
| R10 | Holding a small caseload of your own, with senior support | important | absent | none | capability | You say you have never held your own caseload. The advert pairs the caseload with a senior community nurse and doesn't list it as essential | `[grounded]` your statement; `[grounded]` advert | closure path in G4 |
| R11 | Doppler assessment for leg ulcers (desirable) | preferred | absent | none | capability | You say you have never done one. The team lead has spoken publicly on Doppler training for staff new to community work, so training may exist, which is not confirmed | `[grounded]` your statement; `[inferred]` from her talk topic | closure path G5; ask RR5 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | End-of-life visits (R8, must_have) | discovery | Your CV is silent on palliative or end-of-life care | A named core duty. A yes moves a `must_have` from `unclear` | Caring for dying patients on the ward; symptom control or anticipatory medicines; supporting families; discharging someone home to die in the discharge-to-assess role | A training record or reflective note with patient details removed | `[grounded]` CV silence; `[inferred]` that it could shift fit |
| G2 | Records, continence and care planning (R4, R6b, R7b) | discovery | Three duties your CV doesn't mention | Records are an essential criterion. The other two are named duties | Documenting on an electronic system; bladder or bowel care; writing or contributing to discharge or care plans | A competency sign-off or training record | `[grounded]` CV silence |
| G3 | Leg-ulcer care (R5b, must_have) | transferability | Wound care is stated. Leg ulcers, compression and venous assessment are not | The advert names leg-ulcer care. The team lead has spoken on nurse-led leg-ulcer clinics | Dressing or compression on leg wounds; tissue-viability input; any training in venous disease | A competency record or training certificate | `[inferred]` bridge from your wound-care claim |
| G4 | Home-based care and own caseload (R9, R10) | transferability | The discharge-to-assess visits are real adjacent work. You have never held your own caseload | Both rows rest on how independently you ran those visits | Planning your own visit list; making decisions at the bedside alone; escalating to a GP or community team; following a patient across several visits | A rota or visit-allocation example with patient detail removed | `[grounded]` your CV and statement; `[inferred]` that this is the likeliest question at interview |
| G5 | Doppler assessment (R11, preferred) | capability | Not done | A desirable criterion, not essential. The closure path is training, which RR5 asks about | A short Doppler or leg-ulcer course; shadowing a tissue-viability or district nurse | A course certificate | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed live on the employer's own careers page | unknown | — | "Community Staff Nurse, Band 5 — Calderbrook Community Health CIC, Halifax" | The advert may be on a third-party site, or the careers address I tried may simply be wrong | `[grounded]` careers address returned no page; `[generic]` that adverts get stale | Is this post still open, and what is the closing date? | unresolved |
| RR2 | Where an offer would start within a wide range | unknown | — | "£31,050–£37,800 a year plus mileage" | An offer could land anywhere in the range. The survey median sits mid-range | `[grounded]` advert; `[generic]` survey median | Where in the £31,050–£37,800 range would five years' post-registration experience place me? | unresolved |
| RR3 | Pool cars, named support and a named contact | positive_signal | — | "pool cars are provided"; "supported by a senior community nurse"; "For an informal chat about the role, contact Rhiannon Mabbott" | The role is set up for someone building a caseload. A pool car removes a cost that few survey respondents had covered | `[grounded]` advert; `[generic]` survey (24% had a pool or lease car) | What does the senior nurse's support look like in the first three months? | noted |
| RR4 | Hours, rota and starting caseload size unstated | unknown | — | "You will hold a small caseload of your own" | End-of-life visits may bring weekend or evening working. The advert is silent | `[grounded]` advert silent; `[generic]` pattern for community nursing, not a claim about this employer | What is the working pattern (weekends, evenings, on-call), and how big is a new nurse's starting caseload? | unresolved |
| RR5 | Whether Doppler training is provided | unknown | — | "Desirable: Doppler assessment for leg ulcers" | Training may be offered to new starters | `[inferred]` from the team lead's published talk on Doppler training for staff new to community work | Is Doppler training provided to new starters, and how soon after joining? | unresolved |

## Application plan

**Proposed CV edit** — `resume_edits_pending_approval`

| # | Current | Proposed | Source in your words | Status |
|---|---|---|---|---|
| E1 | The discharge-to-assess secondment sits at the end of your hospital role | Lead with it: "Seconded for 18 months to the discharge-to-assess team, visiting patients at home in their first week after discharge" | "the last 18 months seconded to its discharge-to-assess team, visiting patients at home in their first week after discharge" | `resume_edits_pending_approval` |
| E2 | Wound care, catheter care and insulin sit in a skills line | Keep your own words ("pressure ulcers and surgical wounds", "catheter care", "insulin administration") and put them in the advert's order | "Wound care including pressure ulcers and surgical wounds; catheter care; insulin administration" | `resume_edits_pending_approval` |

This audit holds clause by clause: nothing adds a caseload, a leg-ulcer claim or a Doppler claim.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the post is open on Calderbrook's own careers page before drafting | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Take up the advert's invitation to an informal chat with Rhiannon Mabbott, and ask RR2, RR4 and RR5 verbatim | The advert offers the chat, and the register doubles as your question list | `[grounded]` advert, register | pending your approval |
| A3 | In the supporting statement, say plainly that you have not held your own caseload or done a Doppler assessment. Describe the discharge-to-assess visits as home visits after discharge, not as a caseload | Matches R10 and R11, so an interviewer can't catch you out | `[grounded]` R10, R11 rows | pending your approval |
| A4 | Add a G1–G3 answer to the statement only once you've confirmed it | The rows stay `unclear` until you do | `[grounded]` map | pending your approval |

## Evidence status

Verified: none yet. Your NI number was in what you pasted. It isn't needed to evaluate a role, so I haven't used it, and I'd leave it out of anything further you send me.

Research tier: L1 — searches 4 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax district nursing" and "Community Staff Nurse Band 5 district nursing Calderbrook Community Health CIC job". Fetched "About Calderbrook Community Health" (calderbrookhealth.example/about). A fetch of calderbrookhealth.example/careers returned no page. Role reality: the employer is established and the advert is consistent with the About page. RR1: the posting itself is not confirmed live |
| 2. Role-family sweep | yes | Searched "NHS Agenda for Change Band 5 pay scale 2026/27 district nurse community staff nurse salary", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Market calibration `[generic]` and RR2. The official pay scale itself did not come back, so I haven't checked the advert's range against it |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Role reality (hiring contact), R11, RR5 and plan A2. Search result only, page not opened |

I can save all this as `tuesday-dossier.md` if you'd like a file to keep.

**Upgrade menu**

- A link to the live posting on Calderbrook's own careers page: closes RR1.
- The full job description or person specification: confirms whether other essential criteria sit behind this advert.
- Your answers to G1–G4: could move R8, R4, R6b, R7b, R9 and R10.
- A competency sign-off or training record, with patient details removed: could raise R5a, R6a and R7a from `medium` to `high`.
- Your pay floor and any hours or weekend limits: turns the hard-gates line from unknown into a real check.
- A deeper research pass on Calderbrook (leadership changes, regulator and staff reports, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

**Questions**

1. G1 — Have you cared for dying patients, on the ward or in discharge-to-assess? What did you personally do, and was anyone with you?
2. G4 — In the discharge-to-assess visits, who planned your visit list and decided what to do at the bedside, and when did you escalate to someone else?
3. RR2/RR4 — Is there a salary you wouldn't go below, or working patterns (weekends, evenings, on-call) you wouldn't accept?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.