Research is back on all three targets. I'm now fetching Calderbrook's careers page to check that the posting is live and matches what you pasted.
# Job Underwriting Assessment: Community Staff Nurse, Band 5, Calderbrook Community Health CIC

## Decision snapshot

**Yes, this one is worth applying for. Status: `go`.**

**Fit ledger.**

- `hard_gate` — direct: R1, R2, R3
- `must_have` — direct: R4 · unclear: R5 (Clear, timely written records)
- `important` — direct: R6a, R7a, R8 · adjacent: R6b (Leg-ulcer care), R10 (Housebound adults at home), R11 (Own small caseload) · unclear: R7b (Continence care), R9 (End-of-life visits)
- `preferred` — absent: R12 (Doppler assessment)

R12 — the only gap the advert itself calls desirable, not essential; R11 — the caseload you've never held, bridged by R10's home visiting; R5, R7b, R9 — your CV is silent, which is not the same as absent.

**Opportunity ledger.** The employer is established (RR1), the pay range sits around the market sweep (RR4), and the advert names senior support for a new caseload-holder (RR5). Two points are unconfirmed: whether the vacancy is still open (RR2) and the rota (RR3).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`, R3 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** the vacancy turning out to be closed (RR2), or rota terms that clash with a constraint you haven't told me yet (RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Community interest company running adult community nursing, therapy and rehab across Calderdale under an NHS contract; founded 2015; 410 staff in four locality hubs | `[grounded]` Calderbrook "About" page |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin, care planning, on an electronic patient record | `[grounded]` advert |
| Scope read | An entry route into community work from hospital nursing: one year post-registration is the minimum, the caseload is small and supported by a senior nurse, and Doppler is only desirable | `[inferred]` from the essential list against the "small caseload, supported" wording |
| Market calibration | The advertised £31,050–£37,800 brackets a Band 5 community-nurse survey's median (£34,300) and interquartile range (£32,400–£36,600). The survey is England-wide, so it is a market band and not this employer's offer | `[generic]` Wardround 2026 pay guide, n=1,240; `[grounded]` advert for the posted range |
| Hiring manager | Rhiannon Mabbott leads the Halifax district nursing team after eleven years as a district nurse. At a 2025 forum she spoke on nurse-led leg-ulcer clinics and Doppler training for staff new to community work | `[grounded]` community nursing forum speaker page |
| Unknowns | Whether the vacancy is open; rota and weekend or on-call expectations; where new starters sit in the pay range; induction length before carrying a caseload | `[grounded]` advert silent on each |
| Contradictions | None found between the advert and the About page. The careers page could not be retrieved, so the posting's own listing is unchecked | `[grounded]` About page read, careers fetch returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | Specific claim (PIN, active, revalidation March 2028), but the register entry has not been inspected | `[grounded]` CV | A screenshot of your public NMC register entry would raise it to `high` |
| R2 | Full UK driving licence (pool cars provided) | hard_gate | direct | medium | none | Category B licence stated on the CV; nothing inspectable | `[grounded]` CV | none |
| R3 | Based in Halifax | hard_gate | direct | medium | none | You live in Halifax and the post is in Halifax; stated, not a documented constraint | `[grounded]` your intake and the advert | none |
| R4 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a ward staff nurse stated. A years requirement is graded as a must-have, not a gate | `[grounded]` CV | none |
| R5 | Clear, timely written records (on an electronic patient record) | must_have | unclear | low | discovery | Your CV is silent on records and on which record system you used. Ward and home-visit nursing both involve documentation, but that is a pattern and not your evidence | `[grounded]` CV silence; `[generic]` that ward work involves records | Mention the record system you used, if any, in your application; no question asked this turn |
| R6a | Wound care | important | direct | medium | none | "Wound care including pressure ulcers and surgical wounds" is stated and already in the ad's own terms | `[grounded]` CV | none |
| R6b | Leg-ulcer care | important | adjacent | low | transferability | Your wound care is credible adjacent work. The limit: the CV doesn't mention leg-ulcer assessment or compression, which are specific skills | `[grounded]` CV; `[inferred]` adjacency from the wound-care claim | See G2 |
| R7a | Catheter care | important | direct | medium | none | Catheter care is stated on the CV | `[grounded]` CV | none |
| R7b | Continence care | important | unclear | low | discovery | The CV names catheter care but not continence care more widely. I won't widen one into the other | `[grounded]` CV | Carried as a minor open point; not asked this turn |
| R8 | Insulin administration and care planning for insulin | important | direct | medium | none | Insulin administration is stated. Care planning for it is not stated, so this row claims administration only | `[grounded]` CV | none |
| R9 | End-of-life visits | important | unclear | low | discovery | The CV is silent. An acute medical ward and a home-visiting secondment may both include end-of-life care, but nothing here says you gave it | `[grounded]` CV silence | See G1 |
| R10 | Caring for housebound adults in their own homes | important | adjacent | medium | transferability | 18 months visiting patients at home in their first week after discharge is real home-based work. The limit: short post-discharge visits, which may not be the same as ongoing care for long-term housebound patients | `[grounded]` CV | Frame it as home-visiting experience, with that limit named |
| R11 | A small caseload of your own, with care planning, supported by a senior nurse | important | adjacent | low | transferability | You've said you have never held a caseload. Home visits show you've worked unsupervised in homes, but I can't tell from the CV whether you planned your own visit list. Low, since it sits between adjacent and unclear | `[grounded]` your statement and CV; `[inferred]` the bridge | See G3 |
| R12 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You've never done one. It is desirable, not essential. The hiring manager has spoken publicly about Doppler training for staff new to community work, which suggests training may exist, but that is not confirmed for this employer | `[grounded]` your statement and advert; `[inferred]` training likelihood from the speaker page | Ask what training is offered (RR5) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | End-of-life visits (R9, important) | discovery | The CV says nothing about care of dying patients, on the ward or in discharge-to-assess | The advert lists it as a core duty, so a concrete example would turn a silent row into a strength | Last-days care on the ward; anticipatory medicines; supporting a family at the bedside; a discharge home for end-of-life care | Training record, a competency sign-off, or a reference naming it | `[grounded]` CV silence; `[inferred]` that the duty is core, from its place in the advert's list |
| G2 | Leg-ulcer care (R6b, important) | transferability | Wound care is stated, but not leg ulcers or compression | The advert names leg-ulcer care first among duties, and Doppler sits beside it as desirable | Applying compression bandaging; assessing a venous ulcer; a wound-care study day | A training certificate or competency record | `[grounded]` CV and advert |
| G3 | Own caseload (R11, important) | transferability | Home visits yes, a caseload you managed and planned, no | It's the biggest structural difference between your current work and this role | Your discharge-to-assess visit list: how it was set, who decided the order, what you decided alone and what you escalated | A line from the team lead describing your role there | `[grounded]` CV and your statement; `[inferred]` that the visit list is the bridge |

G3 is a bridge case, not a question this turn: the adjacent evidence is the home visiting, the limit is that you haven't held a caseload, and the strengthener would be a description of how your visits were allocated.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer exists and matches the description | positive_signal | — | "caring for housebound adults in their own homes" | Calderbrook is a real adult community nursing provider in Calderdale | `[grounded]` About page: NHS contract, 410 staff, four hubs | Who would I be working under day to day, and which hub would I be based at? | noted |
| RR2 | Vacancy liveness not confirmed | unknown | — | "For an informal chat about the role, contact Rhiannon Mabbott" | The posting may be current, closed or reposted; I couldn't read the careers page | `[grounded]` careers fetch returned no page | Is this vacancy still open, and what are the closing and interview dates? | unresolved |
| RR3 | Rota and out-of-hours expectations unstated | unknown | — | "district nursing team caring for housebound adults" | Community nursing teams often cover extended days and weekends. The advert doesn't say what this one does | `[generic]` role-family pattern, not a claim about this employer | What does the rota look like, and are weekends or on-call included? | unresolved |
| RR4 | Pay range in line with the market sweep | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The posted range brackets the survey's interquartile range; the starting point within it is not stated | `[grounded]` advert; `[generic]` survey band | Where in the range would my experience place me? | noted |
| RR5 | Senior support named, with a likely training route | positive_signal | — | "supported by a senior community nurse" | The structure is explicit, and the team lead has publicly discussed Doppler training for community newcomers | `[grounded]` advert and forum page; `[inferred]` that new starters get that training | How long is supervised practice before I carry my own caseload, and what leg-ulcer and Doppler training is offered? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Move your secondment to the top of the CV with its own wording: "Seconded for 18 months to the discharge-to-assess team, visiting patients in their own homes in their first week after discharge" | See R10 | `[grounded]` CV | pending your approval |
| E2 | Group wound care (pressure ulcers, surgical wounds), catheter care and insulin administration together in a skills line, using the advert's terms | See R6a, R7a, R8 | `[grounded]` CV | pending your approval |
| A1 | Say plainly in the application that you haven't held your own caseload or done Doppler assessment, and that you want to learn both | The advert makes Doppler desirable and promises senior support; stating limits is stronger than letting them be found | `[grounded]` advert | pending your approval |
| A2 | Use the informal chat with the team lead. Ask the RR2, RR3, RR4 and RR5 questions, and ask about her work on Doppler training | The advert invites the call; the questions double as your own checks | `[grounded]` advert and forum page | pending your approval |
| A3 | Have your NMC register entry and licence details ready | Both gates rest on your word so far | `[generic]` common pre-employment practice | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none. Your National Insurance number isn't needed to assess a role and I haven't used it.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about). A fetch of calderbrookhealth.example/careers returned no page. It moved RR1 and the organization row, and left the posting's liveness open (RR2) |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse district nursing salary Agenda for Change 2026 Band 5 pay scale", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). It moved the market calibration row and RR4 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead", which returned a speaker page (communitynursingforum.example/speakers/rhiannon-mabbott). It moved the hiring-manager row, R12, RR5 and plan item A2 |

I can save this as `tuesday-dossier.md` if you'd like a file to keep.

## Upgrade menu

- A link to the live vacancy or its closing date → RR2 closes.
- A screenshot of your public NMC register entry → R1 to `high`.
- A training record or competency sign-off for compression bandaging or end-of-life care → R6b or R9 firms up.
- A line from your discharge-to-assess lead on how your visits were allocated → R11's bridge strengthens.
- Your pay floor, hours and travel limits → the hard-gates line can then check them against the advert instead of flagging them as unknown.
- A deeper research pass on Calderbrook (inspection outcomes, staff and leadership changes, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

**G1** — On the ward or in discharge-to-assess, have you cared for patients in their last days, such as anticipatory medicines, supporting family, or arranging a discharge home to die? What was your part?
**G2** — Have you applied compression bandaging, assessed a leg ulcer, or done any training on either?
**Constraints** — Do you have a pay floor, hours or weekend limits, or travel limits that I should check against this role?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.