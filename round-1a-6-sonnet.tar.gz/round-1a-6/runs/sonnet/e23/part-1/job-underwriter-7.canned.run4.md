I'll read the reference files the skill points to before building the assessment.
**Is it worth applying?** Yes, it's worth applying — R1 and R2, the two hard gates, are `direct`. R9 (never held a caseload) and R11 (Doppler) are stretches you've already named, and R4b, R6, R10 and R12 are open until you answer. **Status: `conditional_go`.**

## Decision snapshot

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3 · unclear: R10 (clear, timely written records)
- `important` — direct: R4a, R7, R8 · adjacent: R5 (catheter and continence care), R9 (small caseload of your own) · unclear: R4b (leg-ulcer care), R6 (end-of-life visits), R12 (care planning)
- `preferred` — absent: R11 (Doppler assessment)

R9 — never held a caseload, the main stretch; R4b, R6, R10, R12 — CV silent, closable by your answers; R11 — Doppler is desirable, not essential.

**Opportunity ledger.** The role reads sound. Pay sits inside the market range (RR1), pool cars are provided and a named team lead supports the post (RR1, RR5). Hours, contract terms and induction are unstated (RR2, RR3, RR6), and the live posting couldn't be confirmed (RR4).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you can evidence clear, timely records on an electronic system (R10); (2) the post is confirmed live on the employer's own careers page (RR4); (3) the caseload gap is stated plainly, never framed as experience you hold (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015, 410 staff, four locality hubs | `[grounded]` "About Calderbrook Community Health" page |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin and care planning, on an electronic patient record | `[grounded]` advert |
| Caseload and support | A small caseload of your own, supported by a senior community nurse | `[grounded]` advert |
| First-year outcomes | Not stated | `[grounded]` advert is silent |
| Scope read | A first community post: a small supported caseload and a one-year experience floor point to a developmental entry role | `[inferred]` from the advert's "small caseload", "supported" and "at least one year" |
| Hiring lead | Rhiannon Mabbott leads the Halifax district nursing team, after eleven years as a district nurse; at a 2025 forum she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` community nursing forum speaker page |
| Market calibration | Band 5 community staff nurses in England: median £34,300, interquartile range £32,400 to £36,600; 24% have a pool or lease car, 61% are paid mileage. The advert's £31,050–£37,800 plus mileage and pool cars is in line. The survey is a pattern, never this employer's offer | `[generic]` Wardround 2026 pay guide (n=1,240); `[grounded]` advert for its own figures |
| Unknowns | Hours and weekend or on-call work; contract terms (pension, leave, whether national terms apply); starting point on the band; induction for nurses new to community work; whether the post is live | `[grounded]` advert silent on each |
| Contradictions | None between the advert and the About page. The careers page could not be opened, so the posting itself is unconfirmed | `[grounded]` About page read; careers fetch returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | CV gives a PIN, "registration active", revalidation due March 2028. Self-reported; nothing inspected | `[grounded]` CV | none; have the PIN ready, employers check the register themselves |
| R2 | Full UK driving licence (pool cars provided) | hard_gate | direct | medium | none | CV states a full UK licence, category B. Self-reported; the licence was not inspected | `[grounded]` CV | none |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | CV states five years as a staff nurse on an acute medical ward. A length-of-experience term, not a gate | `[grounded]` CV | none |
| R4a | Wound care | important | direct | medium | none | CV: wound care including pressure ulcers and surgical wounds. Ward setting; leg ulcers are not named | `[grounded]` CV | none |
| R4b | Leg-ulcer care | important | unclear | low | discovery | CV is silent on leg ulcers or compression therapy. Pressure-ulcer care is nearby but is not leg-ulcer care | `[grounded]` CV silence | question G2 |
| R5 | Catheter and continence care | important | adjacent | medium | discovery | CV states catheter care; continence care beyond catheters is not stated. Taking the lower reading | `[grounded]` CV | G-queue row G4 |
| R6 | End-of-life visits | important | unclear | low | discovery | CV is silent on end-of-life care. Nothing is asserted from the ward setting | `[grounded]` CV silence; `[generic]` acute medical wards often care for dying patients, which is a lead and not your evidence | question G3 |
| R7 | Insulin administration | important | direct | medium | none | CV states insulin administration. Limit: it is ward-based, and the role adds home settings | `[grounded]` CV | none |
| R8 | Visiting housebound adults in their own homes | important | direct | medium | none | CV: 18 months seconded to the discharge-to-assess team, visiting patients at home in their first week after discharge. This is your most role-shaped evidence | `[grounded]` CV | lead with it (plan E1) |
| R9 | A small caseload of your own, supported by a senior nurse | important | adjacent | medium | transferability | You confirmed you have never held your own caseload. The bridge is home visiting at discharge. The limit is that you haven't owned a visit list or ongoing patient relationships. The support described eases that limit | `[grounded]` your statement and CV | state plainly (plan A2); G5 |
| R10 | Clear, timely written records, on an electronic patient record | must_have | unclear | low | discovery | CV says nothing on documentation or electronic records. Nothing is asserted from the ward role | `[grounded]` CV silence | question G1 |
| R11 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You confirmed you have never done one. Desirable, not essential. The lead has spoken on Doppler training for staff new to community work, so training may be available | `[grounded]` your statement, advert and forum page; `[inferred]` training availability | ask in the informal chat (plan A4) |
| R12 | Care planning | important | unclear | low | discovery | CV is silent on care plans. The advert pairs it with insulin administration | `[grounded]` CV silence and advert | G-queue row G6 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Written records, electronic (R10, must_have) | discovery | The CV doesn't mention documentation or any electronic record system | A must-have row at `unclear`; the advert lists written records as essential | Entering observations, discharge notes or care plans on an electronic patient record; documenting home-visit assessments in the discharge team; record audits | A competency sign-off, an audit result or a reference mentioning documentation | `[grounded]` CV silence; `[inferred]` that closing it moves the status towards `go` |
| G2 | Leg-ulcer care (R4b, important) | discovery | The CV names pressure ulcers and surgical wounds but not leg ulcers or compression | Leg-ulcer care is the advert's second duty and Doppler (R11) builds on it | Applying or reviewing compression bandaging; dressing venous or mixed ulcers; tissue-viability sessions | A competency sign-off, training certificate or revalidation portfolio entry | `[grounded]` CV silence; `[inferred]` Doppler depends on this base |
| G3 | End-of-life visits (R6, important) | discovery | The CV is silent on end-of-life care | It is a named duty; a first community post is likely to meet it early | Caring for dying patients on the ward; symptom control or syringe-driver support; supporting families; discharge for rapid end-of-life care | A training certificate or a reflective entry from revalidation | `[grounded]` CV silence; `[generic]` such work is common on acute medical wards |
| G4 | Continence care beyond catheters (R5, important) | discovery | The CV states catheter care only | Narrows the row from `adjacent` towards `direct` | Bladder and bowel care plans, continence assessments, pad and product selection | A competency record | `[grounded]` CV |
| G5 | Owning a visit list (R9, important) | transferability | Home visits are evidenced; owning the planning, order and follow-up of visits is not | It is the role's central stretch | Planning your own visit order in the discharge team; first-week follow-up decisions; escalating to GPs | Your secondment job description or a reference | `[grounded]` CV and your statement |
| G6 | Care planning (R12, important) | discovery | The CV is silent on care plans | Paired with insulin administration in the advert | Writing or reviewing care plans for discharge or diabetes; setting goals with patients | A sample care-plan format, anonymised | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay, pool cars and named support in line | positive_signal | — | "£31,050–£37,800 a year plus mileage"; "pool cars are provided" | Package is within the range surveyed; the post has a named lead and senior support | `[grounded]` advert; `[generic]` survey median £34,300 | Where on the band would a nurse with my experience start? | noted |
| RR2 | Hours and working pattern unstated | unknown | — | "caring for housebound adults in their own homes" | Community posts may include weekends or on-call; the advert doesn't say | `[generic]` pattern; `[grounded]` advert silent | What are the working days and hours, and is there weekend or on-call work? | unresolved |
| RR3 | Contract terms unstated | unknown | — | "Calderbrook Community Health CIC" | A CIC may not employ on the national NHS terms that the band implies | `[generic]` pattern for CICs under NHS contracts; `[grounded]` advert silent on terms | Does this post carry national NHS terms, including pension and annual leave? | unresolved |
| RR4 | Posting not confirmed live on the employer's site | risk_signal | low | "Community Staff Nurse, Band 5 — Calderbrook Community Health CIC, Halifax" | The employer is real as described; the careers page could not be opened, so the posting may be stale or hosted elsewhere | `[grounded]` About page found, careers fetch returned no page | Can you confirm this post is open, and its closing date? | unresolved |
| RR5 | Named lead with relevant public expertise | positive_signal | — | "informal chat … Rhiannon Mabbott, Community Nursing Team Lead" | The lead has spoken on Doppler training for staff new to community work, which bears directly on R11 | `[grounded]` forum speaker page | How does the team train nurses new to community work, including Doppler? | noted |
| RR6 | Induction and caseload build-up unstated | unknown | — | "You will hold a small caseload of your own, supported by a senior community nurse" | "Small" and "supported" are undefined, and matter as you haven't held a caseload before | `[grounded]` advert; `[inferred]` from your R9 statement | How big is the starting caseload, and how long is the supported period? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | CV edit: move the discharge-to-assess secondment to the top of Experience, in your own words: "Seconded for 18 months to the discharge-to-assess team, visiting patients at home in their first week after discharge." | See R8 | `[grounded]` CV, unchanged wording | resume_edits_pending_approval |
| A1 | Name wound care, catheter care and insulin administration beside the ward role, exactly as you wrote them | See R4a, R5, R7 | `[grounded]` CV | pending your approval |
| A2 | In any supporting statement, say that you have not yet held your own caseload, and that your home-visit work was on discharge | See R9; a plain statement can be checked and won't be contradicted at interview | `[grounded]` your statement; `[generic]` that candour here is the safer ground | pending your approval |
| A3 | Say that you have not done Doppler assessment; it is listed as desirable | See R11 | `[grounded]` advert and your statement | pending your approval |
| A4 | Take up the offered informal chat with Rhiannon Mabbott before applying, and ask the RR2, RR3, RR4 and RR6 questions verbatim, plus how Doppler training works | The advert invites it; the register doubles as preparation | `[grounded]` advert and register | pending your approval |
| A5 | Check the post on Calderbrook's own careers page, and note the closing date | See RR4 | `[grounded]` RR4 | pending your approval |

Everything in this table is proposed. Nothing is applied until you approve it.

## Evidence status

Verified: none yet. Your NI number isn't needed to assess a role, so I haven't used it.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax community staff nurse", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about). A fetch of calderbrookhealth.example/careers returned no page. Role reality: the organization and contradictions rows; RR4 stays open because the posting itself isn't confirmed |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse district nursing salary 2026 Agenda for Change", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved the market calibration row and RR1 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Moved the scope read, R11, RR5 and plan A4 |

I can turn this into a `tuesday-dossier.md` file if you'd like to keep or reuse it.

## Upgrade menu

- A line or two on records or electronic systems you've used, or a documentation audit or competency sign-off, would close R10 and could lift the decision towards `go`.
- Your revalidation portfolio entries, a practice-hours log, or competency sign-offs for wound care, catheterisation and insulin would raise R4a, R5 and R7 towards `high`.
- A check of your entry on the NMC register, and your driving licence, would be the inspectable artifacts for R1 and R2.
- The link to the live posting on Calderbrook's careers page would close RR4.
- Your pay floor and any constraints on hours, days or travel would add hard-gate rows for pay and schedule, and let the snapshot check them.
- A deeper research pass on Calderbrook (contract performance, leadership changes, staff and patient reports, recent news) is available. It would use up to 5 more searches and 2 more fetches — say the word and it runs.

**Questions**

G1 — Have you written patient records on an electronic system (on the ward or in the discharge team), and was timely documentation ever checked or audited? Say what you used and what happened.
G2 — Have you applied compression bandaging or cared for leg ulcers specifically, as opposed to pressure ulcers? What did you do yourself?
G3 — Have you cared for dying patients or supported their families, on the ward or in the discharge team? What was your part?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.