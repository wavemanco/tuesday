**Don't pay, send anything or deposit any cheque. This email has the hallmarks of a fake-cheque scam, and I wouldn't prepare for this "interview" as if it were real.**

## Why it looks like a scam

- **An upfront fee.** Real employers don't charge a €95 "equipment registration fee" to confirm an interview slot.
- **A cheque to deposit and then forward.** The €1,850 cheque is the core of the fraud. It will look genuine and your bank may even credit it. Days or weeks later it bounces, and you're liable for the money you sent on to the "vendor".
- **Passport photo and bank details before any interview.** That is identity theft material. Legitimate employers ask for ID only after a job offer, and usually in person or through a proper HR system.
- **A vague, generic setup.** There's a 30-minute video call, no named interviewer, and an HR address at an `.example` domain. Check the company name and domain independently as well.

## What to do now

1. Don't reply, and don't send the passport or bank details.
2. If you've already sent anything, call your bank straight away. If it was the passport, also contact the Gardaí and consider a credit-file alert.
3. Look up "Brennock Facilities Ltd" in the Companies Registration Office (cro.ie). Find their phone number yourself, not from the email, and ask whether the role exists.
4. Report the email to the Gardaí, and to the job site where you saw the ad so they can remove it.
5. Keep the email as evidence, then block the sender.

The ad itself (calendars, travel, Word/Excel, supplier invoices) is also the kind of generic ad scammers use. That doesn't mean your application was wasted, but treat any contact from that advertiser with caution.

## Prep for a genuine admin interview

Your background fits roles like this well. Here is what a real interview for one usually covers.

**What to expect**
- A 30–45 minute conversation with an office manager or hiring manager, possibly followed by a short Excel or Word task.
- Questions on prioritising, accuracy, handling difficult people, and tools.

**Your strongest material**
- **Calendars:** you ran the appointment book for four physios. Be ready with specifics, such as how you handled double-bookings, cancellations and clashing priorities.
- **Invoices:** you chased unpaid invoices. Have a concrete example, including how you stayed polite but persistent and what the outcome was.
- **Word:** you're good with it, so give an example of a document you produced.

**Your gaps**
- **Excel:** "okay" will get probed. Practise VLOOKUP/XLOOKUP, pivot tables, sorting and filtering, and basic formulas. Be honest about your level, and say how you'd build up the rest.
- **Travel booking:** you haven't done this, and the material doesn't show any equivalent. Prepare an honest bridge. For example, you coordinated patients' schedules and are quick to learn booking tools. Don't claim travel experience you don't have.
- **Remote working:** if it's a remote role, expect questions on self-management and communication.

**Questions to rehearse**
1. Tell me about a time you juggled competing demands on someone's calendar.
2. Describe a mistake you made in a booking or invoice and what you did.
3. How do you handle a supplier or client who won't pay?
4. Rate your Excel, then walk me through something you've built.
5. Why admin, and why remote?

**Questions to ask them**
- What does a typical week look like?
- Which systems do you use for invoicing and travel?
- How is success measured in the first three months?

If you get a real interview invitation, send me the job description and the interviewer's name or role. I'll build the full prep pack for it, with the fit table, question banks and a live drill if you want one.