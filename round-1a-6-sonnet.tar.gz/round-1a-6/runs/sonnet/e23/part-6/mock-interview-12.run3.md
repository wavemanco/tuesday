I'd stop before preparing for this interview, because the email looks like a scam. I haven't built the prep pack. Practising answers for an interview that probably doesn't exist would waste your time.

**Red flags in the email**
- **The €95 "equipment registration fee".** Real employers don't charge candidates to interview, and an interview slot isn't something you pay to confirm.
- **The cheque for €1,850 where you "send the balance on to the vendor".** This is the classic fake-cheque scam. The cheque looks real and your bank may credit it, but it bounces days or weeks later. By then you've sent real money to the "vendor", and the bank takes the full amount back from you.
- **Your passport photo and bank details before any interview.** Nobody legitimate needs these at this stage. This is identity theft or account takeover.
- **An interview that comes with a payment, a cheque and your ID documents.** A genuine process for a remote admin role wouldn't bundle these.
- **The "supplier's account" IBAN.** Money sent to it is very hard to recover.

**What to do now**
1. Don't pay anything. Don't send your passport or bank details. Don't deposit any cheque they send.
2. Check whether Brennock Facilities Ltd exists. Search the Irish Companies Registration Office (CRO) register and look for a real website and phone number. Don't use any contact details from the email. Note that `brennock.example` isn't a real domain.
3. Check where the ad came from. If it was on a job board, report the listing to the board.
4. If you've already sent money or documents, contact your bank straight away and report it to An Garda Síochána. If you sent your passport details, ask your bank and the relevant authorities about identity-fraud protection.

**Interview prep for real roles**
Your background suits remote or in-office admin jobs well. You've run a four-physio appointment book, which is calendar management, and you've chased unpaid invoices, which is invoice and supplier work. Your Word is strong and your Excel is okay, and Excel is the gap to prepare for. Here are two ways I can help:
- If a genuine company interviews you, send me the job description and I'll build a full prep pack with likely questions, answers drawn from your real experience, and a plan for the Excel gap.
- I can build a prep pack now for a generic Remote Administrative Assistant role, using the duties in that ad. It would have no company-specific research.

Which would you like? If it's the second, do you know the interview format, such as a hiring manager, an HR screen or a panel? That would change how I structure it.