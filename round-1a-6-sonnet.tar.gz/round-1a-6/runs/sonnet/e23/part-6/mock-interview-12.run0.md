Please don't pay anything or send your passport or bank details yet. This email has the hallmarks of a fake-cheque scam, and I don't think it's a real interview invitation. I haven't built the prep pack for it, because rehearsing for this "interview" wouldn't help you.

**Why it looks like a scam**
- **Upfront fee:** a real employer never asks you to pay a "registration fee" to be interviewed. The €95 is the first small loss.
- **Passport and bank details before an interview:** legitimate employers ask for these only after a signed contract, for payroll and right-to-work checks.
- **The cheque for €1,850:** this is the main trick. You deposit it and send "the balance" to a vendor. A few days later the cheque bounces, and the money you sent is yours to repay.
- **Payment to a "supplier's account":** the money is going to a third party, not to the company.
- **Other warning signs:** the invitation has no named person, no interview time and no video link. The ad was generic. The domain looks like a placeholder (`brennock.example`), so check the real sender address too.

**What to do**
1. Don't pay, don't reply with documents, and don't deposit any cheque.
2. Look up "Brennock Facilities Ltd" on the Companies Registration Office (cro.ie) register. Then contact the company using a number or website you find yourself, not one from the email.
3. If you've already sent your passport or bank details, tell your bank today and ask them to watch the account. Also consider contacting the Garda National Economic Crime Bureau, and ask about identity-fraud protection.
4. Report the email to the job board where you saw the ad. In Ireland you can also report it to the Garda or the Competition and Consumer Protection Commission (CCPC).

**The prep itself**
Your background fits a real admin role well. You ran the appointment book for four physios, which is calendar management. You chased unpaid invoices, which is invoice processing. Word is solid, and Excel is the gap to close before any real interview. For a genuine assistant role, expect questions on prioritising conflicting bookings, handling difficult people (clients or chasing late payers), and Excel tasks like formulas, pivot tables and tracking invoices. Practising those would be time well spent.

I can build the full prep pack in either of two ways:
- **For a verified employer:** send me the real job description and tell me who the interview is with (office manager, HR or a panel).
- **As a general pack for remote admin assistant roles:** I'd base it on your clinic experience and flag every generic question as generic.

If you'd rather paste the email's sender details or the job ad, I can also help you judge whether the company is real.