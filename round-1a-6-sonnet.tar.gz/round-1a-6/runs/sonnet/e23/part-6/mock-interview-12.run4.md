**Don't send the €95, your passport, your bank details or deposit that cheque. This email has the hallmarks of a fake-cheque scam, not a real interview invitation.** I haven't built the interview pack yet, because I'd be preparing you for an interview that probably doesn't exist.

**Red flags in the email**
- **Paying to get an interview.** Real employers never charge an "equipment registration fee", and certainly not to a "supplier's account".
- **The cheque for €1,850.** You deposit it, then send "the balance" to a vendor. This is the classic scam. The cheque bounces days or weeks later, after the bank has already let you send real money. You then owe the bank that money.
- **Passport and bank details before any interview.** A real employer asks for these after a signed offer, through a proper HR system. Scammers use them for identity theft and account takeover.
- **A 30-minute video call as the only screening.** A job that supposedly pays for your laptop and desk before you've met anyone is offering a lot for very little vetting.
- **Other signs.** The email uses a placeholder-style domain and reads like a template. It also skips the usual details, like interviewers' names and a role description that matches your CV.

**What to do now**
1. **Don't pay, don't reply with documents, and don't deposit anything.** If you've already sent your passport or bank details, call your bank today, ask them to watch the account, and consider changing your online banking credentials.
2. **Check the company independently.** Look it up in the Companies Registration Office (CRO) register at cro.ie. Find its website and phone number yourself, not through the email, and ask whether the role exists. Brennock Facilities Ltd may not exist, or the real company may have had its name copied.
3. **Report it.** In Ireland you can report it to An Garda Síochána, and tell the job site where you applied so they can remove the listing. If you want to confirm it's fake, search for the company name alongside "scam".
4. **Watch for follow-ups.** Scammers often keep pressing with urgency ("slots are filling fast"). That pressure is a further sign.

**Your experience is useful for real roles**

The ad matches your background well. You ran the appointment book for four physios, which covers calendar management. You chased unpaid invoices, which is close to supplier-invoice work. You're good with Word, and Excel is your gap, so spend a few hours on lookups, filters, pivot tables and basic formulas. Real admin interviews will also ask about prioritising conflicting bookings, handling difficult people, accuracy under pressure, and how you'd handle travel booking.

If a genuine interview comes up, whether from a verified employer or one you've contacted yourself, send me the company, the job ad, your CV and who you'll be speaking to. I'll build a full prep pack with likely questions, answer guidance based on your real experience, and questions to ask them.

If you'd like practice in the meantime, I can run a mock admin interview with you now.