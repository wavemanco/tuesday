Loading is done. I'm running the first research searches on the district, the school and the principal, then I'll build the pack.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a6/runs/sonnet/e23/part-3/rooms/case-9-canned-c1c5d10f/Orrinsford_fourth-grade-teacher_interview_pack.md`. I built it for the one 45-minute building panel on the district's hiring page: Principal Vantongeren and two fourth-grade teachers. I had no job posting, so the two rows drawn from a general board listing (F9 and F10) are marked `[inferred]`.

The pack has a fit snapshot against your resume lines, a read on the principal's public background, 22 practice questions across seven interviewer styles, reverse questions, and a list of claims it won't coach. Its top-priority rehearsal is A1, the "never taught fourth grade" question. H2 comes next, because it sets "I led the move" against "I've never been a team lead".

Your resume text included a Social Security number. Interview prep doesn't need it, so I didn't use it. You may want to remove it from any copy you share.

Say the word and I'll play the panel on A1, the question the pack names as its highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Do you have the actual job posting? Pasting it would replace the `[inferred]` rows with the district's own wording and show which requirements need their own question.
Did HR or the invite mention anything beyond the conversation, such as a sample lesson, items to bring or focus areas? That would add a build section.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Orrinsford_fourth-grade-teacher_interview_pack.md -----
# Interview pack: Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)

**Candidate:** Grace. **Round:** one 45-minute panel on Thursday: Principal Dolores Vantongeren and two members of the fourth-grade team (names not given). **Built on:** the invite, your CV text, and L1 research on the district. No job posting was supplied, so posting-derived rows are labeled `[inferred]`.

## How to use this pack

- **Personas describe how a question arrives; types describe what is being scored.** Rehearse both: a panel member can ask a Skeptic question in a Conversational voice.
- **Type tags:** VAL = behavioral / values alignment. EXP = work-experience deep-dive. JD = role-driven. CO = company and strategy knowledge. CASE = a live problem from the role.
- **Guidance is scaffolding, not a script.** Every sentence about your past comes from your own words, quoted. Where the material is silent, the guidance is an answer slot: an instruction for what to say in the interview, with an honest branch if the thing never happened or was not yours.
- **Highest-ROI prep:** A1, the fourth-grade question. It will be asked in some form. H2 is its twin, because it tests two of your own sentences against each other.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | Your own line meets the gate, and its grades 1–6 range includes fourth grade. Nothing was inspected behind it, so expect a request to confirm it. Say it in the quote's own terms and add nothing |
| F2 | "Fourth Grade Teacher position" — invite | "I've never taught fourth grade" — your CV; "Six years teaching third grade at a public elementary school in Joliet" — your CV | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't taught fourth grade." Then the six years at their own scope. Then how you would learn it, said as a plan and never as a past |
| F3 | "reading instruction" — district hiring page (fetched) | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | discovery | The sentences show a curriculum move and a club, not what a reading lesson looks like. Answer slot: expect a probe on how reading is taught. If the move changed how your grade level taught reading, say what changed; if the club connects to classroom reading, say how; if neither reached the daily lesson, say so plainly and stay with the move and the club |
| F4 | "classroom routines" — district hiring page (fetched) | none given | none | [grounded] | discovery | Your material says nothing about routines. Answer slot: if you have a routine you ran in your own room, say what it was and what it did; if none comes to mind, say so plainly and build one from first principles when asked |
| F5 | "how you work with families" — district hiring page (fetched) | "I write a weekly email to families" — your CV | medium | [grounded] | presentation | Say the sentence as it stands: weekly, an email, to families. It is one channel and the words stay at that scope |
| F6 | "each teacher speaks with every family each term" — district beliefs page (fetched) | "I write a weekly email to families" — your CV | low | [inferred] | transferability | Your material says the email, not conversations. Words: "I write a weekly email to families." Answer slot inside the email: say what the email holds and what comes back to you; if nothing comes back, or it was not tracked, say so plainly and stay with the email |
| F7 | "no student leaves third grade without a reading plan" — district beliefs page (fetched) | "Six years teaching third grade at a public elementary school in Joliet" — your CV | low | [inferred] | discovery | The belief ends at the grade you have taught, and your material says the grade, not reading plans. Answer slot: if you wrote or used reading plans for individual students, say what they were and who made them; if none existed, or they were not yours, say so plainly and stay with the six years |
| F8 | "assessments inform teaching and never replace it" — district beliefs page (fetched) | none given | none | [grounded] | discovery | Your material says nothing about assessment. Answer slot: if results ever changed what you taught, say what and how; if not, or it was not your decision, say so plainly and say how you would want to use them |
| F9 | "work with the grade-level team" — K12 Jobs Board listing, a search result not opened | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your CV | medium | [inferred] | presentation | Rewords only the first quote: "I led our grade level's move to a new reading curriculum in 2024." Your second sentence stays beside it as a plain acknowledgment: "I haven't been a team lead." Typical-for-the-role listing text, not this team's practice. The material shows the move, not a title |
| F10 | "differentiate instruction using assessment data" — K12 Jobs Board listing, a search result not opened | none given | none | [inferred] | discovery | Typical for the role, not this team's practice. Answer slot, raised by the district belief in F8: if you used assessment results to teach different students differently, say how; if not, or it was not yours, say so plainly |

## Reading the interviewer

Public professional footprint only; one search result, not opened. Nothing else is claimed.

| Fact | Source | What it means for you |
|---|---|---|
| Principal of Halvering Elementary School since 2022, after nine years as a reading specialist | ilprincipalsforum.example speaker page, search result | Expect reading questions to be followed two or three levels deep. Rehearse A5, E3 and B2 right after A1 |
| 2025 forum talk "Small Groups, Big Readers" covered weekly reading conferences in grades 3 to 5 | same | The range spans the grade you have taught and the grade you are applying for. Say "Six years teaching third grade at a public elementary school in Joliet" at its own scope and let the panel draw the link |
| Terms in the talk title: small groups, reading conferences | same | Use these as the subject of a reverse question (reverse question 1). Describe your own practice with them only if it is yours |

No shared career jump is offered: neither the profile nor your sentences carry one. Panel weights: the principal reads like a hiring-manager relationship (Skeptic and Case). The two fourth-grade teammates read like peers (Peer Evaluator and Prober). Individual names would let the pack assign personas per member.

## Persona table

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A, 5 questions) | Quiet probing of "never taught fourth grade" and "never been a team lead" | High. You stated both gaps (F2, F9), and the relationship prior for a principal is Case plus Skeptic | Rehearse A1 until boring. State each gap in your own words, then the quoted sentence at its scope, then a plan |
| Peer Evaluator (bank B, 4) | Teammates ask about seams, disagreement, credit, what you would need | High. Two of the three panelists are fourth-grade teammates, and the peer prior is Peer Evaluator plus Prober | Reciprocity: what you would bring and what you would need. Offer principles for disagreement, not a claimed history |
| Case / Strategist (bank C, 3) | Live classroom problems: a struggling reader, routines, a curriculum change | Medium. The hiring page names reading instruction and classroom routines as panel topics | Clarify, then objective, then approach, then how you would check, then how families hear about it. Think aloud |
| Values / Behavioral (bank D, 3) | Families, reading plans, assessment, themed on the three district beliefs | Medium. The hiring page names families; the beliefs page says the beliefs guide every hire. No source documents a values round, so it is not guaranteed | Pick a real instance if one comes to mind; if none does, say so plainly and answer as a plan |
| Conversational (bank E, 3) | The opening "walk us through your journey", license confirmation, the reading club | Medium. A single 45-minute panel has to open with the biography | A 90-second arc built only from your four quoted sentences |
| Data-Driven Prober (bank G, 2) | Follow-ups on "led the move" and the weekly email | Low to medium. Your CV has no figures to defend, so probes aim at the claims it does have | Say what each sentence says, name where your part ended, and say plainly when you do not know |
| Pressure (bank H, 2) | A time-boxed "why you" and a challenge that sets two of your sentences against each other | Low. Nothing in the loop sources suggests stress interviewing; it is insurance | Pause, restate, hold the quoted position through two follow-ups, concede the stated gap specifically |

## Question banks

### Bank A: Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "I see six years in third grade and no fourth grade. How do you see that?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet" | The highest-ROI rehearsal in this pack. Say the fact plainly: "I haven't taught fourth grade." Then the six years at their own scope. Do not explain why third grade prepares you; leave that inference to the panel. Then a plan, said as a plan: the two or three things you would ask the fourth-grade teachers first. Name only things you genuinely do not yet know; if none comes to mind, say so plainly and say how you would find out. Three sentences, no apology | F2 is the stated gap, and two of the three panelists teach the grade. JD because it scores the posting's own grade requirement |
| A2 | "You haven't been a team lead. How would you fit in with a fourth-grade team?" | EXP | [grounded] "I've never been a team lead"; "I led our grade level's move to a new reading curriculum in 2024" | Say it in your own words: "I haven't been a team lead." Then the one sentence you have, at its scope: "I led our grade level's move to a new reading curriculum in 2024." Keep "led" attached to the move, as in your sentence. The fit answer is a method: what you would ask the team about how they work, and what you would want from them. If a follow-up reaches past the sentence, answer from your own experience and say plainly where your part ended | F9 pairs the move with the stated absence, so the probe is natural. EXP because it tests what was actually yours |
| A3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade"; "I've never been a team lead" | Choose the weakness that is truest for you. Your own material has already named two, and one of them may be it, or it may be something else. Pair it with one concrete first-month step. Do not pick a strength in disguise; if nothing comes to mind, say so plainly and name the part you would most want to learn from the team | F2 and F9 are the likeliest answers, and an unrehearsed one comes out defensive. JD because the Skeptic stem scores self-assessment against the role |
| A4 | "Why Orrinsford, why Halvering, and why now?" | CO | [grounded] "I've run the after-school reading club for the last two years"; "I write a weekly email to families" | Your reason is yours; this pack does not supply a motive. Name the belief on the district's page you can speak to from your own work, and say that sentence as a fact: "I've run the after-school reading club for the last two years" sits near reading, "I write a weekly email to families" near families. Let the panel draw the link. You may mention that the district's news item says a new grades 3–5 reading curriculum is coming from fall 2027, but only if you have read it yourself. If no strong reason comes to mind, say so plainly and name the part of the district's work you have actually looked at | The beliefs page and the literacy-plan item (Sources) are the current strategy this question tests. CO because it scores homework |
| A5 | "How do you teach reading day to day?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years" | Story-map only what the two sentences state: a 2024 move to a new reading curriculum at your grade level, and a club run after school for two years. Answer slot: the hiring page names reading instruction, so expect a probe on the daily lesson. If you can describe how reading is taught in your room, do so in your own words and only as far as you would stand behind it under a second question; if the move or the club did not reach the daily lesson, or reading was taught by someone else, say so plainly and return to the move and the club | The principal's reading background (Reading the interviewer) and F3 make this the likeliest deep dive. JD because reading instruction is a named panel topic |

### Bank B: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "When two of us on a team disagree about how to teach something, what happens?" | CASE | [generic] | Principles, not a past: raise it directly and early, bring student work or the school's expectations to the table, accept the team's decision, and bring the principal in only when needed. Use a real disagreement only if one is truly yours; if none comes to mind, say so plainly and answer as principles | The peer persona probes the seam; F9's team requirement raises it. CASE because it is a live collegial problem |
| B2 | "How much of the 2024 move to a new reading curriculum was you, and how much was the grade level?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | A credit-sharing probe. Start from your sentence: it says "our grade level's move" and "led", and both are your words. Name your part in your own words, only as far as you can repeat it under a second question, and say where your part ended. Stay inside the sentence | F9's evidence is the one sentence about team work. EXP because it scores attribution |
| B3 | "What would you need from us in your first month, and what could you bring?" | CASE | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Reciprocity. Needs: the things A1's plan names. Bring: that sentence at its scope. The district's news item says a new grades 3–5 reading curriculum is coming from fall 2027; mention it only if you have read it, and do not say it is the curriculum you worked with | F9 and the strategy row make a transition-experienced teammate the natural bring. CASE because it is a live collaboration problem |
| B4 | "A family asks why your classroom works differently from the one next door. What do you say?" | CASE | [generic] | Principles: explain the purpose of your approach, point to the expectations you share, and take real differences to the team rather than around it. No claim about your past is needed. If a real instance comes to mind, tell it in your own words | Combines F5 and the seam. CASE because it asks for a live response |

### Bank C: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A student in your class is two grade levels behind in reading in October. What do you do first?" | CASE | [generic] | Structure it: what you would ask first (what data exists, what has been tried, what the family knows), the objective, your approach, how you would check it is working, and how the family hears about it. A child you actually taught may be mentioned in your own words; if none comes to mind, answer as a plan | The reading belief and F3 and F7 point here. CASE because it is a live problem |
| C2 | "It is the second week of school and transitions are loud. Walk us through the routine you would set up." | CASE | [generic] | Think aloud: the goal of the routine, how you would teach it, how you would practice it, and how you would adjust. Answer slot: classroom routines are a named panel topic. If a routine you ran in your own room fits, say what it was and what it did; if none comes to mind, build one from first principles | F4 has no evidence, so this is a free miss if unrehearsed. CASE because it is a live setup problem |
| C3 | "The district is bringing in a new reading curriculum for grades 3–5 in fall 2027. How would you help a team through that?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Structure: what you would want to learn first, what the team needs in the first weeks, how you would find out what is working, and how you would share what you notice. Tie back only with your sentence at its scope; do not say what the new curriculum is | The literacy-plan item is the current strategy (Sources). CO and CASE because it asks for reasoning at the district's altitude |

### Bank D: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell us how you work with families." | VAL | [grounded] "I write a weekly email to families" | Story-map the sentence: weekly, an email, to families. Answer slot: the district's belief asks for more than a message, so expect a probe on what the email does. Say what it holds and what comes back to you, in your own words; if nothing comes back, or you did not track it, say so plainly and stay with the email | F5 and F6; Families Are Partners is the second belief on the district's page. VAL because it maps to a published belief |
| D2 | "Tell us about a time a child was not reading as well as you hoped. What happened?" | VAL | [grounded] | Selection scaffold: choose a real child and moment with a named stake, what you tried, and what followed, told in your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F7; Every Child a Reader is the first belief on the district's page. VAL because it asks for a specific past |
| D3 | "Tell us about a time assessment results changed what you taught." | VAL | [grounded] | Selection scaffold: choose a real instance where a result changed the plan, say what you saw, what you changed, and what you checked afterward. If none comes to mind, say so plainly and say how you would want to use results | F8 and F10; Teach for Tomorrow, Not for the Test is the third belief. VAL because it scores a published belief |

### Bank E: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk us through the journey." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families" | A 90-second arc from your four sentences, in this order if it suits you: the six years, the 2024 move, the club, the email. Close on why this role, in your own reason. If no strong one comes to mind, say so plainly and name the panel topic you most want to talk about: reading, routines or families | A 45-minute panel will open here, and casual questions are still scored. EXP because it is the CV, spoken |
| E2 | "Just to confirm: you hold the Illinois license with the elementary endorsement?" | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | Answer in the quote's own terms: the Illinois Professional Educator License, the Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029. Nothing needs adding | F1 is the posted requirement. JD because it is the stated gate |
| E3 | "Tell us about the after-school reading club." | EXP | [grounded] "I've run the after-school reading club for the last two years" | Story-map the sentence: after school, a reading club, two years, run by you. Answer slot: the hiring page names reading instruction, so expect a probe on whether the club's work shows up in classroom reading. If it does, say how in your own words; if it does not, say so plainly and stay with the club | F3. EXP because it is one of the two reading sentences, and the principal's reading background makes it a likely follow-up |

### Bank G: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "How did your grade level decide whether the new reading curriculum was working?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Start from the sentence. Answer slot, raised by the district's belief about assessment: if there was a way your grade level looked at whether the curriculum was working, say what it was and what was yours; if no such check was made, or it was not yours, say so plainly and return to the move | F8 and F9 meet here. EXP because it tests the claim past the headline |
| G2 | "What happens after your weekly email goes home?" | EXP | [grounded] "I write a weekly email to families" | Say what you know. Answer slot: if replies come, say what kind and what you did with them; if nothing came back, or you did not track it, say so plainly and stay with the email | F5 and F6. EXP because it checks what sits behind a CV line |

### Bank H: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Sixty seconds: why you over a candidate who has already taught fourth grade?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet" | Pause and restate the question first. Hold the position your quote carries: "Six years teaching third grade at a public elementary school in Joliet." Concede specifically: "I haven't taught fourth grade." Hold through two follow-ups by returning to the sentence, never by adding to it. Do not run down the other candidate | F2 again, in a time-boxed register. JD because the hold-then-concede structure is the type's bar |
| H2 | "You say you led the move to a new reading curriculum, but you have never been a team lead. Which is it?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead" | Both are true, so say both in your own words and let them sit side by side: "I led our grade level's move to a new reading curriculum in 2024" and "I haven't been a team lead." Hold through two follow-ups by returning to the first sentence and its scope; concede the second plainly. A longer defense of "led" is the part that breaks | F9 holds the two sentences, and this is the question where they meet. EXP because it scores attribution under pressure |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 license gate | E2 |
| F2 fourth grade | A1, A3, H1 |
| F3 reading instruction | A5, C1, E3 |
| F4 classroom routines | C2 |
| F5 how you work with families | D1, G2 |
| F6 speaks with every family each term | D1, G2 |
| F7 reading plan, grade 3 | C1, D2 |
| F8 assessments inform teaching | D3, G1 |
| F9 grade-level team | A2, B1, B2, B3, H2 |
| F10 differentiate using assessment data | D3 |
| "plan and teach reading, writing, math, science and social studies" (listing snippet only) | none, and why: it appears only in a search-result snippet of a general board listing, not in the district's own words. The posting would earn it a question |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | To the principal: "Your talk Small Groups, Big Readers covered weekly reading conferences in grades 3 to 5. What does that look like in a fourth-grade room at Halvering?" | It ties to the principal's public path and shows reading-first curiosity. Look the talk up yourself first and ask only what you have seen |
| 2 | To the fourth-grade team: "What do first-year fourth-grade teachers here most often wish they had known in September?" | It acknowledges the gap you have named without apology and turns A1's plan into a conversation |
| 3 | To the teammates: "What could a new teammate do in the first month that would genuinely help your team?" | The reciprocity question for the peer panelists |
| 4 | "The district's belief says each teacher speaks with every family each term. How do teachers at Halvering do that in practice?" | It shows you read the beliefs and takes the families topic seriously |
| 5 | "The district's news item mentions a new grades 3–5 reading curriculum from fall 2027. Where would a new fourth-grade teacher fit in preparing for it?" | It signals current homework and points at the strategy the panel cares about |
| 6 | "What does a good first year look like for this role?" | A standard, useful close that lets the panel describe their own bar |
| 7 | "The hiring page says references follow the panel. What is the timeline from here?" | Practical, and it shows you read their process |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade, or knows the grade from the inside | Negative you stated, F2 | The plain acknowledgment: "I haven't taught fourth grade." With "Six years teaching third grade at a public elementary school in Joliet" at its own scope. No slot |
| Has been a team lead, or led the grade-level team | Negative you stated, F9 | The plain acknowledgment: "I haven't been a team lead." With "I led our grade level's move to a new reading curriculum in 2024" at its own scope. No slot |
| Chose, designed or wrote the new reading curriculum | Inflated form of F3 and F9 | The sentence "I led our grade level's move to a new reading curriculum in 2024" at its own scope. The limit is the pack's observation: your material says the move, not the curriculum's selection or design |
| Spoke with every family each term | Inflated form of F5 and F6 | The sentence "I write a weekly email to families" at its own scope. The limit is the pack's observation: your material says the email, not conversations |

## Sources

**Provided documents:** the invite text from Orrinsford Community School District Human Resources, and your CV text. A Social Security number in the CV text was not used and is not needed.

**Searches sent (5):**

- "Orrinsford Community School District mission values" returned https://orrinsfordschools.example/about/mission-and-beliefs
- "Orrinsford Community School District interview process teacher hiring" returned https://orrinsfordschools.example/careers/how-we-hire-teachers
- "Orrinsford Community School District strategic plan news" returned https://orrinsfordschools.example/news/board-adopts-literacy-plan
- "Dolores Vantongeren principal Halvering Elementary School" returned https://ilprincipalsforum.example/speakers/dolores-vantongeren
- "fourth grade teacher job description Illinois elementary school district" returned https://k12jobsboard.example/listings/fourth-grade-teacher

**Fetches sent (2):** the mission-and-beliefs page and the how-we-hire-teachers page above. Each returned the same text the search snippet showed.

**Facts used and where they sit:** the three beliefs and their one-line meanings, from the beliefs page. The loop (one 45-minute building panel: the principal and two grade-level teachers; topics reading instruction, classroom routines and how you work with families; references after the panel), from the hiring page, which establishes the loop. The August 2026 literacy plan (grades 3–5 reading curriculum from fall 2027; a family reading night each term), from the news item, a search result not opened. The principal's role, tenure and 2025 talk, from the speaker page, a search result not opened. The listing text in F9 and F10, from the K12 Jobs Board result, not opened, representative of the role and not this district's own posting.

**Values cheat sheet:** omitted. The hiring page documents no values or competency round, so none is detected. The beliefs are themed in bank D instead.

**Dossier:** none present.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | yes | The three beliefs by name; bank D themes; A4 and reverse question 4 |
| 2. `{company} interview process {role family}` | yes | One 45-minute panel, who sits on it and its topics; persona weights and banks B, C, D |
| 3. `{company} strategy` / recent news | yes | The August 2026 literacy plan; C3, B3, A4 and reverse question 5. The result was a snippet only |
| 4. `{interviewer name} {company}` | yes | The principal's role, tenure and talk; Reading the interviewer, A5 and reverse question 1 |
| 5. representative `{role title}` JD | yes | F9 and F10 and their `[inferred]` labels; no question rests on it alone |

## Upgrade menu

- The actual job posting → F9 and F10 become quoted from the district's own words, and the subject-breadth requirement earns a question.
- Anything HR said beyond the invite (a sample lesson, items to bring, focus areas) → a build section for any declared deliverable.
- The names of the two fourth-grade teachers → a per-member persona read and a reverse question tied to each.
- A printout or screenshot of your license record → F1 confidence rises from medium to high.
- Your own answers to the slots in F3, F4, F6, F7, F8 and F10 → each quoted into the snapshot, and the guidance rewritten as a story map from your words.
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → the principal's talks and writing in depth, recent organization context, and a grounding brief on the district's literacy plan. Offered once; say the word to run it.
- A tuesday-dossier.md, if you have one from earlier work → verified evidence and prohibited claims in place of this pack's local list, and the most likely objection taken from it.
