Reading the last few reference files (evidence conventions, research checklist, reframing audit), then I'll run the school research and write your pack.
Your prep pack is saved as `halvering-elementary_fourth-grade-teacher_interview_pack.md`. I built it for the 45-minute panel in your invite: the principal as the hiring-manager seat and two fourth-grade teachers as peers. I had no job posting, so the requirements come from your invite and the district's own pages. Those pages describe a single building panel on reading instruction, classroom routines and families, and list three published beliefs.

- **Biggest gap:** A1 is the question I'd rehearse most: "You haven't taught fourth grade. What will be hardest for you in the first month?" The pack gives you a plain statement of the gap, then holds only what your résumé says through two follow-ups.
- **Gaps in your material:** The district's beliefs raise several questions your material doesn't show an answer for: reading plans, speaking with families each term, routines and assessment. The pack leaves each of those as a slot where you answer from your own experience, or say plainly that it wasn't yours.
- **Team lead:** I kept "I've never been a team lead" alongside "I led our grade level's move to a new reading curriculum." The pack tells you to say both as written. It doesn't coach any claim of being a team lead.
- **Your Social Security number:** I didn't use it, and the pack doesn't contain it. You don't need it for interview prep, and it shouldn't be on a résumé you send to an employer. I'd remove it. Your license ID is also left out of the pack.

Say the word and I'll play the skeptical principal on A1, with live follow-ups and feedback against the pack's guidance.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Do you have the full text of the job posting? The research found only a truncated sample posting, and the real one would replace several rows that currently rest on the district's pages.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: halvering-elementary_fourth-grade-teacher_interview_pack.md -----
# Interview pack: Fourth Grade Teacher, Halvering Elementary School

Candidate: Grace. Employer: Orrinsford Community School District. Round: one 45-minute panel on Thursday with Principal Dolores Vantongeren and two members of the fourth-grade team (relationship: the principal is the hiring-manager seat; the two teachers are peers). The loop is one session: the invitation and the district's "How we hire teachers" page both describe a single 45-minute building panel, so the persona weights rest on that, not on an archetype.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it is really testing |
|---|---|
| VAL | Whether past behavior shows the district's published beliefs, not generic virtue |
| EXP | Whether your CV's claims survive scrutiny, and what was actually yours |
| JD | Whether you can do the job as posted, gaps included |
| CO | Whether you know the district's current direction |
| CASE | Structure and reasoning on a live problem from the role |

Answer slots are instructions for the interview, not questions for you now. Where one applies, answer whichever branch is true. The honest second branch ("it was not mine", "there was no such step") is a limit, not a confession.

The single highest-ROI rehearsal in this pack is A1, the fourth-grade question. It will be asked in some form.

## Fit snapshot

No job posting was supplied, so the requirements come from the invitation, the district's own pages, and nothing else. The one search for a representative fourth-grade posting returned a truncated snippet and no row rests on it (see Sources).

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — your invitation | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | Gate shown met by your CV, so no gap. A CV line has nothing inspected behind it here, so expect it to be confirmed. Say it in the quote's own terms, in full. Your CV also carries a license ID; this pack leaves it out because nothing here needs it |
| F2 | "Panels ask about reading instruction" — Orrinsford, How we hire teachers | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | presentation | Both quotes already reach reading, in other terms than a classroom answer. Reword nothing beyond them: in 2024 you led your grade level's move to a new reading curriculum, and for the last two years you have run the after-school reading club. Nothing is inspected behind either, so expect a probe on each |
| F3 | "no student leaves third grade without a reading plan" — Orrinsford, Mission and Beliefs (Every Child a Reader) | "Six years teaching third grade at a public elementary school in Joliet" — your CV | low | [grounded] | discovery | Your material gives the six years in third grade and does not show whether reading plans were part of them. Answer slot: the belief makes a probe on reading plans likely. If students in your room had reading plans, say how they worked and what part was yours, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the six years in third grade |
| F4 | "how you work with families" — Orrinsford, How we hire teachers | "I write a weekly email to families" — your CV | medium | [grounded] | presentation | The quote already reaches the requirement in other terms. Say it as written, "I write a weekly email to families", and add nothing about what the email contains or what families do with it |
| F5 | "each teacher speaks with every family each term" — Orrinsford, Mission and Beliefs (Families Are Partners) | "I write a weekly email to families" — your CV | low | [grounded] | discovery | The belief is about speaking with families, and your material shows an email, with nothing about conversations. Answer slot: if you speak with families outside the email, say when and how, in your own words; if the email is the whole of it, say so plainly and stay with the weekly email |
| F6 | "classroom routines" — Orrinsford, How we hire teachers | "Six years teaching third grade at a public elementary school in Joliet" — your CV | low | [grounded] | discovery | Six years in a classroom touches routines without showing which were yours. Answer slot: if you set routines, say which and why, in your own words; if the school set them, or you did not, say so plainly and stay with the six years in third grade |
| F7 | "assessments inform teaching and never replace it" — Orrinsford, Mission and Beliefs (Teach for Tomorrow, Not for the Test) | none given | none | [grounded] | discovery | Your material says nothing about assessment. Answer slot: the belief makes a probe likely. If you have used assessment results to change what you taught, say one instance, in your own words; if you have not, or it was not yours to decide, say so plainly |
| F8 | "Fourth Grade Teacher" — your invitation | "I've never taught fourth grade" — your message; "Six years teaching third grade at a public elementary school in Joliet" — your CV | none | [grounded] | capability | A gap that wording cannot close, and you have said so. Words: "I've never taught fourth grade." Beside it, the six years at its own scope. Then how you would learn the fourth-grade year, said as a plan and never as a past, in your own words. Never a claim to fourth-grade teaching, and nothing added to make the gap feel smaller |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | Negative you stated, F8 | "I've never taught fourth grade." No slot |
| Has been a team lead | Negative you stated: "I've never been a team lead" — your message | "I've never been a team lead", beside "I led our grade level's move to a new reading curriculum in 2024" — your CV. No slot |
| Chose or wrote the new reading curriculum | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: your material says you led the grade level's move, not what that involved |
| Ran a reading intervention program | Inflated form of F2 | F2's reading-club quote at its own scope. Your material says an after-school reading club, for two years |
| Speaks with or meets every family each term | Inflated form of F4 and F5 | "I write a weekly email to families". The limit is the pack's observation: your material shows an email, not conversations |

## Persona table

Weights below are shown so you can recalibrate if you know something I don't.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic (5 questions) | The principal weighing the fourth-grade gap and the "why now" | High. F8 is a stated absence, and the principal's seat is the one that buys capability and derisks gaps | Rehearse A1 until it is boring: state the gap in your own words, hold the quoted material through two follow-ups, concede specifically, never add to what the quotes carry |
| B. Peer Evaluator (3) | The two fourth-grade teachers asking what you bring to their team and what you would need | High. Two of three panelists are teammates-to-be, and peers price what a hire costs and contributes | Reciprocity: what you bring, only as the quotes state it; and ask how the team plans rather than guessing at it |
| C. Case / Strategist (3) | Live problems from reading instruction and classroom set-up | Medium. The district says panels ask about reading instruction and routines; the principal's public talk is about reading conferences | Clarify, then objective, then approach, then how you would tell it worked, thinking aloud |
| D. Values / Behavioral (3) | Prompts keyed to the district's three published beliefs | Medium. The district says three beliefs guide every hire, but no separate values round is documented, so it is not guaranteed | One selected story per belief, or the honest branch where none comes to mind |
| E. Conversational (3) | Opening journey question and casual questions about reading and routines | Medium. A panel opens warmly, and casual questions on the district's stated topics are still scored | A 90-second arc built only from your own sentences |
| F. Data-Driven Prober (2) | Following up on how you knew the curriculum move worked | Low. Your CV carries no figures to defend, so probing would land on F2 | Say plainly what you did and did not look at |
| G. Pressure (2) | Time-boxed "why you" and "how much was you" | Low. Nothing in the sources documents it; included so you do not meet the style first live | Hold, then concede specifically, never fold on the core claim |

## Reading the interviewer

Public professional footprint only. Only the principal is named; the two teachers are not.

| Observation | Source | What it suggests | Provenance |
|---|---|---|---|
| Principal of Halvering Elementary since 2022, after nine years as a reading specialist | Illinois principals forum speaker page | Expect reading depth, not reading as one topic among many | [grounded] |
| 2025 forum talk "Small Groups, Big Readers" on weekly reading conferences in grades 3 to 5 | Same page | Small-group reading structure is a likely theme (C2), and her range covers the grade you teach now and the grade you are applying to | [grounded] |
| Shared vocabulary: reading | Pairs her path with F2's quote: "I've run the after-school reading club for the last two years" | A natural place to talk in her terms, using only that sentence as your side | [grounded] |

The two fourth-grade teachers' names, if you get them, would let this section cover them too.

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't taught fourth grade. What will be hardest for you in the first month?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet" | The highest-ROI rehearsal in this pack. Open with the plain statement: "I've never taught fourth grade. I have six years teaching third grade at a public elementary school in Joliet." Follow-up one, what will be hardest: answer from what you actually know about the fourth-grade year; if you do not yet know what changes from third to fourth, say so plainly and say what you would ask the fourth-grade team first. Follow-up two, how can you be sure: do not argue it. Concede specifically that you cannot yet point to fourth-grade results, and return to the six years. Never fold on the third-grade years, and never add to them | F8 is the pack's biggest gap and this arrives in some form; JD because it scores the role as posted |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" | Selection scaffold: name the one you would actually pick, with one sentence on why it is your weakest and one first step. Your material names one candidate, and if that is your answer, say it in those words. If nothing else comes to mind, say so plainly, then name the nearest thing or how you would find out | Standard Skeptic stem aimed at F8; JD because it scores honest self-assessment against the role |
| A3 | "You led your grade level's move to a new reading curriculum in 2024. Tell us about that." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead" | Story-mapped on F2, and the beats are the sentence's: 2024, a new reading curriculum, your grade level's move, you leading it. Tell them in your own words and stop where the sentence stops. If asked whether you were the team lead, the plain answer is yours: "I've never been a team lead." Then return to the sentence | F2 is the strongest evidence for reading instruction and the likeliest place for a probe on what "led" meant; EXP because it tests attribution |
| A4 | "Why leave third grade for fourth, and why here, and why now?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | Selection scaffold: one sentence each for why fourth, why this district, why now. Nothing in your material states your reasons, so the pack writes none. For "why here", you may tie to the district's published beliefs (Every Child a Reader, Families Are Partners, Teach for Tomorrow, Not for the Test) only if one is true for you. If no reason comes to mind for one of the three, say so plainly rather than reaching for a slogan | The Skeptic's motivation probe; JD because it scores consistency of story |
| A5 | "Can you confirm your licensure: which license, which endorsement, how long it's valid?" | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | Say it in the CV's own terms, in full, and stop. Say nothing beyond what the license shows | F1 is the invitation's gate; short and certain, so rehearse it once and move on |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our fourth-grade team plans together. What would you bring to that, and what would you need from us?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I've never taught fourth grade" | Reciprocity. What you bring, only as the quotes state it, said as written. What you need: say "I've never taught fourth grade", and that you want to learn how the team plans rather than guess at it | Peers price what a hire costs and contributes; F2 supplies what you can offer, F8 what you will ask for |
| B2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Selection scaffold: pick a time work was shared with colleagues; it needs what was whose in one sentence, "we" for context and "I" for contribution, and a clean ending. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Peer stem on credit; EXP because it tests attribution habits |
| B3 | "Say you and one of us disagree about how to teach a reading unit. What happens?" | CASE | [generic] | Structure it: hear their reasoning first, name what you agree on, bring it back to what the students need, and say how you would settle it. The question needs no claim about your past, so the guidance makes none | Peer seam-splitting; CASE because it is a live problem |

### C. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A fourth grader reads well below grade level and the family is worried. What do you do in the first two weeks?" | CASE | [grounded] | Clarify first (what the child reads, what has been tried, what the family sees), then objective, then approach, then how you would tell it worked, then risks. Include what you would tell the family and when. The district's belief "Every Child a Reader" frames this as a plan for the child, so name a plan rather than a one-off fix. The question needs no claim about your past | Live problem from the district's own reading belief and its hiring topics; CASE |
| C2 | "How would you set up small-group reading so every child gets a conference each week?" | CASE | [grounded] | Structure it aloud: how you would form groups, what a short conference holds, what the rest of the class does meanwhile, how you would keep a record, what you would adjust. No claim about your past | The principal's public talk is on weekly reading conferences in grades 3 to 5; whether she asks is unknown, and the pack says so |
| C3 | "The board adopted a literacy plan this year. What do you know about it, and what would it mean for a fourth-grade classroom?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Know three items as the search result states them: structured phonics from kindergarten to second grade, a new grades 3–5 reading curriculum from fall 2027, and a family reading night at every school each term. That is a search-result summary, so read the full plan before Thursday. Then think aloud on what the 3–5 change means for fourth grade, and ask what is known about the rollout instead of guessing. If you mention your own curriculum move, say it as written and let them draw the connection | The one strategy-grounded question; the district's current direction is the differentiator most candidates skip |

### D. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you made sure a child had a plan to grow as a reader." | VAL | [grounded] "I've run the after-school reading club for the last two years" | Story-mapped only as far as the sentence goes: the reading club, two years, after school. If a particular child's growth sits inside that, choose it and tell it in your own words: the stake, what you changed, what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, the club as written, or how you would handle it | Every Child a Reader is the district's first belief; F3 is where your material is thinnest on it |
| D2 | "Tell me about a time a family's view changed what you did." | VAL | [grounded] "I write a weekly email to families" | Selection scaffold: pick a time a family told you something you then acted on; it needs what they said, what you changed, and how the relationship stood afterward. The email, as written, is your nearest material. If no such time comes to mind, say so plainly and describe how you would handle it | Families Are Partners; F4 and F5 are the evidence and the gap |
| D3 | "Tell me about a time an assessment result changed what you taught." | VAL | [grounded] | Selection scaffold: pick a time a result led you to teach something differently; it needs what the result showed, what you changed, and what followed. Your material has no sentence on this, so the pack supplies none. If no such time comes to mind, say so plainly, then say what you would look at first | Teach for Tomorrow, Not for the Test; F7 is empty, so this is the one most likely to find you unprepared |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey. How did you get here?" | EXP | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029"; "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families" | A 90-second arc made of those sentences, each said as written, in that order. Why you became a teacher and why this district are not in your material, so the pack writes neither; say them in your own words, or leave them out | The biography question is always scored; the arc keeps you inside what you can defend |
| E2 | "What are you actually working on in reading these days?" | JD | [grounded] "I've run the after-school reading club for the last two years" | Start from the club as written. If there is something you are trying in it or in class now, name it in your own words; if nothing comes to mind, say so plainly and stay with the club | Casual question on the topic the district says panels ask about; scored all the same |
| E3 | "What does a smooth morning look like in your room?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | Answer slot: the district says panels ask about classroom routines. Describe your own routines in your own words, only ones you actually use; if the school set them, or you did not set them, say so plainly and stay with the six years in third grade | F6 is the row behind this; EXP because it asks what was actually yours |

### F. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "How did your grade level tell whether the new curriculum was working?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Hold to the sentence. Answer slot: the district's assessment belief makes this probe likely. If you or your grade level looked at results to judge the move, say what you looked at and what it showed, in your own words; if there was no such check, or it was not yours, say so plainly and return to the move you led | F2 carries no figure, so the probe goes to how the move was judged; EXP because it tests what was actually yours |
| F2 | "How would you tell whether a reading group is working?" | CASE | [grounded] | Structure it: what you would look at, how often, what would make you change the group, and how you would explain it to a family. No claim about your past | Teach for Tomorrow, Not for the Test; asked as a live problem so it needs no history |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over a teacher who has already taught fourth grade?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years" | Concede first and specifically: "I've never taught fourth grade." Then hold on the three sentences as written and stop. Do not claim you would be better; the comparison is theirs to draw. Hold through two follow-ups by returning to the sentences, never by adding to them | F8 under time pressure; JD because it scores the posted role |
| G2 | "That curriculum move: how much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead" | Hold the sentence at its own scope through two follow-ups. The concession that is true and already yours: "I've never been a team lead." If a part of the move was not yours, say which part, in your own words; if you cannot separate it, say so plainly. Never widen the sentence to cover what it does not say | Attribution probe on F2; EXP |

### Requirement coverage

| Requirement | Question IDs |
|---|---|
| F1 licence gate | A5 |
| F2 reading instruction | A3, C1, C2, E2, F1 |
| F3 reading plans (Every Child a Reader) | D1, C1 |
| F4 and F5 working with families | D2 |
| F6 classroom routines | E3 |
| F7 assessments inform teaching | D3, F1, F2 |
| F8 fourth grade | A1, A2, A4, G1 |
| Working with the fourth-grade team (not a row; the panel's teachers) | B1, B2, B3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | To the principal: "You spent nine years as a reading specialist before becoming principal. How does that shape what you look for in a fourth-grade reading block?" | Ties to her public path, signals you read her work, and turns the interview into a conversation about reading |
| R2 | To the teachers: "What could a new fourth-grade teacher do in the first month that would genuinely help your team?" | Reciprocity; shows you are thinking about their load, not only your own |
| R3 | "The new grades 3–5 reading curriculum starts in fall 2027. What does this year look like for fourth grade as that gets ready?" | Shows you read the plan, and asks about what you cannot know from outside |
| R4 | "Families Are Partners says each teacher speaks with every family each term. What does that look like in practice here?" | Shows you know the belief by name and asks for the practice |
| R5 | "How does the fourth-grade team plan together, and how much room is there to adjust?" | Speaks to your fourth-grade gap by asking how to learn the year from the team |
| R6 | "What would make you say, at the end of the first semester, that this hire is going well?" | Lets the panel name its own bar |

## Sources

Provided documents: the interview invitation; your CV and message.

Searches and fetches sent:

- Search: "Orrinsford Community School District values mission" → https://orrinsfordschools.example/about/mission-and-beliefs
- Search: "Halvering Elementary School Orrinsford fourth grade teacher interview" → https://orrinsfordschools.example/careers/how-we-hire-teachers
- Search: "Dolores Vantongeren principal Halvering Elementary" → https://ilprincipalsforum.example/speakers/dolores-vantongeren
- Search: "Orrinsford Community School District strategic plan news" → https://orrinsfordschools.example/news/board-adopts-literacy-plan
- Search: "fourth grade teacher job posting Illinois elementary responsibilities qualifications" → https://k12jobsboard.example/listings/fourth-grade-teacher
- Fetch: https://orrinsfordschools.example/about/mission-and-beliefs
- Fetch: https://orrinsfordschools.example/careers/how-we-hire-teachers

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. District values | yes | The three beliefs by name; they raise the VAL questions and F3, F5, F7. No values round is documented, so there is no values cheat sheet |
| 2. Interview process | yes | One 45-minute building panel with the principal and two grade-level teachers; topics are reading instruction, classroom routines and families; persona weights follow |
| 3. Strategy and recent news | yes | The board's literacy plan feeds C3 and R3. Only the search snippet was read, not the full page |
| 4. Interviewer | yes | The principal's public profile feeds the interviewer read, C2 and R1; the two teachers are unnamed, so there is nothing to search for them |
| 5. Representative posting | yes | Returned a truncated snippet that was not fetched; no fit row or question rests on it, so the real posting is the upgrade |

## Upgrade menu

- The actual job posting → the requirement rows now drawn from the district's pages become the posting's own words, JD-tagged questions are added, and the posting's subject and team requirements get rows
- The names of the two panelists → an interviewer read for each, and persona assignments per person
- Your answers to the slots on F3, F5, F6 and F7 → those rows are regenerated from your own quoted words
- How much prep time you have before Thursday → a prioritized prep schedule
- Any recruiter or HR notes on focus areas → coverage for anything pre-declared
- The licence record itself, as issued → F1 moves from medium to high
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → the full literacy plan, the principal's talks, and recent district context, which would sharpen C2, C3 and R3
- A tuesday-dossier.md from job-underwriter → verified evidence and prohibited claims in place of this pack's local list
