# Interview pack: Fourth Grade Teacher, Halvering Elementary School

Orrinsford Community School District. One 45-minute panel on Thursday: Principal Dolores Vantongeren and two members of the fourth-grade team (names not given). Built on the assumption that the two teachers are peers and that no job posting was supplied, so JD-style rows rest on a typical posting and are labeled `[inferred]`.

## How to use this pack

Personas describe how a question is asked. Types describe what it is scoring. Every question carries one of each, plus where its guidance comes from.

| Type | What it is scoring |
|---|---|
| VAL | Whether your past behavior shows the district's published beliefs |
| EXP | Whether the claims on your CV hold up, and which part was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the district and its current plans |
| CASE | How you think through a live classroom problem |

- Guidance is scaffolding, not a script. Say it in your own words and keep it to what you did.
- An answer slot is an instruction for the interview, not a question for this conversation. It has two branches: say what you did, or say plainly that there was no such step or it was not yours, then return to a sentence you can stand behind.
- Provenance labels: `[grounded]` traces to your documents, the invitation or a cited page. `[inferred]` is derived from a typical posting or an adjacent fact. `[generic]` is a pattern with no claim about you or this district.
- Question bank letters skip F, so that bank IDs never collide with the fit rows F1 to F8.
- The most likely objection, and the pack's highest-ROI prep, is A1: you have not taught fourth grade.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — the invitation | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | Your CV states the requirement in its own terms; say it as written, dates included. The pack's observation: the endorsement range in your quote includes grade four. It is a CV line with nothing inspected behind it, so expect a confirmation request. No answer slot |
| F2 | "Fourth Grade Teacher position at Halvering Elementary School" — the invitation | "Six years teaching third grade at a public elementary school in Joliet." — your CV; "I've never taught fourth grade" — your CV | medium | [grounded] | transferability | Words: "I've never taught fourth grade." Then the adjacent work at its own scope: "Six years teaching third grade at a public elementary school in Joliet." Answer slot: if asked what would be new, say in your own words what you would find out first and from whom, as a plan and never as a past; if you are not sure what differs, say so plainly and say how you would learn. Nothing is added to make the gap look smaller |
| F3 | "Every Child a Reader: no student leaves third grade without a reading plan." — district Mission and Beliefs page | "Six years teaching third grade at a public elementary school in Joliet." — your CV; "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years." — your CV | medium | [grounded] | discovery | Your quotes touch reading and do not show whether individual students had reading plans. Answer slot: the belief names third grade, the grade your CV says you taught, so expect a probe. If your students had reading plans, say how they were made and which part was yours; if there were none, or they were not yours, say so plainly and stay with the club and the curriculum move as the quotes state them |
| F4 | "Families Are Partners: each teacher speaks with every family each term." — district Mission and Beliefs page | "I write a weekly email to families." — your CV | medium | [grounded] | transferability | Words at the quote's scope: "I write a weekly email to families." The belief names speaking with each family; your quote names the email and says nothing about conversations. Answer slot: if you also spoke with families directly, say how often and in what setting, in your own words; if the email was the main channel or there was no direct contact, say so plainly and stay with the email |
| F5 | "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it." — district Mission and Beliefs page | none given | none | [grounded] | discovery | Your material does not show how you used assessment results. Answer slot: the belief makes a probe on assessments likely. If a result changed what you taught, say what it showed and what you changed, in your own words; if none did, or the choice was not yours, say so plainly and say how you would use a result |
| F6 | Works with the grade-level team: typical for the role per a K12 Jobs Board listing, not this school's posting | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your CV | medium | [inferred] | presentation | Say the sentence as written: "I led our grade level's move to a new reading curriculum in 2024." Reword nothing beyond it. Because "I've never been a team lead" sits beside it, expect a probe on the difference. Answer slot: say which parts of the move were yours and which were others', in your own words; if the question is about a title, say plainly "I've never been a team lead." |
| F7 | Keeps clear classroom routines: typical for the role per the K12 Jobs Board listing, and a named panel topic on the district hiring page | none given | none | [inferred] | discovery | Strong evidence would be one routine, what it was for, and how students learned it. Selection scaffold: pick a routine from your own classroom, name what it addressed and what changed; if none comes to mind, say so plainly, then say how you would set one up |
| F8 | Teaches reading, writing, math, science and social studies: typical for the role per the K12 Jobs Board listing | none given | none | [inferred] | discovery | Your material says third grade, not which subjects. Selection scaffold: name the subjects you taught, in your own words; if one was taught by someone else, say so plainly, then say which you would want most support with and how you would ramp |

## Reading the interviewer

| Public fact about Principal Vantongeren | Source | What it means for you |
|---|---|---|
| Principal of Halvering Elementary School since 2022, after nine years as a reading specialist | Illinois principals forum speaker page, fetched | Reading questions may come from someone who has worked in reading as a specialty. Answer from what you did, at its scope, and use only terms you would use yourself (B1, B2, D1, G1) |
| 2025 forum talk, Small Groups, Big Readers, covering weekly reading conferences in grades 3 to 5 | Same page | Small-group reading may come up. Your material says nothing about small groups or conferences, so if asked, answer from your classroom or say plainly it is not something you have done. The talk's grade band includes the grade you taught (F2) and the one you are applying for |
| The two fourth-grade teachers are not named | The invitation | Treated as peers. No footprint researched; their names would let the pack read each of them |

| Mirror opportunity | Her public side | Your side, quoted from F3's evidence |
|---|---|---|
| Shared subject: reading | Nine years as a reading specialist; a talk on reading in grades 3 to 5 | "I've run the after-school reading club for the last two years." Offer it as a topic to talk about, never as a claim of equal expertise |

No shared career jump is offered: no row's evidence carries your side of one. Do not build on shared background of any other kind.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of what is missing: the grade you have not taught, the title you have not held | High, weight 5. A principal-led panel prices gaps, and you stated two yourself (F2, F6) | Rehearse A1 until it is boring: concession first, one adjacent sentence at its scope, then a plan said as a plan |
| Case / Strategist | Live classroom problems: a struggling reader, a first morning, a worried family | High, weight 4. The district hiring page names reading instruction, classroom routines and families as panel topics, and the principal is the hiring manager | Clarify, then objective, approach, check, risks. Think aloud and challenge one premise respectfully |
| Peer Evaluator | The two teachers: how you would work beside them, credit, disagreement | High, weight 4. Two of the three panelists are grade-level teachers, per the hiring page and the invitation | Offer what you bring before what you need; describe shared work as shared, with your part named at its scope |
| Values / Behavioral | Stories tied to the district's three beliefs | Medium, weight 3. The district says the beliefs guide every hire, but its hiring page describes one panel and no separate values round, so none is detected and there is no values cheat sheet | Where a quoted sentence carries a story, use it at its scope; where none does, pick a real instance or say plainly none comes to mind |
| Conversational / Rapport | Opening walk-through, closing "anything else" | Medium, weight 3. Every panel opens and closes casually, and casual questions are still scored | A 90-second arc built only from your own sentences; never answer the closing slot with "I think you've covered everything" |
| Data-Driven Prober | Pushing on how you knew something worked | Low to medium, weight 2. Her background is in reading, but your CV gives no figures to dissect | Say plainly what you looked at and what you did not; name what you trust least about it |
| Pressure | Interruptions, time-boxing | Low. A single building panel in a friendly register is the documented format, so there is no separate bank; the attribution probe sits in A2 | Pause, restate, hold the sentence you can stand behind |

## Question banks

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've taught third grade for six years and you've never taught fourth. Why should we take that step with you?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." "I've never taught fourth grade" | The highest-ROI rehearsal in this pack. Level one: open with the concession in your own words as written, "I've never taught fourth grade," then the one adjacent sentence at its scope, "Six years teaching third grade at a public elementary school in Joliet." Then a plan, not a past. Answer slot: say what you would find out first about fourth grade and who you would ask; if you are not sure what differs, say so plainly and say how you would learn. Level two, "Which part worries you most": name one in your own words, or say you cannot know yet and name whom you would ask. Level three, "Other candidates have taught it": hold, and add nothing. Return to the two sentences, concede that the interviewer is right about the experience, and never add a claim to close the gap | F2 is your stated gap and the first thing the invitation's title raises. JD because it scores the stated role; Skeptic because it is aimed at the gap |
| A2 | "You led your grade level's move to a new reading curriculum, and you've never been a team lead. How should we read that?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" "I've never been a team lead" | Hold the first sentence as written. Concede the second as written. Do not reconcile them by describing the move's size or your authority in it. Answer slot: say which parts of the move were yours and which were others', in your own words; if it was shared, say so plainly. Hold through two follow-ups by repeating the two sentences, and concede specifically any part that was not yours | F6 sets the two statements side by side, so a probe on the seam is likely. EXP because it tests attribution; the hold-then-concede shape is the pressure-style move |
| A3 | "What is drawing you to leave your current school after six years?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." | The reason is yours to say and the pack supplies none. Criteria: forward-looking, specific to this school or this grade, and nothing critical of the school you are leaving. Answer slot: if the honest reason is plain, such as wanting a new grade, say that plainly in your own words; do not decorate it | Motivation consistency is the Skeptic's standing probe (F2). EXP because the story must survive a second question |
| A4 | "Which part of this job would you be weakest at on day one?" | JD | [generic] | The pack's observation: besides fourth grade itself, your material shows nothing on routines (F7), core subjects (F8) or assessment use (F5). Selection scaffold: pick the real one, name it, say why, and say what you would do in your first month. If none comes to mind, say so plainly, then name the nearest thing your sentences do not cover and how you would learn it. A made-up weakness fails the next question | A standard Skeptic stem; the gap rows F5, F7 and F8 are where an honest answer comes from. JD because it scores readiness for the listed duties |
| A5 | "Can you confirm your license and endorsement for us?" | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | A twenty-second answer. Say it as written: the Illinois Professional Educator License, the Elementary Education endorsement for grades 1 to 6, registered and active through June 30, 2029. Nothing needs adding and no slot applies | F1 is the one stated requirement in the invitation; a plain confirmation check belongs in the Skeptic bank. JD because it scores the stated qualification |

### B. Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A fourth grader in your class reads well below the rest of the class. Walk me through your first two weeks with that child." | CASE | [generic] | Say the structure aloud. Clarify first: what is known about this child's reading, what information exists, who has seen them. Objective: a plan the child, the family and you share. Approach: choose from the information, keep it small, check it often. Check: how you will know it is working. Risks: what you do if it is not. Family: how and when they hear from you. Challenge one premise respectfully, such as whether the gap is new. This is a live problem and the guidance makes no claim about your past | F3's reading focus makes a reading case likely; Section 7 explains why the principal may probe it closely. CASE because it scores structure, not history |
| B2 | "The board adopted a three-year literacy plan this year. Which part of it touches a fourth-grade classroom most, and why" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Use what the district itself announced in August 2026: a new grades 3 to 5 reading curriculum from fall 2027 and a family reading night at every school each term. Pick the one that matters most to you and say why in your own words. You may say you have been through a curriculum move, as the sentence states it, "I led our grade level's move to a new reading curriculum in 2024," and stop there. Answer slot: if asked what you took from that move, say it in your own words; if you did not take anything, say so plainly | The one strategy-grounded CO question. F3's evidence is the sentence nearest the district's own plan |
| B3 | "It's the first morning with a new class of fourth graders. What routines do you set up first, and why?" | CASE | [generic] | Pick two or three routines, say what each is for, how students would learn it, and how you would adjust it. Ask what the school already has in place before you decide. The guidance makes no claim about your past | F7 has no evidence, and the hiring page names routines as a panel topic. CASE because it is a decision, not a history |
| B4 | "A family writes that their child's reading score dropped and they are worried. What do you reply" | CASE | [grounded] "I write a weekly email to families." | Structure: acknowledge the worry, find out what the score was and what it does and does not show, say what you will do next, and say when you will follow up. The district's published line is that assessments inform teaching and never replace it, so a score is one input. You may name the channel you already have at its scope, "I write a weekly email to families." Answer slot: if you have handled a worried family before, say what you did, in your own words; if you have not, say so plainly and say how you would | Joins F4 and F5, the two belief rows with thin evidence, in one live problem. CASE because it asks for a reply, not a history |

### C. Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you disagreed with a colleague on your grade-level team." | VAL | [generic] | Selection scaffold: pick a real disagreement with an equal. It needs a stake, what you said, what changed, and a working relationship intact afterwards. If no such time comes to mind, say so plainly, then say how you would disagree with a teammate you respect | A Peer Evaluator stem; F6 shows you have worked at grade level but not how disagreement went. VAL because it scores behavior with equals |
| C2 | "Your CV says you led your grade level's move to a new reading curriculum. Whose work was in that, and how do you talk about it?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Use we for the context and I for your part, but only as the sentence does: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: name which pieces were yours and which belonged to others, in your own words; if you cannot separate them, say so plainly | Credit-sharing is the Peer Evaluator's standing probe, and F6's quote is shared work. EXP because it tests attribution |
| C3 | "What could you do for our team in your first month, and what would you need from us?" | JD | [grounded] "I've run the after-school reading club for the last two years." "I write a weekly email to families." "I've never taught fourth grade" | The reciprocity question. What you bring: offer to talk through the reading club you run and the weekly family email you write, as conversations, not as results. What you need: your honest gap, "I've never taught fourth grade," turned into a request. Answer slot: say what you would ask the team to tell you first, in your own words | Reciprocity is what the two teachers are pricing (F2, F3, F4). JD because it scores fit with the team's work |
| C4 | "Our district expects every teacher to speak with every family each term. How would that work for you?" | JD | [grounded] "I write a weekly email to families." | Say what you do at its scope, "I write a weekly email to families." Then say, in your own words, how you would cover the rest. Answer slot: if you have spoken with families directly, say how and when; if you have not, or only by email, say so plainly and stay with the email | F4 sets the district's expectation beside your one sentence on families. JD because it scores a stated expectation of the role |

### D. Values / Behavioral (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our belief is that no student leaves third grade without a reading plan. You've taught third grade for six years. What did that look like for your students?" | VAL | [grounded] "Six years teaching third grade at a public elementary school in Joliet." "I've run the after-school reading club for the last two years." "I led our grade level's move to a new reading curriculum in 2024" | Answer slot: if your students had reading plans, say how they were made and which part was yours; if there were none, or they were not yours, say so plainly and return to the sentences you can stand behind, the club and the curriculum move as they are written | F3 is the belief that matches the grade you taught, so this is the likeliest values probe. VAL because it scores a published belief |
| D2 | "Tell me about a time a family came to you worried about their child's learning." | VAL | [grounded] "I write a weekly email to families." | Selection scaffold: pick a real case with no names. It needs a stake, what you said, what you did next, and how the relationship stood afterwards. Use we for context and I for your part. If no such time comes to mind, say so plainly, then say how you would handle it, or stay with the email at its scope | The Families Are Partners belief raises this theme (F4). VAL because it scores behavior against that belief |
| D3 | "When did you teach something your students needed that a test would not have measured?" | VAL | [grounded] | Selection scaffold: pick a real moment. It needs what you saw, what you chose to teach, and what happened. The district's published line is that assessments inform teaching and never replace it, so describe the judgment, not a slogan. If no such time comes to mind, say so plainly, then say how you would decide | The third belief (F5) with no evidence in your material. VAL because it scores a published belief |

### E. Conversational / Rapport (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through your path to this application." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." "I led our grade level's move to a new reading curriculum in 2024" "I've run the after-school reading club for the last two years." | A 90-second arc in four beats, each a sentence you have written: the six years of third grade; the curriculum move; the reading club; then why fourth grade at Halvering. The last beat is an answer slot: say your reason in your own words; if it is simple, say it simply. The arc supplies no origin story | A casual opener that is still scored; it sets up F2 before A1 arrives. EXP because it is your own story told aloud |
| E2 | "Tell me about the reading club you run after school." | EXP | [grounded] "I've run the after-school reading club for the last two years." | Stay with what the sentence says: you run it, it is after school, it has run two years. Answer slot: if a typical meeting follows a pattern, describe it in your own words; if it changes from week to week, say so. Do not claim results you did not measure | The club is the sentence most likely to be picked up (F3). EXP because it tests that the line is yours |
| E3 | "Why Halvering, and why now?" | CO | [grounded] "I've run the after-school reading club for the last two years." | Bring one named district belief, then one reason that is yours. The three beliefs are Every Child a Reader, Families Are Partners and Teach for Tomorrow, Not for the Test. The district's August 2026 literacy plan is equally available to every other candidate, so do not recite it. You may pair your reason with the club sentence at its scope, without saying it led you here | Motivation again, in a friendly register (F2). CO because it scores homework depth |

### G. Data-Driven Prober (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "What did you look at, if anything, to see whether the new reading curriculum was working?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Say plainly what the sentence says. Answer slot: if anything was checked, say what it counted, who counted it, and which part was yours; if nothing was, or it was not yours, say so plainly and stay with the move. The weakest-assumption move: name what you would trust least about whatever you looked at, or say plainly that you do not know how it was counted | F3 and F5 meet here: a curriculum move and a belief about assessments. EXP because it tests what you can back up |
| G2 | "Fourth grade teaches reading, writing, math, science and social studies. Which of those are you least ready for?" | JD | [inferred] "Six years teaching third grade at a public elementary school in Joliet." | Your sentence names the grade, not the subjects. Answer slot: say which subjects you taught, in your own words; if one was taught by someone else, say so plainly. Then name the one you would want most support with, and how you would ramp | F8 is typical for the role per the K12 Jobs Board listing, not this school's posting. JD because it scores a listed duty |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 License and endorsement | A5 |
| F2 Fourth Grade Teacher position | A1, A3, A4, E1 |
| F3 Every Child a Reader | B1, B2, D1, E2, G1 |
| F4 Families Are Partners | B4, C3, C4, D2 |
| F5 Teach for Tomorrow, Not for the Test | B4, D3, G1 |
| F6 Works with the grade-level team | A2, C1, C2, C3 |
| F7 Classroom routines | B3 |
| F8 Core subjects | G2 |

Your CV gives no headline figures, so there is no defend-the-number question.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your forum talk covered weekly reading conferences in grades 3 to 5. How does that show up in fourth grade at Halvering?" | Tied to the principal's own public path; it shows you read her work and not only the district's page |
| R2 | "What would a strong first term look like for a teacher who is new to fourth grade here?" | Takes A1's gap into the open and shows you are planning for it |
| R3 | "What could a new person do in their first month that would genuinely help the fourth-grade team?" | The reciprocity question for the two teacher panelists |
| R4 | "How is the new grades 3 to 5 reading curriculum planned to reach fourth grade from fall 2027, and where does a teacher's voice go into it?" | Uses the district's own announced plan and connects to your curriculum-move sentence without leaning on it |
| R5 | "How is the family reading night planned at Halvering, and who usually helps run it?" | The district's literacy plan names a family reading night at every school each term; the question shows interest in the family side |
| R6 | "The district page says references are taken up after the panel. What does the timeline look like from here?" | A practical close that shows you read the hiring page |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade, or has fourth-grade experience | Negative you stated: "I've never taught fourth grade" | The plain acknowledgment in your own words, "I've never taught fourth grade," plus "Six years teaching third grade at a public elementary school in Joliet." at its scope |
| Has been a team lead, or led the team | Negative you stated: "I've never been a team lead" | "I led our grade level's move to a new reading curriculum in 2024" at its scope, plus the acknowledgment "I've never been a team lead." |
| Spoke with every family each term | Inflated form of F4 | "I write a weekly email to families." at its own scope. The pack's observation is that the quote names an email and not conversations. A direct-contact slot stays open in C4 and D2 |
| Chose, designed or wrote the new reading curriculum | Inflated form of F3 and F6 | "I led our grade level's move to a new reading curriculum in 2024" at its own scope. The pack's observation is that the quote says the move, not the selection or design of the curriculum |

## Sources

Provided documents: the invitation from Human Resources, Orrinsford Community School District, and your pasted resume text. A government-issued or state ID number and a Social Security number appeared in that text; neither is needed for interview prep and neither was used.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Query or fetch | What came back |
|---|---|
| Search: Orrinsford Community School District mission values | https://orrinsfordschools.example/about/mission-and-beliefs |
| Search: Orrinsford Community School District teacher interview process panel | https://orrinsfordschools.example/careers/how-we-hire-teachers |
| Search: Orrinsford Community School District strategic plan news | https://orrinsfordschools.example/news/board-adopts-literacy-plan |
| Search: Dolores Vantongeren principal Halvering Elementary School | https://ilprincipalsforum.example/speakers/dolores-vantongeren |
| Search: fourth grade teacher job posting Illinois elementary school requirements | https://k12jobsboard.example/listings/fourth-grade-teacher |
| Fetch: the district Mission and Beliefs page | Returned the three beliefs and their definitions, quoted in F3 to F5 |
| Fetch: the principal's speaker page | Returned the role, tenure, background and talk, used in Reading the interviewer |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. District values | yes | The three beliefs by name and definition: rows F3 to F5 and the D bank |
| 2. Interview process | yes | The hiring page establishes one 45-minute building panel of the principal and two grade-level teachers; persona weights follow it. No values-style round is documented, so there is no values cheat sheet |
| 3. Strategy and recent news | yes | The August 2026 board literacy plan: B2, E3, R4 and R5 |
| 4. Interviewer name | yes | The principal's public role and talk: Reading the interviewer, R1. The two teachers are not named |
| 5. Representative job posting | yes | No posting was supplied, so a typical listing set F6 to F8, labeled `[inferred]` |

## Upgrade menu

- The full posting text → F6 to F8 move from `[inferred]` to `[grounded]`, and any requirement not yet covered gets a JD-tagged question
- Any HR prep notes, such as a sample lesson or writing task → a build section for each announced deliverable
- The two teachers' names → a read on each panelist and retuned peer questions
- Your license record as the state's public lookup shows it → F1 moves from medium to high
- Your answers to the slots in F3, F4 and F5, said in your own words → those rows gain quoted evidence and their guidance becomes story-mapped
- A deeper research pass, up to 6 more searches and 2 more fetches and several more minutes → a district strategy brief and recent organization context; say yes to run it
- A tuesday-dossier.md from the job-underwriter → verified evidence and a rated objection feeding the next pack; never required
