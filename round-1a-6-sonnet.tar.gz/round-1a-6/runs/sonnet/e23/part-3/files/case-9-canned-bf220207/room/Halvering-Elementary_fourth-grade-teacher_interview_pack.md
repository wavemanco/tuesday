# Interview pack: Fourth Grade Teacher, Halvering Elementary School

Orrinsford Community School District. One 45-minute panel on Thursday: Principal Dolores Vantongeren and two members of the fourth-grade team (names not given).

## How to use this pack

- **Personas** describe how a question arrives (who is asking, in what register). **Types** describe what is being scored.
- Type key: **VAL** values and behavior; **EXP** work-experience deep-dive; **JD** the role as posted; **CO** company and strategy knowledge; **CASE** a live problem.
- Guidance is scaffolding, not a script. Wherever it says "answer slot", that is an instruction for the interview itself: answer from your own experience, or say plainly it was not yours.
- Highest-ROI rehearsal in this pack: **A1**, the move from third to fourth grade. It will be asked in some form. Rehearse it until it is boring.
- Built for a single panel, which the district's own hiring page describes (see Sources). Persona weights rest on that page and on the invite, not on a guessed loop.

## Fit snapshot

No job posting was supplied. Requirements below come, in order of strength, from the invite, the district's own pages, and one representative posting from a different employer (marked inferred).

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "valid Illinois Professional Educator License with an elementary endorsement" — the invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | A gate your material shows met, in role-relevant terms. It is a CV line with nothing inspected behind it, so expect it to be checked. Lead with it in its own terms: registered and active through June 30, 2029 |
| F2 | "reading instruction" — district hiring page | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | presentation | Reword only these two sentences: you led the grade level's move to a new reading curriculum in 2024, and you have run the after-school reading club for two years. Neither sentence says what daily reading instruction looks like; B1 rehearses that as a live problem, not as a past |
| F3 | "how you work with families" — district hiring page | "I write a weekly email to families" — your CV | medium | [grounded] | none | No gap on the face, but a CV line alone, so expect a probe. Lead with the email in the quote's own terms: it is weekly, and it goes to families |
| F4 | "Families Are Partners: each teacher speaks with every family each term" — district beliefs page | "I write a weekly email to families" — your CV | low | [inferred] | discovery | The belief asks for speaking with every family each term, and the email sentence does not show whether that happened. Answer slot: if you also speak with families individually, say how and how often; if the email is the main channel, or you do not speak with every family each term, say so plainly and say what you would do |
| F5 | "classroom routines" — district hiring page | none given | none | [grounded] | discovery | Your material does not show this either way. Answer slot: if you set routines in your own classroom, say which and why, in your own words; if routines came from the school or a team, or you did not have set ones, say so plainly and describe how the day ran |
| F6 | "assessments inform teaching and never replace it" — district beliefs page | none given | none | [grounded] | discovery | Your material does not show this either way. Answer slot: if an assessment ever changed what you taught, say what it was and what changed; if none did, or assessments were handled by others, say so plainly and say how you would use one |
| F7 | "work with the grade-level team" — K12 Jobs Board listing (a different employer, representative only) | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your message | medium | [inferred] | transferability | Words stay at the first quote's scope: you led the grade level's move. The second quote is your own plain acknowledgment: "I've never been a team lead." Any wider step is an answer slot: say which parts of the move were yours; if it was assigned or decided above you, say so plainly and say what you did within it |
| F8 | "Fourth Grade Teacher position" — the invite | "Six years teaching third grade at a public elementary school in Joliet" — your CV | medium | [grounded] | transferability | Words stay at the quote: six years, third grade, a public elementary school in Joliet. Answer slot: the role title makes a probe on what carries from third grade to fourth likely. If you know from your own contact with fourth grade what differs, say what and how you know; if you do not, say so plainly and say how you would find out |
| F9 | "Fourth Grade Teacher position" — the invite | "I've never taught fourth grade" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never taught fourth grade." Then how you would get up to speed, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F10 | "Every Child a Reader: no student leaves third grade without a reading plan" — district beliefs page | "Six years teaching third grade at a public elementary school in Joliet" — your CV | low | [inferred] | discovery | The belief names third grade, which is the grade in your quote, and the quote does not show reading plans either way. Answer slot: if you wrote or helped write reading plans, say how, in your own words; if you did not, or plans were set elsewhere, or none existed at your school, say so plainly and stay with the grade you taught |
| F11 | "plan and teach reading, writing, math, science and social studies" — K12 Jobs Board listing (a different employer, representative only) | "Six years teaching third grade at a public elementary school in Joliet" — your CV | low | [inferred] | discovery | The quote does not say which subjects you taught. Answer slot: name the subjects you taught, in your own words; if reading was most of it, or others taught the rest, say so plainly |
| F12 | "differentiate instruction using assessment data" — K12 Jobs Board listing (a different employer, representative only) | none given | none | [inferred] | discovery | Your material does not show this either way. Answer slot: if you adjusted instruction for groups of students using any assessment, say what and how, in your own words; if you did not, say so plainly and say how you would start |

## Reading the interviewer

Public professional footprint only. The two teachers' names were not given, so nothing is read about them.

| Fact | Source | Provenance | What it means for the room |
|---|---|---|---|
| Principal of Halvering Elementary School since 2022, after nine years as a reading specialist | Illinois principals forum speaker page (see Sources) | [grounded] | Reading is her home ground. Expect the reading questions (B1, B2, P1, P2, V1) to be asked by someone who can tell a rehearsed answer from a worked one |
| 2025 forum talk "Small Groups, Big Readers", on weekly reading conferences in grades 3 to 5 | Same page | [grounded] | Her vocabulary is small groups and reading conferences. Use those words if they fit your own plan in B1; never describe doing conferences unless you did |
| Mirror opportunity, shared vocabulary only: reading work in grades 3 and up | Same page, set beside F2's evidence | [grounded] | The candidate's side, quoted from F2: "I led our grade level's move to a new reading curriculum in 2024". No shared career jump is offered, because no row's evidence carries one |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (5 questions) | Quiet probing of the third-to-fourth-grade move, the team question, and why here | High. The panel is a principal plus peers, and F9 is the biggest gap in the snapshot. The principal's relationship prior is hiring manager (Case and Skeptic) | Rehearse A1 until it is boring: name the gap first in your own words (F9), hold only what F8 and F1 carry, concede only what is true, and give a plan, never a past |
| Case / Strategist (3) | Live problems from the real job: plan reading for a class, take on a curriculum, read an assessment | High. The district page says panels ask about reading instruction and routines, and the principal is a former reading specialist | Clarify, then objective, then grouping, then approach, then how you would check it, then risk. Think aloud |
| Peer Evaluator (3) | The two fourth-grade teachers asking what you would need and what you would bring | High. Grade-level teachers sit on the panel; peer prior is Peer Evaluator plus Prober | Reciprocity first: what you bring the team, then what you need. Propose principles for disagreement rather than pretending to know their seam |
| Values / Behavioral (3) | Scenario probes tied to the district's three published beliefs | Medium. The beliefs page says they guide every hire, but the hiring page names panel topics, not a values round, so no cheat sheet is included | Pick real stories where one of your quoted sentences carries one; otherwise use the scaffold and its honest branch |
| Conversational (3) | The opening biography question, a morning-in-your-classroom question, a breadth question | High for the opener, which a panel almost always starts with; scored even though it feels casual | A 90-second arc built only from your own sentences (C1) |
| Data-Driven Prober (2) | Line-by-line questions on the curriculum move and the reading club | Medium-low. Teaching panels are less number-driven, and the material carries no outcome figures, so there is no defend-the-number question | Know exactly which parts were yours, and say plainly when you do not have a figure |
| Pressure | Not included | Low. Nothing in the district's hiring page or the invite points to a time-boxed, interrupting style in a 45-minute building panel | Hold-then-concede is built into A1 and A4 |

## Question banks

### Skeptic (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've taught third grade, not fourth. What worries you about the move?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet"; "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | The highest-ROI rehearsal in this pack. Name it first, plainly: "I've never taught fourth grade." Then hold only what the quotes carry: six years of third grade at a public elementary school in Joliet, and the Elementary Education (grades 1–6) endorsement. Answer slot: if you know from your own contact with fourth grade what differs, say what and how you know; if you do not, say so plainly and say what you would ask the two fourth-grade teachers first. Expect two follow-ups: what in third grade will not carry over, and how you would be ready by the first day; answer each from the same two facts and a plan, never by adding to them. Concede only what is true; do not argue the gap is smaller than it is | F9 is the largest gap and the one every panel member can see from the invite alone. JD because it scores the role as titled; the hold is F8 and F1, the concession is F9 |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" | Selection scaffold: choose one true limit, make it specific, and end with what you would do about it in your first month. If no other limit comes to mind, say so plainly and use the nearest thing your material carries: "I've never taught fourth grade." Do not name a limit you do not believe, and do not dress a strength as a weakness | A standard Skeptic stem that probes honest self-assessment. JD because the answer is read against the role as posted; F9 is the fallback limit |
| A3 | "After six years in third grade, why this move and why Halvering?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024" | Your reasons must be yours; the pack cannot supply them. Selection scaffold: one reason for fourth grade, one for this school, each something you can say in a sentence. The district's published plan brings a new grades 3 to 5 reading curriculum from fall 2027 (see Sources). If that is part of your reason, say so and set beside it your own sentence: "I led our grade level's move to a new reading curriculum in 2024". If it is not your reason, leave it out. If no reason comes to mind beyond the practical, say so plainly and give the nearest true one | Motivation consistency is what a Skeptic scores. JD because it tests fit with this specific role; the plan comes from research, the quotes are F8 and F2 |
| A4 | "Have you led other teachers before, formally or informally?" | EXP | [inferred] "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead" | Hold then concede. Hold: "I led our grade level's move to a new reading curriculum in 2024", in those words and no wider. Concede: "I've never been a team lead." The line between the two is yours to draw in your own words. Answer slot: say which parts of the move were yours; if it was assigned or decided above you, say so plainly and say what you did within it | F7 pairs adjacent work with a stated limit, and the representative posting asks for team work, so the line between leading a move and leading a team is likely to be probed. EXP because it tests what was actually the candidate's; the label is inferred because the team requirement is representative, not this district's |
| A5 | "Which of our three beliefs would be hardest for you to live up to?" | VAL | [inferred] "I write a weekly email to families" | The three beliefs are named on the district's page: Every Child a Reader, Families Are Partners, Teach for Tomorrow, Not for the Test. Pick the one that is truest for you. If you pick Families Are Partners, say what the email is, in the quote's words: weekly, to families. The belief asks for speaking with every family each term, which your material does not show; answer slot: if you also speak with families individually, say how and how often; if you do not, say so plainly and say what you would do | F4 is where the published belief goes past the evidence, and a candid answer there is a credibility gain. VAL because the beliefs are the district's own; asked as a Skeptic probe |

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Half your fourth graders start the year reading well below grade level. How do you plan your first six weeks of reading?" | CASE | [grounded] | Structure aloud: what you would clarify first (what data exists, what the students can already do), the objective, how you would group students, what the weeks would contain, how you would check progress, and the risk you would watch. Use the district's own line, assessments inform teaching and never replace it, if it fits. The principal's public talk used the words small groups and weekly reading conferences; use them only if they fit your own plan. The question needs no claim about your past, so the guidance makes none | A live problem from the district's stated panel topic of reading instruction (F2's requirement) and from a principal who was a reading specialist. CASE with CO flavor because it uses the district's vocabulary |
| B2 | "Our board has brought a new reading curriculum to grades 3 to 5 starting fall 2027. How would you help a grade-level team take one on?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Structure first: what you would want to understand about the curriculum, how the team would hear about it, and what you would watch in the first weeks. You have one sentence of your own, in its own scope: "I led our grade level's move to a new reading curriculum in 2024". Answer slot: expect a probe on what the move involved day to day and which parts were yours; say which in your own words; if a role was set by someone else, say so plainly and stay with the move | The plan comes from research (Sources) and is the one differentiator most candidates will not know. CO because it asks about the district's current strategy; F2 is the evidence |
| B3 | "A student's unit assessment comes back well below where you expected. What do you do next?" | CASE | [grounded] | Structure: question what the assessment measured, look at other evidence of the student's reading, adjust what you teach, and tell the family. The district's published belief is that assessments inform teaching and never replace it, so use its words rather than reciting a method. The question needs no claim about your past, so the guidance makes none | F6 and F12 have no evidence, so a live problem rehearses the thinking without asserting a past. CASE because it scores structure and reasoning |

### Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| PE1 | "We teach side by side. What would you want from us in your first month, and what would you bring?" | JD | [generic] | Reciprocity first: what you would bring the team, then what you would need. Say your own; the pack does not know your strengths from your quotes beyond F2 and F3. End with a concrete, small ask, such as a look at how the grade plans together | The panel includes two grade-level teachers, and peers price what the hire costs them. JD because the posting-style requirement is working with the grade-level team (F7) |
| PE2 | "When we disagree about how to teach something, what happens?" | JD | [generic] | Propose principles, not a claimed past: how you raise it, what you would defer, what you would hold. If asked for an instance, give one only if it comes to mind; if none does, say so plainly and say how you would handle it | The stem is a Peer Evaluator standard; F7 is the row it presses on |
| PE3 | "How do you handle credit when work belongs to a whole grade level?" | VAL | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | We for context, I for contribution. Your sentence, at its scope: "I led our grade level's move to a new reading curriculum in 2024". Answer slot: say which parts were yours and which belonged to colleagues, in your own words; if the move was assigned, say so plainly | F7 and F2 carry the only team-level sentence. VAL because credit-sharing is a behavior probe; asked collegially |

### Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time a student wasn't reading as well as you hoped. What did you do?" | VAL | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | Selection scaffold, tied to Every Child a Reader: pick a time with a named need, something you did, and something that changed; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Answer slot: the belief says no student leaves third grade without a reading plan; if you wrote or helped write reading plans, say how, in your own words; if you did not, or none existed at your school, say so plainly | F10 is where the belief and your grade meet and the quote is silent. VAL because the belief is published; the raising source is the district's beliefs page |
| V2 | "Tell us about a time a family disagreed with you or was worried about their child." | VAL | [grounded] "I write a weekly email to families" | Selection scaffold, tied to Families Are Partners: a named concern, what you said, how it ended, and the relationship afterwards. Your own sentence is "I write a weekly email to families"; say it in those words. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F3 and F4 are the family rows. VAL because the district publishes the belief and its hiring page names family work as a panel topic |
| V3 | "Tell me about a time an assessment changed how you taught." | VAL | [grounded] | Selection scaffold, tied to Teach for Tomorrow, Not for the Test: name the assessment, what it showed, and what you changed. The guidance does not supply the example. If no such time comes to mind, say so plainly, then give how you would use one | F6 has no evidence, so this is the story-selection scaffold and its honest branch. VAL because it maps to a published belief |

### Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your journey so far." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families"; "I've never taught fourth grade" | A 90-second arc built only from those sentences, in your own words and in that order: the six years of third grade, the curriculum move, the club, the weekly email, then the honest edge, that fourth grade is new to you, and then why you want it. The last part is yours; the pack cannot supply it | Nearly every panel opens here, and it is scored. EXP because it is your story under light scrutiny; F8, F2, F3 and F9 supply the sentences |
| C2 | "Walk us through a typical morning in your classroom." | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | Answer slot: the district page names classroom routines as a panel topic, so expect a probe on them. If you set the routines yourself, say which and why, in your own words; if routines came from the school or a team, or you did not have set ones, say so plainly and describe how the morning ran | F5 has no evidence. JD because routines are a named panel topic |
| C3 | "Beyond reading, which subjects have you taught?" | JD | [inferred] "Six years teaching third grade at a public elementary school in Joliet" | Answer slot: a typical fourth-grade posting covers more than reading, and your reading work is the strongest part of your material. Name the subjects you taught, in your own words; if reading was most of it, or others taught the rest, say so plainly and stay with what you taught | F11 is silent on subjects, and the posting is a representative one, which is why the label is inferred |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Walk me through the 2024 move to the new reading curriculum. Which parts were yours?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | The beats are the ones your sentence states: the move, your grade level, the new reading curriculum, 2024; tell them in your own words. Answer slot: expect two probes, which decisions were yours and how you knew the move worked. If any decisions were yours, say which and how you made them; if the choice or the timing was set elsewhere, or you have no measure of how it went, say so plainly and stay with leading the grade level's move | F2 is the strongest sentence and the likeliest to be probed. EXP because it tests what was actually the candidate's |
| P2 | "Tell us about the after-school reading club." | EXP | [grounded] "I've run the after-school reading club for the last two years" | The beats are the ones your sentence states: you run it, it is after school, it has been two years. Tell it in your own words with only what you know. If asked for a figure such as attendance or results, give it only if you have it; if you do not, say so plainly | F2's second sentence. EXP because a prober checks the sentence for substance |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 licence | none, and why: a gate your material shows met; it is checked, not probed |
| F2 reading instruction | B1, B2, P1, P2, V1 |
| F3 how you work with families | V2, A5, C1 |
| F4 Families Are Partners | A5, V2 |
| F5 classroom routines | C2 |
| F6 assessments inform teaching | B3, V3 |
| F7 work with the grade-level team | A4, PE1, PE2, PE3 |
| F8 and F9 Fourth Grade Teacher position | A1, A2, A3, C1 |
| F10 Every Child a Reader | V1, B1 |
| F11 subjects | C3 |
| F12 differentiate with assessment data | B1, B3 |
| Defend-the-number questions | none, and why: the material carries no outcome figure to defend |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You spent nine years as a reading specialist before becoming principal. How has that shaped the way reading time is organized in fourth grade here?" | Ties to the principal's own path (Reading the interviewer, rows 1 and 2) and shows you looked at her, not just the school |
| R2 | "Your talk on small groups and weekly reading conferences was about grades 3 to 5. What does that look like in a fourth-grade classroom at Halvering?" | Uses her own published theme and moves the conversation from interview to practice |
| R3 | "The board plan brings a new grades 3 to 5 reading curriculum from fall 2027. How will Halvering's fourth grade be involved in the rollout?" | Shows you read the current plan and are thinking at the school's altitude (B2) |
| R4 | "What could a new fourth-grade teacher do in the first month that would genuinely help your team?" | The reciprocity question for the two peers on the panel |
| R5 | "What support does a teacher get who is new to a grade?" | Your honest edge (F9) turned into a forward-looking question about support, without apologizing |
| R6 | "The plan includes a family reading night each term. How do fourth-grade teachers usually take part?" | Ties to the district's published plan and the Families Are Partners belief |
| R7 | "What would you like to see from a fourth-grade teacher by the end of the first year?" | Closes on the role's own measure of success |

## Prohibited claims

What this pack will not coach, and why. Built from the fit snapshot before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | Negative you stated, F9 | The plain acknowledgment F9 gives: "I've never taught fourth grade." No slot beyond the plan for getting up to speed |
| Has been a team lead | Negative you stated, F7 | The plain acknowledgment F7 gives: "I've never been a team lead." The other quote stays at its own scope |
| Speaks with every family each term | Inflated form of F3 and F4 | The email quote at its own scope: weekly, to families. The limit is the pack's observation: your material says an email, not speaking with every family. A5's slot stays inside the email |
| Chose or built the reading curriculum | Inflated form of F2 | F2's quote at its own scope: you led the grade level's move. The limit is the pack's observation: your material says the move, not the choice of curriculum. P1's slot stays inside the move |
| Held reading conferences or small groups | Inflated form of F2, from the principal's vocabulary | F2's quotes at their own scope. B1 may use the words only as vocabulary, never as a past |

## Sources

Provided documents: the interview invite, and the pasted resume text. No dossier was present. Government and license identifier numbers in the pasted text were not used.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | yes | The three beliefs (Every Child a Reader, Families Are Partners, Teach for Tomorrow, Not for the Test), fetched from the district page; F4, F6, F10, A5, V1 to V3. The hiring page names panel topics, not a values round, so no cheat sheet is included |
| 2. Interview process | yes | The hiring page documents one 45-minute building panel of the principal and two grade-level teachers, and names reading instruction, classroom routines and family work as topics; persona weights and the single-panel structure follow it |
| 3. Strategy and recent news | yes | The board's literacy plan (result snippet only; not fetched): B2, A3, R3, R6 |
| 4. Interviewer footprint | yes | The principal's role and talk (result snippet only; not fetched): the interviewer read, R1, R2, B1 |
| 5. Representative role posting | yes | One listing from a different employer, result snippet cut off mid-sentence in its qualifications line; only its responsibilities were used, for F7, F11 and F12, all marked inferred |

Queries and what came back:

- "Orrinsford Community School District mission values" returned https://orrinsfordschools.example/about/mission-and-beliefs
- "Orrinsford Community School District teacher interview process" returned https://orrinsfordschools.example/careers/how-we-hire-teachers
- "Orrinsford Community School District strategic plan news" returned https://orrinsfordschools.example/news/board-adopts-literacy-plan
- "Dolores Vantongeren principal Halvering Elementary School" returned https://ilprincipalsforum.example/speakers/dolores-vantongeren
- "fourth grade teacher job description elementary school Illinois responsibilities qualifications" returned https://k12jobsboard.example/listings/fourth-grade-teacher
- Fetched in full: the mission and beliefs page and the hiring page above.

## Upgrade menu

- The full posting text → F7, F11 and F12 become grounded, and any requirement beyond these gets its own question
- What HR said about the format (for example a sample lesson or something to bring) and the two teachers' names or roles → persona weights per panel member, a tailored reverse question for each, and a build section if a deliverable was announced
- Your answers to the slots in F4, F5, F6, F10, F11 and F12, stated outside a drill → each answer is quoted into the snapshot and those rows regenerate into story-mapped guidance
- Your license record as the state shows it → F1 can move from medium to high
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a grounding brief on the district's literacy plan and recent context, and more role-specific loop reports. Offered once; say the word to run it
- A tuesday-dossier from the job-underwriter → verified evidence and a sourced prohibited-claims list in place of the locally built one. Never needed to use this pack
