# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

Orrinsford Community School District. 45-minute panel on Thursday with Principal Dolores Vantongeren and two members of the fourth-grade team (names not given). Relationship: panel; the principal is the hiring-side voice and the two team members are prospective peers.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Past behavior against the district's published beliefs |
| EXP | Whether your resume lines survive scrutiny; what was actually you |
| JD | The listed responsibilities and qualifications, gaps included |
| CO | Knowledge of the school or district and its current direction |
| CASE | A live classroom problem, reasoned aloud |

Each question carries a provenance label in its own column: `[grounded]` traces to something you gave me or a page I read, `[inferred]` is my derivation and says from what, `[generic]` is a pattern with no claim about you or the district. Where guidance says what you did, the sentence it rests on is quoted beside the label.

## The fit snapshot

The requirements below come from three places: your invite (the license and the grade), the district's published beliefs page (read), and a representative fourth-grade teacher posting from a job board, because I did not have the actual posting. Rows from the representative posting are `[inferred]` and typical for the role, not this team's practice.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — your invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | The gate is shown met by your material, with nothing inspected behind it, so expect to be asked and say it in the CV's own terms: the license, the elementary endorsement, grades 1–6, active through June 30, 2029. The pack's observation is that grade 4 sits inside the endorsement's stated span. Checking the public license record against your IEIN before Thursday makes your statement match the record |
| F2 | "plan and teach reading, writing, math, science and social studies" — representative Fourth Grade Teacher listing, K12 Jobs Board | "Six years teaching third grade at a public elementary school in Joliet." — your CV | low | [inferred] | discovery | Your material gives the grade, the setting and the years, and does not show which subjects. Answer slot: the listing names five subjects, so expect a probe on which you taught. Say which, in your own words; if some were taught by someone else, or not at all, say so plainly and stay with the third-grade years you wrote |
| F3 | "the Fourth Grade Teacher position at Halvering Elementary School" — your invite | "I've never taught fourth grade" — your CV | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never taught fourth grade." Then how you would learn the grade, said as a plan and never as a past. Never a claim to a fourth-grade classroom, and nothing added to make the gap feel smaller |
| F4 | "differentiate instruction using assessment data" — representative Fourth Grade Teacher listing, K12 Jobs Board | none given | none | [inferred] | discovery | Your material is silent here. Answer slot: if you used assessment results to change how you taught a group, say what the results were and what changed; if you did not, say so plainly and say what you would look at first |
| F5 | "keep clear classroom routines" — representative Fourth Grade Teacher listing, K12 Jobs Board | none given | none | [inferred] | discovery | Your material is silent here. Answer slot: if you set routines in your own classroom, say which and why those; if the routines were set for you, or there were none, say so plainly and say how you would build them in a new grade |
| F6 | "communicate regularly with families" — representative Fourth Grade Teacher listing, K12 Jobs Board | "I write a weekly email to families." — your CV | medium | [inferred] | none | No gap, but a CV line with nothing inspected behind it, so expect a probe. Lead with it in its own terms: you write it, weekly, to families. A named, repeated habit beats an adjective |
| F7 | "Families Are Partners: each teacher speaks with every family each term." — Orrinsford Mission and Beliefs page | "I write a weekly email to families." — your CV | medium | [grounded] | transferability | An email is not a conversation, and the bridge should not stretch it. Words stay at "I write a weekly email to families." Answer slot: the belief names speaking with every family, so expect a probe on direct contact. If you spoke with families by phone or in person, say how and how often; if you did not, say so plainly and stay with the email |
| F8 | "work with the grade-level team" — representative Fourth Grade Teacher listing, K12 Jobs Board | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your CV | medium | [inferred] | presentation | Your sentence already reaches the requirement in other terms, and the words stay exactly there: "I led our grade level's move to a new reading curriculum in 2024." The pack's observation is that the sentence describes a move, not a role, and you have said you have not been a team lead, so hold both sentences at their own scope and let neither stand in for the other |
| F9 | "Every Child a Reader: no student leaves third grade without a reading plan." — Orrinsford Mission and Beliefs page | "I've run the after-school reading club for the last two years" — your CV; "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [grounded] | transferability | Each sentence reaches reading but neither shows a reading plan, so each stays at its own scope. Answer slot: the belief names reading plans, so expect a probe. If reading plans were part of your third-grade work, say how, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the club and the curriculum move |
| F10 | "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it." — Orrinsford Mission and Beliefs page | none given | none | [grounded] | discovery | Your material is silent here. Answer slot: if an assessment result ever changed what you taught, say what it was and what changed; if none did, say so plainly and say how you would use one |

## Reading the interviewer

Public professional footprint only. The two fourth-grade team members are unnamed, so nothing is read for them.

| Fact | Source | Provenance |
|---|---|---|
| Principal of Halvering Elementary School since 2022, after nine years as a reading specialist | Illinois Principals Forum speaker page | [grounded] |
| 2025 forum talk "Small Groups, Big Readers" covered weekly reading conferences in grades 3 to 5 | Illinois Principals Forum speaker page | [grounded] |
| The board adopted a 2026–2029 literacy plan: structured phonics K–2, a new grades 3–5 reading curriculum from fall 2027, a family reading night at every school each term | Orrinsford news page | [grounded] |

| Practical implication | Drawn from | Provenance |
|---|---|---|
| Expect reading instruction to be probed by someone who has specialized in it, so keep every reading claim at the scope of your own sentences (A3, D1, E3) | The first two facts above | [inferred] |
| A new grades 3–5 reading curriculum is coming in fall 2027, so your 2024 curriculum sentence will draw interest and also a probe on what exactly was yours (A3) | The literacy plan fact | [inferred] |
| A family reading night each term makes the family-communication thread (C3, D2) likely to come up | The literacy plan fact | [inferred] |

| Shared ground | Her public side | Your side, quoted from the named row | Provenance |
|---|---|---|---|
| Reading, in a group or club setting | Weekly reading conferences in grades 3 to 5, and nine years as a reading specialist | "I've run the after-school reading club for the last two years" (F9) | [inferred] |

Shared vocabulary is the offer here: you can talk about reading with her in your own terms. Do not claim you run reading conferences; your sentence says a club.

## The personas and how they are weighted

Weights rest on a documented loop: your invite and the district's hiring page both describe one 45-minute building panel of the principal and two grade-level teachers, and the hiring page names reading instruction, classroom routines and families as the panel's topics. No values-style round is documented, so the published beliefs theme bank D but a separate values sheet is not built.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Provenance |
|---|---|---|---|---|
| Skeptic | Quiet, persistent probing of the two gaps in the material | Highest. F3 and F8 are negatives you stated; the principal's hiring-side role starts the weight on Skeptic and Case | Rehearse A2 until it is boring: concede the two stated limits plainly, hold only what your sentences carry (A1 to A5) | [inferred] |
| Peer Evaluator | The two fourth-grade teachers asking what a new teammate adds to or takes from them | High. They are prospective peers, which is the relationship prior for this persona | Reciprocity first: what you bring before what you need; propose how you would learn their routines rather than pretending to know them (B1 to B4) | [inferred] |
| Case / Strategist | Live classroom scenarios on routines, reading support and families | Medium. The hiring page names those as panel topics and the principal's background is reading | Clarify, then objective, then approach, then how you would check it, then risks; think aloud (C1 to C3) | [inferred] |
| Values / Behavioral | Open prompts keyed to the district's three published beliefs | Medium. The beliefs page says three beliefs guide every hire, though no values round is documented | Map a story where one of your sentences carries it; where none does, pick honestly or say so (D1 to D3) | [grounded] |
| Conversational | The opening journey question and casual probes on reading | Medium. Every panel opens somewhere, and casual questions on a hot topic are still scored | A 90-second arc built only from your own sentences (E1 to E3) | [inferred] |
| Data-Driven Prober | Pressing a resume line for who did what | Low. Your resume holds no figures, so the probing lands on attribution, not numbers; it rides A3 | Know exactly what your sentence says and stop there | [inferred] |
| Pressure | Interrupting, time-boxing, challenging motives | Low. No source describes a stress style at this district; the hold-then-concede method is built into A2 | Pause, restate the question, hold, concede specifically | [generic] |

## Question banks

Question IDs run by persona. The highest-ROI prep in this pack is **A2**: the most predictable objection to this candidate is the two stated limits, never having taught fourth grade and never having been a team lead, and a rehearsed, non-defensive answer changes the interview.

### A. Skeptic (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Your teaching so far has been third grade. What makes you ready for fourth?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." "I've never taught fourth grade" "Elementary Education (grades 1–6) endorsement" | Hold only what the three quotes carry: six years in third grade, an endorsement whose span is grades 1–6, and the plain sentence "I've never taught fourth grade." Say the limit first, in those words, then what you would learn first and from whom, as a plan and never as a past. Answer slot: if you have seen fourth-grade instruction or worked with the fourth-grade standards, say what and how; if you have not, say so plainly and stay with the third-grade years and your plan | F3 is the stated gap and F1 bounds it; JD because it scores readiness for the listed grade. A2 is the deeper version of the same objection |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" "I've never been a team lead" "Six years teaching third grade at a public elementary school in Joliet." | The deepest rehearsal in the pack. Hold, then concede. Hold: "Six years teaching third grade at a public elementary school in Joliet." Concede, specifically and in your own words: "I've never taught fourth grade" and "I've never been a team lead." Say which you would honestly weigh heavier first. Expect three follow-ups. One, why take that on: return to the third-grade years and your plan to learn the grade, and add nothing to the sentence. Two, a comparison to a candidate who has taught fourth grade: do not compare yourself to someone you have not met; say what you bring at its own scope and what you would need to learn. Three, what you would do in week one: a plan only, naming who you would ask. Answer slot: if there is a fourth-grade resource, standard or colleague you have already looked at, say which; if not, say so plainly and say what you would ask first. Never fold on the core claim just to restore harmony | F3 and F8 are the two stated gaps and the likeliest objection. JD because it scores the listed role; the Skeptic bank because the question is aimed at exactly the thin places |
| A3 | "Walk me through the move to a new reading curriculum you led — what part was yours?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | The beats the quote states are your grade level, the move to a new reading curriculum, 2024, and that you led it; tell those in your own words. Answer slot: the listing names working with the grade-level team, so expect a probe on who decided what. Say which parts were yours and which were colleagues' or others', in your own words; if the move was set elsewhere or others carried parts, say so plainly and stay with the sentence you wrote. Hold through two follow-ups by returning to the sentence, never by adding to it. The sentence says your grade level, so do not widen it to the school or the district | F8 is the evidence for team work and the resume line most likely to be pressed. EXP because it tests what was actually yours |
| A4 | "You haven't been a team lead. How would you fit a grade-level team as its newest member?" | JD | [grounded] "I've never been a team lead" "I led our grade level's move to a new reading curriculum in 2024" | Start with the plain acknowledgment: "I've never been a team lead." Then say how you would fit, as a plan: what you would ask the team first and what you would offer. The one adjacent sentence your material carries stays at its scope: "I led our grade level's move to a new reading curriculum in 2024." It is a move, not a role, so do not call it a leadership title. Answer slot: if you took the lead on anything else with colleagues, say what, in your own words; if not, say so plainly | F8 holds two sentences that can look like they conflict; this question rehearses holding both truthfully. JD because the listing names team work |
| A5 | "Your teaching has been in third grade. Which subjects have you taught, and which would be new?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." | Start from the sentence: six years, third grade, a public school in Joliet. Answer slot: the listing names reading, writing, math, science and social studies, so expect this probe. Say which of those you taught, in your own words; if any were taught by someone else, or not at all, say so plainly and say how you would come up to speed | F2 is the evidence and it is silent on subjects. JD because it scores a listed duty |

### B. Peer Evaluator (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our team plans together. What would you want from us, and what would you bring?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" "I write a weekly email to families." | Reciprocity first: lead with what you bring, then what you need. What you can say you bring is your two sentences at their own scope: a move you led for your grade level and a weekly email to families. Let the team draw the inference. What you need comes from your A2 plan: to learn the fourth-grade rhythm from them. Answer slot: if you have planned or shared materials with a team before, say how; if not, say so plainly | F8 and F6 are the only evidence for what you bring; JD because the listing names team work. Peer framing because the question prices what the hire costs the team |
| B2 | "Tell me about a time you disagreed with a teammate about how to teach something." | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Selection criteria: pick a time with a named disagreement about teaching, what each side wanted, how it was settled, and how the working relationship stood afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is your sentence about the curriculum move at its own scope, or say how you would handle it. Do not describe the move as having involved a disagreement unless it did | F8; JD content with a behavioral delivery, because the listing names team work and peers test disagreement style |
| B3 | "How do you handle credit when a project spans several teachers?" | JD | [generic] | State your principle in one sentence, in your own words; the pack does not supply it. Offer an example only if one is genuinely yours; if none is, say how you would handle it. The question needs no claim about your past, so the guidance makes none | F8's requirement; a principle question that peers use to test turf awareness |
| B4 | "What would you want to learn from the two of us in your first month?" | JD | [grounded] "I've never taught fourth grade" | The other side of A2: your stated limit, turned into a plan. Choose two things you would honestly ask first; the pack does not pick them for you. Answer slot: if you have already spoken with fourth-grade teachers anywhere, say what you learned; if not, say so plainly | F3; JD because it scores whether the plan for a new grade is real |

### C. Case / Strategist (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "It is the second week and your fourth graders are slow moving between subjects. What do you set up, and what do you need to know first?" | CASE | [generic] | Clarify first (what the transitions look like now, what routines the school already uses), then the objective, an approach, how you would check it is working, and one risk. Think aloud and challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | F5; a live problem because routines are tested by scenario |
| C2 | "Three students in your class are reading well below the rest. Walk me through your first month." | CASE | [generic] | Clarify what data exists, set the objective, name the support options you would weigh, say how you would check progress and when you would bring in the team and the family. Use the district's own words where natural. The question needs no claim about your past, so the guidance makes none | F4 and F9; reading instruction is the principal's field, so structure matters more than a clever answer |
| C3 | "A parent emails twice in one week upset about a grade. What do you do?" | CASE | [generic] | Clarify what the concern is, acknowledge it, understand the facts, involve the right colleague or the principal where appropriate, follow up, and say how you would keep the relationship intact. The question needs no claim about your past, so the guidance makes none | F6 and F7; families are a named panel topic |

### D. Values / Behavioral (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you helped a child become a stronger reader." | VAL | [grounded] "I've run the after-school reading club for the last two years" | The beats your quote states are the club, after school, for two years; tell those in your own words. A particular child's story has to be yours, chosen from your own memory; if none comes to mind, say so plainly and stay with the club. Answer slot: the belief says no student leaves third grade without a reading plan, so expect a probe on plans. If you made or used a reading plan for a student, say how; if there was no such plan, or it was not yours, say so plainly and stay with the club | F9; VAL because Every Child a Reader is a published belief |
| D2 | "Tell me about a time you worked with a family as a partner." | VAL | [grounded] "I write a weekly email to families." | The beats your quote states are that you write it, weekly, to families; tell those in your own words. Answer slot: the belief says each teacher speaks with every family each term, so expect a probe on direct contact. If you spoke with families by phone or in person, say how and what came of it; if you did not, say so plainly and stay with the email | F7 and F6; VAL because Families Are Partners is a published belief |
| D3 | "Tell me about a time assessment results changed what you taught." | VAL | [grounded] | Selection criteria: pick a time with a named assessment, what it showed, what you changed and what happened next. If no such time comes to mind, say so plainly, then say how you would use an assessment so that it informs teaching. The guidance makes no claim about your past | F10 and F4; VAL because Teach for Tomorrow is a published belief, and your material is silent here |

### E. Conversational (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through your journey, and what brings you to Halvering." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." "I led our grade level's move to a new reading curriculum in 2024" "I've run the after-school reading club for the last two years" "I write a weekly email to families." | A 90-second arc built only from those four sentences, in this order: six years in third grade in Joliet, the curriculum move your grade level made in 2024, the reading club for two years, the weekly email. Then why fourth grade and why Halvering, in your own reasons; the pack does not supply a motive. Mention something the district has published only if it genuinely drew you | F2, F8, F9 and F6 are the whole biography this pack can see. EXP because it is the first test of whether your story is one you can stand behind |
| E2 | "Remind us of your licensure." | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | Say it in the CV's own terms and stop: the Illinois Professional Educator License, the elementary endorsement for grades 1–6, active through June 30, 2029. Nothing wider. Have the IEIN from your resume to hand in case they ask for it | F1; the license is the invite's one stated requirement, so it is likely to be confirmed aloud |
| E3 | "What are you actually playing with in reading these days?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Start from the sentence: the club, for the last two years. Answer slot: what you are trying in the club or in class right now is yours to say, in your own words; if nothing new is underway, say so plainly and stay with the club | F9; a casual question on the principal's field, and still scored |

### Requirement coverage

| Requirement | Question IDs |
|---|---|
| License gate (F1) | E2 |
| Teach reading, writing, math, science and social studies (F2) | A5, C2 |
| The Fourth Grade Teacher position (F3) | A1, A2, B4 |
| Differentiate instruction using assessment data (F4) | C2, D3 |
| Keep clear classroom routines (F5) | C1 |
| Communicate regularly with families (F6) | C3, D2 |
| Families Are Partners (F7) | D2, C3 |
| Work with the grade-level team (F8) | A3, A4, B1, B2, B3 |
| Every Child a Reader (F9) | D1, E3 |
| Teach for Tomorrow, Not for the Test (F10) | D3 |

Your resume holds no figures, so there is no defend-the-number question.

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| 1 | "You came to the principal's role after years as a reading specialist. What from that work do you still lean on most when you are in a classroom?" | Ties to her own path and signals you looked at her, not only the school | [grounded] |
| 2 | "Your talk covered weekly reading conferences in grades 3 to 5. What does that look like in a fourth-grade classroom here?" | Uses her own published theme and asks about the grade you would be teaching | [grounded] |
| 3 | "The board's plan brings a new grades 3–5 reading curriculum from fall 2027. How is the fourth-grade team getting ready, and where would a new teacher fit in?" | Shows you read the district's direction and asks where you would plug in | [grounded] |
| 4 | To the two teachers: "What could a new teammate do in the first month that would genuinely help your team?" | The reciprocity question for peers; it answers what you would cost them before they ask | [generic] |
| 5 | "What does a strong first term look like for a new fourth-grade teacher here?" | Turns your stated gap into a question about how success is measured | [generic] |
| 6 | "Families Are Partners says each teacher speaks with every family each term. How does the team manage that in practice?" | Uses the district's own belief and tells you whether direct contact is a real expectation | [grounded] |

## Prohibited claims

What this pack will not coach, and why. These are the claims a candidate reaches for under pressure.

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade, or has fourth-grade classroom experience | Negative you stated, F3 | The plain acknowledgment: "I've never taught fourth grade." No slot, and the plan is said as a plan |
| Has been a team lead | Negative you stated, F8 | The plain acknowledgment: "I've never been a team lead." The curriculum sentence stays at its own scope |
| Led the school's or the district's reading curriculum adoption | Inflated form of F8 and F9 | "I led our grade level's move to a new reading curriculum in 2024." The pack's observation is that your material says your grade level, not the school or the district |
| Experience with the curriculum Orrinsford is adopting for grades 3–5 | Inflated form of F8 and F9 | The same sentence at its own scope. The pack's observation is that your material says a new curriculum in 2024, and the district's published plan is a new one from fall 2027 |
| Ran a reading intervention program | Inflated form of F9 | "I've run the after-school reading club for the last two years." The pack's observation is that your material says a club |
| Speaks with every family each term | Inflated form of F6 and F7 | "I write a weekly email to families." The pack's observation is that your material says an email, not conversations. The slots in D2 and F7 leave room for either truth |

## Sources

Provided: the invitation email and the resume text you pasted.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Query or page | What came back |
|---|---|
| Search: Orrinsford Community School District mission values | https://orrinsfordschools.example/about/mission-and-beliefs |
| Search: Dolores Vantongeren principal Halvering Elementary School | https://ilprincipalsforum.example/speakers/dolores-vantongeren |
| Search: Halvering Elementary School Orrinsford strategic plan improvement | https://orrinsfordschools.example/news/board-adopts-literacy-plan |
| Search: Orrinsford Community School District teacher interview process panel | https://orrinsfordschools.example/careers/how-we-hire-teachers (read as a search result only, not fetched) |
| Search: Fourth Grade Teacher job description Illinois elementary school | https://k12jobsboard.example/listings/fourth-grade-teacher (the listing text returned was cut off at the start of its qualifications line) |
| Fetch: Mission and Beliefs page | Returned the three beliefs and their one-line definitions, the same text as the search result |
| Fetch: Board literacy plan page | Returned the 2026–2029 plan text, the same as the search result |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | yes | The three beliefs by name: rows F7, F9, F10 and bank D |
| 2. Interview process, role family | yes | One 45-minute panel of the principal and two grade-level teachers, topics reading instruction, classroom routines and families: the persona weights and no values-style round |
| 3. Strategy or recent news | yes | The 2026–2029 literacy plan: the interviewer read's implications and reverse questions 3 and 6 |
| 4. Interviewer name and company | yes | The principal's role, background and talk: the interviewer read and reverse questions 1 and 2 |
| 5. Representative role JD | yes | Requirements for rows F2, F4, F5, F6 and F8, all `[inferred]` because the actual posting was not supplied |

## Upgrade menu

- The actual job posting → the `[inferred]` requirement cells in F2, F4, F5, F6 and F8 become `[grounded]` quotes of this posting, and the cut-off qualifications line of the representative listing is replaced by the real one
- Anything HR said about the panel's focus, or a sample lesson or other item to prepare → coverage beyond the three topics the hiring page names, and a build section for any announced deliverable
- The names and roles of the two fourth-grade team members → a separate interviewer read for each and reverse questions tailored to them
- Your own words on the answer slots (which subjects you taught, F2; assessment use, F4 and F10; routines, F5; direct contact with families, F7; reading plans, F9) → those rows move from discovery to a mapped story, and the guidance gains beats it can now quote
- A sample of the weekly family email, or the reading club's description → F6, F7 and F9 can move from medium toward high, since an inspected document is the artifact for those lines
- A look-up of your license record against the IEIN on your resume → F1 can move from medium to high
- A deeper research pass (up to 6 further searches and 2 further fetches, several more minutes) → a fuller strategy brief for the district, the principal's talk and writing in more depth, reports from other candidates on this district's panels, and recent organizational context. Offered once
- A dossier from an earlier evaluation of this role, if you have one → a verified highest-ROI objection and a sourced prohibited-claims list in place of the ones inferred here; never required
