I've read the pack spec and I'm now running the research step: three quick searches on Quillmoor's values, its recent news, and Hannah's public professional footprint. After that I'll build the pack.
Web search wasn't allowed, so all three research calls were refused. I'm building the pack from your material and the advert only.
Your prep pack is saved as `quillmoor-diagnostics_operations-coordinator_interview_pack.md`. I built it for a recruiter screen covering the four items Hannah listed. It has 19 questions across four interviewer styles, each with answer guidance drawn only from your own sentences.

Web search was declined, so all three research calls were refused. Anything about Quillmoor comes from the advert alone, and the Sources section records this.

- **Salary, hybrid and your reason for moving:** these fit your plans. £42,000 is inside the £38,000–£44,000 range. Two days at Avonmouth is fine, with your "wouldn't want more than three" kept as a ceiling, not an offer. The move is your Bristol office closing and the Reading relocation you don't want.
- **Highest-ROI prep (B2):** "Your office is closing, so this move is partly forced. What's the draw here?" Your material gives the push but nothing that draws you to Quillmoor, so work out your own answer to that.
- **Gaps the pack rehearses honestly:** you've never used SAP, but the advert lists it only as a plus. Your material says "deliveries", where the advert asks for production schedules across planning, the warehouse and QA. It says "spreadsheet", not Excel, and shows no weekly reporting. These appear as answer slots for you to fill from your real experience. The pack doesn't fill them for you.

Say the word and I'll play Hannah live on B2.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

What is your notice period? Your answer would make F10 and A5 grounded in your own figure.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor-diagnostics_operations-coordinator_interview_pack.md -----
# Interview pack: Operations Coordinator, Quillmoor Diagnostics

Recruiter screen with Hannah Lowther, Talent Partner. Thursday 2pm, a 30-minute phone call; she rings the mobile number on your application. Her stated agenda: salary expectations, notice period, how the hybrid pattern would work for you, and what's prompting a move, then the team and next steps.

## How to use this pack

Personas describe how a question is asked; types describe what it is scoring. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did.

Highest-ROI prep: B2, the "what's the draw here" question. Her agenda already contains "what's prompting a move", so some form of it will arrive, and your material gives the push but not the pull.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values (none in this pack: no values round is signalled) |
| EXP | Whether your claims about your own work hold up, and what was actually yours |
| JD | Whether you can do the listed job, gaps included, plus the terms of the offer |
| CO | What you know about the company and why you want it |
| CASE | A live problem from the role (none in this pack: a recruiter call signals none) |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | none | Reaches the requirement in its own terms. Say it as you wrote it: four years, logistics coordinator, a building-supplies wholesaler. A CV-style line with nothing inspected behind it, so expect to be asked to expand |
| F2 | "track supplier deliveries and chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | Lead with chasing suppliers when orders slip, which is your sentence. Your material says chase, not how you notice an order slipping. Answer slot: the advert's tracking line makes a probe on that likely. If you have a way of knowing, say it in your own words; if there is no set method, or it comes to you from someone else, say so plainly and return to the chasing |
| F3 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots" — your message | medium | [grounded] | transferability | Your material says deliveries for three depots; it does not say production schedules and names no planning or QA function, so the words stay at deliveries. Answer slot: the advert names planning, the warehouse and QA, so expect a probe on who you coordinate with. If you work with a warehouse or planning function, say who and what you agree between you; if it is not set up that way, say so plainly and stay with scheduling deliveries across the three depots |
| F4 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | Say it in the sentence's own terms: you rebuilt the stock-count spreadsheet, and discrepancies fell by about a third over a year. Keep "about a third"; do not round it. The number's defend-it slots are rehearsed in C1 and D2 |
| F5 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material does not show reporting. Answer slot: the advert's weekly-report line makes a probe likely. If you report on deliveries to anyone, say what and how often; if you do not, say so plainly and return to the deliveries you schedule and the suppliers you chase |
| F6 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | The sentence says spreadsheet, not Excel, and nothing about what you did in it. Answer slot: if the spreadsheet was in Excel, say so and say in your own words what you did in it; if it was another tool, or others built parts of it, say so plainly and return to the rebuild |
| F7 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system." — your message | low | [grounded] | transferability | Words you can say: "I've never used SAP." The second half of your sentence says your company runs its own in-house stock system; it does not say what you do in it or that it is an ERP. Answer slot: if you work in that system day to day, say what for; if you do not, say so plainly and return to the stock-count spreadsheet. The advert lists this as a plus, and the bridge makes no claim that the in-house system is similar to SAP |
| F8 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | The term is met on your own words. Say both halves as written: two days is fine, and you wouldn't want more than three. That is a ceiling you'd rather not pass, not an offer of three. The advert asks for two, so the ceiling matters only if she asks about flexibility |
| F9 | "£38,000–£44,000" — advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | Inside the advertised range. It is a hope, and your material does not say whether it is the lowest figure you would accept, so the words stay at "hoping for". Decide before Thursday whether you would move from it; the pack writes neither answer for you |
| F10 | "your notice period" — Hannah's message | none given | none | [grounded] | hard_gate | Your material does not establish it. It is a term she will ask about, and nothing here can stand in for the figure in your contract |
| F11 | "what's prompting a move" — Hannah's message | "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | medium | [grounded] | none | Say it in those terms: the office is closing next year, the only offer is Reading, you don't want it. Your material gives the push and no pull toward Quillmoor; B2 rehearses what follows |

### Requirement coverage

| Stated requirement or agenda item | Questions |
|---|---|
| 2+ years in operations or logistics coordination | A1, C2 |
| Coordinate production schedules between planning, the warehouse and QA | B1, C3 |
| Track supplier deliveries and chase late orders | C3, A1 |
| Keep stock records accurate | C1, D2 |
| Report weekly on on-time dispatch | C4 |
| Confident with Excel | C5 |
| ERP experience (SAP or similar), a plus | B3, D1 |
| Hybrid, two days at Avonmouth | A3 |
| £38,000–£44,000 and your salary expectations | A4, D3 |
| Notice period | A5 |
| What's prompting a move | A2, B2, B5 |
| Why Quillmoor | A6, B2 |
| Weakest part of the role on day one | B4 |

## Persona table

The loop is one session: Hannah's message gives a 30-minute phone call with her and a four-item agenda. Weights rest on that message and the recruiter-screen prior, not on a company archetype.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Conversational / Rapport Builder | Friendly agenda walk-through: your background, pay, days, notice, the move | High. Her four agenda items are logistics and motivation, asked in a friendly register; the recruiter-screen prior is Conversational first. Casual questions are still scored | A 90-second arc for "tell me about yourself"; one-sentence answers for the logistics items; treat the casual questions as scored |
| B. Skeptic | Quiet probing of why you are leaving, why here, and the manufacturing and SAP lines | Medium. "What's prompting a move" is on her list, and the advert's manufacturing and ERP lines sit against F3 and F7. The prior is a light Skeptic | Rehearse B2 until it is boring: say what your sentences say, and say plainly what they do not |
| C. Data-Driven Prober | Checks the CV line by line; may touch your one number | Low. A recruiter screen is rarely a deep dive, but F4 is a headline figure and is rehearsed anyway | Know what you can say about how the figure was counted, and say plainly where you do not know |
| D. Pressure / Stress | Short, challenging versions: "why you over someone with SAP" | Low. Nothing in her message signals a stress style; kept to three short items so the challenge is not a first time | Pause, restate, hold what your sentences say, concede the gap specifically |
| E. Case / Strategist | Live problems from the role | Not expected. No case is signalled for a recruiter call; a hiring-manager round might add one. No bank | none |
| F. Values / Behavioral | Stories mapped to published values | Not expected. No values round is named in your inputs, and no company values were available. No bank | none |
| G. Peer Evaluator | Seam-splitting with an adjacent team | Not applicable: she is the recruiter. No bank | none |

## Question banks

### A. Conversational (weight: top)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Thanks for making the time. Tell me a bit about what you do now." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Three beats, each a clause your sentences state: four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots and chasing suppliers when orders slip; rebuilding the stock-count spreadsheet, with discrepancies down about a third over a year. About 90 seconds, then stop and let her steer. Nothing goes in beyond those sentences; where she asks for more, that is the probe the later banks rehearse | F1, F2 and F4 supply the beats. EXP because it checks that the CV claims are yours and can be told plainly; a recruiter screen tends to start here |
| A2 | "What's prompting a move?" | EXP | [grounded] "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Three beats, each stated by your sentence: the Bristol office is closing next year; the only offer is relocating to Reading; you don't want that. About 20 seconds, with no comment on your employer beyond it. Answer slot: your material gives no pull toward Quillmoor, so expect B2 next. If something in the advert draws you, say what and why in your own words; if the pull is mainly that the role matches your work, say so plainly | F11 is her agenda item, in her words. EXP because it scores whether the story is consistent and plain |
| A3 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Answer what she asked first: two days a week at Avonmouth is fine, and you live in north Bristol. If she asks about flexibility, add your other half: you wouldn't want more than three. Keep that wording; it says what you'd rather not pass, not that three is on offer. Say nothing about the journey; your material has nothing on it | F8 is a term met on your own words. JD because it scores the advert's hybrid line |
| A4 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | Name the figure once: you're hoping for £42,000, which sits inside the advertised £38,000 to £44,000. Then stop talking. Answer slot: your material does not say whether £42,000 is the lowest you would accept; decide before Thursday, and say only what you decided. If she asks what you earn now, your material gives no figure; decide beforehand whether you will share it, and say your choice plainly rather than improvising | F9 is inside the range and is a hope, not a floor. JD because it scores the advert's pay line |
| A5 | "What's your notice period?" | JD | [generic] | Your material does not give it. Answer slot: state the notice period as your contract words it, as a number of weeks or months, and say plainly if you will need to check it; do not estimate. If she asks about a start date, say only what you know. The pack writes no figure for you | F10 is a gate your material does not establish. JD because it is a term of the offer; generic because the guidance makes no claim about your past |
| A6 | "What do you know about Quillmoor?" | CO | [grounded] | Use only what the advert says: a diagnostic-test manufacturer with about 400 staff, a site at Avonmouth, and a role that coordinates production schedules between planning, the warehouse and QA. Anything beyond that must come from your own reading before Thursday, because the pack could not look anything up. Answer slot: if you find something the company has published, say where you read it; if you find nothing, say plainly that you've read the advert and would like to hear about the team from her | No research ran, so the answer rests on the advert alone. CO because it scores homework; the honest version is short and sourced |

### B. Skeptic (weight: second)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've come from building supplies, and this is a diagnostic-test manufacturer. How do you see the move?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." | Hold on what your sentences say: four years as a logistics coordinator at a building-supplies wholesaler, scheduling deliveries for three depots and chasing suppliers when orders slip. Concede what they do not show: the advert's schedules are production schedules across planning, the warehouse and QA, and your material says deliveries. Answer slot: if you have worked with a planning or QA function, or in a manufacturing setting, say what and where; if you have not, say so plainly and stay with the deliveries and the suppliers. Say what you would learn first as a plan, never as something already done | F3 is the advert's central line and your material reaches only part of it. JD because it scores whether you can do the listed job |
| B2 | "Your office is closing, so this move is partly forced. What's the draw here?" | CO | [grounded] "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | The deepest rehearsal in this pack. Hold: the reason you gave is the one you gave, said again without apology. Follow-up one, "what do you want from your next role?": answer slot, your material does not say, so if the advert's lines draw you, say which and why in your own words; if the pull is mainly that the role fits your work, say so plainly. Follow-up two is B5. Follow-up three, "why not Reading?": your material says only that you don't want it; if you have a reason, say it in your own words; if you would rather not go into it, say so plainly. Concede the true part: the move starts from the closure. Do not describe an enthusiasm for manufacturing or diagnostics your material does not show | F11 has the push and no pull, and her agenda asks for it. CO because it scores why this company; it also tests whether the story stays the same under follow-up |
| B3 | "The advert lists ERP experience, SAP or similar. What have you used?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Say it plainly: you have never used SAP. Then the second half of your sentence at its own scope: your company runs its own in-house stock system. Answer slot: if you work in that system day to day, say what you do in it; if you do not, or it is mostly someone else's, say so plainly and return to the stock-count spreadsheet you rebuilt. The advert lists ERP as a plus, so treat it as one, without apology and without saying the in-house system is the same as SAP | F7 is a stated absence with adjacent work beside it. JD because it scores a listed qualification |
| B4 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Pick one honestly and say it in a sentence, then give a first step as a plan. The gaps your material shows are the ERP line (you have said you have never used SAP), and the advert lines on production-schedule coordination and weekly dispatch reporting, which your sentences do not reach. If none comes to mind, say so plainly and name the advert line you would want to hear most about | F7, F3 and F5 are the candidates. JD because it is the stated-gap question, asked in a friendly way |
| B5 | "If nothing comes of this, would you take the Reading offer?" | EXP | [grounded] "the only offer is relocating to Reading, which I don't want" | Answer slot: your material does not say what you would do if no other offer comes, and the pack will not write it. Say the truth in a sentence, in your own words; if you would take it, say so plainly; if you would not, say so plainly. Do not strengthen or soften "which I don't want" | F11 shows only a preference. EXP because it tests candour about your own position |

### C. Data-Driven Prober (weight: third)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Say the sentence as it stands: you rebuilt the stock-count spreadsheet, and discrepancies fell by about a third over a year. Answer slot, in your own words: how the figure was counted, or say plainly you do not know how it was counted; what it is sensitive to; the assumption behind it you would defend least; which part was yours. If other things changed over the year, say so plainly; if nothing did, say that. Never round the figure up | F4 is the only number in your material, so the likeliest to be probed. EXP because it checks attribution and honesty about the figure |
| C2 | "How long have you been coordinating logistics, and where?" | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." | Four years, logistics coordinator, a building-supplies wholesaler. Do not relabel it as operations; the advert's line is met in your own words and needs no help | F1 covers the 2+ years line. EXP because it is a plain check of the CV claim |
| C3 | "Tell me how you schedule deliveries across your three depots." | EXP | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Beats from your sentence only: you schedule deliveries, for three depots, and you chase suppliers when orders slip. Answer slot: the advert's lines on tracking deliveries and coordinating schedules make a probe on how you decide what goes first, or how you know an order is slipping, likely. If you have a method or tool, say it in your own words; if the depots or suppliers tell you, or there is no set method, say so plainly and return to the chasing | F2 and F3 are the closest your material comes to the advert's core. EXP because it asks you to walk through your own work |
| C4 | "The role includes weekly reporting on on-time dispatch. Have you done anything like that?" | JD | [grounded] | Answer slot: your material does not show reporting. If you report on deliveries to anyone, say what and how often; if you do not, say so plainly and return to the deliveries you schedule and the suppliers you chase | F5 is the requirement with no evidence behind it. JD because it scores a listed duty |
| C5 | "The advert asks for confidence with Excel. Where would you place yourself?" | JD | [inferred] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: your sentence says spreadsheet, not Excel. If it was in Excel, say so and say in your own words what you did in it; if it was another tool, or others built parts of it, say so plainly and return to the rebuild. Do not name features you did not use | F6 is thin: a spreadsheet, not shown to be Excel. JD because it scores a listed requirement |

### D. Pressure / Stress (weight: fourth)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we put you forward over someone who has used SAP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." "I schedule deliveries for our three depots and chase suppliers when orders slip." | Pause, restate the question. Hold: the advert lists ERP as a plus, and your sentences are four years of scheduling deliveries for three depots and chasing suppliers when orders slip. Concede through two follow-ups, specifically: you have never used SAP. Do not say the in-house system is the same, and do not widen your sentences | F7 against F2. JD because it scores the listed plus; pressure delivery |
| D2 | "That result on the spreadsheet: how much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Hold what the sentence says: you rebuilt it. Answer slot: if others worked on the rebuild or the counts, say who and what; if not, say it was you. Concede, specifically, what you do not know about why the figure moved, and do not claim more than the sentence | F4 and the attribution probe |
| D3 | "That's near the top of our range. Why £42,000?" | JD | [grounded] "I'm hoping for £42,000." | Hold the figure by saying it again once, calmly, and noting it sits inside the advertised range. Answer slot: your material gives no reason behind £42,000; if there is one, say it in your own words; if it is simply what you are hoping for, say so plainly. Do not invent a market comparison. Decide beforehand whether you would move from it | F9 is a hope with no stated basis. JD because it scores the pay line under pressure |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Who would I work with most across planning, the warehouse and QA?" | It uses her promise to describe the team and shows you read the advert's three-function line |
| R2 | "Which system does the team use day to day, and how are new starters trained on it?" | It turns the ERP line into a question about onboarding rather than a gap you have to defend |
| R3 | "How is the weekly on-time dispatch report used, and who reads it?" | It ties to a line in the advert and shows interest in the output, not just the task |
| R4 | "How are the two Avonmouth days arranged, fixed days or agreed with the team?" | It is the practical follow-up to her hybrid agenda item |
| R5 | "What does the next stage involve, who is it with, and what will it cover?" | Her message promises next steps; the answer tells you how to weight the next round's bank |
| R6 | "What would a good first three months look like in this role?" | It shows you are thinking about the work rather than the process |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Experienced with SAP or an ERP | Negative the candidate stated, F7 | "Never used SAP." Then the in-house system at its own scope, as B3's slot asks |
| Scheduled production, or worked across planning and QA | Inflated form of F3 | "I schedule deliveries for our three depots". The limit is the pack's observation: your material says deliveries, not production, and names no planning or QA function |
| Excel expert or advanced Excel | Inflated form of F6 | "I rebuilt our stock-count spreadsheet". The pack's observation: your sentence says spreadsheet, not Excel and not any feature |
| Cut discrepancies by a third because of the rebuild, or by exactly 33% | Inflated form of F4 | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year", with its own wording |
| Three days at Avonmouth is fine | Inflated form of F8 | "I wouldn't want more than three", which is a ceiling, not an offer |
| £42,000 is my minimum, or I'm flexible on pay | Inflated form of F9 | "I'm hoping for £42,000", at its own scope; the pack does not say which you would choose |

## Sources

Provided documents: Hannah Lowther's LinkedIn message, the Operations Coordinator advert, and your message about your background and what you would tell her. No dossier was consumed.

Searches sent, all refused: "Quillmoor Diagnostics company values" (refused); "Quillmoor Diagnostics Avonmouth Bristol news" (refused); "Hannah Lowther Talent Partner Quillmoor Diagnostics" (refused). No page fetches.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor Diagnostics values | unavailable | The search was refused. It would have moved the CO answers in A6 and B2 (published value names to quote). No values-style round is detected, so no cheat sheet is built either way |
| 2. Quillmoor Diagnostics interview process, operations coordinator | skipped | Hannah's message fixes this loop: one 30-minute call with her and her agenda. Persona weights follow from it |
| 3. Quillmoor Diagnostics strategy and recent news | unavailable | The search was refused. It would have moved A6's CO guidance and the reverse questions |
| 4. Hannah Lowther, Quillmoor Diagnostics | unavailable | The search was refused. It would have moved an interviewer read and one reverse question tied to her path; both are absent |
| 5. Representative Operations Coordinator JD | skipped | The advert you supplied fixes the fit snapshot and the JD questions |

## Upgrade menu

- Your notice period → F10 and A5 become grounded in your own figure
- Permission to run web search → A6, B2 and the reverse questions rest on Quillmoor's published material; Hannah's public professional footprint adds an interviewer read and a reverse question tied to her path
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes, needs the same permission) → a company strategy brief for the CO questions
- Your answers to the slots in F2, F3, F5, F6, F7 and F9 → those rows become story-mapped, and the banks that draw on them regenerate
- Whether you report on deliveries to anyone → F5 and C4
- What Hannah says the next round covers → persona weights for a hiring-manager bank
- A tuesday-dossier.md from an earlier evidence review → verified claims and strategy limits for the weak rows; not needed for this pack
