# Operations Coordinator, Quillmoor Diagnostics: recruiter screen prep pack

- **Role:** Operations Coordinator, Quillmoor Diagnostics (diagnostic-test manufacturer, about 400 staff), Avonmouth site, Bristol
- **Interviewer and round:** Hannah Lowther, Talent Partner. A recruiter screen: Thursday at 2pm, a 30-minute phone call, Hannah ringing the mobile number on your application
- **Agenda in Hannah's own words:** salary expectations, notice period, how the hybrid pattern would work, what is prompting a move; then Hannah tells you about the team and next steps
- **Built on this assumption:** a single scored screening call. Company research was refused by this host, so nothing here states a fact about Quillmoor beyond the advert and Hannah's message

## How to use this pack

Personas describe how a question is asked. Types describe what it is scoring. Every question carries one of each, plus where its guidance comes from.

| Tag | Meaning |
|---|---|
| VAL | Whether past behaviour shows the company's published values (none are in hand, so none are tagged here) |
| EXP | Whether your own account of your work survives a follow-up |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you have done your homework on the company |
| CASE | A live problem from the role, reasoned aloud |

The guidance is scaffolding, not a script. Wherever it says answer slot, the pack is deliberately not putting words in your mouth: answer either branch truthfully, in your own words. Every sentence about your past in this pack is one you wrote, quoted.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | medium | [grounded] | transferability | Your material says deliveries across three depots, not production schedules, and the words stay there: "I schedule deliveries for our three depots." Answer slot: the advert's planning, warehouse and QA line makes a probe on who you coordinated with likely. If any of your scheduling was done alongside teams like those, say which and how, in your own words; if not, or it was not yours, say so plainly and stay with the deliveries |
| F2 | "chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | medium | [grounded] | none | No gap, but one sentence with nothing inspected behind it, so expect a probe. Lead with it in its own terms: you chase suppliers when orders slip |
| F3 | "track supplier deliveries" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | low | [inferred] | discovery | The sentence says scheduling and chasing, and does not show how deliveries are tracked. Answer slot: if you keep a record of what suppliers have delivered, say what it is and how you use it; if there is no such record, or it was not yours, say so plainly and stay with the scheduling and chasing |
| F4 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | medium | [grounded] | none | No gap, but a figure with nothing inspected behind it. Say it as written, "about a third over a year". Answer slot for the figure: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours, each in your own words; "I don't know how it was counted" is an honest answer if it is true |
| F5 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material is silent on reporting. Answer slot: if you have reported on deliveries or dispatch, say what, how often and to whom; if you have not, say so plainly and say what you would measure first |
| F6 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | No gap. Say it as written: four years, logistics coordinator, a building-supplies wholesaler |
| F7 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | low | [inferred] | discovery | The sentence says a spreadsheet and does not say which program. Answer slot: if it was Excel, say what you did in it, in your own words; if it was another tool, or the rebuild was not in Excel, say so plainly and say where else you have used Excel |
| F8 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system" — your message | medium | [grounded] | transferability | The words are yours: "Never used SAP", and "we run our own in-house stock system". Your material does not show whether that system counts as an ERP, so the pack does not call it one. Answer slot: say what you do in the in-house system, in your own words; if it holds stock records only, say so plainly. The advert calls ERP a plus |
| F9 | "£38,000–£44,000" — advert | "I'm hoping for £42,000" — your message | high | [grounded] | none | Inside the advertised range. The words are the quote, said as a hope, not as a floor |
| F10 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" — your message | high | [grounded] | none | Meets the advert as written. "Wouldn't want more than three" is your preference as you said it, not a stated rule |
| F11 | "your notice period" — Hannah Lowther's message | none given | none | [grounded] | hard_gate | Your material does not establish your notice period. It is a term Hannah has put on the agenda, and wording cannot supply it |
| F12 | "what's prompting a move" — Hannah Lowther's message | "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" — your message | medium | [grounded] | none | The reason is stated and checkable. The words are the quote |

### Requirement coverage

| Requirement | Question IDs |
|---|---|
| Coordinate production schedules between planning, the warehouse and QA | B2, D2 |
| Track supplier deliveries and chase late orders | A2, D1 |
| Keep stock records accurate | C1, C3, D3, E2 |
| Report weekly on on-time dispatch | B4 |
| 2+ years in operations or logistics coordination | A1 |
| Confident with Excel | C2 |
| ERP experience (SAP or similar) a plus | B3, E1 |
| Salary £38,000–£44,000 | A3 |
| Hybrid, two days at Avonmouth | A4 |
| Notice period (Hannah's agenda) | A5 |
| What is prompting a move (Hannah's agenda) | A2, B1 |
| Company knowledge | B5 |

## Persona table

The loop is one session, a recruiter phone call, established by Hannah's own message, so the weights below come from the relationship prior for a recruiter screen and from where your material is thinnest.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly, unstructured; the agenda questions arrive as chat | Highest. Hannah named four agenda items in a friendly register, and the prior for a recruiter screen is conversational. Casual questions are still scored | Short, plain answers to the agenda items; treat each as scored; stop talking after the number (A3) |
| Skeptic | Quiet probing of the gaps and of "why leave" | Co-highest. The advert's first duty is production schedules and your material says deliveries (F1), reporting and Excel are open rows (F5, F7), and the Reading story invites a "why not" | Rehearse B2 until it is boring: hold what you stated, name what would be new as a plan, never stretch the sentence |
| Data-Driven Prober | Asks how a number was counted | Medium. A 30-minute screen leaves little time, but the one figure you have is the easy thing to pull on, and it will matter more with the hiring manager | Know what you can and cannot say about the figure (C1) |
| Case / Strategist | A live problem from the role | Medium. Recruiters sometimes drop in a quick scenario to test thinking; the advert hands them three ready ones | Clarify, then structure, then say what you would record and who you would tell (D1 to D3) |
| Pressure | A time-boxed challenge: "why you" | Low. Not the register of a recruiter screen, but "why not an SAP user" is a natural curveball | Pause, restate, hold what you stated through two follow-ups (E1, E2) |

## Question banks

### A. Conversational (weight: top)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Can you give me a quick run through your background?" | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip"; "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | A 90-second arc with the three beats those sentences state, in your own words: four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots and chasing suppliers when orders slip; rebuilding the stock-count spreadsheet, with discrepancies down about a third over a year. Then one sentence pointing at the advert line you want to do, chosen by you. Add no beat these sentences do not carry | F6 is the experience bar and F2, F4 are the strongest rows, so the opener should be built from them. EXP because it checks that your own account is consistent from the first minute |
| A2 | "So, what's prompting a move?" | EXP | [grounded] "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Say the beats the sentence states: the Bristol office closes next year, the only offer is relocating to Reading, you don't want that. Then turn to the role with the advert line that draws you, in your own words. Do not call it a redundancy or describe how it was announced; your material says neither | Hannah named this item (F12). EXP because it tests whether the reason is consistent with the rest of your story, and a stated reason is easy to hold |
| A3 | "What salary are you looking for?" | JD | [grounded] "I'm hoping for £42,000" | Say it as you said it to me: "I'm hoping for £42,000", then stop. It sits inside the advertised £38,000–£44,000. Answer slot: whether there is room either way is yours to decide before Thursday; decide it, and say only what you mean. If asked your current salary, decide beforehand how you will answer | F9. JD because the pay is a stated term of the role; a pause after the number is the skill being tested |
| A4 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | Say what the sentence says: you live in north Bristol and two days at Avonmouth is fine. Mention the three-day limit only if asked about flexibility, in the words you used: you wouldn't want more than three. Answer slot: if three days is a firm limit for you, say so; if it is a preference, say that. Add no detail about travel that you did not give | F10 meets the advert and is the easiest row to lose by over-explaining. JD because the pattern is in the advert |
| A5 | "What's your notice period?" | JD | [grounded] | Answer slot: state the length from your contract. If any of it can be shortened, say how; if it cannot, say so plainly. The pack does not have your notice period | F11 is a term Hannah put on the agenda, and the pack's material does not establish it. JD because it is a stated term of hiring |

### B. Skeptic (weight: top)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "If your employer is offering Reading, why not take it?" | EXP | [grounded] "the only offer is relocating to Reading, which I don't want" | Hold what the sentence says: you don't want to relocate to Reading. Answer slot: if there is a reason beyond not wanting to relocate that you are comfortable saying, say it; if not, say plainly that you don't want to move, and return to what you want from this role. Never imply a prior attempt to negotiate; your material shows none | F12 invites this follow-up in collegial form. EXP because it tests whether the reason survives one more question |
| B2 | "The role coordinates production schedules between planning, the warehouse and QA. Your background is scheduling deliveries. How do those fit?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" | **Highest-ROI prep in this pack.** Hold only the sentence: "I schedule deliveries for our three depots and chase suppliers when orders slip." Answer slot: if any of your scheduling was done alongside teams like planning, the warehouse or QA, say which and how; if none was, or it was not yours, say so plainly and return to the deliveries. Concede what would be new as a plan, not a past: in the first weeks you would sit with planning, the warehouse and QA to learn how each works. Follow-up one, "have you scheduled production before?": return to the deliveries and the slot, never add to them. Follow-up two, "what would you need from us?": the plan, in your own words. Stay inside the sentence at both | F1 is the widest gap against the first duty in the advert, so some version of this question is the most predictable in the call. JD because it scores the stated duty; the hold-then-concede structure is the Skeptic's counter |
| B3 | "You haven't used SAP. How would you cope?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | Say the sentence's own words: you have never used SAP, and you work in your own in-house stock system. Answer slot: say what you do in that system, in your own words; if it holds stock records only, say so plainly. Then a plan: how you would learn a new system. Note the advert calls ERP a plus. Do not call the in-house system an ERP | F8, a gap you stated yourself, so the acknowledgment is yours to say. JD because the advert lists it |
| B4 | "The role reports weekly on on-time dispatch. What have you reported on?" | JD | [grounded] | Answer slot: if you have reported on deliveries or dispatch, say what, how often and to whom, in your own words; if you have not, or it was not yours, say so plainly, and say what you would measure first. Name no report or metric you cannot stand behind | F5. The pack's material is silent here and the advert raises it, so the honest second branch is prepared before the probe. JD because it scores a stated duty |
| B5 | "What do you know about Quillmoor?" | CO | [generic] | Start from the advert's own words: a diagnostic-test manufacturer, about 400 staff, coordination across planning, the warehouse and QA, a site at Avonmouth. Then add what you find yourself on their website before Thursday; this pack could not search, so nothing current is supplied. Say plainly what you have and have not read | Homework is scored even in a screen. CO and [generic] because the pack holds no company research; the upgrade menu says how to make it grounded |

### C. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Say the sentence as written, "about a third over a year", and keep "about". Answer slot: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours, each in your own words; if you do not know how it was counted, say so plainly. Never name a method or a baseline you did not state | F4 is the one figure you have, so it is the one a prober pulls on. EXP because it tests what is actually yours |
| C2 | "How confident are you with Excel?" | JD | [inferred] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Say what you rebuilt, in the sentence's terms: the stock-count spreadsheet. Answer slot: if it was in Excel, say what you did in it; if it was another tool, say so plainly and say where else you have used Excel. Name no function you did not use | F7. JD because the advert asks for it; [inferred] because the quote says a spreadsheet, not Excel |
| C3 | "How do you keep stock records accurate day to day?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Start with the rebuilt spreadsheet in the sentence's terms. Answer slot: the advert asks about keeping records accurate day to day; if you have a routine, say what it is; if there is none beyond the spreadsheet, say so plainly and describe what you rebuilt | F4. The advert raises a practice your sentence does not describe, so this is a slot. JD because it scores a stated duty |

### D. Case / Strategist (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A key supplier tells you a delivery will slip by a week. Walk me through what you do." | CASE | [generic] | Structure it aloud: first what you need to know (what is affected, the new date, whether it is firm), then who has to hear about it, then what you would ask the supplier, then what you would record and when you would follow up. The question needs no claim about your past, so the guidance makes none | A live problem from the advert's chase-late-orders line (F2). CASE and [generic] because it is a pattern for the problem, not a fact about the employer |
| D2 | "Planning wants a batch moved earlier, but QA has not cleared the previous one. What do you do?" | CASE | [generic] | Clarify first: what is waiting on what, and who decides. Then say who you would bring together, what you would not decide yourself, and what you would put in writing. Think aloud and say your assumptions | From the advert's planning, warehouse and QA coordination line (F1). CASE because it tests structure; [generic] because it carries no company fact |
| D3 | "The system says 40 of an item and the shelf has 32. What do you do?" | CASE | [generic] | Ask what you need first: recount, recent movements, when it last matched. Then say how you would fix the record and what you would record about the cause. Keep to the problem; make no claim about what you have done before | From the advert's stock-records line (F4). CASE and [generic] |

### E. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you rather than someone who has used SAP?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip"; "Never used SAP — we run our own in-house stock system" | Pause, restate. Hold what you stated: the scheduling and chasing sentence. Concede specifically and once: you have never used SAP, and the advert calls it a plus. Then the plan for learning a system. Make no claim that you are better than other candidates | F8. JD, delivered as pressure. Holding a position without defensiveness is what it scores |
| E2 | "How much of that discrepancy drop was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Hold what the sentence says: you rebuilt the spreadsheet, and discrepancies fell by about a third over a year. Answer slot: if anyone or anything else contributed, say what; if nothing did, or you do not know, say so plainly. Do not name a cause the sentence does not | F4. EXP because attribution is what this probe exists to test |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would the first month look like, and who would I work with day to day across planning, the warehouse and QA?" | The advert names those three teams, so it shows you read it, and it tells you where F1's gap would be tested |
| 2 | "Which system does the team use for schedules and stock, and what training comes with it?" | Turns the SAP gap (F8) into a practical conversation and gets the answer that decides how big it is |
| 3 | "How is on-time dispatch reported today, and who reads the weekly report?" | Shows interest in the duty your material is silent on (F5) and lets you hear what a good report looks like |
| 4 | "On the two days at Avonmouth, are they fixed or agreed with the team?" | Makes F10 concrete for you without reopening your limit |
| 5 | "What would a strong first year in this role look like?" | A question about success, not about perks; recruiters weigh the closing slot heavily |
| 6 | "What are the next steps, and who would the next conversation be with?" | Hannah says she will cover next steps; asking who tells you who to prepare for |

## Prohibited claims

What this pack will not coach, and why. These are the stretched wordings a candidate reaches for under pressure.

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated production schedules between planning, the warehouse and QA | Inflated form of F1 | F1's quote at its own scope: "I schedule deliveries for our three depots." The limit is the pack's observation: your material says deliveries, not production schedules. B2's slot stays inside the deliveries |
| Has SAP experience | Negative you stated, F8 | The acknowledgment you gave: "Never used SAP". No slot |
| Has used an ERP comparable to SAP | Inflated form of F8 | F8's quote at its own scope: "we run our own in-house stock system". B3's slot asks only what you do in it |
| Cut discrepancies by a third, or caused the drop single-handedly | Inflated form of F4 | F4's quote at its own scope, "about a third over a year", with the slot on what was yours. E2 stays inside the sentence |
| £42,000 is my minimum | Inflated form of F9 | F9's quote: "I'm hoping for £42,000" |
| Three days a week is my firm limit | Inflated form of F10 | F10's quote: "I wouldn't want more than three". A3's neighbour A4 holds a slot for whether it is firm |
| I was made redundant | Inflated form of F12 | F12's quote: the office is closing next year and the only offer is relocating to Reading, which you don't want |

## Sources

Provided documents: the advert text you pasted; Hannah Lowther's LinkedIn message; your own account of your background and what you would tell her. No dossier was provided.

Searches sent, all refused by the host, so nothing from them is used:

- `Quillmoor Diagnostics values` — refused
- `Quillmoor Diagnostics Avonmouth news strategy` — refused
- `Hannah Lowther Talent Partner Quillmoor Diagnostics` — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | Every call was refused. It would have moved any values-themed questions; no values-style round is detected in any case, so the cheat sheet is absent either way |
| 2. `Quillmoor Diagnostics interview process Operations Coordinator` | skipped | Hannah's message fixes the loop for this pack: one 30-minute phone call with a stated agenda. It sets the persona weights and the banks |
| 3. `Quillmoor Diagnostics strategy` and recent news | unavailable | The call was refused. It would have moved B5 from generic to current and added a company-grounded CO or CASE question |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | The call was refused. It would have moved the interviewer read and a reverse question tied to Hannah's path; both are absent |
| 5. representative `Operations Coordinator` JD | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your notice period, and whether any of it can flex → F11 and A5 become answerable from your own words
- One line on which program the stock-count spreadsheet is in, and whether you have ever reported on deliveries or dispatch → F7 and F5, both `discovery` rows, become `[grounded]` with a quote
- The before-and-after discrepancy counts from the stock-count spreadsheet → F4 can move from medium to high, because that sheet is the inspectable artifact for stock-record work
- A pasted Quillmoor About page or values page, or search access in this session → B5 becomes `[grounded]`, and a values-themed question can be added if a values round is documented
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → a strategy brief and Hannah's public professional footprint, with a reverse question tied to her path
- A `tuesday-dossier.md` from an earlier evaluation, if you have one → verified evidence and sourced prohibited claims in place of the locally built ones; nothing here depends on it
