# Quillmoor Diagnostics — Operations Coordinator: recruiter screen prep pack

Candidate: Sam. Interviewer: Hannah Lowther, Talent Partner. Round: recruiter screen, a 30-minute phone call on Thursday at 2pm, by Hannah's own message. Her stated agenda: salary expectations, notice period, how the hybrid pattern would work, what is prompting a move; then the team and next steps.

## How to use this pack

Personas describe how a question arrives; types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and rehearse only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Behavioral or values alignment: does past behavior show the company's published values |
| EXP | Work-experience deep-dive: does what you say you did survive a follow-up |
| JD | Role and advert driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge: homework depth |
| CASE | A live problem from the role, answered aloud |

Question IDs run by persona letter: A Conversational, B Skeptic, C Data-Driven Prober, D Case/Strategist, E Pressure, V Values/Behavioral. Fit-snapshot rows are F1 to F13.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — the advert | "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | medium | [grounded] | transferability | Your material says delivery scheduling for three depots, not production scheduling, and the words stay there: "I schedule deliveries for our three depots." Answer slot: the advert's line makes a probe on who your scheduling involves likely. If other teams are part of how you schedule deliveries, say which and how, in your own words; if none are, or it is not yours, say so plainly and stay with the depots |
| F2 | "chase late orders" — the advert | "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe on it. Lead with it in the quote's own terms: you chase suppliers when orders slip |
| F3 | "track supplier deliveries" — the advert | "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | low | [inferred] | discovery | Chasing slipped orders is not the same as tracking deliveries, and the bridge stays at chasing. Answer slot: the advert's line makes a probe on how you find out an order has slipped likely. If you can say how, in your own words, do; if there is no such step, or it is not yours, say so plainly and stay with chasing suppliers when orders slip |
| F4 | "keep stock records accurate" — the advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | medium | [grounded] | none | No gap, but a figure with nothing inspected behind it, so expect a defend-the-number probe. Keep the figure as said: about a third, over a year. Answer slot: say how the discrepancies were counted, what the figure is sensitive to, which assumption behind it you would defend least, and which part was yours; if you do not know how it was counted, say so plainly |
| F5 | "report weekly on on-time dispatch" — the advert | none given | none | [grounded] | discovery | Your material does not show reporting of any kind. Answer slot: the advert's line makes a probe on what you report likely. If you report on deliveries or dispatch, say what and how often, in your own words; if you do not, or it is not yours, say so plainly and stay with scheduling deliveries for the depots |
| F6 | "confident with Excel" — the advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | low | [inferred] | discovery | Your message says spreadsheet and does not name a tool, and the pack goes no further. Answer slot: the advert's line makes a probe on the tool and on what you did in it likely. Say which tool it was and what you did in it, in your own words; if it was not Excel, or little of the rebuild was yours, say so plainly |
| F7 | "2+ years in operations or logistics coordination" — the advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | No gap. Say it in the quote's own terms: 4 years as a logistics coordinator at a building-supplies wholesaler |
| F8 | "ERP experience (SAP or similar) a plus" — the advert | "Never used SAP — we run our own in-house stock system" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used SAP." Then how you would learn it, said as a plan and never as a past. The advert lists ERP as a plus |
| F9 | "ERP experience (SAP or similar) a plus" — the advert | "Never used SAP — we run our own in-house stock system" — your message | low | [inferred] | transferability | Your material says the company runs its own in-house stock system, not what you do in it and not that it is an ERP, and the words stay there: "we run our own in-house stock system." Answer slot: if you work in it, say what you do, in your own words; if you do not, or it is not comparable to an ERP, say so plainly |
| F10 | "£38,000–£44,000" — the advert | "I'm hoping for £42,000" — your message | high | [grounded] | none | £42,000 sits inside the advertised band, in its upper part; that is the pack's observation. Words: "I'm hoping for £42,000." The band grades your statement, not the fit. Nothing in your material says whether the figure can move, so decide before Thursday whether it is a target or a floor |
| F11 | "Hybrid: two days a week at our Avonmouth site in Bristol" — the advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" — your message | high | [grounded] | none | Two days is the advert's pattern and your message accepts it. Say both halves in that order so the limit reads as a boundary: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." The limit is not a preference for three, and it stays a limit |
| F12 | "your notice period" — Hannah's message | none given | none | [grounded] | hard_gate | Your material does not establish your notice period. Hannah has listed it among her four topics |
| F13 | "what's prompting a move" — Hannah's message | "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" — your message | medium | [grounded] | none | Say it as the sentence says: "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." The sentence states the reason for leaving and nothing about why Quillmoor, which B1 rehearses |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder (bank A, 5 questions) | Friendly, unstructured; walks through the four agenda items in turn | Highest. [generic] prior for a recruiter screen: logistics, motivation and knockout checks in a friendly register. [grounded] Hannah's message lists salary, notice, hybrid and the reason for moving as the call's content | Short, plain answers to the four agenda items, each built only from the quotes in F10 to F13; treat the casual ones as scored |
| Skeptic (bank B, 4 questions) | Quiet probing of why you are leaving, why here, and the gaps | High. [generic] prior: light Skeptic on a recruiter screen. [grounded] F13 gives a reason for leaving and no reason for joining; F8 is a stated gap | Rehearse B1 until it is boring; name the SAP gap yourself, as in F8; bridge only from what F9 and F1 carry |
| Data-Driven Prober (bank C, 3 questions) | Asks how the stock-count figure was counted, what the spreadsheet was, what you report | Medium. [generic] a recruiter is less likely to dig into a figure than a manager. [grounded] F4 holds a figure and F5 and F6 are silent | Know what you can and cannot say about how the figure was counted; say plainly when you do not know |
| Case / Strategist (bank D, 2 questions) | A live problem from the role, or what you know of the company | Low. [generic] prior: case work belongs to hiring-manager rounds. Kept because the advert's late-orders line makes a quick scenario possible | Clarify, then objective, then approach, then risks; think aloud |
| Pressure (bank E, 2 questions) | Time-boxed challenge, such as sixty seconds against someone who knows SAP | Low. [generic] prior: a screen is rarely adversarial. [grounded] F8 is the obvious pressure point | Hold the position the quotes carry through two follow-ups; concede the SAP gap plainly |
| Values / Behavioral (bank V, 2 questions) | A quick tell-me-about-a-time on chasing suppliers or stock accuracy | Low. The advert's two lines raise it; no published values were found, so no values round is assumed | Choose a real occasion; if none comes to mind, say so plainly |
| Peer Evaluator | Not included | A recruiter screen has no peer in the room, so no bank | None |

Weights rest on this session only: Hannah's own message establishes one 30-minute phone call, and nothing is known of later rounds.

## Question banks

Highest-ROI prep in the pack: B1, the question of what is pulling you toward Quillmoor. It is certain to arrive in some form, because Hannah has named your reason for moving, and your material is silent on a reason for joining.

### Bank A: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Tell me a bit about what you do at the moment." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip"; "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | A 90-second arc in three beats the quotes state: the role and employer (4 years, logistics coordinator, building-supplies wholesaler), what you do (scheduling deliveries for three depots, chasing suppliers when orders slip), then the stock-count rebuild with its figure as you said it (about a third, over a year). Add no team sizes, volumes or tools the quotes do not carry | The opener of any screen, and the arc F7, F2 and F4 supply. EXP because it scores what you actually do |
| A2 | "What are you hoping for salary-wise?" | JD | [grounded] "I'm hoping for £42,000" | Say it plainly and stop: "I'm hoping for £42,000." Answer slot: if she asks whether it can move, answer from what you have decided beforehand; the pack cannot say, and your material does not | F10 is a gate row, shown met against the advertised band; Hannah's first listed topic. JD because it scores the advert's pay line |
| A3 | "What's your notice period?" | JD | [grounded] | Your material does not establish the length (F12), so the pack gives no wording for it. State the length as it stands, and whether anything can shorten it only if you know; if you do not know, say you will confirm | F12 is a gate row with nothing in your material; Hannah named it. JD because it scores a term of the role |
| A4 | "How would the hybrid pattern work for you, two days a week at Avonmouth?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | Beats the sentence states, in order: where you live (north Bristol), two days at Avonmouth is fine, you wouldn't want more than three. Do not turn the limit into being happy with three. If she asks about the journey, answer in your own words; your material gives no detail | F11 is a gate row shown met, and Hannah's third listed topic. JD because it scores the advert's hybrid line |
| A5 | "What's prompting a move at the moment?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Say what the sentence says: the Bristol office is closing next year, the only offer is relocating to Reading, and you don't want that. One sentence, then stop. Add no reasons the sentence does not carry, such as progression or dissatisfaction | F13 is the reason Hannah asked about. EXP because it tests whether your account of your current situation stays consistent |

### Bank B: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "So the Reading offer is what's pushing you out. What's pulling you towards Quillmoor?" | CO | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want"; "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | Limit named first: your material states the push and says nothing of a pull, so the pull is yours to supply or to say you have none. Hold: the push is true as you said it, so say it without apology. Then the pull, as a selection scaffold: pick what actually draws you from what you know, such as a line of the advert you would want to do, or that the job is in Bristol and you live in north Bristol; one reason you can survive a follow-up on. If nothing draws you beyond that, say so plainly and say what you do know about the role. Follow-up 1, would you have looked if the office were not closing: answer slot: if you would have, say why; if you would not, say so plainly and say what makes this role worth taking now. Follow-up 2, can we count on you staying: promise nothing your material does not give, and say what you can honestly say about why this role. Concede only what is true: the closure is why you are looking now | F13 is the push and the highest-ROI objection; CO because it scores what you know and want about this employer, with the advert as the only source in hand |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | The area you can name without bluffing is the one you stated: "I've never used SAP." Note the advert lists ERP as a plus, then say how you would learn it, as a plan and never as a past. Keep what you carry at its own scope, "we run our own in-house stock system", and do not call it an ERP. If you want to name a second weak area, name it only where you know it to be true | F8 is the stated gap; JD because it scores a stated requirement |
| B3 | "What stock or ERP systems have you worked in?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | Answer slot: your material says the company runs its own in-house stock system, not what you do in it. If you work in it, say what you do, in your own words; if you do not, or it is not comparable to an ERP, say so plainly. Either way, "I've never used SAP" stays in the answer | F8 and F9 are the advert's ERP line; JD because it scores a listed plus |
| B4 | "The role coordinates production schedules between planning, the warehouse and QA. How does that compare with what you do now?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" | Say what the quote carries: scheduling deliveries for three depots and chasing suppliers when orders slip. Do not translate delivery scheduling into production scheduling. Answer slot: if other teams are part of how you schedule deliveries, say which and how, in your own words; if none are, or it is not yours, say so plainly and stay with the depots | F1 is the advert's first duty and the largest gap in kind between your material and the role; JD because it scores that duty |

### Bank C: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How was the fall in stock discrepancies measured?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Say it as stated: about a third, over a year. Answer slot: say how the discrepancies were counted, what the figure is sensitive to, which assumption behind it you would defend least, and which part was yours; if you do not know how it was counted, say so plainly. Name the weakest assumption you know of before she does | F4 holds the only figure in your material; EXP because it scores whether the number survives a follow-up |
| C2 | "The advert asks for confidence with Excel. What did you do in your stock-count spreadsheet?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Answer slot: say which tool the spreadsheet was and what you did in it, in your own words; if it was not Excel, or little of the rebuild was yours, say so plainly and stay with the rebuild as you stated it | F6 is silent on the tool; JD because it scores a listed requirement |
| C3 | "The role reports weekly on on-time dispatch. What do you report on now?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" | Answer slot: if you report on deliveries or dispatch, say what and how often, in your own words; if you do not, or it is not yours, say so plainly and stay with scheduling deliveries for the depots | F5 has no evidence; JD because it scores a listed duty |

### Bank D: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Two suppliers' deliveries are both late for the same week, and the production run needs one of them. What do you do first?" | CASE | [generic] | Structure it aloud: what you would ask first (which run depends on which delivery, by when, and whether a partial delivery or an alternative is possible), what you would do today (get a firm date from each supplier and tell the people who depend on it), how the records stay accurate, and what you would write down. The question needs no claim about your past, so the guidance makes none | The advert's chase-late-orders line (F2, F3) as a live problem; `[generic]` because it is a pattern for the problem, not a fact about this employer |
| D2 | "What do you know about what Quillmoor makes and how the site works?" | CO | [grounded] | Use only what the advert says: a diagnostic-test manufacturer of about 400 staff, with an Avonmouth site in Bristol. The research searches were refused, so the pack holds nothing further. If you have not looked beyond the advert, say so plainly and ask Hannah to tell you, since she has offered to cover the team | CO coverage with no research behind it; the advert is the only source in hand |

### Bank E: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we put you ahead of someone who already knows SAP?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip"; "Never used SAP — we run our own in-house stock system" | Hold: 4 years as a logistics coordinator at a building-supplies wholesaler, and chasing suppliers when orders slip. Concede plainly: "I've never used SAP", and the advert lists ERP as a plus. Hold through two follow-ups by returning to those quotes, never by adding to them | F8 is the clearest pressure point; JD because it scores the advert's ERP line |
| E2 | "That stock-count result: how much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Hold on the verb you stated: "I rebuilt our stock-count spreadsheet." Answer slot: if others contributed to the fall, or other changes happened, say so plainly; if you do not know how much of the fall came from the rebuild, say that | F4's figure under attribution pressure; EXP because it scores precise attribution |

### Bank V: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time a supplier let you down and you had to chase it." | EXP | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" | Selection scaffold: pick one real occasion with a named stake, what you did, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry: that you chase suppliers when orders slip | The advert's chase-late-orders line raises it; F2's quote carries the practice and no incident. EXP, since no published values were found |
| V2 | "Tell me about a time you found a stock record was wrong and what you did about it." | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Selection scaffold: pick one real occasion with what was wrong, what you did, and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: you rebuilt the stock-count spreadsheet and discrepancies fell by about a third over a year | The advert's stock-records line raises it; F4's quote carries a rebuild and no incident |

### Requirement coverage

| Requirement | Questions |
|---|---|
| Coordinate production schedules between planning, the warehouse and QA | B4, D1 |
| Track supplier deliveries and chase late orders | V1, D1, A1 |
| Keep stock records accurate | C1, E2, V2 |
| Report weekly on on-time dispatch | C3 |
| 2+ years in operations or logistics coordination | A1, E1 |
| Confident with Excel | C2 |
| ERP experience (SAP or similar) a plus | B2, B3, E1 |
| £38,000–£44,000 | A2 |
| Hybrid, two days at Avonmouth | A4 |
| Notice period (Hannah's agenda) | A3 |
| What is prompting a move (Hannah's agenda) | A5, B1 |

## Reverse questions

| # | Question to ask Hannah | Why it lands |
|---|---|---|
| R1 | "How does the work split between planning, the warehouse and QA day to day, and where would I sit in that?" | Points at the advert's first duty and gives you what you need to judge F1 |
| R2 | "Which ERP does the team use, and how is training handled for someone starting?" | Turns the SAP gap in F8 into a question about ramp-up |
| R3 | "What does the weekly on-time dispatch report look like today, and who reads it?" | Shows you read the advert's reporting line, and tells you about F5 |
| R4 | "Are the two Avonmouth days fixed days or agreed with the team?" | Follows your own limit in F11 and learns how the pattern works in practice |
| R5 | "Who would I work most closely with in my first month?" | Moves the call from screening to the team she has offered to describe |
| R6 | "What are the next steps and the timeline after this call?" | Keeps the close concrete; she has said she will cover it, so ask only if she does not |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated production schedules between planning, the warehouse and QA | Inflated form of F1 | F1's quote at its own scope: "I schedule deliveries for our three depots." The limit is the pack's observation: the material says delivery scheduling, not production scheduling. B4's slot stays inside the depots |
| Tracks supplier deliveries | Inflated form of F2 and F3 | F2's quote at its own scope: you chase suppliers when orders slip. The slot stays with how you find out an order has slipped, inside that scope |
| Cut stock discrepancies by a third through the rebuild | Inflated form of F4 | F4's quote at its own scope: "about a third over a year", with the rebuild and the fall in one sentence. The limit is the pack's observation: the sentence does not say how the fall was counted or how much of it came from the rebuild |
| Confident with Excel | Inflated form of F6 | F6's quote at its own scope: you rebuilt a stock-count spreadsheet. The limit is the pack's observation: the material says spreadsheet, not Excel |
| Has used SAP | Negative the candidate stated, F8 | The plain acknowledgment F8 gives: "I've never used SAP." No slot |
| Has ERP experience | Inflated form of F9 | F9's quote at its own scope: "we run our own in-house stock system." The limit is the pack's observation: the material does not say it is an ERP or what you do in it |
| Happy to work three or more days at Avonmouth | Inflated form of F11 | F11's quote at its own scope: "I wouldn't want more than three" is a limit, not a preference for three |

## Sources

Provided documents: your message, holding the advert for the Operations Coordinator role, your background notes, and Hannah Lowther's LinkedIn message. No dossier was present.

Searches sent (all refused, none returned a result):

- `Quillmoor Diagnostics values` — refused
- `Quillmoor Diagnostics strategy news` — refused
- `Hannah Lowther Quillmoor Diagnostics` — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | The search was refused. It would have supplied published value names to theme the V bank; no values-style round is detected, so section 10 is absent either way |
| 2. `Quillmoor Diagnostics interview process operations coordination` | skipped | Hannah's message already fixes this session: one 30-minute call with a four-topic agenda; later rounds are unknown and the pack says so |
| 3. `Quillmoor Diagnostics strategy news` | unavailable | The search was refused. It would have grounded D2 in current strategy; D2 rests on the advert alone |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | The search was refused. It would have supplied a reading of the interviewer and a reverse question tied to her path; both are absent |
| 5. representative Operations Coordinator JD | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your notice period → A3 gets wording and F12 leaves hard_gate
- Whether £42,000 is a target or a floor → A2's slot becomes a settled answer and F10's last sentence closes
- What draws you to Quillmoor beyond the role being in Bristol → B1's pull stops being a scaffold and becomes a story map
- Your CV → F1 to F9 re-graded against your own sentences instead of your notes; the stock-count spreadsheet itself, or the before-and-after discrepancy counts, would raise F4 from medium to high
- Whether the stock-count spreadsheet was Excel, and what you did in it → F6 and C2
- Whether you report on deliveries or dispatch anywhere → F5 and C3
- What you do in your in-house stock system → F9 and B3
- Permission for web search → targets 1, 3 and 4 run: published values, a grounded D2, and a reverse question tied to Hannah's path
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, for a strategy brief and recent organisation context
- The schedule of any rounds after this call → per-round mini-packs with their own persona weights
- A `tuesday-dossier.md` from an earlier evaluation → verified evidence and a sharper objection list
