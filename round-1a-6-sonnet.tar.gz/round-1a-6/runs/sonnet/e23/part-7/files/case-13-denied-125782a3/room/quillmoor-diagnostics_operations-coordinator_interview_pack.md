# Interview pack: Operations Coordinator, Quillmoor Diagnostics

**Interviewer and round:** Hannah Lowther, Talent Partner. Recruiter screen, a 30-minute phone call on Thursday at 2pm; she rings the mobile number on your application.
**Her stated agenda:** your salary expectations, your notice period, how the hybrid pattern would work for you, and what is prompting a move. Then she tells you about the team and the next steps.
**Built on:** the advert text you pasted, your own account of your background (no CV supplied), and Hannah's message. Your notice period was not in the material.

## How to use this pack

Personas describe how a question is asked. Types describe what it is scoring. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and only say what you actually did.

| Type | What it scores |
|---|---|
| EXP | Whether your account of your own work holds up, and what was actually you |
| JD | Whether you can do the job the advert describes, including where you are thin |
| CO | Knowledge of the company and its strategy (none in this pack; see Sources) |
| CASE | A live problem from the role, scored on structure and reasoning |
| VAL | Past behavior against the company's published values (none in this pack; see Sources) |

The highest-ROI prep in this pack is **B2**, the question about how close scheduling deliveries is to the production coordination the advert describes. It is the largest distance between your material and the advert, and a recruiter is the person who screens for it.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — JD | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material says deliveries for the depots, not production schedules, and the words stay there: "I schedule deliveries for our three depots." Answer slot: the advert's line on planning, the warehouse and QA makes a probe on who you deal with likely. Say which teams or roles you deal with when you schedule deliveries for the depots, in your own words; if you mostly work alone, or there is no such contact, say so plainly and stay with the depots |
| F2 | "track supplier deliveries and chase late orders" — JD | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | Your sentence already reaches the chasing half in the advert's terms, but nothing has been inspected behind it, so expect a probe. Lead with it as written: "chase suppliers when orders slip." Answer slot: the advert says track, which your sentence does not use. If you follow deliveries with a schedule or a tool, say how; if suppliers tell you when something is late, say so plainly |
| F3 | "keep stock records accurate" — JD | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | Your sentence reaches the requirement in role-relevant terms, but a figure with nothing inspected behind it draws the defend-the-number probe. The sentence places the rebuild and the fall side by side without saying one caused the other, and the words stay as written. Answer slots: how the fall was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours; if you do not know how it was counted, say so plainly |
| F4 | "report weekly on on-time dispatch" — JD | none given | none | [grounded] | discovery | Your material does not show whether you report on deliveries. Answer slot: if you produce any regular report on deliveries, say what it covers and how often; if you do not, say so plainly and return to the sentence in F1 |
| F5 | "confident with Excel" — JD | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | Your sentence says a spreadsheet, not which tool, so the bridge should not be stretched. Answer slot: the advert's Excel line makes a probe on the tool likely. If the spreadsheet was in Excel, say so and say what you did in it, in your own words; if it was another tool, say so plainly |
| F6 | "2+ years in operations or logistics coordination" — JD | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | none | Your sentence reaches the requirement in its own terms: four years, logistics coordinator, a building-supplies wholesaler. Say it in exactly those terms, since a named role and employer type beats an adjective |
| F7 | "ERP experience (SAP or similar) a plus" — JD | "Never used SAP — we run our own in-house stock system." — your message | low | [grounded] | transferability | You stated the SAP negative, so the plain words are sourced: "I haven't used SAP." The second half stays at its scope: your sentence says the company runs an in-house stock system, not that you work in it. Answer slot: the advert's "or similar" makes a probe on that system likely. If you use it yourself, say for what, in your own words; if you do not, or it is not like an ERP, say so plainly |
| F8 | "£38,000–£44,000" — JD | "I'm hoping for £42,000." — your message | high | [grounded] | none | The figure sits inside the advert's range. Your sentence is a hope, not a floor, and the words stay that way: "I'm hoping for £42,000." Your material gives no lowest acceptable figure, so that decision is yours to make before the call |
| F9 | "Hybrid: two days a week at our Avonmouth site in Bristol" — JD | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | The pattern in the advert is met by your own statement, and the statement has two parts that both stay: two days is fine, and you would not want more than three |
| F10 | "your notice period" — Hannah's message | none given | none | [grounded] | hard_gate | Your material does not establish your notice period. It is a term she has said she will ask about, and wording cannot supply it |
| F11 | "what's prompting a move" — Hannah's message | "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | medium | [grounded] | none | Your sentence answers the question in its own terms: the Bristol office is closing next year, the only offer is relocating to Reading, and you do not want that. Say it as written without "Honestly," and add nothing about your employer. Answer slot: what draws you to this role is not in your material. If something in the advert draws you, say what, in your own words; if the closure is the main reason, say so plainly |

## Persona table

Weights rest on the recruiter-screen prior (conversational, with a lighter skeptic) and on Hannah's stated agenda. No loop source documents the rounds after this call, so later rounds fall back to the generic archetype with flat weights, and nothing here assumes how they run.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| A. Conversational | Friendly, four-topic logistics call; casual questions on pay, notice, hybrid and motive | Highest, 5 questions. Her message names all four topics, and each is asked in a relaxed register that is still scored | Short, prepared answers: a 90-second background arc, then one clean sentence per topic. Treat "any questions for me?" as scored |
| B. Skeptic | Quiet probing of the gaps and of why now | High, 5 questions. A recruiter screens for the distance between the advert and your background, and her motive question invites the Reading story | Rehearse B2 until it is boring. Hold the quoted sentence, concede the limit plainly, and give a ramp as a plan, never as a past |
| C. Case/Strategist | One quick scenario from the role, such as a late supplier | Medium, 3 questions. Possible on a recruiter call because the advert's core duties are chasing and scheduling, but her stated agenda does not include one | Clarify, then say the objective, options, who to tell and what to record; think aloud |
| D. Data-Driven Prober | Checks the one figure and the tool behind it | Medium, 3 questions. Your background carries one figure and a spreadsheet, and the advert asks for Excel | Know what you can and cannot say about how the figure was counted; say plainly when you do not know |
| E. Pressure | Challenges the number and your share of the result | Low, 2 questions. Salary is on her agenda, and a probe on the figure is the likeliest firm moment on a friendly call | Pause, restate, hold the position through two follow-ups, concede one thing specifically |
| Values/Behavioral | Not in this pack | No values-style round is detected: no loop source documents one and the generic archetype reads no | None |
| Peer Evaluator | Not in this pack | The interviewer is a Talent Partner, not a peer on the team | None |

## Question banks

### A. Conversational (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Thanks for making time. Could you start by telling me about your background and what you do day to day?" | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | A 90-second arc with four beats, one per clause the quotes state: four years as a logistics coordinator at a building-supplies wholesaler; you schedule deliveries for the three depots; you chase suppliers when orders slip; you rebuilt the stock-count spreadsheet. Tell them in your own words and stop, so she steers. Say the figure only if you are ready for D1 | The opening biography question is the near-certain first scored question; F6 and F1 supply its beats and F3 its one figure. EXP because it tests what you say you did |
| A2 | "What's prompting a move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | The beats the quote states: the Bristol office is closing next year, the only offer is relocating to Reading, and you do not want that. Say it in those terms and keep it factual, with nothing added about your employer. Answer slot: if something in the advert draws you, say what, in your own words; if the closure is the main reason, say so plainly and stay with the quote | It is the fourth item on her agenda, and F11 is the whole of your material on it. EXP because it scores your own account of your situation, and the motive probe is where B3 begins |
| A3 | "How would the hybrid pattern work for you, with two days a week at Avonmouth?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Answer what was asked first: you live in north Bristol and two days at Avonmouth is fine. If she asks how much flexibility there is, give the ceiling in your sentence's own terms: you would not want more than three. Add no commute details or reasons that your sentence does not carry | The pattern is one of her four stated topics, and F9 covers both halves of it. JD because it scores a stated term of the role |
| A4 | "What salary are you looking for?" | JD | [grounded] "I'm hoping for £42,000." | Give the figure in one sentence, "I'm hoping for £42,000", and let her respond. It sits inside the advert's range, which she will know. Your material gives a hope, not a floor, so decide before the call what you would say if asked about flexibility, and whether you would share what you earn now if asked; the pack has neither | Salary is the first item on her agenda, and F8 is stated and in range. JD because the advert publishes the range and she is checking against it |
| A5 | "What's your notice period?" | JD | [grounded] | Answer slot: state your notice period as your contract gives it, and say whether any part of it could be shortened. If you are not sure of the exact terms, say so plainly and say you will confirm after checking your contract. Do not estimate | A direct logistics item on her agenda, and F10 is a gate the material does not establish. JD because it scores a term of the role rather than a skill |

### B. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this advert would you be weakest at on day one?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Name the ERP gap before she does, in words the quote supports: "I haven't used SAP." Then the second half at its scope: your company runs its own in-house stock system. Answer slot: if you use that system yourself, say for what; if you do not, say so plainly. Then say how you would pick up a new system, as a plan in your own words and never as something already done | F7 is the one row where you stated an absence, and the advert lists ERP as a plus. JD because it scores the stated requirements, with a Skeptic delivery |
| B2 | "The advert's coordination is between planning, the warehouse and QA. Your background has you scheduling deliveries for three depots. How close are those two jobs?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | The highest-ROI rehearsal in this pack. Hold only what the quote carries: "I schedule deliveries for our three depots and chase suppliers when orders slip." The limit, before it is asked for, is the pack's observation: your material says deliveries at a wholesaler, not production at a manufacturer. Follow-up 1, who do you deal with when you schedule: answer slot, say which teams or roles, in your own words; if you mostly work alone, say so plainly. Follow-up 2, what is different about production: hold the quote again and name the difference you can see between the two jobs; if any part of your work resembles planning around a production run, say what, in your own words, and if none does, say so plainly. Follow-up 3, how quickly could you close the gap: a ramp plan in your own words, never a past. Return to the quote after every follow-up and add nothing to it | F1 is where the advert's central duty meets the thinnest evidence, so this objection arrives in some form. JD because it scores the stated duty, delivered as a Skeptic probe |
| B3 | "The office is closing but you've been offered Reading. Why not take it?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Say it as the quote says it: the only offer is relocating to Reading, and you do not want that. Hold it through a second follow-up without adding reasons. Answer slot: if there is a further reason you are comfortable sharing, say it in your own words; if not, say plainly that Reading is not something you want and return to the quote | F11 is the whole of your material, and a recruiter checks that a move is chosen rather than fled. EXP because it tests your own account |
| B4 | "How long have you been looking, and are you in any other processes?" | EXP | [generic] | The question needs no claim about your past from this pack. Answer slot: say how long you have been looking and whether other processes are live; if there are none, say so plainly. Keep it to facts you can repeat | A common recruiter-screen pattern, labeled `[generic]` because nothing in your material or the advert raises it. EXP because it scores your own account |
| B5 | "The role reports weekly on on-time dispatch. What's your experience with that kind of reporting?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Answer slot: if you produce any regular report on deliveries, say what it covers and how often, in your own words; if you do not, say so plainly and return to "I schedule deliveries for our three depots and chase suppliers when orders slip." Say how you would start such a report as a plan, never as a past | The advert's reporting line is a stated duty, and F4 has no evidence at all. JD because it scores that duty |

### C. Case/Strategist (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A supplier tells you a delivery that production needs next week will arrive five days late. What do you do?" | CASE | [generic] | Structure it aloud: what you would ask first (what the delivery is for, how firm the new date is, what slips if it is late), who needs to know, the options, how you would follow up, and what you would record. The question needs no claim about your past, so the guidance makes none | A live problem from the advert's chase-late-orders line, which F2 covers. CASE because it asks for reasoning on a problem; `[generic]` because it is a pattern for the problem |
| C2 | "A stock record shows one count and the shelf shows another. How would you find out why?" | CASE | [generic] | Structure it aloud: recount first, check recent movements, find where the two diverge, correct the record, then look for a pattern. The guidance makes no claim about your past | A live problem from the advert's stock-records line, which F3 covers. CASE because it scores structure |
| C3 | "Three suppliers are late at once and the warehouse has one free slot on Friday. How do you decide?" | CASE | [generic] | Structure it aloud: ask what each order is blocking, rank by impact, say what you would tell the other two suppliers and the warehouse, and say what you would watch for next. The guidance makes no claim about your past | Prioritising under a clash is the heart of F1 and F2's requirements. CASE because it scores a decision |

### D. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You said discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Say the sentence at its own scope. Answer slots, each in your own words: how the fall was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. Do not describe a baseline or comparison you could not repeat under a second question | The only figure in your material is a magnet for a probe, and F3 carries it. EXP because it tests whether the claim survives scrutiny |
| D2 | "Tell me more about the stock-count spreadsheet you rebuilt." | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | The beat the quote states: you rebuilt the stock-count spreadsheet. Answer slot: the advert asks for confidence with Excel, so expect a probe on the tool. If it was Excel, say so and say what you did in it, in your own words; if it was another tool, or your part in it was limited, say so plainly | F5 is the advert's Excel line with the thinnest evidence. EXP because the question is about your own work, with a JD edge |
| D3 | "When orders have slipped, how do you decide who to chase first?" | EXP | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Answer slot: if you use a rule or a priority, say what it is, in your own words; if you take them in the order they come up, say so plainly. The quote carries only that you chase suppliers when orders slip | The probe turns your one duty sentence into a method, and F2 is where it lands. EXP because it asks how you actually work |

### E. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "The top of the range is £44,000 and ERP experience is a plus. Why £42,000 for you?" | JD | [grounded] "I'm hoping for £42,000." "4 years as a logistics coordinator at a building-supplies wholesaler." "Never used SAP — we run our own in-house stock system." | Hold the figure through two follow-ups, with only the reason your quotes carry: four years as a logistics coordinator at a building-supplies wholesaler. Concede one thing specifically: "I haven't used SAP." Do not concede the figure to restore harmony; the pack does not know your lowest acceptable figure, so decide it beforehand. Answer slot: if you have a further reason for £42,000, say it in your own words | Salary is on her agenda, and F8 is in range but F7 gives her a lever. JD because it scores the stated range and plus; the delivery is Pressure |
| E2 | "That drop in discrepancies. How much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Hold on what the sentence states, that you rebuilt the spreadsheet, and concede specifically. Answer slots: which part was yours and which was not; if anything else changed over that year, say what, and if nothing did, or you do not know, say so plainly. Never claim the whole fall | This is the standard attribution probe, and F3 places the rebuild and the fall side by side. EXP because it scores attribution honesty |

### Requirement coverage

| Requirement | Question IDs |
|---|---|
| Coordinate production schedules between planning, the warehouse and QA | B2, C1, C3 |
| Track supplier deliveries and chase late orders | D3, C1, C3 |
| Keep stock records accurate | D1, D2, C2, E2 |
| Report weekly on on-time dispatch | B5 |
| 2+ years in operations or logistics coordination | A1 |
| Confident with Excel | D2 |
| ERP experience (SAP or similar) a plus | B1 |
| £38,000–£44,000 | A4, E1 |
| Hybrid: two days a week at Avonmouth | A3 |
| Notice period (Hannah's agenda) | A5 |
| What's prompting a move (Hannah's agenda) | A2, B3, B4 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which of planning, the warehouse and QA would I work with most day to day?" | It uses the advert's own coordination line and lets you size the distance in F1 without claiming it |
| R2 | "How is the weekly on-time dispatch report used, and who reads it?" | It shows interest in the advert's reporting duty, the line where F4 has no evidence |
| R3 | "What systems does the team use today for stock and orders?" | It lets you gauge the ERP plus in F7 openly, rather than guess |
| R4 | "Are the two Avonmouth days fixed, or set by the team?" | It treats the hybrid pattern as something you are planning around, and it is the practical follow-up to A3 |
| R5 | "Who would I meet in the next stage, and what would they want to see?" | It uses the next-steps part of her agenda and gives you a target for the next round |
| R6 | "Where in the £38,000–£44,000 range do offers usually land, and what decides it?" | It follows A4 and E1 and tells you what moves the figure, without reopening your number |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinates production schedules between planning, the warehouse and QA | Inflated form of F1 | F1's quote at its own scope: "I schedule deliveries for our three depots." The limit is the pack's observation: your material says deliveries for the depots, not production schedules. B2's slots stay inside the depots |
| Has ERP experience | Inflated form of F7 | F7's quote at its own scope: your sentence says the company runs an in-house stock system, not that you work in it. B1's slot asks only what you use that system for |
| Has used SAP | Negative the candidate stated, F7 | The plain acknowledgment, from "Never used SAP — we run our own in-house stock system.": "I haven't used SAP." No slot |
| The rebuild caused the one-third fall | Inflated form of F3 | F3's quote at its own scope, which places the rebuild and the fall side by side. The limit is the pack's observation. D1 and E2's slots ask only which part was yours |

## Sources

**Provided documents:** the advert text and your background as you wrote them in this conversation; Hannah's LinkedIn message as you pasted it. No dossier was consumed.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Query | Outcome |
|---|---|
| Quillmoor Diagnostics values | refused |
| Quillmoor Diagnostics interview process operations coordinator | refused |
| Quillmoor Diagnostics strategy news | refused |
| Hannah Lowther Quillmoor Diagnostics | refused |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor Diagnostics values | unavailable | The search was refused. It would have fed a values cheat sheet and VAL questions if a values-style round existed; none is detected, so section 10 is dropped |
| 2. Quillmoor Diagnostics interview process, operations | unavailable | The search was refused. It would have fed loop structure and persona weights for rounds after this call |
| 3. Quillmoor Diagnostics strategy and recent news | unavailable | The search was refused. It would have fed CO questions; this pack has none, and the CASE questions are labeled `[generic]` |
| 4. Hannah Lowther, Quillmoor Diagnostics | unavailable | The search was refused. It would have fed an interviewer read and one reverse question tied to her path; both are absent |
| 5. Representative Operations Coordinator JD | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

Nothing in this pack about Quillmoor's values, process or strategy comes from model memory; the pack is built from your advert and your own words.

## Upgrade menu

- Your notice period → F10 gets your own words, and A5's answer slot becomes a real answer
- Your CV → evidence cells for F1 to F7 quote your CV as well as your message, and the Excel, reporting and ERP rows may move up a band
- The tool the stock-count spreadsheet was built in, and whether you use the in-house stock system yourself → rows F5 and F7 become grounded in your own words
- Whether you produce any regular delivery report → row F4 moves from no evidence to a real answer
- The before-and-after discrepancy counts behind the one-third fall, or the stock-count reports themselves → F3 can rise from medium to high, and D1 and E2 can be rehearsed against the real artifact
- Search permission, then a rerun → targets 1 to 4 above, which would add Quillmoor's published values and loop structure, and a read of Hannah's public professional footprint
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, adding a strategy brief and recent company context for CO questions
- Hannah's answer on what the later rounds are → persona weights for those rounds instead of the flat fallback
- A saved record of the gaps this prep exposes would sharpen any later round; it is never a precondition for this pack
