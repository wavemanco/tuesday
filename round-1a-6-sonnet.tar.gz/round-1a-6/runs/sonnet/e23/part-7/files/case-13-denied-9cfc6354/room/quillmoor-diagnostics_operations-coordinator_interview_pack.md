# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** recruiter screen, 30-minute phone call, Thursday 2pm. **Interviewer:** Hannah Lowther, Talent Partner (recruiter). Session mode. Built on the assumption that the call follows the agenda Hannah set out in her message: salary expectations, notice period, how the hybrid pattern would work, what is prompting a move, then the team and next steps.

## How to use this pack, and the type key

Personas describe how a question arrives; types describe what it is scoring. The guidance is scaffolding for your own words, not a script: say only what you actually did.

| Tag | Meaning |
|---|---|
| VAL | Whether past behavior shows the company's published values (none in play here: no values round and no values page in hand) |
| EXP | Whether what you say about your work survives a follow-up |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge (none included: the research that would ground it was declined) |
| CASE | A live problem from the role, answered by structuring it aloud |

Answer slots are instructions for the call, not questions for you now. Where a slot offers two branches, the second is always allowed to be true.

## Fit snapshot

Requirements are quoted from the advert you pasted and from Hannah's message. Your evidence is your own sentences, quoted.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material says delivery scheduling for depots and chasing suppliers, and shows nothing about production schedules, planning or QA. Say the quote at its own scope: "I schedule deliveries for our three depots." Answer slot: the advert names planning, the warehouse and QA, so expect a probe on the other side of that triangle. If you have worked with a planning or QA function, say how, in your own words; if you have not, say so plainly and stay with the depots and suppliers |
| F2 | "track supplier deliveries and chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | The quote already reaches "chase late orders" in role terms. Lead with it as written: you chase suppliers when orders slip. It is a message line with nothing inspected behind it, so expect a follow-up on how you know an order has slipped; answer that in your own words |
| F3 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | Your sentence carries the rebuild and the fall in discrepancies, and says "about a third", so keep "about". It is a figure with nothing inspected behind it: expect how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours |
| F4 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material is silent on reporting. Answer slot: if you already report on deliveries or dispatch on a regular basis, say what you report and how often, in your own words; if you do not, say so plainly and stay with the scheduling and chasing you described |
| F5 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | none | The quote clears the requirement in its own terms. Say it as written |
| F6 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | The quote says spreadsheet, not Excel, so the pack does not know the tool. Answer slot: if the spreadsheet was in Excel, say what you built in it, in your own words; if it was another tool, say so plainly and say what you did in it |
| F7 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't used SAP." Then how you would learn it, said as a plan and never as a past. Never a claim to SAP work |
| F8 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system." — your message | low | [inferred] | discovery | The advert says "or similar", and the quote says your company runs its own stock system, not whether you work in it or whether it resembles an ERP. Answer slot: if you use that system yourself, say what you use it for; if you do not, or it is not like an ERP, say so plainly and return to the spreadsheet you rebuilt |
| F9 | "£38,000–£44,000" — advert | "I'm hoping for £42,000." — your message | medium | [grounded] | none | £42,000 sits inside the band, near its top. The quote is a hope, not a floor, and the pack does not know whether you have a lowest figure. Say the number as written |
| F10 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | Your own specific constraint, met by the advert. Two days is fine; three is your limit, and the second half is a ceiling, not an offer of flexibility, so keep it in its own words |
| F11 | "your notice period" — Hannah's message | none given | none | [grounded] | hard_gate | Your material does not establish your notice period. It is a term she will ask for |
| F12 | "what's prompting a move" — Hannah's message | "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | medium | [grounded] | none | Say it in the quote's own terms: the Bristol office is closing next year, the only offer is relocating to Reading, and you do not want that. Nothing inspected sits behind it, so expect a follow-up on it |

## Persona table

Starting weights come from the recruiter-screen prior (conversational with a light skeptic). Hannah's own agenda is the loop source for this session, and no interviewer profile was available (the search was declined), so nothing adjusts the prior.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Provenance |
|---|---|---|---|---|
| Conversational (weight: highest, 5 questions) | Friendly walk through your background, then her four items in turn | High: Hannah wrote "I'd like to cover your salary expectations, your notice period, how the hybrid pattern would work for you and what's prompting a move" | Scripted 90-second arcs for the biography and the move question; treat the casual questions as scored | [grounded] |
| Skeptic (weight: high, 5 questions) | Quiet probing of the gaps: motivation for Quillmoor, SAP, production scheduling | Medium: her "what's prompting a move" invites "why here"; F1, F7 and F8 are the visible gaps | Rehearse B1 until it is boring; quote-limited bridges; calibrated candor | [grounded] |
| Data-Driven Prober (weight: mid, 3 questions) | Asks how the one-third figure was counted | Low to medium: it is the one figure in your material; recruiters of this kind often skim figures | Know what you can and cannot say about the count; say plainly where you do not know | [generic] |
| Case / Strategist (weight: mid, 3 questions) | A quick what-would-you-do on a late supplier | Low: the agenda she gave has no exercise in it; rehearsed in case a hiring manager round follows | Clarify, structure, then answer; think aloud | [generic] |
| Pressure (weight: low, 2 questions) | Pushes on the number or on SAP | Low: she raised salary herself, so a push on it is possible | Pause, hold the position through two follow-ups, concede specifically | [inferred] |

## Question banks

### A. Conversational (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through where you are now and what's prompting a move." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Three beats, each one a sentence of yours: the four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots and chasing suppliers when orders slip; then the move, in the quote's own terms: the Bristol office is closing next year, the only offer is relocating to Reading, and you do not want that. Add nothing about the closure beyond that sentence. Answer slot: if there is something in this role you are moving toward, say it in your own words; if the reason is the closure, say so plainly and stop there | F5 and F12 are the two rows this question reads. EXP because it is your own history said aloud; it is on Hannah's stated agenda, so it is near certain |
| A2 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Lead with the first half: you live in north Bristol and two days at Avonmouth is fine. If she asks how much flexibility there is, give the second half as written, that you wouldn't want more than three. Keep it a limit; do not turn it into an offer to do three | F10 is a gate the advert and your own statement already meet, so this is a confirm-and-move-on question. JD because it scores a stated term of the role |
| A3 | "What are you looking for salary-wise?" | JD | [grounded] "I'm hoping for £42,000." | Say it once and plainly: you are hoping for £42,000. Then stop and let her respond; do not fill the silence with a justification or a range. Answer slot: if she asks whether that is flexible, say what is true for you: a lowest figure if you have one, decided before the call, or that you have not set one, said plainly rather than invented | F9 is inside the advert's band near its top, so the number is defensible and the follow-up is the real exercise. JD because it scores the stated pay term |
| A4 | "What's your notice period, and when could you start?" | JD | [grounded] | Answer slot: say your notice period as your contract states it; if you do not know it, check your contract before the call, and if a shorter arrangement is possible, say so only if it is true. Make no claim about timing you cannot back | F11 is a term your material does not establish, and she named it on her agenda, so it is certain to be asked. JD because it scores availability against the role |
| A5 | "What caught your eye about this role?" | JD | [generic] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Selection scaffold: pick one or two of the advert's own lines that you actually want to do. The advert says "track supplier deliveries and chase late orders", and your sentence says you chase suppliers when orders slip, so if that line is one you want, say so in those terms. Answer slot: if you cannot point to a line beyond staying in Bristol, say so plainly, then say what you would want to learn about the team | F2 gives you one honest point of contact with the advert. JD because it tests whether your interest is in the listed work; `[generic]` because the choice of lines is yours |

### B. Skeptic (high weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Is this role something you're moving toward, or is it mostly about getting away from the Reading move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | **The highest-ROI rehearsal in this pack.** The hold is only what your sentence carries: the Bristol office is closing next year, the only offer is relocating to Reading, and you do not want that. Answer slot: if there is something in the advert you are moving toward, name it in your own words; if the honest answer is mostly the closure, say so plainly, then point to the advert line nearest your work, which your material says is chasing suppliers when orders slip. Follow-up 1: "Would you apply for any Bristol job?" Say truthfully how you chose, and claim no selection process you did not run. Follow-up 2: "What if we can't match £42,000?" Return to A3's wording and concede only what is true. Concede at the end that the closure is why you are looking | F12 is the reason she asked about, and the "why here, why now" probe aims at it directly. EXP and not JD because it tests your own story under cross-examination |
| B2 | "Do you have SAP experience?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Plain acknowledgment from your own sentence: "I haven't used SAP." Then the in-house system at its own scope: your company runs its own stock system. Answer slot: if you use that system yourself, say what you use it for; if you do not, or it is not like an ERP, say so plainly. Finish with how you would learn SAP, said as a plan and not as a past | F7 and F8 are the rows the advert's "plus" touches. It is a plus, not a requirement, so the aim is a short honest answer and no defensiveness. JD because it scores a stated qualification |
| B3 | "This role coordinates production schedules between planning, the warehouse and QA. How does what you do now compare?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Say your sentence at its own scope: you schedule deliveries for three depots and chase suppliers when orders slip. Observation, the pack's own: your material says delivery scheduling, not production scheduling, and shows no contact with planning or QA. Answer slot: if you have worked with a planning, production or QA team, say how; if you have not, say so plainly and stay with depots and suppliers | F1 is the widest gap in the snapshot and the first thing a hiring manager will probe, so it is worth having ready even on a recruiter call. JD because it scores the headline responsibility |
| B4 | "Which part of this advert would you be weakest at on day one?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Pick the one that is actually weakest by your own reading. Two rows in your material are open: F7, where you have said you have not used SAP, and F4, where your material is silent on dispatch reporting. Answer slot: if weekly reporting is something you already do, say so and leave it off the list; if it is not, say so plainly and name it with how you would pick it up | F7 and F4 are the two open rows. JD because it scores honest self-assessment against the listed requirements |
| B5 | "Have you worked around manufacturing or a regulated product before?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." | Your sentence says wholesaler, and your material shows no manufacturing or regulated work. Answer slot: if any part of your work touched manufacturing, quality checks or regulated products, say what; if none did, say so plainly and say what you would want to learn | F1 and F5 are the rows near this probe. Quillmoor is a diagnostic-test manufacturer per the advert, so the question follows from its own first line. JD because it scores fit with the setting |

### C. Data-Driven Prober (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Four slots, each answered in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. Keep "about a third" and "over a year" as you said them, and do not say more than that your sentence carries | F3 is the only figure in your material, so it is the one a prober goes to. EXP because it tests attribution |
| C2 | "What did you rebuild, and what was different about it?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Beat from your sentence: you rebuilt the stock-count spreadsheet. Answer slot: say what changed in it, in your own words, and whether it was Excel; if others worked on it, say so; if you cannot say what differed, say so plainly and return to the rebuild | F6 and F3 meet here: the Excel requirement rests on this sentence. JD because it scores the Excel line |
| C3 | "How many suppliers or orders are you chasing in a typical week?" | EXP | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | The only scale your sentence carries is three depots. Answer slot: if you know a weekly number, say it as you know it; if you do not, say plainly that you would need to check rather than estimating | F2 carries no figure, so any number must be yours. EXP because it tests whether the claim has a denominator |

### D. Case / Strategist (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A supplier says a key delivery will be two weeks late and the warehouse expects it Monday. What do you do first?" | CASE | [generic] | Structure aloud: what you need to know first (which order, what depends on it, whether the date is firm), who needs to hear (the advert names planning, the warehouse and QA), the options, and what you would record. It makes no claim about your past | The advert's "chase late orders" line (F2's requirement) set as a decision. CASE because it asks for structure on a live problem |
| D2 | "The system says a line has 40 units and the count says 33. How do you find out why?" | CASE | [generic] | Structure: confirm the count, check recent movements, recount, trace the difference, correct the record and note the cause. It makes no claim about your past | The advert's "keep stock records accurate" line (F3's requirement) as a live problem. CASE because it scores method |
| D3 | "How would you report on on-time dispatch each week? What goes in it?" | CASE | [generic] | Structure: what counts as on time, the denominator, the exceptions, the trend, who reads it. Answer slot: if you already report on deliveries in some form, say what; if you do not, say so plainly | F4 is the open row for this line, and the advert names the weekly report. CASE because it asks you to design it |

### E. Pressure (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "£42,000 is near the top of our range. What makes you worth it?" | JD | [grounded] "I'm hoping for £42,000." "4 years as a logistics coordinator at a building-supplies wholesaler." | Hold: say the number again, and rest it only on what you have said: four years as a logistics coordinator at a building-supplies wholesaler. Hold through two follow-ups by returning to the quote, never by adding to it. Concede specifically: you have not used SAP, and the number is near the top of the band. Answer slot: if you have a lowest figure, decide before the call whether to say it; if you have none, say so plainly | F9 sits near the top of the band, and the pressure version of salary is the likely follow-up. JD because it scores pay against the role |
| E2 | "Sixty seconds: why you over someone who has used SAP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." "I schedule deliveries for our three depots and chase suppliers when orders slip." | Concede first and plainly: "I haven't used SAP." Then hold on what your sentence carries: you schedule deliveries for three depots and chase suppliers when orders slip. Do not claim you are better; say how you would learn it, as a plan | F7 is a stated gap, so the honest answer is a concession followed by what you do carry. JD because it scores the qualification under time pressure |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| Coordinate production schedules between planning, the warehouse and QA | B3, B5, D1 |
| Track supplier deliveries and chase late orders | A5, C3, D1 |
| Keep stock records accurate | C1, C2, D2 |
| Report weekly on on-time dispatch | B4, D3 |
| 2+ years in operations or logistics coordination | A1, E1 |
| Confident with Excel | C2 |
| ERP experience (SAP or similar) a plus | B2, B4, E2 |
| £38,000–£44,000 | A3, E1 |
| Hybrid: two days a week at Avonmouth | A2 |
| Notice period (Hannah's agenda) | A4 |
| What's prompting a move (Hannah's agenda) | A1, B1 |

## Reverse questions

Hannah has said she will cover the team and next steps, so these are for the end, after she has.

| # | Question | Why it lands |
|---|---|---|
| R1 | "Who would I work with most closely across planning, the warehouse and QA?" | The advert names all three, so it shows you read the role as a coordination job |
| R2 | "Which systems does the team work in day to day?" | SAP is in the advert as a plus, and the answer tells you how large the gap really is |
| R3 | "How is on-time dispatch measured at the moment?" | It ties to the weekly report in the advert and tells you what you would be reporting on |
| R4 | "How does the two-days-on-site pattern work in practice: fixed days, or agreed with the team?" | It confirms the hybrid term with the person who can answer it |
| R5 | "What would a good first three months look like in this role?" | It shows you are thinking about doing the job, not only getting it |
| R6 | "What are the next stages, and who would I meet?" | She will cover next steps, so this fills any gap she leaves and keeps you informed |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has SAP or ERP experience | Negative you stated, F7 | Your quote, "Never used SAP — we run our own in-house stock system.", and the plain acknowledgment "I haven't used SAP." No slot on the claim itself |
| Coordinated production schedules with planning and QA | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says delivery scheduling for depots |
| My rebuild alone cut discrepancies by a third | Inflated form of F3 | F3's quote as you said it. C1's slots ask only how it was counted, what it is sensitive to, the weakest assumption and which part was yours |
| My role is being made redundant | Inflated form of F12 | F12's quote at its own scope: the office is closing next year, the only offer is relocating to Reading |

## Sources

Provided documents: your message (the advert and your background) and Hannah's LinkedIn message. No dossier was present.

Searches sent, all refused by the host (permission not granted): "Quillmoor Diagnostics values"; "Quillmoor Diagnostics Avonmouth Bristol news strategy"; "Hannah Lowther Talent Partner Quillmoor Diagnostics". No fetches.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor Diagnostics values | unavailable | Search refused. Would have supplied values by name for A5 and a VAL question; no values-style round is detected, so it would not have added a cheat sheet |
| 2. Quillmoor Diagnostics interview process, operations coordinator | skipped | Hannah's message fixes this session's format and agenda, which is all the persona weights and banks key on |
| 3. Quillmoor Diagnostics strategy and recent news | unavailable | Search refused. Would have supported a CO question; none is in the pack, and the pack says so |
| 4. Hannah Lowther, Quillmoor Diagnostics | unavailable | Search refused. Would have supported an interviewer read and a reverse question tied to her path; both are absent |
| 5. Representative Operations Coordinator JD | skipped | The advert you pasted fixes the fit snapshot and the JD questions |

## Upgrade menu

- Your notice period → F11 and A4 become a stated term instead of an answer slot
- Your CV, or a few lines from it → the medium-confidence rows (F1, F2, F3, F5) get checked against what you have written, and F4, F6 and F8 may become grounded
- The stock-count log showing discrepancies before and after, or whatever record the count was kept in → F3 can rise from medium to high, and C1's four slots can be filled from it
- Whether the stock-count spreadsheet was in Excel → F6 moves from discovery to a story with beats
- Whether you have a lowest salary figure → A3 and E1 get a concrete concession line
- Web search permission, or a pasted company about page → values and strategy for a CO question and a better A5; a deeper research pass would be up to 6 more searches and 2 more fetches, several more minutes
- Hannah's public profile, or her recruiter brief → an interviewer read and a tailored reverse question
- A one-line job-underwriter dossier, if you have one → verified evidence and a named highest objection, in place of the inferred ones here
