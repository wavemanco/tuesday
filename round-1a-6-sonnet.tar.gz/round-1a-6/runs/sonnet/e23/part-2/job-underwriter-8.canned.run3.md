I'll read the skill's reference files first, then give you the full assessment.
Checking whether Velloway Logistics exists, and reading how the skill labels research targets. Then I'll write the assessment.
# Job underwriting: Remote Order Processing Coordinator, Velloway Logistics

## Decision snapshot

**No, don't go ahead. Don't send the IBAN, PPS number, passport photo or any money. Status: `no_go`.** RR1, RR2 and RR3 are each a standard fraud mechanism, and the employer isn't established (RR5).

**Fit ledger.**

- `hard_gate`: unclear: R1 (Income of at least €30,000 a year)
- `must_have`: direct: R2, R3, R4
- `important`: adjacent: R6 (Order processing work); unclear: R5 (A quiet place to work)

What matters: R2, R3 and R4 — your background does match the skills the posting asks for, which is why it reads as plausible; R1 — "up to €26" can't establish €30,000.

**Opportunity ledger.** The cheque (RR1), the upfront payment (RR2) and the request for identity documents before any offer (RR3) are the three severe entries. The employer can't be established (RR5), and the Telegram-only process (RR4) and unverifiable pay (RR6) add to them. The role fails on its own terms, however well you fit it.

- **Hard gates:** none failed; unconfirmed: R1 (Income of at least €30,000 a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR5 (`severity: high`).
- **What would change this:** a Velloway presence you can verify on its own website and domain, with the role listed there; an interview by call or video; no cheque and no payment from you; identity documents requested only after a written offer.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Velloway Logistics: no website, careers page or other footprint found, so existence and size are not established | `[grounded]` search "Velloway Logistics" returned no results |
| Mandate | Process orders remotely, spreadsheets and written English, 15–30 hours a week | `[grounded]` posting |
| Pay | "Up to €26 an hour plus commission"; commission terms not stated | `[grounded]` posting |
| Annualised pay | At €26 an hour, 15 hours a week is €20,280 a year and 30 hours is €40,560. Reaching €30,000 at €26 needs about 22 hours a week. Any lower rate needs more hours | `[inferred]` arithmetic on the posting's own figures, assuming 52 paid weeks |
| Process | Telegram only, no calls. Passport, PPS number and IBAN were requested before the interview. A €349 payment was requested next. The "job" was offered after a chat | `[grounded]` the messages you pasted |
| Contact | Offer follow-up goes to an address on a generic mail domain, not a Velloway domain | `[grounded]` the pasted address |
| Market calibration | Not established. The sweep returned nothing, so no pay band is stated | `[grounded]` empty search result |
| Unknowns | Who the employer is, contract type, commission rules, whether the posting is still live on the original site | — |
| Contradictions | None in the posting itself. The process contradicts it: "payroll set-up" and an equipment purchase were demanded before any offer | `[grounded]` posting against messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Income of at least €30,000 a year (your constraint) | hard_gate | unclear | high | hard_gate | Confidence grades your own stated floor. Fit is unclear because "up to €26", variable hours and unstated commission can't establish it, and the employer can't be verified | `[grounded]` your constraint; `[grounded]` posting | none worth pursuing, given RR1 to RR5 |
| R2 | Strong attention to detail | must_have | direct | medium | none | About 60 Zendesk tickets a day and a weekly team tracker kept accurate. Self-reported, nothing inspectable yet | `[grounded]` your account | none |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep a weekly Excel tracker; the level of Excel skill is not specified | `[grounded]` your account | none |
| R4 | Good written English | must_have | direct | medium | none | Written ticket handling and training two starters, plus the clarity of your messages here | `[grounded]` your account; `[inferred]` that the ticket work was written-heavy | none |
| R5 | A quiet place to work | important | unclear | low | discovery | Not covered by anything you've said. It would be easy to confirm | `[grounded]` silence in your message | none |
| R6 | Order processing work itself | important | adjacent | medium | transferability | Parcel-courier customer service shares order and shipment handling, but you haven't described processing orders directly. The posting says no experience is needed | `[inferred]` from courier ticket work against the posting's duties | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay against your floor (R1, hard_gate) | hard_gate | No fixed rate, hours or commission terms in writing | The gate can't be tested without a real employer and written terms | A written contract from a verifiable employer | A contract on company letterhead from a company you've verified | `[grounded]` posting wording |
| G2 | Workspace (R5, important) | discovery | Not stated | Minor and easy to answer, but moot while the role fails on RR1 to RR5 | Your own workspace | None needed now | `[grounded]` silence in your message |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Cheque with part to keep and the rest to send on | red_flag | high | "We are posting you a cheque for €2,850. Lodge it… keep €350… transfer the rest to our equipment partner" | The cheque may be counterfeit or later reversed by your bank. The transfer you make would be real money, and you would be liable for the loss | `[generic]` a widely documented fake-cheque pattern, not a finding about this sender | Can you give me the bank and account the cheque is drawn on, and the name of the company that issues it? | unresolved |
| RR2 | Employee asked to pay €349 before starting | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages" | Genuine employers supply equipment at their own cost, so the fee may be the purpose of the "job" | `[generic]` advance-fee pattern, not a finding about this sender | Will you ship the equipment at your own cost with no payment from me, and put that in the contract? | unresolved |
| RR3 | IBAN, PPS number and passport photo requested before any interview or offer | red_flag | high | "Before your chat interview, please send your IBAN, your PPS number and a clear photo of your passport" | The documents may be used for identity fraud, or your account may be used to move other people's money | `[generic]` identity-harvesting pattern, not a finding about this sender | Why is payroll set-up needed before an offer, and which company's HR holds the data? | unresolved |
| RR4 | Hiring runs on Telegram only, no calls or video, hired after a chat | risk_signal | medium | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | Taken alone it might just be an informal small firm. Severity is taken at the lower value for that reason. It sits beside RR1 to RR3 | `[generic]` pattern, not a finding about this sender | Can we do one video call with someone from your team, and which company email will the written offer come from? | unresolved |
| RR5 | Employer not established | risk_signal | high | "Velloway Logistics"; contact "velloway.hr@postmail.example" | No footprint was found and the contact address isn't on a company domain. Obscurity alone isn't proof of fraud. Severity is high here because of the combination with RR1 to RR3 | `[grounded]` empty search; `[generic]` that small firms can have thin footprints | Can you point me to this role on your own careers site, and who is the named person I'd report to? | unresolved |
| RR6 | Pay can't be tested against your floor | unknown | — | "Earn up to €26 an hour plus commission" | The real rate may be much lower than the ceiling, and the commission is undefined | `[inferred]` from "up to" and unstated commission terms | What is the guaranteed hourly rate, and how is commission calculated? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Send nothing: no IBAN, PPS number, passport photo or payment. Stop replying and block the handle | See RR1, RR2, RR3 | `[grounded]` register | pending your approval |
| A2 | If the cheque arrives, don't lodge it or spend any of it. If you've already lodged one, tell your bank straight away | See RR1 | `[generic]` how cheque reversals work | pending your approval |
| A3 | Report the listing to the jobs site and the Telegram account to Telegram. Consider reporting to An Garda Síochána. Keep the messages as evidence | Protects others and documents the attempt | `[generic]` standard reporting routes | pending your approval |
| A4 | If you ever shared your PPS number or passport details with anyone about this, tell your bank and the relevant authorities | See RR3. You told me you haven't sent anything, so this is only a contingency | `[generic]` | pending your approval |
| A5 | Search for roles in customer-support operations, dispatch or order coordination that list a real company, a salary figure and a live interview by call or video | Your Zendesk volume, training experience and Excel tracker are genuinely relevant to those, and the skill match in R2 to R4 isn't what's wrong with this one | `[generic]` role-family pattern | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Official site and careers page: does the employer exist as described, is the posting live? | yes | Query "Velloway Logistics" returned no results: employer not established. This moved RR5 |
| 2 | Role-family sweep: market-normal scope, title and pay | yes | Query "remote order processing coordinator Telegram cheque overpayment equipment fee job scam Ireland" returned no results. It moved nothing, so no band is stated |
| 3 | Hiring manager's public footprint | n/a | No person's name was given, only the handle @VellowayHiring |

I'd offer a one-page dossier file (`tuesday-dossier.md`) with this assessment if you want to keep the register. Say so and I'll produce it.

**Upgrade menu**

- The jobs site's name and the posting link would let me check whether it's still live and give you a specific listing to report (RR5).
- Your CV document would raise R2, R3 and R4 from `medium` toward `high`, which only matters for roles worth applying to.
- A deeper company check is available once: up to 5 more searches and 2 more fetches on funding, public reports and news. I wouldn't spend it here, since the register already reaches `no_go` without it.

**Questions**

1. (RR5) Which jobs site was the posting on, and is the listing still visible there?
2. (A5) Would you like me to help you aim at specific role types that clear €30,000 and fit your background? If so, tell me your county or whether you need fully remote.

Answer in text, paste a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.