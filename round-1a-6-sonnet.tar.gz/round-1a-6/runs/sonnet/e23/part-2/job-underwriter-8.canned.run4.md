**Decision snapshot**

- **Decision: `no_go`.** Don't send anything and don't lodge the cheque. This matches the standard fake-cheque and identity-theft job scam. `[grounded]` in your messages.
- **Hard gates:**
  - Your €30,000 floor: `fail`. At the posted rate and hours (15–30 a week, up to €26 an hour), the maths gives about €20,300 a year at 15 hours. It only reaches about €40,000 at the top of both ranges, and "up to" is not a guaranteed rate. `[inferred]`
  - Upfront payment: `fail` against any sensible terms. A real employer doesn't charge you to start.
- **Fit ledger:**
  - Must-have: attention to detail (strong), spreadsheets (strong), written English (adjacent, no sample seen yet).
  - Preferred: none stated.
  - Implied: quiet workspace (unknown).
- **Fit versus quality:** you would be a good candidate for a genuine version of this role. This offer is not one.

**Do not send the IBAN, PPS number or passport photo.** With those three items, someone can open accounts or take out credit in your name, or use your account to move stolen money. Sending the IBAN alone is less risky, but there is no reason to send it.

**Research tier: L0 — no searches**

**Role reality** `[grounded]` unless marked

- **Telegram-only hiring.** A real logistics company will have a company email, a careers page and a named recruiter.
- **ID and bank details before any interview.** Payroll collects these after a signed offer, not before a "chat interview".
- **"Passed our first screening" with no screening.** The only thing they asked for was your documents.
- **€349 for a laptop and headset.** Legitimate employers don't charge for equipment. Paying it by bank transfer to an "equipment partner" is the same pattern.
- **The €2,850 cheque.** This is the core of the scam. The cheque will look as if it has cleared in your account. Days or weeks later the bank discovers it is fake and takes the money back. By then you will have sent about €2,500 of your own money to the scammers, and you are liable for the loss. The €350 "bonus" is bait to make you feel paid.
- **Contact details.** The email is on a placeholder-style domain (`postmail.example`), not a company domain. Nothing connects @VellowayHiring to a verifiable company. `[inferred]`
- **Pay.** €26 an hour for "no experience needed" order processing is well above typical entry-level pay. `[generic]`

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap |
|---|---|---|---|---|---|
| 1 | Attention to detail | must | strong | medium (about 60 tickets a day, CV-level) | none |
| 2 | Spreadsheets | must | strong | medium (you keep the weekly Excel tracker) | none |
| 3 | Written English | must | adjacent | low (no samples) | discovery |
| 4 | Quiet place to work | implied | unknown | none | discovery |
| 5 | €30,000 a year minimum | hard gate | fail | high (arithmetic from the posting) | hard-gate |
| 6 | Pay €349 / forward cheque funds | hard gate | fail | high | hard-gate |

**Gap recovery queue**

- **Rows 1 and 2:** nothing to close. These are the strengths you would use in a real application.
- **Row 3:** a short writing sample or your ticket-reply style would raise it. That only matters for a legitimate role.
- **Rows 5 and 6:** wording cannot fix a hard gate, so there is no gap to close.

**Opportunity risk register**

| Risk | Class | Severity |
|---|---|---|
| Cheque overpayment and forward-the-balance request `[grounded]` | red flag | critical |
| Upfront payment for equipment `[grounded]` | red flag | critical |
| Passport, PPS and IBAN requested before any offer `[grounded]` | red flag | critical |
| Telegram-only process, no calls or video `[grounded]` | red flag | high |
| Employer not independently verifiable `[inferred]` | unknown | high |
| Pay far above the market norm for the role `[generic]` | mismatch | medium |
| Positive signals | none | — |

**Application plan**

Don't apply, and don't reply except to end the contact.

1. **Stop all contact.** Don't argue or explain. You can block @VellowayHiring.
2. **If you sent anything so far.** You said you haven't sent anything, but if that changes:
   - If you paid money, contact your bank immediately.
   - If you shared your passport or PPS number, report it to An Garda Síochána and your bank.
3. **Report the account.** Report the Telegram account and the posting to the jobs site.
4. **Never lodge the cheque, even to "see if it clears".** A cheque that appears as cleared in your account can still be reversed.
5. **Point your real strengths at real roles.** A tracker you maintain, 60 tickets a day, and training two new starters are exactly what customer-operations, order-processing and dispatch-admin employers want. Look for roles with a company email, a named recruiter and a live video interview. Expect to be paid, never to pay.

**Evidence status**

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | skipped | The verdict rests on the messages themselves. A missing company wouldn't change it, and a real one wouldn't make the cheque request legitimate. |
| 2. Role-family sweep | skipped | Not needed for this verdict. Market figures here are `[generic]`. |
| 3. Hiring manager's footprint | n/a | No named person was given. |

If you want to check Velloway yourself, look for an official website and a company email. A scammer can also copy a real firm's name, so a real firm existing proves nothing about this chat.

I can build a `tuesday-dossier.md` of this assessment if you'd like to keep it.

**Upgrade menu**

- **A link to the live posting** would let me check whether it matches what the recruiter described.
- **Research (L1)** would add an employer-existence check, but it can't change this verdict.
- **A CV or writing sample** would raise the written-English row for real applications.

**Questions**

1. Have you already sent anything, such as the IBAN, a document or a payment? That determines what to do next.
2. Would you like help targeting real roles that clear €30,000 a year? If so, tell me your location and whether you want remote work.
3. Would you like help reporting this to the jobs site or the Gardaí?

You can answer any of these briefly, or say "skip".

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.