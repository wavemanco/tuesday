I searched for Velloway Logistics online and found nothing. I then read your messages against the posting. The assessment follows, with the verdict first.

## Decision snapshot

**No, don't go ahead. Treat this as a scam, not a job. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Income of at least €30,000 a year)
- `must_have`: direct: R2, R3, R4
- `important`: unclear: R5 (A quiet place to work)

You would likely qualify for the role as written, which is the usual bait in this kind of scam. The fit ledger doesn't matter here, because the opportunity ledger decides the verdict.

**Opportunity ledger.** Three requests in the messages are advance-fee and fake-cheque patterns: payment of €349 for "equipment" (RR1), a cheque to lodge with most of it sent on (RR2), and your IBAN, PPS number and passport photo requested before any interview (RR3). The Telegram-only process (RR4), an employer I couldn't find (RR5), an off-domain contact address (RR6) and a "job offer" with no real interview (RR7) all point the same way. No positive signals were found.

- **Hard gates:** none failed; unconfirmed: R1 (Income of at least €30,000 a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`).
- **What would change this:** nothing in the messages so far. A real employer doesn't ask a new hire to pay for equipment, or to forward part of a cheque it sent. Those requests would have to be withdrawn, and the company would have to be verifiable, before this was worth reopening. Even then, I'd start again from a clean application.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics": no public footprint found | `[grounded]` search returned no results; not established |
| Role | Remote order processing, 15–30 hours a week, "up to €26 an hour plus commission" | `[grounded]` posting |
| Process | Telegram only, no calls or video, and an offer after chat answers | `[grounded]` posting and messages |
| Pay | "Up to" €26 an hour, commission unquantified. At that top rate €30,000 needs roughly 22 hours a week, every hour, with commission unspecified | `[inferred]` arithmetic from the posting's figures |
| Unknowns | Who the employer is, who pays you, contract type, where the company is registered | — |
| Contradictions | The posting says "no experience needed", yet you "passed screening" and the "interview" with no assessed work | `[grounded]` posting against messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Income of at least €30,000 a year (your constraint) | hard_gate | unclear | high | hard_gate | Confidence grades your own stated constraint. Fit is unclear because the pay is "up to" a rate, over 15–30 hours, with unspecified commission | `[grounded]` your stated constraint; `[inferred]` from the posting's terms | moot given the verdict |
| R2 | Strong attention to detail | must_have | direct | medium | none | Three years at about 60 Zendesk tickets a day is repeated, error-sensitive work, but the claim is self-reported with nothing inspectable | `[grounded]` your account | none |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep the team's weekly tracker in Excel, which is also self-reported | `[grounded]` your account | none |
| R4 | Good written English | must_have | direct | medium | none | Ticket replies are daily written work | `[inferred]` from the Zendesk work | none |
| R5 | A quiet place to work | important | unclear | low | discovery | You haven't said | `[grounded]` silence in your message | none, moot |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Income (R1) | hard_gate | The pay can't be confirmed against your floor | It would matter only if the employer were real | Not applicable | A written contract from a verifiable employer | `[inferred]` |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | You are asked to pay to start work | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | Advance-fee scam: the payment is the goal, and no refund follows | `[generic]` well-known fake-job pattern; the quote is `[grounded]` | Which registered company supplies the equipment, and why can't the employer ship it directly? (Don't ask it expecting a real answer.) | unresolved |
| RR2 | Cheque to lodge, keep a "bonus", send the rest on | red_flag | high | "We are posting you a cheque for €2,850 … keep €350 … transfer the rest to our equipment partner." | Fake or overpayment cheque: your transfer leaves your account quickly and the cheque is later returned, leaving you out the money | `[generic]` well-known pattern; the quote is `[grounded]` | Why would an employer send more than the stated cost and ask you to forward the difference? | unresolved |
| RR3 | IBAN, PPS number and passport photo requested before any interview | red_flag | high | "Before your chat interview, please send your IBAN, your PPS number and a clear photo of your passport" | Identity-theft harvesting. Real employers collect these after a signed contract, not before an interview | `[generic]` hiring practice and known pattern; the quote is `[grounded]` | Where is the signed contract that comes before payroll data? | unresolved |
| RR4 | The whole process runs on Telegram, with no calls or video | risk_signal | medium | "no calls or video interviews" | It avoids being identified or traced. Taken alone it is a risk signal, not proof | `[inferred]` from the posting's own wording | Will you meet by video before any personal data or payment? | unresolved |
| RR5 | Employer not established | risk_signal | medium | "Velloway Logistics" | No web presence was found, and combined with RR1–RR3 this points toward a non-existent entity | `[grounded]` search returned nothing; the hypothesis is `[inferred]` | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR6 | Contact is a webmail-style address, not a company domain | risk_signal | medium | "velloway.hr@postmail.example" | Genuine firms usually use their own domain. This may mean no real company stands behind the address | `[generic]` pattern; the quote is `[grounded]` | Which company domain should I use to verify you? | unresolved |
| RR7 | Offer made after chat answers, with no assessed work | risk_signal | medium | "you passed the interview and the job is yours!" | The "interview" was a formality leading to the payment requests | `[inferred]` from the messages' sequence | What was assessed, and by whom? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't send the IBAN, PPS number or passport photo | see RR3 | `[grounded]` RR3 | proposed |
| A2 | Don't pay the €349 or lodge the cheque. If it arrives anyway, don't deposit it or transfer anything from it | see RR1, RR2 | `[grounded]` RR1, RR2 | proposed |
| A3 | Stop replying, and keep screenshots of the posting and chat | Evidence for a report | `[generic]` | proposed |
| A4 | Report it to your bank's fraud team and An Garda Síochána, report the Telegram account, and tell the jobs site | Others may be targeted, and it helps trace the scheme | `[generic]` | proposed |
| A5 | If you did send any ID image, tell your bank and ask about identity protection | Limits misuse | `[generic]` | proposed |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics remote order processing coordinator", which returned no results, so the employer is not established. Moved RR5 |
| 2. Role-family sweep | skipped | The decision is fixed by the messages themselves, so a market band would move nothing |
| 3. Hiring manager's public footprint | n/a | No name was given |
| Outside targets | yes | Searched for the fake-cheque scam pattern. It returned nothing and moved nothing, so the pattern labels above rest on `[generic]` knowledge, not on a source I retrieved |

I can build a `tuesday-dossier.md` of this assessment if you want to keep it.

**Upgrade menu**

- The link to the live posting and the jobs site's name → RR5, and a more specific report.
- The sender's full email headers or domain details → RR6.
- Your target hours (full-time or part-time) → a real role search against the €30,000 floor. A search for genuine order-processing and customer-operations roles built on your Zendesk and Excel background is an extra I can do if you say yes.

**Questions**

1. For RR5: which jobs site did you find it on? A link would let you report it.
2. For R1: would you want full-time or around 22 hours a week for your €30,000 floor, if we look for real roles?

You can answer in text, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.