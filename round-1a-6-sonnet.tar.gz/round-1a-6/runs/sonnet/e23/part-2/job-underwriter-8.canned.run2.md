I'll read the skill's reference files before building the assessment.
I've read the skill's reference files and I'm now checking whether Velloway Logistics exists, then I'll write up the assessment.
**No, don't go ahead, and don't send anything: RR1, RR2 and RR3 (each `severity: high`) are advance-fee and cheque-overpayment red flags, and I couldn't find the employer. Status: `no_go`.**

# Job Underwriting Assessment: Remote Order Processing Coordinator, Velloway Logistics

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Pay of at least €30,000 a year)
- `must_have`: direct: R2, R3, R4
- `important`: unclear: R5 (A quiet place to work)

R2, R3, R4 — your tickets, tracker and written work map onto the stated tasks; R1 — the hours and the "up to" rate leave €30,000 unestablished.

**Opportunity ledger.** The messages ask you to hand over identity details first (RR2), pay for equipment (RR3) and lodge a cheque and pass most of it on (RR1). The channel is Telegram-only (RR4), and I couldn't establish the employer (RR5). The pay is also well above market for "no experience needed" (RR6).

- **Hard gates:** none failed; unconfirmed: R1 (Pay of at least €30,000 a year)
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`)
- **What would change this:** a verified employer, the same terms confirmed in writing, and nothing in the process asking you to pay or relay money. Paying and relaying money are exactly what RR1 and RR3 describe, so I don't expect this to change.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Velloway Logistics. Searches for the name returned nothing, so I couldn't attribute it to a real company | `[grounded]` searches below returned no results |
| Mandate | Remote order processing, 15–30 hours a week, "set your own hours" | `[grounded]` posting |
| Pay as stated | "Up to €26 an hour plus commission" | `[grounded]` posting |
| Pay against your floor | €30,000 over 52 weeks needs about €19.23 an hour at 30 hours, or about €38.46 at 15 hours. At the posting's top rate and top hours the year would be €40,560. At 15 hours it would be €20,280 | `[inferred]` arithmetic on the posting's own figures, assuming 52 paid weeks |
| Market calibration | A 2026 Irish pay guide (n=1,140) puts order-processing and customer-operations coordinators at a median of €31,200 base, interquartile range €28,400 to €34,100. That is about €15 an hour on a 2,080-hour year, so "up to €26" with no experience is about 70% above it. The guide covers salaried roles only, so it is a rough comparison | `[generic]` Pennoral 2026 pay guide |
| Hiring process | Telegram only, no calls. Identity documents requested before the chat interview | `[grounded]` posting and your messages |
| Contact address | The HR email is on postmail.example, not a Velloway domain | `[grounded]` your message |
| Contradictions | The posting says "no experience needed". The offer, though, came with a cheque and a request to forward funds, which is not how the posting describes the job | `[grounded]` posting against messages |
| Unknowns | Who the employer is, where it is registered, what the contract and pay structure are | `[grounded]` nothing provided |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay of at least €30,000 a year (your non-negotiable) | hard_gate | unclear | high | hard_gate | Confidence grades your own stated floor. Fit is `unclear` because 15–30 hours at "up to" €26 reaches €30,000 only near the top of both | `[grounded]` your constraint and the posting | none; the role fails on RR1–RR3 regardless |
| R2 | Strong attention to detail | must_have | direct | medium | none | Roughly 60 tickets a day in Zendesk and a weekly tracker you keep. Confirmed by you, nothing inspectable yet | `[grounded]` your background | none |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel. Confirmed by you, no artifact seen | `[grounded]` your background | none |
| R4 | Good written English | must_have | direct | medium | none | Written ticket handling at volume, and you trained two new starters. Confirmed by you, no sample seen | `[grounded]` your background | none |
| R5 | A quiet place to work | important | unclear | low | discovery | You haven't said either way | `[grounded]` silence in your message | none; this isn't worth a question while the role fails |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay floor against hours (R1, hard_gate) | hard_gate | The posting gives a top rate and a range of hours but no guaranteed income | Under a real offer, €30,000 would need near-full hours at near-top pay | Not applicable: this is a term, not experience | A written contract stating rate, hours and whether pay is guaranteed | `[grounded]` posting terms; `[inferred]` from the arithmetic in role reality |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Cheque to lodge, most of it forwarded to a third party | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest" | In this scheme the cheque is counterfeit or later fails. The bank then reverses it and you owe the money you transferred out | `[generic]` known overpayment pattern, not a finding about this sender | Why would an employer's first act be to send me money to pass to a supplier? | confirmed in your messages |
| RR2 | Bank, PPS and passport requested before any interview | red_flag | high | "please send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up" | These details are what identity fraud needs, and a real payroll would collect them after a signed contract, not before an interview | `[generic]` pattern, not a finding about this sender | Where is my signed contract, and who is the registered employer collecting these? | confirmed in your messages |
| RR3 | Upfront payment for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages" | The fee is the point of the exercise, and the refund is not expected to arrive | `[generic]` advance-fee pattern, not a finding about this sender | Why am I paying for equipment before I have a contract? | confirmed in your messages |
| RR4 | Telegram-only process with no calls or video | risk_signal | medium | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | This avoids identification of the people behind the job. On its own it is a risk signal, and the severity is lowered for that reason | `[generic]` pattern | Can I speak to a named manager by video before sharing anything? | unresolved |
| RR5 | Employer not established from attributable sources | risk_signal | medium | "Velloway Logistics" | The company may be new, or may not exist as a hiring employer. Combined with RR1–RR3 this is not mere obscurity | `[generic]` pattern for companies of this kind, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR6 | Pay well above the market band for "no experience needed" | risk_signal | medium | "Earn up to €26 an hour plus commission" | The rate may be bait. The guide excludes freelance work, so the gap overstates it slightly | `[generic]` pay guide band against `[grounded]` posting | What is the guaranteed rate and hours, in writing? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Send nothing: no IBAN, PPS number or passport photo, and no payment to the "equipment partner" | See RR2 and RR3 | `[grounded]` register | pending your approval |
| A2 | Do not lodge the cheque. If it arrives, don't deposit it and don't transfer any part of it | See RR1 | `[grounded]` register | pending your approval |
| A3 | Stop replying in the chat, and block and report the Telegram account. Garda reporting for fraud is the usual next step | See RR1–RR3 | `[generic]` general practice, not a claim about this sender | pending your approval |
| A4 | If you already sent anything beyond chat answers, tell your bank promptly | See the closing question | `[generic]` general practice | pending your approval |
| A5 | Look instead for customer-operations or order-processing roles with a named employer, using your Zendesk volume, your trainee coaching and the Excel tracker | See R2, R3, R4 | `[inferred]` from your stated background | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics" and "Remote Order Processing Coordinator Telegram cheque equipment payment job scam". Both returned no results, so the employer is not established (RR5) |
| 2. Role-family sweep | yes | Searched "order processing coordinator Ireland hourly pay", which returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). It set the market calibration and RR6 |
| 3. Hiring manager's public footprint | n/a | No manager's name was given, only a Telegram handle, so there was no query to form |

## Dossier offer

I can write all of this up as `tuesday-dossier.md` if you want a record to keep.

## Upgrade menu

- A link to the live posting, or the site where you found it, would help me check that the posting matches what you were sent (RR5).
- A name for the recruiter, or Velloway's company registration details, would let me check who is behind the account (RR5).
- A deeper check on Velloway for reports from other applicants or news coverage would use up to 5 more searches and 2 more fetches. Say the word and it runs.

RR2 — Apart from answering their questions in the chat, have you sent anything to them, such as documents, personal details or money?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.