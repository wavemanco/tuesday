I'll read the skill's reference files first, so the assessment follows its required format.
**No, this isn't a legitimate job, and you shouldn't go ahead. RR2, RR3 and RR4 (each `severity: high`) together follow the standard employment-scam pattern. Status: `no_go`.**

# Job Underwriting — Remote Order Processing Coordinator, "Velloway Logistics"

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (At least €30,000 a year)
- `must_have` — direct: R2, R3 · adjacent: R4 (Attention to detail)
- `important` — adjacent: R6 (Order processing duties) · unclear: R5 (A quiet place to work)

Fit isn't the problem. R2 and R3 match your evidence; R1 can't be established, because the posting says "up to" and promises no guaranteed hours.

**Opportunity ledger.** The opportunity fails on its own terms. The employer could not be established (RR1). The messages ask for identity documents before any interview (RR2), an upfront payment (RR3), and a cheque you would lodge and partly send on (RR4). The offer came with no real interview, and the contact email is not a company address (RR5, RR6). The pay is out of line with the market (RR7).

- **Hard gates:** none failed; unconfirmed: R1 (At least €30,000 a year).
- **Severe red flags:** RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **Conditions for go:** none. No wording or extra evidence can fix RR2 to RR4, so I'm not offering a conditional path.

**What to do now:**

1. Don't paste your IBAN, and don't send your PPS number or a passport photo.
2. Don't pay the €349.
3. Stop replying to @VellowayHiring and block them.
4. Don't lodge the cheque if it arrives. A cheque like this can be counterfeit, and the bank can reverse it days or weeks after it appears to clear. You would then owe the bank the money you transferred. Lodging it and sending the balance onward can also draw you into laundering the proceeds, even though you did it unknowingly.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics": I couldn't confirm it exists as a logistics employer. The search returned nothing. | `[grounded]` search "Velloway Logistics", no results; not established |
| Mandate | Process orders remotely, in a spreadsheet-based role | `[grounded]` posting |
| Hours and pay | 15–30 hours a week, "up to €26 an hour plus commission", set your own hours | `[grounded]` posting |
| Hiring process | Telegram only, "no calls or video interviews" | `[grounded]` posting |
| Scope read | The tasks are unspecified. The posting gives no systems, volumes, team or manager, and no first-90-days outcomes. | `[inferred]` from what the posting leaves out |
| Market calibration | The Pennoral 2026 Ireland pay guide gives a median base of €31,200 a year (interquartile range €28,400 to €34,100) for salaried order-processing and customer-operations coordinators. That is about €15 an hour on a 40-hour week, so €26 an hour is well above the norm for a role needing no experience. The guide excludes freelance and commission-only work, so the comparison is indicative only. | `[generic]` pay guide; hourly figure `[inferred]` (31,200 ÷ 2,080 hours) |
| Unknowns | Who the employer is, where they are registered, who runs the chat, and what the work involves | — |
| Contradictions | The posting says "full training provided" and "no experience needed", yet the "payroll" step asks for a passport photo. The company says it supplies a "work kit" but asks you to buy it. | `[grounded]` posting and messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | At least €30,000 a year (your constraint) | hard_gate | unclear | high | hard_gate | Confidence grades your own constraint. The posting's "up to €26 an hour" at 15–30 hours leaves a possible range of roughly €20,000 to €40,000, and the €30,000 floor needs about 22 hours a week at the top rate all year. Hours aren't guaranteed. | `[grounded]` posting and your stated floor; `[inferred]` arithmetic (30,000 ÷ 26 ÷ 52) | moot; apply the same test to any real posting |
| R2 | Confident with spreadsheets | must_have | direct | medium | none | You keep the team's weekly tracker in Excel. This is your own account and nothing inspectable has been shown. | `[grounded]` your description | none |
| R3 | Good written English | must_have | direct | medium | none | About 60 Zendesk tickets a day is written customer communication. This is your own account. | `[grounded]` your description | none |
| R4 | Strong attention to detail | must_have | adjacent | medium | transferability | The ticket volume and the tracker suggest accuracy, but you've given no accuracy measure. | `[inferred]` from the ticket volume and tracker | see G1 |
| R5 | A quiet place to work | important | unclear | low | discovery | You haven't said. | `[grounded]` silence in what you sent | none |
| R6 | Order processing duties (implied by the title) | important | adjacent | medium | transferability | Parcel-courier ticket handling sits next to order processing, but it isn't the same work. | `[inferred]` from title and your role | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Attention to detail (R4, must_have) | transferability | Volume and a tracker, with no accuracy measure | A real employer will probe it; this row matters for genuine postings only | A QA or audit score, a low error or reopen rate, or catching errors in the tracker | A figure from your team's reporting, or a manager's comment | `[inferred]` from your description; `[generic]` that employers probe it |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established | risk_signal | medium | "Velloway Logistics" | The firm may not exist, or may be a front. Severity is medium because one search is thin evidence on its own. | `[grounded]` search returned no results; the inference is `[inferred]` | Can you give me your company registration number and a link to the live posting on your own website? | unresolved |
| RR2 | Bank details, PPS number and passport requested before any interview | red_flag | high | "please send your IBAN, your PPS number and a clear photo of your passport" | Identity and account details collected for fraud or mule use. A payroll team doesn't need them before an offer. | `[grounded]` message; `[generic]` how hiring works | Why does payroll need my passport and PPS number before I have a signed contract? | unresolved |
| RR3 | Upfront payment for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner" | Advance-fee scam, with a promised refund that never comes. Legitimate employers don't ask new hires to buy kit. | `[grounded]` message; `[generic]` pattern | Will you ship the equipment to me, and put the terms in a written contract? | unresolved |
| RR4 | Cheque for €2,850, keep €350, send the rest on | red_flag | high | "keep €350 as a welcome bonus and transfer the rest to our equipment partner" | Counterfeit or fraudulent cheque overpayment. You would send about €2,500 of real money before the cheque is reversed. | `[grounded]` message; arithmetic `[inferred]`; pattern `[generic]` | Why would an employer pay me money before I start, only to have me send most of it to a third party? | unresolved |
| RR5 | "Interview" was chat answers, then an immediate offer | risk_signal | medium | "after I answered their questions in the chat … you passed the interview and the job is yours" | No assessment of your skills, so the offer isn't about you. | `[grounded]` your account; `[inferred]` | Who will I report to, and can I speak with them by video before accepting? | unresolved |
| RR6 | Contact email on a non-company domain | risk_signal | medium | "velloway.hr@postmail.example" | A generic mail domain rather than one owned by a firm. | `[grounded]` message | Can you write to me from an email address on your company's own domain? | unresolved |
| RR7 | Pay out of line with the market | risk_signal | medium | "up to €26 an hour plus commission" | Inflated pay to lure applicants; see the market calibration line above. | `[inferred]` against `[generic]` band | What is the guaranteed hourly rate and weekly hours in the contract? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Stop replying, block @VellowayHiring, and don't lodge the cheque if it arrives | see RR2 to RR4 | `[grounded]` register | pending your approval |
| A2 | Report it: to An Garda Síochána, to the jobs site where you found the posting, and to Telegram for the account | Others get targeted by the same ad | `[generic]` standard practice | pending your approval |
| A3 | If you ever did send details or lodge a cheque, contact your bank straight away | Early notice can limit the damage | `[generic]` | pending your approval |
| A4 | Re-run this check on real order-processing or customer-operations postings. Your Zendesk, tracker and training experience fits those, and you can screen for the €30,000 floor first. | see R1 to R6 | `[inferred]` from your background | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics" and got no results, so the employer is not established. It fed the standing entry RR1. No page was fetched. |
| 2. Role-family sweep | yes | I worded the search "remote job Telegram interview send passport IBAN pay equipment fee cheque overpayment scam". It returned only "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). That fed the market calibration and RR7. It returned no scam reports, so RR2 to RR4 rest on the messages themselves and the general pattern. |
| 3. Hiring manager's public footprint | n/a | No name was given. A Telegram handle isn't a name. |

I'd offer to save this as `tuesday-dossier.md` if you want a record to keep or use for other postings.

## Upgrade menu

- Whether you've shared anything so far → settles RR2 to RR4 and the A3 action.
- An accuracy measure from your courier job → R4 moves toward `direct` for real applications.
- Salaried, full-time or part-time preference → R1 can be tested properly on genuine roles.

## Questions

1. **RR2–RR4:** Have you given these contacts anything beyond your chat answers, such as your IBAN, PPS number or a passport photo? Has anything arrived by post?
2. **G1 (R4):** Do you have any accuracy figure from the courier, such as a QA score or reopen rate?
3. **R1:** Do you want full-time salaried work, or is part-time acceptable for the €30,000 floor?

You can answer briefly, skip any of these, or ask me to move on.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.