I can't build an interview pack from this message yet. It also has several marks of a common job scam, so I'd hold off on replying.

**Why it looks like a scam**
- **No company or role.** "Jess" names no employer, job title or pay. The prep skill needs a company and a role title, and this message has neither.
- **Unknown number, and you didn't apply.** "We found your profile online" is the usual opener. Scammers scrape job boards and LinkedIn. Real recruiters usually say which application or posting they're following up on.
- **Interview and contract entirely over WhatsApp, with no calls or video.** Real employers almost always want a live conversation. A text-only process lets a scammer avoid being identified.
- **Pressure to act.** "Tomorrow at 11am" leaves you little time to check anything.

You've sent lots of applications, so the timing feels plausible. That's why this pattern works, but it doesn't make the message genuine.

**Before tomorrow**
1. Don't share your CV, ID, address or bank details. Don't click links, and don't pay for anything such as training, equipment or "processing fees".
2. Ask for the company name, the role, the recruiter's work email and a link to the posting. Then check them yourself on the company's careers page, or on LinkedIn through the company's own page.
3. Insist on a video or phone call. A real recruiter will agree. A scammer will deflect or go quiet.
4. If it falls apart, block the number and report it in WhatsApp. In the UK you can also report it to Action Fraud, or to your country's equivalent.

**What I can do next**
- Draft a short, polite reply asking for those verification details.
- Once you have a real company and role, I'll build the full prep pack: likely questions, how your CV fits the job, and a live practice round.
- If one of your actual applications has produced a genuine interview, send me the company, role title, the job description and your CV. I'll prep you for that one now.

Did the message mention any company or role, or was it exactly what you pasted?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.