I'd hold off on prepping for this one. I haven't built an interview pack, because the message doesn't name a company or a role, and there's nothing to prepare against. It also looks a lot like a known recruitment scam.

**Red flags in the message**
- It comes from an unknown number and gives no company, agency or role.
- "We found your profile online" is vague and could be sent to anyone.
- The interview, the contract and everything else happens only over WhatsApp, with no calls or video. Real recruiters rarely do this, and scammers favour it because there's no voice or face to check.
- The interview is tomorrow at 11am. The short notice is meant to hurry you.
- "Remote, flexible hours" with no details is the usual bait.

I can't tell from here whether Jess is a scammer. But legitimate recruiters can answer basic questions, and scammers usually can't.

**What to do before tomorrow**
1. Reply with questions, not availability: "Which company and agency are you with, and what's the role? Can you email me from a company address?"
2. Check the agency exists. Look for a real website and a LinkedIn page, and see whether Jess appears on its team page. Contact the agency through the details on its own site, not the ones in the chat.
3. Check that the job is listed on the employer's official careers page.
4. Ask for a phone or video call. If Jess refuses or dodges, treat it as a scam.
5. Never send a passport, ID, bank details or your National Insurance or Social Security number. Never pay for equipment, training or "checks". Don't click links or install apps. Typical next steps in this scam are a fake job offer, a request for ID or bank details, or a payment you're told to "process" for them.
6. If it turns out to be a scam, block the number and report it in WhatsApp. You can also report it to your national fraud service, such as Action Fraud in the UK or the FTC in the US.

You may well be right that it's tied to your applications. Check your sent list, though. If no application matches a company or agency named in the reply, that points toward a scam.

**Next step for interview prep**
If Jess comes back with a verifiable company and role, send me those along with the job description and your CV. I'll build a full prep pack for that interview. These would help me most:
1. Which company and role is it, and does it check out?
2. What format will the interview take (call, video or in person), and who will interview you?
3. Can you paste the job description and your CV? I can work without them, but the pack will be weaker.

If you'd like, I can also draft the short verification reply to Jess for you to send.