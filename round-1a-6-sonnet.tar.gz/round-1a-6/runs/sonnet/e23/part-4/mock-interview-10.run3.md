I'll load the interview-prep skill. First, though, the message you got has some warning signs that I want to go through with you.
Before we prep, check that this is a real process. The message has several features common to recruitment scams. I can't verify it either way, and it may be legitimate.

**What stands out**
- **Everything happens on Telegram.** That includes the interview, the offer and the onboarding. Real companies usually use email, a video call or an applicant tracking system, at least for the offer and paperwork.
- **Did you give Lumenvale your Telegram?** A careers-page application normally leads to an email from a company domain. If you never put a Telegram handle on the form, ask yourself how Marcus found you.
- **Onboarding in chat is where these scams usually pay off.** That's typically when they ask for ID scans, bank details or a "deposit". They may also ask you to buy equipment (often with a promised reimbursement), install software, or do paid "training tasks".
- **A text-only interview is unusual for a support role.** It also keeps you away from anyone you could check.

**How to check, before you reply with a time**
1. Find the Customer Support Specialist listing on Lumenvale's own website. Go to the site by searching for it, not through any link Marcus sends. Check that the job is real and that your application can be matched to it.
2. Look for Marcus Hale on LinkedIn, listed under Lumenvale. Look through the application confirmation email too.
3. Reply and ask for the invitation by email from a company-domain address. Ask for the interview to be on a video call, and for the offer to come as a formal letter. A real recruiter won't mind. A scammer will push back, rush you or go quiet.
4. Whatever happens, don't send ID, bank or tax details. Don't pay anything or buy anything, and don't install anything. Real employers don't ask for these before a signed contract, and many never ask for them in chat.

If they pass those checks, the interview itself is worth preparing for.

**Prep notes you can use now**
- **Your strengths:** your 3 years of customer service and roughly 60 contacts a day cover the "2+ years" requirement. Freshdesk is a similar ticketing tool to Zendesk. Training four new starters on refunds is good evidence for escalation confidence and clear communication.
- **Your likely weak spot:** you've never worked for a software company. Expect questions on technical troubleshooting and on learning a product quickly. Prepare one example of picking up a new system or process fast, and be honest that SaaS is new to you.
- **For a text interview:** have two or three short, specific stories ready that show your written clarity. A refund dispute, an angry customer you calmed down, or a time you escalated well would all work. Use your real numbers and don't inflate them.

I held off on the full prep pack, with question banks and answer guidance, until you've confirmed the process is real. Once you have, tell me what you find and who the interviewer is. I'll build the pack then.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.