**Before you prep, I think this message is probably a recruitment scam.** Please don't agree to a time yet.

**Warning signs in the message**
- **Telegram only.** The interview, the offer and the onboarding all happen in one chat. Real software companies use email from their own domain and a video call or a scheduling link. Scammers prefer Telegram because it's hard to trace.
- **No named interviewer or scheduling details.** All it says is "our support team lead".
- **The offer and onboarding happen in the same chat.** In this scam, "onboarding" is usually where they ask for your ID, bank details or tax number, or ask you to buy equipment or pay a fee. Some versions also send you "tasks" or cheques to process.
- **The contact came to you on Telegram.** You applied through a careers page, so a real recruiter would normally write from a company email address.

None of this proves it's fake. But it's enough to verify before you engage.

**How to check**
1. Find the Customer Support Specialist listing on Lumenvale's own website, typed in directly rather than reached through the message. Check that the listing exists and see which recruiting contact or email domain it uses.
2. Email that address, or the one on their official contact page, asking whether Marcus Hale works there and whether they've invited you to interview.
3. Look for Marcus Hale on LinkedIn, tied to Lumenvale. A profile with few connections or one created recently is a bad sign.
4. Ask for an email invitation from a company domain address, and a video or phone interview. A genuine recruiter will say yes. A scammer will stall or push you to stay on Telegram.

**A safe reply if you want to answer**
> "Thanks, Marcus. I'd be glad to go ahead. Could you send the invitation from your Lumenvale email address and let me know the interviewer's name and a video call link? I'll confirm times once I have that."

**Until it's verified**
- Don't send ID, a passport photo, bank details or your national insurance number.
- Don't pay anything or buy equipment.
- Don't install software or click links they send.
- Don't accept any "offer" in the chat.

**If it turns out to be real, this is how I'd prep you**

| Requirement | Your evidence | Strength |
|---|---|---|
| 2+ years in support | 3 years as a customer service advisor | Strong |
| Zendesk or similar | Freshdesk every day | Strong, because it's a close equivalent |
| Clear written communication | Emails at roughly 60 contacts a day, shared with calls | Medium. Get one written example ready. |
| Handling escalations | Nothing yet in what you told me | Open. You need a real story. |
| Software experience (implied) | None | Gap. Bridge it honestly. |

**Questions to rehearse**
1. **"Tell me about a difficult escalation."** Pick a real case and cover the situation, what you did, and the outcome. Which case is up to you.
2. **"You've never worked in software. Why this move?"** Say plainly that you haven't. Then point to what carries over: daily ticketing in Freshdesk, high volume, and explaining things to frustrated customers. Say how you'd learn the product quickly.
3. **"How do you keep written replies clear and warm?"** Use a real example, such as a refund explanation you rewrote or a template you improved.
4. **"Tell me about training the four new starters."** Cover what you taught, how you checked they'd got it, and how they did afterwards. This is your strongest differentiator.
5. **"How do you prioritise about 60 contacts a day?"** Describe your actual method.

Questions for them: What does the first month of onboarding look like? Which products or tools would I support? How are escalations handled between the support team and engineering?

A few answers from you would let me tighten this:
1. Do you have a real escalation example, and if so what happened?
2. Have you shared any documents or personal details with Marcus yet?
3. Do you want a full mock-interview pack, with a live drill where I play the interviewer, once you've confirmed the company is genuine?