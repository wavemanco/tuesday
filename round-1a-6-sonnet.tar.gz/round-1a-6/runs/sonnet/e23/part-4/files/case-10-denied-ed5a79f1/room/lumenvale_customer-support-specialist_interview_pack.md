# Interview pack: Customer Support Specialist, Lumenvale Software

Interviewer: support team lead (name not given), text chat. Built as a hiring-manager-style round, since the lead would be your future manager; no company research was possible, so company-specific questions are absent.

## How to use this pack

- Personas are how a question is asked; types are what is scored. Guidance is scaffolding, not a script: say it in your own words.
- Types: **VAL** values alignment, **EXP** work-experience deep-dive, **JD** role requirements, **CO** company knowledge, **CASE** live problem.
- A text-chat interview rewards short, structured written answers: this is itself a test of "clear written communication". Rehearse typing answers, not just thinking them.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — your message | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message | medium | [grounded] | none | No gap. Lead with the three years and the daily volume in those terms. Expect a probe on the 60 a day. Answer slot: if you know how that figure was counted, say so; if it is an estimate, say it is an estimate |
| F2 | "experience with Zendesk or a similar ticketing tool" — your message | "I use Freshdesk every day" — your message | medium | [grounded] | presentation | Freshdesk is the similar tool, and the words stay there: "I use Freshdesk every day." Answer slot: if you have also used Zendesk, say so; if not, say so plainly and stay with Freshdesk |
| F3 | "clear written communication" — your message | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | Emails are written work, but your material does not show how that writing was judged. Answer slot: if any of your written replies were reviewed, scored or used as examples, say how; if none were, say so plainly and let the chat itself be the evidence |
| F4 | "confidence handling escalations" — your message | none given | none | [grounded] | discovery | Your material says nothing about escalations either way. Answer slot: if you passed on or handled escalated cases, say what the situation was and what you did; if escalations were not part of your role, say so plainly and describe how you would handle one |
| F5 | Familiarity with a software company's product and customers — role-family expectation, no source | "I've never worked for a software company" — your message | none | [generic] | capability | Words: "I haven't worked for a software company." Then how you would learn the product, said as a plan and never as a past |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / live problem | Support lead drops a ticket scenario into the chat and asks what you would reply | Highest: a team lead hires by watching you handle a ticket, and a text chat makes this easy to run live | Structure out loud: acknowledge, diagnose, act, confirm, record. The question needs no claim about your past |
| B. Skeptic | "You've never worked in software, why would you cope?" and probes on escalations | High: F4 and F5 are the visible gaps and a lead is derisking them | State the limit plainly, then the plan to close it. Never add experience |
| C. Conversational | Motivation, why leave energy, why remote | Medium: it opens almost every chat | Short, true, specific answers |

## Question banks

### A. Case / live problem (weight highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in for the third time about the same bug and says they are cancelling. How do you reply?" | CASE | [generic] | Structure it: own the repeat contact, check the earlier tickets before replying, say what you will do and by when, and say what you would pass to the right team. The question needs no claim about your past, so the guidance makes none | Tests F4's requirement as a decision, not a record; generic because it is a pattern, not a fact about this employer |
| A2 | "A customer is angry and the fix is outside your control. Walk me through your next three messages." | CASE | [generic] | Message one acknowledges and sets expectations; message two reports progress or the honest wait; message three confirms resolution or the next owner. Keep each reply short, as it would be in the chat | Written-communication test (F3) delivered live |
| A3 | "How would you decide whether a ticket needs escalating?" | JD | [generic] | Give your criteria as a plan: impact, repeat contact, anything beyond your authority or knowledge. Answer slot: if you used such criteria in your own role, say which; if the decision was never yours, say so plainly and give how you would decide | The JD's escalation line (F4); the slot lets the premise be false |

### B. Skeptic (weight high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've not worked for a software company. Why would you cope with our customers?" | JD | [grounded] "I've never worked for a software company" | The highest-ROI rehearsal in this pack. Hold: "I haven't worked for a software company." Then the plan, said as a plan: what you would learn first and how. Do not claim technical support experience. Hold through two follow-ups by returning to the plan, never by adding to the past | F5 is the gap most likely to be raised; JD because it scores fit to the role |
| B2 | "Have you handled escalations?" | EXP | [grounded] "answering around 60 calls and emails a day" | Say what the quote carries: three years of calls and emails at volume. Answer slot: if any contacts were escalated to you or by you, say what happened and what part was yours; if escalation was not your role, say so plainly and describe how you would handle one | F4 is silent in the material, so this probe is likely; the slot lets the premise be false |
| B3 | "You say about 60 a day. How was that counted?" | EXP | [grounded] "answering around 60 calls and emails a day" | Defend the number precisely: say whether it was tracked or your own estimate, what mix of calls and emails it was, and the weakest assumption in it. If you do not know how it was counted, say so plainly | Every headline figure gets a defend-the-number question (F1) |
| B4 | "Zendesk is our tool. How fast would you pick it up?" | JD | [grounded] "I use Freshdesk every day" | "I use Freshdesk every day." Answer slot: if you have used Zendesk, say so; if not, say so plainly, and say what in Freshdesk you would expect to carry over | F2 is a similar tool, not the named one |

### C. Conversational (weight medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about training new starters." | EXP | [grounded] "I trained four new starters on our refunds process last year" | Tell it at its own scope: four new starters, the refunds process, last year. Answer slot: if you chose how to teach it or what they got wrong, say what; if you followed a set programme, say so plainly. Do not call it managing or leading | Your best concrete sentence; the quote carries training only |
| C2 | "Why customer support, and why software?" | JD | [generic] | Pick what is true for you; one specific reason beats three vague ones. If you do not yet have a reason for software, say so plainly and say what draws you to this role | Motivation opener; generic because it is your reason, not a fact in your material |
| C3 | "How do you work remotely and asynchronously?" | JD | [generic] | Describe how you would organise your day and communicate hand-offs, as a plan. Do not claim past remote experience your message does not state | Remote role; your material does not say whether you have worked remotely |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| 2+ years in customer support | B3, C1 |
| Zendesk or a similar ticketing tool | B4 |
| Clear written communication | A1, A2 (and the chat itself) |
| Confidence handling escalations | A1, A3, B2 |

## Reverse questions

1. "What does a typical first month look like for someone new?" — Lands because it shows you plan to learn the product, which answers F5 without claiming anything.
2. "How are escalations handled between support and the product team?" — Lands because it shows you think about escalation as a process.
3. "Which tools do you use besides the ticketing system?" — Lands because it is practical and covers the Zendesk question.
4. "How is quality measured on written replies?" — Lands because you care about the skill the ad names.
5. "How does the team work across time zones, and is the role fully remote?" — Lands because it is a real logistics point you need.
6. "How will I be paid and onboarded, and what paperwork comes with it?" — Lands because a genuine employer answers this easily and by an official route; see the message for why it matters.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Used Zendesk | Inflated form of F2 | "I use Freshdesk every day." Slot in B4 |
| Handled escalations | Inflated form of F4, which the material is silent on | B2's slot, either branch |
| Worked in software or technical support | Negative you stated, F5 | "I haven't worked for a software company." No slot |
| Managed or led a team | Inflated form of C1's quote, which says trained four new starters | The quote at its own scope |
| That 60 a day was a tracked target | Inflated form of F1 | B3's slot |

## Sources

Provided documents: your message (the invitation text, the ad's requirements as you listed them, your background).

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | Search was declined; would have moved a values cheat sheet |
| 2. `Lumenvale Software interview process customer support` | unavailable | Search was declined; would have moved loop structure and persona weights |
| 3. `Lumenvale Software strategy` / recent news | unavailable | Search was declined; would have moved company questions |
| 4. interviewer name | n/a | No name was given |
| 5. representative Customer Support Specialist JD | skipped | Your list of the ad's requirements fixes the fit snapshot |

Two searches were sent (company existence; company plus Telegram recruitment) and both were refused, so nothing about the company or the message is verified.

## Upgrade menu

- The full job ad text → F1 to F4's requirement quotes become the ad's own words
- The interviewer's name and role → an interviewer read and a tailored reverse question
- Permission to search → values, loop structure and company questions
- Whether you handled escalations, used Zendesk, or have worked remotely → F2 to F4 rows gain quoted evidence
