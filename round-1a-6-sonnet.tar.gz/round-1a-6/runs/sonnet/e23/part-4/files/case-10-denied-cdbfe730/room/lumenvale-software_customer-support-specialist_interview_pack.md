# Interview pack: Customer Support Specialist (remote), Lumenvale Software

Interviewer: the support team lead, name not given. Format, as your message describes it: a text chat on Telegram, with any offer and onboarding in the same chat. Relationship assumed: a hiring-manager-style round, because the lead would be the person you work for or alongside. This is a first version.

## How to use this pack

- Personas describe how a question arrives. Types describe what is being scored.
- Type key: VAL (behavioral, values alignment), EXP (work-experience deep-dive), JD (role and job-ad driven), CO (company and strategy knowledge), CASE (live hypothetical problem).
- Guidance is scaffolding, not a script. Where the guidance says "Answer slot", it is an instruction for the live answer: say it from your own experience, or say plainly that the practice was not yours or did not exist.
- Your interview is typed, so your replies are themselves a sample of your written communication. Keep answers to a few short messages rather than one long block.
- The process (chat-only interview, offer and onboarding in the same chat) is as your message describes it. I could not verify it, and reverse questions R4 and R5 are there to check it.
- Provenance labels: `[grounded]` rests on something you wrote, `[inferred]` is this pack's derivation, `[generic]` is a role-family pattern with no claim about you or this employer.

## Fit snapshot

The job-ad lines below are the four requirements as you listed them in your message. The full ad was not supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — job ad, as you listed it | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message | medium | [grounded] | none | No gap on length, but a line in your message with nothing inspected behind it, so expect a probe on it. Lead with the quote's own terms: three years, an advisor, an energy supplier, calls and emails |
| F2 | "experience with Zendesk or a similar ticketing tool" — job ad, as you listed it | "I use Freshdesk every day" — your message | medium | [grounded] | presentation | The quote names the tool you use in other terms than the ad does, and the words stay there: "I use Freshdesk every day." Answer slot: the ad names Zendesk, so expect a probe on it. If you have used Zendesk, say where; if you have not, say so plainly and stay with Freshdesk |
| F3 | "clear written communication" — job ad, as you listed it | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message | low | [grounded] | discovery | The quote says emails were part of the work and is silent on how clear they were, so the bridge should not be stretched. Answer slot: if anyone commented on your written replies, say who and what they said; if no one did, say so plainly and say how you would approach a written reply to an upset customer. The chat itself is a live sample of your writing |
| F4 | "confidence handling escalations" — job ad, as you listed it | none given | none | [grounded] | discovery | Your material does not show escalations either way, and silence is not an absence. Answer slot: if you have handled any, say what the situation was, who it went to and what you did; if you have not, or it was not yours, say so plainly and say how you would handle one |
| F5 | No line in the ad as you listed it; context for the role, written as plain prose | "I've never worked for a software company" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked for a software company." Then how you would learn it, said as a plan and never as a past. Never a claim to software-company work, and nothing added to make the gap feel smaller |
| F6 | No line in the ad as you listed it; a strength to use, not a requirement | "I trained four new starters on our refunds process last year" — your message | medium | [grounded] | none | Not a job-ad line, so it earns no bridge. Say it in the quote's own terms: four new starters, your refunds process, last year. The material says nothing about how you trained them or how it turned out, so tell only what the sentence states |

## Persona table

The loop rests on your message: one session, a text chat with the support team lead, then offer and onboarding in the same chat. No loop source documents a values round, and no interviewer profile exists, so nothing here is adjusted for a named person.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | Live support scenarios typed into the chat: a repeat complaint, a demand for a manager, a triage order | Weight 5. A hiring-manager-style round starts here, and the ad's written-communication and escalation lines (F3, F4) are the easiest things to test with a live scenario | Clarify first, state your order of steps, think aloud in short messages, and say which judgement call you are least sure of |
| B. Skeptic | Quiet probing of the software-company gap and the escalation silence | Weight 4. Hiring-manager prior, raised by F5 and by F4 having no evidence | Rehearse B1 until it is boring: plain acknowledgment, the quotes at their own scope, a plan for the rest |
| C. Conversational/Rapport | Friendly openers such as "walk me through your journey", in a casual register | Weight 3. A text chat makes casual openers likely, and they are still scored | Prepare a short arc from your own sentences; treat casual questions about the tool and training as scored |
| D. Data-Driven Prober | Pressure on the volume line and on what you do in Freshdesk | Weight 3. F1 carries a headline number, which is a magnet for a "how was that counted" probe | Know what you can and cannot say about how the number was counted, and say plainly when you do not know |
| E. Pressure/Stress | Time-boxed or pushy role-play, "how much was actually you" | Weight 3. Escalation handling is a stated requirement, and a lead may test composure by playing the customer | Pause, restate, hold a position through two follow-ups, then concede specifically |
| G. Values/Behavioral | "Tell me about a time" questions on customer judgement | Weight 2. No values round is documented and Lumenvale's published values were not read, so these are generic | Use the selection scaffolds, and give the honest branch where no story comes to mind |

## Question banks

Highest-ROI prep in this pack: B1. The software-company gap is the objection most likely to be put to you in some form, and a calm, short, honest answer to it changes the whole chat.

### A. Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in for the third time about the same unresolved problem and says they will cancel. Type me the reply you would send." | CASE | [generic] | Write it as you would send it, in short plain sentences: acknowledge the specific problem and the repeat contact in your own words, say what you will do next and by when (only what is within your control), and end with one clear next step. One clarifying question is enough if you need it. In this chat the reply is itself the sample of your writing, so keep it unpadded | Tests the written-communication line (F3) with the output visible live; CASE because it is a live problem, with JD content |
| A2 | "A customer rejects your answer and demands a manager. Do you escalate, and what do you send along with it?" | CASE | [generic] | Think aloud in order: what you would check before deciding, what makes this an escalation rather than a hold, what you tell the customer about what happens next without promising an outcome, and what goes in the handover so the next person does not have to ask the customer to repeat themselves. Name the judgement call you are least sure of | The ad's escalation line (F4) has no evidence behind it, so a scenario lets you answer from reasoning without claiming a past. CASE with JD content |
| A3 | "It is your second week and a customer asks about something in our product that you do not know. What do you do in the next ten minutes?" | CASE | [generic] | Say what you would check first, who you would ask, and what you would tell the customer meanwhile: an honest holding reply rather than a guess. Add how you would note the answer so it is not lost. It needs no claim about your past, and the guidance makes none | Probes the product-knowledge side of the gap in F5 through a live problem, which is gentler and more useful to rehearse than the direct version in B1 |
| A4 | "Ten messages arrive at once: a password reset, an angry repeat contact, and a message saying something is broken for a whole team. How do you order them, and what do you say to each?" | CASE | [generic] | Clarify first what priority rules the team has. Then give your ordering with the reason for each step, a one-line holding reply for the ones that wait, and the assumption behind your order that you would defend least | F1 is the volume line, and this tests how volume gets triaged. CASE because it is a live problem |
| A5 | "A customer writes: 'Your update broke everything and nobody answers.' Turn that into a three-line summary a colleague in another team could act on." | CASE | [generic] | Three lines: what the customer reports in their words, what is not yet known, and what you need next and from whom. Keep to what the customer actually said; leave out the emotion and the guesses about the cause | Scores written clarity (F3) and handover habits for the ticketing tool (F2) in one short task. CASE with JD content |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "I see your background is at an energy supplier and you haven't worked for a software company. What would be hardest for you in your first month?" | JD | [grounded] "I've never worked for a software company" and "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" and "I use Freshdesk every day" | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment: "I've never worked for a software company." Then hold only what the quotes carry: three years as a customer service advisor at an energy supplier, calls and emails, and Freshdesk every day. Then a plan, said as a plan: what you would learn first about the product and how you would go about it. Follow-up on whether this would slow the team: hold, and return to the same quotes without adding to them. Follow-up that software support is different: concede specifically, in your own words, for instance "That's fair. I've never worked for a software company, so I would expect to learn how this team works from the start", then hold the three years and the tool. Follow-up comparing you with someone who has software experience: do not compare, return to the quotes | F5 is the biggest gap and this objection is likely to be put to you in some form. JD because it scores fit against the role as the ad describes it |
| B2 | "The ad mentions Zendesk or something similar. Have you used Zendesk?" | JD | [grounded] "I use Freshdesk every day" | Say it in the quote's own words: "I use Freshdesk every day." Answer slot: the ad names Zendesk, so expect this probe. If you have used Zendesk, say where; if you have not, say so plainly and stay with Freshdesk. Hold through a second follow-up by returning to Freshdesk, never by adding to it | F2 is the evidence for the tool requirement and the likeliest place for a literal reading of the ad. JD because it scores a stated requirement |
| B3 | "Tell me about a time you handled an escalation." | JD | [generic] | Selection scaffold: pick a time a customer's issue went beyond what you could settle or they asked for someone senior. It needs a named situation, what you did, who it went to and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle one | The ad's escalation line (F4) has no evidence, so the scaffold prepares both honest branches before the probe arrives. JD content with EXP delivery |
| B4 | "Why software, and why Lumenvale, after working in energy?" | JD | [generic] | Selection scaffold: give one concrete reason you want support work at a software company, and one thing you have actually looked at about Lumenvale's product or site. If you have not looked at the product yet, say so plainly and do that before the chat. Do not claim familiarity you do not have | Skeptics test motivation consistency, and F5 makes the question likely. JD because it scores fit with this role |

### C. Conversational/Rapport (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your journey so far and what brought you to this role." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" and "I trained four new starters on our refunds process last year" and "I use Freshdesk every day" | A short arc from your own sentences: three years as a customer service advisor at an energy supplier, calls and emails, four new starters trained on your refunds process, and Freshdesk every day. Then one honest sentence on why this role, in your own words. Add nothing about results or reasons the sentences do not state | F1, F2 and F6 are the sentences the arc stands on. EXP because it is the biography question, and it is scored even though it feels casual |
| C2 | "I see you trained some new starters. Tell me about that." | EXP | [grounded] "I trained four new starters on our refunds process last year" | Tell it with the beats the sentence states: four new starters, your refunds process, last year, in your own words. The sentence carries no further beats, so the story has only those. If asked how it went or how you did it, answer from what actually happened | F6 is the only evidence of showing others how you work, and the likeliest friendly follow-up. EXP because it checks the claim in your own words |
| C3 | "What makes a good written reply to a customer, in your view?" | JD | [generic] | State two or three standards you actually follow when you write to customers, in plain words, and keep it to what you do rather than what you always do. Avoid describing your replies as clear or excellent; let the interviewer judge that from your typing in this chat | F3 is the written-communication line and the chat is the sample. JD because it scores a stated requirement, in a casual register |

### D. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You say around 60 calls and emails a day. How was that counted?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Say the figure as you wrote it: around 60 calls and emails a day. Answer slot: say how it was counted, what it is sensitive to, which assumption behind it you would defend least, and which part of the volume was yours. "I don't know how it was counted" is an honest answer. Never describe a counting method you did not use | F1 carries the headline number, which is where a prober starts. EXP because it tests attribution, and the figure is yours to explain only as far as you know |
| D2 | "Tell me about your Freshdesk use. What do you actually do in it each day?" | EXP | [grounded] "I use Freshdesk every day" | Say "I use Freshdesk every day." Answer slot: the ad names a ticketing tool, so expect a probe on what you do in it. Say what you do there, in your own words; if you use it in a narrower way than the probe assumes, say so plainly and stay with the quote | F2 is the evidence for the tool requirement and gets probed on depth. EXP because it tests whether the claim survives detail |
| D3 | "Walk me through what happens to a customer email from the moment you open it to the moment it is closed." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Answer slot: describe the steps you actually follow, in order, in your own words. If some steps are done by someone else or by a system, say so plainly; if there is no step you would name, say so and describe what you do first | F1 and F2 are the evidence, and a prober checks the day-to-day behind them. EXP because it tests whether the volume figure matches a real workflow |

### E. Pressure/Stress (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "In three short messages: why should we pick you over someone who has worked in software support?" | JD | [grounded] "I've never worked for a software company" and "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Hold, then concede. Hold the quotes: three years as a customer service advisor at an energy supplier, calls and emails. Concede the plain fact: "I've never worked for a software company." Do not claim an equivalence and do not argue the comparison. Hold through two follow-ups by returning to the same sentences | B1 under time pressure, and it tests composure more than content, per F5. JD content with pressure delivery |
| E2 | Interviewer plays the customer: "This is the fourth time I've written. I want my refund today." | CASE | [generic] | Pause before replying. Acknowledge the repeat contact in your own words, say what you can and cannot do today without promising what you cannot authorise, and say what happens next and when. Hold through two pushes, then concede specifically what you cannot give | Escalation confidence (F4) tested live, with no claim about your past. CASE with pressure delivery |
| E3 | "How much of that new-starter training was actually you?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Hold the sentence: "I trained four new starters on our refunds process last year." Answer slot: if any of it was shared, or used materials someone else wrote, say so plainly; if all of it was yours, say that. Hold through the second follow-up by returning to the sentence, never by adding to it | F6 is the attribution target, and an attribution probe fits it naturally. EXP because it tests attribution honesty |

### G. Values/Behavioral (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "When did you put a customer ahead of an internal rule or target?" | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not simply follow the rule, and a customer relationship still intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Use "we" for context and "I" for your own part | Persona stem for the Values/Behavioral style; no values round is documented, so this is `[generic]` and low-weight. VAL because it scores judgement in the customer's interest |
| G2 | "Tell me about a time you had to give a customer an answer they did not want." | VAL | [generic] | Selection scaffold: pick a time you had to say no or not yet, with the reason, how you said it and how the customer took it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Adapted persona stem on delivering a hard message; it also exercises the written-communication line (F3) in story form. VAL with JD content |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| "2+ years in customer support" (F1) | C1, D1, D3, E1 |
| "experience with Zendesk or a similar ticketing tool" (F2) | B2, D2, D3, A5 |
| "clear written communication" (F3) | A1, A5, C3, G2 |
| "confidence handling escalations" (F4) | A2, B3, E2 |
| Software-company context, no line in the ad as you listed it (F5) | B1, B4, A3, E1 |
| Training, a strength and not a requirement (F6) | C1, C2, E3 |
| The headline figure in F1 | D1 |

## Reverse questions

Your interviewer is unnamed and the loop is a single chat, so these are role-generic. R4 and R5 check the process itself.

| # | Question to ask | Why it lands |
|---|---|---|
| R1 | "What would my first week look like: which queue, which product areas, and who would I shadow?" | Shows you are planning to be useful quickly, and turns the product-knowledge gap in F5 into a ramp conversation |
| R2 | "What does good look like at 90 days for this role, and how is it measured?" | Signals you want a clear bar, and gives you a target to prepare against |
| R3 | "How does escalation work on this team: when does an agent hand a ticket on, to whom, and what happens afterwards?" | Shows interest in the part of the job the ad stresses (F4), and tells you how much judgement the role carries |
| R4 | "Could we also do a short video call, and could you point me to where this role is listed on the Lumenvale website?" | Whatever the answer, you learn whether this process can be checked outside Telegram, and you hear how they handle a reasonable request |
| R5 | "Could I see the contract, pay, hours and employer details in writing before I send any personal documents or bank details?" | Gets the terms in writing before you hand over anything sensitive, and shows you what the answer to a normal request looks like |
| R6 | "What training is there on the product and the tools in the first month?" | Puts the F5 gap on the table early, in the register of a colleague planning to learn |
| R7 | "How is the support team organised, and who would I report to day to day?" | A fair question for a text-chat round with the person who may lead the team, and it tells you who you would actually work with |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Experience working for a software company | Negative the candidate stated, F5 | The plain acknowledgment F5 gives: "I've never worked for a software company." No slot |
| Handling 60 tickets, or resolving 60 contacts, a day | Inflated form of F1 | F1's quote at its own scope: "around 60 calls and emails a day." The limit is the pack's observation: your material says calls and emails, not tickets or resolutions. D1's slot asks only how the figure was counted |
| Leading, designing or running a training programme | Inflated form of F6 | F6's quote at its own scope: "I trained four new starters on our refunds process last year." The limit is the pack's observation: your material says the training, not who designed it or how it went. E3's slot asks only how much was yours |
| Being a clear or strong written communicator | Inflated form of F3 | F3's quote at its own scope: "answering around 60 calls and emails a day." The limit is the pack's observation: your material says emails, not how clear they were |

## Sources

Provided documents: the Telegram message as you pasted it, the four job-ad requirements as you listed them, and your background paragraph. No full job ad, CV or interviewer profile was supplied.

Searches sent, both refused, so nothing came back from either:

- "Lumenvale Software company customer support" — refused
- "fake recruiter Telegram job interview scam customer support onboarding in chat red flags" — refused

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | No search was sent for it, since search was refused. It would have decided whether a values cheat sheet applies; none was built |
| 2. `Lumenvale Software interview process customer support` | unavailable | No search was sent for it, since search was refused. The loop rests on your message alone, and persona weights follow it |
| 3. `Lumenvale Software strategy` / recent news | unavailable | No search was sent for it, since search was refused. It would have fed a CO question; none is in the banks |
| 4. interviewer name | n/a | No interviewer name was given, since the support team lead is unnamed, so there was no query to form; the interviewer read is absent |
| 5. representative `Customer Support Specialist` JD | skipped | The four requirements you listed fix the fit snapshot and the JD-tagged questions |
| Un-numbered: the two refused calls above | unavailable | Both were sent outside the declared targets and returned nothing; they moved nothing |

Company identity, recruiter identity and loop structure are all not established beyond what your message says.

## Upgrade menu

- The full job ad text → F1 to F4 become verbatim ad lines instead of your summary, and any hours, time zone, pay or location terms become fit rows
- Your CV → F3 and F4 may gain quoted evidence, and several `[generic]` questions could become story-mapped
- Your answers to the F3 and F4 answer slots (any written feedback you received, any escalation you handled) → the F3 and F4 rows, A2, B3 and A1 regenerate around what you say
- The support team lead's name or public profile → an interviewer read, persona weights adjusted to them, and a reverse question tied to their path
- Lumenvale's careers page or published values pasted in → a values cheat sheet if a values-style round is documented, and VAL questions that are `[grounded]` instead of `[generic]`
- A deeper research pass (L2; up to 6 more searches and 2 more fetches, several more minutes, needs search permission) → a company strategy brief, CO questions and a grounding section
- A recruiter or careers-page statement of the process and round format → confirms or replaces the single-chat assumption the persona weights rest on
- Your prep time → a prioritised prep triage
- A `tuesday-dossier.md` from the job-underwriter skill → verified evidence and a sourced prohibited-claims list, which would sharpen B1 and the fit snapshot
