I'm writing the prep pack to a file now. The three company-research searches were refused, so the pack will rest on what you sent me.
Before the prep, one thing in the invite. It asks you to "transfer the €95 equipment registration fee to our supplier's account, IBAN ...", to "reply with a photo of your passport and your bank details before the interview", and says "you deposit the cheque and send the balance on to the vendor". A fee up front, passport and bank details before any offer, and a cheque you deposit and then send money on from are a known scam pattern. The fee, the passport and bank details, and the cheque are very likely a scam. Please hold all three until you've checked the invite with the employer, using contact details you find yourself on its own website or careers page. Don't use the email address or any other contact in the invite, and don't rely on the sender's replies. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite's requests weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as `/var/tmp/tuesday-measure/1a6/runs/sonnet/tuesday/part-5/rooms/case-12-denied-e47e833d/brennock-facilities_remote-administrative-assistant_interview_pack.md`. It has 18 practice questions, a fit table of the ad's four duties against what you told me, and six questions for you to ask them.

**What to expect:**
- **Format and style:** The invite describes one 30-minute video call with the office manager. I assumed a hiring-manager style, so expect short practical scenarios: a diary clash, arranging a trip, finding overdue invoices in a spreadsheet.
- **Your strongest ground:** "I ran the appointment book for four physios" fits the calendar duty. Your Word and Excel levels are your own words, so you can state them plainly.
- **Your thinnest ground:** Travel booking isn't in your material at all. You chased unpaid invoices, but the job is processing supplier invoices, which is a different task. The most likely question is "Which part of this job would you be weakest at on day one?" Rehearse that one first (B1).

**Research:** The three company searches were refused, so the pack rests on what you sent me and has no company-specific facts.

I can play the office manager and run a live drill on B1 or any other question. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to Word.

Can you paste the ad's full text? It would let me replace my summary of the four duties with the ad's own wording, and add any duties I've missed.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: brennock-facilities_remote-administrative-assistant_interview_pack.md -----
# Interview pack: Remote Administrative Assistant, Brennock Facilities Ltd

Interviewer: the office manager, name not given. Format: a 30-minute video call, in the invite's words. Built for one session. The pack assumes the office manager interviews in a hiring-manager style, because the invite says nothing about the relationship.

## How to use this pack

Personas describe how a question arrives. Types describe what it is scoring. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Whether past behaviour shows the company's published values. None in this pack: no values round is documented and no values page was read |
| EXP | Whether your own account of your work holds up under follow-up |
| JD | Whether you can do the listed duties, gaps included |
| CO | Company and strategy knowledge. None in this pack: the research searches were refused, so nothing here rests on company facts |
| CASE | A live problem set in the role, answered by structure and reasoning |

Highest-ROI prep: B1, "Which part of this job would you be weakest at on day one?". It will be asked in some form, and it aims at where your material is thinnest (F2 and F5 below). A rehearsed, calm answer changes the interview.

## Fit snapshot

Requirements come from the ad's four duties as you described them to me; the full ad text was not supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as you described it | "I ran the appointment book for four physios" — your message | medium | [grounded] | presentation | Your words already reach the requirement in other terms, so use them as they stand: "I ran the appointment book for four physios." Nothing is added to them, and nothing about how the book was run is claimed. Expect a probe on what that covered (A4) |
| F2 | "booking travel" — the ad, as you described it | none given | none | [grounded] | discovery | Your material does not show this either way. Answer slot: the ad's travel line makes a probe likely. If you have booked travel for anyone, say who for and how you went about it, in your own words; if not, say so plainly and stay with the appointment book you ran |
| F3 | "preparing documents in Word and Excel" — the ad, as you described it | "I'm good with Word" — your message | low | [inferred] | discovery | Your quote gives a level, not a use, so the bridge is a slot. Answer slot: the ad's Word-and-Excel line makes a probe on what you use Word for likely. Say what, in your own words; if the honest answer is little, say so plainly and stay with "I'm good with Word" |
| F4 | "preparing documents in Word and Excel" — the ad, as you described it | "okay with Excel" — your message | low | [inferred] | discovery | Same shape as F3, and "okay" is your own word for your level, so keep it. Answer slot: say what you have used Excel for, in your own words; if the honest answer is little, say so plainly, keep "okay with Excel", and say how you would build it up as a plan, not as a past |
| F5 | "processing supplier invoices" — the ad, as you described it | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Your material says chasing unpaid invoices, not processing supplier invoices, and the words stay at the first: "I chased unpaid invoices." Answer slot: the ad's invoice line makes a probe on your invoice work likely. Say which invoices you chased and what the chasing consisted of, in your own words; if your part was the chasing and nothing more, say so plainly and stay there |

## Persona table

| Persona | How it shows up here | Likelihood and reasoning | Provenance | Counter-strategy |
|---|---|---|---|---|
| A. Case / Strategist | Small live scenarios from the four duties: a diary clash, a trip to arrange, a spreadsheet to check | High. The ad lists four practical duties and the call is 30 minutes, so scenarios are the quickest way to test them. Assumes a hiring-manager style | [inferred] | Clarify first, then the objective, then your approach, then what could go wrong. Think aloud. No scenario here needs a claim about your past |
| B. Skeptic | Probes the gap between a clinic reception and this job: day-one weakness, why this move, remote working | High. F2 and F5 are the thinnest rows, and the ad's duties are specific | [inferred] | Rehearse B1 until it is boring. Bridge only from F1 and F5 at their own scope, and say the limit plainly |
| C. Conversational | Warm openers on a video call: the biography question, the Word and Excel question | Medium. Casual questions on the ad's own topics are still scored | [inferred] | A 90-second arc built only from your quoted sentences (C1). Treat the casual Word and Excel question as scored |
| D. Data-Driven Prober | Asks how things were counted and how an invoice was chased, and tests Excel with a small task | Medium. You gave a count, four physios, and the ad names invoices and Excel | [inferred] | Say what you know and say plainly what you do not. Never give a figure you cannot repeat under a second question |
| E. Pressure | Time-boxed "why you" and "how much was you" | Low to medium. A 30-minute call leaves little room for it | [inferred] | Pause, restate, hold what your quotes carry through two follow-ups, concede the newer parts in your own words |
| F. Peer Evaluator | Day-to-day working questions, such as what you decide and what you check | Low. The office manager may also be the person you work beside | [inferred] | Reciprocity: what you need from them and what you will offer them. Propose working principles, not claims about a past |

## Question banks

### A. Case / Strategist (heaviest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Your manager and a colleague each ask you to hold the same one-hour slot tomorrow, and neither knows about the other. What do you do?" | CASE | [generic] | Clarify before acting: whose request is it, is either movable, is there a rule for who comes first. Then propose: check with whoever owns the priorities, offer the other person the nearest alternatives, tell both once it is settled, and note the decision. The question needs no claim about your past, so the guidance makes none | Tests the ad's calendars duty (F1) as a decision rather than a record. CASE because it is a live problem, and `[generic]` because it is a pattern, not a fact about this employer |
| A2 | "A colleague asks you to book a two-day trip to Galway next week. What do you need to know before you book anything?" | CASE | [generic] | Ask first: the fixed times, who is travelling, any budget or approved supplier, preferences, and whether a refundable fare is wanted. Then offer two options, confirm the choice, send the itinerary, and record the cost. The question needs no claim about your past, so the guidance makes none | The ad's travel line (F2) is where your material is silent. This lets you show method without claiming experience |
| A3 | "Tell me about a time you booked travel or arranged something for someone else." | EXP | [grounded] "I ran the appointment book for four physios" | Selection scaffold: pick a time you arranged something for someone else with a named constraint, say what the constraint was and what you did, in your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I ran the appointment book for four physios", or say how you would handle it | The theme comes from the ad's travel duty, and F2 holds no evidence. EXP because it tests whether a real instance exists |
| A4 | "Walk me through how you ran the appointment book for four physios." | EXP | [grounded] "I ran the appointment book for four physios" | Story-mapped on F1: the book, and the four physios, which are the beats the quote states. Tell them in your own words. Answer slot: the ad's calendars line makes a probe on which parts of running the book were yours to decide likely. If any were, say which and how you decided; if none were, or it was not yours, say so plainly and describe how you ran the book | F1 is the evidence for the calendars duty and the likeliest place to be probed. EXP because it tests what was actually yours |
| A5 | "Here is a spreadsheet of this month's supplier invoices. How would you find the ones that are overdue?" | CASE | [generic] | Ask first: which columns hold the invoice date, due date and status, and what counts as overdue. Then sort or filter by due date, look for anything already paid, list what is left, and flag it to your manager rather than acting on it. Say the steps you actually know; if you are unsure of a function, say what you would look up | A live version of the invoice and Excel duties (F4, F5). It presupposes nothing about your past |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "chased unpaid invoices"; "okay with Excel" | The highest-ROI rehearsal in this pack. Name one of the four duties plainly, in your own words, before they do. The pack does not choose it for you, but its own observation is that your material is thinnest on travel and on supplier invoices. Hold what you do have at its own scope: "I chased unpaid invoices", "okay with Excel". Then give a ramp plan as a plan, not a past: what you would ask for or practise in the first week. Hold through two follow-ups; do not widen the quotes to look stronger | The Skeptic stem aimed at F2 and F5, the thinnest rows. JD because it scores the stated duties, gaps included |
| B2 | "You've spent two years in a clinic reception. Why this role, and why now?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | Three beats. First, where you are now, in the quote's words. Second, your actual reason for this role, in your own words: the pack supplies none. Third, keep it about the work in the ad, and do not criticise the clinic. Answer slot: if your reason is about the work itself, name which duty draws you; if it is something else, say that plainly | The motivation-consistency probe every Skeptic runs. EXP because it tests whether your own account holds together |
| B3 | "This role is remote. How do you keep on top of your work when nobody is beside you?" | JD | [grounded] the role title, "Remote Administrative Assistant" | Selection scaffold: pick a time you worked without anyone checking in, with a named stake, what you did to keep track and what you did when you were stuck. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or describe how you would set up your week and when you would report in | The title makes remote working part of the job. The guidance claims nothing about your past because your material is silent on it |

### C. Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, tell me a bit about yourself and how you came to apply." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic"; "I ran the appointment book for four physios"; "chased unpaid invoices" | A 90-second arc in three beats, each in your own words: the two years as a receptionist at the clinic, the appointment book for four physios, the unpaid invoices you chased. Fourth beat, answer slot: why this role, in your own words. Stop there and let them ask | Every Conversational interviewer opens like this, and the quotes carry the whole arc. EXP because it is your own account |
| C2 | "How would you describe your Word and Excel skills?" | JD | [grounded] "I'm good with Word, okay with Excel" | Give the two level words as you said them: good with Word, okay with Excel. Answer slot: the ad's Word-and-Excel line makes a probe on what you use each for likely. Say what, in your own words; if the honest answer is little for either, say so plainly, stay with the level word, and say how you would build it up | Covers the Word and Excel duty (F3, F4). It is casual in register and scored all the same |
| C3 | "What would a good first month look like for you in this job?" | JD | [generic] | Structure it: learn the four duties and how this office does each, learn your manager's preferences, take on the routine items first and ask on anything involving money or other people's commitments, and agree a check-in. This is a plan and claims nothing about your past | Open-ended and low-risk, and it lets you show how you would ramp up where F2 and F5 are thin |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How many appointments went through that book in a typical week?" | EXP | [grounded] "I ran the appointment book for four physios" | The defend-the-number move, in your own words. Answer slot: give a number only if you know it, and say how you know it. "I don't know the exact figure" is an honest answer. If you do give one, name the assumption behind it that you would defend least. Never offer a figure you could not repeat under a second question | Your quote gives a count, four physios, and a prober tests counts. F1 is the row it draws on |
| D2 | "Walk me through how you chased an unpaid invoice." | EXP | [grounded] "chased unpaid invoices" | Story-mapped on F5 at its own scope: you chased unpaid invoices. Answer slot: the ad's invoice line makes a probe on what the chasing consisted of likely. Say what you did, in your own words; if any part was not yours, say so plainly and stay with the part that was | F5 is the nearest evidence for the invoice duty. EXP because it tests what was actually yours |
| D3 | "In Excel, how would you check a list of invoices for duplicates?" | JD | [grounded] "okay with Excel" | Say the steps you actually know, at the level you called "okay". If you do not know the function, say so, say what you would look up or ask, and say how you would check the result. Do not bluff a formula | A small tool test on the Excel and invoice duties (F4, F5). It presupposes nothing about your past |

### E. Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you rather than someone who has done this exact job before?" | JD | [grounded] "I ran the appointment book for four physios"; "chased unpaid invoices" | Pause and restate the question. Hold on those two sentences at their own scope through two follow-ups. Then concede, specifically and in your own words, which of the four duties is newer to you. The pack does not name it for you, and it never claims the duties your material is silent on | The hold-then-concede structure. The position held is only what the quotes carry |
| E2 | "How much of running that appointment book was actually you?" | EXP | [grounded] "I ran the appointment book for four physios" | Hold the sentence as you said it, "I ran the appointment book for four physios", through two follow-ups. Answer slot: if anyone shared any part of it, say who and which part, in your own words; if nobody did, say so plainly. Do not add detail to sound larger | The attribution probe built to catch inflation. F1 is the row it draws on |

### F. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Where would you draw the line between what you decide yourself and what you check with me first?" | CASE | [generic] | Propose principles and ask which they prefer: routine items you handle, and anything that spends money or changes someone else's commitments you check first. Agree it up front and revisit it after a few weeks. This is a way of working and claims nothing about your past | A peer or manager probes the seam of responsibility. It is a live problem, so it presupposes nothing |
| F2 | "What would you need from me to do this job well?" | JD | [generic] | Reciprocity: ask for clear priorities, the format they prefer for requests, and any approval limits. Then offer something back, such as a short weekly note of what is booked and what is waiting. These are working proposals, not claims about your past | Shows partnership instead of dependence. Peers also price what a hire adds to their own load |

### Requirement coverage

| Requirement | Questions |
|---|---|
| managing calendars | A1, A4, D1, F1 |
| booking travel | A2, A3 |
| preparing documents in Word | C2 |
| preparing documents in Excel | C2, A5, D3 |
| processing supplier invoices | A5, B1, D2, D3 |
| remote working (from the role title) | B3 |

## Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| R1 | "Of the four duties, which takes most of the week for the person in this role?" | Shows you listened to the ad and tells you where to spend your practice time |
| R2 | "Which calendar, travel and invoice tools would I be working in from week one?" | Names the tools you can practise before day one, which matters most where you are newest (F2, F5) |
| R3 | "How are supplier invoices approved before they are paid, and where would I fit in that?" | A working question about control that shows care with money and clarifies the invoice duty |
| R4 | "What would you want me to have learned by the end of the first month?" | Turns the interview into planning together, and signals you are already thinking about ramp-up |
| R5 | "What could a new person do in their first month that would genuinely help you?" | The reciprocity question for a possible peer: it asks what you can add to their load, not only what you need |
| R6 | "How does the team keep in touch day to day when the role is remote: check-ins, a shared inbox, a daily message?" | Shows you have thought about working remotely and gives you the rhythm to plan around (B3) |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed calendars | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios." The limit is the pack's observation: your material says an appointment book for four physios, not calendars. A4's slot stays inside the book |
| Processed supplier invoices | Inflated form of F5 | F5's quote at its own scope: "chased unpaid invoices." The limit is the pack's observation: your material says chasing unpaid invoices, not processing supplier invoices. D2's slot stays inside the chasing |
| Prepared documents in Word | Inflated form of F3 | F3's quote at its own scope: "I'm good with Word." The limit is the pack's observation: your material gives a level, not documents prepared. C2's slot asks only what you use it for |
| Prepared documents or reports in Excel | Inflated form of F4 | F4's quote at its own scope: "okay with Excel." The limit is the pack's observation: your material gives a level word, not a use |

## Sources

Provided: your message, which carried the invite's text, the ad's four duties as you described them, and your background. No dossier was present.

Searches sent, all declared targets: "Brennock Facilities Ltd values" (refused); "Brennock Facilities Ltd interview process administrative assistant" (refused); "Brennock Facilities Ltd strategy recent news" (refused).

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Brennock Facilities Ltd values` | unavailable | Every call was refused. It would have fed a values cheat sheet; no values-style round is detected, so no section 10 was built |
| 2. `Brennock Facilities Ltd interview process administrative assistant` | unavailable | Every call was refused. It would have fed the persona weights; with no loop source beyond the invite's one video call, the weights rest on the hiring-manager-style assumption stated above |
| 3. `Brennock Facilities Ltd strategy recent news` | unavailable | Every call was refused. It would have fed CO questions; the pack has none, and the upgrade menu says what would supply them |
| 4. interviewer name and company | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. representative `Remote Administrative Assistant` JD | skipped | The ad's four duties, as you described them, already fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The ad's full text → the requirement rows quote the ad itself instead of your summary, and any duties your summary left out get their own rows and questions
- Your own words on whether you have booked travel, what you use Word and Excel for, and what the invoice chasing involved → rows F2 to F5 gain quoted evidence and their answer slots become story-mapped guidance
- The company's own published pages on its values or how it interviews, if you find them on its own website → a values cheat sheet if a values round is documented, and persona weights read from a documented process
- The office manager's name → an interviewer read and a reverse question tied to their own path
- A deeper research pass, up to 6 more searches and 2 more fetches and several more minutes, if search is permitted → CO questions on current strategy and recent organisational context
- A `tuesday-dossier.md` → verified evidence and agreed positioning for F1 to F5, which would replace this pack's inferred rows and sharpen the highest-ROI objection
