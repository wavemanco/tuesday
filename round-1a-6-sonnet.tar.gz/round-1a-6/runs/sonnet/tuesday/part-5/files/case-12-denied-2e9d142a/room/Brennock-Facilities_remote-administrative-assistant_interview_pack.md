# Interview pack: Remote Administrative Assistant, Brennock Facilities Ltd

Interviewer: the office manager (name not given). Format: a 30-minute video call, in your words from the invite. Relationship to you: not stated, so this pack assumes a likely day-to-day manager.

## How to use this pack

Personas are how a question is asked. Types are what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the employer's published values |
| EXP | Whether your own experience holds up under follow-up questions |
| JD | Whether you can do the listed duties, gaps included |
| CO | How well you know the company and its strategy |
| CASE | How you structure a live problem from the job |

Answer slots in the guidance are instructions for the interview, not questions for you now. Where a slot says "say so plainly", that is a fully acceptable answer.

## Fit snapshot

Requirements are quoted from the ad as you described it in your message. Evidence is your own words only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — ad, as you described it | "two years as a receptionist at a physiotherapy clinic" — your message, "I ran the appointment book for four physios" — your message | medium | [grounded] | presentation | Words: "I ran the appointment book for four physios." The quote gives the book and the four physios, and it states no system or routine, so neither goes into your answer. Expect a probe on how an appointment book compares with someone's calendar |
| F2 | "booking travel" — ad, as you described it | none given | none | [grounded] | discovery | Answer slot: if you have booked travel for anyone, say what and for whom, in your own words; if you have not, or there was no such task, say so plainly and return to the appointment book you ran |
| F3 | "preparing documents in Word and Excel" (the Word half) — ad, as you described it | "I'm good with Word" — your message | medium | [grounded] | discovery | The quote says a skill, not what was prepared with it. Answer slot: if you have prepared particular documents in Word, say what they were, in your own words; if your use was light, say so plainly and say what you would do first to be ready |
| F4 | "preparing documents in Word and Excel" (the Excel half) — ad, as you described it | "okay with Excel" — your message | low | [inferred] | discovery | Inferred from reading a self-rating of "okay" against the ad's document-preparation duty: the rating is the whole of the evidence, and it stays at its own strength. Answer slot: if you have used Excel for any task, say what, in your own words; if not, say so plainly and say, as a plan, what you would practise first |
| F5 | "processing supplier invoices" — ad, as you described it | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Your material says chasing unpaid invoices, and the ad says processing supplier invoices. Words: "I chased unpaid invoices." Answer slot: if what you did with those invoices went beyond chasing, say what, in your own words; if it was chasing alone, say so plainly and stay with that |

## Persona table

The invite gives one session run by one person, so the loop is the one call. Weights start from the hiring-manager prior (Case/Strategist and Skeptic) and are tilted toward Conversational because the call is 30 minutes by video. No interviewer profile exists, so no signal adjustments apply. If the office manager turns out to be a peer, reweight (see the upgrade menu).

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet, persistent probing of where your material is thin: invoices, travel, Excel, why the move | Highest. F2, F4 and F5 are where your material is thinnest, and a manager buying capability probes gaps first | Rehearse the invoice question until it is boring; hold the quoted sentence, return to it under follow-up, and name limits plainly |
| B. Case/Strategist | Live problems from the job: a clash, a mismatched invoice, a trip, a tracker | High. The ad lists four concrete duties, and each converts to a live problem | Clarify, then structure, then think aloud; no claim about your past is needed |
| C. Conversational | Friendly walk-through of your background and tools | Medium. A 30-minute video call usually opens this way, and casual questions here are still scored | A short arc built only from the sentences you gave; treat tool questions as scored |
| D. Data-Driven Prober | Pulls on your numbers and what was yours | Low-medium. Your material carries few figures, but four physios and unpaid invoices are the ones likely to be pulled | Know what you can and cannot say about each, and say plainly when you do not know |
| E. Peer Evaluator | Asks how you would work with the people you support | Low. It appears only if the office manager is a colleague rather than your manager | Say what you would need and what you bring, in principles |
| F. Pressure | A 60-second or challenge framing of the same gaps | Low. A short call can include one compressed challenge | Pause, restate, hold what you actually did through two follow-ups, concede specifically |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You chased unpaid invoices at the clinic, and this job processes supplier invoices. How do the two compare?" | JD | [grounded] "chased unpaid invoices" | The highest-ROI rehearsal in this pack. Hold only what the quote carries: "I chased unpaid invoices." Let the interviewer draw the comparison; do not tell them the two are the same work. Answer slot: if what you did with those invoices went beyond chasing, say what, in your own words; if it was chasing alone, say so plainly and stay with that. Hold through two follow-ups by returning to that sentence, never by adding to it. Then say, as a plan, how you would learn the invoice process here | F5 is the evidence for the invoice duty and the likeliest place to be pressed. JD because it scores a stated duty; it is the deepest rehearsal because the gap sits here |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [generic] | Selection scaffold: pick the duty from the ad where your own material says least, say it before the interviewer does, then say what you would do in your first week to learn it, as a plan. If one of the duties is something you have done, say that instead and describe what you did, in your own words. If no duty comes to mind as weaker, say so plainly and name the one you would want guidance on first | F2 and F5 are the thinnest rows. JD because it scores honest self-assessment against the ad |
| A3 | "The ad mentions booking travel. What travel have you booked?" | JD | [grounded] "I ran the appointment book for four physios" | Answer slot: if you have booked travel for anyone, say what and for whom, in your own words; if you have not, or there was no such task, say so plainly and return to "I ran the appointment book for four physios." Then say what you would ask first before booking a trip, which B3 rehearses | F2 has no quote at all, so the premise is the ad's and the guidance cannot supply an answer. JD because it scores a listed duty |
| A4 | "What is making you want to move from reception into administration?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | Give your actual reason in your own words, in two or three sentences. Keep what you say about the clinic to the quote above, and name no ambition or achievement you cannot stand behind | F1 carries the background the question starts from. Skeptics always ask why now; EXP because it tests whether your story stays consistent |
| A5 | "How would you rate yourself on Excel?" | JD | [grounded] "okay with Excel" | Hold the words you used: "okay with Excel." Answer slot: if you have used it for a task, say what, in your own words; if you have not, say so plainly. Then say, as a plan, what you would practise first. Never give yourself a higher rating than you can demonstrate | F4 is low confidence and the ad names Excel. JD because it scores a stated tool |

### B. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Two managers each ask you to book the same 10 a.m. slot. What do you do?" | CASE | [generic] | Think aloud: what you would ask each of them first, how fixed each time is, who decides priority, what alternatives you could offer, how you confirm the outcome in writing. The question needs no claim about your past, so the guidance makes none | F1's calendar duty as a live problem. Generic because it is a pattern for the problem, not a fact about this employer |
| B2 | "A supplier invoice arrives and its total does not match the order. Walk me through it." | CASE | [generic] | Structure: do not treat it as settled; check it against whatever record of the order exists; ask the supplier or the person who ordered; find out who approves; record what you found and what happened. Say the order of your steps aloud | F5's invoice duty as a decision rather than a record. CASE because it scores reasoning, and it lets you show care without claiming a past |
| B3 | "A manager needs to be in another city for a two-day meeting. What do you need to know before you book anything?" | CASE | [generic] | Clarify first: purpose, dates, budget, preferences, who approves, what changes are allowed. Then options, then confirmation in writing, then a record. Ask before you structure | F2's travel duty as a live problem, rehearsing the part your material cannot cover |
| B4 | "We want a simple spreadsheet to track supplier invoices. How would you set it up and keep it right?" | CASE | [generic] | Think aloud about what each row must hold, how you would see what is due and what is paid, and how you would catch a duplicate or a typing mistake. If you have built something like it, say so in your own words; if not, present it as how you would build it | F4 and F5 meet here: a document task with an invoice purpose. CASE because it scores structure |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your journey so far." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic", "I ran the appointment book for four physios", "chased unpaid invoices" | A 90-second arc with the three beats those quotes state, in order: the two years at the clinic, the appointment book for four physios, chasing unpaid invoices. Then, in your own words, why this role next. Add no beats the quotes do not carry | F1 and F5 supply the beats. Casual openers are scored, so the arc is prepared |
| C2 | "Tell me about your Word skills." | JD | [grounded] "I'm good with Word" | Hold the words you used: "I'm good with Word." Answer slot: if you have prepared particular documents in it, say which, in your own words; if your use was light, say so plainly. Never name a feature or document you have not used | F3 is medium and the ad names Word. JD because it scores a listed tool |
| C3 | "You ran the appointment book for four physios. Tell me about that." | EXP | [grounded] "I ran the appointment book for four physios" | The beats are the book and the four physios; tell them in your own words. Answer slot: the ad's calendar line makes a probe on how you kept it organised likely. If you used a particular system or routine, say what and how; if there was none, say so plainly and describe how you ran it | F1 is the evidence for the calendar duty and the best story the material carries. EXP because it tests what was actually yours |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You ran the book for four physios. Which part of that was yours?" | EXP | [grounded] "I ran the appointment book for four physios" | Say in your own words which part was yours. If any part was shared with someone or set by someone else, say so plainly. If you do not know how something was recorded or counted, say that rather than guessing | F1's one figure, four, is the one a prober pulls. EXP because it scores attribution honesty |
| D2 | "Tell me about the unpaid invoices you chased: what did you do, and what happened?" | EXP | [grounded] "chased unpaid invoices" | The beat the quote states is the chasing; tell it in your own words. Answer slot: if you kept track of how many were outstanding or how many were paid afterwards, say what you recorded; if you did not keep count, say so plainly and describe how you did the chasing. Never give a figure you cannot say how you reached | F5 is the invoice evidence, and the outcome is the part a prober asks for. EXP because it tests what was actually done |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "The people you support each say their request is urgent. How do you decide what goes first?" | CASE | [generic] | Structure: ask about deadlines and consequences, check with whoever sets priorities, tell people what to expect and when. Describe it as how you would work, since the question needs no claim about your past | F1's calendar duty seen from the peer side. Generic because it is a collaboration pattern |
| E2 | "What would you need from me in your first week?" | JD | [grounded] "I ran the appointment book for four physios" | Reciprocity framing: ask for access, examples of finished work, how requests reach you and who approves what. Offer what your own quote carries, in its words, and nothing wider | F1 supplies the one thing you can offer by its own words. JD because it scores readiness for the listed duties |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you for this role?" | JD | [grounded] "two years as a receptionist at a physiotherapy clinic", "I ran the appointment book for four physios" | Hold what the quotes carry: the two years, the appointment book for four physios. If pushed, name plainly, in your own words, which of the ad's duties you have done and which would be new to you. Hold through two follow-ups, concede specifically, and do not fold on what you did | F1 and F5 are what you can hold, and the rest of the ad is where pressure lands. JD because it scores fit against the ad |
| F2 | "That appointment book: how much of it was actually you?" | EXP | [grounded] "I ran the appointment book for four physios" | Hold the sentence: "I ran the appointment book for four physios." Answer slot: if any part was shared with someone or set by someone else, say so plainly. Hold through two follow-ups by returning to the sentence, not by adding to it | F1 is where a pressure interviewer tests attribution. EXP because it scores precise honesty under pushback |

## Requirement coverage

| Requirement | Questions |
|---|---|
| "managing calendars" | B1, C3, D1, E1, F2 |
| "booking travel" | A3, B3 |
| "preparing documents in Word and Excel" | A5, B4, C2 |
| "processing supplier invoices" | A1, B2, B4, D2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a typical week of diary and booking work look like in this role?" | It shows you are picturing the work, and the answer tells you what to practise first |
| R2 | "Which systems do you use for diaries, travel and invoices?" | It lets you name what you would learn first, which answers A2 before it is asked |
| R3 | "How are supplier invoices approved here, and who would I go to when one does not match?" | It shows you think about the whole invoice path, and it prepares your answer to B2 |
| R4 | "What would a good first month look like in this role?" | It turns a scored interview into a shared picture of success |
| R5 | "What could a new person do in their first month that would genuinely help you?" | It is the reciprocity question, and it works whether the office manager is your manager or a peer |
| R6 | "What are the next steps after this call, and when should I expect to hear?" | It lets you plan your week, and it is an ordinary closing question |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Processed supplier invoices | Inflated form of F5 | F5's quote at its own scope: "chased unpaid invoices". The limit is the pack's observation: your material says chasing, not processing. A1's slot stays inside the invoices you chased |
| Advanced or expert Excel skills | Inflated form of F4 | F4's quote at its own scope: "okay with Excel". A5's slot asks only what you have used it for |
| Managed calendars across a whole team or office | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios". C3's slot stays inside the book you ran |

## Sources

Provided documents: your message, containing the invite text, your description of the ad, and your background. No `tuesday-dossier.md` was present.

Searches sent, each refused:

- `Brennock Facilities Ltd company values`: refused
- `Brennock Facilities Ltd interview process administrative assistant`: refused
- `Brennock Facilities Ltd news strategy`: refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Brennock Facilities Ltd company values` | unavailable | Search was refused. It would have fed value-themed questions; none are in this pack, so nothing here rests on the company's values |
| 2. `Brennock Facilities Ltd interview process administrative assistant` | unavailable | Search was refused. It would have checked loop structure; the pack uses your own description, one 30-minute video call with the office manager |
| 3. `Brennock Facilities Ltd news strategy` | unavailable | Search was refused. It would have fed CO questions; the case questions are labelled generic instead |
| 4. `{interviewer name} Brennock Facilities Ltd` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Remote Administrative Assistant` JD | skipped | The ad as you described it already fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full ad text → F1 to F5's requirements become exact quotes, and any duty I could not see becomes a row with its own JD question
- Your CV text → more of your own sentences in the fit snapshot, so more questions become story-mapped instead of slots
- Your answers to the slots under F2 to F5 → those rows move from discovery to grounded, and A1, A3, A5, C2 and D2 get stronger guidance
- Whether the office manager would be your manager or a colleague → persona weights recompute and the banks are reordered
- The office manager's name → an interviewer read and a reverse question tied to their path
- Pages you paste, such as the employer's values or careers page → company-specific questions replace the generic cases, and the research gaps in the table above close
- A deeper research pass, up to 6 more searches and 2 more fetches and several more minutes, if search is permitted → a grounding brief and company-specific CO questions
- A `tuesday-dossier.md` → verified evidence and prohibited claims arrive from an earlier session instead of being built locally
