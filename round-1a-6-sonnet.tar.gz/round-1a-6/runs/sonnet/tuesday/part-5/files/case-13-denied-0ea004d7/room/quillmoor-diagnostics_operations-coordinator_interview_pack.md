# Interview prep pack — Operations Coordinator, Quillmoor Diagnostics

Round: recruiter screen, a 30-minute phone call, Thursday at 2pm, with Hannah Lowther (Talent Partner), who will ring the mobile number on your application. Her own agenda, from her message: your salary expectations, your notice period, how the hybrid pattern would work for you and what's prompting a move, then the team and the next steps.

## How to use this pack

- Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words.
- Type key: VAL tests behaviour against values, EXP tests whether your experience survives scrutiny, JD tests a stated requirement, CO tests what you know about the company, CASE tests reasoning on a live problem.
- Labels: `[grounded]` traces to something you or the advert supplied, `[inferred]` is this pack's derivation, `[generic]` is a role-family pattern with no claim about you or Quillmoor.
- An answer slot is an instruction for the call, not a question for you now. It asks you to answer from your own experience, and it always allows that the thing never happened or was not yours.
- Persona weights rest on Hannah's own message and the recruiter-screen priors, not on a documented Quillmoor process.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it. Say it in the quote's own terms: four years as a logistics coordinator at a building-supplies wholesaler |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | medium | [grounded] | transferability | Your material says delivery scheduling across three depots, not production schedules, and nothing in it names other teams. The words stay at the quote: "I schedule deliveries for our three depots." Answer slot: the advert's line makes a probe on the overlap likely. If your delivery scheduling involved other teams, say which and what part was yours, in your own words; if it did not, or it was not yours, say so plainly and stay with the depots |
| F3 | "track supplier deliveries" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | low | [inferred] | discovery | Scheduling deliveries and chasing late ones sits near tracking them, but the sentence does not say how an order's position is followed, and the bridge should not be stretched. Answer slot: if any part of your scheduling or chasing meant checking where an order stood, say what you checked and how, in your own words; if it did not, or that was not yours, say so plainly and stay with the chasing |
| F4 | "chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | medium | [grounded] | none | No gap on the chasing, but a line with nothing inspected behind it, so expect a probe. Lead with it in the quote's own terms: you chase suppliers when orders slip |
| F5 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | medium | [grounded] | none | No gap, but a figure with nothing inspected behind it, so expect a probe on it. The sentence joins the rebuild and the fall with "and", not "because", and the claim stays there: you rebuilt the spreadsheet, and discrepancies fell by about a third over a year |
| F6 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material says nothing on reporting. Answer slot: the advert's weekly dispatch line makes a probe on reporting likely. If you have produced a regular report on deliveries or dispatch, say what it covered and how often, in your own words; if you have not, or it was not yours, say so plainly and stay with the scheduling and chasing |
| F7 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet" — your message | low | [inferred] | discovery | Your material says spreadsheet, not which tool, and the bridge should not be stretched. Answer slot: the advert's mention of a spreadsheet tool makes a probe on the tool likely. If you can say which tool the stock-count spreadsheet was in and what you did in it, say so in your own words; if it was a different tool, or the work was not yours to set up, say so plainly |
| F8 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system" — your message | medium | [grounded] | transferability | A plus, not a requirement. Your material says SAP is not something you have used and that you work in an in-house stock system, and does not say what that system covers. Words: "I haven't used SAP; we run our own in-house stock system." Answer slot: the advert's "or similar" makes a probe on what the in-house system does likely. If you used it for particular tasks, say what they were, in your own words; if you did not work in it directly, say so plainly |
| F9 | "£38,000–£44,000" — advert | "I'm hoping for £42,000" — your message | high | [grounded] | none | Gate met on your material: the figure sits inside the advertised range. Say it as you gave it: "I'm hoping for £42,000." Nothing is added to it here |
| F10 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" — your message | high | [grounded] | none | Gate met on your material, with your own limit in it. Say it as you gave it, limit included. Nothing is added to it here |

## Persona table

Highest-ROI prep: B2, the production-schedules overlap. It sits on F2, the advert's core line, where your material is adjacent rather than direct, so some form of it is likely and a rehearsed, non-defensive answer changes the call.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Conversational / rapport builder | Friendly, unstructured; pay, notice, hybrid and background as chat | High. Hannah's message lists a logistics agenda, and the recruiter-screen prior is a conversational register where casual questions are still scored | A 90-second arc from your own sentences (A1); the logistics answers in your own words, as you stated them; use the questions slot rather than "I think you've covered everything" |
| B. Skeptic | Quiet probing of why you are moving and of the gaps against the advert | Medium-high. "What's prompting a move" is the Skeptic's why-leave, why-now, and the SAP, Excel and production-schedule lines are knockout-style checks in a friendly register | Rehearse B2 until it is boring; bridge only from your own sentences; plain acknowledgment only where you stated the negative; a ramp plan said as a plan, never as a past |
| C. Data-driven prober | Asks how a figure was counted; asks what reporting exists | Medium. Hannah's message names no deep probing, but a quantified claim is the first thing a prober reaches for, and the advert has a weekly reporting line | Know what you can and cannot say about how the figure was counted; say plainly when you do not know; name the assumption you would defend least before she does |
| D. Pressure | Time-boxed challenge, such as sixty seconds on why you | Low. Nothing in Hannah's message suggests it; included for the SAP challenge, which is the likeliest time-boxed one | Pause, restate, hold your position through two follow-ups, concede one thing specifically |
| E. Case / strategist | A live problem from the role | Low. Hannah's message lists no live problem; included so a scenario never lands cold | Clarify, then structure, then answer; think aloud |
| F. Values / behavioral | Tell me about a time | Low. No values material could be researched, and no values-style round is documented, so these rest on the persona's stems and the advert's coordination line | Select a real instance using the scaffold; if none comes to mind, say so plainly |

## Question banks

### A. Conversational (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your background and what you do day to day." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" "I schedule deliveries for our three depots and chase suppliers when orders slip" "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Story-mapped in three beats, each a clause the quotes state: the four years at the wholesaler; scheduling deliveries for three depots and chasing suppliers when orders slip; the stock-count spreadsheet rebuild and the fall in discrepancies. Tell them in your own words and stop there, letting her draw any inference | The opener sets the frame for every later probe; it feeds F1, F4 and F5. EXP because it tests what was actually yours |
| A2 | "What salary are you looking for?" | JD | [grounded] "I'm hoping for £42,000" | Logistics slot, kept whole: say it as you gave it, "I'm hoping for £42,000." Nothing is added to it here. If asked what you earn now: "I'd rather focus on the range for this role." | Salary expectations are the first item in Hannah's message; F9 is the row. JD because it scores the listed job's terms |
| A3 | "What's your notice period?" | JD | [grounded] | Logistics slot: give your actual notice period, in your own words. No figure is supplied here because none was given | Named in Hannah's message; the upgrade menu says what a stated figure would add. JD because it is a term of taking the job |
| A4 | "The role is hybrid, two days a week at Avonmouth. How would that work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | Logistics slot, kept whole: say it as you gave it, limit included, "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." If she follows up on it, your own words were that sentence; nothing more is scripted | The hybrid pattern is the third item in Hannah's message; F10 is the row. JD because it scores the advert's stated pattern |
| A5 | "What do you know about Quillmoor?" | CO | [grounded] | The only facts this pack holds about Quillmoor are the advert's: a diagnostic-test manufacturer, about 400 staff, a site at Avonmouth. Say what you have actually read, in your own words; if you have looked beyond the advert, say what and where; if you have not, say so plainly and let her tell you more, as she has said she will. Company research did not run (see Sources), so anything beyond the advert would be this pack's guess | Homework depth is scored even in a friendly register. CO because it tests company knowledge; the pack could rehearse it from the advert alone |

### B. Skeptic (second weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "What's prompting a move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Logistics slot, kept whole: say it as you gave it, in your own words, "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." Nothing is added to it here. If she asks again on the same point, your own words were that sentence | The fourth item in Hannah's message and the Skeptic's why-now. EXP because it tests whether your story is consistent |
| B2 | "This role coordinates production schedules between planning, the warehouse and QA. What overlap do you see with scheduling deliveries?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" "4 years as a logistics coordinator at a building-supplies wholesaler" | The deepest rehearsal in the pack. Level 1: say what you do in the quote's own words, "I schedule deliveries for our three depots and chase suppliers when orders slip." Level 2, she presses on the overlap: return to the same sentence and let her judge the overlap; the pack offers none. Answer slot: if your delivery scheduling involved other teams, say which and what part was yours, in your own words; if it did not, or it was not yours, say so plainly and stay with the depots. Level 3, she asks directly whether you have scheduled production: give the true answer from your own experience in one sentence, then a plan said as a plan, such as what you would ask planning, the warehouse and QA about how the schedule works in your first weeks. Hold your position through two follow-ups; concede only what you can say truthfully | F2 is the advert's core line and the thinnest of the core rows, so this objection arrives in some form. JD because it scores a stated responsibility, with Skeptic delivery |
| B3 | "ERP experience, SAP or similar, is a plus. What systems have you used?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | Say it at the quote's scope: "I haven't used SAP; we run our own in-house stock system." Answer slot: if she asks what the in-house system does, say what you used it for in your own words; if you did not work in it directly, say so plainly. Then a plan, said as a plan: how you would get up to speed on a new system, and what you would ask for in the first weeks. The pack does not call the in-house system an ERP | F8 is a stated gap on a plus; the stated negative gives the plain acknowledgment its source. JD because it scores a listed plus |
| B4 | "Which part of this job would you find hardest on day one?" | JD | [inferred] | Selection scaffold: choose the advert line you judge your own material reaches least, name it in your own words, then how you would close it as a plan, never as past work. Rows F2, F6 and F7 are where this pack's observation is that your material is thinnest, derived from the snapshot above. If none comes to mind, say so plainly and say how you would find out | The standard Skeptic stem, derived from the snapshot's gaps. JD because it scores the advert's own list |

### C. Data-driven prober (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Say it at the sentence's scope: you rebuilt the spreadsheet, and discrepancies fell by about a third over a year. Four slots, each in your own words. How it was counted: if you know, say how; if you do not, say so plainly. What it is sensitive to: if you know, say what; if not, say so. The assumption behind it you would defend least: name it before she does. Which part was yours: say what part, and who else contributed if anyone did | A figure is the first thing a prober checks; F5 is the row. EXP because it tests attribution |
| C2 | "Tell me about a time you reported on deliveries or stock to other people." | JD | [grounded] | Selection scaffold: pick an occasion when you passed delivery or stock figures to someone who used them; it needs what was reported, how often, and what changed afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would set up a weekly report on on-time dispatch | F6 is where the advert asks and your material is silent. JD because it scores the reporting line |
| C3 | "The advert asks for confidence with Excel. What do you do in it?" | JD | [inferred] "I rebuilt our stock-count spreadsheet" | Say the quote at its own scope: you rebuilt the stock-count spreadsheet. Answer slot: if you can say which tool it was in and what you did in it, say so in your own words; if it was a different tool, or the setup was not yours, say so plainly. Name no feature you did not use | F7 is a discovery row, so the honest answer is a slot. JD because it scores a stated tool requirement |
| C4 | "How do you keep track of supplier deliveries, and what do you do when one slips?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" | Story-mapped on what the sentence states: you schedule deliveries for three depots, and you chase suppliers when orders slip. Answer slot: if any part of that meant checking where an order stood, say what you checked and how, in your own words; if it did not, or that was not yours, say so plainly and stay with the chasing | F3 and F4 are the rows; this is the one question that covers the tracking and the chasing together. JD because it scores two stated responsibilities |

### D. Pressure (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you, when other applicants may have used SAP?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" "I schedule deliveries for our three depots and chase suppliers when orders slip" "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" "Never used SAP — we run our own in-house stock system" | Hold, then concede. Hold on what your sentences carry, said as what you did: four years as a logistics coordinator, scheduling deliveries for three depots, chasing suppliers when orders slip, the spreadsheet rebuild and the fall in discrepancies. Let her draw the inference. Hold through two follow-ups by returning to those sentences. Concede once, specifically: "I haven't used SAP." Stop there, and add no claim the sentences do not carry | F8 is the stated gap and the likeliest thing to be challenged in a time box. JD because it scores fit against the advert |
| D2 | "How much of that result was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Hold on the sentence: you rebuilt the spreadsheet. Concede explicitly what the sentence does not say: it joins the rebuild and the fall with "and", not "because". Answer slot: if other changes also contributed to the fall, say what they were, in your own words; if you do not know whether anything else contributed, say so plainly. Never fold on the rebuild itself | Attribution probes exist to catch inflation, and F5 is the row. EXP because it tests what was actually yours |

### E. Case (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A supplier tells you on Monday that a delivery needed for a production run later in the week will be a week late. What do you do?" | CASE | [generic] | Structure it: what the delivery is for and by when; who is waiting on it, which the advert names as planning, the warehouse and QA; what the supplier can actually commit to; the options; telling those affected; recording it and following up. The question needs no claim about your past, so the guidance makes none | A live problem from the advert's chasing line (F4). Generic because it is a pattern for the problem, not a fact about Quillmoor |
| E2 | "The stock record says one number and the shelf says another. What do you do first?" | CASE | [generic] | Structure it: confirm the count and when it was taken; check what moved since; correct the record once the cause is understood; record the cause. The question needs no claim about your past, so the guidance makes none | A live problem from the advert's stock-records line (F5). Generic because it is a pattern for the problem |

### F. Values / behavioral (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something they did not want to hear; it needs a named stake, a moment you did not fold, and a working relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The persona's own stem; no values page could be read, so this is not tied to Quillmoor's values. VAL because it tests past behaviour |
| F2 | "Tell me about a time you worked with a team outside your own to get something done." | VAL | [grounded] | Selection scaffold: pick a time you needed another team's help; it needs what you needed, how you agreed it, and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach it | The advert's coordination line is the raising source for the theme. VAL because it tests collaboration behaviour |

### Requirement coverage

| Requirement | Questions | Notes |
|---|---|---|
| F1 "2+ years in operations or logistics coordination" | A1 | — |
| F2 "Coordinate production schedules between planning, the warehouse and QA" | B2, B4, E1, F2 | Highest-ROI rehearsal is B2 |
| F3 "track supplier deliveries" | C4 | — |
| F4 "chase late orders" | C4, E1 | — |
| F5 "keep stock records accurate" | C1, D2, E2 | — |
| F6 "report weekly on on-time dispatch" | C2, B4 | — |
| F7 "confident with Excel" | C3, B4 | — |
| F8 "ERP experience (SAP or similar) a plus" | B3, D1 | — |
| F9 pay | A2 | — |
| F10 hybrid | A4 | — |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Is this role new, or does it replace someone, and what should it do differently?" | Shows interest in how the team has been shaped, and gives context for how to pitch later answers |
| R2 | "Who would I work with day to day across planning, the warehouse and QA?" | Uses the advert's own line and gives you real seams to talk about before B2 comes up again |
| R3 | "Which systems does the team use day to day for stock and orders?" | Puts the systems question on your terms and informs your answer to B3 |
| R4 | "How is on-time dispatch measured and reported today?" | Shows you read the weekly reporting line and tells you what C2 is really about |
| R5 | "How are the two Avonmouth days set, fixed days or agreed with the team?" | A practical follow-through on the hybrid item that does not reopen your own limit |
| R6 | "What would a good first three months look like in this role?" | Moves the conversation from screening to doing the job, and tells you what to emphasise next |
| R7 | "After this call, who would I speak to next, and what will they look at?" | Tells you which persona banks to weight for the next round |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinates production schedules between planning, the warehouse and QA | Inflated form of F2 | F2's quote at its own scope: "I schedule deliveries for our three depots and chase suppliers when orders slip". The limit is the pack's observation, not words for you: the material says delivery scheduling, not production schedules. B2's slot stays inside the depots |
| Has used SAP | Negative you stated, F8 | The plain acknowledgment F8 gives: "I haven't used SAP." No slot on it |
| Has ERP experience | Inflated form of F8 | F8's quote at its own scope: "we run our own in-house stock system". The limit is the pack's observation: the material does not say what that system covers. B3's slot asks only what you used it for |
| Is confident with Excel | Inflated form of F7 | F7's quote at its own scope: "I rebuilt our stock-count spreadsheet". The limit is the pack's observation: the material says spreadsheet, not which tool. C3's slot asks only which tool and what you did in it |
| Tracks supplier deliveries | Inflated form of F3 | F3's quote at its own scope: "I schedule deliveries for our three depots and chase suppliers when orders slip". C4's slot stays inside the scheduling and chasing |
| Cut stock discrepancies by a third through the rebuild | Inflated form of F5 | F5's quote at its own scope: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year". The limit is the pack's observation: the sentence joins the two with "and", not "because". D2's slot asks only what else contributed |

## Sources

Provided documents: the advert as pasted; Hannah Lowther's LinkedIn message as pasted; your note on your background and what you would tell her. No dossier was present. No fetches were sent.

Searches sent, all refused:

- "Quillmoor Diagnostics values" — refused
- "Quillmoor Diagnostics Avonmouth Bristol news strategy" — refused
- "Hannah Lowther Talent Partner Quillmoor Diagnostics" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor values | unavailable | Would have themed the VAL questions and the company-specific part of A5; no values-style round is documented either way, so no values cheat sheet |
| 2. Quillmoor interview process, operations roles | skipped | Hannah's message already fixes this session: a 30-minute phone call with her and her four-item agenda, so persona weights follow that |
| 3. Quillmoor strategy and recent news | unavailable | Would have moved A5 and a reverse question on current priorities |
| 4. Hannah Lowther, Quillmoor | unavailable | Would have given an interviewer read and one reverse question tied to her path; both are absent |
| 5. representative Operations Coordinator advert | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your notice period → A3 becomes your own words, quoted, instead of an instruction
- Your CV → the rows built from your message alone (F1, F4, F5, F7, F8) gain quotes of their own, and F7 or F3 may move from discovery
- Your answers on any answer slot (F2, F3, F6, F7, F8) → quoted into the snapshot, regenerating the rows that draw on them
- Hannah's prep email or any pre-call guidance → coverage of anything she has pre-declared
- Permission to run web search → the three refused searches can be rerun, giving company-specific CO questions and an interviewer read, and a deeper pass of up to 6 more searches and 2 more fetches, taking several more minutes, can follow on your say-so
- A `tuesday-dossier.md`, if you have one → verified evidence and risks that sharpen the guidance and reverse questions
