# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** recruiter screen, a 30-minute phone call with Hannah Lowther (Talent Partner), Thursday at 2pm. She said she will ring the mobile number on your application.
**Her stated agenda:** your salary expectations, your notice period, how the hybrid pattern would work for you, and what is prompting a move. Then she tells you about the team and the next steps.
**Built on this assumption:** a single recruiter screen with no dossier and no CV, only your own notes. The pack is built on the advert text, Hannah's message and your own sentences.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say things in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether your experience claims survive follow-up |
| JD | Whether you meet the advert's stated duties and terms, gaps included |
| CO | How well you know the company and its strategy |
| CASE | How you structure a live problem from the role |

Where an answer slot appears, it is an instruction for the interview, not a question for you now.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material says deliveries and chasing suppliers, not production schedules, planning or QA, with nothing inspected behind it. The words stay at the quote: "I schedule deliveries for our three depots." Answer slot: the advert's planning-warehouse-QA line makes a probe on that work likely. If you have worked with planning or QA-type teams, say who and how, in your own words; if not, or there was no such work, say so plainly and stay with the deliveries |
| F2 | "track supplier deliveries" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Scheduling deliveries and chasing suppliers is adjacent to tracking them, and the sentence does not say how you follow a delivery. Answer slot: if you follow where supplier orders are, say how, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the scheduling and the chasing |
| F3 | "chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | No gap: the sentence already says you chase suppliers when orders slip. Lead with it in its own terms, "I chase suppliers when orders slip." Expect a probe, because a sentence in a message has nothing inspected behind it |
| F4 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | No gap, but a figure with nothing inspected behind it, so expect a defend-the-number probe (C1). Keep "about a third" and "over a year" as you said them |
| F5 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material does not show whether you report on delivery performance. Answer slot: if you produce regular reports on deliveries or stock, say what and how often, in your own words; if not, say so plainly and say what you would want to learn first |
| F6 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | none | No gap: the quote reaches the requirement in the advert's own terms. Say it in its own terms and let the interviewer draw the comparison |
| F7 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | The sentence says a spreadsheet, not Excel, and it does not say what was built in it. Answer slot: if it was in Excel, say what you rebuilt in it, in your own words; if it was another tool, or Excel was used for something else, say so plainly |
| F8 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system." — your message | none | [grounded] | capability | You stated this one yourself. Words: "I've never used SAP." Then how you would learn a new system, said as a plan and never as a past |
| F9 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system." — your message | low | [inferred] | transferability | The second half of your sentence is adjacent work, and the pack does not call it an ERP or an equivalent. Words at its own scope: "we run our own in-house stock system." Answer slot: if you used that system yourself, say what you did in it, in your own words; if you did not use it directly, say so plainly |
| F10 | "£38,000–£44,000" — advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | No gap: the figure is inside the advertised band. Say it in your own words and stop. The pack adds no reason, range or flexibility |
| F11 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | No gap: two days is within your own words. Keep both halves of your sentence together, "fine" for two and "wouldn't want more than three" |
| F12 | "your notice period" — Hannah's message | none given | none | [grounded] | hard_gate | Your material does not establish your notice period. This is a term, so it is surfaced and never bridged |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Conversational / Rapport Builder | Friendly, unstructured; Hannah's four stated topics arrive as chat | Highest. A recruiter screen's prior is conversational, and her message names logistics and motivation, which are casual-register questions that are still scored | Treat each chatty question as scored. Say your own words for the logistics slots and stop |
| B. Skeptic | Quiet probing of the gaps: production, ERP, why this company | Medium, light. The prior for a recruiter screen is light skepticism, and F1, F8 and F9 are where the material is thinnest | Rehearse the single most predictable objection (B1) until it is boring; bridge only from the quotes |
| C. Data-Driven Prober | Asks how a number was counted | Medium-low. Recruiters rarely probe, but one headline figure sits in F4 and costs nothing to rehearse | Know what you can and cannot say about the figure, and say plainly when you do not know |
| D. Case / Strategist | A quick live problem from the role | Low. Not typical of a recruiter screen, and no signal from Hannah's message | Clarify, then structure, then answer; think aloud |
| E. Pressure | A time-boxed challenge | Low. Possible as a short "why you" test | Pause, restate, hold through two follow-ups by returning to your quoted words |
| F. Values / Behavioral | "Tell me about a time" prompts from the advert's duties | Low. No published values are in hand and no values-style round is detected | Pick a real time and use the honest branch where none comes to mind |

No Peer Evaluator bank: no peer is in this session.

## Question banks

### A. Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "To start, tell me a bit about your background and what your role involves day to day." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." | Story-mapped on F6 and F3, with only the beats those sentences state: the four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots; chasing suppliers when orders slip. Tell them in your own words and stop when the beats run out. Add a detail only if you can repeat it under a second question | F6 and F3 carry the biography the recruiter invites first. EXP because it tests what you say you did |
| A2 | "What's prompting a move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Logistics slot, filled by your own words, quoted whole: "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." Say it that way and stop. If she follows up on any part of it, your own words again, the same sentence | Hannah's message names it as one of her four topics. EXP because it tests whether the story is consistent |
| A3 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | Logistics slot: "I'm hoping for £42,000." Say it in your own words and stop. If asked what you earn now: "I'd rather focus on the range for this role." | F10 holds the figure. JD because pay is the listed job's term |
| A4 | "What's your notice period?" | JD | [grounded] | Logistics slot: give your actual notice period, in your own words. Your material does not state it, so the pack supplies no figure | F12 is a gate row. JD because it is a term of taking the job |
| A5 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Logistics slot: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." Say it in your own words, with both halves together. If she asks anything more about it, your own words again, the same sentence | F11 holds it. JD because the hybrid pattern is the advert's term |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | The highest-ROI rehearsal in this pack, and the hold is only what the quote carries: "I schedule deliveries for our three depots and chase suppliers when orders slip." The pack's observation is that your material says deliveries and chasing suppliers, not production schedules, planning or QA. Answer slot: the advert's planning-warehouse-QA line makes a probe likely. If you have worked with planning or QA-type teams, say who and how, in your own words; if not, or there was no such work, say so plainly and return to the deliveries and the suppliers. Then give a plan, said in the future tense: how you would learn the three teams' schedules in your first weeks. Hold through two follow-ups by returning to the deliveries, never by adding to them | F1 and F2 are where the role's mandate presses hardest, so this objection arrives in some form. JD because it scores the stated requirement |
| B2 | "ERP experience, SAP or similar, is a plus. What's your experience there?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | The plain acknowledgment comes from your own sentence: "I've never used SAP." Then the second half at its own scope: "we run our own in-house stock system." Answer slot: if you used that system yourself, say what you did in it, in your own words; if you did not use it directly, say so plainly. Leave "similar" to the interviewer rather than calling the system an ERP. Close with how you would learn a new system, as a plan | F8 is a stated gap and F9 is adjacent work. JD because it is a listed plus |
| B3 | "What interests you about Quillmoor, and about working for a diagnostics manufacturer?" | CO | [grounded] | Selection scaffold, with no claim about your past. The only company facts in hand are the advert's: a diagnostic-test manufacturer, about 400 staff, and the duties it lists. Pick what in that list you actually want to do and say why, in your own words. If you know nothing more about the company, say so plainly | Casual company questions are scored. The search for company facts was refused, so the pack holds nothing beyond the advert. The upgrade menu says what research would add |
| B4 | "How confident are you in Excel, and what have you built in it?" | JD | [inferred] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Say it at its scope: "I rebuilt our stock-count spreadsheet." Answer slot: if it was in Excel, say what you rebuilt in it, in your own words; if it was another tool, or Excel was used for something else, say so plainly. Name a feature only if you used it | F7 is the row. JD because "confident with Excel" is a stated requirement |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said discrepancies fell by about a third. Walk me through how that was counted." | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Four slots, each in your own words: how it was counted; what it is sensitive to; the assumption behind it you would defend least; which part was yours. Where you do not know one, say so plainly, since "I don't know how it was counted" is an honest answer. Keep "about a third" and "over a year" as you said them. If you have the figures behind it, offer to walk through them | F4 holds the headline figure. EXP because it tests attribution |
| C2 | "The role reports weekly on on-time dispatch. What have you reported on?" | JD | [grounded] | Answer slot: if you produce regular reports on deliveries or stock, say what and how often, in your own words; if not, say so plainly and say what you would want to learn first | F5 is a discovery row. JD because the advert lists the report |
| C3 | "How do you keep stock records accurate day to day?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Story-mapped with only what the sentence states: the rebuilt stock-count spreadsheet, and the fall in discrepancies. Answer slot: the advert's accurate-records line makes a probe on the routine behind it likely. If you do a regular count or check, say what and how often, in your own words; if the rebuild was a one-off, or the routine was not yours, say so plainly and stay with the spreadsheet | F4 again, from the requirement's side. JD because the advert lists it |

### D. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A supplier tells you a delivery that production needs on Monday won't arrive until Thursday. Walk me through what you do." | CASE | [generic] | Structure it: what you would ask first, what is affected and by how much, the options, who you would tell, and what you would record. The question needs no claim about your past, so the guidance makes none | A live problem from the advert's supplier-chasing line (F3's requirement). `[generic]` because it is a pattern for the problem, not a fact about this employer |
| D2 | "Planning wants the schedule one way, the warehouse another, and QA has a hold. How do you decide what goes first?" | CASE | [generic] | Structure it: ask what each constraint really is, find the real deadline, propose an order, check it with all three, and record the decision. No claim about your past | A live problem from the advert's planning-warehouse-QA line (F1's requirement) |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you rather than someone who has already worked in manufacturing?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." | Pause and restate the question. The hold is only the two quotes, in your own words. Answer slot: if you have worked in or near manufacturing, say how; if not, say so plainly and return to the four years of coordination. Hold through two follow-ups by returning to your quotes, never by adding to them | F1 and F6 are where this test lands. JD because it scores fit for the listed job |
| E2 | "Two days a week at Avonmouth is the pattern. Are you sure that works for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Hold with your own words: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." Hold through two follow-ups by saying the same sentence again, adding no reason, distance or flexibility you have not stated | F11 holds it. JD because it is the advert's term, asked under pressure |

### F. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time an order slipped and you had to chase it." | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Your sentence states a practice, not an occasion, so this is a selection scaffold. Pick one real time. It needs what was late, what you did and how it ended; use "we" for context and "I" for your own part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F3 is the row. JD because the advert lists chasing late orders |
| F2 | "Tell me about a time you had to get several teams to agree on dates." | JD | [generic] | Selection scaffold: pick one real time. It needs the teams, the date at stake, what you did and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F1's requirement from the behavioural side. `[generic]` because the pack has no sentence of yours that carries it |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| Coordinate production schedules between planning, the warehouse and QA (F1) | B1, D2, E1, F2 |
| Track supplier deliveries (F2) | A1, D1 |
| Chase late orders (F3) | A1, D1, F1 |
| Keep stock records accurate (F4) | C1, C3 |
| Report weekly on on-time dispatch (F5) | C2 |
| 2+ years in operations or logistics coordination (F6) | A1, E1 |
| Confident with Excel (F7) | B4 |
| ERP experience, SAP or similar (F8, F9) | B2 |
| Pay band (F10) | A3 |
| Hybrid pattern (F11) | A5, E2 |
| Notice period (F12) | A4 |
| Reason for the move (Hannah's topic) | A2 |
| Company interest | B3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which of planning, the warehouse and QA would I work with most day to day, and where does this role sit between them?" | It shows you read the advert's three-way coordination line, and the answer tells you where the weight of the job sits |
| R2 | "What does a good first three months look like in this role?" | It signals you are thinking about ramping up, which matters most where the production side is new to you |
| R3 | "How is on-time dispatch reported today, and who reads the weekly report?" | It ties to the advert's reporting duty and shows interest in how the number gets used |
| R4 | "Which system does the team use for stock and orders, and how is a new starter trained on it?" | It raises the ERP point on your terms and surfaces the ramp support without claiming experience you do not have |
| R5 | "Who would I meet next, and what would each conversation cover?" | Hannah has promised next steps, and this lets you prepare the following round specifically |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated production schedules between planning, the warehouse and QA | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says deliveries, not production schedules. B1's slot stays inside the deliveries |
| Has used SAP | Negative you stated, F8 | The plain acknowledgment F8 gives: "I've never used SAP." No slot |
| Has ERP-equivalent experience | Inflated form of F9 | F9's quote at its own scope: "we run our own in-house stock system." The limit is the pack's observation: your material says an in-house stock system, not an ERP. B2's slot asks only what you did in it |
| Advanced or expert Excel skills | Inflated form of F7 | F7's quote at its own scope: "I rebuilt our stock-count spreadsheet." The limit is the pack's observation: your material says a spreadsheet, not Excel. B4's slot stays inside what you rebuilt |
| Cut discrepancies by a third through the rebuild | Inflated form of F4 | F4's quote at its own scope, with "about a third" and "over a year" as you gave them. C1's slots ask only how it was counted and which part was yours |

## Sources

**Provided documents:** the advert text you pasted, Hannah Lowther's LinkedIn message as you pasted it, and your own notes in your message. No `tuesday-dossier.md` was present. Hannah's message establishes the loop: one 30-minute phone call with her, so persona weights follow the recruiter-screen priors and no archetype fallback applies.

**Searches sent, each refused:**

- "Quillmoor Diagnostics values" — refused
- "Quillmoor Diagnostics strategy news" — refused
- "Hannah Lowther Talent Partner Quillmoor Diagnostics" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | The call was refused. It would have moved B3 and the VAL framing. The pack holds no company values |
| 2. `Quillmoor Diagnostics interview process operations` | skipped | Hannah's message fixes the session (one phone call with her) and what it covers, so persona weights and structure are already set |
| 3. `Quillmoor Diagnostics strategy` / recent news | unavailable | The call was refused. It would have moved B3 from the advert's facts to current priorities |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | The call was refused. It would have moved the interviewer read and added a reverse question tied to her path. Both are absent |
| 5. representative `Operations Coordinator` JD | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV → F1 to F9 move from your message sentences to your CV's own lines, and rows can gain an inspectable source
- The stock-count spreadsheet or a discrepancy log, or a weekly delivery report if you produce one → F4 or F5 could rise from medium or none, because those are the artifacts a logistics role keeps
- Your answers to the slots in B1, B2, B4, C1, C2 and C3, stated outside a drill → each is quoted into the fit snapshot and the rows that draw on it regenerate; none is needed to use the pack
- Your notice period → fills F12 and the A4 slot in your own words
- Search permission for the company's published values and strategy and for Hannah's public professional footprint → B3 moves from the advert's facts to grounded company facts, and one reverse question can tie to her path
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → a strategy brief and recent organisation context for B3 and the reverse questions
- Anything Hannah says about later rounds → per-round mini-packs with their own persona weights
- A `tuesday-dossier.md` from an earlier fit check, if you have one → verified evidence and a do-not-claim list; the pack stands without it
