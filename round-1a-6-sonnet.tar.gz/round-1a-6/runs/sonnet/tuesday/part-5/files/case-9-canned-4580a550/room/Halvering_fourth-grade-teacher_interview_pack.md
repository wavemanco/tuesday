# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**Role:** Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)
**Round:** one 45-minute panel on Thursday, per the invite
**Panel:** Principal Dolores Vantongeren and two members of the fourth-grade team (names not given). Built as a panel: the principal reads as a hiring-manager relationship, the two teammates as peers.
**Built on:** the invite, your résumé text, and L1 research. No Halvering posting was supplied, so the requirement rows below are quoted from a representative posting and labeled `[inferred]`.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and rehearse only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Behavioral and values alignment: whether past behavior shows the district's published beliefs |
| EXP | Work-experience deep-dive: whether your résumé lines survive scrutiny and what was actually you |
| JD | Role-driven: the listed responsibilities and qualifications, gaps included |
| CO | Company and strategy knowledge: what you know about the district and its plans |
| CASE | A live problem set in the role |

**Highest-ROI prep in this pack: A1.** Your material says "I've never taught fourth grade", and that question will be asked in some form. A rehearsed, non-defensive answer changes the interview. A2 is second: the team-lead question.

## The fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" — Halvering invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | This is a term, and your material shows it met: the license, the elementary endorsement, active through June 30, 2029. Nothing has been inspected here, and checking it is yours, so have the details ready for HR. Your license number is not used anywhere in this pack or in any search. Words: "I hold an Illinois Professional Educator License with the Elementary Education endorsement for grades 1–6, registered and active through June 30, 2029." |
| F2 | "plan and teach reading" — Fourth Grade Teacher job description, K12 Jobs Board (a representative posting, not Halvering's) | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | medium | [inferred] | discovery | These lines touch reading without showing what your own reading teaching looked like. Words stay at their scope: "I led our grade level's move to a new reading curriculum in 2024, and I've run the after-school reading club for the last two years." Answer slot: the district's hiring page names reading instruction first, so expect a probe on your own reading block. If you taught reading to your own class, describe how in your own words; if you did not, or it was not yours, say so plainly and stay with the move and the club |
| F3 | "writing, math, science and social studies" — K12 Jobs Board representative posting | none given | none | [inferred] | discovery | Your material is silent on subjects other than reading, and the pack adds none. Answer slot: if you taught any of these subjects, say which, in your own words; if you did not, or another teacher did, say so plainly and say what you would want to learn first |
| F4 | "differentiate instruction using assessment data" — K12 Jobs Board representative posting | none given | none | [inferred] | discovery | Silent in your material. The district's published belief says assessments "inform teaching and never replace it", so expect this topic. Answer slot: if assessment results ever changed what you did with a group, say what, in your own words; if they did not, or that was not yours to decide, say so plainly and say what you would look at first |
| F5 | "keep clear classroom routines" — K12 Jobs Board representative posting | none given | none | [inferred] | discovery | Silent in your material, and the district's hiring page names classroom routines as a panel topic. Answer slot: if you ran routines in your third-grade room, say what they were and why, in your own words; if you did not, or they were set for you, say so plainly and say how you would set them up |
| F6 | "communicate regularly with families" — K12 Jobs Board representative posting | "I write a weekly email to families" — your CV | medium | [inferred] | none | Lead with it in the quote's own terms: you write a weekly email to families. Limit, as the pack's observation: the district's published belief is that each teacher speaks with every family each term, and your material shows the email, not conversations. D1 and E2 rehearse that edge |
| F7 | "work with the grade-level team" — K12 Jobs Board representative posting | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your CV | medium | [inferred] | none | Lead with the move at its own scope. The limit is yours and stated: "I haven't been a team lead." Say both, in that order, and never let "led the move" drift into "led the team" |
| F8 | "experience in grades 3 to 5 preferred" — K12 Jobs Board representative posting | "Six years teaching third grade at a public elementary school in Joliet" — your CV | medium | [inferred] | none | Third grade sits inside the band the posting names. Words: "For six years I taught third grade at a public elementary school in Joliet." Nothing is inspected behind the line, so expect a probe on what that year looked like |
| F9 | "Fourth Grade Teacher position" — Halvering invite | "I've never taught fourth grade" — your CV | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't taught fourth grade." Then F8's quote at its own scope. Then a plan, said as a plan and never as a past: what you would do in your first weeks. Nothing added to make the gap feel smaller |

## Reading the interviewer

Public professional footprint only. Only the principal is named; the two teammates are not, so there is no read for them.

| Fact | Provenance | What it means for you |
|---|---|---|
| Dolores Vantongeren has been principal of Halvering Elementary School since 2022, after nine years as a reading specialist (ilprincipalsforum.example) | [grounded] | Expect reading instruction to be probed with depth, and expect her to hear the difference between describing reading and doing it |
| Her 2025 forum talk, "Small Groups, Big Readers", covered weekly reading conferences in grades 3 to 5 (ilprincipalsforum.example) | [grounded] | Her recurring theme is reading in small groups and conferences, so C2 and E1 are the likeliest places it surfaces |
| Mirror opportunity: a shared professional interest in reading. Her path is reading specialist to principal; your side is F2's "I've run the after-school reading club for the last two years" | [grounded] | Use it through R1, a reverse question about her view of reading in fourth grade. It is a shared interest, not a shared path, and your material shows no reading-specialist role |

## Persona table

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the fourth-grade and team-lead gaps | Highest. The principal's hiring-manager prior is Case plus Skeptic, and F9 and F7 are stated gaps. 5 questions | Rehearse A1 until it is boring: the plain acknowledgment, the adjacent quote at its scope, then a plan |
| Peer Evaluator | The two teammates ask how you would work beside them | High. The peer prior is Peer Evaluator plus Prober, and the loop source puts two grade-level teachers on the panel. 4 questions | Reciprocity: what you bring the team, with seam principles rather than pretended knowledge of their seam |
| Case/Strategist | A live reading or classroom scenario from the principal | High. Hiring-manager prior, tilted toward reading by her published talk topic. 4 questions | Clarify, objective, approach, risks; think aloud; challenge one premise respectfully |
| Values/Behavioral | Scenarios themed on the district's published beliefs and on families | Medium. The district's hiring page names families as a panel topic and its beliefs are published; no dedicated values round is documented. 3 questions | Map a story only where your own quoted sentence carries one; otherwise use the selection scaffold and its honest branch |
| Data-Driven Prober | Teammates press on how you know things: assessment, the email, the club | Medium. Second peer-prior persona; F4 is a silent row. 3 questions | Know what you can and cannot say about each line, and say plainly when you do not know |
| Conversational | The opening biography question, in a friendly register | Low-medium. Panels open this way and casual questions are still scored. 2 questions | A 90-second arc built only from your own lines |

Pressure is left out: nothing in the invite, the hiring page or the principal's footprint points to a stress format.

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've taught third grade. What will be different for you on day one in fourth grade?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet" | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment: "I haven't taught fourth grade." Then the adjacent fact at its scope: "For six years I taught third grade at a public elementary school in Joliet." Then a plan, in the future tense: what you would do in your first weeks to learn how fourth grade works here. Answer slot: if you have already looked at fourth-grade expectations, say what you read; if you have not, say so plainly. Hold through two follow-ups by returning to the grade you have taught and the plan, never by claiming fourth-grade knowledge. Concede specifically what you do not yet know | F9 is the stated gap and F8 the adjacent evidence. JD because it scores the role's grade requirement; this question will arrive in some form |
| A2 | "I don't see a team lead role in your background. This job works with a grade-level team, so how would you handle that?" | JD | [grounded] "I've never been a team lead"; "I led our grade level's move to a new reading curriculum in 2024" | Plain acknowledgment first: "I haven't been a team lead." Then the move at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Do not let "move" become "team". Answer slot: if your grade level disagreed at any point during the move, say what happened and which part was yours; if it did not, or you were not involved in that, say so plainly and stay with the move | F7 holds both the limit and the nearest evidence. JD because the team line is a listed responsibility |
| A3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" | Your material states one limit in your own words: "I haven't taught fourth grade." Choose your answer from what is true. If a different area, such as another subject or assessment, is genuinely weaker, say which and what you would do about it. If no other area comes to mind, say so plainly and stay with the grade-level limit and your plan | F9, with F3 and F4 as the rows where your material is silent. JD because it is a stem for the Skeptic that scores honest self-assessment |
| A4 | "Why Halvering, and why fourth grade now?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Your reasons are yours to give, so the pack supplies none. The public facts you may refer to: the board's August 2026 three-year literacy plan, which includes a new grades 3–5 reading curriculum from fall 2027. If you connect it to your own work, say only what the quote says: "I led our grade level's move to a new reading curriculum in 2024." Claim no knowledge of which curriculum the district will pick | F8 and F2 supply the nearest evidence. CO because it tests homework on the district's plan |
| A5 | "Tell me about the reading curriculum change you led. How much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Story-mapped on F2, with only the beats the quote states: the move, your grade level, 2024. Answer slot: the district's plan includes a new reading curriculum, so expect a probe on who chose it and what training followed. If you chose or helped choose it, say how, in your own words; if it was chosen elsewhere, or there was no such step, say so plainly and stay with leading your grade level's move. Hold the claim as "led the move", never "designed the curriculum" | F2 is the evidence. EXP because this is the attribution probe, and the Skeptic asks it when a line sounds bigger than it is |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our team plans together. Where is the seam between your room and ours, and what happens when we disagree?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Offer seam principles rather than pretending to know their seam: what you would ask the team before changing anything. Answer slot: if there was a disagreement on your grade level during the move, say what and how it was settled, in your own words; if there was none, say so plainly and say how you would raise one with colleagues | F7. JD because the grade-level team line is a listed responsibility |
| B2 | "What could you bring our team in your first month?" | JD | [grounded] "I've run the after-school reading club for the last two years"; "I led our grade level's move to a new reading curriculum in 2024" | Reciprocity, not a wish list. Name only what the quotes carry: the club, run for two years, and the move. Answer slot: if you have materials or routines from the club to share, say what; if you do not, say so plainly and say what you would ask the team you could help with | F2 and F7. This is the reciprocity question for a peer panel |
| B3 | "How do you handle credit when work spans teams?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | "We" for what the grade level did, "I" for what you did, and no more than the quote's scope: you led the move. Do not describe who else did what unless you can say it in your own words | F7. EXP because it tests attribution honesty in collegial packaging |
| B4 | "How would you want to learn how our team already works before you change anything?" | JD | [grounded] "I've never taught fourth grade" | A plan, not a past: what you would watch, read and ask in the first weeks, with the plain acknowledgment "I haven't taught fourth grade" as the reason to listen first. No claim to knowledge of this team's practices | F9 and F7. JD because it scores the grade-level team line |

### C. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A student in your class is reading well below grade level in October. What would you do, and what do you need to know first?" | CASE | [generic] | Clarify first (what the reading difficulty looks like, what is already known, who has seen the child), then objective, approach in small steps, how you would tell it is working, and what could go wrong. Think aloud and challenge one premise. The question needs no claim about your past, so the guidance makes none | The district's published belief puts reading first, and F2 and F4 are rows where your own material is thin. Pattern for the problem, not a fact about this employer |
| C2 | "How would you fit weekly reading conferences in small groups into a week with a full class?" | CASE | [grounded] | Structure aloud: who meets, how often, what the other students do meanwhile, and how you would record what you learn. Say plainly where you would want to learn from the team how it is done here. No claim about your past is needed | The principal's 2025 talk covered weekly reading conferences in grades 3 to 5, so the theme is likely. F2 is the row it presses on |
| C3 | "The board's new literacy plan brings a new grades 3–5 reading curriculum from fall 2027. How would you approach a changeover like that?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Bring one point that shows you did your homework on the plan, then your own thinking rather than a recitation of it. Your side is the quote at its scope: you led your grade level's move. Answer slot: if you handled training or family communication during that move, say how; if you did not, or that was someone else's, say so plainly and stay with leading the move | F2 and F7. CO and CASE because it is a live problem set inside the district's current strategy |
| C4 | "Walk me through your first week with fourth graders: what routines do you set and what do you teach first?" | CASE | [generic] | Think aloud as a plan: what you would establish first and why. Answer slot: if you ran routines in your own third-grade room, say what they were; if you did not, or they were set for you, say so plainly and say how you would build them | F5 is a silent row, and the hiring page names classroom routines as a panel topic. The question asks about a plan, not your past |

### D. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Families Are Partners: tell me about a time you worked with a family to help a child." | VAL | [grounded] "I write a weekly email to families" | Selection scaffold: pick a time where a child's need and a family's part in it were both clear. It needs a named stake, what you actually said or did, and how it ended. The only family line your material carries is "I write a weekly email to families", which is an email, so do not stretch it into a conversation. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | F6. VAL because the district's published beliefs name families |
| D2 | "Every Child a Reader: tell me about a time you made sure a child had a plan for their reading." | VAL | [grounded] "I've run the after-school reading club for the last two years" | Selection scaffold: pick a child, what you noticed, what you did, how you knew. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is "I've run the after-school reading club for the last two years", or how you would handle it. Do not describe plans or conferences the quote does not state | F2. VAL because it presses on the district's first published belief |
| D3 | "Teach for Tomorrow, Not for the Test: tell me about a time an assessment changed what you taught." | VAL | [grounded] | Selection scaffold: a named assessment, what it showed, what you changed, what happened next. Your material carries no such story, so none is supplied. If no such time comes to mind, say so plainly, then say how you would use an assessment so that it informs teaching and never replaces it | F4 is a silent row. VAL because the belief reads that assessments inform teaching and never replace it |

### E. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "How do you decide which students need extra support in reading?" | JD | [inferred] | The question presupposes a deciding practice that your material does not state. Answer slot: if you used a measure or a routine to decide, say what it was, in your own words; if you did not, or it was not yours, say so plainly and say what you would look at first. The pack names no assessment for you | F4 and F2, both silent. The principal's footprint is small-group reading, so the probe is likely. Premise comes from the representative posting's data line |
| E2 | "Tell me about your weekly email to families. What goes into it?" | EXP | [grounded] "I write a weekly email to families" | Say what goes in it, in your own words; the content is yours and the pack supplies none. Answer slot: the district's belief is that each teacher speaks with every family each term. If families reply or you talk with them by other means, say how; if not, say so plainly and stay with the email | F6. EXP because it tests whether the line is a habit or a headline |
| E3 | "Tell me about the after-school reading club. What does a session look like?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Describe a session in your own words; the pack supplies none. Answer slot: who comes, how books are chosen and what you do are yours to say. If you set the format, say so; if it was set for you, or there was no format, say so plainly and stay with running it for two years | F2. EXP because a two-year commitment invites detail questions |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey. How did you get to this role?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years" | A 90-second arc built only from these lines: six years in third grade, the move, the club, the weekly email. Your reasons for fourth grade are yours to add, in your own words; the pack supplies none. End on what draws you to this role, not on a summary | F8 and F2. EXP because the biography is scored for economy |
| F2 | "What's a book you'd put in a fourth grader's hands?" | JD | [generic] | Pick a real title you have actually read or used, and say why in a sentence or two. Do not name a book you cannot discuss. If none comes to mind, say so, and say how you would choose | F2's requirement, asked casually. A casual question about a hot topic is still scored |

## Requirement coverage

| Requirement | Questions | Note |
|---|---|---|
| F1 license | none | A term your material shows met; no question, but have your license details ready |
| F2 plan and teach reading | A5, C1, C2, C3, D2, E1, E3, F2 | |
| F3 other subjects | none | Neither the district's hiring page nor your invite names them; the row's answer slot is the rehearsal, and the posting would settle it |
| F4 assessment data | D3, E1 | |
| F5 routines | C4 | |
| F6 families | D1, E2 | |
| F7 grade-level team | A2, B1, B2, B3, B4 | |
| F8 grades 3 to 5 | A1, A4, F1 | |
| F9 fourth grade | A1, A3, B4 | |

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R1 | "You spent nine years as a reading specialist before becoming principal. What does a strong weekly reading conference look like to you in fourth grade?" | Ties to her own path and published talk, and signals you researched her, not just the district | [grounded] |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for the two teammates; it shows you think about their load | [generic] |
| R3 | "How does the fourth-grade team plan together week to week?" | Speaks to the team line and tells you what you would be joining | [generic] |
| R4 | "How will the new grades 3–5 reading curriculum from fall 2027 reach fourth grade here?" | Shows you read the board's literacy plan and care about the changeover | [grounded] |
| R5 | "The plan includes a family reading night at every school each term. Where would a fourth-grade teacher fit in it?" | Connects the district's family belief to a concrete role | [grounded] |
| R6 | "What would you want to see from me by the end of the first term?" | Closes on expectations, and a rapport-style panelist weights this slot heavily | [generic] |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Having taught fourth grade | Negative you stated, F9 | The plain acknowledgment: "I haven't taught fourth grade." Then F8's quote at its own scope. No slot |
| Having been a team lead | Negative you stated, F7 | The plain acknowledgment: "I haven't been a team lead." Then "I led our grade level's move to a new reading curriculum in 2024." No slot |
| Designed or chose the new reading curriculum | Inflated form of F2's "led our grade level's move" | The quote at its own scope. The limit is the pack's observation: the line says the move, not the choice. A5's slot stays inside the move |
| Speaks with every family each term | Inflated form of F6's weekly email | The quote at its own scope: you write a weekly email to families. The limit is the pack's observation: the line says email, not conversations |

## Sources

Provided documents: the Halvering invite as pasted, and your résumé text. A government ID number you included is not needed, was not used, and appears nowhere in this pack. No dossier was present.

Searches sent, 5:

1. "Orrinsford Community School District mission values" returned https://orrinsfordschools.example/about/mission-and-beliefs
2. "Orrinsford Community School District teacher interview process" returned https://orrinsfordschools.example/careers/how-we-hire-teachers
3. "Orrinsford Community School District strategic plan news" returned https://orrinsfordschools.example/news/board-adopts-literacy-plan
4. "Dolores Vantongeren principal Halvering Elementary School" returned https://ilprincipalsforum.example/speakers/dolores-vantongeren
5. "fourth grade teacher job posting Illinois elementary school" returned https://k12jobsboard.example/listings/fourth-grade-teacher

Fetches sent, 2: the mission and beliefs page (full text read), and the K12 Jobs Board posting (full text read).

What the sources established: the district's three published beliefs are Every Child a Reader, Families Are Partners, and Teach for Tomorrow, Not for the Test. Its hiring page describes one 45-minute building panel of the principal and two grade-level teachers, with questions on reading instruction, classroom routines and families, and references taken after the panel, which matches your invite. The board adopted a three-year literacy plan in August 2026. The posting is a representative one from a jobs board, not Halvering's own, and every row drawn from it is `[inferred]`.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Orrinsford Community School District` values | yes | The beliefs by official name, which themed bank D and the families and reading rows |
| 2. `Orrinsford Community School District` interview process, teacher | yes | Confirmed the single 45-minute panel and its topics; persona weights follow it |
| 3. `Orrinsford Community School District` strategy and recent news | yes | The 2026–2029 literacy plan, which fed A4, C3, R4 and R5 |
| 4. `Dolores Vantongeren` `Halvering Elementary School` | yes | The interviewer read, C2 and R1; the two teammates are unnamed, so nothing more was searched |
| 5. representative `Fourth Grade Teacher` JD | yes | No Halvering posting was supplied, so it supplied F2 to F8's requirement text, labeled `[inferred]` |

## Upgrade menu

- The Halvering posting, or any note HR sent about what the panel covers → F2 to F8's `[inferred]` requirement rows become `[grounded]`, and the JD-tagged questions retune to Halvering's actual list
- Your own answers to the answer slots in F2 to F5 (what you taught besides reading, how you used assessments, what your routines were) → those rows upgrade from `discovery`, and the matching questions become story-mapped
- The names and roles of the two team members → a per-person interviewer read and persona weights
- How much time you have before Thursday → a prioritized prep schedule
- A deeper research pass (L2): up to 6 more searches and 2 more fetches, several more minutes → a grounding brief on the district's current strategy and more specific CO and CASE questions
- A `tuesday-dossier.md` from an earlier role check, if you have one → an evidence-derived top objection and sourced prohibited claims in place of the ones inferred here
