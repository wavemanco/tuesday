# Interview pack: Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)

Panel interview, 45 minutes, Thursday. Principal Dolores Vantongeren plus two members of the fourth-grade team (unnamed). Built as one panel session: the district's own hiring page describes teacher hiring as one 45-minute building panel of the principal and two grade-level teachers.

## How to use this pack

- Personas describe how a question is asked. Types describe what is being scored. Every question carries both.
- The five type tags: VAL = behavioral / values alignment (does past behavior show the district's published beliefs); EXP = work-experience deep-dive (does your resume survive scrutiny, and what was actually you); JD = role-driven (can you do the listed job, gaps included); CO = company and strategy knowledge (do you know the district's current direction); CASE = a live problem set in the role.
- Fit rows are numbered F1 to F9. Question letters skip F so the two never collide.
- Guidance is scaffolding, not a script. Where a cell says "answer slot", it is an instruction for the interview, not a question for you now: answer it from your own experience, in your own words, or say plainly that the step was not yours or never existed.
- Highest-ROI prep: A1, the fourth-grade question. It will be asked in some form. The pack's deepest rehearsal sits there.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" — the invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | A gate your material shows met: kind, endorsement and expiry as you stated them. I have not checked the license itself, and confirming it is active is yours. Say it in the quote's terms: "I hold an Illinois Professional Educator License with an Elementary Education endorsement, active through June 30, 2029." Your license number is not needed in this pack and is not used in it |
| F2 | "Fourth Grade Teacher position" — the invite | "I've never taught fourth grade" — your CV | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't taught fourth grade." Then how you would learn it, said as a plan and never as a past. Nothing added to make it smaller; the adjacent work is F3 |
| F3 | "plan and teach reading, writing, math, science and social studies" — a representative fourth-grade posting (K12 Jobs Board), typical for the role, not this team | "Six years teaching third grade at a public elementary school in Joliet" — your CV | medium | [inferred] | transferability | Your material says six years in third grade at a public school, not which subjects, and the words stay there: "I've taught third grade for six years at a public elementary school in Joliet." Answer slot: the representative posting's subject list makes a probe on which subjects were yours likely. If you taught several, say which; if some were taught by others, say so plainly and stay with the third-grade years |
| F4 | "reading instruction" — Orrinsford hiring page: "Panels ask about reading instruction, classroom routines and how you work with families." | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | presentation | Lead with the two sentences in their own terms: you led the grade level's move to a new reading curriculum in 2024, and you run the after-school reading club. Your material says led the move, not chose or built the curriculum; the wording stays at the move |
| F5 | "keep clear classroom routines" — a representative fourth-grade posting (K12 Jobs Board), typical for the role | none given | none | [inferred] | discovery | Your material does not show this. Answer slot: the representative posting and the district's hiring page both put routines in front of a panel. Say, in your own words, how your classroom handles the day; if routines were set by others, or you cannot say, say so plainly and say what you would put in place first |
| F6 | "each teacher speaks with every family each term" — Orrinsford beliefs page, Families Are Partners | "I write a weekly email to families" — your CV | medium | [grounded] | transferability | The quote says a weekly email, and the words stay there: "I write a weekly email to families." Your material says an email, not a conversation. Answer slot: if families answered the emails, say how, in your own words; if they did not, or you do not know, say so plainly and stay with the email |
| F7 | "assessments inform teaching and never replace it" — Orrinsford beliefs page, Teach for Tomorrow, Not for the Test | none given | none | [grounded] | discovery | Your material does not show this. Answer slot: if you have used assessment results to adjust what you taught, say one case in your own words; if you have not, or the adjusting was done by others, say so plainly and say how you would want results to shape a unit |
| F8 | "work with the grade-level team" — a representative fourth-grade posting (K12 Jobs Board), typical for the role | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your CV | medium | [inferred] | transferability | The first quote is adjacent work at its own scope: you led the move. The second is your own stated limit, so the plain words are available: "I've never been a team lead." Answer slot: the representative posting's team line makes a probe on how colleagues took part in the move likely. If colleagues worked with you on it, say how; if not, or it was not yours, say so plainly and return to the quote |
| F9 | "communicate regularly with families" — a representative fourth-grade posting (K12 Jobs Board), typical for the role | "I write a weekly email to families" — your CV | medium | [inferred] | none | No gap in terms, but a resume line with nothing inspected behind it, so expect a probe. Lead with the quote's own terms: weekly, an email, to families |

## Reading the interviewer

| Item | Detail | Source | Provenance |
|---|---|---|---|
| Career pattern | Principal of Halvering Elementary School since 2022, after nine years as a reading specialist | Illinois principals forum speaker page | [grounded] |
| Published talk | 2025 forum talk "Small Groups, Big Readers" covered weekly reading conferences in grades 3 to 5 | Same page | [grounded] |
| Implication | Expect reading instruction questions asked with some depth, since reading is her stated specialty and talk subject | Derived from the two rows above | [inferred] |
| Implication | Describe your own reading work in your own terms; do not borrow her vocabulary for your history | Reframing rule; derived from the talk title | [inferred] |
| Mirror opportunity | Her reading background and your F4 evidence: "I've run the after-school reading club for the last two years" — a shared professional domain, nothing more | F4 | [inferred] |
| The two teachers | Unnamed; no footprint researched | The invite names no one | [generic] |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Quiet, persistent probing of the two gaps you stated: fourth grade (F2) and team lead (F8) | Highest. The principal sits in the hiring-manager seat, which tilts to Skeptic plus Case; your material names both gaps itself | Rehearse the fourth-grade objection until it is boring; hold what the quotes carry; ramp plan said as a plan |
| Peer Evaluator (B) | The two fourth-grade teachers asking what you would need from them and bring them | High. Teachers on a panel sit in the peer seat, which tilts to Peer Evaluator plus Prober | Reciprocity: what you bring, limited to your quotes; "we" for context, "I" for contribution |
| Data-Driven Prober (C) | Line-by-line on your curriculum move and the reading club | Medium-high. Peer seat; the hiring page names reading instruction as a panel topic | Know what you can and cannot say about each line; say plainly when you do not know |
| Case / Strategist (D) | Live problems from the role: reading support, family communication, the district's new plan | Medium. Hiring-manager seat; the board's literacy plan gives them live material | Clarify, then structure, then answer; think aloud |
| Values / Behavioral (E) | Questions mapped to the district's three published beliefs | Medium. No dedicated values round is documented; the beliefs page says three beliefs guide every hire | Stories only where your sentences carry them; scaffold with an honest branch where none does |
| Conversational (G) | Friendly openers, the journey, a day in your classroom | Medium. Opening minutes of most panels; still scored | A 90-second arc made only of your own sentences |
| Pressure (H) | Time-boxed "why you" and attribution probes | Low-medium. A school panel is rarely a stress format, but attribution probes arrive politely | Pause, restate, hold the core claim, concede specifically |

## Question banks

### A. Skeptic (5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've taught third grade. What makes you ready for fourth?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet" | The highest-ROI rehearsal in this pack. Say it plainly first: "I haven't taught fourth grade. I've taught third grade for six years at a public elementary school in Joliet." Then a plan said as a plan: what you would ask the team and what you would read first, in your own words. Hold through two follow-ups by returning to the third-grade years, never by adding fourth-grade knowledge you do not have. Concede specifically: you have not taught this grade | F2 is the stated gap and the likeliest objection; F3 is the adjacent work. JD because it scores the role's grade |
| A2 | "You haven't been a team lead. How do you see your place on our fourth-grade team?" | JD | [grounded] "I've never been a team lead"; "I led our grade level's move to a new reading curriculum in 2024" | Say the plain words: "I've never been a team lead." Then what you did, at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: if colleagues worked with you on the move, say how; if they did not, or it was not yours, say so plainly and return to the quote. Do not describe yourself as a lead of the team | F8 holds both the stated limit and the adjacent work. JD because the posting-style team line is what it scores |
| A3 | "You've been in third grade six years. Why this move, and why Halvering?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | The pack does not supply your reason. Give your actual reason in your own words, naming what draws you to fourth grade and to this school. If part of the reason is simply that you want the new grade, say that plainly | F2 makes a motivation probe near-certain; EXP because it tests whether your story holds together |
| A4 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade"; "I've never been a team lead" | Choose honestly. Your own material names two candidates: the grade itself, and being on a team without having led one. The pack does not pick for you. Say it in one sentence, then one concrete first step, said as a plan | The Skeptic's standard stem; F2 and F8 are the rows it lands on |
| A5 | "What would you do in your first two weeks to get up to speed on fourth grade?" | JD | [inferred] "I've never taught fourth grade" | A plan, not a past: who you would ask, what you would look at, what you would do in the room, all in your own words. The pack supplies no fourth-grade content, standards or materials, and neither should you claim any | F2 again, asked as a forward question so the honest limit is paired with a ramp. Inferred because the plan is yours to write |

### B. Peer Evaluator (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "What would you need from the fourth-grade team, and what would you bring to it?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families" | Reciprocity first: what you bring, in the three quotes' own terms and nothing wider. Then what you need, in your own words; an honest need includes the fourth-grade specifics | F8 and F4 supply the bring; peers weigh whether the hire reduces or adds to their load |
| B2 | "When you and a colleague disagree about how to teach something, what happens?" | VAL | [generic] | Selection scaffold: pick a real disagreement with a named position, what changed, and an intact working relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Peers test disagreement style with equals; no past claim is made for you |
| B3 | "How do you handle credit when work spans a whole grade level?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | "We" for the grade level's work, "I" for what you did: "I led the move." Do not widen it to what the curriculum was or who chose it | F4; the quote says led the move, and a credit probe tests exactly that |
| B4 | "What do you want to learn from this team?" | JD | [generic] | Say it in your own words, tied to fourth grade. The pack supplies no specifics | Pairs with A1 so the honest limit becomes a collegial ask |

### C. Data-Driven Prober (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk us through your grade level's move to a new reading curriculum in 2024." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Tell it at the beats the sentence states: you led, it was the grade level's move, it was a new reading curriculum, it was 2024. Further steps are in your own words only if they were yours; if a part was not yours, say so plainly | F4; the likeliest line to be read closely |
| C2 | "You led the move but haven't been a team lead. What did leading look like?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead" | Hold the quote: "I led our grade level's move to a new reading curriculum in 2024," and the stated limit: "I've never been a team lead." Answer slot: if there were steps you drove, say them in your own words; if "led" meant something narrower or shared, say so plainly. Never upgrade the move into a team role | F8 holds both sentences and an apparent tension a prober will notice |
| C3 | "Tell us about the after-school reading club you run." | EXP | [grounded] "I've run the after-school reading club for the last two years" | Beats the quote states: after school, a reading club, two years, yours to run. Answer slot: the district's belief that assessments inform teaching makes a probe on how you tell students are progressing likely. If you tracked anything, say what, in your own words; if you did not, or it was not yours to track, say so plainly and describe the club as you ran it | F4 and F7 |

### D. Case / Strategist (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "The board adopted a literacy plan with a new grades 3–5 reading curriculum from fall 2027. What would you want to know first?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Clarify before structuring: what the curriculum is, who decides pacing, what support teachers get. Then your approach, thinking aloud. If it helps, one sentence and stop: "I led our grade level's move to a new reading curriculum in 2024." Nothing about how | F4; the district's published plan is the strategy hook for this loop |
| D2 | "A fourth grader reads well below the rest of the class. Walk us through your first month." | CASE | [generic] | Structure it: what you would ask first, what you would look at, what support you would set up, how you would tell it is working, who you would involve. No claim about your past is needed | Reading instruction is a documented panel topic; this is the live version |
| D3 | "A parent writes to say her child is not being challenged. What do you do?" | CASE | [generic] | Structure it: listen first, look at the child's work, reply by a stated time, agree a next step, follow up. No claim about your past | F9 and F6; family communication is a documented panel topic |

### E. Values / Behavioral (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Every Child a Reader. When have you changed how you taught reading because a student was not progressing?" | VAL | [grounded] "I've run the after-school reading club for the last two years" | Selection scaffold: pick a time with a named student need, a change you made, and what followed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is the reading club in the quote's own terms, or how you would handle it | The belief is the district's published wording; F4 is the nearest evidence |
| E2 | "Families Are Partners. How do you keep families involved in what their child is learning?" | VAL | [grounded] "I write a weekly email to families" | Story-mapped on the quote's beats: weekly, an email, to families. Answer slot: if families answered the emails, say how, in your own words; if they did not, or you do not know, say so plainly and stay with the email | F6 and F9; the belief names conversations, the quote names emails |
| E3 | "Teach for Tomorrow, Not for the Test. What role should assessment results play in your teaching?" | VAL | [grounded] | A position in your own words. Answer slot: if you have used results to adjust a lesson, say one case; if you have not, or the adjusting was not yours, say so plainly and say how you would want results to shape a unit | F7 has no evidence, so this is a slot, not a story |

### G. Conversational (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through your journey to teaching." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years" | A 90-second arc made of your own sentences: the license and endorsement (F1), six years in third grade, the move, the club. Why you became a teacher is yours to say; the pack does not supply it | F1 and F4; casual openers are still scored |
| G2 | "What does a day in your classroom look like?" | JD | [inferred] "Six years teaching third grade at a public elementary school in Joliet" | Answer slot: the representative posting lists the subjects and routines of the role. Describe a day from your third-grade years in your own words; if some subjects were taught by others, or routines were set by others, say so plainly and say what you would put in place | F3 and F5, the two rows with no evidence beyond the grade |

### H. Pressure (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Sixty seconds: why you over a teacher who already teaches fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families" | Pause, then: "I haven't taught fourth grade. I've taught third grade for six years, I run the after-school reading club, and I write a weekly email to families." Hold through two follow-ups by returning to those sentences. Do not claim to be stronger | F2 conceded, F4 and F9 held |
| H2 | "That curriculum move: how much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Hold: "I led our grade level's move to a new reading curriculum in 2024." Concede specifically what was shared or not yours, in your own words. Never fold on the core sentence just to restore harmony | F4; the attribution probe in polite packaging |

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R1 | "You came to the principal's role after nine years as a reading specialist. How does that shape what you look for in how reading is taught across fourth grade?" | Ties to her own path and turns an interrogation into a peer conversation | [grounded] Illinois principals forum speaker page |
| R2 | "Your 2025 talk, Small Groups, Big Readers, covered weekly reading conferences in grades 3 to 5. What does that look like in a fourth-grade room here?" | Shows you researched her, and moves you to practice | [grounded] Same page |
| R3 | "The board's plan brings a new grades 3–5 reading curriculum from fall 2027. What would you like a new fourth-grade teacher doing before then?" | Shows district-level awareness and asks for a ramp | [grounded] District news page |
| R4 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity question for the two teachers; shows you think of their load | [generic] |
| R5 | "How are new fourth-grade teachers supported in their first year here?" | Turns F2 into a forward-looking question without confessing it | [generic] |
| R6 | "What does a strong first term look like for this role?" | Asks for the scoring sheet in the room | [generic] |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | Negative the candidate stated, F2 | The plain acknowledgment F2 gives: "I haven't taught fourth grade." Plan only; no slot |
| Was a team lead, or led the grade-level team | Negative the candidate stated, F8 | The plain acknowledgment: "I've never been a team lead." The quote "I led our grade level's move to a new reading curriculum in 2024" at its own scope; A2 and C2 stay there |
| Chose, designed or built the reading curriculum | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation, not words for you: the material says led the move, not chose or built the curriculum. C1 and H2 stay inside the move |
| Spoke with every family each term | Inflated form of F6 | F6's quote at its own scope. The limit is the pack's observation: the material says a weekly email, not conversations. E2's slot stays inside the email |

## Requirement coverage

| Requirement | Questions |
|---|---|
| F1 License and endorsement | — none, and why: a term your material shows met, not a skill to rehearse; it appears in the G1 arc |
| F2 Fourth Grade Teacher position | A1, A3, A4, A5, H1 |
| F3 plan and teach the subjects | G2 |
| F4 reading instruction | C1, C3, D1, D2, E1, H2 |
| F5 classroom routines | G2 |
| F6 families, as the district words it | E2 |
| F7 assessments inform teaching | E3, C3 |
| F8 work with the grade-level team | A2, B1, B2, B3, C2 |
| F9 communicate regularly with families | D3, E2 |

## Sources

Provided: the invite text and your resume, both pasted. No tuesday-dossier.md was present.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | yes | Search "Orrinsford Community School District mission values" returned https://orrinsfordschools.example/about/mission-and-beliefs, fetched. Three published beliefs named; themed E1 to E3 and F6, F7 |
| 2. `{company} interview process {role family}` | yes | Search "Orrinsford Community School District teacher interview process" returned https://orrinsfordschools.example/careers/how-we-hire-teachers, fetched. Loop is one 45-minute panel of the principal and two grade-level teachers; persona blend follows it. No values round is named on the page, so no values cheat sheet is built. Page age not stated |
| 3. `{company} strategy` / recent news | yes | Search "Orrinsford Community School District strategic plan news" returned https://orrinsfordschools.example/news/board-adopts-literacy-plan. Moved D1 and R3 |
| 4. `{interviewer name} {company}` | yes | Search "Dolores Vantongeren principal Halvering Elementary School" returned https://ilprincipalsforum.example/speakers/dolores-vantongeren. Moved the interviewer read, R1 and R2. The two teachers are unnamed |
| 5. representative `{role title}` JD | yes | Search "fourth grade teacher job posting Illinois elementary school requirements" returned https://k12jobsboard.example/listings/fourth-grade-teacher. No full posting was supplied, so it supplies F3, F5, F8 and F9, each labeled inferred |

## Upgrade menu

- The full posting text → F3, F5, F8 and F9 move from inferred to grounded, and the coverage table is rebuilt on the posting's own lines
- Anything HR or the principal said about focus areas or a demo lesson → a build section for any announced deliverable, and tighter persona weights
- The two teachers' names → an interviewer read for each and tailored reverse questions
- Your answers to the answer slots on F3, F5, F6, F7 and F8 → those rows become stories carried by your own quotes
- A deeper research pass, offered once → up to 6 more searches and 2 more fetches, several more minutes: a district strategy brief, the principal's talks in depth, loop reports and recent org context, which would add a grounding brief
- A tuesday-dossier.md from an earlier review → verified evidence and standing prohibited claims; not needed to use this pack
