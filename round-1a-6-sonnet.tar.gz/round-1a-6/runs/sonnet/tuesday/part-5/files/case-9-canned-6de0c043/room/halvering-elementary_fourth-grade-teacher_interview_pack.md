# Interview pack: Fourth Grade Teacher, Halvering Elementary School

**Role:** Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)
**Round:** One 45-minute panel on Thursday: Principal Dolores Vantongeren and two members of the fourth-grade team (their names were not given)
**Mode:** Session. Built for one panel, which is what your invite describes and what the district's hiring page describes too.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and only say what you actually did.

| Type tag | What it scores |
|---|---|
| VAL | Whether past behavior shows the district's published beliefs |
| EXP | Whether your CV's claims hold up under follow-up, and what was actually yours |
| JD | The role itself, including where your background is thin |
| CO | Whether you know the district's current direction |
| CASE | How you reason through a live classroom problem |

The highest-ROI rehearsal in this pack is **S1**, the fourth-grade question. It will be asked in some form.

## Fit snapshot

No job description was supplied. The requirements below are quoted from your invite and from two district pages read for this pack (the beliefs page and the hiring page). Requirements the district states but your material is silent on are answer slots, not claims.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" — your invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | A term, and your CV shows it met: the credential, its endorsement, its status and its expiry. The stated grades include fourth grade. Nothing is inspected behind the line, and this pack does not look the licence up; confirming your record matches what you wrote is yours. Say it as written |
| F2 | "Panels ask about reading instruction" — district hiring page; "Every Child a Reader" — district beliefs page | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | presentation | These two sentences reach reading from the curriculum side and the club side, in other terms than instruction. Say them as written. The limit is the pack's observation: your material does not say what reading instruction looked like in your own classroom, so expect the probe there |
| F3 | "Families Are Partners: each teacher speaks with every family each term" — district beliefs page | "I write a weekly email to families" — your CV | medium | [grounded] | transferability | The belief says speaks with; your material says writes. Words: "I write a weekly email to families." Answer slot: expect a probe on direct contact. If you have spoken with families directly, say how and when, in your own words; if not, say so plainly and stay with the email |
| F4 | "classroom routines" — district hiring page | "Six years teaching third grade at a public elementary school in Joliet" — your CV | low | [grounded] | discovery | The sentence touches the requirement without showing routines. Answer slot: the district says panels ask about classroom routines. If routines in your third-grade room were yours to set, say which and how you decided; if they were set school-wide, or you did not set them, say so plainly and describe how you would set them for a new class |
| F5 | "Fourth Grade Teacher position" — your invite | "I've never taught fourth grade" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't taught fourth grade." Then how you would learn it, said as a plan and never as a past. Never a claim to fourth-grade teaching, and nothing added to make the gap feel smaller |
| F6 | "Fourth Grade Teacher position" — your invite | "Six years teaching third grade at a public elementary school in Joliet" — your CV | medium | [grounded] | transferability | Adjacent work, held at its own scope: third grade. Your material does not say how fourth grade differs, so the words stay at third grade. Answer slot: if you have worked alongside fourth-grade colleagues or used fourth-grade materials, say how, in your own words; if not, say so plainly and return to the third grade you taught |
| F7 | "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it" — district beliefs page | none given | none | [grounded] | discovery | Your material is silent here, which is not the same as no evidence. Answer slot: if results from your own class changed what you taught next, say what you saw and what you changed, in your own words; if that was not a step you took, or was decided school-wide, say so plainly and describe how you would want results to inform your next lesson |
| F8 | "Every Child a Reader: no student leaves third grade without a reading plan" — district beliefs page | none given | none | [grounded] | discovery | Your material is silent here. Answer slot: if you have written or contributed to a reading plan for a student, say whose part was yours, in your own words; if there was no such plan, or it was not yours, say so plainly and describe how you would approach a student who needed one |

## Reading the interviewer

Public professional footprint only. Two of the three panelists are unnamed, so this covers the principal.

| Fact | Source |
|---|---|
| Principal of Halvering Elementary School since 2022, after nine years as a reading specialist | Illinois principals forum speaker page, search snippet, page not fetched |
| 2025 forum talk "Small Groups, Big Readers" on weekly reading conferences in grades 3 to 5 | Same page |

What it means in practice:

- Her background is reading, so S2 and S4 carry answer slots for "what happened in the room" follow-ups, not just "what did you run".
- Her published theme is small-group reading, so C1 is the likeliest case to see.
- The shared vocabulary is reading. F2's sentence "I led our grade level's move to a new reading curriculum in 2024" is the one that speaks it, at its own scope.
- Two reverse questions are tied to her path and talk: RQ1 and RQ2.

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | The principal probing the fourth-grade jump, the curriculum move, why now | Highest. A hiring-manager prior favors it, and F5 is a stated gap against the role's own title | Rehearse S1 until it is boring, using only the two sentences quoted in its Provenance |
| Peer Evaluator | The two fourth-grade teachers asking what you would need, who gets credit, where the seam is | High. Two grade-level peers sit on the panel, and a peer prior favors it | Reciprocity: ask before you offer; speak of the team as "we" and of yourself as "I" only for what you can name as yours |
| Case/Strategist | Live classroom problems: a struggling reader, a first week | Medium-high. A hiring-manager prior, plus the principal's public reading and small-group theme | Clarify, set the objective, approach, check, risks; think aloud |
| Values/Behavioral | Scenarios tied to the district's three published beliefs | Medium. The hiring page names no values round, but "Three beliefs guide every hire" on the beliefs page makes them a likely theme | Where a quoted sentence carries a story, map it; where none does, use the selection scaffold and its honest branch |
| Conversational | Panel openers: "tell us about yourself" | Low-medium. Every panel opens somewhere, and casual questions are still scored | A 90-second arc built only from your own sentences |
| Data-Driven Prober | Follow-ups on the curriculum move and the club | Low. Your CV states no figures to probe, so this shows up as collegial follow-ups, not number audits | Say plainly what you do and do not know about how anything was counted or measured |
| Pressure | Not included | Not plausible for an elementary building panel on the evidence read; dropped, not padded | Not applicable |

## Question banks

### Skeptic (weight highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "I don't see fourth grade in your background — how would you handle the jump from third?" | JD | [grounded] "I've never taught fourth grade" and "Six years teaching third grade at a public elementary school in Joliet" | The highest-ROI rehearsal in this pack. Hold only what the quotes carry: "I haven't taught fourth grade. I've spent six years teaching third." Then the plan, spoken as a plan and never as a past: what you would ask the two fourth-grade teachers first and what you would read before day one, in your own words. Follow-up 1, "What will be hardest?": name one thing you expect to learn and how. Follow-up 2, "And if the team does it differently?": hold your plan and concede what you do not yet know about fourth grade. Answer slot: if you have worked alongside fourth-grade colleagues or used fourth-grade materials, say how, in your own words; if not, say so plainly and return to the third grade you taught. The limit, named before it is asked for: your material does not say how fourth grade differs, so say what you would ask, never what you know | F5 is a stated gap against the role's own title, so this objection arrives in some form; F6 is what you hold. JD because it scores the stated role, and the Skeptic's delivery is what you rehearse |
| S2 | "Tell us about the move to a new reading curriculum at your grade level." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Tell the beats the sentence states: the move, your grade level's, 2024, and that you led it, in your own words. Answer slot: the district's belief "Every Child a Reader" makes a probe on what changed in the classroom likely. If you chose the curriculum, or decided how it was introduced, say which and how; if the choice was made elsewhere, or you did not decide how it was introduced, say so plainly and stay with the move you led | F2 is your strongest reading evidence and the likeliest place to be probed; EXP because it tests what was actually yours |
| S3 | "Why Halvering, and why now?" | EXP | [generic] | Your reason is yours, and nothing in your material states one. Say your actual reason in a sentence or two. Then, only if it is true for you, tie it to one of the three beliefs on the district's page. If you cannot name a reason yet, say what you are looking for in a fourth-grade classroom and stop | The Skeptic's motivation stem; F5 is why it will be asked. EXP because it tests the consistency of your story |
| S4 | "Tell us about the reading club." | EXP | [grounded] "I've run the after-school reading club for the last two years" | Say it in the sentence's terms: an after-school reading club you have run for two years. Answer slot: "Every Child a Reader" makes a probe on who the club serves and what happens in a session likely. If you decided who joins or what is read, say how, in your own words; if those were not yours to decide, or there was no set approach, say so plainly and describe how a session runs | F2's second sentence, probed the way a reading specialist probes. EXP because it tests what was yours |

### Peer Evaluator (weight high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "You would be joining our fourth-grade team. What would you need from us, and what could you bring?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" and "I write a weekly email to families" | Reciprocity, ask first and offer second. What you need, as questions you would ask: how the year's reading is sequenced, how the team plans, what they want from a new teammate. What you bring, only what the sentences carry, in your own words: the grade level's curriculum move you led, and the weekly email to families | A peer prices what the hire costs and contributes to their own work; F2 and F3 are what you bring. JD because it scores the team part of the role |
| P2 | "Tell us about a time you and a colleague disagreed about how to teach something." | VAL | [generic] | Pick a time with a named disagreement about teaching: what each of you wanted, how it ended, and the working relationship afterwards. "We" for context, "I" for your own part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The peer's disagreement-with-equals probe; VAL because it scores behavior, not content. No row carries a story for it, so this is the scaffold case |
| P3 | "You led the grade level's move to the new curriculum — how much of that was you and how much was the team?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" and "I've never been a team lead" | Hold the sentence: "I led our grade level's move to a new reading curriculum in 2024." If asked whether that made you the team lead, the plain answer is yours: "I haven't been a team lead." Hold through two follow-ups by returning to the sentence, never by adding to it. Answer slot: which parts were yours to decide and which were the team's, in your own words; if the decisions were shared, say so plainly and name only your part | The credit-sharing probe, aimed at F2. EXP because it tests attribution |
| P4 | "Our students arrive from third grade. What should fourth-grade teachers know about them, and what should third grade know about us?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | Offer seam principles rather than pretending to know the seam. You taught third grade, in the words of the sentence, so you can say what you would want to ask fourth-grade colleagues about arriving students and what you would want them to ask you. Do not describe how handoffs work here: your material does not say | F6 is the only fourth-grade-adjacent evidence; the seam question is the Peer's native probe. JD because it scores working across the grade boundary |

### Case/Strategist (weight medium-high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Five students in your class are reading well below the rest. Plan the next two weeks." | CASE | [inferred] | Think aloud. Clarify first: what you know about each reader and what has been tried. Then the objective, your approach, how you would check it is working, what could go wrong, and how the family hears about it. No claim about your past is needed, and none is made | Derived from the principal's public small-group reading theme (Reading the interviewer), so `[inferred]`. CASE because it scores structure and reasoning on a live problem |
| C2 | "A parent emails to say their child dreads reading. What do you do this week?" | CASE | [generic] | Structure it: what you would ask first, what you would do for the child, what you would tell the parent and when, and what you would check next. The question needs no claim about your past | F3's belief, asked as a decision. `[generic]` because it is a pattern for the problem, not a fact about this district |
| C3 | "Our Board adopted a three-year literacy plan in August. What stands out to you for fourth grade?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Know the plan as the district's news page gives it: structured phonics from kindergarten to second grade, a new grades 3–5 reading curriculum from fall 2027, and a family reading night at every school each term. Say what you notice for fourth grade: the curriculum change reaches your grade. Then ask what is known about it. Your own sentence stays at its scope; do not claim to know the new curriculum or compare it to the one you moved to. Do not correct their framing | Current strategy: the plan the district's news page says the Board adopted in August 2026. CO because it tests homework. F2 is the one sentence it touches |
| C4 | "It is the first week of school. How do you want the room to run by Friday?" | JD | [generic] | Structure it: what students need to know by Friday, how you would teach it, and how you would check it. If routines you set before come to mind, say so in your own words; the question needs no claim about your past | F4's requirement. JD content, CASE delivery; `[generic]` because it is a pattern, not a fact about this room |

### Values/Behavioral (weight medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Our belief is Families Are Partners: each teacher speaks with every family each term. How would you do that?" | VAL | [grounded] "I write a weekly email to families" | Start with what the sentence says: "I write a weekly email to families." Answer slot: the belief says speaks with, and an email is not a conversation, so expect a probe on direct contact. If you have spoken with families directly, say how and when; if not, say so plainly and stay with the email. Then, as a plan only, say how you would make sure each family hears from you each term | F3 is the evidence, and the likeliest place the belief presses. VAL because it scores a published belief |
| V2 | "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it. What does that look like in a classroom?" | VAL | [generic] | Pick a time what students showed you changed what you taught next: the evidence, the change, what students did after. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F7's belief; no sentence of yours carries it, so this is the scaffold case |
| V3 | "Every Child a Reader: no student leaves third grade without a reading plan. Tell us about a student who needed one." | VAL | [generic] | Pick one student, without identifying details: the need, the plan, what changed, what stayed hard. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F8's belief. The belief names third grade, and F6 holds your third-grade sentence. Scaffold case |

### Conversational (weight low-medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "Tell us about yourself and how you got here." | EXP | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" and "Six years teaching third grade at a public elementary school in Joliet" and "I led our grade level's move to a new reading curriculum in 2024" and "I've run the after-school reading club for the last two years" and "I write a weekly email to families" | A 90-second arc with five beats, one per sentence, in this order: your licence and endorsement as written, your six years in third grade, the curriculum move, the club, the weekly email. A sixth beat, why fourth grade, is yours to give; nothing in your material states it | The biography question every panel opens with, and the one place F1 gets said aloud. EXP because it is your CV, spoken |
| R2 | "What is something in reading instruction you have been curious about lately?" | JD | [generic] | Name something real, in your own words; the pack supplies none. If nothing comes to mind, say what you would like to learn from the fourth-grade team | A casual question on the topic F2 raises, which is still scored |

### Data-Driven Prober (weight low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "What changed for students after the new reading curriculum, and how do you know?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Answer slot: if you looked at any student results before and after, say what you looked at, what it showed and what you would defend least about reading it, in your own words; if nothing was measured, or it was not yours to measure, say so plainly and stay with "I led our grade level's move to a new reading curriculum in 2024." "I don't know" is an honest branch | F2 probed the way a prober would. EXP because it tests whether the claim survives a follow-up |
| D2 | "How many students come to the reading club, and who decides who joins?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Answer slot: if you know the number, say it and how you know it; if you do not, say so plainly. If you decided who joins, say how; if that was not yours, or there was no deciding, say so plainly and stay with the club you ran | F2's second sentence, with its denominator asked for. EXP because it tests what was yours |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 licence and endorsement | R1 |
| F2 reading instruction | S2, S4, C1, C3, R1, R2, D1, D2 |
| F3 families | V1, C2 |
| F4 classroom routines | C4 |
| F5 and F6 fourth grade | S1, S3, P4 |
| F7 assessments inform teaching | V2 |
| F8 reading plan | V3 |
| Team: the invite names two team members but states no requirement text | P1, P2, P3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "You spent nine years as a reading specialist before becoming principal. What changes for readers between third and fourth grade, from where you sit?" | Tied to the principal's own path. It turns the fourth-grade gap into a conversation with the person best placed to answer it |
| RQ2 | "Your talk on weekly reading conferences covered grades 3 to 5. How do fourth-grade teachers here fit them into the week?" | Shows you read her public work, and asks about her own theme |
| RQ3 | "The Board's literacy plan brings a new grades 3–5 reading curriculum from fall 2027. How is the fourth-grade team being involved in that?" | Shows you know the plan, and asks about the change that reaches your grade |
| RQ4 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for the two peers on the panel |
| RQ5 | "What does a strong first year look like for a fourth-grade teacher here, and how is a new one supported?" | Answers F5's open question from the team's side |
| RQ6 | "The plan includes a family reading night each term. How do fourth-grade teachers take part?" | Ties to the belief in F3 and shows you read the plan |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | A negative you stated: "I've never taught fourth grade" — your message (F5) | "I haven't taught fourth grade," and F6's sentence at third grade, then a plan said as a plan. S1's slot stays on colleagues and materials |
| Has been a team lead, or led the grade-level team | A negative you stated: "I've never been a team lead" — your message | "I haven't been a team lead," and "I led our grade level's move to a new reading curriculum in 2024" at its own scope. P3 stays on the move |
| Chose, designed or owned the reading curriculum | Inflated form of F2 | F2's sentence at its own scope. The limit is the pack's observation: your material says the move, not which curriculum or how it was introduced. S2's slot stays inside the move |
| The curriculum move or the club improved students' reading | Inflated form of F2 | F2's sentences at their own scope. Your material states no results; D1 asks only whether anything was looked at |
| Spoke with every family each term | Inflated form of F3 | "I write a weekly email to families" at its own scope. Your material says writes, not speaks; V1's slot stays inside the email |

## Sources

Provided documents: the invite, and your CV and message. No dossier was present.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Orrinsford Community School District values` | yes | F3, F7 and F8; V1 to V3. No values cheat sheet: the hiring page names no values round, so none is detected |
| 2. `Orrinsford Community School District teacher interview process` | yes | Loop: one 45-minute building panel; persona blend; F2 and F4 topics; C4 |
| 3. `Orrinsford Community School District strategic plan news` | yes | C3, RQ3, RQ6 |
| 4. `Dolores Vantongeren Halvering Elementary School principal` | yes | Reading the interviewer; RQ1, RQ2; C1's derivation |
| 5. `fourth grade teacher job description Illinois elementary school` | yes | Moved nothing: it returned one job-board snippet, which is not a raising source, so no row or question rests on it |

Searches and what came back:

- `Orrinsford Community School District values mission`: https://orrinsfordschools.example/about/mission-and-beliefs
- `Orrinsford Community School District teacher interview process`: https://orrinsfordschools.example/careers/how-we-hire-teachers
- `Orrinsford Community School District strategic plan news`: https://orrinsfordschools.example/news/board-adopts-literacy-plan (snippet read, page not fetched)
- `Dolores Vantongeren Halvering Elementary School principal`: https://ilprincipalsforum.example/speakers/dolores-vantongeren (snippet read, page not fetched)
- `fourth grade teacher job description Illinois elementary school`: https://k12jobsboard.example/listings/fourth-grade-teacher (snippet read, page not fetched, not used)

Fetches: the beliefs page and the hiring page above.

## Upgrade menu

- The posting's full text → F4, F7 and F8 become requirements quoted from the posting instead of from the district's pages, and C4 and R2 can be tightened to its terms
- Anything HR said about preparing, such as a sample lesson → a build section for each declared deliverable; none was declared, so none is built
- The two fourth-grade teachers' names or roles → interviewer reads and persona weights for the peers, and a reverse question tied to their paths
- Your answers to the answer slots in F3, F4, F6, F7 and F8 → those rows become quoted evidence and the matching guidance becomes story-mapped
- How much time you have before Thursday → a prioritized prep schedule sized to it
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a fuller picture of the district's strategy and recent organizational context for C3 and the reverse questions
- A `tuesday-dossier.md` from an earlier session, if you have one → verified evidence and claims to avoid, carried in so the guidance rests on them
