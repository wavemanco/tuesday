# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

Orrinsford Community School District. Session mode, one 45-minute panel on Thursday: Principal Dolores Vantongeren and two members of the fourth-grade team (names not given). Built from your invite and your resume only; no posting text was provided.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Tag | Name | What it tests |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the district's published beliefs |
| EXP | Work-experience deep-dive | Whether your CV lines hold up; what was actually you |
| JD | Role-driven | The listed job, including its gaps |
| CO | Company and strategy knowledge | Homework on the district's current plans |
| CASE | Live problem | Structure and reasoning on a problem from the role |

Where guidance says "Answer slot", it is an instruction for the interview, not a question for now: answer from your own experience, or say plainly it was not yours.

## 1. Fit snapshot

Row F1's quote stops before the licence number, which this pack does not use.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — your invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | A gate your material shows met, so it routes like any row. Say it in the quote's own terms and stop. Checking the record is yours to do, and no number is needed in the room |
| F2 | "reading instruction" — district hiring page | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | transferability | Both are reading work; neither says how reading is taught in your room, so the words stay at the quotes: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: panels ask about reading instruction, so expect a probe on your day-to-day teaching of reading. If you taught reading to your own class, say how, in your own words; if the teaching was set by the curriculum or by someone else, or there was no such routine, say so plainly and stay with the move and the club |
| F3 | "classroom routines" — district hiring page | "Six years teaching third grade at a public elementary school in Joliet." — your CV | low | [inferred] | discovery | The sentence shows the teaching, not routines. Answer slot: if you set routines in your room, say which and why, in your own words; if none were yours to set, or you ran none, say so plainly and stay with the six years |
| F4 | "how you work with families" — district hiring page | "I write a weekly email to families." — your CV | medium | [grounded] | none | The quote already reaches it. Lead with the email in its own terms, weekly and to families, because a named habit beats an adjective. Expect a follow-up on what else reaches families (F5) |
| F5 | "Families Are Partners: each teacher speaks with every family each term." — district Mission and Beliefs page | "I write a weekly email to families." — your CV | low | [inferred] | discovery | The email is writing and the belief is speaking, so the bridge is not stretched. Answer slot: if anything besides the email reaches families, say what, in your own words; if the email is the whole of it, say so plainly and stay with the email |
| F6 | "work with the grade-level team" — K12 Jobs Board listing, a representative posting | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your CV | medium | [inferred] | transferability | Words stay at the quotes: "I led our grade level's move to a new reading curriculum in 2024." If asked about leading a team: "I haven't been a team lead." Answer slot: if colleagues worked on the move with you, say what each of you did, in your own words; if the work was not shared, or it was not yours, say so plainly and stay with the move |
| F7 | "Fourth Grade Teacher position" — your invite | "I've never taught fourth grade" — your CV | none | [grounded] | capability | A gap wording cannot close, and you said so. Words: "I haven't taught fourth grade." Then how you would learn the grade, said as a plan and never as a past. Never a claim to fourth-grade teaching, and nothing added to make the gap feel smaller |
| F8 | "Every Child a Reader: no student leaves third grade without a reading plan." — district Mission and Beliefs page | "I've run the after-school reading club for the last two years" — your CV; "Six years teaching third grade at a public elementary school in Joliet" — your CV | low | [inferred] | discovery | The quotes show a club and third grade; neither shows reading plans. Answer slot: the belief puts reading plans in third grade in play. If reading plans were part of your third-grade work, say how they worked and what was yours, in your own words; if there was no such practice, or it was not yours, say so plainly and stay with the club and the six years |
| F9 | "assessments inform teaching and never replace it" — district Mission and Beliefs page | none given | none | [grounded] | discovery | Your material is silent on assessment. Answer slot: if assessment results shaped your own planning, say what and how, in your own words; if they did not, or planning was set by others, say so plainly and say how you would approach it |
| F10 | "differentiate instruction using assessment data" — K12 Jobs Board listing, a representative posting | none given | none | [inferred] | discovery | Answer slot: if you adjusted teaching for different learners using data, say how, in your own words; if you did not, or it was not yours to adjust, say so plainly |
| F11 | "plan and teach reading, writing, math, science and social studies" — K12 Jobs Board listing, a representative posting | none given | none | [inferred] | discovery | Answer slot: name the subjects you taught, in your own words; if you taught only some, say so plainly and say where you would want support |

## 2. Requirement coverage

| Row | Covered by |
|---|---|
| F1 | D2 |
| F2 | C4, G1, G2 |
| F3 | C3 |
| F4 | B4, E1 |
| F5 | E1 |
| F6 | A4, B1, B3 |
| F7 | A1, A2, A3, H1 |
| F8 | E2 |
| F9 | E3 |
| F10 | E3 |
| F11 | A5 |

The district's published literacy plan is covered by C1 and reverse question 2.

## 3. Reading the interviewer

| Item | Finding | Source | Provenance |
|---|---|---|---|
| Principal Dolores Vantongeren: career | Principal of Halvering Elementary School since 2022, after nine years as a reading specialist | Illinois principals forum speaker page | [grounded] |
| Principal Dolores Vantongeren: published talk | 2025 forum talk "Small Groups, Big Readers", on weekly reading conferences in grades 3 to 5 | Illinois principals forum speaker page | [grounded] |
| Implication 1 | Expect depth on reading instruction from her; read the talk if you can find it, and ask a real question rather than claim a practice | Reading of the rows above | [inferred] |
| Implication 2 | Her talk covers grades 3 to 5, so fourth grade sits inside her topic; A1 and C4 are the likeliest places she presses | Reading of the rows above and F7 | [inferred] |
| Mirror opportunity | Shared ground is reading. Your side is F2's quote: "I've run the after-school reading club for the last two years". No shared career jump is offered, because no row carries one | Reading of F2 | [inferred] |
| The two team members | Names not given; treated as peers on the fourth-grade team | Your invite | [grounded] |

## 4. Loop and persona weights

| Item | Finding | Source | Provenance |
|---|---|---|---|
| Loop | One 45-minute building panel: the principal and two grade-level teachers; matches your invite | District hiring page | [grounded] |
| Panel topics | Reading instruction, classroom routines, how you work with families | District hiring page | [grounded] |
| Values-style round | None detected: the hiring page names no round that assesses values. The three published beliefs still theme bank E, so no values cheat sheet is included | District hiring page and Mission and Beliefs page | [grounded] |

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet, persistent probing of the fourth-grade gap and the team question | Highest, 5 questions: F7 and F6 are limits you stated, and the principal chairs the panel | Rehearse A1 until it is boring; plain acknowledgment, then a plan, never a bluff |
| B. Peer Evaluator | Two fourth-grade teachers asking how you would work beside them | High, 4 questions: they are pricing what you add to their team | Reciprocity: what you bring, not only what you need; disagreement stories with spine and tact |
| C. Case / Strategist | Live classroom problems and the district's literacy plan | High, 4 questions: the hiring page names reading instruction and routines, and the principal's path is reading | Clarify first, then structure, then answer; think aloud |
| D. Conversational | Friendly openers: your journey, your licence | Mid, 3 questions: panels open warm and still score it | A 90-second arc built only from your own sentences |
| E. Values / Behavioral | Scenarios tied to the district's three beliefs | Mid, 3 questions: the beliefs are published and map to the panel's family and reading topics | Story where one of your sentences carries it; selection scaffold where none does |
| G. Data-Driven Prober | Asks what sits behind a claim | Low, 2 questions: your material carries no figures, but the 2024 move and the club invite it | Say what you know of how things were checked, and say plainly where you do not |
| H. Pressure | Time-boxed, devil's advocate | Low, 2 questions: a building panel is less likely to press, but A1's gap invites one | Pause, restate, hold through two follow-ups, concede only what is true |

## 5. Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't taught fourth grade before. What will be hardest about the move, and what will you do about it?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet" | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment: "I haven't taught fourth grade." Then the one fact you have: "Six years teaching third grade at a public elementary school in Joliet." Then a plan, said as a plan: name, in your own words, the first two things you would learn about the grade and who you would learn them from. Follow-up 1, "what do you not know yet": answer with something specific you do not know. Follow-up 2, "is third grade enough": hold by returning to the quote, never by adding to it. Follow-up 3, "what if it is harder than you expect": concede only that you have not taught the grade and say what you would do about it | F7 is the stated gap and the likeliest place the panel presses; JD because it scores the role's grade level |
| A2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade"; "I've never been a team lead" | Choose from limits you actually have. Your material shows two you stated: fourth grade and team lead. If you name one, use the plain words: "I haven't taught fourth grade." or "I haven't been a team lead." Then a plan. Answer slot: if there is a weakness you know of beyond those two, name it in your own words; if there is not, say so plainly and stay with the one you chose | F7 and F6 are where the Skeptic aims; JD because it scores fit against the listed job |
| A3 | "You've spent six years in third grade. Why fourth grade now?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | Give your actual reason in one or two sentences, in your own words; the pack does not supply one. Tie it to this school only if the tie is true for you. A reason you would not say aloud to a friend is not yet the answer | F7 makes motivation the likeliest probe; JD because it tests the move the role asks of you |
| A4 | "You haven't been a team lead before. Does that matter for working on this team?" | EXP | [grounded] "I've never been a team lead"; "I led our grade level's move to a new reading curriculum in 2024" | Hold-then-concede. Plain acknowledgment: "I haven't been a team lead." Then the move at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: if colleagues worked on the move with you, say what each of you did; if the work was not shared, or it was not yours, say so plainly and stay with the move. Do not let the move stand in for a team-lead role | F6 holds both quotes and the stated limit; EXP because it tests what was actually yours |
| A5 | "The role covers reading, writing, math, science and social studies. Where are you strongest, and where would you want support?" | JD | [inferred] listing clause, typical for the role and not necessarily this team's | Answer slot: name the subjects you taught, in your own words; if you taught only some, say so plainly, and say where you would want support. Choose a real answer, not a modest one | F11 is silent in your material, so the answer has to come from you; JD because it scores the listed duties |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell us about a time you worked through a disagreement with a colleague." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Story-mapped on F6 only as far as the quote goes: the move, led, at your grade level, in 2024. Answer slot: if colleagues disagreed about the move, say what happened and what part was yours; if they did not, or it was not yours, say so plainly and stay with the move. If no disagreement from it comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle one | F6 is your only team evidence; EXP because it tests what you actually did; the peer stem raises the disagreement theme |
| B2 | "What would you need from us in your first month?" | EXP | [grounded] "I write a weekly email to families"; "I've run the after-school reading club for the last two years" | Reciprocity framing. Name your own real needs, as requests. Then what you bring, at the quotes' scope: you write a weekly email to families, and you've run an after-school reading club for two years. Offer no result you have not stated | F4 and F2 give the two things you can offer a team plainly; EXP because it tests partnership fit |
| B3 | "How do you handle credit when work spans teams?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Use "we" for context and "I" for what you did. The quote says you led the grade level's move, so say that and no more. Answer slot: if colleagues contributed, say what each did; if they did not, or you do not know, say so plainly and stay with the move | F6 again, from the peer's angle: credit-sharing probes catch inflated attribution |
| B4 | "A parent emails you at 9 p.m. unhappy about a grade, and a teammate teaches the same family's other child. What do you do?" | CASE | [generic] | Structure it: what you would ask yourself first, what you would say to the parent and when, what you would tell your teammate and why, and what you would record. The question needs no claim about your past, so the guidance makes none | A live problem from the families topic (F4) with a team seam; [generic] because it is a pattern for the problem, not a fact about this school |

### C. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "In August the board adopted a three-year literacy plan with a new grades 3–5 reading curriculum from fall 2027. What would you want to know about it, and how would you prepare a fourth-grade classroom for it?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Clarify first: what you would ask about the curriculum, its timing and what fourth grade is expected to do. Then structure: what you would learn, from whom, by when. About your past, the quote at its own scope only: "I led our grade level's move to a new reading curriculum in 2024." Do not describe how that move was run beyond the quote | Differentiator question most candidates cannot touch; the plan is in Sources; F2 holds your only related quote |
| C2 | "It's week three. A new student in your fourth-grade class is reading well below grade level. What do you do first?" | CASE | [generic] | Clarify what you would find out first, state the goal, then segment: the child, the family, the classroom, the school's supports. Name how you would tell it is working. Think aloud, and challenge one premise respectfully. The question needs no claim about your past | The district's Every Child a Reader belief (F8) set as a live problem |
| C3 | "It's the first week with a new fourth-grade class. Which routines do you set up first, and why?" | CASE | [generic] | Pick routines you would actually set and give the reason for each. Present them as your plan for this class. Where you did something similar before, say so only if it is true, in your own words | Classroom routines are a named panel topic; F3 shows no routine evidence, so this is the safest place to rehearse the answer |
| C4 | "Tell us about how you teach reading." | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years" | Story-mapped on F2 at the quotes' scope: the curriculum move, and the club. Answer slot: panels ask about reading instruction, so expect a probe on your day-to-day teaching of reading. If you taught reading to your own class, say how, in your own words; if the teaching was set by the curriculum or by someone else, or there was no such routine, say so plainly and stay with the move and the club | F2 is the district's named topic and the principal's field; JD because it scores the listed duty |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk us through your journey. What brought you to this role?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years" | A 90-second arc with three beats the quotes state: six years teaching third grade in Joliet, the grade level's move to a new reading curriculum, the reading club. End with your own reason for this role and this school. Nothing else goes in the arc | The opener is scored even when it feels casual; F2, F3 and F8 supply the beats |
| D2 | "Tell us about your licensure." | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | Say it at the quote's scope: an Illinois Professional Educator License with an Elementary Education endorsement for grades 1–6, registered and active through June 30, 2029. You do not need to recite a number | F1 is the invite's one stated requirement; a plain, ready answer closes it quickly |
| D3 | "What's something in reading instruction you've been curious about lately?" | CO | [generic] | Name something real you have actually been curious about, and why. If nothing comes to mind, say so plainly and name what you would like to learn. Do not invent a recent reading | The principal's background is reading, so a casual question on it is scored; [generic] because it needs no claim about your past |

### E. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Families Are Partners is one of our beliefs. Tell us about a time you worked with a family to support a child." | VAL | [grounded] "I write a weekly email to families" | Story-mapped only as far as the quote: a weekly email, to families. Answer slot: if anything besides the email reached families, say what and what was yours; if the email is the whole of it, say so plainly and stay with the email. If no specific time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4 and F5; the published belief raises the theme |
| E2 | "Every Child a Reader is another. Tell us about a time you helped a child who was behind in reading." | VAL | [grounded] "I've run the after-school reading club for the last two years" | A selection scaffold: pick a time with a child you can describe without a name, a step you took that was yours, and an outcome you can honestly state. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is the club at the quote's scope, or how you would handle it | F8 shows a club and third grade but no reading plans; the belief raises the theme |
| E3 | "Our belief is that assessments inform teaching and never replace it. What does that look like in a classroom?" | VAL | [grounded] the district's published belief; no claim about you | Answer first as a view: what it looks like in a room, in your own words. Answer slot: if assessment results shaped your own planning, say how; if they did not, or planning was set by others, say so plainly and say how you would approach it | F9 and F10 are silent in your material, so the honest branch matters |

### G. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Walk us through the 2024 move to a new reading curriculum, from your grade level's side." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Story-mapped at the quote: you led the grade level's move; the curriculum was a new reading one; the year was 2024. Answer slot: if you set any part of how the move went, say which part and how you decided; if the pace or choices were set by someone else, or there was no such step, say so plainly and stay with the move. Say plainly what you do not know about how it went | F2 is the quote a prober reads closely; EXP because it tests attribution |
| G2 | "Tell us about the reading club: what happens in a session, and how do you tell whether it is helping?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Describe a session in your own words, at the scale you ran it. Answer slot: if you looked at anything to tell how it was going, say what and what it showed; if you did not track anything, say so plainly and say what you would look at | F2 again; the question is premised only on the club |

### H. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Sixty seconds: why you over a teacher who has already taught fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I've run the after-school reading club for the last two years" | Pause, restate. Concede the true thing in one sentence: "I haven't taught fourth grade." Hold on what your material carries: "Six years teaching third grade at a public elementary school in Joliet" and the club. Add your own reason, in your own words. Do not argue that third grade equals fourth | F7 under time pressure; JD because it scores fit |
| H2 | "That curriculum move: how much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Hold through two follow-ups: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: if there were parts of the move others did, say which and who; if you do not know the split, say so plainly and stay with the move | F2 and F6; the attribution probe exists to catch inflation |

## 6. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "You moved from reading specialist to principal. How does that background shape what you look for in a fourth-grade reading block?" | Ties to the principal's own path and shows you researched her |
| 2 | "The board's plan brings a new grades 3–5 reading curriculum from fall 2027. What would a fourth-grade teacher here be doing to prepare, starting this year?" | Shows homework on the district plan and turns the gap in F7 toward preparation |
| 3 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity question for the two peers on the panel |
| 4 | "How does the fourth-grade team plan together, and where would a new teacher fit in?" | Signals interest in the team and invites the peers to describe their practice in their own words |
| 5 | "What does a strong first year look like for a teacher who is new to fourth grade?" | Lets the panel define success and opens the gap kindly |
| 6 | "How do families here hear from teachers each term?" | Connects to the Families Are Partners belief without claiming a practice of your own |

## 7. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I haven't taught fourth grade." Then a plan, never a past. No slot |
| Has been a team lead | Negative the candidate stated, F6 | The plain acknowledgment F6 gives: "I haven't been a team lead." The move at its own scope: "I led our grade level's move to a new reading curriculum in 2024." |
| Chose or wrote the new reading curriculum | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: your material says the move, not who chose or built the curriculum. G1 and H2 stay inside the move |
| Speaks with every family each term | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation: your material says the email, not conversations. E1's slot stays inside what reaches families |

## 8. Sources

Provided documents: the invite from Human Resources, Orrinsford Community School District, and your resume text. A dossier was not present.

Research tier: L1 — searches 5 of 6, fetches 1 of 2

Queries and what came back:

| Query or fetch | Result |
|---|---|
| Search: Orrinsford Community School District mission values | https://orrinsfordschools.example/about/mission-and-beliefs |
| Fetch: the Mission and Beliefs page | Page text: three beliefs, Every Child a Reader, Families Are Partners, Teach for Tomorrow, Not for the Test |
| Search: Halvering Elementary School Orrinsford principal Dolores Vantongeren | https://ilprincipalsforum.example/speakers/dolores-vantongeren |
| Search: Orrinsford Community School District strategic plan news | https://orrinsfordschools.example/news/board-adopts-literacy-plan |
| Search: Orrinsford Community School District teacher interview process panel | https://orrinsfordschools.example/careers/how-we-hire-teachers |
| Search: fourth grade teacher job description Illinois elementary school responsibilities qualifications | https://k12jobsboard.example/listings/fourth-grade-teacher |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | yes | Bank E and rows F5, F8, F9; the beliefs are quoted by name. No cheat sheet, since no values-style round is detected |
| 2. Interview process | yes | The loop: one 45-minute building panel, principal plus two grade-level teachers, with the named topics; persona weights follow it |
| 3. Strategy and recent news | yes | C1 and reverse question 2: the board's three-year literacy plan, adopted August 2026 |
| 4. Interviewer name and company | yes | Section 3 and reverse question 1: career and a published talk |
| 5. Representative role JD | yes | Rows F6, F10 and F11 as [inferred]; the result's text stopped before the qualifications list |

## Upgrade menu

- The full posting text → rows F6, F10 and F11 move from [inferred] to [grounded], and the JD questions can be tightened to this team's own words
- Anything HR said about what to prepare or bring, such as a demo lesson or work samples → a build section for each deliverable named
- The names of the two team members → an interviewer read for each and persona weights per member
- Your own answers to the answer slots in rows F2, F3, F5, F6, F8, F9, F10 and F11 → those rows and their questions regenerate with your words quoted
- How much prep time you have before Thursday → a triage schedule sized to it
- A tuesday-dossier.md from an earlier fit check → verified evidence, a named highest-priority objection and absolute prohibited claims, in place of the ones built here
