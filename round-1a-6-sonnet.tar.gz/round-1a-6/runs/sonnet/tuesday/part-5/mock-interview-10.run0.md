Building your prep pack now. The three company searches were refused, so I'm labelling anything company-specific as generic.
Before the prep, one thing in the invite: it says the process "is carried out entirely on Telegram" and that "your offer and onboarding will be completed in this chat as well". A hiring process run wholly by chat is a known scam pattern, and a chat alone doesn't show who you're dealing with. Until you've checked, hold off on paying anything or sending documents or bank details. Check with the company through contact details you find yourself on its own website or careers page, not through this chat. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as `/var/tmp/tuesday-measure/1a6/runs/sonnet/tuesday/part-5/rooms/case-10-denied-2efc159e/lumenvale-software_customer-support-specialist_interview_pack.md`. I built it for a hiring-manager-style round, since your note doesn't say whether the team lead would be your manager or a peer. It has 18 questions, a fit snapshot against the four requirements in the ad, six reverse questions, and a list of claims the pack won't coach.

Two things to know:
- **Company research:** My three company searches were refused, so nothing in the pack comes from research on Lumenvale. Company-specific questions are marked generic.
- **Biggest objection:** The deepest rehearsal is B2, which comes from your own line "I've never worked for a software company". Your gaps are that line, Freshdesk instead of Zendesk, and no escalation experience in what you told me. Your 3 years of customer service, your daily Freshdesk use and your refunds training for four new starters carry the strongest answers.

Say the word and I'll play the Skeptic on B2 as a live typed drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is the support team lead the person you'd report to, or a peer on the team? The answer reweights every bank.
Can you paste the full job ad, and your CV if you'd like it used? I've worked from your summary, so say skip and I'll carry on.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: lumenvale-software_customer-support-specialist_interview_pack.md -----
# Interview prep pack: Customer Support Specialist, Lumenvale Software

**Interviewer:** the support team lead (name not given). **Format:** a typed text chat. **Relationship assumed:** hiring-manager style, since your note does not say whether the team lead would be your manager or a peer. Weights below rest on that assumption and shift if it is wrong.

**Loop:** one session, a text chat with the support team lead (your message). That establishes the loop, so no archetype fallback is used. No round assessing values is documented, so there is no values cheat sheet.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. The guidance is scaffolding, not a script: say it in your own words, and only what you actually did.

The interview is typed, so each answer is a few short paragraphs, not a two-minute speech. Your typed replies are also read as samples of your written communication.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values (none used in this pack) |
| EXP | Whether what you have said about your work survives questions, and what was actually you |
| JD | A requirement the ad states, including where you are thin |
| CO | What you know about the company and its customers |
| CASE | A live problem from the role, worked through in front of the interviewer |

## Fit snapshot

Requirements are quoted from your description of the job ad. The ad's own text was not supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — your message (the job ad as you described it) | "3 years as a customer service advisor at an energy supplier" — your message; "I trained four new starters on our refunds process last year" — your message | medium | [grounded] | none | No gap on the years, but this is one sentence with nothing inspected behind it, so expect a probe. Lead in its own terms: "3 years as a customer service advisor at an energy supplier". Your material says customer service advisor where the ad says customer support, so use your own title. The training sentence is separate evidence and stays at its own scope: four new starters, the refunds process, last year |
| F2 | "experience with Zendesk or a similar ticketing tool" — your message (the job ad as you described it) | "I use Freshdesk every day" — your message | medium | [grounded] | presentation | Your material names Freshdesk and not Zendesk. Say it as you said it: "I use Freshdesk every day". The ad's wording is Zendesk or a similar tool, and the pack adds nothing to your sentence |
| F3 | "clear written communication" — your message (the job ad as you described it) | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | Emails are written work, but your material does not show how clear the writing was. This is the pack's derivation from the word emails. The interview itself is typed, so expect it to be read as a sample. Answer slot: the ad's written-communication line makes a probe on your written replies likely. If you can say what made your replies clear, say it in your own words; if you cannot, or the wording was not yours to choose, say so plainly and stay with "answering around 60 calls and emails a day" |
| F4 | "confidence handling escalations" — your message (the job ad as you described it) | none given | none | [grounded] | discovery | Your material does not mention escalations. Answer slot: the ad asks for confidence handling escalations, so expect a probe. If you took escalated contacts, or passed them on, say what they were and what you did, in your own words; if you did neither, or it was not yours to do, say so plainly and stay with the calls and emails you answered |
| F5 | Familiarity with a software company's product and customers (a role-family expectation, written from no source) | "I've never worked for a software company" — your message | none | [generic] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked for a software company." Then how you would learn the product, said as a plan and never as a past. Nothing added to make the gap feel smaller |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | A live support scenario typed into the chat: write a reply, order a queue, decide when to hand a case on | High. The hiring-manager prior puts Case and Skeptic first. The round is a typed chat, which lets a lead set a scenario and read your reply as the answer, and the ad's written-communication and escalation lines (F3, F4) are what a scenario scores | Clarify first, then structure, then answer. Say what you would check before replying. Keep a visible order in each typed answer |
| B. Skeptic | Quiet probing of the gaps: no software background, Freshdesk against Zendesk, escalations | High. Same prior. F5 is a gap you stated, and F2 names a different tool from the ad | Rehearse the F5 objection until it is boring. Build bridges only from your quoted sentences, and where there is none, say the limit plainly and give a concrete plan |
| C. Conversational | A friendly opener: your journey, what you know about the company | Medium. A first chat usually opens this way, and casual questions are still scored | Have a short arc ready for the journey question. Treat the casual company question as scored |
| D. Data-Driven Prober | Reads your background line by line and presses the numbers | Medium. Your message carries two figures, "around 60 calls and emails a day" and "four new starters", and a lead reading closely may press both | Know what you can and cannot say about how each figure was counted, and say plainly when you do not know |
| E. Pressure | Time-boxed, devil's advocate: "why you over someone else" | Low. A typed chat makes interrupting hard, but a short time-boxed challenge can still arrive | Pause, restate, hold the position your sentences carry, concede one thing specifically |

The Peer Evaluator is not banked. If the team lead turns out to be a peer, that bank is added and the weights change.

## Question banks

### A. Case/Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in for the third time about the same unresolved problem and asks for a manager. What do you do in your next reply?" | CASE | [generic] | Clarify first: say what you would check on the ticket before replying. Then structure it: acknowledge the repeat contact, say what you will do yourself, say when you would hand it on and what you would pass with it, and say what the customer hears next. Think aloud in that order. The question asks about no past, so the guidance makes no claim about yours | A live problem from the escalation line behind F4, asked as a decision. Generic because it is a pattern for the problem, not a fact about this employer. CASE because it scores structure |
| A2 | "Here is a customer message: 'I've been charged twice and nobody has answered me.' Write your reply now, in this chat." | CASE | [generic] | Type the reply as you would send it: show you have seen the problem, say what you will do and when they will hear from you, ask only for what you need. Plain words, short sentences, and read it back before you send. The reply is the sample, because the interview is typed. No claim about your past | F3's requirement tested directly, in the medium the interview is held in. Generic because the scenario is a pattern, not this employer's |
| A3 | "A customer asks how to do something in our product, and you haven't used that part of it. What do you do?" | CASE | [generic] | Say plainly that you would not guess. Say where you would look first, who you would ask and when, and what you would tell the customer meanwhile. Keep to what you would do: the question asks about no past, and your material carries no software product experience | The natural form of the F5 gap as a live problem, so the honest answer is rehearsed before it is probed. CASE because it scores reasoning under a gap |
| A4 | "Three tickets are open: one from the customer who has waited longest, one marked urgent, and one you could close in two minutes. What do you do first, and why?" | CASE | [generic] | Say your order and the rule behind it out loud. Then say what you would ask the team about its own priority rules, and name the case where your order would change. No claim about your past | A prioritisation problem a support role sets; no line of the ad raises it, so it is generic practice for live scenarios. CASE because it scores how you reason aloud |
| A5 | "A customer asks for a refund the policy doesn't allow. How do you reply?" | CASE | [grounded] "I trained four new starters on our refunds process last year" | Structure the reply: what you cannot do and why, what you can do instead, what happens next. If the scenario touches refunds, you may point to your own sentence at its own scope: "I trained four new starters on our refunds process last year." Do not describe a policy or process beyond what you were there for | A live problem close to the second quote in F1. CASE because it is a decision, and the quote is offered as an optional pointer, not a script |

### B. Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company" | Name one gap from your own material, not a virtue dressed as a weakness. Your own words are "I've never worked for a software company." Then a plan for the first weeks, said as a plan: how you would learn the product and who you would ask. Hold the answer through one follow-up and do not swap in a different weakness to look safer | F5 is the gap you stated, and this is the Skeptic's standard stem. JD because it scores the whole job's ask |
| B2 | "You've never worked for a software company. Why should we expect you to pick up our product quickly?" | JD | [grounded] "I've never worked for a software company"; "I use Freshdesk every day"; "3 years as a customer service advisor at an energy supplier" | The highest-ROI rehearsal in this pack. Open by owning it: "I've never worked for a software company." Hold only what your quotes carry: "I use Freshdesk every day", and the three years at an energy supplier, at their own scope. Then the learning plan, said as a plan: what you would ask for in week one and how you would learn the product. Hold through two follow-ups by returning to those sentences, never by adding a past instance of learning a product that you have not told me about. Concede plainly that product knowledge is what you would need to build | F5 is the largest gap and the objection this loop is most likely to raise in some form. JD because it scores fit with the listed job. A rehearsed, non-defensive answer here changes the interview |
| B3 | "The ad names Zendesk, and your experience is Freshdesk. What carries over, and what wouldn't?" | JD | [grounded] "I use Freshdesk every day" | Name Freshdesk as you said it: "I use Freshdesk every day." Answer slot: the ad's Zendesk line makes a probe on Zendesk itself likely. If you have used Zendesk, say where and when; if you have not, say so plainly and stay with Freshdesk. On what carries over, say which parts of Freshdesk you use each day, in your own words, and what you would expect to learn fresh; if you cannot compare the two tools, say you cannot | F2 is the evidence for the ticketing-tool requirement and names a different tool from the ad. JD because it scores the stated requirement, including its gap |
| B4 | "Why move from an energy supplier into a software company?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" | Give your actual reason in your own words; this pack has none from you and supplies none. Keep it to what is true and forward-looking, and do not run the energy supplier down. If you have no settled reason yet, say so plainly and say what draws you to this role | The Skeptic's why-here, why-now probe, with F1 and F5 on either side of the move. EXP because it tests whether your story holds together |
| B5 | "Tell me about a time you took over a customer problem that someone else couldn't resolve." | JD | [generic] | Selection scaffold: pick a case with a named customer problem, a clear point where it reached you or where you passed it on, what you did yourself, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing you have actually done, or how you would handle it | The open-prompt form of the escalation line behind F4, whose evidence cell is empty. Generic because no quote of yours carries a story for it |

### C. Conversational (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So — walk me through your three years as a customer service advisor." | JD | [grounded] "3 years as a customer service advisor at an energy supplier" | Story-mapped on F1: the role as you titled it, the kind of employer, the three years, which are the beats the quote states; tell them in your own words. Answer slot: the ad asks for 2+ years in customer support, so expect a probe on whether the work was support. If your duties changed over the three years, say how; if they did not, say so plainly and describe the work as it was. Keep it to a few short typed paragraphs | F1 is the evidence for the years requirement. JD because it scores that requirement, and the delivery is a friendly walk-through |
| C2 | "What do you know about Lumenvale Software?" | CO | [generic] | Selection scaffold: this pack holds no researched facts about the company. Use only what you have read yourself on its own website or careers page, and say where you read it. If you have not found much, say so plainly, then say what you would like to understand better | A homework check any friendly opener can carry. Generic because company research did not run for this pack |
| C3 | "What kinds of customer email do you find easiest to write, and which are hardest?" | JD | [generic] | Open prompt: choose one easy kind and one hard kind, and say why in your own words, a sentence each. If no clear example comes to mind, say so plainly, then say how you would approach a hard one | F3's requirement raised casually, which is how a written-communication probe often arrives. Generic because no quote of yours speaks to it |

### D. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You said around 60 calls and emails a day. How was that counted?" | EXP | [grounded] "answering around 60 calls and emails a day" | Say the figure as you said it: around 60, calls and emails together, nothing else. Answer slots: how it was counted: if it came from a report or a system, name it; if it was your own estimate, say so plainly. What it moves with: say in your own words, or say you do not know. The assumption behind it you would defend least: say it before they do, or say plainly that you do not know how it was counted. Which part was yours: say it at the scope the sentence gives | F3 holds the only headline figure in your material, and probers go for those. EXP because it tests attribution and counting |
| D2 | "You trained four new starters on the refunds process. Walk me through what that involved." | EXP | [grounded] "I trained four new starters on our refunds process last year" | Story-mapped on F1's second quote: four new starters, the refunds process, last year, which are the beats the quote states; tell them in your own words. Answer slot: if you chose what to cover or how, say which; if you were following existing material or someone else's plan, or there was no set plan, say so plainly and describe what you did. The figure is four people and nothing larger | F1's second quote is your only evidence of working with colleagues, and it carries a figure. EXP because it tests what was actually yours |
| D3 | "What do you actually do in Freshdesk in a day?" | JD | [grounded] "I use Freshdesk every day" | Start from the quote: "I use Freshdesk every day." Answer slot: the ad's ticketing-tool line makes a probe on depth likely. Say which parts you use daily, in your own words; if you use only part of it, or the heavier set-up belongs to someone else, say so plainly and describe your daily use | F2 is the evidence for the tool requirement and has nothing behind it but your sentence. JD because it scores that requirement |

### E. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has already worked in software support?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier"; "I use Freshdesk every day"; "I've never worked for a software company" | Pause, restate the question, then answer in two moves. Hold: "3 years as a customer service advisor at an energy supplier" and "I use Freshdesk every day", at their own scope. Concede one thing specifically: "I've never worked for a software company." Do not claim to be better than the other candidate and do not add a quality the sentences do not carry. Hold through two follow-ups by returning to those sentences | A time-boxed form of the F5 objection. JD because it scores fit with the listed job |
| E2 | "That refunds training: how much of it was actually you?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Hold what the quote carries: "I trained four new starters on our refunds process last year." Answer slot: if any of what you covered came from existing material or from someone else's decisions, say which part; if you set it, say so; if you cannot separate the two, say that plainly. Concede the specific part that was not yours rather than defending all of it | The Pressure stem aimed at F1's second quote. EXP because it tests attribution under challenge |

### Requirement coverage

| Requirement | Fit rows | Questions |
|---|---|---|
| "2+ years in customer support" | F1 | C1, B4, D2, E1 |
| "experience with Zendesk or a similar ticketing tool" | F2 | B3, D3, E1 |
| "clear written communication" | F3 | A2, C3, D1 |
| "confidence handling escalations" | F4 | A1, B5 |
| Familiarity with a software company's product and customers (generic) | F5 | A3, B1, B2, E1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good first month look like for someone new on the support team?" | It moves the chat to the work, and the answer tells you what you will be measured on |
| R2 | "How are escalations handled on your team: who takes them, and what should a first reply pass on?" | It shows you think about hand-offs, and it covers the escalation requirement behind F4 |
| R3 | "Which ticketing tool does the team use, and how long is onboarding on it?" | It puts the F2 tool question on the table and lets you ask for the learning time you would need |
| R4 | "What would you want a new person to learn first about the product?" | It shows you plan to learn it, which answers the F5 gap before it becomes an objection |
| R5 | "How does the team give feedback on written replies?" | It shows you care about clear writing, the F3 requirement, and tells you how quality is judged |
| R6 | "Is the rest of the process also a text chat, or does a call or video follow at any point?" | It tells you whether to prepare spoken answers as well, so you prepare for the right format |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has Zendesk experience | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day." The limit is the pack's observation: your material says Freshdesk, not Zendesk. B3's slot stays on whether you have used Zendesk, with an honest branch for no |
| Has used a ticketing tool for three years | Inflated form of F1 and F2 | The quotes at their own scope: the three years are as "a customer service advisor at an energy supplier", and the tool sentence carries no length of time |
| Resolved around 60 tickets a day | Inflated form of F3 | F3's quote at its own scope: "answering around 60 calls and emails a day". The figure belongs to calls and emails together |
| Designed or ran a training programme, or owned the refunds process | Inflated form of F1's second quote | The quote at its own scope: "I trained four new starters on our refunds process last year." The limit is the pack's observation: your material says you trained four people on the process, not that you built the process or ran a programme. D2's slot stays inside that |
| Has worked in software or software support | Negative you stated, F5 | The plain acknowledgment F5 gives: "I've never worked for a software company." No slot |

## Sources

Provided documents: the invite message as you pasted it; your description of the job ad's requirements; your background as you wrote it.

Searches sent, all refused, no results returned:

- "Lumenvale Software company values" — refused
- "Lumenvale Software interview process customer support specialist" — refused
- "Lumenvale Software strategy recent news" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | The search was refused. It would have given C2 and the reverse questions published value names; with no values round detected it would not have added a cheat sheet |
| 2. `Lumenvale Software interview process customer support` | unavailable | The search was refused. It would have checked the loop; your own words already establish one typed session with the team lead, so it would have moved persona weights only if the loop differed |
| 3. `Lumenvale Software strategy` / recent news | unavailable | The search was refused. It would have moved C2 from generic to grounded and given the reverse questions current company context |
| 4. interviewer name and company | n/a | The support team lead is unnamed, so there was no query to form; there is no interviewer read |
| 5. representative `Customer Support Specialist` JD | skipped | The four requirements you listed fix F1 to F4 and the JD-tagged questions, so a comparable posting could not have changed them |

## Upgrade menu

- The full text of the job ad → F1 to F4 are quoted from the ad itself, and any further requirement it states gets its own row and question
- Your CV → more rows get quoted evidence, and the F3 and F4 answer slots can be replaced by your own sentences
- Whether the support team lead would be your manager or a peer → persona weights are recomputed, and a Peer Evaluator bank is added if a peer
- Search access for the company's values, loop and strategy → C2 moves from generic to grounded and the reverse questions become company-specific
- The team lead's name → an interviewer read and a reverse question tied to their own path
- How much prep time you have → a prioritised schedule sized to it, ending with what is only insurance
- A `tuesday-dossier.md` from an earlier session → verified evidence and agreed positioning per weak area; the pack stands without it
