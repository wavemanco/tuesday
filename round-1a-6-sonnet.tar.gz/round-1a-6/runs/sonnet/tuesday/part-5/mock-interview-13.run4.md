Web search was refused, so I'm building the pack from the advert, Hannah's message and what you told me. Company facts will be labelled generic or left out. I'm writing the pack file now.
Your prep pack is saved as quillmoor-diagnostics_operations-coordinator_interview_pack.md. I built it for Hannah's 30-minute recruiter call, using the advert, her message and what you told me. The web searches I tried were refused, so it holds no company facts beyond the advert. Where that left a gap, the pack says so.

Say the word and I'll play the Skeptic on B2. That's the question about coordinating production schedules across planning, the warehouse and QA, which the pack names as your highest-ROI prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

What's your notice period? It's the one topic Hannah listed that your message doesn't answer, and your answer fills A4.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor-diagnostics_operations-coordinator_interview_pack.md -----
# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Interviewer:** Hannah Lowther, Talent Partner (recruiter). **Round:** recruiter screen, a 30-minute phone call on Thursday at 2pm. Hannah said she will ring the mobile number on your application.
**Built for:** one session. Hannah's own message is the loop source: one call with her, covering salary expectations, notice period, how the hybrid pattern would work, and what is prompting a move, then the team and next steps. No values-style round is documented, so there is no values cheat sheet.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did.

| Tag | Meaning |
|---|---|
| VAL | Whether past behaviour shows values, not generic virtue |
| EXP | Whether claims about your work survive scrutiny |
| JD | Whether you can do the listed job, including its gaps and terms |
| CO | Company and strategy knowledge |
| CASE | A live problem set in the role |

This pack has no CO questions. Web research was refused in this session, so nothing here rests on company facts beyond the advert. Question IDs skip the letter F because F1 to F12 are fit-snapshot rows.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material says delivery scheduling across three depots, not production scheduling, and the words stay there: "I schedule deliveries for our three depots." Answer slot: the advert names planning, the warehouse and QA, so a probe on whether you have worked with any of them is likely. If you have, say which and how, in your own words; if not, or it was not yours, say so plainly and stay with the delivery scheduling you do |
| F2 | "track supplier deliveries and chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it. Lead with it in its own terms: you chase suppliers when orders slip. Answer slot: the advert's tracking line makes a probe on how you know an order is slipping likely. If you had a way of tracking, say what it was; if there was none, or you were told by others, say so plainly and stay with the chasing |
| F3 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | presentation | Lead with the rebuild and the fall in the sentence's own terms. The sentence sets the rebuild beside the fall and does not say one caused the other, so the words stay at that. Expect a probe on how the figure was counted (C1) |
| F4 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material does not show whether you report on deliveries or dispatch. Answer slot: if you produce any regular report on deliveries, say what it covers and how often, in your own words; if you do not, say so plainly and say what you would track first |
| F5 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | No gap. Say it as written: four years as a logistics coordinator at a building-supplies wholesaler. Self-reported, so expect it to be taken at your word and probed through the rows above |
| F6 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | The sentence says spreadsheet and names no tool, so it may or may not be Excel; the reading downward is the safe one. Answer slot: if the spreadsheet was in Excel, say what you did in it; if it was another tool, or the Excel work was not yours, say so plainly |
| F7 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used SAP." Then how you would learn it, said as a plan and never as a past. The advert calls it a plus, not a requirement |
| F8 | "SAP or similar" — advert | "Never used SAP — we run our own in-house stock system." — your message | low | [inferred] | discovery | Your material does not show whether the in-house system does the kind of work an ERP does. Answer slot: if you used it for stock or orders, say what you did in it, in your own words; if it is not comparable, or you did not use it, say so plainly |
| F9 | "£38,000–£44,000" — advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | The figure sits inside the advert's band, which is this pack's observation. The words stay yours: "I'm hoping for £42,000." |
| F10 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | The words stay yours, whole: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." |
| F11 | "your notice period" — Hannah's message | none given | none | [grounded] | hard_gate | Your material does not establish it, and Hannah has said she will ask. This row asks nothing; A4 is where it is rehearsed |
| F12 | "what's prompting a move" — Hannah's message | "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | medium | [grounded] | none | The words stay yours, whole, and nothing is added to them |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder (bank A, 5 questions) | A friendly call; the four topics Hannah listed, asked casually | Highest. A recruiter screen starts here, and Hannah's message names pay, notice, hybrid and the reason for the move as her agenda | Treat casual questions as scored. Have a 90-second arc ready for the background question (A1). Never answer "I think you've covered everything" at the reverse-question slot |
| Skeptic (bank B, 4 questions) | Quiet probing of the gaps and of why this role | Second. The prior is "light", but F1 and F7 are real gaps and F7 is one you stated yourself, so it will come up | Rehearse B2 until it is boring. Build bridges only from what you stated, say the limit plainly, and give the ramp as a plan |
| Data-Driven Prober (bank C, 3 questions) | Takes the discrepancy figure and the Excel line and asks how they work | Middle. A recruiter may only note the figure, but a hiring manager later will ask, and this call is where you first say it | Know what you can and cannot say about how the figure was counted, and say plainly when you do not know |
| Case / Strategist (bank D, 2 questions) | A quick what-would-you-do on late supplier deliveries or stock mismatches | Low. Recruiters seldom run cases, but this role is a coordination role and a short scenario is plausible | Clarify first, then options, then who needs to know |
| Pressure (bank E, 2 questions) | A time-boxed "why you" or "how much was you" | Low. Unusual in a recruiter call, but cheap to rehearse | Pause, restate, hold the position through two follow-ups, concede specifically |
| Values / Behavioral (bank G, 2 questions) | Standard behavioural prompts | Low. No values round is documented and no published values were available | Pick real stories, or say plainly that none comes to mind |

The Peer Evaluator is left out: Hannah is a recruiter, not a peer.

## Question banks

**Bank A: Conversational**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The advert asks for two or more years in operations or logistics coordination. Walk me through your background." | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip."; "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Story-mapped on F5, F2 and F3: four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots and chasing suppliers when orders slip; the stock-count rebuild and the fall of about a third over a year. Those are the only beats the quotes state; tell them in your own words and stop there. About 90 seconds | The first question of nearly every screen, and the one that sets the register. JD because it scores the two-years requirement (F5), with the biography as its delivery |
| A2 | "What's prompting a move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Logistics slot: your own words, whole: "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." If Hannah follows up on the Reading offer, your own words again, quoted, with nothing added | Hannah named this as one of four topics (F12). EXP because it tests whether the story you tell holds together |
| A3 | "What salary are you looking for?" | JD | [grounded] "I'm hoping for £42,000." | Logistics slot: your own words: "I'm hoping for £42,000." If asked what you earn now, a conditional line you can use is: "I'd rather focus on the range for this role." | Hannah named salary expectations (F9). JD because pay is a term of the listed job |
| A4 | "What's your notice period?" | JD | [grounded] | Logistics slot: give your actual notice period, in your own words | Hannah named it (F11). It is the one topic of her four that your message does not answer, so it is rehearsed as an instruction until you supply the fact |
| A5 | "The role is hybrid, two days a week at Avonmouth. How would that work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Logistics slot: your own words, whole: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." If asked about the journey, your own words again, nothing added | Hannah named the hybrid pattern (F10). JD because location is a term of the listed job |

**Bank B: Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Choose from your own material and say it at the size your material gives. The one thing you have stated outright is: "Never used SAP — we run our own in-house stock system." Whatever you name, add how you would close it, as a plan and never as a past | A near-certain Skeptic question for any candidate with a stated gap (F7). JD because it scores the listed requirements, including their gaps |
| B2 | "How would you coordinate production schedules between planning, the warehouse and QA?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | The highest-ROI rehearsal in this pack. Start from what the quote carries: "I schedule deliveries for our three depots and chase suppliers when orders slip." Answer slot: the advert names planning, the warehouse and QA, so expect a probe on whether you have worked with any of them. If you have, say which and how; if not, or it was not yours, say so plainly and stay with the delivery scheduling you do. Expect follow-ups on what you would need to know first and on who wins when two teams disagree; hold by returning to the quote, and concede the limit plainly. Then say how you would learn the production side, as a plan | This is the advert's first duty and F1 is where your material is adjacent rather than direct, so the objection arrives in some form. JD because it scores a stated responsibility |
| B3 | "The advert lists SAP or similar ERP experience as a plus. Where does that leave you?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Words you can say: "I've never used SAP." Then the in-house system at its own scope: "we run our own in-house stock system." Answer slot: the advert's "or similar" makes a probe on whether that system does an ERP's work likely. If you used it for stock or orders, say what you did in it; if it is not comparable, or you did not use it, say so plainly. Close with how you would learn SAP, as a plan | F7 and F8. The stated negative is the source for the plain acknowledgment. JD because ERP is a listed item |
| B4 | "What do you know about us, and what appeals about this role?" | JD | [generic] | Selection scaffold. What you know from the advert is its own words: "diagnostic-test manufacturer, about 400 staff". Say that is what you have from the advert. Then pick one line of the advert that genuinely appeals and say why, in your own terms; if none stands out, say so plainly and say what you would like to learn on the call | The Skeptic's "why here". Web research was refused, so there are no company facts here; `[generic]` because it is a pattern |

**Bank C: Data-Driven Prober**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You say discrepancies fell by about a third. Walk me through how that was counted." | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Story-mapped on F3: the rebuild, and the fall of about a third over a year, which are the beats the quote states. Four answer slots, each in your own words: how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. The sentence sets the rebuild beside the fall and does not say one caused the other | The headline metric, and the likeliest target for a probe (F3) |
| C2 | "The advert asks for confidence in Excel. How would you describe yours?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Say what the spreadsheet was built in. Answer slot: if it was Excel, say what you did in it, in your own words; if it was another tool, or the Excel work was not yours, say so plainly and say what you can do | F6 is a hard requirement with a thin quote behind it |
| C3 | "Tell me about a time you reported on how orders were going out to other people." | JD | [grounded] | Selection scaffold: pick a time with a named audience, something that was measured, and something decided from it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4 has no quote, and the advert makes weekly reporting a duty. An open prompt, so it presupposes no event |

**Bank D: Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A supplier tells you at 9am that a delivery your planners are counting on for tomorrow will be two days late. Walk me through what you do." | CASE | [generic] | Structure it: what the delivery holds and who is relying on it, what is already in stock, the options (partial delivery, another source, re-sequencing), who needs to know (planning, the warehouse, QA, from the advert), and what you record. The question needs no claim about your past, so the guidance makes none | A live problem from the advert's supplier-chasing line (F2). `[generic]` because it is a pattern for the problem |
| D2 | "The stock record says an item is in the warehouse and the warehouse says it is not. What do you do?" | CASE | [generic] | Structure it: confirm the facts before changing anything, find where the record and the shelf diverge, correct the record with a note of why, and say how you would stop it recurring. No claim about your past | A live problem from the advert's stock-records line (F3). `[generic]` because it is a pattern |

**Bank E: Pressure**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who already knows SAP?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip."; "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year."; "Never used SAP — we run our own in-house stock system." | Pause and restate the question. Hold only what the quotes carry: "I schedule deliveries for our three depots and chase suppliers when orders slip." and the stock-count rebuild. Hold through two follow-ups by returning to them and never adding. Concede specifically: "I've never used SAP." Do not fold on the quoted work to restore harmony | F7 and F2. JD because the advert lists ERP as a plus |
| E2 | "That discrepancy figure: how much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Hold: "I rebuilt our stock-count spreadsheet." Answer slot: if others contributed to the fall, or other things changed over the year, say so plainly; if you do not know, say that. Hold through two follow-ups by returning to the rebuild, and concede the limit of what you know | F3. EXP because attribution is exactly what this probe tests |

**Bank G: Values / Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not soften it, and a working relationship intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioural prompt. No published values were available, so it is `[generic]` and low weight |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a specific decision, what the metric was, what you gave up, and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioural prompt. `[generic]` and low weight, as G1 |

**Requirement coverage**

| Requirement | Questions |
|---|---|
| Coordinate production schedules between planning, the warehouse and QA | B1, B2 |
| Track supplier deliveries and chase late orders | A1, D1 |
| Keep stock records accurate | A1, C1, D2, E2 |
| Report weekly on on-time dispatch | C3 |
| 2+ years in operations or logistics coordination | A1 |
| Confident with Excel | C2 |
| ERP experience (SAP or similar) a plus | B1, B3, E1 |
| £38,000–£44,000 | A3 |
| Hybrid, two days a week at Avonmouth | A5 |
| Notice period (Hannah's agenda) | A4 |
| What is prompting a move (Hannah's agenda) | A2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What does coordinating a production schedule look like in a typical week, and which of planning, the warehouse and QA does this role work with most?" | It shows you are weighing the part of the job F1 is thinnest on, and the answer tells you what to learn first |
| 2 | "Which stock or ERP system does the team use day to day, and how much of the role is spent in it?" | The advert says SAP or similar is a plus (F7); the answer tells you how much that gap matters in practice |
| 3 | "How is on-time dispatch measured today, and what does the weekly report look like?" | The advert makes it a weekly duty (F4); asking shows you read the role as a reporting job too |
| 4 | "Are the two days at Avonmouth fixed days of the week, or agreed with the team?" | A practical question about the pattern, which signals you are planning for the role |
| 5 | "What would a good first three months look like for this role?" | Recruiters weight this slot as a preparation signal, and the answer tells you what the hiring team will measure |
| 6 | "Who does this role work with most closely, and who does it report to?" | It surfaces the team shape Hannah said she would describe, and gives you a name to prepare for next |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated production schedules | Inflated form of F1 | F1's quote at its own scope. The limit is this pack's observation, not words for you: the material says delivery scheduling, not production scheduling. B2's slot stays inside what you do |
| Has SAP experience | Negative you stated, F7 | The plain acknowledgment your sentence gives: "I've never used SAP." No slot |
| The stock-count rebuild caused the fall in discrepancies | Inflated form of F3 | F3's quote at its own scope. The sentence sets the rebuild beside the fall; it does not say one caused the other. C1 and E2 keep to the quote |
| Built the stock-count spreadsheet in Excel | Inflated form of F6 | F6's quote at its own scope: it says spreadsheet. C2's slot asks which tool |
| Happy to work three days a week at Avonmouth | Inflated form of F10 | F10's quote, whole: you said two days is fine and you would not want more than three. That is a limit, not an offer |
| Cannot relocate to Reading | Inflated form of F12 | F12's quote, whole: the offer is "which I don't want" |

## Sources

Provided documents: the advert text, Hannah Lowther's LinkedIn message, and your own account of your background, all in your message. No tuesday-dossier.md was present.

Searches sent, all refused (the host did not grant permission to search):

- "Quillmoor Diagnostics values": refused
- "Quillmoor Diagnostics interview process operations coordinator": refused
- "Quillmoor Diagnostics Avonmouth news": refused
- "Hannah Lowther Talent Partner Quillmoor Diagnostics": refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor Diagnostics values | unavailable | Would have fed a values cheat sheet and VAL questions; none could be built, and bank G is `[generic]` |
| 2. Quillmoor Diagnostics interview process, operations coordinator | unavailable | Would have named later rounds and moved persona weights; the loop is Hannah's own description of this call |
| 3. Quillmoor Diagnostics strategy and recent news | unavailable | Would have fed CO questions and B4; there are none and B4 uses the advert's own words |
| 4. Hannah Lowther, Quillmoor Diagnostics | unavailable | Would have fed an interviewer read and a reverse question tied to her path; both are absent |
| 5. Representative Operations Coordinator JD | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your notice period → A4 and F11 move from an instruction to your own quoted words
- Your CV → more `[grounded]` rows, and F4, F6 and F8 may upgrade
- Your answers to the answer slots in B2, B3, C2 and C3 (what the spreadsheet was built in, whether you do any reporting, whether the in-house system compares to an ERP) → rows F1, F4, F6 and F8 upgrade
- Web search permission → values, loop structure and recent news (rows 1 to 3 above), which would add CO questions and a grounding brief; a deeper pass of up to 6 more searches and 2 more fetches, several more minutes, can follow once
- Hannah's public professional footprint, once search is permitted → an interviewer read and a reverse question tied to her path
- How much prep time you have → a prioritised prep triage
- A tuesday-dossier.md from an earlier evaluation of this role → an evidence-derived top objection and absolute prohibited claims; the pack does not need it
