Searches were refused, so I'm building the pack from your message alone and will say so in its Sources section.
Before the prep, one thing in the invite. It asks you to "transfer the €95 equipment registration fee to our supplier's account, IBAN ...", to "reply with a photo of your passport and your bank details before the interview", and says "you deposit the cheque and send the balance on to the vendor". Each of these is a known scam sign:

- **The fee:** you're asked to pay before any job exists.
- **The passport and bank details:** they're requested before any offer.
- **The cheque:** a cheque you deposit and then forward most of is a known fake-cheque pattern. The cheque can bounce days later, after your own money has gone.

The fee request, the passport and bank-details request and the cheque arrangement are very likely a scam. Hold all three until you've checked the invite with the employer. Use contact details you find yourself on its own website or careers page, and don't use any email, number or replies from the sender. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as `Brennock-Facilities_remote-administrative-assistant_interview_pack.md`. It has 18 rehearsal questions across five interviewer styles, built from the five phrases about your background in your message. Every answer is held to what you actually said. Where your material is silent, it gives you a slot to answer honestly rather than words to claim. Web searches were refused here, so there's no company research in it.

Say the word and I'll play the Skeptic on A2, the question the pack names as your highest-ROI prep: why a clinic receptionist is ready to process supplier invoices.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Would the office manager be your line manager or a peer on the team? The answer reweights every question bank.
Can you paste the ad's exact text? Six of the pack's rows are quoted from your description of it rather than from the ad.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Brennock-Facilities_remote-administrative-assistant_interview_pack.md -----
# Interview pack: Remote Administrative Assistant, Brennock Facilities Ltd

Interviewer: the office manager, name not given, relationship to you not given. Format: a 30-minute video call. Built as a hiring-manager-style round, because your note does not say whether the office manager would be your manager or a peer.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values. None in this pack: no values round was detected and no values page was read |
| EXP | Whether your CV claims survive scrutiny, and what was actually yours |
| JD | The ad's stated duties, including the ones your material does not yet cover |
| CO | Knowledge of the company's strategy. None in this pack: no research succeeded |
| CASE | How you structure a live problem from the job |

The highest-ROI rehearsal is question A2, on supplier invoices. Rehearse it until it is boring.

The requirements below are quoted from your description of the ad, not from the ad's own text.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — your message | "I ran the appointment book for four physios" — your message | medium | [grounded] | presentation | Say it in the quote's own terms: you ran the appointment book for four physios. Keep it at that scope: it was the physios' appointment book, not calendars in general. Your material does not say whether anyone shared the book with you, so expect that probe |
| F2 | "booking travel" — your message | none given | none | [grounded] | discovery | Your material does not show booking travel. Answer slot: the ad lists it, so expect a probe. If you have booked travel, say what and how, in your own words. If you have not, say so plainly and stay with the appointment book |
| F3 | "preparing documents in Word and Excel" — your message | "I'm good with Word" — your message | low | [grounded] | discovery | A self-assessment, with no document named. Answer slot: the ad's line makes a probe on what you have prepared likely. If a particular document comes to mind, name it and your part in it, in your own words. If none does, say so plainly and say that you are good with Word, as you put it |
| F4 | "preparing documents in Word and Excel" — your message | "okay with Excel" — your message | low | [grounded] | discovery | Keep your own level word for word: okay. Answer slot: if anything you have done in Excel resembles the ad's duties, say what. If nothing does, say so plainly and say what you would practise first |
| F5 | "processing supplier invoices" — your message | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Chasing unpaid invoices is not processing supplier invoices, and the words stay at chasing. Your material does not say whether those invoices were owed to the clinic or by it. Answer slot: if any were invoices the clinic had to pay, say what you did with them. If they were all owed to the clinic, say that plainly and stay with the chasing |

## Persona table

The loop rests on your own words: one 30-minute video call with the office manager. The relationship is unknown, so the weights start from the hiring-manager prior and can be recalibrated.

| Persona | How it shows up | Weight, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Quiet probing of the distance between a clinic reception desk and this job | Highest. The hiring-manager prior is Case plus Skeptic, and F2 and F5 are where your material is thinnest | Rehearse the likeliest objection (A2) until it is calm. Bridge only from what you said. Give a ramp plan as a plan, never as a past |
| Case / Strategist (B) | Live problems from the job: a clash, a cancelled flight, an invoice that does not match | Highest, level with the Skeptic. The ad's four duties each translate into a short live problem | Clarify first, then structure, then answer. Think aloud |
| Conversational (C) | A friendly walk through your background | Mid. A 30-minute call likely opens with your background, and casual questions are still scored | A 90-second arc built only from your own sentences |
| Data-Driven Prober (D) | Takes each phrase in your background and asks what was yours | Mid. Your material is a few specific phrases, and each can be probed | Know what each phrase covers, and say plainly where it stops |
| Peer Evaluator (E) | Collegial questions on how the two of you would work together | Low. Used only if the office manager is a peer or day-to-day partner | Reciprocity: what you bring, not only what you need |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this job would you be weakest at on day one?" | JD | [inferred] "I ran the appointment book for four physios" | Derived from comparing F1 to F5. Hold the one thing your quote carries: you ran the appointment book for four physios. Answer slot: name the duty your own material shows least, and say plainly that it is the one you would learn first. Then give a plan, not a past: what you would ask in your first week and who you would ask. Hold your position through two follow-ups. Concede only what you cannot back | F1 to F5 are the duties set against your quotes, and this is the standard Skeptic opener. JD because it scores the ad's duties, including the gaps |
| A2 | "Your background is reception at a clinic. What makes you ready for processing supplier invoices?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic", "chased unpaid invoices" | The highest-ROI rehearsal in this pack. Hold only what the quotes carry: "I was a receptionist for two years, and I chased unpaid invoices." Answer slot: the ad's line makes a probe on which side of the invoice you were on likely. If any were invoices the clinic had to pay, say what you did with them. If they were all owed to the clinic, say so plainly and stay with the chasing. Hold through two follow-ups by returning to the chasing, never by adding to it | F5 is where the ad presses hardest on your material, so this objection will come in some form. EXP because it tests what was actually yours |
| A3 | "Why move from reception into remote administration, and why now?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | The reasons are yours, and the pack does not know them. Selection scaffold: give one reason about the work itself, such as calendars, documents or invoices, and one about working remotely. Both must be true. If you are unsure of a reason, say so plainly and say what you are sure of. Keep the clinic described only as the quote says | A motivation probe is a standard Skeptic stem. EXP because it tests whether the move story is consistent with your history in F1 |
| A4 | "This role is remote. What experience do you have of working remotely?" | JD | [generic] | Answer slot: the title says remote, so expect this probe. If you have worked remotely, say where, for how long and how, in your own words. If you have not, say so plainly, then say what you would put in place at home to work without anyone beside you. The guidance makes no claim about your past | The invite's own title makes remote working a stated requirement. JD because it scores a stated feature of the job |
| A5 | "Booking travel is part of the job. What experience do you have with it?" | JD | [grounded] | Answer slot: if you have booked travel, say what you booked and how, in your own words. If you have not, say so plainly and stay with the appointment book you did run. Then say how you would learn this employer's booking rules. The guidance makes no claim about your past | F2 is a duty with no evidence behind it, so a direct probe on it is likely. JD because it scores a listed duty |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Two people ask you to book a meeting in the same hour on Thursday, and one of them is your manager. What do you do?" | CASE | [generic] | Structure it: what you would ask first, which meeting has priority and who decides, what you would offer the other person, and how you would confirm back in writing. The question needs no claim about your past, so the guidance makes none | A live problem from the ad's calendars duty (F1's requirement), asked as a decision rather than a record. `[generic]` because it is a pattern, not a fact about this employer |
| B2 | "A flight for a client meeting is cancelled the night before. Walk me through it." | CASE | [generic] | Clarify first: who is travelling, what the meeting needs, the budget, and who approves changes. Then offer options, confirm the choice, and say what you would record. No claim about your past | A live problem from the ad's travel duty (F2's requirement). It lets you show reasoning where your material shows no travel |
| B3 | "Three supplier invoices arrive and one does not match what was ordered. What do you do?" | CASE | [generic] | Do not approve it. Ask who owns the order and who approves payment, then flag it, hold it and record it. Ask what the company's process is. The guidance makes no claim about your past | A live problem from the ad's supplier-invoices duty (F5's requirement). It lets you show judgement without claiming processing experience |
| B4 | "You'd be preparing documents in Word. What would you want to know on day one?" | JD | [grounded] "I'm good with Word" | Ask about templates, who reviews and signs off, formats and deadlines. Say "I'm good with Word" in your own words and no stronger. Answer slot: if a particular document you prepared comes to mind, name it and your part. If none does, say so plainly and ask which documents come first | F3 is a self-assessed skill, so this asks you to show it without inflating it. JD because it scores a listed duty |
| B5 | "What would you be doing in Excel in this job, and how comfortable are you with it?" | JD | [grounded] "okay with Excel" | Say "I'm okay with Excel" at that level, never higher. Answer slot: if anything you have done in Excel resembles the ad's duties, say what. If nothing does, say so plainly and say what you would practise first | F4 is the thinnest evidence for a named tool, and the ad names it. A calm, honest level answer is stronger than a stretched one |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your journey so far." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic", "I ran the appointment book for four physios", "chased unpaid invoices" | A 90-second arc with exactly the beats your sentences state: two years as a receptionist at a physiotherapy clinic, the appointment book you ran for four physios, and chasing unpaid invoices. Tell it in your own words. Answer slot: end with why this role next, in your own reason | The biography question opens most calls and is scored even when casual. F1 and F5 supply the beats |
| C2 | "Tell me about running the appointment book for four physios." | EXP | [grounded] "I ran the appointment book for four physios" | Beats from the quote: the book, the four physios, that you ran it. Answer slot: the ad's calendars line makes a probe on what happened when the physios' times changed likely. If that came up, say what you did and which part was yours. If it did not, or it was not yours, say so plainly and stay with the book | F1 is your strongest line and likely to be opened up. EXP because it tests what was actually yours |
| C3 | "What do you use Excel for these days?" | JD | [grounded] "okay with Excel" | Answer in your own words at your own level: you said okay. Answer slot: if you use it for something, name what. If you do not use it, say so plainly and say what you would like to use it for in this role | F4 asked casually, so it is easy to over-answer. The level you gave is the whole claim |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You ran the book for four physios. Help me understand that, and what part was yours." | EXP | [grounded] "I ran the appointment book for four physios" | The number is four, and the claim is that you ran the appointment book. Answer slot, for a number: say how the four was counted, what it is sensitive to, and the assumption you would defend least, each in your own words. If you do not know how it was counted, say so plainly. If anyone shared the book, say so | F1's figure is a magnet for a probe on how it was counted and whose it was |
| D2 | "Tell me about chasing unpaid invoices. What was your part?" | EXP | [grounded] "chased unpaid invoices" | Say what you did in your own words, at the scope of chasing. Answer slot: the ad's invoices line makes a probe on whether your part went beyond that likely. If it did, say what. If it did not, say so plainly and stay with the chasing | F5 tested at the edge the ad draws. EXP because it separates your part from the invoice process |
| D3 | "How would you describe your Word skills, and how do you know?" | EXP | [grounded] "I'm good with Word" | Say it as you said it: you are good with Word. Answer slot: if a document you prepared comes to mind, name it and your part. If none does, say so plainly and offer to show a short sample | F3 asks for evidence behind a self-assessment. The honest branch is a limit, not a confession |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "You'll be remote and I'll be in the office. How would you keep me up to date on where things stand?" | JD | [generic] | Propose a principle, not a pretence of knowing their system: a short written update at a regular time, flags raised early, and a question about their preferred tool. No claim about your past | The remote title makes handover a real concern for whoever sits in the office |
| E2 | "What do you think you'd need from me in your first month?" | JD | [generic] | Reciprocity framing: name what you would ask for, then what you would take off their plate. Keep it to principles, with no claim about your past | A collegial question where a peer is pricing what you add to their load |

## Requirement coverage

| Requirement | Questions |
|---|---|
| "managing calendars" | B1, C2, D1 |
| "booking travel" | A5, B2 |
| "preparing documents in Word and Excel" | B4, B5, C3, D3 |
| "processing supplier invoices" | A2, B3, D2 |
| "Remote Administrative Assistant" (the invite's title) | A4, E1, E2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a good first month look like in this role?" | It shows you plan from the start, and the answer tells you which duty to practise first |
| R2 | "Which tools do you use for calendars and for invoices, so I can get familiar with them first?" | It shows preparation, and the answer shows how much Word and Excel the job really holds |
| R3 | "How are supplier invoices approved here, and who signs them off?" | It shows you understand the control point, and sizes the F5 gap before you start |
| R4 | "How much travel do you book in a typical month, and who approves it?" | It sizes the F2 gap and shows you are thinking about the duty |
| R5 | "What could a new person do in their first month that would genuinely help you?" | A reciprocity question that moves the call from interrogation to partnership |
| R6 | "What happens after this call, and when would I hear?" | A process question with a prep reason: it tells you whether a second round needs its own preparation |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Processed supplier invoices | Inflated form of F5 | F5's quote at its own scope: "chased unpaid invoices". The limit is the pack's observation: your material says chasing, not processing. A2 and D2 stay inside the chasing |
| Advanced or expert Excel | Inflated form of F4 | F4's quote at its own scope: "okay with Excel". B5 and C3 keep your own level word |
| Managed the clinic's calendars | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios". The limit is the pack's observation: your material says the physios' appointment book, not calendars in general |

## Sources

Provided documents: your message, which holds the invite's text, your description of the ad and your background. No dossier.

Searches sent, each refused by the host:

- "Brennock Facilities Ltd values" — refused
- "Brennock Facilities Ltd interview process administrative assistant" — refused
- "Brennock Facilities Ltd strategy news" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | The call was refused. Would have fed a values cheat sheet, but no values-style round is detected, so the pack is unchanged |
| 2. `{company} interview process {role family}` | unavailable | The call was refused. Would have fed loop structure. Your own words give one 30-minute video call, so persona weights follow the hiring-manager prior |
| 3. `{company} strategy` / recent news | unavailable | The call was refused. Would have fed CO questions, so the pack has none |
| 4. `{interviewer name} {company}` | n/a | No name was given, so there is no query to form. The interviewer read is absent |
| 5. representative `{role title}` JD | skipped | Your description of the ad's duties fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The ad's exact text → the requirement quotes in F1 to F5 come from the ad itself rather than your description
- Your CV → more evidence rows, and fewer answer slots in the fit snapshot
- Whether the office manager would be your manager or a peer → persona weights reweight and every bank is retuned
- A real example of booking travel, of a Word document, or of Excel work → F2, F3 and F4 become story-mapped rows rather than answer slots
- A deeper research pass, up to 6 more searches and 2 more fetches and several more minutes → a company strategy brief for CO questions
- The office manager's name → an interviewer read and a reverse question tied to their path
- A `tuesday-dossier.md` → the gaps this prep exposed are carried into later sessions, and the highest-ROI objection is evidence-derived rather than inferred
