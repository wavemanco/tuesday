Web search was refused, so I'm building the pack from your message only. I'm saving it now.
Before the prep, one thing in the invite: it says the hiring process is "carried out entirely on Telegram" and that "your offer and onboarding will be completed in this chat as well". A hiring process run wholly by chat is a known scam pattern. A chat alone doesn't show who you're dealing with. Until you know, don't pay anything, deposit a cheque, or send documents or bank details through it. Onboarding done in a chat is where those requests tend to arrive. Check the invite with Lumenvale through contact details you find yourself on its own website or careers page, not through this chat. The invite may not come from who it names. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as `/var/tmp/tuesday-measure/1a6/runs/sonnet/tuesday/part-5/rooms/case-10-denied-f3a1d66c/lumenvale-software_customer-support-specialist_interview_pack.md`. It has 19 questions, built for a typed chat with a team lead who is probably your future manager. Web search was refused in this session, so nothing in it is about Lumenvale beyond what you told me.

Your strongest fit is the 3 years, Freshdesk daily, and the 60 calls and emails a day. The two gaps to rehearse are never having worked for a software company (B1) and no escalation example in what you've told me (B3, A1 and A4). Rehearse B1 first, because an interviewer is most likely to press it.

Say the word and I'll play the Skeptic on B1 in a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is the support team lead your future manager or a peer on the team? The answer reweights every bank.
Can you paste the full text of the job ad? I've proceeded without it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: lumenvale-software_customer-support-specialist_interview_pack.md -----
# Interview pack: Customer Support Specialist, Lumenvale Software

Interviewer: the support team lead (name not given). Relationship assumed: future manager or lead of the team, not confirmed. Format, in the invite's words: a text chat on Telegram. Built on your message alone: no company research ran.

## How to use this pack

- Personas describe how a question is asked. Types describe what is being scored.
- Types: EXP is a deep-dive on your own work. JD is a stated requirement of the role. CASE is a live problem. VAL is behaviour against values. CO is company knowledge.
- Guidance is scaffolding, not a script. Say only what you actually did, in your own words.
- The interview is typed. Practise answering in short messages of a few lines, not one long block.
- "Answer slot" means an instruction for the interview: say what is true for you, and say plainly when a practice was not yours or did not exist.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — the job ad, as you relayed it | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead with it in its own terms: three years as an advisor, around 60 calls and emails a day. Keep calls and emails as the nouns. The figure raises the defend-the-number questions: how it was counted, what it varies with, the assumption you would defend least, and which part was yours |
| F2 | "experience with Zendesk or a similar ticketing tool" — the job ad, as you relayed it | "I use Freshdesk every day" — your message | medium | [grounded] | none | No gap, with a limit. Your material names Freshdesk, not Zendesk, so name the tool you use and stay at "every day". Answer slot: the ad's ticketing-tool line makes a probe on what you do in the tool likely. Say which parts you use yourself, in your own words; if some parts are handled by someone else or you do not use them, say so plainly and return to using it every day |
| F3 | "clear written communication" — the job ad, as you relayed it | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | Your material says calls and emails, not how the emails were written, so the words stay at that scope: you answered around 60 calls and emails a day. Answer slot: the ad's written-communication line makes a probe on your writing likely, and this interview is itself typed. If you wrote replies to customers, say how you kept them clear, in your own words; if most of your contact was by phone, or the writing was not yours to shape, say so plainly and stay with the calls and emails you answered |
| F4 | "confidence handling escalations" — the job ad, as you relayed it | none given | none | [grounded] | discovery | Your material does not show escalation work, and the pack writes none. Answer slot: the ad's escalation line makes a probe likely. If you handled escalations, say what happened and what part was yours, in your own words; if escalations went to someone else, or there were none, say so plainly and stay with the three years as an advisor at the energy supplier |
| F5 | Familiarity with software products — a role-family expectation, not in the ad as you relayed it | "I've never worked for a software company" — your message | none | [generic] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked for a software company." Then how you would learn the product, said as a plan and never as a past. Never a claim to software-company experience |
| F6 | Supporting teammates on a support team — a role-family expectation, not in the ad as you relayed it | "I trained four new starters on our refunds process last year" — your message | medium | [generic] | none | No claim beyond the quote: you trained four new starters on the refunds process last year. The limit is the pack's observation: your material says the training, not that you designed the process. Expect a probe on which part was yours |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | Live support scenarios typed into the chat | High. A hiring-manager-style relationship favours live problems, and a support lead tests how you handle a ticket, not just what you did | Clarify first, then structure, in short messages; say the next step and when it happens |
| B. Skeptic | Quiet probing of the gaps | High. F5 is a gap you stated, and F4 is a requirement your material does not show | Rehearse B1 until it is boring; hold what your own words carry, concede the rest specifically |
| C. Data-Driven Prober | Asks how your figures were counted | Medium. F1 and F6 hold figures, and a typed chat makes them easy to question line by line | Know what you can and cannot say about the count; say plainly when you do not know |
| D. Conversational | Friendly opener, "tell me about yourself" | Medium. Chat interviews tend to open casually, and casual questions are still scored | A short arc in three or four messages, from your own sentences only |
| E. Pressure | Compressed or challenging follow-ups | Low. A team-lead chat seldom time-boxes, but text can feel abrupt | Pause, restate, hold the position through two follow-ups before conceding anything real |
| F. Values / Behavioral | "Tell me about a time" prompts | Low. Your message describes one chat session with the team lead, and no values round is documented; no company values were in hand | Selection scaffolds only; pick a true instance or say you have none |

Persona weights rest on the relationship prior and on your message's description of the process, not on any researched loop for this company.

## Question banks

### A. Case / Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer has written in three times about the same problem, the ticket is still open, and now they are asking for a manager. What do you do first?" | CASE | [generic] | Structure it aloud: acknowledge them, read the history so they do not repeat themselves, say what you will do and by when, decide whether and to whom it escalates, and record it. The question needs no claim about your past, so the guidance makes none | The ad's escalation line (F4) turned into a decision rather than a story; JD content, CASE delivery |
| A2 | "A customer writes: 'Your update broke my account and I lost a day of work.' Reply to me now as if I were that customer." | CASE | [generic] | Write it live in a few lines: acknowledge the lost time, do not argue about cause, ask for the one or two details you need, and say what happens next. Keep it plain and short | Tests the ad's written-communication line (F3) in the medium the interview is held in; CASE delivery, JD content |
| A3 | "Twenty tickets arrive in ten minutes and they all look like the same issue. What do you do?" | CASE | [generic] | Clarify before acting: are they actually the same issue, and who on the team needs to know. Then say what you would tell the customers while it is looked at. Say that you would ask how this team handles it rather than pretending to know their process | A live volume problem for a support role; the guidance claims no past |
| A4 | "A long-standing customer asks for something our policy does not allow. How do you handle it?" | CASE | [generic] | Hear the request, explain what you can do, say what you would not promise, and say when you would involve the team lead and why. Think aloud and challenge one premise politely, such as what the policy actually says | Covers the escalation line (F4) from the policy side; JD content, CASE delivery |
| A5 | "You are new here and a ticket is about a feature you have never seen. Walk me through your first fifteen minutes." | CASE | [generic] | A plan, never a past: read what the customer actually asked, look for what the team already has written on it, ask a colleague a specific question, and reply to the customer with an honest time frame. Say what you would not do, which is guess | F5 is the likeliest worry, and a learning plan answers it before it is raised; CASE with a Skeptic edge |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have not worked for a software company. What will be hardest for you in your first month?" | JD | [grounded] "I've never worked for a software company" "I use Freshdesk every day" | The highest-ROI rehearsal in this pack. Hold-then-concede: concede in your own words, "I've never worked for a software company", and do not fold on the rest. Then say how you would learn the product, as a plan. The one adjacent fact your material carries is "I use Freshdesk every day", and it stays at that scope. Answer slot: if asked how long to get up to speed, give your honest estimate or say what you would want to find out first; do not borrow a number. Hold through two follow-ups by returning to what you have said | F5 is the gap an interviewer is likeliest to press, in some form; JD because it scores the role's fit, and Skeptic because it probes the mismatch |
| B2 | "The ad asks for Zendesk or a similar ticketing tool. How do you use your ticketing tool day to day?" | JD | [grounded] "I use Freshdesk every day" | Say the tool by name and that you use it every day, in your own words. Answer slot: say which parts you use yourself; if some parts are handled by someone else, or you do not use them, say so plainly and return to using it every day. Do not describe features you did not use | F2 is the evidence for the tool requirement, and the likeliest place for a follow-up on detail; JD content |
| B3 | "Tell me about a time a customer asked to escalate, and what you did." | JD | [grounded] | Selection scaffold: pick a time with a named customer problem, what you chose to do, who else was involved, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is three years of calls and emails as an advisor, or say how you would handle it | F4 is the requirement your material is silent on; the ad raises it, so it will be asked; JD content, EXP delivery |
| B4 | "You have been at an energy supplier. Why a software company, and why now?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" "I've never worked for a software company" | Your reason is yours: give your actual reason in your own words; the pack supplies none and will not. Keep it consistent with what you say in B1 and D1, since a skeptic checks them against each other | Motivation consistency is what a Skeptic scores; F1 and F5 frame the move |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You say around 60 calls and emails a day. How was that counted?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Say, in your own words, how the figure was counted, what it varies with, which assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say that plainly. Keep "calls and emails" as the nouns; do not turn them into tickets | F1's figure is the headline number, and a defend-the-number question is the standard probe; EXP |
| C2 | "You trained four new starters on your refunds process. What did that involve, and which part was yours?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Story-mapped on the quote: four new starters, the refunds process, last year, told in your own words. Answer slot: say what the training consisted of and which part was yours; if it was shared, or you covered only part of it, say so plainly | F6 holds a count and an attribution, the two things a Prober presses; EXP |
| C3 | "Walk me through an ordinary day, first contact to last." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" "I use Freshdesk every day" | Tell only the beats your sentences carry: calls and emails, around 60 a day, Freshdesk every day. Keep it in your own words and add no routine you did not state | F1 and F2 are the day-to-day evidence; a Prober checks whether the description matches the numbers; EXP |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your journey and why this role." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" "I use Freshdesk every day" "I trained four new starters on our refunds process last year" "I've never worked for a software company" | A three or four message arc built from your own sentences: the three years as an advisor, the Freshdesk use, the training. Answer slot: why this role, in your own words, with no reason borrowed from the ad. Mention that you have not worked for a software company yourself, so no one finds it first | The standard opener, and the place all four of your sentences meet; F1, F2, F5 and F6 |
| D2 | "What do you enjoy most about helping customers?" | VAL | [generic] | Selection scaffold: pick something real and say why it matters to you; do not rehearse a line that sounds good. If nothing specific comes to mind, say so plainly and say what you do notice about a conversation that went well | A casual question that is still scored for genuine interest |
| D3 | "Have you had a look at what we make?" | CO | [generic] | Say only what you have actually looked at. This pack could not research the company, so this is the question where your own preparation beats the pack: spend a short while on the company's own site and help pages, which you reach yourself, and note two real observations | CO coverage; a rapport-style interviewer scores homework |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has already worked in software support?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" "I use Freshdesk every day" "I've never worked for a software company" | Hold-then-concede. Hold on what your sentences carry: three years as an advisor, around 60 calls and emails a day, Freshdesk every day. Concede specifically: "I've never worked for a software company." Do not assert what your work proves; describe it and let them draw the line | F1, F2 and F5 meet in the hardest framing of the gap; JD with Pressure delivery |
| E2 | "That training: how much of it was actually you?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Hold what the quote carries: you trained four new starters on the refunds process last year. Answer slot: say which part was yours; if it was shared, or the process was designed by someone else, say so plainly and return to the training you did | F6's attribution is where a pressure interviewer goes next; EXP |

### F. Values / Behavioral (lowest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you put a customer's problem ahead of getting through your queue." | VAL | [generic] | Selection scaffold: pick a time with a named customer problem, the choice you made, and what it cost you. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is three years answering calls and emails, or say how you would weigh it | A standard support-values prompt; no company values were in hand, so it is a pattern, not this company's value |
| F2 | "Tell me about a time you had to tell a customer something they did not want to hear." | VAL | [generic] | Selection scaffold: pick a time with the message, how you said it, and how it ended. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or say how you would approach it | The same pattern from the other side; a hard truth that landed is the story to choose, and only if it is true |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| "2+ years in customer support" | B4, C1, C3, D1, E1 |
| "experience with Zendesk or a similar ticketing tool" | B2, C3 |
| "clear written communication" | A2, D1 |
| "confidence handling escalations" | A1, A4, B3 |
| Familiarity with software products (role-family) | A5, B1, B4, E1 |
| Supporting teammates (role-family) | C2, E2 |
| Company knowledge | D3, and a researched question is none, because no research ran |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good first month look like for someone joining the support team?" | Shows you plan to ramp, and tells you the bar you are being measured against |
| R2 | "Which ticketing tool does the team use, and how do people usually get comfortable in it?" | Brings the Zendesk-or-similar line (F2) into the open and shows you expect to learn the tool |
| R3 | "What kinds of issues come up as escalations here, and who picks them up?" | Shows you think about the escalation line (F4) as a handover, not a heroic act |
| R4 | "When someone is stuck on a product question they cannot answer yet, how does the team help?" | Signals you expect to learn the product (F5) and care about how the team works |
| R5 | "How is the team's day split between written chat, email and calls?" | Shows interest in the written-communication side (F3) and tells you what to practise |
| R6 | "What is the next step after this chat, and is there anything you would like me to prepare for it?" | Lets you prepare for the next stage and shows you plan ahead |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Experienced with Zendesk | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day". The limit is the pack's observation: your material names Freshdesk, not Zendesk. B2's slot stays inside the tool you use |
| Resolved around 60 tickets a day | Inflated form of F1 | F1's quote at its own scope: around 60 calls and emails a day. Calls and emails stay the nouns |
| Has software-company or SaaS support experience | Negative you stated, F5 | The plain acknowledgment F5 gives: "I've never worked for a software company." No slot |
| Designed or owned the refunds process or its training | Inflated form of F6 | F6's quote at its own scope. The limit is the pack's observation: your material says you trained four new starters on it, not that you designed it. C2's slot asks only which part was yours |

## Sources

Provided: your message, covering the ad's requirements as you relayed them, your background, and the invite's description of the interview format. No dossier was present.

Searches sent, all refused by the host:

- "company values Lumenvale Software" — refused
- "interview process customer support specialist Lumenvale Software" — refused
- "strategy recent news Lumenvale Software" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. company values | unavailable | Would have fed a values cheat sheet if a values round were documented; none was, so VAL questions are generic |
| 2. interview process, role family | unavailable | Would have tested the persona weights against a documented loop; weights rest on your message and the relationship prior |
| 3. company strategy, recent news | unavailable | Would have grounded CO and CASE questions in current strategy; D3 and A1 to A5 are generic instead |
| 4. interviewer name | n/a | No name was given for the support team lead, so there was no query to form |
| 5. representative JD | skipped | The requirements you relayed fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full text of the job ad → the four relayed requirements become exact quotes, and mid-list items get their own JD questions
- Search permission, if you grant it → the three unavailable rows become sourced, and a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) can add a strategy brief
- The interviewer's name or profile → an interviewer read, persona weights from their public footprint, and a reverse question tied to their path
- Your own answers to the slots on F2, F3, F4 and F6 → those rows become grounded quotes and the matching guidance cells become story-mapped
- Your actual reason for moving into software → B4 and D1 stop being slots
- A tuesday-dossier.md from an earlier session → verified evidence and prohibited claims arrive pre-graded; nothing here depends on one
