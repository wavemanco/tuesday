I'm running the default research on Lumenvale (values, interview process, recent strategy) so the prep pack rests on sources instead of memory.
Before the prep, one thing in the invite: it says the process is "carried out entirely on Telegram" and that "your offer and onboarding will be completed in this chat as well". A hiring process run wholly by chat is a known scam pattern, and a chat alone doesn't show who you're dealing with. Until you've checked, hold off on paying anything, depositing a cheque, or sending documents or bank details. Check with Lumenvale through contact details you find yourself on its own website or careers page, not through this chat. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as `/var/tmp/tuesday-measure/1a6/runs/sonnet/tuesday/part-5/rooms/case-10-denied-ce5c102c/lumenvale-software_customer-support-specialist_interview_pack.md`. I built it for a hiring-manager-level, text-chat interview with the support team lead. Your invite doesn't say how that person relates to the job. The web searches on Lumenvale's values, interview process and strategy were refused, so the pack rests only on what you told me. It has no company-specific questions.

The pack has 18 questions in five banks (live support scenarios, skeptic, conversational, number-probing and pressure), plus six questions for you to ask them. Your biggest gap is "I've never worked for a software company", so the question on it (B1) is the one to rehearse most. Escalations is the second gap: nothing you've told me shows you handled any, so the pack gives you honest-answer slots there instead of a story.

Say the word and I'll play the Skeptic on B1.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is the support team lead your future manager, or a peer on the team? The answer reweights every bank.
Can you paste the full text of the ad? The four requirements would become exact quotes, and any I missed would get questions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: lumenvale-software_customer-support-specialist_interview_pack.md -----
# Interview pack: Customer Support Specialist, Lumenvale Software

Interviewer: the support team lead, name not given. Relationship assumed: hiring-manager level. Format: one text chat.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Tag | Name | What it scores |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the company's published values |
| EXP | Work-experience deep-dive | Whether your claims survive scrutiny and what was actually you |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge | Homework depth on the company |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the role |

This pack has no VAL or CO questions: no values page or company research was available (see Sources), and no round that scores values was established.

Because the interview is a text chat, your written replies are themselves scored. Type in short, plain sentences, and answer the question asked.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — the ad, as you gave it | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message | medium | [grounded] | none | No gap, but a line in your message with nothing inspected behind it, so expect a probe on the figure. Lead with your own title, in the quote's own terms: for three years you were a customer service advisor at an energy supplier. The ad says support and you said service advisor, so keep your title and let the interviewer ask what it covered |
| F2 | "experience with Zendesk or a similar ticketing tool" — the ad, as you gave it | "I use Freshdesk every day" — your message | medium | [grounded] | none | Say Freshdesk by name: "I use Freshdesk every day." Whether Freshdesk counts as similar is the interviewer's call, so do not call it Zendesk and do not claim features beyond the ones you use. Expect a probe on it |
| F3 | "clear written communication" — the ad, as you gave it | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message; "I trained four new starters on our refunds process last year" — your message | low | [inferred] | discovery | Your material shows emails answered and a process taught, not how your written replies were received or whether the training was written. Answer slot: this chat is itself a sample of your writing, so expect it to be scored live. If you have anything showing how your replies were received, such as a quality score or a customer comment, say what it was, in your own words; if you have nothing of that kind, say so plainly and describe how you write a reply |
| F4 | "confidence handling escalations" — the ad, as you gave it | none given | none | [grounded] | discovery | Your material does not mention escalations. Answer slot: the ad's escalations line makes a probe likely. If escalations came to you in your role, say what kind and which part was yours, in your own words; if none did, or they went to someone else, say so plainly and say how you would handle the first one that reached you |
| F5 | Familiarity with a software product and its customers, plain prose and not in the ad as you gave it | "I've never worked for a software company." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked for a software company." Then a plan, said as a plan: what you would learn first and how. Never a claim of past exposure to software. This is the most likely objection in the interview |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (bank A) | Live support scenarios typed into the chat: an angry customer, a locked account, a rewrite | High. A support team lead hiring for a support role is likely to test judgment on live problems, and a text chat makes writing the thing scored | Clarify first, state the objective, then the approach, and name one assumption. These questions need no claim about your past |
| Skeptic (bank B) | Quiet probing of the gaps: software background, the tool, escalations, why leave energy | High. Your own message names the software gap, and the ad's escalations line has no evidence behind it yet | Rehearse B1 until it is boring: your own words, then a plan said as a plan |
| Conversational (bank C) | Friendly openers: the journey, a normal day, training new starters | Medium. A lead opening a chat tends to start easy, and those answers are still scored | Pre-script a 90-second arc from your own sentences and nothing more |
| Data-Driven Prober (bank D) | Goes line by line through your numbers and your tool use | Medium. "around 60" and "four" are numbers, and a tool line invites "walk me through it" | Say how each figure was counted, or say plainly that you do not know |
| Pressure (bank E) | Time-boxed, devil's-advocate versions of the same gaps | Low to medium. Text chat softens it, but "sixty seconds" prompts are common for this gap profile | Pause, restate the question, hold what your sentences carry through two follow-ups, concede one thing specifically |
| Values / Behavioral | Not banked | No round that scores values was established, so no bank is built | Not applicable until a values-style round is named |
| Peer Evaluator | Not banked | The relationship assumed is hiring-manager level, not peer | Not applicable until the interviewer is known to be a peer |

## Question banks

### Bank A: Case / Strategist (weight highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in for the third time about the same problem and says they will cancel. What is the first thing you write back?" | CASE | [generic] | Say you would read the earlier messages first. Then acknowledge in one plain sentence that this is the third time, state what you will do and by when, and ask only for what you still need. Clarify before offering a fix. The question needs no claim about your past, so the guidance makes none | The ad's written-communication line (F3) is scored live in a text chat, and CASE because it is a live problem set in the role |
| A2 | "A customer says they are locked out of their account and have a deadline in an hour. The queue is long. What do you do in the first five minutes?" | CASE | [generic] | Clarify first: what the customer sees, how urgent it is, whether others are affected. Then the objective, the approach, and what you would tell the customer and when you would update them. Name one assumption you are making. You do not know the product, so say what you would check rather than what the product does | A software-support problem for a candidate whose F5 row shows no software background, so it tests structure and not product knowledge |
| A3 | "A customer insists on speaking to a manager. What do you do?" | CASE | [generic] | Find out what they want fixed before deciding whether it needs a manager. If it does, hand over with the full story written so the customer does not repeat it, and tell them what happens next. Say what you would do first and when you would hand over, as a plan | The live form of the escalations line (F4); no past claimed |
| A4 | "You think a customer has hit a bug. They ask when it will be fixed, and you do not know. What do you write?" | CASE | [generic] | Say what you know, what you do not, what you have passed on and to whom, and when the customer will hear from you next. Do not promise a fix date you were not given; say so plainly | Combines the written-communication line (F3) and the escalations line (F4) in a situation software support meets often |
| A5 | "Imagine I am the customer. Put this in plain words: 'Your ticket has been escalated per policy to Tier 2 pending root cause analysis.'" | JD | [generic] | Two or three short sentences: what is happening, what you need from the customer if anything, when they will hear back. No jargon. Type it, then offer to adjust the tone. No claim about your past | Scores the written-communication line (F3) directly, in the medium the interview uses |

### Bank B: Skeptic (weight highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have never worked for a software company. How would you handle that in your first month?" | JD | [grounded] "I've never worked for a software company." | The highest-ROI rehearsal in this pack. Start with your own words: "I've never worked for a software company." Then a plan, said as a plan: what you would learn first, who you would ask, and how you would know you were ready to take tickets alone, all in your own words. Claim no past exposure to software. Hold through two follow-ups, the likeliest being what you would do the first time you did not know a product answer and how fast you would expect to be useful. If you cannot yet say how fast, say so plainly rather than offering a timeline you cannot back. Return to the plan, never to something added | F5 is the biggest gap and your own message names it, so some form of this question is very likely; JD because it scores fit against the role |
| B2 | "The ad asks for Zendesk or a similar tool. How quickly could you be productive on ours?" | JD | [grounded] "I use Freshdesk every day" | Hold exactly this: "I use Freshdesk every day." Answer slot: if you have used Zendesk, say where and how much, in your own words; if you have not, say so plainly and return to Freshdesk. Do not describe features you do not use, and do not call Freshdesk Zendesk | F2 is the evidence for the tool requirement; JD because it scores the stated line, and "similar" is where the interviewer decides |
| B3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company." | Selection scaffold: pick the gap you can state plainly and attach a plan to. Your own words already give you one: "I've never worked for a software company." If you pick another, it must be something you can name from your own work; if nothing else comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The Skeptic's standard stem, aimed at F5; JD because it tests honest self-assessment against the role |
| B4 | "The role needs confidence with escalations. What is the hardest escalation you have handled?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Hold only what the quote carries: three years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day. Answer slot: if escalations came to you in that role, say what kind and which part was yours, in your own words; if none did, or they went to someone else, or there was no such step, say so plainly and return to the three years and the calls and emails | F4 is where the ad presses and your material is silent; EXP because it tests what was actually yours |
| B5 | "Why move from an energy supplier to software support?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Your reason, in your own words; the pack has no source for it and supplies none. Keep it about what draws you to this work, not what is wrong with where you were. One sentence on why now. If your reason is not about the work, say what it is plainly | The Skeptic's motivation probe across F1 and F5; EXP because it tests whether your story holds together |

### Bank C: Conversational (weight medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey. How did you end up in customer service?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | A 90-second arc with only the beats the sentence states: the role, the three years, the calls and emails. Why you started and where you want to go next are yours to say in your own words; the pack has no source for either | Friendly openers are still scored, and F1 is the spine of the biography; EXP because it tests the story against your own words |
| C2 | "What does a normal day look like for you?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Use the sentence's own rhythm: answering around 60 calls and emails a day. Keep "around", which is your own hedge. Whether those calls and emails ran through Freshdesk is your fact to state, not the pack's. Anything beyond the sentence is your own account, and only if it happened | F1 again, in casual form; EXP because it checks the day against the claim |
| C3 | "Tell me about training the new starters." | EXP | [grounded] "I trained four new starters on our refunds process last year" | The beats the sentence states: four new starters, your refunds process, last year. Tell them in your own words. Anything about how you taught it, what went wrong or how they got on is yours to say only if it happened | F3's second quote is your only evidence of teaching or explaining; EXP because it tests what you did |

### Bank D: Data-Driven Prober (weight medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You said around 60 calls and emails a day. How was that counted?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Four slots, in your own words: how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say that plainly and do not reconstruct a method. Keep "around", and keep calls and emails together, since your sentence counts both | F1 holds your one headline figure; EXP because probers test attribution on every number |
| D2 | "You trained four new starters. How much of that training was you?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Hold: "I trained four new starters on our refunds process last year." Answer slot: if others were involved, say who did what; if you did it alone, or it was not all yours, say so plainly. The same four slots apply to "four": how it was counted, what it is sensitive to, the assumption you would defend least | F3's second quote carries a number and a claim of doing; EXP because the question exists to catch inflated credit |
| D3 | "Walk me through a ticket from arrival to close in Freshdesk." | JD | [grounded] "I use Freshdesk every day" | Answer slot: describe the steps you actually take, in your own words and in the order they happen. If some stages are done by someone else or in another system, or a step I might expect does not exist in your workflow, say so plainly and stay with what you do: "I use Freshdesk every day." Never add a feature or a stage you do not use | F2 is the evidence for the tool requirement and the likeliest place for a line-by-line probe; JD because it scores that line |

### Bank E: Pressure (weight low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who already works in software support?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day"; "I use Freshdesk every day"; "I've never worked for a software company." | Hold, then concede. Hold: three years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day, and "I use Freshdesk every day." Through two follow-ups, return to those and add nothing. Concede once and specifically: "I've never worked for a software company." Do not fold on what you hold to restore harmony, and do not claim to be better; say what you bring and what you lack | The Pressure stem aimed at F5; JD because it scores fit against the role |
| E2 | "Convince me you are confident handling escalations. You have sixty seconds." | JD | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Pause and restate the question. Answer slot: if escalations came to you, say what kind, what you did and what you handed on; if none did, or they went to someone else, say so plainly, then say how you would handle the first one that reached you. Hold whichever branch is true through two follow-ups, and concede what you do not know rather than adding detail | F4 under time pressure; JD because it scores the ad's escalations line |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| "2+ years in customer support" | C1, C2, D1, E1 |
| "experience with Zendesk or a similar ticketing tool" | B2, D3, E1 |
| "clear written communication" | A1, A4, A5 |
| "confidence handling escalations" | A3, A4, B4, E2 |
| Software background, not in the ad as you gave it | B1, B3, B5, E1 |

## Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| R1 | "What does a good first month look like for someone new on the support team?" | Shows you are planning your ramp, which answers B1 before it is asked, and tells you how you will be judged |
| R2 | "Which kinds of tickets go to escalation, and who picks them up?" | Shows you take the escalations line seriously and gives you the real shape of the work |
| R3 | "How does the team coach written replies, and is there a style guide or review?" | Written communication is scored, so asking how the team keeps it consistent signals you care about it |
| R4 | "Which ticketing tool does the team use, and how do new starters learn the product?" | Ties to the tool line and to your software gap without making a claim |
| R5 | "Will a later stage include a spoken or video conversation, or does everything stay in text?" | A prep reason: you will know whether to rehearse spoken answers as well as typed ones |
| R6 | "What is the biggest thing the team is trying to improve right now?" | Shows you think about the team's goals and not only your own fit, and gives you something specific to refer back to |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Used Zendesk | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day." The limit is the pack's observation, not words for you: your material names Freshdesk, not Zendesk. B2's slot stays on whether you have used Zendesk, with an honest second branch |
| Handled 60 tickets a day | Inflated form of F1 | F1's quote at its own scope: "answering around 60 calls and emails a day." The limit is the pack's observation: your sentence counts calls and emails, not tickets |
| Ran the team's onboarding, or the refunds training programme | Inflated form of F3 | F3's quote at its own scope: "I trained four new starters on our refunds process last year." D2's slot stays inside that sentence |
| Has worked with or supported a software product | A negative you stated, F5 | The plain acknowledgment F5 gives: "I've never worked for a software company." Then a plan said as a plan. No slot |

## Sources

Provided documents: your message, which holds the invite text, the ad's requirements as you gave them and your background. No dossier was consumed.

Searches sent, all refused: "Lumenvale Software company values"; "Lumenvale Software interview process customer support specialist"; "Lumenvale Software strategy news".

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | Search refused. Would have moved a values cheat sheet if a values-style round were detected, and VAL questions |
| 2. `Lumenvale Software interview process customer support specialist` | unavailable | Search refused. The loop rests on the invite's own words, which give one text chat with the support team lead; nothing about the chat's format or focus beyond that is established |
| 3. `Lumenvale Software strategy` or recent news | unavailable | Search refused. Would have fed CO questions, so the banks have none |
| 4. `{interviewer name} Lumenvale Software` | n/a | No name was given for the interviewer, so there was no query to form; the interviewer read is absent |
| 5. representative `Customer Support Specialist` JD | skipped | The requirements you supplied fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Search permission, so the three refused searches can run → values, loop structure and strategy rows move from unavailable, and CO and VAL questions can be added; a deeper pass of up to 6 further searches and 2 further fetches, several more minutes, can follow on your say-so
- The full text of the ad → the four requirement rows become exact quotes from it, and any requirement beyond those four gets its own question
- The support team lead's name and profile → an interviewer read, persona weights tuned to their public footprint, and a reverse question tied to their own path
- Anything the talent team told you about the chat's focus or length → coverage assumed from round-type priors becomes coverage built on what they said
- Your own account of escalations in your current role, if any came to you → F4 moves from none given to quoted evidence, and B4 and E2 become story maps
- A written reply of yours with names and details removed, or a quality score or customer comment on your replies → F3 moves from low confidence, because that is the artifact this field keeps for written communication
- A tuesday-dossier.md from an earlier session → the highest-ROI objection would be evidence-derived and not inferred, and weak areas would carry a stated strategy
