Searches weren't permitted in this session, so I'm building the pack from the advert, Hannah's message and your notes. I'm writing it now.
Your prep pack is saved as `quillmoor-diagnostics_operations-coordinator_interview_pack.md`. I built it for Hannah's recruiter screen. Web searches weren't permitted in this session, so nothing in it about Quillmoor comes from outside the advert. The pack has no company-specific questions or interviewer read for that reason.

The answers on pay, hybrid days and why you're leaving are your own words, kept whole. Rehearse them as you said them to me. The pack has 18 questions in five styles, six questions for you to ask Hannah, and a list of claims it won't coach.

The gap most likely to come up is the advert's first duty: coordinating production schedules between planning, the warehouse and QA. Your material says "I schedule deliveries for our three depots", which is delivery scheduling, not production scheduling. Question B2 rehearses holding that line honestly, and I'd start there. SAP is a smaller risk. The advert calls it a plus, and your answer is "Never used SAP", plus a plan for learning it.

Say the word and I'll play the Skeptic on B2.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

What notice period do you owe your current employer? Hannah will ask, and your notes don't say.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor-diagnostics_operations-coordinator_interview_pack.md -----
# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** recruiter screen, Thursday 2pm, a 30-minute phone call (Hannah rings the mobile number on your application).
**Interviewer:** Hannah Lowther, Talent Partner. Her message says she will cover salary expectations, notice period, how the hybrid pattern would work for you and what is prompting a move, then tell you about the team and next steps.
**Candidate:** Sam.

## How to use this pack

Personas describe how a question is asked. Types describe what it is scoring. Guidance is scaffolding, not a script: rehearse it in your own words, and only what you actually did.

| Tag | Meaning |
|---|---|
| VAL | Behavioral or values alignment |
| EXP | Work-experience deep-dive: do your claims survive scrutiny |
| JD | Role and advert-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | Hypothetical or live problem |

This pack has no CO or CASE questions. Company research was unavailable (see Sources), and a recruiter screen rarely sets a live problem.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots" — your message | medium | [grounded] | transferability | Your material says delivery scheduling for three depots, not production scheduling between planning, the warehouse and QA, and the words stay there: "I schedule deliveries for our three depots." Answer slot: the advert's planning, warehouse and QA line makes a probe on that coordination likely. If any of your scheduling involved a planning or QA function, say which and how, in your own words; if none did, or it was not yours, say so plainly and stay with the deliveries |
| F2 | "chase late orders" — advert | "chase suppliers when orders slip" — your message | medium | [grounded] | none | No gap, but a message line with nothing inspected behind it, so expect a probe. Lead with it in the quote's own terms: you chase suppliers when orders slip |
| F3 | "track supplier deliveries" — advert | "I schedule deliveries for our three depots" — your message | low | [inferred] | discovery | Scheduling deliveries to depots does not show tracking what suppliers deliver, and the bridge should not be stretched. Answer slot: if you track incoming supplier deliveries, say how, in your own words; if you do not, or it is not yours, say so plainly and stay with scheduling deliveries |
| F4 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | medium | [grounded] | none | No gap, but a figure with nothing inspected behind it, so expect it to be probed. The sentence says you rebuilt the spreadsheet and that discrepancies fell by about a third over a year; it does not say the rebuild caused the fall, and the words should not either |
| F5 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material does not show this either way. Answer slot: if you report on delivery performance, say what and how often, in your own words; if you do not, or it is not yours, say so plainly and stay with "I schedule deliveries for our three depots" |
| F6 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | No gap. Lead with the years and the role in the quote's own terms |
| F7 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet" — your message | low | [inferred] | discovery | The quote says spreadsheet, not Excel, and the tool is not stated. Answer slot: if the spreadsheet was in Excel, say what you did in it, in your own words; if it was another tool, or part of it was not yours, say so plainly and name the tool |
| F8 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "Never used SAP." Then how you would learn it, said as a plan and never as a past. The advert calls ERP experience a plus, not a requirement; that is the advert's wording, not a promise about how it is weighed |
| F9 | "or similar" ERP — advert | "we run our own in-house stock system" — your message | low | [inferred] | discovery | The quote says your company runs an in-house stock system; it does not say what you do in it. Answer slot: if you use it day to day, say what for, in your own words; if you do not, say so plainly and return to the quote |
| F10 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" — your message | high | [grounded] | none | Your own constraint, met by the advert's two days. Words: your sentence, as you said it |
| F11 | "£38,000–£44,000" — advert | "I'm hoping for £42,000" — your message | high | [grounded] | none | Your own figure, inside the advert's band. Words: your sentence, as you said it |
| F12 | "your notice period" — Hannah's message | none given | none | [grounded] | hard_gate | Your material does not establish it. The pack asks nothing here and writes no words for it |
| F13 | "what's prompting a move" — Hannah's message | "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" — your message | medium | [grounded] | none | Your stated reason, whole. Words: your sentence, as you said it |

## Persona table

| Persona | How it shows up in this call | Likelihood and reasoning | Counter-strategy (a rehearsal method, not a claim) |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly, unstructured; Hannah's four logistics topics arrive as chat | Highest. The recruiter-screen prior puts logistics and motivation first, and Hannah's message lists exactly those. No interviewer signals were available | A short arc for the biography question; treat casual questions as scored |
| Skeptic | Quiet probing of the gaps in a friendly register | High. Relationship prior for a screen, and the snapshot shows gaps at F1, F3, F5 and F8 | Rehearse the single most predictable objection (B2) until it is boring |
| Data-Driven Prober | Picks up the one figure and asks how it was counted | Medium. A recruiter may skim a figure; a hiring manager will not. You have one figure, F4 | Know what you can and cannot say about how it was counted; say plainly when you do not know |
| Pressure / Stress | A time-boxed or challenging turn inside an otherwise friendly call | Low to medium. Uncommon on a screen, but a quick "why you" is common | Pause, restate, hold a position through two follow-ups, concede only what is real |
| Values / Behavioral | An "Tell me about a time" question | Low. No values-style round is established for this loop: Hannah's message describes only this call, and no company values were read | Choose a real instance, or say plainly that none comes to mind |

Case/Strategist and Peer Evaluator are not weighted: neither fits a recruiter screen. Persona weights rest on the recruiter-screen prior alone; nothing is known about later rounds, and no archetype is assumed for them.

## Requirement coverage

| Requirement | Questions |
|---|---|
| Coordinate production schedules between planning, the warehouse and QA | B2, D1 |
| Track supplier deliveries and chase late orders | C3, E1 |
| Keep stock records accurate | C1, D2, E2 |
| Report weekly on on-time dispatch | B5 |
| 2+ years in operations or logistics coordination | A1 |
| Confident with Excel | C2 |
| ERP experience (SAP or similar) | B1, B4, D3 |
| Hybrid, two days a week at Avonmouth | A4 |
| £38,000–£44,000 | A2 |
| Notice period (Hannah's agenda) | A3 |
| What is prompting a move (Hannah's agenda) | A5, B3 |

## Question banks

### A. Conversational / Rapport Builder (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey to where you are now." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip"; "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | A 90-second arc in three beats, each a clause the quotes state: the role and the four years; scheduling deliveries for three depots and chasing suppliers when orders slip; rebuilding the stock-count spreadsheet, with the figure as you said it. Tell them in your own words and in that order. Close with one sentence of your own on what in the advert draws you; that sentence is yours to supply | F6, F2 and F4 supply the arc. EXP because the biography question tests whether your account of your own work is plain and consistent |
| A2 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000" | Logistics slot: give your figure in your own words, as you said it: "I'm hoping for £42,000." If she asks again, give those words again. If asked what you earn now: "I'd rather focus on the range for this role" | F11. Hannah's message lists it first; JD because pay is the advert's term |
| A3 | "What's your notice period?" | JD | [grounded] | Logistics slot: give your actual notice period, in your own words | F12. Hannah's message names it; JD because it is a term of taking the job |
| A4 | "How would the hybrid pattern work for you, two days a week at Avonmouth?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | Logistics slot: give your own words, as you said them: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." If she comes back to it, give those words again | F10. Hannah's message names the hybrid pattern; JD because the advert states it |
| A5 | "What's prompting a move?" | EXP | [grounded] "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Logistics slot: give your reason in your own words, whole: "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." If she comes back to it, those are your words again | F13. Hannah's message names it; EXP because it is about your own situation |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Have you worked in SAP or a similar ERP?" | JD | [grounded] "Never used SAP"; "we run our own in-house stock system" | Words: "Never used SAP." Then, as a plan and not a past, how you would learn it, in your own words. Answer slot: the advert's "or similar" makes a probe on other systems likely. If you use the in-house stock system day to day, say what for; if you do not, say so plainly and return to "we run our own in-house stock system" | F8 and F9. The advert names ERP as a plus; JD because it scores a listed qualification |
| B2 | "This role coordinates production schedules between planning, the warehouse and QA. What's your experience of that kind of coordination?" | JD | [grounded] "I schedule deliveries for our three depots" | **The highest-ROI rehearsal in this pack.** The hold is only what the quote carries: "I schedule deliveries for our three depots." Answer slot: if any of that scheduling involved a planning or QA function, say which and how, in your own words; if none did, or it was not yours, say so plainly and describe the deliveries. Hold through two follow-ups by returning to the deliveries, never by adding to them. The concession uses only the quote, and then asks Hannah what the production side involves, which is a question and not a claim | F1 is the advert's first duty and the widest gap between your material and the listed job, so this objection arrives in some form. JD because it scores a stated responsibility |
| B3 | "Why this role, rather than another coordinator job in Bristol?" | JD | [grounded] "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Say in your own words what in the advert draws you; the pack does not write that for you. If she comes back to why you are looking, your own words are the quote, again, whole | F13. Motivation consistency is what a screen tests; JD because it asks about this role |
| B4 | "Which part of this advert would you be weakest at on day one?" | JD | [grounded] "I schedule deliveries for our three depots"; "Never used SAP" | Choose the gap you would name yourself, in your own words. The pack's observation is that your material shows delivery scheduling (F1), nothing on weekly dispatch reporting (F5) and no SAP (F8). Whichever you pick, follow it with how you would learn it, said as a plan and never as a past | F1, F5 and F8. A standard skeptic question; JD because it scores the advert's own list |
| B5 | "The advert asks for weekly reporting on on-time dispatch. How comfortable are you with that?" | JD | [grounded] "I schedule deliveries for our three depots" | Answer slot: if you report on delivery performance, say what and how often, in your own words; if you do not, or it is not yours, say so plainly and return to "I schedule deliveries for our three depots" | F5. The advert states it and your material is silent; JD because it is a listed duty |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Answer slot, in your own words: how the figure was counted; what it is sensitive to; the assumption behind it you would defend least; and which part was yours. If you do not know how it was counted, say so plainly. The quote carries "I rebuilt our stock-count spreadsheet" as yours and "about a third over a year" as the figure's size and span; describe the two as the sentence does | F4. It is your one headline figure, so it is the likeliest target of a probe; EXP because it tests attribution |
| C2 | "What did you build the stock-count spreadsheet in?" | JD | [grounded] "I rebuilt our stock-count spreadsheet" | Answer slot: name the tool as it actually was. If it was Excel, say what you did in it, in your own words; if it was another tool, or part of it was not yours, say so plainly | F7. The advert asks for Excel confidence and the quote does not name a tool; JD because it scores a listed skill |
| C3 | "When an order slips, what do you do to chase the supplier?" | EXP | [grounded] "chase suppliers when orders slip" | Answer slot, in your own words: say what you actually do when an order slips. If chasing differs from how you describe it, or part of it is someone else's, say so plainly and return to "chase suppliers when orders slip" | F2. The advert's "chase late orders" line raises it; EXP because it tests what you did |

### D. Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who already works in manufacturing?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "chase suppliers when orders slip" | Pause and restate the question. Hold on the quotes only: the four years as a logistics coordinator, and chasing suppliers when orders slip. Hold through two follow-ups. Concede specifically and only from the quote: what you schedule is deliveries, and you would ask what the production side involves | F6, F2 and F1. JD because it tests fit with the listed job under time pressure |
| D2 | "That result. How much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Hold on what the quote carries: "I rebuilt our stock-count spreadsheet." Answer slot: if anything else contributed to the fall, say what, in your own words; if you do not know, say so plainly. Do not claim the rebuild caused the fall unless you can say how | F4. A standard attribution probe |
| D3 | "Convince me you would cope without SAP experience." | JD | [grounded] "Never used SAP"; "we run our own in-house stock system" | Words: "Never used SAP." Then a plan, in your own words, for how you would learn it. Do not offer the in-house system as an equivalent unless you can say what you do in it (B1's slot) | F8 and F9. JD because it presses on a listed plus |

### E. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time a supplier let you down and you had to deal with it." | VAL | [grounded] "chase suppliers when orders slip" | Selection scaffold: pick a specific time, with a named order, what you did and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "chase suppliers when orders slip", or how you would handle it | F2. The advert's "chase late orders" line raises it; VAL because it asks for past behavior |
| E2 | "Tell me about a time you spotted an error in records and what you did about it." | VAL | [grounded] "discrepancies fell by about a third over a year" | Selection scaffold: pick a specific time, with what the error was and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "discrepancies fell by about a third over a year", or how you would handle it | F4. The advert's "keep stock records accurate" line raises it; VAL because it asks for past behavior |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "After this call, what are the next steps, and who would I meet in what format?" | Hannah says she will cover next steps; this confirms the shape of the loop, which this pack could not research |
| R2 | "Who does the role report to, and which teams sit around it?" | She says she will tell you about the team; this shows you are picturing the working arrangement |
| R3 | "How do planning, the warehouse and QA currently hand schedule changes to each other, and where does the coordinator sit?" | It reads the advert's first duty back to her and shows you took the three-function line seriously |
| R4 | "Which ERP does the team work in, and how is onboarding handled?" | The advert says "SAP or similar"; this turns F8 into a question about onboarding, on your terms |
| R5 | "What does on-time dispatch look like today, and what would good weekly reporting look like in the first few months?" | It engages with the reporting duty (F5) and gives you a sense of the standard |
| R6 | "What would the first month look like for someone in this role?" | An open, forward-looking close that avoids a generic "no, you've covered everything" |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has production-scheduling experience, or coordinates between planning, the warehouse and QA | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says delivery scheduling, not production scheduling. B2's slot stays inside the deliveries |
| Has used SAP | Negative stated by the candidate, F8 | The plain acknowledgment F8 gives: "Never used SAP." Then a plan, never a past. No slot |
| Has ERP experience equivalent to SAP | Inflated form of F9 | F9's quote at its own scope: "we run our own in-house stock system." The limit is the pack's observation: the quote says the company runs it, not what you do in it. B1's slot stays inside that |
| The spreadsheet rebuild cut discrepancies by a third | Inflated form of F4 | F4's quote at its own scope. The pack's observation: the sentence pairs the rebuild and the fall without stating a cause. C1's and D2's slots ask only how it was counted and which part was yours |
| Advanced or expert Excel skills | Inflated form of F7 | F7's quote at its own scope: "I rebuilt our stock-count spreadsheet." The pack's observation: it names a spreadsheet, not Excel. C2's slot asks only which tool it was and what you did in it |

## Sources

Provided: the advert you pasted, Hannah Lowther's LinkedIn message, and your own notes on your background and what you would tell her. No CV was provided; no dossier was present.

Searches sent, all refused (the session did not grant search permission):

- "Quillmoor Diagnostics values" — refused
- "Quillmoor Diagnostics interview process operations coordinator" — refused
- "Quillmoor Diagnostics strategy news Avonmouth" — refused
- "Hannah Lowther Talent Partner Quillmoor Diagnostics" — refused

Nothing about Quillmoor beyond the advert's own words appears in this pack.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | Every call was refused. It would have supplied published values by name; with no values-style round established, it would have themed VAL questions only |
| 2. `Quillmoor Diagnostics interview process operations coordinator` | unavailable | Every call was refused. It would have named the later rounds and reweighted personas beyond this screen |
| 3. `Quillmoor Diagnostics strategy news` | unavailable | Every call was refused. It would have supplied the CO questions, so the pack has none |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | Every call was refused. It would have supplied an interviewer read and a reverse question tied to her path; the reverse questions are role-generic |
| 5. representative `Operations Coordinator` JD | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV → rows built only from your message (F1 to F9, F13) are checked against a fuller record, and the thin rows may rise from `low` or `medium`. The artifacts that would raise F4 to `high` in this field are the rebuilt stock-count file itself, or a delivery schedule or supplier-chase log you can describe
- Your notice period → F12 is filled and A3 is written in your own words
- Your own answers to the slots in F1, F3, F5, F7 and F9 (which tool the spreadsheet was in, whether you track supplier deliveries or report on delivery performance, what you do in the in-house system) → those rows become evidence, and B1, B2, B5, C2 and C3 sharpen
- The company's careers page, values page or any recruiter email on later rounds, pasted in → company-specific questions and persona weights replace the recruiter-screen prior
- Hannah's LinkedIn profile text, pasted in → an interviewer read, and a reverse question tied to her path
- A `tuesday-dossier.md`, if you have one → verified evidence and any prohibited claims carry in, and the objection to rehearse is read from it rather than inferred
