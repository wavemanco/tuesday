Routing to mock-interview, so I'll read its playbook first.
Before the prep, one thing in the invite: it says the process is "carried out entirely on Telegram" and that "your offer and onboarding will be completed in this chat as well". A hiring process run wholly by chat is a known scam pattern. A chat alone doesn't show who is on the other end, and the invite may not come from who it names. Until you've checked, don't pay anything, deposit a cheque, or send documents or bank details through the chat. Check with Lumenvale through contact details you find yourself on its own website or careers page, not through this chat or any number or email the sender gives. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as `lumenvale-software_customer-support-specialist_interview_pack.md`. I built it assuming the support team lead would be your future manager, since your message didn't say. The pack has 19 questions across Case, Skeptic, Conversational, Prober, Pressure and Peer styles, plus six reverse questions.

- **Top objection:** your own line, "I've never worked for a software company", is the likeliest challenge, so B1 is the question to rehearse most.
- **Gaps to prepare for:** your material doesn't show escalations (F4) or what the written-communication requirement rests on (F3). Those rows have answer slots for you to fill from what you actually did.
- **Your strengths:** the three years, the 60 calls and emails a day, daily Freshdesk and the four new starters are kept to exactly what you wrote.
- **Not researched:** my two web searches on Lumenvale were refused. The pack has no company facts, so the company-knowledge questions are generic.

Say the word and I'll play the Skeptic on B1, the question the pack names as its highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is the support team lead who'll run the chat the person you'd report to, or a peer? The answer reweights every bank.
Can you paste the full ad text and your CV? The pack rests on your summary of the ad for now, and I've built it without them if you'd rather skip.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: lumenvale-software_customer-support-specialist_interview_pack.md -----
# Interview prep pack: Customer Support Specialist, Lumenvale Software

Interviewer: the support team lead (name not given). Relationship assumed: your future manager, because your message did not say. Format: a text chat, one session, as your message describes it. Session mode.

## How to use this pack

Personas describe how a question arrives; types describe what is being scored. The guidance is scaffolding, not a script: say it in your own words, and only about what you actually did. Your interview is typed, so rehearse by typing short, complete messages rather than reciting.

Type key:

- VAL: whether past behaviour shows the company's published values (none in this pack: no values page was read and no values round is established)
- EXP: whether your claims survive scrutiny, and what was actually you
- JD: the ad's stated requirements, including your gaps against them
- CO: what you know about the company
- CASE: a live problem from the job, scored on structure and reasoning

## Fit snapshot

The requirements are the ad's four lines as you relayed them in your message. Evidence is your own sentences, quoted.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — the ad, as you relayed it | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it, so expect a probe. Lead in the quote's own terms: three years, customer service advisor, an energy supplier, around 60 calls and emails a day. Keep the word "around" |
| F2 | "experience with Zendesk or a similar ticketing tool" — the ad, as you relayed it | "I use Freshdesk every day" — your message | medium | [grounded] | none | Say it by name and in the present tense, as you did: "I use Freshdesk every day." Your material names one tool and says nothing about any other. Whether the interviewer treats it as similar is theirs to judge, so expect a probe on what you do in it |
| F3 | "clear written communication" — the ad, as you relayed it | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | Emails are in the sentence; whether this reaches the requirement is not shown, and the bridge should not be stretched. Answer slot: the ad's line makes a probe likely, and the interview itself is typed. If anything about how you answered those emails was yours to decide, say what; if nothing was, or it was not yours, say so plainly and stay with the emails you answered each day |
| F4 | "confidence handling escalations" — the ad, as you relayed it | none given | none | [grounded] | discovery | Your material does not show escalations either way. Answer slot: the ad's line makes a probe likely. If a case came to you from a colleague, or was pushed higher by the customer, say what it was and what you did, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the volume you answered each day |
| F5 | Experience supporting customers of a software product — a role-family expectation, not stated in the ad as you relayed it | "I've never worked for a software company" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked for a software company." Then how you would learn their product, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F6 | None stated in the ad as you relayed it: a strength you offered | "I trained four new starters on our refunds process last year" — your message | medium | [grounded] | none | Keep the quote's verb, number and scope: trained, four new starters, the refunds process, last year. Expect a probe on which part was yours |

## Persona table

Weights rest on the relationship prior for a hiring manager (Case/Strategist plus Skeptic) and on the one-session text-chat format your message describes. If the lead is a peer, the weights change; the closing question asks.

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (bank A, 5 questions) | Live problems from the job: an angry customer, a handover, a policy no | High: top prior for a hiring manager, and the ad's escalations line invites a live problem | Clarify, state the objective, structure, then answer; challenge one premise politely |
| Skeptic (bank B, 5 questions) | Quiet probing of the gaps: software, the named tool, escalations, why this move | High: second prior for a hiring manager, and your message itself names a gap (F5) | Rehearse the software-company objection until it is boring: hold on the quoted sentences, concede plainly, add nothing |
| Conversational (bank C, 3 questions) | A friendly opener such as "walk me through your journey", then casual questions about the ad's topics | Medium: a one-session chat plausibly opens this way, but nothing in the invite says so | Prepare a short arc from your own sentences and treat casual questions as scored |
| Data-Driven Prober (bank D, 2 questions) | Pulls on the figures you gave | Medium-low as a style, high as a topic: you gave two figures, around 60 a day and four new starters (F1, F6) | Know what you can and cannot say about how each figure was counted, and say plainly when you do not know |
| Pressure (bank E, 2 questions) | Time-boxes you with a short, abrupt message | Low: nothing in the invite points to a stress style; included because short typed turns can feel abrupt | Pause before replying, restate the question, hold your position through two follow-ups, concede only what is true |
| Peer Evaluator (bank F, 2 questions) | Teamwork and handover scenarios | Low: the interviewer is assumed to be your manager, not a peer | Frame what you bring the team, not only what you need |

## Question banks

Highest-ROI prep: B1, the software-company objection. It is the gap you stated yourself (F5), it will be asked in some form, and a calm, short answer changes the interview.

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in for the third time about the same unresolved problem and says they will cancel today. Write me the first reply." | CASE | [generic] | Structure it before you type: what you would check first, what you will do now and by when, what you need from the customer if anything, and what you will not promise. Keep the reply short enough to read at a glance. The question needs no claim about your past, so the guidance makes none | Case/Strategist is the top-weighted persona (persona table). CASE because it scores reasoning on a live problem; `[generic]` because it is a role-family pattern, not a fact about this employer |
| A2 | "A customer is angry and the fix sits with a team you cannot instruct. What do you do, and what do you tell the customer while you wait?" | JD | [generic] | Structure it: what you would try yourself first, what makes it a handover, what the handover note must carry so the customer does not repeat themselves, and what you tell the customer about timing without promising a fix. Name one premise you would check before acting. No claim about your past | Scores the ad's escalations line (F4) as a decision rather than a record. JD for the requirement, CASE in delivery; `[generic]` because it is a pattern for the problem |
| A3 | "Three messages arrive together: a customer who cannot log in, a refund query, and a complaint about a colleague. Which do you take first, and why?" | CASE | [generic] | Say your ordering rule out loud before applying it: what is time-sensitive, what is blocking a customer entirely, what can wait with an honest holding message. Then name the one thing you would want to know that you cannot tell from the messages. No claim about your past | Prioritisation is a common live problem in a support loop, and the Case persona likes a rule stated before the answer. `[generic]`; CASE |
| A4 | "A customer asks for something that is against policy. Write me how you would say no." | JD | [generic] | Lead with what you can do, then the limit in plain words, then the reason in one line, then the next step. Keep the tone steady and the message short. No claim about your past | Scores the ad's written-communication line (F3) by having you write rather than describe. JD for the requirement, CASE in delivery |
| A5 | "A customer asks a question about our product that you cannot answer yet, and the product is new to you. What do you do in the next ten minutes?" | CASE | [generic] | A plan, said as a plan and never as a past: what you would look up, who you would ask, what you would tell the customer honestly about timing, and how you would record the answer so it is quicker next time. No claim about software experience | The same objection as B1, set as a live problem so the answer is practised in two shapes (F5). CASE because it asks no past |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never worked for a software company. How will you get up to speed on ours?" | JD | [grounded] "I've never worked for a software company" and "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment: "I haven't worked for a software company." Then what your material carries, at its own scope: "For three years I was a customer service advisor at an energy supplier, answering around 60 calls and emails a day." Then the plan, said as a plan: what you would learn first about their product and whom you would ask. Follow-up 1 will likely press on the difference: hold by returning to that sentence, adding nothing. Follow-up 2 will likely ask what happens when you do not know an answer: concede plainly that there will be things you do not yet know, and say what you would do next (A5 rehearses it). The limit is part of the answer, not a confession | F5 is the gap you stated, and the objection aims exactly where the material is thinnest, which is where a pack is tempted to thicken it. JD because it scores a gap against the role; the label is `[grounded]` on your two sentences |
| B2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company" | Choose from what you actually know about yourself. One honest candidate is the gap you stated: "I haven't worked for a software company." Name it in a sentence, then say what you would do in your first weeks about it, as a plan. If a different weakness is truer, use that one and say it plainly; do not pick a weakness you do not have | The stock Skeptic question, and F5 is the likeliest answer to it. JD because it asks about fit against the role |
| B3 | "The ad mentions Zendesk or a similar ticketing tool. What do you use?" | JD | [grounded] "I use Freshdesk every day" | Answer with the tool you named, in the present tense: "I use Freshdesk every day." Answer slot: the ad's line makes a probe on what you do in it likely. Say, in your own words, what you do in it; if part of it is not something you use, say so plainly and stay with what you do. Do not answer yes to a tool your material does not name | Covers the ad's ticketing-tool line (F2) and keeps you inside the sentence you gave. JD; the question's premise is the ad's, and the guidance does not adopt anything beyond your quote |
| B4 | "The ad asks for confidence handling escalations. Tell me about a case you handled." | JD | [generic] | No sentence in your material carries an escalation (F4), so this is selection, not a story map. Pick a case that fits these criteria: it came to you from a colleague or was pushed higher by the customer, you can say what was wrong, what you did and what the customer got. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The requirement with no evidence is where a Skeptic aims, and a calm, honest answer is the rehearsal. JD because it scores the stated requirement; `[generic]` because no quoted sentence carries it |
| B5 | "Why this move, and why Lumenvale?" | CO | [generic] | Your message gives no reason, so the reason has to come from you, in your own words. Say what draws you to this role and to this company, and keep to what you found out yourself. Research on the company was not available when this pack was built (see Sources), so nothing about the company is supplied here | The Skeptic's motivation-consistency probe. CO because it tests homework on the company; `[generic]` because the pack holds no company facts |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey so far." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" and "I use Freshdesk every day" | Build a short arc from the beats your sentences state: three years as a customer service advisor at an energy supplier, around 60 calls and emails a day, Freshdesk daily. Then, in your own words and only if you want to, where you are heading. Answer slot: why you want this role is yours to say; do not borrow a reason | The biography question is the usual opener for this persona and is still scored (F1, F2). EXP because it tests what you will claim about your own history |
| C2 | "Tell me about training the new starters on refunds." | EXP | [grounded] "I trained four new starters on our refunds process last year" | Tell the beats the sentence states: four new starters, the refunds process, last year, and that you trained them. If asked for more, say what you actually did, in your own words, and say plainly if you do not remember. Keep "trained"; do not upgrade it to a bigger-sounding verb | F6 is your one example of working with other people, so it is likely to be asked. EXP because it tests attribution |
| C3 | "The ad asks for clear written communication. What does that mean to you in a reply to a customer?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Say in your own words what a good reply looks like to you. Answer slot: if anything about how you answered those emails was yours to decide, say what; if nothing was, or it was not yours, say so plainly and describe what you do when you answer one | Covers the ad's written-communication line (F3) in a casual register, which is still scored. JD |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You said around 60 calls and emails a day. How was that counted?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Say how the figure was counted, in your own words, and keep "around". Answer slot: what the figure was sensitive to, the assumption behind it you would defend least, and which part of it was yours alone. If you do not know how it was counted, say so plainly. Do not split calls from emails unless you know the split | The only headline figure you gave is the one a Prober pulls on (F1). EXP because it tests whether the number survives scrutiny |
| D2 | "You trained four new starters. Which part of that was yours alone?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Answer slot: say in your own words which part was yours; if any part was shared or set by others, say so plainly and stay with what the sentence carries: you trained four new starters on the refunds process last year | A figure raises the which-part-was-yours probe (F6), and the honest answer is rehearsed here. EXP |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "You have sixty seconds: why should I move you forward?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day", "I use Freshdesk every day" and "I've never worked for a software company" | Hold-then-concede. Hold on what your sentences carry: three years as a customer service advisor at an energy supplier, around 60 calls and emails a day, Freshdesk every day. Hold it through two follow-ups by returning to those sentences, not by adding to them. Concede plainly: "I haven't worked for a software company." Do not claim you are better than another candidate | The time-boxed form of F1 and F5 together. JD because it scores fit against the ad; Pressure persona because the test is composure |
| E2 | "I'll stop you there. What is the one thing I should remember about you?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day", "I use Freshdesk every day" and "I trained four new starters on our refunds process last year" | Choose one of your own sentences, in one short message, and say it as you said it. The choice is yours; the pack does not pick. Add nothing the sentence does not say | A forced-choice question tests whether you know what your strongest true line is (F1, F2, F6). EXP |

### F. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "A colleague asks you to take one of their tickets, and it is a hard one. What do you do?" | CASE | [generic] | Structure: what you would ask first, what you would agree to, what you would check so the customer is not handed over twice, and what you would say to the colleague. No claim about your past | A collegial form of the handover problem in A2. CASE because it asks no past |
| F2 | "Two of you worked on the same fix and your lead thanks only you. What do you say?" | CASE | [generic] | Say what you would do in one or two short messages: name the other person's part plainly, and say your own part without claiming theirs. Keep to a principle; the pack supplies no story for you and makes no claim about your past | The Peer persona's credit-sharing stem, set as a live situation. CASE because it asks no past |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| "2+ years in customer support" | E1, C1, D1 |
| "experience with Zendesk or a similar ticketing tool" | B3 |
| "clear written communication" | A4, C3 |
| "confidence handling escalations" | A2, B4 |
| Software-product experience (stated gap, F5) | B1, B2, A5, E1 |
| Training others (F6, your offered strength) | C2, D2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good first month look like for someone in this role, and what would you want to see by the end of it?" | It shows you are thinking about ramp-up, which speaks to F5 without claiming anything |
| R2 | "Which tool would I use day to day, and what kinds of customer questions would I take first?" | It lets you place the ad's tool line against the Freshdesk you use (F2) |
| R3 | "What do new starters on the team find hardest to get right?" | It signals you expect to learn, and it connects to your own experience training new starters (F6) |
| R4 | "How are escalations handled on the team: when does a case move up, and to whom?" | It shows you are thinking about the ad's escalations line (F4) as a team process, not only a personal skill |
| R5 | "What happens after this chat: is there another step, such as a call or a task, before an offer?" | It tells you whether to prepare for another format, so you can plan your prep time |
| R6 | "How does the team review the quality of written replies?" | It ties to the ad's written-communication line (F3) and shows you want feedback on it |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Experience with ticketing tools other than the one you named | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day." The limit is the pack's observation: your material names one tool. B3's slot stays inside what you do in that tool |
| Clear written communication as a track record | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material says emails answered, not how they were worded. C3's slot stays inside how those emails were answered |
| Software company experience | Negative you stated, F5 | The plain acknowledgment F5 gives: "I haven't worked for a software company." No slot |
| Ran or led the refunds training | Inflated form of F6 | F6's quote at its own scope: "I trained four new starters on our refunds process last year." D2's slot asks only which part was yours |

## Sources

Provided documents: your message (the ad's four requirements as you relayed them, your background, and the process the invite describes: one text chat with the support team lead). No other document was provided.

Searches sent: "Lumenvale Software values" — refused. "Lumenvale Software strategy news" — refused.

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | Every call was refused. It would have supplied value names to theme VAL questions; none are in this pack, and B5 is `[generic]` |
| 2. `Lumenvale Software interview process customer support` | skipped | Your message already fixes the loop: one text chat with the support team lead. Persona weights follow it |
| 3. `Lumenvale Software strategy news` | unavailable | Every call was refused. It would have grounded a CO question; B5 is `[generic]` instead |
| 4. `{interviewer name} Lumenvale Software` | n/a | No interviewer name was given, so there was no query to form; there is no interviewer read |
| 5. representative `Customer Support Specialist` JD | skipped | The four ad requirements you relayed fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full text of the ad → the requirement cells become quotes from the ad itself, and any pay, hours, location or right-to-work terms it states get checked as gates
- Your CV → F3 and F4 may gain evidence beyond your message, and the evidence column becomes CV quotes
- Your own answers to the slots in F3 and F4, outside a drill → those rows move from low and none to a real story, and the matching bank rows regenerate
- The support team lead's name, and whether they would be your manager → persona weights read from their public professional footprint, and a reverse question tied to their path
- A deeper research pass (up to 6 further searches and 2 further fetches, several more minutes; it needs web search permission, which the first pass did not get) → targets 6 to 9 become sourced, and B5 and the CO bank stop being `[generic]`
- The company's published values or a recent news piece, if you paste them → the same, without needing search
- A `tuesday-dossier.md` from an earlier run → verified evidence, an evidence-derived top objection and absolute prohibited claims, in place of the ones inferred here
