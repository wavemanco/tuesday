I tried four searches on Quillmoor and Hannah, and the permission was refused for all of them. I'm building the pack from what you've pasted. Anything about the company will be labelled generic.
Your prep pack is saved as `Quillmoor-Diagnostics_operations-coordinator_interview_pack.md`. I built it for Hannah's 30-minute recruiter screen on the four topics in her message. It has 18 questions, six reverse questions and a fit snapshot of the advert against what you told me.

- **Research:** none ran. All four searches I tried (values, interview process, strategy, Hannah) were refused. So nothing in the pack claims to know Quillmoor beyond the advert, and the "what do you know about us?" answer (B4) is generic. Read their website before Thursday and say what you actually read.
- **Your four logistics answers:** pay (£42,000), the Avonmouth days, and why you're leaving all use your own sentences, kept whole. The pack coaches no flexibility on pay or office days. Notice period is an instruction to give your actual notice, because you haven't told me yours.
- **Highest-ROI rehearsal (B1):** the step from scheduling deliveries at a wholesaler to coordinating production schedules between planning, the warehouse and QA. Your material is thinnest there, so expect it in some form.
- **SAP (B2):** you said you've never used SAP, so you can say that plainly. Your in-house stock system stays at what you said about it. Whether it counts as "similar" is a slot for you to answer truthfully.
- **The stock-count figure (C1, D2):** your sentence says you rebuilt the spreadsheet and that discrepancies fell by about a third. It doesn't say the rebuild caused the fall. Be ready to say how much of it was yours.

Say the word and I'll play the Skeptic on B1, the question the pack names as its highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quillmoor-Diagnostics_operations-coordinator_interview_pack.md -----
# Interview pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** recruiter screen, a 30-minute phone call, Thursday at 2pm. Hannah Lowther, Talent Partner, will ring the mobile number on your application. Her stated agenda: salary expectations, notice period, how the hybrid pattern would work for you, what is prompting a move, then the team and next steps.

Built from three things you gave me: the advert, Hannah's message, and your background notes. No company research ran (see Sources), so nothing here claims to know Quillmoor beyond the advert.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your own account of your work survives follow-up |
| JD | Whether you can do the listed job, including its gaps and terms |
| CO | Whether you know the company and can think at its level |
| CASE | A live problem from the role, scored on structure |

An answer slot is an instruction for the interview, not a question for you now. Where the pack has no sentence of yours to build on, it gives a slot with two honest branches instead of a story.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | No gap on length, but a line with nothing inspected behind it, so expect a probe. Say it in the quote's own terms: four years as a logistics coordinator at a building-supplies wholesaler |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots" — your message | medium | [grounded] | transferability | Your material says delivery scheduling across three depots, not production scheduling, and the words stay there: "I schedule deliveries for our three depots." Answer slot: the advert's planning, warehouse and QA line makes a probe on who you work with likely. If any of your scheduling involved working with a planning, warehouse or quality function, say which and how, in your own words; if none did, say so plainly and stay with the depots |
| F3 | "chase late orders" — advert | "chase suppliers when orders slip" — your message | medium | [grounded] | none | No gap. Lead with the quote's own terms: you chase suppliers when orders slip, because a named activity beats an adjective |
| F4 | "track supplier deliveries" — advert | "I schedule deliveries for our three depots" — your message; "chase suppliers when orders slip" — your message | low | [inferred] | discovery | Scheduling deliveries and chasing slipped orders touch the requirement without showing how orders are tracked. Answer slot: the advert's tracking line makes a probe likely. If you keep track of supplier orders, say how, in your own words; if you do not, or it is someone else's task, say so plainly and stay with scheduling and chasing |
| F5 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | medium | [grounded] | none | No gap on the line. The sentence states two things, the rebuild and the fall, and does not say the rebuild caused the fall, so the two are told as the quote tells them. The figure raises the defend-the-number slots in C1 and D2 |
| F6 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material does not show this requirement. Answer slot: if you produce any regular reporting on deliveries or dispatch, say what and how often; if you do not, say so plainly and stay with the stock-count spreadsheet |
| F7 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet" — your message | low | [inferred] | discovery | The quote says spreadsheet, not Excel, and the pack reads it at the lower scope. Answer slot: if the spreadsheet was in Excel, say what you did in it, in your own words; if it was another tool, say which, plainly |
| F8 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP" — your message; "we run our own in-house stock system" — your message | medium | [grounded] | transferability | The acknowledgment is yours: "Never used SAP." The in-house system stays at its own scope: "we run our own in-house stock system", which does not say whether you work in it or whether it counts as similar. Answer slot: the advert's "or similar" makes a probe likely. If you work in that system, say what you do in it; if you do not, say so plainly. Then how you would learn a new system, said as a plan and never as a past |
| F9 | "£38,000–£44,000" — advert | "I'm hoping for £42,000" — your message | high | [grounded] | none | Inside the advert's band, said in your own words and kept whole. Nothing is added to it |
| F10 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" — your message | high | [grounded] | none | The advert's pattern is met in your own words, and both halves of your sentence stay together |
| F11 | "your notice period" — Hannah's message | none given | none | [grounded] | discovery | Your material does not give it. The slot is an instruction in its own words: give your actual notice period |
| F12 | "what's prompting a move" — Hannah's message | "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" — your message | medium | [grounded] | none | Said in these words, kept whole |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational (bank A) | Friendly, unstructured; Hannah's four topics asked as chat | High. Hannah's message names four logistics topics, and a recruiter screen leans this way. The risk is treating it as unscored | A 90-second arc built only from your quoted sentences (A5); each logistics answer in your own words, kept whole |
| Skeptic (bank B) | Quiet probing of the gaps | Medium. The recruiter-screen prior is light, raised for F2, F4, F6 and F8, where your material does not show the requirement | Rehearse the production-scheduling step until it is boring (B1); adjacent evidence only, the limit said plainly |
| Data-Driven Prober (bank C) | Reads the advert line by line, asks how things were done | Medium. The advert lists Excel and weekly reporting, and F5 carries a figure | Know what you can and cannot say about how the figure was counted, and say plainly when you do not know |
| Pressure (bank D) | Short, time-boxed, tests whether you hold a position | Low. Nothing in Hannah's message suggests it; two short items test composure | Pause, restate, anchor in your quoted sentences, concede only what is true |
| Case/Strategist (bank E) | A live problem from the role | Low in this call. Three short problems because the advert's own duties turn into live problems when tested; each makes no claim about your past | Clarify, then structure, then answer; think aloud |

Persona weights rest on Hannah's message and the recruiter-screen prior. They do not rest on a documented Quillmoor process.

## Question banks

Highest-ROI prep in the pack: **B1**. It is where your material is thinnest against the advert's headline duty.

Requirement coverage:

| Requirement | Covered by |
|---|---|
| 2+ years in operations or logistics coordination | A5 |
| Coordinate production schedules between planning, the warehouse and QA | B1, E1 |
| Track supplier deliveries | C3 |
| Chase late orders | A5, E1 |
| Keep stock records accurate | C1, D2, E3 |
| Report weekly on on-time dispatch | C4, E2 |
| Confident with Excel | C2 |
| ERP experience (SAP or similar) a plus | B2 |
| Salary, notice, hybrid pattern, reason for leaving | A1, A2, A3, A4 |

### A. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What's prompting a move?" | EXP | [grounded] "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Logistics slot. Your own words, kept whole: that sentence. If she follows up on this topic, return to those same words and add nothing | F12; Hannah named it as an agenda item, and EXP because it tests whether your account stays consistent |
| A2 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000" | Logistics slot. Your own words: "I'm hoping for £42,000." If asked what you earn now, a line to decline with no figure: "I'd rather focus on the range for this role." | F9; JD because the advert's band is the listed job's term |
| A3 | "What's your notice period?" | JD | [generic] | Logistics slot. Give your actual notice period, in your own words. This pack supplies no figure | F11; JD because it is a term of the job offer, and the pack has nothing from you to put in it |
| A4 | "The role is hybrid, two days a week at Avonmouth. How would that work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | Logistics slot. Your own words, whole: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." If she asks about this again, those same words | F10; JD because the pattern is the advert's own term |
| A5 | "Tell me about your background: how long have you been in logistics coordination, and what does the job involve?" | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots"; "chase suppliers when orders slip"; "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Story-mapped on F1, F2, F3 and F5, in the order of the quotes: four years as a logistics coordinator at a building-supplies wholesaler; you schedule deliveries for three depots; you chase suppliers when orders slip; you rebuilt the stock-count spreadsheet and discrepancies fell by about a third over a year. Stating the last figure invites C1. Close with one sentence in your own words on what in the advert interests you, if something does | F1 to F5 supply the arc; EXP because it is the biography question, and it also covers the advert's 2+ years line |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your background is scheduling deliveries at a wholesaler, and this role coordinates production schedules between planning, the warehouse and QA. How do you see that step?" | JD | [grounded] "I schedule deliveries for our three depots"; "4 years as a logistics coordinator at a building-supplies wholesaler" | The highest-ROI rehearsal. Hold on the quotes only: "I schedule deliveries for our three depots", four years at a wholesaler. Answer slot: if any of your scheduling involved working with a planning, warehouse or quality function, say which and how; if none did, say so plainly. First follow-up, what is different: stay with the depots and say the difference in your own words. Second follow-up, how you would get up to speed: a plan for what you would learn first, said as a plan and never as a past. Never say or imply that you scheduled production | F2 is the thinnest evidence against the advert's headline duty, so this question arrives in some form; JD because it scores the stated requirement |
| B2 | "I don't see SAP in your background. How would you handle the ERP side of this role?" | JD | [grounded] "Never used SAP"; "we run our own in-house stock system" | Your own words: "Never used SAP." Then the system at its own scope: "we run our own in-house stock system." Answer slot: the advert says "SAP or similar", so expect a probe on whether yours counts. If you work in it, say what you do in it; if you do not, say so plainly. Then how you would learn a new system, as a plan | F8; the negative is one you stated, so the plain acknowledgment has its source |
| B3 | "Which part of this advert would you be weakest at on day one?" | JD | [generic] | Selection scaffold. Pick the requirement your material carries least, name it, and say what you would do first. The pack's own reading is that rows F2, F4, F6 and F7 are thinnest; the choice and the words are yours. If nothing comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F2, F4, F6, F7; JD because it asks about the listed requirements |
| B4 | "What do you know about Quillmoor, and what interests you about this role?" | CO | [generic] | No research ran, so this pack holds nothing about Quillmoor beyond the advert's own words. Before Thursday, read the company's own website and say what you actually read, in your own words. For the interest half, name one duty from the advert you would want to do; if none comes to mind, say so plainly and say what you would want to learn | Recruiters commonly ask it; CO because it tests homework depth, and generic because the research is missing |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that stock discrepancy figure was counted." | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Defend-the-number slots, each in your own words: how the figure was counted, what it is sensitive to, which assumption behind it you would defend least, and which part was yours. "I don't know how it was counted" is an honest branch. The sentence says you rebuilt the spreadsheet and that discrepancies fell; whether the rebuild caused the fall is yours to say, or to say you cannot | F5; EXP because it tests attribution |
| C2 | "How confident are you in Excel, and what do you do in it?" | JD | [inferred] "I rebuilt our stock-count spreadsheet" | Say what you built, in those words. Answer slot: if it was in Excel, say what you did in it; if it was another tool, say which, plainly | F7; JD because it scores the stated requirement, inferred because the quote says spreadsheet, not Excel |
| C3 | "How do you keep track of where supplier orders are?" | JD | [grounded] "chase suppliers when orders slip"; "I schedule deliveries for our three depots" | Tell what you do in those words. Answer slot: if you keep track of supplier orders, say how; if you do not, or it is someone else's task, say so plainly and stay with scheduling and chasing | F4; the question's premise comes from the advert's tracking line, and the guidance does not adopt it |
| C4 | "The role includes weekly reporting on on-time dispatch. How much reporting like that have you done?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Answer slot: if you produce any regular reporting on deliveries or dispatch, say what and how often; if you do not, say so plainly and return to the quote: you rebuilt the stock-count spreadsheet | F6; JD because it scores a stated requirement your material does not yet show |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "In a sentence or two: why you for this role?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "chase suppliers when orders slip"; "Never used SAP" | Pause and restate the question. Hold on the quotes: four years as a logistics coordinator at a building-supplies wholesaler, and you chase suppliers when orders slip. Hold through two follow-ups. If pushed on the gaps, concede only what you stated: "Never used SAP." Do not fold on the core claim to restore harmony | F1, F3 and F8; JD because it tests fit against the listed job |
| D2 | "That drop in discrepancies: how much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Hold on "I rebuilt our stock-count spreadsheet". Concede explicitly that the sentence says discrepancies fell, not that the rebuild alone caused it. Answer slot: say how much of the fall you can attribute to the rebuild and how you would know; if you cannot say, say so plainly | F5; EXP because it probes attribution |

### E. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A supplier tells you a delivery for a production run will be two days late. Who do you need to tell, and what do you do first?" | CASE | [generic] | Clarify first: what the delivery feeds and what is waiting on it. Then who needs to know, using the advert's own three functions: planning, the warehouse and QA. Then your options, your first action, and how you would check it landed. The question needs no claim about your past, so the guidance makes none | Built from the advert's coordination and late-order lines; generic because it is a pattern for the problem |
| E2 | "On-time dispatch dropped sharply this week. How would you start diagnosing it?" | CASE | [generic] | Clarify what dropped and against what, then segment where it dropped, then the likeliest causes in order, then what you would check first and what you would report. No claim about your past | Built from the advert's weekly dispatch reporting line; generic |
| E3 | "The warehouse says a part is in stock, but the stock record says it isn't. What do you check?" | CASE | [generic] | Clarify which record and which count. Check recent movements, then the count itself, then what the discrepancy affects, then what you would record. No claim about your past | Built from the advert's stock-records line; generic |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How do planning, the warehouse and QA work together today, and where does this role sit between them?" | It uses the advert's own three functions and shows you read the role as coordination |
| R2 | "What would the first month look like for someone in this role?" | It surfaces the ramp, which is where your thinnest rows sit |
| R3 | "Which system does the team work in day to day, SAP or something else?" | The advert says "SAP or similar", and the answer sizes how much learning F8 involves |
| R4 | "How is on-time dispatch measured today, and who reads the weekly report?" | It ties to F6 and shows interest in the output of the job |
| R5 | "On the hybrid pattern, how are the two days at Avonmouth usually arranged?" | It is a practical question about the advert's own term |
| R6 | "Is this a new role or a replacement?" | It tells you whether there is a predecessor's way of working to inherit |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Scheduled or coordinated production | Inflated form of F2 | F2's quote at its own scope: "I schedule deliveries for our three depots." The limit is the pack's observation: your material says deliveries, not production. B1's slot stays inside the depots |
| Used SAP | Negative the candidate stated, F8 | The plain acknowledgment: "Never used SAP." No slot |
| Has ERP experience | Inflated form of F8 | F8's quote at its own scope: "we run our own in-house stock system." The limit is the pack's observation: your material says an in-house stock system, not an ERP |
| Cut discrepancies by a third through the rebuild | Inflated form of F5 | F5's quote at its own scope, two statements. C1 and D2 ask only how much of the fall was yours |
| Advanced or expert Excel | Inflated form of F7 | F7's quote at its own scope: "I rebuilt our stock-count spreadsheet." C2's slot asks only what tool and what you did |
| Any flexibility on the figure or on the number of office days | Softening of F9 and F10, which you stated | Your own sentences, whole: "I'm hoping for £42,000" and "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" |

## Sources

Provided documents: the advert as you pasted it, Hannah's LinkedIn message, and your background notes. No dossier was present.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Search "Quillmoor Diagnostics company values" was refused. It would have moved B4 and any values-themed question; no values page was read, so no values cheat sheet appears |
| 2. `{company} interview process {role family}` | unavailable | Search "Quillmoor Diagnostics interview process operations coordinator" was refused. It would have moved persona weights beyond this call; weights rest on Hannah's message and the recruiter-screen prior |
| 3. `{company} strategy` / recent news | unavailable | Search "Quillmoor Diagnostics strategy news Avonmouth" was refused. It would have grounded B4, which is generic |
| 4. `{interviewer name} {company}` | unavailable | Search "Hannah Lowther Talent Partner Quillmoor Diagnostics" was refused. It would have supplied an interviewer read; that section is absent |
| 5. representative `{role title}` JD | skipped | The advert you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Search permission granted, for the four refused searches → B4 becomes grounded on Quillmoor's own pages, and the interviewer read can be built from Hannah's public professional footprint; a deeper research pass, up to 6 more searches and 2 more fetches and several more minutes, is available if you want it
- Your CV as you submitted it → check which of F2, F4, F6 and F7 it already carries lines for, since Hannah has read it
- Your answers to the slots in F2, F4, F6, F7 and F8 → each becomes a story-mapped row in place of an answer slot
- Your notice period in your own words → A3 and F11 become grounded
- The schedule of any later rounds → per-round mini-packs with their own persona weights
- A `tuesday-dossier.md`, if you have one from earlier work → verified evidence and an objection ranked from an evidence map
