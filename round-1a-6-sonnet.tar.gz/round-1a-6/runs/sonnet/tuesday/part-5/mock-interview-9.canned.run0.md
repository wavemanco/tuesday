I've run five searches. Next I'm fetching the district's values page and its hiring-process page to confirm the exact wording.
Your prep pack is saved as `halvering-elementary_fourth-grade-teacher_interview_pack.md`. I built it for one 45-minute panel with Principal Vantongeren and two fourth-grade teachers. I used a representative fourth-grade listing, because the invite isn't the posting.

- **License:** your résumé shows the Illinois license requirement as met.
- **Biggest prep item:** the fourth-grade gap. B2 in the pack is the question I'd rehearse most.
- **Research:** the district's own pages describe this exact panel format, and its board adopted a new literacy plan in August 2026.
- **Your SSN:** I didn't use it or put it in the pack. I left your license number out too, since neither is needed.

Say the word and I'll run a live drill as the Skeptic on B2.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the posting, along with any note HR sent about what to prepare? That would turn F7 to F9 from inferred to grounded.

Do you want a deeper research pass? It would add up to 6 more searches and 2 more fetches, take several more minutes, and cover the district's strategy, the principal's talks and writing, loop reports for this role, and recent org context.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: halvering-elementary_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**Employer:** Orrinsford Community School District
**Round:** one 45-minute panel on Thursday
**Panel:** Principal Dolores Vantongeren and two members of the fourth-grade team (names not given)
**Relationship:** hiring principal plus two future teammates

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say only what you actually did, in your own words.

| Type | What it scores |
|---|---|
| VAL | Whether your past behavior fits the district's published beliefs |
| EXP | Whether the claims in your material survive a close read, and what was actually you |
| JD | The role's stated requirements, gaps included |
| CO | Whether you know the district's current direction |
| CASE | Structure and reasoning on a live problem |

Provenance labels: `[grounded]` rests on your own words or a page read for this pack, `[inferred]` is derived from a representative source or a thin quote, `[generic]` is a pattern with no claim about you or the district.

An answer slot is an instruction for the interview. It names the likely probe and gives two honest branches. It asks nothing of you now. Question IDs use the letters A to E, G and H, because F1 to F9 are the fit-snapshot rows.

The loop is established by the district's own hiring page, which describes one 45-minute building panel of the principal and two grade-level teachers. That matches your invite, so the persona weights below rest on the district's documented process, not on a fallback pattern.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — your invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | The material shows this requirement met: license kind, issuer, endorsement and expiry are all in the quote, and the expiry falls after the panel. It is a CV line with nothing inspected behind it, so expect a confirmation. Lead with it in the quote's own terms. Your license number is not needed and stays out of this pack; checking your status against the issuer's own record is yours to do |
| F2 | "Fourth Grade Teacher position" — your invite | "Six years teaching third grade at a public elementary school in Joliet." — your CV; "I've never taught fourth grade" — your message | medium | [grounded] | transferability | Adjacent work, and you have stated the gap. Words: "I've never taught fourth grade." Then the adjacent evidence at its own scope: "Six years teaching third grade at a public elementary school in Joliet." Then how you would learn fourth grade here, said as a plan and never as a past |
| F3 | "reading instruction" — district hiring page, which says panels ask about it | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | transferability | Adjacent work: a curriculum move and an after-school club. Neither sentence says how reading is taught day to day in your room, and the words stay at the quotes' scope. Answer slot: the hiring page names reading instruction, so a probe on your daily reading teaching is likely. If you can say how you teach reading in your own room, say it in your own words; if the two sentences above are all that bears on it, say so plainly and stay with the move and the club |
| F4 | "classroom routines" — district hiring page, which says panels ask about it | "Six years teaching third grade at a public elementary school in Joliet." — your CV | low | [inferred] | discovery | The quote shows the grade and the school and nothing about routines. Answer slot: a probe on how a day runs in your room is likely. If you can describe it in your own words, do; if you had no routine of your own, or it was set elsewhere, say so plainly and say how you would set routines in a new room |
| F5 | "how you work with families" — district hiring page, which says panels ask about it | "I write a weekly email to families." — your CV | medium | [grounded] | presentation | The quote already reaches the requirement in other terms. Say it as written: the email is weekly and goes to families. Nothing is added to it here |
| F6 | "each teacher speaks with every family each term" — district mission page | "I write a weekly email to families." — your CV | medium | [grounded] | transferability | An email is a different kind of work from a conversation, so the words stay at the email. Answer slot: the district's own page makes a probe on direct conversations likely. If you speak with families directly, say how and how often, in your own words; if you do not, say so plainly and stay with the weekly email |
| F7 | "plan and teach reading, writing, math, science and social studies" — a representative fourth-grade listing, not this posting | "Six years teaching third grade at a public elementary school in Joliet." — your CV | low | [inferred] | discovery | The quote names the grade and the school, not the subjects. Answer slot: a probe on which subjects you taught is likely. Say which, in your own words; if it was only some of them, or none of these, say so plainly and stay with third grade as written |
| F8 | "differentiate instruction using assessment data" — a representative fourth-grade listing, not this posting | none given | none | [inferred] | discovery | Nothing in your material speaks to this. Answer slot: if you have used assessment information to decide what a student got next, say what and how in your own words; if you have not, or it was decided elsewhere, say so plainly and say how you would start |
| F9 | "work with the grade-level team" — a representative fourth-grade listing, not this posting | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your message | medium | [inferred] | presentation | The first quote already reaches the requirement in other terms: a grade-level move, in 2024, that you led. Say it as written. The limit, as the pack's own observation: the sentence says the move, not the team, and your second statement stands beside it |

## Persona table

Weights are a shown judgment. Start from the relationship priors for a panel: the principal reads as a hiring manager (Case/Strategist and Skeptic), and the two teachers read as peers (Peer Evaluator and Data-Driven Prober). The district's hiring page then adjusts them: it names reading instruction, classroom routines and family work as panel topics.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Peer Evaluator | Two fourth-grade teammates asking what you would be like to work beside | high: two of the three panelists are fourth-grade team members, and F9 is the row that speaks to teamwork | Reciprocity: say what you bring them, not only what you need. Propose principles for working together rather than pretending to know their seams |
| B. Skeptic | Quiet, persistent probing of the fourth-grade gap | high: the principal row points here, and F2 and F9 hold two gaps you have stated yourself | Rehearse the most predictable objection until it is boring. Bridge only from what your quotes say, and say the limit plainly |
| C. Case/Strategist | Live classroom problems and the district's reading plan | medium: the hiring page names classroom routines and reading instruction, which can arrive as live problems | Clarify first, then objective, approach, how you would know, risks. Think aloud |
| D. Data-Driven Prober | A close read of your few CV lines | medium: the peer prior, and your material is a handful of specific lines that can each be read closely | Know the scope of each sentence and keep to it. Say plainly when you do not know something |
| E. Values/Behavioral | Questions built on the district's three beliefs | medium: the hiring page names family work and the mission page publishes three beliefs, though no dedicated values round is named | Map a story to a belief only where your own sentence carries one. Where none does, choose from your own experience or say so plainly |
| G. Conversational | The opening walk-through and casual reading chat | low: it is one 45-minute panel, so this style mostly shows up as the opener | Prepare a 90-second arc from stated facts. Treat casual questions as scored |
| H. Pressure | Sixty-second challenges and motive probes | low: nothing read for this pack suggests a stress style | Pause, restate the question, hold your position through two follow-ups, concede specifically |

## Reading the interviewer

Public professional footprint only. The two teachers are unnamed, so this covers the principal.

| Fact | Source | Provenance | What it means for you |
|---|---|---|---|
| Principal of Halvering Elementary School since 2022, after nine years as a reading specialist | Illinois principals forum speaker page, search result | [grounded] | Expect depth on reading instruction: C2, D1, G2 and E3 |
| Her 2025 forum talk, "Small Groups, Big Readers", covered weekly reading conferences in grades 3 to 5 | Same page | [grounded] | Reading in grades 3 to 5 is her stated subject. Do not claim a method of hers as yours; ask about it instead (reverse question 1) |
| Two panelists are members of the fourth-grade team | Your invite | [grounded] | Peer persona for both; their names would sharpen this section |

Mirror opportunity: her talk's subject is reading in grades 3 to 5, and your side is the sentence "I've run the after-school reading club for the last two years" (F3). Use it to ask about her work (reverse question 1), not to claim a shared method.

## Question banks

### A. Peer Evaluator (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Tell us how you work with the other teachers in your grade level." | JD | [inferred] "I led our grade level's move to a new reading curriculum in 2024" | Story-mapped on F9: the move, your grade level, and 2024 are the beats the quote states; tell them in your own words. Answer slot: a typical listing for this role names working with the grade-level team, so a probe on how your grade level worked together on the move is likely. If you worked out with colleagues how the move would happen, say how, in your own words; if there was no such arrangement, or it was not yours, say so plainly and stay with the move you led | F9 is the only evidence for the team-work requirement, and the peers on the panel will go to it first. JD because it scores a stated requirement of the role, even though the listing is a representative one |
| A2 | "Tell us about a time you and a colleague saw a teaching decision differently." | JD | [generic] | Pick a time you disagreed with a colleague about a teaching decision; it needs what each of you wanted, what you said, and a working relationship that was intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Show spine and tact together | Disagreement with equals is the peer persona's standard probe, and nothing in your material carries a story for it, so this is a selection scaffold. It scores the team-work requirement behind F9 |
| A3 | "When work spans a whole grade level, how do you handle credit?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Use we for context and I for your own part, as your sentence does. The beats the quote states are the move, your grade level and 2024. Answer slot: a probe on who else contributed to the move is likely. If others did, say how and what was yours, in your own words; if you cannot say who did what, or it was yours alone, say so plainly and stay with the sentence | Credit-sharing is the peer persona's attribution check, and F9 is the sentence it will land on. EXP because it tests what was actually yours |
| A4 | "What could you offer our team in your first semester?" | JD | [grounded] "I've run the after-school reading club for the last two years"; "I write a weekly email to families." | The reciprocity answer. Offer only what the two quotes carry: you run an after-school reading club and you write to families weekly. Answer slot: if either could help colleagues here, say how in your own words; if neither could, say so plainly and ask what the team would find useful | Peers price what a hire adds to their own work, and F3 and F5 are the only things your material offers them. JD because it scores how you fit the team the role works with |
| A5 | "How would you keep teammates informed when you want to try something new in your room?" | CASE | [generic] | Structure it as a plan: who you would tell first, what you would share, and what you would do if a teammate objected. The question needs no claim about your past, so the guidance makes none | A collaboration scenario in the peer persona's register. `[generic]` because it is a pattern for the problem, not a fact about this team. CASE because it asks for reasoning, not a story |

### B. Skeptic (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet." | Name the part plainly, in your own words: "I've never taught fourth grade." Then what your material does carry, at its scope: "Six years teaching third grade at a public elementary school in Joliet." Then how you would learn the part, said as a plan and never as a past | This is the Skeptic's standard stem, and F2 is the gap it points at. JD because it scores the role's requirement, gaps included |
| B2 | "You've taught third grade for six years and not fourth. Why are you ready for fourth?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet."; "I've never taught fourth grade" | **The highest-ROI rehearsal in this pack.** This question will arrive in some form, and a calm, rehearsed answer changes the interview. Concede first, in your words: "I've never taught fourth grade." Then the adjacent evidence at its own scope: "Six years teaching third grade at a public elementary school in Joliet." Then your own first-month plan for learning fourth grade here, said as a plan. The limit, named before anyone asks: your material says third grade, not fourth. Follow-up 1, what changes between third and fourth. Answer slot: if you know from your own work what changes, say it in your own words; if you do not, say so plainly and say what you would ask the team first. Follow-up 2, what you would do in your first week, as a plan. Follow-up 3, what you would do if you found yourself behind. Hold the plan, and concede plainly where you would need help; do not claim a readiness the quotes do not carry | F2 is the largest gap against the role's title, so some form of this question is close to certain. JD because it scores the stated requirement; the deepest follow-up ladder sits here because the objection aims exactly where the material is thin |
| B3 | "You led your grade level's move to a new reading curriculum. What did leading it involve?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Story-mapped on F9: the move, your grade level and 2024 are the beats the quote states. Answer slot: if any part of the move was yours to decide, say which part and how you decided, in your own words; if the decisions were made elsewhere, or there was no such decision, say so plainly and describe what you did in the move. Hold at led and our grade level's; do not widen the sentence | F9 is where a skeptic tests whether leading meant deciding, and it is the one leadership line you have. EXP because it tests attribution |
| B4 | "Have you led anything for your grade level or your school?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead" | Answer with what the quote carries: "I led our grade level's move to a new reading curriculum in 2024." If asked directly whether you have been a team lead, the plain answer is yours: "I've never been a team lead." Then stop; do not widen the move into a lead role. Say how you would work with a team as a member, as a plan, in your own words | F9 holds both a leadership line and a stated limit, and a skeptic reads the two together. JD because the role works with a grade-level team |
| B5 | "Why Halvering, and why now?" | CO | [grounded] Mission page beliefs: Every Child a Reader, Families Are Partners, Teach for Tomorrow, Not for the Test | Give your own reasons, in your own words; your material states none and this pack supplies none. If a reason connects to one of the district's three published beliefs, name that belief only if it is genuinely your reason; if none is, say so plainly and give the reason you have | Motivation consistency is what the Skeptic scores. CO because the strongest answers connect to what the district publishes; the belief names come from its own mission page |

### C. Case/Strategist (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "It is the second week of school and mornings are chaotic: students arrive in waves and the first twenty minutes are lost. Walk us through what you would do." | CASE | [generic] | Clarify first: what exactly is happening, with whom and when. Then the objective, your approach, how you would know it is working, and the risk you would watch. Think aloud and challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | The district's hiring page names classroom routines (F4), and a routine problem set in a room is how a panel can test it. CASE because it asks about nothing in your past |
| C2 | "Sketch how you would run reading time in a fourth-grade class during your first month. What do you need to know first?" | CASE | [generic] | Clarify first: what curriculum is in use, what the team already does, what the children can already do. Then the objective, grouping, your approach, how you would know it works, and the risks. Think aloud. The question needs no claim about your past, so the guidance makes none | The hiring page names reading instruction and the principal's public work is reading (F3). A live sketch tests structure over a right answer |
| C3 | "The board has adopted a literacy plan with a new grades 3–5 reading curriculum from fall 2027 and a family reading night each term. Where does a fourth-grade teacher fit?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Use the plan's own words (see Sources) and think aloud: what you would ask the team first about the new curriculum and the family reading night, and what you would watch for in a move to a new curriculum. The only past you may bring is your sentence; its beats are the move, your grade level and 2024, and it does not say the curriculum was similar or what the move involved. Answer slot: if the move taught you something that applies to this plan, say what, in your own words; if it did not, say so plainly and stay with how you would learn the curriculum | The board's August 2026 plan is the district's current strategy, and it is public to every candidate, so this separates those who read it. F9 is your one link to a curriculum move |

### D. Data-Driven Prober (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Your reading club has run for two years. What does a session look like?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Story-mapped on F3: the club, after school, the last two years are the beats the quote states. Answer slot: the hiring page names reading instruction, so a probe on what happens in the club is likely. If the club follows a pattern, describe it in your own words; if it has no set pattern, or it is run differently, say so plainly and say what you do | F3 is one of your two reading lines and the prober will read it closely. EXP because it tests whether the line survives a follow-up |
| D2 | "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it. How would you use assessment data to decide what a student gets next?" | JD | [inferred] none given | Structure it in your own words: what information you would look at, what decision it would inform, and how you would check the decision worked. A use of data that serves a teaching decision fits the district's belief. Answer slot: if you have used assessment information to decide what a student got next, say what and how in your own words; if you have not, or it was decided elsewhere, say so plainly and say how you would start | F8 has no evidence, so this rehearses the honest answer before it is probed. The district's belief and a typical listing both raise the topic; JD because it scores a stated requirement |
| D3 | "Which classrooms did that move to a new reading curriculum cover?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Your sentence says our grade level's move; say that, at that scope. Answer slot: if the move covered your whole grade level as the sentence says, say so; if the scope was different, say what it was, plainly. Do not widen the sentence | Scope is where a close reader checks a leadership line (F9). EXP because it is a scope check on a quoted claim |

### E. Values/Behavioral (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Families Are Partners is one of the district's three beliefs. Tell us how you work with families." | VAL | [grounded] "I write a weekly email to families." | Story-mapped on F5: weekly, an email, to families are the beats the quote states. Answer slot: the district's own page makes a probe on direct conversations likely. If you speak with families directly, say how and how often, in your own words; if you do not, say so plainly and stay with the weekly email | The hiring page names family work, and F5 and F6 are your only evidence for it. VAL because the question is built on a published belief |
| E2 | "Tell us about a time you worked with a family to support their child as a reader." | VAL | [grounded] "I write a weekly email to families." | Pick a time with a clear situation (no names), what you and the family each did, and where it ended; no sentence of yours carries one, so choose from your own experience. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I write a weekly email to families.", or how you would handle it | Two beliefs, Families Are Partners and Every Child a Reader, meet here. Your material has the email only (F5), so this is a selection scaffold |
| E3 | "Every Child a Reader: no student leaves third grade without a reading plan. What does a reading plan look like in your room?" | VAL | [grounded] "Six years teaching third grade at a public elementary school in Joliet." | Your quote shows the grade, not any plan. Answer slot: the district's belief names a reading plan for every third-grade student, so a probe is likely. If you write or use reading plans, describe what yours hold, in your own words; if your school did not use them, or it was not yours, say so plainly and say how you would handle a child who is not yet reading well | The belief is written about third grade, which is the grade F2 shows you teaching, so expect it to be put to you. VAL because it rests on a published belief |

### G. Conversational (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk us through your journey." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet."; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years" | A 90-second arc built only from what you have stated, in order: the six years in third grade, then the 2024 move you led, then the reading club. What first brought you to teaching and why Halvering are your own words; this pack supplies neither. End on fourth grade here as what you want next, in your own reasons | A friendly opener is still scored for economy. EXP because it sets the facts the rest of the panel will probe (F2, F3, F9) |
| G2 | "What is your reading club reading these days?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | A fact only you have; say real titles, since the pack names none. The beats the quote states are the club, after school and the last two years. Answer slot: if the club has a current title, say it and how it came to be chosen, in your own words; if there is no set title, or the club works differently, say so plainly and say what the children do. Treat it as scored | The conversational persona asks hot-topic questions casually, and the principal's public subject is reading. F3 is the line it draws on |

### H. Pressure (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Sixty seconds: why you over a teacher who has already taught fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet."; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I've never taught fourth grade" | Pause and restate the question. Hold only what the quotes carry, in order: the six years in third grade, the move you led, the reading club. Concede in the same breath, specifically: "I've never taught fourth grade." Hold through two follow-ups by returning to those sentences, never by adding to them. The pack supplies no claim that you are the stronger candidate | The pressure persona tests composure on F2's gap. JD because it scores the stated requirement |
| H2 | "That curriculum move: how much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Hold the sentence at its scope. Answer slot: if some parts were decided or done by others, say which, plainly, and what was yours; if the move was yours as the sentence says, say that and nothing more. Hold through two follow-ups; concede specifically and never fold on the core claim | The attribution probe is the pressure persona's standard stem, and F9 is the sentence it lands on |

### Requirement coverage

| Requirement | Questions |
|---|---|
| Illinois PEL with an elementary endorsement (F1) | none, and why: a term your material shows met, so there is nothing to rehearse beyond stating it as written |
| Fourth Grade Teacher position (F2) | B1, B2, B4, H1 |
| Reading instruction (F3) | C2, C3, D1, E3, G2 |
| Classroom routines (F4) | C1 |
| How you work with families (F5) | E1, E2 |
| Each teacher speaks with every family each term (F6) | E1 |
| Plan and teach reading, writing, math, science and social studies (F7) | none, and why: it comes from a representative listing, this role's subject load is unknown, and the panel topics the district names are reading, routines and families; the posting would let the pack add one |
| Differentiate instruction using assessment data (F8) | D2 |
| Work with the grade-level team (F9) | A1, A2, A3, A4, A5, B4 |
| Belief: Every Child a Reader | B5, E3 |
| Belief: Families Are Partners | B5, E1, E2 |
| Belief: Teach for Tomorrow, Not for the Test | B5, D2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "You spent nine years as a reading specialist before becoming principal. How does that shape what you look for in a fourth-grade reading block?" | It ties to the principal's own public path and invites her to talk about the subject she has spoken on |
| 2 | "What does the fourth-grade team's part look like between now and the new grades 3–5 reading curriculum in fall 2027?" | It shows you read the board's plan and asks what the work actually is |
| 3 | "What could a new fourth-grade teacher do in their first month that would genuinely help your team?" | The reciprocity question for the two teammates on the panel |
| 4 | "The district's belief is that each teacher speaks with every family each term. How does your team do that in practice, and what helps?" | It shows you read the belief and asks for the working detail from the people who live it |
| 5 | "What does a strong first semester look like for someone who is new to fourth grade here?" | It answers the fourth-grade gap (F2) from their side and signals you plan to ramp up |
| 6 | "How does the family reading night work at Halvering, and where would a fourth-grade teacher help?" | The board's plan includes a family reading night each term, so it shows you read it and connects to your reading club (F3) |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade, or has fourth-grade experience | Negative the candidate stated, F2 | The plain acknowledgment F2 gives: "I've never taught fourth grade." F2's third-grade quote at its own scope. No slot |
| Has been a team lead, or led the grade-level team | Negative the candidate stated, F9 | The plain acknowledgment F9 gives: "I've never been a team lead." F9's quote at its own scope; the limit is the pack's observation that the sentence says the move, not the team |
| Chose, designed or ran the reading curriculum, or led a school-wide adoption | Inflated form of F3 and F9 | F9's quote at its own scope. The limit is the pack's observation that the material says the move, not who chose or designed the curriculum. B3 and D3 stay inside the move |
| Speaks with every family each term | Inflated form of F5 and F6 | F5's quote at its own scope. The limit is the pack's observation that the material says a weekly email, not conversations. E1 stays inside the email |
| Ran a reading intervention or a school reading programme | Inflated form of F3 | F3's club quote at its own scope: an after-school reading club, run for the last two years. D1 stays inside the club |

## Sources

Provided documents: your message, which holds the invite and your résumé text.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

Searches and fetches sent:

- Search: "Orrinsford Community School District mission values" returned https://orrinsfordschools.example/about/mission-and-beliefs
- Search: "Orrinsford Community School District teacher hiring interview process" returned https://orrinsfordschools.example/careers/how-we-hire-teachers
- Search: "Orrinsford Community School District strategic plan news" returned https://orrinsfordschools.example/news/board-adopts-literacy-plan
- Search: "Dolores Vantongeren principal Halvering Elementary School" returned https://ilprincipalsforum.example/speakers/dolores-vantongeren
- Search: "fourth grade teacher job posting Illinois elementary school responsibilities qualifications" returned https://k12jobsboard.example/listings/fourth-grade-teacher
- Fetch: https://orrinsfordschools.example/about/mission-and-beliefs, which confirmed the three beliefs and their wording
- Fetch: https://orrinsfordschools.example/careers/how-we-hire-teachers, which confirmed the one-panel loop and its topics

The strategy, interviewer and representative-listing results were read from search-result snippets only. The listing's snippet was cut off partway through its qualifications line, so nothing from that line is used.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | yes | The three beliefs by name in B5, D2, E1, E2 and E3. No values cheat sheet: the district's hiring page names no values-style round, so none is detected |
| 2. `{company} interview process {role family}` | yes | Loop structure: one 45-minute panel of the principal and two grade-level teachers, and its three topics. It set the persona weights and F3 to F6 |
| 3. `{company} strategy` / recent news | yes | The board's August 2026 literacy plan, which fed C3 and reverse questions 2 and 6 |
| 4. `{interviewer name} {company}` | yes | The principal's role and public talk, which fed the interviewer read and reverse question 1. The two teachers are unnamed, so there was nothing to search for them |
| 5. representative `{role title}` JD | yes | A representative listing, not this posting, which supplied F7 to F9 as `[inferred]` requirements |

## Upgrade menu

- The posting text → F7 to F9 move from `[inferred]` to `[grounded]`, the coverage table checks against the real requirements, and a JD-tagged question gets added for F7
- Any note HR sent about what the panel will cover or what to prepare → coverage of any pre-declared deliverable, and persona weights refined
- The names of the two fourth-grade teachers → a persona per panelist and a tailored reverse question for each
- Your own words on the answer-slot rows (F3, F4, F6, F7, F8) → the discovery rows become quoted evidence, and A1, B3, D1, D2, E1, E3 and G2 get mapped stories in place of slots
- A sample weekly family email with names removed → F5 moves from medium to high confidence
- The curriculum adoption memo or the reading club's schedule or flyer → F3 and F9 move from medium to high confidence
- Your license status page from the issuer, with the number hidden, if you choose to share it → F1 moves from medium to high confidence
- A `tuesday-dossier.md` from an earlier role evaluation, if you have one → verified evidence for the thinnest rows and a ready list of prohibited claims
