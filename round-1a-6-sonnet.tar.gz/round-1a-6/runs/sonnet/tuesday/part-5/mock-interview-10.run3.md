The searches were refused, so I'm building the pack from what you've told me and labelling the company-specific parts as generic. I'm saving it now.
Before the prep, one thing in the invite: it says the hiring process is "fully remote and is carried out entirely on Telegram", that "your interview will be a text chat here with our support team lead", and that "your offer and onboarding will be completed in this chat as well". A hiring process run wholly by chat is a known scam pattern. A chat alone doesn't show who you're dealing with, and the message may not come from the company it names. Until you've checked, don't pay anything, deposit a cheque, or send documents or bank details. Check with Lumenvale Software using a phone number or address from its own website or careers page, not through this chat or anything the sender gives you. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as `/var/tmp/tuesday-measure/1a6/runs/sonnet/tuesday/part-5/rooms/case-10-denied-9615b36c/lumenvale-software_customer-support-specialist_interview_pack.md`. I assumed the support team lead interviews like a hiring manager. My three web searches on the company's values, process and strategy were refused, so the company-specific parts are marked generic.

The pack has 18 questions, including a mock of the Skeptic's "you've never worked for a software company" probe (A1). It also has reverse questions and a requirement-coverage table.

Say the word and I'll play the Skeptic on A1, the question the pack names as your highest-ROI prep. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Is the support team lead likely to be your future manager or a peer, and has the talent team told you anything else about the format, such as a task or a time limit? Can you paste the full text of the job ad, or say skip and I'll carry on with the four requirements you gave?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: lumenvale-software_customer-support-specialist_interview_pack.md -----
# Interview pack: Customer Support Specialist, Lumenvale Software

- Role: Customer Support Specialist (remote), Lumenvale Software
- Interviewer: the support team lead, name not given
- Format: a text chat on Telegram, one session, from your message
- Relationship assumed: hiring-manager style, until you say otherwise

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and since this is a text chat, send it as a few short messages rather than one block.

| Type | Meaning |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your own experience holds up when probed |
| JD | Whether you can do the job the ad describes, gaps included |
| CO | What you know about the company and its direction |
| CASE | A live problem from the role, answered on the spot |

An answer slot is an instruction for the interview, not a question for you now. It names what an interviewer is likely to probe and gives two honest branches: say it if it is true, or say plainly that it is not, and return to what you did say.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — your message, relaying the ad | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it, so expect a probe. Lead with the quote's own terms: three years, customer service advisor, an energy supplier, calls and emails. Keep your own job title and do not rename it |
| F2 | "experience with Zendesk or a similar ticketing tool" — your message, relaying the ad | "I use Freshdesk every day" — your message | medium | [inferred] | presentation | Derivation: this pack reads Freshdesk as the ad's "similar ticketing tool", and whether it counts is the interviewer's call. Name the tool: "I use Freshdesk every day." Answer slot: the ad names Zendesk, so expect a probe. If you have used Zendesk, say where and for how long, in your own words; if not, say so plainly and stay with Freshdesk |
| F3 | "clear written communication" — your message, relaying the ad | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | Derivation: emails touch this requirement, but volume does not show clarity, and the bridge should not be stretched. This chat is itself a sample of your writing. Answer slot: if anything shows your written replies landed clearly, say what, in your own words; if nothing comes to mind, say so plainly and stay with the volume you described |
| F4 | "confidence handling escalations" — your message, relaying the ad | none given | none | [grounded] | discovery | Your material does not show escalations either way. Answer slot: the ad's escalations line makes a probe likely. If you handled escalated contacts, say what kind and what part was yours, in your own words; if you did not, or it was not yours, say so plainly, then say how you would handle one |
| F5 | Working inside a software company, a role-family expectation not in the ad as you relayed it | "I've never worked for a software company" — your message | none | [generic] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked for a software company." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F6 | Helping teammates learn the work, a role-family expectation not in the ad as you relayed it | "I trained four new starters on our refunds process last year" — your message | medium | [generic] | none | Not a line the ad as relayed asks for, so it is a strength to hold at its scope. Use the quote's terms: four new starters, the refunds process, last year. Expect a probe on what you did; answer in your own words and stop where the quote stops |

## Persona table

Weights rest on a hiring-manager prior for a team lead, with no interviewer profile. Your own words establish one text chat with the support team lead and no other rounds, so no archetype fallback is used.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet probing of the software gap, day-one weakness, and why this move | Highest: the hiring-manager prior includes the Skeptic, and F5 is a gap you stated | Rehearse A1 until it is boring: hold F5 in your own words, state the plan as a plan, and return to the same sentence under follow-up |
| B. Case / Strategist | Live support scenarios: an angry customer, a three-problem email, an unfamiliar feature | High: the hiring-manager prior includes it, and F3 and F4 are the rows a scenario can test live | Clarify first, say what you can fix and what you would hand on, write the reply as you would send it, say what you would record |
| C. Data-Driven Prober | Reads your lines closely and asks how the figures were counted | Medium: your message carries three figures, and F1 and F6 hold them | Know what you can and cannot say about how each figure was counted, and say plainly when you do not know |
| D. Conversational | A friendly opening such as the journey or why you applied | Medium: a team lead often opens loosely, and casual questions are still scored | Pre-build a short arc from your own sentences and treat casual questions as scored |
| E. Pressure | Time-boxed challenges to your position or your share of a result | Lower: no signal of a stress style, but F5 and the figures are natural targets | Pause, restate, hold your position through two follow-ups, then concede one specific thing |

## Question banks

Highest-ROI prep: A1, the software-company question. It will be asked in some form, and a calm, rehearsed answer changes the chat.

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "I don't see a software company in your background. How would you handle that in this role?" | JD | [grounded] "I've never worked for a software company"; "I use Freshdesk every day"; "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Hold the fact in your own words: "I've never worked for a software company." Then say what you would do about it, as a plan and never as a past: what you would learn first and who you would ask. You may name the adjacent material at its own scope, in the quotes' words. Do not say what it proves; let the interviewer draw that. Rehearse the follow-ups A2, A3 and B4 after it, and hold by returning to the same sentence | F5 is the largest stated gap and the likeliest probe; JD because it scores whether you can do the listed job, gap included |
| A2 | "Which part of this ad would you be weakest at on day one?" | JD | [generic] | Answer slot: name the requirement you would be least ready for on day one, in your own words, then what you would do about it as a plan. This pack's own observation is that F4 and F3 are the rows your material shows least on; the words stay yours | The stem is a standard Skeptic probe aimed at F3 and F4; JD because it scores the ad's list |
| A3 | "What draws you to support work at a software company?" | EXP | [generic] | Give your actual reason, in your own words, in one or two sentences. Nothing here supplies one. Claim knowledge of the company's product only if you have read about it | Motivation consistency sits next to F5; EXP because it tests whether your story holds together |
| A4 | "The ad asks for Zendesk or a similar ticketing tool. Which tool have you used, and how do you use it day to day?" | JD | [grounded] "I use Freshdesk every day" | Name the tool and the frequency in the quote's words. Describe what you do in it in your own words, without a feature list the quote does not carry. Answer slot: if you have used Zendesk, say where; if not, say so plainly and stay with Freshdesk | F2 is the ad's one named tool requirement and the likely check on whether Freshdesk counts |
| A5 | "The ad asks for 2+ years in customer support. What did your three years involve?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Story-mapped on F1: the beats the sentence states are three years, customer service advisor, an energy supplier, and calls and emails at around 60 a day. Tell them in your own words and add no beat the sentence does not state | F1 is the evidence for the experience requirement; JD because it scores the stated years |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer writes in for the third time about the same problem and says they will cancel and post about it. Write your next message." | CASE | [generic] | Structure it: acknowledge the third contact first, say what you have checked in the history, say what you can fix yourself and what you would hand on and to whom, tell the customer what happens next, and say what you would record. Write it as you would send it; this is a text chat | The live form of the escalations line behind F4; it asks about no past and presupposes nothing about you |
| B2 | "Tell me about a time a customer contact needed more than a standard reply." | JD | [generic] | Pick a time that had a named stake, a decision that was yours, and a clear next step for the customer. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Open prompt from the ad's escalations line (F4); your material does not carry a story for it, so this is a scaffold |
| B3 | "A customer emails one long angry message with three different problems in it. How do you reply?" | CASE | [generic] | Structure it: open by acknowledging, take the three problems one at a time in short paragraphs, say what you will do and what you need from them, and end with the next step. Send your answer as short messages | The written-communication line behind F3, tested live rather than claimed |
| B4 | "A customer says a feature you have never seen is broken. What do you do in the first ten minutes?" | CASE | [generic] | Clarify first: what they see, what they expected, and the steps that lead there. Check the ticket history and whatever internal notes the team has. Tell the customer what you are doing while you look, and say what you would pass on if it stays unresolved. These are things you would do, not things you have done | The live form of F5: the software gap, answered as a method |
| B5 | "A customer insists on a refund that policy does not allow. What do you write?" | CASE | [generic] | Structure it: acknowledge, say plainly what cannot be done and why as the policy states it, say what can be done, and name the next step or route. The pack does not know this company's policy, so ask the lead how refunds work if the question allows | Combines F3 and F4 in one reply; CASE because it is a live problem set in the role |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You say around 60 calls and emails a day. How was that counted, and what would move it?" | EXP | [grounded] "answering around 60 calls and emails a day" | Defend-the-number slots, each in your own words: how the figure was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. "Around" is your word, so keep it approximate. If you know the split between calls and emails, say it; if you do not know how it was counted, say so plainly | F1 holds the figure, and a headline number is where a prober starts |
| C2 | "Walk me through how you trained the four new starters." | EXP | [grounded] "I trained four new starters on our refunds process last year" | Story-mapped on F6: the beats the sentence states are four new starters, the refunds process, and last year. Tell them in your own words and stop where the sentence stops. Answer slot: which part of the training was yours, in your own words; if any of it was not, say so plainly | F6 is the one line about helping others learn, and "four" is a figure to be probed |
| C3 | "Was that one role for the whole three years?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Answer slot: if the role or its duties changed, say how, in your own words; if not, say so plainly and describe the role as the sentence does | F1's three years invite a check that the years are one continuous role |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day"; "I use Freshdesk every day"; "I trained four new starters on our refunds process last year"; "I've never worked for a software company" | A short arc in your own words, using only these sentences: the three years and the daily contacts, Freshdesk every day, the four new starters on refunds. Then say why this role, in your own words. Say the software gap plainly, once, before you are asked | A casual opener is still scored; F1, F2, F5 and F6 are the arc's material |
| D2 | "What made you apply to us?" | CO | [generic] | Give your actual reason. Mention a fact about the company only if you have read it on the company's own site; nothing in this pack supplies one. If you have read nothing yet, read the company's own pages before the chat | Company research could not run, so this question is generic and the pack adds no company claim |
| D3 | "What do you enjoy most about support work?" | EXP | [generic] | Answer in your own words in two or three short messages. Nothing in this pack supplies the answer | A rapport question that sits near the motivation probe in A3 |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has worked in software support?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day"; "I use Freshdesk every day"; "I've never worked for a software company" | Hold: say what you bring in those quotes' words. Do not claim to be better than anyone. Through two follow-ups, return to the same sentences. Concede one specific thing: "I've never worked for a software company." Then give the plan from A1 | F5 is the likeliest pressure target; JD because it scores fit against the listed job |
| E2 | "That volume: how much of it was actually you?" | EXP | [grounded] "answering around 60 calls and emails a day" | Hold the sentence at its own scope. Answer slot: if the 60 was your own count, say so; if it was a team figure or you do not know how it was counted, say so plainly. Never defend a share the sentence does not state | F1's figure again, rehearsed under the pressure style |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| "2+ years in customer support" | A5, C3, D1 |
| "experience with Zendesk or a similar ticketing tool" | A4 |
| "clear written communication" | B3, B1, B5 |
| "confidence handling escalations" | B1, B2, B5 |
| Working inside a software company (F5, role-family) | A1, B4, E1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a typical first week look like for someone new to your product?" | It shows you plan to learn the product, which answers the F5 gap without claiming anything |
| R2 | "Which kinds of tickets come up to you as lead, and what makes one need you?" | It tells you where the team draws the escalation line, which F4 leaves open, and shows you think about hand-offs |
| R3 | "What does a good written reply look like on this team?" | It gives you the standard behind F3 and shows you care about the writing |
| R4 | "Which ticketing tool does the team use, and how much of it is new to people joining from elsewhere?" | It tells you how far F2 stretches and how much of the tooling you would learn |
| R5 | "What helps people from a non-software background do well in their first three months?" | It invites the lead to talk about a gap you have already named, so the conversation moves to how you would close it |
| R6 | "Is there a further step after this chat, such as a call or a task, so I can prepare for it?" | It tells you what to prepare next |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Worked in software or software support | Negative you stated, F5 | The plain acknowledgment F5 gives: "I've never worked for a software company." Then a plan, said as a plan |
| Strong written communication, shown by volume | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material gives the volume of calls and emails, not how clear they were |
| Led or ran training for the team | Inflated form of F6 | F6's quote at its own scope: "I trained four new starters on our refunds process last year." The limit is the pack's observation: the sentence says the training, not a programme or a lead role |

## Sources

Provided: your message, including the invite text, the requirements as you relayed them from the ad, and your background. No document or link was supplied.

Searches sent, all refused: "Lumenvale Software company values", "Lumenvale Software interview process customer support", "Lumenvale Software strategy news". No fetches.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software company values` | unavailable | The search was refused. It would have supplied published values for a cheat sheet, which this pack leaves out; the CO question D2 stays generic |
| 2. `Lumenvale Software interview process customer support` | unavailable | The search was refused. It would have added documented loop structure; persona weights rest on your account of one chat plus the hiring-manager prior |
| 3. `Lumenvale Software strategy news` | unavailable | The search was refused. It would have grounded a strategy question; D2 is generic instead |
| 4. interviewer name and company | n/a | No name was given for the support team lead, so there was no query to form; the interviewer read is absent |
| 5. representative Customer Support Specialist JD | skipped | The four requirements you relayed fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full text of the ad → rows quoted from the ad itself, and any further requirement gets its own JD question
- Whether the support team lead would be your manager or a peer, and anything the talent team said about format → persona weights recomputed and the banks reweighted
- The team lead's name → an interviewer read and a reverse question tied to their path
- The company's own values and process pages pasted in, or search permission granted → grounded CO questions, and a values cheat sheet if a values round is documented
- An example you can describe of an escalated contact or a written reply that landed well → F3 and F4 move from answer slots to story-mapped answers
- A tuesday-dossier.md from earlier work → verified evidence and prohibited claims carried in
