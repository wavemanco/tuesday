I've read the playbook and I'm now running two quick public-web checks on the company's values and interview process before I write the prep pack.
Before the prep, one thing in the invite: it asks you to "transfer the €95 equipment registration fee to our supplier's account, IBAN ...", to "reply with a photo of your passport and your bank details before the interview", and says that after a cheque arrives "you deposit the cheque and send the balance on to the vendor". Payments, ID and bank details requested before any offer, and a cheque you deposit and then pass on, are a known scam pattern, and this job is very likely a scam. Please hold all three (paying, sending your passport or bank details, depositing the cheque) until you have checked the invite with the employer. Use contact details you find yourself on its own website or careers page, not the email address, replies or answers from whoever sent the invite. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite itself weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as `/var/tmp/tuesday-measure/1a6/runs/sonnet/tuesday/part-5/rooms/case-12-denied-b9be84a0/brennock-facilities_remote-administrative-assistant_interview_pack.md`. It covers the 30-minute video call with the office manager and has 19 practice questions, reverse questions and a fit table. I assumed the office manager would be your likely line manager, since the invite doesn't say. The web searches on the company were refused, so the pack rests only on what you gave me.

Say the word and I'll play the Skeptic on B2, the question about moving from chasing unpaid invoices to processing supplier invoices. It's the one the pack names as your most important prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Would the office manager be the person you'd report to, or a peer on the team? The answer reweights every bank.
Can you paste the full text of the ad? I've proceeded without it, but exact wording would upgrade several rows.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: brennock-facilities_remote-administrative-assistant_interview_pack.md -----
# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

Interviewer: the office manager (name not given; relationship to you not stated, so built as the person you would probably report to). Format, in the invite's words: a 30-minute video call.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

| Tag | Meaning |
|---|---|
| VAL | Whether past behaviour shows the company's published values. None in this pack: no published values were in hand |
| EXP | Whether what you say about your experience survives follow-up questions |
| JD | Whether you can do the duties the ad lists, gaps included |
| CO | Company and strategy knowledge. None in this pack: no company research was available |
| CASE | A live problem from the role, scored on structure and reasoning |

Highest-ROI prep: B2. Of the four duties in the ad, supplier invoices is the one your material reaches least directly, so expect it in some form and rehearse the honest answer until it is boring.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as you described it | "ran the appointment book for four physios" — your message | medium | [grounded] | presentation | Your sentence already reaches the requirement in other terms. Say it at its own scope: "I ran the appointment book for four physios." Your material does not show calendars beyond that book, so the words stay there |
| F2 | "booking travel" — the ad, as you described it | none given | none | [grounded] | discovery | Your material is silent on travel. Answer slot: if you have booked travel for anyone, at the clinic or elsewhere, say for whom and what you handled; if you have not, say so plainly, then say how you would go about it, stated as a plan |
| F3 | "preparing documents in Word and Excel" (the Word half) — the ad, as you described it | "I'm good with Word" — your message | medium | [grounded] | none | No gap, but a self-report with nothing inspected behind it, so expect a probe on what you have made in Word. Use the quote's own terms: you are good with Word |
| F4 | "preparing documents in Word and Excel" (the Excel half) — the ad, as you described it | "okay with Excel" — your message | low | [inferred] | discovery | Your sentence touches the requirement without showing what you have done in Excel. Answer slot: if you have used Excel for something at work, say what, in your own words; if you have not, say so plainly and say what you would practise first |
| F5 | "processing supplier invoices" — the ad, as you described it | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Your material says chasing unpaid invoices, not processing supplier ones, with nothing inspected behind it. Say it at its own scope: "I chased unpaid invoices." Answer slot: if you did anything with those invoices beyond chasing them for payment, say what, in your own words; if not, or it was not yours, say so plainly and stay with the chasing |

## Persona table

Weights start from the relationship prior for a manager-style interviewer (Case/Strategist plus Skeptic), then adjust for the invite's own words: a short 30-minute call.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (A) | Live problems from the job: schedule this, book that, what do you do when an invoice looks wrong | Highest. A manager is buying capability, and the ad's four duties each convert directly into a practical scenario | Clarify first, then structure, then answer; think aloud. These questions need no claim about your past |
| Skeptic (B) | Quiet probing of what your background does not show: travel, Excel, supplier invoices, the move to remote | High. F2, F4 and F5 are the rows your material shows least, and a manager screening for fit goes there | Rehearse B2 until it is boring. Use only your own sentences, and where your material is silent, say so plainly |
| Conversational (C) | A friendly opening: walk me through your journey, what made you apply | Medium. A short video call usually opens this way, and casual questions are still scored | A 90-second arc built only from your quoted sentences; treat the casual Word question as scored |
| Data-Driven Prober (D) | Follow-ups on the details of what you said: how the invoices were tracked, how comfortable you are in Excel | Medium-low. Your material holds one number (four physios) and two thin skill statements, which gives a prober little to open | Know what you can and cannot say about each statement, and say plainly when you do not know |
| Pressure (E) | Time-boxed challenge: why you over someone who already has an admin job | Low. A first conversation with an office manager rarely leans on stress, but the question is cheap to rehearse | Pause, restate, hold your position through two follow-ups, concede specifically |

Not included: Values/Behavioral, because no published values or values round were in hand, and Peer Evaluator, because the interviewer's relationship to you is not stated. A peer answer would reweight every bank.

## Question banks

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "I need a one-hour meeting with five people by end of day, and their diaries are all busy. How do you go about it?" | CASE | [generic] | Structure it aloud: what you would ask first (who is essential, the deadline, any fixed constraints), how you would find the overlap, offering two or three options rather than one, confirming with the essential people before sending the invite, and recording the outcome. The question needs no claim about your past, so the guidance makes none | The ad's calendar duty (F1) turned into a live decision; CASE because it scores structure, not history |
| A2 | "A colleague has to be in another city for a 9am meeting on Tuesday and back by Wednesday evening. Walk me through booking it." | CASE | [generic] | Clarify before booking: budget, preferences, who approves, the meeting's exact time. Then options, confirming with the traveller before anything is booked, and keeping the itinerary where they can find it. Makes no claim about your past | The ad's travel duty (F2), where your material is silent; a case lets you show method without a claim you cannot back |
| A3 | "A supplier invoice arrives and the amount is not what was agreed. What do you do?" | CASE | [generic] | Structure it: check the invoice against what was agreed, do not pay or approve it yourself, raise it with whoever approves spend, query the supplier in writing, and record what happened. Makes no claim about your past | The ad's invoice duty (F5) as a live problem; CASE because it scores reasoning |
| A4 | "I give you a list of fifty invoices with due dates. How would you set it up so nothing gets missed?" | CASE | [generic] | Ask what the list must show and who needs to see it, then describe a set-up in terms of what you can actually do in Excel today. Name no function or feature you have not used. If you would need to look something up, say you would and how | Tests the ad's Excel duty (F4) without requiring a claim about past Excel work |
| A5 | "Three people each send you an urgent request in the same hour. How do you decide the order?" | CASE | [generic] | Clarify what each deadline really is and what depends on it, order by deadline and consequence, tell each person where theirs sits, and ask the office manager when two truly clash. Makes no claim about your past | A standard prioritisation case for an assistant supporting several people (F1); CASE because it scores judgement |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "okay with Excel" | Name it plainly in your own words, then give a plan stated as a plan: what you would practise first and how you would check you were improving. Answer slot: if you have already used Excel for something at work, say what; if not, say so plainly and stay with the plan | F4 is the row your material shows thinly, so this is the likeliest honest-weakness question; JD because it scores the ad's own duties |
| B2 | "Your background is chasing unpaid invoices. This role is processing supplier invoices. How does one prepare you for the other?" | JD | [grounded] "chased unpaid invoices" | The highest-ROI rehearsal in this pack. The hold is only what the quote carries: "I chased unpaid invoices." Answer slot: if you did anything with those invoices beyond chasing them for payment, say what, in your own words; if not, or it was not yours, say so plainly and stay with the chasing. Hold through two follow-ups by returning to the chasing, never by adding to it. Then give a plan for what you would learn first | F5 is where the ad's invoice duty presses hardest on your material, so this objection will arrive in some form; JD because it scores the stated duty |
| B3 | "You have been a receptionist. Why an admin role, and why remote?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | Say the quoted sentence as it stands, then give your own reason for the move in your own words. This pack does not supply your reason, and none should be made up for you. If a reason is not clear to you yet, say so plainly and say what draws you to the work itself | F1 and F5 are your two strongest links to the job; EXP because it tests whether your story holds together |
| B4 | "Have you booked travel for anyone before?" | JD | [grounded] | Answer slot: if you have booked travel for anyone, at the clinic or elsewhere, say for whom and what you handled; if you have not, say so plainly, then say how you would go about it, as a plan. Never describe a booking you did not make | F2 is where your material is silent, so this is a likely direct question; JD because the ad lists travel booking |
| B5 | "This role is remote, so I will not see you work. How will I know things are getting done?" | JD | [generic] | Structure it: what you would report and how often, how you would flag a problem early, how you would confirm instructions in writing, and asking what the office manager prefers. Makes no claim about your past | The role is titled remote, so reliability without supervision is a natural probe; JD because it is about this role's set-up |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your journey so far." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" "ran the appointment book for four physios" "chased unpaid invoices" | A 90-second arc with three beats, each a clause your sentences state: the clinic and the two years; the appointment book for four physios; chasing unpaid invoices. Tell them in your own words and add nothing between them. Close with your own reason for this role, which this pack does not supply | The biography opener is nearly certain, and an unrehearsed one drifts; EXP because it tests whether your story is consistent with F1 and F5 |
| C2 | "What made you apply for this role?" | JD | [generic] | A selection scaffold: pick the one duty in the ad that you genuinely want to do more of, say why in a sentence, and say what you hope the role would lead to. If no single duty stands out, say so plainly, then name the nearest thing your material carries | Motivation questions are scored even in a friendly register; JD because it is about the listed duties |
| C3 | "You said you are good with Word. What do you use it for?" | EXP | [grounded] "I'm good with Word" | Start from your own sentence. Answer slot: name what you have actually produced in Word, in your own words; if you cannot name specifics, say so plainly and say what you are comfortable doing in it. Do not describe documents you have not made | F3 is a self-report with nothing inspected behind it, so a casual follow-up is how it gets tested; EXP because it tests the claim |
| C4 | "Tell me about running the appointment book for four physios." | EXP | [grounded] "ran the appointment book for four physios" | Story-mapped on F1, with the beats the quote states: the appointment book, and the four physios. Tell those in your own words. Answer slot: the ad's calendar duty makes a probe on changes or clashes between the physios likely. If any were yours to sort, say how; if there were none, or they were not yours, say so plainly and describe the book as you ran it | F1 is your strongest row, so this is the question to answer best; EXP because it tests what was actually yours |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You said okay with Excel. What is the most involved thing you have done in it?" | EXP | [grounded] "okay with Excel" | Start from your own sentence. Answer slot: name the most involved thing you have done in Excel, in your own words; if it was simple, say so plainly, and say what you would learn next. Never name a function or feature you have not used | F4 is a thin self-report, and the ad names Excel directly; EXP because it tests the claim |
| D2 | "How did you keep track of which invoices were still unpaid?" | EXP | [grounded] "chased unpaid invoices" | Start from the quote: "I chased unpaid invoices." Answer slot: if you kept a list or record, say what it was and how it stayed current, in your own words; if you did not, or someone else kept it, say so plainly and describe how you did the chasing | F5's follow-up: a prober goes from the claim to the method. EXP because it tests what was yours |
| D3 | "Four physios. How much of that appointment book was your own work?" | EXP | [grounded] "ran the appointment book for four physios" | Hold the sentence as it stands: "I ran the appointment book for four physios." Answer slot: if anyone else worked on the book, say what was theirs and what was yours; if it was all yours, say so plainly. Never round it up | The one figure in your material is a magnet for an attribution probe; EXP because it tests precision about what was yours |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should I hire you over someone who already has an admin job?" | EXP | [grounded] "ran the appointment book for four physios" "I'm good with Word" "okay with Excel" | Pause and restate the question. Hold on what the quotes carry: you ran the appointment book for four physios, and you are good with Word. When pushed on Excel, concede in your own words from "okay with Excel", specifically and without apology. Hold through two follow-ups by returning to those sentences, never by adding to them | F1, F3 and F4 together are your honest case and your honest limit; EXP because it tests composure and whether your claims hold under pressure |
| E2 | "How much of that reception work was really administration?" | EXP | [grounded] "ran the appointment book for four physios" "chased unpaid invoices" | Hold the two things your sentences state: the appointment book and the chasing of unpaid invoices. Answer slot: if there was other administrative work that was yours, say what, in your own words; if there was not, say so plainly and stay with those two. Hold through two follow-ups; concede only what you know | F1 and F5 are the administrative content of your background; EXP because it tests whether you overstate or understate it |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| "managing calendars" | A1, A5, C4, D3, E1 |
| "booking travel" | A2, B4 |
| "preparing documents in Word and Excel", Word | C3 |
| "preparing documents in Word and Excel", Excel | A4, B1, D1 |
| "processing supplier invoices" | A3, B2, D2, E2 |
| Remote working (the role title) | B5, B3 |
| Motivation and background | B3, C1, C2 |

## Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| R1 | "Whose diaries would I be managing, and what does a typical week of scheduling look like?" | It shows you are thinking about the scale of the calendar duty, and the answer tells you how big that part of the job is |
| R2 | "How are supplier invoices handled today, and which part would I own?" | The invoice duty is the one your material reaches least, so the answer tells you where you would start learning |
| R3 | "Which systems does the team use for calendars, travel and invoices?" | It shows you are planning to be productive early, and gives you something specific to practise beforehand |
| R4 | "What would a good first month look like?" | It turns the interview toward the work and gives you a target to prepare against |
| R5 | "How do you and the person in this role stay in touch day to day when it is remote?" | It answers your own question about how the job runs, and shows you take the remote set-up seriously |
| R6 | "What would you want to see from me after three months for you to say it is going well?" | It shows you are thinking about results, and names the measure you will be held to |
| R7 | "What are the next steps after this call, and is there a further stage?" | It is a plain process question, and the answer tells you what to prepare next |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Processed supplier invoices | Inflated form of F5 | F5's quote at its own scope: "I chased unpaid invoices." The limit is the pack's observation: the material says chasing unpaid invoices, not processing supplier ones. B2's slot stays inside what you did with the invoices you chased |
| Advanced or confident Excel skills | Inflated form of F4 | F4's quote at its own scope: "okay with Excel." D1's slot asks only what you have actually done in it |
| Managed calendars across the office | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios." D3's slot asks only which part of that book was yours |

## Sources

Provided documents: your message, holding the invite's text and your description of the ad. No dossier was present.

Searches sent: `Brennock Facilities Ltd company values` — refused. `Brennock Facilities Ltd interview process administrative assistant` — refused.

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Brennock Facilities Ltd company values` | unavailable | Every call was refused. It would have fed a values cheat sheet and VAL questions; neither is in this pack |
| 2. `Brennock Facilities Ltd interview process administrative assistant` | unavailable | Every call was refused. It would have fixed the loop structure. Persona weights rest on the relationship prior and the invite's own description of a 30-minute call |
| 3. Brennock Facilities Ltd strategy or recent news | unavailable | No search was sent after the two refusals. It would have fed CO questions; none are in this pack |
| 4. interviewer name | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Remote Administrative Assistant` JD | skipped | The four duties you gave fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full text of the ad → requirements in the fit snapshot become exact quotes, and any duty beyond the four you listed gets its own row and questions
- The interviewer's name and role → an interviewer read, persona weights from their public footprint, and a reverse question tied to their path
- Whether the interviewer would be your manager or a peer → persona weights recomputed and a reciprocity question added if peer
- Any travel you have booked for anyone → F2 becomes a mapped story instead of an answer slot, and B4 and A2 gain a grounded answer
- What you have actually done in Excel, and what you have made in Word → F4 and F3 become specific, and D1 and C3 gain grounded answers
- Anything you did with the invoices beyond chasing them → F5 moves from transferability toward a mapped story and B2 gains a grounded hold
- A values or interview-process page you find on the employer's own website → a values cheat sheet, loop-based persona weights and CO questions
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a company strategy brief and CO questions
- A `tuesday-dossier.md` from an earlier session, if you have one → verified evidence and prohibited claims that sharpen B2 and the rows around it
