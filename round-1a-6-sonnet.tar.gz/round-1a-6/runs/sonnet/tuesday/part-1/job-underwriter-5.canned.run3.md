Checked the live posting and the company page. Here's the assessment.

## Decision snapshot

**Yes, this looks worth applying to, provided you can work from the US (or Denver) and the pay range clears your floor. R1 and R2 are unconfirmed. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (US remote or Denver office), R2 (pay $148,000–$166,000)
- `must_have` — direct: R3, R4, R5, R6, R7
- `important` — adjacent: R8 (BigQuery warehouse); unclear: R9 (data contracts), R10 (ingestion from app and CRM)

R8 (`medium`) — Snowflake and dbt carry over, its limit named; R9 and R10 — your background is silent on them, waiting on answers.

**Opportunity ledger.** Pay is disclosed and sits inside the market range you sent (RR1). Team size, reporting line and equity terms are unstated (RR2, RR3, RR4). The posting is live and matches the company's own pages (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (US remote or Denver office), R2 (pay $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you can work from the US or Denver, R1; (2) the range clears your pay floor, R2; (3) BigQuery is presented as adjacent to your Snowflake work and never as experience you have, R8.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` the company's about page, as its own statement; the round has no second source |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and the data contracts analysts depend on | `[grounded]` the live posting, fetched |
| Stated requirements | 5+ years data engineering; strong SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` the live posting |
| Pay and terms | $148,000–$166,000 plus equity (type, size and vesting not stated); remote (US) or the Denver office | `[grounded]` the live posting |
| Scope read | The post spans ingestion, warehouse modelling and analyst-facing contracts. The report you sent calls one domain's pipelines the typical scope, so this may be wider, or "build and run" may just be loose wording. The posting does not say | `[inferred]` from the posting's three duties against the report's typical-scope line |
| Market calibration | The posted floor is $3,000 below the report's Series B–D base median of $151,000, and the ceiling of $166,000 is above the interquartile range's upper edge of $163,500. Series C falls inside the report's B–D group, and your 6 years sit in its typical 5–8 for "Senior". This is the employer's posted band, never an offer (RR1) | `[grounded]` the posting and the Datawright report you sent, taken as given and not independently checked; `[generic]` that the report's figures describe the market, not this employer |
| Unknowns | Team size and reporting line; hiring manager (none named); whether "run" includes on-call; equity terms | `[grounded]` the posting is silent on each; `[inferred]` that "run" may mean on-call |
| Contradictions | None between the pasted posting and the live careers page, which reads "Accepting applications" | `[grounded]` page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or the Denver office | hard_gate | unclear | none | hard_gate | The posting sets the term. You haven't said where you are or what you require, so nothing grades your side of it. | `[grounded]` posting; your message is silent on location | Ask Q1 below |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | The posting states the range. Your pay floor was not given, so whether it clears is not established. | `[grounded]` posting; floor not stated | Ask Q2 below |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years at a B2B payroll company. That is specific and confirmed in your message, with no inspectable artifact yet. | `[grounded]` your message | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You state daily use of both. No sample or repository has been inspected, so it stays at `medium`. | `[grounded]` your message | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | You built the dbt project on Snowflake, about 180 models. Snowflake is a cloud warehouse, which is what the requirements list asks for. | `[grounded]` your message | A sanitized project excerpt would raise to high |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | You state Airflow for orchestration at the payroll company. The depth of your ownership is unstated. | `[grounded]` your message | none |
| R7 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite. Coverage and results are unstated. | `[grounded]` your message | A sanitized suite config would raise to high |
| R8 | A dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | Your dbt and Snowflake work carries over. Limit: you have never used BigQuery. Warehouses differ in SQL dialect and cost model, and none of that has been exercised. | `[grounded]` your stated BigQuery gap; `[generic]` that warehouses differ in dialect and cost model | Narrow the limit; see G1 |
| R9 | Data contracts analysts depend on | important | unclear | none | discovery | Nothing in your background addresses contracts. That is silence, not a negative. | `[grounded]` your message is silent | Ask Q3 below |
| R10 | Ingestion from the app and CRM | important | unclear | none | discovery | Your message doesn't say which sources fed your pipelines. | `[grounded]` your message is silent | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8, important) | transferability | Snowflake plus dbt at scale; no BigQuery use, as you stated | The role description names BigQuery as the warehouse, and the requirements list asks only for "a cloud warehouse" | dbt models you wrote that were warehouse-agnostic; any BigQuery exposure through a side project or a vendor sandbox | A small public dbt project run on BigQuery's free sandbox | `[grounded]` your stated gap; `[inferred]` that a small project narrows the limit |
| G2 | Data contracts (R9, important) | discovery | Nothing in your background addresses them | Analysts depending on contracts is a named duty of the role | Schema tests that downstream teams relied on; agreed field definitions with analysts; alerts when a source changed | A dbt schema file or a short contract doc, sanitized | `[grounded]` your message is silent; `[inferred]` that your dbt and Great Expectations work may touch it |
| G3 | App and CRM ingestion (R10, important) | discovery | Sources behind your pipelines are not stated | The posting names the app and the CRM as the two sources | Loading from a product database, a SaaS API or a CRM export; managing a connector or an ingestion DAG | A sanitized DAG or a pipeline diagram | `[grounded]` your message is silent; `[inferred]` that payroll work involved comparable sources |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay disclosed, inside the market range | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range is posted openly and sits mostly in the upper half of the report's Series B–D band. It is the employer's band, not an offer. | `[grounded]` posting and the report you sent | Where in the range would you expect to place a candidate with six years' experience? | noted |
| RR2 | Team size, ownership and on-call unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | "Build and run" with no team size could mean sole ownership of the platform's reporting pipelines, or on-call duty. | `[inferred]` from the posting's silence; `[grounded]` the report's typical scope is one domain, no reports | How many data engineers are on the team today, which pipelines would I own at the start, and is there an on-call rotation? | unresolved |
| RR3 | No hiring manager named | unknown | — | "The posting names no hiring manager" (your note) | The reporting line is unknown, and there is no public footprint to read yet. | `[grounded]` your note and the posting | Who would I report to, and can I speak with them before the loop? | unresolved |
| RR4 | Equity unspecified | unknown | — | "plus equity" | Type, size and vesting are unstated, so the total package can't be compared with the report's base-pay figures. | `[grounded]` posting; the report covers base pay | What is the equity grant for this level: instrument, amount, vesting and strike? | unresolved |
| RR5 | Employer and posting check out | positive_signal | — | "Accepting applications" (the careers page, fetched) | The posting is live and matches the pasted text, and the about page matches the company description. The round and headcount rest on the company's own page alone. | `[grounded]` pages fetched | What has the Series C changed for the data team's plans this year? | noted |

## Application plan

All rows are proposed language or actions, `pending your approval`.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Answer Q1 and Q2 before spending effort on the application | see R1, R2 | `[grounded]` the two unconfirmed gates | pending your approval |
| A2 | Lead with the three facts as you stated them: "Built our dbt project on Snowflake — about 180 models", "Airflow for orchestration", "I set up our Great Expectations test suite" | see R5, R6, R7 | `[grounded]` your message | pending your approval |
| A3 | Say plainly that you have used Snowflake and not BigQuery. Don't put BigQuery on the resume | see R8 | `[grounded]` your stated gap | pending your approval |
| A4 | Optionally build a small dbt project on BigQuery's free sandbox to narrow R8's limit | see G1 | `[inferred]` from the gap type | pending your approval |
| A5 | Ask the RR2, RR3 and RR4 questions verbatim in the loop | the register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning Series C $52M tutoring Denver", which returned "About Pellucid Learning" (pellucidlearning.com/about). Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer). This moved the contradictions row (posting live and consistent) and RR5. No independent source returned for the funding round. |
| 2. Role-family sweep | skipped | The Datawright report you pasted already fixes the market calibration line and RR1, so a search could change nothing. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there is no query to form. |

I can save this as `tuesday-dossier.md` if you'd like to keep it, with no pressure.

## Upgrade menu

- Your location and pay floor → R1 and R2 close, and the decision likely becomes `go` or `no_go`.
- A sanitized dbt project excerpt or a Great Expectations suite config → R5 and R7 to `high`.
- A sanitized DAG, schema file or short contract doc → R9 and R10 rise from `none`.
- Your current resume → I can check for presentation gaps I can't see from your message.
- The hiring manager's name → the scope read and which story to lead with for that reader.
- A deeper research pass on Pellucid Learning (funding and leadership churn, hiring patterns, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

Q1 (R1) — Are you based in the US, or willing to work from Denver?

Q2 (R2) — Is $148,000–$166,000 at or above your pay floor?

Q3 (R9) — Have you ever set or maintained agreed definitions or schema guarantees that analysts or other teams relied on? What did you own, and what happened when a source changed?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.