**Decision snapshot**

**Yes, this is worth applying to, but two checks first and two stretch areas to own. Status: `conditional_go`.** The two stretches are R6 (owning a forecast) and R7a (billing data).

**Fit ledger.**

- `hard_gate` — unclear: R1 (Bristol hybrid, two office days), R2 (£61,500–£67,000 salary)
- `must_have` — direct: R3, R4 · adjacent: R5 (Strong SQL and spreadsheet modelling), R6 (Experience owning a forecast) · unclear: R7b (Working with finance on revenue data) · absent: R7a (Working with finance on billing data)
- `important` — direct: R8

R6 — a credible bridge, its limit named; R7a — absent, billing data never worked on.

**Opportunity ledger.** The role is clearly described and its pay is stated and in a normal band (RR4, RR5). Open items are the posting's absence from Quillfield's own careers page (RR1), what "Lead" means for team and forecast ownership (RR2), and unquantified share options (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days), R2 (£61,500–£67,000 salary); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Bristol hybrid and the pay range work for you (R1, R2); (2) R6 and R7a are framed as limits, never as experience you have; (3) the answers on team and forecast ownership are acceptable (RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants; founded 2018, Bristol; 96 employees; Series A (£11M) closed April 2025 | `[grounded]` About Quillfield page (search result) |
| Mandate | Own CRM and billing data; build the pipeline and renewal reporting sales and finance run on; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern | Bristol, hybrid, two days a week in the office | `[grounded]` posting |
| Pay | £61,500–£67,000 plus share options; option terms not stated | `[grounded]` posting |
| First-year outcomes | Not stated | `[grounded]` posting silent |
| Reporting line | Not stated. The recruiter named Tamsin Achebe as hiring manager, and her public profile reads Head of Revenue Operations at Quillfield, so the role plausibly sits under her | `[grounded]` profile title; `[inferred]` reporting line |
| Scope read | CRM, billing data, reporting and forecast in one post, with no team or direct reports mentioned | `[inferred]` from the responsibility list and its silence on reports |
| Market calibration | Ledgerline 2026 UK pay guide, revenue operations lead at UK B2B software (n=438): median base £64,200, interquartile range £57,800–£70,400. The posting's midpoint, £64,250, sits close to that median. This is a market band, never Quillfield's offer | `[generic]` one search, guide snippet only, not fetched; `[grounded]` posting figures |
| Unknowns | Team and reports; who owns the forecast today; option terms; first-year outcomes; billing system and finance contacts | `[grounded]` posting silent |
| Contradictions | None between the posting and Quillfield's About page. The role was not located on Quillfield's own careers page (RR1) | `[grounded]` About page; careers address tried returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two office days a week | hard_gate | unclear | none | hard_gate | You have not stated where you live or whether two days in Bristol works, so nothing settles it | `[grounded]` posting term; candidate constraints not given | G1 question |
| R2 | Salary £61,500–£67,000 | hard_gate | unclear | none | hard_gate | No pay floor stated, so the range cannot be checked against it | `[grounded]` posting figures; candidate floor not given | G1 question |
| R3 | 4+ years in revenue operations, sales operations or similar analytics role at a B2B software company | must_have | direct | medium | none | Five years in sales operations, the last two running revenue operations for the UK team, clears the years and the function. Your account is specific but nothing was inspected, so `medium`. Your employer is a B2B payments company; whether the recruiter reads that as "B2B software" is theirs to say | `[grounded]` your summary; `[generic]` that payments firms vary in how much of their product is software | Confirm sector fit with the recruiter |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified is specific, but the certification record was not inspected | `[grounded]` your summary | A certification record would raise to `high` |
| R5 | Strong SQL and spreadsheet modelling | must_have | adjacent | medium | discovery | SQL weekly and Excel daily show regular use. "Strong" and "modelling" are not established, and resolving downward gives `adjacent` | `[grounded]` your summary | A sanitized model or query example |
| R6 | Experience owning a forecast (and running the quarterly revenue forecast with the CFO) | must_have | adjacent | medium | transferability | You run the monthly pipeline review with your sales director, which is pipeline inspection. Limit: finance owned the company forecast, and you have never owned it | `[grounded]` your summary, including that you never owned the forecast | G2 question |
| R7a | Experience working with finance on billing data | must_have | absent | none | capability | You have never worked on billing data. This is also a stated duty: "own our CRM and billing data" | `[grounded]` your statement | Closure path in G3; carried as material risk |
| R7b | Experience working with finance on revenue data | must_have | unclear | low | discovery | Renewal dashboards touch revenue-related data, but nothing says finance used them or worked on them with you | `[inferred]` from the renewal dashboard work against silence on finance involvement | G4 question |
| R8 | Build the pipeline and renewal reporting sales and finance run on | important | direct | medium | none | You rebuilt your pipeline and renewal dashboards, which is the same work. Whether finance used them is not stated (R7b) | `[grounded]` your summary | A sanitized dashboard screenshot would raise to `high` |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and pay fit (R1, R2) | hard_gate | Neither your base nor your pay floor is stated | A failed gate ends the decision whatever the fit elsewhere | Not applicable; this is a yes or no on your own terms | Nothing to attach | `[grounded]` constraints not given |
| G2 | Owning a forecast (R6, must_have) | transferability | Monthly pipeline review with your sales director; finance owned the forecast | The posting asks you to run the quarterly forecast with the CFO, so this is the largest stretch in the role and the likeliest interview probe | Supplying pipeline or renewal numbers that fed a finance forecast; owning a commit or best-case roll-up; a variance review against forecast | A sanitized forecast roll-up, or the review deck | `[grounded]` your summary; `[generic]` that interviews for this title probe forecast ownership |
| G3 | Billing data (R7a, must_have) | capability | No billing-data work | A named duty and a named requirement | Not applicable; none stated | Not applicable | `[grounded]` your statement. Closure path, `[generic]`: ask your finance team for read access to invoice and revenue exports and reconcile one against CRM bookings, or ask how much billing ramp-up Quillfield expects |
| G4 | Finance on revenue data (R7b, must_have) | discovery | Renewal dashboards exist; finance's role in them is not stated | Could move R7b to `adjacent` or `direct` | Finance using your renewal dashboard; agreeing renewal-revenue definitions with finance; reconciling dashboard figures to finance reports | A sanitized dashboard, or an email thread agreeing definitions | `[grounded]` your summary; `[inferred]` that finance contact is plausible |
| G5 | Spreadsheet modelling (R5, must_have) | discovery | Daily Excel is stated; modelling is not | Would move R5 to `direct` | Scenario or target models; renewal-rate projections; quota or capacity models | A sanitized model | `[grounded]` your summary |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Role not found on Quillfield's own careers page | unknown | — | "Revenue Operations Lead, Quillfield. Bristol, hybrid" | The role may be listed under another address, only on the board, or not yet on the careers page. The one address I tried returned no page, which is weak evidence either way | `[inferred]` from one fetch of an address I guessed | Can you point me to this role on Quillfield's own careers page? | unresolved |
| RR2 | "Lead" with no stated team, and forecast ownership not described | unknown | — | "run the quarterly revenue forecast with the CFO" | The role may be a hands-on post carrying four areas, or may manage people or be supported by finance | `[inferred]` from the responsibility list against the posting's silence on reports | Does this role have direct reports, and who owns the forecast today? | unresolved |
| RR3 | Share options unquantified | unknown | — | "plus share options" | Value depends on grant size, vesting and strike price | `[generic]` options at a funded company vary widely; nothing here is specific to Quillfield | What is the option grant, vesting schedule and strike price? | unresolved |
| RR4 | Pay stated and inside the market band | positive_signal | — | "£61,500–£67,000" | The range is given up front and sits near the guide's median | `[grounded]` posting; `[generic]` band, role-family sweep | What decides where in the range an offer lands? | noted |
| RR5 | Hiring manager attributable and relevant | positive_signal | — | "Tamsin Achebe" (named by the recruiter) | Her public profile shows Head of Revenue Operations at Quillfield, consistent with what the recruiter told you | `[grounded]` search result, snippet only | What does success look like in the first year? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm Bristol hybrid and the pay range work for you before applying | R1, R2 | `[grounded]` rows | pending your approval |
| A2 | Positioning, to lead with: "two years running revenue operations for the UK team, Salesforce admin certified, rebuilt pipeline and renewal dashboards, runs the monthly pipeline review with the sales director." Each clause is your own sentence | R3, R4, R8 | `[grounded]` your summary | pending your approval |
| A3 | Say plainly that finance owned the company forecast and that you have not worked on billing data; do not describe pipeline review as forecasting | R6, R7a | `[grounded]` your statements | pending your approval |
| A4 | Ask RR1 to RR5's questions verbatim with the recruiter and in the hiring-manager round | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A5 | With Tamsin Achebe, lead with your UK revenue operations work. Her profile shows a path from sales operations manager at a payments company into revenue operations | Her path is public; how she will read yours is inference | `[grounded]` profile title and prior role; `[inferred]` relevance | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company careers", which returned "About Quillfield" (quillfield.co.uk/about); fetched quillfield.co.uk/careers, an address I guessed, which returned "No page". Role reality: the company exists as the posting describes. The careers listing is unconfirmed (RR1) |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK B2B software Bristol", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Market calibration and RR4 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe), seen as a snippet only. Role reality's reporting line, RR5 and A5 |

Offer: a one-page `tuesday-dossier.md` of this assessment is available if you want to keep it or reuse it later.

## Upgrade menu

- Your CV → the fit rows move from your summary to the document, and any presentation gaps surface.
- Your base location and pay floor → R1 and R2 resolve, and the hard-gates line stops reading "constraints not given".
- A sanitized pipeline or renewal dashboard, or your Salesforce certification record → R4 and R8 can reach `high`.
- Your answer on G2 or G4 → R6 or R7b firms up or stays a named limit.
- A sanitized model or query → R5 to `direct`.
- The recruiter's answers on team, forecast ownership and option terms → RR2 and RR3 close.
- A deeper research pass on Quillfield (funding follow-up, leadership changes, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

G1 — Where are you based, can you do two days a week in Bristol, and what is the lowest base salary you would accept?

G2 — Have you ever built or contributed numbers to a forecast that finance or leadership used, such as a commit or best-case roll-up, or a forecast-versus-actual review? What did you own, and what happened?

G4 — Did anyone in finance use your renewal dashboards or agree renewal-revenue definitions with you? What was your part in it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.