## Decision snapshot

**Yes, apply. You fit the core of this role: every must-have (R1, R2, R3, R4, R5) lands `direct`. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R5
- `important` — adjacent: R7a (Partner with product managers on roadmap); unclear: R6 (Define and maintain the metrics layer), R7b (Partner with clinicians), R8 (Mentor two junior analysts)
- `preferred` — adjacent: R9 (Healthcare data experience, HIPAA)

R6, R7b and R8 — each can be settled by something you tell me; R9 (`medium`) — a credible bridge, its limit named.

**Opportunity ledger.** Under-specified rather than worrying: pay (RR1) and work arrangement (RR2) are not stated, the employer has not been checked against outside sources (RR3), and success measures are not stated (RR4). The concrete scope and a team to lead point the other way (RR5).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting and employer verify as live and real (RR3); (2) pay and work arrangement turn out acceptable to you, once you tell me your limits (RR1, RR2); (3) the HIPAA gap is framed as adjacent, never as HIPAA experience (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up of about 400 people at Series C, with a care-navigation app | `[grounded]` JD header; not checked against any outside source |
| Mandate | Own product analytics for the app: metrics layer, A/B test design and analysis, self-serve Looker dashboards, partnering with PMs and clinicians | `[grounded]` JD |
| Team | Mentor two junior analysts | `[grounded]` JD |
| Stated requirements | 5+ years product analytics, expert SQL, experiment design at scale, Looker or similar, written communication with non-technical stakeholders; HIPAA experience a plus | `[grounded]` JD |
| Pay, location, work arrangement | Not stated in the posting as given | `[grounded]` JD silence |
| First-year outcomes | Not stated | `[grounded]` JD silence |
| Scope read | A broad single-owner post: one person carries the metrics, experimentation and dashboard work for the app and also coaches juniors | `[inferred]` from the JD's responsibilities list |
| Market calibration | Not run, so there is no band for this title and seniority | `[generic]` none available; see Evidence status |
| Unknowns | Pay; location or remote policy; success measures; what metrics layer exists today; who the hiring manager is | — |
| Contradictions | None between the JD and your background; the JD was not checked against a careers page | `[grounded]` the two inputs read against each other |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | You state 6 years of product analytics at one consumer-subscription company, which clears the bar. It is self-reported, with no dated document inspected yet | `[grounded]` your intake message | none |
| R2 | Expert SQL | must_have | direct | medium | none | You state daily SQL on a Snowflake warehouse. "Expert" is a level your statement implies but nothing inspected shows. Expect a probe | `[grounded]` intake message; `[generic]` analyst loops often include a live SQL exercise | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | You state that you designed and ran the experimentation program, 30+ A/B tests a year, including the pricing test behind an 11% retention lift, for a ~2M-subscriber base. The JD gives no scale figure to compare against, and the pricing test's lift is yours to explain: what you owned versus the team | `[grounded]` intake message | offer: a sanitized readout of the pricing test would raise to high |
| R4 | Looker or a similar BI tool, self-serve dashboards | must_have | direct | medium | none | You built the Looker instance from scratch with 40+ governed dashboards. "Self-serve" use by others is not stated, so the claim stays at what you said | `[grounded]` intake message | offer: a sanitized dashboard screenshot would raise to high |
| R5 | Written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads and present monthly to the VP Product. Clinicians are a different audience, carried in R7b | `[grounded]` intake message | offer: a sanitized memo would raise to high |
| R6 | Define and maintain the metrics layer | important | unclear | low | discovery | Governed dashboards and a warehouse consent-state model sit near this. Nothing you said states that you owned metric definitions, or where they lived | `[grounded]` the Looker build and consent-state model as stated; `[inferred]` that metric ownership may sit inside that work | G1's question |
| R7a | Partner with product managers to turn analysis into roadmap decisions | important | adjacent | medium | discovery | You present to the VP Product monthly and ran a pricing test with a retention result. Whether analyses changed roadmap choices is not stated, so the adjacent call is the downward reading | `[grounded]` intake message | offer: one example where a result changed what shipped |
| R7b | Partner with clinicians | important | unclear | none | discovery | Nothing in what you shared touches clinical partners. This is a first-pass `unclear`, not a verdict on your experience | `[grounded]` silence in your intake message | G2's question |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Nothing you shared mentions managing or coaching analysts | `[grounded]` silence in your intake message | G3 stays in the queue; asked if you want it prioritised |
| R9 | Healthcare data experience (HIPAA) a plus | preferred | adjacent | medium | transferability | You handled GDPR/CCPA consumer PII and built the warehouse consent-state model, which is credible privacy-governed data work. Limit: it did not exercise HIPAA specifics such as protected health information or de-identification rules | `[grounded]` intake message; `[generic]` health-data roles commonly treat these as distinct regimes | proposed bridge in E2 below, pending approval |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer ownership (R6, important) | discovery | A governed Looker build and a consent-state model; no statement of who defined metrics | It is the first duty the JD lists, so an answer could turn R6 from `unclear` to `direct` | Writing the official definition of churn, activation or retention; reconciling two teams' numbers; a metrics glossary or a modeled layer others queried | A sanitized glossary, a model excerpt, or a definitions doc | `[grounded]` your intake message is silent on definitions; `[inferred]` an answer could move R6 |
| G2 | Clinician partnership (R7b, important) | discovery | Nothing stated | The JD names clinicians as partners, and a real example would close the most role-specific gap | Working with nutrition, culinary or customer-care experts on a test design; explaining a result to a domain expert who does not read data | A test brief or a write-up naming the partner function | `[grounded]` silence; `[generic]` health-product roles lean on clinical partners |
| G3 | Mentoring (R8, important) | discovery | Nothing stated | The post expects two juniors to be coached | Onboarding an analyst; reviewing others' queries or dashboards; running office hours | A review checklist or an onboarding doc | `[grounded]` silence in your intake message |
| G4 | HIPAA and health data (R9, preferred) | transferability | Consent-state model and GDPR/CCPA PII handling | A preferred row, but the likeliest question an interviewer raises | Designing consent flags that gate which data analysts see; access controls or masking on PII | A sanitized model diagram | `[inferred]` bridge from the consent-state model; `[generic]` that this is the likeliest probe |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay not stated | unknown | — | (no compensation language in the posting) | The figure may be withheld, or sit outside what you need | `[inferred]` from the JD's silence | What is the budgeted salary band for this post? | unresolved |
| RR2 | Work arrangement not stated | unknown | — | (no location or remote language in the posting) | The role may be on-site or hybrid in a way that conflicts with your plans | `[inferred]` from the JD's silence | Where is this role based, and what is the in-office expectation? | unresolved |
| RR3 | Employer not established from attributable sources | risk_signal | medium | "digital-health scale-up, ~400 people, Series C" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer; outside checks did not run, so none of these is ranked as likely | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR4 | No success measures stated | unknown | — | "turn analysis into roadmap decisions" | The post may carry accountability for roadmap impact without defined measures | `[inferred]` from the JD's outcome language against its silence on targets | What would success look like at six and twelve months? | unresolved |
| RR5 | Concrete scope and a team | positive_signal | — | "mentor two junior analysts" | The post has defined duties and some team capacity | `[grounded]` JD | Which metrics layer exists today, and who maintains it? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the resume with: "Designed and ran the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift" | R3; every word is yours, nothing added | `[grounded]` your intake message | pending your approval |
| E2 | Pair it with: "Built the warehouse consent-state model; handled GDPR/CCPA consumer PII". Never write HIPAA experience or compliance | R9; the bridge stops at the limit | `[grounded]` your intake message | pending your approval |
| E3 | Surface the monthly exec memo and the monthly VP Product presentation near the top | R5, R7a | `[grounded]` your intake message | pending your approval |
| A1 | Check the posting on the employer's own careers page before investing effort | RR3 | `[grounded]` register | pending your approval |
| Q1 | Ask RR1, RR2, RR4 and RR5's questions verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search "Harborlight Health care navigation app careers Senior Product Analyst" was refused. It would have moved role reality's organization and contradictions rows and RR3 |
| 2. Role-family sweep | unavailable | Search "senior product analyst digital health salary range 2026 experimentation Looker" was refused. It would have moved the market calibration row and RR1's comparison |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I'll offer to save this as `tuesday-dossier.md` so a later step can start from it.

## Upgrade menu

- Allow web search → targets 1 and 2 run (RR3 and the market band firm up); a deeper pass would add up to 5 more searches and 2 more fetches.
- A sanitized pricing-test readout, dashboard screenshot or monthly memo → R3, R4 or R5 to `high`.
- A metrics glossary or model excerpt → R6.
- Your non-negotiables → hard-gate rows exist and are checked against the role.
- The hiring manager's name → role reality's scope read and which story to lead with.

**Questions**

Constraints — what are your non-negotiables for this move: pay floor, location or remote, and work authorization if it applies?

G1 — Did you personally write the official definitions of core metrics such as retention or churn, and where did they live (Looker model, a doc, the warehouse)?

G2 — Have you worked with a domain expert, such as a dietitian or culinary team, on designing or reading an experiment? What was your part?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.