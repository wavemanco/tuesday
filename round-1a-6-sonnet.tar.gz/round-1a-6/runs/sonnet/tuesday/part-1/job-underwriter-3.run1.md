Web search wasn't permitted, so I'm working from the posting and your background alone.

## Decision snapshot

**No, this isn't worth pursuing as posted. R1 and R2 are both hard gates, and both fail. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (On-site in our Austin office 5 days a week), R2 ($70–85k base)
- `must_have` — direct: R3, R4, R5, R6
- `important` — unclear: R7 (SEO/content), R8 (brand, PR, partnerships, sales ops), R9 (team of one)

R1 — on-site five days against remote-only; R2 — a $70–85k base against a $150k floor; R6 (`medium`) — your strongest row, confirmed but with no artifact inspected yet.

**Opportunity ledger.** Two of the posting's terms conflict with your non-negotiables (RR1, RR2). It also folds many functions into one solo role (RR3), gives no definition of success (RR4), signals after-hours expectations (RR5), leaves authority and budget open (RR6) and has an unchecked employer (RR7). One entry runs the other way: the CEO reporting line (RR8).

- **Hard gates:** failed: R1 (On-site in our Austin office 5 days a week), R2 ($70–85k base).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would change this:** the employer would have to allow remote work from Portland (R1) and offer a base of at least $150k (R2). The posting says "no exceptions" on location, so only a change in the employer's terms could move this. Rewording your application can't.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` posting header; the claims are not checked |
| Mandate | Own revenue growth end to end across paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships and sales ops | `[grounded]` posting |
| Team | "A team of one to start" | `[grounded]` posting |
| Reporting line | CEO, with a dotted line to the board | `[grounded]` posting |
| Working pattern | Austin office five days a week, no exceptions; evenings and weekends "when it matters" | `[grounded]` posting |
| Compensation | $70–85k base plus "meaningful equity upside"; equity size and terms not stated | `[grounded]` posting |
| Success definition | "Success metrics will evolve as we learn"; no first-90-days or first-year outcomes stated | `[grounded]` posting |
| Scope read | Several full specializations folded into one title, with no support staff | `[inferred]` from the function list against "team of one" |
| Market calibration | Not established. The role-family sweep was refused, so no band is offered, and the posted pay is not set against one | `[grounded]` search refused this session |
| Unknowns | Budget, decision rights, equity terms, who the dotted-line board contact is | `[grounded]` the posting is silent |
| Contradictions | None visible, but there is only one source | `[grounded]` posting only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in our Austin office 5 days a week — no exceptions | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own statement (remote-only, Portland, not relocating), which is specific and confirmed. Fit fails because the posting excludes any exception | `[grounded]` posting quote and your stated constraint | Surface only; the employer changing terms or you changing the constraint are the only resolutions |
| R2 | Compensation: $70–85k base | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your $150k floor, which is yours and specific. The top of the posted range is $65k under it. The equity is unquantified | `[grounded]` posting quote and your stated constraint | Surface only; same as R1 |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | You state 9 years, as growth lead and then Head of Growth. This is self-report with nothing inspected yet | `[grounded]` your intake message | none |
| R4 | Paid acquisition | must_have | direct | medium | none | You state you owned paid. Channels, spend levels and returns are not stated | `[grounded]` your intake message | A sanitized channel-level spend and return summary would raise it to `high` |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You state you owned lifecycle and name Braze. No inspectable artifact yet | `[grounded]` your intake message | A sanitized lifecycle flow map or a retention report would raise it to `high` |
| R6 | Own revenue growth | must_have | direct | medium | none | You scaled one company from $8M to $40M ARR over three years with a budget you controlled. How much of that growth was yours is not stated | `[grounded]` your intake message | A sanitized ARR bridge would raise it to `high` |
| R7 | SEO and content | important | unclear | none | discovery | Your intake lists paid, lifecycle and experimentation, and does not mention SEO or content | `[grounded]` the intake is silent | See gap G1 |
| R8 | Brand, PR, partnerships and sales ops | important | unclear | none | discovery | Nothing in your intake touches these four functions | `[grounded]` the intake is silent | See gap G2 |
| R9 | Operate as a team of one | important | unclear | low | discovery | You built and managed teams of 3–7, which is a different shape from solo execution. Solo work is not stated | `[grounded]` your intake; `[inferred]` that the shapes differ | See gap G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO and content (R7, important) | discovery | Your intake doesn't mention SEO or content | An important row, but it can't change the decision while R1 and R2 stand | Commissioning content or running a content calendar tied to acquisition; owning technical SEO fixes with engineering | Organic traffic report, content roadmap | `[grounded]` intake silence; `[inferred]` that it cannot move the decision |
| G2 | Brand, PR, partnerships, sales ops (R8, important) | discovery | Your intake doesn't mention any of the four | Same: it matters only if the gates change | Running a partner or affiliate program; supporting a sales team with pipeline reporting | Partner program brief, pipeline dashboard | `[grounded]` intake silence; `[inferred]` that it cannot move the decision |
| G3 | Solo operation (R9, important) | discovery | Your team-building experience is clear, but solo execution is not stated | Same | Periods when you executed alone, such as before your first hire | A description of your solo scope | `[grounded]` intake; `[inferred]` that it cannot move the decision |

No questions are asked this turn. No answer to these rows can move R1 or R2.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Location conflicts with your remote-only constraint (see R1) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions." | The role can't be done from Portland as written | `[grounded]` posting quote against your stated constraint | Is the five-days-in-Austin requirement fixed for this role, as the posting states? | confirmed |
| RR2 | Base pay conflicts with your floor (see R2) | red_flag | high | "$70–85k base plus meaningful equity upside" | The top of the range sits $65k below your floor, and the equity is unquantified | `[grounded]` posting quote against your stated floor | Is the $70–85k base fixed, and what are the size and terms of the equity grant? | confirmed |
| RR3 | Many specializations in one solo role | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops… a team of one" | Several full roles are bundled under one title at a base the posting sets at $70–85k, though it asks for 8+ years | `[inferred]` from the function list against the team size and pay; market band not checked | Which of these functions are first-year priorities, and what headcount or budget is committed to the rest? | unresolved |
| RR4 | No defined success measures | risk_signal | medium | "success metrics will evolve as we learn" | You may be accountable for outcomes that aren't yet defined | `[inferred]` from the posting's wording | What would count as success at six and twelve months, and who sets it? | unresolved |
| RR5 | After-hours expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Extra hours may be a standing expectation, not an exception | `[inferred]` from the phrase "just who we are" | How often did evenings or weekends come up for the team last quarter? | unresolved |
| RR6 | Authority and resources unspecified | unknown | — | "You will be a team of one to start… dotted line to the board" | Budget and decision rights are not stated | `[grounded]` the posting is silent | What budget and decision rights does this role hold, and what does the board line involve in practice? | unresolved |
| RR7 | Employer unchecked | unknown | — | "Series A, profitable since day one" | The stage and profitability claims are untested, because research did not run | `[grounded]` search was refused this session | Can you point me to this role on your own careers site, and who would I interview with? | unresolved |
| RR8 | Senior reporting line | positive_signal | — | "Report to the CEO" | The reporting line fits the title's seniority | `[grounded]` posting | How often does the CEO review growth targets with this role? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't spend application time on this posting as written | See R1, R2 | `[grounded]` R1, R2 rows | pending your approval |
| A2 | If you proceed anyway, ask RR1 and RR2 first, verbatim, before any further effort | A reply that holds both terms ends it cheaply | `[grounded]` register | pending your approval |
| A3 | If the terms change, share the revised posting and I'll re-run this | R1, R2 are the only rows that decide it | `[grounded]` R1, R2 rows | pending your approval |

## Evidence status

Verified: none yet. Everything above comes from your intake message and the posting.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Austin careers Head of Growth" and the host refused it. It would have moved role reality's organization row and RR7 |
| 2. Role-family sweep | unavailable | Searched "Head of Growth Series A startup salary range base compensation 2026" and the host refused it. It would have moved the market calibration row and RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given, so no query could be formed |

## Upgrade menu

- Permission to search would run the official-site check and the pay-band sweep. That would move RR7, and RR3 would be set against a market band.
- Your resume would let me check R3–R6 against what it actually says.
- A sanitized spend-and-return summary or ARR bridge would raise R4 and R6 to `high`.
- Answers on SEO/content, brand/PR/partnerships/sales ops and solo work would settle R7, R8 and R9. They can't move the decision while R1 and R2 stand.
- The employer's answer on whether the location and base terms are fixed (RR1, RR2) is the only input that could change the status.

If you'd like, I can save this as a `tuesday-dossier.md` to carry forward.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.