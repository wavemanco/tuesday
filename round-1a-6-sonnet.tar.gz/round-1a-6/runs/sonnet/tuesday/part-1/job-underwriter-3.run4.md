Web search was denied, so I'm assessing from the posting and your background alone.

## Decision snapshot

**No. R1 (pay) and R2 (on-site), both hard gates, fail your two constraints, so this isn't worth pursuing as posted. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: hard_gate_fail: R1 (Compensation $70–85k base), R2 (On-site in Austin five days a week)
- `must_have`: direct: R3, R4, R5
- `important`: unclear: R6 (SEO/content), R7 (Brand, PR, partnerships), R8 (Sales ops), R9 (Team of one)

R1 — pay conflicts with your floor; R2 — location conflicts with your remote-only constraint; R4 and R5 — direct, the strongest overlap with your background.

**Opportunity ledger.** The posting conflicts with your constraints on pay and location (RR1, RR2). Its scope and terms also carry risk signals: pay against mandate (RR3), seven functions for one person (RR4), always-on expectations (RR5) and undefined success metrics (RR6). Its one clear positive is the reporting line (RR9).

- **Hard gates:** failed: R1 (Compensation $70–85k base), R2 (On-site in Austin five days a week).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would change this:** the base would have to reach at least $150k (R1), and the role would have to allow remote work from Portland (R2). The posting says "no exceptions" on location, and the pay figure is stated.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` JD header; not verified (target 1 did not run) |
| Mandate | Own revenue growth across paid, SEO/content, lifecycle/CRM, brand, PR, partnerships and sales ops | `[grounded]` JD |
| Team and reporting | Team of one to start; reports to the CEO, dotted line to the board | `[grounded]` JD |
| Schedule | "Evenings and weekends when it matters" | `[grounded]` JD |
| Location | On-site in Austin, five days a week, "no exceptions" | `[grounded]` JD |
| Pay | $70–85k base plus "meaningful equity upside", with no equity figure | `[grounded]` JD |
| Success metrics | "Will evolve as we learn" | `[grounded]` JD |
| Market calibration | Not established. The role-family sweep did not run, so no market band is stated, and the posting's own figure is the only pay data | `[grounded]` JD |
| Unknowns | Budget, equity terms, first-year outcomes, who the CEO is, whether the team will grow | — |
| Contradictions | None found within the posting. It was not checked against the careers page | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Compensation $70–85k base | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own stated floor of at least $150k base, which is specific and confirmed. Fit fails because the top of the posted range is $65k under it | `[grounded]` JD and your message | none on your side; only the employer changing the terms resolves it |
| R2 | On-site in Austin five days a week | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own stated remote-only, Portland, no-relocation constraint. Fit fails because the JD allows no exception | `[grounded]` JD and your message | none on your side; only the employer changing the terms resolves it |
| R3 | 8+ years of growth leadership | must_have | direct | medium | none | You state 9 years in growth, as growth lead and then Head of Growth at two B2C subscription companies, with teams of 3–7. This is self-reported, with no CV or artifact, and your message doesn't split leadership years from the 9 | `[grounded]` your message | confirm the leadership-years split before any application |
| R4 | Paid acquisition | must_have | direct | medium | none | You state you owned paid at both companies and scaled one from $8M to $40M ARR over three years with a budget you controlled. This is confirmed and specific, but no artifact has been inspected | `[grounded]` your message | a sanitized dashboard or board slide would raise it to `high` |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You state you owned lifecycle and are deep in Braze, SQL and GA4. This is self-reported and uninspected | `[grounded]` your message | a sanitized lifecycle program summary would raise it |
| R6 | SEO/content | important | unclear | none | discovery | Your message doesn't mention SEO or content. Silence is not absence | `[grounded]` silence in your message | see G3 |
| R7 | Brand, PR, partnerships | important | unclear | none | discovery | Your message doesn't mention these either | `[grounded]` silence in your message | see G4 |
| R8 | Sales ops | important | unclear | none | discovery | Your message doesn't mention it | `[grounded]` silence in your message | see G5 |
| R9 | Working as a team of one | important | unclear | low | discovery | You built and managed teams of 3–7, and the posting needs solo, hands-on work across all seven functions. Your account doesn't say how much of your work was hands-on | `[grounded]` your message; `[inferred]` from the JD's team-of-one wording | see G6 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay (R1, hard_gate) | hard_gate | $70–85k posted against your floor of at least $150k | It decides the outcome | Nothing on your side; only a changed offer | A written pay band from the employer | `[grounded]` JD and your message |
| G2 | Location (R2, hard_gate) | hard_gate | Five days a week in Austin, "no exceptions", against your remote-only constraint | It decides the outcome | Nothing on your side; only changed terms | A written remote or hybrid policy from the employer | `[grounded]` JD and your message |
| G3 | SEO/content (R6, important) | discovery | Not in your account | An important row, but it can't move the decision while R1 and R2 stand | Owning organic or content growth; briefing writers or agencies; a content-driven acquisition channel | Channel report or traffic dashboard | `[grounded]` silence in your message |
| G4 | Brand, PR, partnerships (R7, important) | discovery | Not in your account | Same, it can't move the decision | Running partner or affiliate programs; launch PR; brand campaigns | Campaign brief or partner deck | `[grounded]` silence in your message |
| G5 | Sales ops (R8, important) | discovery | Not in your account | Same, it can't move the decision | Lead routing or CRM-to-sales handoffs; pipeline reporting | Process doc or funnel dashboard | `[grounded]` silence in your message |
| G6 | Team of one (R9, important) | discovery | Your leadership evidence is team-based; solo hands-on scope is unclear | Same, it can't move the decision | Periods when you personally ran channels without a team | A role description or a period summary | `[grounded]` your message |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay below your floor (see R1) | red_flag | high | "$70–85k base plus meaningful equity upside" | The top of the range is $65k under your floor, and equity is unquantified (RR7), so it can't close that gap | `[grounded]` JD and your message | Is the base negotiable above the posted range, and by how much? | confirmed |
| RR2 | On-site five days against remote-only (see R2) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | The terms rule out remote work from Portland | `[grounded]` JD and your message | Is there any remote or hybrid arrangement for this role? | confirmed |
| RR3 | Seniority-compensation mismatch | risk_signal | medium | "8+ years growth leadership required" with "$70–85k base" | The pay may sit below what this mandate usually commands. The market sweep was refused, so this is unconfirmed | `[inferred]` from the posting's scope against its stated pay | How was the base range set, and against what benchmark? | unresolved |
| RR4 | Bundled specializations, no stated budget or team | risk_signal | medium | "Own all revenue growth end to end … a team of one to start" | Seven functions with one person and no stated budget may mean responsibility without resources | `[inferred]` from the scope list against the JD's silence on budget | What budget and headcount are committed for the first year? | unresolved |
| RR5 | Always-on expectations | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Out-of-hours work may be a standing expectation, not an exception | `[inferred]` from the posting's phrasing | How often has the team worked evenings or weekends in the past quarter? | unresolved |
| RR6 | Success metrics undefined | risk_signal | medium | "success metrics will evolve as we learn" | A demanding mandate with no stated definition of success makes it harder to know whether you're meeting expectations | `[inferred]` from the posting's silence on targets | What does success look like at 6 and 12 months? | unresolved |
| RR7 | Equity unquantified | unknown | — | "meaningful equity upside" | Terms such as the amount, vesting and strike price are missing | `[grounded]` JD silence | What is the equity grant, as a percentage, with vesting terms? | unresolved |
| RR8 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The entity may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer. The check was refused, so none of these is ranked | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who I would be interviewing with? | unresolved |
| RR9 | Reporting line to the CEO with board access | positive_signal | — | "Report to the CEO with a dotted line to the board" | The role has senior visibility | `[grounded]` JD | Who is the CEO, and how often does the board see growth reporting? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't spend application effort on this posting as written | See R1, R2, RR1, RR2 | `[grounded]` the two failed gates | pending your approval |
| A2 | If you want to test the terms, send the employer one question each on pay (RR1) and remote work (RR2), using contact details from its own website. Treat "no exceptions" as the likely answer | See RR1, RR2 | `[grounded]` the posting's wording | pending your approval |

I propose no resume edits.

## Evidence status

Verified: the constraint claims in R1 and R2, which are your own statements. Your growth experience (R3, R4, R5) is self-reported and uninspected.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Novaline e-commerce enablement startup Austin Series A" was refused. A result would have checked the company and posting, feeding role reality and RR8 |
| 2. Role-family sweep | unavailable | The search "Head of Growth salary Series A startup base salary range 2026" was refused. A result would have supplied a market band for the calibration row and RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given. The posting says only "the CEO" |

I'd offer the dossier as a record of this assessment, and I'm happy to write it up as `tuesday-dossier.md` if you want it.

## Upgrade menu

- Permission to search the web would let targets 1 and 2 run. That would settle RR8 and give RR3 a market band, which can't change the decision, only its explanation.
- Your CV, or a sanitized dashboard or board slide for the $8M to $40M ARR work, would move R3, R4 and R5 toward `high`.
- The CEO's name would let me look at their public professional footprint and shape how you'd frame your story.
- A deeper research pass on Novaline (funding and leadership churn, public employee reports, recent news; up to 5 more searches and 2 more fetches) runs only if you say the word.

No questions this turn, because nothing you could answer would change the decision.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.