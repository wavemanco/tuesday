I've read the job-underwriter playbook and its reference files. Next I'll check that the posting and the company page are still live and match what you pasted. Then I'll write up the assessment.
## Decision snapshot

**Yes, worth applying to, on conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity)
- `must_have` — direct: R3, R4, R5, R6, R7
- `important` — adjacent: R8 (BigQuery as the warehouse) · unclear: R9 (Ingestion from app and CRM), R10 (Data contracts for analysts)

R8 — a credible bridge, its limit named; R9, R10 — your account is silent so far.

**Opportunity ledger.** The pay is stated and sits in line with the report you supplied (RR1). The shape of the role is thin. Scope may run wider than one domain (RR2), no outcomes are stated (RR3), and equity terms are missing (RR4). I couldn't check the pasted pages against the live site (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your location and pay floor fit the posting, see R1, R2, G1; (2) the posting is confirmed live on the company's own careers page, see RR5; (3) team size, reporting line and scope are concrete in the first conversation, see RR2; (4) the BigQuery bridge is framed as adjacent, never as BigQuery experience, see R8.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` the about-page text you pasted, not checked against the live page |
| Mandate | Build and run the pipelines behind the platform's reporting: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` the JD you pasted |
| Terms | 5+ years; $148,000–$166,000 plus equity; Remote (US) or Denver | `[grounded]` JD |
| First-year outcomes | Not stated | `[grounded]` JD silence |
| Scope read | Three named areas (ingestion, warehouse modelling, contracts) read as end-to-end ownership of reporting data. The report you supplied describes typical senior scope as one domain's pipelines, no direct reports | `[inferred]` from the JD's three areas set against the report's typical-scope line |
| Market calibration | Senior Data Engineer at Series B–D companies, US: base median $151,000, IQR $139,000–$163,500, "senior" typically 5–8 years. The posted range spans the median, and its top is above the IQR's upper bound. This is the band's pattern, never this employer's offer | `[generic]` Datawright 2026 report (n=2,310) as supplied, no search run; `[grounded]` the posted range; `[inferred]` that the posted salary is base |
| Unknowns | Hiring manager (none named), team size and reporting line, equity terms, whether the BigQuery warehouse exists or is to be built, your own location and pay floor | `[grounded]` JD silence |
| Contradictions | None between the two pasted texts; neither was checked against the live pages | `[grounded]` the pasted texts |

## Evidence map

Your background is typed prose, so it is treated like a CV: self-reported, with `medium` as the ceiling until something inspectable is shown.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or our Denver office | hard_gate | unclear | none | hard_gate | The posting's terms are stated; whether they meet your location isn't. You've given no constraint yet, so there is nothing to grade | `[grounded]` JD quote; your side silent | Question G1 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | The pay term is stated; your floor isn't, so whether it is met is open | `[grounded]` JD quote; your side silent | Question G1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years of data engineering at a B2B payroll company, in your own words; no dated CV or artifact seen | `[grounded]` your intake message | none; a CV with dates would firm it up |
| R4 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily" is specific on frequency, not on what was built | `[grounded]` your intake message | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | You built the dbt project on Snowflake, about 180 models; Snowflake is a cloud warehouse. Confirmed and specific, no inspectable proof yet, so expect a probe | `[grounded]` your intake message | A sanitized lineage graph or dbt docs page would raise to high |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | "Airflow for orchestration" says you used it; who designed the DAGs isn't stated, so claim use, not ownership | `[grounded]` your intake message | none |
| R7 | Experience with data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite, so ownership is clear; its coverage isn't stated | `[grounded]` your intake message | A sanitized suite listing would raise to high |
| R8 | BigQuery as the warehouse | important | adjacent | medium | transferability | Same dbt-on-a-cloud-warehouse pattern on a different engine. Limit: you have not used BigQuery. Warehouses differ in how they bill, partition and cluster, so engine-specific habits would be new | `[grounded]` your statement of no BigQuery use; `[inferred]` adjacency from Snowflake and dbt; `[generic]` that engines differ in those habits | Gap queue G4 |
| R9 | Ingestion from app and CRM | important | unclear | low | discovery | You described the dbt, Airflow and testing layers; nothing about source ingestion or CRM or app data | `[grounded]` silence in your account | Question G2 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | A test suite is related in kind, but nothing you said mentions agreements with analysts. A contract is an agreed schema or set of expectations between producer and consumer | `[grounded]` silence in your account; `[generic]` the definition | Question G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and pay terms (R1, R2; hard_gate) | hard_gate | The posting states both; you've stated no constraints | Either could end the application before fit matters | Not applicable: a gate is met or it isn't | Nothing to attach; your own confirmation | `[grounded]` JD terms and your silence |
| G2 | Ingestion from app and CRM (R9; important) | discovery | Pipeline work is clear, but sources and loading aren't described | The mandate leads with ingestion, so a clear answer could move this row to direct | Loading product or event data; syncing a CRM or billing system; API or file ingests you wrote or ran | A pipeline diagram or sanitized DAG listing | `[grounded]` your account; `[inferred]` the row is central because the JD names ingestion first |
| G3 | Data contracts (R10; important) | discovery | A test suite, but no stated agreements with consumers | The role says analysts depend on contracts | Schema or freshness agreements with analysts; breaking-change notices; documented expectations for a model | A contract doc, a schema-change policy, or test configs tied to a consumer | `[grounded]` your account |
| G4 | BigQuery (R8; important) | transferability | Snowflake and dbt at scale, no BigQuery | The role names BigQuery; the bridge helps only if its limit is stated | A small dbt-on-BigQuery project, even a personal one | A public repo or a short write-up of the build | `[inferred]` bridge from the Snowflake work; `[generic]` engines differ in cost and partitioning habits |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay stated and in line with the supplied market report | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The posted range spans the report's median and its top is above the IQR's upper bound, so seniority-pay mismatch looks unlikely | `[grounded]` posting and supplied report; `[generic]` the band is a pattern, not this employer's offer | Is the range for this level, and where in it would my experience sit? | noted |
| RR2 | Scope may exceed one domain; team and reporting line unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting: ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts our analysts depend on" | The role may be end-to-end ownership, possibly as the first or only data engineer, which would be wider than the one-domain scope the report calls typical | `[inferred]` from the JD's three areas against the report's typical-scope line | How many data engineers are on the team, who does this role report to, and who owns ingestion versus modelling today? | unresolved |
| RR3 | No stated success measures | unknown | — | "Build and run the pipelines…" (no outcomes given) | What counts as done in year one is open | `[grounded]` JD silence | What should be live or different six and twelve months in? | unresolved |
| RR4 | Equity terms absent | unknown | — | "plus equity" | Type, size and vesting are unstated, so its value to you can't be judged | `[grounded]` JD gives no terms | What is the equity: type, amount, vesting, and latest valuation? | unresolved |
| RR5 | Pasted posting and company text not checked against the live pages | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states." | The posting may have changed or closed since you copied it. Nothing I was given contradicts it | `[generic]` pattern for any pasted posting not re-checked, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Settle location and pay floor (G1) before investing effort | R1, R2 | `[grounded]` the two gate rows | pending your approval |
| A2 | Open the posting on the company's own careers page and confirm it is live before applying | RR5 | `[grounded]` RR5 | pending your approval |
| E1 | Summary line: "Six years of data engineering at a B2B payroll company; SQL and Python daily." | R3, R4; each clause is your sentence | `[grounded]` your intake message | `resume_edits_pending_approval` |
| E2 | Lead bullet: "Built the dbt project on Snowflake (about 180 models)" | R5 | `[grounded]` your sentence | `resume_edits_pending_approval` |
| E3 | Bullet: "Set up the Great Expectations test suite" | R7 | `[grounded]` your sentence | `resume_edits_pending_approval` |
| E4 | Bullet: "Used Airflow for orchestration" (use, not ownership, until you tell me more) | R6 | `[grounded]` your sentence | `resume_edits_pending_approval` |
| P1 | Positioning line for a note or screen: "My warehouse work has been Snowflake with dbt; I haven't used BigQuery." Don't describe it as BigQuery or data-contract experience | R8, R10 | `[grounded]` your statement of no BigQuery use | pending your approval |
| Q1 | Ask the questions of RR1–RR4 verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 0 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both page fetches (the careers page and the about page, as a check on your pasted text) were refused: fetch permission wasn't granted. It would have moved role reality's contradictions row and RR5 |
| 2. Role-family sweep | skipped | The Datawright report you supplied is in hand and fixes the market calibration line and RR1 |
| 3. Hiring manager's public footprint | n/a | The posting names no one, so there was no query to form |

## Upgrade menu

- A CV or dated role list moves R3 from your own account to something inspectable, and may show ingestion or contract work for R9 and R10.
- A sanitized dbt lineage graph or docs page, or a Great Expectations suite listing, moves R5 and R7 to `high`.
- Your location and pay floor close R1 and R2, and the decision likely simplifies to `go` or `no_go`.
- Answers to G2 and G3 resolve R9 and R10.
- The hiring manager's name (the posting gives none) would sharpen the scope read and which story the plan leads with.
- Page-fetch permission lets me check the live careers and about pages, closing RR5 and role reality's contradictions row.
- A deeper pass on Pellucid Learning (funding and leadership changes, hiring patterns, recent news; up to 5 more searches and 2 more fetches) runs if you say the word.

If you'd like, I can write all of this into a `tuesday-dossier.md` that the mock-interview module can read later.

G1 — Do the posting's location (remote in the US, or Denver) and pay ($148,000–$166,000 plus equity) work for you?

G2 — What have your pipelines ingested from (product events, a CRM, third-party APIs), and which of that did you build yourself?

G3 — Did you agree schemas, freshness or quality expectations with the analysts who used your models, and in what form?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.