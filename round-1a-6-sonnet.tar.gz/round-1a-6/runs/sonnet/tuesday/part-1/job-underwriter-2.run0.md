Working from your pasted JD and resume only, because web search was denied.

## Decision snapshot

**No, you're not wasting your time. R1a (titled PM years) is `absent`, which makes this role a stretch to win, but the rest of the map supports a targeted application. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R3, R4 · adjacent: R1b (PM-type work, not the title), R2 (shipped API or platform products) · unclear: R6b (own the roadmap) · absent: R1a (3+ years titled PM experience)
- `important` — adjacent: R5 (discovery with partners), R6a (specs and delivery with squads) · unclear: R7 (launches with sales and support), R8 (adoption metrics), R9 (agile delivery)

R1a — titled years, absent, and wording can't close it; R1b, R2 — credible bridges, limits named; R6b, R8 — the product-ownership evidence, waiting on an answer.

**Opportunity ledger.** The mandate reads concrete (RR3), but the employer can't be established from here (RR1), pay is unstated (RR2), and what the PM inherits of metrics is unknown (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer verifies as real and the posting as live (RR1); (2) you can confirm at least one example of owning what got built or measuring its use (R6b, R8); (3) you apply through a route where a person reads your R1b evidence (plan A1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B. Not verified (see Evidence status) | `[grounded]` JD header |
| Mandate | Own the roadmap for the partner-facing API platform; discovery with integration partners; specs and delivery with two engineering squads; adoption metrics; launches with sales and support | `[grounded]` JD |
| Scope read | A single product surface with two squads. The "3+ years" bar points to a mid-level post, not a lead or director role | `[inferred]` from the squad count and the years bar |
| Market calibration | Not available. The role-family search was refused, so there is no pay or scope band | — |
| Unknowns | Pay; decision rights; existing metrics and roadmap; whether the "3+ years" accepts equivalent work | `[grounded]` JD silent on each |
| Contradictions | None within the JD | `[grounded]` JD read |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | "3+ years product management experience (must-have)", as titled years | must_have | absent | none | capability | You state you have never held a PM title. A years requirement isn't a gate and is graded on fit, so this is a plain absence. Postings with a stated years minimum are often screened literally, which is a risk to name, not a gate | `[grounded]` your statement; `[generic]` on literal screening | No wording closes this. Closure is R1b's evidence, a role that credits it, or a referral (A1) |
| R1b | The same requirement read as the work, not the title (named inference) | must_have | adjacent | medium | transferability | Credible bridge: 7 years of API integrations, requirements documents, quarterly roadmap-input sessions, and coordination with product managers. Limit: all of it was on the vendor's delivery side, and prioritization and roadmap decisions are not claimed | `[grounded]` resume; `[inferred]` adjacency | See G1 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ client integrations of your company's REST APIs and wrote the internal integration playbook. Limit: the resume does not say you designed, published or launched an API product | `[grounded]` resume | See G2 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | "Comfortable in Postman and SQL and reading OpenAPI specs", plus integration architecture across the integrations. Self-reported, no inspectable artifact | `[grounded]` resume | Offer: a sanitized playbook excerpt or architecture diagram would raise this to `high` |
| R4 | Stakeholder management across engineering and customers | must_have | direct | medium | none | You coordinated your engineers, the client's engineers and product managers on custom builds. Sales is not mentioned, so it sits in R7 | `[grounded]` resume | none |
| R6b | Own the roadmap | must_have | unclear | low | discovery | You ran roadmap-input sessions for product, which is feeding a roadmap, not owning one. Nothing stated either way on ownership | `[grounded]` resume silence | See G1 |
| R5 | Run discovery with integration partners | important | adjacent | medium | transferability | Scoping workshops and quarterly client-feedback sessions. Limit: the feedback went to product, and the resume doesn't say you decided what got built | `[grounded]` resume | none |
| R6a | Write specs; drive delivery with two squads | important | adjacent | medium | transferability | Requirements documents and engineer coordination on client custom builds. Limit: these were client-build requirements, not a product backlog | `[grounded]` resume | none |
| R7 | Coordinate launches with sales and support | important | unclear | low | discovery | Go-lives are stated, but not any work with your own sales or support teams | `[grounded]` resume silence | See G3 |
| R8 | Define and track adoption metrics | important | unclear | low | discovery | SQL is stated; no adoption-metrics work is. An unconfirmed note suggests an adopted internal tool (see Evidence status) | `[grounded]` resume silence | See G1 |
| R9 | Agile delivery | important | unclear | low | discovery | The resume names no delivery method | `[grounded]` resume silence | Fold into G1's answer if natural |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning what gets built, and measuring use (R6b, R8; also R1b) | discovery | Roadmap input and requirements work, but no stated decision on what to build and no usage measurement | R6b is a `must_have` row and R8 an `important` one, and the role is about exactly this | The integration playbook (did others adopt it, and how did you know?); an internal tool or process that others used; a client-feedback theme you pushed that changed what product built | A usage count, a before/after, a roadmap item you can point to, the playbook itself | `[grounded]` resume silence; `[inferred]` that an answer would move R6b |
| G2 | Shipping an API or platform product (R2) | transferability | Heavy API integration work; no stated API design or launch | A `must_have` row at `adjacent`; a stronger bridge narrows the likeliest objection | A change to an API or its docs that you requested and followed through; partner-facing guides you wrote; a design review you joined | A request ticket, a doc you authored, a release note | `[grounded]` resume; `[generic]` that this is the likeliest objection |
| G3 | Launch work with your own sales and support (R7) | discovery | Client go-lives only | `important`, and a named duty in the role | Pre-sales scoping calls; handing a live integration to support; training account or sales staff | A handover doc or a launch checklist | `[grounded]` resume silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The entity may be too new or small for a footprint, the posting may be stale, or it may not represent a real hiring employer; none is more likely than another | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Compensation unstated | unknown | — | The posting gives no figure | The pay may sit above or below what you need; your floor isn't given | `[inferred]` from the posting's silence | What is the budgeted range for this role? | unresolved |
| RR3 | Concrete mandate and resources | positive_signal | — | "Own the roadmap for our partner-facing API platform … drive delivery with two engineering squads" | The scope, counterparts and squads are named | `[inferred]` from the JD's named elements | Which decisions does this role make alone, and which with squad leads and sales? | noted |
| RR4 | Metrics baseline unknown | unknown | — | "define and track adoption metrics" | The role may inherit existing metrics or have to build them | `[inferred]` from "define" against the JD's silence on targets | What adoption metrics exist today, and what is this role accountable for? | unresolved |

I'm going only on what you've shared, and I can get this wrong. RR1 is open because search didn't run, not because anything looked off. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Look for a referral or a direct note to the hiring team rather than a cold submission | Cold screens on a stated years minimum tend to be applied literally; see R1a | `[generic]` role-family pattern | pending your approval |
| A2 | Say plainly in the cover note or screen: "I haven't held a PM title," then lead with the work in R1b, R2 and R5 | This is your own statement. Dodging it invites the first follow-up question | `[grounded]` your statement; R1a | pending your approval |
| A3 | Ask the RR1–RR4 questions verbatim in the loop | The register doubles as interview prep | `[grounded]` register | pending your approval |
| A4 | Alongside this role, aim at platform, API or integration-product PM roles and at an internal move | Your strongest rows, R3 and R4, matter most where API fluency differentiates | `[generic]` role-family pattern, no search behind it | pending your approval |
| E1 | Resume line: "Led 30+ client integrations of our REST APIs end to end, from scoping workshops to go-live" | Traces to your own sentence | `[grounded]` resume | `resume_edits_pending_approval` |
| E2 | Resume line: "Ran quarterly sessions collecting client feedback as input to the product roadmap" | Traces to your "roadmap-input sessions collecting client feedback for product" | `[grounded]` resume | `resume_edits_pending_approval` |

If you decide to apply, resume-tailor can turn E1 and E2 into a full edit ledger.

## Evidence status

Verified: none yet. Unverified lead: earlier notes suggest you may have built an internal request-triage tool that support agents adopted. It is unconfirmed, and it only prompts the question in G1.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Quartzline logistics technology API platform careers" was refused. It would have settled RR1 and role reality's organization row |
| 2. Role-family sweep | unavailable | The search on PM scope and pay for API platform roles was refused. It would have given the market calibration and tested RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

If you want it, I can save all of this as a `tuesday-dossier.md` to carry forward.

## Upgrade menu

- Permission to run web search → RR1 settles one way or the other, and role reality gets a scope and pay band.
- Your pay floor, location and any other must-haves → the hard-gates line stops reading "checks unknown."
- A sanitized playbook excerpt or an integration architecture diagram → R3 to `high`.
- Answers to G1–G3 → R6b, R8, R2 and R7 move off `unclear` or `adjacent`, and the decision's second condition can close.
- The hiring manager's name → role reality's scope read, and which story the plan leads with.

**Questions**

G1 — Which product-like thing have you owned (a tool, a process or the playbook), and how did you know people used it?
G2 — When clients hit a limit in your company's APIs, did you ever drive a change to the API or its docs, and what happened?
G3 — What did your integration work involve with your own sales and support teams, before and after go-live?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.