Posting read and three public lookups done. Here's the assessment.

## Decision snapshot

**Yes, apply, but as a stretch. R6 (owning a forecast), R7a (billing data) and R7b (working with finance on revenue data) are the real gaps. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Bristol, two office days), R2 (£61,500–£67,000 base)
- `must_have` — direct: R3a, R4 · adjacent: R5 (SQL and spreadsheet modelling), R6 (Owning a forecast) · unclear: R3b (At a B2B software company), R7b (Working with finance on revenue data)
- `important` — direct: R8 · absent: R7a (Own billing data)

R6 — a credible bridge, its limit named; R7a — the clearest gap, confirmed by you; R7b (`low`) — one answer could move it.

**Opportunity ledger.** Quillfield matches the posting's description (RR5 only notes I haven't seen the role on its own site), and the stated pay sits inside the market range (RR3). The open unknowns are who this role leads (RR1), how much is bundled into one post (RR2) and what the share options are worth (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days), R2 (£61,500–£67,000 base plus share options); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 clear your own location and pay floor; (2) your answer on G3 shows some revenue-data work with finance (R7b), or you are comfortable going in with R7a and R7b still open; (3) the interview confirms what support exists for billing data and forecasting (RR1, RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants; founded 2018 in Bristol; 96 employees; £11M Series A closed April 2025 | `[grounded]` "About Quillfield" (quillfield.co.uk/about) |
| Mandate | Own the CRM and billing data; build the pipeline and renewal reporting that sales and finance run on; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Terms | Bristol, hybrid, two days a week in the office; £61,500–£67,000 plus share options | `[grounded]` posting |
| Hiring manager | Tamsin Achebe is listed publicly as Head of Revenue Operations at Quillfield, previously sales operations manager at Corvane Payments for four years. The recruiter's naming of her as hiring manager is your report. | `[grounded]` search result "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe), snippet only |
| Scope read | Four duties (CRM, billing data, reporting, forecast) in one post, with no team, reporting line or success measures stated | `[inferred]` from the posting's duty list and its silence |
| Market calibration | Ledgerline's 2026 UK pay guide gives a median base of £64,200 for this title in UK B2B software (interquartile range £57,800–£70,400, n=438). It is UK-wide, not Bristol-specific. The posting's range has a midpoint of £64,250, so it sits inside that range. This is a market band, not Quillfield's offer. | `[generic]` Ledgerline guide (snippet); `[grounded]` posting figures |
| Unknowns | Reporting line; team size; first-year outcomes; option terms; which CRM and billing system they use | `[grounded]` posting silent |
| Contradictions | None between the posting and the About page. The role was not seen on Quillfield's own careers page (RR5). | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol office, hybrid, two days a week | hard_gate | unclear | none | hard_gate | The posting sets the term. You haven't said where you're based or what commute you'll accept, so there is no stated constraint to grade or to test the role against. | `[grounded]` posting; your constraint not given | G1 |
| R2 | Base £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | The pay is stated. Your floor isn't, so whether it clears is not established. | `[grounded]` posting; your constraint not given | G2 |
| R3a | 4+ years in revenue operations, sales operations or a similar analytics role | must_have | direct | medium | none | You report 5 years in sales operations, the last 2 running revenue operations for the UK team. That meets the years and the function. It is self-reported with nothing inspected yet, and years of experience is graded as fit, not as a gate. | `[grounded]` your account | none |
| R3b | …at a B2B software company | must_have | unclear | low | discovery | You describe your employer as a B2B payments company. Whether that counts as a software company isn't established. Quillfield sells invoicing and payments software, so payments experience is likely relevant to the domain. | `[grounded]` your description; `[inferred]` domain relevance from the About page | G7 |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | You are Salesforce admin certified and rebuilt pipeline and renewal dashboards. The certification record hasn't been inspected, so the band stays `medium`. Expect a probe. | `[grounded]` your account | none |
| R5 | Strong SQL and spreadsheet modelling | must_have | adjacent | low | discovery | "SQL weekly, Excel daily" shows frequency of use, not strength or modelling. I took the lower band. | `[grounded]` your account | G6 |
| R6 | Experience owning a forecast; running the quarterly forecast with the CFO | must_have | adjacent | medium | transferability | You've said finance owned the company forecast. The adjacent work is the monthly pipeline review you run with your sales director and the pipeline dashboards. Limit: the company forecast number sat with finance, so the bridge covers pipeline inspection and not forecast ownership. | `[grounded]` your account | G4 |
| R7a | Own billing data ("own our CRM and billing data") | important | absent | none | capability | You've never worked on billing data, so there is no direct or adjacent evidence. The CRM half of that sentence is R4. | `[grounded]` your account | G5 |
| R7b | Experience working with finance on billing or revenue data | must_have | unclear | low | discovery | The posting says "billing or revenue data". You've ruled out billing. Whether your renewal reporting used revenue figures from finance hasn't been said, so I'm not asserting it. | `[grounded]` posting wording and your statement; `[inferred]` that renewal reporting may touch revenue figures | G3 |
| R8 | Build the pipeline and renewal reporting that sales and finance run on | important | direct | medium | none | You rebuilt your pipeline and renewal dashboards. Whether finance used them isn't stated, so I'm not claiming that audience. | `[grounded]` your account | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and office days (R1, hard_gate) | hard_gate | The posting requires two Bristol office days. Your base is unstated. | A gate you meet or don't; wording can't change it | n/a | n/a | `[grounded]` posting |
| G2 | Pay floor (R2, hard_gate) | hard_gate | Pay is stated; your floor is not | Same as G1 | n/a | n/a | `[grounded]` posting |
| G3 | Revenue data with finance (R7b, must_have) | discovery | You've ruled out billing data. Where your renewal figures came from isn't said. | The posting accepts "billing or revenue data", so this is the one route to a direct match on a must-have | Renewal dashboards built on contract or renewal values from finance; agreeing a metric definition with finance; reconciling pipeline totals to finance's numbers | A sanitized dashboard screenshot, a metric-definition page, a thread agreeing a definition | `[grounded]` posting wording; `[inferred]` that an answer could move R7b |
| G4 | Forecast bridge (R6, must_have) | transferability | Adjacent: the monthly pipeline review and dashboards. Limit: forecast ownership sat with finance. | R6 is a `must_have` at `adjacent`, and the bridge is what you can truthfully say | Preparing pipeline figures for forecast discussions; flagging slippage in the review | A sanitized pipeline-review pack | `[grounded]` your account |
| G5 | Billing data (R7a, important) | capability | No direct or adjacent evidence, and you've confirmed it | Carried as a material risk | n/a | n/a | `[grounded]` your account |
| G6 | SQL and modelling strength (R5, must_have) | discovery | Frequency of use is stated, not depth | The posting says "strong" | Queries joining several tables; a forecast or renewal model you built in a spreadsheet | A sanitized query or workbook | `[grounded]` your account |
| G7 | Software-company experience (R3b, must_have) | discovery | Your employer is described as a payments company | The posting says "B2B software company" | Whether the employer sells a software product that you supported | The employer's product page | `[grounded]` your description |

For G5 the closure path is to ask which billing system Quillfield uses (RR2's question) and read that system's published data documentation before any interview. That is a `[generic]` approach, not a claim about Quillfield.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Reporting line and team unstated | unknown | — | "Revenue Operations Lead" | The post may be a single-owner role or lead a team. The hiring manager's listed title is Head of Revenue Operations, so it may report to her. That is unconfirmed. | `[inferred]` from the posting's silence and the search result's title | Who does this role report to, and does it have direct reports now or planned? | unresolved |
| RR2 | Four duties bundled in one post | risk_signal | low | "own our CRM and billing data, build the pipeline and renewal reporting… and run the quarterly revenue forecast with the CFO" | CRM, billing data, reporting and the forecast may be separate specialisms folded into one title. Severity is `low` because the post sits at a company with a named RevOps head. | `[generic]` bundled-scope pattern, not a claim about this employer | Which of these four is the priority in the first six months, and what support exists on billing data? | unresolved |
| RR3 | Pay stated and inside the market range | positive_signal | — | "£61,500–£67,000 plus share options" | No seniority-pay mismatch is signalled against the Ledgerline range. That band is not Quillfield's offer. | `[grounded]` posting; `[generic]` band | Does the band flex with experience? | noted |
| RR4 | Share option terms unstated | unknown | — | "plus share options" | Their value depends on quantity, vesting and strike terms, none of which are given. | `[inferred]` from a one-phrase mention | How many options, on what vesting and strike terms? | unresolved |
| RR5 | Role not seen on Quillfield's own careers page | unknown | — | The posting as read on Tallyboard Jobs | The employer exists as described. The role may be live but not surfaced by my search. | `[grounded]` About page found, careers page not returned | Is this role listed on Quillfield's own careers page, and is Tamsin Achebe the hiring manager? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Settle R1 and R2 against your own location and pay floor before investing time | Both hard gates are unconfirmed | `[grounded]` map | pending your approval |
| A2 | Lead with your own words: two years running revenue operations for the UK team, the pipeline and renewal dashboards you rebuilt, and the monthly pipeline review you run with your sales director | R3a, R4, R8 | `[grounded]` your account | pending your approval |
| A3 | Say plainly that finance owned the forecast and that you haven't worked on billing data. Frame the bridge as the pipeline review, never as forecasting. | R6, R7a | `[grounded]` your account | pending your approval |
| A4 | Ask RR1, RR2 and RR4 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A5 | Ask the recruiter to confirm the role is on Quillfield's own site | RR5 | `[grounded]` RR5 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company Bristol" and found "About Quillfield" (quillfield.co.uk/about). It confirmed the employer exists as described, so no failed-attribution entry. No careers page came back, which is RR5. The posting itself was read from the link you gave (Tallyboard Jobs). |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary Bristol UK B2B software" and found "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). It moved the market calibration and RR3. |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield" and found "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). It moved role reality's hiring-manager row and RR1. |

I can save this as a `tuesday-dossier.md` if you want to carry it into later steps.

## Upgrade menu

- Your CV with dates raises R3a toward `high` and lets me check R4 and R8 for presentation gaps.
- The Salesforce certification record raises R4 to `high`.
- A sanitized dashboard screenshot or metric definition helps R8 and G3.
- A sanitized SQL query or spreadsheet model moves R5.
- Your location and pay floor close R1 and R2.
- The recruiter's answers on reporting line and option terms close RR1 and RR4. A careers-page link closes RR5.
- A deeper research pass on Quillfield (funding, leadership changes, public employee reports, recent news; up to 5 more searches and 2 more fetches) runs if you say the word.

## Questions

G1 — Can you do two days a week in the Bristol office from where you live now?

G2 — What base salary would you need to move, and does £61,500–£67,000 clear it?

G3 — Did any figures in your renewal or pipeline dashboards come from finance, such as contract values, renewal amounts or invoiced revenue? Did you work with finance to define or check them, and what exactly was your part?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.