I've read the playbook and the worked report format. Next I'm checking the remaining rules for the decision snapshot and questions, then I'll look up Brindlemoor and write the assessment.
## Decision snapshot

**Worth applying to, on one condition. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote, UK)
- `must_have` — direct: R2, R3, R4, R5, R6, R7
- `preferred` — direct: R8 · adjacent: R9 (Pet-insurance domain, `[inferred]` requirement)

R5 (`medium`): you built and maintained the model, but "monitor" in the JD isn't yet matched by anything you've said.

**Opportunity ledger.** The role is clearly defined, but the posting contradicts itself on location (RR1). Salary is not stated (RR2). The reporting line is stated (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the working arrangement is confirmed and works for you. The JD you pasted says fully remote, but the company's careers page says Leeds office four days a week (R1, RR1).

Your lack of pet-insurance experience and of people management does not decide this. The JD lists no management requirement, and it only asks for insurance experience as a plus.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurer with a UK careers site, hiring for a pet-insurance product | `[grounded]` careers page (brindlemoor.co.uk/careers/senior-pricing-analyst) |
| Mandate | Own pricing analytics for the pet-insurance product; reports to the Director of Pricing | `[grounded]` careers page and JD |
| Posting status | Live: "Accepting applications" | `[grounded]` careers page |
| Working pattern | JD: "Fully remote (UK)". Careers page: "Leeds office four days a week" | `[grounded]` both sources, which conflict |
| Requirements verified against the live page | The page text I could read doesn't list the requirements, so the years, SQL/Python, GLM and presenting items rest on your pasted JD only | `[grounded]` fetched page content |
| People management | Not listed as a requirement in the JD | `[grounded]` JD |
| Market calibration | UK senior pricing analyst base pay: median £58,400, interquartile range £52,100 to £64,900. This is a pattern, not Brindlemoor's offer | `[generic]` Pricewell 2026 survey |
| Hiring manager | Odile Varga, Director of Pricing. Previously head of pricing analytics at Calloway Re for six years. Spoke at the 2025 Insurance Pricing Forum on "Small Books, Loud Errors", about monitoring rating models in small books | `[grounded]` professional profile, public talk listing |
| Unknowns | Salary; whether the role has reports; the real working arrangement | — |
| Contradictions | Remote versus Leeds four days a week | `[grounded]` JD against careers page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | low | hard_gate | The JD and the careers page disagree, and you haven't told me your constraints on location | `[grounded]` JD and careers page quotes | RR1 question before investing in the process |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You state 5 years at a UK motor insurer, 2 as senior analyst. This is CV-level evidence, so `medium` | `[grounded]` your statement | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You say you use both daily. No inspectable artifact has been seen | `[grounded]` your statement | offer: a sanitized code sample would raise to `high` |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book | `[grounded]` your statement | none |
| R5 | Build and monitor rating models | must_have | direct | medium | discovery | "Built and maintained" is stated. "Monitor" is ambiguous, so I take the reading that claims less until you say what monitoring you did | `[grounded]` your statement; `[inferred]` the monitoring reading | gap queue G1 |
| R6 | Design and read price tests | must_have | direct | medium | none | You ran 14 price tests last year with the underwriting team. Whether you designed them or ran them to a design is not stated | `[grounded]` your statement | none |
| R7 | Present to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your statement | none |
| R8 | Insurance experience (a plus) | preferred | direct | medium | none | Five years in motor insurance | `[grounded]` your statement | none |
| R9 | Pet-insurance product knowledge (not listed in the JD) | preferred | adjacent | low | transferability | The role owns a pet product. The same rating and test discipline applies, but you have no pet experience. I treat this as a preferred item, not a requirement | `[inferred]` from the role's product focus | gap queue G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Monitoring of rating models (R5) | discovery | "Built and maintained" the young-driver GLM; nothing on how you tracked it after launch | The JD says "build and monitor", and monitoring is a likely interview probe | Tracking actual against expected, drift checks, periodic refits, a monitoring report you produced | A sanitized monitoring pack or one paragraph describing it | `[inferred]` from the JD wording against your statement |
| G2 | Pet domain (R9) | transferability | Motor pricing only | Preferred, not required; the likely objection is "new product line" | Any small or low-volume segment you priced, or a claims-driven rating factor you worked on | A short note on how you handled thin data in the young-driver book, if you did | `[inferred]` bridge from your motor work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working arrangement differs between sources | risk_signal | medium | JD: "Fully remote (UK)". Careers page: "Leeds office four days a week" | The pasted copy may be older, may come from a different listing, or may describe a policy that has since changed | `[inferred]` from the two quotes; no cause is established | Is this role fully remote, or office-based in Leeds four days a week? | unresolved |
| RR2 | Salary not stated in the JD you pasted | unknown | — | JD gives no figure | The offer may sit inside or outside the survey band | `[inferred]` against the `[generic]` band | What salary range is budgeted for this post? | unresolved |
| RR3 | Reporting line stated | positive_signal | — | "reports to the Director of Pricing" | The role has a named senior owner in pricing | `[grounded]` careers page | Does the role have any reports or a team? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the working arrangement with the recruiter or via Brindlemoor's own careers contact before you invest time | see RR1, R1 | `[grounded]` RR1 | pending your approval |
| E1 | Lead your application with three of your own statements: you built and maintained the GLM rating model for the young-driver book; you ran 14 price tests with the underwriting team last year; you present the quarterly pricing review to the head of underwriting | see R4, R6, R7 | `[grounded]` your statements | pending your approval |
| E2 | Describe the pet gap plainly as a new product line, with no claim of pet knowledge. Do not describe your motor work as pet-insurance work | see R9 | `[grounded]` your statement that you have no pet experience | pending your approval |
| P1 | Before any conversation with the Director of Pricing, read the abstract or slides of "Small Books, Loud Errors" if they are public, and prepare an honest account of your monitoring work (G1) | see G1 | `[grounded]` the talk exists; its content is unread | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech careers"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). Role reality: posting is live, and the location contradiction (R1, RR1) |
| 2. Role-family sweep | yes | Searched "Senior Pricing Analyst pet insurance UK remote salary", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). Market calibration `[generic]`, RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga). Role reality's hiring-manager row and action P1 |

## Dossier offer

I can write all of this up as a `tuesday-dossier.md` if you want a record to carry forward.

## Upgrade menu

- Your actual constraints on location, salary floor and schedule would settle R1 and RR2 against your terms.
- A sanitized code sample or model-monitoring pack would raise R3 and R5 to `high`.
- A link to the live posting you copied the JD from would show whether the remote wording comes from a different listing.
- Deeper company diligence (funding, hiring patterns, recent news) is available once: up to 5 more searches and 2 more fetches. Say the word and I'll run it.

## Questions

- **R1/RR1:** Would four days a week in Leeds work for you, or is fully remote a must?
- **R5/G1:** What monitoring did you do on the young-driver GLM after it went live, such as actual-versus-expected tracking or refit triggers?
- **RR2:** What is your salary floor for a move?

Answer in text, paste a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.