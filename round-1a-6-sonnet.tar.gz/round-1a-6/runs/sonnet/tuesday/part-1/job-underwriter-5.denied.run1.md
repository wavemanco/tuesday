**Yes, it's worth applying — on conditions. Status: `conditional_go`.** R1, R2, R3, R5 and R6 (all `must_have`) are `direct`. Two terms I can't check yet, R9 and R10, depend on constraints you haven't told me.

I couldn't open the live careers page: the fetch was refused, so everything below rests on the text you pasted.

**Fit ledger.**

- `hard_gate` — unclear: R9 (Remote US or Denver office), R10 (Pay $148,000–$166,000 plus equity)
- `must_have` — direct: R1, R2, R3, R5, R6
- `important` — adjacent: R4 (dbt-modelled warehouse in BigQuery) · unclear: R7 (Ingestion from app and CRM), R8 (Data contracts for analysts)

R4 (`medium`) — a Snowflake bridge, its limit named; R7 and R8 — your background is silent, so they are worth a question.

**Opportunity ledger.** Pay is stated and sits inside the market range you sent (RR4). The open points are the unchecked live posting (RR1), no named manager or team (RR2), unspecified equity (RR3) and a possibly wide scope (RR5).

- **Hard gates:** none failed; unconfirmed: R9 (Remote US or Denver office), R10 (Pay $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you meet the location and work-authorization terms — R9; (2) the band clears your pay floor — R10, RR4; (3) the BigQuery gap is framed as adjacent, never as BigQuery experience — R4; (4) the posting is confirmed live on the company's own site — RR1.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` your pasted about page; stated by the company, not independently checked |
| Mandate | Pipelines behind reporting: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` JD |
| Stack | dbt, BigQuery, Airflow or similar, data quality testing | `[grounded]` JD |
| Location | Remote (US) or Denver office | `[grounded]` JD |
| Scope read | Three areas under one title (ingestion, warehouse, contracts) is somewhat wider than the one-domain remit the report calls typical | `[inferred]` JD's three areas against the report's scope line; `[generic]` for the report's typical scope |
| Market calibration | Report: Series B–D senior data engineers, base median $151,000, IQR $139,000–$163,500, "senior" typically 5–8 years, no direct reports. The posting's $148,000 floor is $3,000 under the median; its $166,000 top is $2,500 over the top of the IQR; its 5+ years sits inside the 5–8 range. The report is a market pattern, never this employer's offer | `[generic]` report you supplied, no search run; `[grounded]` posting's figures |
| Unknowns | Hiring manager and team; reporting line; equity type and size; whether the posting is live | — |
| Contradictions | None between the two pasted pages; the live page was not checked | `[grounded]` pasted texts only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years at a B2B payroll company; specific, but no artifact inspected, so `medium` is the intake ceiling. Six years sits inside the 5–8 the report calls typical for "senior" | `[grounded]` your background; `[generic]` report's range | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily" shows use, not depth; the depth case rests on the dbt and pipeline work in R3 and R5 | `[grounded]` your statement | A code or model sample would raise it |
| R3 | dbt and a cloud warehouse | must_have | direct | medium | none | You built the dbt project, about 180 models, on Snowflake, a cloud warehouse; the JD names no specific warehouse in this requirement | `[grounded]` your statement; `[grounded]` JD wording | A sanitized project doc or model lineage screenshot would raise to `high` |
| R4 | A dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | dbt modelling carries over from Snowflake. Limit: you've never used BigQuery, so its SQL dialect and its cost and partitioning behavior are unexercised. Never present this as BigQuery experience | `[grounded]` your statement; `[generic]` that modelling skills transfer while warehouse specifics differ | See G1 |
| R5 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow named directly; scale (DAG count, run volume) not stated, so none is claimed | `[grounded]` your statement | none |
| R6 | Experience with data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite, so ownership is yours as stated; no artifact yet | `[grounded]` your statement | A sanitized expectation list would raise it |
| R7 | Ingestion from the app and CRM | important | unclear | low | discovery | Your sources at the payroll company aren't stated, so nothing here shows app-event or CRM ingestion | `[grounded]` background silent on sources | See G2 |
| R8 | Data contracts analysts depend on | important | unclear | low | discovery | Great Expectations tests are adjacent but not the same as agreed contracts with consumers; nothing stated either way | `[grounded]` background silent; `[inferred]` adjacency from the GE suite | See G3 |
| R9 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Confidence grades your own statement of the constraint, and none was given. Fit is `unclear` because your location and authorization are unstated | `[grounded]` JD; no candidate constraint supplied | The gate question below |
| R10 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | No pay floor was given, so I can't test the band against it; the band sits near the market median in role reality | `[grounded]` JD figure; no candidate floor supplied | The gate question below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R4, important) | transferability | Strong dbt-on-Snowflake record; no BigQuery use | The role runs on it, so this is the likeliest probe in a screen | Any GCP exposure; moving a model between warehouses; query cost tuning | A small dbt project run against BigQuery, if you choose to build one | `[inferred]` bridge from your dbt work; `[generic]` that screens probe the named warehouse |
| G2 | App and CRM ingestion (R7, important) | discovery | Your pipeline sources are unstated | A stated responsibility; one concrete example could move R7 to `direct` | Product-event or database extracts; CRM exports or API pulls; connector tools or custom Python extract jobs; payroll-system integrations | A pipeline diagram or DAG list, sanitized | `[grounded]` background silent on sources |
| G3 | Data contracts (R8, important) | discovery | A GE suite exists, with no stated agreement with consumers | The JD says analysts depend on these contracts | Schema or freshness agreements with upstream teams; expectations analysts relied on; communicating breaking changes | A sanitized expectation suite or dbt schema file | `[grounded]` background silent; `[inferred]` GE adjacency |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Live posting and employer account not independently checked | unknown | — | "Series C ($52M, February 2026)" | Facts rest on pasted text; the page may differ or be stale | `[inferred]` from the refused fetch | Can you point me at this role on your careers site? | unresolved |
| RR2 | No hiring manager or team named | unknown | — | "The posting names no hiring manager" | Reporting line and team size are unknown | `[grounded]` posting silent | Who would I report to, and who else is on the data team? | unresolved |
| RR3 | Equity unspecified | unknown | — | "plus equity" | The type and size may materially change total pay | `[grounded]` JD wording | What is the equity grant, type and vesting? | unresolved |
| RR4 | Pay stated and in line with the market range you sent | positive_signal | — | "$148,000–$166,000 plus equity" | The band is transparent and near the median | `[grounded]` JD; `[generic]` report band | Where in the band do offers for this level usually land? | noted |
| RR5 | Scope may exceed one domain | risk_signal | low | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts" | One title may cover three areas | `[inferred]` JD vs `[generic]` report scope | Which of these three areas is owned today, and by whom? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the resume with the dbt project (about 180 models, Snowflake) and the Great Expectations suite you set up | R3, R6 are the strongest rows | `[grounded]` your statements | `resume_edits_pending_approval` |
| P1 | Positioning line: "Six years of data engineering at a B2B payroll company; built our dbt project (about 180 models) on Snowflake, with Airflow orchestration and a Great Expectations test suite I set up." Do not say BigQuery or data contracts | Each clause traces to your own sentences | `[grounded]` your statements | pending your approval |
| Q1 | Ask the RR1–RR5 questions in the screen | The register doubles as interview prep | `[grounded]` register | pending your approval |
| A1 | Confirm remote or Denver terms and the equity detail before investing in a long loop | R9, R10, RR3 | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 0 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Tried to fetch pellucidlearning.com/careers/senior-data-engineer; the call was refused. It would have confirmed the posting is live and the pasted terms match (RR1, role reality) |
| 2. Role-family sweep | skipped | The pay report you pasted fixes the market calibration and RR4 |
| 3. Hiring manager's public footprint | n/a | No name was given, so no query could be formed |

I'd offer a dossier file, `tuesday-dossier.md`, if you want to carry this forward.

## Upgrade menu

- Your location, work authorization and pay floor → R9 and R10 close; the decision likely moves to `go`.
- A pipeline diagram or DAG list → R7, G2.
- A sanitized expectation suite or dbt schema file → R8 and R6.
- A sanitized dbt lineage screenshot → R3 to `high`.
- Your current or last base pay, if you wish → sets the band against what you'd actually move for.
- The live careers-page link or the hiring manager's name → RR1, RR2, and the scope read.
- A deeper research pass (leadership changes, funding follow-up, hiring patterns; up to 5 more searches and 2 more fetches): say the word and it runs.

**Questions**

R9 and R10 — Are you in the US and authorised to work there without sponsorship, and is $148,000–$166,000 plus equity at or above your floor?

G2 — Which sources did your payroll-company pipelines ingest from (product database, event stream, CRM, vendor files), and which parts did you build yourself?

G3 — Did analysts or other teams depend on your tests or schemas, and was there any agreement with upstream owners about what could change?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.