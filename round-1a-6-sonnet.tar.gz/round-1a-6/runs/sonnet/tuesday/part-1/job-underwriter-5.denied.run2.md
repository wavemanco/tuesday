# Job underwriting: Senior Data Engineer at Pellucid Learning

## Decision snapshot

**Yes, worth applying to, on conditions: R1 and R2, both hard gates, are unconfirmed, and I couldn't check the posting against the company's live page (RR1). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver location), R2 (Posted $148,000–$166,000 plus equity)
- `must_have`: direct: R3, R4, R5, R6, R7, R8
- `important`: adjacent: R9 (BigQuery warehouse) · unclear: R10 (Ingestion from app and CRM), R11 (Data contracts analysts depend on)

R9 — Snowflake-to-BigQuery bridge, its limit named; R10 — nothing in what you gave me; R11 — your tests sit near contracts and are not shown to be them.

**Opportunity ledger.** The stated pay is open and brackets the report's median (RR5). Scope, equity terms, whether the band varies by location, and whether the posting is live are all unconfirmed (RR1, RR2, RR3, RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver location), R2 (Posted $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm R1 and R2 against your own location and pay floor; (2) the role verifies as live on the company's own careers page (RR1); (3) the scope answer in RR2 is a role you would want; (4) the BigQuery bridge is told plainly as adjacent (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` the about-page text you pasted; I could not read the page myself, so the figures are the company's own and unchecked |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from app and CRM, a dbt-modelled warehouse in BigQuery, data contracts for analysts | `[grounded]` posting |
| Requirements stated | 5+ years, SQL and Python, dbt and a cloud warehouse, Airflow or similar, data quality testing | `[grounded]` posting |
| Working pattern | Remote (US) or Denver office | `[grounded]` posting |
| First-year outcomes, team size, reporting line | Not stated; no hiring manager is named | `[grounded]` posting silence |
| Scope read | Wider than one domain's pipelines: ingestion, modelling and contracts in one post. It names BigQuery in the mandate but asks only for "a cloud warehouse" in requirements, which suggests Snowflake experience is accepted | `[inferred]` from the posting's three layers against the report's one-domain norm |
| Market calibration | Senior at Series B–D: base median $151,000, interquartile range $139,000–$163,500, "Senior" typically 5–8 years, one domain, no direct reports. The posting's 5+ years and Series C stage fit that frame. The band runs from $3,000 under the median to $2,500 over the upper quartile | `[generic]` role-family band from the Datawright report your recruiter sent; `[grounded]` the posting's own figures |
| Contradictions | None between the pasted posting and pasted about text; the live careers page is unchecked | `[grounded]` pasted text only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you are or which option you'd take; nothing settles it | `[grounded]` no statement of your location | Question R1 below |
| R2 | Posted $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | You haven't given a pay floor, so the band can't be checked against one | `[grounded]` no floor stated | Question R2 below |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years at a B2B payroll company. Self-reported, nothing inspectable yet, so expect a probe. A length-of-experience requirement is graded on fit, not as a gate | `[grounded]` your background message | Share your CV with dates |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You state both daily. "Strong" is a judgement no artifact backs yet | `[grounded]` your background message | A code sample or sanitized repo would raise to `high` |
| R5 | dbt | must_have | direct | medium | none | You built the dbt project, about 180 models, on Snowflake. Specific, with no inspectable proof yet | `[grounded]` your background message | A dbt docs site or sanitized model list would raise to `high` |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake meets the requirement as the posting words it. BigQuery specifically is R9 | `[grounded]` your message and the posting's wording | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | You used Airflow for orchestration. No scale or scope stated | `[grounded]` your background message | DAG count or a sanitized DAG graph would raise to `high` |
| R8 | Experience with data quality testing | must_have | direct | medium | none | You set up your company's Great Expectations test suite | `[grounded]` your background message | A sanitized suite config would raise to `high` |
| R9 | BigQuery-based dbt warehouse | important | adjacent | medium | transferability | Same pattern, different engine: the dbt-on-Snowflake work carries over. Limit: you haven't used BigQuery, so its specifics are untested. Strengthener: a small dbt project run on BigQuery | `[grounded]` you have not used BigQuery; `[inferred]` the bridge from your dbt-on-Snowflake work | Gap G1 |
| R10 | Ingestion from the app and the CRM | important | unclear | low | discovery | Your background doesn't mention ingestion. Airflow work often includes it, so this is a lead only | `[grounded]` background silent; `[generic]` that orchestration work often includes ingestion | Gap G3 |
| R11 | Data contracts analysts depend on | important | unclear | low | discovery | Your dbt tests and Great Expectations suite are adjacent. Contracts are agreements with consumers, and nothing says you held any | `[inferred]` adjacency from the test suite you described | Gap G2, asked below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R9, important) | transferability | Snowflake and dbt carry over; no BigQuery use | It is the posting's named stack and the likeliest probe | A side project or sandbox running dbt on BigQuery; any BigQuery exposure at work, even as a consumer | A small public repo or dbt docs page on BigQuery | `[grounded]` no BigQuery use stated; `[generic]` that named-stack gaps get probed |
| G2 | Data contracts (R11, important) | discovery | Tests exist; no agreement with analysts is described | The posting names contracts as a core deliverable | Agreeing a schema, freshness or ownership expectation with analysts; alerts on a breaking upstream change; a documented model owner | A contract doc, a test config, an incident write-up | `[grounded]` background silent on contracts; `[inferred]` that resolving it firms up the bridge |
| G3 | App and CRM ingestion (R10, important) | discovery | No ingestion work described | Ingestion is the first thing the posting lists | Pulling from an app database or a CRM API into the warehouse; syncing customer or billing data | A pipeline diagram or sanitized DAG | `[grounded]` background silent; its question waits for a later turn |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting and company facts unchecked by me | unknown | — | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states. Founded 2016, Denver. 264 employees. Series C ($52M, February 2026)." | The posting could be stale, or differ from the live page; the figures are the company's own claims | `[grounded]` my one fetch was refused, so nothing was read; `[generic]` that postings go stale | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Scope may be wider than one domain | unknown | — | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts our analysts depend on" | One person may own ingestion, modelling and contracts, beyond the one-domain norm | `[inferred]` from the posting's three layers against the report's typical scope | How many data engineers are there today, who owns ingestion versus modelling, and who would I report to? | unresolved |
| RR3 | Equity unspecified | unknown | — | "plus equity" | Size, type and vesting are unstated, so its value can't be set | `[grounded]` posting names no terms | What is the equity grant for this level: type, amount, vesting, and the basis for its valuation? | unresolved |
| RR4 | Band may vary by location | unknown | — | "Remote (US) or our Denver office." | The band may apply to one option, both, or be adjusted for remote hires | `[generic]` pattern that some employers vary pay by location | Is the $148,000–$166,000 band the same for the remote and Denver options? | unresolved |
| RR5 | Pay is stated up front | positive_signal | — | "Salary $148,000–$166,000 plus equity." | The band is disclosed and brackets the report's $151,000 median | `[grounded]` posting and the report you provided | Where in the band would an offer land for my experience? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead your summary with "Built the dbt project on Snowflake, about 180 models, and set up the Great Expectations test suite" | R5, R8; both clauses are your own words | `[grounded]` your background message | `resume_edits_pending_approval` |
| E2 | Say plainly you haven't used BigQuery, and name Snowflake as the warehouse you ran dbt on | R9; candor is the stronger position when the limit will be probed | `[grounded]` R9 row | pending your approval |
| A1 | Ask your recruiter RR1 to RR4's questions before investing in the loop | Settles the posting, scope, equity and band | `[grounded]` register | pending your approval |
| A2 | Build a small dbt-on-BigQuery project as a work sample | Narrows R9's limit; worth it only if R1, R2 and RR1 clear | `[inferred]` from G1 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 0 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | I tried one fetch of the careers page (pellucidlearning.com/careers/senior-data-engineer); permission was refused and nothing was returned. It would have fed the contradictions row and RR1 |
| 2. Role-family sweep | skipped | The Datawright report you sent fixes the market calibration and the pay comparison, so a search could not change them |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there was no query to form |

If you'd like a record to carry forward, I can write this up as a `tuesday-dossier.md` whenever you ask.

## Upgrade menu

- Your CV with dates, a dbt docs site, a sanitized Great Expectations config or a code sample → R3, R4, R5, R7 and R8 can move from `medium` to `high`.
- Your answers on location and pay floor → R1 and R2 close, and the status can move to `go` or `no_go`.
- Your recruiter's answers on the live posting, team, equity and band by location → RR1 to RR4 close.
- A small public dbt-on-BigQuery project → G1 narrows R9's limit.
- The hiring manager's name → role reality's scope read, and which story to lead with for that reader.
- A deeper research pass on Pellucid Learning (funding, leadership changes, public staff reports; up to 5 more searches and 2 more fetches) — say the word and it runs.

R1 — Are you based in the US, and happy with either the remote or the Denver option?
R2 — What base salary is your floor for leaving your current role?
G2 — Have you ever agreed a schema, freshness or ownership expectation with the analysts who rely on your models? What did you own, who was involved, and what happened?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.