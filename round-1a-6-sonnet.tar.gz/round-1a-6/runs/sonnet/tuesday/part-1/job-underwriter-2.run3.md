Search permission wasn't granted, so this read uses only your text and the posting. The research accounting is below.

## Decision snapshot

**Am I wasting my time? Not on this role, but it's a stretch. R3, R4a and R7 land `direct`, and R1a, the titled PM years, is `absent`. Apply on conditions. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R3, R4a · adjacent: R1b (PM experience, product-adjacent work), R2a (API or platform products shipped, integration side) · unclear: R2b (API or platform products shipped, triage-tool lead), R4b (Stakeholders in sales), R5 (Agile delivery) · absent: R1a (PM experience, titled years)
- `important` — direct: R7 · adjacent: R6 (Own the roadmap), R8 (Specs and delivery with two squads) · unclear: R9 (Adoption metrics), R10 (Launches with sales and support)

R1a — titled years, nothing to reword; R1b (`medium`) — the bridge, its limit named; R2b — a lead only, waiting on your answer.

**Opportunity ledger.** The scope is concrete: a partner-facing API platform and two squads (RR4). The employer is unverified because the search was refused (RR1). Pay (RR2), authority over the roadmap (RR3) and how firmly the years bar is applied (RR5) are all unstated.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Quartzline and the posting verify as live and as described (RR1); (2) the years bar proves flexible for product-adjacent work (R1a, RR5); (3) your answers to G1 and G2 show you shipped or owned something, not only coordinated it (R2b, R6).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B, as the posting describes itself. Not independently checked. | `[grounded]` JD header |
| Mandate | Own the roadmap for the partner-facing API platform, run partner discovery, write specs, drive delivery with two squads, track adoption metrics, coordinate launches with sales and support | `[grounded]` JD |
| Years requirement | "3+ years product management experience (must-have)". It is a requirement graded on fit, not a legal or credential gate. | `[grounded]` JD quote; classification per the suite's gate definition |
| Scope read | A hands-on platform PM post working directly with engineers. It reads as the product side of the APIs you have spent seven years integrating. | `[inferred]` from the responsibilities list set against your integration work |
| First-90-days read | Learn the partner base and current roadmap, write a first spec with a squad, set a baseline adoption metric | `[inferred]` from the JD's metrics and spec duties; the JD states no 90-day outcomes |
| Market calibration | Not run, so no salary band. The JD states no pay. | `[grounded]` JD silent on pay; research refused |
| Unknowns | Pay; reporting line; decision rights over priorities; how strictly the years bar is applied; whether the posting is live | `[grounded]` JD silence |
| Contradictions | None inside the JD. Not checked against the careers page. | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years product management experience, titled years | must_have | absent | none | capability | You said you have never held a PM title. Rewording cannot create titled years. Whether it is screened literally is RR5. | `[grounded]` your statement; `[generic]` that titled-years bars are often screened literally | Carry as the main risk; ask RR5 |
| R1b | Same requirement, product-adjacent work | must_have | adjacent | medium | transferability | You ran quarterly roadmap-input sessions, wrote requirements documents and worked alongside PMs. That is input to a roadmap and specs, not ownership of prioritization or the outcome. | `[grounded]` CV, self-reported, nothing inspected yet | G2 |
| R2a | Shipped API or platform products, integration side | must_have | adjacent | medium | transferability | You delivered 30+ integrations of your vendor's REST APIs end to end and wrote the integration playbook. You used and deployed the API; you did not ship it as a product. | `[grounded]` CV | Playbook (sanitized) would raise to `high` |
| R2b | Same requirement, a product you built | must_have | unclear | low | discovery | The internal request-triage tool that support agents adopted is an unconfirmed memory lead, not evidence. It could count if you owned it. | `[inferred]` from a memory lead, unconfirmed | G1 |
| R3 | Technical fluency: API docs and schemas | must_have | direct | medium | none | Postman, SQL and OpenAPI reading, plus integration architecture work. Self-reported, no inspectable artifact. | `[grounded]` CV | none |
| R4a | Stakeholder management across engineering and customers | must_have | direct | medium | none | You coordinated your engineers, client engineers and product managers, and ran scoping, UAT and go-live with clients. | `[grounded]` CV | none |
| R4b | Stakeholder management with sales | must_have | unclear | none | discovery | Your sales contact is not mentioned anywhere in what you gave me. | `[grounded]` CV silence | G3 |
| R5 | Experience with agile delivery | must_have | unclear | low | discovery | You ran UAT and go-lives, but the delivery method is unstated and the engineers you coordinated were not your squad. | `[grounded]` CV silence on method | G4 |
| R6 | Own the roadmap | important | adjacent | medium | transferability | You fed client input into product's roadmap. Input is not ownership or prioritization. | `[grounded]` CV | G2 |
| R7 | Run discovery with integration partners | important | direct | medium | presentation | Quarterly feedback sessions with clients, whose engineers integrate your APIs. The CV frames them as roadmap input, not discovery. | `[grounded]` CV | E1 |
| R8 | Write specs and drive delivery with engineering squads | important | adjacent | medium | transferability | You wrote requirements documents and coordinated engineers on custom builds. You did not run a standing squad's backlog. | `[grounded]` CV | G2; E2 |
| R9 | Define and track adoption metrics | important | unclear | none | discovery | No metrics work is stated. The triage tool lead might connect, if confirmed. | `[grounded]` CV silence | G5 |
| R10 | Coordinate launches with sales and support | important | unclear | low | discovery | Client go-lives are launches of your work, not of a product release. Support contact is unstated. | `[grounded]` CV; `[inferred]` that go-lives are the nearest analogue | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Shipped product (R2b, must_have) | discovery | A possible triage tool, unconfirmed, with no ownership or outcomes known | The posting's shipped-product requirement is graded adjacent at best; confirmed ownership could move it | Defining what the tool did, deciding what went in, getting agents to adopt it, tracking its use | Screenshot, usage numbers, a one-pager | `[inferred]` from a memory lead; `[generic]` that hiring managers weigh shipped work |
| G2 | Roadmap ownership and delivery (R6, R8, R1b) | transferability | Input and coordination, not decision rights | R1a is `absent`, so this is the bridge a reader will test | Choosing which client request went into a custom build; sequencing work with engineers; saying no to a request | A requirements document or spec you wrote (sanitized) | `[grounded]` CV; `[generic]` that bridges get tested |
| G3 | Sales and support working (R4b, R10) | discovery | No contact with either is stated | Both are named in the JD | Joint calls with account executives; handing a go-live to support; writing launch notes | A launch or handover document | `[grounded]` CV silence |
| G4 | Agile delivery (R5) | discovery | Method unstated | A must-have that a CV line could settle | Sprint ceremonies with the engineers, a Kanban board, backlog grooming on custom builds | A board screenshot (sanitized) | `[grounded]` CV silence |
| G5 | Adoption metrics (R9) | discovery | None stated | An important responsibility | Tracking integration go-lives, time-to-live, support ticket volume | A dashboard or report | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The company may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer. Here the cause is that the search was refused, not a finding. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who I would be interviewing with? | unresolved |
| RR2 | Pay not stated | unknown | — | JD gives no salary | The figure may sit anywhere, and its withholding is itself worth asking about | `[grounded]` JD silence | What salary range is budgeted for this post? | unresolved |
| RR3 | Authority over the roadmap unstated | unknown | — | "Own the roadmap for our partner-facing API platform" | The role may carry accountability without clear say over priorities against sales and partner requests | `[inferred]` from the JD's silence on reporting line and decision rights | Which roadmap decisions does this role make alone, and who does it report to? | unresolved |
| RR4 | Concrete scope: a named platform and two squads | positive_signal | — | "drive delivery with two engineering squads" | The scope is defined and matches your integration background | `[grounded]` JD | How are the two squads split across the platform? | noted |
| RR5 | Firmness of the years bar | unknown | — | "3+ years product management experience (must-have)" | The bar may be screened literally, or flexed by the hiring manager for product-adjacent work | `[generic]` pattern for titled-years bars | How strictly is the 3+ years applied, and would you weigh years of API integration and roadmap-input work? | unresolved |

Going only on what you've shared and the posting text, I can get this wrong. Check the posting on Quartzline's own careers page before sending anything. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Move the roadmap-input sessions bullet to the top of your experience section, your wording unchanged | See R7, R6 | `[grounded]` CV | resume_edits_pending_approval |
| E2 | Give "Wrote the internal integration playbook the whole team uses" its own line, wording unchanged | See R2a, R8 | `[grounded]` CV | resume_edits_pending_approval |
| C1 | In the cover note, say plainly that you have not held a PM title, then point to the work behind R1b, R4a and R7 | A reader will see the missing title in seconds; stating it first is the honest framing | `[grounded]` your statement | pending your approval |
| A1 | Ask RR5 and RR1 of the recruiter before investing in the loop | They decide whether R1a ends the application | `[grounded]` register | pending your approval |
| A2 | Look for a route to the hiring manager before a cold application | Referrals are one way a missing title gets read in context | `[generic]` hiring pattern, not a claim about Quartzline | pending your approval |
| A3 | Run a parallel track on technical PM or product-owner roles on integration or platform teams, or an internal move at your current employer | Titled years are the bottleneck, not your integration skills | `[generic]` pivot pattern, not a claim about Quartzline | pending your approval |
| Q1 | Ask the RR2 to RR5 questions verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: a prior-conversation mention of an internal triage tool that support agents adopted. It is unconfirmed and used only to prompt G1.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Quartzline logistics technology Series B partner API platform"; the call was refused. It would have moved RR1 and the contradictions row. |
| 2. Role-family sweep | unavailable | Searched "Product Manager platform API role requirements salary B2B SaaS Series B technical product manager from solutions engineer"; the call was refused. It would have moved the market calibration and RR2. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |

I can save this as a `tuesday-dossier.md` if you want to carry it forward.

**Upgrade menu**
- Permission to search, or a link to the live posting or Quartzline's careers page → RR1 resolves or stays open on evidence, and role reality gets a pay band.
- The hiring manager's name → role reality's scope read and which story the plan leads with.
- A sanitized playbook, spec or requirements document → R2a and R8 can reach `high`.
- Screenshots or usage numbers for the triage tool → R2b and R9 firm up.
- Your pay floor, location and notice constraints → the hard-gates line stops reading "checks unknown".

**Questions**

G1 (also covers G5): Did you build, or own the decisions on, the request-triage tool? What did it do, who used it, and how did you know it worked?
G2: On a custom build, was there a case where you decided what went in or what was cut, and what happened?
G3: Have you worked with sales or support on a launch or handover, and what was your part?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.