I've run three searches. The company's own careers page lists this role as Leeds office four days a week, but the JD you pasted says fully remote. I'm fetching that page now to check the details.
# Job Underwriting Assessment: Senior Pricing Analyst, Brindlemoor

## Decision snapshot

**Probably yes on substance, but not decidable yet. R1, the working-pattern gate, is unconfirmed: `hold_pending_answers`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote (UK))
- `must_have`: direct: R2, R3, R4a, R5, R6 · unclear: R4b (Monitor rating models)
- `important`: direct: R7a · unclear: R7b (Recommendations for product)
- `preferred`: direct: R8

R1 and RR1 — your copy of the posting and the company's own page disagree on where the job is done; R4b (`low`) — "maintained" is not yet "monitored"; R7b — no product-side evidence stated yet.

**Opportunity ledger.** The role is live on the employer's own site and reports to the Director of Pricing (RR3). The working pattern conflicts between your copy and that page (RR1), and the salary is withheld (RR2).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Awaited answers:** whether you can work from Leeds four days a week (G1, R1); which working pattern the employer actually means (RR1); what you monitored on your model (G2, R4b).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD header; careers page lists the same role |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reporting line | Reports to the Director of Pricing; you named the hiring manager as Odile Varga, Director of Pricing | `[grounded]` careers page; the search result lists her under that title |
| Working pattern | Your JD copy says "Fully remote (UK)". The careers page says "Leeds office four days a week" | `[grounded]` both texts quoted |
| Management scope | The JD lists no people-management duty, so "never managed anyone" is not a stated requirement gap | `[grounded]` JD |
| Market calibration | Senior pricing analyst, UK insurers and insurtechs (n=612): median base £58,400, interquartile range £52,100 to £64,900. The posting states no figure, so this is the band to expect and never this employer's offer (RR2) | `[generic]` Pricewell 2026 survey, search-result snippet only; `[grounded]` JD for the absent figure |
| Hiring manager footprint | Spoke at the 2025 Insurance Pricing Forum on "Small Books, Loud Errors" (monitoring rating models in small books); previously head of pricing analytics at Calloway Re for six years | `[grounded]` search-result snippet, profile page not opened |
| Scope read | Her talk topic overlaps the JD's "monitor rating models", so monitoring is a plausible interview theme | `[inferred]` from the talk title set against the JD wording |
| Unknowns | Salary; first-year outcomes; team size; whether Leeds attendance is required | `[grounded]` absent from the JD and the careers page |
| Contradictions | Working pattern, as above | `[grounded]` JD copy against careers page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | The JD copy says remote and the careers page says Leeds four days a week. You have not told me whether remote is a requirement for you, so there is no stated constraint to grade | `[grounded]` JD copy, careers page, and your message's silence on location | G1; ask the employer via RR1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years of pricing analytics at a UK motor insurer, stated in prose and not yet probed. Years of experience is not a gate | `[grounded]` your background summary | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily", confirmed in prose, with no inspectable artifact yet | `[grounded]` your background summary | none |
| R4a | Build rating models, with GLM experience | must_have | direct | medium | none | You built the GLM rating model for the young-driver book. Limited inspectable proof, so expect a probe | `[grounded]` your background summary | offer: a sanitized model-spec or documentation extract would raise it to high |
| R4b | Monitor rating models | must_have | unclear | low | discovery | You say "maintained", which may include monitoring but does not say so. Low, not none, because there is a concrete thread to pull | `[inferred]` from "built and maintained" against the JD's "monitor" | G2 |
| R5 | Design and read price tests | must_have | direct | medium | none | "Ran 14 price tests last year with the underwriting team". "Ran" does not say who designed each test, so expect that probe | `[grounded]` your background summary | offer: a sanitized test readout would raise it to high |
| R6 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. The JD says "underwriting or actuarial" | `[grounded]` your background summary | none |
| R7a | Recommendations for underwriting | important | direct | medium | none | Price tests run with underwriting, and the quarterly review goes to its head | `[grounded]` your background summary | none |
| R7b | Recommendations for product | important | unclear | none | discovery | Nothing you described touches a product team | `[grounded]` your summary's silence on product | G3 |
| R8 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer. Pet insurance is new to you; pet rating factors typically differ from motor ones, so expect the question | `[grounded]` your background summary; `[generic]` for the factor difference | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Working pattern (R1, hard_gate) | hard_gate | Your copy says remote; the careers page says Leeds four days a week; your own constraint is unstated | A gate: wording cannot solve it, and it decides whether this role is open to you | Not applicable; this is a term you meet or do not | Your own statement, then the employer's confirmation | `[grounded]` two conflicting texts; `[inferred]` that it decides the status |
| G2 | Monitoring rating models (R4b, must_have) | discovery | "Maintained" the young-driver GLM, with no detail on what was watched | A must-have, and the hiring manager's published talk is on monitoring | Actual-versus-expected tracking, drift or lift reviews, refit triggers, alerts on thin segments, a post-launch review of a rate change | A sanitized monitoring pack, an actual-versus-expected report or a model-review note | `[grounded]` your wording; `[inferred]` that monitoring is a likely interview theme, from the talk title |
| G3 | Recommendations for product (R7b, important) | discovery | Underwriting recommendations are evidenced; product ones are not | An important row; the JD names product as an audience | A test result that changed a product feature, a quote-journey or cover-level change, a pricing proposal taken to a commercial or product group | A sanitized recommendation paper or readout deck | `[grounded]` your summary's silence on product |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern differs between sources (R1) | risk_signal | medium | JD copy: "Fully remote (UK)"; careers page: "Leeds office four days a week" | Your copy may come from an earlier version or another listing, or the page may be the current one; neither is more likely | `[grounded]` both quotes; hypothesis is possibilities side by side | Is this role fully remote, or based in the Leeds office four days a week? | unresolved |
| RR2 | Salary not stated | unknown | — | JD copy gives no figure; careers page snippet gives none | The pay may sit inside the survey band or outside it; the posting alone cannot say | `[grounded]` absence in both sources; band is `[generic]` | What salary range is budgeted for this role? | unresolved |
| RR3 | Role live and attributable to the employer | positive_signal | — | "Accepting applications. Senior Pricing Analyst… reports to the Director of Pricing" | The role exists on the employer's own site, and its reporting line matches your hiring manager's title | `[grounded]` careers page fetched | What are the first-year outcomes for this role? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask the recruiter or Odile Varga to confirm the working pattern before investing effort (RR1 verbatim) | R1 decides the status | `[grounded]` RR1 | pending your approval |
| A2 | Ask for the salary range early and set it against the band (RR2 verbatim) | RR2 is unresolved | `[grounded]` RR2 | pending your approval |
| P1 | Lead with the young-driver GLM rating model, the 14 price tests run with the underwriting team, and the quarterly review to the head of underwriting | Each traces to your own sentences and to R4a, R5, R6, R7a | `[grounded]` your background summary | pending your approval |
| P2 | Be ready to describe, in your own words, what maintaining the model involved, and say plainly where it stops short of monitoring if it does | The manager's published talk is on monitoring (G2) | `[inferred]` from the talk title; `[grounded]` your wording | pending your approval |
| P3 | Say plainly that pet insurance is new to you and point to the motor rating work. Don't offer "never managed anyone" as a gap; the JD asks for no line management | R8; Role reality, Management scope | `[grounded]` JD, your summary | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none. The background above is your prose summary, so every claim is a lead until you share an artifact.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech careers Senior Pricing Analyst". Fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). It confirmed the role is live and moved R1, RR1 and RR3. The page held no pay or other detail beyond the snippet |
| 2. Role-family sweep | yes | Searched "senior pricing analyst pet insurance UK salary", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). I read the snippet only, so I have the pay band and not scope norms. It moved the market calibration and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga), snippet only. It moved the Role reality footprint row, G2 and P2 |

Would you like me to save this as a `tuesday-dossier.md`? It's optional.

## Upgrade menu

- Your answer on Leeds four days a week → R1 and G1 close, and the status likely moves to `conditional_go` or `no_go`.
- The employer's confirmation of the working pattern → RR1 closes.
- The salary range, and your own pay floor if you have one → RR2 closes, and a pay hard-gate row can be checked against it.
- A sanitized monitoring pack, a model spec or a price-test readout → R4a, R4b and R5 can reach `high`.
- Your CV, which I have not seen → the rows can be checked against it, not only against your summary.
- Deeper research on Brindlemoor (funding, leadership changes, recent news; up to 5 more searches and 2 more fetches) → say the word and it runs.

Questions (answer in text, paste a voice transcript, attach a document, drop a link, or say skip):

- G1 — Is fully remote a requirement for you, or could you work from Leeds four days a week?
- G2 — What did maintaining the young-driver GLM involve in practice: what did you watch, how often, and what did you do when it drifted?
- G3 — Have you made recommendations beyond underwriting, to a product or commercial team, and what did you own?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.