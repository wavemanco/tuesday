# Job Underwriting Assessment: Senior Pricing Analyst at Brindlemoor

## Decision snapshot

**Yes, worth applying to, provided the working-pattern conflict (R1, RR1) settles in a way you can live with. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote (UK))
- `must_have`: direct: R2, R3, R4, R5a, R6, R7 · unclear: R5b (Monitor rating models)
- `important`: adjacent: R8 (Recommendations for underwriting and product)
- `preferred`: direct: R9 · adjacent: R10 (Pet-insurance product knowledge)

R1: the pasted JD and the careers page disagree on where the work is done; R5b: maintenance is stated, monitoring is not; R8 (`medium`): underwriting contact shown, product side not; R10: adjacent, limit named.

**Opportunity ledger.** The role's named outputs are concrete (RR4). Its terms conflict on where the work is done (RR1), the pasted JD gives no salary (RR2), and the team around the role is unspecified (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the working pattern settles into something you can do (R1, RR1); (2) pay clears your floor (RR2); (3) the pet-insurance bridge is presented as adjacent, never as pet experience (R10).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD header |
| Live posting | The role is on Brindlemoor's own careers page, marked "Accepting applications" | `[grounded]` fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst) |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Working pattern | The JD says "Fully remote (UK)". The careers page says "Leeds office four days a week" | `[grounded]` JD and the fetched careers page, which disagree |
| Reporting line | Reports to the Director of Pricing (Odile Varga) | `[grounded]` careers page; JD names her as hiring manager |
| People management | The JD lists no line-management requirement. Whether the role has direct reports is not stated | `[grounded]` JD silence |
| Hiring manager | Odile Varga, Director of Pricing. She spoke at the 2025 Insurance Pricing Forum ("Small Books, Loud Errors", on monitoring rating models in small books) and was previously head of pricing analytics at Calloway Re for six years | `[grounded]` search result "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga), snippet only, page not opened |
| Scope read | A single-product ownership role with four named kinds of output, which is ordinary scope for a senior analyst title | `[inferred]` from the JD's duty list against its silence on team size |
| Market calibration | UK senior pricing analysts at insurers and insurtechs: median base £58,400, interquartile range £52,100 to £64,900 (n=612, 2026 survey). This is the band to expect, never Brindlemoor's offer (RR2) | `[generic]` role-family sweep, "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey), snippet only |
| Unknowns | Salary; team size and sign-off rights; whether the role has reports; where the work is actually done | `[grounded]` JD and careers page silence |
| Contradictions | JD "Fully remote (UK)" against careers page "Leeds office four days a week" | `[grounded]` both quoted above |

## Evidence map

Your background below comes from your message, which counts as self-report. `medium` is the ceiling until you share something inspectable.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | You haven't stated a working-pattern constraint, so there is no claim to grade. The role's own terms conflict (RR1) | `[grounded]` JD line and fetched careers page | G1 question; RR1 question to the employer |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You state 5 years of pricing analytics at a UK motor insurer, 2 of them as senior analyst. It is specific, with no inspectable artifact yet | `[grounded]` your message | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You state daily use of both. The depth is not described | `[grounded]` your message | an artifact would raise it, see upgrade menu |
| R4 | GLM experience | must_have | direct | medium | none | You state that you built and maintained the GLM rating model for your young-driver book. Specific, but no artifact inspected | `[grounded]` your message | an artifact would raise it, see upgrade menu |
| R5a | Build rating models | must_have | direct | medium | none | Same GLM young-driver model as R4 | `[grounded]` your message | none |
| R5b | Monitor rating models | must_have | unclear | low | discovery | You said "maintained". Whether that included performance tracking, drift checks or review cycles is not stated. Resolved downward, not assumed | `[grounded]` the wording of your message | G2 question |
| R6 | Design and read price tests | must_have | direct | medium | none | You state running 14 price tests last year with the underwriting team | `[grounded]` your message | none |
| R7 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You state presenting the quarterly pricing review to the head of underwriting | `[grounded]` your message | none |
| R8 | Turn results into recommendations for underwriting and product | important | adjacent | medium | discovery | Underwriting contact is shown (R6, R7). Recommendations specifically, and any product-side work, are not stated | `[grounded]` your message; `[inferred]` that the quarterly review involved recommendations | G3 recovery row |
| R9 | Insurance experience, a plus | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your message | none |
| R10 | Pet-insurance product knowledge (not a stated requirement; derived from the product the JD names) | preferred | adjacent | medium | transferability | Nearest evidence is young-driver rating in motor. That exercised none of pet-specific rating, and you have not worked on pet insurance | `[inferred]` from the JD's product against your stated background | G4 bridge case |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Working pattern (R1, hard_gate) | hard_gate | Two sources disagree and your constraints are not stated | If you can't work four days a week in Leeds and the role is not remote, this is a failed gate | Not applicable: this turns on the terms, not on experience | Written confirmation from the employer of the working pattern | `[grounded]` JD and careers page; `[inferred]` that it could flip the status |
| G2 | Monitoring rating models (R5b, must_have) | discovery | "Maintained" is stated; monitoring is not | The hiring manager's published talk is on monitoring rating models, and the JD names monitoring as a duty | Tracking actual-versus-expected by factor; drift or stability checks; scheduled model reviews; a refit triggered by monitoring | A monitoring pack, a review pack, a model-performance dashboard screenshot | `[grounded]` JD duty and talk title; `[inferred]` that this is where an interviewer would probe |
| G3 | Recommendations to underwriting and product (R8, important) | discovery | Price tests with underwriting are stated; recommendations and product-side work are not | The JD ends its duty list on this | A test readout that led to a rate change; a recommendation accepted or rejected; work with a product or proposition team | A test readout or recommendation paper, sanitized | `[grounded]` JD; `[inferred]` from the gap in your message |
| G4 | Pet-insurance knowledge (R10, preferred) | transferability | Motor young-driver rating is the adjacent work | Preferred, but it is the likeliest objection to a candidate from outside pet | The bridge: segmentation on thin or volatile data in a young-driver book. The limit: no pet-specific factors, claims patterns or vet-cost inflation work. The strengthener: a short note on how you would approach a pet rating factor set | A one-page approach note, written by you | `[inferred]` bridge from your motor work; `[generic]` that this is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern differs between sources (see R1) | risk_signal | medium | JD: "Fully remote (UK)". Careers page: "Leeds office four days a week" | The pasted JD and the live page may reflect different versions of the posting, so which one governs is not established | `[inferred]` from the two quotes | Is this role fully remote, or based in the Leeds office four days a week? | unresolved |
| RR2 | Salary not stated in the pasted JD | unknown | — | The JD gives no figure | The figure may sit above or below the survey band in role reality, or Brindlemoor may share it later in the process | `[inferred]` from the JD's silence, against the `[generic]` band | What salary range is budgeted for this post? | unresolved |
| RR3 | Team, sign-off rights and reports unspecified | unknown | — | "Own pricing analytics for our pet-insurance product" | The role may sit alone or in a team, and rating-model sign-off may sit with pricing, underwriting or actuarial | `[inferred]` from the JD's silence on team and authority | Who else is in pricing, who signs off rating-model changes, and does this role have direct reports? | unresolved |
| RR4 | Named outputs | positive_signal | — | "build and monitor rating models, design and read price tests, and turn the results into recommendations" | The duties are concrete, which gives something specific to be measured against | `[grounded]` JD | How is success in the first year measured? | noted |

## Application plan

Each row is proposed and finalized only on your approval.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask the recruiter or Odile Varga's team to confirm the working pattern before you invest in an application | R1, RR1 | `[grounded]` RR1 | pending your approval |
| E1 | Lead your CV and any cover note with your own two statements: "built and maintained the GLM rating model for our young-driver book" and "ran 14 price tests last year with the underwriting team". Add nothing beyond what they say | R4, R5a, R6 | `[grounded]` your message | pending your approval |
| E2 | Present the pet gap as adjacent: say what carries over (rating on a young-driver book) and that pet-specific factors would be new to you. Don't claim pet-insurance experience | R10, G4 | `[grounded]` your message | pending your approval |
| P1 | Settle G2 before anything goes out. If your maintenance work did include monitoring, it is your most direct link to Odile Varga's published talk. If it didn't, don't claim it | R5b | `[grounded]` the talk title from the search snippet | pending your approval |
| Q1 | Put the RR1 to RR4 verification questions to the employer, verbatim, in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech careers Senior Pricing Analyst"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). It confirmed the role is live and surfaced the working-pattern contradiction: role reality's contradictions row, R1 and RR1 |
| 2. Role-family sweep | yes | Searched "senior pricing analyst insurance UK salary remote", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). It set the market calibration row and the band RR2 is read against |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga). It set role reality's hiring-manager row and plan rows P1 and G2's relevance |

I'd like to save this as a `tuesday-dossier.md` you can reuse or hand to another step later. Say so if you want it.

## Upgrade menu

- Your location, and whether four days a week in Leeds is workable: R1 and RR1 settle, and the status likely becomes `go` or `no_go`.
- Your pay floor: RR2 closes against the survey band.
- Your actual CV, or sanitized pricing artifacts: a rating-model spec or factor summary, a price-test readout and the quarterly pricing-review deck. Any of these could raise R3, R4, R5a, R6 and R7 toward `high`, and G2 and G3 depend on the review deck and test readouts.
- A deeper research pass on Brindlemoor (funding and leadership changes, hiring patterns, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

## Questions

G1 — The JD says fully remote in the UK, and the careers page says the Leeds office four days a week. Is four days a week in Leeds something you can do, or is fully remote a requirement for you?

G2 — When you maintained the young-driver GLM, did that include monitoring it, such as actual-versus-expected tracking, drift checks or scheduled reviews? Who ran those, and is there a pack you could share in sanitized form?

RR2 — What is your pay floor? The pasted JD gives no figure, so I can't check it against the role.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.