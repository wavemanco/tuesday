Web search was refused, so this runs on your pasted JD and resume only.

## Decision snapshot

**Not a waste of your time, but a stretch. R3 is `direct`, R1b and R2 are `adjacent`, and R1a (titled PM years) is `absent`. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R3 · adjacent: R1b (PM-type work), R2 (shipped API or platform products), R4 (stakeholders incl. sales) · unclear: R5 (agile delivery) · absent: R1a (3+ years titled PM)
- `important` — direct: R6 · adjacent: R7 (specs, drive squads), R9 (own the roadmap) · unclear: R8 (adoption metrics), R10 (launches with sales and support)

R1a — titled years absent, the screening risk; R1b and R2 — real adjacent work, limits named; R3 (`medium`) — strongest row, awaiting an artifact.

**Opportunity ledger.** The scope reads concrete (RR3). Four things are unchecked: the employer (RR1), pay (RR2), decision rights and who a first-time PM would report to (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the hiring side accepts adjacent work against the "3+ years" must-have, tested through a referral or recruiter conversation before you invest in a full application (R1a); (2) the employer is verified (RR1); (3) the API bridge is framed as adjacent, never as shipping an API product (R2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, ~150 people, Series B | `[grounded]` JD header; not independently checked |
| Mandate | Own the roadmap for the partner-facing API platform; discovery with integration partners; specs and delivery with two engineering squads; adoption metrics; launches with sales and support | `[grounded]` JD |
| Scope read | An individual-contributor PM post on one platform with two squads, not a leadership role | `[inferred]` from "two engineering squads" and the absence of any reports |
| Screening pattern | Postings that make "3+ years PM" a must-have are often screened on titles first, and roles in this family are commonly filled by people already titled PM | `[generic]` role-family pattern, not a claim about Quartzline |
| Market calibration | Not run; search was refused, so no pay or title band is offered | `[grounded]` search refused |
| Unknowns | Pay, reporting line, whether other PMs exist, who sets priorities between partner asks and sales asks | `[grounded]` JD is silent |
| Contradictions | None visible inside the JD | `[grounded]` JD text only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years of product management experience, as titled | must_have | absent | none | capability | You said you have never held a PM title, so the titled years do not exist. Wording cannot create them. The JD calls this a must-have, and a literal screen would catch it | `[grounded]` your statement; `[generic]` that titled-years must-haves are often screened literally | Closure path in plan A1 and A3; no wording fix |
| R1b | The same requirement, read as PM-type work | must_have | adjacent | medium | transferability | Roadmap-input sessions for product, requirements documents, and custom builds coordinated with PMs are PM-adjacent. The limit: you fed product decisions and did not make them. Confirmed prose only, nothing inspectable | `[grounded]` resume; limit `[inferred]` from "collecting client feedback for product" | G1 and G2 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | 30+ end-to-end integrations of your employer's REST APIs show deep use and implementation. The limit: no stated work on designing, versioning, documenting or launching an API as a product | `[grounded]` resume; limit `[inferred]` from silence | G4 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI reading and integration architecture across 30+ clients are the same skill the JD asks for. Medium only because nothing has been inspected | `[grounded]` resume | A sanitized playbook excerpt would raise it to `high` |
| R4 | Stakeholder management across engineering, sales, customers | must_have | adjacent | medium | discovery | Engineers on both sides and clients are covered. Sales and support are not mentioned, so the reading takes the lower fit | `[grounded]` resume; sales and support are `[grounded]` silence | Covered by the R10 question in G3 |
| R5 | Agile delivery experience | must_have | unclear | low | discovery | The resume says you coordinated engineers but says nothing of sprints, backlogs or release cadence | `[grounded]` resume silence | G3 |
| R6 | Discovery with integration partners | important | direct | medium | presentation | Scoping workshops and quarterly client roadmap-input sessions are discovery with external technical users. The resume does not name it as discovery | `[grounded]` resume | E1 |
| R7 | Write specs and drive delivery with two squads | important | adjacent | medium | transferability | Requirements documents and integration architecture are spec-like. Whether engineers built from your documents, and who owned delivery, is not stated | `[grounded]` resume; gap `[inferred]` | G2 |
| R8 | Define and track adoption metrics | important | unclear | low | discovery | Nothing in the resume. A recalled item from an earlier conversation, a request-triage tool agents adopted, is unconfirmed and only prompts a question | `[grounded]` resume silence; `memory_lead` unconfirmed | G1 |
| R9 | Own the roadmap | important | adjacent | medium | transferability | Collecting client input for product is the input side of roadmapping. Ownership of priorities is a different kind of work, and no evidence shows it | `[grounded]` resume; limit `[inferred]` | G2 |
| R10 | Coordinate launches with sales and support | important | unclear | low | discovery | Go-lives were client-facing, but the resume does not mention sales or support coordination | `[grounded]` resume silence | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Adoption and ownership of something you built (R8, R1b) | discovery | The resume has no metric or built-product line; one unconfirmed lead about an internal triage tool | R8 is blank, and a confirmed tool would be the nearest thing to PM-owned work on the page | A tool, template or process others adopted; a usage count or time saved; a decision about what it did or skipped | A screenshot, usage numbers, a one-page description, the support team's feedback | `[grounded]` resume silence; `[inferred]` that this could move R1b and R8 |
| G2 | Deciding what got built (R7, R9) | discovery | Requirements documents exist, but not who decided scope or priority | This is the line between feeding product and acting as product | Choosing between two client asks; cutting scope on a custom build; a spec engineers built from | A requirements doc or a roadmap-input summary, sanitized | `[inferred]` from the resume wording |
| G3 | Agile delivery and sales/support launches (R5, R10) | discovery | No sprint, backlog or launch-comms evidence | Both are named requirements and are unestablished | Attending sprint planning or refinement; a go-live that involved sales or support | A launch checklist or runbook | `[grounded]` resume silence |
| G4 | API as a product (R2) | transferability | Strong implementation experience; no design, versioning or docs ownership | It is the second-largest bridge the posting asks you to cross | Feeding API design changes back to product; maintaining docs or a changelog | A feedback ticket, a docs contribution, a playbook section on API pitfalls | `[inferred]` bridge from the resume |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not checked | unknown | — | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | Nothing about the company was verified because search was refused | `[grounded]` search refused | Can you point me to this role on your careers page, and who would I interview with? | unresolved |
| RR2 | Pay not stated in what was pasted | unknown | — | no compensation in the pasted JD | A first PM title can pay less than a senior implementation lead; the band is unknown | `[generic]` pattern for career switches, not a claim about Quartzline | What is the budgeted range for this role? | unresolved |
| RR3 | Concrete scope | positive_signal | — | "two engineering squads; define and track adoption metrics; coordinate launches" | Responsibilities and success measures are named | `[grounded]` JD | What does a successful first year look like for this role? | noted |
| RR4 | Decision rights and support for a first-time PM | unknown | — | "Own the roadmap" | Sales asks and partner asks may compete, and the JD does not say who settles it | `[inferred]` from the JD's silence | Who decides priority when sales and partners disagree, and who would I report to? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Keep your existing lines and move these to the top, in your own words: "Led 30+ client integrations of our REST APIs end to end"; "Ran quarterly roadmap-input sessions collecting client feedback for product"; "Wrote the internal integration playbook the whole team uses". Do not add "product manager", "owned the roadmap" or "shipped an API" | See R6, R1b, R3. Each line is quoted from your resume | `[grounded]` resume | `resume_edits_pending_approval` |
| A1 | Go through a person: a referral or a direct note to the hiring manager before a cold application | A human can weigh adjacent work against a literal screen | `[generic]` role-family pattern | pending your approval |
| A2 | Ask RR2 and RR4 in the first call, verbatim | The register doubles as your interview preparation | `[grounded]` register | pending your approval |
| A3 | Run a parallel track at roles where the experience bar is lower, such as technical, integration or platform PM, or product-ops roles at API-first companies | R1a cannot be closed by wording | `[generic]` role-family pattern | pending your approval |
| W1 | A two-page spec for an improvement to your own vendor's partner onboarding or API docs, using no confidential detail | It is an inspectable artifact for R7 and R2 | `[inferred]` from the gap queue | pending your approval |

resume-tailor can do the line-by-line edits once you pick a target.

## Evidence status

Verified: none yet. Unverified lead: a request-triage tool agents adopted, from agent memory, unconfirmed; it only prompts G1.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search refused. It would have moved RR1 and whether the posting is live |
| 2. Role-family sweep | unavailable | Search refused. It would have moved market calibration and RR2 |
| 3. Hiring manager's public footprint | n/a | No name given, so no query could be formed |

## Upgrade menu

- Permission to search: runs targets 1 and 2, which settles RR1 and adds a pay and title band.
- Answers to G1 and G2: could move R8, R7, R9 and R1b, and with them the strength of the case in plan A1.
- A sanitized playbook excerpt or requirements doc: R3 to `high`, R7 evidence.
- Your pay floor and location limits: turns the hard-gates line from unknown to checked.
- The hiring manager's name: scope read and positioning.

I can also emit this as `tuesday-dossier.md` if you want it kept for later turns.

**Questions**

- G1 — Did you build or lead any tool, template or process that others adopted, such as a request-triage tool? What did you own, who used it, and how did you know it worked?
- G2 — Have you ever decided what got built or cut on a custom build, or written a spec that engineers then built from? What was yours and what was someone else's?
- C1 — Do you have a pay floor or location limit that this role would have to meet?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.