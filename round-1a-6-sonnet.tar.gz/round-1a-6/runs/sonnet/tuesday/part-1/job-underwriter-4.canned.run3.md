## Decision snapshot

**Yes, probably go for it, once the working pattern is settled. Status: `conditional_go`.** Your fit is strong on the must-have requirements. R1, the working-pattern gate, is unconfirmed because the JD and the company's careers page disagree.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK) working pattern)
- `must_have` — direct: R2, R3, R4, R5a, R6, R7 · adjacent: R8 (Recommendations for underwriting and product) · unclear: R5b (Monitoring rating models)
- `preferred` — direct: R9 · adjacent: R10 (Pet-insurance domain knowledge)

R5b — maintaining a model is not stated as monitoring it, waiting on your answer; R8 — recommendation work is plausible but the product side is unstated; R10 — a credible bridge, its limit named.

**Opportunity ledger.** The post is live on the employer's own site, but its working-pattern terms conflict with your JD (RR1) and no pay is stated (RR2). Team size, any direct reports and product maturity are unknown (RR3, RR4). The title and reporting line check out against the careers page (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK) working pattern); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the working pattern is confirmed workable for you (R1, RR1); (2) the pay is confirmed against your floor (RR2).
- **What would turn this to `no_go`:** the post is confirmed as Leeds four days a week and you need remote (R1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, described in your JD as an insurtech; the post is listed on brindlemoor.co.uk. Its stage and size are not established: a general search on the company returned nothing | `[grounded]` JD header, careers page fetched; `[grounded]` search returned no results |
| Mandate | Own pricing analytics for the pet-insurance product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD, careers page |
| Working pattern | The JD says "Fully remote (UK)". The careers page says "Leeds office four days a week". The two sources conflict, and neither is shown to be current | `[grounded]` both sources |
| Reports to | Director of Pricing (Odile Varga) | `[grounded]` careers page and your message |
| Direct reports | None named. The JD states no line-management duty | `[grounded]` JD silence |
| Scope read | A single-product ownership role at senior-analyst level. Nothing in the JD makes people management part of it | `[inferred]` from the mandate wording and the JD's silence on reports |
| Hiring manager | Spoke at the 2025 Insurance Pricing Forum on "Small Books, Loud Errors" (monitoring rating models in small books). Previously head of pricing analytics at Calloway Re for six years | `[grounded]` search-result snippet; the page itself was not fetched |
| Market calibration | UK insurers and insurtechs, senior pricing analyst: median base £58,400, interquartile range £52,100–£64,900. The posting states no salary, so this is the band to expect, not Brindlemoor's offer (RR2) | `[generic]` one survey (Pricewell 2026, n=612), seen as a search snippet; `[grounded]` JD silence on pay |
| First 90 days | Not stated | `[grounded]` JD silence |
| Unknowns | Working pattern; salary; team size and any reports; how mature the pet book is; whether recommendations go to a product owner | — |
| Contradictions | JD "Fully remote (UK)" against careers page "Leeds office four days a week" | `[grounded]` both sources |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) working pattern | hard_gate | unclear | none | hard_gate | The JD and the careers page disagree. You haven't stated a location constraint, so there is nothing to grade. Confidence grades your statement of a constraint, not whether the role meets it | `[grounded]` JD against careers page | Ask G1; verify via RR1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You state 5 years of pricing analytics at a UK motor insurer. That is self-reported with no inspectable artifact yet. A length-of-experience requirement is not a gate | `[grounded]` your message | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You state daily use of both. The strength is not shown by an artifact | `[grounded]` your message | Optional: a sanitised notebook or query would raise this to `high` |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. Specific, but no inspectable proof | `[grounded]` your message | Optional: sanitised model documentation would raise this to `high` |
| R5a | Build rating models | must_have | direct | medium | none | The same GLM build supports this row | `[grounded]` your message | none |
| R5b | Monitor rating models | must_have | unclear | low | discovery | You said "maintained", which does not say what was tracked or how often. Where a sentence admits two readings, the reading that claims less is taken | `[grounded]` your wording; `[inferred]` that "maintained" may include monitoring | Ask G2 |
| R6 | Design and read price tests | must_have | direct | medium | none | You ran 14 price tests last year with the underwriting team. "Ran" does not say whether you designed them or read the results, so expect a probe on which parts were yours | `[grounded]` your message | Be ready to say which parts were yours |
| R7 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your message | none |
| R8 | Turn results into recommendations for underwriting and product | must_have | adjacent | low | discovery | The review presentations and test work with underwriting are adjacent. Nothing says you made recommendations, or that product was a stakeholder | `[grounded]` your message; the gap is `[inferred]` | Ask G3 |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your message | none |
| R10 | Pet-insurance domain knowledge (inferred from "our pet-insurance product") | preferred | adjacent | low | transferability | Personal-lines GLM pricing is a credible bridge. Limit: you have no pet pricing, and pet-specific rating factors are untested for you. The band takes the lower of motor evidence (`medium`) and pet evidence (`none`) | `[grounded]` your message; `[generic]` that pet pricing has its own rating factors | See G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Working pattern (R1, hard_gate) | hard_gate | Two sources, two answers. You haven't said what you can accept | A gate: if the role is Leeds four days a week and you need remote, the status becomes `no_go` | Not applicable: a term, not experience | The recruiter's or Odile's written confirmation of the current pattern | `[grounded]` both sources conflict |
| G2 | Monitoring rating models (R5b, must_have) | discovery | "Maintained" is stated. What you tracked, how often and what you did with it is not | A must-have. Odile's published talk was on monitoring rating models, so this is the row most worth firming up | Actual-versus-expected checks by segment; drift or stability checks on rating factors; a recurring performance report to underwriting; triggering a refit or a rate change | A sanitised monitoring report, dashboard screenshot or model-review note | `[grounded]` your wording; `[inferred]` that this row matters most to this hiring manager, from her talk topic |
| G3 | Recommendations to underwriting and product (R8, must_have) | discovery | Presenting and testing are stated, but not what you recommended or to whom | A must-have, and "recommendations for underwriting and product" is part of the JD's mandate | A test readout ending in a roll-out, stop or rework call; a pricing-review paper with proposed rate actions; a product owner for the young-driver proposition who used your results | A sanitised test readout or review deck | `[grounded]` your message |
| G4 | Pet-insurance knowledge (R10, preferred) | transferability | Motor GLM work carries over as method. Pet rating is untested for you | Preferred only, but it is the first thing you will be asked about | Frequency and severity modelling on a personal-lines book; any exposure to claims-cost inflation work | None needed now; a short written bridge case (see plan A4) | `[inferred]` bridge from your motor work; `[generic]` that pet pricing differs |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern differs between sources (R1) | risk_signal | low | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | The JD copy may be out of date, or the role may have changed. Kept at `low` because neither source is shown to be current | `[inferred]` from the two sources disagreeing | Is this role fully remote, or is it Leeds four days a week, and has that changed recently? | unresolved |
| RR2 | Salary not stated | unknown | — | The JD as given lists no salary | The figure may sit inside or outside the band in role reality. Your pay floor was not given, so no comparison is possible yet | `[inferred]` from silence, set against the `[generic]` band | What is the budgeted salary range for this post? | unresolved |
| RR3 | Team size and reports not stated | unknown | — | "Own pricing analytics for our pet-insurance product" | The post may be a solo owner or may carry a junior analyst. The JD names no reports | `[inferred]` from the JD's silence | Does this role have direct reports now or in its first year, and how big is the pricing team? | unresolved |
| RR4 | Employer footprint thin | unknown | — | JD header: "Brindlemoor (insurtech)" | The company may be small or new. Its own careers page does attribute the post to it | `[generic]` pattern for small employers, not a claim about this one | How long has the pet product been live, and how large is its book? | unresolved |
| RR5 | Posting live, title and reporting line match | positive_signal | — | "Accepting applications ... reports to the Director of Pricing" | The role is real and the reporting line is consistent with your JD | `[grounded]` careers page fetched | Who would you work with day to day? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Settle the working pattern with the recruiter or Odile before investing in the application | See R1, RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Positioning, lead with three things you stated: the GLM rating model you built and maintained for the young-driver book; the 14 price tests you ran with underwriting last year; the quarterly pricing review you present to the head of underwriting | See R4, R6, R7 | `[grounded]` your message | pending your approval |
| A3 | Prepare specifics on what you tracked on the young-driver model, using only what you actually did | See R5b, G2 | `[grounded]` the row; `[inferred]` link to her talk topic | pending your approval |
| A4 | Pet bridge line: "My pricing work has been UK motor; I haven't worked on pet insurance. What I'd bring is GLM rating-model work and price testing." | See R10 | `[grounded]` your message | pending your approval |
| A5 | Management: if asked, say plainly that you haven't managed anyone. The JD states no line-management duty, but ask RR3 to confirm | See RR3 | `[grounded]` JD silence | pending your approval |
| A6 | Ask RR1–RR4's questions verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Everything about you above comes from your message and stands as a lead, not proof. I've assumed your stage is evaluating.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech" (no results) and "Brindlemoor careers Senior Pricing Analyst"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). It confirms the post is live and matches on title and reporting line (RR5). It contradicts the JD's working pattern (R1, RR1). The company's stage and size stayed unestablished (RR4) |
| 2. Role-family sweep | yes | Searched "senior pricing analyst pet insurance UK salary remote", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey), seen as a snippet only. It moved the market calibration band (RR2). It did not cover scope or remote norms |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga), seen as a snippet only. It moved the scope read and the positioning in A3 |

## Upgrade menu

- Your location and pay non-negotiables: R1 settles, and RR2 gets compared against your floor.
- A sanitised model-monitoring report or model documentation: R5b and R4 go up a band.
- A sanitised price-test readout: R6 and R8 go up a band.
- Your CV with dates: R2 and R9 get checked against the document, and I can check A2's wording against it.
- A deeper research pass on Brindlemoor (funding, leadership changes, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.
- If you go ahead, resume-tailor can tailor your CV to this role.

If it would help, I can save all this as a `tuesday-dossier.md` for later use.

G1 — Is a fully remote role a requirement for you, or is Leeds four days a week workable?
G2 — After the young-driver model went live, what did you personally track, how often, and did you act on anything it showed?
G3 — Is there a price test where your readout fed into a decision? What did you recommend, to whom, and what was decided?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.