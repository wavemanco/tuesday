## Decision snapshot

**Yes, apply. On what you've given me you're a fit for the core of the role: R1, R2, R3, R4 and R5 are all `direct`. Status: `conditional_go`.**

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4, R5 · adjacent: R6 (Define and maintain the metrics layer)
- `important`: direct: R7a · unclear: R7b (Partner with clinicians), R8 (Mentor two junior analysts)
- `preferred`: adjacent: R9 (Healthcare data experience, HIPAA)

R6, R8 and R9 are the rows to firm up. R6 (`low`): governed dashboards sit near it, but shared metric definitions aren't in what you've told me. R8: nothing stated on mentoring. R9 (`medium`): a credible bridge, its limit named.

**Opportunity ledger.** The employer isn't established from attributable sources, because my searches were not permitted to run (RR1). Pay and location are unstated (RR2), and whether a metrics layer already exists is unknown (RR3). One entry runs the other way: the responsibilities and team are concrete (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. The employer and live posting verify (RR1).
  2. Pay and location terms fit your own constraints, which I haven't been given (RR2, C1 below).
  3. You can show some shared-definitions work for R6, and some mentoring for R8.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up of about 400 people, Series C | `[grounded]` JD header as pasted; not independently verified |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, Looker dashboards, partnering with PMs and clinicians, mentoring two junior analysts | `[grounded]` JD |
| Scope read | A senior individual-contributor post with light mentoring (two named juniors), not a people-management post | `[inferred]` from "mentor two junior analysts" and no stated reports or budget |
| Market calibration | Not available: the role-family search did not run, and the posting states no pay | `[grounded]` JD silent on pay; no search result used |
| Unknowns | Pay; location and remote terms; whether a metrics layer exists; experiment volume in the app; who the clinicians are and how they work with analytics | `[grounded]` JD silent on each |
| Contradictions | None visible within the JD alone | `[grounded]` JD as pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | You state 6 years of product analytics at a ~2M-subscriber consumer-subscription company. It is intake prose with no inspectable artifact yet, so `medium`. The domain differs (meal-kit versus care navigation), but the JD names no domain | `[grounded]` your message | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on a Snowflake warehouse is confirmed. "Expert" is a level and your claim shows daily use, not a level. Roles like this often test SQL in a screen | `[grounded]` your message; `[generic]` on the screen | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | You designed and ran the program, with 30+ A/B tests a year, including the pricing test behind an 11% retention lift. The JD doesn't quantify "scale", and your base is ~2M subscribers | `[grounded]` your message | A sanitized experiment readout would raise this to `high` |
| R4 | Looker or a similar BI tool | must_have | direct | medium | none | You built the company's Looker instance from scratch, with 40+ governed dashboards. No inspectable artifact yet | `[grounded]` your message | Dashboard screenshots or a LookML or explore sample would raise this to `high` |
| R5 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads and present monthly to the VP Product | `[grounded]` your message | A sanitized memo excerpt would raise this to `high` |
| R6 | Define and maintain the metrics layer | must_have | adjacent | low | discovery | Governed dashboards and the metrics memo are near this, but shared definitions, a semantic layer or metric ownership aren't stated. `low`, not `none`, because there is a concrete thread to pull | `[grounded]` your message silent on definitions; `[inferred]` adjacency from the governed dashboards | G1 |
| R7a | Partner with product managers to turn analysis into roadmap decisions | important | direct | medium | none | Monthly presentation to the VP Product, and the pricing test led to a retention result. Day-to-day PM partnership isn't described | `[grounded]` your message | none |
| R7b | Partner with clinicians | important | unclear | none | discovery | Nothing in your message touches clinical or domain-expert stakeholders | `[grounded]` your message silent | G3 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Mentoring isn't mentioned. Absence from a summary isn't evidence of absence | `[grounded]` your message silent | G2 |
| R9 | Healthcare data experience, HIPAA (a plus) | preferred | adjacent | medium | transferability | You've handled GDPR/CCPA consumer PII and built the consent-state model for your warehouse. Limit: no healthcare data and no HIPAA obligations exercised. HIPAA covers health information under its own rules | `[grounded]` your message; `[generic]` on HIPAA's scope | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R6, must_have) | discovery | Governed Looker dashboards and a metrics memo, with no mention of shared metric definitions | It is the only `must_have` row below `direct`, so closing it most strengthens the case | A metrics dictionary or certified definitions others relied on; a LookML or dbt layer; settling disagreements over what "retention" means | A metric glossary, a Looker explore or model sample, a definitions doc | `[grounded]` message silent; `[inferred]` that the dashboards imply some definitions work |
| G2 | Mentoring (R8, important) | discovery | No mention | The JD names two juniors; "senior" may imply this, and it affects positioning | Onboarding analysts, reviewing their queries or analyses, informal coaching, running a team practice | A short description of who and for how long; a review checklist | `[grounded]` message silent |
| G3 | Clinician partnership (R7b, important) | discovery | No clinical or domain-expert stakeholders mentioned | A stakeholder type unfamiliar from meal-kit | Work with domain experts such as nutritionists or food-safety staff; translating analysis for a non-analytic specialist | A project note naming the specialist stakeholder | `[grounded]` message silent |
| G4 | Healthcare data (R9, preferred) | transferability | PII handling and a consent-state model under GDPR/CCPA, but no health data | Preferred only, and the bridge is credible | Data-access controls, retention or deletion handling, the consent-model design itself | A sanitized consent-model diagram | `[grounded]` message; `[generic]` that healthcare employers weigh this |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "digital-health scale-up, ~400 people, Series C" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. Raised because my search could not run, not because anything found conflicts | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay and location terms absent | unknown | — | "(the posting as pasted states no pay, location or remote terms)" | These may sit elsewhere on the listing, or the company may withhold them until later stages | `[grounded]` pasted JD silent | What is the salary range, and is the role remote, hybrid or office-based? | unresolved |
| RR3 | Metrics layer: build or maintain | unknown | — | "define and maintain the metrics layer" | It may be an established layer to look after or a greenfield build, with different workloads | `[inferred]` from "define and maintain" against silence on current state | Does a metrics layer exist today, in what tool, and who owns it? | unresolved |
| RR4 | Concrete responsibilities, named team and tools | positive_signal | — | "mentor two junior analysts" | Scope reads as defined, with a named tool and a team size | `[grounded]` JD | How is success measured in the first year? | noted |

## Application plan

`resume_edits_pending_approval`: E1 and E2. Each proposed line uses only your own words.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with the experimentation program, using your phrasing: "30+ A/B tests a year", including the pricing test behind an 11% retention lift | R3, the headline requirement | `[grounded]` your message | pending your approval |
| E2 | Foreground "built the company's Looker instance from scratch" and "40+ governed dashboards" | R4 | `[grounded]` your message | pending your approval |
| A1 | Say plainly that you haven't worked in healthcare, then name what you did handle: GDPR/CCPA consumer PII and the consent-state model. Don't imply HIPAA experience | R9, whose limit is HIPAA and health data | `[grounded]` your message | pending your approval |
| Q1 | Ask the RR1, RR2 and RR3 questions verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

Tailoring the resume itself is resume-tailor's job, if you'd like it.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | A search for the company and its careers page was refused. It would have moved RR1 and the contradictions row |
| 2. Role-family sweep | unavailable | A search on pay and scope for this title was refused. It would have moved the market-calibration row and RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer

I can write this up as a `tuesday-dossier.md` if you'd like a version to carry into prep or revisions.

## Upgrade menu

- A sanitized experiment readout, Looker screenshots or a LookML sample, or a metrics-memo excerpt would raise R3, R4 and R5 toward `high`.
- An answer to G1 would move R6, the only `must_have` row below `direct`.
- Your constraints (pay floor, location, authorization) would turn the hard-gates line from "checks unknown" into real checks.
- Search permission, or a link to the live posting and the company's careers page, would let RR1 and the market band resolve.
- The hiring manager's name would let me read their public footprint and set the positioning.
- A deeper research pass on the company, with up to 5 more searches and 2 more fetches, runs only if you say so and search is permitted.

## Questions

C1 — Do you have non-negotiables I should check this role against, such as a pay floor, location or remote needs, or work authorization?

G1 — Have you defined or owned shared metric definitions (a metrics dictionary, certified Looker explores, a LookML or dbt layer) that others relied on? What did you own, who used it, and how did you settle disagreements?

G2 — Have you mentored or onboarded analysts, formally or informally? What did you own, and for how many people and how long?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.