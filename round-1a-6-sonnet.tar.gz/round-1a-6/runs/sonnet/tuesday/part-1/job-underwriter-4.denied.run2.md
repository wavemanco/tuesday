Search permission was declined, so this assessment uses only your JD and background. Every claim about Brindlemoor and the market is unchecked, and each place that depends on it says so.

## Decision snapshot

**Yes, worth applying to: R2, R3, R4, R5, R6, R7a and R8 are `direct`, and R1 needs one answer from you. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote, UK)
- `must_have` — direct: R2, R3, R4, R5, R6, R7a, R8 · unclear: R7b (Recommendations to product)
- `important` — adjacent: R10 (Own pricing analytics), R11 (Pet-insurance domain knowledge)
- `preferred` — direct: R9

R11 (`medium`) — a credible bridge from young-driver rating, its limit named; R7b — unconfirmed, one question away.

**Opportunity ledger.** The employer is unverified because research did not run (RR1), pay is not in the posting as pasted (RR2), and ownership is stated without team or tooling (RR3). The pet product's maturity is unknown (RR4). The deliverables are concrete (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm R1; (2) Brindlemoor and a live posting verify on its own careers page (RR1); (3) the pet gap is framed as adjacent, never as pet experience (R11).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD header; existence not checked |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reports to | Odile Varga, Director of Pricing | `[grounded]` your message |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| People management | The JD lists no line management, so your lack of it is not a stated gap | `[grounded]` JD silence |
| Scope read | An individual-contributor senior role with end-to-end ownership of one product's pricing analytics | `[inferred]` from "Own" and the absence of any team language |
| Market calibration | Not available: no search ran, so no title, scope or pay band is claimed | — |
| Unknowns | Pay; team and tooling; contract basis; how long the pet product has been live; whether "product" is a distinct stakeholder | — |
| Contradictions | None found between the JD and your background; the JD could not be checked against Brindlemoor's own pages | `[grounded]` the two inputs only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK | hard_gate | unclear | low | hard_gate | You work at a UK insurer, which suggests UK-based, but you have not stated your location or right to work. Unsettled, so unclear. | `[inferred]` from a UK employer | Question R1 below |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years of pricing analytics, the last 2 as senior analyst. Specific but not inspected, and a length requirement is not a gate. | `[grounded]` your background, prose | Dated role history (CV) would firm it up |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Used daily. Confirmed but no inspectable artifact. | `[grounded]` your background | An anonymised code sample or notebook would raise to `high` |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for the young-driver book. | `[grounded]` your background | Anonymised model documentation would raise to `high` |
| R5 | Build and monitor rating models | must_have | direct | medium | none | Same evidence as R4: built and maintained, so build and monitor are both covered. The line of business differs from the role's. | `[grounded]` your background | none |
| R6 | Design and read price tests | must_have | direct | medium | none | 14 price tests run last year with the underwriting team. | `[grounded]` your background | A test readout, anonymised, would raise to `high` |
| R7a | Recommendations to underwriting | must_have | direct | medium | none | You ran the tests with underwriting and present the quarterly pricing review to the head of underwriting. | `[grounded]` your background | none |
| R7b | Recommendations to product | must_have | unclear | low | discovery | Nothing in your background mentions a product or commercial owner. Silence is not absence. | `[grounded]` background silence | Question R7b below |
| R8 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | The quarterly pricing review goes to the head of underwriting. | `[grounded]` your background | none |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | 5 years at a motor insurer. | `[grounded]` your background | none |
| R10 | Own pricing analytics for the product (end-to-end) | important | adjacent | medium | transferability | You owned the young-driver GLM and the tests, which is one book, not a whole product's pricing analytics. Limit: no stated ownership across a full product and no one managed. | `[inferred]` from "Own" in the JD against the scope you described | Describe what you owned end-to-end beyond the model |
| R11 | Pet-insurance domain knowledge | important | adjacent | medium | transferability | Rating a high-variance segment by risk class in motor is a credible bridge. Limit: none of the pet-specific rating factors, claims patterns or product design has been exercised. | `[inferred]` implied requirement from "pet-insurance product"; `[generic]` that pet pricing has its own rating factors | A short written note on how you would approach it |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance domain (R11, important) | transferability | Strong motor pricing evidence and no pet work, which you stated yourself | The likeliest objection to your application; a stated limit reads better than a hidden one | Rating by age and risk class in the young-driver book; any claims-frequency or severity analysis; any exposure to renewal or retention pricing | A one-page note on how you would approach pet rating, clearly yours | `[inferred]` bridge from motor evidence; `[generic]` that it is the likeliest objection |
| G2 | Recommendations to product (R7b, must_have) | discovery | Underwriting audiences are clear; no product or commercial audience appears | A must-have the role names alongside underwriting; resolving it could remove the only open must-have | A test result you took to a product, commercial or distribution owner; a pricing change you proposed that shipped; a result you presented outside underwriting | A slide, a memo or a test readout | `[grounded]` background silence |
| G3 | UK-based and remote (R1, hard_gate) | hard_gate | UK employer, but location and right to work not stated | A gate: unsettled until you confirm it | Not applicable: this is a yes or no | None needed | `[grounded]` background silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer. No search ran, so nothing was checked. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay not in the posting as pasted | unknown | — | (no salary stated in the pasted JD) | The posting may withhold pay, or the figure may have been left out of the paste | `[inferred]` from the pasted text | What salary range is budgeted for this post? | unresolved |
| RR3 | Ownership without stated team or tooling | unknown | — | "Own pricing analytics for our pet-insurance product" | The role may be accountable without named data, tooling or decision rights | `[inferred]` from the JD's scope language against its silence on resources | What team, data and tooling support this role, and which pricing decisions does it make itself versus recommend? | unresolved |
| RR4 | Maturity of the pet product unknown | unknown | — | "our pet-insurance product" | The product may be new, with limited claims history for model building | `[inferred]` from the JD naming no data or history | How long has the pet product been live, and how much claims history does the rating model have to work with? | unresolved |
| RR5 | Concrete deliverables stated | positive_signal | — | "build and monitor rating models, design and read price tests, and turn the results into recommendations" | The role's work is defined, which supports a measurable first year | `[grounded]` JD | What would a good first year look like in this role? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | CV ordering, no new claims: lead with the GLM rating model you built and maintained for the young-driver book, the 14 price tests run with underwriting last year, and the quarterly pricing review you present to the head of underwriting | R4, R6, R8 | `[grounded]` your sentences | `resume_edits_pending_approval` |
| P1 | Say plainly that you have no pet-insurance experience and bring a bridge from rating by risk class in motor, labeled adjacent | R11, G1 | `[inferred]` bridge; its limit named | pending your approval |
| P2 | If asked about managing people, say that you haven't; the JD lists no line management | People management in role reality | `[grounded]` JD silence, your words | pending your approval |
| A1 | Verify Brindlemoor and the live posting on its own careers page before investing effort | RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask Odile Varga the questions of RR2, RR3 and RR4 verbatim in the process | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Brindlemoor pet insurance insurtech careers"; the call was refused. It would have moved RR1 and the contradictions row in role reality |
| 2. Role-family sweep | unavailable | Searched "Senior Pricing Analyst pet insurance UK remote salary"; the call was refused. It would have moved the market calibration and RR2 |
| 3. Hiring manager's public footprint | unavailable | A name was given. Searched "Odile Varga Director of Pricing Brindlemoor"; the call was refused. It would have moved the scope read and which story the plan leads with |

I'm not retrying the searches.

Would you like me to save this as `tuesday-dossier.md` so a later step can pick it up?

## Upgrade menu

- Search permission, or a link to the role on Brindlemoor's own careers page → RR1 resolves, and the role-reality calibration and pay band fill in (up to 5 more searches and 2 more fetches for a deeper pass, only if you say the word).
- An answer on R7b → the only open must-have closes.
- An anonymised model document, code sample or test readout → R3, R4 and R6 can reach `high`.
- Your pay floor and location → R1 closes, and RR2 can be checked against your floor.

R1 — Are you UK-based with the right to work in the UK, and happy working fully remote?

R7b — Have you taken a pricing or test result to a product or commercial owner, not underwriting, and shaped what they changed? What was yours, and what happened?

Constraints — Do you have a pay floor, or a notice period or start date, that I should check this role against?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.