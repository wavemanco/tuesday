Both web searches were refused, so this assessment rests only on the posting and your message. The research accounting is under Evidence status.

## Decision snapshot

**No. R1 and R2, both hard gates, fail. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (On-site Austin 5 days), R2 (Base $70–85k)
- `must_have` — direct: R4, R5 · unclear: R3 (8+ years growth leadership), R6 (SEO/content)
- `important` — unclear: R7 (Brand and PR), R8 (Partnerships and sales ops), R9 (Team of one, ambiguity)

R4, R5 — your stated paid and lifecycle ownership matches channels the posting lists; R3 — your leadership years are not split out from your nine; R1, R2 — the failed terms decide the status.

**Opportunity ledger.** Your instinct has support in the posting's own words: seven functions with no team (RR4), an after-hours expectation (RR5), success metrics left undefined (RR6), and unquantified equity (RR7). The pay band's market fit is unestablished because the sweep did not run (RR3), and the employer is unverified (RR8). One entry runs the other way (RR9).

- **Hard gates:** failed: R1 (On-site Austin 5 days), R2 (Base $70–85k).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would change this:** Novaline would have to confirm in writing a Portland-based remote arrangement (R1) and a base at or above your $150k floor (R2). Neither is suggested anywhere in the posting.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, Series A, "profitable since day one"; not verified from any outside source | `[grounded]` JD header, as stated |
| Mandate | Own revenue growth end to end: paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` JD |
| Team and reporting | "A team of one to start"; reports to the CEO with a dotted line to the board | `[grounded]` JD |
| Working pattern | On-site in Austin 5 days a week, "no exceptions"; "evenings and weekends when it matters" | `[grounded]` JD |
| Compensation | $70–85k base plus "meaningful equity upside"; the equity is not quantified | `[grounded]` JD |
| Scope read | Reads as several specializations folded into one title | `[inferred]` from the seven named functions against a team of one |
| Market calibration | Not run: the role-family sweep was refused, so no band is offered and none is taken from memory | — |
| Unknowns | Equity size, vesting and strike; budget; what "success" means; who the hiring manager is; what "to start" means for headcount | `[grounded]` JD silence |
| Contradictions | Title says "Head of", mandate says team of one | `[inferred]` from the JD's own two phrases |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Austin, 5 days a week, "no exceptions" (your constraint: remote-only, Portland, no relocation) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your statement of the limit, which is yours, specific and confirmed. The fit fails because the JD rules out the exception your limit needs | `[grounded]` JD quote and your stated constraint | Surface only. Wording cannot resolve it; only Novaline changing terms would |
| R2 | Base pay of $70–85k (your constraint: at least $150k base) | hard_gate | hard_gate_fail | high | hard_gate | Your floor is your own, specific and confirmed. The posted top of $85k is below it by $65k, so no point in the range meets it | `[grounded]` JD quote and your stated floor | Surface only; see RR2 |
| R3 | 8+ years growth leadership | must_have | unclear | medium | discovery | You state 9 years in growth, "growth lead, then Head of Growth". The JD asks for leadership years, and you haven't said how many of the nine were in leadership roles. I resolved this downward | `[grounded]` your message; no CV or artifact inspected | Give the start date of your first lead title |
| R4 | Paid acquisition | must_have | direct | medium | none | You state you owned paid at two B2C subscription companies, with controlled budget at one. It is confirmed and plausible, with no inspectable artifact yet, so expect a probe | `[grounded]` your message | A channel-spend and CAC report would raise it to high |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You state you owned lifecycle and are deep in Braze, with no inspectable artifact yet | `[grounded]` your message | A sanitized Braze journey map or lifecycle results deck would raise it to high |
| R6 | SEO/content | must_have | unclear | none | discovery | Your message does not mention SEO or content. GA4 depth is analytics, which does not evidence SEO work. Silence is not absence | `[grounded]` your message's silence | See G1 |
| R7 | Brand and PR | important | unclear | none | discovery | Your message does not mention either | `[grounded]` your message's silence | See G2 |
| R8 | Partnerships and sales ops | important | unclear | none | discovery | Your message does not mention either | `[grounded]` your message's silence | See G2 |
| R9 | Operating as a team of one; thriving on ambiguity | important | unclear | low | discovery | You built and managed teams of 3–7, which is indirect context and does not show solo execution across seven functions | `[inferred]` from your team history against the JD's team-of-one line | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content (R6, must_have) | discovery | Nothing in your message establishes SEO or content ownership | It is a must-have row at `unclear`; closing it helps only if the terms change, because R1 and R2 fix the status | Owning organic-traffic targets; briefing writers or an agency; technical-SEO fixes you prioritized | A Search Console or GA4 organic report, a content calendar, or a brief | `[grounded]` your message's silence |
| G2 | Brand, PR, partnerships, sales ops (R7, R8, important) | discovery | Nothing in your message touches these four functions | Same as G1; these rows sit at `important` | Co-marketing or affiliate deals; a PR launch; a CRM-to-sales handoff you designed | A partner agreement, a press clip, or a pipeline report | `[grounded]` your message's silence |
| G3 | Solo execution (R9, important) | discovery | Your team history says nothing on running every channel alone | Whether you've done it, and wanted it, is a fit question and a preference question | A stretch before your teams existed, or a founder-stage role | A channel-mix plan from a period you worked alone | `[inferred]` from the JD against your team history |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Location conflicts with your remote-only constraint (R1) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions." | Hiring a Portland-based remote candidate is not possible on these terms | `[grounded]` JD quote against your stated constraint | Is a remote arrangement possible for this role in any form? | confirmed |
| RR2 | Base pay is below your floor (R2) | red_flag | high | "$70–85k base" | The offer cannot reach your $150k floor within the stated range | `[grounded]` JD figure against your stated floor | Is the base band flexible, and what is the ceiling for the right candidate? | confirmed |
| RR3 | Seniority-compensation mismatch | risk_signal | medium | "8+ years growth leadership required" with "$70–85k base" | The pay may sit below what this seniority and mandate command, and I could not run the sweep to test it; severity stays medium until it does | `[inferred]` from the JD's years and scope against its figure | What is the budgeted range for this role, and how was it set? | unresolved |
| RR4 | Bundled specializations with no team | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops"; "a team of one to start" | One person may be accountable for several roles' worth of work without headcount or budget | `[inferred]` from the JD's function list against its team line | What headcount and channel budget are committed in the first year? | unresolved |
| RR5 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | After-hours work may be routine and not exceptional | `[inferred]` from the JD's phrasing | How often have evenings and weekends been needed in the last quarter? | unresolved |
| RR6 | Success metrics undefined on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | Accountability may be set after the fact | `[inferred]` from the JD's silence on targets against its scope | What does success look like at 6 and 12 months, in numbers? | unresolved |
| RR7 | Equity unquantified | unknown | — | "meaningful equity upside" | The value of the equity cannot be judged without the percentage, strike and vesting | `[grounded]` JD silence on terms | What percentage, strike price and vesting schedule apply? | unresolved |
| RR8 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The entity may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer; no search ran | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who I'd report to? | unresolved |
| RR9 | Reporting line to CEO with board access | positive_signal | — | "Report to the CEO with a dotted line to the board" | Senior visibility may mean real decision access | `[grounded]` JD states it | Which decisions does this role make without CEO sign-off? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | No resume edits are proposed: the status does not rest on presentation | see R1, R2 | `[grounded]` the two failed gates | no action |
| A2 | If you pursue it anyway, put RR1 and RR2 to the employer before any application effort, then RR3 and RR4 | A "no" at the start costs one email. It saves a loop | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Your background reached me as prose, which has the same standing as a CV, and no document was inspected.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search sent: "Novaline e-commerce enablement startup Austin careers Head of Growth", refused. It would have moved role reality's organization row and RR8 |
| 2. Role-family sweep | unavailable | Search sent: "Head of Growth salary Series A startup base compensation 2026", refused. It would have moved the market calibration row and RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I'd offer a dossier (`tuesday-dossier.md`) to carry this forward, whenever you want it.

## Upgrade menu

- Permission to search → targets 1 and 2 run; the organization row, RR8, the market calibration row and RR3 fill in. A further pass (up to 5 more searches and 2 more fetches) could follow.
- A link to the role on Novaline's own careers page → RR8 closes.
- Equity percentage, strike and vesting → RR7 closes.
- Novaline's written answer on remote and base pay → R1 and R2 move, the only route to a different status.
- The hiring manager's name → role reality's scope read and the positioning for that reader.
- A GA4 or Search Console organic report, a partner agreement, or a press clip → R6, R7 and R8 move from `unclear`.

No questions this turn: nothing you could answer would change the status. Only Novaline changing its terms would.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.