Web search was declined, so this assessment runs on your JD and background only.

## Decision snapshot

**Yes, you're a fit and the role is worth applying to, on conditions: R1, R2, R3, R4 and R5 are `direct`. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R5 · adjacent: R6 (Define and maintain the metrics layer)
- `important` — direct: R7a · adjacent: R7b (Partnering with clinicians) · unclear: R8 (Mentoring two junior analysts)
- `preferred` — adjacent: R9 (Healthcare data experience, HIPAA)

R6 — governed dashboards sit near a metrics layer, its limit named; R8 — your background is silent on mentoring; R9 — a consent-state model is a credible bridge, its limit named.

**Opportunity ledger.** The employer is unverified because research did not run (RR1), the pay is not stated (RR2), and the state of the existing metrics layer and team is unstated (RR3).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Harborlight and the live posting verify (RR1); (2) the metrics-layer question G1 resolves (R6); (3) the pay is checked against your floor once you share it (RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, about 400 people, Series C | `[grounded]` JD header |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, self-serve Looker dashboards, partnering with PMs and clinicians, mentoring two junior analysts | `[grounded]` JD |
| Seniority | Senior individual contributor with light people leadership (two juniors) | `[inferred]` from "Senior" in the title and the mentoring line |
| First-year outcomes | Not stated in the JD | `[grounded]` JD silent |
| Market calibration | Not run, because search was declined. No band is offered, and the pay cannot be set against a floor | `[grounded]` research unavailable |
| Unknowns | Pay; whether a metrics layer already exists; how the two juniors are structured; remote or onsite; how clinicians are involved day to day | `[grounded]` JD silent |
| Contradictions | None found within the JD. It was not checked against a careers page | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | You state 6 years of product analytics. This is specific self-report with no inspectable artifact yet | `[grounded]` your background prose | offer: CV with titles and dates would raise it |
| R2 | Expert SQL | must_have | direct | medium | none | You state daily SQL on Snowflake. "Expert" is your own grade, and a technical screen is where it gets tested | `[grounded]` your background prose | offer: a sanitized query or model you wrote would raise it |
| R3 | Experiment design at scale | must_have | direct | medium | none | You state 30+ A/B tests a year, including the pricing test behind an 11% retention lift. Limit: the JD's "at scale" is undefined. Care settings often add constraints that consumer tests lack, which is a `[generic]` pattern | `[grounded]` your background prose; `[generic]` care-setting constraints | offer: a sanitized test plan or readout would raise it |
| R4 | Looker or similar BI tool | must_have | direct | medium | none | You state you built the Looker instance from scratch, with 40+ governed dashboards | `[grounded]` your background prose | offer: sanitized dashboard screenshots would raise it |
| R5 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads and present to the VP Product monthly | `[grounded]` your background prose | offer: a sanitized memo would raise it |
| R6 | Define and maintain the metrics layer | must_have | adjacent | low | discovery | Governed dashboards suggest metric definitions, but nothing you wrote says you defined a shared semantic layer or its versioning. It is low rather than none because there is a concrete thread to pull | `[inferred]` from "governed dashboards" against silence on a metrics layer | G1 |
| R7a | Partner with product managers | important | direct | medium | none | You present monthly to the VP Product, and PM partnership is the same working relationship. The stated evidence is exec-level reporting, not day-to-day PM work | `[grounded]` your background prose | none |
| R7b | Partner with clinicians | important | adjacent | low | transferability | No clinical stakeholders appear in your history. Partnering with non-analyst functions is the nearest evidence, and the limit is clinical judgment and its vocabulary | `[inferred]` from your cross-functional work | G3 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Nothing in your background mentions mentoring or managing | `[grounded]` background silent | G2 |
| R9 | Healthcare data experience (HIPAA) a plus | preferred | adjacent | medium | transferability | You handled GDPR/CCPA consumer PII and built the consent-state model. Limit: no PHI, HIPAA rules, or clinical data. The bridge is real, but it is not healthcare experience | `[grounded]` your stated privacy work; `[generic]` that HIPAA differs from GDPR/CCPA | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R6, must_have) | discovery | Governed dashboards, but no stated shared metric definitions | A must-have at `adjacent`. Resolving it is the likeliest way to move R6 to `direct` | Defining a canonical retention, churn or activation metric used across teams; LookML or dbt models; a metrics dictionary; resolving disagreeing definitions between teams | A metrics dictionary, LookML excerpt, or definition doc (sanitized) | `[grounded]` background silent on the layer; `[generic]` that "metrics layer" ownership is a core scope of this role family |
| G2 | Mentoring (R8, important) | discovery | No mention in your background | The JD names two juniors, and an unanswered R8 leaves a visible hole | Onboarding an analyst; code or dashboard review; running an informal analytics office hour; coaching on an experiment readout | A mentee's name is not needed. A short description of what you did is enough | `[grounded]` background silent |
| G3 | Clinician partnership (R7b, important) | transferability | Cross-functional work, no clinical stakeholders | Clinicians are named in the JD as a partner group | Working with a domain expert (nutrition, culinary, ops) to turn judgment into a metric or test | A sanitized example where a domain expert shaped an analysis | `[inferred]` bridge from your cross-functional work |
| G4 | HIPAA (R9, preferred) | transferability | Consent-state model and GDPR/CCPA handling | A plus, not a requirement, so it is minor | Data-minimization decisions, access controls, de-identification, audit trails | A sanitized description of the consent-state model | `[grounded]` your stated privacy work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | Research did not run. The employer may be fine, and this entry only records that it is unchecked | `[generic]` pattern for any posting not yet checked, not a claim about this one | Can you point me to this role on your own careers site, and who would I be working with? | unresolved |
| RR2 | Pay not stated | unknown | — | the JD gives no figure | The figure may sit anywhere in the role-family band. I cannot compare it to a band or to your floor | `[grounded]` JD silent | What is the budgeted salary range for this role? | unresolved |
| RR3 | Starting state of the metrics layer and team unstated | unknown | — | "define and maintain the metrics layer" and "mentor two junior analysts" | You may be inheriting an existing layer and team, or building both | `[inferred]` from the JD's wording against its silence on a starting point | What exists today for the metrics layer, and who are the two analysts reporting into this role? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | `resume_edits_pending_approval`: lead with your own sentence — "Designed and ran the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift" | R3 | `[grounded]` your background prose | pending your approval |
| E2 | `resume_edits_pending_approval`: keep the consent-state model and GDPR/CCPA handling as stated. Do not describe it as healthcare or HIPAA experience | R9 | `[grounded]` your stated privacy work | pending your approval |
| W1 | Prepare a sanitized monthly metrics memo as a writing sample | R5 | `[grounded]` R5 row | pending your approval |
| Q1 | Ask RR1, RR2 and RR3 verbatim with the recruiter before investing in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search "Harborlight Health care navigation app careers" was refused. It would have fed RR1, role reality's organization and contradictions rows |
| 2. Role-family sweep | unavailable | Search "senior product analyst digital health salary range experimentation Looker" was refused. It would have fed market calibration and RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so no query could be formed |

## Dossier and upgrade menu

I can save this as `tuesday-dossier.md` if you'd like to carry it into later steps.

- Access to web search → targets 1 and 2 run, which would verify the employer (RR1) and calibrate pay (RR2).
- Your answer to G1 → R6 moves toward `direct`.
- A sanitized memo, test readout, or dashboard screenshots → R3, R4 and R5 move toward `high`.
- Your constraints (pay floor, location, schedule) → the hard-gates line stops being unknown.
- The hiring manager's name → role reality's scope read.

## Questions

G1 — Have you defined metrics that several teams relied on, such as a canonical retention or churn definition, and where did that definition live (LookML, dbt, a doc)?

G2 — Have you onboarded, coached or reviewed the work of other analysts, and what did that look like?

C1 — What are your non-negotiables for this role: pay floor, location or remote, schedule?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.