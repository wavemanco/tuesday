Posting read and company, pay and hiring-manager searches done. I'm making one last check, on whether Quillfield's own careers page lists the role, before I write this up.
# Job Underwriting — Revenue Operations Lead at Quillfield

## Decision snapshot

**Yes, go for it, as a stretch. R6, R7 and R8b are the real gaps, and R1 and R2 are still unconfirmed. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Bristol hybrid, two office days), R2 (Pay £61,500–£67,000 plus options)
- `must_have` — direct: R3, R4, R5a · adjacent: R6 (Owning a forecast) · unclear: R5b (Spreadsheet modelling), R7 (Working with finance on billing or revenue data)
- `important` — direct: R8a, R9 · absent: R8b (Owning billing data)

R6 — a credible bridge, its limit named; R8b (`none`) — you have said you have never worked on billing data; R7 — open, waiting on your answer.

**Opportunity ledger.** The stated pay sits inside the market band (RR1). Reporting line (RR2), what "run the forecast with the CFO" means (RR3), the billing-data setup (RR4) and the posting's absence from Quillfield's own site (RR5) are unknowns that interviews or the recruiter can close.

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days), R2 (Pay £61,500–£67,000 plus options); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Bristol with two office days and the pay range work for you — R1, R2, G1; (2) you are comfortable that the forecast and billing-data parts would be learned on the job, and the hiring manager hears that early — R6, R7, R8b, RR3, RR4; (3) the posting is confirmed live with Quillfield — RR5.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants, founded 2018 in Bristol, 96 employees, Series A (£11M) closed April 2025 | `[grounded]` About page (quillfield.co.uk/about), search result |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting for sales and finance; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Terms | Bristol, hybrid, two office days a week; £61,500–£67,000 plus share options | `[grounded]` posting |
| Hiring manager | Tamsin Achebe, Head of Revenue Operations at Quillfield; previously sales operations manager at Corvane Payments for four years | `[grounded]` profile search result (linkedin.example/in/tamsin-achebe), public role and career pattern only |
| Scope read | A broad single-owner remit: CRM, billing data, reporting and a CFO-level forecast sit in one post at a 96-person company | `[inferred]` from the posting's four responsibilities against the company size |
| Market calibration | UK B2B software revenue operations leads: median base £64,200, interquartile range £57,800–£70,400. The posting's range sits inside that interquartile range, and the band is not Bristol-specific. It is a pattern, not this employer's offer | `[generic]` Ledgerline 2026 pay guide (n=438), one search; `[grounded]` posting for the range |
| Unknowns | Reporting line and team; who builds and signs off the forecast; billing system and data quality; share-option terms | `[grounded]` posting silent on each |
| Contradictions | None between the posting and the About page. The role is not on a Quillfield careers page at the address I tried | `[grounded]` fetch returned no page |

## Evidence map

Your background is intake prose, so it carries the same standing as a CV. `medium` is the ceiling until something inspectable is shared.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two office days a week | hard_gate | unclear | none | hard_gate | You have not stated a location constraint, so there is nothing to grade and nothing to compare | `[grounded]` posting; no constraint given | G1 question |
| R2 | Salary £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | No pay floor given. Options terms are unstated | `[grounded]` posting; no constraint given | G1 question |
| R3 | 4+ years in RevOps, sales ops or similar analytics at a B2B software company | must_have | direct | medium | none | 5 years in sales operations, the last 2 running revenue operations for the UK team. The posting says "B2B software company" and you described your employer as a B2B payments company. Whether it counts as software is unstated, so expect that to be probed. Years of experience is not a gate | `[grounded]` your background; `[inferred]` that the software wording may be probed | none |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | "Salesforce admin certified". The certificate itself has not been inspected | `[grounded]` your background | A certificate would raise this to `high` |
| R5a | Strong SQL | must_have | direct | medium | none | "SQL weekly" shows regular use. "Strong" is not probed | `[grounded]` your background | none |
| R5b | Spreadsheet modelling | must_have | unclear | low | discovery | "Excel daily" shows use, not modelling. Taking the lower band | `[grounded]` your background; modelling not stated | See G4 |
| R6 | Experience owning a forecast | must_have | adjacent | medium | transferability | You said finance owned the company forecast. Adjacent: you run the monthly pipeline review with your sales director and rebuilt the pipeline dashboards. Limit: you have never owned a forecast | `[grounded]` your own statements | G2 question |
| R7 | Experience working with finance on billing or revenue data | must_have | unclear | low | discovery | The posting says "billing or revenue", so revenue data would count. You built renewal dashboards, but whether finance used or shaped them is unconfirmed. You have never worked on billing data | `[grounded]` your background; posting wording | G3 question |
| R8a | Own the CRM data | important | direct | medium | none | Salesforce admin certified and you rebuilt the pipeline and renewal dashboards. The ownership scope is not stated | `[grounded]` your background | none |
| R8b | Own the billing data | important | absent | none | capability | You told me you have never worked on billing data. Capability is the honest call because you said so directly. The bridge, if any, runs through renewals data (G3) | `[grounded]` your own statement | Named as a risk; see G3 |
| R9 | Build pipeline and renewal reporting for sales and finance | important | direct | medium | none | You rebuilt pipeline and renewal dashboards. Finance as a consumer of them is unconfirmed | `[grounded]` your background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and pay terms (R1, R2; hard_gate) | hard_gate | Terms are in the posting, but no constraints from you | Either could end the process regardless of fit | n/a: this gate is met or not | Your own floor and commute situation | `[grounded]` posting; `[inferred]` that it decides the status |
| G2 | Owning a forecast (R6; must_have) | transferability | You supply pipeline reviews and dashboards; finance builds the forecast | The posting makes the forecast with the CFO the headline duty, so this is the likeliest objection | Maintaining a pipeline-coverage or renewal-rate projection; a number you committed to and tracked; a forecast you rebuilt or challenged | A sanitized projection sheet or a review deck | `[grounded]` your statements; `[generic]` that a forecast duty is typically probed hard |
| G3 | Finance and billing data (R7, R8b; must_have and important) | discovery | Renewal dashboards exist; the finance link and any invoice-level data are unstated | Billing data is the other headline duty, and R7 may close through revenue data | Renewals reconciled with finance; a reporting fix traced to invoices; sharing definitions of ARR or churn with finance | A metric-definitions doc or a reconciliation sheet | `[grounded]` posting and your statements |
| G4 | Spreadsheet modelling (R5b; must_have) | discovery | Daily Excel use, with no models described | Modelling underpins the forecast duty | A scenario or what-if model; a multi-tab workbook other people relied on | A workbook with confidential content removed | `[grounded]` your statements |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay stated and inside the market band | positive_signal | — | "Salary £61,500–£67,000 plus share options" | Transparent pay, near the median for the title | `[grounded]` posting; `[generic]` band, not this employer's offer | What do the share options consist of, and over what vesting period? | noted |
| RR2 | Reporting line and team not stated | unknown | — | "You will own our CRM and billing data" | The Head of Revenue Operations may be the line manager, or the role may sit under finance | `[inferred]` from her listed title against the posting's silence on reporting | Who does this role report to, and what team supports it? | unresolved |
| RR3 | Forecast duty is shared, split unclear | unknown | — | "run the quarterly revenue forecast with the CFO" | The role may build the model, or may supply the inputs and the CFO signs off | `[inferred]` from "with the CFO" against the lack of any detail | Who builds the forecast model today, and who signs it off? | unresolved |
| RR4 | State of the billing data not described | unknown | — | "own our CRM and billing data" | The billing data may need cleaning or reconciliation before it can be reported on | `[generic]` pattern for owning billing data at companies at this stage | Which billing system holds the data, and how clean is it today? | unresolved |
| RR5 | Role not found on Quillfield's own site | unknown | — | "Revenue Operations Lead, Quillfield \| Tallyboard Jobs" | The listing may sit elsewhere on the site, be recent, or be handled only through the recruiter | `[grounded]` fetch returned no page; the company itself is established | Is this role listed on Quillfield's own careers page, and which team is hiring? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the pipeline and renewal dashboard rebuild and the monthly pipeline review you run with your sales director | R9, R8a, R3; the hiring manager came to RevOps from sales operations, so this lead should read naturally to her | `[grounded]` your background; `[inferred]` from her listed prior role | pending your approval |
| P2 | Say the gaps plainly: "Finance owned the company forecast where I work, and I haven't worked on billing data" | R6, R8b; it uses only your own statements and keeps the probe on your terms | `[grounded]` your statements | pending your approval |
| P3 | Ask RR2, RR3, RR4 and RR5 verbatim, with the recruiter first for RR5 | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| P4 | Confirm R1 and R2 with the recruiter before investing further | G1 | `[grounded]` posting terms | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company" and "Quillfield careers Revenue Operations Lead Bristol" (no results); fetched quillfield.co.uk/careers (no page); read "About Quillfield" (quillfield.co.uk/about). Moved role reality's organization row, and added RR5 |
| 2. Role-family sweep | yes | Searched "revenue operations lead salary UK B2B SaaS Bristol", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved the market calibration and RR1 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Moved the scope read and P1 |

I can write this assessment up as a `tuesday-dossier.md` if you want to keep it for later rounds.

**Upgrade menu**

- Your pay floor and location limits → R1 and R2 resolve, and the decision likely becomes `go` or `no_go`.
- An answer to G2 or G3 → R6, R7 or R8b move up. A sanitized projection or metric-definitions doc would raise them to `high`.
- Your CV → fit rows firm up, and resume-tailor can then tailor it to this role.
- Quillfield's own listing, or the recruiter's confirmation → RR5 closes.
- A deeper pass on Quillfield (funding and leadership changes, recent news; up to 5 more searches and 2 more fetches) → say the word and it runs.

**Questions**

G1 — Do the posting's terms (Bristol with two office days a week, £61,500–£67,000 plus options) work for you?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G2 — Have you ever built, maintained or committed to a forecast or projection number, even one finance later rolled up? What did you own?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G3 — In the renewal and pipeline reporting, did you work with finance, and did any of that data trace back to invoices or billing?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.