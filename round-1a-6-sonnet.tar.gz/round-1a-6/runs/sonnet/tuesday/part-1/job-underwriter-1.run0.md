Web search was denied, so this assessment uses only your JD and background.

## Decision snapshot

**Yes, apply. R1, R2, R3, R4 and R5 (the `must_have` rows) are all `direct`. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R5
- `important` — direct: R7a · adjacent: R6 (Define and maintain the metrics layer) · unclear: R7b (Partner with clinicians), R8 (Mentor two junior analysts)
- `preferred` — adjacent: R9b (HIPAA-governed data) · absent: R9a (Healthcare data experience)

R6 — a credible bridge, its limit named; R7b and R8 — unconfirmed, cheap to close; R9a — a real gap, tiered only `preferred`.

**Opportunity ledger.** Nothing in the posting points to a problem, but the employer could not be checked (RR1) and the JD states no pay or location terms (RR2). The remit is wide for one seat (RR3), and the roles and partners it names are concrete (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Harborlight and the live posting verify — RR1; (2) pay, location and work model fit what you need — RR2; (3) the HIPAA bridge is framed as adjacent and never as healthcare experience — R9a, R9b.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up of ~400 people at Series C | `[grounded]` JD header; not checked against any outside source |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, self-serve Looker dashboards, partnering with product managers and clinicians, mentoring two junior analysts | `[grounded]` JD |
| Seniority shape | Senior individual contributor with a mentoring duty; no direct reports stated | `[inferred]` from the mentoring line and the absence of any management language |
| Compensation | Not stated | `[grounded]` JD silent |
| Location and work model | Not stated | `[grounded]` JD silent |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Market calibration | Not established. The role-family search was denied, so no pay band or title norm is offered | `[grounded]` research accounting below |
| Unknowns | Pay, location and work model, work authorization, success measures, reporting line, who maintains the warehouse models under the metrics layer | `[grounded]` JD silent on each |
| Contradictions | None found between the JD and your background. The JD was not compared with the employer's own careers page | `[grounded]` the two inputs you gave |

## Evidence map

Your background came in as prose, so it counts as self-report and no row can rise above `medium` until you attach something inspectable.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | You state 6 years of product analytics at a consumer-subscription company. Specific and plausible, with nothing inspectable yet, so expect a probe | `[grounded]` intake prose | none |
| R2 | Expert SQL | must_have | direct | medium | none | You state daily SQL on a Snowflake warehouse. "Expert" is the JD's word, and daily use is the evidence you gave for it | `[grounded]` intake prose | A sanitized query or model you wrote would raise it to `high` |
| R3 | Experiment design at scale | must_have | direct | medium | none | You designed and ran the program (30+ A/B tests a year) on a base of about 2M subscribers, including the pricing test behind an 11% retention lift. The JD does not define "at scale", so whether this clears its bar is not established | `[grounded]` intake prose; `[inferred]` that the JD's bar is undefined | A sanitized write-up of the pricing test would raise it to `high` |
| R4 | Looker or a similar BI tool | must_have | direct | medium | none | You built the Looker instance from scratch, with 40+ governed dashboards. The 40+ counts dashboards, not users or queries | `[grounded]` intake prose | Dashboard screenshots or a LookML excerpt would raise it to `high` |
| R5 | Written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads and present to the VP Product monthly. Both are specific | `[grounded]` intake prose | A sanitized memo would raise it to `high` |
| R6 | Define and maintain the metrics layer | important | adjacent | low | discovery | "Governed dashboards" and a from-scratch Looker build sit next to a metrics layer. You did not say you defined or owned metric definitions, so ownership is not established. Reading that ownership into "governed" would widen your claim | `[grounded]` intake prose; `[inferred]` adjacency | Ask G1 |
| R7a | Partner with product managers on roadmap decisions | important | direct | medium | none | A monthly presentation to the VP Product is a standing product-leadership channel. Whether it changed roadmap decisions is not stated | `[grounded]` intake prose | Name one decision the analysis changed |
| R7b | Partner with clinicians | important | unclear | low | discovery | Nothing in your background mentions clinicians or other domain experts | `[grounded]` intake silence | Ask if it matters after G1 and G2 |
| R8 | Mentor two junior analysts | important | unclear | low | discovery | You mention no mentoring, onboarding or reviewing of junior analysts. Silence is not absence | `[grounded]` intake silence | Ask G2 |
| R9a | Healthcare data experience | preferred | absent | none | capability | You have never worked in healthcare. Preferred-tier, so a minor risk and not a blocker | `[grounded]` your statement | Say it plainly in the application; no closure needed for a `preferred` row |
| R9b | HIPAA-governed data handling | preferred | adjacent | medium | transferability | You handled GDPR/CCPA consumer PII and built the consent-state model for your warehouse. Limit: that was consumer PII, not health data. You have not exercised HIPAA's rules on protected health information, business associate agreements or de-identification | `[grounded]` intake prose; `[generic]` that HIPAA work involves those elements | Say what carries over and what does not |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer ownership (R6, important) | discovery | Governed dashboards and a Looker build, but no statement that you defined the metrics behind them | It is the JD's first responsibility, so it sets what you lead with | Writing LookML measures others reused; a metric dictionary; settling a disputed definition such as "active member" or "retained" | A metric spec, a LookML excerpt, or a definitions doc | `[grounded]` intake silence on ownership; `[generic]` that metrics-layer work usually turns on definition ownership |
| G2 | Mentoring (R8, important) | discovery | No mention of junior analysts | A named duty in the JD, and a likely interview topic | Onboarding a new analyst, reviewing SQL or analyses, running a team office hour | Nothing formal needed; a specific example is enough | `[grounded]` intake silence; `[generic]` that mentoring is probed in senior analyst loops |
| G3 | Clinician partnership (R7b, important) | discovery | Nothing on working with domain experts | Clinicians are one of the two named partner groups | Working with operations, culinary or nutrition staff on analyses; any non-analyst domain expert whose input shaped a metric or test | A short example | `[grounded]` intake silence |
| G4 | Healthcare and HIPAA exposure (R9a, R9b, preferred) | transferability | Consent-state modelling on consumer PII only | A `preferred` row, so it moves the application little, but an interviewer may ask | Access controls, PII minimization, de-identification, audit trails, or privacy reviews you took part in | A privacy design note you can share | `[inferred]` bridge from the consent-state model; `[generic]` that the limit is protected health information |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. I could not check, because search was denied | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay, location and work-model terms unstated | unknown | — | "— (the pasted JD states none)" | The terms may sit outside the pasted text, or the posting may withhold them | `[grounded]` JD silence | What is the pay range for this role, and is it remote, hybrid or on-site? | unresolved |
| RR3 | Wide remit for one seat | risk_signal | low | "define and maintain the metrics layer, design and analyze A/B tests, build self-serve dashboards in Looker, partner with product managers and clinicians" | Several workstreams may exceed one person's time if analytics-engineering support is thin. Taken as low because the JD does not say the support is missing | `[inferred]` from the JD's list against its silence on engineering support | Who maintains the warehouse models beneath the metrics layer, and how is time split between experiments, dashboards and mentoring? | unresolved |
| RR4 | Concrete roles and partners named | positive_signal | — | "mentor two junior analysts" | The team already exists, and the partner groups are named, so the scope looks defined | `[inferred]` from named roles against vague-posting language | Where do the two junior analysts sit today, and who would you report to? | noted |

## Application plan

Each block below is proposed. Nothing is final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the live posting and employer through the company's own careers page before investing effort | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Lead with the experimentation program (30+ tests a year, including the pricing test behind the 11% retention lift), the Looker build (40+ governed dashboards) and the monthly exec memo | see R3, R4, R5 | `[grounded]` your intake statements | pending your approval |
| A3 | Frame the privacy work as: "built the consent-state model for our warehouse and handled GDPR/CCPA consumer PII". Add that you have not worked with health data. Don't call it HIPAA experience | see R9a, R9b | `[grounded]` your two statements | pending your approval |
| A4 | Put the RR2 and RR3 questions to the employer verbatim before or in the first call | see RR2, RR3 | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | I searched "Harborlight Health care navigation app careers", and the call was refused. It would have fed the employer-not-established entry, RR1, and the contradictions row |
| 2. Role-family sweep | unavailable | I searched "senior product analyst digital health salary range 2026", and the call was refused. It would have fed the market calibration row and the pay check against your floor |
| 3. Hiring manager's public footprint | n/a | The JD names no one, so there was no query to form |

## Upgrade menu

- Your pay floor, location or work-model limits, and work authorization → the hard-gates line gets real checks, and RR2 resolves against them.
- Search permission → the employer check clears or confirms RR1, and a pay band lets me set the unstated pay against your floor.
- A sanitized pricing-test write-up, a Looker or LookML excerpt, or a sanitized monthly memo → R3, R4 and R5 can reach `high`.
- An answer to G1 → R6 moves from adjacent toward direct, or the limit gets named.
- A hiring manager's name → the scope read and which of your stories to lead with.

If you want, I can save this as a `tuesday-dossier.md` so later work builds on it.

C1 — What are your non-negotiables for a role like this: pay floor, location or work model, and work authorization?

G1 — In the dashboards you built, did you define the underlying metrics yourself (LookML measures, a definitions doc, settling what "retained" means), and who else relied on those definitions?

G2 — Have you mentored or onboarded junior analysts, formally or informally? Who, over what period, and what changed for them?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.