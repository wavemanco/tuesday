**No, this posting isn't worth pursuing as written. R1 and R2, both hard gates, fail. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (Base $70–85k against a $150k floor), R2 (On-site Austin five days, remote-only)
- `must_have` — direct: R3, R4, R5 · unclear: R6 (SEO/content)
- `important` — unclear: R7 (Brand, PR), R8 (Partnerships, sales ops), R9 (Team of one to start)

R1, R2 — failed on terms the posting states as fixed; R6, R7, R8, R9 — open channel and structure questions that would matter if the terms moved.

**Opportunity ledger.** Terms against your constraints are RR1 and RR2. The scope and expectations entries (RR3, RR4, RR5, RR6) read as a stretched mandate with open-ended demands, which matches the "off" feeling. RR7 runs the other way, and the employer itself is unchecked (RR8).

- **Hard gates:** failed: R1 (Base $70–85k against a $150k floor), R2 (On-site Austin five days, remote-only).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would change this:** R1 would need a base at or above your $150k floor. R2 would need remote work from Portland, which the posting rules out in "no exceptions". The base term is the employer's to change and the remote term is yours or theirs. Better wording on your side doesn't affect either.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` JD header; the profitability claim is the posting's own, unchecked |
| Mandate | Own revenue growth across paid, SEO/content, lifecycle/CRM, brand, PR, partnerships and sales ops | `[grounded]` JD |
| Team and reporting | A team of one to start; reports to the CEO, dotted line to the board | `[grounded]` JD |
| Working pattern | On-site Austin five days a week, "no exceptions"; "evenings and weekends when it matters" | `[grounded]` JD |
| Compensation | $70–85k base plus "meaningful equity upside"; equity terms unstated | `[grounded]` JD |
| Scope read | Seven functions with no staff sits broader than a single-function head role under a Head title | `[inferred]` from the function count against "team of one" |
| Market calibration | Not available. The role-family sweep did not run, so no band is stated | n/a, see Evidence status |
| Unknowns | Equity terms, marketing budget, hiring plan, what success means, how profitability is evidenced | `[grounded]` JD silence |
| Contradictions | None visible inside the posting; the employer's own pages were not checked | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Base at or above your $150k floor (JD: "$70–85k base plus meaningful equity upside") | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated floor. Fit fails because the posted top of range is $65k below it. No equity terms are stated, so equity cannot offset a base-pay floor | `[grounded]` JD and your stated floor | Surface in the snapshot; the employer or you changing terms resolves it |
| R2 | On-site Austin, five days a week (JD: "no exceptions") against your remote-only, Portland constraint | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated constraint. The posting rules out remote and you won't relocate | `[grounded]` JD and your stated constraint | Surface in the snapshot; the employer changing terms resolves it |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | You state 9 years in growth, growth lead then Head of Growth. The split of leadership years is not given, so I took the reading that claims less. Self-report with no inspectable artifact yet, so expect a probe | `[grounded]` your description | Confirm the year you took your first leadership title |
| R4 | Paid acquisition | must_have | direct | medium | none | You state you owned paid, with a controlled budget while scaling $8M to $40M ARR over three years. Specific but not inspectable | `[grounded]` your description | An exported channel report or board update would raise it to `high` |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You state you owned lifecycle and are deep in Braze, SQL and GA4. Specific but not inspectable | `[grounded]` your description | Campaign or cohort reporting would raise it to `high` |
| R6 | SEO/content | must_have | unclear | none | discovery | Your description names paid, lifecycle and experimentation; SEO and content are not mentioned | `[grounded]` description silent | See G1 |
| R7 | Brand and PR | important | unclear | none | discovery | Not mentioned in your description | `[grounded]` description silent | See G2 |
| R8 | Partnerships and sales ops | important | unclear | none | discovery | Not mentioned in your description | `[grounded]` description silent | See G2 |
| R9 | Operating as a team of one | important | unclear | low | discovery | You built and managed teams of 3–7. Nothing says you ran all channels with no staff, so the adjacency is indirect | `[grounded]` your team sizes; `[inferred]` that solo execution is untested | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content (R6, must_have) | discovery | Nothing in your description on organic search or content | A `must_have` row at `unclear`; closing it would not move `no_go` while R1 and R2 stand | Owning landing pages or a content calendar tied to sign-ups; briefing writers or an agency on keyword targets | A Search Console export, a content brief, an organic traffic report | `[grounded]` description silent; `[inferred]` status would not move |
| G2 | Brand, PR, partnerships, sales ops (R7, R8, important) | discovery | Silent on all four | Four functions of the seven the posting bundles | Co-marketing or affiliate deals you negotiated; press you secured; CRM-to-sales handoffs you designed | A partner agreement, a press clipping, a lead-routing spec | `[grounded]` description silent; `[inferred]` status would not move |
| G3 | Solo operation (R9, important) | discovery | Teams of 3–7 are stated; no stretch with no staff is stated | The posting says "team of one to start" | An early stage before you hired; a period where you ran channels yourself | A role timeline showing team size by period | `[grounded]` description; `[inferred]` status would not move |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posted base below your floor (R1) | red_flag | high | "$70–85k base plus meaningful equity upside" | The posted range cannot meet your $150k base floor | `[grounded]` JD against your stated floor | Is the base range fixed at $70–85k for this role? | confirmed |
| RR2 | On-site five days against remote-only (R2) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | The posting rules out the working arrangement you require | `[grounded]` JD against your stated constraint | Is the five-day Austin requirement fixed for this role? | confirmed |
| RR3 | Seniority-compensation mismatch | risk_signal | medium | "8+ years growth leadership required" with "$70–85k base" | The figure may sit below what the title and mandate usually carry; no market band was checked, so I take the lower severity | `[inferred]` from the posting's own seniority and mandate against its figure | What is the full cash range budgeted for this role, and what are the equity terms? | unresolved |
| RR4 | Bundled specializations, no stated resources | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops… a team of one to start" | Seven functions may be folded into one title with no stated budget or headcount | `[inferred]` from the function list against the posting's silence on budget | What marketing budget and headcount are committed for the first year? | unresolved |
| RR5 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Out-of-hours work may be a standing expectation, not an exception | `[inferred]` from the posting's framing of it as identity | How often did evenings and weekends come up last quarter? | unresolved |
| RR6 | Success undefined on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | Accountability for all revenue growth with no stated definition of success | `[inferred]` from the quote against "own all revenue growth" | What outcome would count as a strong first year, and who sets it? | unresolved |
| RR7 | Senior reporting line | positive_signal | — | "Report to the CEO with a dotted line to the board" | Access to decision-makers is stated | `[grounded]` JD | Who sets the growth targets, the CEO or the board? | noted |
| RR8 | Employer not yet checked | unknown | — | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | Whether the company and posting match this description was not verified | `[grounded]` search refused, nothing checked | Can you point me to this role on your own careers page? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply on the current terms | see R1, R2, RR1, RR2 | `[grounded]` map and register | pending your approval |
| A2 | If you want to test whether the terms move, ask the employer the RR1 and RR2 questions before spending any application effort | Asks whether the gates are met, not for a workaround | `[grounded]` register | pending your approval |
| A3 | If the terms ever did move, lead with R3, R4 and R5 as you described them, with the verification caveat named, and make no claim on SEO, PR, partnerships or sales ops without evidence | see G1, G2 | `[grounded]` map | pending your approval |

## Evidence status

Verified: none yet. Leads to confirm: R3's leadership-year split.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Austin Series A"; the call was refused, so nothing came back. It would have moved role reality's organization row and RR8 |
| 2. Role-family sweep | unavailable | Searched "Head of Growth salary Series A startup base compensation range"; the call was refused. It would have moved the market calibration row and RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given |

If you'd like this kept on file, I can write it up as `tuesday-dossier.md`.

**Upgrade menu**

- Search access, so targets 1 and 2 can run: RR8 and RR3 would get checked. Neither could change `no_go`, because R1 and R2 fail on the posting's own terms.
- The employer's answer on whether the base range and the on-site requirement are fixed: this is the one input that could move R1, R2, RR1 and RR2.
- Your resume or links to a channel report, board update or Braze campaign report: R3, R4 and R5 could rise to `high`.
- Any SEO, PR, partnership, sales-ops or solo-operation work: R6, R7, R8 and R9 would get a fit call.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.