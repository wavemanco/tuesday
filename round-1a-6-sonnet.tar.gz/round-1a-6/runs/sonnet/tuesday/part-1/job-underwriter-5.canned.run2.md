I checked the live posting and the company page against what you pasted, then ran the full assessment.

## Decision snapshot

**Yes, this is worth applying to. R3, R4, R5, R6, R7 and R8 are the `must_have` rows, and all six are `direct`. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity)
- `must_have` — direct: R3, R4, R5, R6, R7, R8
- `important` — adjacent: R9 (BigQuery specifically); unclear: R10 (ingestion from app and CRM), R11 (data contracts)

R9 (`medium`) — a credible bridge, its limit named; R10 and R11 — your background is silent, one question each.

**Opportunity ledger.** Pay is disclosed and sits in the market range (RR4). The open items are team shape and reporting line (RR2), first-year outcomes (RR3), equity terms (RR5), and funding figures that come only from the company's own pages (RR1).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) remote from the US, or Denver, works for you (R1); (2) $148,000–$166,000 plus equity meets your pay floor (R2); (3) your BigQuery gap is stated plainly and not papered over (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` company's about page, fetched. It is the company's own statement |
| Mandate | Build and run the pipelines behind tutoring-platform reporting: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Posting status | Live ("Accepting applications"), and its text matches what you pasted | `[grounded]` careers page fetched |
| Scope read | End-to-end ownership of one reporting domain's pipelines; the JD mentions no direct reports | `[inferred]` from "build and run" and the JD's silence on managing people |
| Market calibration | Datawright 2026 (n=2,310), Senior Data Engineer at Series B–D companies: base median $151,000, IQR $139,000–$163,500. The posted $148,000 is $3,000 below the median. The posted $166,000 is $2,500 above the third quartile. The report puts "Senior" at typically 5–8 years, and your 6 years sit inside that. The band is a market pattern, never this employer's offer. | `[grounded]` your recruiter's report and the JD figures; `[generic]` as a pattern for this title and stage |
| Hiring manager | None named in the posting | `[grounded]` JD |
| Unknowns | Team size and reporting line; first-year outcomes; equity grant and vesting; which orchestrator ("Airflow or similar") | `[grounded]` JD silence |
| Contradictions | None between the pasted text and the live pages | `[grounded]` both pages fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You have not stated where you are or what you will work. A gate the inputs do not settle stays unclear | `[grounded]` no constraint given | Question C1 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | Your pay floor was not given, so whether the range clears it is unknown. The range is in market (RR4), but that is not your floor | `[grounded]` no floor given; `[generic]` market placement | Question C1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years at a B2B payroll company. It is self-report with nothing inspected yet, so `medium` | `[grounded]` your stated background | Offer: none needed unless probed |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You state daily use of both. Self-report, no artifact inspected | `[grounded]` your stated background | none |
| R5 | dbt | must_have | direct | medium | none | You built the company's dbt project, about 180 models, on Snowflake. Specific, no artifact inspected | `[grounded]` your stated background | A sanitized dbt docs or lineage view would raise it to `high` |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse. The role's own warehouse is BigQuery, which is R9 | `[grounded]` your stated background | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | You state Airflow orchestration. Airflow is named in the JD | `[grounded]` your stated background | A sanitized DAG listing would raise it to `high` |
| R8 | Data quality testing | must_have | direct | medium | none | You set up the company's Great Expectations suite | `[grounded]` your stated background | The suite's config or data docs would raise it to `high` |
| R9 | BigQuery (the role's warehouse) | important | adjacent | medium | transferability | Snowflake plus dbt is credible adjacent work. Limit: you have never used BigQuery. Its cost model and table-design habits differ from Snowflake's, so expect a probe. This is a requirement I inferred from the mandate, not a quoted must-have | `[inferred]` from the JD's "dbt-modelled warehouse in BigQuery"; `[generic]` that warehouses differ in cost and table design | See G3 |
| R10 | Ingestion from the app and the CRM | important | unclear | low | discovery | Your background states Airflow and dbt but not which sources you ingested. Nothing here confirms app or CRM sources | `[grounded]` background silence | G1 |
| R11 | Data contracts analysts depend on | important | unclear | low | discovery | The Great Expectations suite is related, but nothing you have said establishes agreed contracts with analysts | `[grounded]` background silence | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Ingestion from the app and the CRM (R10, important) | discovery | Airflow and dbt are established, but not which source systems fed your pipelines | The JD lists ingestion first in the mandate, so a clear answer lets you lead with it | Pulling product-event or database data into the warehouse; loading a CRM such as Salesforce or HubSpot; building or maintaining Airflow loads from SaaS APIs | A DAG listing, an architecture sketch, or a source inventory, all sanitized | `[grounded]` background silence; `[inferred]` that it matters because the JD names it first |
| G2 | Data contracts (R11, important) | discovery | The testing suite is established, but not any agreement with downstream analysts | The JD names contracts as something analysts depend on, so it is likely probed in a screen | A schema or freshness agreement with analysts; tests that blocked a bad load; an owner-and-SLA doc for a model | A sanitized contract doc, a test config, or an incident write-up | `[grounded]` background silence; `[generic]` that screens for this role family probe it |
| G3 | BigQuery specifically (R9, important) | transferability | Snowflake and dbt carry over; BigQuery use does not exist | The role's warehouse is BigQuery, so this is the most likely objection | A small dbt project run against BigQuery; any prior GCP exposure you have not mentioned | A repo or a short write-up | `[inferred]` bridge from Snowflake and dbt; `[generic]` that this is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Funding and headcount come only from the company's own pages | unknown | — | "Series C ($52M, February 2026)" | The figures may be accurate and simply not covered elsewhere, or I may not have found independent sources. One search returned only the company's own page | `[inferred]` from the one search's single result | Is this a new position or a backfill, and what does the data team's plan for the next year look like? | unresolved |
| RR2 | Team shape and reporting line are unstated, and no hiring manager is named | unknown | — | "Build and run the pipelines" | This could be a lone data engineer owning ingestion, modelling and contracts, or one of several | `[inferred]` from the JD's silence on team | Who is on the data team today, and who does this role report to? | unresolved |
| RR3 | No first-year outcomes for a build-and-run mandate | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | Success may be undefined, or defined in the interview but not in the posting | `[inferred]` from the JD's silence | What would a successful first year look like for this role? | unresolved |
| RR4 | Pay disclosed and in line with market | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range spans from just under the report's median to above its third quartile, so it is not a seniority-pay mismatch | `[grounded]` JD figures and the report's published figures; `[generic]` peer set | Where in this range would someone with my experience land? | noted |
| RR5 | Equity terms unstated | unknown | — | "plus equity" | The grant cannot be valued without its size, form and vesting | `[inferred]` from the JD's single word on equity | What form does the equity take, what is typical at this level, and what is the vesting schedule? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Resume: put the dbt project (about 180 models) and the Great Expectations suite you set up at the top of the payroll role | See R5 and R8 | `[grounded]` your stated background | pending your approval |
| E2 | Resume: name Snowflake as your warehouse experience and do not list BigQuery. In a screen, say plainly you haven't used it and say what carries over | See R9 | `[grounded]` your stated background | pending your approval |
| W1 | Optional: a small dbt-on-BigQuery project to narrow the R9 limit | See R9, G3 | `[inferred]` from the R9 gap | pending your approval |
| Q1 | Ask RR1, RR2, RR3 and RR5 verbatim in the loop, and RR4's question when pay comes up | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning online tutoring K-12 Series C $52M", which returned "About Pellucid Learning" (pellucidlearning.com/about). Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer). The call checked your pasted material: the posting is live, and both pages match what you pasted. The only source found was the company's own site, which is RR1 |
| 2. Role-family sweep | skipped | Your pasted Datawright report already fixes the market calibration line and RR4, so a search would add nothing to either |
| 3. Hiring manager's public footprint | n/a | The posting names no one, so there is no query to form |

## Upgrade menu

- Your location, pay floor and any non-negotiables → R1 and R2 resolve, and the hard-gates line moves from unconfirmed to met or failed.
- Answers to G1 and G2 → R10 and R11 firm up and the application plan gains lead stories.
- A sanitized dbt docs or lineage view, the Great Expectations config or data docs, or a DAG listing → R3 to R8 can rise from `medium` to `high`.
- The hiring manager's name → the scope read and which story to lead with for that reader.
- A deeper pass on Pellucid (funding, leadership changes, employee reports, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

A `tuesday-dossier.md` of this assessment is available if you'd like to keep it.

C1 (R1, R2) — Do the role's terms, remote from the US or Denver and $148,000–$166,000 plus equity, work for you on location and on your pay floor?

G1 (R10) — Which source systems fed your pipelines, and did any come from the product itself or a CRM?

G2 (R11) — Did you ever agree schemas, freshness or ownership with the analysts who used your models, and what happened when a test failed?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.