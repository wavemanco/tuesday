**Yes, apply, once the employer and posting check out (RR2) and R1 is confirmed. Status: `conditional_go`.**

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote, UK-based)
- `must_have`: direct: R2, R3, R4, R5, R6, R8, R9 · adjacent: R7 (Monitor rating models)
- `important`: adjacent: R11 (Own pricing analytics for the whole product) · unclear: R10 (Recommendations for product)
- `preferred`: direct: R12 · adjacent: R13 (Pet-insurance knowledge)

R7 (`low`): she says "maintained", not monitored; R10: nothing stated on product-side work; R13: a credible bridge, its limit named.

**Opportunity ledger.** Concrete deliverables (RR5), but the employer could not be established from here (RR2), and the salary (RR1), authority over recommendations (RR3) and team shape (RR4) are unstated.

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK-based); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify (RR2); (2) R1 confirmed; (3) the salary, once known, clears your floor (RR1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech; pet-insurance product | `[grounded]` JD header; existence not established, see RR2 |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing | `[grounded]` JD; public footprint not researched |
| Working pattern | Fully remote (UK) | `[grounded]` JD |
| Scope read | Shaped as a hands-on analyst post: the JD names no reports or team | `[inferred]` from the JD's silence on people management |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Market calibration | Not available: searches were refused, and no band is given from memory | `[grounded]` research status below |
| Unknowns | Salary; contract type; team size and reports; who decides on recommendations; data volume and test infrastructure for the pet book | `[grounded]` JD silent on each |
| Contradictions | None between the JD's own lines | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK-based | hard_gate | unclear | low | hard_gate | The JD says "Fully remote (UK)". Your location and right to work are not stated, only that your employer is a UK insurer | `[grounded]` JD; `[inferred]` UK base from your UK employer | Ask: closing question R1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years pricing analytics at a UK motor insurer, stated; nothing inspected yet | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily", stated. "Strong" is your usage, not a measured level; no code seen | `[grounded]` your background | A sanitised query or notebook would raise to `high` |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for the young-driver book. Specific, but a motor segment, not pet | `[grounded]` your statement | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your statement | none |
| R6 | Build rating models | must_have | direct | medium | none | "Built" the GLM rating model for one book (young drivers); the scope stays as stated | `[grounded]` your statement | none |
| R7 | Monitor rating models | must_have | adjacent | low | discovery | You say "maintained". That may include monitoring (drift, actual versus expected), but none is stated, so it resolves downward | `[grounded]` your wording; `[inferred]` that maintenance may include monitoring | G1 |
| R8 | Design and read price tests | must_have | direct | medium | discovery | You "ran" 14 tests last year with underwriting. Reading them is covered; whether you designed them (hypotheses, sizing, controls) is not stated | `[grounded]` your statement | G2 |
| R9 | Turn results into recommendations for underwriting | must_have | direct | medium | none | Tests run with the underwriting team; quarterly review to its head | `[grounded]` your statement | none |
| R10 | Recommendations for product | important | unclear | low | discovery | Nothing in your background touches a product team | `[grounded]` background silent | G3 |
| R11 | Own pricing analytics for the whole pet product (inferred from the role's own wording) | important | adjacent | medium | transferability | You owned the GLM for one book and ran the tests. Limit: a segment is not a whole product line | `[inferred]` adjacency from segment-level ownership | G4 |
| R12 | Insurance experience, a plus | preferred | direct | medium | none | Five years at an insurer | `[grounded]` your background | none |
| R13 | Pet-insurance knowledge (inferred from the product named in the role) | preferred | adjacent | medium | transferability | You state no pet work. Carries over: GLM and price-testing on a personal-lines motor book. Limit: pet-specific rating factors such as breed are not exercised | `[grounded]` your statement; `[generic]` that pet rating uses factors with no motor equivalent | Name the limit in the application |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Monitoring rating models (R7, must_have) | discovery | "Maintained" the GLM; no monitoring routine named | A must_have at `low`; resolving it is the most likely way to firm up the model-ownership half of the role | Actual-versus-expected tracking, drift or stability checks, back-tests after a rate change, a refit trigger you set | A monitoring pack, a model-review document, a dashboard screenshot | `[grounded]` wording gap; `[inferred]` that it is the likeliest probe |
| G2 | Test design (R8, must_have) | discovery | 14 tests "run" with underwriting; your part in design is not stated | "Design and read" is half the role's second duty | Choosing hypotheses, sizing, holdouts or controls; writing the readout | A test readout or design note, sanitised | `[grounded]` your wording; `[inferred]` on the design half |
| G3 | Product-side recommendations (R10, important) | discovery | No product-team work stated | The JD names product as a second audience | Presenting a test result to a product owner; a pricing change that fed a product decision | A deck or note aimed at product | `[grounded]` background silent |
| G4 | Whole-product ownership (R11, important) | transferability | Segment-level GLM ownership; no whole-product claim | "Own" is the JD's word | Bridge: the GLM and 14 tests carry over. Limit: one book is not a product. Strengthener: show the model's place in the wider rating structure | Model documentation, sanitised | `[inferred]` bridge from your stated work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Salary not stated | unknown | — | (the pasted JD gives no pay figure) | The pay may be unpublished or may sit below what the role needs | `[inferred]` from the JD's silence | What salary band is budgeted for this post? | unresolved |
| RR2 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR3 | Recommendations without stated authority | unknown | — | "turn the results into recommendations for underwriting and product" | The role may recommend while others decide | `[inferred]` from "recommendations" against the JD's silence on decision rights | Who decides whether a test result or rating change goes live? | unresolved |
| RR4 | Reports and team size unstated | unknown | — | "Own pricing analytics" (no team described) | The post may or may not carry reports; you have not managed anyone | `[inferred]` from the JD's silence | Does this role have or expect direct reports, and how big is the pricing team? | unresolved |
| RR5 | Concrete deliverables and a named senior owner | positive_signal | — | "build and monitor rating models, design and read price tests" | The scope is specific and sits under a Director of Pricing | `[grounded]` JD | What does success look like in the first year? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before investing effort, find the role on Brindlemoor's own careers page, and check the recruiter's email domain | see RR2 | `[grounded]` RR2 | pending your approval |
| A2 | Lead with the GLM rating model for the young-driver book and the 14 price tests, keeping your own wording ("built and maintained", "ran") | see R4, R6, R8 | `[grounded]` your statements | pending your approval |
| A3 | Draft line: "I have not worked on pet insurance; I built and maintained a GLM rating model for a motor young-driver book and ran 14 price tests with underwriting last year." | see R13; each clause traces to your sentences | `[grounded]` your statements | pending your approval |
| A4 | Ask RR1, RR3 and RR4 verbatim in the screen | The register doubles as interview preparation | `[grounded]` register | pending your approval |

No CV was provided, so no resume edits are proposed.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search "Brindlemoor pet insurance insurtech careers" was refused. It would have moved the employer-not-established entry (RR2) and role reality's organization row |
| 2. Role-family sweep | unavailable | Search "senior pricing analyst pet insurance UK salary remote" was refused. It would have moved market calibration and the salary check against RR1 |
| 3. Hiring manager's public footprint | unavailable | Search "Odile Varga Director of Pricing Brindlemoor" was refused. It would have moved the scope read and which story to lead with in A2 |

I'm treating the refusals as final and haven't retried.

If you'd like a `tuesday-dossier.md` of this assessment to carry forward, say so and I'll emit it.

## Upgrade menu

- Your CV → resume edits for the rows above, and a check of R2–R6 against the document itself.
- A sanitised SQL or Python sample → R3 to `high`. GLM model documentation → R4 and R6 to `high`. A price-test readout → R8.
- A link to the live posting or the company's careers page → RR2 closes.
- The salary band and your floor → RR1 closes and is set against your floor.
- Search permission → targets 1–3 run, filling market calibration, RR2 and the hiring manager's public footprint.

**Questions** (any of these can be answered in text, by voice transcript, by attachment, by link, or skipped)

R1 — What are your non-negotiables for a role like this: UK base and right to work, pay floor, contract type?

R8 — On the 14 price tests, which parts did you personally own: hypotheses and design, sizing and controls, the analysis, the readout? What changed as a result?

R7 — Once the young-driver GLM was live, which monitoring checks did you run (drift, actual versus expected, back-tests), how often, and what did you do when one moved?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.