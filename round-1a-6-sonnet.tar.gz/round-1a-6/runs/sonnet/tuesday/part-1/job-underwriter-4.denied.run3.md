Web search was declined, so this runs on your JD and background alone.

## Decision snapshot

**Yes, apply. Pet-specific experience and managing people aren't in the JD's list: R9 asks only for insurance as a plus, and RR4 records that reports are unstated. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote (UK))
- `must_have`: direct: R2, R3, R4, R5, R6, R7
- `important`: direct: R8a · adjacent: R10 (Own pricing analytics for the product) · unclear: R8b (Recommendations to product)
- `preferred`: direct: R9 · adjacent: R11 (Pet-insurance knowledge)

R10: a credible bridge, its limit named; R6 (`medium`): confirmed, with design ownership still to be specified; R8b: the product side is unconfirmed.

**Opportunity ledger.** The responsibilities are concrete and a senior owner is named (RR5). The employer could not be checked from here (RR1), pay is withheld (RR2), decision rights are unstated (RR3), and whether the role has reports is unstated (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. You are UK-based, which closes R1.
  2. The employer and posting verify as live (RR1).
  3. Ownership of the whole product turns out to be compatible with your segment-level experience (R10, RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD header; not independently checked |
| Hiring manager | Odile Varga, Director of Pricing | `[grounded]` your message |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, and turn results into recommendations for underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote (UK) | `[grounded]` JD |
| Scope read | One product, with recommendations going to two functions, and no team or reports mentioned | `[inferred]` from the mandate wording against the JD's silence on headcount |
| Pet versus motor | Pet pricing is likely to rate on different factors than motor, such as the animal's breed and age and vet-cost trends, so expect a domain ramp-up | `[generic]` role-family pattern, not a claim about this employer |
| Market calibration | Not calibrated: the role-family search was refused, so no pay band is offered | — |
| Unknowns | Salary; decision rights over rating changes; whether the role has or will have reports; tooling and data; first-year outcomes | `[grounded]` JD states none of these |
| Contradictions | None inside the JD; it could not be checked against a careers page | `[grounded]` JD text only |

## Evidence map

Your background is typed prose, so it counts as self-report, and `medium` is the ceiling on a first pass.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | low | hard_gate | You haven't stated where you are based. A UK employer is a hint, not a statement | `[inferred]` from UK motor-insurer employment | G1 question |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in pricing analytics, two of them senior. Self-reported, nothing inspected | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Daily" use is stated. "Strong" is the JD's word and nothing shows the level | `[grounded]` your background | A sanitized query or notebook sample would raise it to `high` |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. Specific, but no artifact inspected | `[grounded]` your background | Sanitized model documentation (factors, validation) would raise it to `high` |
| R5 | Build and monitor rating models | must_have | direct | medium | discovery | "Built and maintained" is stated. Monitoring specifics (drift, loss-ratio tracking, refit triggers) are not | `[grounded]` your background; monitoring detail is a gap | Add monitoring detail when answering G2 |
| R6 | Design and read price tests | must_have | direct | medium | discovery | You ran 14 tests last year with underwriting. "Ran" doesn't say whether you designed them (hypothesis, split, sizing) or read the results, so this takes the lower reading | `[grounded]` your background | G3 question |
| R7 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your background | A sanitized review pack would raise it to `high` |
| R8a | Turn results into recommendations for underwriting | important | direct | medium | none | Tests ran with the underwriting team, and the quarterly review is delivered to their head | `[grounded]` your background | none |
| R8b | Turn results into recommendations for product | important | unclear | low | discovery | No product-facing work is stated | `[grounded]` silence in your background | Ask the employer (RR3 question); mention any product-team work if you have it |
| R10 | Own pricing analytics for the product | important | adjacent | medium | discovery | You owned the GLM for one segment (young drivers). The JD's wording suggests whole-product ownership, and that scale isn't evidenced. Likely broader than a segment | `[grounded]` your background; `[generic]` on the scale of whole-product ownership | G2 question |
| R9 | Insurance experience | preferred | direct | medium | none | Five years at a UK motor insurer | `[grounded]` your background | none |
| R11 | Pet-insurance knowledge (inferred: pet product, "insurance experience a plus") | preferred | adjacent | medium | transferability | Motor rating (GLM, tests, underwriting liaison) carries over. Pet-specific risk factors and claims behaviour haven't been exercised | `[inferred]` from the JD's product against your motor background | Bridge case in G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | UK location (R1, hard_gate) | hard_gate | No statement of where you are based | A gate; unresolved, it holds the status below a plain `go` | Not applicable: this is a yes/no on whether the gate is met | None needed | `[grounded]` your message is silent on location |
| G2 | Whole-product ownership and model monitoring (R10 important, R5 must_have) | discovery | A segment-level GLM, built and maintained; monitoring and end-to-end scope are unstated | A senior role that "owns" analytics is likely to be probed on scope | Owning the data prep, fit, validation, monitoring and rate-change hand-off; the young-driver book as a share of the motor account; refits you triggered | Sanitized model documentation or a monitoring dashboard screenshot | `[grounded]` your CV-level description; `[generic]` that scope gets probed in senior hiring |
| G3 | Test design versus test execution (R6, must_have) | discovery | 14 tests were run with underwriting; your role in design and readout is unstated | Price-test design is one of the role's named duties | Writing the hypothesis and success metric; choosing the split and sample size; presenting the readout and the call that followed | A sanitized test readout or a test-design template | `[grounded]` your background; `[inferred]` that the design side decides the fit |
| G4 | Pet-specific knowledge (R11, preferred) | transferability | Motor GLM, tests and underwriting liaison carry over; no pet or animal-claims exposure | A preferred row, but the product is pet insurance, so expect it to come up | Adjacent: frequency/severity modelling and rate-change work. Limit: the rating factors and claims dynamics differ. Strengthener: a short, honest note on how your motor method would be applied to pet | A one-page note of that kind | `[inferred]` adjacency from your motor work; `[generic]` that pet factors differ |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. Search was refused, so nothing was checked | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Salary not stated | unknown | — | "Fully remote (UK)." closes the posting with no figure | The figure may sit below the market band for this seniority, or the employer may simply not publish pay | `[inferred]` from the JD's silence | What salary range is budgeted for this post? | unresolved |
| RR3 | Decision rights and resources unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | The role may carry the analytics without authority over rating changes, which could sit with underwriting or product | `[inferred]` from the mandate wording against the JD's silence on decision rights | Which pricing decisions does this role make, and who signs off rating changes? | unresolved |
| RR4 | People management unstated | unknown | — | "Senior Pricing Analyst" (no reports mentioned) | The role may be an individual-contributor post, or may expect reports later | `[inferred]` from the JD's silence | Does this post have direct reports now, or is that expected to develop? | unresolved |
| RR5 | Concrete responsibilities and a named senior owner | positive_signal | — | "build and monitor rating models, design and read price tests" | The work is defined and sits under a Director of Pricing | `[grounded]` JD and your message | What would the first quarter's priorities be? | noted |

## Application plan

Each row is proposed. None is final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with the young-driver GLM and the 14 price tests, stating scope in your own terms. Don't use "designed" for the tests until G3 is answered | See R4, R6 | `[grounded]` your background | pending your approval |
| E2 | In the cover note or screen, name the motor-to-pet gap yourself and say how you'd close it | See R11, G4 | `[grounded]` R11 row | pending your approval |
| Q1 | Ask the verification questions from RR1 to RR5 verbatim in the screen with Odile Varga | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Confirm the role is live on Brindlemoor's own careers page before investing effort | See RR1 | `[grounded]` RR1 | pending your approval |

Extra offer, built only on your approval: a one-page motor-to-pet transfer note. It would give the honest case for G4 and its limits, since this role's main objection is likely to be domain, not method.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Brindlemoor pet insurance insurtech"; the call was refused and returned nothing. It would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | Searched "senior pricing analyst pet insurance UK remote salary"; the call was refused and returned nothing. It would have moved market calibration and RR2 |
| 3. Hiring manager's public footprint | unavailable | Searched "Odile Varga Director of Pricing"; the call was refused and returned nothing. It would have moved the scope read and which story the plan leads with |

I can save this as a `tuesday-dossier.md` if you'd like to carry it forward.

**Upgrade menu**

- Your location (G1) closes R1.
- Search access would let me retry targets 1 to 3 for RR1, the pay band and Odile's public footprint. A deeper pass on the company would cost up to 5 more searches and 2 more fetches.
- A sanitized GLM write-up, test readout or review pack would raise R4, R5, R6 and R7 toward `high`.
- A link to the live posting would check the JD and RR1.
- Anything you know about salary would close RR2.

**Questions**

- G1 (R1): Are you based in the UK and able to work from there on a fully remote basis?
- G2 (R10, R5): In your young-driver GLM work, what did you own end to end (data prep, fitting, validation, monitoring, rate-change hand-off), and how large was that book relative to the whole motor account?
- G3 (R6): For the 14 price tests, did you design them (hypothesis, split, sample size, success metric) or run tests someone else specified, and who made the call on the results?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.