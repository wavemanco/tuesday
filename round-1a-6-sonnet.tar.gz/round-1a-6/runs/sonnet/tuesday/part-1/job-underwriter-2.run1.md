Status: I've read the underwriter playbook and its evidence rules. Next I'll read the research-tier rules, run the L1 company check on Quartzline, and then write the assessment.
# Job Underwriting — Product Manager, Platform APIs at Quartzline

## Decision snapshot

**No, applying isn't a waste of your time, but it's a stretch application, not a strong match. R1b (titled PM years) is absent, and R1a and R2a are only adjacent. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R3, R4 · adjacent: R1a (PM work behind "3+ years"), R2a (Shipped API or platform products) · unclear: R2b (Internal request-triage tool), R5 (Agile delivery) · absent: R1b (Titled PM years)
- `important` — direct: R6 · adjacent: R7 (Specs, delivery with squads), R8 (Own the roadmap) · unclear: R9 (Adoption metrics), R10 (Sales and support launches)

R1a, R2a — credible bridges, limits named; R1b — titled tenure absent, a screen risk and not a gate; R2b, R9 — hinge on one unconfirmed lead; R5 — agile work not evidenced.

**Opportunity ledger.** The mandate is concrete (RR6), but it is unverified (RR1). It's unclear how strictly the 3+ years is applied (RR2), and decision rights, success measures and pay are all unstated (RR3, RR4, RR5).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. The employer confirms that PM-equivalent work without a PM title can satisfy "3+ years" (RR2, R1b).
  2. At least one of R2b, R5 and R9 firms up on your answers.
  3. The employer verifies as real and the posting is live (RR1).
- **What would change this:** a flat "titled PM years only" answer to RR2 turns this into `no_go`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B. Not checked against the company's own pages | `[grounded]` JD header; research unavailable |
| Mandate | Own the partner-facing API platform roadmap, run discovery with integration partners, write specs and drive two engineering squads, track adoption metrics, coordinate launches with sales and support | `[grounded]` JD |
| Scope read | A single PM across two squads is real ownership, not an assistant role | `[inferred]` from "own the roadmap" and "two engineering squads" |
| Pivot read | Your listed work sits closest to the partner-discovery and API-fluency half of this role. It sits furthest from the roadmap-ownership and metrics half | `[inferred]` from your resume against the JD's responsibilities |
| Market calibration | No band: the role-family sweep did not run. Platform and API PM postings usually weigh technical fluency heavily, which is where your evidence is strongest | `[generic]` role-family pattern, no search behind it |
| Unknowns | Pay; how strictly the 3+ years is applied; decision rights over priorities; success measures | — |
| Contradictions | None visible inside the JD; not cross-checked against a careers page | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years PM experience — the work itself | must_have | adjacent | medium | transferability | Your quarterly roadmap-input sessions and your coordination of PMs and engineers on custom builds are PM-adjacent. You supplied input to product and have never held PM decision rights, so the limit is prioritisation and ownership | `[grounded]` your resume; `[generic]` that screeners and interviewers weigh decision rights over input | G1: a concrete roadmap-input outcome |
| R1b | 3+ years PM experience — titled tenure | must_have | absent | none | capability | You confirm no PM title. The bridge sits in R1a and this row grades the title alone. It is a screen risk, not a gate | `[grounded]` your statement | RR2's question to the employer |
| R2a | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ client integrations of your employer's REST APIs and wrote the internal integration playbook. That is delivery on top of an API product, not shipping one | `[grounded]` your resume | Name which API-product changes your feedback drove (G1) |
| R2b | Shipped platform products — internal request-triage tool | must_have | unclear | low | discovery | Earlier agent memory suggests you built a triage tool that support agents adopted. It is unconfirmed, so it is a question and not evidence | `[grounded]` memory_lead only | G2 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI specs, 30+ REST integrations. Confirmed prose with nothing inspectable yet | `[grounded]` your resume | A sanitised integration design or spec would raise it to `high` |
| R4 | Stakeholder management across engineering and customers (the JD also names sales; see R10) | must_have | direct | medium | none | You coordinated your engineers, client engineers and PMs, and ran scoping workshops | `[grounded]` your resume | none |
| R5 | Agile delivery | must_have | unclear | low | discovery | The resume mentions UAT and go-live and says nothing of sprints or agile cadence | `[grounded]` resume silence | G3 |
| R6 | Run discovery with integration partners | important | direct | medium | none | Scoping workshops and quarterly client feedback sessions, with clients integrating your APIs | `[grounded]` your resume | none |
| R7 | Write specs and drive delivery with engineering squads | important | adjacent | medium | transferability | You wrote requirements documents and integration architecture. You coordinated engineers on custom builds, with no stated authority over a squad's backlog | `[grounded]` your resume | Say which build specs engineers built from (G1) |
| R8 | Own the roadmap | important | adjacent | medium | transferability | You ran the input sessions. Nothing says you decided what was built | `[grounded]` your resume | G1 |
| R9 | Define and track adoption metrics | important | unclear | low | discovery | SQL is a tool for it, but no metric work is stated. The triage-tool lead, if confirmed, might bear on this | `[grounded]` resume silence; memory_lead | G2 |
| R10 | Coordinate launches with sales and support; stakeholder work with sales | important | unclear | low | discovery | Sales and support are not mentioned in your resume | `[grounded]` resume silence | G4, not asked this turn |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | PM-type ownership (R1a, R2a, R7, R8) | transferability | Strong input and delivery work; nothing showing what you decided or what your input changed | R1a and R2a are `must_have` rows at `adjacent`, and a concrete outcome narrows the objection most likely to be raised | A client request from a roadmap-input session that became a product change; a custom build where your requirements document drove what engineers built; a playbook decision others adopted | A sanitised requirements document, the session summary format, or a playbook excerpt | `[inferred]` bridge from your stated work; `[generic]` that this is the likeliest objection |
| G2 | Internal tool and adoption evidence (R2b, R9) | discovery | A lead only, nothing confirmed | A confirmed, specific story would give a `must_have` row and an `important` row real evidence | Building or specifying a tool support agents adopted; how you learned whether it was used; a dashboard or usage numbers you pulled | A screenshot, usage report or short write-up | `[grounded]` memory_lead only |
| G3 | Agile delivery (R5) | discovery | Silent | A `must_have` that interviews probe | Sprint planning, backlog refinement or demos with engineers on custom builds | A ticket board excerpt or a sprint-review note | `[grounded]` resume silence |
| G4 | Sales and support launches (R10) | discovery | Silent | Part of the mandate | Go-lives that involved support handoff or sales messaging | A go-live checklist | `[grounded]` resume silence; not asked this turn because its decision impact is lower |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. The check could not run here | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your careers site, and who would I be interviewing with? | unresolved |
| RR2 | The 3+ years PM requirement is a must-have and you have no titled years | unknown | — | "3+ years product management experience (must-have)" | The requirement may be applied literally, or may be satisfiable by equivalent work | `[inferred]` from the JD's own "must-have" marker against your resume; `[generic]` that firms differ in how literally they apply such lines | Would you consider a candidate with seven years leading API integrations and running roadmap-input sessions, but no PM title? | unresolved |
| RR3 | Responsibility without stated authority | unknown | — | "Own the roadmap for our partner-facing API platform" | The PM may own outcomes while priorities are set by engineering or sales leadership | `[inferred]` from the JD's silence on decision rights | Who sets platform priorities when sales and engineering disagree, and what is this role's call? | unresolved |
| RR4 | No success definition | unknown | — | "define and track adoption metrics" | The role may define its own measures with no first-year outcomes stated | `[inferred]` from the JD listing metrics as a duty, not a target | What would a successful first year look like, and what adoption baseline exists today? | unresolved |
| RR5 | Pay withheld | unknown | — | JD states no compensation | The pay may sit above or below your current band; I could not calibrate it | `[grounded]` JD silence; no band available | What is the budgeted range for this role? | unresolved |
| RR6 | Mandate stated concretely | positive_signal | — | "two engineering squads … partner-facing API platform" | Scope and counterparts are named, which suggests a defined role | `[grounded]` JD | Who are the two squad leads, and who does this role report to? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask RR2's question of the recruiter before investing in a full application | The titled-years line is the decisive unknown (R1b) | `[grounded]` RR2 | pending your approval |
| A2 | Lead with two of your own sentences, kept as written: "led 30+ client integrations of our REST APIs end to end" and "ran quarterly roadmap-input sessions collecting client feedback for product" | They are your strongest evidence (R2a, R6, R8) and each traces to your resume. Do not describe either as product management experience, roadmap ownership or product ownership | `[grounded]` your resume | pending your approval |
| A3 | Prepare one concrete roadmap-input example: a client request and what happened to it | It narrows the R1a, R8 bridge, but I won't write it into any document until you confirm the facts (G1) | `[inferred]` need derived from the map | pending your approval |
| A4 | Verify Quartzline on its own careers page before applying | See RR1 | `[grounded]` RR1 | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: a possible internal request-triage tool, unconfirmed, held as a question only (R2b, R9).

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Quartzline logistics technology partner API platform careers"; the call was refused. It would have moved role reality's organization and contradictions rows, and RR1 |
| 2. Role-family sweep | unavailable | Searched "Product Manager Platform APIs B2B salary range solutions engineer to product manager transition"; the call was refused. It would have moved market calibration and RR5 |
| 3. Hiring manager's public footprint | n/a | No name was given, so no query could form |

## Upgrade menu

- Permission to search: Quartzline's careers page closes RR1, and a salary and role-family sweep gives the market calibration and RR5.
- An answer to G2 moves R2b and R9, and possibly R2a.
- An answer to G3 moves R5.
- A roadmap-input outcome (G1) moves R1a and R8.
- A sanitised spec or integration design raises R3 to `high`.
- The recruiter's answer on RR2 decides whether this stays `conditional_go`.
- The hiring manager's name unlocks role reality's scope read and which story to lead with.

I can also save this as a `tuesday-dossier.md` if you want to carry it forward.

**Questions**

G2 — Did you build an internal request-triage tool that support agents adopted, and if so, what did you personally own and how do you know it was used?

G3 — On your custom builds with engineers, did delivery run in sprints or another agile cadence, and what was your part in it?

C1 — What are your non-negotiables for this move, such as a pay floor, location or remote requirement, and any start-date limit?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.