Research is done for the company, the pay band and the hiring manager. I'm now checking Quillfield's own careers page to see whether the posting is live there. Then I'll write the assessment.
## Decision snapshot

**Should you go for it? Yes, apply, but as a stretch rather than a safe fit. R8 (billing data) is a plain gap, R6 (forecast) is a bridge and R7 (finance data) is still open. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol hybrid, two office days), R2 (£61,500–£67,000 base)
- `must_have`: direct: R3, R4, R9 · adjacent: R5 (Strong SQL and spreadsheet modelling), R6 (Experience owning a forecast) · unclear: R7 (Working with finance on billing or revenue data) · absent: R8 (Own the billing data)

R6: a credible bridge through your monthly pipeline review, its limit named; R7: open, and may close on one recall answer; R8: the plain gap, with a closure path.

**Opportunity ledger.** The stated pay sits in line with the band I found (RR1). Who owns the forecast number and who this role reports to is unstated (RR2). The posting is not confirmed on Quillfield's own site (RR3), and the scope of the billing-data work is unstated (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days), R2 (£61,500–£67,000 base); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 fit your own limits; (2) the forecast ownership and reporting line turn out workable (RR2, R6); (3) you go in stating the billing gap plainly, and the billing scope (RR4) is something to learn rather than a day-one expectation (R8).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield makes invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol, 96 employees, Series A of £11M closed April 2025 | `[grounded]` "About Quillfield" page (quillfield.co.uk/about), seen as a search result |
| Mandate | Own CRM and billing data; build the pipeline and renewal reporting that sales and finance run on; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Terms | Bristol, hybrid, two office days a week; £61,500–£67,000 plus share options | `[grounded]` posting |
| Hiring manager | Tamsin Achebe is listed as Head of Revenue Operations at Quillfield, previously sales operations manager at a payments company for four years | `[grounded]` search-result summary of her public profile; the page itself was not opened |
| Scope read | Four responsibilities in one Lead post: CRM data, billing data, reporting and the forecast. A Head of Revenue Operations also exists, so the split between the two roles is not visible | `[inferred]` from the posting's responsibility list set against Tamsin's listed title |
| Market calibration | A revenue operations lead at a UK B2B software company has a median base of £64,200 and an interquartile range of £57,800–£70,400 (n=438). The posting's range sits inside that range, near the median. The band is UK-wide, not Bristol-specific, and is never Quillfield's offer | `[generic]` Ledgerline 2026 pay guide, a survey result seen as a search result; `[grounded]` the posting's own figure |
| Unknowns | Reporting line; who holds the forecast number; which billing system and its state; share-option terms | — |
| Contradictions | Nothing contradicts the posting on the about page. I could not find the posting on Quillfield's own site (RR3) | `[grounded]` one address tried returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two days a week in the office | hard_gate | unclear | none | hard_gate | You haven't stated where you're based or what office days you'll accept, so there is no statement to grade and the posting's term can't be checked | `[grounded]` posting quote; your silence | Question R1/R2 below |
| R2 | £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | No pay floor given. The band comparison is in role reality and RR1; it says nothing about your floor | `[grounded]` posting quote; your silence | Question R1/R2 below |
| R3 | 4+ years in revenue operations, sales operations or a similar analytics role at a B2B software company | must_have | direct | medium | none | You describe 5 years in sales operations, the last 2 running revenue operations for the UK team. The employer is a B2B payments company; the posting says software, so the match is exact only if that company is a software business | `[grounded]` your stated background, self-report | none |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified, which meets the "or". The certificate hasn't been inspected, so `medium` | `[grounded]` your stated certification | offer: the certificate's name and date would raise to `high` |
| R5 | Strong SQL and spreadsheet modelling | must_have | adjacent | medium | discovery | You say SQL weekly and Excel daily. That shows use, not modelling or strength, and nothing in your background mentions building a model | `[grounded]` your stated usage; `[inferred]` that modelling is untested | offer: a sanitized SQL or model sample; asked later if the decision still turns on it |
| R6 | Experience owning a forecast, and running the quarterly revenue forecast with the CFO | must_have | adjacent | medium | transferability | You run the monthly pipeline review with your sales director and have never owned the company forecast, which finance did. The bridge is pipeline review; the limit is that you haven't produced or owned a forecast number | `[grounded]` your stated review and your stated limit | G1 |
| R7 | Experience working with finance on billing or revenue data | must_have | unclear | low | discovery | You've never worked on billing data, but the requirement says "billing or revenue". Your renewal and pipeline dashboards are revenue data. Whether you worked with finance on them isn't stated | `[grounded]` your stated limit; `[inferred]` that renewal reporting may touch revenue figures | G2 |
| R8 | Own the billing data | must_have | absent | none | capability | You say you've never worked on billing data. Nothing adjacent has been stated, so this is carried as a plain gap | `[grounded]` your own statement | closure path in G3 |
| R9 | Build pipeline and renewal reporting for sales and finance | must_have | direct | medium | none | You rebuilt your pipeline and renewal dashboards. That finance used them isn't stated, so the match is for the dashboards and not for that audience | `[grounded]` your stated work | offer: a sanitized screenshot would raise to `high` |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R6, must_have) | transferability | A monthly pipeline review with your sales director; no forecast owned | The forecast is named in the posting's mandate, and the gap is the likeliest place this application gets probed | Presenting a commit or best-case number in the review; maintaining a pipeline-coverage model; supplying pipeline inputs to finance's forecast; a scenario or variance analysis | A review deck with the numbers removed, a coverage-model screenshot, the structure of a forecast input you supplied | `[grounded]` your stated review and limit; `[generic]` that forecast ownership draws the most scrutiny in roles like this |
| G2 | Working with finance on revenue data (R7, must_have) | discovery | Renewal and pipeline dashboards; no stated work with finance | It is a must-have and could move from `unclear` to `adjacent` or settle as a plain gap | Reconciling renewal figures against finance's numbers; agreeing definitions of ARR or renewal rate with finance; fixing a CRM-to-finance mismatch | A definitions document, a reconciliation sheet, a dashboard that finance signed off | `[grounded]` the dashboards you described; `[inferred]` that the dashboards may touch finance figures |
| G3 | Billing data (R8, must_have) | capability | No billing-data work | A must-have the posting names in its first line of responsibilities | Closure path: build a small work sample, such as a mock invoice-to-CRM-renewal reconciliation, and learn a common billing system's data model. This narrows the gap and doesn't close it | The sample itself, kept honestly labelled as a self-made exercise | `[generic]` closure path; `[grounded]` your stated gap |
| G4 | SQL and spreadsheet modelling (R5, must_have) | discovery | Usage stated, modelling not | Lower priority than G1 and G2: it can move the row, but is unlikely to move the decision | A forecast or ARR model in Excel; a SQL query that joins CRM and contract data; a cohort or retention analysis | A sanitized query or workbook | `[grounded]` your stated usage |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay stated, in line with band; share-option terms unstated | positive_signal | — | "Salary £61,500–£67,000 plus share options" | The figure is disclosed and sits in the role-family range, so no pay mismatch shows. The options' value depends on terms the posting doesn't give | `[grounded]` posting figure; `[generic]` the survey band | What are the share options' terms: vesting, strike price and the share they represent? | noted |
| RR2 | Forecast ownership and reporting line unclear | unknown | — | "run the quarterly revenue forecast with the CFO" | A Head of Revenue Operations is already listed at the company, so this Lead may share forecast duties with that role, and who holds the number may be unclear | `[inferred]` from the posting's forecast clause set against Tamsin's listed title | Who owns the forecast number, this role, the Head of Revenue Operations or the CFO, and who does this role report to? | unresolved |
| RR3 | Posting not confirmed on Quillfield's own site | risk_signal | low | "Revenue Operations Lead, Quillfield" on Tallyboard Jobs | Quillfield may list roles at another address, may hire through job boards, or the posting may be out of date. None is ranked as likely | `[generic]` pattern for small employers; `[grounded]` the one address tried returned no page | Can you point me to this role on your own careers page and confirm it is still open? | unresolved |
| RR4 | Billing-data scope unstated | unknown | — | "own our CRM and billing data" | The role may expect billing-data ownership from day one, with the billing system, its state and the finance counterpart all unstated | `[inferred]` from the posting's silence on those three | Which billing system does this role own data from, what state is it in, and who in finance is the counterpart? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm location and pay with the recruiter before investing in the loop | see R1, R2 | `[grounded]` the unconfirmed gate rows | pending your approval |
| A2 | Lead the application with your rebuilt pipeline and renewal dashboards and the monthly pipeline review. Say the forecast point in your own terms: "I run the monthly pipeline review with our sales director; finance owns our company forecast, and I haven't owned it." | see R6, R9; every clause traces to your own statements | `[grounded]` your own sentences | pending your approval |
| A3 | State the billing gap up front rather than around it: "I haven't worked with billing data; I rebuilt our pipeline and renewal dashboards." | see R8; the gap can't be framed away | `[grounded]` your own statements | pending your approval |
| A4 | For Tamsin's reading: her listed background is sales operations at a payments company, so your sales-ops years at a payments company may read as familiar. Lead with operational detail over strategy language | see her hiring-manager row in role reality | `[inferred]` from her listed prior role | pending your approval |
| A5 | Ask the verification questions of RR2, RR3 and RR4 verbatim in the loop | the register doubles as interview preparation | `[grounded]` register | pending your approval |
| A6 | Optional work sample for G3: a small mock reconciliation of invoice data to CRM renewals, labelled as a self-made exercise | narrows R8 without claiming it | `[generic]` closure path | pending your approval |

No resume edits are proposed this turn, because I haven't seen your CV.

## Evidence status

Verified: none yet. Your background is self-report of the same standing as a CV until a specific answer or an artifact confirms it. Unverified leads: none.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company careers", which returned "About Quillfield" (quillfield.co.uk/about). Fetched quillfield.co.uk/careers, a guessed address, which returned no page. Moved role reality's organization and contradictions rows, and RR3 |
| 2. Role-family sweep | yes | Searched "revenue operations lead salary UK B2B SaaS Bristol", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved the market calibration row and RR1 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Moved the hiring-manager row, RR2 and A4 |

If useful, I can write this up as a `tuesday-dossier.md` to carry forward.

## Upgrade menu

- Your base-pay floor and where you're based: closes R1 and R2, and settles the hard-gates line.
- Your answer to G1: strengthens or settles R6.
- Your answer to G2: R7 moves to `adjacent` or settles as a gap.
- The Salesforce certificate's name and date: R4 to `high`.
- A sanitized dashboard screenshot: R9 to `high`.
- A sanitized SQL query or workbook: R5 to `high`.
- The recruiter's answers on reporting line, billing system and share-option terms: close RR2, RR4 and RR1's open point.
- A link to the role on Quillfield's own careers page: closes RR3.
- A deeper research pass on Quillfield (funding and leadership changes, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

R1/R2: What are your own limits on the two terms the posting sets, the Bristol office two days a week and £61,500–£67,000 base?
G1: When you run the monthly pipeline review, have you ever put a number to it yourself, such as a commit, a best case or a scenario? What did you own?
G2: Have you worked with finance on revenue figures, for example reconciling renewals or pipeline against what finance reports? What part was yours?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.