The job-search tools were set up, but the two web searches I tried were refused, so everything below rests on your text and the posting alone.

## Decision snapshot

**Yes, you're a fit on the core, and the role is worth applying to: R1, R2, R3, R4 and R6, every `must_have` row, land `direct`. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R6
- `important` — direct: R7a · unclear: R5 (metrics layer), R7b (clinicians), R8 (mentor two junior analysts)
- `preferred` — adjacent: R9 (healthcare data, HIPAA)

R9 (`medium`) — a bridge from consent work, its limit named; R5, R7b, R8 — the CV-style summary is silent, one answer each could settle them.

**Opportunity ledger.** Nothing about the employer could be checked (RR1), pay and working pattern are unstated (RR2, RR3), and five responsibilities sit in one post with no word on who owns the data models underneath (RR4). One entry runs the other way: the partners and the team you would mentor are named (RR5).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify — RR1; (2) pay and location fit your own terms — RR2, RR3; (3) healthcare data is framed as adjacent through your consent-state work, never as HIPAA experience — R9.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up of about 400 people at Series C, with a care-navigation app | `[grounded]` JD header |
| Mandate | Own product analytics for the app: metrics layer, A/B tests, self-serve Looker dashboards, partnering with PMs and clinicians, mentoring two junior analysts | `[grounded]` JD |
| Scope read | An individual-contributor senior post with mentoring, not a people-management post: mentoring is named and line management is not | `[inferred]` from the JD's wording on mentoring against its silence on reports |
| Working pattern | Not stated | `[grounded]` JD silent |
| Compensation | Not stated | `[grounded]` JD silent |
| Market calibration | Not available: the role-family search was refused, so no pay or scope band is given | `[grounded]` search refused |
| Unknowns | Pay; location or remote policy; who owns the warehouse models under the metrics layer; what "at scale" means for the experimentation volume | — |
| Contradictions | None visible inside the posting; no second source was read to compare it against | `[grounded]` JD only |

## Evidence map

Your background was typed into the chat, so it counts as self-report. That caps every row at `medium` until you share something inspectable.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | You state 6 years of product analytics at a consumer-subscription company; confirmed in your message, with no document behind it yet | `[grounded]` your stated background | none |
| R2 | Expert SQL | must_have | direct | medium | none | You state daily SQL on a Snowflake warehouse; "expert" is the JD's level and rests on your word | `[grounded]` your stated background | A query or model you can share, sanitized, would raise to `high` |
| R3 | Experiment design at scale | must_have | direct | medium | none | You state you designed and ran the program, 30+ A/B tests a year, including the pricing test behind an 11% retention lift. Your ~2M-subscriber base is the scale reference; no test write-up has been inspected | `[grounded]` your stated background | A sanitized test plan or readout would raise to `high` |
| R4 | Looker or a similar BI tool | must_have | direct | medium | none | You state you built the company's Looker instance from scratch, with 40+ governed dashboards | `[grounded]` your stated background | A dashboard screenshot or LookML sample would raise to `high` |
| R5 | Define and maintain the metrics layer | important | unclear | low | discovery | Governed dashboards and a monthly metrics memo sit near this, but a metrics layer means shared definitions held in a semantic or modeling layer, and nothing you wrote says you owned that. Whether LookML models or a metric dictionary were yours is open | `[grounded]` CV-style summary silent on the layer itself; `[generic]` that dashboards alone don't establish ownership of one | Ask G1 |
| R6 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | You state you write the monthly metrics memo the exec team reads and present monthly to the VP Product | `[grounded]` your stated background | A sanitized memo would raise to `high` |
| R7a | Partner with product managers on roadmap decisions | important | direct | medium | presentation | Monthly presentations to the VP Product are partnering at a senior level. Whether any of your analyses changed a roadmap decision is not stated, and the JD's wording is about decisions | `[grounded]` your stated background | Propose E1 for approval; one example of an analysis that changed a roadmap decision would help |
| R7b | Partner with clinicians | important | unclear | none | discovery | Nothing in your background mentions subject-matter experts such as dietitians or clinicians; it is silent, not a negative | `[grounded]` your stated background silent | Ask G3 if budget allows |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Your background doesn't mention mentoring. You may have done it without it appearing in a summary | `[grounded]` your stated background silent | Ask G2 |
| R9 | Healthcare data experience (HIPAA) a plus | preferred | adjacent | medium | transferability | You have handled GDPR and CCPA consumer PII and built the consent-state model for your warehouse. That carries over on privacy discipline; it did not exercise PHI, HIPAA rules, or clinical data | `[grounded]` your stated consent-state model; `[generic]` that HIPAA is a distinct regime from GDPR and CCPA | Propose E2 for approval, with the limit stated |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer ownership (R5, important) | discovery | Governed Looker dashboards and a metrics memo, but nothing on who defined and maintained the shared metric definitions | The JD lists this first among the responsibilities; an answer likely changes how R5 and RR4 read | Writing the LookML models behind your dashboards; running a metric dictionary or a definitions review; resolving a dispute over how retention or churn is calculated | A metric dictionary page, a LookML snippet, a definitions doc | `[grounded]` your background silent on the layer; `[inferred]` that this is the row an interviewer would press |
| G2 | Mentoring (R8, important) | discovery | No mention of mentoring or coaching analysts | The post is explicit about two juniors, so a gap here affects both the application framing and the senior label | Onboarding a new analyst; reviewing others' SQL or test designs; running a team training session | A short note naming whom you mentored, for how long, and what changed | `[grounded]` your background silent; `[generic]` that senior analytics posts commonly include mentoring |
| G3 | Clinician partnership (R7b, important) | discovery | Silence on working with domain experts outside product | Clinicians are named as partners in the JD; any comparable example narrows the objection | Working with dietitians, medical advisors or other specialists to interpret or design an analysis | A short example of a test or metric shaped with a specialist | `[grounded]` your background silent |
| G4 | Healthcare data (R9, preferred) | transferability | Consent-state model and GDPR and CCPA handling | Preferred only, so it is a minor risk, but it is the likeliest "have you worked with sensitive data" probe | Consent or data-subject-request work; access controls on the warehouse; privacy reviews you sat in | A sanitized consent-model description | `[grounded]` your stated work; `[inferred]` that the bridge ends where PHI and HIPAA rules begin |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | No search ran, so nothing was checked. The employer may be real and simply unchecked here; the posting could also be stale or aggregated, or not represent a real hiring employer | `[generic]` pattern for any unchecked employer, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Compensation unstated | unknown | — | no pay figure in the pasted posting | The range may sit anywhere in market; the withholding is itself worth a question | `[grounded]` JD silent | What is the budgeted salary range for this post? | unresolved |
| RR3 | Location and working pattern unstated | unknown | — | no location or remote policy in the pasted posting | May be remote, hybrid or office-based; this matters against any constraint you hold | `[grounded]` JD silent | Where is this role based, and what is the remote or hybrid arrangement? | unresolved |
| RR4 | Bundled scope: analytics engineering plus analysis in one post | unknown | — | "define and maintain the metrics layer, design and analyze A/B tests, build self-serve dashboards in Looker, partner with product managers and clinicians… mentor two junior analysts" | The post may fold modeling work normally held by a data-engineering team into an analyst role | `[inferred]` from the JD's responsibility list against its silence on who owns the models | Who owns the warehouse models beneath the metrics layer, this role or a data-engineering team? | unresolved |
| RR5 | Named partners and named team | positive_signal | — | "partner with product managers and clinicians to turn analysis into roadmap decisions… mentor two junior analysts" | Roadmap partners and the mentee team are named, so the role's working relationships are defined | `[grounded]` JD | Who are the two junior analysts, and what level are they at today? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead your resume summary with the experimentation program (30+ A/B tests a year) and the pricing test behind an 11% retention lift; keep "behind", since you didn't say the test caused it alone | see R3, R7a | `[grounded]` your stated background | `resume_edits_pending_approval` |
| E2 | Add one line on the consent-state model for the warehouse and your GDPR and CCPA PII handling, with no claim of HIPAA or PHI experience | see R9 | `[grounded]` your stated background | `resume_edits_pending_approval` |
| E3 | Keep the monthly exec metrics memo and monthly VP Product presentations visible in the top third | see R6, R7a | `[grounded]` your stated background | `resume_edits_pending_approval` |
| A1 | Confirm the posting is live on Harborlight's own careers page before investing effort | see RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask RR2, RR3 and RR4 verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

Polishing these resume lines is resume-tailor's job, if you want to take that next.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | I tried one company search, and it was refused in this session. It would have confirmed the employer and that the posting is live (RR1) |
| 2. Role-family sweep | unavailable | I tried one search on pay and scope for this role family, and it was refused. It would have supplied a market band and set the scope read against role-family norms |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer and upgrade menu

I can save this as a `tuesday-dossier.md` whenever you like; it is optional.

- Letting the searches run, or pasting Harborlight's careers page and posting link → RR1 closes, the market calibration appears, and the decision likely moves toward `go` or `no_go`.
- Your pay floor, location and any must-haves → hard gates get checked against RR2 and RR3 and the snapshot's constraint flag clears.
- A sanitized test readout, LookML sample or metrics-memo page → R2, R3, R4, R6 go from `medium` toward `high`.
- A metric dictionary or definitions doc → R5 resolves.
- The hiring manager's name → role reality's scope read and which story to lead with.

**Questions**

Constraints — What are your non-negotiables on pay, location or remote, and anything else, such as sponsorship, that this role could touch?
G1 — Did you define and maintain the shared metric definitions behind your dashboards, for example in LookML or a metric dictionary, or did another team own them?
G2 — Have you mentored or onboarded analysts, and if so, who, for how long, and what changed?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.