Checking that Pellucid Learning and the posting are real and live, then I'll write the full assessment.
# Job Underwriting Assessment: Senior Data Engineer at Pellucid Learning

## Decision snapshot

**Yes, this is worth applying to. Your background meets R3, R4, R5, R6a, R7 and R8 directly, and the BigQuery gap (R6b) can be bridged. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver), R2 (Salary $148,000–$166,000)
- `must_have`: direct: R3, R4, R5, R6a, R7, R8
- `important`: adjacent: R6b (BigQuery warehouse); unclear: R9 (ingestion from app and CRM), R10 (data contracts)

R6b is adjacent through Snowflake, with its limit named; R9 and R10 are rows your background does not yet speak to.

**Opportunity ledger.** The pay is disclosed and sits inside the report's range (RR2), and the funding is recent (RR6). Four things are unchecked: whether the posting is live (RR1), the reporting line (RR3), the team's shape (RR4) and the equity terms (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your own location and pay floor fit R1 and R2; (2) the employer and the live posting are confirmed, per RR1; (3) the BigQuery bridge is framed as adjacent and never as BigQuery experience, per R6b.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` the about-page text you pasted; not checked live (see Evidence status) |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and the data contracts analysts depend on | `[grounded]` JD |
| Requirements | 5+ years data engineering; strong SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Pay and location | $148,000–$166,000 plus equity; Remote (US) or Denver office | `[grounded]` JD |
| Scope read | Reads as ownership of the reporting pipelines with no direct reports stated. "Build and run" across the app and CRM could be wider than the one domain the report calls typical | `[inferred]` from the JD's scope wording against the pay report's typical-scope line |
| Market calibration | Senior Data Engineer at Series B–D companies: base median $151,000, interquartile range $139,000–$163,500, "Senior" typically 5–8 years. Your 6 years sits inside that span. The posted band's low end is $3,000 under the median and its top is $2,500 over the 75th percentile. This is a market band, never this employer's offer | `[grounded]` the Datawright 2026 report you pasted (n=2,310); `[grounded]` JD for the posted band |
| Unknowns | Hiring manager (the posting names none); team size and which domains you would own; equity terms; whether the posting is still open | `[grounded]` JD silence |
| Contradictions | None between the JD and the about text as pasted | `[grounded]` both texts; not cross-checked against the live site |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You have not stated where you are or work from, so the gate is not established. Confidence grades your statement of the constraint, and there is none yet | `[grounded]` JD term; no constraint given | Closing question, R1 and R2 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | No pay floor given, so whether the band clears it is not established. The band's position against the market is in RR2 | `[grounded]` JD term; no constraint given | Closing question, R1 and R2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years of data engineering at a B2B payroll company. It is specific and plausible but unprobed prose, so `medium` is the intake ceiling. A years requirement is graded as fit, not as a gate | `[grounded]` your background as typed | none; dated CV roles would let a reader confirm the span |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You state both are used daily. Specific, but nothing inspectable yet | `[grounded]` your background as typed | none |
| R5 | dbt | must_have | direct | medium | none | You built the dbt project on Snowflake, about 180 models. That is specific and well within what the role describes. No artifact yet, so `medium`, with the expectation that you will be probed on it | `[grounded]` your background as typed | none |
| R6a | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse, and you have used it in production work on the dbt project | `[grounded]` your background as typed | none |
| R6b | BigQuery as the warehouse | important | adjacent | medium | transferability | The posting's description names BigQuery and you have never used it. Your Snowflake and dbt work is real adjacent evidence. Limit: it exercised none of BigQuery's own cost model, partitioning or tooling. dbt projects usually carry across warehouses with SQL-dialect changes | `[grounded]` your stated Snowflake experience and no BigQuery; `[generic]` that dbt logic is largely warehouse-portable | See G1; W1 below |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | You state Airflow was your orchestrator. Specific, but no artifact | `[grounded]` your background as typed | none |
| R8 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite. Confirmed and specific, with no inspectable artifact yet | `[grounded]` your background as typed | none |
| R9 | Ingestion from the app and CRM | important | unclear | low | discovery | Your pipelines' source systems are not described, so whether they included product-app event data or CRM data is unknown | `[grounded]` background silent on sources | See G2 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | The Great Expectations suite is quality testing (R8). Whether you agreed schemas or expectations with downstream analysts is not in what you wrote | `[grounded]` background silent on consumer agreements | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery warehouse (R6b, important) | transferability | Snowflake plus dbt at about 180 models; no BigQuery | The posting names BigQuery, and an interviewer may test the difference directly | Moving or reimplementing any dbt models across warehouses; tuning query cost or table layout in Snowflake; any BigQuery contact, however small | A small dbt project on BigQuery that you build and can link | `[grounded]` your stated experience; `[generic]` that hiring screens for a named warehouse often probe it |
| G2 | Ingestion from the app and CRM (R9, important) | discovery | Your pipelines are described without their source systems | The role is built around these two sources | Event or API ingestion from a product; syncing a CRM such as Salesforce or HubSpot into the warehouse; replacing a manual export | A pipeline diagram or README, with names scrubbed | `[grounded]` background silent on sources; `[inferred]` that this is the biggest unknown left on the fit side |
| G3 | Data contracts (R10, important) | discovery | Quality testing is evidenced; agreements with consumers are not | The JD names the contracts analysts depend on | Agreeing schemas with upstream owners; versioned model interfaces; alerting analysts to breaking changes; documented expectations per table | A contract doc, a schema-change policy, or a test configuration | `[grounded]` Great Expectations suite stated, contracts not; `[inferred]` that it is adjacent evidence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and live posting not verified from here | risk_signal | medium | "Founded 2016, Denver. 264 employees. Series C ($52M, February 2026)." | The pasted JD and about text agree with each other, but I could not read either live, so whether the posting is still open is unchecked | `[grounded]` the two texts you pasted; my searches were refused, so no live check | Can you confirm this role is open on your careers page, and who it reports to? | unresolved |
| RR2 | Stated pay against the market | positive_signal | — | "$148,000–$166,000 plus equity" | Disclosed pay brackets the report's median ($151,000) and extends past its 75th percentile ($163,500) | `[grounded]` JD against the Datawright report you pasted | Where in the range would an offer land for 6 years of experience? | noted |
| RR3 | Hiring manager and reporting line not named | unknown | — | "The posting names no hiring manager" | Who sets priorities, and who the analysts are, is open | `[grounded]` JD silence | Who would this role report to, and which analysts consume these models? | unresolved |
| RR4 | Scope and team shape unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | This could be sole ownership of the reporting stack or one domain among several; the report's typical senior scope is one domain with no reports | `[inferred]` from the JD wording against the report's typical-scope line | How many data engineers and analysts are there, and which domains would I own? | unresolved |
| RR5 | Equity terms unstated | unknown | — | "plus equity" | The type, size and vesting of the grant are open, so its value cannot be weighed | `[grounded]` JD silence | What is the equity grant structure: type, vesting schedule and current valuation basis? | unresolved |
| RR6 | Recent funding | positive_signal | — | "Series C ($52M, February 2026)" | A recent raise suggests the role is funded; it does not show the data team's hiring plan | `[inferred]` from the funding line in the pasted page | What does the data team's hiring plan look like after this round? | noted |

RR1 caps the decision at `conditional_go` until the posting is confirmed live on the company's own careers page.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Put your dbt project line ("built the dbt project on Snowflake, about 180 models") and your Great Expectations line ("set up the test suite") first, worded as you wrote them with nothing added | R5, R8 | `[grounded]` your own sentences | pending your approval |
| E2 | Name Snowflake explicitly beside dbt and the warehouse. Do not list BigQuery as a skill | R6a, R6b | `[grounded]` your stated experience | pending your approval |
| W1 | Build a small dbt project on BigQuery that you can link, to narrow the limit named in R6b | R6b, G1 | `[inferred]` it narrows the gap; `[grounded]` it adds no claim you do not hold | pending your approval |
| Q1 | Ask the verification questions of RR1, RR3, RR4 and RR5 verbatim in the recruiter screen | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Confirm the posting is live on Pellucid's own careers page before spending effort on the application | RR1 | `[grounded]` RR1 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | I sent two searches and both were refused: "Pellucid Learning Senior Data Engineer careers Denver" (restricted to pellucidlearning.com) and "Pellucid Learning online tutoring K-12 Series C $52M". They would have confirmed the company and the live posting, so RR1 stays unresolved |
| 2. Role-family sweep | skipped | The Datawright report you pasted already fixes the market calibration line, RR2 and the scope read |
| 3. Hiring manager's public footprint | n/a | The posting names no manager, so there was no query to form |

I offer the dossier as a single line: if you want a durable record of this assessment for later steps, I can write it up as `tuesday-dossier.md`.

## Upgrade menu

- Your pay floor and where you would work from → R1 and R2 move from `unclear` to met or failed, and the hard-gates line settles.
- Your answers on ingestion sources and data contracts → R9 and R10 may move to `direct` or `adjacent`.
- A pipeline diagram, a test configuration or a contract doc → raises those rows from `medium` toward `high`.
- A link to the live careers page → RR1 closes and the cap at `conditional_go` lifts.
- The recruiter's answers on reporting line, team shape and equity → RR3, RR4 and RR5 close.
- A deeper research pass on Pellucid Learning (funding, leadership churn, recent news; up to 5 more searches and 2 more fetches) is offered once. Say the word and it runs, though search permission would need to be granted first.

## Questions

R1, R2: What base salary would you need, and where would you work from (remote in the US, or Denver)?

G2: Have you built ingestion from a product app's event data or from a CRM into a warehouse, and what did you own?

G3: Have you agreed schemas or expectations with the analysts who consume your models, and how were breaking changes handled?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.