Checking the posting and the company page turned up no conflict with what you pasted. Here is the assessment.

## Decision snapshot

**Yes, this is worth applying to, on two conditions only you can settle (R10, R11). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R10 (Remote US or Denver), R11 (Salary $148,000–$166,000 plus equity)
- `must_have`: direct: R1, R2, R3, R4, R5, R6
- `important`: adjacent: R7 (BigQuery warehouse); unclear: R8 (Data contracts), R9 (Ingestion from app and CRM)

R7 — a credible bridge, its limit named; R8 and R9 — waiting on your answers.

**Opportunity ledger.** The posting is live and the company matches its own description (RR4), and the stated pay sits at or above the market median you sent (RR1). Team size and ownership boundaries are unstated (RR2), and so is who you would report to (RR3).

- **Hard gates:** none failed; unconfirmed: R10 (Remote US or Denver), R11 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the location and pay terms meet your own constraints — R10, R11; (2) the role's scope verifies as one domain's pipelines — RR2; (3) BigQuery is framed as adjacent, never as hands-on experience — R7.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` About page, via search result |
| Posting status | Live ("Accepting applications"); its text matches what you pasted | `[grounded]` careers page fetched |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: app and CRM ingestion, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` JD |
| Seniority | 5+ years asked; "Senior" typically means 5–8 years at this stage | `[grounded]` JD; `[generic]` Datawright 2026 (n=2,310, US, Series B–D) |
| Scope read | No direct reports or people management mentioned. Typical scope is ownership of one domain's pipelines. Three layers (ingestion, warehouse, contracts) may or may not be one domain | `[inferred]` from the JD's silence on reports; `[generic]` report's typical scope |
| Market calibration | Report band: base median $151,000, IQR $139,000–$163,500. The posting's low end is $3,000 under the median and its top is $2,500 over the 75th percentile. Equity is extra and unvalued. This is the band, not Pellucid's offer to you | `[grounded]` posting figures; `[generic]` band from your recruiter's report |
| Unknowns | Hiring manager, team size, equity terms, backfill or new headcount, how much BigQuery depth is expected, whether data contracts already exist | `[grounded]` JD silence |
| Contradictions | None between the pasted JD and the careers page | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years at a B2B payroll company. Specific, but self-reported with no artifact inspected | `[grounded]` your message | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily" is specific and plausible, with nothing inspected | `[grounded]` your message | none |
| R3 | dbt | must_have | direct | medium | none | You built the dbt project, about 180 models, on Snowflake. Confirmed and specific, no inspectable artifact yet, so expect a probe | `[grounded]` your message | A sanitized lineage graph or project README would raise it to `high` |
| R4 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse. BigQuery is carried separately in R7 because the JD names it in the mandate, not in the requirements list | `[grounded]` your message and JD | none |
| R5 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow is named in the JD and in your background | `[grounded]` your message and JD | none |
| R6 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite. Your wording is "set up", so ownership of ongoing coverage is not established | `[grounded]` your message | A sanitized suite listing or coverage summary would raise it to `high` |
| R7 | BigQuery warehouse | important | adjacent | medium | transferability | Snowflake plus 180 dbt models is the credible bridge. The limit is that you have never used BigQuery, so its cost and partitioning model are unexercised. dbt supports both warehouses | `[inferred]` from the JD mandate against your Snowflake work; `[generic]` that dbt spans warehouses | See G3 |
| R8 | Data contracts analysts depend on | important | unclear | none | discovery | Inferred from "the data contracts our analysts depend on". Nothing you have said covers it. The Great Expectations work is a lead, not evidence | `[inferred]` requirement from the JD mandate; `[grounded]` your message is silent | Question 2 |
| R9 | Ingestion from the app and the CRM | important | unclear | none | discovery | Inferred from the mandate. Your payroll-company ingestion sources are not described | `[inferred]` requirement from the JD mandate; `[grounded]` your message is silent | Question 3 |
| R10 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You have not said where you live or what work arrangement you need. No statement exists to grade | `[grounded]` JD; your constraints not given | Question 1 |
| R11 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | The posting states pay, but your floor is not given, so the term is not established as met | `[grounded]` JD; your constraints not given | Question 1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Data contracts (R8, important) | discovery | Nothing in your background covers agreed schemas or ownership between data producers and consumers | It is named in the mandate, and an interviewer will probably ask about it | Schema-change agreements with an app team; versioned table specs analysts relied on; alerts when a producer broke a downstream model; Great Expectations checks tied to a stated consumer promise | A sanitized schema spec, a runbook, or a test-suite listing | `[grounded]` your message is silent; `[generic]` that this role family probes contract ownership |
| G2 | App and CRM ingestion (R9, important) | discovery | Your ingestion sources are not described | It is the first named piece of the mandate, and resolving it may lift R9 to `direct` | Loading data from an application database or event stream; syncing a CRM or similar SaaS source through an API or connector; handling schema drift or late-arriving data | A pipeline diagram or DAG screenshot | `[grounded]` your message is silent on sources |
| G3 | BigQuery (R7, important) | transferability | Adjacent through Snowflake and dbt. You have never used BigQuery | The JD names it in the mandate, so expect the question. The honest answer is "adjacent, not hands-on" | Cost control through partitioning and clustering concepts; any exposure to another columnar warehouse | An optional small dbt project on BigQuery using a public dataset | `[grounded]` your statement; `[inferred]` the bridge from R3 and R4 |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay stated, with equity unvalued | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The figure is disclosed and sits at or above the report's median. Equity could be material or negligible; the posting does not say | `[grounded]` posting and your report; `[generic]` that equity value varies by stage | What are the equity terms (type, vesting, current valuation), and where in the range would my experience place an offer? | noted |
| RR2 | Scope and team size unstated | unknown | — | "Build and run the pipelines … ingestion … a dbt-modelled warehouse … and the data contracts" | One person could own three layers, or sit on a team that splits them. A very wide remit would be broader than the report's typical single-domain scope | `[inferred]` from the JD's three layers against its silence on team; `[generic]` report's typical scope | Who else is on the data team, and which of ingestion, modelling and contracts would I own alone? | unresolved |
| RR3 | No hiring manager named | unknown | — | "The posting names no hiring manager" | Reporting line is unknown, and so is whether the role is a backfill | `[grounded]` posting silence | Who would I report to, and is this a new seat or a backfill? | unresolved |
| RR4 | Employer and posting verified | positive_signal | — | "Series C ($52M, February 2026) … 264 employees" | The employer exists as described and the posting is live. This takes away the standing employer-not-established entry | `[grounded]` About page and careers page | What does the data team's roadmap look like for the next year? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check your own pay floor and location needs against R10 and R11 before spending effort | They are the two hard gates and nobody has checked them yet | `[grounded]` R10, R11 | pending your approval |
| A2 | Lead the resume with the dbt project (about 180 models, Snowflake), the Airflow orchestration and the Great Expectations suite you set up. Use your own numbers and verbs only | These cover R3, R5 and R6 | `[grounded]` your message | pending your approval |
| A3 | Say plainly that BigQuery is new to you and that Snowflake with dbt is your adjacent base. Do not list BigQuery as a skill | See R7 | `[grounded]` your statement | pending your approval |
| A4 | Ask RR1, RR2 and RR3 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning online tutoring K-12 Denver Series C", which returned "About Pellucid Learning" (pellucidlearning.com/about). Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer). It showed the posting live and consistent with your paste, and it cleared the employer-not-established entry (RR4) |
| 2. Role-family sweep | skipped | The Datawright 2026 report you sent is in hand and fixes the market calibration line and the pay mismatch check (RR1) |
| 3. Hiring manager's public footprint | n/a | The posting names no one, so there was no query to form |

I can write the resume edits and the dossier as files once you say so. The dossier would be `tuesday-dossier.md`.

**Upgrade menu**

- Your pay floor, work location and work authorization would settle R10 and R11. Decision likely simplifies to `go` or `no_go`.
- An answer on data contracts or on ingestion sources would settle R8 or R9.
- A sanitized dbt lineage graph or Great Expectations listing would raise R3 and R6 to `high`.
- The hiring manager's name would add a scope read and a lead story for that reader, once someone gives it.
- A deeper research pass on Pellucid (funding follow-ups, leadership changes, recent news, public employee reports; up to 5 more searches and 2 more fetches) would run if you say the word.

**Questions**

1. R10, R11 — What is your pay floor, where do you live (US state), and do you need remote work or could you work from Denver?
2. G1 — Have you ever set up an agreement with an app team or analysts about table schemas or change notice, and what did you personally own?
3. G2 — What data sources did you ingest at your payroll company, and was any of it from an application database or a CRM?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.