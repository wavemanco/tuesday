I'm still reading the job-underwriter playbook's reference files so the assessment follows its required format. Next is the research-tier rules and the worked report.
**Yes, worth applying, on conditions. R1 and R2, the two hard gates, aren't confirmed yet. Status: `conditional_go`.**

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (US location and work authorization), R2 (pay $148,000–$166,000 against your floor)
- `must_have`: direct: R3, R4, R5, R7, R8
- `important`: adjacent: R6 (BigQuery); unclear: R9 (ingestion from app and CRM), R10 (data contracts)

R5 and R8 (`medium`): confirmed and specific, waiting on an artifact; R6: a credible bridge, its limit named; R9, R10: the JD's responsibilities, not yet in your background; R1, R2: your own terms, not yet stated.

**Opportunity ledger.** Sound on what's stated. The pay is disclosed and sits inside the market band (RR4). The employer details are unchecked from here (RR1), and team shape and equity are unstated (RR2, RR3).

- **Hard gates:** none failed; unconfirmed: R1 (US location and work authorization), R2 (pay $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm R1 and R2; (2) the posting is confirmed live on the company's own careers page (RR1); (3) your Snowflake-to-BigQuery bridge is framed as adjacent, never as BigQuery experience (R6).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` the About text you pasted, not checked against the live site (see Evidence status) |
| Mandate | Build and run reporting pipelines: app and CRM ingestion, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Location and pay | Remote (US) or Denver; $148,000–$166,000 plus equity | `[grounded]` JD |
| Scope read | Ingestion, warehouse modelling and contracts together may be broader than the report's typical single-domain scope; no reports, no team size, no manager named | `[inferred]` from the JD's three responsibilities against the report's stated typical scope |
| Market calibration | Base median $151,000, interquartile range $139,000–$163,500 for Senior Data Engineer at Series B–D (n=2,310). The posted low end is $3,000 under the median and the top is $2,500 above the upper quartile. "Senior" typically means 5–8 years, and you have 6. This is the market band, not this employer's offer. | `[generic]` Datawright 2026 report, supplied by your recruiter; `[grounded]` the posting's own figures |
| Unknowns | Hiring manager; team size; on-call; equity terms; whether the role owns the whole stack | `[grounded]` JD silence |
| Contradictions | None found between the JD and the About text | `[grounded]` the two pasted texts only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Work in the US, remote or Denver | hard_gate | unclear | none | hard_gate | You haven't stated where you are or your authorization, so the gate isn't established | `[grounded]` JD term; no statement from you | Q1 |
| R2 | Pay $148,000–$166,000 | hard_gate | unclear | none | hard_gate | No pay floor stated from you. The band itself is credible (RR4) | `[grounded]` JD term; no statement from you | Q1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | 6 years at a B2B payroll company. It's self-report with no artifact, so expect a probe on scope | `[grounded]` your background text | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | "Daily" use is stated, but depth is unprobed | `[grounded]` your background text | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | You built the dbt project (about 180 models) on Snowflake, which is a cloud warehouse. Nothing inspectable yet | `[grounded]` your background text | a sanitized lineage graph or dbt docs page would raise it to `high` |
| R6 | BigQuery (named in the role description, not the requirements) | important | adjacent | medium | transferability | Snowflake and dbt carry over. The limit: you've never used BigQuery, so its platform-specific design and cost behaviour is untested. Teams hiring for one warehouse often accept a close one | `[inferred]` requirement from the JD's responsibilities; `[grounded]` your no-BigQuery statement; `[generic]` on hiring flexibility | W1 |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow is named directly. Scale and ownership aren't stated | `[grounded]` your background text | none |
| R8 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite, so ownership is stated | `[grounded]` your background text | an expectation list or data-docs page would raise it to `high` |
| R9 | Ingestion from an app and a CRM | important | unclear | none | discovery | Nothing says what sources your pipelines ingested | `[grounded]` silence in your background text | Q2 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | Your tests suite suggests adjacent habits, but nothing shows analyst-facing agreements or SLAs | `[inferred]` from the GE suite against silence on contracts | Q3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location, authorization and pay floor (R1, R2, hard_gate) | hard_gate | Neither term is established | A failed gate would make this `no_go` whatever the fit | Your US state or city, your work authorization, your minimum base | none needed beyond your word | `[grounded]` JD terms against your silence |
| G2 | App and CRM ingestion (R9, important) | discovery | Sources are unstated | It's a named responsibility, and the JD gives it first place | Product event streams, a Salesforce or HubSpot extract, API or CDC loads, a payroll-system export | A pipeline diagram or a sanitized DAG listing | `[grounded]` background text silent on sources; `[generic]` that ingestion work is usually probed |
| G3 | Data contracts (R10, important) | discovery | Testing is shown; analyst-facing agreements aren't | The JD says analysts depend on them | Schema-change notices to analysts, dbt model contracts or versioning, freshness SLAs, an owner list per model | A sanitized contract or schema-change note | `[inferred]` from the GE suite; `[generic]` on how roles like this weigh it |
| G4 | BigQuery bridge (R6, important) | transferability | Close platform, no direct use | It's the likeliest objection to your application | A small dbt project on BigQuery's free tier or a public dataset | the repo itself | `[grounded]` your statement; `[inferred]` that it's the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not established from here | risk_signal | medium | "Founded 2016, Denver. 264 employees. Series C ($52M, February 2026)." | The posting may be current and simply unchecked, or stale or aggregated. The fetch that would have checked it was refused. | `[generic]` pattern for any unchecked employer, not a claim about this one | Can you point me to this role on your own careers site, and who I would be interviewing with? | unresolved |
| RR2 | Team shape and scope unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | You may be the only data engineer owning the whole stack, or one of several; "run" implies on-call | `[inferred]` from the JD's silence against the report's typical scope | How many data engineers and analysts are there, who does this role report to, and who carries on-call? | unresolved |
| RR3 | Equity unquantified | unknown | — | "plus equity" | Value depends on grant size, vesting and strike terms, none of which the posting gives | `[generic]` how equity offers usually work | What is the equity grant for this level, and what are its vesting and strike terms? | unresolved |
| RR4 | Pay disclosed and inside the market band | positive_signal | — | "$148,000–$166,000 plus equity" | The posted range meets the report's interquartile range at its top and sits near the median at its low end | `[grounded]` posting and Datawright report | Where in the range would someone with six years land? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm R1 and R2 for yourself before investing further | A failed gate decides everything | `[grounded]` R1, R2 | pending your approval |
| A2 | Find the role on the company's own careers page, or ask the recruiter for the live link | Closes RR1 | `[grounded]` RR1 | pending your approval |
| W1 | A small dbt-on-BigQuery project, a few models plus tests on a public dataset | Narrows R6's limit and gives something inspectable | `[inferred]` from R6's limit | pending your approval |
| E1 | Lead your resume with the roughly 180-model dbt project, the Airflow orchestration and the Great Expectations suite, in your own wording and numbers | These are your strongest rows (R5, R7, R8) | `[grounded]` your background text | pending your approval |
| Q1 | Ask the questions in RR2, RR3 and RR4 verbatim in the loop | The register doubles as interview prep | `[grounded]` register | pending your approval |

Nothing here is final until you approve it, and that covers the prose advice as well as the table.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 0 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The fetch of pellucidlearning.com/careers/senior-data-engineer was refused (permission not granted), so no search was sent after it. It would have settled whether the posting is live and matches your pasted text (role reality, RR1). |
| 2. Role-family sweep | skipped | The Datawright report you pasted already fixes the market calibration, the pay comparison and RR4. |
| 3. Hiring manager's public footprint | n/a | The posting names no one, so there was no query to form. |

I'm offering a deeper pass once (L2): up to 5 more searches and 2 more fetches on the company's funding, hiring pattern and recent news. It would need page-fetch permission.

I can write this up as a `tuesday-dossier.md` if you want one to keep or hand to interview prep.

## Upgrade menu

- Your location, work authorization and pay floor → R1 and R2 close, and the decision likely becomes `go` or `no_go`.
- Answers on app and CRM ingestion and on analyst contracts → R9 and R10 resolve.
- A sanitized dbt lineage graph or docs page, and a Great Expectations expectation list or data-docs page → R5 and R8 move to `high`.
- Permission to fetch the careers page, or a link to the live posting → RR1 closes.
- A hiring manager's name → role reality's scope read and the positioning in the plan.
- The L2 pass above, if you want it.

**Questions**

Q1 (G1, R1 and R2): Where will you work from, are you authorized to work in the US, and does $148,000–$166,000 clear your minimum base?

Q2 (G2, R9): What sources fed your pipelines at the payroll company, and did any look like a product database, event stream or CRM, and what did you own?

Q3 (G3, R10): Did you ever give analysts a written agreement on schema, freshness or ownership, such as a model contract or a change notice, and what happened when it broke?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.