## Decision snapshot

**Yes, this is worth applying to. R1, R2, R3, R4a, R5 and R6 (the must-haves) all land `direct`. R9 and R10, the two gates, are the only things left to confirm against your own terms. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R9 (Remote (US) or Denver office), R10 (Salary $148,000–$166,000)
- `must_have`: direct: R1, R2, R3, R4a, R5, R6
- `important`: adjacent: R4b (BigQuery warehouse); unclear: R7 (Ingestion from app and CRM), R8 (Data contracts)

R4b is a credible bridge with its limit named; R7 (`low`) and R8 (`low`) are waiting on your answers.

**Opportunity ledger.** The role looks sound on what is visible. The posted pay sits inside the reported market range (RR1) and the posting is live and matches the company's own pages (RR4). Equity terms (RR2), the manager and team (RR3) and success measures (RR5) are unknown.

- **Hard gates:** none failed; unconfirmed: R9 (Remote (US) or Denver office), R10 (Salary $148,000–$166,000); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. R9 and R10 match your own location, authorization and pay floor.
  2. The BigQuery bridge (R4b) is framed as adjacent, with Snowflake as your warehouse experience.
  3. RR3 and RR5 are answered in the screening call.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` About page, found by search |
| Posting status | Live ("Accepting applications"); the text matches your pasted copy | `[grounded]` careers page fetched |
| Mandate | Build and run reporting pipelines: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` JD |
| Seniority and scope | 5+ years sits inside the report's typical 5–8 for "Senior". The JD names no reports; the report's typical scope is one domain's pipelines with no direct reports | `[grounded]` JD and pasted Datawright report |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Market calibration | Report (n=2,310, Series B–D): median $151,000, IQR $139,000–$163,500. Posted $148,000–$166,000 straddles the median and its top end is above the IQR ceiling. Pellucid's Series C stage is inside the report's B–D scope. This is the report's figure, which I haven't verified independently. | `[grounded]` pasted report and JD |
| Unknowns | Hiring manager, team size, equity terms, success measures, interview process | — |
| Contradictions | None between your pasted JD and About text and the fetched pages | `[grounded]` pages fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years data engineering | must_have | direct | medium | none | 6 years at a B2B payroll company clears the bar. This is self-reported and nothing has been inspected, so `medium` | `[grounded]` your message | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | "Daily" use is the claim. "Strong" is what a technical screen will probe | `[grounded]` your message; `[generic]` that screens usually probe this | none |
| R3 | dbt | must_have | direct | medium | none | You built the dbt project, about 180 models, on Snowflake. Confirmed and specific, but no artifact inspected | `[grounded]` your message | Offer: a sanitized lineage graph or project structure would raise it to `high` |
| R4a | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse | `[grounded]` your message | none |
| R4b | dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | Carries over: warehouse SQL and dbt modelling. Limit: you have never used BigQuery. Partitioning, clustering and query-cost mechanics are warehouse-specific. The confidence grades your Snowflake claim | `[grounded]` your message; `[generic]` that these mechanics differ by warehouse | See G3 |
| R5 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow is named directly in your background | `[grounded]` your message | none |
| R6 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite. Confirmed and specific, no artifact inspected | `[grounded]` your message | Offer: a sanitized suite config or test-coverage summary would raise it to `high` |
| R7 | Ingestion from app and CRM | important | unclear | low | discovery | Airflow pipelines suggest data-movement work, but you haven't said which sources you ingested | `[grounded]` background silent on sources; `[inferred]` from the Airflow work | See G1 |
| R8 | Data contracts analysts depend on | important | unclear | low | discovery | A Great Expectations suite is adjacent to enforcing contracts, but you haven't claimed agreements with downstream consumers | `[inferred]` from the test suite | See G2 |
| R9 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location and work authorization were not given, so the gate is neither met nor failed | `[grounded]` JD; your constraints not given | Ask Q1 |
| R10 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | Your pay floor was not given | `[grounded]` JD; your constraints not given | Ask Q2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Ingestion from app and CRM (R7, important) | discovery | Airflow work is claimed, but not which source systems fed it | This is the first item in the role's mandate, so a concrete example moves it from `unclear` | Pulling product event or database data into the warehouse; syncing a CRM or billing system such as Salesforce or HubSpot; building a connector or CDC job | A sanitized DAG graph or an architecture diagram | `[grounded]` background silent on sources |
| G2 | Data contracts (R8, important) | discovery | A test suite is described, with no consumer-facing agreements | The posting names contracts as what analysts depend on | Schema or freshness checks that failed a run when upstream changed; a written SLA with analysts; dbt model contracts or tests that gated releases | A sanitized test list or a schema-change runbook | `[grounded]` the posting names contracts; `[inferred]` that the gap is discovery |
| G3 | BigQuery (R4b, important) | transferability | Snowflake and dbt, no BigQuery use | The one stack-specific item where you are adjacent | Any warehouse migration or cross-warehouse dbt work | A small personal BigQuery and dbt project, if you choose to build one | `[grounded]` your message; `[inferred]` that a sample project narrows the limit |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posted pay against the market | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range straddles the reported median, and its top end exceeds the interquartile ceiling | `[grounded]` JD and pasted report | Where in the range would someone with my background be placed? | noted |
| RR2 | Equity unspecified | unknown | — | "plus equity" | The grant could be material or nominal; the posting doesn't say | `[inferred]` from the posting's silence on type, size and vesting | What is the equity for this level: type, size, vesting and valuation basis? | unresolved |
| RR3 | Manager, team and scope of ownership unknown | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | The role could be the sole data engineer or one of several. The posting names no hiring manager | `[inferred]` from the JD against its silence on team | Who would I report to, how large is the data team, and who sets analysts' priorities? | unresolved |
| RR4 | Posting live and consistent with the company's own pages | positive_signal | — | "Accepting applications." | Employer and posting match what you pasted | `[grounded]` careers and About pages | What does the interview process look like? | noted |
| RR5 | No success measures stated | unknown | — | "Build and run the pipelines" | A demanding mandate with no stated definition of success | `[inferred]` from the JD's silence on outcomes | What would a successful first year look like for this role? | unresolved |

## Application plan

Every row below is proposed and pending your approval. `resume_edits_pending_approval` covers E1 and E2.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with the dbt project on Snowflake (about 180 models), Airflow orchestration and the Great Expectations suite you set up | R3, R5, R6 | `[grounded]` your message | pending your approval |
| E2 | Name Snowflake explicitly, and make no BigQuery claim | R4b | `[grounded]` your message | pending your approval |
| Q1 | Ask RR2, RR3 and RR5 verbatim in the recruiter screen | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Settle RR1 and RR2 together before accepting terms: where you land in the range, and the equity | RR1, RR2 | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Your background is self-reported prose, so these are leads, not proof.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer) and searched "Pellucid Learning online tutoring K-12 Denver Series C", which returned "About Pellucid Learning" (pellucidlearning.com/about). Both checked your pasted copies; the text matches and the posting is live. This moved role reality's posting-status and contradictions rows, and no failed-attribution entry was needed |
| 2. Role-family sweep | skipped | Your recruiter's pasted report already fixes the market-calibration row and RR1, so a search would change nothing |
| 3. Hiring manager's public footprint | n/a | The posting names no one, so there is no query to form |

## Dossier offer

If you want to keep this analysis, I can save it as a `tuesday-dossier.md`.

## Upgrade menu

- Your location, work authorization and pay floor close R9 and R10, and likely move the decision to `go`.
- An answer on data contracts (G2) or ingestion (G1) resolves R8 or R7.
- A sanitized dbt lineage graph or Great Expectations suite summary raises R3 or R6 to `high`.
- The hiring manager's name unlocks a footprint read and which of your stories to lead with.
- A deeper pass on Pellucid (funding, leadership changes, recent news) costs up to 5 more searches and 2 more fetches. Say the word and it runs.

## Questions

- **Q1 (R9):** Where are you based, and are you authorized to work in the US without sponsorship?
- **Q2 (R10):** Does a base of $148,000–$166,000 clear your pay floor, and what is that floor?
- **Q3 (G2):** Have you enforced agreements with downstream analysts, such as schema or freshness checks that blocked a release? What did you own, and what happened?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.