Web search wasn't permitted in this session, so this runs on the JD and your background alone, with no outside checks.

**Yes, apply, on conditions. Status: `conditional_go`.** R2, R3, R4, R5, R7a and R8 land `direct`. What's left open is whether Brindlemoor and the posting are real and live, a UK-remote confirmation on R1, and how you frame the pet-insurance gap (R10).

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote, UK)
- `must_have` — direct: R2, R3, R4, R5, R7a, R8 · unclear: R7b (Monitor rating models)
- `important` — adjacent: R9 (Recommendations for underwriting and product)
- `preferred` — direct: R6 · adjacent: R10 (Pet-insurance product knowledge)

R10 — a credible bridge, its limit named; R7b — monitoring practice unconfirmed; R1 — UK base unconfirmed.

**Opportunity ledger.** The role's deliverables are clearly stated (RR4). The employer is unverified because the search was refused (RR1), the pay is not stated (RR2), and team size and sign-off authority are not stated (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. Brindlemoor and the live posting verify on its own careers site (RR1).
  2. You confirm you are UK-based and can work remotely there (R1).
  3. You frame the pet gap as adjacent, never as pet expertise (R10).
  4. The pay is disclosed and works for you (RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product; not independently verified | `[grounded]` JD header; checks refused (see Evidence status) |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reports to | Odile Varga, Director of Pricing | `[grounded]` your message |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Line management | The JD states no reports and no management requirement | `[grounded]` JD silence |
| Scope read | A hands-on senior individual-contributor role, since the verbs are build, design and read and no team is mentioned | `[inferred]` from the JD's verbs against its silence on reports |
| Market calibration | None offered: no research ran and the posting states no pay | `[grounded]` JD silence on pay |
| Unknowns | Salary, contract basis, team size, who signs off rate changes, what pet claims data and rating tooling exist | — |
| Contradictions | None between the JD and your background; the JD could not be checked against a careers page | `[grounded]` JD and your message |

## Evidence map

Your background is prose in this conversation, so it counts as self-report and tops out at `medium` until you share something inspectable.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK | hard_gate | unclear | low | hard_gate | You haven't stated your location or constraints. Your UK motor insurer role suggests a UK base, but that is an inference and not a confirmed statement | `[inferred]` from "UK motor insurer"; JD term `[grounded]` | Ask G1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You state 5 years of pricing analytics, 2 of them as senior analyst; specific, but not yet inspectable | `[grounded]` your message | Offer: CV or role history would raise this |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You state daily use of both; no artifact seen | `[grounded]` your message | Offer: a sanitized query or notebook sample would raise this |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book; confirmed and specific, with no model documentation inspected. Expect a probe on the modelling choices | `[grounded]` your message | Offer: sanitized model documentation would raise this |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting; the audience is underwriting, which the JD names. Actuarial audiences are not mentioned | `[grounded]` your message | Offer: a sanitized review deck would raise this |
| R6 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a UK motor insurer | `[grounded]` your message | none |
| R7a | Build rating models | must_have | direct | medium | none | You built the young-driver GLM rating model | `[grounded]` your message | none |
| R7b | Monitor rating models | must_have | unclear | low | discovery | You say "maintained", which doesn't establish monitoring practice such as performance tracking or drift checks. Read downward, it stays unconfirmed | `[grounded]` your wording; the gap is `[inferred]` | Ask G2 |
| R8 | Design and read price tests | must_have | direct | medium | none | You ran 14 price tests last year with the underwriting team. "Ran" doesn't say who set the test design, so expect a probe on that | `[grounded]` your message | Be ready to say exactly what you designed versus what others set |
| R9 | Turn results into recommendations for underwriting and product | important | adjacent | medium | discovery | Underwriting is covered by the tests you ran with them and the quarterly review. Product-side recommendations are not mentioned | `[grounded]` your message; product gap `[inferred]` | Ask G3 |
| R10 | Pet-insurance product knowledge (implied by the role's product) | preferred | adjacent | medium | transferability | You confirm you have never worked on pet insurance. Your GLM rating work on a personal-lines motor book carries over. Limit: pet-specific rating factors and claims patterns were not exercised | `[inferred]` adjacency from your motor rating work; limit `[generic]` | Bridge case in G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | UK-remote term (R1, hard_gate) | hard_gate | You haven't stated your base or constraints | A gate that nothing settles stays open and is shown in the snapshot | A UK home base, UK right to work, and any pay floor or other term you won't trade | Nothing to attach | `[grounded]` no constraints given |
| G2 | Monitoring rating models (R7b, must_have) | discovery | "Maintained" is stated; monitoring practice is not | Monitoring is named in the JD's first duty, and which answer is true decides how you present R7b | Tracking actual versus expected loss ratios by segment; drift or stability checks on rating factors; periodic model refreshes you triggered | A monitoring dashboard or a sanitized model-review pack | `[grounded]` JD duty; `[generic]` that rating-model roles probe monitoring |
| G3 | Product-side recommendations (R9, important) | discovery | Underwriting audiences are covered; product stakeholders are not mentioned | The JD names product as a second audience for your recommendations | A pricing result that changed a product feature, cover limit or excess; working with a product owner on a launch or rate change | A sanitized recommendation paper or readout | `[grounded]` JD names product; `[inferred]` the product gap from your silence |
| G4 | Pet-insurance knowledge (R10, preferred) | transferability | Motor GLM rating, with no pet exposure | A preferred, implied requirement, and the likeliest "never done pet" objection | The bridge is rating a personal-lines book by GLM. The limit is pet-specific factors and claims patterns. The strengthener is a short note on how you would approach a pet rating model | A brief, sanitized outline of how your motor rating approach would adapt | `[inferred]` bridge from your motor rating work; `[generic]` that this is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. The search was refused, so nothing is established either way | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Salary not stated | unknown | — | The JD as pasted gives no pay figure | The figure may be withheld, or may not have been in what you pasted | `[grounded]` JD silence as pasted | What salary range is budgeted for this post? | unresolved |
| RR3 | Ownership asserted, team and authority unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | You may be the sole analyst, or may be accountable for rating without sign-off on rate changes | `[inferred]` from the JD's scope language against its silence on team and authority | Who is in the pricing team, and who signs off a rate change? | unresolved |
| RR4 | Deliverables stated concretely | positive_signal | — | "build and monitor rating models, design and read price tests" | The work is defined by what you produce, and what you'll be judged on can be read from the duties | `[grounded]` JD | What would a good first year look like for this post? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm Brindlemoor and the live posting on its own careers site before investing in an application | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Lead with the three things you've said about yourself that match the JD's core duties: you built and maintained the young-driver GLM rating model, you ran 14 price tests last year with the underwriting team, and you present the quarterly pricing review to the head of underwriting. Use those words and nothing stronger | see R4, R8, R5 | `[grounded]` your message | pending your approval |
| A3 | State plainly that you haven't worked on pet insurance and that your rating experience is from motor; don't call it pet expertise | see R10 | `[grounded]` your message | pending your approval |
| A4 | If asked about management, say you haven't managed anyone. The JD states no reports, so ask whether the role has any | see RR3 | `[grounded]` your message; JD silence | pending your approval |
| A5 | Ask the register's verification questions verbatim in the loop, including who signs off a rate change | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Stage assumed: evaluating. Your background is treated as self-report until you answer a probe or share an artifact.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Brindlemoor pet insurance insurtech"; the call was refused. It would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | Searched "Senior Pricing Analyst pet insurance UK salary"; the call was refused. It would have moved market calibration and RR2 |
| 3. Hiring manager's public footprint | unavailable | Searched "Odile Varga Director of Pricing Brindlemoor"; the call was refused. It would have moved the scope read and which story the plan leads with |

If you'd like, I can save this as a `tuesday-dossier.md` to carry forward.

**Upgrade menu**

- Allow web search, and I'll run the three checks above. They would close or reduce RR1, give a market calibration for RR2, and add Odile's public professional footprint to the plan.
- Your non-negotiables (pay floor, UK base, right to work) → R1 resolves, and any pay or location gate rows get checked.
- A monitoring dashboard or model-review pack, a sanitized test readout, and your quarterly pricing review deck → R4, R7a, R7b, R8 and R5 can rise from `medium` to `high`.
- Your CV, if you want it read as a document rather than from your message → rows are re-checked against it.
- The salary range → RR2 closes.

**Questions**

G1 — What are your non-negotiables for this role: are you UK-based with the right to work there remotely, and is there a pay floor or any other term you won't trade?

G2 — Have you tracked how your young-driver GLM performed after it went live, such as actual versus expected loss ratios by segment or checks on whether factors drifted? What did you own, and what did you do when it moved?

G3 — Has one of your price test results changed a product decision, such as a feature, a cover limit or a rate change? Who did you present it to, and what did you recommend?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.