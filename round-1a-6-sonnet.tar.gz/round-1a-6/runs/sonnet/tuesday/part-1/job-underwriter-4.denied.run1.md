I've read the playbook. Next I'm running the default research: checking that Brindlemoor exists, a salary sweep for the role, and Odile Varga's public footprint.
**Short answer: yes, apply, on conditions.** Web search was refused, so I couldn't verify Brindlemoor or the salary. Everything below rests on the JD and what you told me.

## Decision snapshot

**Yes, worth applying to. The JD asks for no people management, and pet insurance is listed nowhere as a requirement, so neither of your two concerns blocks you. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote (UK))
- `must_have`: direct: R2, R3, R4, R5
- `important`: direct: R6, R8 · unclear: R7 (Monitor rating models)
- `preferred`: direct: R9 · adjacent: R10 (Pet-insurance product knowledge)

R10: a credible bridge, its limit named; R7: your stated work is maintaining the model, not monitoring it; R1 (`low`): UK base inferred, not stated.

**Opportunity ledger.** Thin but not excluded: the employer and posting are unverified (RR1), pay is unstated (RR2), and team and decision rights are unstated (RR3). The responsibilities are concrete and the hiring manager is named (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) UK base and right to work confirmed (R1); (2) Brindlemoor and the live posting verified (RR1); (3) the salary clears your own floor (RR2); (4) pet experience framed honestly as adjacent, never as pet-pricing experience (R10).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product; existence not verified | `[grounded]` JD header as you gave it |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing; public footprint not researched | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| People management | The JD lists no direct reports and no management requirement | `[grounded]` JD text provided |
| Scope read | A single-product pricing seat where you would be the named owner of the analytics | `[inferred]` from "Own pricing analytics" against the JD's silence on team size |
| Market calibration | Not calibrated: the sweep was refused and the JD states no pay (RR2) | `[grounded]` search refused; JD silent |
| Unknowns | Salary, team size, decision rights on rate changes, tools and data stack | `[grounded]` absent from the JD |
| Contradictions | None inside the JD; the careers page was not checked | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | low | hard_gate | You didn't state your location or right to work. You work at a UK insurer, so UK is likely, but that's a guess and not your word | `[inferred]` from "UK motor insurer"; no stated constraint | G1 question |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Your account: 5 years of pricing analytics, the last 2 as senior analyst. Self-reported, nothing inspectable yet | `[grounded]` your account | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily"; the word "strong" is untested without an artifact | `[grounded]` your account | a sanitized query or notebook would raise it to `high` |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for your young-driver book | `[grounded]` your account | a model-documentation excerpt would raise it |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. Underwriting is named in the JD, actuarial is not covered | `[grounded]` your account | a sanitized review deck would raise it |
| R6 | Build rating models | important | direct | medium | none | "Built and maintained" the GLM model | `[grounded]` your account | none |
| R7 | Monitor rating models | important | unclear | low | discovery | "Maintained" doesn't say whether you tracked live performance, drift or segment results | `[grounded]` your account is silent on monitoring | G2 question |
| R8 | Design and read price tests | important | direct | medium | discovery | You ran 14 price tests last year with the underwriting team. The account doesn't say which parts were yours: design, running, reading, or the recommendation | `[grounded]` your account | G3 question |
| R9 | Insurance experience, a plus | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your account | none |
| R10 | Pet-insurance product knowledge (not a JD requirement) | preferred | adjacent | low | transferability | Inferred from "for our pet-insurance product". You confirmed no pet work. Motor GLM rating transfers in method; pet-specific rating inputs and claims patterns were not exercised by your work | `[inferred]` from the role title; `[generic]` that pet rating uses different risk factors from motor | G4 bridge |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | UK base and right to work (R1, hard_gate) | hard_gate | Nothing stated about location or work eligibility | A failed gate would end this, whatever the fit elsewhere | Not applicable; this is a status, not an experience | Nothing needed beyond your answer | `[grounded]` constraint not given |
| G2 | Monitoring rating models (R7, important) | discovery | Building and maintaining are stated; monitoring is not | Monitoring is named in the JD's first responsibility | Tracking actual-versus-expected by segment; a post-launch review; drift or relativity checks; a dashboard others used | A sanitized monitoring pack or dashboard screenshot | `[grounded]` account silent; `[inferred]` that this is the weakest stated responsibility |
| G3 | Price-test ownership (R8, important) | discovery | 14 tests, with the split of your role unstated | The JD says design and read, and an interviewer will ask what was yours | Choosing the test and control split; setting sample size or run length; analysing results; presenting the recommendation | A sanitized test write-up or readout | `[grounded]` account; `[generic]` that interviews for this kind of role probe attribution |
| G4 | Pet-insurance knowledge (R10, preferred) | transferability | Motor GLM work is the bridge; its limit is that no pet-specific work has been done | It is the likeliest objection, though not a stated requirement | Any work on a non-motor line, an animal or breed dataset, or claims-cost modelling | A short note on how a motor rating structure would map to pet | `[inferred]` bridge; `[generic]` objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not verified | unknown | — | "Brindlemoor (insurtech)" | No result either way: the checks were refused, so nothing is established or ruled out | `[grounded]` three searches refused, none returned | Can you point me at this role on Brindlemoor's own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Salary not stated | unknown | — | No pay figure in the JD | The pay may or may not meet your floor; I can't calibrate it without a market sweep | `[grounded]` JD silent | What salary range is budgeted for this post? | unresolved |
| RR3 | Team and decision rights unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | You may be the sole pricing owner, or one of a team | `[inferred]` from the scope language against the JD's silence on team | Who else is on the pricing team, and which rate changes does this role decide versus recommend? | unresolved |
| RR4 | Concrete responsibilities and a named manager | positive_signal | — | "turn the results into recommendations for underwriting and product" | The scope is defined and matches your work | `[grounded]` JD | What would a successful first year look like for this role? | noted |

## Application plan

`resume_edits_pending_approval`: every row is proposed, none applied.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Put the GLM rating model for the young-driver book and the 14 price tests run with underwriting last year at the top of your CV, in your own words | see R4, R8 | `[grounded]` your account | pending your approval |
| E2 | Add the quarterly pricing review to the head of underwriting as its own line | see R5 | `[grounded]` your account | pending your approval |
| E3 | In the cover note, say plainly that your pricing work is motor and the structure carries over, with no claim of pet-pricing experience | see R10 | `[grounded]` your confirmation of no pet work | pending your approval |
| Q1 | Ask the questions of RR1, RR2, RR3 and RR4 verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Brindlemoor pet insurance insurtech careers Senior Pricing Analyst"; refused. It would have confirmed the employer and live posting (RR1) |
| 2. Role-family sweep | unavailable | Searched "senior pricing analyst insurance UK salary remote pet insurance"; refused. It would have given a market band for RR2 and the calibration line |
| 3. Hiring manager's public footprint | unavailable | Searched "Odile Varga Director of Pricing Brindlemoor"; refused. It would have shaped which story to lead with in the plan |

I can write this up as `tuesday-dossier.md` if you want to carry it forward.

## Upgrade menu

- Web search access → RR1 and the employer check, a market salary band against RR2, and Odile Varga's public professional background for the application plan.
- Your location and right to work → R1 closes.
- A sanitized monitoring pack, test readout, or code sample → R7, R8 and R3 can reach `high`.
- Your salary floor → RR2 can be checked as a hard-gate row.

## Questions

G1: Are you based in the UK with the right to work there, and is fully remote working fine for you?

G2: After a rating model went live, what did you personally do to monitor it: which measures, how often, and who saw the results?

G3: For the 14 price tests, which parts were yours: designing, running, reading the results, or recommending the decision?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.