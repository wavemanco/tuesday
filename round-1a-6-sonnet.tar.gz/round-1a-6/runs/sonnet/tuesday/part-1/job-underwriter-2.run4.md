## Decision snapshot

**No, you are not wasting your time, but treat this as a stretch application: `conditional_go`.** R3 and R4a are `direct`, R1a and R2 are `adjacent`, and R1b, the titled PM years, is `absent`.

**Fit ledger.**

- `must_have` — direct: R3, R4a · adjacent: R1a (PM-adjacent work), R2 (Shipped API or platform products) · unclear: R4b (Stakeholder work with sales), R5 (Agile delivery) · absent: R1b (Titled PM years)
- `important` — direct: R6 · adjacent: R7 (Specs and squad delivery), R10 (Launch coordination) · unclear: R8 (Roadmap ownership), R9 (Adoption metrics)

R1b — the missing title, graded as a must-have gap and not a gate; R1a (`medium`) — adjacent work, its limit named; R2 (`medium`) — integrated APIs, not shipped them.

**Opportunity ledger.** The scope is concrete, with named stakeholders and metrics (RR5). Employer existence is unverified because research was refused (RR1). Pay and location are unstated (RR2, RR3), and roadmap decision rights are unclear (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the missing title is stated plainly and bridged with named evidence — R1a, R1b; (2) a concrete example of deciding what to build and tracking its adoption emerges — R8, R9, G1; (3) the posting and employer verify — RR1.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B | `[grounded]` JD header |
| Mandate | Own the roadmap of a partner-facing API platform. Run partner discovery, write specs, drive two engineering squads, track adoption, coordinate launches with sales and support | `[grounded]` JD |
| Level read | A mid-level IC post. The ask is "3+ years", with no senior or lead language | `[inferred]` from the years requirement and the absence of seniority wording |
| Scope read | Platform-PM scope that fits your integration background closely. Partners are the customers and the API is the product | `[inferred]` from the JD's partner and API wording against your resume |
| Years requirement | The JD says "product management experience" and does not say whether equivalent work counts. Some hiring teams read the phrase as titled years and others accept adjacent work | `[generic]` pattern, not a claim about this employer |
| Market calibration | Not run. Both searches were refused, so pay and title norms are unknown | `[grounded]` the refusals, this session |
| Unknowns | Pay, location or remote terms, roadmap decision rights, which adoption metrics exist today, who the hiring manager is | `[grounded]` JD silence |
| Contradictions | None found inside the JD | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years of product management experience: product-facing work | must_have | adjacent | medium | transferability | Requirements documents, client feedback fed to product, and coordination with PMs on custom builds are real product-adjacent work. They were done from the vendor's delivery side, not as the owner of a product. Intake prose caps this at `medium` | `[grounded]` resume, unprobed | G1 |
| R1b | 3+ years of product management experience: titled or owned years | must_have | absent | none | capability | You have never held the title, and nothing shows you owned prioritization. This is a statement about the evidence, not about you. It is a must-have gap and not a gate, because a length-of-experience requirement is never a gate | `[grounded]` your statement | State it plainly in the application; see plan P2 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ integrations of your employer's REST APIs and wrote the internal integration playbook. Limit: you integrated and enabled a product and did not ship one. A recalled internal triage tool is a lead only | `[grounded]` resume; `[inferred]` bridge | G1 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL and OpenAPI reading, plus integration architecture across 30+ clients, match the ask closely. `medium` because nothing inspectable has been seen yet | `[grounded]` resume | Offer: a sanitized slice of the playbook would raise it to `high` |
| R4a | Stakeholder management across engineering and customers | must_have | direct | medium | none | You coordinated your engineers, client engineers and PMs, and ran client scoping and UAT | `[grounded]` resume | none |
| R4b | Stakeholder management with sales | must_have | unclear | low | discovery | The resume does not mention sales. Client-facing work suggests contact but does not show it | `[grounded]` resume silence | G3 |
| R5 | Experience with agile delivery | must_have | unclear | low | discovery | The resume describes UAT and go-live and says nothing of sprints, backlogs or squad ceremonies | `[grounded]` resume silence | G2 |
| R6 | Run discovery with integration partners | important | direct | medium | none | Scoping workshops and quarterly roadmap-input sessions with clients are partner discovery in substance | `[grounded]` resume | none |
| R7 | Write specs and drive delivery with two engineering squads | important | adjacent | medium | transferability | You wrote requirements documents and coordinated engineers on custom builds. Limit: those were client-specific builds, not product specs prioritized across a standing squad's backlog | `[grounded]` resume; `[inferred]` limit | G2 |
| R8 | Own the roadmap | important | unclear | low | discovery | You collected feedback "for product", which feeds a roadmap but does not own one. The triage-tool lead might show prioritization, unconfirmed | `[grounded]` resume; `memory_lead` unconfirmed | G1 |
| R9 | Define and track adoption metrics | important | unclear | low | discovery | The resume gives no adoption measures. The triage-tool lead mentions agents adopting it, unconfirmed | `[grounded]` resume silence | G1 |
| R10 | Coordinate launches with sales and support | important | adjacent | medium | transferability | Client go-lives are launches in a narrow sense. Limit: they were one client at a time, not a platform release to many partners | `[grounded]` resume; `[inferred]` limit | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning a product decision and its adoption (R8, R9, R2, R1a; must_have and important) | discovery | Nothing in the resume shows you deciding what to build or measuring uptake of something you built | This is the evidence most likely to move R1a and R8 and narrow the title objection | An internal tool you scoped and others adopted; a client-driven feature you prioritized against other asks; usage counts or a before-and-after you tracked | A one-page description, screenshots, usage numbers, a request list | `[grounded]` resume silence; `[inferred]` that it moves R1a and R8 |
| G2 | Agile delivery with a standing engineering team (R5, R7; must_have and important) | discovery | UAT and go-live are described, but not iterative delivery with a squad | The JD names agile as a requirement and names two squads | Sprint planning or backlog grooming with engineers on an internal build; writing tickets or acceptance criteria that engineers delivered against | A ticket export, a roadmap or backlog screenshot | `[grounded]` resume silence |
| G3 | Working with sales and support on launches (R4b, R10; must_have and important) | discovery | Go-lives are described, with no sales or support hand-offs | The JD's stakeholder list includes both groups | Briefing sales on a new capability; writing enablement for support; co-owning a client launch plan | A launch checklist, an enablement doc, a hand-off note | `[grounded]` resume silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. Both searches were refused, so this is untested and not a finding | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Compensation not stated | unknown | — | The posting provided gives no pay figure | The range may sit above or below your floor, which I do not have | `[inferred]` from the posting's silence | What is the budgeted range for this role? | unresolved |
| RR3 | Location and working arrangement not stated | unknown | — | The posting provided gives no location or remote terms | The post may be in-office or hybrid in a way that matters to you | `[inferred]` from the posting's silence | Where is this role based, and what are the in-office expectations? | unresolved |
| RR4 | Roadmap ownership without stated decision rights | unknown | — | "Own the roadmap for our partner-facing API platform" | The roadmap may be shaped largely by sales and partner requests, with the PM arbitrating | `[inferred]` from the scope wording against its silence on authority | Which roadmap decisions does this role make alone, and which go to engineering or leadership? | unresolved |
| RR5 | Scope and success measures are explicit | positive_signal | — | "define and track adoption metrics"; "two engineering squads" | The mandate is defined enough to be judged | `[grounded]` JD | Which adoption metrics does the team track today? | noted |

## Application plan

This is the plan, not a resume rewrite. Tailoring the resume to this posting is resume-tailor's job, and I have not done it. Every row below, and the prose in it, is proposed only and is final only once you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the work that is nearest to product: the roadmap-input sessions, the playbook, and the partner scoping workshops. Describe them as what they were. Do not call the sessions roadmap ownership, and do not call the integrations shipped products | See R1a, R2, R6, R8 | `[grounded]` resume | pending your approval |
| P2 | Say plainly in the cover note that you have not held a PM title, then name the closest evidence in your own words. Add G1's answer if it confirms | See R1b | `[grounded]` R1b row | pending your approval |
| P3 | Ask the verification questions of RR1 to RR5 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| P4 | Look for an intro through a current partner or ex-colleague before applying cold | How hiring often works at small companies, not a fact about this one | `[generic]` role-family pattern | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: a recalled internal request-triage tool that support agents adopted. It is unconfirmed, and it only prompts G1. It is not evidence.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | I searched "Quartzline logistics technology Series B partner API platform". The call was refused, so RR1 stays untested. A result would have shown whether the company and posting exist as described |
| 2. Role-family sweep | unavailable | I searched for platform-API PM requirements, pay and solutions-engineer transitions. The call was refused, so role reality's market calibration row is empty. A result would have set pay and the years requirement against norms |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- Permission to run web search → targets 1 and 2 run. RR1 can clear, and the market calibration row fills.
- A name for the hiring manager → role reality's scope read and which story the plan leads with.
- Your pay floor, location limits and any other must-haves → hard-gate checks against RR2 and RR3, which are unknown today.
- A one-page description or usage numbers for the triage tool → R8, R9 and R2 can move, and R1a may strengthen.
- A sanitized slice of the integration playbook → R3 to `high`.

Say the word and I can emit this as `tuesday-dossier.md` to carry into later steps.

**Questions**

G1 — Is there something you built or shaped, such as the request-triage tool, where you decided what it should do, others adopted it, and you can say how you knew? What was yours, what was the team's, and what happened?
G2 — Have you worked with an engineering team in sprints or a backlog, for example writing tickets or acceptance criteria that engineers delivered against?
G3 — Have you briefed sales or support on a new capability, or co-owned a launch plan with them? What did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.