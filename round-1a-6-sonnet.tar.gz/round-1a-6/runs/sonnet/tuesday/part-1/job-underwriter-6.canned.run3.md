Research is done: three searches, plus the posting you linked. Here's the assessment.

## Decision snapshot

**Yes, worth applying, as a stretch rather than a clean fit: R10 is absent and R7 is not established. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Office location: Bristol, hybrid two days), R2 (Pay: £61,500–£67,000 plus share options)
- `must_have` — direct: R3, R5 · adjacent: R6 (Strong SQL and spreadsheet modelling), R8 (Run the quarterly revenue forecast with the CFO) · unclear: R4 (At a B2B software company), R7 (Experience owning a forecast), R9 (Working with finance on billing or revenue data) · absent: R10 (Own the billing data)
- `important` — direct: R11

R8 — a credible bridge, its limit named; R6 (`low`) — usage stated, modelling depth not; R10 — no evidence yet, a closure path in G4.

**Opportunity ledger.** The employer matches the posting (RR1) and the pay sits inside the market band (RR3). Open items: whether the role is listed on Quillfield's own site (RR2), the share option terms (RR4), and the team and who owns billing data today (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Office location: Bristol, hybrid two days), R2 (Pay: £61,500–£67,000 plus share options); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. Bristol with two office days (R1) and the pay range (R2) work for you. If either fails, the status becomes `no_go`.
  2. Quillfield treats forecast ownership and billing data (R7, R10) as things you can learn on the job. Check this through RR5's question and a conversation with the hiring manager.
  3. You state the gaps yourself, without bridging them with adjacent experience (see A2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants, founded 2018 in Bristol, 96 employees, Series A (£11M) closed April 2025 | `[grounded]` quillfield.co.uk/about, search result text |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting for sales and finance; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern and pay | Bristol, hybrid, two office days a week; £61,500–£67,000 plus share options | `[grounded]` posting |
| First-90-days and first-year outcomes | Not stated in the posting | `[grounded]` posting silent |
| Reporting line | Tamsin Achebe's public profile lists her as Head of Revenue Operations at Quillfield, so the post plausibly reports to her. The recruiter named her as hiring manager. | `[grounded]` profile (linkedin.example/in/tamsin-achebe) for her title; `[inferred]` for the reporting line |
| Scope read | Data ownership, cross-team reporting and a CFO-facing forecast are folded into one post, and the team size is not stated (RR5) | `[inferred]` from the posting's three duties and its silence on reports |
| Market calibration | £61,500–£67,000 brackets the median of £64,200 (interquartile range £57,800–£70,400) for UK B2B software revenue operations leads, n=438. This is a national band from one pay guide, not Bristol-specific and not this employer's offer. | `[grounded]` posting figure; `[generic]` band from the Ledgerline 2026 guide |
| Unknowns | Direct reports, current owner of billing data, forecast tooling, share option terms | `[grounded]` posting silent |
| Contradictions | None found between the posting and the company page | `[grounded]` both read |

## Evidence map

Your background is typed prose, so it counts as self-report, and `medium` is the ceiling until something inspectable exists.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Office location: "Bristol, hybrid: two days a week in the office" | hard_gate | unclear | none | hard_gate | You have not said where you are based or what office days you will accept, so nothing settles this term | `[grounded]` posting quote; no constraint stated | G1 |
| R2 | Pay: "£61,500–£67,000 plus share options" | hard_gate | unclear | none | hard_gate | No pay floor stated; the posting gives the range, so only your floor is missing | `[grounded]` posting quote; no constraint stated | G1 |
| R3 | "4+ years in revenue operations, sales operations or a similar analytics role" | must_have | direct | medium | none | You describe 5 years in sales operations, the last 2 running revenue operations for the UK team. Specific and plausible, with no artifact inspected. | `[grounded]` your background | none |
| R4 | The role sits "at a B2B software company" | must_have | unclear | low | discovery | You describe a B2B payments company. The posting says software company, and your background does not settle whether that counts. | `[grounded]` your wording against the posting quote | G7 |
| R5 | "HubSpot or Salesforce administration" | must_have | direct | medium | none | You are Salesforce admin certified. A credential link would make this inspectable. | `[grounded]` your background | none |
| R6 | "Strong SQL and spreadsheet modelling" | must_have | adjacent | low | discovery | You use SQL weekly and Excel daily. Frequency is stated, but strength and modelling (as opposed to use) are not. | `[grounded]` your wording | G6 |
| R7 | "Experience owning a forecast" | must_have | unclear | low | discovery | You have never owned the company forecast, because finance did. The posting says "a forecast", so a narrower one (team, region, renewals) may exist and you have not said either way. | `[grounded]` your statement; `[inferred]` from the posting's wording | G2 |
| R8 | Run the quarterly revenue forecast with the CFO | must_have | adjacent | medium | transferability | You run the monthly pipeline review with your sales director. Limit: that review is not the forecast, and finance owned the forecast where you work. | `[grounded]` your statements | G5 |
| R9 | "Experience working with finance on billing or revenue data" | must_have | unclear | low | discovery | You have never worked on billing data. The "or revenue data" half is open: your renewal dashboards are revenue-related, but working with finance on them is not stated. | `[grounded]` your statement; `[inferred]` that renewal dashboards touch revenue data | G3 |
| R10 | "Own our CRM and billing data" | must_have | absent | none | capability | The CRM half is carried by R5 and R11. The billing half has no evidence, because you have never worked on billing data. | `[grounded]` your statement | G4 |
| R11 | Build the pipeline and renewal reporting sales and finance run on | important | direct | medium | none | You rebuilt your pipeline and renewal dashboards. Whether finance used them is not stated, so only the build is claimed. | `[grounded]` your background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and pay terms (R1, R2) | hard_gate | Posting terms known; your constraints unknown | A failed gate ends the decision at `no_go` however strong the fit | A term you meet or not, so this is not an experience question | Your own statement of floor and limits | `[grounded]` posting terms; your constraints not given |
| G2 | Owning a forecast (R7) | discovery | Company forecast was finance's; narrower forecasts unmentioned | A must-have, and the CFO forecast is a stated duty | A UK-team or renewals projection you built and others used; a quarterly bookings number you maintained and defended | A sanitized forecast workbook; a forecast-versus-actual review | `[grounded]` your statement; `[inferred]` that a narrower forecast may exist |
| G3 | Finance on revenue data (R9) | discovery | Billing excluded; revenue-data half unaddressed | The posting offers "billing or revenue data", so this half could carry the row | Reconciling renewal figures with finance; agreeing metric definitions; quarter-end reporting support | A metric-definition document; a sanitized reconciliation sheet | `[grounded]` posting wording and your statement |
| G4 | Billing data ownership (R10) | capability | No evidence; you have not worked on billing data | A must-have and part of the first sentence of the mandate | Closure path: learn how invoices, subscriptions and credit notes are structured and linked to the CRM, and name that ramp-up openly | A short sanitized worked example once learned | `[grounded]` your statement; `[generic]` that billing data follows this structure at invoicing companies |
| G5 | Forecast with the CFO (R8) | transferability | Monthly pipeline review you run with your sales director | It is your nearest bridge to the forecast duty, with its limit named | A sanitized pipeline-review pack; how its numbers fed anything finance used | A one-page pack example | `[grounded]` your statements |
| G6 | SQL and modelling depth (R6) | discovery | Usage frequency only | Strength and modelling are what the posting asks | The query behind a renewal dashboard; an Excel pipeline-coverage or renewal-rate model | A sanitized query or workbook | `[grounded]` your wording |
| G7 | Software-company setting (R4) | discovery | You describe a payments company | Wording in the posting you cannot change but can explain | Subscription or platform products your employer sold | Your employer's product page | `[grounded]` your wording |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer matches the posting | positive_signal | — | "invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol; 96 employees" | The posting's company, product and city agree with the company's own page | `[grounded]` quillfield.co.uk/about | How is the revenue operations function structured today? | noted |
| RR2 | Role seen on the job board only | unknown | — | "Revenue Operations Lead, Quillfield. Bristol, hybrid" (Tallyboard listing) | The one careers search returned the company page and no listing, which may only mean the board is where it is advertised | `[inferred]` from one search against the board listing | Is this role live on your own careers page, and since when? | unresolved |
| RR3 | Pay inside the market band | positive_signal | — | "Salary £61,500–£67,000" | The stated range brackets the national median for the title | `[grounded]` posting figure; `[generic]` Ledgerline band | Where in the range would someone with my background start? | noted |
| RR4 | Share option terms unstated | unknown | — | "plus share options" | Their worth depends on grant size, vesting and strike price, none of which the posting gives | `[generic]` that option value turns on those terms; `[grounded]` posting silent | What are the grant size, vesting schedule and strike price? | unresolved |
| RR5 | Reports and billing-data ownership unstated against a "Lead" title | unknown | — | "You will own our CRM and billing data" | The post may be a lead of one, with billing data currently sitting elsewhere | `[inferred]` from the posting's silence on reports against its "Lead" title | Does this role have direct reports, and who owns the billing data today? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with your Salesforce admin certification, the rebuilt pipeline and renewal dashboards, and the monthly pipeline review you run with your sales director | see R5, R11, R8 | `[grounded]` your statements | pending your approval |
| A2 | State plainly that finance owned the company forecast where you work and that you have not worked on billing data, each paired with how you would come up to speed | see R7, R10 | `[grounded]` your statements | pending your approval |
| A3 | Ask RR5's, RR4's and RR2's questions verbatim, and ask how the CFO forecast is built today | see RR2, RR4, RR5, R8 | `[grounded]` register | pending your approval |
| A4 | Frame your story in sales-operations terms for Tamsin Achebe, whose listed background includes four years as a sales operations manager at a payments company | see R3, R11 | `[grounded]` her profile text; `[inferred]` that this framing suits her | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company careers"; result text of "About Quillfield" (quillfield.co.uk/about). Moved role reality's organization row and RR1. No careers listing returned, which moved RR2. |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary Bristol B2B software"; result text of "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved the market calibration row and RR3. |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield"; result text of "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Moved the reporting-line row and A4. |

These rest on search-result text, not full pages.

If you'd like a saved record of this assessment, I can emit it as `tuesday-dossier.md`.

## Upgrade menu

- Your pay floor, where you would commute from, and the office days you will accept → R1 and R2 resolve and the hard-gates line closes.
- Any forecast you built, even narrow, plus a sanitized workbook → R7 and R8 firm up.
- Examples of working with finance on renewal or revenue numbers → R9 resolves.
- A link to your Salesforce credential → R5 rises to `high`. A sanitized SQL query or dashboard screenshot → R6 and R11 firm up.
- Your CV → I can check its wording against these rows.
- Whether your employer sells software or a platform → R4 resolves.
- A deeper research pass on Quillfield (funding, leadership changes, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

G1 — Are two office days a week in Bristol and a £61,500–£67,000 base workable for you, and if not, what is your limit?

G2 — Have you ever built or owned any forecast, even for the UK team or renewals alone, and what was your part and who used it?

G3 — Have you worked with your finance team on revenue or renewal numbers (reconciling figures, agreeing definitions, quarter-end reporting), and what did you personally do?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.