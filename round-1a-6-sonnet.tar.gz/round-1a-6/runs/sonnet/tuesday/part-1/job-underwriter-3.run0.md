# Job Underwriting: Head of Growth, Novaline

## Decision snapshot

**No, this isn't worth pursuing. R1 and R2, both hard gates, fail. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: hard_gate_fail: R1 (On-site Austin five days a week), R2 (Base $70–85k)
- `must_have`: direct: R3, R4, R5, R6 · unclear: R7 (SEO and content)
- `important`: adjacent: R10 (Team of one) · unclear: R8 (Brand, PR, partnerships), R9 (Sales ops)

R1: the posting says "no exceptions"; R2: its $85k top sits $65k below your floor.

**Opportunity ledger.** The register backs up the feeling that something is off. Seven functions sit with no team (RR2), hours are open-ended (RR3), success is undefined (RR4), and the pay is unchecked against market (RR1). Equity is unquantified (RR5) and the employer is unconfirmed (RR6). One entry runs the other way: you report directly to the CEO (RR7).

- **Hard gates:** failed: R1 (On-site Austin five days a week), R2 (Base $70–85k).
- **Severe red flags:** none found.
- **What would change this:** the posting would need to allow remote work from Portland and a base of at least $150k. It says neither is available, so the match on paper doesn't rescue it.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement startup, Series A, "profitable since day one". This is the posting's own description and is not checked | `[grounded]` JD header; not verified, search refused |
| Mandate | Own all revenue growth end to end across paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships and sales ops | `[grounded]` JD |
| Team and reporting | Team of one to start; reports to the CEO with a dotted line to the board | `[grounded]` JD |
| Working pattern | On-site in Austin five days a week, "no exceptions"; evenings and weekends "when it matters" | `[grounded]` JD |
| Compensation | $70–85k base plus "meaningful equity upside", with no equity terms given | `[grounded]` JD |
| Success measures | "will evolve as we learn" | `[grounded]` JD |
| Scope read | Several specialist jobs under one title, with no stated staff | `[inferred]` from the function list against "team of one" |
| Market calibration | Not established. The role-family sweep did not run, so no market band is quoted. The posting's figure is compared only with your floor (R2) | `[grounded]` JD figure against your stated floor |
| Unknowns | Equity terms, budget, headcount plan, success measures, hiring manager's name | — |
| Contradictions | None found within the posting; not checked against Novaline's own careers page | `[grounded]` posting text only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Austin, 5 days a week, "no exceptions" | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your statement: remote-only, living in Portland, not relocating. It is specific and your own. The posting rules out remote work, so the gate fails | `[grounded]` JD quote and your stated constraint | Only the employer changing terms or you changing the constraint resolves it; neither is indicated |
| R2 | Base $70–85k | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your $150k floor, which is specific and your own. The posted range tops out $65k below it | `[grounded]` JD figure and your stated floor | Same as R1 |
| R3 | 8+ years of growth leadership | must_have | direct | medium | none | You state 9 years, as growth lead then Head of Growth at two companies. It is confirmed in your message with no inspectable artifact yet. A length-of-experience requirement is not a gate | `[grounded]` your stated background | none |
| R4 | Paid acquisition | must_have | direct | medium | none | You state you owned paid. Spend and channel mix are not stated | `[grounded]` your stated background | none |
| R5 | Lifecycle and CRM | must_have | direct | medium | none | You state you owned lifecycle and are deep in Braze. The posting names no tool | `[grounded]` your stated background | none |
| R6 | Own revenue growth end to end | must_have | direct | medium | none | You state you scaled one company from $8M to $40M ARR over three years with a budget you controlled. Both employers were B2C subscription companies; Novaline's customer type is not stated beyond "e-commerce enablement" | `[grounded]` your stated background; `[inferred]` that the business models may differ | none |
| R7 | SEO and content | must_have | unclear | low | discovery | Your message covers paid, lifecycle and experimentation, and is silent on SEO and content. It is low and not none because growth leaders often touch it | `[grounded]` your message's silence; `[generic]` that growth roles commonly include it | See G1 |
| R8 | Brand, PR and partnerships | important | unclear | low | discovery | Nothing stated | `[grounded]` your message's silence | See G2 |
| R9 | Sales ops | important | unclear | low | discovery | Nothing stated, and your background is B2C subscription | `[grounded]` your message's silence | See G3 |
| R10 | Working as a team of one | important | adjacent | low | transferability | You built and managed teams of 3–7. Nothing stated about delivering every channel yourself, and leading a team is different work from executing without one | `[grounded]` your stated team sizes; limit named | See G4 |

## Gap recovery queue

All four gaps matter only if R1 and R2 move.

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO and content (R7, must_have) | discovery | No SEO or content work stated | The one `must_have` row still unclear | Owning organic traffic targets, a content calendar, or a technical SEO fix | Organic traffic reports, a content performance dashboard | `[grounded]` silence in your message |
| G2 | Brand, PR, partnerships (R8, important) | discovery | Nothing stated | Three functions in one row | A launch with PR, an affiliate or co-marketing deal | A partnership deal summary, press coverage | `[grounded]` silence in your message |
| G3 | Sales ops (R9, important) | discovery | Nothing stated | The posting folds it into the mandate | CRM and pipeline work with a sales team | A pipeline or CRM process document | `[grounded]` silence in your message |
| G4 | Team of one (R10, important) | transferability | Team-leading evidence only | Execution without a team is a different job | Periods you ran channels hands-on, before building the team | A channel report you built yourself | `[grounded]` your stated team sizes |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay may sit below the title and scope (see R2) | risk_signal | medium | "8+ years growth leadership required"; "$70–85k base" | The base may be low for a head-level, all-channel mandate. The market band was not checked, so this stays a flag | `[inferred]` from the posting's seniority and scope against its figure | How was the base set, and what is the total package including equity? | unresolved |
| RR2 | Seven functions, no team | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops. You will be a team of one" | One person may be accountable for several specialisms with no stated staff or budget | `[inferred]` from the function list against the posting's silence on budget | What budget and headcount are committed, and which functions are in scope in year one? | unresolved |
| RR3 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | The hours expectation may be open-ended, since the posting does not say how often "when it matters" applies | `[inferred]` from the quoted wording | In a typical month, how often do evenings and weekends come up, and is there time off in return? | unresolved |
| RR4 | No success measures on a broad mandate | risk_signal | medium | "success metrics will evolve as we learn" | You could be accountable for revenue with no agreed definition of success | `[inferred]` from the quoted wording | What would count as success at 90 days and at 12 months, and who decides? | unresolved |
| RR5 | Equity unquantified | unknown | — | "meaningful equity upside" | The value of the equity can't be judged without terms | `[grounded]` the posting gives no percentage, vesting or strike price | What percentage, vesting schedule and strike price, and at what valuation? | unresolved |
| RR6 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. No check ran because search was refused | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR7 | Direct line to the CEO and the board | positive_signal | — | "Report to the CEO with a dotted line to the board" | The role has visibility at the top | `[grounded]` JD | Which decisions can I make without CEO sign-off? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Don't spend application effort on the current terms | See R1, R2 | `[grounded]` map rows | pending your approval |
| P2 | If you want to test it anyway, send one written question asking whether the role can be remote and whether base can reach $150k, before any interview | See R1, R2. The posting says "no exceptions" for on-site and shows no flex on pay | `[grounded]` JD quotes | pending your approval |
| P3 | If you proceed, ask the verification questions from RR1, RR2, RR3, RR4, RR5 and RR6 verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: R1 and R2 claims, which are your own stated constraints. R3, R4, R5 and R6 stand as you stated them, with no artifact inspected, so none is verified. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Austin Series A"; the call was refused. It would have moved role reality's organization and contradictions rows and RR6 |
| 2. Role-family sweep | unavailable | Searched "Head of Growth salary range Series A startup base compensation"; the call was refused. It would have moved role reality's market calibration and RR1 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- Permission to search, or a link to the live posting on Novaline's own careers page: this settles RR6 and fills role reality's organization row. It can't change the decision while R1 and R2 stand.
- A market salary band for this title: it closes RR1 and sets R2's gap against a benchmark.
- The hiring manager's name: it feeds role reality's scope read.
- Equity terms (percentage, vesting, strike price): they close RR5.
- A growth-channel summary, such as an ARR bridge, a channel report or a Braze program report: it raises R3, R4, R5 and R6 toward `high`.

I can also write this up as a `tuesday-dossier.md` if you want to keep it.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.