I've read the job-underwriter playbook and its reference files. Next I'll check that the posting is still live on the careers page. Then I'll write the assessment.
**Yes, it's worth applying to, on the conditions below. Status: `conditional_go`.** R3, R4, R5, R6, R8 and R9 all land `direct`. Your location and pay floor aren't known yet, so R1 and R2 stay open.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity)
- `must_have` — direct: R3, R4, R5, R6, R8, R9
- `important` — adjacent: R7 (BigQuery); unclear: R10 (Ingestion from app and CRM), R11 (Data contracts analysts depend on)

R7 — a credible bridge from Snowflake, its limit named; R10 and R11 — unconfirmed, waiting on your examples.

**Opportunity ledger.** The pay is stated and sits inside the report's band (RR1). Equity terms (RR2), the scope of the remit (RR3), the reporting line (RR4) and what "run" covers (RR5) are unresolved. None of them is a red flag.

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your location and base-pay floor clear R1 and R2 (G1); (2) the remit proves to be one coherent domain, not a whole platform on one person (RR3); (3) BigQuery is framed honestly as new to you, bridged from Snowflake and never claimed as experience (R7).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, Denver, founded 2016, 264 employees, Series C ($52M, February 2026) | `[grounded]` the About page text you pasted; the funding and headcount were not independently checked |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` posting, confirmed live on the careers page |
| Working pattern | Remote (US) or the Denver office | `[grounded]` posting |
| Compensation | $148,000–$166,000 plus equity | `[grounded]` posting |
| Scope read | Three layers (ingestion, warehouse, contracts) may be wider than a single domain's pipelines, depending on team size | `[inferred]` from the posting's three responsibilities against the report's scope norm |
| Market calibration | Report figures for Senior Data Engineer at Series B–D: base median $151,000, interquartile range $139,000–$163,500, usually 5–8 years, one domain's pipelines, no direct reports. The posting's low end is $3,000 under that median and its high end is $2,500 above the upper quartile. It is a survey band, not this employer's offer | `[grounded]` the posting and the recruiter's Datawright 2026 report (n=2,310) |
| Unknowns | Hiring manager and reporting line, team size, equity terms, first-year outcomes, on-call expectations | `[grounded]` the posting is silent on each |
| Contradictions | None between the pasted posting and the live careers page | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you live or whether you'd relocate, so nothing settles it | `[grounded]` posting terms; no constraint stated | G1 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | The pay is stated, but your floor isn't, so fit can't be called. Equity is unstated (RR2) | `[grounded]` posting; no floor stated | G1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years at a B2B payroll company. Prose background is CV-equivalent, so `medium` is the ceiling. It clears the 5+ floor and sits inside the report's typical 5–8 years for "Senior". No CV seen, so how it reads on paper is untested | `[grounded]` your statement and the report | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. Stated, specific, but nothing inspectable yet | `[grounded]` your statement | none |
| R5 | dbt | must_have | direct | medium | none | You built your company's dbt project, about 180 models. Nothing inspectable yet | `[grounded]` your statement | A sanitized dbt docs or lineage screenshot would raise it to `high` |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse. BigQuery is named in the role description, not in the requirements list, and it is carried at R7 | `[grounded]` your statement and the posting's requirements line | none |
| R7 | BigQuery as the team's warehouse | important | adjacent | medium | transferability | The posting's requirements list says "a cloud warehouse", but the mandate names BigQuery, so I've treated it as a requirement. Your 180-model dbt project on Snowflake is the bridge. The limit is that you have never used BigQuery, so its cost and partitioning model are untested | `[inferred]` requirement from the mandate text; `[grounded]` your statement of no BigQuery use | G2 |
| R8 | Airflow or similar orchestration | must_have | direct | medium | none | You use Airflow for orchestration. Stated, with no inspectable artifact yet | `[grounded]` your statement | none |
| R9 | Data quality testing | must_have | direct | medium | none | You set up your company's Great Expectations suite. Stated, with no inspectable artifact yet | `[grounded]` your statement | A sanitized suite config or data-docs page would raise it to `high` |
| R10 | Ingestion from the app and a CRM | important | unclear | low | discovery | Your payroll sources aren't described, so whether you've ingested product events and CRM data is open | `[grounded]` your background is silent on sources | G3 |
| R11 | Data contracts analysts depend on | important | unclear | low | discovery | Your background doesn't mention written contracts or agreed schemas with downstream users. It's a lead to ask about, not a claim | `[grounded]` your background is silent | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and pay (R1, R2, hard_gate) | hard_gate | The posting allows remote in the US or Denver and states a range; your location and floor are unknown | A failed gate means `no_go`, however strong the fit | Your state, a willingness to be in Denver, a base-pay floor | None needed | `[grounded]` posting terms; no stated constraint |
| G2 | BigQuery (R7, important) | transferability | Carry-over: dbt modelling and warehouse design on Snowflake. Limit: no BigQuery use, so cost, partitioning and its dbt adapter are unexercised. Strengthener: a small dbt-on-BigQuery project you build and can show | The mandate names it, so interviewers will ask | A small side project, a cloud-provider course project, a migration you scoped | A repo link or project write-up | `[inferred]` bridge from the Snowflake and dbt work you described; `[generic]` that a named warehouse draws questions in a data-engineering loop |
| G3 | Ingestion sources and data contracts (R10, R11, important) | discovery | Your sources and any agreements with analysts aren't described | Both are in the mandate and could separate you from other applicants | Ingesting product events, a CRM or third-party files; a written schema or ownership agreement; test failures that alerted data consumers | A sanitized DAG, a schema doc, a Great Expectations suite listing | `[grounded]` background silent on both |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay stated and in band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The figure sits at or above the report's median for the title, so pay is unlikely to be the problem | `[grounded]` posting and recruiter's report | Where in the range would someone with my background land? | noted |
| RR2 | Equity terms unstated | unknown | — | "plus equity" | Grant size, vesting and exercise terms are missing, so the total package can't be compared | `[grounded]` posting is silent | What is the equity grant at this level, and what are the vesting and exercise terms? | unresolved |
| RR3 | Scope may exceed one domain | risk_signal | low | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts our analysts depend on" | Three layers could be one engineer's whole platform, wider than the report's one-domain norm. A team may own them instead | `[inferred]` from the posting's three responsibilities against the report's `[grounded]` scope norm | Who else works on the data platform, and which of these three layers does this role own alone? | unresolved |
| RR4 | No hiring manager or reporting line named | unknown | — | The posting names no hiring manager | The reporting line and team size are unknown | `[grounded]` posting is silent | Who does this role report to, and how big is the team? | unresolved |
| RR5 | What "run" covers | unknown | — | "Build and run the pipelines" | Running pipelines may include on-call or incident response, which the posting doesn't state | `[inferred]` from the posting's verb | Is there an on-call rotation for these pipelines, and how often are you paged? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Answer G1 before investing effort, since a failed gate ends the case | see R1, R2 | `[grounded]` gate rows | pending your approval |
| A2 | Lead with the dbt project you built (about 180 models, on Snowflake), the Airflow orchestration, and the Great Expectations suite you set up. Say "Snowflake" plainly | see R5, R8, R9 | `[grounded]` your statements | pending your approval |
| A3 | State BigQuery as new to you and name Snowflake as the bridge. Don't list it as a skill | see R7 | `[grounded]` your statement of no BigQuery use | pending your approval |
| A4 | Optionally build a small dbt project on BigQuery. You could then say what you did and nothing more | see G2 | `[inferred]` strengthener | pending your approval |
| A5 | Ask RR2–RR5's questions verbatim in the screens, and ask the recruiter for the hiring manager's name | The register doubles as interview preparation | `[grounded]` register | pending your approval |

If you go ahead, the resume-tailor module can turn A2 and A3 into an approve-first edit ledger.

## Evidence status

Verified: none yet. The Series C and headcount come from the About page you pasted, and no search checked them.

Research tier: L1 — searches 0 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer). The posting is live ("Accepting applications") and matches your pasted text. It moved role reality's contradictions row. The About page was not fetched |
| 2. Role-family sweep | skipped | The Datawright report you pasted already fixes market calibration, the scope norm and the seniority band, so a search could change none of them |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there was no query to form |

I can save this as a `tuesday-dossier.md` that the other modules can read, if you want it.

**Upgrade menu**

- Your location and base-pay floor → R1 and R2 resolve, and the decision moves to `go` or `no_go`.
- Your CV → whether it reads as these rows do, which I couldn't test, and any presentation gaps.
- Sources and contract examples (G3) → R10 and R11 move off `unclear`.
- A sanitized dbt lineage or docs page, a Great Expectations suite config, or a DAG definition → R5 and R9 can reach `high`.
- A small BigQuery project → R7's limit narrows.
- The hiring manager's name → the scope read and which story to lead with.
- A deeper research pass on Pellucid (funding and leadership changes, hiring patterns, employee reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

G1 — Does the role's location and pay work for you: are you in the US (or open to Denver), and does a $148,000 base clear your floor?

G3 — At the payroll company, which sources did you ingest from (app events, a CRM, third-party files), and did you agree any written schema or ownership terms with the analysts using your models?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.