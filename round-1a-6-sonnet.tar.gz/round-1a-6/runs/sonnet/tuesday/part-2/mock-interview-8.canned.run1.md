I've saved the pack. Now I'm checking the file for stray square brackets and pipe characters inside cells, which the format rules forbid, before I present it.
Your prep pack is saved as `ashgrove-credit-union_member-experience-lead_interview_pack.md`. I built it in loop mode, with a mini-pack for each of the three rounds on 5 December. I used only your message and the pasted material. I ran no web searches, because your values page, the recruiter's email and the strategy points already covered everything a search would have. I have only the four strategy points you quoted, not the full brief.

- **Highest-ROI prep:** D2, the contact-centre question. The JD has you owning the process across the contact centre, and you've said you've never worked in one. Expect it in all three rounds, so say the same words each time.
- **Other gaps:** Presenting to senior leaders (D3) is the second one you've stated outright.
- **Thin evidence:** Your complaints-log and escalation-script sentences are real, but they're adjacent. They cover one branch and new tellers, where the JD says end to end and supervisors. The pack keeps your words at their actual scope and gives you answer slots where an interviewer will probe further.
- **Date check:** 5 December 2026 is a Saturday. Confirm the date and times with the recruiter, and ask whether the round 3 case is live or comes with materials beforehand.

Say the word and I'll play the Skeptic on D2 for a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste your CV (or just a dated list of your roles)? It would let me quote a document instead of your message and could move several rows up a band.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Three rounds on 5 December 2026, built in loop mode.

| Round | Who | Length | What the recruiter's email says |
|---|---|---|---|
| 1 | The recruiter | 30 minutes | A conversation |
| 2 | Head of Member Services, who would be your manager | 45 minutes | Mostly behavioural |
| 3 | Panel of two branch managers | 60 minutes | Includes a 20-minute case on a complaint escalation; also the values round, scored against the four values |

Interviewer names are not assigned yet, so no interviewer read is included. Built from your message alone: no CV was supplied, so every statement about your past is one of your own sentences, quoted.

The highest-ROI prep in this pack is D2, the contact-centre question. It will arrive in some form in all three rounds, so say the same words each time.

## How to use this pack

- Personas describe how a question is asked. Types describe what is being scored.
- Type key: VAL is behavioural and values alignment, EXP is a deep-dive on your work, JD is the role's stated requirements, CO is company and strategy knowledge, CASE is a live problem.
- Guidance is scaffolding, not a script. Wherever it speaks about your past it rests on a sentence you wrote, quoted in the Provenance column. An answer slot is an instruction for the interview: say what is true in your own words, and if the practice never existed or was not yours, say that plainly.
- Provenance labels: `[grounded]` traces to a document you gave me, `[inferred]` is derived and the derivation is named, `[generic]` is a pattern with no claim about Ashgrove or you.
- All suggested wording in this pack is pending your approval. Change anything that is not how it happened.

## Fit snapshot (shared by all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it, so expect a probe on it. Lead with it in its own terms: six years in retail banking, the last three as a branch supervisor |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | Your material says a formal complaints log and nothing in it shows what rules the complaints fell under, so the words stay at the log: "I handled the branch's formal complaints log." Answer slot: the JD's complaints line makes a probe on the rules behind the log likely. If you know which rules governed those complaints, say so in your own words; if you do not know, or the log was not tied to any, say so plainly and stay with the log |
| F3 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Adjacent work on one branch's log, which does not reach end to end or across branches. The words stay at the quote: "I handled the branch's formal complaints log." Answer slot: expect a probe on what happened to a complaint after it left your branch's log. If you followed any further, say how far and what part was yours; if the log ended at your branch, or following on was not yours, say so plainly and stay with the log |
| F4 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then what you would do to learn it, said as a plan and never as a past. Nothing is added to make the gap feel smaller |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The quote says a monthly complaints spreadsheet your regional manager uses; it does not say what the spreadsheet counted, so the words stay there: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: expect a probe on what it showed. If it showed volumes, resolution times or other measures, say which, in your own words; if it showed something else, say what; if you did not produce the monthly report from it yourself, say so plainly and stay with the spreadsheet you built |
| F6 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Adjacent: tellers and a script, where the JD says supervisors and escalations. Words: "I trained new tellers on our escalation script." Answer slot: expect a probe on coaching people at your own level or above. If you have coached supervisors, or anyone beyond new tellers, on escalations, say who and how, in your own words; if not, say so plainly and stay with the tellers |
| F7 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | Words: "I've never presented to anyone above regional level." Your material does not say whom you have presented to below that, so nothing is claimed about it. Then how you would prepare, said as a plan and never as a past |
| F8 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | low | [inferred] | discovery | The quote says spreadsheet. It does not say Excel or what the spreadsheet did, and Excel is this pack's reading of it. Answer slot: say which tool it was built in and what it did, in your own words; if it was not Excel, say so plainly |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Nothing in your material speaks to this, and nothing is claimed. Answer slot: expect a probe on any work with digital or product teams. If you have worked with one on something members used, say what it was and what your part was, in your own words; if not, say so plainly and say what you would want to find out first |

No JD requirement above is a gate: the length-of-experience line (F1) is graded like any other requirement, and the JD names no pay, location or credential. Suggested wording above is pending your approval.

## Requirement coverage

| Row | Requirement | Questions that cover it |
|---|---|---|
| F1 | 4+ years in financial-services customer operations | B1, A1 |
| F2 | Regulated complaints | B2, C1 |
| F3 | Own the process end to end | D1, H1, H2 |
| F4 | Across branches and the contact centre | B3, D2, H2 |
| F5 | Monthly reporting on volumes and resolution times | A3 |
| F6 | Coach branch supervisors on escalations | C4, G2, J1 |
| F7 | Present to senior leaders | B4, D3, C2 |
| F8 | Excel reporting | A3 |
| F9 | Digital teams, self-service journeys | C5, E2 |

## Grounding brief: Ashgrove's July 2026 strategy

Your message relays four points from the strategy brief the recruiter sent. I have not seen the brief itself, so only these four points are used.

| Point (quoted from your message) | Where it bites in this loop | Provenance |
|---|---|---|
| "move 40% of member service to digital channels by 2028" | The JD's self-service line (F9); E2 and the reverse questions | [grounded] |
| "consolidate eight branches into five hubs over 2027" | The branch managers in round 3 are the people this lands on; H3 and the Neighbours, Not Numbers answers | [grounded] |
| "launch a small-business lending product in Q1 2027" | A new kind of member is likely to bring a new kind of complaint; a reverse question in round 2 asks rather than assumes | [inferred] |
| "the main competitive pressure is app-only banks" | The reason speed and plain explanations matter; K2 | [grounded] |

The brief is public to every interviewer and rival candidate. For CO and CASE questions, bring one point from it to show you read it, then your own view, and, where the role means saying no, what you would keep out of self-service.

---

# Round 1: Recruiter screen (30 minutes)

## Persona table

| Persona | How it shows up | Weight, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly, unstructured, with pay, notice, location and the reason for leaving asked in passing | High. The recruiter-screen prior is Conversational plus a light Skeptic; no signal in the email moves it | A short biography arc built only from sentences you wrote; treat every casual question as scored |
| Skeptic | Knockout checks against the JD in a friendly register | Low. Same prior. F4 and F7 are requirements where you have stated a gap, so expect them early | Say the plain acknowledgment once, then your plan, and stop |

Pressure, Prober, Case and Peer are not weighted in a 30-minute screen.

## Question bank

### A: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" "I handled the branch's formal complaints log" "trained new tellers on our escalation script" "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F1, F2, F6 and F5. The beats are the clauses the quotes state: six years in retail banking, the last three as a branch supervisor; you handled the branch's formal complaints log; you trained new tellers on the escalation script; you built the monthly complaints spreadsheet your regional manager uses. Tell them in your own words in about 90 seconds and stop; the recruiter picks what to ask about. Leave the reason for moving to A7 | Every screen opens here, and F1 is the requirement it checks first |
| A2 | "Why Ashgrove, and why this role?" | CO | [grounded] | Selection scaffold, since none of your sentences carries your reasons. Pick one published value by its name (Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix) or one strategy point, and say in your own words why it matters to you. If none stands out, say so plainly and give the reason you applied | Motivation is scored in a recruiter screen even when asked casually; the pack cannot supply the reasons |
| A3 | "Tell me about the monthly complaints spreadsheet you built." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F5 and F8. The beats the quote states: you built it, it is monthly, it is about complaints, your regional manager uses it. Answer slot: the JD's reporting line makes a probe on what it showed likely. If it showed volumes, resolution times or other measures, say which; if it showed something else, say what; if you did not produce the monthly report from it yourself, say so plainly and stay with the spreadsheet you built. Answer slot: say which tool it was built in and what it did; if it was not Excel, say so plainly | The JD's reporting and Excel lines both rest on this one sentence, so it is the likeliest place to be probed; JD because it scores those two requirements |
| A4 | "What salary are you looking for?" | JD | [generic] | Pay slot: give your own number, or ask for the role's band first. The JD names no pay, so asking for the band is a fair first move. If asked what you earn now: "I'd rather focus on the range for this role." | A recruiter screen checks pay; the only safe answer is your own |
| A5 | "What notice period do you have?" | JD | [generic] | Notice slot: give your actual notice period. If you do not know the contract's term, say you will confirm it | Logistics the recruiter has to establish |
| A6 | "Would the location and working pattern work for you?" | JD | [generic] | Location slot: say where you are and what working pattern you can do. The JD names no base, so ask where the role is based and whether it moves between branches and the contact centre before you commit to an answer | A requirement the posting leaves open, so a question back is natural |
| A7 | "What's prompting you to look at a move now?" | EXP | [generic] | Reason slot: give your actual reason, in your own words, in one or two sentences, in a form you would say in front of your current manager | Motivation consistency across the loop is checked from this answer |

### B: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role asks for four or more years in financial-services customer operations. How do you meet that?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Say it in the quote's own terms: "I have six years in retail banking, the last three as a branch supervisor." Let the recruiter decide how it maps to the JD's wording | F1; a quick knockout that is easy to close with your own sentence |
| B2 | "The role covers regulated complaints. What experience do you have there?" | JD | [grounded] "I handled the branch's formal complaints log" | Say "I handled the branch's formal complaints log." Answer slot: expect a probe on the rules behind the log. If you know which rules governed those complaints, say so in your own words; if you do not know, or the log was not tied to any, say so plainly and stay with the log | F2 is the headline requirement and the most checkable at a screen |
| B3 | "This role spans the contact centre, and you haven't worked in one. How do you see that?" | JD | [grounded] "Never worked in a contact centre" | Words: "I haven't worked in a contact centre." Then one sentence on what you would do to learn it, as a plan in your own words. Build the full version in D2 first; here, keep it short | F4 is a stated gap, and recruiters often carry it forward to the next interviewer |
| B4 | "Are you comfortable presenting to senior leaders?" | JD | [grounded] "I've never presented to anyone above regional level" | Words: "I've never presented to anyone above regional level." Answer slot: if you have presented at regional level, say to whom and about what; if not, say so plainly. Then how you would prepare, as a plan | F7 is a stated gap; the recruiter will pass on how you handled it |

Suggested wording above is pending your approval.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1a | "Will the case in the panel round be given to me beforehand, or is it live?" | The recruiter's email says a 20-minute case; the answer decides how you prepare G and H |
| R1b | "Can you tell me who is on the panel and which branches they manage?" | Names unlock an interviewer read for round 3, and it reads as preparation |
| R1c | "What does the band for this role look like?" | It moves pay from guesswork to the recruiter's own number, and it matches A4's second option |

---

# Round 2: Head of Member Services (45 minutes, your future manager)

## Persona table

| Persona | How it shows up | Weight, with reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | "Tell me about a time" questions, STAR-shaped | High. The hiring-manager prior is Case plus Skeptic, but the recruiter says this round is mostly behavioural, which lifts this persona | "We" for context, "I" for contribution; use a story only where your quoted sentences carry it, and a selection scaffold with its honest branch where none does |
| Skeptic | Quiet probing of the gaps in F3, F4 and F7 | Mid. A manager is pricing what the hire still has to learn, and you have stated two gaps outright | Rehearse the single most predictable objection until it is boring; the plain acknowledgment, then the plan |
| Case/Strategist | One or two live problems on the role's real work | Low. Prior is high for a hiring manager, lowered by "mostly behavioural" | Clarify, objective, segmentation, approach, metrics, risks; think aloud |

## Question bank

### C: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how you handled the branch's formal complaints log." | EXP | [grounded] "I handled the branch's formal complaints log" | Story-mapped on F2 and F3. The beat the quote states is that you handled the branch's formal complaints log; tell it in your own words. Answer slot: the JD's end-to-end line makes a probe on the stages a complaint went through likely. If you set or ran any of those stages, say which and how you decided; if there were no such stages, or they were not yours, say so plainly and describe what handling the log involved | A manager will test the one complaints sentence you have; EXP because it tests what was actually yours |
| C2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold, since none of your sentences carries this. Pick a time with a named stake, a moment you did not soften it, and a relationship that was intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The persona stem for this round; it also probes F7's senior-audience gap from the side |
| C3 | "When did you put a member ahead of an internal metric?" | VAL | [generic] | Selection scaffold. Pick a time you made the member's case against a target or a procedure, with the cost to you named and what the member got. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioural stem that sits close to Ashgrove's first value; the full values mapping is in round 3 |
| C4 | "The role coaches branch supervisors on escalations. Tell me about a time you helped someone handle an escalation well." | JD | [grounded] "trained new tellers on our escalation script" | Story-mapped on F6. The beat the quote states is that you trained new tellers on your escalation script; tell it in your own words. Answer slot: the JD says supervisors, so expect a probe on coaching beyond new tellers. If you have coached a supervisor or anyone senior to a teller, say who and how; if not, say so plainly and stay with the tellers | The JD's coaching line against F6, which is adjacent only |
| C5 | "Tell me about a time you worked with a team outside your branch on something members would use." | JD | [generic] | Selection scaffold, since none of your sentences carries this. Pick a time with a named team, a named thing members used, and what your part was. If none comes to mind, say so plainly, then say what you would want to find out first about working with a digital team | F9 has no evidence at all; the scaffold prepares the honest answer rather than a thin one |

### D: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Your complaints experience is from a branch's log. What makes you think you can own the process across branches?" | JD | [grounded] "I handled the branch's formal complaints log" | Hold at the quote: "I handled the branch's formal complaints log." Answer slot: expect a probe on what happened once a complaint left your branch. If you followed any further, say how far and what part was yours; if the log ended at your branch, or following on was not yours, say so plainly. Then, as a plan, what you would want to learn first about how other branches differ | F3 is adjacent only, and "end to end" is the JD's widest phrase |
| D2 | "This role owns the process across the contact centre, and you've never worked in one. How do you handle that?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log" "trained new tellers on our escalation script" | **The highest-ROI prep in this pack.** Concession, exact: "I haven't worked in a contact centre." Then what your material carries, at its own scope: you handled the branch's formal complaints log, and you trained new tellers on the escalation script. The limit, named by the pack and not words for you: your material says branch, not contact centre. Follow-up 1, "What would you do in your first weeks?": a plan in your own words; options to choose from only if you would really do them are listening to calls, sitting with the team, and reading complaints that crossed channels. Follow-up 2, "What do you think is different there?": say what you expect and label it an expectation; if you do not know, say so plainly. Follow-up 3, "Have you dealt with the contact centre from the branch side?": if a complaint of yours ever involved it, say what happened and what was yours; if none did, say so plainly and return to the log. Concede exactly what you said and nothing more, and do not retreat from the branch work | F4 is a stated gap against the JD's headline responsibility, and it recurs in B3 and H2; JD because it scores a stated responsibility |
| D3 | "How confident are you presenting to senior leaders, and what has your experience of it been?" | JD | [grounded] "I've never presented to anyone above regional level" | Words: "I've never presented to anyone above regional level." Answer slot: if you have presented at regional level, say to whom and what the room did; if not, say so plainly. Then how you would prepare for a first senior audience, as a plan. Nothing in your material says the spreadsheet your regional manager uses was ever presented, so do not describe it as presented | F7 is a stated gap and the JD names the audience; the monthly report is where it would show |

### E: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A member raises a complaint in a branch, then rings the contact centre about the same issue. Walk us through how you'd want that handled." | CASE | [grounded] | Think aloud: clarify first (what the member was told, what is on record, who holds it now), then the objective in Ashgrove's own words: a member who has to explain it twice is a sign it was written wrong (Plain Words), and someone keeps hold until it is solved (Own the Fix). Then approach, the measures the JD names (volumes and resolution times), and risks. The question needs no claim about your past, so the guidance makes none | A live problem on the JD's cross-channel line; [grounded] on the pasted values and the JD |
| E2 | "We want 40% of member service on digital channels by 2028. What belongs in a self-service complaints journey, and what should never be?" | CASE | [grounded] | Bring the brief's 40% to show you read it, then your own view. Clarify first: which complaints, which members. A divergence worth holding only if you agree with it: self-service for status and information, a person for resolution. Name what you would keep out of self-service and why. The question needs no claim about your past, so the guidance makes none | CO and CASE grounded in the July 2026 brief; the anti-pick matters because the role's job includes saying no |

Suggested wording above is pending your approval.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R2a | "Which complaints measures does Member Services look at monthly today, and what would you want changed?" | Shows you think in the JD's own reporting terms (F5) and tells you what the manager would hold you to |
| R2b | "How do complaints move between the contact centre and the branches today?" | Asks about the one area where your material is thin (F4) without claiming anything about it |
| R2c | "How will the hub plan and the small-business lending launch change who handles complaints during 2027?" | Ties two brief points to the role; it reads as diligence and tells you whether the job grows |
| R2d | "What would make you say in a year that I had been the right hire?" | Gets the manager to name the scoring sheet for the role |

---

# Round 3: Panel of two branch managers (60 minutes)

This round is the values round and holds the 20-minute case. The recruiter's email says the panel scores against the four values.

## Persona table

| Persona | How it shows up | Weight, with reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | A question per value, STAR-shaped stories | High. The recruiter says the panel scores against the four values; the loop source documents a values round | A story per value from your quoted sentences where one carries it, a selection scaffold where none does |
| Case/Strategist | The 20-minute complaint-escalation case | Mid. A named, timed block of the round | Clarify, objective, segmentation, approach, metrics, risks; say the structure aloud first |
| Peer Evaluator | Seam-splitting: where the lead's job ends and the branch manager's begins | Low. The JD has you coaching branch supervisors, so branch managers are the people whose staff you would work with; the panel's own relationship to the role is not stated | Offer principles for the seam, not a claim to know it; reciprocity |
| Conversational | Opening questions about your branch | Low. A panel opens warmly, but the email gives no weight to it | Short, plain answers; scored all the same |

## Question bank

### G: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] | Selection scaffold on Members First, Always. Pick a decision where the member's position and the branch's convenience pointed different ways, name the cost and what the member got. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Value 1, scored by name |
| G2 | "Tell me about a time something you explained or wrote needed explaining twice." | VAL | [grounded] "trained new tellers on our escalation script" | Story-mapped on F6 and Plain Words. The beat the quote states is that you trained new tellers on the escalation script. Answer slot: the value says a second explanation means the writer got it wrong, so expect a probe on whether the wording ever changed. If you changed it, or told anyone to, say what and why; if the script was not yours to change, or no such change happened, say so plainly and stay with the training | Value 2; the only one of your sentences that touches how something is explained |
| G3 | "Tell me about a time you took a branch's town into account in a decision." | VAL | [grounded] | Selection scaffold on Neighbours, Not Numbers. Pick a decision where the branch's town changed what you did, name the town and the figure it was weighed against. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Value 3; the hub plan makes it the most live value for this panel |
| G4 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Story-mapped on F2 and Own the Fix. The beat the quote states is that you handled the branch's formal complaints log. Answer slot: the value says whoever finds the problem keeps hold of it until it is solved, so expect a probe on a complaint you saw to its end. If you followed one through, say what happened and what part was yours; if the log did not give you that, or it was not yours, say so plainly and stay with the log | Value 4; JD's "end to end" line sits behind it |

### H: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "A branch supervisor escalates a member's complaint to you. Talk us through what you do." | CASE | [grounded] "I handled the branch's formal complaints log" | The largest block of time in round 3. Say your structure aloud first. Clarify: what the member is asking for, what they have been told and by whom, what is on record, who holds it now, and whether any time limit applies to this kind of complaint. Objective in Ashgrove's words: decide from the member's side, someone keeps hold until it is solved, and the reply reads clearly once. Approach, then the measures the JD names (volumes and resolution times), then risks. Challenge one premise respectfully, for example whether it needed escalating at all. If a panellist asks whether you have seen this before, answer from the quote only: "I handled the branch's formal complaints log" | The panel's stated case; it tests F2 and F3 live |
| H2 | "Now suppose the member has also rung the contact centre and was told something different. What changes?" | CASE | [generic] | A likely twist on H1, given the JD's contact-centre line. Say who now holds the complaint, how you would reconcile what was said, and how the member hears one answer. If it exposes a gap in the process, say so and name what you would ask for. The question needs no claim about your past, so the guidance makes none | F3 and F4 together; [generic] because it is a pattern for the problem, not a fact about Ashgrove |
| H3 | "A member's branch is due to close under the hub plan while their complaint is still open. What do you do?" | CO | [grounded] | Bring the brief's hub plan, then your view: who keeps hold while the branch changes, how the member hears it once, and what the town loses. The panel are branch managers and the plan may touch their own branches, so ask before you assume and do not argue the plan. The question needs no claim about your past, so the guidance makes none | A strategy-grounded case aimed at Neighbours, Not Numbers and Own the Fix |

### J: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "You'd coach our supervisors on escalations. Where's the line between your job and ours, and what happens when we disagree?" | JD | [grounded] "trained new tellers on our escalation script" | Propose principles, not a claim to know the seam: agree up front who decides when you and a branch disagree about an escalation, and ask for it in writing. Reciprocity: say what you would bring to the branch managers, not only what you would need. The one quote you can stand on is that you trained new tellers on the escalation script. Answer slot: if you have coached a supervisor, say how the line was drawn; if not, say so plainly | F6 is adjacent only, and this is where it shows |
| J2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Selection scaffold. Pick a time work spanned teams, use "we" for the context and "I" for what was yours. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The persona stem; credit is a behavioural proxy for honest attribution |

### K: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "Tell us about the branch where you've been supervisor." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Beat the quote states: you have been a branch supervisor for the last three years. Say what the branch is and who it serves, in your own words; this opener is scored against Neighbours, Not Numbers | An opening question that is scored like any other |
| K2 | "App-only banks are Ashgrove's main competitive pressure. What do you make of that?" | CO | [grounded] | Bring the brief's point, then your own view in one or two sentences. A divergence worth holding only if you agree with it: what a branch gives a member that an app does not. The question needs no claim about your past, so the guidance makes none | A differentiator question from the July 2026 brief |

Suggested wording above is pending your approval.

## Values / principles cheat sheet

Values are quoted by their published names, as pasted from ashgrovecu.org/about/values on 26 November 2026.

| Value (official name) | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Members First, Always | Decisions start from the member's position at the counter | No sentence of yours carries a story. Selection scaffold: pick a decision where the member's position and the branch's convenience differed, naming the cost; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Plain Words | If a member needs it explained twice, the explanation was the problem | F6: "trained new tellers on our escalation script". Answer slot: if the wording ever changed because something needed explaining twice, say what changed; if it was not yours to change, say so plainly |
| Neighbours, Not Numbers | Each branch belongs to its town, and decisions weigh that | No sentence of yours carries a story. Selection scaffold: pick a decision where the town changed what you did; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F2: "I handled the branch's formal complaints log". Answer slot: if you followed a complaint to its end, say what happened and what was yours; if the log did not give you that, say so plainly |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R3a | "Where has a complaint been fixed well here, and who kept hold of it?" | It uses their fourth value and gets the panel to tell the story they score for |
| R3b | "As branches move to hubs, what do you most want kept in each town?" | Neighbours, Not Numbers, asked as a question rather than a view on a plan that touches them |
| R3c | "How do you want to hear about escalations on your supervisors' cases?" | Opens the seam J1 asks about, from their side |
| R3d | "What could a new lead do in the first month that would genuinely help your supervisors?" | Reciprocity question for a panel who are peers to the role's stakeholders |

---

# Shared sections

## Prohibited claims

Built before the banks. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the member complaints process end to end | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says the branch's formal complaints log, not the process across branches |
| Handled regulated complaints | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: the material says a formal complaints log, not what rules the complaints fell under. B2 and C1 slots stay inside the log |
| Coached branch supervisors on escalations | Inflated form of F6 | F6's quote at its own scope: new tellers and an escalation script. C4 and J1 slots stay with the tellers |
| Wrote the escalation script | Inflated form of F6 | The quote says you trained new tellers on it, not that you wrote it |
| Reported monthly on complaint volumes and resolution times | Inflated form of F5 | F5's quote at its own scope: you built the monthly complaints spreadsheet your regional manager uses. A3's slot asks what it showed |
| Built Excel reporting | Inflated form of F8 | The quote says spreadsheet. A3's slot asks which tool |
| Presented the complaints spreadsheet to the regional manager | Inflated form of F5 and F7 | The quote says the regional manager uses it, not that you presented it |
| Worked in a contact centre | Negative you stated, F4 | The plain acknowledgment F4 gives: "I haven't worked in a contact centre." No slot |
| Presented to senior leaders | Negative you stated, F7 | The plain acknowledgment F7 gives: "I've never presented to anyone above regional level." No slot |

## Sources

Provided documents: the job description; Ashgrove's values, pasted from ashgrovecu.org/about/values on 26 November 2026; the recruiter's email about the process; the four points of the July 2026 strategy brief as you relayed them; your message about your background. No dossier was present, so the pack was built from raw inputs.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove values` | skipped | Could not have moved the values cheat sheet or the VAL bank: the pasted values page fixes both |
| 2. `Ashgrove interview process, member services` | skipped | Could not have moved the persona weights: the recruiter's email names three rounds, who runs each and the case format |
| 3. `Ashgrove strategy` | skipped | Could not have moved the CO and CASE questions: the relayed brief points fix them; the full brief would add detail, which the upgrade menu offers |
| 4. `interviewer name, Ashgrove` | n/a | No names are assigned yet, so there is no query to form; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV, or a dated list of your roles → rows F1, F2, F5, F6 and F8 can quote a document instead of your message and some move up a band
- The spreadsheet's column headings, with no member data → F5 and F8 move from discovery toward grounded rows, and A3's slots become a story
- Your answers to the answer slots on F2, F3, F5, F6, F8 and F9 → each answer becomes quoted evidence and regenerates those rows and the questions that draw on them
- The recruiter's confirmation of the date and times → 5 December 2026 falls on a Saturday, so check the date and whether all three rounds are the same day; ask whether the case in round 3 is live or comes with materials beforehand
- The full strategy brief, or its key pages → the grounding brief and E2, H3 and K2 can use more than four points
- The panellists' names and roles once assigned → an interviewer read, persona weights tuned to each, and a reverse question tied to their own path
- A deeper research pass, up to 6 more searches and 2 more fetches and several more minutes → recent organisation context and reports on similar loops; say so and I will run it, once
- How many hours you have before 5 December → a prep triage ordered to your time
- A `tuesday-dossier.md` from an earlier underwriting run → graded evidence and constraints on what is coachable, so rows would arrive pre-graded; the pack does not need it
