Web search was denied, so I'm building the pack from your message alone. I'm writing it now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a6/runs/sonnet/tuesday/part-2/rooms/case-3-denied-463f7a86/stripe_product-operations-manager_interview_pack.md`. It has 21 questions across seven interview styles, six reverse questions and a fit worksheet.

I built it from your message alone, assuming a final round with unknown interviewers and no CV or JD. Web search was denied, so nothing in it comes from Stripe's own materials. That means no Stripe values, loop details or strategy. The pack lists the four refused searches, and the upgrade menu says what each one would have added.

The question I'd rehearse first is B1: "Which part of a product operations role would you be weakest at on day one?" It will come up in some form. With your CV, I could aim it at your real gap.

Say the word and I'll play the Skeptic on B1 as a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, and convert the pack to a Word document.

Two questions that would restructure the pack:
1. Who are you meeting in the final round, and in what format? For example, a manager, peers, or several back-to-back sessions. If the recruiter gave you focus areas or a take-home, include those. It reweights every question bank.
2. Can you paste the job description and a few lines on your background, or your CV? Without them the answer guidance stays generic, and I'll keep going on what I have if you'd rather skip this.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe

**Round:** final round, structure and interviewers not yet known. **Interviewer:** none named. **Built from:** your message only: company, role, round. No JD, no CV, no research.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values, not generic virtue |
| EXP | Whether your experience survives scrutiny, and what was actually you |
| JD | The role's stated responsibilities and qualifications, gaps included |
| CO | Company and strategy knowledge |
| CASE | Structure and reasoning on a live problem |

## Fit snapshot

This is the worksheet variant: no CV and no JD were given, so every evidence cell reads `none given`. Requirements are role-family prose, not quotes from a posting. No requirement here is a gate, because no posting says one is.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Run launches or rollouts of product changes across several teams (role-family) | none given | none | [generic] | discovery | Strong evidence is one named launch or rollout, who was involved, and what you personally coordinated. Pick one occasion where you ran a cross-team rollout; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Use data and metrics to find and fix operational problems (role-family) | none given | none | [generic] | discovery | Strong evidence is one metric you used to make a decision and how it was counted. Pick one decision that rested on a number; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Build or improve internal processes, tools and documentation (role-family) | none given | none | [generic] | discovery | Strong evidence is one process or artifact you changed and what happened afterwards. Pick one change you made; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Work with product, engineering and go-to-market teams without direct authority (role-family) | none given | none | [generic] | discovery | Strong evidence is one disagreement across teams and how it was resolved. Pick one such occasion; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Communicate clearly in writing and to senior audiences (role-family) | none given | none | [generic] | discovery | Strong evidence is a document or update you wrote that someone senior acted on. Pick one; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Prioritize and make progress under ambiguity (role-family) | none given | none | [generic] | discovery | Strong evidence is one situation with unclear ownership or goals and the first steps you took. Pick one; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

## Persona table

No loop source establishes Stripe's final round, so this pack uses the Generic archetype: weights are close to flat, and no values-style round is assumed. Priors come from a final round with unknown relationship, blending the hiring-manager and cross-functional rows. If your final is several sessions, send the schedule and the pack becomes per-session mini-packs.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | Live product-ops problems: launches, metric drops, process design | Highest: a final round with a manager present tends to test live reasoning, and this is the prior for that row | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud. Challenge one premise respectfully |
| B. Skeptic | Quiet probing of day-one weaknesses, motivation and why-now | High: same prior; with no CV the pack cannot aim it at your real gap, so it aims at the role's | Rehearse the single most predictable objection (B1) until it is boring. Name a real limit and a concrete ramp plan |
| C. Peer Evaluator | Seam-splitting between product ops and adjacent teams, credit, collaboration | Medium: the role sits between teams, so peers are plausible in a final | Reciprocity framing; propose seam principles rather than pretending to know the seam |
| D. Data-Driven Prober | Pushes on how metrics are counted and what they hide | Medium: product ops work is metric-adjacent | Name the weakest assumption before they do; say plainly when you do not know how something was counted |
| E. Values / Behavioral | Scenario probes against published values | Low-medium: no source here documents a values round, so it is not assumed | Map a story to each published value once research is available; until then, use selection scaffolds |
| F. Conversational | Friendly openers, biography, what you are playing with lately | Low-medium: a casual register is common in later rounds, and still scored | A 90-second arc; never answer "I think you've covered everything" at the reverse-question slot |
| G. Pressure | Devil's advocate, time-boxed answers | Low: no signal for it here | Pause, restate, hold through two follow-ups, then concede one specific thing |

## Question banks

Every row carries `[generic]` because the pack has no sentence of yours to rest on. None of the guidance below says what you did. Where a question asks you to choose an occasion, the guidance ends with the honest branch: if none exists, say so.

**The highest-ROI prep in this pack is B1.** It will be asked in some form. It is aimed at the role's likeliest weak spot, not yours, because the pack has no CV. A CV would let it point at your real one.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A new feature launches and the weekly adoption number looks healthy, but support tickets about it have doubled. What do you want to know first, and what do you do in the first week?" | CASE | [generic] | Clarify first: how adoption is counted, which cohort, which ticket types, timing against rollout. State the objective, split by segment, name the first checks, say which metric would change your mind, and name one risk. Challenge one premise aloud: that the two numbers are related at all | A live problem set inside the role, asked as reasoning; F2 and F1 are the rows it scores |
| A2 | "Three product teams each change the same customer-facing workflow in the same month with no shared calendar. What process would you put in place?" | CASE | [generic] | Ask what failure looks like and who is affected. Propose the lightest mechanism that would work, say what it costs the teams, say how you would know it helps, and say what you would drop if teams ignore it. Name the tradeoff between process and speed | Tests process design without presupposing any history; F1 and F3 |
| A3 | "Weekly usage of an internal tool fell 20%. Diagnose it." | CASE | [generic] | Check measurement before cause: instrumentation changes, definitions, a data gap. Then segment, then line up timing against releases or seasonality. Say what you would rule out first and why | The standard metric-drop case, a persona stem; F2 |
| A4 | "Engineering says a launch needs two more weeks. Go-to-market says the date is committed. You own the launch process. What do you do?" | CASE | [generic] | Separate facts from positions: what is actually blocked and what is only preferred. Name who decides, lay out two or three options with costs, say how and when you would escalate, and say what you would record afterwards | Scores influence without authority in a concrete conflict; F4 and F1 |
| A5 | "You have no prior context on this team. How do you write a 90-day plan for this role?" | JD | [generic] | Say who you would talk to and what you would ask in the first two weeks, which existing processes you would map, how you would choose one early win, and how you would agree success measures. A plan is a method, not a claim | Tests handling ambiguity and prioritization; F6 and F3 |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of a product operations role would you be weakest at on day one?" | JD | [generic] | Pick a real limit, not a disguised strength. Name it plainly, say the specific ramp: who you would ask, what you would read, what you would have delivered by day 30. Hold your position through two follow-ups, concede one specific thing, never fold on the core. If no real limit comes to mind, say so plainly, then name where you expect to be slowest | The most predictable objection for any candidate; the highest-ROI prep. JD because it scores the role's stated demands, with a Skeptic delivery; F1 to F6 |
| B2 | "Why this role, why Stripe, why now?" | CO | [generic] | Three parts, each specific to you: what draws you to the work, what draws you to this company, what makes this the moment. The company part needs facts from Stripe's own published material, which this pack could not fetch; do not use anything you cannot source. If a part has no honest answer yet, say so, then give the one you do have | Motivation consistency under cross-examination; CO because it tests homework, EXP-adjacent in delivery |
| B3 | "Product operations can look like a coordination role. What makes it more than that?" | JD | [generic] | Define the job in terms of outcomes: decisions made faster, mistakes not repeated, information that reaches the right people. Use your own words, and tie each point to something you would do, not something you did, unless it is yours to claim. If you have not done this work, say so plainly and say how you would start | Skeptics test whether the candidate understands the job; F3 and F4 |
| B4 | "Pick a result you are proud of. How much of it was actually you?" | EXP | [generic] | Choose a result where you can separate your part from the team's. Use "we" for context and "I" for what you contributed, and name what someone else owned. If you cannot separate them, say so plainly, then give the nearest thing your material does carry | A persona stem aimed at attribution honesty; F4 |

### C. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our teams sit side by side. Where is the seam between product operations and product management, and what happens when we disagree?" | JD | [generic] | Offer principles, not a pretended map: who owns the decision, who owns the process, how a disagreement gets named early. Do not assert how Stripe's teams divide this; ask. Show spine and tact together | Seam-splitting is the peer's core probe; F4 |
| C2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Say your rule in your own words: name contributors specifically, credit before asked. If you have an occasion you can stand behind, use it; if not, say so plainly and state what you would do | A persona stem; F4 |
| C3 | "What would you need from me in your first month, and what could you do for my team?" | JD | [generic] | Lead with reciprocity: what you would take off their plate, then what you need. Keep the needs to access, context and decisions rights, not favors | Peers price what the hire costs and contributes; F4 and F6 |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Launch cycle time improved 30% after a new process went in. How would you decide whether the process caused it?" | CASE | [generic] | Define cycle time and the baseline, check mix shift in what was launched, selection effects, and timing. Say which assumption you would defend least before they ask, and what comparison you would want | The weakest-assumption move, rehearsed on a case that needs no history; F2 |
| D2 | "Which three metrics would you track to know product operations is working, and what would each one hide?" | JD | [generic] | Pick metrics tied to decisions, one leading and one lagging. For each, name its blind spot in one sentence. If you cannot choose, say what you would need to learn first | Probers score whether metrics are held lightly; F2 |
| D3 | "Pick a number you have relied on to make a decision. How was it counted, and which assumption would you defend least?" | EXP | [generic] | Choose a number whose counting you actually know. Say how it was counted, what it is sensitive to, and the assumption you trust least. If you do not know how it was counted, say so plainly | The defend-the-number rehearsal without a figure from the CV; F2 |

### E. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time that has a named stake, a moment you did not soften it, and a relationship that survived. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem; F4 |
| E2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a decision with a visible tradeoff: what the metric said, what the customer needed, what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem; F2 and F6 |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [generic] | Prepare a 90-second arc: where you started, the one or two turns that matter, why this role is next. Every fact in it must be one you can defend; keep it to what you would say unprompted | Casual openers are scored on economy; F5 |
| F2 | "What are you reading, building or trying out lately that is relevant to this work?" | JD | [generic] | Name one real thing and why it interests you. If nothing comes to mind, say so plainly and name what you would pick up first | Casual questions on hot topics are still scored; F6 |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you for this role?" | JD | [generic] | Pause, restate the question, then three beats: what you do, why it fits the role, what you would do first. Hold if challenged and concede one specific point if pushed twice | A time-boxed motive challenge; F1 to F6 |
| G2 | "Product operations sounds like the first thing cut when budgets tighten. Convince me it is not." | JD | [generic] | Hold the position through two follow-ups. Concede one specific, true limit, such as that the value is hard to see when it works, then say how you would make it visible | Devil's advocate on the role, with no premise about your past; F3 |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| F1 Run launches or rollouts across teams | A1, A2, A4, G1 |
| F2 Use data and metrics | A1, A3, D1, D2, D3, E2 |
| F3 Build or improve processes | A2, A5, B3, G2 |
| F4 Work across teams without authority | A4, B3, B4, C1, C2, C3, E1 |
| F5 Written and senior communication | F1 only; no written question: a spoken bank cannot test writing, so ask the recruiter whether a written exercise exists |
| F6 Prioritize under ambiguity | A5, C3, E2, F2, G1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a successful first 90 days look like for this role, and how will you know?" | Shows you think in outcomes and gives you the scoring sheet |
| R2 | "Where does product operations end and product management begin here, and where is that line still being worked out?" | Signals you respect the seam and invites a candid answer |
| R3 | "What is the most recent process change this team made that did not stick, and what did you learn?" | Invites honesty and shows you expect imperfection |
| R4 | "Which decisions does this role own, and which does it only influence?" | Clarifies authority before you accept it |
| R5 | "What does the team wish it had measured earlier?" | Shows data instinct and surfaces real priorities |
| R6 | "What would you want a new person to avoid in their first month?" | Turns the interviewer into a coach, which builds rapport |

## Prohibited claims

None listed. The material holds no sentence of yours to inflate and no stated negative, so there is nothing for the pack to widen or contradict. This is an empty list because nothing was given, not because everything was checked. It fills once you supply a CV.

## Sources

Provided documents: your message only (company, role, final round). No dossier was present.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

Searches sent, all refused, none returned a result:

- "Stripe operating principles values" — refused
- "Stripe interview process product operations manager" — refused
- "Stripe strategy news 2026" — refused
- "Stripe Product Operations Manager job posting responsibilities requirements" — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | The search was refused. A values cheat sheet needs the published value names; none were used, and no values-style round is assumed |
| 2. Stripe interview process, product ops | unavailable | The search was refused. Persona weights rest on the Generic archetype, not on Stripe's documented loop |
| 3. Stripe strategy, recent news | unavailable | The search was refused. No question is grounded in current Stripe strategy; B2 and the reverse questions stay general |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative Product Operations Manager JD | unavailable | The search was refused. Fit snapshot rows are role-family prose labeled generic, not quotes from a posting |

## Upgrade menu

- Web search access → rows 1, 2, 3 and 5 above: Stripe's published value names, its documented loop, current strategy for a CO question, and a representative JD that turns six generic rows into inferred ones
- A deeper research pass, once → up to 6 more searches and 2 more fetches, several more minutes: a strategy brief and loop reports for this role family
- The job description text → the six fit-snapshot rows become grounded, and every question is checked against its requirement list
- Your CV or a few lines on your background → F1 to F6 get your own quoted sentences, the bridges become story maps, and B1 points at your real gap
- Interviewer names, or the final-round schedule → an interviewer read, persona weights by session, and a reverse question tied to their path
- Recruiter or HR guidance on focus areas, or any take-home or presentation → a build section for each announced deliverable
- A `tuesday-dossier.md` from an earlier session → verified evidence and constraints carried in, if you have one
