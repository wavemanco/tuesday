I'm fixing a few wrong question IDs and two unsupported phrases in the pack file, using the Edit tool instead of a script.
Dara, your prep pack is saved as `Ashgrove_member-experience-lead_interview_pack.md`. It covers all three rounds on 5 December, with 27 questions and reverse questions for each round. I built it from the recruiter's email, so the weights for rounds 2 and 3 rest on the interviewers' roles only. The two panel managers aren't named yet, so there's no read on them.

- **Biggest risk:** The question to rehearse hardest is B2: "This role owns complaints across every branch and the contact centre. What part of that have you owned yourself?" Your material says you handled one branch's formal complaints log, and that you've never worked in a contact centre. The pack has you hold to the log, say the contact-centre gap plainly, and give a plan rather than a past.
- **Presenting gap:** You've said you've never presented above regional level. B4 prepares you to say that plainly and follow it with a plan.
- **Round 3:** C1–C4 each map to one of the four values. Only "Own the Fix" has a story from your own words, and the other three are selection scaffolds with an honest "nothing comes to mind" branch. C8 and C9 prepare the 20-minute escalation case.
- **Answer slots:** Several rows ask what your material doesn't show, such as what the spreadsheet counted, whether it was Excel, and which rules governed the log. Your answers would turn those rows from slots into your own quoted evidence.
- **Not searched:** The values, the recruiter's email, the strategy summary and the JD already fixed everything a search could change, so I ran no web searches. I only had your summary of the strategy brief, not the brief itself. The pack lists the exact upgrades that would help, including a deeper research pass.

Say the word and I'll run a live drill, starting with B2 as the Skeptic. I can also record the gaps this prep exposed in a `tuesday-dossier.md` for later sessions, or convert the pack to Word.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Ashgrove_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara. **Mode:** loop, three rounds on 5 December 2026, built from the recruiter's email.

| Round | Who | Length | What the recruiter's email says |
|---|---|---|---|
| 1 | The recruiter | 30 min | Process conversation |
| 2 | The Head of Member Services, your future manager | 45 min | "mostly behavioural" |
| 3 | Panel of two branch managers | 60 min | Includes a 20-minute case on a complaint escalation. "The panel is also the values round — they score against the four values." |

The panel members' names are not assigned yet, so there is no interviewer read. Rounds 2 and 3 are weighted from their roles alone.

## How to use this pack

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows Ashgrove's published values |
| EXP | Whether your own experience holds up under follow-up questions |
| JD | The job's stated requirements, gaps included |
| CO | What you know about Ashgrove and its strategy |
| CASE | A live problem set in the role |

Labels: `[grounded]` traces to something you gave me, `[inferred]` is my derivation, `[generic]` is a pattern with no claim about Ashgrove or you. An answer slot is an instruction for the interview, not a question for you now. It asks you to say what is true in your own words, and every slot allows that the practice never existed or was not yours.

## Prep triage (nine days to 5 December)

1. **Days 1–2: B2.** The most likely objection is that you handled one branch's log and this role owns the whole process. Say B2 aloud until the honest answer is boring.
2. **Days 3–4: C1–C4 and C8.** Round 3 is scored against the four values and includes the case. Choose one story per value, or settle on the honest branch. Run C8 aloud twice, timed to 20 minutes.
3. **Days 5–6: B4, B8, B9.** These are the senior-audience, spreadsheet and Excel rows.
4. **Day 7: A3–A6.** Write your own answers to pay, notice, location and reason for leaving, in your own words.
5. **Day 8: the reverse questions** for all three rounds.
6. **Day 9, 4 December: one light pass** over A1 and B2. Nothing new.

Everything else in this pack is insurance.

## Fit snapshot (shared by all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap on the years, but a line in your message with nothing inspected behind it, so expect a probe on what the branch work covered. Lead with the quote's own terms: six years in retail banking, the last three as a branch supervisor |
| F2 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says the branch's log, not the process across branches, with nothing inspected behind it. Words: "I handled the branch's formal complaints log." Answer slot: the JD's wording on the whole process makes a probe on what happened to a complaint beyond the log likely. If any part beyond the log was yours, say which part and what you decided, in your own words. If none was, or it was not yours, say so plainly and stay with the log |
| F3 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked in a contact centre." Then how you would learn it, said as a plan and never as a past: for example, ask early to hear how complaints reach that team and who they hand over to. Nothing added to make the gap feel smaller |
| F4 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | discovery | A formal log is not shown to be a regulated one, and the bridge should not be stretched. Answer slot: if you know which rules or deadlines governed the log, say which, in your own words. If you do not know, or none applied, say so plainly and stay with the log |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | The sentence shows a monthly complaints spreadsheet someone uses, not what it counted. Answer slot: if it tracked how many complaints came in or how long they took to resolve, say which and how each was counted, in your own words. If it tracked something else, say so plainly and stay with the spreadsheet |
| F6 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says new tellers and the escalation script. Words: "I trained new tellers on our escalation script." The limit is the pack's observation: the sentence names tellers, not supervisors. Answer slot: the JD's escalations line makes a probe on how that training was run likely. Say what was yours to decide in it, in your own words. If you taught the script as handed to you, say so plainly and stay with that |
| F7 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent here. Answer slot: if you have worked with a digital or product team on anything members used for themselves, say what it was and what was yours, in your own words. If not, say so plainly and say what you would ask them first |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Then how you would prepare, said as a plan and never as a past. The sentence says nothing about regional level itself, and your material does not settle whether this panel would count that as senior |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | The quote says spreadsheet, not Excel. Answer slot: if it was built in Excel, say so and what it did, in your own words. If it was another tool, say which and stay with the spreadsheet |

## Grounding brief (shared)

Source is the 2026 strategy summary in your message. The brief itself was not read, so these are its headline items only.

| Item, as you gave it | Provenance | Where it may surface |
|---|---|---|
| "move 40% of member service to digital channels by 2028" | [grounded] | A2, B10, RB3 |
| "consolidate eight branches into five hubs over 2027" | [grounded] | A2, C5, RC3 |
| "launch a small-business lending product in Q1 2027" | [grounded] | A2 |
| "the main competitive pressure is app-only banks" | [grounded] | A2, B10 |

The brief is dated July 2026, about four months old, so it is inside the freshness window for strategy.

---

# Round 1: the recruiter (30 minutes)

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly, unstructured; biography, motivation, pay, notice, location, reason for leaving | High. The recruiter-screen prior is Conversational plus a light Skeptic, and the email describes this round as the process conversation | Treat every casual question as scored. Keep your biography arc to the quoted facts in F1 and F2 |
| Skeptic (light) | Knockout checks in a friendly register | Medium. The JD's contact-centre and regulated-complaints lines are the obvious screens (F3, F4) | Say the plain acknowledgment for F3, then the plan. For F4, the slot's honest branch |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." and "I handled the branch's formal complaints log and trained new tellers on our escalation script." | A 90-second arc with only the beats those sentences state: six years in retail banking, the last three as a branch supervisor, the branch's formal complaints log, and training new tellers on the escalation script. Say them in your own words. Close on why this role, in your own words; nothing here supplies your reason | The biography question opens most recruiter screens and anchors every later probe. F1 and F2 hold the facts, and EXP because it tests what was actually yours |
| A2 | "What do you know about where Ashgrove is heading?" | CO | [grounded] | Bring one item from the brief to show you read it: the 40 percent digital target for 2028, the eight-to-five hub plan for 2027, the Q1 2027 small-business lending launch, or app-only banks as the main pressure. Then give one view of your own on what it means for complaints work, labelled as your view, and concede that you have not seen Ashgrove's complaint figures. Do not recite the whole brief, since it is published and any prepared candidate can recite it | The brief is equally available to rival candidates, so a departure from it with reasons is what shows judgement. See the grounding brief |
| A3 | "What are your salary expectations?" | JD | [generic] | A logistics slot, and only your own answer is safe. Give your own number, or ask for the role's band first. Nothing here supplies a figure. If asked what you earn now: "I'd rather focus on the range for this role" | Recruiters ask this to check the role is affordable for both sides, and the answer must be yours. JD because it concerns the listed job's terms |
| A4 | "What's your notice period?" | JD | [generic] | A logistics slot. Give your actual notice period, in your own words, and anything that affects your start date | Asked in every recruiter screen. JD because it concerns the listed job's terms |
| A5 | "Where can you work, and how often?" | JD | [generic] | A logistics slot. State where you can work and how often, in your own words. Nothing here supplies your answer | Location is a term the candidate meets or does not, so it is better settled early. JD because it concerns the listed job's terms |
| A6 | "What's prompting a move now?" | EXP | [generic] | A logistics slot. Give your own reason, in your own words; nothing here supplies one. Keep it about what you are moving toward and add nothing you cannot stand behind | The reason for leaving is checked for consistency with the rest of the story. EXP because it concerns your own history |
| A7 | "The role spans the branches and the contact centre. How does your background fit that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Say it plainly: "I've never worked in a contact centre." Then the plan as a plan: what you would ask to see first in that team, and who you would ask. Then the part you do have, at its own scope: "I handled the branch's formal complaints log." Do not stretch the log to cover the contact centre | The Skeptic's knockout check, and F3 is the sharpest edge of the JD. JD because it scores a stated requirement |
| A8 | "Walk me through how the branch's formal complaints log worked." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F4: the log, and that you handled it, which are the beats the quote states. Answer slot: the JD's regulated-complaints line makes a probe on the rules the log sat under likely. If you know which rules or deadlines applied, say which, in your own words. If you do not know, or none applied, say so plainly and stay with the log | F4 is thin, and the recruiter is the first person likely to test it. JD because the premise is the JD's |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RA1 | "When will the two branch managers on the panel be confirmed, and could you tell me their roles?" | Names and roles unlock the interviewer read and sharper persona weights in round 3 |
| RA2 | "For the 20-minute case, is it live, or is there material to read beforehand?" | The format changes how you prepare C8 and C9 |
| RA3 | "What would the Head of Member Services most want from this role in its first months?" | Shows you are preparing for round 2 and gives you its frame in advance |
| RA4 | "How is complaint handling split between the branches and the contact centre today?" | Turns F3 into a conversation about the real structure |
| RA5 | "What happens after the 5 December rounds, and when would you expect to decide?" | Practical, and shows you are planning |

---

# Round 2: the Head of Member Services (45 minutes, your future manager)

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the gaps against the JD: contact centre, presenting upward, digital | High. The hiring-manager prior is Case plus Skeptic, and this person is buying capability and derisking gaps (F2, F3, F7, F8) | Rehearse B2 until it is boring. Use plain acknowledgments only where you stated the negative, and add a plan each time |
| Values / Behavioral | Scenario and story probes | High. The recruiter calls the round "mostly behavioural", which lifts this above the prior | Where one of your quoted sentences carries a story, map to it. Where none does, pick a story by the stated criteria, or take the honest branch |
| Data-Driven Prober | Asks what the spreadsheet counted and how | Medium. The JD asks for monthly reporting on volumes and resolution times, and you built a monthly spreadsheet (F5, F9) | Say what you know about how anything was counted, and say plainly when you do not know |
| Case / Strategist | A live problem from the roadmap | Low-medium. The prior says Case, but the recruiter's email puts the formal case in round 3 | Clarify, then structure, then answer, then metrics and risks. Think aloud |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pick the one that is truest and say it plainly, in the quote's terms: "I've never worked in a contact centre," or "I've never presented to anyone above regional level." Then your plan for it, as a plan. If digital teams is your pick, say what you have or have not done with them, in your own words. Do not list all three | The Skeptic's opener, and a calm, specific answer converts a gotcha into credibility. F3, F7 and F8 are the candidates for the answer |
| B2 | "This role owns complaints across every branch and the contact centre. What part of that have you owned yourself?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." and "Never worked in a contact centre, and I've never presented to anyone above regional level." | **The highest-ROI rehearsal in this pack.** The hold is only what the quote carries: "I handled the branch's formal complaints log." Concede the contact-centre half plainly: "I've never worked in a contact centre." Answer slot: if any part beyond the log was yours, say which part and what you decided. If none was, say so plainly and describe how you handled the log. Hold through two follow-ups by returning to the log, never by adding to it. Follow-up one is likely to ask what happened to a complaint after it left the log, so use the slot again. Follow-up two is likely to ask how you would take on branches you have not worked in, so give a plan, not a past | F2 and F3 are where the role's whole-process mandate presses hardest, so this objection arrives in some form in every round. JD because it scores the stated requirement |
| B3 | "How would you approach coaching branch supervisors on escalations?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Start from what you did, at its own scope: "I trained new tellers on our escalation script." Then how you would approach supervisors, said as a plan and your own view: how you would find out what they already do, and how you would agree what good looks like with them. Do not describe coaching supervisors as something you have done | F6 is a transferability row, with tellers in the evidence and supervisors in the JD. JD because it scores a stated requirement, with a CASE-style future framing |
| B4 | "How would you present the monthly complaints report to our senior leaders?" | JD | [grounded] "I've never presented to anyone above regional level." and "I built the monthly complaints spreadsheet our regional manager uses." | Open with the plain acknowledgment: "I've never presented to anyone above regional level." Then a plan: what you would put first, what decision you would ask them to make, and a practice run with someone who can interrupt before the first one. What you can say about the report is only that you built the monthly complaints spreadsheet your regional manager uses | F8 is a stated gap, and the manager owns the senior audience. JD because it scores the stated requirement |
| B5 | "Tell me about a time you had to deliver an unwelcome message to someone senior." | VAL | [generic] | A selection scaffold. Pick a time with a named stake, a moment you did not fold, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The Behavioral persona's stem, and the manager will be one of the senior people you report to. The scaffold is used because no quoted sentence carries this story |
| B6 | "Tell me about a complaint that was hard to resolve." | EXP | [generic] | A selection scaffold. Pick one where you can say what the member was asking for, what stood in the way, and how it ended. If no such complaint comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's whole subject. Scaffold used because no quoted sentence carries a hard case |
| B7 | "How did you teach new tellers the escalation script?" | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F6, at its own scope: you trained new tellers on the escalation script. Answer slot: the JD's coaching line makes a probe on what was yours to decide in how it was taught likely. Say which parts, in your own words. If you taught it as handed to you, say so plainly and stay with that | F6 is the evidence for the coaching requirement and the likeliest place for the manager to dig. EXP because it tests what was actually yours |
| B8 | "Walk me through the monthly complaints spreadsheet you built — what did it track?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F5: you built it, it was monthly, it covered complaints, and your regional manager uses it. Answer slot: the JD's volumes and resolution times line makes a probe on what it counted likely. If it tracked either, say which and how it was counted. If it tracked something else, say so plainly and stay with the spreadsheet. The weakest-assumption move: name, in your own words, the part of how anything was counted that you would defend least, or say plainly that you do not know how it was counted | F5 is the evidence for the reporting requirement. EXP because it tests the attribution and the counting |
| B9 | "How comfortable are you building reports in Excel?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: if the spreadsheet was in Excel, say so and what it did, in your own words. If it was another tool, say which and stay with the spreadsheet. Do not claim features you did not use | F9 is a discovery row, because the quote says spreadsheet and not Excel. JD because it scores a stated requirement |
| B10 | "Ashgrove plans to move 40 percent of member service to digital channels by 2028. How would you decide which complaints belong in self-service?" | CASE | [grounded] | Clarify first: what counts as a complaint and what as a query, and who now handles each. Then objective, then segmentation by type and by risk, then approach, metrics and risks. Challenge one premise respectfully, such as whether every complaint type suits self-service. Use Ashgrove's own words: member, self-service journeys. The question asks about no past, so the guidance makes no claim about yours | F7 is a silence row and the brief makes digital the strategy, so this is the likely case-style probe. CASE because it is a live problem |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RB1 | "When the monthly complaints report goes to senior leaders, what decisions do they make from it?" | Shows you think of reporting as decisions, and it prepares B4 |
| RB2 | "Where does a complaint stop having an owner today, between branches and the contact centre?" | Points straight at the role's whole-process mandate and the Own the Fix value |
| RB3 | "How do you expect the 40 percent digital target to change the complaints this role sees?" | Shows you read the strategy and lets the manager teach you |
| RB4 | "What would you want me to learn first about the contact centre?" | Converts F3 into a plan the manager can shape |
| RB5 | "How do branch supervisors experience escalations today, and what would you want to change?" | Shows the coaching mandate is about listening before teaching |
| RB6 | "What does the working relationship with the digital teams look like today?" | Surfaces F7 as a question about structure rather than a gap |

---

# Round 3: the panel of two branch managers (60 minutes, values round with a 20-minute case)

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scenario probes scored against the four published values | High. The recruiter says "they score against the four values" | Map a story to each value where a quoted sentence carries one; elsewhere use the selection criteria and the honest branch |
| Peer Evaluator | Seam-splitting, "what would you need from us", credit and disagreement | High-medium. The panel is branch managers, and the JD has the role coaching branch supervisors. That link is my inference, and names are not yet assigned | Offer principles for the seam rather than pretending to know it, and say what you would bring them |
| Case / Strategist | The 20-minute complaint-escalation case | Medium. The recruiter's email names it. The case is live and set in the role | Clarify, then structure, then answer. Challenge one premise. Think aloud |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you made a decision from the member's side of the counter." | VAL | [grounded] | A selection scaffold for Members First, Always. Pick a decision where you can say what the member needed, what pushed the other way, and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would decide | The first published value. A scaffold is used because no quoted sentence carries this story |
| C2 | "Tell me about a time you reworded something because people needed it explained twice." | VAL | [grounded] | A selection scaffold for Plain Words. Pick a time you can describe: what was unclear, who found it unclear, and what you changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The second published value, which says that if a member needs it explained twice, "we wrote it wrong". No quoted sentence carries it |
| C3 | "Each of our branches is part of its town, and this role reports on numbers. Tell me about a time a number and a person pointed in different directions." | VAL | [grounded] | A selection scaffold for Neighbours, Not Numbers. Pick a time you can describe: the figure, the person, and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The third published value, and the tension is built into the role's monthly reporting. See F5 for the reporting side |
| C4 | "Tell me about a time you kept hold of a problem until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F2, at its own scope: you handled the branch's formal complaints log. Answer slot: the value says whoever finds a problem keeps hold of it until it is solved, so expect a probe on a complaint that stayed with you. If one did, say which, what stayed yours and what you did. If it passed to others, or you only logged it, say so plainly and stay with the log | The fourth published value and the nearest to the JD's ownership line. VAL because it is scored against a value |
| C5 | "The brief has eight branches becoming five hubs over 2027. What would you want from branch managers, and what would you offer them, while that happens?" | CO | [grounded] | Propose principles for the seam, not a claim to know it: a named route for a supervisor to reach you, and what you would report back to them. Say what you would bring, not only what you would need. Concede that you do not know how each branch handles complaints today. The question asks about no past | The hub plan puts branches in the conversation, and this is the reciprocity question. See the grounding brief |
| C6 | "Where is the seam between your job and a branch manager's, and what happens when we disagree?" | VAL | [generic] | Offer seam principles, then a disagreement scaffold: pick a time you disagreed with someone at your level or above over how a customer issue should be handled, where you can name the stake and the repaired relationship. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The Peer Evaluator's stem. A scaffold is used because no quoted sentence carries a disagreement |
| C7 | "How do you handle credit and blame when a complaint spans a branch and the contact centre?" | VAL | [generic] | Say your principle first and keep it short: whose name goes on the fix, and how a mistake is owned without being assigned. Use the Own the Fix value in its published wording. The question asks about no past | The Peer Evaluator's credit probe, set in the role's own structure (F2, F3) |
| C8 | "A member has complained twice about the same problem. The branch says it is resolved. The member says it is not. The contact centre's notes tell a third story, and the complaint has now come to you. Walk us through what you do." | CASE | [generic] | Clarify first: what the member is actually asking for, what each record shows, and which time limits apply to this kind of complaint. Then objective, then who holds the complaint now, then what you would tell the member in plain words, what you would tell the branch supervisor, and what you would record and report. Challenge one premise respectfully, such as treating the three accounts as equally reliable. Think aloud. The scenario is a pattern, not a claim about Ashgrove or you | The 20-minute case in the recruiter's email. It tests ownership and plain words together |
| C9 | "Now the branch supervisor says your handling has made the branch look bad. How do you respond?" | CASE | [generic] | Hold, then concede. Hold the member's side without defensiveness through two follow-ups. Concede specifically, for example that you have not seen how the branch handled it. Restate the question before answering and pause first | The panel follows the case with pressure on it. Hold-then-concede is the structure that scores |

## Values / principles cheat sheet

The values are quoted from the page you copied on 26 November 2026.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Selection scaffold: pick a decision where you can say what the member needed and what pushed the other way. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would decide |
| Plain Words | If a member needs it explained twice, the wording was the problem | Selection scaffold: pick a time you reworded something. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Neighbours, Not Numbers | Every branch is treated as part of its town | Selection scaffold: pick a time a figure and a person pointed apart. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F2: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Answer slot in C4 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RC1 | "What would you most want a Member Experience Lead to understand about your branch before they coach your supervisors?" | Shows you would listen before teaching, and it speaks to Neighbours, Not Numbers |
| RC2 | "When a complaint is escalated to you today, what do you wish arrived with it?" | Surfaces the real escalation pain, and it connects to Plain Words and Own the Fix |
| RC3 | "Does the move to hubs change who handles complaints at your branch?" | Strategy-aware, and lets them tell you what they are worried about |
| RC4 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question, which fits peers |
| RC5 | "Which of the four values do you see tested most in complaint handling, and what does it look like when it goes right?" | Asks them for their own example, in the vocabulary they score against |

---

## Requirement coverage

| JD requirement | Questions |
|---|---|
| 4+ years in financial-services customer operations | A1 |
| Own the member complaints process end to end across branches | B2, C4, C8 |
| across branches and the contact centre | A7, B1, B2, C7 |
| experience handling regulated complaints | A8, C8 |
| report monthly on complaint volumes and resolution times | B8, C3 |
| coach branch supervisors on escalations | B3, B7, C6, C9 |
| work with digital teams on self-service journeys | B10, RB6 |
| confident presenting to senior leaders | B1, B4, B5 |
| comfortable with Excel reporting | B8, B9 |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the member complaints process end to end | Inflated form of F2 | F2's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: your material says the branch's log, not the process across branches |
| Has contact-centre experience | Negative you stated, F3 | The plain acknowledgment: "I've never worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment: "I've never presented to anyone above regional level." No slot |
| Handled regulated complaints | Inflated form of F4 | F4's quote at its own scope: a formal complaints log you handled. The limit is the pack's observation: your material does not show which rules governed it |
| Coached branch supervisors on escalations | Inflated form of F6 | F6's quote at its own scope: "I trained new tellers on our escalation script." |
| Reported on complaint volumes and resolution times | Inflated form of F5 | F5's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." |
| Built Excel reporting | Inflated form of F9 | F9's quote at its own scope: a spreadsheet. The limit is the pack's observation: your material does not name Excel |

## Sources

**Provided:** the job description; the four published values, copied by you from the Ashgrove values page on 26 November 2026; the recruiter's email on the process; your summary of Ashgrove's July 2026 strategy brief, with the brief itself not read; your background. No dossier was present.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The values you pasted fix the cheat sheet and C1–C4; nothing a search could return would change them |
| 2. `Ashgrove Credit Union interview process member services` | skipped | The recruiter's email already gives the rounds, who runs each, and their format, so it fixes the persona weights and the loop structure |
| 3. `Ashgrove Credit Union strategy` | skipped | Your summary of the July 2026 brief fixes the CO items and the grounding brief; it is about four months old |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No interviewer has been named, so there was no query to form; the upgrade menu says what names would unlock |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The strategy brief itself → B10, C5 and A2 move from your summary to the brief's own wording and numbers
- The panel members' names and roles, once assigned → an interviewer read for round 3, per-person persona weights, and a reverse question tied to each one's path
- What the 20-minute case provides (live, or material beforehand), from one email to the recruiter → C8 and C9 tuned to the real format
- Your own answers to the answer slots in A8, B2, B7, B8, B9 and C4, said in a message → F2, F4, F5, F6 and F9 regenerate from slot to quote
- The column headings of the monthly spreadsheet and the format of the escalation script, with no member data → F5, F6 and F9 evidence could rise from medium toward high, since those are what a complaints role would inspect
- A CV → a second source for F1–F9 and possibly more rows
- Your pay, notice, location and reason for leaving, in your own words → A3–A6 become quoted logistics answers
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → public strategy context, the panel's public footprint once named, and loop reports for credit-union member-service roles
- A `tuesday-dossier.md`, if you have one → verified evidence and ready-made prohibited claims in place of the ones built here
