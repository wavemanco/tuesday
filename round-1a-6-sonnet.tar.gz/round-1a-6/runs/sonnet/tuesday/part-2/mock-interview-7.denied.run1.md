Web search was denied in this session, so I'm building the pack from your JD and background only, with everything outside those marked generic. I'll write the file now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a6/runs/sonnet/tuesday/part-2/rooms/case-7-denied-740b787a/saltmarsh-games_live-operations-producer_interview_pack.md`.

I couldn't search the web. Search permission wasn't granted, so all four searches were refused: company values, interview process, strategy, and Tobias's public background. The pack is built only from your JD and what you told me. It has no company-specific questions, no values cheat sheet and no read on Tobias. The Sources section lists each refused query.

I built it for a hiring-manager round on the assumption that Tobias is who the role reports to. The first bank is live-ops case problems, and the second probes your two stated gaps, in-app purchases and team leadership. The question I'd rehearse most is B1, "Which part of this JD would you be weakest at on day one?"

Say the word and I'll play the Skeptic on B1, or run any other question as a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias your future manager, and did the recruiter mention any focus areas or a task to prepare? Your answer reweights the question banks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations. Built for a 60-minute hiring-manager round: your note named his title and not your relationship to him, so this assumes he is the person the role reports to. Built from your JD and your own description of your background; no web research was available (see Sources).

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did. The letter F is left unused as a question prefix so it cannot be confused with the fit-snapshot rows F1 to F10.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your described experience survives follow-up; what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Knowledge of the company and its strategy |
| CASE | Structure and reasoning on a live problem from the role |

This pack has no VAL or CO questions: no values or strategy material was available, so none could be written without inventing it.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says a content-drop calendar for one title, not live events and not two titles, and the words stay there: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's live-events and two-title lines make a probe on both likely. If any drops were timed events, or you worked across more than one title, say how, in your own words; if not, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show which of these teams you worked with. Answer slot: the JD names four teams, so expect a probe on each. Say which you worked with and how work moved between you, in your own words; if you did not work with some of them, or did not coordinate them, say so plainly and stay with what you can say you did |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your material says presented, monthly, to the studio head. It does not say owned, and does not say post-event. The words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's own line makes a probe on who chose what the numbers reported likely. If you chose or built any of what was reported, say which, in your own words; if someone else set it, or no review followed an event, say so plainly and stay with presenting the numbers |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | Lead in the quote's own terms: you wrote the checklist, and QA still uses it. Your material says wrote, not that you ran each release against it, so the words do not go past the checklist. Expect a probe on how a release went through QA; say what you did, in your own words, or that your part was the checklist itself |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | discovery | Your material does not say whether the studio's title ran as a live service, or what the first two of the four years held. Answer slot: the JD ties the years to live-service work, so expect a probe on it. If the title ran as a live service, say how, in your own words; if it did not, or the first two years were other work, say so plainly and stay with the years and the calendar you stated |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe on it. Lead with the quote's own terms: weekly, one main title, the last two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | presentation | Reword only the quote: "I presented the monthly retention numbers to the studio head." Your material shows presenting the numbers, not how they were counted; C1 rehearses that |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | low | [inferred] | discovery | A checklist is written work, but your material does not show other kinds of writing a live-ops role asks for. Answer slot: if you have written other things that others relied on, say which, in your own words; if nothing beyond the checklist, say so plainly and stay with the checklist |
| F9 | in-app-purchase familiarity for a mobile live-ops role, a role-family expectation that is not in the JD | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F10 | team leadership, which the JD does not ask for (its line is coordinating teams, F2) | "Never led a team" — your message | none | [grounded] | capability | Words: "I haven't led a team." Keep it separate from F2: coordinating teams on an update is a different claim, and your material does not show it either way |

## Persona table

Weights are a shown judgment. Change them if you know something I do not.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (A, 5 questions) | Live problems from the role: plan a calendar, diagnose a drop, sketch a review | Highest. The hiring-manager prior puts it first, and the JD's lines are all planning and running tasks. This rests on the round-type prior; no interviewer profile was available to adjust it | Clarify, then objective, segments, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic (B, 4 questions) | Quiet probing of the gaps you named | High. The hiring-manager prior, plus two gaps you stated yourself (F9, F10) and the thin F3 | Rehearse B1 until it is boring; plain acknowledgment, then a plan stated as a plan |
| Data-Driven Prober (C, 3 questions) | Retention and KPI questions taken to their assumptions | Medium. The JD names retention metrics and KPIs, and your material includes presenting retention numbers | Know what you can and cannot say about how the numbers were counted; say plainly when you do not know |
| Conversational (D, 3 questions) | Walk-me-through opener and friendly questions that are still scored | Medium. Most rounds open this way; the likelihood here is the generic loop prior | A short arc built only from your own quoted lines |
| Peer Evaluator (E, 2 questions) | Seam and credit questions between teams | Low in this round, higher if later rounds include design, art or engineering leads | Reciprocity framing; propose seam principles rather than pretend to know the seam |
| Pressure (G, 2 questions) | Time-boxed challenges to your claims | Low. Not a hiring-manager prior; included so the style is not new to you | Pause, restate, hold the quoted position through two follow-ups, concede specifically |

Values/Behavioral has no bank. No loop source was available, so the fallback is the generic archetype with flat weights around the hiring-manager prior, and a values-style round is not assumed under it. If Saltmarsh publishes values or runs a values round, the upgrade menu says what to send.

## Requirement coverage

| JD requirement | Questions |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A1, D2, G2 |
| "coordinate design, art, engineering and community teams on each update" | A3, B3, E1 |
| "own the post-event review and the KPIs it reports" | A4, B4, C3 |
| "manage the release checklist with QA" | A5, E2 |
| "3+ years producing live-service games or apps" | B1, D1, G1 |
| "experience running a content calendar" | A1, D1, G2 |
| "comfortable with player-retention metrics" | A2, C1, C2 |
| "clear written communication" | D3 |

## Question banks

### A. Case/Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two titles both want a big event in the same week. How do you build the calendar?" | CASE | [generic] | Clarify first: what is fixed, what team capacity each title has, what each event is meant to achieve. Then objective, how you would sequence or stagger, what you would measure, and what could go wrong. Challenge one premise, for example whether both events need that week. The question needs no claim about your past, so the guidance makes none | F1 and F6 are the calendar requirements; the JD's two-title line makes a scheduling conflict a natural live problem. CASE because it scores structure; generic because it is a pattern, not a fact about this employer |
| A2 | "Retention dropped after an event ended. Diagnose it." | CASE | [generic] | Clarify before diagnosing: which players, which platform, compared with what, what else changed that week. Then segment, form two or three hypotheses, say which data you would pull for each and what you would do. Think aloud. The question needs no claim about your past | F7 is the retention requirement and the persona stem is the Case/Strategist's own. CASE because it scores reasoning, not a right answer |
| A3 | "An update is due Thursday. Engineering says one feature will not be ready and art wants to cut something else. What do you do?" | CASE | [generic] | Ask what is fixed and what is movable, then lay out options: cut, delay, ship in part. Say who decides, how you would tell design and community, and what you would record. Challenge one premise, for example why Thursday. The question needs no claim about your past | F2 lists four teams the producer coordinates; this puts two of them in conflict. CASE with JD content |
| A4 | "Sketch the post-event review for an event we just ran. What do you need to know first?" | CASE | [generic] | Clarify what the event was for and what was promised, then what to compare it against, what the review reports, who reads it and what decision follows. Say aloud which metrics you would include and why you would leave one out. The question needs no claim about your past | F3's requirement asks you to own the review and its KPIs. This asks for the design of a review, not a claim to have run one |
| A5 | "Walk me through how you would run a release day for an update, with QA." | CASE | [grounded] "Wrote the release checklist our QA team still uses" | Structure it: scope of the release, what QA checks and when, who signs off, what happens on a fail. Where you reach for the checklist, say it in your own words: "I wrote the release checklist, and our QA team still uses it." Answer slot: the JD's QA line makes a probe on how a release actually went through QA likely. If you worked through releases with QA, say how; if your part was the checklist itself, say so plainly and stay there | F4 is the evidence and its words stop at the checklist. CASE with JD content: it scores a plan for a release, and the checklist is the only past it draws on |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this JD would you be weakest at on day one?" | JD | [inferred] "never worked on a game with in-app purchases"; "Never led a team"; "Presented the monthly retention numbers to the studio head" | The highest-ROI rehearsal in this pack, named by this pack from your own gaps, not by an underwriter. Choose one weakest area your material shows and say it first, plainly: "I haven't worked on a game with in-app purchases," or "I haven't led a team." Level two, "how would you close it": give a plan in the future tense, what you would learn first and who you would ask, in your own words, never a past event. Level three, "what if that blocks you in week two": say what you would ask for and from whom. Hold the plain statement through the follow-ups and concede nothing further | F9 and F10 are gaps you stated and F3 is the thinnest row against a JD line, so this question is the likeliest place the interview turns. JD type because it scores the stated requirements; inferred because the pack derives that it will be asked |
| B2 | "I don't see in-app purchases in your background. How would you handle that in this role?" | JD | [inferred] "never worked on a game with in-app purchases" | Open with the plain acknowledgment: "I haven't worked on a game with in-app purchases." Then a plan, said as a plan: name the first things you would learn and who you would ask, in your own words. Promise nothing about the past and do not claim a nearby skill covers it | F9 is the gap you named. The JD does not name it, so the pack's inference is that it can arrive through the KPI requirement in F3; the persona stem is the Skeptic's |
| B3 | "The role coordinates design, art, engineering and community teams. You have never led a team. How would you get them to move on a date?" | JD | [grounded] "Never led a team" | Acknowledge plainly: "I haven't led a team." Then how you would work without authority, as a plan in your own words: what you would agree up front, and how you would escalate. Answer slot: the JD names four teams, so expect a probe on which you have worked with. Say which and how, in your own words; if none, or if you did not coordinate them, say so plainly and stay with the plan | F10 is your stated negative and F2 is the requirement. JD type because it scores the stated coordination line |
| B4 | "This role owns the post-event review and its KPIs. What part of that have you owned?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | The hold is only what the quote carries: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose or built any of what was reported, say which, in your own words; if someone else set it, or no review followed an event, say so plainly and stay with presenting the numbers. Hold through two follow-ups by returning to the quote, never by adding to it | F3 is where the JD's ownership line presses against a presenting-only quote. JD because it scores the stated requirement |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the monthly retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Defend-the-number slots, each in your own words: how the numbers were counted; what they are most sensitive to; the assumption behind them you would defend least; which part was yours. "I don't know how that was counted" is an honest branch. Name nothing the quote does not state | F7 is the retention evidence and it shows presenting, not counting; a prober goes straight there. EXP because it tests what was actually yours |
| C2 | "Tell me about a time retention numbers changed what the team did." | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Open prompt, so pick the instance: a named decision, the numbers that drove it, and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I presented the monthly retention numbers to the studio head," or how you would handle it | The JD's retention line raises the theme and F7 is the nearest evidence. Guidance is a scaffold with its honest branch because the quote carries no decision |
| C3 | "Which retention measures would you put on a post-event review, and why?" | CASE | [generic] | State what you would compare an event against and what else could explain a change, then which measures you would include and which you would leave out and why. Say what you would not claim from one event. The question needs no claim about your past | F3 and F7 together; CASE because it scores reasoning about measures, with no claim about your past |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc from those four lines only, in your own words: the four years at the puzzle-game studio, the weekly calendar for the main title for the last two, the checklist, the retention numbers. Answer slot: the why this role, why now beat is yours; say your own reason, or say plainly you are still weighing it. This arc supplies none | F5, F6, F4 and F7 are the lines the arc draws on. EXP because it is the opening biography; a chatty register does not make it unscored |
| D2 | "What mobile games are you following for how they run their live events?" | JD | [generic] | Name games you actually play or follow and one thing about how they run events, in your own words. If you do not follow any, say so plainly and say how you would study two before starting. No claim about your past is supplied | The JD's live-events line is the raising source and F1 is the requirement. A casual question about a hot topic is still scored |
| D3 | "Tell me about a time something you wrote changed what people did." | JD | [grounded] "Wrote the release checklist our QA team still uses" | Open prompt, so pick the instance. Choose one with a named reader, what you wrote and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I wrote the release checklist, and our QA team still uses it," or how you would handle it | The JD's written-communication line raises the theme; F8 is thin, so the honest branch matters |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our teams sit side by side. Where is the seam between live ops and design, and what happens when we disagree?" | JD | [generic] | Propose principles, not a map you cannot know: who decides dates, who decides content, how a disagreement is escalated and recorded. Say that you would confirm the real seam with them. Reciprocity: what you bring their team. No claim about your past is supplied | F2 is the coordination requirement; the persona stem is the Peer Evaluator's own |
| E2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Open prompt, so pick the instance: a named piece of work, who else contributed, how you shared credit. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I wrote the release checklist, and our QA team still uses it," or how you would handle it | F4's checklist is the only cross-team evidence in your material; persona stem from the Peer Evaluator |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over a candidate who has already run live events on a mobile title?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "never worked on a game with in-app purchases" | Pause and restate. Hold only what the quotes carry: "I ran the weekly content-drop calendar for our main title for the last two years," and the checklist QA still uses. Concede one thing specifically: "I haven't worked on a game with in-app purchases." Hold through two follow-ups by returning to those lines, not by adding to them | F1 and F4 are the evidence and F9 is the concession. JD because it scores the stated role; Pressure because it tests composure |
| G2 | "That calendar, how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Hold the quote's scope: "I ran the weekly content-drop calendar for our main title." Answer slot: if any part, such as what shipped or its dates, was set by someone else, say which part and who; if the whole of it was yours to set, say so plainly. Hold through two follow-ups, concede only what is true, and never fold on the core claim to restore harmony | F1 and F6 draw on this line; the persona stem tests attribution, which is where a one-line claim is probed |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a good first 90 days look like for someone owning the calendar for these two titles?" | Shows you think in outcomes and gives you the yardstick you will be held to |
| R2 | "Which KPIs does the post-event review report today, and who has owned it so far?" | Draws out what own means in this team before you are asked to claim it (F3) |
| R3 | "How do design, art, engineering and community usually hear about an update's dates, and where does that break down?" | Surfaces the real coordination problem the role exists to solve (F2) |
| R4 | "How does the release checklist work with QA today, and what would you want changed?" | Invites the interviewer to say what manage means in practice (F4) |
| R5 | "Where would you expect a new producer to need the most ramp-up in the first month?" | Lets the interviewer name the gap on your terms, and tells you where your stated gaps weigh (F9, F10) |
| R6 | "What does the conversation look like after an event underperforms?" | Shows you want the review to drive decisions, and tells you how safe it is to report a miss |

No question is tied to Tobias's own career path: no interviewer information was available beyond his title.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team | Negative the candidate stated, F10 | The plain acknowledgment F10 gives: "I haven't led a team." No slot |
| Has worked on a game with in-app purchases | Negative the candidate stated, F9 | The plain acknowledgment F9 gives: "I haven't worked on a game with in-app purchases." No slot |
| Ran live events across two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says a content-drop calendar for one title. G2's and A1's slots stay inside the calendar |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope. The material says presented, not owned. B4's slot asks only what part of what was reported was yours |
| Managed releases with QA | Inflated form of F4 | F4's quote at its own scope. The material says wrote the checklist, not ran each release against it. A5's slot stays inside the checklist |

## Sources

Provided documents: the JD text you pasted; your own description of your background in your message. No CV, recruiter note or interviewer profile was provided. No dossier was present.

Searches sent, all refused (permission to search was not granted in this session):

- "Saltmarsh Games mobile studio values" — refused
- "Saltmarsh Games interview process live operations producer" — refused
- "Saltmarsh Games strategy news mobile titles" — refused
- "Tobias Wrenfield Saltmarsh Games Head of Live Operations" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Every call was refused. Would have fed a values cheat sheet and VAL questions; both are dropped |
| 2. `{company} interview process {role family}` | unavailable | Every call was refused. Would have set the loop and persona weights; the generic archetype with flat weights stands in, and a values-style round is not assumed |
| 3. `{company} strategy` / recent news | unavailable | Every call was refused. Would have fed CO questions and a grounding brief; both are dropped |
| 4. `{interviewer name} {company}` | unavailable | Every call was refused. Would have fed the interviewer read and a reverse question about his path; both are dropped |
| 5. representative `{role title}` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Permission to search the web → rows 1 to 4 above become researched: published values, the documented loop, current strategy and Tobias's public footprint, with CO questions, a grounding brief, a values cheat sheet if a values round exists, and a reverse question tied to his path. A deeper pass (up to 6 more searches and 2 more fetches, several more minutes) is available once, if you want it
- Whether Tobias is your future manager, and anything the recruiter said about focus areas or a task to prepare → persona weights are recomputed and any announced deliverable gets its own build section
- Your CV text → the quoted lines in the fit snapshot are replaced with your own CV sentences, and F1 to F8 are re-graded
- Your own answers to the answer slots on F1, F2, F3, F5 and F8, said in your own words → those rows stop being slots and the matching bank guidance becomes story-mapped
- The release checklist itself, an export of the content calendar, or a retention deck you presented → F3, F4, F6 and F7 can move from medium to high, because those are the artifacts a producer can show
- Time you have to prepare → a prioritized prep schedule sized to it
- A `tuesday-dossier.md` from an earlier session, if you have one → verified evidence and any objections already worked out arrive pre-graded, so the pack needs fewer guesses; it is never a prerequisite
