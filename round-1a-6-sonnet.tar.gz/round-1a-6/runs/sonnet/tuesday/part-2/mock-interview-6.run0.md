Web search wasn't permitted, so I'm building the pack from what you told me and saving it as one file.
Your prep pack for all three rounds is saved as `/var/tmp/tuesday-measure/1a6/runs/sonnet/tuesday/part-2/rooms/case-6-denied-7df4051b/larkfield-systems_engineering-manager_interview_pack.md`.

It has 25 questions: eight for Tuesday, nine for the panel and eight for the VP. Each round has its own persona weights and five reverse questions. A shared fit snapshot, a prohibited-claims list and a prep triage sit above them.

I built it on your message alone. The web searches I tried (values, interview process, strategy) were not permitted. So there is no company research, no values cheat sheet for Monday, and the company-strategy questions are generic. I also assumed the Director is your would-be boss and the VP is senior to them.

Your highest-ROI prep is A1, "Which part of this role would you be weakest at on day one?" Your "never owned a hardware-adjacent roadmap" is the likeliest objection, and every round circles back to it.

- **Drill:** say the word and I'll run a live mock on A1 or any other question.
- **Dossier:** I can save a `tuesday-dossier.md` with the gaps this prep exposed, for later sessions.
- **Word version:** I can convert the pack to a Word document if you want one.

Can you paste the full job description and your CV? Either would turn several rows from inferred to quoted and could change the questions. If you'd rather not, the pack stands as it is.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview prep pack: Engineering Manager, Larkfield Systems (loop of three rounds)

Candidate: Yusuf. Rounds: Tuesday, hiring manager (Director of Engineering, 45 min). The Thursday after, panel (two staff engineers and a product manager, 60 min). The following Monday, VP Engineering (30 min, "values and leadership philosophy" per the recruiter). Interviewer names: not given. Built on your message alone: no full JD, no CV, no company research (see Sources).

## How to use this pack

Personas are how a question is asked; types are what it is scored on. Guidance is scaffolding for a 90 to 120 second spoken answer, not a script. Where guidance says "answer slot", it is an instruction for the interview: answer from your own experience, or say plainly it was not yours.

| Tag | Name | What it is really testing |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows values, not generic virtue |
| EXP | Work-experience deep-dive | Whether your claims survive scrutiny; what was actually you |
| JD | Role / JD-driven | Whether you can do the listed job, including its gaps |
| CO | Company and strategy knowledge | Homework depth (none in this pack: no research ran) |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the role |

## Prep triage

| When | Do these, in order | Why |
|---|---|---|
| Before Tuesday | A1 until it is boring, then A2, C1, C2, B1 | The Director is buying capability and derisking gaps; A1 is the highest-ROI prep in the whole loop |
| Before Thursday | E1, E2, D1, G1, then F1 | The panel tests technical depth and the product seam; E1 covers the one JD line with no evidence yet |
| Before Monday | H1, H2, H3, I1, J1 | A 30-minute values conversation rewards three or four rehearsed stories, not breadth |

Everything else is insurance.

## Fit snapshot (shared across all three rounds)

Requirements are quoted from the role description you gave, which is the only JD text available. Evidence is your own words from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — JD (your role description) | "9 years engineering" — your message; "3 as a team lead of 6" — your message; "never managed managers" — your message | medium | [grounded] | transferability | Your material says a team of six, not two squads, and nothing inspected sits behind it. Words: "Three of my nine years have been as a team lead of 6." If asked about managers under you: "I've never managed managers." Answer slot: the JD's two-squads line makes a probe on how you would split attention across two teams likely. Say how, in your own words; if you have not led more than one team, say so plainly and stay with the team of six |
| F2 | "device-management services" — JD (your role description) | "currently at a payments company" — your message | low | [inferred] | discovery | The quote names the company type, not the work, so the bridge is not stretched. Answer slot: the JD's device-management line makes a probe on what you have built that resembles it likely. If any of your team's services dealt with device-connected systems, say what, in your own words; if none did, say so plainly and stay with the payments work you can describe |
| F3 | "own delivery, hiring and growth for 11 engineers" (the delivery strand) — JD (your role description) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | The sentence carries a reliability quarter pushed through and an on-call figure, not ownership of a team's delivery. Words stay at its scope: "I pushed a reliability quarter through against roadmap pressure." Answer slot: the JD's own-delivery line makes a probe on how you decided what shipped likely. If any of that was yours to decide, say how, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the reliability quarter |
| F4 | "own delivery, hiring and growth for 11 engineers" (the hiring strand) — JD (your role description) | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | presentation | The quote already reaches hiring; lead with it in its own terms: "I run our hiring loop for backend roles." The limit is the pack's observation: the material says the loop for backend roles, not hiring decisions for a team's headcount. The 40 is a figure, so expect the defend-the-number probe in C2 |
| F5 | "own delivery, hiring and growth for 11 engineers" (the growth strand) — JD (your role description) | none given | none | [grounded] | discovery | Nothing in your material speaks to developing engineers, which is not the same as there being nothing. Strong evidence would be a named engineer, what changed in their work, and your part in it. Answer slot: if you helped someone grow into more scope, say who and what changed, in your own words; if you did not, or it was not yours, say so plainly and say what you would do in the first months |
| F6 | "partner with hardware and product on roadmap" (the hardware strand) — JD (your role description) | "never owned a hardware-adjacent roadmap" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F7 | "partner with hardware and product on roadmap" (the product strand) — JD (your role description) | "pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | The quote carries roadmap pressure, not who applied it or a product counterpart. Words stay there: "I pushed a reliability quarter through against roadmap pressure." Answer slot: the JD's product-partnership line makes a probe on who you were working against or with likely. If the pressure came from product, say what each side wanted; if it came from elsewhere, or there was no such counterpart, say so plainly and tell it from the quarter itself |

## Prohibited claims (shared)

Built before the question banks; nothing in the pack coaches these.

| Not coached | Basis | Honest form |
|---|---|---|
| Led two squads or an eleven-person organization | Inflated form of F1 | F1's quote at its own scope; the pack's observation is that the material says a team of six, not two squads. D1 and A2 stay inside that |
| Managed managers | Negative you stated, F1 | The plain acknowledgment F1 gives: "I've never managed managers." No slot |
| Owned a hardware-adjacent roadmap | Negative you stated, F6 | The plain acknowledgment F6 gives: "I've never owned a hardware-adjacent roadmap." No slot |
| Owned a team's delivery | Inflated form of F3 | F3's quote at its own scope; the limit is the pack's observation, not words for you |
| The 60% drop was entirely your doing | Inflated form of F3 | F3's quote as worded, "dropped 60% after I pushed"; C1 and I2 stay on it, with the share of it that was yours as an answer slot |
| Owned hiring headcount for a team | Inflated form of F4 | F4's quote at its own scope: the loop for backend roles |

## Sources and research accounting

Provided documents: your message only (role description, round list, background). No dossier was present.

Searches sent, all refused by the host (nothing returned): "Larkfield Systems values industrial IoT"; "Larkfield Systems interview process engineering manager"; "Larkfield Systems industrial IoT device management strategy news".

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Would have fed a values cheat sheet and VAL questions mapped to named values; the cheat sheet is dropped and R3's VAL questions use persona stems only |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Would have checked your three rounds against documented loop structure; the loop rests on your words and the recruiter's |
| 3. `Larkfield Systems strategy` / recent news | unavailable | Would have fed CO and CASE questions grounded in current strategy; those questions are generic and labeled so |
| 4. `{interviewer name} Larkfield Systems` | n/a | No interviewer name was given, so there was no query to form; no interviewer reads, and the upgrade menu says what names unlock |
| 5. representative Engineering Manager JD | skipped | The role description you gave fixes every fit-snapshot row and JD-tagged question |

The loop is established by your words: three sessions, each with who runs it and its length. The VP round is values-style because the recruiter's own words name it so.

---

# Round 1: Tuesday, hiring manager (Director of Engineering, your would-be boss), 45 min

Assumption: the Director is the person you would report to, so hiring-manager priors apply.

## R1 persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the biggest gap: "weakest on day one", hardware, scale | High. Hiring-manager prior, and F6 is a stated gap against a JD line | Rehearse the single most predictable objection until it is boring; limit said plainly first |
| Case/Strategist | Live problems from the real role: two squads, hardware and product pulling different ways | High. Hiring-manager prior; the role is defined by roadmap partnership | Clarify, objective, options, metrics, risks; think aloud; challenge one premise respectfully |
| Data-Driven Prober | Line-by-line on the two figures you gave | Medium. Any hiring manager who read your background will test the numbers | Know and say how each figure was counted, or say plainly you do not know |

## R1 question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "never owned a hardware-adjacent roadmap"; "pushed a reliability quarter through against roadmap pressure" | The highest-ROI rehearsal in all three rounds. Say the limit first, in your own words: "I've never owned a hardware-adjacent roadmap." Then stop, and hold through two follow-ups by returning to that sentence, never by adding to it. Speak the plan only in the future tense, as what you would do, with specifics you really intend. The nearest thing your material carries is roadmap pressure, not hardware, so say it at that scope or leave it out | F6 is the likeliest place a hiring manager presses; F7 is the only adjacent evidence. JD because it scores the stated roadmap-partnership requirement, delivered as a Skeptic stem |
| A2 | "You'd go from a team of six to two squads and eleven engineers. What changes in how you lead?" | JD | [grounded] "3 as a team lead of 6"; "never managed managers" | Talk about the future in your own words. The past is one sentence: "Three of my nine years have been as a team lead of 6." If asked about managers under you: "I've never managed managers." Answer slot: if the squads have leads of their own, expect a probe on managing them. Say how you would approach it as a plan; if the squads have no such leads, say so and return to the team of six | F1 is the scale step; the JD's two-squads line raises it. JD because it scores the stated requirement |
| A3 | "Why this role, and why now?" | JD | [generic] | No quoted sentence carries a motivation, so this is a selection scaffold. Pick the two reasons that are actually true, each tied to something specific about this role in your own words. If a reason is mostly leaving something rather than wanting this, say that plainly. Do not supply reasons you do not hold | Motivation-consistency is the Skeptic's standing probe; generic because it is a pattern, not a fact about this employer |
| B1 | "A hardware team asks your squads to support a device feature that product has not prioritised. What do you do?" | CASE | [generic] | Clarify first: what the ask is, who needs it by when, what it displaces. Then objective, options, who you would bring into the room, how you would decide and what you would tell each side. Challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | A live problem from the JD's roadmap-partnership line (F6, F7); generic because it is a pattern for the problem |
| B2 | "Your two squads have one quarter and three requests: new device-management features, a reliability backlog, and a deadline set by hardware. How do you decide?" | CASE | [generic] | Same structure: clarify the cost of each request not being met, then criteria, then the decision and what you would say no to. Only if you choose to use your reliability quarter as the example, keep it to the sentence's own scope (see C1) | The JD's delivery strand (F3) in live form; CASE because it tests prioritisation reasoning, not recall |
| B3 | "What would you want to learn in your first 90 days before changing anything?" | CASE | [generic] | A short list in your own words, ordered by what would change your decisions: how the squads are organised, how hardware timing reaches them, how delivery is judged today. No claim about what you have done | Hiring managers use it to see whether a new manager arrives with a plan or a mandate; generic |
| C1 | "The on-call burden dropped 60%. Walk me through how that was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Defend-the-number, in your own words only. Say how the 60% was counted, what it is most sensitive to, the assumption behind it you would defend least, and which part was yours. Where you do not know how it was counted, say so plainly. Keep the sentence's wording, "dropped 60% after I pushed", and do not upgrade "after" to "because" | F3's figure is a magnet target; EXP because it tests attribution |
| C2 | "About 40 interviews last year. How did you count those, and which part of the hiring loop was yours?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Defend-the-number slots in your own words: how the 40 was counted, what it is sensitive to, the assumption behind it you would defend least. Which part of the loop was yours is yours to say; if parts were not, say so plainly and stay with "I run our hiring loop for backend roles" | F4 is the hiring evidence and carries a figure, so it is probed to its assumptions |

R1 reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "What would make the first two quarters a clear success for this role, from where you sit?" | Surfaces what your boss will actually measure, and lets you answer to it |
| R1.2 | "How do product and hardware priorities reach the two squads today, and where does it hurt?" | Turns the roadmap gap in F6 into a conversation about how you would learn it |
| R1.3 | "How are new managers supported on areas outside their experience, such as hardware cycles?" | Shows you plan to close the limit you named in A1 |
| R1.4 | "What would you want me to be strongest at in month one, and what could you cover for me?" | A hiring manager who answers is already sizing the ramp |
| R1.5 | "How do you and the VP of Engineering think about what good looks like for managers here?" | Prepares you for Monday and signals you are thinking at that altitude |

---

# Round 2: the Thursday after, panel (two staff engineers and a product manager), 60 min

Assumption: the staff engineers are technical specialists and near-peers on the work; the product manager is cross-functional. Per the panel rule, personas blend each member's top two; with no names, there are no interviewer reads and no per-member assignment.

## R2 persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Seam-splitting, credit, disagreement with equals | High. Staff engineers are pricing what you add to or take from their work, and the product manager sits on the same seam | Reciprocity framing; propose seam principles, not a claim you know the seam |
| Data-Driven Prober | Technical and numeric depth on what you built and counted | High. Technical specialists verify depth; the domain line F2 has no evidence yet | Say what you can and cannot say about how a number was counted; name your weakest assumption first |
| Values/Behavioral | Product-manager scenario probes about disagreement and trade-offs | Medium. Cross-functional prior; a product manager often scores behavior | Stories where the hard truth landed; where your material shows none, say so |
| Pressure | One staff engineer pushing hard on "why you" | Low. Technical specialist prior, kept to one question | Pause, restate, hold the position through two follow-ups, concede only specifically |

## R2 question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Where is the seam between a staff engineer's calls and yours as the manager, and what happens when we disagree?" | JD | [generic] | Propose principles rather than pretending to know their seam: what you would want to decide, what you would want them to decide, how a disagreement gets raised. Offer what you would bring them, not only what you need. No claim about your past | Peer stem; the JD's two-squads line (F1) is why the seam matters; generic because it is a pattern |
| D2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Your approach in one or two sentences. If you have a true example, tell it in your own words; none of your quoted material carries one, so if none comes to mind, say so plainly and give how you would handle it | Peer-evaluator stem scoring partnership fit; generic |
| D3 | "Tell me about a time you disagreed with a senior engineer." | VAL | [generic] | Selection scaffold: pick a disagreement with a named stake, where you held your view without making it personal and the working relationship was intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Peer stem on disagreement with equals; no quoted sentence carries it, so a scaffold |
| E1 | "What parallels do you see between your payments services and a device-management service?" | JD | [inferred] "currently at a payments company" | Say what you see in your own words, as comparison rather than experience. Answer slot: if any of your team's services dealt with device-connected systems, say what; if none did, say so plainly and stay with the payments work you can describe. Never claim IoT experience the material does not show | F2 is the thinnest row against a JD line and the staff engineers will test it; JD because it scores the stated requirement |
| E2 | "Walk us through the reliability quarter you pushed through." | EXP | [grounded] "pushed a reliability quarter through against roadmap pressure" | The beats the sentence states: a reliability quarter, pushed through, against roadmap pressure. Tell them in your own words. Answer slot: the JD's roadmap line makes a probe on how the quarter was chosen likely. If you set the criteria, say how; if there were none, or they were not yours, say so plainly and stay with the quarter | F3 and F7 are your strongest story and the likeliest depth probe; EXP because it tests what was actually yours |
| E3 | "What would you want to understand about our device-management services before changing how the squads work?" | CASE | [generic] | A short list ordered by what would change a decision: how failures reach the team, how change gets released to devices in the field, what the squads own end to end. Questions, not claims about what you know | Tests clarify-first thinking on the role's own domain; generic |
| F1 | "Tell me about a time you and a product partner wanted different things." | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" | Story-map only the sentence's beats: a reliability quarter and roadmap pressure. Answer slot: if the pressure came from product, say what each side wanted and how it ended; if it came from elsewhere, or there was no product counterpart, say so plainly and tell it from the quarter | The product manager's seam question (F7); the JD's product-partnership line raises the theme |
| F2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where a named customer need and a measure you were held to pointed different ways, and say what you chose and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem for a cross-functional scorer; no quote carries it |
| G1 | "Sixty seconds: why you over a candidate who has already run a hardware roadmap?" | JD | [grounded] "never owned a hardware-adjacent roadmap"; "3 as a team lead of 6" | Pause, restate. Hold only what the quotes carry, at their scope: "Three of my nine years have been as a team lead of 6." Concede specifically and early: "I've never owned a hardware-adjacent roadmap." Hold the rest through two follow-ups without adding to it | Pressure stem aimed at F6; JD because it scores the stated roadmap-partnership requirement |

R2 reverse questions

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "What could a new manager do in their first month that would genuinely help your work?" | Reciprocity question for the staff engineers; shows you are pricing your cost to them |
| R2.2 | "Where do technical decisions get made on the squads, and where should a manager stay out?" | Opens the seam conversation on your terms |
| R2.3 | "Where does hardware timing show up in the product roadmap, and who owns that conversation today?" | For the product manager; turns F6 into learning |
| R2.4 | "How do disagreements between product, hardware and engineering get resolved today?" | Shows partnership thinking and gives you the real process |
| R2.5 | "What is one thing a new manager would be wise to stop or start doing, from where you sit?" | Invites candour and shows you intend to adjust |

---

# Round 3: the following Monday, VP Engineering, 30 min, "values and leadership philosophy"

Assumption: the VP is senior to your Director, so skip-level and dedicated-values priors blend. In 30 minutes expect three or four questions, so depth beats breadth.

## R3 persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario probes on values and leadership; STAR-shaped stories | High. The recruiter's own words name this round values and leadership philosophy | Where a quoted sentence carries a story, map it; where none does, a scaffold with its honest branch |
| Pressure | Altitude and composure; time-boxed answers | Medium. Executive prior | Pause, hold through two follow-ups, concede specifically |
| Conversational | Open "walk me through" opener | Low-medium. A short round often opens this way | A pre-scripted 90-second arc from your own sentences |
| Case/Strategist | One question at the company's altitude | Low. Executive prior, but no strategy research ran | Clarify, then think aloud |

## R3 question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" | Story-map the sentence's beats only: a reliability quarter pushed through against roadmap pressure. Answer slot: if the pressure came from leadership and you told them something unwelcome, say what and how it landed; if the pressure came from elsewhere, or no one in leadership was involved, say so plainly and use the nearest thing your material does carry | Persona stem for a values round; F7 is the only quoted story with pressure in it |
| H2 | "How would you describe your leadership philosophy?" | VAL | [grounded] "3 as a team lead of 6" | The recruiter's own wording raises this. Selection scaffold: choose two or three principles you actually practice and for each give one sentence of what you did, in your own words. If a principle is an aspiration rather than a practice, say that plainly. Your leadership history, said at its scope: "Three of my nine years have been as a team lead of 6" | The recruiter named it; a philosophy with no behavior behind it is what a VP probes |
| H3 | "Tell me about a time you helped someone on your team grow." | VAL | [generic] | No quoted sentence carries this (F5), so a scaffold: a named engineer, what changed in their work, your part in it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would do it as a plan | The JD's growth strand; generic because nothing in the material speaks to it |
| H4 | "Tell me about a time a hiring call didn't go the way you expected." | VAL | [grounded] "I run our hiring loop for backend roles" | Open prompt; pick a real instance and say what you learned and changed in the loop. If none comes to mind, say so plainly and say what you watch for in the loop you run | The JD's hiring strand; the VP tests judgment more than process |
| I1 | "Sixty seconds: why should an industrial IoT company trust a payments engineer with two squads?" | JD | [grounded] "currently at a payments company"; "3 as a team lead of 6"; "never owned a hardware-adjacent roadmap" | Pause and restate. Hold what the quotes carry: "Three of my nine years have been as a team lead of 6." Concede early and specifically: "I've never owned a hardware-adjacent roadmap." Hold through two follow-ups by returning to what you said, not adding to it | The same objection as A1 at executive altitude; Pressure stem |
| I2 | "You pushed a reliability quarter through against roadmap pressure. Looking back, would you make the same call?" | EXP | [grounded] "pushed a reliability quarter through against roadmap pressure" | Hold the call as the sentence states it. Concede specifically, in your own words, anything about the call you would do differently. Answer slot: if there was a cost to the call, say what; if there was none, say so plainly | Pressure and values blended; EXP because it tests ownership of a decision |
| J1 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering"; "3 as a team lead of 6"; "currently at a payments company" | A 90-second arc built only from these sentences: nine years in engineering, three of them as a team lead of 6, now at a payments company. Why this role is an answer slot: say your actual reasons, in your own words, and do not supply any here | Short rounds often open this way and the casual register is still scored |
| K1 | "What does good look like for your two squads in a year?" | CASE | [generic] | Describe outcomes you would want to be held to and how you would find out whether you are getting there, in your own words. Clarify what the company needs from the squads first. No claim about your past | The only altitude question; generic because no company strategy research ran |

R3 reverse questions

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "Which of the company's values gets tested hardest in engineering, and how do you see it show up?" | Shows you listened for values in practice, and gives you real material for the values conversation |
| R3.2 | "What do you want engineering managers to be known for across the company?" | Lets you answer to the VP's own standard |
| R3.3 | "Where is the biggest gap between how engineering works with hardware today and how you would like it to?" | Altitude question that connects to F6 without admitting more than you said |
| R3.4 | "How do you develop managers here, and what does growth look like for someone in this seat?" | Signals ambition and respects the limit you named on managing managers |
| R3.5 | "What should I understand about where the company is heading that I could not learn from outside?" | Fills the gap that no company research ran, with the best source |

---

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| "Lead two squads building device-management services" | A2, D1, I1 |
| "device-management services" | E1, E3 |
| "own delivery" | B2, E2, I2 |
| "hiring" | C2, H4 |
| "growth" | H3 |
| "partner with hardware" | A1, B1, G1 |
| "partner with ... product on roadmap" | B1, F1, D1 |

## Upgrade menu

- Full JD text → the seven rows above become quoted from the real posting, and requirements the role description does not show get their own questions
- Your CV or resume → more rows get an evidence quote, and the stories in H1 to H4 map from your own sentences instead of scaffolds
- Search permission, or a pasted copy of Larkfield's published values page → a values cheat sheet for Monday, and VAL questions mapped to named values
- A pasted recruiter or interviewer note on the loop → confirms the three-round structure and the VP's skip-level relationship
- Interviewer names (any of the four) → per-person reads and persona weights from their public professional footprint, and a reverse question tied to their path
- A strategy brief or deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → CO and CASE questions grounded in the company's current strategy
- A tuesday-dossier.md from an earlier decision about this role → verified evidence and any prohibited claims, replacing the locally built list
