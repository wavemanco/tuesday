All six web searches were refused, so I'm building the pack from your message and the recruiter's words alone. I'm writing it to a file now.
Your prep pack is saved as `kelverton-rail_senior-partnerships-manager_interview_pack.md`. I built it for the panel as the recruiter described it: Deepa as hiring manager, Ross on commercials, a 15-minute POV, then Q&A. All six web searches were refused, so it rests on your message and the recruiter's words. I couldn't see the market report or a job spec, so anything not from your message is labeled `[generic]`.

- **POV build (section 5):** three thesis options, each with a concession you say aloud. It also covers how to depart from the report rather than recite it, an anti-pick, a minute map, and a close on what it means for the operators.
- **Highest-ROI prep:** B2, "you've never carried a direct quota". Name the limit yourself before Ross asks. Rail (F5) is the other stated gap, handled in B1, B4 and D1.
- **Your two numbers:** the £4M and the 6 to 40 each get a defend-the-number question (C1, C2). I supplied no counting method, since your message gives none. Where you don't know how something was counted, the pack says so plainly.

The pack has 21 questions across seven personas, a four-session weekend schedule, and the reverse questions. It also has a list of claims it won't coach, and the upgrade menu.

Say the word and I'll play Skeptic on B2.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed.
If you'd like the pack as a Word document, say so and I'll convert it.

If you can paste the report's sections on operators and partnerships, and the job spec, the strategy questions and the POV build become grounded. Or say skip and the pack stands as is.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview prep pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, Tuesday. A 60-minute panel: Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). The first 15 minutes are your spoken POV, no slides. The rest is Q&A, and Ross will push on commercials. Source: the recruiter's email, as you quoted it.

**What this pack is built on:** your message and the recruiter's words. The market report and a job spec were not in this conversation, and the web searches were refused. Anything not traceable to your message is labeled `[generic]`, and the upgrade menu says what each missing input would change.

## 2. How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding, not a script. Every line of guidance is proposed language, pending your approval: edit it into your own words, and say only what you actually did.

An answer slot is an instruction for the interview, not a question for this conversation. It gives you two honest branches, and the second always allows that the practice never existed or was not yours.

| Tag | Name | What it scores |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the values an employer cares about, not generic virtue |
| EXP | Work-experience deep-dive | Whether your CV claims survive scrutiny, and what was actually yours |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge | Homework depth, and thinking at the company's altitude |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the actual role |

Question IDs skip the letter F so they never collide with fit-snapshot rows (F1 to F5).

## 3. Prep triage (four hours)

| Session | Time | Do this | Tied to |
|---|---|---|---|
| 1 | 60 min | Re-read the report with one job: find the single recommendation any prepared candidate would repeat, and one place you would depart from it. Pick one of the three theses. Draft the operator close first, then the rest. | Section 5, A1, A4 |
| 2 | 60 min | Say the POV aloud twice against a timer. Aim for 12 to 13 minutes. Cut material rather than speed up. | Section 5, A1, A5 |
| 3 | 60 min | The highest-ROI prep in this pack: B2 and its three follow-up levels. Then write, in your own words, your answers to the four number slots on the £4M and the 6 to 40, or write plainly that you do not know. | B2, C1, C2, D2, D3 |
| 4 | 60 min | Have someone play Skeptic and Pressure on B1, B4, D1. Choose three reverse questions. | B1, B4, D1, section 11 |

Everything else in this pack is insurance.

## 4. Fit snapshot

Requirements are quoted from the recruiter's email as you gave it. Where no supplied document states a requirement, it is plain prose and carries no answer slot.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" — recruiter's email | "9 years in partnerships, last 4 at a payments company running the ISV channel" — your message; "took it from 6 partners to 40" — your message | medium | [grounded] | transferability | Your material says the ISV channel, not operator partnerships, with nothing inspected behind it, and the words stay there: "For four years I ran the ISV channel at a payments company, and I took it from 6 partners to 40." Answer slot: the recruiter's phrase "operator partnerships" makes a probe on what carries over from an ISV channel likely. If a parallel is real, say what it is and where it stops, in your own words; if you see none, say so plainly and stay with the channel you ran |
| F2 | "Please land on what it means for the operators themselves" — recruiter's email | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Your material says bus and light rail network planning, and "the other side" without saying whose side. The words stay at that scope: "I spent five years in transport consulting, on bus and light rail network planning." Answer slot: the recruiter's close on the operators makes a probe on what operators care about likely. If the consulting work gave you a view, say what it was and which operators it concerned; if it did not reach train operating companies, say so plainly and stay with bus and light rail |
| F3 | "Ross will push on commercials" — recruiter's email | "roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | The figure stays at its words: "roughly £4M of influenced revenue." Nothing is inspected behind it, so expect a probe. Answer slot: expect questions on how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. Answer each in your own words; "I don't know how it was counted" is an honest answer |
| F4 | Commercial accountability for a number (role-family expectation; no supplied document states it) | "never carried a direct quota, only influenced revenue" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never carried a direct quota, only influenced revenue." Then how you would approach carrying one, said as a plan and never as a past. Never a claim to owned revenue, and nothing added to make the gap feel smaller |
| F5 | Experience selling into rail (role-family expectation; your message says Kelverton sells scheduling software to train operating companies) | "Never sold into rail specifically" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never sold into rail specifically." The adjacent work sits on F2 at F2's scope; neither row is stretched to cover the other. Then how you would learn it, said as a plan and never as a past |

No row is a gate. Neither your message nor the recruiter's email states a term such as location, travel, pay band or right to work. If the job spec carries one, it appears as its own row on a re-run.

**Requirement coverage** (what the recruiter's email and your message state, not a full posting):

| Requirement | Questions that cover it |
|---|---|
| F1: where you would take operator partnerships | A1, A2, A3, A4, A5, G1, G2 |
| F2: what it means for the operators | A1, A2, A3, B1, G1 |
| F3: commercials | B2, C1, C2, C3, D2, D3, E1 |
| F4: commercial accountability | B2, B4, C3, D3 |
| F5: rail | B1, B3, B4, D1 |

## 5. Graded deliverable: the 15-minute POV

The brief as the recruiter wrote it: talk them through where you would take operator partnerships over the next 18 months, no slides, and land on what it means for the operators themselves. The pack has not seen the report, so the build gives you the structure, and the report's content comes from you.

**Proposed language, pending your approval.** Your own sentences are quoted below. Nothing else about your past appears in this section.

**Grounded facts to build on**

| Fact | Where it comes from | Use in the talk |
|---|---|---|
| "9 years in partnerships, last 4 at a payments company running the ISV channel" | F1 | The opening, in one sentence, at its own scope |
| "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | F2 | The second sentence of the opening. Say bus and light rail as such, and say which side you mean |
| "took it from 6 partners to 40" | F1 | Once at most, only if it supports a point. It counts partners, and C2 will probe it |
| "never carried a direct quota, only influenced revenue" | F4 | Name this limit yourself before Ross asks. It is the weakest-assumption move for this loop |

**Three thesis options.** Each carries a concession you must say aloud. All three are `[generic]` patterns until you test them against the report. Pick the one the report lets you defend.

| Thesis | What it means for the operators (your close) | Mandatory concession | Provenance |
|---|---|---|---|
| 1. Start from what an operator could say has changed, then work back to which partners | Each partnership is tied to one change an operator would recognise in their own terms, and has one named counterpart at Kelverton | It narrows the partner count, so headline growth is slower. It also assumes Kelverton can see operator-level results, which your material does not show | [generic] |
| 2. Go deep with a few operators before going wide | Operators spend their time on a few partnerships that work, not many that need attention | Your own history is stated in partner counts ("took it from 6 partners to 40"). Say that counting partners may be the wrong measure here, and that you do not yet know the right one | [generic] |
| 3. Make each partnership measurable for the operator and for commercial | An operator can tell, in their own terms and within 18 months, whether the partnership delivered | It commits Kelverton to being judged on the measure, and you cannot set the measures from outside. They depend on data you have not seen, and you have never carried a direct quota | [generic] |

**Differentiation against the report.** The report was written by their own strategy team, so reciting it back scores as homework.

1. Bring one consensus item, the single recommendation any prepared candidate would draw from it, in one sentence and in the report's own terms. That proves grounding.
2. Then depart from it with a reason that is your own judgment. Do not cite a figure from memory.
3. Do not correct the report. Extend it or weigh it differently, and point to the sentence you mean.

**The anti-pick.** The role includes saying no. Name one thing the report's direction might invite that you would not do within 18 months, and say why. Concede the revenue you would leave on the table (see A5).

**The requested close.** Finish on what it means for the operators themselves. State what an operator would see differently by month 6, 12 and 18, in the operator's terms. If time runs short, cut anything except this.

**Minute map (aim for 12 to 13 minutes, leaving room for interruptions)**

| Time | Beat |
|---|---|
| 0:00 to 1:00 | Opening: your two sentences at their own scope, your one-sentence thesis, and where you will land |
| 1:00 to 3:00 | The report: the consensus item, then where you depart from it |
| 3:00 to 8:00 | The thesis and the 18 months. State what you would need to learn first as questions, not as facts about operators |
| 8:00 to 10:00 | The anti-pick, with its cost |
| 10:00 to 12:00 | What it means for the operators: the close |
| 12:00 to 13:00 | Name your limit before they do: "I've never sold into rail specifically" and "I've never carried a direct quota, only influenced revenue." Invite their push |

## 8. Persona table

The loop is established by the recruiter's email: one 60-minute panel, with a POV and then Q&A. No archetype fallback applies. No loop source names a values-style round, so none is detected and the pack has no values cheat sheet. There were no interviewer profiles, so weights rest on relationship priors and the recruiter's note only.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (A, weight 5) | The POV itself, then live problems on the partnerships roadmap | High. Deepa is your future manager, which sets Case/Strategist and Skeptic as dominant. The POV is a case you deliver | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully |
| Skeptic (B, weight 4) | Deepa probing the rail and quota gaps and the sector switch | High. Same relationship prior. F4 and F5 are gaps you stated yourself | Rehearse the single most predictable objection until it is boring. Bridge only from what you stated, and plainly acknowledge the limit |
| Data-Driven Prober (C, weight 3) | Ross on how the numbers were counted | Medium. The recruiter says Ross will push on commercials, and F3 is the only figure he has to push on | Know what you can and cannot say about how each number was counted. Say plainly when you do not know |
| Pressure (D, weight 3) | Time-boxing and devil's advocate from Ross | Medium. "Push" is the only signal. Ross's relationship to you is not stated | Pause, restate, anchor in what you stated. Hold a challenged position through two follow-ups before conceding anything real |
| Peer Evaluator (E, weight 2) | The seam between partnerships and commercial | Low to medium. Ross leads commercial, which touches Deepa's team, but how he sees the seam is unknown | Offer seam principles rather than pretending to know the seam. Show what you bring commercial |
| Conversational (G, weight 2) | An opening "walk me through" before the POV or after it | Low to medium. Any panel opens warmly, and the question is still scored | Prepare a 90-second arc. Treat casual questions as scored |
| Values/Behavioral (H, weight 2) | Scenario probes | Low. No values-style round is named anywhere in the material | Where no story comes to mind, say so plainly, then give the nearest thing or how you would handle it |

## 9. Question banks

### A. Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Take us through where you'd take our operator partnerships over the next 18 months, and what that means for the operators themselves." | CASE | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | The build is section 5. Open with your two quoted sentences at their own scope and tell them in your own words, with no beat added. Then the thesis, then the anti-pick. Finish on the operator close, whatever else you cut | The announced deliverable, asked live. F1 and F2 are the evidence it rests on, and F4 and F5 the limits to name. CASE because it scores structure, JD because it is the stated task |
| A2 | "Where would an operator's priorities and ours pull apart, and how would you decide which to follow?" | CASE | [generic] | Say what you need to know first: which operators, which priority, what the report says. State the objective, split the problem by the questions you would ask, never by claims about operators, then give the approach, the measure and the risk. Challenge one premise politely, such as whether the two are separable. The question needs no claim about your past, so the guidance makes none | Tests whether the candidate reasons from the operator's side, which the recruiter's close names (F2). `[generic]` because it is a pattern for the problem |
| A3 | "Imagine a partnership has gone quiet six months in, and the operator it was meant for says it isn't helping. What do you do first?" | CASE | [generic] | Structure it: who you talk to first (the operator), what you would ask, how you decide between repairing and stopping, and what you would record. Show you would be willing to stop one. This links to A5. No claim about your past is made | A live problem from the operator-first brief (F2). `[generic]` because it is a pattern, not a fact about Kelverton |
| A4 | "What in the report would you challenge, and what did you find missing?" | CO | [generic] | The pack has not seen the report, so use your own reading. Bring one point you would extend and one you would weigh differently, each tied to a sentence you can point to. Do not correct a number. Do not recite the consensus beyond one sentence | CO question on the document the recruiter sent. `[generic]` until the report is pasted. F1 is what it feeds. The differentiation rule in section 5 applies |
| A5 | "What would you decline to do over the next 18 months?" | CASE | [generic] | Name one thing, give the reason, and state its cost, meaning the revenue or goodwill you would give up. Hold it through one challenge, then concede what you do not know. The guidance makes no claim about your past | The anti-pick, which the role earns by including the word no. F1 is the requirement it scores. CASE for the reasoning, JD for the stated role |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't sold into rail. What would you have to learn first, and how fast?" | JD | [grounded] "Never sold into rail specifically"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Words: "I've never sold into rail specifically." Then the adjacent work, quoted at its scope, with bus and light rail said as such. Then a ramp plan in the future tense: the two or three things you will learn first, in your own words. Answer slot: if the consulting work gave you a working view of what operators need, say what it was and which operators; if it did not reach train operating companies, say so plainly and stay with bus and light rail network planning | F5 is the likeliest opening for a skeptic. The adjacency is F2's, and no further. JD because the role sells into rail |
| B2 | "You've never carried a direct quota. Why should we trust you with commercial accountability here?" | JD | [grounded] "never carried a direct quota, only influenced revenue"; "took it from 6 partners to 40"; "roughly £4M of influenced revenue" | **The highest-ROI rehearsal in this pack.** Name the limit yourself before it is asked: "I've never carried a direct quota, only influenced revenue." Hold at the quotes' words: "took it from 6 partners to 40, roughly £4M of influenced revenue." Three follow-up levels are likely. The first presses on whether the influenced figure would have happened anyway. The second asks how you would behave carrying a number rather than influencing one. The third asks why Kelverton should take the risk on you. At each level, hold at the quote's scope and concede only what you can name. Answer slot: if you were ever held to a target of any kind, say what it was and who set it; if not, say so plainly and return to the channel. Never claim you are used to targets | Ross has been told to push on commercials, and F4 is the stated gap, so this arrives in some form. Held in the quotes' own words so the second follow-up does not break it. JD because it scores the requirement |
| B3 | "Why leave payments for rail-tech, and why now?" | EXP | [generic] | Your material gives no reason, so the pack supplies none. Answer slot: say your actual reason in your own words, one you would still give on a third asking and one specific enough to be tested; if you have no reason beyond wanting this role, say so plainly. Do not rehearse enthusiasm you cannot back with a specific | F5 makes the sector switch the likeliest motivation probe. EXP because it tests whether your story survives cross-examination |
| B4 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically"; "never carried a direct quota, only influenced revenue" | Choose one of your two stated limits, the one you think is weaker, and name it before they do. Say what you will do about it in the first weeks, as a plan. Answer slot: if a third area would be weaker than these, say so; your material shows only these two | F4 and F5 are both on the table, and this is the stem that asks you to rank them. JD because it scores honest self-assessment against the listed job |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the roughly £4M of influenced revenue was counted." | EXP | [grounded] "roughly £4M of influenced revenue" | Answer slot: say how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours, each in your own words. If you did the analysis yourself, offer to walk them through it end to end; if someone else's analysis produced it, say whose. "I don't know how it was counted" is an honest answer. Never name a method you did not use | F3 is a headline figure, and figures draw this probe |
| C2 | "Walk me through the 6 to 40: what counted as a partner?" | EXP | [grounded] "took it from 6 partners to 40" | Answer slot: say what counted as a partner, what the count is sensitive to, the assumption you would defend least, and which part of that growth was yours, in your own words. If you do not know how it was counted, say so plainly | F1 holds the second headline number. EXP because it tests attribution |
| C3 | "If we asked you to put a number on operator partnerships over 18 months, what would you measure and how would you defend it?" | CASE | [generic] | Propose the measure in the operator's terms and Kelverton's, name the assumption you would defend least before they ask, and say plainly what data you would need that you do not have. Do not state a figure unless the report gives one you can cite. As you have never carried a direct quota, say who you would need to agree the measure with | This is where F3 and F4 meet a forward-looking question. CASE because it scores structure |

### D. Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has sold into rail?" | JD | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel"; "took it from 6 partners to 40"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"; "Never sold into rail specifically" | Three beats, the three quoted clauses in that order, told in your own words. Then concede at once: "I've never sold into rail specifically." Do not argue you are better; say what you bring and what you lack, and stop at sixty seconds. If pressed twice, hold the three clauses and concede the rail point plainly | F5 is the gap this stem presses on, and F1 and F2 are what you hold. JD because it scores fit against the role |
| D2 | "That growth from 6 to 40: how much of it was actually you?" | EXP | [grounded] "took it from 6 partners to 40" | Hold that the sentence is yours as written, "took it from 6 partners to 40", through two follow-ups, returning to it rather than adding to it. Answer slot: say which part of that growth was yours and, if others carried parts, say who and which; if you cannot separate them, say so plainly. Concede only what you can name | F1 is the figure being pressed. The attribution probe is the one Pressure interviewers use against numbers |
| D3 | "Influenced revenue isn't revenue. Why should that count for anything here?" | JD | [grounded] "roughly £4M of influenced revenue"; "never carried a direct quota, only influenced revenue" | Concede the definition first, in your own words: "I've never carried a direct quota, only influenced revenue." Hold the figure at its scope, "roughly £4M of influenced revenue", and no wider. Answer slot: if you know how the business counted it, say so; if you do not, say so plainly | F3 and F4 together are the commercial challenge the recruiter flagged. JD because it scores the commercial requirement |

### E. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Where's the seam between partnerships and commercial, and what happens when we disagree about a deal?" | JD | [generic] | Offer seam principles instead of pretending to know the seam, and say what you bring commercial, not just what you need. Answer slot: if a real disagreement with another function comes to mind, tell it in your own words and say which part was yours; if none does, say so plainly and give the rule you would propose | Ross leads commercial, so the seam is his ground (F3). `[generic]` because it carries no claim about your past |
| E2 | "How do you handle credit when work spans teams?" | VAL | [inferred] "roughly £4M of influenced revenue" | Selection scaffold: pick a time credit was shared, with a named stake, what you said, and how it left the relationship. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: the figure at its own words. Say only what "influenced" covers, and no more | F3's word "influenced" is the adjacent evidence, so the label is `[inferred]`. VAL because it scores partnership behavior |

### G. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So — walk me through the journey." | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"; "9 years in partnerships, last 4 at a payments company running the ISV channel" | A 90-second arc in your own words: beat one is the consulting sentence, beat two the partnerships sentence. Answer slot: if a thread connects them, say it in your own words; if there is no single thread, say so plainly and tell the moves in order. End on what brings you to this role, in your own words | F2 and F1 are the two sentences the arc is built on, and no beat goes beyond them. EXP because it tests whether the story hangs together |
| G2 | "Who would you want to talk to in your first month, and what would you ask them?" | CASE | [generic] | Choose by the questions you need answered, not by claims about who exists inside Kelverton or its operators. Name categories of people and one question for each. This is your ramp plan said aloud | A scored ramp-plan question in a casual register, tied to F5. `[generic]` because it supplies nothing about this employer |

### H. Values/Behavioral (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: it needs a named stake, a moment you said the hard thing, and an intact relationship afterwards. Your material carries no such story, so the pack supplies none. If no such time comes to mind, say so plainly, then give the nearest thing from your own history or say how you would handle it | A persona stem at low weight, as no values round is named. VAL because it scores behavior |
| H2 | "When did you put a partner's interest ahead of an internal metric?" | VAL | [generic] | Same scaffold: a named stake, the decision, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing from your own history or say how you would handle it | The operator-first brief (F2) makes this a natural values question. `[generic]` because your material carries no story for it |

## 11. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would make you say, three months in, that this hire is working, and what would make you say it isn't?" | It asks for the bar in advance, and shows you intend to be measured |
| R2 | "When the report went round internally, which part did people disagree with most?" | It signals you read it as an argument, not as scripture, and often gets the live debate |
| R3 | "How are operator partnerships measured against commercial targets today, and who owns the number?" | It surfaces the quota expectation you named in B2 and puts the commercial seam on the table |
| R4 | "Which operator relationships would you want this person to inherit, and which to build?" | It separates the ramp from the build, and shows you plan for both |
| R5 | "What do operators say they want more of from Kelverton?" | It keeps the panel on the operators themselves, as the recruiter asked |
| R6 | "What would you want to be true at month 18 for this to count as the right hire?" | It mirrors the POV's horizon and invites the panel to say it aloud |

## 13. Prohibited claims

Built before the banks, so the banks are written against it. It is present in every pack, so you can tell a pack that found nothing to inflate from one that inflated nothing.

| Not coached | Basis | Honest form |
|---|---|---|
| Having sold into rail | Negative you stated, F5 | The plain acknowledgment: "I've never sold into rail specifically." No slot |
| Having carried a quota, owned revenue or closed deals | Negative you stated, F4 | The plain acknowledgment: "I've never carried a direct quota, only influenced revenue." No slot |
| Generated, sourced or closed roughly £4M | Inflated form of F3 | F3's quote at its own scope: "roughly £4M of influenced revenue". The limit is the pack's observation: your material says influenced, not generated or closed |
| Built the partner programme, or recruited the new partners yourself | Inflated form of F1 | F1's quote at its own scope: "took it from 6 partners to 40". The limit is the pack's observation: your material says the count moved, not who recruited the partners or designed the programme |
| Knowing train operating companies from the inside, or having worked on heavy rail scheduling | Inflated form of F2 | F2's quote at its own scope: "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)". The limit is the pack's observation: your material says bus and light rail, and does not say whose side |

## 14. Sources

**Provided documents:** your message (your background, the round, and the recruiter's email as you quoted it). The market report is named in your message but its contents were not in this conversation, so nothing here is drawn from it. No dossier was present.

**Searches sent (all refused, so none returned a result):**

| Query | Outcome |
|---|---|
| Kelverton Rail values | refused |
| Kelverton Rail interview process partnerships | refused |
| Kelverton Rail strategy scheduling software train operating companies news | refused |
| Deepa VP Partnerships Kelverton Rail | refused |
| Ross Commercial Director Kelverton Rail | refused |
| Senior Partnerships Manager job description rail technology UK operator partnerships | refused |

Research tier: L1 — searches 6 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Search permission was not granted. It would have set published value names for VAL themes. It could not have created a values cheat sheet, since no values-style round is detected |
| 2. `Kelverton Rail interview process partnerships` | unavailable | Search permission was not granted. It would have confirmed the panel's structure. The recruiter's email already fixes this session |
| 3. `Kelverton Rail strategy` and recent news | unavailable | Search permission was not granted. It would have grounded A2 and A4 and enabled a grounding brief |
| 4. `Deepa` and `Ross` with title and company | unavailable | Both calls were refused. It would have enabled an interviewer read and a tailored reverse question |
| 5. Representative `Senior Partnerships Manager` JD | unavailable | Search permission was not granted. It would have supplied quoted requirements for more fit rows |

## 15. Upgrade menu

- The job spec text → the fit snapshot gets quoted requirements instead of role-family prose on F4 and F5, and any gate (location, travel, pay band) surfaces as its own row
- The report's sections on operators and partnerships, pasted → a grounding brief becomes possible, A2 and A4 become `[grounded]`, and section 5 names the consensus item and the anti-pick from the report itself
- Public profiles for Deepa and Ross, pasted → an interviewer read, persona weights from their paths, and a reverse question tied to each
- Your own words on how the £4M and the 6 to 40 were counted, what carries from bus and light rail to operators, and what drew you to rail → C1, C2, D2, D3, B1, B3 and G1 become story-mapped
- Search access → values, loop structure and strategy research at L1, and an optional deeper pass of up to 6 more searches and 2 more fetches, several more minutes
- A `tuesday-dossier.md` → verified evidence, an evidence-based top objection and prohibited claims arrive from an earlier analysis, not as a prerequisite
