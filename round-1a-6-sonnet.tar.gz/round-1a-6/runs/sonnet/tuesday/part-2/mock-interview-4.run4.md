The search permission was refused, so I'm building the pack from your dossier alone. I'm writing the prep file now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a6/runs/sonnet/tuesday/part-2/rooms/case-4-denied-1375d540/quartzline_product-manager-platform-apis_interview_pack.md`. It has 21 questions, the fit snapshot, persona weights, six reverse questions and a prohibited-claims list.

I built it as one hiring-manager session, using the persona mix that round type usually gets: Skeptic and Case/Strategist lead, with the Skeptic first.

- **Top priority:** rehearse A1 until it feels dull, since it's the highest-ROI question. It's the dossier's own objection ("never held the PM title or owned a roadmap"). Start with the plain acknowledgment, then give the integration work at its quoted scope, then a ramp stated as a plan.
- **Roadmap gap:** answer A2 ("weakest on day one") with a straight acknowledgment and no bridge. The dossier marks roadmap ownership as `acknowledge_gap`, so don't use the roadmap-input sessions to cover it.
- **Weak spots:** the roadmap-input sessions (C2) are only medium confidence, so say what they covered before the interviewer asks. Expect pressure on the "30+ integrations" count (C1 and F2) and on shipped-product and API-docs experience (A3 and A4).
- **Reverse questions:** your two dossier questions on decision authority and the adoption baseline lead, followed by four more.
- **Research failed:** the three web searches were refused, so nothing in the pack comes from Quartzline itself. The company-knowledge and values-style questions (B4, D3, G1, G2) are generic, and there's no values cheat sheet. Pasting their careers page or developer docs would fix that.

The pack has no prep-time triage because you didn't say how much time you have.

Offers, none required:
- I can run a live drill of A1 as the Skeptic.
- I can save an updated `tuesday-dossier.md` recording the gaps this prep exposed.
- I can convert the pack to a Word document.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview pack: Product Manager, Platform APIs at Quartzline

Round: a 45-minute conversation with the hiring manager, on Thursday. Interviewer name: not given. Built as one session in session mode.

## How to use this pack

- Personas are how a question is asked. Types are what it scores.
- Types: **VAL** is values alignment. **EXP** is a work-experience deep-dive. **JD** is role or requirement driven. **CO** is company and strategy knowledge. **CASE** is a live problem.
- Guidance is scaffolding, not a script. Every sentence about your past in a cell is quoted from your dossier in that row's Provenance column. Where a cell says "Answer slot", it tells you what the interviewer is likely to probe and gives you two honest branches. It does not tell you what to say.
- The highest-ROI rehearsal is A1. The underwriter named that objection from evidence you confirmed, and the pack gives it the deepest rehearsal.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | low | [grounded] | transferability | Adjacent work only, and the words stay at the quotes' scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs." The underwriter's limit binds: the bridge is positioned as adjacent, never as product management experience. The plain acknowledgment is sourced by the dossier's prohibited_claims field: "I haven't held a product manager title." The second quote is confirmed with limited inspectable proof, so expect a probe on it and say what it covers before it is extracted |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibilities | none given | none | [grounded] | capability | The dossier records this as an acknowledge_gap area, so there is no bridge and no slot. Words, sourced by that field and by prohibited_claims: "I haven't owned a roadmap." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F3 | "Shipped API or platform products" — dossier role_profile R2 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [inferred] | transferability | The dossier does not grade R2 separately, so this row is the pack's derivation from the one quote. The quote says client integrations of the vendor's APIs, not releasing the API product itself, and the words stay there. Answer slot: the JD's shipped-products line makes a probe on the API's own release likely. If any part of that release was yours, say which part and how, in your own words; if none was, say so plainly and stay with the integrations |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | low | [inferred] | discovery | Both quotes touch REST APIs and a written artifact, and neither says whether API docs or schemas were part of the work. Answer slot: the JD names API docs and schemas, so expect a probe on which ones. If you worked in specific docs or schemas, say which and what you did with them; if the work did not involve them, or they were someone else's, say so plainly and stay with the integrations and the playbook |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [grounded] | transferability | The quotes show client-facing work and evidence passed to product. Neither names sales or an engineering squad, and the words stay inside that. Answer slot: the JD names engineering, sales and customers, so expect a probe on the two the quotes do not show. If you worked with sales or engineers in these integrations or sessions, say how; if you did not, say so plainly and stay with clients and product |
| F6 | "Agile delivery experience" — dossier role_profile R5 | none given | low | [grounded] | discovery | The dossier's strategy for this area is clarify, and no verified entry speaks to it, so nothing about your past goes in the answer. Answer slot: the JD's agile line makes a probe on how you have worked with sprint-based teams likely. If you have worked that way, say how, in your own words; if you never did, say so plainly and ask the interviewer how the two squads define it, so you can say where your experience overlaps |

Dossier `hard_gates` is empty and none of the five requirements is a term the candidate meets or does not, so the snapshot carries no gate row.

## Persona table

| Persona | How it shows up here | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | A quiet, persistent probe of the missing PM title, the roadmap, the shipped-product line | High. A hiring-manager round starts from Case and Skeptic (relationship prior). The dossier's named objection sits squarely in this persona, and F1, F2 and F3 are the thin rows | Rehearse A1 until it is boring: the plain acknowledgment first, then the adjacent work at its own scope with its limit named, then a ramp stated as a plan |
| Case / Strategist | Live problems from the partner API role: adoption, conflicting partner asks, a first-90-days plan | High. Same hiring-manager prior, and the JD responsibilities (adoption metrics, partner discovery, two squads) map directly onto live problems | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully per case |
| Data-Driven Prober | Reads the quoted evidence line by line: the 30+ count, the sessions, the playbook | Medium. A hiring manager buying a transfer case will test whether the evidence survives, and the 30+ is the one headline number | Know what you can and cannot say about how the 30+ was counted and say plainly where you do not know |
| Conversational / Rapport Builder | The opener: "walk me through the journey", why Quartzline | Medium. Nearly every hiring-manager conversation opens this way, and it is scored | A 90-second arc built only from your three confirmed sentences |
| Peer Evaluator | The seam between you and the two squad leads | Low to medium. The hiring manager may price the seam because decision authority is unevidenced in the JD | Offer seam principles, not a pretended seam. Never recount setting priorities for a squad |
| Pressure | "Sixty seconds: why you over a PM with three years?" | Low to medium. A time-boxed version of the same objection | Pause, restate, hold the quoted position through two follow-ups, concede specifically |
| Values / Behavioral | An unpopular-truth story, a customer-over-metric story | Low. Your note describes one conversation with the hiring manager, and nothing read for this pack documents a values round | Selection scaffolds ending in the honest branch |

No interviewer profile exists, so there are no interviewer-signal adjustments. The loop is the one session you described.

## Question banks

### A. Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; plain acknowledgment sourced by prohibited_claims "Having held a product manager title or role" and acknowledge_gap "Owning a roadmap and prioritization authority (R1 sub-claim)" | The highest-ROI rehearsal in the pack, and the underwriter's own objection, asked as they wrote it because both negatives have a dossier source. Open with the acknowledgment before it is extracted: "I haven't held a product manager title, and I haven't owned a roadmap." Then the adjacent work at its own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." And: "I ran quarterly roadmap-input sessions feeding client evidence to product." Volunteer the second one's limit: it is confirmed, but little inspectable sits behind it. Answer slot: the JD's roadmap line makes a probe on those sessions likely. Say what client evidence you fed to product and how, in your own words; if you do not know what happened to it afterwards, say so plainly and stay with the sessions as you ran them. Hold through two follow-ups by returning to those sentences, never by adding to them. Concede in these words: "A PM with three years in the seat has done what I am asking you to trust me with. I haven't." Close with how you would learn it, as a plan | F1 and F2 are where the role presses hardest, and this is where the interview is won or lost. JD because it scores R1 and the roadmap line; Skeptic because it arrives as a quiet cross-examination, not a case |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] acknowledge_gap "Owning a roadmap and prioritization authority (R1 sub-claim)" | Plain acknowledgment, sourced by that dossier area: "Owning a roadmap and prioritization authority is where I'm weakest. I haven't done it." Do not bridge it. The underwriter looked and found nothing, so inventing a bridge live is how a candidate gets caught, and the sessions in A1 stay out of this answer. Then the ramp, said in the future tense: read the current roadmap, meet both squad leads, and find out how adoption is measured today. Those are the two unknowns in the dossier, so the ramp doubles as your reverse questions | F2 is a capability gap the candidate cannot reword; the Skeptic stem asks for it directly and a rehearsed, non-defensive answer reads as judgment |
| A3 | "Tell me about an API or platform product you've shipped, and what your part in it was." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Story-mapped on F3, at the quote's own scope: the client integrations of the vendor's REST APIs and the stages the quote lists, told in your own words. Say them as integrations; the quote does not say you released the API itself. Answer slot: the JD's shipped-products line makes a probe on the API's own release likely. If any part of that release was yours, say which part and how; if none was, say so plainly and stay with the integrations. The honest branch is a limit, not a confession. Hold by returning to the quote | F3 is the must-have with the least direct evidence, so this is the second most likely hard question. JD because R2 is a stated must-have |
| A4 | "What API documentation or schemas have you worked in, and how?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | Derived from R3's wording; the quotes are at their own scope. Say what the quotes say: "I led 30+ end-to-end client integrations of the vendor's REST APIs, including architecture, and I wrote the internal integration playbook my team uses." Answer slot: the JD names API docs and schemas, so expect a probe on which ones. If you worked in specific docs or schemas, say which and what you did with them; if the work did not involve them, or they were someone else's, say so plainly and stay with the integrations and the playbook | F4 is a discovery gap, so the honest answer depends on a fact the pack does not have. JD because R3 is a stated requirement |
| A5 | "How have you worked with agile teams?" | JD | [grounded] JD R5 "Agile delivery experience" | No verified entry speaks to this, so nothing about your past goes into the answer unless you say it. Answer slot: if you have worked in sprint-based delivery, say how, in your own words; if you never worked that way, say so plainly. Then ask: "How do your two squads define it — cadence, how work reaches them — so I can tell you where my experience overlaps?" | F6 is a discovery gap with the clarify strategy; the question-shaped answer is the one the underwriter allows. R5 is preferred, so this costs little if handled honestly |

### B. Case / Strategist (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Partner usage of a newly released endpoint is flat eight weeks after launch. How do you find out why?" | CASE | [generic] | Clarify first: what counts as usage, what the expectation was, and whether a baseline exists (the dossier lists adoption measurement as an unknown, so asking is natural). Then the objective, a segmentation of partners, how you would get both usage data and partner conversations, the metrics you would watch, and the risks. Challenge one premise respectfully, such as whether flat is a problem. Makes no claim about your past | The JD responsibility "Define and track adoption metrics" is the live problem the manager is most likely to set. CASE because it scores structure; `[generic]` because it is a pattern, not a fact about Quartzline |
| B2 | "Two partners ask for conflicting API changes and your squads can take one this quarter. How do you decide?" | CASE | [generic] | Ask who decides before anything else, since decision authority is the dossier's open risk. Then criteria, in order, the cost your squad leads see, and what you would tell the partner who loses. Answer as how you would decide, never as a time you did: setting priorities for a squad is on the prohibited list | The JD names two squads and a roadmap, and this is the sharpest way to test the seam. CASE because it asks about no past |
| B3 | "What do your first 90 days look like?" | JD | [inferred] derived from the JD responsibility "Own the roadmap for the partner-facing API platform" | A plan, in the future tense. Listen first: both squad leads, a handful of partners, the current roadmap, how adoption is measured today. Do not offer a roadmap before you know where decisions sit. It is the same ramp as A2, extended; it claims nothing about your past | The underwriter's strategy for the roadmap gap is acknowledge plus a ramp plan, and this is where the ramp gets asked for |
| B4 | "What do you know about how our partners use the platform today?" | CO | [generic] | No research reached this pack, so it holds no Quartzline facts. Before Thursday, read anything Quartzline publishes for developers or partners and say what you saw and what you would want to check. Say plainly what you have not read. Do not assert company facts you cannot source | The CO gap is the honest cost of the failed research; the upgrade menu says what closes it |

### C. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 30+ was counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The pack supplies no counting method. Answer slots, in your own words: how the 30+ was counted, what the figure is sensitive to, the assumption behind it you would defend least, and which part was yours, which the quote says is "Led". If you do not know how some of it was counted, say so plainly. Name the weakest assumption before the interviewer does | F1 and F3 both lean on this number, and it is the only headline figure. EXP because it tests attribution |
| C2 | "Tell me about the quarterly roadmap-input sessions." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Medium confidence: confirmed, with limited inspectable proof, so volunteer the limit before it is extracted. The beats are the ones the quote states: quarterly, roadmap input, client evidence to product. Answer slot: the JD's partner-discovery line makes a probe on how the sessions ran likely. If you chose who attended or what was asked, say how; if the format was set by someone else, or there was none, say so plainly and stay with what the quote says | The seam in F1 and F5. A session agenda or notes would lift the confidence band, and the upgrade menu says so |
| C3 | "Tell me about the integration playbook: what's in it and who uses it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | The beats are the ones the quote states: you wrote it, it is internal, your team uses it. Answer slot: if it covers API docs or schemas, say what; if it does not, say so plainly. Say what is in it from the document itself, since the underwriter had it provided and it is inspectable | High-confidence, inspectable evidence is the strongest thing to rehearse, and R3 asks about technical documentation |

### D. Conversational / Rapport Builder (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc, in your own words, using only those three sentences at their own scope. For why product and why now, give your own reason; the pack supplies none. Do not end the arc on a claim to own a roadmap, which the prohibited list rules out | Casual opener, scored anyway, and the one answer you can fully script |
| D2 | "What are you actually playing with in API tooling or product work these days?" | JD | [generic] | Name one thing you have actually used or read recently. If nothing comes to mind, say so plainly and say what you would start with. Do not name a tool you have not touched | R3's technical-fluency line asked casually |
| D3 | "Why Quartzline, and why this role?" | CO | [generic] | Your own reasons, in under a minute. Cite only what you have actually read about Quartzline, as this pack could not research it | The motivation check every rapport-style interviewer runs |

### E. Peer Evaluator (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "The squad leads sit beside you. Where is the seam between you and them, and what happens when you disagree?" | JD | [generic] | Offer seam principles, not a pretended seam: you do not know where it sits, and the dossier records decision authority as unevidenced in the JD. Say what you would want settled in the first weeks and who you would go to. For a disagreement story, pick a time you disagreed with an engineer or lead over scope, with a named stake, what you proposed and how it ended. If none comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | R4 names engineering as a stakeholder, and this is the risk the dossier asks you to validate |
| E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time work crossed a team boundary, naming what was yours and what was theirs. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | Peer-style collaboration probe; no quoted sentence carries a credit story |

### F. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over a PM with three years in the seat?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; plain acknowledgment sourced by prohibited_claims "Having held a product manager title or role" | Pause, restate the question, then the A1 sequence compressed: the acknowledgment, the integrations at their own scope, the ramp as a plan. Hold through two follow-ups, then concede the part that is true: you have not done the job. Never fold on the integrations to restore harmony | The same objection in a time-boxed form; rehearsed once, it will not freeze you |
| F2 | "That 30+ — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold the quote's verb, "Led". Answer slot: if some of the 30+ were shared with others, or began before you, say how many or which parts, in your own words; if all of them were yours to lead, say so plainly. Concede only what you state | The Pressure persona's attribution stem, aimed at the one number |

### G. Values / Behavioral (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to a client or to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, what you said, how it landed and an intact relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | Persona stem; no values round was documented, so low weight |
| G2 | "When did you put a customer's need ahead of an internal metric?" | VAL | [generic] | Same scaffold: name the need, the metric, and what it cost you. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | Persona stem; customer-first is the natural frame for a partner-facing role |

### Requirement coverage

| Requirement | Questions |
|---|---|
| R1 "3+ years product management experience" | A1, A2, F1 |
| R1 sub-claim, roadmap ownership and prioritization | A1, A2, B2, B3 |
| R2 "Shipped API or platform products" | A3 |
| R3 "Technical fluency: API docs, schemas" | A4, C3, D2 |
| R4 "Stakeholder management across engineering, sales, customers" | C2, E1, E2 |
| R5 "Agile delivery experience" | A5 |

Responsibilities: adoption metrics, B1; partner discovery, C2; working with two squads, B2 and E1. The headline figure, the 30+, is C1 and F2.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The JD asserts authority but the dossier finds it unevidenced. The answer tells you what you would be accepting, and it reads as diligence about how the role works |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | The metric is named as a responsibility with no baseline in the JD. The answer tells you whether the number you would be held to exists |
| 3 | "What does agile delivery look like for the two squads — cadence, and how work reaches them?" | It answers F6's open question and lets you place your experience against their actual practice |
| 4 | "Has the team brought anyone into product from outside a PM title? What helped them ramp?" | It names the hiring manager's likely hesitation without arguing against it, and gets their ramp criteria |
| 5 | "What partner feedback reaches the roadmap today, and by what route?" | It tests how partner discovery works in practice, so you learn what the role does with the evidence you would gather |
| 6 | "What would you want to see from the first 90 days to know the roadmap is on the right track?" | It turns your ramp plan from A2 and B3 into their criteria |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims | The plain acknowledgment, sourced by that field: "I haven't held a product manager title." No bridge that implies it |
| Having owned a product roadmap | Dossier prohibited_claims and the acknowledge_gap area | The plain acknowledgment, sourced by those fields: "I haven't owned a roadmap." No bridge and no slot |
| Having set prioritization for an engineering squad | Dossier prohibited_claims | The plain acknowledgment, sourced by that field: "I haven't set prioritization for an engineering squad." B2 and E1 are answered as how you would decide |
| Shipped the API product itself | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material says client integrations of the vendor's APIs, not the API's release |
| Authored API documentation or schemas | Inflated form of F4 | F4's quotes at their own scope. The material says a playbook and integrations, not docs or schemas |
| Managed stakeholders across engineering, sales and customers | Inflated form of F5 | F5's quotes at their own scope. The material shows clients and product |
| Shaped the product roadmap | Inflated form of the roadmap-input quote in F1 | That quote at its own scope: sessions that fed client evidence to product |

## Sources

Provided documents: `tuesday-dossier.md` from job-underwriter, dossier_version 1.1, generated 2026-08-14, plus your message (a 45-minute conversation with the hiring manager, Thursday). The dossier was consumed and supplied: `role_profile` (requirement text and responsibilities), `handoff_to_mock_interview` (high-priority requirements, verified evidence, weak areas with allowed strategies, the interviewer objection, risks, employer questions, prohibited claims) and `decision` (context only). It carried no `evidence_map`, `evidence_state` or `risk_register`, so gradings come from the handoff. Everything about Quartzline outside the dossier is `[generic]` or absent.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

Searches sent: "Quartzline company values" (refused); "Quartzline interview process product manager" (refused); "Quartzline strategy partner API platform news" (refused).

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | The search was refused. It would have fed a values cheat sheet and VAL questions; none is built, and G1 and G2 are generic |
| 2. `Quartzline interview process product manager` | unavailable | The search was refused. The loop here rests on your own description of one hiring-manager conversation, so persona weights come from the round-type prior |
| 3. `Quartzline strategy partner API platform news` | unavailable | The search was refused. It would have grounded B4 and D3, which are `[generic]` |
| 4. `{interviewer name} Quartzline` | n/a | No interviewer name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's role_profile supplies the requirement lines the fit snapshot and JD questions rest on |

## Upgrade menu

- The interviewer's name → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to their own path
- The recruiter's prep note (focus areas, any case or presentation expected) → coverage of a pre-declared deliverable, which the pack assumes there is none of
- Quartzline's careers page, values page or developer docs pasted here, or search permission → B4 and D3 become `[grounded]`, and a values cheat sheet is built if a values round is documented
- Your own answers to the slots in F3, F4, F5 and F6, and to A5, C1 and C2, typed outside a drill → those rows are regenerated from your words, and several `[inferred]` rows can become `[grounded]`
- A roadmap-input session agenda, notes or a deck you shared with product → the "Ran quarterly roadmap-input sessions" claim can rise from medium to high confidence
- Your raw CV → the quotes the pack draws on are checked against it
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes), only if web search is permitted → a strategy brief for the CO and CASE bank
