Quick status: I'm building your Thursday prep pack from the dossier. The three web searches I tried were refused, so the pack relies on the dossier and your own words. I'm writing the pack file now.
Your prep pack is saved at `/var/tmp/tuesday-measure/1a6/runs/sonnet/tuesday/part-2/rooms/case-4-denied-261d9f72/quartzline_product-manager-platform-apis_interview_pack.md`. It's built for a 45-minute hiring-manager conversation, with 21 questions across seven interviewer styles.

- **Most important prep:** A1 is the objection the dossier named: "You have never held the PM title or owned a roadmap — why hire you over a PM with three years of the actual job?" The pack coaches you to say the acknowledgment first, give the integration and playbook quotes at their own scope, and say plainly that this is adjacent work, not PM experience.
- **R2 has no prep in the dossier:** "Shipped API or platform products" is a must-have, but the dossier gave it no weak-area row. Your evidence says you led client integrations of "the vendor's REST APIs", not that you released a product. The dossier doesn't say which side of the API you were on, so the pack doesn't assume either side. A3 rehearses the question and keeps you to what the quote says.
- **Roadmap ownership gets an acknowledgment, not a bridge.** The pack scripts that line and a ramp plan only for the "own the roadmap" requirement and doesn't build a bridge, because the underwriter found nothing to bridge from.
- **No web research ran.** All three searches were refused, so nothing in the pack states a fact about Quartzline beyond what the dossier supplied. That is why there's no company-strategy question. Your reverse questions come straight from the dossier's open items on squad-lead authority and the adoption baseline.

I can play the Skeptic live on A1 so you hear the follow-ups out loud. I can also save an updated `tuesday-dossier.md` recording the gaps this prep exposed (R2 first), for the underwriter to verify. Or I can convert the pack to a Word document.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

**Round:** one 45-minute conversation with the hiring manager (your words). **Interviewer:** name not given. **Built from:** your underwriting dossier (conditional_go) and your message. No web research ran (see Sources).

## How to use this pack

Personas describe how a question arrives; types describe what is being scored. Guidance is scaffolding, not a script: every sentence about your past is a quote you already hold, and every place the pack does not know something is an answer slot for you to fill in your own words, or to say plainly that it did not happen.

| Tag | Meaning |
|---|---|
| VAL | Behavioral or values alignment: whether past behavior shows the company's published values |
| EXP | Work-experience deep-dive: whether a claim survives scrutiny, and what was actually yours |
| JD | Role or JD-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem set in the role, answered by structure and reasoning |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1 (must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier handoff; "Wrote the internal integration playbook her team uses" — dossier handoff | low | [grounded] | transferability | The underwriter's condition: position this as adjacent, never as PM experience (strategy: bridge). Words stay at the quotes' scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs" and "I wrote the internal integration playbook my team uses." The limit, as the pack's observation: neither quote says product management. The dossier records the title as a prohibited claim, `prohibited_claims`: "Having held a product manager title or role", so the plain acknowledgment has a source: "I haven't held a product manager title." |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibilities | none given | none | [grounded] | capability | The dossier records this as an `acknowledge_gap` area: "Owning a roadmap and prioritization authority (R1 sub-claim)", with `prohibited_claims`: "Having owned a product roadmap" and `prohibited_claims`: "Having set prioritization for an engineering squad". Words: "I haven't owned a product roadmap." Then a ramp plan, said as a plan and never as a past: what you would learn first is which roadmap decisions the PM makes alone and which belong to the two squad leads. No bridge and no slot, because the underwriter looked and found nothing to bridge from |
| F3 | "Shipped API or platform products" — dossier role_profile R2 (must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier handoff | low | [inferred] | discovery | The dossier lists R2 as high priority but gives it no weak-area row, so nothing in it prepared you for this probe. Your material says integrations you led, not a product you released, and it does not say which side of the API you stood on, so the pack assumes neither. Words stay at the quote: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Answer slot: the R2 line makes a probe on the product side of those integrations likely. If any go-live decision was yours to set, say which and how you decided, in your own words; if there was none, or it was not yours, say so plainly and describe how you led the integrations |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3 (important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier handoff; "Wrote the internal integration playbook her team uses" — dossier handoff | medium | [inferred] | discovery | The quotes carry REST API integrations and a written playbook; they do not mention docs or schemas. Answer slot: the R3 line names API docs and schemas, so expect a probe. If you worked from or wrote to them in those integrations, say how, in your own words; if you did not, say so plainly and stay with the integrations and the playbook |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4 (important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier handoff; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier handoff | medium | [inferred] | discovery | The quotes carry clients and product; engineering and sales are not in them. The sessions line is confirmed with limited inspectable proof, so expect a probe and name that limit yourself before it is extracted. Answer slot: the R4 line names engineering, sales and customers. Say which of the three were part of those integrations or sessions and how, in your own words; if one was not, say so plainly and stay with the ones that were |
| F6 | "Agile delivery experience" — dossier role_profile R5 (preferred) | none given | low | [grounded] | discovery | The dossier's strategy here is clarify (area: "Agile delivery inside a product org (R5)"). No quote speaks to it, so nothing about your past goes in. Answer slot: the R5 wording is the interviewer's likely probe. If you have worked in sprint-based delivery, say how, in your own words; if you have never worked that way, say so plainly, then say what you would want to confirm about how they define it |

## Persona table

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet, persistent probing of the title gap, the missing roadmap and the "why now" | Top. Hiring-manager prior puts it first alongside the Case persona, and the dossier names an objection that is this persona's native question | Rehearse the one named objection until it is boring; bridge only from adjacent quotes with the limit said; concede specifically |
| B. Case / Strategist | Live problems from the actual role: diagnose adoption, split capacity, run discovery | High. Hiring-manager prior; the JD's own responsibilities are the case material | Clarify, then structure, then answer; think aloud; challenge one premise respectfully |
| C. Conversational | Friendly opener ("walk me through the journey"); still scored | Mid. A 45-minute conversation tends to open this way, which is a prior, not a fact about this interviewer | A 90-second arc built only from your quoted sentences; treat casual questions on API topics as scored |
| D. Data-Driven Prober | Reads your claims line by line; asks how the 30+ was counted | Mid. One headline figure, and one claim the dossier marks "expect a probe" | Know how each number was counted and say plainly where you do not know; name the assumption you would defend least before they do |
| E. Pressure | Time-boxes you, plays devil's advocate on "why you" | Low. Not the hiring-manager prior, but the objection can arrive in this register | Pause, restate, hold the quoted position through two follow-ups, then concede only what is true |
| F. Peer Evaluator | Seam-splitting with the two squad leads | Low. The interviewer is your future manager, but the role sits between two squads | Propose seam principles rather than pretend to know the seam; ask how decisions are split |
| G. Values / Behavioral | Scenario prompts, STAR-shaped | Low. No values-style round is detected: your own words establish one session, a conversation with the hiring manager, and no published values were read | Choose a story where the hard truth actually landed; if none comes to mind, say so |

Loop: your own words establish one session, so no archetype fallback applies. No interviewer profile exists, so no interviewer-signal adjustment was made.

## Question banks

### A. Skeptic (weight: top)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | The highest-ROI prep in this pack, and the underwriter's `likely_interviewer_objections` named it. Open with the acknowledgment, sourced to `prohibited_claims`: "Having held a product manager title or role" and "Having owned a product roadmap": "I haven't held a product manager title, and I haven't owned a product roadmap." Then the bridge with its limit named, adjacent work and not PM experience: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live. I wrote the internal integration playbook my team uses." Stop there and let them draw the inference. Then a ramp, as a plan only: which roadmap decisions are the PM's alone and which are the squad leads'. Follow-up 1 (so roadmap ownership would be new): agree specifically and return to the two quotes. Follow-up 2 (why would integration work transfer): do not argue it; restate the quotes at their scope, name the limit, and ask which part of the job they think is hardest to learn from the integration side. Never fold on the quotes and never add to them | F1 and F2 are the rows this question presses on; it is the most predictable question for this candidate. JD because it scores the years requirement; delivered in the Skeptic's quiet register |
| A2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] `acknowledge_gap` area: "Owning a roadmap and prioritization authority (R1 sub-claim)"; `prohibited_claims`: "Having set prioritization for an engineering squad" | Name it plainly, in under a minute: "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then the plan only: you would first learn which roadmap decisions are the PM's alone and which belong to the two squad leads. No bridge from other work and no slot, because the underwriter found nothing to bridge from | F2 is the one row with no evidence behind it, so this stem lands there directly. JD because it scores the responsibility the gap sits on |
| A3 | "The role needs shipped API or platform products. What have you shipped?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Say what the quote says, in those words: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Answer slot: the R2 line makes a probe on the product side of those integrations likely. If any go-live decision was yours to set, say which and how you decided, in your own words; if there was none, or it was not yours, say so plainly and describe how you led the integrations. Do not rename the integrations as products | F3 is a must-have the dossier left ungraded, which makes it the likeliest surprise. JD because it scores R2 |
| A4 | "Why move into product management now?" | JD | [generic] | Selection scaffold, in your own words: one thing about this role that you want, taken from its listed responsibilities, said without a claim about what your past work demonstrated. If no clear reason comes to mind, say so plainly, then give the nearest thing your material carries, or how you would decide whether the role is right | F1's gap makes motivation the Skeptic's second probe. JD because it tests fit with the listed job |
| A5 | "Walk me through the quarterly roadmap-input sessions you ran." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Medium confidence: confirmed, limited inspectable proof, so name the limit before they extract it: say what you can show and what you cannot, in your own words. Beats the quote states: you ran them, they were quarterly, they fed client evidence to product; tell those in your own words. Answer slot: the R4 line names engineering, sales and customers, so expect a probe on who was in the room. Say who and how, in your own words; if one group was not, or the sessions were not run that way, say so plainly and stay with what the sentence says | F5 is the evidence the dossier marks "expect a probe"; EXP because it tests what was actually yours |

### B. Case / Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You start as the PM for the partner API platform. What do you need to know in your first two weeks before you touch the roadmap?" | CASE | [generic] | Clarify first: which decisions are yours alone and which are the two squad leads'; how partner adoption is measured today and from what baseline; who the partners are and what they are trying to do. Then objective, then a first-month plan. Think aloud and say the open items as questions you would ask | The JD's own unknowns are the case. CASE because it asks for structure and makes no claim about your past; F2 is why asking before deciding is the honest posture |
| B2 | "Partner adoption of the API has stalled. How do you diagnose it?" | CASE | [generic] | Clarify what adoption means here, since the JD asks the PM to define and track it. Segment partners, walk the path from first contact to sustained use, name hypotheses (docs, schemas, auth, partner effort), and say what data would separate them. Challenge one premise respectfully | The JD names adoption metrics as a responsibility. CASE because it is a live problem in the role |
| B3 | "Two squads want the same capacity: one for a partner-requested endpoint, one for platform reliability. How do you decide?" | CASE | [generic] | Start with decision rights: whose call is it, and what input does each squad lead hold. Then criteria (partner impact, risk, cost of delay), what you would ask each lead, and how you would record the trade-off. Answer as "I would", never as a past decision | The two-squad structure is in the JD. CASE; the guidance makes no claim because F2 records no prioritization history |
| B4 | "A partner tells you the API is hard to integrate. How would you run discovery with them?" | CASE | [generic] | Ask what they were trying to do and where it broke; plan two or three partner conversations before forming a view; look for the pattern across partners before proposing a fix; say how you would test the fix. A plan, not a past | The JD lists discovery with integration partners as a responsibility. CASE because it is a live problem |

### C. Conversational (weight: mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc with only the beats those sentences state: the integrations you led, the playbook you wrote, the sessions you ran (name their limit if asked). Close with one sentence, in your own words, on why this role. The pack holds no titles, dates or employer details for you, so add none that you do not state yourself | F1 and F5 draw on these quotes. EXP because the interviewer is checking what the background actually is, in a casual register that is still scored |
| C2 | "When you look at a partner API, what do you read first, and why?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: the R3 line names API docs and schemas, so expect this probe. Say what you read first and why, in your own words, anchored to the integrations in the quote; if you did not work from docs or schemas in them, say so plainly and stay with the REST API integrations | F4 is the row this question tests. JD because it scores R3 in conversational packaging |
| C3 | "Tell me about your experience with agile delivery." | JD | [grounded] `uncertain_or_weak_areas` entry: "Agile delivery inside a product org (R5)" | Question-shaped. No quote speaks to this, so nothing about your past goes in. Answer slot: the R5 wording is the likely probe. If you have worked in sprint-based delivery, say how, in your own words; if you have never worked that way, say so plainly. Then ask: "How does your team define it day to day?" | F6 is a clarify area, so the honest move is to find out what they mean. JD because R5 is a listed requirement, preferred |

### D. Data-Driven Prober (weight: mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You led 30+ integrations. Walk me through how that number was counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Four slots, in your own words: how the 30+ was counted; what it is sensitive to; the assumption behind it you would defend least; which part was yours. If you do not know exactly how it was counted, say so plainly. The pack supplies no counting method and no denominator. The integration playbook is the inspectable artifact behind this claim, so offer to walk through it | F1's headline figure. EXP because it tests whether the number survives scrutiny |
| D2 | "Walk me through the integration playbook you wrote. What would you change in it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Say what you wrote and that your team uses it, in the quote's words. What it covers is in your hands, not the pack's: say it in your own words, then name the one thing in it you would defend least. If a section is not yours, or you cannot recall how it was built, say so plainly | F1 and F4 both lean on this line. EXP because the playbook is the claim with the most inspectable support |
| D3 | "Who did you work with to get one of those integrations live: engineering, sales, the customer?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: the R4 line names engineering, sales and customers, so expect a probe on each. Say which you worked with and how, in your own words, for one integration you can speak to fully; if a group was not part of it, say so plainly and stay with the ones that were | F5 is the row this tests. JD because it scores R4 |

### E. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a PM with three years of the job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | The A1 objection, time-boxed. Pause and restate it. Hold only what the quotes carry: "I led 30+ end-to-end client integrations of the vendor's REST APIs. I wrote the internal integration playbook my team uses." Do not argue you are better. Hold through two follow-ups by returning to those sentences, then concede explicitly and specifically, sourced to `prohibited_claims`: "Having held a product manager title or role": "I haven't held a product manager title." Never fold on the quotes, never add to them | Same objection as A1 in a different register; F1. JD because it scores R1 |
| E2 | "That 30+: how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold the verb the quote carries: "I led them." Answer slot: say which of the stages in that sentence (scoping, requirements, architecture, UAT, go-live) were yours alone and which were shared, in your own words; if you cannot separate them, or some were not yours, say so plainly. Hold through two follow-ups, then concede the specific shares and nothing more | F1's attribution probe. EXP because it exists to catch inflation |

### F. Peer Evaluator (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "You and one of the two squad leads disagree about what the squad builds next. Where is the seam, and what happens?" | CASE | [generic] | Propose seam principles rather than pretending to know the seam: the PM owns the problem and the partner evidence, the squad lead owns how it gets built, with the exact split to be confirmed. Say how you would raise a disagreement (data first, then escalate the decision, not the person). Ask how decisions are split today. Answer as "I would" | The dossier's open risk on decision authority. CASE; F2 is why the guidance makes no claim about past prioritization |
| F2 | "How do you handle credit and hand-offs when work spans our teams?" | EXP | [generic] | Selection scaffold: pick a time when work crossed team lines and it mattered what was whose; it needs a named hand-off, who held which part, and how it was settled. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the end-to-end scope in the integrations quote at its own words, or how you would handle it | F5's engineering and sales gap. EXP, not VAL, since no published values were read |

### G. Values / Behavioral (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | EXP | [generic] | Selection scaffold: choose a time where the truth was stated and it landed. It needs a named stake, the moment you said it, and an intact relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Persona stem for this style; EXP rather than VAL because no published values were read. F5 is the row it supports |
| G2 | "When did you put a customer ahead of an internal metric?" | EXP | [generic] | Selection scaffold: a decision, what the metric was, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the client-evidence quote at its own scope, or how you would handle it | Persona stem for this style; F5. EXP because no published values were read |

### Requirement coverage

| Requirement or responsibility | Questions |
|---|---|
| R1: 3+ years product management experience | A1, A2, A4, A5, E1 |
| R2: Shipped API or platform products | A3 |
| R3: Technical fluency: API docs, schemas | C2, D2 |
| R4: Stakeholder management across engineering, sales, customers | A5, D3, F2 |
| R5: Agile delivery experience | C3 |
| Own the roadmap for the partner-facing API platform | A1, A2, B1, B3 |
| Run discovery with integration partners | B4 |
| Define and track adoption metrics | B2 |
| Write specs and drive delivery with two engineering squads | B3, F1 — no spec-writing question, because nothing announced one; see the upgrade menu |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the two squad leads?" | The dossier flags it as unresolved: "Decision authority versus the two squad leads is asserted in the JD but not evidenced". It reads as diligence, and the answer decides whether the role is an owner role or a coordinating one |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | The dossier flags: "Adoption metrics are named as a responsibility but no current baseline is stated". The answer tells you what success looks like in the first months |
| 3 | "What would a strong first 90 days look like for someone coming from the integration side rather than a PM seat?" | It puts the A1 objection on the table as an expectation to set, and shows you have thought about the ramp |
| 4 | "How does partner input reach the two squads today?" | It tests the discovery and stakeholder parts of the role, and shows what a PM would inherit |
| 5 | "Who in sales and customer success does this PM work with on the partner roadmap, and how often?" | R4 names sales; your quotes do not, so the answer shows how large that gap is in practice |
| 6 | "How does delivery run day to day on the two squads?" | It answers the definition question C3 asks you to raise, without having to claim anything first |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Sourced: dossier `prohibited_claims` | The plain acknowledgment: "I haven't held a product manager title." Adjacent work only, at the quotes' scope |
| Having owned a product roadmap | Sourced: dossier `prohibited_claims` and `acknowledge_gap` area | The plain acknowledgment: "I haven't owned a product roadmap." Ramp as a plan only; no bridge, no slot |
| Having set prioritization for an engineering squad | Sourced: dossier `prohibited_claims` and `acknowledge_gap` area | The plain acknowledgment: "I haven't set prioritization for an engineering squad." No slot |
| Shipped an API or platform product | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material says integrations led, not a product released. A3's slot stays inside the go-live of those integrations |
| Shaped or decided what product built from the sessions | Inflated form of F5 | F5's sessions quote at its own scope. The limit is the pack's observation: the material says the sessions fed client evidence to product, not what product did with it |

## Sources

**Provided documents.** Your message (Thursday, a 45-minute conversation with the hiring manager) and `tuesday-dossier.md`, version 1.1, generated by job-underwriter. Sections consumed: `role_profile` (requirement text stands as the JD's lines) and `handoff_to_mock_interview` (all fields). `decision` read as context only. The dossier carries no `evidence_map`, `evidence_state` or `risk_register`, so none was used.

**Searches sent, all refused (permission not granted):**
- "Quartzline company values" — refused
- "Quartzline interview process product manager" — refused
- "Quartzline partner API platform strategy news" — refused

Nothing in this pack states a fact about Quartzline that the dossier did not supply.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Search refused. Would have supplied published value names for VAL themes; no values-style round is detected, so no cheat sheet is owed either way |
| 2. Quartzline interview process, product management | unavailable | Search refused. Would have documented the loop; your own words already establish this one session, so persona weights are unchanged |
| 3. Quartzline strategy and recent news | unavailable | Search refused. Would have enabled a CO question; the bank has none, and the CASE questions are generic |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form |
| 5. Representative product manager JD | skipped | The dossier's role_profile fixes the fit snapshot and the JD questions |

## Upgrade menu

- Permission to search the web, which was refused this session → values, interview process and strategy become sourced; a CO question can be written, and the values-round check can be rerun
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes, needs search permission) → a strategy brief, recent org context, and a grounding brief section
- The hiring manager's name → an interviewer read, reweighted personas, and a reverse question tied to their career path
- The recruiter's prep note, including any announced exercise such as a spec or product case → coverage of that deliverable and a spec-writing question
- A statement from you, outside rehearsal, on any release work beyond the client integrations, on API docs or schemas, and on sprint delivery → F3, F4 and F6 move from answer slots to quoted evidence
- An agenda or notes from one roadmap-input session → raises F5's sessions line from medium toward high
- Hours available before Thursday → a prep triage ordered to your time
