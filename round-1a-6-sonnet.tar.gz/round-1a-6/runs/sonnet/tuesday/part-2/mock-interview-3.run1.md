Reading is done, and I'm now running Stripe research: values, interview loop, strategy and a representative job posting. Then I'll build your prep pack.
Your prep pack is saved at `/var/tmp/tuesday-measure/1a6/runs/sonnet/tuesday/part-2/rooms/case-3-denied-8b824985/Stripe_product-operations-manager_interview_pack.md`.

Web search was refused in this environment, so I couldn't research Stripe. I also had no job description, CV or interviewer details. The pack is therefore a worksheet:
- **Content:** It has 21 questions across seven interviewer styles, with answer guidance, six questions to ask them, and a requirement-coverage table.
- **Stripe specifics:** It makes no claims about Stripe's values, interview loop or strategy.
- **Your experience:** It makes no claims about it either. Each story is a "pick a real instance" scaffold, so you supply the facts.
- **Weights:** Interviewer-style weights are blended for an unspecified final round.
- **Rehearse first:** B1, "Which part of this role would you be weakest at on day one?" It stands in for your real top objection until I see your CV.

You can say the word and I'll run a live drill on B1 or any question you pick. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to Word.

Three questions would restructure the pack:
1. Who are you meeting in the final, and in how many sessions (hiring manager, skip-level, peers, cross-functional)? Did the recruiter mention focus areas, a presentation or a take-home?
2. Can you paste the job description and your CV? I can also proceed without them.
3. Do the role's location, in-office and work-authorization terms work for you?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe (final round)

Interviewer: not given. Relationship: not given. Sessions in the final: not given, so weights below are blended. Built with no JD, no CV and no web research, so it is a worksheet pack: it makes no claim about your past and none about Stripe.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored.

| Type | Meaning |
|---|---|
| VAL | Behavioral / values alignment: whether past behavior shows the company's published values |
| EXP | Work-experience deep-dive: whether your claims survive scrutiny and what was actually you |
| JD | Role-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge: whether you can think at the company's altitude |
| CASE | A live problem from the role, scored on structure and reasoning |

Guidance is scaffolding, not a script. Because no CV was supplied, every story is yours to choose: where a row says "selection scaffold", pick a real instance that fits the criteria. Nothing here supplies an event, figure or result for you.

## Fit snapshot

No requirements were supplied, so the rows are role-family requirements written as plain prose, all `[generic]`. Replace them with the JD's own lines when you send it. Every evidence cell is empty because nothing about your past was provided.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Plans and runs product launches across engineering and non-engineering teams (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a launch where you can say what you owned, what you did not, and what happened. Selection scaffold: pick one launch where you can name those three things; if no such launch comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Builds and runs operating cadences such as planning and reviews with product teams (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a recurring forum you ran, with who attended and what changed because of it. Selection scaffold: pick one recurring process you ran or redesigned, naming the problem it addressed; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Defines and tracks product health metrics and uses data to drive decisions (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a metric you can explain end to end: definition, source, how it was counted, and one decision it changed. Selection scaffold: pick one metric you can explain that way; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Improves processes and tooling that product teams depend on (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a process or tool change you drove, with the before, the change and a result you can stand behind. Selection scaffold: pick one such change and be exact about your part; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Communicates with senior leaders, including bad news (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a moment you told senior people something unwelcome and the relationship held. Selection scaffold: pick a time with a named stake and a clear outcome; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Partners with peer functions such as product management, engineering, support and go-to-market (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a disagreement with an equal that you resolved while keeping the partnership. Selection scaffold: pick one with real stakes on both sides; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F7 | Location, in-office expectations and work-authorization terms for the role (role-family pattern) | none given | none | [generic] | hard_gate | Your material does not establish whether these terms are met. This is a term rather than a skill, so it is surfaced and not bridged: no wording can close it |

## Persona table

No loop source established Stripe's final round, so these weights rest on relationship priors for an unspecified final round, blended, and on the generic fallback pattern. They are not Stripe's documented process. Re-weight when you tell me who you are meeting.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problems from the role: plan this, diagnose that | High: hiring managers and skip-levels in a final round typically test structure on role problems | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic | Quiet probing of gaps, motivation and day-one weakness | High: a final round is where remaining doubt gets tested, and your material is not yet seen | Rehearse the most predictable objection until it is boring; name limits plainly; give a concrete ramp |
| Peer Evaluator | Seam-splitting with product and engineering, credit, disagreement | Medium: product operations sits between teams, so peers are likely in a loop | Reciprocity framing; propose seam principles, not a pretend seam; spine and tact together |
| Data-Driven Prober | Asks how numbers were counted and what they depend on | Medium: the role is metric-heavy | Know how any number you cite was counted; name your weakest assumption first; say plainly when you do not know |
| Pressure | Time-boxes, interrupts, questions motives | Medium: skip-level and executive rounds often test composure | Pause, restate, hold a position through two follow-ups, concede specifically |
| Values / Behavioral | Scenario probes against published values | Lower: no values-style round is documented here, so none is assumed | Choose stories where the hard truth landed; we for context, I for contribution |
| Conversational | Friendly, unstructured, still scored | Lower: likely as openers and closers | Prepare a 90-second arc; treat casual questions as scored |

## Question banks

Highest-ROI prep: with no CV I cannot name your single most likely objection, so B1 (weakest part on day one) stands in for it. Rehearse it first, and send your CV to replace it with the real one.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A launch is two weeks out and engineering, support and sales each say they are not ready. How do you decide whether to hold the date, and what do you do in the next 48 hours?" | CASE | [generic] | Clarify first: who owns the date, what ready means for each team, what delay costs. Then objective, then split readiness into must-have and nice-to-have, then an approach (readiness check per team, one named risk owner, one decision forum), metrics for readiness, and risks. Challenge one premise, such as whether all three teams share one definition of ready. The question needs no claim about your past, so the guidance makes none | F1 is the requirement it scores; CASE because it is a live problem set in the role |
| A2 | "Product teams say planning reviews take a lot of time and produce little. Redesign the cadence. What do you need to know first?" | CASE | [generic] | Open with questions: what each review is for, who attends, what decisions it should produce, what the teams value today. Then objective, segmentation of review types, a lighter design, how you would measure that it works, and the risk of stripping out something a team relies on. No claim about your past | F2 is the requirement; CASE because it asks for a design under uncertainty |
| A3 | "A usage metric for a recently shipped feature dropped 20% week on week. Diagnose it." | CASE | [generic] | Check the data before the product: definition change, instrumentation, seasonality, one segment. Then segment by cohort, platform and region, form two or three hypotheses, say what data would separate them, and name the first action. Think aloud and state the hypothesis early | F3 is the requirement; the stem is a standard diagnostic case |
| A4 | "You have one quarter and no new headcount. What do you stand up first as the product operations manager, and what do you deliberately not do?" | JD | [generic] | Structure: listen first, find the one visible friction product teams share, pick a single mechanism to fix it, say how you would know it worked, and name what you would defer and why. State assumptions aloud because you have not seen the team. Make no claim about what you have done before | F4 is the requirement; JD in content, CASE in delivery |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Selection scaffold: look at F1 to F6 and pick the one where your own material is thinnest. Name it first, before they do. Then give the nearest thing your material does carry, and a concrete ramp, such as who you would learn from in the first weeks. If you cannot name a weakest part, say so plainly and say what you would check first | Standing in for your real top objection until a CV exists; JD because it scores the requirements list |
| B2 | "Walk me through your first 30, 60 and 90 days, and where you would ask for help." | JD | [generic] | Thirty days: listen and map stakeholders and existing mechanisms. Sixty: one visible fix chosen with the teams. Ninety: a repeatable rhythm and one metric. Name the help you would ask for and from whom. This is a plan, not a past, so keep it as a plan | Skeptics test whether a gap has a ramp; F1 to F4 are the areas it covers |
| B3 | "Why product operations, and why now?" | JD | [generic] | Give one honest thread that connects what you have chosen so far to this role. Answer slot: give your actual reason for choosing this path, in your own words; if it is not yet a considered choice, say so plainly and say what you hope to learn. Do not borrow reasons from the job description | Motivation consistency is what skeptics cross-examine; JD because it scores fit to the role |
| B4 | "What would make you decide this role is not right for you?" | JD | [generic] | Answer with real criteria, such as the type of problems, the decision rights, how success is measured, and tie each to something you will ask them. A role-fit answer that shows self-knowledge scores better than none. If you have no deal-breakers, say so plainly and say what you would weigh most | Tests whether your interest is considered; relates to F7 as well as F1 to F6 |

### C. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our teams sit side by side. Where is the seam between product operations and product, and what happens when we disagree?" | JD | [generic] | Propose seam principles, not a map you cannot know: product owns what and why, you own the mechanisms that make shipping and learning repeatable, and disagreements go to the shared goal first. Then a disagreement story. Selection scaffold: pick a disagreement with an equal where you showed spine and tact; if none comes to mind, say so plainly, then say how you would handle it | F6 is the requirement; peers price whether you add or remove load |
| C2 | "How do you handle credit when work spans teams?" | VAL | [generic] | We for context and I for your contribution, said precisely. Selection scaffold: pick one piece of cross-team work where credit could have been unclear and describe what you actually did about it; if none comes to mind, say so plainly, then say how you would handle it | Credit-sharing is a standard peer probe on F6 |
| C3 | "What would you need from me in your first month, and what could you do that would genuinely help my team?" | JD | [generic] | Reciprocity: lead with what you would offer, then name two specific things you would ask for, such as context on current pain points and an intro to partner teams. Keep offers to things you can honestly deliver | Peers weight what the hire adds to their work; F6 |

### D. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not soften the message, and an intact relationship afterwards. Tell it with I for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F5; no published values were read, so this is a common stem and not a Stripe-specific map |
| D2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where the two pulled apart, say what you weighed and what happened. Be exact about whose decision it was. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F6 and F5; same stem family as D1 |

### E. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Pick a metric you have reported on and walk me through how it was counted." | EXP | [generic] | Selection scaffold: choose a number you can explain end to end: definition, source, numerator and denominator, and what it is sensitive to. If you cannot recall how it was counted, say so plainly and say how you would find out | F3; EXP because it tests whether your claims survive scrutiny |
| E2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | Name the weakest assumption in your own words before they do. This turns a gotcha into a credibility gain. If you do not know, say so plainly | Follow-up on E1; F3 |
| E3 | "Here is a dashboard of weekly active usage per feature. What three questions do you ask before you trust it?" | CASE | [generic] | Definition of active and of feature; instrumentation and recent changes; population and time window. Then say what you would check first and why | F3; CASE because it is a live data-trust problem |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, restate the question, then three beats drawn only from your own answers to B1, B3 and your arc in G1. Hold the position through two follow-ups; concede a specific limit if pressed, without folding on the core. This pack supplies no beats because it has none from you | F5 and F1 to F4 as a whole; pressure tests composure more than content |
| F2 | "That result: how much of it was actually you?" (asked after any story you tell) | EXP | [generic] | Hold, then concede. State exactly what was yours in one sentence, name what was shared and with whom, and stay with that through the second follow-up. Never add to the story under pressure. If part was not yours, say so plainly | Attribution probes follow any story; EXP |
| F3 | "You have two minutes: the one thing you would change about how a product team launches, and defend it." | CASE | [generic] | Pick one change you can defend, give the problem, the change, the cost, the risk and how you would know it worked. When interrupted, restate the question and return to the structure | F1 and F4; CASE under time pressure |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | Prepare a 90-second arc in three beats: where you are now, the thread that led here, why this role. Fill it with your own facts; the pack has none to give. Rehearse aloud once | Opening question in almost every loop; casual but scored |
| G2 | "What are you reading or experimenting with these days that is relevant to this work?" | JD | [generic] | Name something true and specific, say what you took from it and how it could apply to product teams. If nothing comes to mind, say so plainly and say what you would explore first | Rapport-style interviewers test genuine interest |

## Requirement coverage

| Requirement | Questions |
|---|---|
| F1 launches | A1, B2, F3 |
| F2 operating cadences | A2, B2 |
| F3 metrics and data | A3, E1, E2, E3 |
| F4 process and tooling | A4, B2, F3 |
| F5 senior communication | D1, F1 |
| F6 peer partnership | C1, C2, C3, D2 |
| F7 location and authorization | none: it is a term, not a skill, so there is nothing to rehearse |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does success look like for this role at six months, and how will it be measured?" | Shows you think in outcomes and gives you the scoring sheet |
| R2 | "Which product launches or processes are hardest for the teams right now?" | Surfaces the real problem you would be hired to solve |
| R3 | "Where does product operations end and product management begin here, and where do they overlap?" | Shows seam awareness and tests the same boundary C1 rehearses |
| R4 | "What have previous people in this role found hardest in the first 90 days?" | Signals you are planning the ramp |
| R5 | "How are decisions made when product, engineering and operations disagree?" | Reveals decision rights, which determine how effective the role can be |
| R6 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity question for a peer; ask it of any peer in the loop |

## Prohibited claims

No entries. Nothing was supplied about your past, so there is no sentence of yours for this pack to stretch, and it lists none. The guidance above makes no claim about what you did, owned or decided. Any story you tell must be one you can defend under a second question. This list will be built from your CV once you send it.

## Sources

Provided documents: your message, which gave the company, the role and the round. No JD, CV or interviewer information was provided.

Searches sent, all refused by the environment, so nothing was returned and nothing from them is used:

- `Stripe operating principles values` (refused)
- `Stripe interview process product operations manager` (refused)
- `Stripe strategy news 2026` (refused)
- `Product Operations Manager job posting Stripe` (refused)

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Would have fed the values cheat sheet with Stripe's published value names; none is in this pack |
| 2. `{company} interview process {role family}` | unavailable | Would have established the final-round loop and persona weights; weights rest on relationship priors instead |
| 3. `{company} strategy` / recent news | unavailable | Would have grounded a CO or CASE question in Stripe's current strategy; the questions are generic |
| 4. `{interviewer name} {company}` | n/a | No name was given, so there was no query to form |
| 5. representative `{role title}` JD | unavailable | Would have turned the generic requirement rows into inferred ones quoted from a posting |

## Upgrade menu

- JD text → the seven generic rows become rows quoted from the real requirements, and every question gets a JD hook
- Your CV → real evidence in the fit snapshot, story-mapped guidance instead of selection scaffolds, a named top objection, and a built prohibited list
- The interviewer names and relationship → the interviewer read, persona weights reset, and a reverse question tied to their path
- The schedule of your final, if it is several sessions → per-session mini-packs
- The recruiter's prep notes → coverage of any announced presentation, take-home or focus area
- Web search enabled → Stripe's published values, loop and current strategy replace the generic rows; a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) can follow on request
- A `tuesday-dossier.md` from an earlier session, if you have one → verified evidence and constraints to build on
