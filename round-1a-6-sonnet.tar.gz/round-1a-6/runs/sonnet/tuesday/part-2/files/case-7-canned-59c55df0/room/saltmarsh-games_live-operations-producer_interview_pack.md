# Interview prep pack: Live Operations Producer, Saltmarsh Games

Candidate: Femi. Interviewer: Tobias Wrenfield, Head of Live Operations. Round: one 60-minute interview, built on the assumption that Friday is Saltmarsh's "Outage Hour" with Tobias as hiring manager (the loop source is the Interviewing at Saltmarsh page, listed in Sources). Not yet confirmed: whether he is your direct manager.

## How to use this pack

- Personas describe how a question is asked. Types describe what is being scored.
- Type key: VAL = behavioral and values alignment; EXP = work-experience deep-dive; JD = role and job-description requirement; CO = company and strategy knowledge; CASE = hypothetical or live problem.
- Guidance is scaffolding, not a script. Say everything in your own words, and say only what you actually did.
- An "answer slot" is an instruction for the interview, not a question for you now: say what is true for you, and if the practice did not happen or was not yours, say that plainly.
- Highest-ROI prep in this pack: C2, the in-app-purchases question. It is the one most likely to be asked in some form, and a calm, rehearsed answer changes the interview.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title, with nothing inspected behind it, and the words stay there: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's live-events and two-titles lines make a probe likely. If your calendar held events as well as content drops, say how they differed; if it held only content drops, or only the one title, say so plainly and stay with the weekly calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team" — your message | low | [grounded] | discovery | Your material does not show which teams your calendar involved. The one stated limit is yours to give back: "I haven't led a team." Answer slot: if on any drop you worked with design, art, engineering or community, say which and what you needed from them; if you did not, or it was not yours, say so plainly and say how you would learn each team's constraints |
| F3 | "own the post-event review" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented monthly retention numbers, not that you owned a review of events. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if reviews followed your content drops, say what they covered and which part was yours; if there was no such review, or it was not yours, say so plainly and stay with the monthly presentation |
| F4 | "the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message; "never worked on a game with in-app purchases" — your message | medium | [grounded] | transferability | Retention is the one KPI family your material carries, at the scope of presenting it. The JD does not say which KPIs this role reports, so what the set holds is open. The stated limit is yours to give back: "I haven't worked on a game with in-app purchases." Then how you would learn the rest, said as a plan and never as a past |
| F5 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | A CV-style line with nothing inspected behind it, so expect a probe. Lead with the checklist in the quote's own terms: "I wrote the release checklist our QA team still uses." Your material says wrote it and QA still uses it; it does not say how each release was run against it |
| F6 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | Your material does not say how much of the four years the title was live. Answer slot: the JD asks for live-service years, so expect a probe. If the title was live for more than the last two years, say which part; if the live period was the two years of the weekly calendar, say so plainly |
| F7 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap on the requirement as worded, though nothing is inspected behind it. Lead with it in its own terms: weekly, main title, two years |
| F8 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | The quote reaches the requirement: you presented them, monthly, to the studio head. Your material gives no figure, so no number needs defending, but expect a probe on how they were counted (D1) |
| F9 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [grounded] | discovery | A written document in use is the nearest thing in your material; it does not show how clear it is. Answer slot: if you have a written piece others relied on, such as a checklist or a post-drop summary, name it and what it was for; if the checklist is the only one, say so and stay with it |

## Requirement coverage

| JD requirement | Fit rows | Questions |
|---|---|---|
| Plan and run the live-events calendar for two titles | F1 | A2, A3, A4 |
| Coordinate design, art, engineering and community | F2 | A5, C3 |
| Own the post-event review | F3 | D3, B4 |
| The KPIs it reports | F4 | C2, D3 |
| Manage the release checklist with QA | F5 | D2, B3, E2 |
| 3+ years producing live-service games or apps | F6 | C1 |
| Experience running a content calendar | F7 | A4, F1 |
| Comfortable with player-retention metrics | F8 | D1 |
| Clear written communication | F9 | D3 |

## Reading the interviewer

Public professional footprint only.

| # | Public signal | Source | Provenance | What it means for Friday |
|---|---|---|---|---|
| I1 | Head of Live Operations at Saltmarsh Games | Talk listing, "Patch Notes Are a Promise" (GDC 2026) | [grounded] | He runs the function this role sits in, so questions come from live-ops practice, not general producing |
| I2 | Previously a QA lead at a console studio | Same talk listing | [grounded] | Expect a QA-literate listener on the checklist: D2, E2 |
| I3 | His talk's argument: a live team is judged by how often its patch notes describe what actually shipped | Same talk listing | [grounded] | Expect precision about what was built versus what was announced: A1, B2 |
| I4 | Mirror opportunity, as shared vocabulary and not a shared path: his QA background beside F5's quote "Wrote the release checklist our QA team still uses." — your message | Derived from I2 and F5 | [inferred] | Use the checklist as your natural bridge into release discipline. Do not claim common ground beyond the quote |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (bank A) | A live-incident tabletop on a simulated outage during a live event | High. The Interviewing at Saltmarsh page documents the tabletop as the first part of the hour, and the hiring-manager prior points the same way | Clarify, then structure, then answer; think aloud; challenge one premise respectfully |
| Values / Behavioral (bank B) | A values conversation mapped to Saltmarsh's three published values | High. The same page documents a values conversation as the second part, and the values page names the three | Where a quoted sentence carries a story, map it; where none does, choose a real story or say none comes to mind. "We" for context, "I" for contribution |
| Skeptic (bank C) | Quiet probing of the stated limits and the live-service years | Medium to high. Hiring-manager prior, plus two limits you stated (F2, F4) | Rehearse the in-app-purchases objection until it is boring; concede plainly and give a plan, not a past |
| Data-Driven Prober (bank D) | Line-by-line probing of retention numbers and the checklist | Medium. His talk's theme (I3) and QA background (I2) point to precision about what shipped | Know what you can and cannot say about how the numbers were counted; say plainly where you do not know |
| Pressure (bank E) | Time-boxed challenges in the tabletop; attribution probes | Low to medium. The tabletop is live, so composure counts; the page does not say it is time-boxed | Pause, restate, hold the claim you actually made through two follow-ups, then concede specifically |
| Conversational (bank F) | A friendly opener or a homework question | Low to medium. A 60-minute hour usually opens with the journey | A 90-second arc built only from your own sentences |

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A reward from a live event is not reaching a share of players on day two, and engineering says a fix is hours away. Walk me through your next hour." | CASE | [generic] | Say your structure aloud first. Clarify: what is affected, how many players, since when, what is known and unknown. Decide what to do about the event itself: Saltmarsh's published first value is Players Before Plans, so the players outrank the calendar. Say who you need from design, art, engineering and community, and what you need from each. Tell players only what is built, not what is hoped; that is the second value. Close with a review. Challenge one premise politely, such as the fix time. This question needs no claim about your past, so the guidance makes none | The Outage Hour is documented as a tabletop on a simulated outage during a live event; this scenario is a pattern for it, not Saltmarsh's actual one. CASE because it scores structure and reasoning |
| A2 | "Both titles want the same weekend, and engineering has one release slot. What do you do?" | CASE | [generic] | Clarify what each event is for and what is already promised to players; state the objective; compare the player impact of each; involve QA on what the slot can safely carry; decide and explain what you would tell each team. No claim about your past | JD line on two titles (F1) turned into a decision. CASE because it is a live problem, and the pattern is generic |
| A3 | "From February we run one shared events calendar across the titles. What would you want to know before building it?" | CO | [grounded] Project Larkspur announcement (September 2026), as read in search results; "I ran the weekly content-drop calendar for our main title for the last two years." | Open with what you want to learn, in your own words, and tie it to the announcement: one shared calendar, one live-ops group. Your own calendar is the quote: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if any of your calendar coordinated more than the one title, say how; if it was the one title, say so plainly and say how you would approach two | A differentiator question most candidates will not touch; it rests on the published announcement. Calendar experience is F7 |
| A4 | "The job is to plan and run the live-events calendar for two titles. Starting from the calendar you ran, how would you build that?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Beats the quote states: weekly, main title, two years. Say what that taught you in your own words. Answer slot: the JD's live-events and two-titles lines make a probe likely. If your calendar held events as well as content drops, say how; if it did not, or only the one title, say so plainly and stay with the weekly calendar | The core responsibility, scored directly. F1 is the evidence and F7 the requirement it also closes |
| A5 | "Walk me through how you would run one update across design, art, engineering and community." | JD | [grounded] "Never led a team" | Structure by stage: what each team needs from you, what you need from them, who decides what. The stated limit is yours to give back if asked: "I haven't led a team." Answer slot: if you have worked with any of the four on a drop, say which and what you needed; if you have not, or it was not yours, say so plainly and say how you would learn each team's constraints | JD line on coordination (F2) is a discovery gap, so the honest answer here carries a slot |

### B. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed. What did you do?" | VAL | [grounded] Saltmarsh values page: Players Before Plans; "I ran the weekly content-drop calendar for our main title for the last two years." | Selection scaffold: pick a time you changed or kept a plan because of what players were experiencing. It needs a named stake, what you chose, and what players saw. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I ran the weekly content-drop calendar for our main title for the last two years.", or say how you would handle it | The first published value, and the one a calendar owner is most likely asked about |
| B2 | "Tell me about a time you had to decide what an update announcement could honestly say." | VAL | [grounded] Saltmarsh values page: Ship the Patch Not the Promise; Tobias Wrenfield's GDC 2026 talk listing | Selection scaffold: pick a time you described a release, with a named gap between what was built and what you could say, and the line you chose. If no such time comes to mind, say so plainly, then say how you would handle it: say only what has shipped, and name what has not | Value two, and the theme of his talk (I3) |
| B3 | "Tell me about the release checklist you wrote." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F5: you wrote it, and QA still uses it, which are the beats the quote states. Tell them in your own words. Answer slot: the values page's third value is Leave the Build Greener, about leaving the checklist better than found, so expect a probe on whether it changed. If you updated it after releases, say what and why; if it was not changed, or revisions were not yours, say so plainly and stay with writing it and QA's continued use | Value three, and the clearest story your material carries |
| B4 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Selection scaffold: pick a time a number you presented was not what the room wanted, naming the stake and what you said. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I presented the monthly retention numbers to the studio head.", or say how you would handle it | Persona stem for the values conversation; ties to F3 and F4. Nothing in your material states the hard truth, so no ending is supplied |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "The role asks for three years or more producing live-service games. How much of your four years was live?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio."; "I ran the weekly content-drop calendar for our main title for the last two years." | Say the two quotes at their own scope: four years as an associate producer, and the last two running the weekly content-drop calendar. Answer slot: if the title was live for more than the last two years, say which part and how you know; if the live period was the two years of the weekly calendar, say so plainly | The years requirement is read literally by many hiring managers, so it is a risk to name. F6 is a discovery gap |
| C2 | "You haven't worked on a game with in-app purchases. How would you get to grips with the KPIs on a title that has them?" | JD | [grounded] "never worked on a game with in-app purchases"; "Presented the monthly retention numbers to the studio head."; "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses." | The highest-ROI rehearsal. Say the limit first, before it is asked for: "I haven't worked on a game with in-app purchases." Then the nearest thing your material carries: "I presented the monthly retention numbers to the studio head." Then a plan, said as a plan: name, in your own words, the first two things you would learn and who you would ask. Follow-up 1, "What would worry you most?": name honestly the one thing you would want help with. Follow-up 2, "Why not hire someone who has?": hold, concede the gap again in the same words, and stay with what the quotes carry: the weekly calendar and the checklist. Never describe in-app purchase work as something you have done | F4 pairs a KPI requirement with a limit you stated. This is where the interview is most likely to press; the pattern is generic and not a claim about Saltmarsh's titles |
| C3 | "I don't see team leadership in your background, and this role coordinates design, art, engineering and community. How would you do that?" | EXP | [grounded] "Never led a team" | Give the limit back in your own words: "I haven't led a team." Then what you can honestly say about coordinating. Answer slot: if you have coordinated work across those disciplines on a drop, say which and what you needed; if you have not, or it was not yours, say so plainly and say how you would learn each team's constraints | The negative is yours (F2). The JD's coordination line is why it is asked |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the monthly retention numbers you presented to the studio head." | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Beats the quote states: monthly, retention numbers, the studio head. Answer slot: expect probes on how a number was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. Answer each in your own words; if you do not know how something was counted, say so plainly, and if the counting was not yours, say that and return to presenting them | F8 is the requirement. JD for the retention requirement, EXP delivery. Your material gives no figure, so none is supplied |
| D2 | "The role manages the release checklist with QA. How would you run it across two titles, building on the one you wrote?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Say the quote at its own scope: "I wrote the release checklist our QA team still uses." Answer slot: expect a probe on what the checklist covers and how QA worked with it. Answer in your own words; if part of that was not yours, say so plainly. How you would run it across two titles is a plan, said as one | F5 is the requirement; I2 makes the probe likely |
| D3 | "How would you structure a post-event review that a studio head can act on in five minutes, and which KPIs would it carry?" | JD | [grounded] "Presented the monthly retention numbers to the studio head."; "Wrote the release checklist our QA team still uses." | Structure: what was planned, what happened, what players did, what you would change, and one decision needed. Name the KPIs you would choose in your own words, and say plainly which you would want help choosing. Answer slot: if reviews followed your content drops, say what they covered; if there was no such review, or it was not yours, say so plainly and stay with the monthly presentation | Covers the review, the KPIs and written clarity (F3, F4, F9) |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has run live events with in-app purchases?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses."; "never worked on a game with in-app purchases" | Pause, restate the question, then hold: "I ran the weekly content-drop calendar for our main title for the last two years, and I wrote the release checklist our QA team still uses." Concede the gap once and specifically: "I haven't worked on a game with in-app purchases." Hold through two follow-ups by returning to those two quotes, never by adding to them | Time-boxed form of C2. EXP because it tests what you actually did |
| E2 | "That release checklist: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold only the quote: "I wrote the release checklist our QA team still uses." Answer slot: if anyone else contributed, or QA has changed it since, say so plainly and return to writing it. Do not enlarge it | The standard attribution probe, aimed at the line the interviewer is best placed to test (I2) |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio."; "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses."; "Presented the monthly retention numbers to the studio head." | A 90-second arc in that order, using only those four sentences in your own words. Why live operations and why Saltmarsh are yours to say; nothing in your material states a reason, so none is supplied | Casual openers are still scored. F6 and F7 are the evidence |
| F2 | "What have you been looking at from us lately?" | CO | [grounded] Project Larkspur announcement (September 2026); Saltmarsh values page | Read the announcement and the values page the night before, and say in your own words what struck you. Answer slot: if you have played either title, say what you noticed; if you have not, say so plainly and talk about what you read | Homework check; this is the stem for a rapport-style opener |

## Values and principles cheat sheet

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | Selection scaffold at B1, ending in its honest branch; nearest material is F7's quote, "I ran the weekly content-drop calendar for our main title for the last two years." |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | Selection scaffold at B2, ending in its honest branch; nothing in your material carries an announcement story |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F5: "Wrote the release checklist our QA team still uses." Beats are the quote's: you wrote it, and QA still uses it; the slot at B3 asks whether it changed |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your talk argues a live team is judged by whether its patch notes match what shipped. What does that look like on this team week to week?" | Ties to his own public work and signals you researched him, not just the company |
| R2 | "You came to live operations from QA. What from that time shows up in how you run live ops?" | Ties to his own path (I2) and turns the hour into a peer conversation |
| R3 | "Project Larkspur moves to one shared events calendar and one live-ops group from February. Would this role build that calendar or inherit it?" | Shows you read the announcement, and answers what "two titles" means in practice |
| R4 | "What would a strong first 90 days look like, and which KPIs would I report in it?" | Maps to the JD's KPI line and surfaces which KPIs the role really owns |
| R5 | "Can you tell me about a recent time the calendar gave way to the players?" | Tests whether the first value is practised, and gives you a live example to compare with |
| R6 | "What did the strongest candidates do in the Outage Hour that others did not?" | Shows you are thinking about the format and invites a direct steer |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team | Negative you stated, F2 | The plain acknowledgment: "I haven't led a team." No slot |
| Has worked on a game with in-app purchases | Negative you stated, F4 | The plain acknowledgment: "I haven't worked on a game with in-app purchases." Then a plan, never a past |
| Ran live events across two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says a weekly content-drop calendar for your main title. A4's slot stays inside the calendar |
| Owned post-event reviews and the KPIs they report | Inflated form of F3 and F4 | F3's quote at its own scope. The limit is the pack's observation: your material says you presented monthly retention numbers. D3's slot asks only what any review covered |
| Managed each release with QA | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation: your material says you wrote the checklist and QA still uses it. D2's slot stays inside the checklist |

## Sources

Provided: the job description and your background, as given in your message. No dossier was present.

Queries sent:

- "Saltmarsh Games values" returned https://saltmarshgames.com/values
- "Saltmarsh Games interview process live operations producer" returned https://saltmarshgames.com/careers/interviewing
- "Saltmarsh Games strategy mobile games news" returned https://saltmarshgames.com/news/project-larkspur (read as a search snippet only, dated September 2026)
- "Tobias Wrenfield Saltmarsh Games Head of Live Operations" returned https://talks.gdconf.example/2026/patch-notes-are-a-promise (read as a search snippet only)

Pages fetched: https://saltmarshgames.com/values and https://saltmarshgames.com/careers/interviewing.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet; banks B and A1 use the three values by name |
| 2. `Saltmarsh Games interview process live operations producer` | yes | Loop structure: one session, a tabletop then a values conversation; persona weights follow it; a values-style round is detected |
| 3. `Saltmarsh Games strategy` / recent news | yes | A3 and F2, and reverse question R3, from the Project Larkspur announcement |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | Interviewer read, B2, D2 and reverse questions R1 and R2 |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Whether Tobias would be your direct manager → reweights banks A and B and the reverse questions
- What your recruiter said about the tabletop (an outage type, a focus, a time limit) → tailors bank A to the actual scenario instead of the generic ones
- How many hours you have before Friday → a prep triage sized to it, with the few things worth doing in order
- Your answers to the answer slots in F1, F2, F3, F6 and F9 → those discovery and transferability rows become grounded and the matching slots in A4, A5, B3, C1, C3, D3 turn into story maps
- The artifacts your field keeps (the checklist itself, a sample of your weekly calendar, a retention deck) → medium-confidence rows F1, F5, F7 and F8 can reach high
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a strategy brief and Tobias's other talks and writing, so bank A and the interviewer read go deeper; offered once
- A `tuesday-dossier.md` from an earlier run → graded evidence and absolute prohibited claims to replace the ones built here; not needed for this pack
