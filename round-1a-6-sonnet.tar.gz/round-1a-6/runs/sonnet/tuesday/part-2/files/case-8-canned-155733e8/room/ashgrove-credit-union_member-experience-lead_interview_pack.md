# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara. **Date of all three rounds:** 5 December 2026 (nine days from 26 November). **Mode:** loop, because three rounds are scheduled.

| Round | Who | Length | What the recruiter's email says |
|---|---|---|---|
| 1 | The recruiter | 30 minutes | A screen |
| 2 | Head of Member Services, who would be your manager | 45 minutes | Mostly behavioural |
| 3 | Panel of two branch managers | 60 minutes | Includes a 20-minute case on a complaint escalation; the panel is also the values round and scores against the four values |

Interviewer names beyond these roles have not been assigned, so there is no interviewer read in this pack.

## How to use this pack

- **Personas** describe how a question will be asked: A Conversational, B Skeptic, C Values/Behavioral, D Case/Strategist, E Data-Driven Prober, F Peer Evaluator. **Types** describe what is being scored: VAL (values alignment), EXP (work-experience deep-dive), JD (role and listed requirements), CO (company and strategy knowledge), CASE (live problem).
- Question IDs read round, persona letter, number: R2-B1 is round 2, Skeptic, first question.
- **Guidance is scaffolding, not a script.** Every claim about your past in this pack is a sentence you wrote, quoted next to the guidance. An **answer slot** is an instruction for the interview, not a question for you now: say what is true in your own words, and if the step was not yours or never existed, say that plainly.
- Wording marked as proposed language is pending your approval: change anything that is not how it happened.

## Prep triage

Nine days is enough to do these well, in this order. Everything else is insurance.

1. **R2-B1**, the contact-centre ladder. It is the highest-ROI prep in the pack (reasoning under the persona table). R1-B1 is its short form.
2. **R3-D1 to R3-D4**, the case. Say it aloud once, timed to 20 minutes. The four values are its spine.
3. **R2-B2 and R2-E1**: the presenting gap, and the monthly spreadsheet you built.
4. **R3-C1 to R3-C4**: one real story per value from your own work, or the honest branch where none comes to mind.
5. **R1-A3 to R1-A6**: decide your own answers on reason for leaving, pay, notice and location before the 5th.

## Fit snapshot (shared across rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says the branch's log, not the process end to end, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what happened to a complaint beyond the log likely. If any later steps were yours, say which, in your own words; if the log was the extent of it, or the steps belonged to others, say so plainly and stay with the log |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you stated it. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan ("I would...") and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The sentence reaches monthly complaints reporting but does not show what the spreadsheet held. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names volumes and resolution times, so expect a probe on what was in it. If it counted either, say what and how it was counted; if it held neither, or something else, say so plainly and describe what it held |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The sentence says spreadsheet, not which program. Answer slot: say which program it was built in and what you did in it, in your own words; if it was built elsewhere than the tool the JD names, or parts were not yours, say so plainly and stay with the spreadsheet |
| F5 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your sentence says new tellers and the escalation script; supervisors are a different audience. Words: "I trained new tellers on our escalation script." Answer slot: if you have coached anyone at supervisor level on an escalation, say who and what; if not, say so plainly and stay with the tellers |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it, so expect a probe. Lead with it in its own terms: six years in retail banking, the last three as a branch supervisor |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | The sentence says formal complaints, and nothing shows whether rules or deadlines governed them. Words: "I handled the branch's formal complaints log." Answer slot: expect a probe on what made a complaint formal at your branch and what the log recorded. If particular rules or deadlines governed it, say which, in your own words; if none you knew of did, say so plainly and stay with the log |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you stated it. Words: "I've never presented to anyone above regional level." Then a plan, said as a plan. Never a claim to leadership presenting |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing about digital work. Answer slot: if you have worked with a digital or app team on something a member used themselves, say what and which part was yours; if not, say so plainly and say how you would start |

No row is a gate: the JD sets no authorization, licence, location, schedule or pay term, so no gate question is asked.

## Grounding brief

From your summary of the 2026 strategy brief the recruiter sent, published July 2026, so under six months old at 5 December. The brief itself was not in hand.

| Point, as you gave it | Source | Provenance | Feeds |
|---|---|---|---|
| "move 40% of member service to digital channels by 2028" | your message | [grounded] | R2-D1, R3-D4 |
| "consolidate eight branches into five hubs over 2027" | your message | [grounded] | R2-D2, R3-D4, R3-C3 |
| "launch a small-business lending product in Q1 2027" | your message | [grounded] | Background only; no question rests on it |
| "the main competitive pressure is app-only banks" | your message | [grounded] | R2-D1 |
| The JD and the values page say "member", not "customer"; the JD says "self-service journeys" | JD and values as pasted | [grounded] | Use their words in every answer |

The brief is public to every prepared candidate, so recite none of it: one point to show you read it, then a view of your own with reasons (R2-D1 shows how).

## Round 1: recruiter, 30 minutes

### Personas

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A Conversational | Friendly walk-through, motivation, logistics | High: a recruiter screen sits at this persona's relationship prior, and 30 minutes leaves room for little else | Know your 90-second arc; treat casual questions as scored |
| B Skeptic | Knockout checks on the JD's listed requirements | Medium-light: the recruiter will check the JD's items, and your material states two absences (F2, F8) | Say the stated gap plainly once, then the plan, and stop |

### A. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-A1 | "So, walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F6 and F1 at the quotes' scope: six years in retail banking, the last three as a branch supervisor, and that you handled the branch's formal complaints log. Say why this role in your own words; the pack supplies no motive. About 90 seconds | The opener of almost every screen; EXP because it checks what the self-reported line claims. F6 and F1 are the evidence |
| R1-A2 | "What draws you to a member-owned credit union?" | CO | [grounded] | Your reasons must be yours; the pack supplies none. Pick one thing in Ashgrove's own published words, the JD's "member-owned" or one of the four values, that matches a real reason, and say the reason first. If none matches, say what does draw you, plainly. Do not recite all four values | Recruiters check motivation consistency; CO because it tests homework on published words. The JD and the pasted values page are the sources |
| R1-A3 | "Why are you looking to move on from your current role?" | EXP | [generic] | Logistics slot: give your own reason, in your own words, once and plainly. The pack supplies none. If it comes up again, repeat the same reason in the same words | Asked in nearly every screen; EXP because it tests consistency of story. Your message states no reason, so no row applies |
| R1-A4 | "What salary are you looking for?" | JD | [generic] | Logistics slot: give your own figure, or ask what the band for the role is before naming one. The pack holds no figure of yours and supplies none. If asked what you earn now, a line to prepare: "I'd rather focus on the range for this role." | The JD sets no pay term, and recruiters raise pay early. Your message states none |
| R1-A5 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period. The pack supplies none | A standard screen item; your message states none |
| R1-A6 | "The role spans branches and the contact centre. Where would you be based, and what travel between sites is workable for you?" | JD | [grounded] | Logistics slot: say where you can work from and what travel you can do, using your own facts. Your message gives neither, and the pack supplies neither | The JD's "across branches and the contact centre" makes site and travel a likely question; no row covers it |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-B1 | "The role covers the contact centre, and you haven't worked in one. How do you see that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Say it plainly: "I haven't worked in a contact centre." Then one plan, with "I would": the first things you would want to learn about how complaints are handled there, and who you would ask. Stop there. The pack's observation is that your material does not show branch work to be the same as contact-centre work, so do not say it is. The deep version is R2-B1 | F2 is the gap the JD's first line presses on; JD because it tests a listed part of the remit |
| R1-B2 | "How comfortable are you in Excel, and what do you use it for?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F4 at the quote's scope: you built the monthly complaints spreadsheet your regional manager uses. Answer slot: say which program it was built in and what you did in it; if it was built elsewhere, or parts were not yours, say so plainly and stay with the spreadsheet | The JD's "comfortable with Excel reporting" is a screen-level knockout; F4 is the evidence and its limit |
| R1-B3 | "The role needs experience handling regulated complaints. What does that look like in your background?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F7 at the quote's scope: "I handled the branch's formal complaints log." Answer slot: expect a probe on what made a complaint formal at your branch and what the log recorded. If particular rules or deadlines governed it, say which; if none you knew of did, say so plainly and stay with the log | The JD lists regulated complaints as a requirement, so a screen checks it. F7 holds the evidence and the open point |

### Reverse questions, round 1

| # | Question | Why it lands |
|---|---|---|
| 1 | "Will the case in the panel round be shared beforehand, or is it cold on the day?" | Shows you are planning for the 20-minute case, and the answer changes how you prepare |
| 2 | "When will the panel's names be confirmed?" | Names unlock an interviewer read for round 3; recruiters can usually say |
| 3 | "How is the complaints work split today between branches and the contact centre?" | Tells you how large the contact-centre side of the role really is, which is the gap F2 names |

## Round 2: Head of Member Services, 45 minutes

### Personas

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| C Values/Behavioral | "Tell me about a time..." scenarios | High: the recruiter calls the round mostly behavioural | Quoted-sentence stories where one exists; scaffolds with the honest branch where none does |
| B Skeptic | Probing the contact-centre and presenting gaps | High: a future manager is buying capability and weighing risk, and your material states both gaps | Rehearse R2-B1 until it is boring; say each gap once, then the plan |
| E Data-Driven Prober | What was in the report, how it was counted | Medium: reporting is one of four duties and F3 is your most concrete evidence | Know what you can and cannot say about what it counted; say plainly when you do not know |
| D Case/Strategist | Strategy and a live reporting problem | Medium: the hiring-manager prior, tempered by "mostly behavioural", and the strategy brief gives real material | Clarify, structure, answer; challenge one premise respectfully |

**Highest-ROI prep in the pack: R2-B1.** The JD's first line puts the contact centre inside the remit, you have said you have not worked in one, and your future manager will ask in some form. A rehearsed, non-defensive answer changes the round.

### C. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not soften it, and a working relationship that survived; "I" for what you said, "we" for context. If no such time comes to mind, say so plainly, then give the nearest thing you actually did, or how you would handle it. Do not reach for a leadership audience you did not have | Behavioural rounds reach for this prompt; VAL because it scores behaviour, not knowledge. F8 is where it presses hardest |
| R2-C2 | "Tell me about a time you helped someone handle an escalation they were not sure how to handle." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F5 at the quote's scope: "I trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on what happened when someone was not sure likely. If any teller needed more than the script, say what you did, in your own words; if the training was the extent of it, say so plainly and stay with the training | The JD's "coach branch supervisors on escalations" is the raising source; F5 holds the evidence and its limit |
| R2-C3 | "Tell me about a time you took a complaint from the first report to a resolution and kept hold of it." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold, because the quote carries a log, not a complaint's story: pick one complaint, with a named stake, who else touched it, and how it ended. If none comes to mind, say so plainly, then give the nearest thing your material carries, "I handled the branch's formal complaints log", or how you would keep hold of one | The JD's end-to-end line and the Own the Fix value both raise it. F1 is the evidence |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-B1 | "You would own complaints in the contact centre as well as the branches, and you haven't worked in a contact centre. Walk me through your first month." | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "6 years in retail banking, the last 3 as a branch supervisor." | **Level 1, the answer.** Start with "I haven't worked in a contact centre." Then three beats, each with "I would": what you would want to see first (how complaints are recorded and resolved there), who you would ask, and what you would not change before you understood it. **Level 2, likely follow-up: "What if the team does not take you seriously?"** Hold the plan; do not claim equivalence with their experience. **Level 3, likely follow-up: "Why not someone who has done it?"** Concede the specific thing: "That is a real gap, and I won't pretend otherwise." Hold what the quotes carry: "I handled the branch's formal complaints log", and six years in retail banking, the last three as a branch supervisor. **Limit named before you are asked:** you cannot speak to contact-centre volumes, tools or how complaints arrive there. Do not fold the core point to restore harmony | F2 is the objection and F1 and F6 are what you hold. JD because it tests the stated remit; Skeptic because it is the single most predictable objection |
| R2-B2 | "Part of this role is presenting to senior leaders. What is the most senior audience you have presented to?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Say it early and plainly: "I've never presented to anyone above regional level." Answer slot: if you have presented at regional level, say what and to whom; if that level never saw you present, say so plainly. Then a plan, said as a plan: what you would do to prepare for a first leadership session, in your own words | F8 is the gap; JD because the requirement is listed |
| R2-B3 | "This role spans branches and the contact centre across about 900 staff. What changes when you go from the log you handled to the whole process?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Hold what the quote carries: "I handled the branch's formal complaints log." The pack's observation is that your material says the log, not the whole process. Answer slot: if any step beyond the log was yours, say which; if not, say so plainly, and say what you would need to learn first | F1 is where the scale of the role presses on the evidence |

### E. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-E1 | "Walk me through the monthly complaints spreadsheet: what was in it, and who read it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F3, with the beats the quote states: you built it, it was monthly, your regional manager uses it. Answer slot: the JD names volumes and resolution times. If it counted either, say what was counted, how, what it is most sensitive to, and the assumption behind it you would defend least; if it held neither, or the counting was not yours, say so plainly and describe what it held | F3 is your most concrete reporting evidence and so the likeliest to be probed; EXP because it tests what was actually yours |
| R2-E2 | "Resolution times have been getting longer for three months. What do you look at first?" | CASE | [generic] | Think aloud: first clarify what starts and stops the clock and what counts as resolved. Then split by channel (branch, contact centre), complaint type and age of case, and check whether volume or mix changed. Say where you would look first and what you would tell leadership. The question needs no claim about your past, so the guidance makes none | Tests the reporting duty as a live problem rather than a record; CASE because it is a diagnosis. The JD's volumes and resolution times are its source |

### D. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-D1 | "The strategy moves 40% of member service to digital channels by 2028, and this role works with digital teams on self-service journeys. Where do complaints fit?" | CO | [grounded] | Think aloud: clarify which journeys move first and whether complaints sit inside the 40%; then objective, segments, approach, metrics, risks. **Differentiate.** Bring one consensus point to prove you read the brief (digital lowers handling effort), then one view of your own with a concession. Options, all arguments not facts: every digital route needs a named human owner, with the concession that self-service suits simple queries; track resolution times by channel so the move cannot hide slow cases; against app-only banks, how a credit union handles a complaint is part of what it offers. Answer slot (F9): if you have worked with a digital or app team on something a member used themselves, say what and which part was yours; if not, say so plainly and say how you would start | The brief's digital target and the JD's digital-teams line both raise it; CO because it tests thinking at the company's altitude. F9 holds the open point |
| R2-D2 | "The strategy consolidates eight branches into five hubs over 2027. What happens to complaints while that is going on?" | CO | [grounded] | Think aloud: clarify which branches change and in what order, and what members are told and by whom. What you would watch: volumes and resolution times by branch before and after, the monthly report the JD asks for. Say who owns a complaint while its branch is changing. Offer these as hypotheses to test, never as predictions. The Neighbours, Not Numbers value is the tension: put the member's side first | The hub plan is the strategy item closest to complaints and to the third-round panel. F3 is the reporting evidence the answer leans on |

### Reverse questions, round 2

| # | Question | Why it lands |
|---|---|---|
| 1 | "What does a good first 90 days look like, including the contact-centre side?" | Invites them to say how much weight the contact centre carries, which tells you how large F2 is |
| 2 | "How are complaint volumes and resolution times reported today, and what do you wish they showed?" | Frames reporting as shared work and shows you think about what a number should answer |
| 3 | "How do you see the move to 40% digital service by 2028 changing the complaints this role carries?" | Uses the brief's own figure without reciting the rest, and shows you read it |
| 4 | "Which leadership forums would I present to, and how often?" | Turns F8 into a practical question and signals you are already planning for it |

## Round 3: panel of two branch managers, 60 minutes

### Personas

Names are unassigned, so each member's persona is a blend. Roughly a third of the time, 20 of 60 minutes, is the case.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| C Values/Behavioral | A scored scenario per value | High: the recruiter says the panel is the values round and scores against the four values | One real story per value, or the scaffold's honest branch |
| D Case/Strategist | The 20-minute escalation case | High: the recruiter announced it, and it takes a third of the round | Clarify, objective, segmentation, approach, metrics, risks; think aloud |
| F Peer Evaluator | Seam-splitting between your role and theirs | Medium: they run branches, your role coaches their supervisors, and the JD has you work across branches. This is an inference from the recruiter's description, not a documented format | Reciprocity first; propose seam principles rather than pretending to know the seam |

### C. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-C1 | "Tell me about a time you decided from the member's side of the counter when that was the harder path." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Selection scaffold for **Members First, Always**: pick a decision where the member's interest and the easier internal route differed, with a named stake, what you chose, what it cost, and how it ended. If none comes to mind, say so plainly, then give the nearest thing you did in your branch supervisor years, in your own words, or how you would decide | The value's own wording ("from the member's side of the counter") is the raising source; no quoted sentence carries a decision story |
| R3-C2 | "Tell me about a time something had to be explained to someone twice." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F5 for **Plain Words**, at the quote's scope: "I trained new tellers on our escalation script." Answer slot: if any teller needed it explained twice and you changed how you explained it, say what you changed; if that did not happen, say so plainly and stay with the training | The value says "if a member needs it explained twice, we wrote it wrong", which raises the theme. F5 is the only evidence near it |
| R3-C3 | "Tell me about a time you thought of a branch as part of its town, not only as numbers." | VAL | [grounded] | Selection scaffold for **Neighbours, Not Numbers**: pick a decision where a branch's place in its community changed what you did, with a named stake and how it ended. If none comes to mind, say so plainly, then say how you would weigh it. Pair it with R2-D2: a panel of branch managers sits close to the hub plan, so expect this value to be pressed. That is an inference, not a source | The value is the raising source. No quoted sentence carries a community story, so none is claimed |
| R3-C4 | "Tell me about a time you found a problem that was not yours to fix, and what you did about it." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold for **Own the Fix**: pick a problem you found, the point at which you decided to keep hold of it, who you worked with, and how it ended. If none comes to mind, say so plainly, then give the nearest thing your material carries, "I handled the branch's formal complaints log", or how you would keep hold of one | "Whoever finds the problem keeps hold of it until it is solved" is the raising source. F1 is the nearest evidence, and it carries a log, not a story |

### D. Case/Strategist

This is a practice case written for rehearsal, not Ashgrove's case. The four values give a ready spine for any complaint escalation: the member's side first, one owner until it is solved, words that need no second explanation, and the branch's town in view.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-D1 | "A member has complained three times, at the branch, to a branch manager and through the contact centre, and was told something different each time. You have been asked to take it over. What do you do?" | CASE | [generic] | **Clarify first:** what the member was told, by whom, what they want, whether it is already a formal complaint and what timeframe applies (ask, do not assume). **Objective:** solve it from the member's side, with one named owner until it is closed. **Segment:** the member's issue, and the process fault that let three different answers out. **Approach:** one person contacts the member, one account of the facts goes to the branch and the contact centre, and the reply is written so it needs no second explanation. **Metrics:** time to resolve, number of handoffs, whether the member had to repeat themselves. **Risks:** blame landing on the branch, conflicting records, a missed deadline. **Challenge one premise politely:** why it took three contacts before anyone owned it. The question needs no claim about your past, so the guidance makes none | The recruiter announced a complaint-escalation case; CASE because it scores structure, not the right answer. The JD's end-to-end line is the source |
| R3-D2 | "The branch supervisor says your plan makes the branch look bad. What do you say?" | CASE | [generic] | Hold the member-first position and one agreed account of the facts. Concede only what is real: the supervisor's concern about blame is legitimate. Turn it into a coaching conversation, not a verdict. Do not promise what you cannot control | A branch-manager panel will test how you handle the people you coach; this follow-up is a likely form |
| R3-D3 | "Afterwards, what would you put in next month's report from this one case?" | JD | [generic] | Name what the case adds to volume and resolution-time figures, how many handoffs it took, and one plain-words line a leader could read without a second explanation. No claim about your past | Ties the case to the monthly-reporting duty. F3 is the evidence behind the duty; the question itself needs none |
| R3-D4 | "The member's branch is one of the eight due to be consolidated into five hubs. Does that change your approach?" | CASE | [grounded] | Think aloud, as hypotheses: who owns the complaint after the branch changes, what the member is told and in what words, and how the branch's place in its town affects the conversation. Do not predict outcomes as facts | A twist built from the brief's hub plan and the Neighbours, Not Numbers value; offered as rehearsal, not as a forecast of the panel's case |

### F. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-F1 | "You would be asking our supervisors to change how they handle escalations. What would you need from us, and what do we get from you?" | JD | [generic] | Reciprocity first: what you would give the branches, in "I would" terms, then what you would need from them. The guidance makes no claim about your past | A panel of branch managers is the other side of the coaching duty; JD because it scores the listed remit |
| R3-F2 | "Where is the seam between your role and a branch manager's when an escalation goes wrong, and what happens when we disagree?" | JD | [generic] | Propose seam principles rather than pretending to know their seam: one owner at a time, and agree the handover with them. For disagreement, a scaffold: pick a disagreement with an equal where you showed spine and tact together, with a named stake and how it ended. If none comes to mind, say so plainly, then say how you would handle it | Peer persona stem; the JD's coaching line is the raising source |
| R3-F3 | "You have trained new tellers. Our supervisors are experienced. How is coaching them different?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Hold what the quote carries: "I trained new tellers on our escalation script." Answer slot: if you have coached anyone at supervisor level, say who and what; if not, say so plainly and say how you would approach people who know the job | F5 is the evidence and its limit; the relationship between tellers and supervisors is a different one |

### Values and principles cheat sheet

Built because the recruiter says the panel scores against the four values, and your pasted values page names them. Values are quoted from the page as you copied it on 26 November 2026.

| Value (official name) | Working meaning, paraphrased | Mapped story or scaffold |
|---|---|---|
| Members First, Always | Decisions start from how they land for the member | F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." That sentence carries a log and training, not a decision, so use the R3-C1 scaffold, with its honest branch |
| Plain Words | Wording that needs no second explanation | F5: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Story-mapped at the quote's scope in R3-C2, with its answer slot |
| Neighbours, Not Numbers | Each branch counts as part of its town | No quoted sentence carries a story. Use the R3-C3 scaffold, ending in its honest branch |
| Own the Fix | The person who finds a problem keeps it until it is solved | F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Nearest evidence only; use the R3-C4 scaffold, with its honest branch |

### Reverse questions, round 3

| # | Question | Why it lands |
|---|---|---|
| 1 | "What could a new person do in their first month that would genuinely help your branch?" | The reciprocity question for a panel of branch managers |
| 2 | "Which part of the escalation process do your supervisors find hardest?" | Invites lived experience and tells you where coaching would matter first |
| 3 | "Which changes in the 2027 hub plan do you expect to bring the most member concerns?" | Uses the brief's hub plan and the Neighbours, Not Numbers value, and lets them answer from where they stand |
| 4 | "How would you like to hear about complaint trends that touch your branch, and how often?" | Connects the monthly report to the people who will read it |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| Own the member complaints process end to end across branches and the contact centre | R1-B1, R2-B1, R2-B3, R2-C3, R3-D1, R3-D4 |
| Report monthly on complaint volumes and resolution times | R2-E1, R2-E2, R3-D3 |
| Coach branch supervisors on escalations | R2-C2, R3-D2, R3-F1, R3-F2, R3-F3 |
| Work with digital teams on self-service journeys | R2-D1 |
| 4+ years in financial-services customer operations | R1-A1 |
| Experience handling regulated complaints | R1-B3, R2-C3 |
| Confident presenting to senior leaders | R2-B2, R2-C1 |
| Comfortable with Excel reporting | R1-B2, R2-E1 |

## Prohibited claims

What this pack will not coach, because your own sentences do not support it. Built locally, with no dossier present.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says the branch's log, not the process end to end |
| Has contact-centre experience | Negative you stated, F2 | The plain acknowledgment: "I haven't worked in a contact centre." Then a plan, no slot |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment: "I've never presented to anyone above regional level." Then a plan |
| Handled complaints under a regulator's rules | Inflated form of F7 | F7's quote at its own scope: formal complaints, with a log. The slot in R1-B3 stays inside the log |
| Reported complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope: the monthly spreadsheet your regional manager uses. The slot asks only what it held |
| Built the report in a named program | Inflated form of F4 | F4's quote: "spreadsheet". The slot asks which program, without supplying one |
| Coached branch supervisors | Inflated form of F5 | F5's quote at its own scope: new tellers and the escalation script |

## Sources

**Provided documents:** the job description; the values text you copied from ashgrovecu.org/about/values on 26 November 2026; the recruiter's email on the process; your summary of the July 2026 strategy brief; your background as you gave it. No `tuesday-dossier.md` was present. The page you named for the values is where your pasted text came from, so it was not fetched. The loop is established by the recruiter's email, which gives three sessions and says who runs each and what it holds, and it documents a values-style round, so no archetype fallback was used.

**Searches and fetches sent:** none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | Could not have moved the values cheat sheet: your pasted page already gives the four values by name |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | Could not have moved the persona weights: the recruiter's email already fixes the rounds, who runs them and what they hold |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | Could not have moved the CO bank: the four brief points you gave, under six months old, supply current priorities and the competitive frame |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No interviewer name was given, only roles, so there was no query to form |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Interviewer names for rounds 2 and 3, once assigned → an interviewer read, persona weights adjusted to their public footprint, and a reverse question tied to a career path
- The strategy brief itself, not the four points → the CO and CASE questions can use its own wording, and you can see where it frames complaints, if anywhere
- A redacted copy of the spreadsheet's layout (column headings only, no member data) → F3 and F4 can rise from `medium` to `high`, and R1-B2 and R2-E1 move from slots to story-mapped answers
- Your own answers on F1, F5, F7, F8 (regional level only) and F9, said in your own words → those rows regenerate with your sentences quoted, and the slots in R1-B3, R2-B2, R2-C2, R2-D1 and R3-F3 become story-mapped
- The recruiter's note on the panel case, if there is one (format, whether material is shared) → the R3-D bank is reshaped to it, and this is usually one email
- A deeper research pass, up to 6 more searches and 2 more fetches and several more minutes, offered once → recent organisation context and reports from role-family loops, and a stronger substitute for the brief if it cannot be shared
- A `tuesday-dossier.md` from an earlier assessment of this role, if you ever have one → graded evidence and a list of claims to avoid, which would sharpen the guidance and the prohibited list
