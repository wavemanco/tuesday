# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara. **Loop:** three rounds, all on 5 December 2026.

| Round | Who | Length | What the recruiter said |
|---|---|---|---|
| 1 | The recruiter | 30 minutes | A conversation about the process and the role |
| 2 | Head of Member Services, who would be your manager | 45 minutes | Mostly behavioural |
| 3 | Panel of two branch managers | 60 minutes | Includes a 20-minute case on a complaint escalation; also the values round, scored against the four values |

Interviewer names are not assigned yet, so there is no interviewer read. The case's content is not known, so the case bank is built on the pattern of a complaint escalation, not on Ashgrove's own case.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: everything it says about your past is a sentence you wrote, kept at the scope you wrote it. Where the pack could not know something, it leaves an answer slot for you to fill from your own experience, and every slot allows for the honest answer being "that was not me" or "that did not exist".

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows Ashgrove's published values |
| EXP | Whether what you have told them survives questions about what you actually did |
| JD | The listed responsibilities and requirements, including the gaps |
| CO | Whether you can think at the company's altitude: strategy, competition |
| CASE | A live problem from the role, reasoned out loud |

Fit rows are F1 to F9. Question letters skip F so the two never collide.

## Prep triage

You have nine days. These are the few things to do well, in this order; everything else is insurance.

1. **26 to 27 November:** write and say aloud your answers to D1 and D2, then B1, which draws on the same two gaps. D1 is the highest-ROI rehearsal in this pack.
2. **28 to 29 November:** for H1 to H4, pick one real story each using the scaffolds. Answer the slots on F2, F3, F5, F6 and F9 for yourself, and send me what you answer so the pack can quote it.
3. **30 November to 1 December:** J1 to J3 aloud, timed to 20 minutes, thinking out loud.
4. **2 to 3 December:** G1 and J3 (the spreadsheet), C1 to C4, and H5.
5. **4 December:** the A1 arc, then A3 to A6 in your own words. All three rounds are on the same day, so your reason, notice, pay position and the two gaps must come out the same each time.

Everything else is insurance.

## Fit snapshot

Shared by all three rounds. Evidence is your own words and nothing else.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Your words are retail banking and branch supervisor and the posting's are customer operations, so keep your words: "I've spent six years in retail banking, the last three as a branch supervisor." |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | discovery | Your sentence says a formal complaints log, not a regulated one, and the pack does not close that for you. Answer slot: the posting's regulated-complaints line makes a probe on what rules the log followed likely. If it was kept to regulatory rules, say which and how, in your own words; if it was not, or you do not know, say so plainly and stay with the formal complaints log you handled |
| F3 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says the log and the script, not the process end to end, with nothing inspected behind it, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the end-to-end line makes a probe on the stages likely. If any stage beyond the log was yours to set or run, say which and how, in your own words; if there was no such stage, or it was not yours, say so plainly and stay with the log |
| F4 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing in your material reaches the contact centre, so none is claimed |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | Your sentence says a monthly complaints spreadsheet your regional manager uses; it does not say what it counted, so the pack does not say it counted volumes or times. Answer slot: the posting names both measures, so expect a probe on what the sheet showed. If it showed either, say which and how it was counted, in your own words; if it did not, say so plainly and stay with the monthly spreadsheet you built |
| F6 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says tellers, not supervisors, and training on a script, not coaching on live escalations. The words stay at that scope: "I trained new tellers on our escalation script." Answer slot: the coaching line makes a probe on whether you have supported anyone through a live escalation likely. If you did, say who and what you did, in your own words; if you have not, say so plainly and stay with the training |
| F7 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Nothing in your material speaks to this, so the pack says nothing about it. Answer slot: the posting names digital teams and self-service journeys, so expect a probe. If you have worked with a digital team on anything members use without staff, say what and what you did, in your own words; if you have not, say so plainly and say what you would ask a digital team first |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Your material does not say where Ashgrove's senior leaders sit against regional level, so the size of this gap is not known to this pack; the Round 2 reverse questions ask. Then how you would prepare, said as a plan and never as a past |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | Your word is spreadsheet and the posting's is Excel, and the pack does not assume they are the same. Answer slot: if it was built in Excel, say so, in your own words; if it was another tool, say so plainly and stay with the monthly complaints spreadsheet you built |

## Grounding brief

What the strategy brief says, as you gave it. The brief itself was not pasted, so nothing beyond these four points is claimed.

| Point | Feeds | Provenance |
|---|---|---|
| Move 40% of member service to digital channels by 2028 | E2, E3, reverse questions | [grounded] your summary of the July 2026 brief |
| Consolidate eight branches into five hubs over 2027 | H5, reverse questions | [grounded] your summary of the July 2026 brief |
| Launch a small-business lending product in Q1 2027 | Round 2 reverse questions | [grounded] your summary of the July 2026 brief |
| The main competitive pressure is app-only banks | E2 | [grounded] your summary of the July 2026 brief |

## Prohibited claims

Built from the fit snapshot before any bank was written. None of these is coached, softened or implied anywhere in this pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran the complaints process end to end | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation, not words for you: the material says the log and the script, not the process. D4's slot stays inside the log |
| Handled regulated complaints | Inflated form of F2 | F2's quote at its own scope. Your material says a formal complaints log, not a regulated one. B2's slot asks only what rules the log followed |
| Coached supervisors on escalations | Inflated form of F6 | F6's quote at its own scope: trained new tellers on the script. C2's slot stays with the training |
| Wrote or designed the escalation script | Inflated form of F6 | "I trained new tellers on our escalation script" at its own scope. Your message says you trained tellers on it, not who wrote it. H2's slot stays with the training |
| Reported complaint volumes and resolution times | Inflated form of F5 | F5's quote at its own scope. Your message says a spreadsheet, not what it counted. G1 and J3 ask only what the sheet showed |
| Presented complaint figures to the regional manager | Inflated form of F5 | F5's quote at its own scope: the regional manager uses the sheet. Your message does not say you presented it |
| Built it in Excel, or has Excel expertise | Inflated form of F9 | F9's quote at its own scope: a spreadsheet. G1's slot asks only what it was built in |
| Has contact-centre experience | Negative you stated, F4 | The plain acknowledgment: "I've never worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment: "I've never presented to anyone above regional level." No slot |

---

# Round 1: the recruiter (30 minutes)

## Persona weights

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly, unstructured opener; pay, notice, location, reason for looking; motivation | Top. A recruiter screen's prior is Conversational plus a light Skeptic, and the recruiter's own words describe a 30-minute conversation. Casual questions here are still scored | A pre-scripted 90-second arc (A1); each logistics answer in your own words and identical across all three rounds |
| Skeptic (light) | Knockout checks on the lines the posting leans on | Light. The JD names the contact centre and regulated complaints, and your own words state one of the two gaps. Expect it phrased as a friendly check | Say each gap plainly once, then move to your plan. Do not defend; do not inflate |
| All others | Pressure, Prober, Case, Peer, Values | Low. Not expected in a 30-minute recruiter call from the relationship prior; the Values and Case styles arrive in Rounds 2 and 3 | Nothing to rehearse here |

## Question bank

### A: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc with one beat per sentence you wrote. Beat 1: six years in retail banking, the last three as a branch supervisor. Beat 2: you handled the branch's formal complaints log and trained new tellers on your escalation script. Beat 3: you built the monthly complaints spreadsheet your regional manager uses. Beat 4: why this role, in your own words. Answer slot: if you want to say why you are moving now, give your actual reason; the pack supplies none. Stop each beat where the sentence stops | F1, F3, F5 and F9 are what the arc sets up. EXP because it fixes the biography every later round will test |
| A2 | "What draws you to Ashgrove, and to a credit union?" | CO | [grounded] | No claim about your past here. Use Ashgrove's own names for its values: Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix. Answer slot: say which one matters to you and why, in your own words; if none stands out, say so plainly and talk about the role itself. The strategy points you can reference are the 40% digital shift by 2028 and the small-business lending product in Q1 2027; mention one only if it genuinely interests you | The recruiter will test whether the motivation is specific. CO because it scores homework depth, and the values and strategy points are the ones you supplied |
| A3 | "What's prompting you to look at a move now?" | EXP | [generic] | Logistics slot: give your actual reason, in your own words, briefly. The pack supplies none. Whatever you say must match what you say to the Head of Member Services and the panel later the same day | A reason for looking is a standard recruiter check. EXP because it tests consistency of your story rather than the job's terms |
| A4 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period, in your own words | A standard logistics question; JD because it is a term of the listed job |
| A5 | "What are you looking for salary-wise?" | JD | [generic] | Logistics slot: give your own number, or ask for the role's range first, whichever you choose. The pack supplies no figure. If asked what you earn now: "I'd rather focus on the range for this role." | A standard logistics question; JD because it is a term of the listed job |
| A6 | "Where are you based, and does the role's location work for you?" | JD | [generic] | Logistics slot: give your actual location and any limit on where you can work, in your own words. The posting you pasted does not say where the role is based, so ask the recruiter (Round 1 reverse question 1) | A standard logistics question; JD because location is a term of the listed job. The hub plan makes location worth knowing early |

### B: Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would be hardest for you on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Name one gap plainly, in your own words: "I've never worked in a contact centre" or "I've never presented to anyone above regional level". Then give your plan for it, said as a plan: choose what you would do in your first weeks. The pack supplies none. Add nothing to the sentence: it does not say you have done anything adjacent | F4 and F8 are the two gaps you stated. JD because the question reads the posting's own responsibilities against them |
| B2 | "The posting asks for experience handling regulated complaints. What have you handled?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say what the sentence says: you handled the branch's formal complaints log. Answer slot: the regulated-complaints line makes a probe on what rules or deadlines the log followed likely. If it was kept to regulatory rules, say which, in your own words; if it was not, or you do not know, say so plainly and stay with the formal complaints log you handled. Do not call your own work regulated unless your honest answer is yes | F2 is the requirement a recruiter most likely screens on. JD because it quotes the posting |

## Reverse questions: Round 1

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| 1 | "Where is the role based, and how is the week split between the branches and the contact centre?" | Your posting names both and does not say where the role sits. The answer settles A6 and tells you how much of your week D1 matters to | [grounded] the JD's "across branches and the contact centre" |
| 2 | "Is there anything the Head of Member Services or the panel has asked to focus on?" | Recruiter guidance on focus areas is the highest-value input a candidate can get | [generic] |
| 3 | "What does the 20-minute case look like, and is there any pre-reading or format I should know?" | The case is the one round-three item you cannot prepare from the posting. If the answer is no format, J1 to J3 stay as built | [grounded] the recruiter's email naming the 20-minute case |
| 4 | "When will you know who is on the panel?" | Panel names would unlock an interviewer read for Round 3 | [grounded] your note that interviewers beyond their roles are not assigned |
| 5 | "What happens after the third round, and on what timeline?" | Shows you are planning ahead | [generic] |

---

# Round 2: Head of Member Services, your would-be manager (45 minutes)

## Persona weights

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario prompts: "tell me about a time" | Top. The recruiter's own words say the round is mostly behavioural | Where one of your sentences carries a story, map it; where none does, choose a real instance from the scaffold and say plainly if none comes to mind |
| Skeptic | Derisks the gaps in your background; "I don't see X" | Top. A hiring manager buys capability and derisks gaps, and two gaps are in your own words. D1 is the deepest rehearsal in the pack | Say the gap plainly once, hold your position through two follow-ups, concede specifically, never bluff a competency |
| Case/Strategist | Live problems from the role; strategy | Mid. The hiring-manager prior includes live problems, and the 40% digital shift is in the brief | Clarify, objective, segment, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Data-Driven Prober | Reads your one artifact closely | Low. The spreadsheet is the one thing you built that can be walked through line by line | Know what the sheet counted and what it was built in; say plainly if you do not know |
| Pressure, Peer, Conversational | Interruptions; seam-splitting; rapport | Low in this round. Pressure shows up as follow-up depth inside D1 and D3 | Hold-then-concede on D1 and D3 |

## Question bank

### C: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold. Pick a time you told someone senior something they did not want to hear; it needs a named stake, a moment you did not fold, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioural prompt for a manager round. The pack has no sentence of yours that carries this story, so it gives a scaffold. VAL because it scores behaviour rather than the job's terms |
| C2 | "Tell me about a time you helped someone handle a difficult escalation." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F6: you trained new tellers on your escalation script. Those are the beats the sentence states; tell them in your own words. Answer slot: the posting's coaching line makes a probe on whether you supported anyone through a live escalation likely. If you did, say who, what the escalation was and what you did; if the training was the extent of it, say so plainly and stay with the training. Do not describe the tellers as supervisors | F6 is the thinnest part of the coaching requirement and the likeliest place to be probed. JD because it comes from the posting's coaching line |
| C3 | "Tell me about a complaint you found hard to close." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F3: you handled the branch's formal complaints log. That is the only beat the sentence states. Answer slot: Ashgrove's Own the Fix line makes a probe on a complaint you kept hold of likely. If one stayed with you through to its close, say what it was, what you did and how it ended, in your own words; if you handled the log but did not follow one through, or none was hard to close, say so plainly and describe how you handled the log | F3 is where the end-to-end requirement presses. EXP because it tests what you actually did |
| C4 | "When did you put a member ahead of an internal metric?" | VAL | [generic] | Selection scaffold. Pick a time the member's need and an internal target pointed different ways; it needs the decision, what the member needed, what it cost internally, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The persona-stem question for this style, and a direct preview of Members First, Always. VAL because it scores behaviour against a published value |

### D: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "This role owns complaints across the branches and the contact centre. Where does your experience sit on the contact-centre side?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | **The highest-ROI rehearsal in this pack: this question will be asked in some form.** Name the limit before it is asked for. Opening, in your own words: "I've never worked in a contact centre." Then what your sentences carry: "I handled the branch's formal complaints log." That is the branch side only, and the pack's own observation is that your material shows nothing past it. Then a plan, said as a plan: name two or three things you would do in your first weeks to see a complaint from the contact-centre side; the pack supplies none. Likely follow-up one: how you would own a complaint that starts on the phone. Answer as a plan only: who you would ask first, what you would want to see, what you would record; do not describe handling calls. Likely follow-up two: what worries you most. Choose one real worry and say what you would do first. Hold the position through both follow-ups by returning to the log you handled; concede specifically, "I haven't done this yet"; never say more than the sentence | F4 is a stated gap against the posting's headline responsibility, so it is the single most predictable objection. JD because it quotes the posting's own scope |
| D2 | "I don't see presenting to senior leaders in your background. How would you handle that in this role?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain acknowledgment first: "I've never presented to anyone above regional level." Then a plan, said as a plan: what you would do before your first monthly report. Choose it; the pack supplies none. Your material does not say where Ashgrove's senior leaders sit, so ask (Round 2 reverse question 5) before you decide how big this gap is. Do not describe the regional manager's use of your spreadsheet as presenting to them | F8 is a stated gap against a posting requirement and the manager in this round would be the one receiving the report. JD because it quotes the posting |
| D3 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 60-second answer made of your three sentences: "I've spent six years in retail banking, the last three as a branch supervisor. I handled the branch's formal complaints log, trained new tellers on our escalation script, and built the monthly complaints spreadsheet our regional manager uses." Then one honest limit, the contact-centre side (D1), then your own reason for wanting the role. Do not compare yourself to people you have not met; pause before answering and restate the question first | F1 is the length-of-experience requirement, and a pressure stem tests whether you hold a position without defensiveness. JD because it asks you to place your own background against the role |
| D4 | "Where in a complaint's journey, from first contact to close, have you worked?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F3: you handled the branch's formal complaints log. Answer slot: the posting's end-to-end line makes a probe on the stages likely. If any stage beyond the log was yours to set or run, say which and how, in your own words; if there was no such stage, or it was not yours, say so plainly and stay with the log | F3 is the requirement the posting leads with. JD because it quotes the end-to-end responsibility |

### E: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Complaints about slow replies have risen 20 percent over two months. Diagnose it." | CASE | [generic] | Clarify first: what counts as slow, which channel, which complaint types, when it started. Then objective; segment by channel (branch, contact centre, digital) and by type; hypotheses; what data you would pull; risks. Think aloud and challenge one premise respectfully, for example whether more members are complaining or whether more complaints are being logged. The question needs no claim about your past, so the guidance makes none | A diagnosis problem built from the posting's monthly-reporting line (F5). CASE because it scores structure; [generic] because it is a pattern, not a fact about Ashgrove |
| E2 | "The brief aims to move 40 percent of member service to digital by 2028. What does that change for how complaints are handled, and what would you want to know first?" | CO | [grounded] | Clarify first: whether complaints count in the 40 percent, and what counts as service. Then where complaints would enter (branch, contact centre, digital); what must stay with a person; and the brief's named pressure from app-only banks. The question needs no claim about your past, so the guidance makes none. Do not assert what Ashgrove's plan is beyond the points you have | The strategy point most relevant to complaint handling. CO because it scores strategy fluency; grounded in your summary of the brief |
| E3 | "Self-service journeys are part of this role. What would you want a complaint journey in the app to do for a member, and who would you need in the room?" | JD | [grounded] | Structure it from the member's side: what the member needs to see, when a person must step in, what gets recorded. Answer slot: the posting's digital-teams line makes a probe on whether you have worked with one likely. If you have, say on what and what you did, in your own words; if you have not, say so plainly and say what you would ask a digital team first | F7 has no evidence behind it, so this is the question to prepare from scratch. JD because it quotes the posting's self-service line |

### G: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Walk me through how the monthly complaints spreadsheet works." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F5 and F9: you built it; it is monthly; it is about complaints; your regional manager uses it. Those are the beats the sentence states. Answer slot: the posting names complaint volumes, resolution times and Excel, so expect a probe on what the sheet showed and what it was built in. If it showed volumes or time to resolve, or was built in Excel, say so and how any figure was counted, in your own words; if it did not, say so plainly and stay with the monthly spreadsheet you built. If you do not know how something was counted, say so plainly | F5 and F9 both draw on the same sentence, so one rehearsal covers both. JD because it tests the reporting and Excel lines; EXP in what it checks |

## Reverse questions: Round 2

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| 1 | "What would success look like at 90 days for whoever owns the complaints process?" | Shows you think in outcomes and gives you the measure you will be held to | [generic] |
| 2 | "Where does the process work today between the branches and the contact centre, and where is the seam you most want fixed?" | Puts the contact-centre gap in your manager's own terms and shows you are thinking about the seam | [generic] |
| 3 | "With 40 percent of service moving to digital by 2028, which complaints do you expect to move, and who owns the self-service journeys?" | Ties your answer to a point in the brief and tells you what F7 really requires | [grounded] your summary of the strategy brief |
| 4 | "The brief names eight branches becoming five hubs over 2027 and a small-business lending product in Q1 2027. Which of those changes the complaints process first?" | Shows you read the brief and surfaces the order of work | [grounded] your summary of the strategy brief |
| 5 | "Who would I present the monthly report to, and what do they do with it?" | Tells you the real audience for F8 and how big that gap is | [generic] |

---

# Round 3: panel of two branch managers (60 minutes)

This round includes a 20-minute case on a complaint escalation and is scored against the four values.

## Persona weights

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario prompts mapped to the four published values | Top. The recruiter said the panel is the values round and scores against the four values | One story per value from a real instance; "we" for context, "I" for what you did; say plainly if none comes to mind |
| Case/Strategist | The 20-minute complaint-escalation case | Mid. The recruiter named the case; its content is not known | Clarify, objective, segment, approach, metrics, risks, aloud; challenge one premise |
| Peer Evaluator | "What would you need from us"; seam between a branch and your role | Mid. The role coaches branch supervisors, and the panelists are branch managers. Their relationship to the role is inferred from their titles only: [inferred] from the recruiter's description | Reciprocity: say what you would bring their branches, not only what you would need; propose principles for the seam instead of pretending to know it |
| Conversational | A friendly opener | Low. Covered by the A1 arc | Reuse A1; do not improvise a second biography |
| Pressure, Prober, Skeptic | Interruptions during the case; follow-ups on the spreadsheet | Low as separate styles. Hold-then-concede still applies inside H5 and J1 | Hold your position through two follow-ups; concede specifically |

## Question bank

### H: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you made a decision from the member's side of the counter." | VAL | [grounded] | Selection scaffold, for Members First, Always. Pick a decision where the member's side and the easier internal route pointed different ways; it needs the decision, what the member needed, what it cost, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Ashgrove's first published value, in its own words. VAL because it scores behaviour against that value. None of your sentences carries a story for it, so this is a scaffold |
| H2 | "When have you had to reword something because it needed explaining twice?" | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | For Plain Words. Your sentence carries one beat near this: you trained new tellers on your escalation script. Answer slot: Ashgrove's Plain Words line makes a probe on whether you changed any wording because people needed it twice likely. If you did, say what you changed and why, in your own words; if you trained on the script but did not write or change it, say so plainly and stay with the training | The published value puts a test on wording. VAL because it scores behaviour against a published value. F6 is the only sentence near it |
| H3 | "Tell me about a time what a decision meant for a particular town or community changed how you handled something." | VAL | [grounded] | Selection scaffold, for Neighbours, Not Numbers. Pick a time the effect on a particular community mattered in how you handled a case; it needs the decision, whose community, and the outcome. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The third published value, in its own words, and the one the hub plan puts under pressure. VAL because it scores behaviour against that value. None of your sentences carries a story for it |
| H4 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | For Own the Fix. Story-mapped on F3: you handled the branch's formal complaints log. That is the only beat the sentence states. Answer slot: if a problem you found stayed with you until it was solved, say what it was, what you did and how it ended, in your own words; if the items in the log passed to someone else, or none stayed with you, say so plainly and stay with the log | The fourth published value, and the nearest one your sentence supports. VAL because it scores behaviour against that value |
| H5 | "Ashgrove plans to bring eight branches into five hubs over 2027, and one of our values is Neighbours, Not Numbers. How does that sit with you?" | CO | [grounded] | No claim about your past here. Acknowledge the tension plainly rather than defending the plan or attacking it. Say what a complaint process could do to keep a town's members from feeling like numbers during a change, as a plan. Say what you do not know about the plan beyond the brief. Do not guess which branches are affected. Hold your view through one follow-up; concede specifically what you have not seen | The panel are branch managers and the plan is in the brief. Whether their own branches are among the eight is not known to this pack, so treat it as a question, not an assumption. CO because it scores strategy fluency; grounded in your summary of the brief and the pasted values |

### J: Case/Strategist (the 20-minute case)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "A member's complaint has gone back and forth between a branch and the contact centre for three weeks, and they have written to say they are leaving. Walk us through what you do." | CASE | [generic] | Clarify first: what the member has been told and by whom, what is recorded where, whether any deadline applies, what outcome they want. Objective: one named person holds it from today, in the spirit of Own the Fix. Then segment (what the member needs now, what the branch and contact centre each hold), approach, how you would tell the member in plain words, how you would measure it, and the risk if it sits. Challenge one premise respectfully, such as whether leaving is the real request. The question needs no claim about your past, so the guidance makes none | The nearest pattern to the case the recruiter named. CASE because it scores structure; [generic] because the real case is not known |
| J2 | "A branch supervisor says a complaint is not worth escalating because the member always complains. How do you coach them?" | CASE | [generic] | A coaching conversation, structured: ask what they have seen, state the standard from the member's side, agree the next step, say what gets recorded. Answer slot: the coaching line makes a probe on whether you have had a conversation like this. If you have, say how it went, in your own words; if you have not, say so plainly and describe how you would run it | The posting's coaching line (F6) as a live scenario. CASE because it scores how you would act, not what you did |
| J3 | "What would you put in front of us every month to show whether the process is working?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Start from the sentence: you built the monthly complaints spreadsheet your regional manager uses. Then structure the answer around the posting's two measures, complaint volumes and resolution times: ask what resolved means here before choosing, and what you would do with each. Answer slot: if your sheet showed either, say how it was counted, in your own words; if it did not, say so plainly and say what you would start counting | F5 is a monthly-reporting requirement with no stated count behind it. JD because it quotes the posting's reporting line |

### K: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "Our supervisors are busy at the counter. What would you need from us, and what do we get from you?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Reciprocity framing. The one thing your sentence says that touches this is that you trained new tellers on your escalation script. What you would need: how escalations reach you, what each branch holds. What they get: a clear route and a plan for the first month. Say these as principles and plans, not past results | F6 as seen by the people whose supervisors you would coach. JD because it quotes the coaching line |
| K2 | "When a branch and the contact centre disagree about who owns a complaint, who decides?" | JD | [generic] | Propose principles instead of pretending to know today's seam: one named holder at all times, handovers recorded, the member never re-explaining. Ask how it works today. The question needs no claim about your past, so the guidance makes none | The seam the posting's end-to-end line creates. JD because it tests the responsibility |
| K3 | "A complaint shows that one of our branches got something wrong. How do you tell us?" | VAL | [generic] | Facts first, from the member's side; privately before wider; offer the fix and what you would need from them. If pushed back, hold the facts and concede what you do not yet know. The question needs no claim about your past, so the guidance makes none | A peer-collegial version of the unpopular-truth probe. VAL because it scores behaviour toward a peer |

## Values cheat sheet

Official names and wording from the page you pasted on 26 November 2026. Meanings are paraphrased.

| Value | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decisions start from the member's side of the counter | Scaffold at H1: pick one real decision; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Plain Words | If a member needs something explained twice, the wording was wrong | F6, "I handled the branch's formal complaints log and trained new tellers on our escalation script." Only the training is stated; whether you changed any wording is H2's slot |
| Neighbours, Not Numbers | Every branch is part of its town | Scaffold at H3: pick one real instance; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Own the Fix | Whoever finds a problem keeps hold of it until it is solved | F3, "I handled the branch's formal complaints log and trained new tellers on our escalation script." Only the log is stated; whether you followed any item to its close is H4's slot |

## Reverse questions: Round 3

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| 1 | "Which complaints from your branch would you most want a lead to take off your supervisors' plate, and which would you rather keep close?" | The reciprocity question: it offers value to their branches before asking for anything | [grounded] the JD's coaching and ownership lines |
| 2 | "How do escalations reach you today, and which part feels slowest?" | Surfaces the seam K2 asks about from the people who live it | [generic] |
| 3 | "What would Own the Fix look like in your branch when the fix sits in the contact centre or with a digital team?" | Uses their own value to test whether the process has owners | [grounded] the pasted values and the JD's contact-centre and digital lines |
| 4 | "Which of the four values is hardest to hold in a busy week at your branch?" | Invites a real answer instead of a recital | [grounded] the pasted values |
| 5 | "What are your members saying about the hub plan?" | Meets Neighbours, Not Numbers directly; ask it only after hearing how the panel talks about the change | [grounded] your summary of the strategy brief |

---

## Sources

Provided documents:

- The job description, pasted.
- The four published values, pasted; copied on 26 November 2026 from ashgrovecu.org/about/values. The page was not fetched.
- The recruiter's email, which establishes the three rounds, who runs each, and their lengths.
- The 2026 strategy brief, published July 2026, as the four points you gave. The brief itself was not pasted.
- Your background, as you described it in your message. No CV was provided.
- No `tuesday-dossier.md` was present.

No searches or fetches were sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | Could not have moved the cheat sheet or H1 to H4: the pasted page, copied this morning, gives the four values by name |
| 2. `Ashgrove Credit Union interview process member services` | skipped | Could not have moved the persona weights: the recruiter's email gives the three rounds, who runs them and their lengths |
| 3. `Ashgrove Credit Union strategy` | skipped | Could not have moved E2 or H5: the four brief points you gave already feed them; a fuller brief would add more, which the upgrade menu offers |
| 4. `interviewer name Ashgrove Credit Union` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Interviewer names or titles once assigned → an interviewer read, persona weights tuned per panelist, and a reverse question tied to one panelist's own path
- The strategy brief itself, pasted → the grounding brief grows beyond four points and E2, H5 and the reverse questions sharpen
- Your CV or resume text → more verbatim lines for the fit snapshot, which could turn some discovery rows into story-mapped answers
- Your own answers to the slots on F2, F3, F5, F6, F7 and F9 (what the log followed, which stages were yours, what the sheet counted and was built in, any coaching of a live escalation, any digital-team work) → those rows and their question slots regenerate from your words, as long as you say them outside a drill
- Your actual notice, pay position, location and reason for looking → A3 to A6 hold your own words instead of a slot
- The case format, from the recruiter → J1 to J3 retuned to the real case
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → a strategy brief, role-family loop reports and recent organisational context, so the CO and CASE questions rest on more than four points
- A `tuesday-dossier.md` from an earlier fit check → pre-graded evidence and a ready-made prohibited-claims list
