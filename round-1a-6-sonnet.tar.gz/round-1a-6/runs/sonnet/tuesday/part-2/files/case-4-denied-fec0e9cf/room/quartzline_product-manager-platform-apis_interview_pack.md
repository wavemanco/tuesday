# Interview pack: Product Manager, Platform APIs at Quartzline

- Role: Product Manager, Platform APIs
- Company: Quartzline
- Round: one 45-minute conversation with the hiring manager (your words). Interviewer's name not given.
- Built from: your tuesday-dossier.md (role_profile, decision, handoff_to_mock_interview) and nothing researched, because the web searches were refused in this session (see Sources).

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding for a spoken answer, not a script. Every line of guidance that speaks about your past sits next to the sentence it rests on. Where no sentence of yours covers a question, you get an answer slot, a short instruction that has two honest branches, or a selection scaffold. Everything marked as guidance is proposed language, pending your approval.

| Type | Meaning |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company and can think at its altitude |
| CASE | A live problem from the role, scored on structure and reasoning |

Provenance labels: `[grounded]` traces to your dossier or the JD lines in it, `[inferred]` is this pack's derivation from them, `[generic]` is a role-family pattern with no claim about you or Quartzline.

## Fit snapshot

Requirement lines are quoted from the dossier's role_profile. Evidence cells hold your confirmed sentences from the dossier's verified_candidate_evidence, quoted exactly, with the dossier's confidence notes left out of the quote and carried in the Confidence column and the bridge.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence 3 | low | [inferred] | transferability | The dossier's strategy is bridge, positioned as adjacent and never as PM experience. Say the work at its own scope: you led the client integrations, and you ran the roadmap-input sessions that fed client evidence to product. The limit stays in the answer: this is integration leadership, not time in the PM role. The second quote is confirmed with limited inspectable proof, so expect a probe on it and volunteer its limit first |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibilities, with the dossier's weak area "Owning a roadmap and prioritization authority (R1 sub-claim)" | none given | none | [grounded] | capability | The dossier's strategy is acknowledge_gap, so no bridge is coached. Your words come only from that field: "I haven't owned a product roadmap." Then a plan for how you would learn it, said as a plan and never as a past. Your material says input to product, not ownership of what product decided |
| F3 | "Shipped API or platform products" — dossier role_profile R2, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence 2 | low | [inferred] | transferability | The dossier lists R2 as high priority but grades no weak area for it, so this row is the pack's own reading: your quotes show leading integrations of the vendor's APIs and writing a playbook, not shipping an API product. Stay at those quotes' scope. Answer slot: the must-have makes a probe on shipping likely. If any part of the vendor's API platform was yours to ship, say which and what part was yours, in your own words; if the integrations were deployments of an API others shipped, or none of it was yours, say so plainly and return to the integrations you led |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1 | low | [inferred] | discovery | The quote touches REST APIs and architecture without showing API docs or schemas. Answer slot: expect a probe on docs and schemas. If you read, wrote or reviewed any in those integrations, say which and what you did with them, in your own words; if not, say so plainly and stay with the REST integrations you led |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence 3 | medium | [inferred] | discovery | The quotes name clients and product. They do not show engineering or sales. Answer slot: if you worked with engineering or sales colleagues on those integrations, say how, in your own words; if you did not, say so plainly and stay with the clients and the product team the quotes name. The second quote carries the medium-confidence caveat |
| F6 | "Agile delivery experience" — dossier role_profile R5, preferred | none given | low | [grounded] | discovery | The dossier's strategy is clarify and no quote speaks to it. Answer slot: the line "Agile delivery experience" makes a probe on working inside a product org's delivery cycle likely. If you worked that way, say how it ran and what part was yours; if you never did, say so plainly, and say what you would want to confirm about how Quartzline defines it |
| F7 | "Run discovery with integration partners" — dossier role_profile responsibilities | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence 3 | medium | [inferred] | discovery | The quote shows the sessions and where their evidence went. It does not show who attended or how the evidence was gathered. Answer slot: expect a probe on how partner input was collected. If you chose who to include or what to ask, say how; if the format was set by someone else, or there was none, say so plainly and stay with the sessions as quoted |
| F8 | "Define and track adoption metrics" — dossier role_profile responsibilities | none given | none | [grounded] | discovery | Silence, not an admitted absence. Answer slot: if you ever defined or tracked adoption of anything, say what was counted, in your own words; if not, say so plainly and say what you would ask for first. The dossier also records that Quartzline's current baseline is unstated |
| F9 | "Write specs and drive delivery with two engineering squads" — dossier role_profile responsibilities | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1 | low | [inferred] | discovery | The quote lists requirements as one stage of integrations you led. It does not show specs written for engineers or delivery driven with a squad. Answer slot: if you wrote requirements that engineers built from, say what and for whom; if not, say so plainly and stay with the stages the quote names |

## Persona table

The weights start from the hiring-manager prior and are adjusted by nothing else, because no interviewer profile exists. The loop is the one session you described: no loop source names a values round, so none is assumed.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Quiet, persistent probing of the title and roadmap gap | Highest. A hiring manager is derisking gaps, and the dossier names one objection that will arrive in some form | Concede the two plain facts first, hold the adjacent case at its own scope, name a ramp plan |
| Case / Strategist (B) | Live problems on the partner API roadmap | Highest. The hiring-manager prior puts it beside the Skeptic, and the role's responsibilities are naturally case-shaped | Clarify, then objective, segmentation, approach, metrics, risks; challenge one premise respectfully |
| Data-Driven Prober (C) | Pulls on the 30+ figure, the playbook and technical fluency | Medium. Your headline number and an inspectable playbook invite it, and adoption metrics are a named responsibility | Know what you can and cannot say about how the number was counted; name the weakest assumption first |
| Conversational (D) | The opening, "walk me through the journey" | Medium. The first minutes of a 45-minute conversation are usually unstructured, and still scored | A 90-second arc made only of your three confirmed sentences |
| Pressure (E) | Time-boxed "why you" challenges | Low to medium. The hiring-manager prior does not centre it, but the objection lends itself to it | Pause, restate, hold two follow-ups before conceding anything real |
| Peer Evaluator (F) | Seam-splitting with the two squad leads | Low. The manager is not the squad leads, but authority versus the leads is an open item | Propose seam principles instead of pretending to know the seam |

## Question banks

Highest-ROI prep in the pack: A1. The underwriting dossier you carried named this objection, from evidence you confirmed, so it gets the deepest rehearsal here.

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; prohibited_claims: "Having held a product manager title or role"; uncertain_or_weak_areas acknowledge_gap: "Owning a roadmap and prioritization authority (R1 sub-claim)" | Level one: concede before you defend, in your own words, sourced from prohibited_claims and the acknowledge_gap area: "I haven't held a product manager title, and I haven't owned a product roadmap." Then hold only what the quotes carry: you led 30+ end-to-end client integrations of the vendor's REST APIs, and you ran quarterly roadmap-input sessions feeding client evidence to product. Volunteer the limit of the second before it is extracted: it is confirmed, with limited inspectable proof. Level two, "that is not three years of the job": agree it is not, and do not claim equivalence; say what the work is and let them weigh it. Level three, "what would be hardest for you in the first six months": name the roadmap and prioritization side as what you would be learning, then give the ramp plan, pending your approval: ask how decisions are split with the squad leads, get the adoption baseline, and learn the prioritization process before proposing changes | The dossier's named objection, aimed at F1 and F2. JD because it scores the stated years requirement, deepest because it will be asked in some form |
| A2 | "Which part of owning the roadmap for this partner-facing API platform would be weakest for you on day one?" | JD | [grounded] uncertain_or_weak_areas acknowledge_gap: "Owning a roadmap and prioritization authority (R1 sub-claim)"; prohibited_claims: "Having owned a product roadmap" | Plain acknowledgment, sourced from the acknowledge_gap area: "I haven't owned a product roadmap." Then the ramp plan, pending your approval, said as a plan: which decisions you would want clarity on first, and who you would learn the prioritization process from. No bridge to ownership. Nothing about your past goes into this answer | F2. The underwriting dossier found nothing to bridge, so the honest form is the acknowledgment and the plan |
| A3 | "The role needs someone who has shipped API or platform products. What is your closest experience?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | Start from the quotes at their own scope: you led 30+ end-to-end client integrations of the vendor's REST APIs, and you wrote the integration playbook your team uses. Answer slot: the must-have makes a probe on whether any part of the vendor's platform itself was yours to ship likely. If any was, say which and what part was yours; if the integrations were deployments of an API others shipped, or none of it was yours, say so plainly and return to the integrations you led | F3. A must-have the dossier did not grade as weak, so the answer is built from the quotes alone and the second probe is expected |
| A4 | "Tell me about a time you worked inside an agile delivery cycle." | JD | [grounded] | No quote of yours speaks to this, so this is the clarify shape. Answer slot: the JD's "Agile delivery experience" makes a probe on a product org's cycle likely. If you worked that way, say how it ran and what part was yours, in your own words; if you never did, say so plainly, then say what you would want to confirm about how Quartzline defines it | F6, the dossier's clarify area. Preferred rather than must-have, so a short honest answer costs little |
| A5 | "Why this move, into product, and why now?" | EXP | [generic] | Selection scaffold. Give your own reason in two sentences, one you would repeat under a second "why". Nothing in your dossier states your motive, so this pack does not supply one. If no clear reason comes to mind, say so plainly, then say what about this role's responsibilities draws you to it | Motivation consistency is the Skeptic's last probe, and the dossier records no motive, so it stays a scaffold |

Guidance in this table is proposed language, pending your approval.

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A partner tells you their integration breaks every time we ship a new API version. Two squads, one roadmap, limited capacity. How do you decide what happens next?" | CASE | [generic] | Clarify first: how many partners, how severe, what commitments exist, who owns the decision. Then objective, segmentation of partners by impact, options, how you would measure, risks. Name aloud that decision authority versus the squad leads is something you would confirm, rather than assuming it. Frame your answer as what you would recommend and who you would bring in. It asks about no past, so the guidance makes no claim about yours | The role's core job as a live problem; ties to the open decision-authority item and the dossier's prohibited claims on prioritization authority |
| B2 | "Adoption of a new partner endpoint is flat after 60 days. Diagnose it." | CASE | [generic] | Ask how adoption is defined and what the baseline is, since the dossier records neither. Then split: awareness, access, integration effort, value. Name the assumption you would defend least before they do. Pick what you would check first and why | F8, the adoption-metrics responsibility, as a live diagnosis with the weakest-assumption move built in |
| B3 | "Sketch how you would run discovery with integration partners in your first quarter. What do you need to know first?" | CASE | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Structure: who the partners are, what you would ask, how you would bring the evidence back to the squads. You may refer to the roadmap-input sessions at the quote's own scope, with its limit volunteered. Answer slot: the JD's discovery line makes a probe on how that input was gathered likely. If you chose whom to include or what to ask, say how; if the format was set by someone else, or there was none, say so plainly and stay with the sessions as quoted | F7. CASE delivery of a JD responsibility, with a story anchor that carries a caveat |
| B4 | "A spec for a breaking change lands two weeks before a partner launch. What does a good spec contain and how do you drive it with the squad?" | CASE | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Describe a good spec in your own terms and how you would work it with engineers. Say the stages you led from the quote if they help: scoping, requirements, architecture, UAT, go-live. Answer slot: the JD's spec-and-delivery line makes a probe on written specs likely. If engineers built from requirements you wrote, say what and for whom; if not, say so plainly and stay with the stages the quote names | F9. The delivery side of the JD, with the prohibited prioritization claim kept out |
| B5 | "How would you decide what partner API adoption success looks like for us, and what would you need before committing to a number?" | CO | [generic] | Ask for the current baseline first. Then propose how you would define adoption, which partners count, and over what period. Name the weakest assumption in any target before they do. It is labelled generic because no company research ran, so it makes no claim about Quartzline | F8 and the dossier's unresolved baseline risk. CO in spirit; no company facts are available, so it stays generic |

Guidance in this table is proposed language, pending your approval.

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You led 30+ client integrations of the vendor's REST APIs. How were those counted, and which were truly end to end?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Defend the number in your own words. Answer slot: how the 30+ was counted, what it is most sensitive to, the assumption behind it you would defend least, and which part of each was yours. If you do not know how it was counted, say so plainly. The dossier graded this high because an integration playbook is inspectable, so be ready to point to it | F1 and F3. The headline figure on your record is the first thing a prober pulls |
| C2 | "Tell me about the integration playbook your team uses." | EXP | [grounded] "Wrote the internal integration playbook her team uses" | In first person, same words: you wrote the integration playbook your team uses. Say what is in it and how your team uses it, in your own words. Answer slot: if others contributed to it, say who and what part; if you wrote it alone, say so plainly | F3. Inspectable evidence is the strongest thing you carry, so rehearse describing it precisely |
| C3 | "What have you worked with in API docs and schemas?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The quote reaches REST APIs and architecture. Answer slot: if you read, wrote or reviewed API docs or schemas in those integrations, say which and what you did; if not, say so plainly and stay with the REST integrations you led | F4. The technical-fluency line is important, not must-have, but is easy to probe |

Guidance in this table is proposed language, pending your approval.

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc with three beats, each in the quote's own scope: the client integrations you led, the playbook you wrote, the roadmap-input sessions feeding client evidence to product. Give no dates or titles beyond what you have said. The last beat is your own words on why this role, and volunteer that the sessions' proof is limited | F1, F3, F7. The first minutes set the frame for the Skeptic that follows |
| D2 | "What is on your mind in partner API design lately?" | CO | [generic] | Selection scaffold. Pick something you have really read or tried; say what you noticed and what you would want to test. If nothing comes to mind, say so plainly and name the question you would want to explore first. Casual questions on hot topics are still scored | JD-adjacent rapport question; generic because no company research ran |
| D3 | "Tell me about a partner or client conversation that changed how you saw a product." | EXP | [inferred] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Selection scaffold: choose a real instance with a named client or partner, what they said, what you did next, and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: the roadmap-input sessions, at their own scope | F5 and F7. Open prompt, theme from the JD's discovery responsibility |

Guidance in this table is proposed language, pending your approval.

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; prohibited_claims: "Having held a product manager title or role"; uncertain_or_weak_areas acknowledge_gap: "Owning a roadmap and prioritization authority (R1 sub-claim)" | Pause and restate the question. Concede the plain facts first, sourced from prohibited_claims and the acknowledge_gap area: "I haven't held a product manager title and I haven't owned a roadmap." Hold what the quote carries: you led 30+ end-to-end client integrations of the vendor's REST APIs. Hold through two follow-ups by returning to that, never by adding to it, and concede specifically what is not covered rather than folding on the core | F1 and F2. The time-boxed version of A1 |
| E2 | "That result: how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | You wrote "led". Answer slot: say which of scoping, requirements, architecture, UAT and go-live were yours to carry; if any were shared or run by others, say so plainly. Then return to the integrations you led | F3. The attribution probe exists to catch inflation, so the honest breakdown is the win |

Guidance in this table is proposed language, pending your approval.

### F. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "You would work alongside two squad leads. Where is the seam between your calls and theirs, and what happens when you disagree?" | JD | [generic] | Do not pretend to know the seam: the dossier records decision authority as unresolved. Offer seam principles instead, such as who owns the why, who owns the how, and how a stalemate escalates, then ask how Quartzline splits it. It claims nothing about prioritization authority in your past | F2 and the dossier's authority risk. Collegial packaging of the Skeptic's concern |
| F2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "Wrote the internal integration playbook her team uses" | Use "we" for context and "I" for what was yours. If you want an example, the playbook your team uses is the one sentence you have confirmed that names a shared artifact, at its own scope. Answer slot: if others contributed to it, say who and what part; if you wrote it alone, say so plainly | F5. Open prompt from the peer persona stem; no company values were established |

Guidance in this table is proposed language, pending your approval.

### Requirement coverage

| Requirement | Covered by |
|---|---|
| R1 3+ years PM experience (F1) | A1, A5, E1 |
| Own the roadmap (F2) | A1, A2, E1, F1 |
| R2 Shipped API or platform products (F3) | A3, C1, C2, E2 |
| R3 Technical fluency (F4) | C3 |
| R4 Stakeholder management (F5) | D3, F1, F2; sales has no question, and the reverse questions carry it |
| R5 Agile delivery (F6) | A4 |
| Run discovery with integration partners (F7) | B3, D3 |
| Define and track adoption metrics (F8) | B2, B5 |
| Write specs and drive delivery (F9) | B4, B1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R-1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | From the dossier's unresolved risk: authority is asserted in the JD but not evidenced. The answer tells you what the role is before you accept it |
| R-2 | "How is partner API adoption measured today, and what is the current baseline?" | From the dossier's second risk: the metric is a named responsibility with no stated baseline. It also shows you are thinking about the number you would be held to |
| R-3 | "When a partner's need conflicts with what a squad is already building, who has the last word, and how did the last such call go?" | Extends R-1 into a real case, and tells you how the seam works in practice |
| R-4 | "How do partner integration problems reach the PM today, and who does the PM hear from first?" | Shows where discovery starts, which is a JD responsibility, and lets you hear how much of it exists |
| R-5 | "What would this person need to have done by day 90 for you to say the hire was right?" | Names the bar you are rehearsing toward, and gives your ramp plan a target |
| R-6 | "Which engineering and sales colleagues would this PM work with most, and where does that work run into friction?" | Covers the part of the stakeholder requirement your material does not show, and surfaces where the real friction sits |

## Prohibited claims

What this pack will not coach, and why. All three come from the dossier's prohibited_claims, and each also bounds every cell above.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Sourced: prohibited_claims: "Having held a product manager title or role" | The adjacent quotes at their own scope (F1). Plain acknowledgment, from that field: "I haven't held a product manager title." |
| Having owned a product roadmap | Sourced: prohibited_claims: "Having owned a product roadmap", and the acknowledge_gap area "Owning a roadmap and prioritization authority (R1 sub-claim)" | "I haven't owned a product roadmap." Then a ramp plan. No bridge, and the roadmap-input sessions are never described as ownership (F2) |
| Having set prioritization for an engineering squad | Sourced: prohibited_claims: "Having set prioritization for an engineering squad" | "I haven't set prioritization for an engineering squad." Case answers (B1, F1) are framed as what you would recommend and who you would bring in, never as something you did |

## Sources

Provided documents: tuesday-dossier.md, version 1.1, read in full. It supplied role_profile (requirements and responsibilities), decision (context only), and handoff_to_mock_interview (verified evidence, weak areas and their allowed strategies, the objection, risks, employer questions, prohibited claims). It carried no evidence_map, risk_register or evidence_state, so those rows are the pack's own reading where marked.

Loop source: your own words (one 45-minute hiring-manager conversation). It names no values round, so no values cheat sheet was built.

Searches sent, all refused by the host:

- "Quartzline company values" — refused
- "Quartzline interview process product manager" — refused
- "Quartzline strategy recent news API platform" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Every call was refused. Would have moved a values cheat sheet and VAL questions; none is built |
| 2. Quartzline interview process, product role family | unavailable | Every call was refused. Would have moved the loop structure and persona weights; they rest on the hiring-manager prior and your own description |
| 3. Quartzline strategy and recent news | unavailable | Every call was refused. Would have moved CO and CASE grounding; B5 and D2 are labelled generic |
| 4. Interviewer name | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative Product Manager JD | skipped | The dossier's role_profile supplies the requirements and responsibilities the fit snapshot and JD-tagged questions rest on |

## Upgrade menu

- Search permission → the L1 targets re-run (values, loop structure, strategy), which would turn B5 and D2 from `[generic]` into company-specific CO questions. A deeper pass, L2, adds up to 6 more searches and 2 more fetches and several more minutes, and would add a grounding brief; offered once.
- The interviewer's name → an interviewer read, persona weights from their public footprint, and a reverse question tied to their own path.
- The recruiter's agenda or prep note → coverage of anything pre-declared, such as a case or a deliverable.
- Your answers to the answer slots in F3, F4, F5, F6, F7, F8 and F9, said in your own words → those rows move from slots to story-mapped guidance, and the questions that draw on them are regenerated.
- A roadmap-input session agenda or the deck it produced → the artifact that would lift the third verified sentence from medium confidence to high in F1, F5 and F7.
- An API doc or schema you wrote or reviewed → the artifact that would settle F4.
