# Interview pack: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. **Relationship:** assumed hiring manager, unconfirmed. Saltmarsh's interviewing page says its single 60-minute interview, the Outage Hour, is with the hiring manager, and your session matches that description. **Built for:** the Outage Hour, a live-incident tabletop on a simulated outage during a live event, followed by a values conversation. The page says there is no take-home.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows Saltmarsh's published values, not generic virtue |
| EXP | Whether what you say about your work survives follow-up, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company's current strategy and can think at its altitude |
| CASE | Structure and reasoning on a live problem from the role |

An answer slot is an instruction for the interview, not a question for this chat. Where a slot has two branches, either one is a good answer if it is true.

## Prep triage

Sized to roughly one day before Friday, which is what your note implies. Tell me if you have more or less.

1. Say C1 and C2 aloud until they feel boring. They are the most predictable questions in the pack, and C1 is the highest-ROI prep.
2. Run A1 and A2 aloud against a timer, using the clarify, objective, segmentation, approach, metrics, risks frame. The tabletop is the documented half of the hour.
3. Rehearse B3, D1 and D2. They rest on sentences you gave me.
4. Learn the three value names exactly as written in section 10, then read the Project Larkspur announcement (A5).
5. Pick three reverse questions from section 11.

Everything else is insurance.

## Requirement coverage

| Requirement | Questions covering it |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A2, A5, F1 |
| Coordinate design, art, engineering and community teams on each update | A1, C1 |
| Own the post-event review and the KPIs it reports | A3, D3 |
| Manage the release checklist with QA | A4, B3, D1 |
| 3+ years producing live-service games or apps | E1, F1 |
| Experience running a content calendar | E2, F1 |
| Comfortable with player-retention metrics | A3, D2 |
| Clear written communication | F2 |
| Each published value | B1, B2, B3, with B4 as the general unpopular-truth question |

## Fit snapshot

Rows R1 to R8. The JD lists no gate terms such as location, pay or a credential, so no row is a gate.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| R1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says the weekly content-drop calendar for your main title, not live events and not two titles, and the words stay there: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's two-titles and live-events wording makes a probe on both likely. If any drop was a timed event, or you also worked another title's calendar, say which and how, in your own words; if not, say so plainly and stay with the one title's calendar |
| R2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show how the calendar's work reached those teams. Answer slot: the JD names four teams, so expect a probe on each. If you worked with design, art, engineering or community on a drop, say with which and what you did, in your own words; if you did not, or it was not yours, say so plainly and stay with the calendar you ran |
| R3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented monthly retention numbers, not that you owned a review or chose the KPIs, and the words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose what was in those numbers, or looked back at a drop, say what and how, in your own words; if the numbers were set by someone else, or there was no such review, say so plainly and stay with presenting them |
| R4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap, but a chat line with nothing inspected behind it, so expect a probe. Lead with it in the quote's own terms: you wrote it, and your QA team still uses it. The JD says manage and the quote says wrote, so the words stay with wrote |
| R5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | presentation | Say the role and the years in the quote's own terms: "I've spent four years as an associate producer at a puzzle-game studio, and for the last two I ran the weekly content-drop calendar for our main title." The JD's words are live-service; your material does not use them, so the pack does not label you with them |
| R6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a chat line with nothing inspected behind it. Lead with it in the quote's own terms: ran, weekly, main title, two years |
| R7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | presentation | Lead with the quote in its own terms: "I presented the monthly retention numbers to the studio head." Expect a probe on how those numbers were counted; D2 holds that slot. The quote does not say you produced them, so the words do not either |
| R8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | A checklist others use shows written work in use, not how clear your writing is, and the pack claims no more. Answer slot: if other writing of yours was acted on by other teams, say what it was, in your own words; if the checklist is the one example, say so plainly and stay with it |

## Reading the interviewer

Source: a search snippet for a GDC 2026 talk titled "Patch Notes Are a Promise", which names Tobias Wrenfield as Head of Live Operations at Saltmarsh Games, previously a QA lead at a console studio. The snippet gives his argument as: a live team is judged by how often its patch notes describe what actually shipped. I read the snippet only, not the talk page, so treat anything beyond it as unknown.

| Signal (public) | What it implies for you |
|---|---|
| Previously a QA lead | Expect depth on the release checklist; D1 carries more weight than a generic pack would give it |
| His talk's argument about patch notes and what actually shipped | It echoes the published value "Ship the Patch Not the Promise". Precision about what was built versus hoped is the register to answer in |
| Head of Live Operations | He owns the calendar and review you would run, so R1 to R3 are his own territory; concede limits plainly rather than bluffing them |

**Mirror opportunity (shared vocabulary):** his QA background and your R4 line, "Wrote the release checklist our QA team still uses." — R4. Mention the checklist in his terms, as a thing QA still uses, and stop there.

## Persona table

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A Case/Strategist | The Outage Hour tabletop: a simulated outage during a live event | High. The interviewing page documents the tabletop, and the hiring-manager prior favors Case/Strategist | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully. Case questions ask about no past, so make no claim about yours |
| B Values/Behavioral | The values conversation that follows the tabletop | High. The same page documents a values conversation in this hour, and the values page names three values | Map a story where one of your quoted sentences carries one (B3). Where none does, use the selection scaffold and its honest branch |
| C Skeptic | Probing the gaps in your own stated limits | Medium. The hiring-manager prior includes the Skeptic, and you stated two limits yourself | Rehearse C1 until it is boring. State each limit plainly, then a ramp plan said as a plan and never as a past |
| D Data-Driven Prober | Line-by-line questions on the checklist and the retention numbers | Medium. His public QA background points to detail. This is pack inference, not documented loop structure | Know what you can and cannot say about how each thing was counted or built, and say plainly when you do not know |
| E Pressure | Time-boxed or interrupted answers during the tabletop | Low. A simulated outage can carry time pressure, but nothing read documents a pressure style | Pause, restate, anchor in what you said, and hold the quoted position through two follow-ups |
| F Conversational | An opening biography question | Low. Likely only as an opener | Prepare the 90-second arc in F1 from the four sentences you gave me |

Peer Evaluator is left out: the person across the table is a hiring manager, not a peer.

## Question banks

### A. Case/Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Mid-event, a reward is not granting for part of your players and the community channels are filling up. What do you do in the first fifteen minutes?" | CASE | [generic] | Think aloud. Clarify first: what exactly is broken, for how many players, and whether it is getting worse. State the objective as stopping further harm to players. Weigh pausing or extending the event against holding the calendar, and say which way you lean: the published value "Players Before Plans" says that when the calendar and the players disagree, the players win. Name who needs to know, and what players are told: what is known, what is not, and when the next update comes, in line with "Ship the Patch Not the Promise". Close with the risks and what you would check afterward. The question needs no claim about your past, so the guidance makes none | Mirrors the documented Outage Hour format (a simulated outage during a live event), which is why it leads the bank. R2 is the requirement it presses on. `[generic]` because the scenario is a pattern, not a claim about Saltmarsh |
| A2 | "Engineering says the fix needs eight hours. The next event is scheduled to start in six. What happens to the calendar?" | CASE | [generic] | Clarify: does the next event depend on the broken thing, can it run without the fix, and is the six-hour start fixed. Lay out the options (hold, slide, run a reduced version), the cost of each, who decides, what players are told, and what happens to the events after it. Pick one and say why, leaning on "Players Before Plans". Challenge one premise respectfully. The guidance makes no claim about your past | R1 is the calendar requirement, and this tests it live. CASE with JD content |
| A3 | "The outage is over. What goes into the post-event review, and which KPIs do you report on it?" | CASE | [generic] | Structure the review: what happened and when, what players experienced, and what it cost on the measures you would choose. Name those measures yourself and say what each cannot tell you. If retention is one, say what you would compare it with. Say what changes in the release checklist afterward, in the spirit of "Leave the Build Greener", and who reads the review. The guidance makes no claim about your past | R3 is the requirement the JD says you would own. CASE because it is set live, JD because it scores that line |
| A4 | "Tonight's patch carries the event's content. What has to be true before it ships, and what do you ask QA for?" | CASE | [generic] | Structure it: what the patch changes, what could hurt players, what QA has covered and what it has not, the rollback path, and whether the patch notes will describe only what shipped. Say who can stop the release. Plan aloud and make no claim about your past | R4 is the checklist-with-QA requirement, and an interviewer with a QA background will enjoy this one. CASE delivery, JD content |
| A5 | "Saltmarsh announced Project Larkspur: from February 2027, Tidepool Tactics and Lantern Row move to a season-pass model with one shared events calendar, and per-title event teams give way to a single live-ops group. How would you build one calendar for two titles?" | CO | [grounded] | Say you know this from the announcement and do not claim inside knowledge. Clarify what the two titles share (players, rewards, release days), what collides, and what stays per title. Then objective, segmentation, approach, metrics and risks, in the company's own words: shared events calendar, season pass, single live-ops group. The guidance makes no claim about your past | The strategy-grounded CO question. Source: a search snippet of the Larkspur announcement (see Sources); the page itself was not fetched. R1 asks for a two-title calendar, and this is the shape it takes from February |

### B. Values/Behavioral (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed. What won?" | VAL | [grounded] | Selection scaffold: pick a time with a named date, a named group of players, and a moment you chose, where the outcome is told as it actually was and the working relationship was intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would decide | Theme from the published value "Players Before Plans". No quoted sentence of yours carries this story, so it is a scaffold. `[grounded]` on the values page |
| B2 | "Tell me about a time you had to decide what to announce before everything was finished." | VAL | [grounded] | Selection scaffold: pick a time with a named announcement, what was built and what was only hoped, and what you said. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would decide | Theme from "Ship the Patch Not the Promise", which also echoes the interviewer's public talk. No quoted sentence carries it |
| B3 | "Tell me about a time you left a process better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on R4: you wrote the release checklist, and your QA team still uses it. Those are the beats the sentence states; tell them in your own words. Answer slot: the published value says every release leaves the checklist better than it found it, so expect a probe on whether it changed. If you changed it after its first version, say what prompted that; if it stayed as first written, say so plainly and say what you would change in it first | R4 is the one row that carries a story for "Leave the Build Greener". VAL because it scores the value, EXP in how it will be probed |
| B4 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, the message as you said it, and how it landed, with your relationship with that leader intact. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would do it | A standard values-round question, and the monthly numbers in R7 are a setting where it could arise. No quoted sentence carries the story |

### C. Skeptic (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You have never led a team. This role coordinates design, art, engineering and community on every update. How do you get four teams to hit your dates?" | JD | [grounded] "Never led a team"; "I ran the weekly content-drop calendar for our main title for the last two years." | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment in your own words: "I've never led a team." The JD's verb is coordinate, which is the pack's observation about the posting, not words for you. Then the calendar at its own scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: if running that calendar meant getting other teams' work to land on its dates, say how, in your own words; if it did not, or that was not yours, say so plainly and say how you would start with each of the four teams, as a plan. Hold through two follow-ups by returning to the calendar, and concede the limit specifically: you have not led people. Never fold on the calendar you ran | R2 is the thinnest requirement row and you stated the limit yourself, so this will be asked in some form. JD because it scores the stated requirement, Skeptic delivery |
| C2 | "Saltmarsh's titles move to a season-pass model from February. You have never worked on a game with in-app purchases. What do you need to learn first?" | JD | [grounded] "never worked on a game with in-app purchases" | Plain acknowledgment in your words: "I've never worked on a game with in-app purchases." Your material gives no monetization experience, and the retention sentence in R7 is not one, so the pack does not bridge to it. Then a plan, said as a plan: what you would learn first about how events and the pass connect to what players buy, whom you would ask, and how soon. Hold the limit calmly | The second limit you stated. The season-pass fact is from the Larkspur snippet (Sources). `[grounded]` on your own sentence, with no bridge written because none of your quotes carries one |
| C3 | "Which part of this JD would you be weakest at on day one?" | JD | [generic] | Name it before he does. R2 and R3 are the thinnest rows in your material, which is the pack's observation. Pick the one you honestly believe, say the limit plainly, and give a first-month plan as a plan. If two come to mind, choose the one a prober would find first | A persona-stem question every Skeptic asks; naming the weakest area yourself converts a probe into credibility |

### D. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the release checklist you wrote." | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on R4: you wrote it, and your QA team still uses it. Tell those two beats in your own words. Answer slot: the JD's "with QA" wording makes a probe on QA's part likely. If QA shaped what was on it, say how; if QA had no hand in it, say so plainly and describe the checklist as you wrote it. Expect precision from an interviewer with a QA background, so say only what the checklist actually contained | R4 is the likeliest place to be probed given the interviewer's public background. EXP because it tests what was actually yours |
| D2 | "Walk me through how the retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Start at the quote: you presented them. Then the four slots a figure raises, each in your own words: how the numbers were counted, what they were sensitive to, the assumption behind them you would defend least (name it before he does), and which part was yours. If you do not know how they were counted, say so plainly | R7 and R3 are why this arrives. Probers go two levels past a headline, and there is no figure in your message, so the rehearsal is the four slots |
| D3 | "What did the post-event review look like on your title?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Start at the quote: you presented the monthly retention numbers. Answer slot: the JD's post-event review line makes this probe likely. If you looked back at drops, say how and who saw it, in your own words; if there was no such review, or it was not yours, say so plainly and stay with the monthly numbers | R3 is a requirement your material touches without showing, so the question is premised on the JD, and the slot's second branch allows that no such review existed |

### E. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you for this role?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years." | Pause, restate the question, then give the years and the calendar in the quotes' own terms. Answer slot: the JD says live-service. If the main title was updated live after release, say so and what that meant in your week, in your own words; if not, say so plainly and stay with the years and the weekly calendar. Hold through two follow-ups by returning to the quotes | R5 and R6 are the requirement lines this scores. JD content with Pressure delivery |
| E2 | "That calendar: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | The hold is the quote: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if the decisions were yours, say which; if others set what went in or fixed the dates, say so plainly and stay with running the calendar. Hold through two follow-ups, concede specifically, and never fold on the core claim | R1 and R6 rest on this one sentence, so an attribution probe will land here |

### F. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses."; "Presented the monthly retention numbers to the studio head." | A 90-second arc of four beats only: the years, the calendar, the checklist, the monthly numbers, each at its own scope in your own words. Why you are moving is yours to say; the pack writes no reason for you | R1, R4, R5, R6 and R7 sit in this one answer. Casual questions are still scored |
| F2 | "Tell me about something you wrote that other people actually used." | JD | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on R8: you wrote the release checklist, and your QA team still uses it. Tell those beats in your own words. Answer slot: if other writing of yours was acted on by other teams, say what it was; if the checklist is the one example, say so plainly and stay with it | R8 is the clear-written-communication requirement, and the checklist is the only quoted evidence for it |

## Values and principles cheat sheet

| Value | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | None of your sentences carries it. Scaffold in B1 |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | None of your sentences carries it. Scaffold in B2 |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | R4: "Wrote the release checklist our QA team still uses." Beats and slot in B3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "In your GDC talk you argued a live team is judged by whether its patch notes describe what actually shipped. How does your team check that internally?" | Ties to his public work, and signals you prepared for him, not just for the company |
| 2 | "You came to live operations from QA. How has that shaped what you expect a producer to own at a release?" | Ties to his own path and invites him to talk about the checklist side of the role |
| 3 | "Are the two titles in this role the ones moving to the shared calendar in February, and how does the producer's week change after that?" | Shows you read the Larkspur announcement and asks about the role's real shape |
| 4 | "What separates a strong Outage Hour from a weak one?" | Prep signal; also tells you how to use the rest of your hour |
| 5 | "How do design, art, engineering and community agree on a date today, and where does that get stuck?" | Ties to R2 and gives you the real coordination problem to think about |
| 6 | "What was the hardest thing for someone who joined the team last year to learn, and how was it taught?" | Opens the ramp-up conversation, including monetization, without you naming it first |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team | Negative the candidate stated | The plain acknowledgment: "I've never led a team." Quote limiting it: "Never led a team". No slot |
| Has worked on a game with in-app purchases | Negative the candidate stated | The plain acknowledgment: "I've never worked on a game with in-app purchases." Quote limiting it: "never worked on a game with in-app purchases". No slot |
| Owned the post-event review and its KPIs | Inflated form of R3 | R3's quote at its own scope. The limit is the pack's observation: your material says you presented the numbers, not that you owned a review |
| Ran live events across two titles | Inflated form of R1 | R1's quote at its own scope. The pack's observation: your material says the weekly content-drop calendar for your main title |
| Managed releases with QA | Inflated form of R4 | R4's quote at its own scope. The pack's observation: your material says you wrote the checklist and QA uses it |

## Sources

**Provided documents:** the JD and background you pasted in your message. No dossier was present, so no dossier sections were consumed.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Section 10 and B1 to B3: three values by official name. Query returned https://saltmarshgames.com/values, which was fetched |
| 2. `Saltmarsh Games interview process live operations producer` | yes | Loop structure: persona weights follow the Outage Hour. Query returned https://saltmarshgames.com/careers/interviewing, which was fetched |
| 3. `Saltmarsh Games mobile studio strategy news` | yes | A5, C2 and reverse question 3. Query returned https://saltmarshgames.com/news/project-larkspur; its content is the search snippet only, the page was not fetched |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | Reading the interviewer, D1 weight, reverse questions 1 and 2. Query returned https://talks.gdconf.example/2026/patch-notes-are-a-promise; snippet only, not fetched |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Confirmation that Tobias is your future manager, plus anything the recruiter said about what the tabletop covers → persona weights confirmed or reweighted, and the case bank retuned to the recruiter's focus areas
- Your CV text → R1 to R8 quoted from the document instead of from chat, and more story maps; the artifacts that would raise a row from medium to high are the checklist itself, the calendar itself (an export of a drop schedule) and a retention report you presented
- Your own answers to the slots on R1, R2, R3, R5 and R8, said in your own words outside a drill → those rows move from slots to quoted story maps
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes. It would read the Project Larkspur page and Tobias's talk page in full, add loop reports and recent org context, and add a grounding brief section plus sharper CO questions. Say the word and I will run it
- A tuesday-dossier.md from an earlier role check → evidence graded by confidence, a named top objection, and a prohibited-claims list built from your confirmed answers
