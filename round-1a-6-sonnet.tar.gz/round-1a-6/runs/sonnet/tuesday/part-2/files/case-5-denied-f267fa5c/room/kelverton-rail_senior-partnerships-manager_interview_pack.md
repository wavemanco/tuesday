# Kelverton Rail — Senior Partnerships Manager — second-round panel prep pack

## 1. Title block

- **Role:** Senior Partnerships Manager, Kelverton Rail
- **Round:** second round, Tuesday, 60 minutes: a 15-minute spoken POV on operator partnerships over the next 18 months with no slides, then Q&A
- **Panel:** Deepa, VP Partnerships (your future manager); Ross, Commercial Director, who the recruiter says "will push on commercials"
- **Built on:** your message only. No JD, no CV file and no copy of the market report were in hand, and web search was refused (section 14)

## 2. How to use this pack, and the type key

Personas describe how a question arrives. Types describe what it is scoring. Guidance is scaffolding, not a script: where a cell quotes your own sentence, say it in your own words at that scope, and where a cell holds an answer slot, answer from what you actually did or say plainly that you did not.

| Tag | Name | What it is really testing |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the company's published values (no values round is detected for this loop, so no VAL questions) |
| EXP | Work-experience deep-dive | Whether your claims survive scrutiny and how precisely you attribute them |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge | Homework depth and whether you think at the company's altitude |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the actual role |

## 3. Prep triage

You have about four hours across the weekend. Do these in this order. Everything else is insurance.

| Session | Time | What | Tied to |
|---|---|---|---|
| Saturday | 90 min | Build the POV: pick a thesis, choose one consensus item and one divergence from the report you have read, write six cue words, and run it aloud twice | Section 5 |
| Saturday | 30 min | Say the structure aloud for the case questions | A1 to A5 |
| Sunday | 75 min | The commercials chain: write down, in your own words, what you do and do not know about how the £4M was counted, then say C1 and its follow-ups aloud three times | B1 to B5, C1, D1 to D3 |
| Sunday | 15 min | Your 90-second arc and the seam answer | E1, P1, P2 |
| Sunday | 10 min | One last timed run of the POV, aloud | Section 5 |
| Sunday | 20 min | Pick your five reverse questions and say the first two aloud | Section 11 |

## 4. Fit snapshot

The posting was not supplied, so the first three requirements are the recruiter's own words from your message. F4 to F6 are role-family requirements with no source, written as plain prose and labeled generic. They raise no answer slot.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email, in your message | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [grounded] | transferability | Your material says an ISV channel at a payments company, not operator partnerships and not rail, and the words stay at that scope: "For my last four years at a payments company I ran the ISV channel and took it from 6 partners to 40." Answer slot: the recruiter's 18-month framing makes a probe on sequencing likely. If you chose the order partners were added, say how you decided, in your own words; if there was no such order, or it was not yours, say so plainly and stay with the growth as you stated it |
| F2 | "Please land on what it means for the operators themselves." — recruiter's email, in your message | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." — your message | medium | [grounded] | transferability | The quote is bus and light rail network planning; your material does not show train operating companies. The words stay there: "Before the partnerships work I spent five years in transport consulting, in bus and light rail network planning." Answer slot: expect a probe on what "the other side" meant. Say whose side you stood on and what it gave you, in your own words; if the phrase is wider than the work was, shrink it to the work |
| F3 | "Ross will push on commercials." — recruiter's email, in your message | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [grounded] | transferability | The figure is roughly £4M of influenced revenue, and the pack's observation is that your material says influenced, not closed or owned. Answer slot: if you know how the £4M was counted, what it is sensitive to, which assumption you would defend least and which part was yours, say so in your own words; if you do not know how it was counted, say so plainly and return to the figure as you gave it |
| F4 | Carry a direct commercial target for partner-sourced revenue (role-family, no source) [generic] | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never carried a direct quota, only influenced revenue." Then how you would learn it, said as a plan and never as a past: you would find out how targets are set here before proposing any |
| F5 | Has sold into the rail sector (role-family, no source) [generic] | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | Words: "I've never sold into rail specifically." Then a plan, not a past: what you would learn first. Nothing added to make the gap feel smaller, and F2 is not a substitute for it |
| F6 | Grow a partner base (role-family, no source) [generic] | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [grounded] | none | No gap in terms, but a line with nothing inspected behind it, so expect a probe on what counted as a partner (B4). Lead with the quote's own terms: "I took the ISV channel from 6 partners to 40." |

## 5. Graded deliverable: the 15-minute POV

The recruiter announced it, so it is graded. The panel wrote or circulated the report you read, so a recitation of it scores as homework and a departure from it, with reasons, scores as judgment.

**Grounded facts to build on.** Each is a row of the fit snapshot and a sentence quoted exactly from its evidence cell, used at that scope and no wider.

| Row | Sentence | How it may be used |
|---|---|---|
| F1 | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | One sentence of context, in its own terms, early. It is not evidence about operators or rail |
| F2 | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | The lens for your operator close, at its scope: bus and light rail network planning. Do not stretch it to train operating companies |
| F4 | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Say the limit once, early, in these terms, because Ross will reach it. Whether to name it in the first minute is your call |

**Three defensible theses.** All three are `[generic]` patterns, written without the report or the JD. Test each against the report you have read before choosing.

| Thesis | The line you would say | Mandatory concession |
|---|---|---|
| T1 Depth before breadth | Choose a small number of operator partnerships and make each work to an outcome the operator defines, before widening | Fewer partnerships means slower headline growth and concentration on a few operators |
| T2 The operator is the unit of success | Define each partnership by an outcome the operator's own people would recognise, agreed before work starts | Kelverton cannot guarantee outcomes an operator controls, and agreeing them up front slows signing |
| T3 A repeatable motion, then scale | Get one partnership motion working end to end, then repeat it | A repeatable motion risks standardising what operators want to shape themselves, and the first partnerships will be bespoke |

**Differentiation from the report.** Bring one consensus item from the report in one sentence to show you read it, then one divergence your chosen thesis supports, with your reason. Then give the anti-pick: one kind of operator partnership you would decline in year one, with your criteria. A role that includes saying no is graded on the criteria, not on the example. Do not walk through the report's list.

**Shape, as six cue words and about ten minutes spoken**, leaving the rest of the 15 for a first question: framing (what you take "operator partnerships" to mean, and that you would check it with them), thesis, three moves across 18 months, measures (what Kelverton would count and what an operator would count), the concession, the operator close.

**The requested close, what it means for the operators themselves.** Three sentences: what is different for an operator at month 18, in the operator's terms; what the operator is asked to commit; how an operator would know within 18 months that it is working. Pending your approval: every sentence is yours to write. The pack supplies the structure and no facts about Kelverton's operators.

## 8. Persona table

Personas are assigned per panel member from their roles and the recruiter's own words.

| Persona | How it shows up here | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Deepa, your future manager, after the POV: plan this, sequence that | High. The hiring-manager prior is Case/Strategist plus Skeptic, and the POV is itself a live problem on their roadmap | Clarify, then objective, approach, measures, risks. Think aloud and challenge one premise respectfully |
| Data-Driven Prober | Ross on the £4M and the 6 to 40 | High. The recruiter's words, "Ross will push on commercials", plus two headline numbers in your own summary | Know what you can and cannot say about how each figure was counted, and say plainly when you do not know. Name the assumption you would defend least before he does |
| Skeptic | Both panelists, on the two stated gaps | Mid. The hiring-manager prior, and you have named both gaps yourself | Rehearse C1 until it is boring. Bridge only from what you stated, and name the limit before it is asked |
| Pressure | Ross, time-boxing and testing influenced revenue | Mid. "Push" suggests it, but nothing says whether his style is composure-testing or numbers-testing | Pause, restate, hold through two follow-ups, concede specifically |
| Conversational | Opening biography question | Low. It is a panel with a set agenda, but openers are still scored | A 90-second arc built only from what you have said |
| Peer Evaluator | Ross as the commercial counterpart, on the seam | Low. He is not a peer by title, but partnerships and commercial share a boundary | Propose seam principles rather than claiming to know the seam |

No Values/Behavioral bank: the recruiter describes a POV and Q&A, no values round is detected, and no published values are in hand.

## 9. Question banks

### A. Case / Strategist (Deepa) — top weight

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Talk us through where you'd take our operator partnerships over the next 18 months." | CASE | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | This is the section 5 build. Your first sentence says what you take "operator partnerships" to mean and that you would check it with them. Context from your material is the one sentence: "For my last four years at a payments company I ran the ISV channel and took it from 6 partners to 40." Nothing about operators or rail comes from it | The recruiter announced this as the deliverable, and F1 is the evidence nearest it. CASE because it is a live problem, JD-driven in content |
| A2 | "What would you need to know in your first 30 days before committing to a plan?" | CASE | [generic] | Structure it: what you would ask operators, what you would ask internal teams, what you would want to see written down, and what decision each answer unlocks. It needs no claim about your past, so the guidance makes none | Tests clarify-before-structure, which the Case persona scores. Generic because it is a pattern for the problem and no fact about this employer |
| A3 | "An operator partner tells us our scheduling software isn't solving their problem. How do you handle it?" | CASE | [generic] | Structure: acknowledge, find what exactly is not working and for whom in the operator's organisation, separate a product issue from a relationship issue, bring the right internal team in, agree a next step with a date. It needs no claim about your past | A live problem on the relationship side of the job, drawn from F2's operator-facing requirement. Generic because it asks about no past |
| A4 | "Sketch how you'd choose and sequence the first operator partnerships — what do you need to know first, and what would you say no to?" | CASE | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Answer as a plan: criteria, order, and the anti-pick from section 5. Answer slot: the recruiter's 18-month framing makes a probe on how you grew the channel likely. If you chose which partners came first, say how you decided, in your own words; if there was no such choice, or it was not yours, say so plainly and stay with the growth as you stated it | F1's sequencing probe and the report differentiation both land here. CASE for the live problem, JD because the recruiter's framing raises it |
| A5 | "What does your plan mean for the operators themselves — what is different for them in 18 months?" | CASE | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | The three-sentence close from section 5. If you mention your consulting years, use the sentence's words: five years in transport consulting, in bus and light rail network planning. Do not describe operators' working lives beyond what you have actually seen | The recruiter's requested close, F2. CASE because it is asked as a recommendation |

### B. Data-Driven Prober (Ross) — top weight

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the roughly £4M of influenced revenue was counted." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Say the figure in its own terms: roughly £4M, influenced. Answer slot: if there was a rule linking a partner to a deal, say what it was, in your own words; if there was no formal rule, or the count was not yours, say so plainly and return to the figure as you gave it | F3 is the first place a commercial director probes. EXP because it tests whether the number survives attribution |
| B2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | The weakest-assumption move: name the assumption you would defend least, in your own words, before he does. The pack names none. Answer slot: if you do not know how it was counted, say so plainly; that answer holds up better than a guess | F3. EXP because converting a gotcha into candor is the move being scored |
| B3 | "How much of that £4M was actually you?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Hold only what the sentence carries: you ran the ISV channel and took it from 6 partners to 40. Answer slot: say which part was yours, in your own words; if the share cannot be separated, say so plainly and return to the sentence | F3 and the Pressure stem for attribution. EXP because it tests attribution honesty |
| B4 | "What counted as a partner in the 40?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Answer slot: if there was a definition, say what it was in your own words; if there was no formal one, or it was not yours, say so plainly and stay with "I took the ISV channel from 6 partners to 40." | F6's headline metric: a partner count raises the same denominator question as a revenue figure |
| B5 | "Partnerships here will be judged commercially. What would you want to be measured on, and what would you refuse to be measured on?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Start with the limit in your own terms: "I've never carried a direct quota, only influenced revenue." Then propose, as a plan: leading measures the operator would recognise, lagging revenue measures, and what you would ask about how targets are set before proposing any. Nothing here claims past target-setting | The recruiter flagged commercials, and F4 is the gap this question presses. JD because it scores a stated expectation |

### C. Skeptic (both) — mid weight

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've never sold into rail, and you've never carried a direct quota. Why should we believe you can do this here?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | **Highest-ROI prep in this pack.** Name the limit first, before they do: "I've never carried a direct quota, only influenced revenue, and I've never sold into rail specifically." Follow-up 1, "So the £4M wasn't yours to deliver?": hold on the figure as given, roughly £4M of influenced revenue, and nothing more. Follow-up 2, "Then why would a target here be different?": answer as a plan, learning how targets are set here and what counts as partner-sourced before proposing one. Follow-up 3, "Would you take one?": that is D3, and the answer is your own decision | F4 and F5 are the two stated gaps and this is the single most predictable question. JD because it scores the stated requirement. The limit is the quote's, and nothing here softens it |
| C2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Pick from what you have said: the two limits in their own words. Then what you would do in the first weeks, as a plan. Do not name a third weakness the material does not carry | F4 and F5. A stem asked of every hiring-manager candidate, and the honest answer is already on the page |
| C3 | "What draws you to this role, and why now?" | JD | [generic] | Give your own reason in two or three sentences and make sure it would hold against the rest of this pack. The pack supplies none. Do not recite the report as your reason | Motivation consistency is what the Skeptic scores. Generic because the reason is yours alone |

### D. Pressure (Ross) — mid weight

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a candidate who has sold into rail?" | JD | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue."; "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Pause, restate the question in a clause. Hold: "For my last four years at a payments company I ran the ISV channel and took it from 6 partners to 40." Concede, specifically: "I've never sold into rail specifically." Hold through two follow-ups by returning to the first sentence and never by adding to it | F5 is the gap, and this is its time-boxed form. JD because it compares you with the role's stated need |
| D2 | "Influenced revenue is a soft number. Convince me it's worth anything to us." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue."; "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Do not defend the number harder than you hold it. Restate, then: "It's roughly £4M of influenced revenue, and that is how I'd describe it." Concede the limit in the quote's words. The counting detail is B1's slot and the same two branches apply | F3 and F4 in Pressure packaging. EXP because it tests attribution under composure pressure |
| D3 | "Suppose we asked you to carry a direct partner-sourced target in year one. Would you take it?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Decide before Tuesday what your actual position is, including any terms, and say that in your own words. The pack supplies no yes and no conditions. Do not describe having carried a target, because you have said you have not | F4 turned into a decision. JD because it tests the stated commercial expectation, and it is a future choice the pack cannot make for you |

### E. Conversational (opening)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)."; "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Ninety seconds in three beats the sentences state: five years in transport consulting, in bus and light rail network planning; nine years in partnerships, the last four running the ISV channel at a payments company. Your material names only the last four partnership years, so the first five are yours to describe in your own words, or to leave out | F1 and F2 give both ends of the arc. EXP because the biography is checked against the rest |
| E2 | "What are you actually looking at in scheduling or rail-tech these days?" | CO | [generic] | Say only what you have genuinely looked at before Tuesday. Answer slot: if you have not looked at anything yet, say so plainly and say what you would look at first. Do not recite the report | A casual question about the employer's field that is still scored. Generic because it asks about no past |

### P. Peer Evaluator (Ross, as commercial counterpart)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Where is the seam between partnerships and commercial, and what happens when we disagree?" | CASE | [generic] | Propose seam principles and do not pretend to know the seam: who owns the relationship, who owns the price, and how a disagreement is settled. Offer what you would bring his team as well as what you would need from it. If asked for a real example of a disagreement, choose one you actually had; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Ross's role sits across the commercial boundary, and this is the collegial form of the F4 concern. CASE because it asks for a design |
| P2 | "How do you handle credit when a partner-led deal also has our sales team's fingerprints on it?" | EXP | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Say how you would propose credit be shared here, as a plan. Answer slot: if there was a credit rule at the payments company, say what it was and which part you set, in your own words; if there was none, or it was not yours, say so plainly and return to "influenced revenue" as you stated it | F3 and F4 as a collegial probe. EXP because it tests the attribution habits behind the figure |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 operator partnership POV | A1, A2, A4, section 5 |
| F2 land on what it means for operators | A3, A5, E1, section 5 |
| F3 commercial push | B1, B2, B3, D2, P2 |
| F4 direct commercial target | B5, C1, C2, D1, D2, D3, P2 |
| F5 sold into rail | C1, C2, D1, E2 |
| F6 grow a partner base | B4, E1 |

## 11. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "When you say operator partnerships, which kinds of operator relationship do you count, and which would you most like more of?" | It checks the framing you flagged in your first sentence and gives you the definition for every later answer |
| R2 | "What would tell you in the first 90 days that this hire is working?" | It turns the commercial push into agreed measures on their terms |
| R3 | "How is partnership performance judged here today, and how do you want it judged in 18 months?" | It puts the quota and influenced-revenue question on the table without you defending it, and Ross will have a view |
| R4 | "Where does partnership work overlap with the commercial team's, and where do you want it kept separate?" | It is the seam question, asked by you, to the person who owns the other side |
| R5 | "Which recommendation in the strategy report do you think will be hardest to deliver?" | It shows you read the report and moves the conversation from reciting it to judging it |
| R6 | "What would an operator tell us is the best and worst thing about working with us today?" | It shows the operator-side lens the recruiter asked you to land on |

## 13. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Carried a direct quota, or owned or delivered revenue | Negative the candidate stated, F4 | The plain acknowledgment F4 gives: "I've never carried a direct quota, only influenced revenue." No slot |
| Has sold into rail | Negative the candidate stated, F5 | The plain acknowledgment F5 gives: "I've never sold into rail specifically." No slot |
| Closed or delivered £4M | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation, not words for you: the material says roughly £4M of influenced revenue. B1 to B3 stay inside the figure as given |
| Built, launched or designed the ISV channel | Inflated form of F1 and F6 | The quote at its own scope: you ran the channel and took it from 6 partners to 40. The limit is the pack's observation: the material says running and growing it, not starting it or designing it |
| Knows train operating companies | Inflated form of F2 | F2's quote at its own scope, bus and light rail network planning. The limit is the pack's observation: your material does not show train operating companies |

## 14. Sources

- **Provided documents:** your message, including the recruiter's email as you quoted it. No `tuesday-dossier.md` was present. The market report the recruiter attached was not pasted here, so it was not read.
- **Searches sent, all refused:**
  - `Kelverton Rail company values` — refused
  - `Kelverton Rail interview process partnerships` — refused
  - `Kelverton Rail strategy train operating companies scheduling software news` — refused
  - `Deepa VP Partnerships Kelverton Rail` — refused
  - `Senior Partnerships Manager rail technology job description train operating companies` — refused
- Nothing in this pack rests on research. Everything about Kelverton comes from your message.

Research tier: L1 — searches 5 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Search refused. It would have fed the values cheat sheet, which is dropped here anyway because no values round is detected |
| 2. `Kelverton Rail interview process partnerships` | unavailable | Search refused. It would have checked the loop and persona weights, which here rest on the recruiter's own words |
| 3. `Kelverton Rail strategy` / recent news | unavailable | Search refused. It would have fed a CO question and a grounding brief, both absent here |
| 4. `Deepa VP Partnerships Kelverton Rail` | unavailable | Search refused, and no second query for Ross was sent after it. It would have fed the interviewer read, which is dropped |
| 5. representative Senior Partnerships Manager JD | unavailable | Search refused. It would have given quoted requirements to the fit snapshot and JD-tagged questions in place of the generic rows F4 to F6 |

## 15. Upgrade menu

- The JD text → F4 to F6 become quoted requirements instead of generic ones, the JD-tagged questions are re-derived, and any gate it contains (location, right to work, travel) becomes a visible row
- The market report's main recommendations, pasted → the section 5 differentiation stops being a method and names the consensus item and the divergence, and a CO question is added
- Search access, which was refused in this session → company values, loop checks, recent news and public footprints for Deepa and Ross, plus an interviewer read and a reverse question tied to a path; a deeper pass of up to 6 more searches and 2 more fetches is available once and takes several more minutes
- In your own words, how the £4M was counted and which part was yours → B1 to B3, D2 and the F3 slot become story-mapped, labeled `[grounded]` rows
- In your own words, what you did in your first five years in partnerships → E1's arc is completed from your sentences instead of left to you
- Deepa's and Ross's surnames or profile links → the interviewer read and persona weights per panel member
- A `tuesday-dossier.md` from an earlier assessment of this role → verified evidence, the objection worth the deepest rehearsal, and absolute prohibited claims, all of which this pack inferred locally
