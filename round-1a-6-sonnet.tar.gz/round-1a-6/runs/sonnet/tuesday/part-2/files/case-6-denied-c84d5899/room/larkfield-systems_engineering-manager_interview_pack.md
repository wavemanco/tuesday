# Engineering Manager, Larkfield Systems: three-round interview pack (loop mode)

Candidate: Yusuf. Interviewers are unnamed in everything provided.

| Round | When | Who | Length | Relationship |
|---|---|---|---|---|
| R1 | Tuesday | Director of Engineering | 45 min | Hiring manager, your would-be boss |
| R2 | The Thursday after | Two staff engineers and a product manager | 60 min | Panel: technical peers plus a cross-functional partner |
| R3 | The following Monday | VP Engineering | 30 min | Skip-level, described by the recruiter as "values and leadership philosophy" |

Built from the role description you pasted and your own account of your background. No company research ran (see Sources). Everything about Larkfield itself is therefore absent or labeled `[generic]`.

## How to use this pack

- Personas describe how a question is asked. Types describe what is being scored.
- Types: VAL is values and behavior, EXP is a deep-dive on your own experience, JD is a stated role requirement, CO is company and strategy knowledge, CASE is a live problem.
- Guidance is scaffolding, not a script. Where a cell says "answer slot", it is an instruction for the interview: answer it truthfully from your own experience, in your own words, and take the second branch if the practice was not yours or never existed.
- Quotes in the Provenance column are your own sentences. Say nothing about your past that those sentences do not say.

## Prep triage

Two weeks, three rounds. In order:

1. Before Tuesday: A1 (the hardware answer, the highest-ROI prep in this pack), then B3 and C2.
2. Before Thursday: E1 to E3 (the 60% figure and the reliability quarter), then D3 and D1.
3. Before Monday: G1, H1 and G2.
4. Everything else is insurance.

## Fit snapshot (shared across all three rounds)

The role description gives no location, pay, schedule, travel or credential term, so the snapshot has no gate rows. Where a requirement quote is the role description's words, its source is "role description you pasted".

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role description you pasted | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | medium | [grounded] | transferability | Your material says a team lead of 6 at a payments company. It does not show a second squad or device-management work, and the words stay at "3 as a team lead of 6". Answer slot: the two-squads line makes a probe on what changes beyond one team likely. If you have led or coordinated beyond that one team, say how, in your own words; if not, say so plainly and stay with the team of 6. Answer slot: if any of your services worked with devices or fleets, say what; if none did, say so plainly |
| F2 | "own delivery, hiring and growth for 11 engineers" — role description you pasted (the delivery part) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | discovery | The quote says on-call burden dropped 60% after you pushed a reliability quarter through against roadmap pressure. The word is "after", not "because", and the words stay there. Answer slot: the own-delivery line makes a probe on how delivery commitments were handled likely. If delivery dates or commitments were yours to set or move, say which and how you decided; if they were not, or there was no such step, say so plainly and stay with the reliability quarter |
| F3 | "own delivery, hiring and growth for 11 engineers" — role description you pasted (the hiring part) | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | none | The quote already speaks to hiring in role-relevant terms, but it is a message line with nothing inspected behind it, so expect a probe. Lead in its own terms: you run the loop, for backend roles, about 40 interviews last year. The counted noun is interviews, so hires are not claimed |
| F4 | "own delivery, hiring and growth for 11 engineers" — role description you pasted (the growth part) | none given | none | [grounded] | discovery | Your material says nothing about developing engineers. Answer slot: the growth line makes a probe likely. If you have helped an engineer grow, say who in general terms and what you did, in your own words; if you have not, say so plainly and say how you would approach it as a plan, not a past |
| F5 | "partner with hardware and product on roadmap" — role description you pasted (the product part) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | low | [inferred] | discovery | The quote says roadmap pressure, not whose, so the pack derives only a lead, not a claim. Answer slot: if that pressure came from product, say who and how it was worked out, in your own words; if it came from elsewhere, or there was no product counterpart, say so plainly and stay with the reliability quarter |
| F6 | "partner with hardware and product on roadmap" — role description you pasted (the hardware part) | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | discovery | The sentence says you have not owned a hardware-adjacent roadmap, and the words for that are your own: "I haven't owned a hardware-adjacent roadmap." It is silent on working alongside hardware teams. Answer slot: if you have worked alongside hardware or embedded teams in any form, say what, in your own words; if not, say so plainly. Then a ramp plan, said as a plan and never as a past |

The pack's own observation, not words for you: the role description does not say whether the two squads have leads under you, so your stated limit on managing managers matters only if the answer to that is yes. R1's reverse question 1 asks it.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed 6 engineers, or line-managed a team | Inflated form of F1 | F1's quote at its own scope: "3 as a team lead of 6". The limit is the pack's observation: the material says team lead, not what the role covered |
| Managed managers, or led a lead layer | Negative you stated, F6's sentence | "I haven't managed managers." No answer slot |
| Owned a hardware-adjacent roadmap | Negative you stated, F6's sentence | "I haven't owned a hardware-adjacent roadmap." Working alongside hardware stays an answer slot in A1 |
| The reliability quarter caused the 60% drop, or the 60% is a wider result than your team's | Inflated form of F2 | F2's quote at its own scope: the drop came "after", and it is your team's on-call burden |
| Hired about 40 engineers, or personally interviewed 40 candidates | Inflated form of F3 | F3's quote at its own scope: the loop ran about 40 interviews |

## Round 1: hiring manager, Tuesday, 45 min

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (4 questions) | Quiet probing of the hardware gap, the scope jump and why leave | High: a hiring manager is derisking a gap, and your message names two limits | Rehearse the single most predictable objection until it is boring; name the limit plainly, then a ramp plan |
| Case/Strategist (3) | Live problems from their actual roadmap | High: the relationship prior for a hiring manager, and your boss will want to see how you reason | Clarify, objective, options, metrics, risks; think aloud; challenge one premise respectfully |
| Conversational (2) | Biography opener and a hiring question in a friendly register | Medium: an opener is near-certain in any 45-minute round, and it is scored | Prepared 90-second arc built only from your quotes |

No interviewer profile and no company research, so these weights rest on the relationship prior alone.

### Bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't owned a hardware-adjacent roadmap. How would you work with our hardware team on ours?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | The highest-ROI prep in this pack. Open with the limit before it is asked for: "I haven't owned a hardware-adjacent roadmap." Then a ramp plan said as a plan: name, in your own words, the two or three things you would need to learn from hardware and from product first, and how you would learn them. Answer slot: if you have worked alongside hardware or embedded teams in any form, say what; if not, say so plainly and stay with the ramp plan. Hold through two follow-ups by returning to the plan, never by adding to your past | F6 is where the role's roadmap line presses hardest, so this objection arrives in some form. JD because it scores a stated requirement, with CASE delivery |
| A2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Name one limit your message states, with its own words. The role description raises hardware, not managers, so the hardware limit is the one the role line asks about; raise the manager limit only if asked or if the answer to reverse question 1 makes it relevant. Plain acknowledgment, then the ramp plan. Do not volunteer a limit you cannot back | F6 supplies both limits. The Skeptic stem is asked in almost every hiring-manager round |
| A3 | "You've led a team of 6. This is eleven engineers across two squads. What changes?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Say what you led in the quote's own terms: three years as a team lead of 6. Answer slot: the two-squads line makes a probe on what changes likely. If you have split attention or structure across more than one group, say how; if you have not, say so plainly and answer as a plan, not a past | F1's scope gap. The 11 and the two squads come from the role description |
| A4 | "Why leave a payments company for industrial IoT, and why now?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Answer slot: give your actual reason, in your own words. Use only reasons you hold. No company research ran, so do not cite Larkfield's strategy or values until you have read their own material | Motivation consistency is what the Skeptic scores. The pack has no sourced Larkfield facts to build a reason from |
| B1 | "Product wants a reliability backlog deferred for a feature. Walk me through how you decide." | CASE | [generic] | A live problem, so no claim about your past. Structure: what you would ask first, the objective, the options and what each costs, how you would measure the outcome, the risk you would name. Challenge one premise respectfully. If you reach for your own reliability story, say only what its quote says, and take it from B3 | The role description's delivery and roadmap lines make a delivery-versus-reliability case likely. `[generic]` because it is a pattern, not a Larkfield fact |
| B2 | "A hardware release slips and both squads' plans depend on it. What do you do in the first week?" | CASE | [generic] | No claim about your past. Clarify what slipped and what depends on it, then objective, options, who you talk to and in what order, what you would decide yourself and what you would escalate. Say a premise you would test | Tests the hardware partnership requirement through a case, where F6 stays an acknowledged limit and not a bluff |
| B3 | "Tell me about a time you pushed back on roadmap pressure." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Beats the quote states: you pushed a reliability quarter through, against roadmap pressure, and on-call burden dropped 60% after. Say "after", as your own words did. Defend-the-number slots: how the 60% was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours; answer each in your own words, and if you do not know how it was counted, say so plainly. Answer slot: if the pressure came from product, say who and how it was resolved; if not, say so plainly | The open-prompt theme comes from the role description's roadmap line. F2 and F5 are the evidence; EXP because it tests what was actually yours |
| C1 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I run our hiring loop for backend roles — about 40 interviews last year."; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | A 90-second arc with only the beats these three sentences state: nine years engineering, three as a team lead of 6, now at a payments company, you run the backend hiring loop, and the reliability quarter. Answer slot: why this role next, in your own words | A biography opener is near-certain and scored; F1, F2 and F3 hold the beats |
| C2 | "How do you run hiring for backend roles?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Say it in the quote's terms: you run the loop, for backend roles, about 40 interviews last year. Defend-the-number slots: how the 40 was counted, and which part was yours; if you do not know, say so plainly. Answer slot: the hiring line makes a probe on the loop's stages, rubric and calibration likely. If you set any of those, say which and how you decided; if they were set before you, by someone else, or there was no such step, say so plainly and stay with the fact that you run the loop | F3. The role says you own hiring for your squads, so this is where you are strongest, and a prober will still test the number |

## Round 2: panel, Thursday, 60 min

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator (4) | Seam-splitting between engineering and product, "what do you need from me" | High: three people who will work alongside you, and the PM sits exactly on the roadmap seam | Reciprocity: what you bring their team. Propose seam principles, not false knowledge of their seam |
| Data-Driven Prober (3) | Staff engineers pressing on the 60% and the reliability quarter | High: staff engineers read claims line by line, and your message gives them one number | Know what you can and cannot say about how the number was counted; name the weakest assumption first |
| Values/Behavioral (2) | The PM's behavioral probes on disagreement and saying no | Medium: the cross-functional prior; the recruiter described no values round for this session | Stories only where a quote carries one; otherwise a selection scaffold ending in its honest branch |

Panel blend: top two personas of each member's relationship (staff engineers: Peer Evaluator and Prober; PM: Values/Behavioral and Conversational, with the Conversational weight folded into the Peer Evaluator seam questions). Unnamed, so no per-member assignment.

### Bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where is the seam between engineering and product, and what happens when we disagree?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Propose principles for the seam, not claimed knowledge of theirs. Reciprocity: what you would bring their team. If you tell a disagreement story, use only this quote's beats. Answer slot: if the roadmap pressure came from product, say who and how it was resolved; if not, or there was no disagreement with product, say so plainly | F5. The PM and the staff engineers will each price what a manager costs their work |
| D2 | "What do you need from product to run two squads well, and what will product need from you?" | JD | [generic] | No claim about your past. Two short lists in your own words, with the second as long as the first. Say which items you would test with product in the first weeks rather than assume | The PM's natural reciprocity question. `[generic]` because no Larkfield fact is sourced |
| D3 | "How do you lead engineers who know the domain better than you do?" | JD | [generic] | No claim about your past. Principles in your own words: what you would ask them, what you would decide yourself and what you would leave to them, how you would learn the domain fast. Do not claim hardware depth you do not have; your own limit is in F6 | The question a staff engineer asks a manager who has not worked in their domain. Highest-risk question in the panel |
| D4 | "When a staff engineer disagrees with you on technical direction, what do you do?" | CASE | [generic] | No claim about your past. How you would listen, what would make you overrule and what would make you defer, and how you would record the decision. Hold-then-concede is the shape if pushed | Staff engineers screen managers for turf awareness; a peer-style probe |
| E1 | "Walk me through how the 60% was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Defend-the-number slots, each in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. Keep "after", never "because" | F2. A figure with nothing inspected behind it is the first thing a prober tests |
| E2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Answer slot: name the weakest assumption you know of, in your own words, before they do; if you do not know one, say so plainly. The pack does not name it for you | The weakest-assumption move converts a gotcha into credibility. Stem from the Prober persona |
| E3 | "Walk me through the reliability quarter: what did you push against?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The beats the quote states: a reliability quarter, pushed through, against roadmap pressure. Answer slot: the roadmap line makes a probe on who applied the pressure and how it ended likely. Say, in your own words, who and what happened; if there was no single source, or it was not resolved the way the quote's ending implies, say so plainly | F2 and F5. The follow-up two levels deep is where the story is tested |
| F1 | "Tell me about a time you disagreed with a product partner and what you did." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Selection scaffold: pick a time with a named stake, a moment you did not fold, and an intact relationship at the end. If the reliability quarter fits, its quote carries only: you pushed it through against roadmap pressure. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The open-prompt theme comes from the role's product-partnership line. F5 |
| F2 | "Tell me about a time you had to say no to a request from another team." | VAL | [generic] | Selection scaffold: pick a time with a named request, a reason you can state, and a relationship that survived. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A cross-functional behavioral probe. No quote carries this, so it is a scaffold |

## Round 3: VP Engineering, Monday, 30 min

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral (4) | Stories mapped to how you lead | High: the recruiter's words are "values and leadership philosophy", and the loop is documented by you and the recruiter | Stories only where a quote carries one; "we" for context, "I" for contribution |
| Pressure (3) | Time-boxed, devil's advocate | Medium: the executive prior, and the thin 30 minutes | Pause, restate, anchor in what you stated, hold two follow-ups, then concede specifically |
| Case/Strategist (2) | First 90 days, how you would approach a fleet-scale change | Medium: the skip-level prior, tempered by a values-led description | Think aloud; clarify before you structure |

Thirty minutes carries about four or five of these questions. Rehearse G1, G2, H1 and I2 first.

### Bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | If the reliability quarter fits, its quote carries only: you pushed it through, against roadmap pressure. Answer slot: say what you said, to whom and what happened, in your own words; if it was not a message to leadership, or the material does not show the truth landing, say so plainly rather than supplying an ending. If none fits, say so plainly and give the nearest thing your material does carry, or how you would handle it | The persona stem for Values/Behavioral. F2 is the only quote that could carry it |
| G2 | "How do you think about what a good engineering manager does?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year."; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Your philosophy, in your own words: two or three principles you actually act on. Tie each to something you did only if one of these two quotes carries it; otherwise leave it as a principle and say what you would do. Do not state what your work is proof of; let them draw it | The recruiter's "leadership philosophy" line raises it. F2 and F3 are the only quoted material to anchor it |
| G3 | "Tell me about a time you helped an engineer grow." | VAL | [generic] | Selection scaffold: pick a time with a named person (no name needed), a specific thing you did, and a visible change. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The role's growth line raises it, and F4 holds no quote |
| H1 | "Sixty seconds: why you for this role over someone who has run hardware-adjacent roadmaps?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I've never managed managers and never owned a hardware-adjacent roadmap." | Pause and restate the question. Hold only what the quotes carry: three years as a team lead of 6. Concede the limit specifically: "I haven't owned a hardware-adjacent roadmap." Then your ramp plan from A1. Do not claim to be better than the other candidate | F1 and F6. The Pressure stem, and the hold-then-concede shape |
| H2 | "That result, the 60%: how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold what the quote carries: you pushed the reliability quarter through. Concede specifically that the drop came "after" and was your team's on-call burden. Answer slot: which parts were yours and which were others', in your own words; if others did most of it, say so plainly | The Pressure stem. F2. The most-asked pressure question in an executive round |
| H3 | "You've never managed managers. Does that matter for where this role could go?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Plain acknowledgment: "I haven't managed managers." Then the plan: what you would want to learn and from whom, in your own words. The role description does not say it manages managers, so do not argue the point | F6's stated limit. A skip-level probes growth path |
| I1 | "If your squads rolled out a change to a fleet of devices in customers' plants, what would you want to know first?" | CASE | [generic] | No claim about your past. Clarify what could go wrong and for whom, how you would stage the change, how you would know it worked and how you would undo it, and what you would not decide alone | The role builds device-management services, which makes a fleet-scale change case likely. `[generic]`: no Larkfield process is sourced |
| I2 | "What would you do in your first 90 days?" | CASE | [generic] | No claim about your past. Listen first: who you would meet, what you would read, what you would not change yet. A plan with a few concrete checkpoints, said as intentions. Name the hardware and product relationships as the ones you would build first | Near-certain at a skip-level. F6 is the honest reason the plan opens with listening |

## Reverse questions

### R1: the Director

| Question | Why it lands |
|---|---|
| "Do the two squads have tech leads or senior engineers who carry day-to-day direction, and what do you expect from me versus them?" | Settles whether managing managers is even in scope, which the role description does not say |
| "What does success look like at 90 days and at a year?" | Gives you your boss's own scoring sheet |
| "How does the hardware roadmap reach the squads today, and where does it hurt?" | Shows you are starting from the hardware seam, the area you flagged as new |
| "What is the hardest delivery-versus-reliability tradeoff the squads face right now?" | Ties to the roadmap pressure you have lived |
| "What would make you say the first six months did not go well?" | Surfaces the real worry before you leave the room |

### R2: the panel (reciprocity included)

| Question | Why it lands |
|---|---|
| "What could a new manager do in their first month that would genuinely help your squads?" | The reciprocity question for peers |
| "What does the staff engineers' role look like next to the manager's today?" | Shows turf awareness to the staff engineers |
| "How does product learn about hardware constraints now, and how do you want that to change?" | Speaks to the PM on the seam |
| "What is one decision you wish the last manager had involved you in earlier?" | Draws out a pain the panel will want fixed |
| "What is the best technical call this team made in the last year?" | Rapport and a view of how the team reasons |

### R3: the VP

| Question | Why it lands |
|---|---|
| "What leadership habit do you most want engineering managers here to have?" | Hands you the VP's own philosophy to test your answers against |
| "How are managers here grown and held to account?" | Responds to "leadership philosophy" and your own growth gap in F4 |
| "Where does engineering most need to change in the next year?" | Strategy-altitude, without claiming Larkfield facts |
| "What separates the managers you would promote from the ones you would not?" | A candid growth-path question for a first manager-of-the-squads role |
| "What would you want me to have fixed by the end of my first year?" | Closes on what success looks like to them |

## Requirement coverage

| Requirement | Questions |
|---|---|
| Lead two squads building device-management services | A3, I1; device-management background is an answer slot in F1 |
| Own delivery | B1, B3, E3, H2 |
| Own hiring | C2 |
| Own growth for 11 engineers | G3, G2 |
| Partner with hardware on roadmap | A1, A2, B2, D3, H1 |
| Partner with product on roadmap | B3, D1, D2, F1, F2 |
| "Values and leadership philosophy" (recruiter's words for R3) | G1, G2, G3 |

## Sources

Provided: the role description you pasted, your three rounds and their interviewers' roles, and your own account of your background. No dossier was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Search refused; it would have moved the values cheat sheet, which is dropped for lack of published values in hand |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Search refused; it would have moved loop structure, though your own account already fixes the three rounds |
| 3. `Larkfield Systems strategy` / recent news | unavailable | Search refused; it would have grounded CO and CASE questions in current strategy, so those are `[generic]` |
| 4. `{interviewer name} Larkfield Systems` | n/a | No names were given, so no query could be formed; the interviewer read is dropped |
| 5. representative `Engineering Manager` JD | skipped | The role description you pasted fixes the requirement rows as far as it goes; a full JD would extend them |

Queries sent, all refused: "Larkfield Systems industrial IoT values"; "Larkfield Systems interview process engineering manager"; "Larkfield Systems strategy news industrial IoT device management".

## Upgrade menu

- The full job description → any location, travel, schedule or credential terms become fit-snapshot rows, and `[grounded]` JD-tagged questions replace `[generic]` ones
- What the recruiter said each round will cover → coverage tuned per round, plus any pre-declared deliverable
- The panel's and the VP's names → an interviewer read, persona weights from their public footprint, and a reverse question tied to their own path
- Larkfield's published values page, pasted → the values cheat sheet for R3, with a mapped story for each value
- A pasted company strategy brief, or a deeper research pass if search becomes available → CO and CASE questions grounded in current strategy
- How the 60% was counted and who the roadmap pressure came from → rows F2 and F5 move from answer slots to story-mapped guidance
- Any work alongside hardware or embedded teams → F6 gains a quoted bridge beyond the ramp plan
- A `tuesday-dossier.md`, if you have one → the objection worth the deepest rehearsal arrives evidence-derived instead of inferred
