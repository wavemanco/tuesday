# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara. **Loop:** three rounds on 5 December 2026: recruiter screen (30 min), Head of Member Services (45 min, your future manager, mostly behavioural), panel of two branch managers (60 min, including a 20-minute complaint-escalation case; also the values round, scored against the four values).
**Interviewers:** none named yet, so there is no interviewer read; persona weights rest on each round's relationship and the recruiter's description.
**Built on one assumption:** the recruiter's email is the whole loop; this is loop mode, with one shared fit snapshot and a mini-pack per round.

## How to use this pack

Personas describe how a question is asked. Types describe what it is scoring. Guidance is scaffolding, not a script: every line of proposed wording here is pending your approval, so change anything that is not true of you. Where guidance says "answer slot", it is an instruction for the interview, not a question for now: answer either branch from your own experience.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows Ashgrove's published values, not generic virtue |
| EXP | Whether what you say about your work survives follow-up, and what was actually yours |
| JD | Whether you can do the listed job, including its gaps |
| CO | Whether you can think at the company's altitude: strategy, competition, recent moves |
| CASE | Structure and reasoning on a live problem from the role |

Where a question carries one type, the rationale says when a second type applies.

## Prep triage

All three rounds fall on 5 December, nine days from today (26 November). In this order:

1. Round 2, question D2: the most predictable objection to you, and the highest-ROI prep in this pack. Rehearse it aloud until it is boring.
2. Round 3, questions G1 to G4 and the values cheat sheet: the panel scores against the four values.
3. Round 3, the case, H1 to J2: do it aloud against a 20-minute timer.
4. Rounds 2 and 3 story rows with answer slots: C2, C4, F1, G2, G4. Decide your honest answer to each slot before the day.
5. Round 1, A3 to A6: write your own pay, notice, location and reason-for-moving answers in one sentence each.

Everything else is insurance.

## Fit snapshot

Evidence cells hold your own words and nothing else. Requirement cells quote the job description you pasted.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap on the number: the quote already reaches the requirement in role-relevant terms, though it is a self-report with nothing inspected behind it, so expect a probe on what the work covered. Lead with the quote's own terms: six years in retail banking, the last three as a branch supervisor |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | Your material says a formal complaints log, and does not show what governed the complaints in it. Words: "I handled the branch's formal complaints log." Answer slot: the JD's line on regulated complaints makes a probe on what rules applied to the complaints in your log likely. If rules or deadlines applied, say which and how your log tracked them; if none did, or tracking them was not yours, say so plainly and stay with the log you handled |
| F3 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says one branch's log, not the process across branches, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what happened to a complaint after your part of it likely. If you followed any beyond your branch, say how far and how you knew; if your part ended with the log, or nothing was followed further, say so plainly and stay with the log |
| F4 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. No answer slot, and nothing added to make the gap feel smaller |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | Your material shows a monthly complaints spreadsheet, not what it counted. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD's volumes-and-resolution-times line makes a probe on what the sheet counted likely. If it counted volumes or how long complaints took to resolve, say how each was worked out; if it counted something else, or neither, say so plainly and stay with the sheet |
| F6 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | low | [inferred] | discovery | Derived from reading your word "spreadsheet" against the JD's "Excel": the quote does not name the tool. Say "spreadsheet" as you said it. Answer slot: if it was built in Excel, say so and what you used it for; if it was another tool, say which, plainly |
| F7 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Adjacent work: training new tellers, not coaching supervisors. Words: "I trained new tellers on our escalation script." Answer slot: the JD's supervisors line makes a probe on how coaching a supervisor differs from training a new teller likely. If you have coached supervisors, say how, in your own words; if not, say so plainly, stay with the tellers, and say how you would adapt as a plan |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | Words: "I've never presented to anyone above regional level." The JD does not say who its senior leaders are, so the pack cannot say whether regional level is below that bar. Your quote sets a ceiling and says nothing about what sits under it: anything you have presented below it is yours to name, and the pack has nothing to quote for it. Then how you would prepare for a senior audience, as a plan. No answer slot |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Nothing in your message speaks to this. Answer slot: expect a probe on any work with digital teams. If you have worked with one on anything members use, say what and what part was yours; if not, say so plainly and lead with how you would approach it (E1 gives the structure) |

No row is a gate: nothing in the JD is a term such as pay, location, a schedule or a credential, and length of experience is graded like any other requirement. Pay, notice and location come up in round 1 as logistics slots.

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Own the member complaints process end to end across branches and the contact centre | B1, D1, D2, H1 |
| Report monthly on complaint volumes and resolution times | D3, F1, F2, H2 |
| Coach branch supervisors on escalations | C1, C2, H3, I3 |
| Work with digital teams on self-service journeys | E1, E2 |
| 4+ years in financial-services customer operations | A1 |
| Experience handling regulated complaints | B3, C4 |
| Confident presenting to senior leaders | B2, D3 |
| Comfortable with Excel reporting | F1 |

All four published values are covered by G1 to G4.

## Grounding brief

From the 2026 strategy brief, as you summarised it. The pack holds your four points, not the brief's full text.

| Point | Source | Provenance |
|---|---|---|
| Move 40% of member service to digital channels by 2028 | 2026 strategy brief, published July 2026, per your message | [grounded] |
| Consolidate eight branches into five hubs over 2027 | same | [grounded] |
| Launch a small-business lending product in Q1 2027 | same | [grounded] |
| The main competitive pressure is app-only banks | same | [grounded] |
| Ashgrove is member-owned, with about 900 staff | the job description's first line, per your message | [grounded] |

---

# Round 1: recruiter screen (30 minutes)

## Persona weights

Relationship prior: a recruiter screen leans Conversational with a light Skeptic. Interviewer signals: none, no profile. Loop: the recruiter's email says 30 minutes with the recruiter and nothing else about format, so the prior stands.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly opener, then pay, notice, location, reason for moving | High: it is the recruiter-screen prior, and the four logistics questions are asked in this register | A pre-scripted 90-second arc for the biography question; treat casual questions as scored; never answer "I think you've covered everything" to the questions slot |
| Skeptic (light) | Knockout checks on the JD's gaps | Medium: F4 and F8 are limits you have already stated, and a screen is where a gap gets checked first | Say each limit plainly, then the plan; do not bluff a competency |

## Question bank, round 1 (proposed wording, pending your approval)

### A: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log" | A 90-second arc in the beats the quotes state, in your own words: six years in retail banking; the last three as a branch supervisor; handling the branch's formal complaints log. Stop at those beats. Then your own reason for this role, in your own words; the pack supplies none | F1 and F2 are the spine of this arc, and recruiters open here; EXP because it tests whether the story holds together |
| A2 | "What do you know about Ashgrove, and why us?" | CO | [grounded] | Published material is available to every candidate, so reciting the brief scores as homework. Bring one specific and tie it to the role: the 40% digital target connects to the JD's self-service line. Then one view of your own about what a member-owned credit union should protect while it digitises, drawn from the values page: "if a member needs it explained twice, we wrote it wrong." Your own reason for wanting this role: answer slot, in your own words, one or two sentences | The grounding brief gives the specifics; CO because it tests homework depth at a screen |
| A3 | "What salary are you looking for?" | JD | [generic] | Logistics slot: give your own number, or ask for the role's band first; the pack supplies no figure. If asked what you earn now: "I'd rather focus on the range for this role" | Pay is a standard recruiter-screen item; the only safe answer is your own |
| A4 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period, in your own words | Standard recruiter-screen item; the pack supplies no figure |
| A5 | "Where are you based, and does the role's reach across branches and the contact centre work for you?" | JD | [generic] | Logistics slot: say where you are based and what travel between sites you can do, in your own words; if you do not yet know what the role needs, say you would like the working pattern confirmed | The JD's across-branches-and-contact-centre line makes the working pattern a fair question |
| A6 | "What's prompting you to look at a move?" | EXP | [generic] | Logistics slot: give your own actual reason, in one or two sentences, about what you are moving toward; the pack supplies none | The reason for leaving is asked at every screen; EXP because consistency with the rest of your story is scored |

### B: Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role runs across the contact centre too, and you haven't worked in one. How do you see that?" | JD | [grounded] "Never worked in a contact centre" | Say the limit first: "I haven't worked in a contact centre." Then the nearest thing your material carries, at its own scope: "I handled the branch's formal complaints log." Stop there. Then how you would learn it, in the future tense and in your own words: what you would ask to see or sit in on first. Do not claim to know how a contact centre handles complaints | F4 is a stated gap and the JD names the contact centre; JD because it scores a listed requirement |
| B2 | "The JD asks for confidence presenting to senior leaders. How comfortable are you with that?" | JD | [grounded] "I've never presented to anyone above regional level" | Start with the limit as you put it: "I've never presented to anyone above regional level." Name what you have presented below that level only if you can say it in your own words; the pack has nothing to quote for it. Then your plan for a first senior audience, in the future tense: who is in the room, what they need to decide, and the one page they should leave with | F8 is a stated limit; JD because it scores a listed requirement |
| B3 | "Tell me about the formal complaints you handled in your branch." | EXP | [grounded] "I handled the branch's formal complaints log" | Story-mapped on F2: you handled the branch's formal complaints log. Tell that in your own words. Answer slot: the JD's line on regulated complaints makes a probe on what rules applied to the complaints in your log likely. If rules or deadlines applied, say which and how your log tracked them; if none did, or tracking them was not yours, say so plainly and stay with the log you handled | F2 is where the JD's regulated-complaints line presses hardest; EXP because it tests what was actually yours |

## Reverse questions, round 1

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "Is the 20-minute case in the panel shared in advance or given on the day?" | It decides how you prepare the case rows, and it is a normal process question |
| R1.2 | "Do you know yet who is on the panel, and could you share their names when you do?" | Names let the pack read their public professional footprint and reweight round 3 |
| R1.3 | "Which parts of the role will the Head of Member Services most want to talk through?" | It points your round 2 preparation at their priorities |
| R1.4 | "How does the contact centre connect to this role today?" | It turns the biggest stated gap into a conversation about structure |
| R1.5 | "Is there a part of the strategy brief you'd suggest I read most closely for this role?" | It signals you have read it and gives you the recruiter's emphasis |

---

# Round 2: Head of Member Services, your future manager (45 minutes, mostly behavioural)

## Persona weights

Relationship prior: a hiring manager leans Case/Strategist plus Skeptic. Interviewer signals: none, no profile. Loop: the recruiter describes this round as mostly behavioural, which moves Values/Behavioral to the top and Case down; the JD's reporting line and your spreadsheet put a light Prober on the list.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scenario probes on escalation, coaching, member-first decisions | High: the recruiter's "mostly behavioural" | Story from your quoted sentences where one carries a story; otherwise a selection scaffold ending in its honest branch; "we" for context, "I" for contribution |
| Skeptic | Probing the gaps: contact centre, scope, senior presenting | Medium-high: this person is hiring you to own the process end to end, and F3, F4 and F8 are where your material is thinnest | Rehearse the single most predictable objection (D2) until it is boring; bridges only from what you stated; a plan, not a bluff |
| Case / Strategist | Live problems on digital and the strategy | Low-medium: the recruiter said mostly behavioural, but the JD names digital teams | Clarify, then objective, segments, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Data-Driven Prober | Line-by-line on the spreadsheet | Low: the JD asks for Excel reporting and you built the sheet | Know what the sheet counted and how; say plainly where you do not know |

## Question bank, round 2 (proposed wording, pending your approval)

### C: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time a complaint had to be escalated, and what you did." | EXP | [grounded] "trained new tellers on our escalation script" | Your quote carries an escalation script you trained others on; it does not carry an incident, so this is a selection case. Pick a time with a named complaint, the point it needed to go further, who you took it to, and what happened for the member. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's escalation line (F7) makes this likely from a manager; EXP because it asks what you actually did |
| C2 | "Tell me about the training you gave new tellers on your escalation script." | EXP | [grounded] "trained new tellers on our escalation script" | Story-mapped on F7: the beats the quote states are new tellers, the escalation script, and you training them. Tell those in your own words. Answer slot: the JD's supervisors line makes a probe on how coaching a supervisor differs from training a new teller likely. If you have coached supervisors, say how; if not, say so plainly, stay with the tellers, and say how you would adapt as a plan | F7 is the nearest evidence for the coaching requirement; EXP because it tests what you did, JD in its second half |
| C3 | "When did you put a member ahead of an internal metric?" | VAL | [grounded] | A selection case: pick a time when what the member needed and what a figure or process wanted pulled apart. It needs a named situation, the decision you made, what it cost or whom you had to persuade, and where it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Members First, Always is a published value and this is a stem from the Values persona; VAL because it scores behaviour against that value |
| C4 | "Tell me about a complaint you saw through to the end." | VAL | [grounded] "I handled the branch's formal complaints log" | Story-mapped on F2 at its own scope: you handled the branch's formal complaints log. Answer slot: if you kept hold of a particular complaint until it was solved, name it and say what solved meant; if the log was where your part ended, or you did not follow any through, say so plainly and stay with the log | Own the Fix is a published value; F2 is the nearest evidence |

### D: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Choose one and say it plainly, then the plan. The contact centre sits inside the JD's end-to-end line, so it is the one this manager is likeliest to test: "I haven't worked in a contact centre." Say the second limit as you put it only if asked. The plan is in the future tense and in your own words | F4 and F8 are your two stated limits; JD because it scores the role's gaps |
| D2 | "You've handled one branch's complaints log, and this role owns the process across every branch and the contact centre. Why should we think you can?" | JD | [grounded] "I handled the branch's formal complaints log"; "Never worked in a contact centre" | **The highest-ROI prep in this pack.** Name the limit before it is asked: "I handled the branch's formal complaints log, and I haven't worked in a contact centre." Follow-up 1, how does it scale: hold by returning to what the quote carries, never by adding to it; answer slot: if any part of what you did reached beyond your branch, say what; if none did, say so plainly. Follow-up 2, what do you do in the first weeks: a plan in the future tense, your own words. Follow-up 3, so it is a stretch: concede specifically, "It is a step up in scope", and do not fold on the core: what you did is real and specific. Hold two follow-ups before conceding anything real | F3 and F4 together are the most predictable objection to you, and the manager owns the answer; JD because it scores the headline responsibility |
| D3 | "You'd present complaint results to our leadership each month. How would you approach the first one?" | JD | [grounded] "I've never presented to anyone above regional level"; "I built the monthly complaints spreadsheet our regional manager uses" | Limit first, as you put it. Then the approach as a plan: who is in the room, what they need to decide, one page. Where your sheet comes in, say only what the quote says: "I built the monthly complaints spreadsheet our regional manager uses"; F5's answer slot covers what it counted | F8 and F5 meet here; JD because it scores the reporting and presenting lines |

### E: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our strategy aims to move 40% of member service to digital by 2028. Where do complaints fit in that, and what should we protect?" | CASE | [grounded] | Say the structure aloud. Clarify: which complaint types are simple and which need a person, and what counts toward the 40%. Objective: a member's problem fixed, in plain words. Segments: simple and complex. Approach: self-service for the simple, one named human owner for the complex. Metrics: the JD's volumes and resolution times, by channel. Risks: a member who cannot find a way to a person. Challenge one premise respectfully, such as whether complaints count toward the 40%. Answer slot for F9: if you have worked with a digital team on anything members use, say what and what was yours; if not, say so plainly and lead with the structure | The 40% target is the first of the four strategy points and the JD names digital teams; CASE because it is a live problem, CO in its second half |
| E2 | "App-only banks are the main pressure on us. What can a member-owned credit union do about a complaint that an app can't?" | CO | [inferred] derived from the brief's competitive point and the values page | Bring one consensus item, then one thesis of your own. Consensus: personal contact. A thesis to consider: digital should make the simple complaints disappear so people have time for the hard ones, and a member with a hard one gets one named owner and plain words. The mandatory concession: an app will serve many members better and faster on simple issues. The anti-pick: do not argue against digital; the role works with digital teams. These are options for you to take only if you hold them | The brief is shared material, so differentiate from it rather than recite it; CO because it tests whether you can think at the company's altitude |

### F: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Walk me through the monthly complaints spreadsheet your regional manager uses." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F5: you built it, it is monthly, your regional manager uses it. Then the four slots a figure raises, each in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know how something was counted, say so plainly. JD slots: if it counted volumes or resolution times, say how each was worked out, and if it counted something else or neither, say so; if it was built in Excel say so, and if another tool say which | F5 and F6 are the evidence for the reporting lines and a prober reads them first; EXP because it tests attribution |
| F2 | "If you owned the whole complaints picture, what would you add to that spreadsheet?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Answer slot first: say what your sheet counts today, in your own words; if you cannot say, say so plainly. Then what you would add, as a plan: start from what a leader would need to decide, not from what is easy to count | The quote does not show what the sheet counted, so the honest answer starts there; JD because the role owns the reporting |

## Reverse questions, round 2

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "What does a good month look like for complaints here, and what makes a bad one?" | It surfaces what this manager measures and ties to the JD's monthly reporting |
| R2.2 | "Where does the handoff between the branches and the contact centre work well, and where does it work less well?" | It invites the manager to describe the end-to-end problem you would own |
| R2.3 | "How do you expect the move to 40% digital by 2028 to change what complaints look like?" | It shows you read the strategy and invites their view |
| R2.4 | "What would you want the person in this role to have changed by the end of the first year?" | It tells you the manager's real expectations |
| R2.5 | "How does the role work with the branch supervisors today, and who do they report to?" | It tests the coaching line and prepares you for the panel |

---

# Round 3: panel of two branch managers (60 minutes, including a 20-minute case; also the values round)

## Persona weights

Relationship prior: a panel blends the top two personas of each member's relationship; the names are unknown, so the blend is built from the round's description. Interviewer signals: none. Loop: the recruiter says the panel scores against the four values, which makes Values/Behavioral guaranteed here, and sets a 20-minute escalation case, which lifts Case; the panelists are branch managers and the role coaches branch supervisors, which supports a Peer Evaluator; the case is time-boxed, which adds Pressure.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | One probe per published value, scored | High: the recruiter says the panel is the values round | A story for each value where one of your quoted sentences carries one; otherwise a selection scaffold ending in its honest branch |
| Case / Strategist | The 20-minute escalation case | High: the recruiter named it | Clarify, objective, segments, approach, metrics, risks; think aloud; challenge one premise |
| Peer Evaluator | Seam between branches and your role, supervisors, hubs | Medium: both panelists run branches and the JD has you coaching branch supervisors | Reciprocity; propose seam principles rather than claiming to know the seam |
| Pressure | Time-boxing and a member threatening to leave | Low-medium: the case is time-boxed | Pause, restate the question, hold a position through two follow-ups before conceding anything real |

## Question bank, round 3 (proposed wording, pending your approval)

### G: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Members First, Always: tell me about a time you decided from the member's side of the counter." | VAL | [grounded] | A selection case: pick a time when what the member needed and what the process or a number wanted pulled apart. It needs a named situation, the decision you made, what it cost or whom you persuaded, and where it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The first published value, asked in its own words |
| G2 | "Plain Words: tell me about something you wrote or explained that had to be explained twice, and what you did about it." | VAL | [grounded] "trained new tellers on our escalation script" | Your quote carries the training and the script, not a rewording. Answer slot: if the script or its training was ever changed because trainees needed it explained twice, say what changed and who changed it; if not, say so plainly, then give the nearest thing your material does carry, or how you would test whether a script's wording works | The value says "if a member needs it explained twice, we wrote it wrong"; F7 is the nearest evidence |
| G3 | "Neighbours, Not Numbers: tell me about a time a number told one story and the people in your branch told another." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses"; "the last 3 as a branch supervisor" | Your material holds numbers and a branch: the sheet, and three years as a branch supervisor. Neither quote carries a moment where they disagreed. Answer slot: if a figure in your sheet ever hid something about a member or your branch, say what and what you did; if none did, say so plainly, then give the nearest thing your material does carry, or how you would hold both | The value sits against your reporting work, so expect it; F1 and F5 are the evidence |
| G4 | "Own the Fix: tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Story-mapped on F2 at its own scope: you handled the branch's formal complaints log. Answer slot: if you kept hold of a particular problem until it was solved, name it and what solved meant; if the log was where your part ended, or you did not see any through, say so plainly and stay with the log | The value is "whoever finds the problem keeps hold of it until it is solved"; F2 is the nearest evidence |

### H: Case / Strategist (the 20-minute case)

The scenario below is the pack's own hypothetical. Your real case will differ, so rehearse the structure, not the details.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "A member rang the contact centre last week and their branch the week before about the same unanswered complaint, and has now been told two different things. The branch supervisor says it was escalated; the contact centre has no record. What do you do in the first hour?" | CASE | [generic] | Say the structure aloud. Clarify: what the member has been told and by whom, what they want, what deadline applies to this complaint and where it stands, and what "escalated" covers. Objective: one clear answer and one named owner for the member. First hour: take hold of it yourself, find the record on both sides, tell the member plainly what is happening and when they will hear. The question needs no claim about your past, so the guidance makes none | The recruiter named an escalation case; CASE because it is a live problem, VAL in how it will be scored |
| H2 | "How would you know your fix had worked, and what would you tell us about it at month end?" | CASE | [generic] | Metrics: the JD's complaint volumes and resolution times, by channel and by branch, plus whether the member's problem stayed fixed. Say what a leader would need to decide. Any claim about what your own sheet counted stays with F5's answer slot | The JD's reporting line; CASE because the metric is part of the live problem |
| H3 | "Once the member is sorted, what would you change so this doesn't happen again?" | CASE | [generic] | Root cause first: what let it fall between the branch and the contact centre. Then one owner for the fix, a plain-words briefing for supervisors, and how you would check it later. Any claim that you have coached supervisors stays with F7's answer slot | The JD's coaching and end-to-end lines; CASE because it extends the live problem |

### I: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "Where's the seam between your job and ours, and what happens when we disagree about an escalation?" | JD | [grounded] "the last 3 as a branch supervisor" | Propose seam principles, not a seam you cannot know: the member has one owner, the branch keeps the relationship, whoever finds the problem keeps hold of it. Reciprocity: "For three years I was a branch supervisor", so you have stood on the branch side. Disagreement: show spine and tact together, and ask what a good escalation looks like to them before you tell them | The panelists run branches and the role sits across them; JD because it scores how the role works with branches |
| I2 | "The strategy takes eight branches to five hubs over 2027. What should complaints handling protect in a branch that becomes part of a hub?" | CO | [grounded] | Structure: what members could lose, such as a face they know; what must be kept, such as a named owner, a plain reply and local knowledge; what the change makes easier, conceded honestly. Tie it to "every branch is part of its town". The question needs no claim about your past, so the guidance makes none | The consolidation is the second strategy point and the panelists run branches, so expect it; CO because it tests strategy at their altitude |
| I3 | "One of my supervisors escalates everything and another never does. How would you coach them?" | CASE | [grounded] "trained new tellers on our escalation script" | Structure: find out why each does what they do, agree with them what a good escalation looks like, look at a few real cases together, give plain feedback, and check later against the data. Your quote carries training new tellers on a script; where you would say you have coached supervisors, F7's answer slot applies | The JD's coaching line; CASE because the question is a live problem about their staff |

### J: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "The member says they'll take their money to an app-only bank. What do you say to them?" | CASE | [generic] | Pause, restate it, and answer in plain words: what you will do, who owns it, when they will hear. Do not promise an outcome you cannot guarantee. Hold your position through two follow-ups before conceding anything real | The brief names app-only banks as the main pressure; CASE delivered in a Pressure register |
| J2 | "We've got five minutes left. What is the one thing you'd do on Monday?" | CASE | [generic] | One action, one owner, one date for hearing back. Say what you would leave until you know more, and why | A time-box test of whether you can prioritise under pressure |

## Values cheat sheet

Detected: the recruiter's email says the panel is the values round and scores against the four values. Names are the published ones, from the values page you pasted.

| Value | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decisions start from the member's side of the counter | No quoted sentence carries a story here (G1). Selection scaffold: a named situation where the member's need and a process or number pulled apart, the decision you made, what it cost, where it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Plain Words | If a member needs it explained twice, the wording was wrong | F7: "trained new tellers on our escalation script" at its own scope; whether anything was reworded is G2's answer slot. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would test a script's wording |
| Neighbours, Not Numbers | Every branch is part of its town | F5 and F1 hold your numbers and your branch, and neither carries a story where they disagreed (G3). If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would hold both |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F2: "I handled the branch's formal complaints log" at its own scope; whether you followed any problem to its end is G4's answer slot |

## Reverse questions, round 3

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "What could a new Member Experience Lead do in their first month that would genuinely help your branch?" | Reciprocity: it shows you think about what you bring them, not only what you need |
| R3.2 | "How do you expect the move to hubs to change the complaints your branch sees?" | It touches the second strategy point from their side of the counter |
| R3.3 | "What does a good escalation from a supervisor look like to you?" | It surfaces their standard for the JD's coaching line |
| R3.4 | "Which of the four values do you see tested most when a complaint comes in?" | It shows you read the values and lets them talk about their own branch |
| R3.5 | "How will complaints from the small-business lending product in Q1 2027 reach the process?" | It ties the role to the third strategy point |

---

## Prohibited claims

What this pack will not coach, and why. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation, not words for you: the material says one branch's log, not the process across branches. D2's slot stays inside the quote |
| Has handled regulated complaints | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: the material says a formal complaints log and does not show what governed it. B3's slot stays inside the log |
| Reported complaint volumes and resolution times | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation: the material says a monthly complaints spreadsheet, not what it counted. F1's slot asks only what the sheet counted |
| Built the reporting in Excel | Inflated form of F6 | F6's quote at its own scope. The limit is the pack's observation: the material says spreadsheet and does not name the tool |
| Coached branch supervisors on escalations | Inflated form of F7 | F7's quote at its own scope. The limit is the pack's observation: the material says training new tellers. C2's slot stays with the tellers |
| Worked in a contact centre | Negative you stated, F4 | The plain acknowledgment F4 gives: "I haven't worked in a contact centre." No slot |
| Presented above regional level | Negative you stated, F8 | The plain acknowledgment F8 gives: "I've never presented to anyone above regional level." No slot |

## Sources

- Provided documents: the job description; the values page text, copied by you on 26 November 2026 from ashgrovecu.org/about/values; the recruiter's email about the process; your summary of the 2026 strategy brief (published July 2026, so under six months old); your background statement. No dossier was present.
- No search or fetch was sent. The values URL is where your pasted text came from, not a link read.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | Could not have moved the values cheat sheet or the G bank: the pasted values page already gives all four principles by name |
| 2. Ashgrove interview process, member-services roles | skipped | Could not have moved the persona weights: the recruiter's email already names three rounds, who runs each and what each holds, including the values-style round |
| 3. Ashgrove strategy and recent news | skipped | Could not have moved the CO bank at the level the four brief points reach; the full brief would add more, and the upgrade menu offers it |
| 4. Interviewer name and Ashgrove | n/a | No interviewer name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative member experience lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full text of the strategy brief → the grounding brief and the CO and CASE rows (E1, E2, I2) move from your four points to the brief's own language
- A CV, or the complaints and reporting lines on it → rows F2, F3, F5, F6 and F7 may move from your message's one-line sentences to quoted CV lines; an anonymised extract of the complaints log, the monthly spreadsheet with figures removed, or the escalation script's training outline would be the inspectable artifacts that raise those rows' confidence
- Your honest answers to the answer slots in F2, F3, F5, F6, F7 and F9 → each row regenerates with your own words quoted into it
- Your own pay, notice, location and reason-for-moving statements → A3 to A6 take your words instead of instructions
- The names of the two panelists → an interviewer read, panel persona weights read from their public professional footprint, and a reverse question tied to their own paths
- The recruiter's word on whether the case scenario comes in advance → a build section for the case if it does
- A `tuesday-dossier.md` from an earlier underwriting pass, if you have one → an evidence-graded fit snapshot and a named objection in place of the pack's own inference
