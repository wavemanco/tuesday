# Interview prep pack: Operations Manager, Atlas Freight

- Role: Operations Manager, Atlas Freight (regional logistics, 800 employees), from the JD you pasted
- Interviewer and relationship: not known
- Round type: not known. Built as a full-loop session pack with flat persona weights, which is noticeably weaker than a pack built for a known round; the one question that would sharpen it is in the message that came with this file
- Mode: session

## How to use this pack

Personas describe how a question arrives. Types describe what it scores.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether the CV's claims survive scrutiny and attribution |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | Structure and reasoning on a live problem |

Guidance is scaffolding, not a script. Every claim about your past rests on a sentence you wrote, quoted in the Provenance cell. An answer slot is an instruction for the interview, not a question for you here: it gives two honest branches, and either one is a good answer. Start with B2. It is the highest-ROI prep in the pack.

## Fit snapshot

No requirement in the JD is a gate (a term you either meet or do not). The 5+ years line is experience, graded in F4.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "currently a senior shift manager over 3 supervisors" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your words stay at their scope: "I'm currently a senior shift manager over 3 supervisors" and "I ran the site's peak-season surge plan two years running." The pack's observation: your material shows one site's plan and does not show a second site. It also says warehouse and distribution where the JD says terminal, and the pack does not know how far apart those are. Answer slot: the JD's 4-sites line makes a probe on multi-site scope likely. If any of your work reached more than one site, say which and what you did, in your own words. If you have worked in a freight terminal, say where. If neither is true, say so plainly and stay with the site's surge plan |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | The quote is a mis-pick rate and a pick path, not on-time performance or cost-per-shipment, and the words stay there: "I cut the mis-pick rate 40% by redesigning the pick path." Read literally, the JD sentence has on-time performance going down, so confirm direction and definitions with the interviewer (reverse question 1). Answer slot: if you tracked either measure, or the redesign touched either, say what you tracked and how you know, in your own words. If you did not track them, or the redesign did not touch them, say so plainly and stay with the mis-pick rate |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | The quote says 3 and the JD says 12, and the number stays 3: "I'm currently a senior shift manager over 3 supervisors." The pack's observation: your material does not show a team of more than 3. Answer slot: if you led a larger team at any earlier point, say when and how many. If you did not, say so plainly and stay with the 3 |
| F4 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | The quote counts years in ops, not years leading people, and the words stay there: "I have 7 years in warehouse and distribution ops." Answer slot: the JD's minimum makes a probe on how many of those years were leadership likely. Say from when you led people, in your own words. If the leadership years are fewer than the JD names, say so plainly and give the leadership years you have |
| F5 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap, but a credential with nothing inspected behind it, so expect a probe. Lead with it in the quote's own terms: "I'm green belt certified." The quote does not say which methodology or which body issued it. Your certificate does, and the pack states neither |
| F6 | "build reporting in Excel/Power BI" — JD | "solid Excel" — your message | low | [inferred] | discovery | A skill statement is not reporting built, and the bridge should not be stretched: "I'm solid in Excel." Answer slot: if you have built reporting in Excel, say what it showed and who used it. If your Excel work was something else, say what it was. If you have not built reporting, say so plainly and say what you would build first |
| F7 | "build reporting in Excel/Power BI" — JD | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't used Power BI." Then how you would learn it, said as a plan and never as a past. Never a claim to Power BI work. The JD joins the two tools with a slash and the pack cannot tell from that line whether one suffices; reverse question 3 asks |

## Persona table

Weights are flat. No relationship prior applies because the round type is unknown, no interviewer signal exists, and no loop source was read, so the loop falls back to the Generic archetype (screen, hiring manager, panel) with flat weights. Banks are ordered by where your material is thinnest, not by likelihood. Each persona gets 3 questions.

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy for you |
|---|---|---|---|
| A. Conversational / Rapport Builder | Friendly, unstructured; casual questions that are still scored | Equal. Recruiter screens lean this way and your round is unknown | Run the arc in A1 from your own sentences. Treat casual questions on Lean and the company as scored |
| B. Skeptic | Quiet, persistent probing of the gaps | Equal, but F1, F3, F4 and F7 are where it would press | Rehearse B2 until it is boring, holding only "I'm currently a senior shift manager over 3 supervisors" and the surge-plan sentence |
| C. Case / Strategist | Live problems from the role: diagnose, plan, build | Equal. The JD's measures and its reporting line invite live problems | Clarify, objective, segmentation, approach, metrics, risks, out loud. Challenge one premise per case |
| D. Data-Driven Prober | Reads the numbers line by line | Equal, and your one headline figure is a magnet for it | Know what you can and cannot say about how the 40% was counted, and say plainly where you do not know |
| E. Pressure / Stress | Interrupts, time-boxes, tests composure | Equal. Scale (F1, F3) is the natural pressure point | Pause, restate, hold on your quoted sentences through two follow-ups, concede one specific thing |
| F. Values / Behavioral | Scenario probes, story-shaped answers | Equal. No published company values were retrieved, so none are mapped | Choose a story where one of your sentences carries it, and use the honest branch where none does |
| G. Peer Evaluator | Seams between sites, credit, disagreement | Equal. A multi-site role has peers at the other sites | Reciprocity: say what you would bring the other site. Propose seam principles, not a seam you do not know |

## Question banks

### A. Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops" "currently a senior shift manager over 3 supervisors" "cut mis-pick rate 40% by redesigning the pick path" "ran the site's peak-season surge plan two years running" | Story-mapped on F4, F3, F2 and F1, in that order, each beat a clause a quote states: 7 years in warehouse and distribution ops; currently a senior shift manager over 3 supervisors; cut mis-pick rate 40% by redesigning the pick path; ran the site's peak-season surge plan two years running. Tell each in your own words, about 90 seconds in all. Close with one sentence on why this role. That reason is yours; the pack does not know it and writes none | A friendly opener that is still scored, and the answer every later question builds on. EXP because it tests the CV's claims in sequence |
| A2 | "Lean and Six Sigma are listed as a plus. What does your green belt cover?" | JD | [grounded] "green belt certified" "cut mis-pick rate 40% by redesigning the pick path" | Say it in the quote's terms: you are green belt certified. Then say, from your certificate, which methodology it is and who issued it. Answer slot: if any of your work used what the belt covers, say which work and what you did, and say so if the pick-path redesign was one. If none did, or you hold the certificate only, say so plainly and say where you would start | F5 is the one row that reaches a JD plus, and the likely probe is whether the certificate has been used. JD because it scores a listed qualification |
| A3 | "What do you know about Atlas Freight so far?" | CO | [generic] | Research on the company did not run for this pack, so it states no fact about Atlas Freight beyond the JD's own descriptor, "regional logistics, 800 employees". Before the interview, read its website and careers page yourself. Say what you found and why it matters to you, in your own words. If you found little, say so plainly and ask what the interviewer would want you to know | A homework check asked casually. CO because it tests company knowledge. The generic label is the honest one until research runs, and the upgrade menu says how to change that |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never used Power BI" "currently a senior shift manager over 3 supervisors" | Choose from your own material and say it first. The one wording with a source is "I haven't used Power BI", followed by a plan for your first weeks, said as a plan and never as a past. If you choose scale instead, the words are "I'm currently a senior shift manager over 3 supervisors", set against the JD's 12. Pick the one you can answer best, in your own words | F7 and F3 are where the material is thinnest against the JD, so this is the persona's opening probe. JD because it scores the posting's own list |
| B2 | "This role leads 12 supervisors and covers 4 sites, and you currently have 3 supervisors. How would you handle the difference in scale?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" "ran the site's peak-season surge plan two years running" | The highest-ROI rehearsal in this pack. Name the limit before it is asked for: your material shows 3 supervisors and one site's surge plan. Hold on exactly this: "I'm currently a senior shift manager over 3 supervisors, and I ran the site's peak-season surge plan two years running." Follow-up one, 12 against 3. Answer slot: if you led a larger team at any point, say when and how many. If not, say so plainly and stay with the 3. Follow-up two, four sites. Answer slot: if any of your work reached past one site, say what. If not, say so plainly. Then concede one specific thing, that this role is a step up in scale, and give your first-weeks plan as a plan. Hold through both follow-ups by returning to the quotes, never by adding to them | F1 and F3 are the widest distance between the JD and the material, so this objection arrives in some form. JD because it scores the lead-12 and four-sites lines |
| B3 | "You have 7 years in warehouse and distribution ops, and the JD asks for 5+ years of operations leadership. How much of that was leading people?" | JD | [grounded] "7 years in warehouse and distribution ops" "currently a senior shift manager over 3 supervisors" | Start with the quote at its own scope: 7 years in warehouse and distribution ops. Answer slot: say from when you led people, in your own words. If leadership started later, or covers fewer years than the JD names, say so plainly and give the leadership years you have, ending on "currently a senior shift manager over 3 supervisors". Do not round the leadership years up to the full 7 | F4 is a requirement whose evidence counts ops years, not leadership years. JD because it scores the stated minimum |

### C. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "On-time performance at one terminal drops sharply week over week. What do you need to know first, and how would you diagnose it?" | CASE | [generic] | A live problem, with no claim about your past. Say the framework aloud first. Clarify: what counts as on-time, over what period, for which shipments. Then the objective, then segment the drop, by day, shift, lane or customer, whichever the data supports. Then approach, metrics and risks. Challenge one premise respectfully, such as whether the measure itself changed | A live problem from the JD's on-time line, which F2 does not reach, so a case shows structure where the CV cannot. CASE because it scores reasoning; generic because it is a pattern, not a fact about Atlas Freight |
| C2 | "Volume is forecast to surge across all four sites next quarter. Sketch the plan: what do you need to know first?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Same structure: clarify, objective, segmentation, approach, metrics, risks. One anchor sentence is available, in the quote's words: "I ran the site's peak-season surge plan two years running." Then do the case. Where your plan covered something you can name, name it from your own memory, and where it did not, do not borrow. Say what changes with four sites as the first thing you would ask | The one case where the material carries an anchor, supplied by F1. CASE because it scores structure; the guidance adds no detail to the earlier plan |
| C3 | "You need one weekly report on how the four sites are performing. What is on it, and how would you build it?" | CASE | [grounded] "solid Excel" "never used Power BI" | Structure: who reads it and what decision it drives, then the JD's two measures first, on-time performance and cost-per-shipment, then the few others you would add and why, then data source and cadence. For the tool, say what is true of you: "I'm solid in Excel." If Power BI comes up, "I haven't used Power BI", then your plan, said as a plan. Do not describe past dashboards | JD content with CASE delivery: the reporting line has the least behind it (F6, F7), and a live build shows method where a CV cannot. Tagged CASE because the delivery is a live problem |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Four slots, each in your own words and none filled by the pack. How it was counted: if you know, say so, and if you do not, say plainly that you do not. What it is sensitive to: say, or say you do not know. The assumption behind it you would defend least: name it before they do. Which part was yours: if the redesign was a team's, or someone else did part of it, say so plainly and return to the pick-path redesign in the quote's words | F2's figure is the only headline number in the material and the prober's natural target. EXP because it tests counting and attribution |
| D2 | "The JD asks you to drive on-time performance and cost-per-shipment down. Did the pick-path redesign move either?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: if you tracked either measure and the redesign moved it, say which, by how much and how you know, in your own words. If you did not track them, or the redesign did not move them, say so plainly and return to the mis-pick rate. Do not link the redesign to either measure beyond what you tracked | F2 is adjacent to the JD's two measures, not on them, so this probe is likely. JD because it scores the posting's headline measures |
| D3 | "What have you used Excel for?" | JD | [grounded] "solid Excel" "never used Power BI" | Answer slot: if you have built reporting in Excel, say what it showed, who read it and how often, in your own words. If your Excel work was something else, say what it was. If you have not built reporting, say so plainly and say what you would build first. On Power BI the words are "I haven't used Power BI", then your plan for learning it, said as a plan and never as a past | F6 and F7 are the JD's reporting line, one half thin and one half absent. JD because it scores a named tool requirement |

### E. Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who already manages several sites?" | JD | [grounded] "7 years in warehouse and distribution ops" "cut mis-pick rate 40% by redesigning the pick path" "ran the site's peak-season surge plan two years running" "green belt certified" | Pause, restate the question, then answer from the quotes only. Pick two of your four sentences and say them as they are, for example "7 years in warehouse and distribution ops" and the surge plan you ran two years running. Hold through two follow-ups by returning to those sentences. Concede one specific thing, that your current role is over 3 supervisors, and claim no multi-site record you have not stated | Tests composure on the F1 and F3 gaps together. JD because the answer is judged against the posting's scale. Pressure changes the delivery, not the content |
| E2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Pause. The quote does not say who did what, so the answer is yours alone. Answer slot: say which part was yours, in your own words. If part was a team's or someone else's, say so plainly, and if none of it was yours, say that. Hold through two follow-ups by repeating what you did, and concede only what you do not know about how it was counted | The standing pressure probe on a CV number, carried by F2. EXP because it scores attribution honesty |
| E3 | "You're a senior shift manager. Why should I trust you with a whole terminal network?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" "ran the site's peak-season surge plan two years running" | Restate it calmly, then hold on the two sentences: "currently a senior shift manager over 3 supervisors" and "ran the site's peak-season surge plan two years running". The second reaches past your own shift to the site. Answer slot: if any other work of yours reached past one shift or site, say what. If none did, say so plainly and stay with the site's plan. Concede that scale is the open point and offer your first-weeks plan as a plan | F1 and F3 again, in a time-boxed register. JD because the question presses the four-sites line |

### F. Values / Behavioral

No published company values were retrieved, so no story is mapped to a named value. These are generic behavioral probes.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | No sentence of yours carries this story, so this is a selection scaffold. Pick a time with a named stake, what you said, how it landed, and a relationship that held. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry or how you would handle it. Use I for your part and we for the team's | A behavioral probe from the persona's standard stems. VAL because it scores past behavior. Generic because no quote carries it |
| F2 | "Tell me about a time you led your supervisors through a hard stretch." | VAL | [grounded] "ran the site's peak-season surge plan two years running" "currently a senior shift manager over 3 supervisors" | Story-mapped on F1 and F3 with only the beats the quotes state: peak season, the site's surge plan you ran, two years running, and the supervisors you currently lead. Answer slot: the JD's lead-supervisors line makes a probe on how they responded likely. If their response is part of the story, say what happened and what you did. If the story is about the plan and not the supervisors, say so and tell that. If a different stretch fits better, use a selection scaffold: a named stake, what you did, how it ended | The JD's lead-supervisors line raises this theme, and F1 and F3 supply the only quoted beats. VAL because it scores how you lead under load |
| F3 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | A selection scaffold. Pick a decision with a named customer need, the metric it cost you, and what you said to your own side. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry or how you would handle it | A standard behavioral stem, with no quote that carries it. VAL because it scores behavior against a trade-off |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "I run another site. Where is the seam between us, and what happens when we disagree?" | CASE | [generic] | A live problem, with no claim about your past. Propose seam principles instead of pretending to know the seam: who decides what, how shared resources get settled, when and how you escalate. Reciprocity: say what you would bring their site, not only what you need. Do not state how Atlas Freight's sites divide work; the pack does not know | A multi-site role has peers at the other sites. CASE because it is a live problem; generic because it is a pattern |
| G2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | State the principle in your own words: we for context, I for your contribution. If you use the pick-path redesign as the example, answer slot: say who else took part, if anyone did, and what part was yours. If you did it alone, say so plainly. Never present a team's result as yours | A collegial form of the attribution probe in E2, with F2 as the only quoted example. VAL because it scores behavior toward peers |
| G3 | "Tell me about a time you disagreed with a manager on another team and how it ended." | VAL | [generic] | A selection scaffold. Pick a disagreement with a named stake, your position, what the other person's was, and how the relationship held. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry or how you would handle it | The persona's standard disagreement probe. VAL because it scores spine and tact together. Generic because no quote carries it |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "Own daily terminal operations across 4 sites" | B2, E3 (JD); C2 (CASE) |
| "drive on-time performance and cost-per-shipment down" | D2 (JD); C1 (CASE) |
| "lead a team of 12 supervisors" | B2 (JD); F2 (VAL) |
| "build reporting in Excel/Power BI" | D3, B1 (JD); C3 (CASE) |
| "5+ years operations leadership required" | B3 (JD); A1 (EXP) |
| "Lean/Six Sigma a plus" | A2 (JD) |

Company and strategy: one CO question (A3), generic. The strategy-grounded CO or CASE question this pack would otherwise carry needs research, which did not run.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "How is on-time performance defined here, and which direction does the target move?" | The JD's sentence reads ambiguously on direction, and the answer is the definition you will be judged against |
| 2 | "How are the 12 supervisors spread across the 4 sites, and who leads each terminal day to day?" | It turns the JD's totals into the real span of control behind B2 |
| 3 | "What does terminal reporting run on today, Excel, Power BI or something else, and who builds it?" | It sizes the Power BI gap in practice and shows you ask about the work, not around it |
| 4 | "What would a good first 90 days look like, and what would make it a miss?" | It ties your first-weeks plan from B1 and B2 to what they would measure |
| 5 | "How does the network handle a volume surge across sites today?" | It invites a short, true mention of the surge plan in your own quoted words, and shows operator interest |
| 6 | "Is continuous improvement work part of this role or the sites' routine?" | It tells you whether the green belt in F5 is a live asset here |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned terminal operations across several sites | Inflated form of F1 | F1's quotes at their scope. The limit is the pack's observation: your material shows a senior shift manager over 3 supervisors and one site's surge plan, not several sites. B2's slot stays inside that |
| Led a team of 12 supervisors, or any team larger than 3 | Inflated form of F3 | F3's quote: "currently a senior shift manager over 3 supervisors". The limit is the pack's observation, and B2's slot asks only whether a larger team existed |
| Reduced on-time failures or cost per shipment | Inflated form of F2 | F2's quote at its scope: the mis-pick rate. D2's slot asks only whether either measure was tracked |
| Has 5+ years of operations leadership | Inflated form of F4 | F4's quote: "7 years in warehouse and distribution ops". B3's slot asks only for the years you led people |
| Built operational reporting in Excel | Inflated form of F6 | F6's quote at its scope: "solid Excel". D3's slot asks only what you used it for |
| Has used Power BI | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I haven't used Power BI." No slot |
| Led Lean or Six Sigma improvement projects | Inflated form of F5 | F5's quote at its scope: "green belt certified". A2's slot asks only whether any of your work used the belt's method |
| Designed the peak-season surge plan | Inflated form of F1 | The quote's own verb: "ran the site's peak-season surge plan two years running" |

## Sources

Provided documents: your message, containing the JD text as you pasted it and your background. No dossier was present, and no page was read.

Searches sent, all refused, so nothing came back and nothing in this pack states a fact about Atlas Freight beyond the JD's own descriptor:

- "Atlas Freight regional logistics company values" — refused
- "Atlas Freight interview process operations manager" — refused
- "Atlas Freight regional logistics news strategy 2026" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Every call was refused. It would have moved the values cheat sheet and the VAL mapping, so the F bank is generic |
| 2. `Atlas Freight interview process operations manager` | unavailable | Every call was refused. It would have moved the loop structure and persona weights, so weights are flat on the Generic archetype |
| 3. `Atlas Freight strategy` / recent news | unavailable | Every call was refused. It would have moved the CO bank, so A3 is generic and no strategy-grounded case was written |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. representative `Operations Manager` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Who the next round is with, and its type (recruiter, future manager, a peer or site leader, panel) → persona weights reweighted and the top two banks deepened; a recruiter screen also adds pay, notice, location and reason-for-leaving rows
- The interviewer's name → an interviewer read and a reverse question tied to their own path, which is the one that turns an interrogation into a peer conversation
- Anything the recruiter said about focus areas or a take-home or presentation → a build section for each declared deliverable
- Your answers to the answer slots in B2, B3, D2 and D3, given outside a drill → F1, F2, F3 and F4 and F6 regenerated with your own words quoted, and the bridge cells made firmer
- Your green belt certificate (methodology and issuing body) and the site's before-and-after mis-pick report → F5 and F2 from medium toward high, and the D1 and E2 answers anchored in how the 40% was counted
- A link to Atlas Freight's own about or careers page → read as a provided document, which makes the A3 answer and the reverse questions company-specific
- Permission to run web search → values, loop structure and recent news, which turn the generic F bank and A3 into grounded rows. A deeper pass, up to 6 more searches and 2 more fetches and several more minutes, would add a strategy brief and a strategy-grounded CASE question; it needs search permission first
- Your prep time → a prioritized prep schedule sized to it
- A `tuesday-dossier.md` from a job-underwriter run → verified evidence, per-gap strategy and the objection worth the deepest rehearsal, instead of the ones inferred here
