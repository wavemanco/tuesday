# Interview prep pack: Operations Manager, Atlas Freight

Interviewer: not known. Relationship: not known, so this pack is built for a hiring-manager round. If that is wrong, the persona weights below are the first thing to change.

## How to use this pack

Personas describe how a question is asked. Types describe what it is scored on. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

| Tag | Name | What it is really testing |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the company's published values. No published values were available, so no question here carries this tag |
| EXP | Work-experience deep-dive | Whether your claims survive scrutiny and what was actually yours |
| JD | Role / JD-driven | The posting's stated responsibilities and qualifications, gaps included |
| CO | Company and strategy knowledge | Homework depth |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the actual role |

Highest-ROI prep: question A1, the step from three supervisors to twelve across four sites. It will be asked in some form.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Adjacent work, kept at its own scope: "I have 7 years in warehouse and distribution ops" and "I ran the site's peak-season surge plan two years running." Your material says warehouse and distribution work and one site's plan, not terminal operations and not four sites. Answer slot: the JD's "4 sites" makes a probe on multi-site scope likely. If you covered more than the one site, say which and how, in your own words; if you did not, say so plainly and stay with the site you ran the plan for |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Mis-pick rate is the measure your sentence names; on-time performance and cost-per-shipment are the JD's. Words: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if on-time performance or cost-per-shipment was tracked in your work, say what was tracked and how it was measured, in your own words; if neither was, say so plainly and stay with the mis-pick result. The 40% itself raises four slots, handled in C1, C2 and G1: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Leading supervisors is in your sentence; the count is yours at 3 against the JD's 12, and the number stays as it is. Words: "I'm a senior shift manager over 3 supervisors." Answer slot: if you have led more than 3 supervisors in any role, say which and when; if not, say so plainly. What you would do with a larger team is a plan, said as a plan and never as a past |
| F4 | "build reporting in Excel/Power BI" — JD, the Excel half | "solid Excel" — your message | low | [inferred] | discovery | "Solid Excel" is a skill level, and your material does not show whether you have built reporting in it. Answer slot: if you built reports in Excel, say what they showed and who used them, in your own words; if you did not, say so plainly and say how you use Excel |
| F5 | "build reporting in Excel/Power BI" — JD, the Power BI half | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used Power BI." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | low | [inferred] | discovery | Your 7 years are in operations, and your sentence names leadership only for the current role, so your material does not show how many years you have led people. The 7 years are not restated as years of leadership. Answer slot: the JD's "required" makes a probe on years leading likely. Give the real figure from your own dates; if it is under 5, say the real figure plainly and stay with the 7 years in operations |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | Your sentence reaches the requirement in its own terms: "I'm green belt certified." Expect a probe on where you applied it, rehearsed in C3. The certificate itself would move this from medium to high |

The JD states no eligibility terms (authorization, licence, location, schedule, pay, travel), so there is no gate row. "5+ years" is an experience requirement, not a gate, and is graded in F6.

## Persona table

Loop basis: no source establishing Atlas Freight's interview loop was available, so weights rest on your hiring-manager relationship prior plus the generic archetype of screen, then hiring manager, then panel. That is a pattern, not Atlas's documented process. No values-style round is detected.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy, as rehearsal method |
|---|---|---|---|
| A. Skeptic | Probes the jump from 3 supervisors to 12 and from warehouse work to terminal operations; the Power BI gap | High. The hiring-manager prior puts it first, and F1, F3, F5 and F6 give it material | Rehearse A1 until it is boring; bridge only from quotes; give a plan for the rest |
| B. Case / Strategist | Live problems drawn from the JD: on-time performance, cost-per-shipment, reporting, four sites | High. The hiring-manager prior puts it first, and the JD is metric-led | Clarify, then structure, then answer; think aloud; challenge one premise per case |
| C. Data-Driven Prober | Your one headline number, reporting tools, the green belt | Mid. The JD's reporting and metrics asks and the 40% claim raise it above the prior | Know how the 40% was counted or say plainly you do not |
| D. Values / Behavioral | Leadership-of-supervisors stories | Low. No values-style round is detected, but supervising 12 people invites behavioral probes | Pick stories that hold a hard moment; say so plainly where none comes to mind |
| E. Conversational | Biography opener, company knowledge | Low. A casual register is possible even in a manager round | Prepare a 90-second arc from your own sentences |
| F. Peer Evaluator | Seams between sites | Low. The JD has a four-site structure, but no peer round is known | Propose seam principles; do not pretend to know their seam |
| G. Pressure | Attribution on the 40%; "why you" in sixty seconds | Low. Nothing in the material says this is a stress interview | Pause, hold what your sentence carries, concede specifically |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You lead three supervisors today, and this role has twelve across four sites. How would you step up to that?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI rehearsal in this pack. Open with the quote at its own scope: "I'm a senior shift manager over 3 supervisors." Name the difference yourself before they do: the JD's twelve and four sites are bigger than your three. Answer slot: if you have led more than 3 supervisors, or worked across more than one site, in any role, say which in your own words; if not, say so plainly and stay with the 3. Then give a plan for the first weeks, said as a plan: what you would learn about each site and each supervisor first, and how you would check you were right. Hold through two follow-ups by returning to the team you lead now; concede the difference in span specifically, and do not fold on what you do lead today | F3 is the gap this interview presses, and F1 compounds it with the four sites. JD because it scores the stated requirement, delivered in a Skeptic register |
| A2 | "Tell me where your warehouse and distribution work overlaps with terminal operations, and where it doesn't." | JD | [grounded] "7 years in warehouse and distribution ops" | Start from the quote: "I have 7 years in warehouse and distribution ops." Answer slot: the JD says "terminal operations", so expect a probe on the difference. If you have worked in or around a freight terminal, say how, in your own words; if you have not, say so plainly, then say what from your own work you expect to carry over and what you would need to learn first | F1 is where the kind of work differs from the JD's wording. JD because it scores the posting's first line |
| A3 | "The role is judged on on-time performance and cost-per-shipment. What have you measured?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Lead with the one measure your sentence names: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if on-time performance or cost-per-shipment was tracked in your work, or moved with the pick path, say what was tracked and how, in your own words; if neither was, say so plainly and stay with the mis-pick result. Never describe a measure you did not track | F2 is the JD's headline ask. The question's premise is the JD's, and the guidance does not adopt it |
| A4 | "Reporting in Excel and Power BI is part of this job. Where are you with each?" | JD | [grounded] "solid Excel"; "never used Power BI" | Power BI first, plainly: "I've never used Power BI." Then how you would get working in it, said as a plan: what you would learn first and how you would show progress. Excel: "My Excel is solid." Answer slot: if you have built reports in Excel, say what they showed and who used them, in your own words; if you have not, say so plainly and say how you use it | F5 is a stated gap and F4 is thin evidence, so rehearsing both means neither lands as a surprise. JD because it scores a named tool requirement |
| A5 | "Why are you looking, why this role, and why now?" | EXP | [generic] | Logistics slot: give your actual reason in your own words. The pack supplies none, because you have not stated one. Keep it short, and make it consistent with everything else you say about the role | The Skeptic's motivation probe. EXP because it tests whether your own story holds together |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one of our terminals has dropped compared with last quarter. You have a week. What do you ask first, and what do you look at?" | CASE | [generic] | Clarify first: how on-time is defined and measured, what changed and when, and which lanes, shifts or customers are affected. Then segment (lane, shift, door, customer, cause), form two or three hypotheses, name the data each needs and who holds it, and say what you would act on in week one versus confirm first. Challenge one premise, such as whether the measure itself changed. The question needs no claim about your past, so the guidance makes none | The JD's on-time ask (F2's requirement) as a live problem. CASE because it is delivered live |
| B2 | "Cost-per-shipment is rising at one site while volume holds. How do you find out why?" | CASE | [generic] | Break cost into parts (labor, overtime, transport, handling, claims), check the definition and the denominator, compare against the other sites, then pick a lever per part and say which are quick and which are structural. Close with what you would report weekly to know it is working. No claim about your past | The JD's cost-per-shipment ask (F2's requirement) as a live problem |
| B3 | "Two of your four sites hit peak volume on the same days and draw on the same flex labor. How do you decide who gets what?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Structure it: each site's volume and service commitments, what the flex pool can and cannot do, trade-off rules agreed ahead of time rather than decided on the day, who decides when the rules clash, and how you check it afterwards. If you draw on your own work, say only what your sentence says: "I ran the site's peak-season surge plan two years running", and what happened inside it is in your own words | F1's surge-plan sentence is the nearest evidence to four-site coordination. CASE because it is a live problem |
| B4 | "You inherit four sites that each report daily performance differently. What do you build first?" | CASE | [generic] | Start from the decisions the reports must support, then agree a few measures every site reports the same way and fix their definitions before any tool. A simple version first, checked with the supervisors who own the numbers. Power BI is the step you would learn or get help with, said as a plan. No claim about your past | The JD's reporting line (F4 and F5's requirement) as a live problem |
| B5 | "Day one: four sites, twelve supervisors, and you have met none of them. Walk me through your first ninety days." | CASE | [generic] | Clarify what is expected at 30, 60 and 90 days. Then listen first: site visits, one-to-ones with each supervisor, the numbers each site already trusts. Pick one or two early fixes on the JD's measures, set a reporting rhythm, then take on structural changes. Every step is a plan, said as a plan | F3 and F1 as a live problem. JD content, CASE delivery |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You cut mis-pick rate 40%. Walk me through how that was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say the sentence first: "I cut mis-pick rate 40% by redesigning the pick path." Then the four slots, each in your own words: what was counted and over what period; what the figure is sensitive to; the assumption behind it you would defend least; which part was yours. Answer slot: if you know how it was counted, say so; if you do not, say so plainly rather than reconstructing it | F2's only number, so a Prober goes here first |
| C2 | "What did you change about the pick path, and what did you leave alone?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | "Redesigning the pick path" is the whole of what your sentence says, so the changes are yours to describe in your own words; the pack does not supply them. Answer slot: if any part of the redesign was shared with others, say which part and with whom; if none was, say it was yours | F2's attribution. EXP because it tests what was actually yours |
| C3 | "Where have you applied your green belt?" | JD | [grounded] "green belt certified" | "I'm green belt certified." Answer slot: the JD's "Lean/Six Sigma a plus" makes a probe on application likely. If you have applied it to a project, name the project and say what the method did for it, in your own words, including whether the pick-path redesign was one; if you have not applied it, say so plainly and say what you would use first | F7. The plus scores only when an example stands behind it |

### D. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you had to deliver an unpopular truth to leadership." | EXP | [generic] | Selection scaffold: pick a time with a named stake, a moment when the message was unwelcome, and a relationship still intact afterwards. Say what you said, what you asked for and what followed, using "we" for context and "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | A standard behavioral probe. EXP because it tests what you actually did; generic because no quoted sentence carries a story for it |
| D2 | "Tell me about a time you had to hold a supervisor accountable for a miss." | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Selection scaffold: pick a time with a named miss, a conversation you actually had, and an outcome you can state. Your sentence says you lead supervisors today, and the pack supplies no incident beyond that. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | The JD's supervisor-leadership line (F3's requirement), asked as an open prompt |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | A 90-second arc with two fixed ends from your own sentences: the start is "I have 7 years in warehouse and distribution ops", the end is "I'm a senior shift manager over 3 supervisors." The steps between are yours to name, in your own words, because the pack does not know them. Close on why this role, in your own reason | F6 and F3's evidence, rehearsed as the biography question. EXP because it tests your own account |
| E2 | "What do you know about Atlas Freight?" | CO | [generic] | This pack could not research Atlas, because search was refused. Before the interview, read Atlas Freight's own website and careers pages and note what they say they do and where, and say only what you read, naming the source. If you find nothing, say so plainly and ask them what matters most | A casual question that is still scored. CO because it tests homework; generic because no research ran |

### F. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Say you and a peer at another site both need the same resources in the same week. Where is the seam, and what happens when you disagree?" | CASE | [generic] | Propose seam principles rather than pretending to know theirs: who decides, by what agreed rule, what gets escalated. Frame it as reciprocity: what you would offer the other site as well as what you would need. State disagreement as facts and the rule, with the relationship intact. No claim about your past | The JD's four-site structure (F1's requirement) |
| F2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Selection scaffold: pick a time when work crossed teams, where you can say what you did and what others did. Use "we" for context and "I" for what was yours. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | A standard peer probe on credit-sharing. No quoted sentence carries a story for it |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "That 40%. How much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Pause and restate the question. Hold only what your sentence carries: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: say which parts of the redesign were yours and which were shared or someone else's, in your own words; if any were not yours, say so plainly and return to the part that was. Hold through two follow-ups by returning to the sentence, never by adding to it, and concede specifically what you cannot speak to rather than folding | F2's number under attribution pressure. EXP because it tests exactly that |
| G2 | "Sixty seconds: why you over a candidate who already runs several sites?" | JD | [grounded] "ran the site's peak-season surge plan two years running"; "cut mis-pick rate 40% by redesigning the pick path"; "green belt certified"; "7 years in warehouse and distribution ops" | Four short sentences, one per quote, in first person and at their own scope. Concede the span difference in one clause: the other candidate has the multi-site span the question assumes. Then hold on what you bring and say plainly what you would need to learn. No claim to multi-site work | F1 and F3 under time pressure. JD because it scores fit to the stated role |

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| "Own daily terminal operations across 4 sites" | A2, B3, B5, F1, G2 |
| "drive on-time performance and cost-per-shipment down" | A3, B1, B2 |
| "lead a team of 12 supervisors" | A1, B5, D2 |
| "build reporting in Excel/Power BI" | A4, B4 |
| "5+ years operations leadership required" | A1, E1 |
| "Lean/Six Sigma a plus" | C3 |
| Your headline number, the 40% | C1, C2, G1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "How does Atlas define on-time performance today, and where does it stand against target?" | It starts from the definition, the same move as B1, and tells you what you would be judged on |
| 2 | "Which of the four sites would you want looked at first, and why that one?" | It points at a real first-ninety-days priority and shows you think site by site |
| 3 | "How are the twelve supervisors spread across the four sites, and what has changed in that team recently?" | It shows you are thinking about span and team state before taking it on |
| 4 | "What reporting exists today, and what would you want built in the first quarter?" | It surfaces how much Power BI is expected, so your plan answers the real need |
| 5 | "What would make you say, a year from now, that this hire was a clear success?" | It turns the success measure into something you can work toward and check |
| 6 | "What do the site leads and the people around this role expect from it in the first week?" | It shows you will work with the people around the role, not only over them |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran terminal operations across multiple sites | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation, not words for you: the material says warehouse and distribution work and one site's plan |
| Improved on-time performance or cost-per-shipment | Inflated form of F2 | F2's quote at its own scope: "I cut mis-pick rate 40% by redesigning the pick path." A3's slot asks only what was tracked |
| Led or managed twelve supervisors, or a team of that size | Inflated form of F3 | "I'm a senior shift manager over 3 supervisors." The count stays at 3 |
| Experience building reports in Excel beyond "solid Excel" | Inflated form of F4 | The quote at its own scope. A4's slot asks what, if anything, you built |
| Any Power BI experience | Negative you stated, F5 | The plain acknowledgment F5 gives: "I've never used Power BI." No slot |
| Five or more years of operations leadership | Inflated form of F6 | The 7 years in operations at their own scope. The real years leading are in A1's and F6's slots |
| Led Lean or Six Sigma projects | Inflated form of F7 | "I'm green belt certified." C3's slot asks only where you applied it |

## Sources

Provided: the job description text and the background in your message. No CV, interviewer profile or recruiter guidance was provided, and no dossier was present.

| Query | Outcome |
|---|---|
| Atlas Freight regional logistics company values | refused |
| Atlas Freight interview process operations manager | refused |
| Atlas Freight regional logistics strategy news | refused |

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight` values | unavailable | Every call was refused. It would have moved a values cheat sheet and any VAL questions; none is built |
| 2. `Atlas Freight` interview process, operations manager | unavailable | Every call was refused. It would have moved the loop structure and the persona weights; the generic archetype stands in |
| 3. `Atlas Freight` strategy and recent news | unavailable | Every call was refused. It would have moved the CO bank; E2 is a generic scaffold instead |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative operations manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Round type and who you are meeting (recruiter, hiring manager, panel) → persona weights reweighted for the real round, and bank depth moved to match
- The interviewer's name → an interviewer read from their public professional footprint, and a reverse question tied to their own career path
- Your CV → quotes that replace several answer slots and could move F1, F3, F4 and F6 from medium or low toward higher bands
- Your answers to the answer slots on F1 (sites covered), F2 (on-time or cost measures), F3 (supervisors led before) and F6 (years leading) → those rows regenerate with your own words in them
- The green belt certificate → F7 moves from medium to high, and C3 gets a named anchor
- A pasted Atlas Freight values page, careers page or the recruiter's email on the loop → a values cheat sheet if a values round is documented, the real loop structure in place of the generic archetype, and the CO bank grounded
- Search permission, if you grant it → the same three targets run, and a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) can be offered once for strategy and recent organization context
- The recruiter's guidance on focus areas, any deliverable, and process → coverage without assumption; usually one email
- Your prep hours before the interview → a prioritized prep schedule sized to them
- A tuesday-dossier.md from an earlier fit check → an evidence-derived top objection and prohibited claims in place of the ones inferred here
