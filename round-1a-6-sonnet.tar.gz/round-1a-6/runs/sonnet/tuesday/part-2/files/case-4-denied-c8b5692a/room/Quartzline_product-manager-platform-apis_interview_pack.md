# Interview prep pack: Product Manager, Platform APIs at Quartzline

- **Role:** Product Manager, Platform APIs
- **Company:** Quartzline
- **Round:** one 45-minute conversation with the hiring manager (your words). Interviewer not named.
- **Built from:** your tuesday-dossier.md (version 1.1) and your message. No web research was available (see Sources).

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether the claims on your record survive scrutiny and attribution probes |
| JD | Whether you can do the listed job, including its gaps |
| CO | Company and strategy knowledge (none in this pack, see Sources) |
| CASE | Structure and reasoning on a live problem from the role |

Fit-snapshot rows are F1 to F7. Question IDs run A to E, then G and H, so they never collide with the F rows.

## Fit snapshot

Requirements are the dossier's role_profile lines. Evidence is your confirmed claims from the dossier's handoff, quoted exactly. The hiring-manager prior and the dossier's three weak areas drive everything below.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence 3 | low | [inferred] | transferability | Strategy is `bridge`, positioned as adjacent and never as PM experience. Words: "I led 30+ end-to-end client integrations of the vendor's REST APIs." The limit is the pack's observation: your material shows client integration work, not product management time, so the three years are not claimed. The plain acknowledgment is sourced by `prohibited_claims: "Having held a product manager title or role"`: "I haven't held a product manager title or role." The second quote is confirmed with limited inspectable proof, so expect a probe on it |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibilities | none given | none | [grounded] | capability | The dossier lists this as an `acknowledge_gap` area in `uncertain_or_weak_areas`, and `prohibited_claims: "Having owned a product roadmap"` bars the claim. Words: "I haven't owned a product roadmap." Then how you would learn it, said as a plan and never as a past. No bridge and no answer slot, because the underwriter found nothing to bridge from |
| F3 | "Shipped API or platform products" — dossier role_profile R2 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1 | high | [grounded] | transferability | Words stay at the quote's scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs." The pack's observation: the material shows integrating the vendor's APIs, not releasing an API product. Answer slot: the JD's "shipped API or platform products" line makes a probe on whether any of that work released something others build on likely. If any did, say what it was and what part was yours, in your own words; if none did, or it was not yours, say so plainly and stay with the integrations you led |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence 2 | low | [inferred] | discovery | The quotes touch REST APIs and an architecture stage without showing whether API docs or schemas were part of the work. Answer slot: the JD names API docs and schemas, so a probe on which you worked from is likely. If you read, wrote or checked either as part of that work, say which and what you did with them, in your own words; if you did not work from them, say so plainly and say what you would read first |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4 (customers) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1 | medium | [grounded] | presentation | The quote already reaches the client side in other terms. Reword only the quote: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Add no practice, outcome or relationship the quote does not state |
| F6 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4 (engineering and sales) | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence 3 | low | [inferred] | discovery | The quote reaches product, not engineering or sales, and nothing shows whether it reaches them. Answer slot: the JD names engineering and sales, so a probe on working with each is likely. If you worked with engineers or sales on that work, say what it looked like in your own words; if you did not, say so plainly and say how you would start. Confirmed with limited inspectable proof, so volunteer that limit |
| F7 | "Agile delivery experience" — dossier role_profile R5 | none given | low | [grounded] | discovery | Strategy is `clarify`, and no verified entry speaks to this requirement itself, so nothing about your past is coached. Answer slot in B5, plus the honest line "Here's what I'd want to confirm about how you define it here." |

No requirement in the dossier is a gate: its `hard_gates` list is empty.

## Persona table

The hiring-manager prior sets the weights: Case/Strategist and Skeptic lead. The dossier then sharpens them.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (A) | Live problems on the real platform: roadmap, discovery, squad trade-offs, adoption | high: hiring-manager prior, and the JD's four responsibilities are all case-shaped | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic (B) | Quiet probing of the title gap, roadmap, squad authority and agile | high: hiring-manager prior, and the dossier names an objection and three weak areas | Rehearse B1 until it is boring; concede the sourced gaps plainly; bridge only from quoted adjacent work with the limit named |
| Data-Driven Prober (C) | Reads your record line by line; probes the 30+ figure and the playbook | medium: one headline number on your record, and adoption metrics are in the JD | Know what you can and cannot say about how the figure was counted; say so plainly where you do not know |
| Conversational (D) | Opens with the journey; casual questions that are still scored | medium: a 45-minute conversation usually starts here, and nothing in your inputs says otherwise | A 90-second arc built only from your quoted sentences; treat casual JD questions as scored |
| Peer Evaluator (E) | Seam-splitting with the squad leads; working with sales | low: the manager is not a peer, but two squad leads are in the JD | Offer seam principles instead of pretending to know the seam; reciprocity framing |
| Pressure (G) | Time-boxed "why you" and "how much was you" | low: possible, not signalled by anything you gave me | Pause, restate, hold the quoted position through two follow-ups, concede specifically |
| Values/Behavioral (H) | Behavioral probes in a manager's register | low: your words describe one manager conversation and no values round, and Quartzline's values are not established | Selection scaffolds with an honest branch; no mapped stories without a quoted sentence |

Depth follows weight: 5, 5, 3, 3, 2, 2, 2 questions. Your own words establish the loop (one manager conversation), so no archetype fallback was used.

## Question banks

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You inherit the roadmap for the partner-facing API platform. What do you need to know first, and how do you decide what goes next?" | CASE | [generic] | Think aloud in order: clarify, objective, segmentation, approach, metrics, risks. Clarify first with the two things the dossier left open: which roadmap decisions are yours alone and which belong to the squad leads, and how adoption is measured today. Then name partner segments, the outcome the platform exists for, how you would rank candidate work against it, and what you would tell the squads. Challenge one premise respectfully, such as whether partner demand or platform health goes first | The live form of F2: it lets you show reasoning where F2 shows no ownership. CASE because it asks about no past; JD content from the first responsibility |
| A2 | "Partner sign-ups are healthy but few partners reach steady production use. Diagnose it." | CASE | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Clarify what adoption means and how Quartzline measures it, since the baseline is unknown. Segment partners, lay out the stages from sign-up to production, and form two or three hypotheses with the data that would test each. The integrations you led had named stages, scoping, requirements, architecture, UAT and go-live, which is your own vocabulary for naming where a partner could stall. Answer slot: the JD asks you to track adoption, so a probe on where partners stall is likely. If you saw where integrations stalled, say where and what you saw, in your own words; if you did not track that, or there was no pattern, say so plainly and say what data you would pull first | Adoption metrics are a stated responsibility, and F3 and F5 carry the integration quote. CASE delivery, JD content |
| A3 | "Two squads, one sprint: one wants to ship a developer-experience fix, the other needs a breaking change for a large partner. How do you decide?" | CASE | [generic] | Settle decision rights first: who decides, and say you would confirm that rather than assume it. Then criteria (partner impact, reversibility, cost of delay), options (sequence, split, stagger), what you tell each squad lead and when, and what would change your recommendation. Give a recommendation, not a survey | JD line on driving delivery with two squads; F6 is the row it presses on, and squad authority is the dossier's open risk. CASE because it presupposes nothing about your past |
| A4 | "You have five discovery conversations with integration partners next month. Who do you pick, and what do you want out of them?" | CASE | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Structure: pick partners by segment and by where adoption stalls; per conversation decide what you want to learn and what you will not do (pitch); say how the findings become input that you take to the squad leads. The nearest thing your material carries is the quoted sentence: tell it in its own beats, the sessions and the client evidence, with nothing added. It is confirmed with limited inspectable proof, so volunteer that limit before a prober extracts it, and say the partners here may differ from the clients in that sentence | JD responsibility "Run discovery with integration partners"; F6 and F1 carry the quote. CASE, with the medium-confidence caveat coached in |
| A5 | "Sketch your first ninety days in this role." | CASE | [generic] | Three phases: learn (who decides what, the adoption baseline, partners, the squads' backlogs), then choose one small visible item to ship with a squad, then agree how adoption will be measured. Say your ramp plan on roadmap ownership as a plan: what you would learn, from whom, and by when. A plan is not a past, so claim nothing you have not done | The ramp-plan half of B1, asked as a plan. CASE because it asks about no past; JD content |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; negatives sourced by `prohibited_claims: "Having held a product manager title or role"`, `prohibited_claims: "Having owned a product roadmap"` and the `acknowledge_gap` area in `uncertain_or_weak_areas` | The highest-ROI prep in this pack: the underwriter named this objection, and it is asked as they wrote it. About ninety seconds, four beats. One, concede first and plainly: "I haven't held a product manager title or role, and I haven't owned a product roadmap." Two, give what you can stand behind, at its own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live — and I wrote the internal integration playbook my team uses." Three, name the limit before they do: this is adjacent work, not product management experience, and you are not arguing it equals three years of the job. Four, a ramp plan said as a plan: in the first weeks you would find out which decisions are yours and which belong to the squad leads, and how adoption is measured today. Hold through two follow-ups by returning to the integrations and the concession, never by adding to either. If probed on "Ran quarterly roadmap-input sessions feeding client evidence to product", say what the sessions were in your own words and volunteer that the proof behind them is limited | F1 and F2 are where the objection presses. JD because it scores the stated R1 requirement, and it will be asked in some form even if not in these words |
| B2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] `uncertain_or_weak_areas` `acknowledge_gap` area; `prohibited_claims: "Having owned a product roadmap"` | Name the real one first, in the sourced words: "Owning a roadmap is the part I haven't done." Then the ramp plan as a plan: what you would learn, from whom, in what order. The underwriter found nothing to bridge here, so do not bridge it. Do not pick a safer weakness to avoid the roadmap, and do not pick one your material does not show to sound modest. Calibrated candor beats bluffing a competency the interviewer personally owns | F2 is the weakest row and the interviewer likely owns the roadmap; the persona stem is the Skeptic's own. JD because it asks you to rank the job's own requirements |
| B3 | "The role asks for shipped API or platform products. What have you shipped?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Say what the quote says, at its scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs." The pack's observation is that the material shows integrating the vendor's APIs, not releasing an API product, so do not describe the work as shipping one. Answer slot: if any of that work released something others build on, say what it was and what part was yours, in your own words; if none did, or it was not yours, say so plainly and stay with the integrations you led | F3 is the row; R2 is a must-have, so this is asked directly. JD tag because it scores a stated requirement. The question's premise is the JD's, and the guidance does not adopt it |
| B4 | "You have never set prioritization for an engineering squad. How would you handle your first real disagreement with a squad lead?" | JD | [grounded] `prohibited_claims: "Having set prioritization for an engineering squad"` | Concede in the sourced words: "I haven't set prioritization for an engineering squad." Then an approach, not a past: agree up front who decides what, bring partner evidence rather than opinion, disagree in the open and decide once, escalate the decision and not the person. Answer slot: the JD names engineering, so a probe on working with engineers is likely. If the integrations put you alongside engineers, say what that looked like in your own words; if they did not, or it was not part of your role, say so plainly and say how you would build that working relationship in the first weeks | F6 and the dossier's squad-authority risk. JD because it scores "drive delivery with two engineering squads" |
| B5 | "How do you define agile delivery, and where have you worked that way?" | JD | [grounded] `uncertain_or_weak_areas` `clarify` area for R5 | The dossier's strategy is `clarify` and no verified entry speaks to this requirement, so nothing about your past is coached. Answer slot: the JD's "Agile delivery experience" line makes a probe on where you worked that way likely. If you worked that way, say where and what your part was, in your own words; if you did not work that way, or not inside a product organization, say so plainly. Either way, close with the honest line: "Here's what I'd want to confirm about how you define it here." | F7. R5 is only preferred, so a calm, short answer is the goal. JD tag because it scores a stated requirement |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You led 30+ integrations. Walk me through how that number was counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Say it as the quote has it: "I led 30+ end-to-end client integrations." Then the weakest-assumption move, before they ask. Answer slot, each in your own words: how the number was counted; what it is sensitive to; the assumption behind it you would defend least; which part was yours. If you do not know how it was counted, say so plainly | The only headline number in your record, so it is the prober's target. F1, F3 and F5 carry it. EXP because it tests attribution and what the figure survives |
| C2 | "Walk me through the integration playbook you wrote." | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Tell the beats the quote states: you wrote it, it is the internal integration playbook, your team uses it, in your own words. The underwriter inspected the playbook, so offering to show it beats describing it, once you have checked you may share it. Answer slot: the JD's "Write specs" line makes a probe on how the playbook compares to a spec likely. If any of your integration work involved writing specs or requirements documents, say what they were and what part was yours; if not, say so plainly and stay with the playbook | It is your strongest, inspectable item, so expect it to be opened. F1 and F4 carry the quote. EXP because it tests what you actually produced |
| C3 | "How would you tell a partner that has adopted the API from one that has just signed up?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Pick a definition of adoption and defend it, and ask how Quartzline measures it today, since the baseline is unknown. The integrations you led ended at go-live in your own quote; what happened after go-live is not in your material. Answer slot: the JD's adoption-metrics line makes a probe on usage after go-live likely. If you tracked usage after go-live, say what you looked at, in your own words; if you did not, say so plainly and say what you would measure first | Adoption metrics are a named responsibility with no stated baseline (the dossier's risk). F3 carries the quote. JD tag because it scores that responsibility |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the journey: how did you get from where you are to this role?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc in three beats, each in the quote's own terms: you led client integrations of the vendor's REST APIs, you wrote the internal integration playbook your team uses, you ran quarterly sessions feeding client evidence to product. The turn toward this role is yours to say: in your own words, what pulled you toward the platform itself. The last quote is confirmed with limited inspectable proof, so keep it to what the sentence says | Rapport-style openers set the frame for the whole 45 minutes. F1 carries the arc. EXP because it tests a coherent, honest account of your record |
| D2 | "What are you actually playing with in API products these days?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Casual wording, still scored. Anchor on the quote: the work you led was on "the vendor's REST APIs". Answer slot: the JD's "API docs, schemas" line makes a probe on what you read or build against likely. If you have been working from API documentation or schemas lately, say which and what you did with them, in your own words; if you have not, say so plainly and say what you would read first | F4 is thin on documents and schemas, and this is how it arrives casually. JD because it scores technical fluency |
| D3 | "Tell me about a time you had to bring a customer around to a decision they didn't want." | EXP | [generic] | Selection scaffold: pick a time with a named stake, a decision the customer resisted, what you did, and where the relationship ended up. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Stakeholder management across customers is a stated requirement and no quoted sentence carries this story. F5 is the row; the theme comes from the JD line. EXP because it asks for a past instance |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our two squads sit side by side with product. Where's the seam between you and a squad lead, and what happens when you disagree?" | JD | [generic] | Offer seam principles, not a claim to know the seam: decision rights agreed early, you own bringing partner evidence, the squad owns how it is built, disagreements decided once and recorded. Then reciprocity: what you bring the squads, and ask where they feel the current seam hurts. Say you would confirm all of it with the squad leads | The dossier flags squad authority as unverified. F6. JD because it scores the squad-delivery responsibility |
| E2 | "How do you work with sales when a partner asks for something the platform doesn't do?" | JD | [generic] | Structure: understand the partner's underlying need, check how many partners share it, say what you can and cannot promise, and tell sales what to say meanwhile. Answer slot: the JD names sales, so a probe on working with them is likely. If you worked with sales on client integrations, say what that looked like in your own words; if you did not, say so plainly and say how you would start | F6 (sales half). JD because it scores the stakeholder requirement |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over a PM who already has the title?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; `prohibited_claims: "Having held a product manager title or role"` | Pause and restate the question. Hold only what the quotes carry: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live — and I wrote the internal integration playbook my team uses." Hold through two follow-ups, conceding the title in the sourced words ("I haven't held a product manager title or role"), and do not claim to rank above the other candidate. Never fold on the integrations to restore harmony | B1 in a time-boxed delivery. F1. JD because it scores R1 |
| G2 | "That figure, 30+ — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold at the quote's verb: "I led 30+ end-to-end client integrations." Hold through two follow-ups by returning to that sentence. Concede specifically, not generally. Answer slot: say which parts were yours and which were your team's, in your own words; if you cannot say how many of the 30+ you led yourself, or part of it was not yours, say so plainly and stay with what you led | The attribution probe is the pressure persona's stem, aimed at your one number. C1 is its calm version. EXP because it tests what was actually you |

### H. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to a stakeholder." | VAL | [generic] | Selection scaffold: pick a time with a named stake, the truth you delivered, how the stakeholder reacted, and an intact relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Behavioral probes can come in a manager's register even without a values round. No quoted sentence carries this story, and Quartzline's published values are not established, so this is a pattern and not a values map |
| H2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where the customer's need and an internal number pulled apart, what you chose, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The customer-facing half of the role makes it plausible. F5. Generic for the same reason as H1 |

## Requirement coverage

| Requirement or responsibility (dossier role_profile) | Questions |
|---|---|
| R1 "3+ years product management experience" | B1, B2, G1 |
| R2 "Shipped API or platform products" | B3 |
| R3 "Technical fluency: API docs, schemas" | D2, A2, C3 |
| R4 "Stakeholder management across engineering, sales, customers" | B4, D3, E1, E2 |
| R5 "Agile delivery experience" | B5 |
| "Own the roadmap for the partner-facing API platform" | A1, A5, B1 |
| "Run discovery with integration partners" | A4 |
| "Write specs and drive delivery with two engineering squads" | A3, B4, C2, E1 |
| "Define and track adoption metrics" | A2, C3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The dossier's open risk: authority is asserted in the JD and not evidenced. It reads as diligence, and the answer is something you need before accepting |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | The dossier's second risk: adoption metrics are a named responsibility with no baseline stated. It also shows you think in measures |
| 3 | "How do the two squads divide the platform today, and where does a decision most often need someone from outside both?" | Turns the seam into a concrete answer you can plan around, and shows you are thinking about the squads' reality |
| 4 | "Who holds the partner relationships today that I would be running discovery with?" | Tells you what you would inherit, and signals you plan to build on existing relationships and not around them |
| 5 | "What would a good first ninety days look like, and how will you judge it?" | Gets the manager to state their bar in their own terms, which makes A5's plan checkable |
| 6 | "I haven't held the PM title or a roadmap. What would you want to see in the first sixty days to be confident about the move?" | The negatives are sourced by `prohibited_claims`. It moves the hardest objection from an interrogation to a shared plan, and the answer tells you what the role is really about |

## Prohibited claims

Built from the dossier's `prohibited_claims`, plus inflated forms of your own quotes. Each is a line the pack will not coach.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier `prohibited_claims` | The plain acknowledgment: "I haven't held a product manager title or role." Then the integrations at their own scope (F1) |
| Having owned a product roadmap | Dossier `prohibited_claims` and the `acknowledge_gap` area in `uncertain_or_weak_areas` | The plain acknowledgment: "I haven't owned a product roadmap." A ramp plan, said as a plan. No slot and no bridge |
| Having set prioritization for an engineering squad | Dossier `prohibited_claims` | The plain acknowledgment: "I haven't set prioritization for an engineering squad." B4's slot asks only about working alongside engineers |
| Shipped an API or platform product | Inflated form of F3 | The quote at its own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs." The limit is the pack's observation: the material shows integrations of the vendor's APIs, not a released API product |
| Influenced or shaped the product roadmap | Inflated form of the quarterly-sessions quote in F1 and F6 | The quote at its own scope: "Ran quarterly roadmap-input sessions feeding client evidence to product." The limit is the pack's observation: the material shows evidence fed to product, not what product did with it. Volunteer that the proof behind it is limited |

## Sources

- **Provided:** tuesday-dossier.md, version 1.1. Consumed: role_profile (requirements, responsibilities) and handoff_to_mock_interview (verified evidence, weak areas with their strategies, the named objection, risks, employer questions, prohibited claims). Your message supplied the round: a 45-minute conversation with the hiring manager.
- **Not consumed:** the dossier's decision prose, which summarizes your background more broadly than any verified entry, so nothing here rests on it.
- **Loop:** your own words establish one hiring-manager conversation. No values-style round is detected, so there is no values cheat sheet, and no archetype fallback was used.
- **Research:** every search was refused by the host, so nothing about Quartzline's values, interview process or strategy is established. No CO questions are written, and company-specific claims are absent rather than guessed.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Search "Quartzline company values" was refused. Would have fed a values cheat sheet if a values round were documented |
| 2. `Quartzline interview process product manager` | unavailable | Search was refused. Would have checked the loop structure and persona weights |
| 3. `Quartzline strategy` / recent news | unavailable | Search "Quartzline API platform strategy news" was refused. Would have fed a CO or CASE question grounded in current strategy |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so there was no query to form |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's role_profile supplies the JD lines the fit snapshot and JD-tagged questions rest on |

## Upgrade menu

- Search access, if you allow it → Quartzline's published values, documented loop and current strategy, which would add CO and CASE questions grounded in the company. A deeper pass would be up to 6 further searches and 2 further fetches, several more minutes
- The hiring manager's name → an interviewer read, persona weights tuned to their public footprint, and a reverse question tied to their own career path
- The recruiter's prep note, if one exists → any stated focus areas or pre-declared deliverable, which would add a build section
- The API docs or schemas you worked from in those integrations → upgrades F4 and A2, D2 from guesses to your own words
- How the 30+ was counted and which parts were yours → upgrades C1 and G2 into a mapped answer
- Whether the integrations put you alongside engineers or sales, and what that looked like → upgrades F6, B4 and E2
- Where, if anywhere, you have worked in an agile delivery setup → upgrades F7 and B5
- The raw CV behind your confirmed claims → lets the evidence cells quote it directly
