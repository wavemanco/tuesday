# Interview prep pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy at Northwind, a peer (same VP). **Round:** one 60-minute conversation.

Built on this assumption: a single peer conversation, so persona weights come from the peer relationship plus what Dan's profile says about himself. Nothing in your material names a values round or other rounds, and no loop archetype was needed because your own words fix the session.

## How to use this pack

Personas describe how a question is asked. Types describe what it is scored on. Guidance is scaffolding, not a script: say it in your own words, and rehearse only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Behavior against the company's published values (none used here; see Sources) |
| EXP | Whether a claim about your past survives scrutiny and attribution |
| JD | Whether you can do the listed job, gaps included |
| CO | Depth of company and strategy knowledge |
| CASE | Structure and reasoning on a live problem |

An answer slot is an instruction for the interview, not a question for you now. If you did the thing, say how, in your own words. If there was no such step, or it was not yours, say so plainly and return to what you did do.

## Fit snapshot

Requirements are quoted from your JD highlights, not the full posting. Evidence is quoted from your notes on Priya.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | Your material shows strategy consulting, then product strategy and ops, and does not show a go-to-market or a product-line launch; the words stay at the quote. Answer slot: the JD's two-new-product-lines line makes a probe on any new-product work likely. If any of your product strategy work took something new to market, say what it was and what part was yours; if none did, or it was not yours, say so plainly and stay with the product strategy and ops work |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | low | [inferred] | discovery | The quote touches ARR growth and does not show whether it looked at a stage of a customer lifecycle. Answer slot: the JD's land/adopt/expand/renew line makes a lifecycle probe likely. If your work looked at where growth was untapped across a customer lifecycle, say how and what you found; if it did not, say so plainly and stay with the change you proposed |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | discovery | The quote gives the tools and does not say whether the analysis was run independently. Your words: "I'm skilled in SQL/Tableau." Answer slot: a self-described data-driven interviewer will likely ask for an analysis you ran. If you ran one start to finish, say what it answered and what you checked; if it was a team effort or not yours, say so plainly and stay with the tools |
| F4 | "partner-motion design experience required" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | Your material says a model used in negotiations, not a partner motion, and the words stay there: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: the JD's partner-motion line makes a probe on what part of a motion you designed likely. If you set any part of how partners are engaged, say which part and how you decided; if the model was your piece and the motion was someone else's, or there was no such design, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | presentation | The quote already reaches the requirement in other terms; reword only it: "I set annual volume targets with consensus across orgs." Answer slot: expect a probe on where orgs started apart. If they did, say what moved them and what part was yours; if consensus came without disagreement, or the step was not yours, say so plainly |
| F6 | "AI experience a plus" — JD highlights | "uses AI tools daily" — the coach's notes | medium | [grounded] | presentation | The quote is use, and your material does not show building. Your words: "I use AI tools daily." Answer slot: name the tools and the work you use them for, in your own words; if you have built or shipped something with AI, say what it was, and if your experience is as a daily user, say that plainly |
| F7 | Sales-ops and quota-setting fluency — role-family expectation, no JD line states it (generic) | "No classic sales-ops or quota-setting experience" — the coach's notes | none | [grounded] | capability | A gap the coach's notes state, so the words are theirs: "I haven't had classic sales-ops or quota-setting experience." The word classic is part of the statement, and nothing here widens or narrows it. Then how you would learn it, said as a plan and never as a past |

## Reading the interviewer

Only what you supplied: his self-description, "relentlessly data-driven", a career spine in pricing and monetization roles, and one early-stage-startup chapter. No search was run on him.

| Signal | What it likely means in the room | Where it shows up |
|---|---|---|
| Self-described "relentlessly data-driven" | Every number gets probed to its inputs, and he will go two levels deeper than your answer | A1, A2, A3, A4, A5 |
| Pricing and monetization career | Case questions will tilt to pricing, packaging and unit economics, which is his native language | C2, R6 |
| One early-stage-startup chapter | Builder stories land well, and expect probes on how you work without a playbook | D2, R1 |
| Peer, same VP | He is judging what you would cost and contribute to his own work, so seam and credit questions come collegially | B1, B2, B3, B4, R2, R3 |

Mirror opportunities, at the level of shared vocabulary only, with no shared experience claimed:

- Data-driven language pairs with F3's quote, "skilled in SQL/Tableau". Offer an analysis walk-through only if you ran one yourself.
- Monetization language pairs with F4's quote, "built a partner-level revenue model used in carrier negotiations". Describe the model in its own terms and let him draw the connection.
- Your material shows no career jump shared with his, so none is offered.

## Persona table

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober (A, 5 questions) | Line-by-line probing of your figures and analyses | Highest. The peer prior lists it, and his own "relentlessly data-driven" line raises it to the top | Say how each figure was counted, or say plainly that you do not know; name your weakest assumption before he does |
| Peer Evaluator (B, 4 questions) | Seam-splitting, credit, disagreement, what you need from him | Very high. Peer is the strongest prior for this persona, and he is judging load on his own team | Frame what you bring his team first; propose seam principles rather than pretending to know the seam |
| Case/Strategist (C, 3 questions) | Live problems on Compass, bundling, enterprise expansion, partner motion, pricing | Medium. Not the hiring manager, but the research note's priorities and his pricing spine make live problems likely | Clarify, objective, segments, approach, metrics, risks; think aloud; challenge one premise politely |
| Skeptic (D, 3 questions) | The sales-ops and quota gap, working without a playbook, why here | Medium. His function is sales strategy and F7 is a stated gap, so the objection is predictable even from a peer | Rehearse the single predictable objection until it is boring; calibrated candor over bluffing |
| Conversational (E, 2 questions) | A friendly biography and an AI chat | Low to medium. The register is casual but the AI plus is scored | A tight 90-second arc; treat the AI question as scored |
| Pressure (F, 2 questions) | Time-boxed or challenging attribution on the headline figure | Low. A peer is unlikely to stress-test, but one pointed challenge on the biggest number is plausible | Pause, restate, hold through two follow-ups, concede specifically |

Values/Behavioral is not weighted: no loop source in your material names a values round, and no published Northwind values were supplied, so no cheat sheet is built. B2 and B3 carry the behavioral flavor a peer would use.

## Question banks

Highest-ROI prep in this pack: **D1**, the sales-ops and quota-setting objection. It follows from F7 and from Dan's function, and a rehearsed, non-defensive answer changes the conversation.

### A. Data-Driven Prober (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Start where the quote stops: "I proposed the change, and the uplift was credited to it." Then the four slots a figure raises, each in your own words: how the figure was counted; what it is sensitive to; the assumption behind it you would defend least, named before Dan names it; and which part was yours. If you do not know how it was counted, say that plainly. It is an honest answer, and it beats a method you cannot repeat under a second question | F2 holds this figure, and a data-driven peer is likely to go to the biggest number first. EXP because it tests counting and attribution, not the role |
| A2 | "How did the annual volume targets get to a number the orgs agreed on?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Beats the quote states: you set annual volume targets, and there was consensus across orgs. Answer slot: expect a probe on where the number came from and who pushed back. Say in your own words how it was reached and which part was yours; if the number came from elsewhere, or there was no pushback, say so plainly and stay with the consensus across orgs. Do not call the targets quotas | F5 is the evidence for cross-functional influence, and an agreed target invites a how-was-it-reached probe. EXP because it tests what you did. It also sets up D1, where the line between targets and quotas gets tested |
| A3 | "Walk me through the partner-level revenue model you built. What did it answer, and how did it get used in the carrier negotiations?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Beats the quote states: the model, built at partner level, used in carrier negotiations. Answer slot: the JD's partner-motion line and a data-driven interviewer make probes on what the model assumed and who set the partner terms likely. If the model informed terms you proposed, say how; if someone else set the terms, or the model was one input among others, say so plainly and stay with the model you built. Name in your own words the assumption you would defend least. Do not call the model a partner motion | F4 is the only evidence for a required partner-motion line, so the model-versus-motion distinction is where it gets tested. EXP because it probes what was actually built, with JD delivery |
| A4 | "Tell me about an analysis you ran yourself in SQL and Tableau." | JD | [grounded] "skilled in SQL/Tableau" | The quote does not carry a story, so this is a selection scaffold. Pick one you ran yourself from query to chart. It needs the question it answered, what you checked before trusting it, and what happened with the result; expect Dan to ask for denominators and what you validated. Choose one where you can answer those without guessing. If no such analysis comes to mind, say so plainly, then give the nearest thing your material does carry, "skilled in SQL/Tableau", or how you would approach one | F3 is a named requirement, and a self-described data-driven interviewer is likely to test it by asking for a real analysis. JD because it scores the stated requirement |
| A5 | "Suppose you had our customer base cut by land, adopt, expand and renew tomorrow. What are the first three cuts you'd run, and what would make you distrust them?" | JD | [grounded] the JD line "identify whitespace across land/adopt/expand/renew" | A live problem, so it makes no claim about your past. Clarify first: what each stage means in the data and where it lives. State the objective, then the three cuts and why each, then what you would check before trusting each, such as denominators and mix effects. Say what you would do with each finding. Think aloud | F2 is where the lifecycle requirement has the thinnest material. JD content with CASE delivery, because whitespace analysis is the core analytic of the role and this is how a prober would test it live |

### B. Peer Evaluator (weight: very high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam between Sales Strategy and Emerging Products GTM, and what happens when we disagree?" | JD | [generic] | No claim about your past. Say you do not yet know where the seam sits and propose principles for finding it: who owns which decision, what data is shared, and how a disagreement gets settled between the two of you before it goes to your shared VP. Add what you would bring his team. Show spine and tact together: you would rather settle a disagreement with data than with rank | F5 names cross-functional influence as a requirement, and peers ask this when they are pricing what you add to or take from their load. JD content, peer delivery |
| B2 | "How do you handle credit when work spans teams? Tell me about a time it did." | EXP | [grounded] "set annual volume targets with cross-org consensus" | Beats the quote states: annual volume targets and consensus across orgs. Answer slot: expect a probe on who else shaped it. Say who and what in your own words; if others did not shape it, or you cannot say, say so plainly and stay with the consensus across orgs | F5 is the evidence, and credit-sharing is a standard peer probe. EXP because it tests attribution |
| B3 | "Tell me about a disagreement with a peer where you did not get your way." | EXP | [generic] | Your quotes do not carry a story for this, so it is a selection scaffold. Pick a time with a named stake, a position you held, and a relationship that was intact afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle one | Peer evaluators test disagreement style with equals, and the persona stem for it is a standard one. EXP because it asks about a past instance |
| B4 | "What would you need from me in your first ninety days, and what can you do for my team?" | JD | [grounded] "skilled in SQL/Tableau" | Lead with the offer, then the ask. The offer rests on the quote: you are skilled in SQL/Tableau, so offer analysis support in those tools, and add what else you would bring in your own words. Keep the ask to data access and context on how his team measures things | A reciprocity question for a peer, and the first thing a peer is weighing is whether the hire reduces or adds to their load. JD because it tests cross-functional partnership, not past work |

### C. Case/Strategist (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Compass is launching, and a much larger platform vendor is bundling against us. How would you structure the GTM for Compass, and what would you want to know first?" | CASE | [grounded] "an AI copilot launch ('Compass')"; "main competitive threat is bundling by a much larger platform vendor" — your research note | No claim about your past. Say the structure aloud, then clarify: who the Compass buyer is, what the bundle includes and what it costs the customer, and where Northwind wins on its own. Then objective, segments (land, adopt, expand, renew), approach, metrics, risks. State an early hypothesis and challenge one premise politely, such as whether to fight the bundle head on or position where it is weak | Strategy-grounded, from the research note's launch and threat. CASE because it is a live problem; CO content, since it tests whether you can think at Northwind's altitude |
| C2 | "Profitability is a stated priority. How would you think about pricing and packaging Compass against a bundle?" | CASE | [grounded] "reaching profitability" — your research note | Pricing is Dan's native ground, so think aloud and invite his view. Clarify cost to serve and what the bundle gives away, then options for the value metric, where you would test, and guardrails on margin and discounting. Say where you would lean on his judgment rather than pretend a pricing background your material does not show | His pricing and monetization spine tilts case questions this way, and profitability is a stated priority. CASE because it is live; the CO content comes from the note |
| C3 | "Enterprise expansion is a stated priority. How might a partner motion help, and what would you want to know before designing one?" | JD | [grounded] "enterprise expansion" — your research note | No claim about your past. Structure: what the motion must achieve for enterprise accounts, which partner types, who owns the customer relationship, the economics for partners and for Northwind given profitability, and conflict with direct sales. Ask Dan where such conflict has shown up. A3 is where your model quote gets rehearsed | The JD requires partner-motion design experience and F4 is thin, so a live design question is likely. JD content with CASE delivery |

### D. Skeptic (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "I don't see classic sales-ops or quota-setting in your background. Does that matter for this role, and how would you close it?" | EXP | [grounded] "No classic sales-ops or quota-setting experience"; "set annual volume targets with cross-org consensus" | **Highest-ROI prep.** Open with the plain words: "I haven't had classic sales-ops or quota-setting experience." Then your adjacent work at its own scope: "What I have done is set annual volume targets with cross-org consensus." Then a ramp plan, said as future: what you would learn first and from whom, in your own words. Follow-ups to rehearse, hold at the quote each time. One: "Isn't setting volume targets just quota-setting by another name?" Answer slot: if you can say what was the same and what differed, say it in your own words; if you cannot, say that plainly and do not call the work quota-setting. Two: "What would you be weakest at in your first month?" Concede specifically with the thing you would learn first. Three: "How do you earn credibility with a team that has carried a number?" Answer with what you would ask them and how you would use their judgment. Do not fold on the quote, and do not widen it | F7 is the largest stated gap and Dan's function is sales strategy. EXP because it asks whether the background survives cross-examination; Skeptic delivery |
| D2 | "Both product lines are new, and you've spent nine years at a large company. How do you work when the playbook for something new doesn't exist yet?" | JD | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | The quote carries no story of starting something without a template, so this is a selection scaffold. Pick a time you started something with nothing to copy: what you did first, where you got stuck, what you would do differently. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would work. Dan's startup chapter makes a builder story land and a scrappiness probe likely | F1 shows no new-product work, and the JD makes two new product lines the job. JD content, Skeptic delivery, tilted by his startup chapter |
| D3 | "Why B2B data infrastructure, and why Northwind?" | CO | [grounded] "an AI copilot launch ('Compass')"; "enterprise expansion"; "reaching profitability" — your research note | Your material gives no reason, so the reason is yours. Say it in your own words; if it is still forming, say so plainly. If it is true, connect it to one of the three priorities in the note, and keep your history in your own words rather than borrowing Northwind's vocabulary | F1 is a consumer-tech background moving to B2B, so motivation consistency is the standard Skeptic probe. CO because it tests homework on the company |

### E. Conversational (weight: low to medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc built from that sentence only: two years of strategy consulting at a top firm, then nine at a large consumer-tech company in product strategy and ops, ending on why this role. Your reasons for each move are yours; this pack has none, so say them in your own words | A casual opener that is still scored for economy. F1 is the evidence. EXP because it walks the CV |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | "I use AI tools daily." Then name the tools and the work you use them for, in your own words. Keep it at use: if you have built or shipped something with AI, say what; if your experience is as a daily user, say that plainly. Treat it as scored, since the JD lists AI as a plus and Compass is an AI copilot | F6 is the evidence. A casual question on a JD plus is still scored. JD because it scores the stated plus |

### F. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "That ~$400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause and restate the question. Hold at the quote: "I proposed the change, and the uplift was credited to it." Hold through two follow-ups by returning to those words, never by adding to them. Concede specifically: the credit is what the change received, and any share beyond the proposal is for you to name. Answer slot: if you did more than propose, say what; if others built, shipped or measured it, say so plainly | F2 holds the headline number, so attribution is its likeliest pressure point. EXP because it tests attribution under stress; pairs with A1 |
| F2 | "Sixty seconds: why you over a candidate who has run quotas and territories?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus"; "skilled in SQL/Tableau"; "No classic sales-ops or quota-setting experience" | Sixty seconds, three beats. State the three things in the quotes' own terms: you built a partner-level revenue model used in carrier negotiations, you set annual volume targets with cross-org consensus, and you are skilled in SQL/Tableau. Then the plain acknowledgment: "I haven't had classic sales-ops or quota-setting experience." Close with what you would do first. Do not say what these prove; let Dan draw the inference | F4, F5, F3 and F7 are the material. JD because it scores fit to the listed job; Pressure delivery tests composure with a time limit |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| own GTM strategy for two new product lines | D2, C1, C2 |
| identify whitespace across land/adopt/expand/renew | A5, C1 |
| run independent analysis in SQL and Tableau | A4, A5 |
| partner-motion design experience required | A3, C3 |
| strong cross-functional influence | B1, B2, B3, B4, A2 |
| AI experience a plus | E2 |
| Sales-ops and quota-setting (role-family, no JD line) | D1, F2 |

Headline figure: ~$400M ARR is covered by A1 and F1.

## Reverse questions

| # | Question for Dan | Why it lands |
|---|---|---|
| R1 | "You've spent your career in pricing and monetization, with one early-stage chapter. What from that chapter do you still reach for in sales strategy here?" | Ties to his own path, which turns an interrogation into a peer conversation and shows you looked at him |
| R2 | "What could a new person on my side do in the first month that would genuinely help your team?" | The reciprocity question for a peer: it shows you are thinking about his load, not only your own needs |
| R3 | "Where do you see the seam between your work and emerging-products GTM, and where has it been hardest to hold?" | Follows from B1 and invites him to describe the real friction, which tells you what the job is |
| R4 | "When Compass lands in enterprise accounts, which numbers would you and I be held to separately, and which jointly?" | Speaks his data-driven language and tests how accountability would actually be split |
| R5 | "With bundling the main competitive threat, what do you most wish you could measure about it today?" | Invites a data-minded peer to share his open problem, and it shows you took the research note seriously |
| R6 | "Profitability is one of the three priorities. How does it change which pricing and packaging bets are on the table for the new lines?" | Tied to his pricing and monetization spine, and it signals you think about unit economics, not only growth |

## Prohibited claims

Built locally from the fit snapshot. These are claims the pack will not coach, because they stretch what your notes say.

| Not coached | Basis | Honest form |
|---|---|---|
| Delivered, owned or generated the ~$400M ARR uplift | Inflated form of F2's quote | The quote at its own scope: "proposed a store-surface change credited with a ~$400M ARR uplift". The limit is the pack's observation: the material says proposed and credited, not delivered or owned |
| Designed or ran a partner motion | Inflated form of F4's quote | "I built a partner-level revenue model that was used in carrier negotiations." The material says a model, not a motion. A3's slot stays inside the model |
| Treating the annual volume targets as quota-setting | Inflated form of F5's quote | The quote at its own scope: "set annual volume targets with cross-org consensus". The material says volume targets with consensus, not quotas |
| Has sales-ops or quota-setting experience | Negative stated in the coach's notes, F7 | The plain acknowledgment F7 gives: "I haven't had classic sales-ops or quota-setting experience." No slot |
| Built or shipped AI products | Inflated form of F6's quote | "I use AI tools daily." The material says use, not building |
| Independently ran the analysis behind the headline figures | Inflated form of F3's quote | "I'm skilled in SQL/Tableau." The material gives the tools; A4's slot asks only about an analysis you ran yourself |

## Sources

Provided documents: your message, containing the JD highlights, the summary of Priya's background, Dan's profile as you described it, and your research note on Northwind's priorities and competitive threat. No dossier was present. The currency of the research note was not checked.

Research tier: L0 — no searches

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | No search was sent; I worked from your material. It would have supplied published value names for VAL questions. No values-style round is detected, so the cheat sheet is absent either way |
| 2. `Northwind Data interview process` | skipped | Your words fix the loop: one 60-minute conversation with a peer. Persona weights follow from that |
| 3. `Northwind Data strategy` / recent news | skipped | Your research note supplies the three priorities and the threat that feed C1 to C3 and D3; its age was not checked |
| 4. `Dan Kovac Northwind Data` | unavailable | No search was sent; I worked from the profile you described. It would have moved the interviewer read and R1 |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions, though only as highlights, not full text |

## Upgrade menu

- The full JD text → any mid-list requirement I could not see becomes a question, and F2 moves from `[inferred]` toward `[grounded]`
- Priya's own account of the figures, one or two lines each, outside a drill: how the ~$400M was counted and which part was hers, how the volume targets were reached, how the revenue model was used, and one SQL analysis she ran herself → A1, A2, A3, A4 and F1 become story-mapped instead of slots
- The recruiter's or Dan's invite, if it names focus areas or an exercise → coverage for any pre-declared deliverable
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → published Northwind values by name, a current strategy brief, Dan's public talks and writing, and loop reports
- A `tuesday-dossier.md` from job-underwriter → verified evidence, confidence caveats and prohibited claims arrive pre-graded, so the prohibited list stops being built locally
