# Interview prep pack: Product Manager, Platform APIs at Quartzline

- Role: Product Manager, Platform APIs, Quartzline
- Round: one 45-minute conversation with the hiring manager (name not given)
- Mode: session. Built on your underwriting dossier (`tuesday-dossier.md`, version 1.1)
- Research: none of the Quartzline searches ran (refused), so company facts are absent and labeled `[generic]` where a question needs them

## How to use this pack

Personas are how a question arrives. Types are what it scores. Guidance is scaffolding, not a script: say it in your own words.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your CV claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you did your homework on the company |
| CASE | Structure and reasoning on a live problem from the role |

Labels: `[grounded]` traces to a provided document or your confirmed claims. `[inferred]` is derived by this pack, with the derivation named. `[generic]` is a role-family pattern with no claim about Quartzline or you.

Everything this pack says about your past is one of your quoted sentences, a plain acknowledgment the dossier sources, or an answer slot. An answer slot is an instruction for the interview: answer it from your real experience, or say plainly it was not yours.

## Fit snapshot

Requirement text comes from the dossier's `role_profile`. The dossier carried no evidence map, so the grading of F3, F4, F5, F7, F8 and F9 is this pack's own. F1, F2 and F6 take the underwriter's grading.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | low | [grounded] | transferability | The low grade is the underwriter's for R1 itself, not for the quoted sentences. The underwriter's frame binds: this is adjacent work, never PM experience. Pack observation: your material shows integration work and no PM title or role. Words, at the quotes' own scope and in your own words: led 30+ end-to-end client integrations, scoping through go-live. The plain acknowledgment comes from dossier field prohibited_claims: "Having held a product manager title or role", so the words are: I haven't held a product manager title. Never say the integration work is the three years |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibilities | none given | none | [grounded] | capability | The dossier records this as an acknowledge_gap area: "Owning a roadmap and prioritization authority (R1 sub-claim)". Words come only from that field: I haven't owned a product roadmap. Then a ramp plan, said as a plan and never as a past. No bridge and no slot, because the underwriter found nothing to bridge with |
| F3 | "Shipped API or platform products" — dossier role_profile R2, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | low | [inferred] | transferability | The dossier gave no map row for R2. Pack observation: the quotes show work integrating the vendor's APIs, not shipping an API product. Words stay at the quotes' own scope. Answer slot: the JD's shipped-API line makes a probe on the API itself likely. If any part of how the API worked changed because of an integration you led, say which part and what was yours; if none did, or the API was not yours to shape, say so plainly and stay with the integrations |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3, important | "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | low | [inferred] | discovery | The quote does not say whether the playbook covers API docs or schemas. Answer slot: the JD's docs-and-schemas line makes a probe on that likely. If the playbook or your integration work dealt with docs or schemas, say how, in your own words; if it did not, say so plainly and stay with the playbook as it stands |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [inferred] | discovery | The quotes show client-facing work and a hand-off to product. They do not show engineering or sales. Answer slot: the JD names all three groups, so expect a probe on which you worked with directly. Say which, in your own words, with one example; if engineering or sales was not part of that work, say so plainly and stay with the clients and product |
| F6 | "Agile delivery experience" — dossier role_profile R5, preferred | none given | low | [grounded] | discovery | The dossier's strategy for this area is clarify. No verified entry speaks to it. Answer slot: the requirement's own words, agile delivery, are the interviewer's likely probe. If you have worked that way, say how, in your own words; if you never did, say so plainly, and say what you would want to confirm about how they define it |
| F7 | "Run discovery with integration partners" — dossier role_profile responsibilities | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [inferred] | discovery | Confirmed, with limited inspectable proof, so expect a probe and volunteer the limit before it is extracted. Words stay at the quote's scope: you ran the sessions and they fed client evidence to product. Answer slot: if you know what product did with that evidence, say what and which part was yours; if you do not know, or nothing visibly changed, say so plainly and stay with the sessions |
| F8 | "Write specs and drive delivery with two engineering squads" — dossier role_profile responsibilities | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | low | [inferred] | discovery | The quotes name requirements inside client integrations and a playbook. They do not say whether anything you wrote was built from by engineers. Answer slot: if a document you wrote was built from by engineers, say what it was and what it asked for; if your requirements went to clients and not to a delivery team, say so plainly and stay with the integrations |
| F9 | "Define and track adoption metrics" — dossier role_profile responsibilities | none given | none | [inferred] | discovery | Nothing in your material speaks to this. Answer slot: if you tracked any adoption or usage measure on an integration, say what it was and what it told you; if you did not, say so plainly, and say what you would measure first |

## Persona table

Weights start from the hiring-manager prior (Case/Strategist and Skeptic), then move on what the dossier shows. No interviewer profile exists, and no loop source beyond your own words, which establish this one 45-minute session. No values-style round is detected.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems on partner requests, adoption, specs | High. A hiring manager buys capability on the role's own work, and the responsibilities (roadmap, discovery, specs, metrics) are all live-problem material. 5 questions, A1 to A5 | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud. Challenge one premise politely. Make no claim about your past in a case |
| Skeptic | The title and roadmap objection, weakest-area probes | High. The dossier names an objection built on exactly the F1 and F2 gaps. 5 questions, B1 to B5. B1 is the highest-ROI rehearsal in the pack | Rehearse B1 until it is boring. Bridge only from the quoted adjacent work, limit named first, plus a ramp plan |
| Data-Driven Prober | Counting the 30+, probing the playbook | Medium. Two high-confidence quoted claims invite line-by-line probing. 3 questions, C1 to C3 | Know how the count was made and say plainly what you do not know. Name the assumption you would defend least before they do |
| Conversational/Rapport | "Walk me through the journey", docs small talk | Medium. A 45-minute conversation opens casually, and casual questions are still scored. 3 questions, D1 to D3 | A 90-second arc built only from your quoted beats. Treat casual API-docs questions as scored |
| Pressure | Time-boxed "why you over a PM" | Low to medium. The objection can arrive time-boxed. 2 questions, E1 and E2 | Pause, restate, hold the adjacent evidence through two follow-ups, concede only what the dossier sources |
| Peer Evaluator | Seam with the two squad leads | Low as a persona, since the interviewer is the manager. The seam question is folded into A5 | Propose seam principles, not a claimed seam. Offer what you bring the squads |
| Values/Behavioral | Scenario probes against published values | Not banked. No values-style round is detected and no published Quartzline values are in hand | Not applicable this round |

## Question banks

### A. Case/Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You're the PM for the partner API platform. Three partners each want a different new endpoint this quarter and your two squads can ship one. How do you decide, and what do you need to know first?" | CASE | [generic] | Clarify before structuring: how many partners each need touches, the adoption baseline, what each endpoint costs a squad, and who makes the call. Then objective, criteria, trade-off, recommendation, and what you would measure afterward. Speak in the hypothetical ("I'd recommend") and ask which part of the decision is the PM's, because the dossier flags squad-lead authority as unevidenced. The question needs no claim about your past, so the guidance makes none | F2 is empty, so a case lets you show prioritization reasoning without claiming to have owned it. CASE because it scores structure; `[generic]` because it is a role-family pattern |
| A2 | "A partner API launched three months ago and adoption is flat. Diagnose it." | CASE | [generic] | Ask for the baseline first, since the dossier lists the current baseline as unknown. Segment: not integrating, integrating but not live, live but low volume. Hypotheses on discoverability, docs, friction, and value. Name the metric for each and what you would ask partners. No claim about your past | F9 and F4 are where the JD's metrics and docs lines press. CASE on the adoption responsibility |
| A3 | "How would you run discovery with integration partners in your first thirty days?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Shape a plan: who you would talk to, what you would ask, how you would record it, and how it would reach the squads. Then the one quoted beat: you ran quarterly sessions that fed client evidence to product. It is confirmed with limited inspectable proof, so volunteer that limit first. Answer slot: if you know what product did with that evidence, say what and which part was yours; if you do not know, or nothing visibly changed, say so plainly and stay with the sessions | F7 is the evidence and sits at medium confidence, so a probe is likely. JD because discovery is a stated responsibility, with CASE delivery |
| A4 | "A partner's engineers keep failing at the same step of your API's onboarding. Outline the spec you'd hand a squad." | CASE | [generic] | Outline: the problem and its evidence, who is affected, proposed behavior, error handling, docs and schema changes, rollout, success measure, and open questions you would settle with engineering. Say aloud what you would check with the squad before committing. No claim about your past | F4 and F8 raise specs and docs. Pure CASE so the answer rests on structure, not on a claim about specs you wrote |
| A5 | "A key partner says they'll pause their integration unless you commit to an endpoint this quarter. Sales has half-promised it, and a squad lead says it's two sprints you don't have. What do you do in the next forty-eight hours?" | CASE | [generic] | Facts first: what was promised, what the partner actually needs, what the squad's two sprints displace. Map the three parties, lay out options, recommend one, and say who decides. Propose seam principles instead of claiming to know the seam, and say what you bring the squad lead, such as the partner's evidence and a clear ask. Show spine and tact together. No claim about your past | F5 and the dossier's authority-versus-squad-leads risk meet here. The Peer register lives in this question |

### B. Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | The underwriter named this objection, so it gets the deepest rehearsal. Say the limit before it is asked for. Concede first, in words the dossier sources (prohibited_claims: "Having held a product manager title or role"; acknowledge_gap area "Owning a roadmap and prioritization authority (R1 sub-claim)"): I haven't held a product manager title, and I haven't owned a roadmap. Then the adjacent case at the quotes' own scope: the 30+ integrations from scoping to go-live, the playbook your team uses, and the quarterly sessions that fed client evidence to product, volunteering that this last one is confirmed with limited inspectable proof. Call it adjacent, never the three years. Close with a ramp plan said as a plan: what you would ask first and whom you would learn the squads' constraints from. Follow-up 1, "that's integration, not product": agree it is adjacent and return to the quotes without adding to them. Follow-up 2, "what do you do on day one": the ramp plan, plus asking which decisions are the PM's alone. Follow-up 3, "we'd be teaching you on our time": hold the adjacent evidence, concede the ramp cost plainly, and promise no speed you cannot back | The dossier's own objection, and the F1 and F2 gaps are exactly where it aims. JD because it scores the must-have. Highest-ROI prep in the pack |
| B2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] dossier uncertain_or_weak_areas, acknowledge_gap area "Owning a roadmap and prioritization authority (R1 sub-claim)" | Name the one the underwriter already found, plainly, in words that field sources: I haven't owned a roadmap or prioritization authority. Then how you would close it, said as a plan: what you would learn first and from whom. Do not soften it with the quarterly sessions; the underwriter found no bridge here, and an invented one is how candidates get caught | F2 is the capability gap. Candor here earns the trust B1 spends |
| B3 | "Tell me about the API or platform work you're closest to." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Beats the quote states: you led the integrations, 30+ of them, end to end, from scoping through go-live. Pack observation: this is integrating the vendor's APIs, not shipping an API product, so state it that way. Answer slot: the JD's shipped-API line makes a probe on the API itself likely. If any part of how the API worked changed because of an integration you led, say which part and what was yours; if none did, or the API was not yours to shape, say so plainly and stay with the integrations | F3 is the must-have R2 gap. An open prompt, so the question presupposes nothing beyond the quote |
| B4 | "Walk me through the quarterly roadmap-input sessions you ran." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Beats the quote states: you ran them, quarterly, and they fed client evidence to product. Medium confidence: confirmed, limited inspectable proof, so say plainly what you can show and what you cannot before they extract it. Pack observation: the material shows the sessions as input, and does not show the roadmap being yours. Answer slot: if you know what product did with what you brought, say what and which part was yours; if you do not know, or it never visibly changed anything, say so plainly and stay with the sessions | F7 is the medium-confidence claim a prober will test. EXP because it checks what was actually yours |
| B5 | "Tell me about your experience with agile delivery." | JD | [grounded] dossier uncertain_or_weak_areas, clarify area "Agile delivery inside a product org (R5)" | Nothing in your verified material speaks to this itself, so the guidance is clarifying. Answer slot: the requirement's own words, agile delivery, are the probe. If you have worked that way, say how, in your own words; if you never did, say so plainly, then say what you would want to confirm about how they define it. Do not stretch UAT or go-live into a delivery method | F6 is a discovery gap with a clarify strategy. JD because R5 is a stated preference |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You led 30+ integrations — walk me through how that number was counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Four slots, each in your own words and none supplied by the pack. Say how the 30+ was counted; if you do not know exactly, say so plainly. Say what the count is sensitive to. Name, before they do, the assumption behind it you would defend least; if none comes to mind, say so plainly. Say which part was yours, staying with the quote's own words: led, end to end, scoping through go-live; if some stages were shared or someone else's, say which | The CV's headline figure is a prober's first target. F1 and F3 both rest on it |
| C2 | "Walk me through the integration playbook you wrote." | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Beats the quote states: you wrote it and your team uses it. It is your inspectable evidence, so offer to walk through the document end to end. The pack has not seen it, so describe only what is actually in it. Answer slot: the JD's docs-and-schemas line makes a probe on that likely. If the playbook covers API docs or schemas, say what it says; if it does not, say so plainly and stay with what it does cover | F4 and F8 touch the playbook, and it is the one high-confidence artifact you can put in front of them |
| C3 | "Tell me about a time a number, not an opinion, changed what you did on an integration." | JD | [generic] | Selection scaffold. Pick an instance where a measure changed a decision: it needs the measure, the decision, and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the 30+ integrations at the scope quoted in B3, or how you would decide what to measure first. Never name a metric you did not track | F9 has no evidence, so this question is rehearsed as a scaffold. JD because adoption metrics are a stated responsibility |

### D. Conversational/Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc using only these beats in order: the integrations you led, the playbook you wrote, the sessions you ran. Then the turn toward product, in your own words and from your real reason. If no single reason comes to mind, say so plainly, then give the nearest honest one. Do not give the arc a PM-shaped ending | F1 and F7 supply the beats. Casual openers are scored, and this one frames the B1 conversation |
| D2 | "Have you had a chance to look at our developer docs? What stood out?" | CO | [generic] | Say only what you actually read. The pack could not research Quartzline, so it cannot say what the docs contain. Before Thursday, read their public API docs if they are public and note two specifics, one that works well and one friction point, framed as observation. If you have not looked yet, say so plainly and say what you would look at first | F4 is the technical-fluency requirement. `[generic]` because no Quartzline research ran |
| D3 | "Tell me about a time a client and an engineer wanted opposite things from you." | JD | [generic] | Selection scaffold. Pick a time with a named stake, both sides, a decision, and an intact relationship afterward. If no such time comes to mind, say so plainly, then say how you would handle it. Answer slot: the JD names sales alongside engineering and customers. If sales was part of any integration you ran, say how; if sales was not part of that work, say so plainly | F5 asks about three stakeholder groups and the quotes show only clients and product |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a PM who has done this for three years?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | Pause, restate the question, then hold. Concede in one line, in words the dossier sources (prohibited_claims: "Having held a product manager title or role"): I haven't held a product manager title. Hold the adjacent evidence through two follow-ups: the integrations and the playbook, at the quotes' scope. Never claim the three years, and never fold the adjacent claim just to restore harmony. Rehearse it time-boxed | B1 in a hostile register. F1 is the gap, and the format tests composure |
| E2 | "That 30+ — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold the quote's own verb, led, through two follow-ups before conceding anything real. Answer slot: if some integrations were jointly led or handed to others, say which share and which stages; if you led all of them, say so; if you do not know the split exactly, say so plainly and stay with the quote | A stock Pressure probe on the one figure on your record. F1 and F3 rest on it |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| R1 3+ years product management | B1, B2, E1, A3, D1 |
| R1 sub-claim: roadmap and prioritization | A1, A5, B1, B2, B4 |
| R2 Shipped API or platform products | B3, C1 |
| R3 Technical fluency: API docs, schemas | A2, A4, C2, D2 |
| R4 Stakeholder management | A5, D3 |
| R5 Agile delivery | B5 |
| Run discovery with integration partners | A3, B4 |
| Write specs and drive delivery with two squads | A4, A5 |
| Define and track adoption metrics | A2, C3 |

## Reverse questions

Questions 1 and 2 are the dossier's own employer questions. Questions 1 to 3 also test its two open risks.

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The JD asserts decision authority over two squads but the dossier found no evidence of it. The answer tells you whether you would hold the roadmap or share it, and it reads as diligence, not doubt |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | Adoption metrics are a stated responsibility with no baseline in the posting. The answer tells you whether you would inherit a baseline or have to define one |
| 3 | "When a request needs both squads, where does it get decided and who breaks a tie?" | It turns question 1 into a concrete seam, and it shows you are thinking about how the squads actually work |
| 4 | "What would you want a new PM on this platform to learn in the first thirty days?" | It invites the manager to name the ramp on their own terms, which is the honest answer to the objection in B1 |
| 5 | "How does partner feedback reach the roadmap today, and where does it tend to get stuck?" | Discovery is a stated responsibility. It asks about the channel instead of assuming one, and it gives you the real shape of the job |
| 6 | "Where have you seen people with an integration background succeed or struggle in product roles?" | It names the gap openly and asks for the manager's experience, which reads as candor and gets you their real criteria |

## Prohibited claims

Not coached in any cell of this pack. Entries 1 to 3 come from the dossier's `prohibited_claims`.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims | F1's quotes at their own scope, plus the plain acknowledgment: I haven't held a product manager title. No slot |
| Having owned a product roadmap | Dossier prohibited_claims, and the acknowledge_gap area "Owning a roadmap and prioritization authority (R1 sub-claim)" | The plain acknowledgment: I haven't owned a product roadmap. No slot, no bridge |
| Having set prioritization for an engineering squad | Dossier prohibited_claims, and the same acknowledge_gap area | The plain acknowledgment: I haven't set prioritization for an engineering squad. No slot, no bridge |
| Shipped an API product | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material shows integrating the vendor's APIs, not shipping an API product |
| Wrote specs that engineering squads built from | Inflated form of F8 | F8's quotes at their own scope. B-bank and A4 slots ask only whether anything you wrote was built from |
| Ran a product discovery programme | Inflated form of F7 | F7's quote at its own scope: quarterly sessions that fed client evidence to product |

## Sources

Provided documents: `tuesday-dossier.md`, version 1.1, which is within the 1.x this skill reads. Sections consumed: `role_profile`, which supplied the requirement text, and `handoff_to_mock_interview`, which supplied verified evidence, weak areas and strategies, the objection, risks, employer questions and prohibited claims. The dossier's `decision` (conditional_go) is context only. The dossier carried no `evidence_map`, so F3, F4, F5, F7, F8 and F9 are graded by this pack, which is why they read `[inferred]`. Your own message supplied the round: a 45-minute conversation with the hiring manager, on Thursday.

Searches sent, all refused, none returned anything:
- `Quartzline company values principles` — refused
- `Quartzline interview process product manager` — refused
- `Quartzline API platform strategy news` — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Every call was refused. It would have decided whether published values could theme a VAL question or a values cheat sheet; no values-style round is detected, so neither was built |
| 2. `Quartzline interview process product manager` | unavailable | Every call was refused. It would have named the loop and moved persona weights; the weights rest on your own words and the hiring-manager prior |
| 3. `Quartzline strategy` / recent news | unavailable | Every call was refused. It would have grounded a CO or CASE question in current priorities; A1 to A5 and D2 are `[generic]` for that reason |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so no query could be formed; the interviewer read is absent |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's `role_profile` already fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Search access for Quartzline research → grounded CO and CASE questions on current strategy, the published values by name, and the documented loop. A deeper pass, up to 6 further searches and 2 further fetches and several more minutes, would add a strategy brief and recent org context
- The hiring manager's name → an interviewer read, persona weights tuned to their public footprint, and a reverse question tied to their own path
- The recruiter's prep email, if one exists → coverage of anything pre-declared, such as a case or a deliverable
- The full JD text → F3, F4, F5, F7, F8 and F9 move from `[inferred]` toward `[grounded]`, and unquoted lines become quotable
- The integration playbook itself → C2 becomes story-mapped on what it actually contains, and F4 moves off a discovery gap if it covers docs or schemas
- Your answers to the answer slots in F3 to F9, stated outside a drill → each becomes a quoted row and the affected guidance is regenerated
- How many hours you have before Thursday → a prep schedule keyed to question IDs
