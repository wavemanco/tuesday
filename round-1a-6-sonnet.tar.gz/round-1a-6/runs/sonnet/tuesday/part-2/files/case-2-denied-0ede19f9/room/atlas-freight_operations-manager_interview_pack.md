# Interview prep pack: Operations Manager, Atlas Freight

- **Role:** Operations Manager, Atlas Freight (regional logistics, 800 employees), per the posting you pasted
- **Interviewer and relationship:** not known
- **Built on this assumption:** round type unknown, so this is a full-loop pack with flat persona weights from the Generic archetype (screen, hiring manager, panel). Those weights rest on a pattern, not on Atlas's own documented process. A noticeably weaker basis than knowing who you meet, and the pack says so rather than hiding it.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did. An "answer slot" is an instruction for the interview, not a question for you now: it tells you which probe to expect and gives both honest branches.

| Type | What it is really testing |
|---|---|
| VAL | Whether past behavior shows good judgment on values-style themes |
| EXP | Whether the claims in your background survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, including its gaps |
| CO | Company and strategy knowledge (none in this pack: see Sources) |
| CASE | A live problem from the role, scored on structure and reasoning |

Provenance labels: `[grounded]` traces to what you wrote or a cited source, `[inferred]` is this pack's derivation, `[generic]` is a role-family pattern with no claim about Atlas or about you.

## Fit snapshot

No requirement in the posting is a gate in the sense of a licence, credential, location or pay term. The 5+ years line is length of experience and is graded like any other row (F6).

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "currently a senior shift manager over 3 supervisors" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your quotes say a shift manager role and the site's surge plan. Your material does not show terminal operations or work beyond the site, and the words stay at "I'm currently a senior shift manager over 3 supervisors" and "I ran the site's peak-season surge plan two years running." Answer slot: the JD's four-site line makes a probe on multi-site ownership likely. If any of your work reached beyond the site, say which part and how, in your own words; if it did not, or the daily running was not yours, say so plainly and stay with the role you hold |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | The quote is a mis-pick rate, which is neither on-time performance nor cost-per-shipment, so the bridge stays at "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: the JD names on-time performance and cost-per-shipment, so expect a probe on whether you tracked either. If you did, say what you tracked and what it showed; if you did not, say so plainly and stay with the mis-pick result |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | The number stays attached to what you have now: "I'm currently a senior shift manager over 3 supervisors." The pack's observation, not words for you: your material shows 3 supervisors, not 12. Answer slot: if any part of your work involved supervising more people than those 3, say how, in your own words; if not, say so plainly, then describe how you would handle a larger team as a plan and never as a past |
| F4 | "build reporting in Excel/Power BI" — JD, Excel side | "solid Excel" — your message | low | [inferred] | discovery | A self-rating, with nothing said about reports. Answer slot: the JD's reporting line makes a probe on what you built likely. If you built reports in Excel, say which and what they showed; if you did not build reports there, say so plainly and say what you use Excel for |
| F5 | "build reporting in Excel/Power BI" — JD, Power BI side | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used Power BI." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller. The JD writes the two tools with a slash, and whether either alone meets the need is a question for the interviewer (reverse question 4) |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message | medium | [grounded] | discovery | The quote counts years in operations, and does not show how many of them were spent leading people. Answer slot: the JD's 5+ years of leadership makes a probe on that split likely. Say how many of the seven were in a role leading people, in your own words; if fewer than five were, say so plainly and stay with the seven you state |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | The quote already reaches the requirement in the JD's own terms, so lead with it as written: "I'm green belt certified." Nothing inspected sits behind it, so expect a probe on what you have done with it (D2) |

## Persona table

Relationship unknown, so priors are flat and the reasoning is shown for you to correct. If you know who you are meeting, say so and every weight below moves.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Bank |
|---|---|---|---|---|
| Case / Strategist | Live problems from the role: plan this, diagnose that | High. The role is operational and a hiring-manager round is the most likely one under the Generic archetype | Clarify, objective, segmentation, approach, metrics, risks; think aloud | A, 4 questions |
| Skeptic | Quiet, persistent probing of the gaps | High. The JD asks for a bigger team, more sites and a tool you have not used, which are exactly where this persona probes | Rehearse the most predictable objection until it is boring; calibrated candor over bluffing | B, 5 questions |
| Data-Driven Prober | Reads your background line by line, asks how numbers were counted | Medium. You gave one headline number and the JD is metric-heavy | Know what you can and cannot say about how each number was counted; say plainly when you do not know | C, 3 questions |
| Conversational / Rapport | Friendly, unstructured, still scored | Medium. Likely in a recruiter screen or opening minutes of any round | A short arc, and treat casual questions about JD topics as scored | D, 3 questions |
| Pressure / Stress | Interrupts, time-boxes, tests composure | Low to medium. More likely in a panel or senior round | Pause, restate, hold a position through two follow-ups before conceding anything real | E, 2 questions |
| Values / Behavioral | Scenario probes, expects story-shaped answers | Low. No values-style round is detected, so these come from standard persona prompts only | Choose a story where the hard truth actually landed, or say plainly that none comes to mind | H, 2 questions |
| Peer Evaluator | Seam-splitting between adjacent teams | Low. Plausible if another site manager joins a panel | Reciprocity framing, seam principles rather than pretending to know the seam | G, 2 questions |

## Question banks

Each Provenance cell leads with one label. Where the guidance makes a claim about your experience, your own quoted sentences follow it, and the guidance goes no further than they do.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It is 6am and two of your four terminals report being behind on outbound loading. Walk me through your next hour." | CASE | [generic] | Structure it aloud: clarify first, meaning what behind means, how far behind, and what the cut-off is; then your objective; then who you call and in what order; then what you decide now and what waits; then what you check at the end of the hour. The question needs no claim about your past, so the guidance makes none | A live problem from the JD's daily-operations line (F1's requirement); `[generic]` because it is a pattern for the problem, not a fact about Atlas |
| A2 | "Which two numbers would you want in front of you in your first week to judge on-time performance and cost-per-shipment, and why?" | JD | [generic] | Clarify before choosing: how Atlas defines on-time, at what point it is measured, and what sits inside cost-per-shipment. Then name your two numbers and what each would tell you, and say plainly what you would need to learn about how Atlas counts them. Challenge one premise respectfully, such as whether the two measures move together | Scores F2's requirement as a live reasoning task, since your material shows no tracking of either measure; CASE delivery, JD content |
| A3 | "You inherit four sites with four different on-time results. Where do you spend your first two weeks?" | CASE | [generic] | Clarify, then objective, then segmentation (which site, which shift, which part of the day), then approach, metrics and risks. Say what you would ask each supervisor and what you would hold back from changing until you have seen it run. Think aloud | F1's requirement at its widest: the four-site span is where your material is thinnest, so this rehearses reasoning rather than a claim |
| A4 | "One of your supervisors keeps missing the same daily cut-off, and the site team defends them. What do you do?" | CASE | [generic] | Facts first, then a direct conversation, then written expectations and a date to review, then what you do if nothing changes. Say what you would not do, such as deciding before you have the facts. No claim about your past is made, so none is needed | The people-leadership half of F3's requirement; JD content, CASE delivery |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You're a senior shift manager over three supervisors today, and this role leads twelve across four sites. What changes for you?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI rehearsal in this pack. Hold only what the quote carries: "I'm currently a senior shift manager over 3 supervisors." Hold through two follow-ups by returning to that, never by adding to it. Concede specifically: the span is larger than the one you hold now. Then give a plan, said as a plan: what you would learn about each supervisor first, how you would split your time across sites, what you would measure in the first month. Answer slot: if any of your work involved supervising more people than those 3, say how, in your own words; if it did not, say so plainly and stay with the 3 | F3 and F1 together are the biggest step between your evidence and the JD, so this objection arrives in some form; JD because it scores the stated requirement |
| B2 | "The role builds reporting in Excel and Power BI. Where are you with each today?" | JD | [grounded] "solid Excel" "never used Power BI" | Say plainly: "I've never used Power BI." Hold Excel at its quote: "solid Excel." Answer slot: if you built reports in Excel, say which and what they showed; if you did not, say so plainly and say what you use Excel for. Then a plan for Power BI: name one step you will actually take before a start date, and only one you will take. If you build a small report from data you already work with in Excel before the interview, you can then say so, and not before | F4 and F5; the stated gap is the cleanest to rehearse because it needs no defence, only an honest sentence and a plan |
| B3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never used Power BI" | Choose by your own judgment between the Power BI gap and the larger team, and say it first. If you pick Power BI, the words are "I've never used Power BI," followed by the plan from B2. Do not pick a smaller gap to look safer: a stated weakness with a plan scores better than a dodge | F5 and F3; the question is a stock Skeptic prompt and its honest answer is already in your material |
| B4 | "The posting requires 5+ years operations leadership. How many of your seven years count?" | JD | [grounded] "7 years in warehouse and distribution ops" | Hold: "I have 7 years in warehouse and distribution ops." Answer slot: say how many of those years were in a role leading people, in your own words; if fewer than five were, say so plainly and stay with the seven you state. Give no figure you cannot repeat under a second question | F6; the question exists because the quote counts operations years and the JD counts leadership years |
| B5 | "Why leave where you are, why Atlas, and why now?" | EXP | [generic] | Give your own reasons. The pack supplies none, because your message gives none. Each reason should be about the work, and if the main reason is growth, say that plainly rather than dressing it up. Keep it to three short sentences, one per part of the question | A standard Skeptic prompt: motivation consistency is scored in every round type |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% reduction in mis-pick rate was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Your words: "I cut mis-pick rate 40% by redesigning the pick path." Four things this question raises, each answered in your own words: how the rate was counted, what the 40% is sensitive to, the assumption behind it you would defend least (name it before they do), and which part of the result was yours. If you do not know how it was counted, say so plainly. Add no method, period or comparison you could not repeat under a second question | F2 holds your only headline number, so it is the magnet for a prober; EXP because it tests attribution |
| C2 | "When you ran the peak-season surge plan, what did you track while it ran, and how did you use it?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Beats the quote states: the plan, the site's, peak season, two years running. Tell them in your own words. Answer slot: the JD's on-time and cost-per-shipment lines make a probe on tracking likely. If you tracked anything, say what and what you did with it; if nothing was tracked, or it was not yours to track, say so plainly and describe how you ran the plan | F1 and F2's requirement; the premise of tracking comes from the JD, not from your quote, so the guidance does not adopt it |
| C3 | "On-time performance and cost-per-shipment can pull against each other. How would you decide which to protect on a bad day?" | JD | [generic] | Ask first what Atlas's customers are promised and what a late shipment costs here. Then give a decision rule you can explain in two sentences, and say what you would tell the customer or the site team. Name the case where you would break your own rule. No past is claimed | F2's requirement as a trade-off, rehearsed without relying on tracking you may not have done; CASE delivery |

### D. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops" "currently a senior shift manager over 3 supervisors" | A 90-second arc with only the beats your quotes carry: seven years in warehouse and distribution ops, now a senior shift manager over 3 supervisors, then your own reason for this role, in your own words. Fill the middle only with facts you can repeat, since the pack supplies none | F6 and F3; a casual biography question is still scored on economy and consistency with B5 |
| D2 | "What are you actually playing with in Lean or Six Sigma these days?" | JD | [grounded] "green belt certified" "cut mis-pick rate 40% by redesigning the pick path" | Start with the quote: "I'm green belt certified." Answer slot: if you use the method now, say where, in your own words; if you have not used it lately, say so plainly. A second slot: if the pick-path redesign used a tool from your training, say which; if it did not, say so plainly and leave the two apart | F7 is a plus, not a gate, but it is the one requirement you meet in the JD's own terms, so expect it asked casually; JD content |
| D3 | "If you could put one report in your supervisors' hands every morning, what would it show?" | JD | [grounded] "solid Excel" | Ask what decisions a supervisor makes at the start of a shift, then choose what the report needs to show for those decisions and say what you would leave out. On tools, the honest line is the quote: "solid Excel." Say Excel is where you would start, and put Power BI as something you would learn, not something you have done | F4's requirement as a design question; the quote supports Excel only, and the Power BI limit is F5's |

### E. Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we choose you over the other finalists?" | JD | [grounded] "7 years in warehouse and distribution ops" "ran the site's peak-season surge plan two years running" "cut mis-pick rate 40% by redesigning the pick path" | Pause, restate the question, then three beats in your own words, one per quote: seven years in warehouse and distribution ops, the site's peak-season surge plan two years running, the mis-pick rate cut by redesigning the pick path. Hold through two follow-ups by repeating those beats, not by adding to them. Concede only what you have said: "I've never used Power BI." Answer slot: if you have run more than one site, say so; if you have not, say so plainly and stay with the three beats | A time-boxed stem for a senior or panel round; F1, F2 and F6 supply the beats and F5 the one stated concession |
| E2 | "That result: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if others contributed, say who and what, in your own words; if the redesign was yours alone, say so; if part of the result was not yours, say so plainly. Concede exactly the part that was not yours, and never fold on what the quote says | F2; the question exists to catch inflation, so the preparation is candor |

### H. Values / Behavioral

No values-style round is detected for Atlas, so these two come from standard persona prompts and no company value is mapped.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | No sentence in your material carries this story, so this is a selection scaffold. Pick an occasion with a named stake, a moment where you said it plainly, and a relationship that was intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard Values prompt; it maps to nothing in the fit snapshot, so the pack supplies no story |
| H2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | A selection scaffold: pick an occasion where the choice cost something you could name, say what you chose and why, and say what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard Values prompt in a service business; no quote carries it, so no story is mapped |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "You and another site's manager both need the same people on a busy day. How do you settle it?" | CASE | [generic] | Offer a principle, not a pretended knowledge of their seam: what you would ask first, what rule you would propose for settling it, what you would escalate and when, and what you would do afterwards to keep the relationship. No past is claimed | F1's requirement at the seam between sites; a collegial form of the case |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | A selection scaffold: pick an occasion where several teams contributed, say how credit was named and by whom. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard Peer prompt; no quote carries it, so nothing about your past is asserted |

### Requirement coverage

| Stated requirement | Question IDs |
|---|---|
| "Own daily terminal operations across 4 sites" | A1, A3, B1, C2 |
| "drive on-time performance and cost-per-shipment down" | A2, C2, C3 |
| "lead a team of 12 supervisors" | A4, B1 |
| "build reporting in Excel/Power BI" | B2, D3 |
| "5+ years operations leadership required" | B4, D1 |
| "Lean/Six Sigma a plus" | D2 |
| Your headline number, the 40% mis-pick reduction | C1, E2 |

No CO question appears: the research that would ground one was refused (see Sources), and a company-strategy question without it would be generic, so it is left for the upgrade menu.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What does on-time performance look like across the four sites today, and which one is furthest from where you want it?" | Uses the JD's own measure, and the answer tells you what you would inherit |
| 2 | "How is cost-per-shipment calculated here, and who owns its inputs?" | Shows you ask how a number is counted, which is the same habit C1 tests in you |
| 3 | "Of the twelve supervisors, how many are new to the role and how many have been in it a while?" | Turns the team-size step into a conversation about the real starting point |
| 4 | "The posting names Excel and Power BI. Which do the sites' reports run on today, and what would the first reporting piece be?" | Puts the Power BI gap on the table yourself and asks what is needed first |
| 5 | "What would you want to be visibly different at the four sites after ninety days?" | Gets a concrete success picture you can plan against |
| 6 | "How is Lean or Six Sigma used here today, if at all?" | The JD calls it a plus, and the answer shows whether your certification is wanted in practice |

## Prohibited claims

Built locally from the fit snapshot, before the banks were written. No guidance, slot, hold or rationale in this pack asserts, softens or implies any of these.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran terminal operations across several sites | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation, not words for you: your material says a shift manager role and the site's surge plan. Slots stay inside those quotes |
| Improved on-time performance or cost-per-shipment | Inflated form of F2 | F2's quote at its own scope: a mis-pick rate. The slot asks only what, if anything, you tracked |
| Led or managed a team of twelve supervisors | Inflated form of F3 | F3's quote: "currently a senior shift manager over 3 supervisors". The limit is the pack's observation: 3, not 12 |
| Built reports or dashboards in Excel | Inflated form of F4 | F4's quote at its own scope: "solid Excel". The slot asks only whether any reports were built |
| Has used Power BI | Negative the candidate stated, F5 | The plain acknowledgment F5 gives: "I've never used Power BI." No slot |
| Has 5+ years of leading people | Inflated form of F6 | F6's quote: "7 years in warehouse and distribution ops". The slot asks how many of them were leadership |

## Sources

- Provided: your message, which supplied the posting text and your background. No dossier was present, and no CV was provided.
- Every call sent, by query. All three were refused, so nothing came back from them and nothing from them is used:
  - "Atlas Freight regional logistics company values": refused
  - "Atlas Freight interview process operations manager": refused
  - "Atlas Freight regional logistics strategy news terminals": refused
- Atlas's values, loop structure and current strategy are therefore not established. None of them is filled from memory. Persona weights fall back to the Generic archetype, as the title block says.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Every call was refused. Would have fed a values cheat sheet if a values-style round were detected; no such round is, so the section is absent either way |
| 2. Atlas Freight interview process, operations manager | unavailable | Every call was refused. Would have set the loop and the persona weights from named rounds; the weights are flat instead |
| 3. Atlas Freight strategy and recent news | unavailable | Every call was refused. Would have grounded at least one CO or CASE question in current priorities; none is written |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative operations manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Round type and who you are meeting: reweights every bank; flat weights are the weakest part of this pack
- The interviewer's name and title: an interviewer read, persona weights from their public footprint, and a reverse question tied to their path
- The recruiter's prep note or stated focus areas: coverage of any announced deliverable or topic, usually one email to the recruiter
- Permission to run web search, or a pasted values page and careers page for Atlas: the company's values, a documented loop, and a CO question. A deeper pass would add up to 6 more searches and 2 more fetches, at several more minutes
- Your own written answers to the answer slots in F1, F2, F4 and F6: those rows, and the banks that draw on them, are regenerated from your own words
- The green belt certificate, and the pick-accuracy report showing the rate before and after the change: either could lift F7 or F2 from medium toward high
- A CV: more of your own sentences to quote, so rows that now rest on a single clause can be graded on more
- A `tuesday-dossier.md` from an earlier fit check: verified evidence and a sourced prohibited-claims list in place of the locally built one
