# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations
**Round:** 60 minutes. Relationship assumed to be hiring manager, because your note did not say. If that is wrong, the persona weights and banks change.
**Research:** none ran. All four searches were refused, so nothing here is sourced from the web.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and use only what you actually did.

| Tag | Name | What it is really testing |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the company's published values |
| EXP | Work-experience deep-dive | Whether your claims survive scrutiny and you can say what was actually you |
| JD | Role / JD-driven | Whether you can do the listed job, including its gaps |
| CO | Company and strategy knowledge | Homework depth on strategy and recent moves |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the role |

Question IDs run by persona (A to E, then G). The letter F is skipped so question IDs never collide with fit-snapshot rows (F1 to F9). Answer slots are instructions for the interview, not questions for you to answer here.

## Prep triage

You have until tomorrow (Friday). In order:

1. Say B2 and B3 aloud until the plain acknowledgments feel boring (B2 is the highest-ROI prep in this pack).
2. Build your 90-second arc for D1 from the four sentences it quotes.
3. Run A1 and A4 as structured thinking-aloud: clarify, structure, then answer.
4. Prepare the answer slots on F1, F3 and F5, the three places a probe is most likely.
5. Pick three reverse questions and say why you want each.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for one title, and the words stay there: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's live-events and two-titles lines make a probe on both likely. If any drops were time-limited events, or you worked on a second title, say which, in your own words; if not, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team, and never worked on a game with in-app purchases" — your message | low | [inferred] | discovery | Your sentence states that you have not led a team and is silent on working across teams without leading them. Words you can say: "I've never led a team." Answer slot: the JD's four teams make a probe on who you worked with around the calendar likely. If you worked with any of design, art, engineering or community, say which and what you did, in your own words; if the calendar did not involve them, or it was not yours to coordinate, say so plainly and stay with the calendar |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [inferred] | discovery | Presenting numbers is not owning a review or choosing the KPIs, and the bridge should not be stretched. Answer slot: if you chose or defined any of the metrics you presented, say which; if the numbers were produced or chosen by others, say so plainly and stay with presenting them |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | Say it in the quote's own terms: "I wrote the release checklist our QA team still uses." A document a team still uses, named, beats an adjective. Nothing about running individual releases is in your material, so the words stop at writing it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [inferred] | discovery | Your sentences give four years as an associate producer and two years on the weekly calendar. They do not say how many of the four years were on a live game. Answer slot: expect a probe on the other two years. If they were on a live title, say what it was; if they were not, say so plainly and lead with the two years of the weekly calendar |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap, but a message line with nothing inspected behind it, so expect a probe. Lead in the quote's terms: weekly, main title, two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | No gap, but nothing inspected behind it. Lead with the named audience and cadence in the quote's terms: monthly, to the studio head. Expect the probe on definitions (C1, C3) |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | low | [inferred] | discovery | The checklist is the one written artifact in your material, and whether it shows clear writing is the reader's call. Answer slot: if asked for a written example, name the document and who had to act on it; if it is the only one, say so and offer it |
| F9 | revenue and purchase metrics for a mobile live-service title (a role-family expectation, no JD line says it) | "Never led a team, and never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Never a claim to purchase-related work, and nothing added to make the gap feel smaller |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | Live problems from the job: plan a calendar, sequence a collision, diagnose a metric drop | High. The hiring-manager prior is Case plus Skeptic, and a Head of Live Operations interviewing a producer is likely to test planning live. No interviewer profile exists to adjust it | Clarify, objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully |
| B. Skeptic | Quiet probing of the gaps: the days-one weakness, the team you have not led, the monetization side | High. Same prior. Your own message names two gaps, so this persona has material | Rehearse the most predictable objection until it is boring. Build bridges only from what you stated, and say the limit plainly |
| C. Data-Driven Prober | Which retention metrics, how defined, what assumptions | Medium. Retention is a JD line and a CV line, and a presented number invites follow-ups | Know what you can and cannot say about how each number was counted. Say plainly when you do not know |
| D. Conversational / Rapport Builder | Friendly opener, then "what are you playing" and written-communication probes | Medium. Most interviews open this way, and casual questions are still scored | A 90-second arc for the biography question, built only from your own sentences. Treat casual questions on live events as scored |
| E. Pressure | Time-boxed "why you" and "how much was actually you" | Low. Nothing in the material points to a stress format, but the attribution probe is common | Pause, restate, anchor in what you stated, hold through two follow-ups, concede specifics |
| G. Peer Evaluator | Seam between live ops and engineering, credit across teams | Low. The JD is built on coordination with other teams, but the interviewer's seniority makes a peer posture less likely | Reciprocity framing. Propose seam principles instead of pretending to know the seam |

Loop: your own words establish one 60-minute session with Tobias, so persona weights rest on that. No loop source documents a values-style round, so none is assumed and there is no values cheat sheet.

## Question banks

### A. Case / Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch a four-week events calendar for two mobile titles on different update rhythms. What do you need to know first?" | CASE | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Clarify first: what each title's events are meant to move, what is fixed (releases, store dates), and who has capacity. Then structure: objective, segments, sequence, metrics, risks. You may connect it in your own words to the calendar you ran, and no further than that sentence | F1 and F6 are the evidence closest to the JD's calendar line. CASE because it scores structure; JD because the two-titles line is the JD's |
| A2 | "An event is scheduled for Thursday and QA finds a blocker on Tuesday. Walk me through the next 48 hours." | JD | [grounded] "Wrote the release checklist our QA team still uses" | Structure it: what you establish first, who you tell and in what order, what moves and what does not, and what you record afterwards. You may say you wrote the checklist QA still uses, in those words, and no more than that about it | F4 is the JD's release-checklist line. JD because it scores the stated responsibility, CASE in delivery |
| A3 | "Day-7 retention dropped after the last event. How do you diagnose it?" | CASE | [grounded] "Presented the monthly retention numbers to the studio head" | Clarify the definition, the cohort and the timing against releases and events. List competing causes (content, bug, event fatigue, a change in who is playing) and say what data would separate them. You may mention in your own words that you presented retention numbers monthly | F7 and F3. CASE because the problem is set in the role; the metric stem is a persona stem |
| A4 | "A content drop, an engineering fix and a community event all want the same weekend. How do you sequence them, and who do you talk to?" | JD | [generic] | Make no claim about your past. Structure: what each one is for, what each costs in other teams' time, which is hardest to move, then who decides. Name the four teams in the JD (design, art, engineering, community) as the people you would talk to. If you have faced a collision like this, say what happened in your own words; if not, stay with the structure | F2's coordination line. JD because it scores the stated responsibility; the guidance stays generic because no quoted sentence speaks to it |
| A5 | "You would run the calendars for two titles at once. How do you keep them from competing for the same team's time?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Structure: what is shared (teams, tools, QA time) and what is not, how you would see collisions early, who arbitrates. Answer slot: if any of your weeks involved more than one title, say how you handled it; if not, say so plainly and stay with how you ran the calendar for the one title | F1's two-titles line is the stretch from your material. JD because it scores the stated scope |

### B. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases" | Pick from what you have stated, in your own words, and stop. Your own sentence names two limits; name the one most relevant and say how you would close it. Do not volunteer a weakness your material does not show | F2 and F9. JD because it scores the posting's own list |
| B2 | "You haven't worked on a game with in-app purchases. If this role's KPIs include purchase metrics, how would you get up to speed?" | EXP | [grounded] "Never led a team, and never worked on a game with in-app purchases" | The highest-ROI prep in this pack. Level 1, say it before they do: "I've never worked on a game with in-app purchases." Then a plan, never a past: what you would ask for in week one and who you would ask. Level 2, if pressed on whether that is a dealbreaker: hold on what your material carries, the weekly calendar and the retention numbers you presented, in those words. Level 3, if pressed that retention is not purchase metrics: concede it specifically, say what you have not seen, and say what you would want from the first post-event reviews. Never claim adjacent experience you did not state | F9 is the gap you named and the likeliest place to be probed. EXP because it scores candor about what you have done |
| B3 | "You've told us you've never led a team. This job coordinates design, art, engineering and community. How do you get people who don't report to you to move?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases" | Start with the plain acknowledgment: "I've never led a team." Answer slot: if you got work from other teams without authority, say how, in your own words; if the calendar did not involve that, say so plainly and describe how you would do it, as a plan. Hold through two follow-ups by returning to what you stated | F2. JD because the coordination line is the JD's; the stem is the Skeptic's "how would you handle the X in this role" |
| B4 | "The posting asks for 3+ years producing live-service games or apps. How much of your four years does that cover?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" and "I ran the weekly content-drop calendar for our main title for the last two years" | Say your four years and your two years on the weekly calendar, in those words. Answer slot: if the other two years were on a live title, say what it was; if not, say so plainly and lead with the two years | F5. JD because it tests the years requirement directly |

### C. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which retention metrics did you present each month, and how were they defined?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Say which numbers, in your own words. Answer slot: if you chose or defined them, say how; if they came from an analytics team or a tool, say so plainly and stay with presenting them. Never name a metric you did not present | F7. EXP because the prober tests whether the number survives scrutiny |
| C2 | "How would a post-event review work if you owned it? What goes in it?" | JD | [grounded] | Structure only: what the event was meant to move, what happened, why, what changes next time, and who sees it. Answer slot: if you have written reviews of content drops, say what they covered; if not, say so plainly and stay with the retention numbers you presented | F3's JD line. JD because the review is a stated responsibility |
| C3 | "Which assumption behind the numbers you presented would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | The weakest-assumption move: name, in your own words, the assumption you would defend least before they do. Answer slot: if you know how a number was counted and what it is sensitive to, say so; if you do not, say plainly that you do not | F7 and F3. EXP because it converts a gotcha into credibility |

### D. Conversational / Rapport Builder (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" and "I ran the weekly content-drop calendar for our main title for the last two years" and "Wrote the release checklist our QA team still uses" and "Presented the monthly retention numbers to the studio head" | A 90-second arc made of those four sentences, in that order, in your own words, nothing between them added. Close with your own reason for this role, in your own words | F5, F6, F4 and F7. EXP because it scores economy and consistency of your story |
| D2 | "What are you actually playing and following in mobile live events these days?" | JD | [generic] | Name only what you actually play or follow, and say what you notice about how they run events. If nothing comes to mind, say so plainly and name what you would study first | Casual questions on JD topics are still scored. Generic because it makes no claim about your past |
| D3 | "What's the last document you wrote that other people had to act on?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | The beats the sentence states: you wrote it, QA still uses it. Answer slot: if you can say who asked for it and what it replaced, say so; if there was no such step, say so plainly and stay with the checklist | F8's clear-written-communication line. JD because the JD lists it |

### E. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you for this role?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" and "Wrote the release checklist our QA team still uses" and "Presented the monthly retention numbers to the studio head" | Pause, restate, answer. Hold: the calendar, the checklist and the retention numbers, in those words. Hold through two follow-ups. Concede specifically if pushed on purchases: "I've never worked on a game with in-app purchases." Do not fold on the core claim just to restore harmony | F4, F6 and F7 carry the case; F9 is what the concession is about. EXP because it tests composure |
| E2 | "That calendar. How much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Anchor in the sentence: you ran it. Answer slot: if parts were shared or set by others, say which and what was yours; if it was all yours, say so plainly. Hold through two follow-ups by returning to the sentence, not by adding to it | F1 and F6. EXP because it is the attribution probe |

### G. Peer Evaluator (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our teams sit side by side. Where's the seam between live ops and engineering, and what happens when we disagree?" | JD | [generic] | Propose seam principles instead of claiming to know theirs: who owns the date, who owns the scope, who decides when they collide, and how that is recorded. Make no claim about your past | F2's engineering line. Generic because it makes no claim about this employer or you |
| G2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Answer in principle: name the contribution of each team in the record and in the review. Answer slot: if you have a real example of work spanning teams, say what happened in your own words; if not, say so plainly and stay with the principle | F2. EXP because it scores collegial attribution |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| Plan and run the live-events calendar for two titles (F1) | A1, A5, E2 |
| Coordinate design, art, engineering and community (F2) | A4, B3, G1, G2 |
| Own the post-event review and the KPIs (F3) | C2, C3 |
| Manage the release checklist with QA (F4) | A2 |
| 3+ years producing live-service games or apps (F5) | B4, D1 |
| Experience running a content calendar (F6) | A1, D1, E1 |
| Comfortable with player-retention metrics (F7) | A3, C1, C3 |
| Clear written communication (F8) | D3 |
| Purchase metrics, a role-family expectation (F9) | B1, B2 |
| Company and strategy knowledge (CO) | none, because no research ran, so a CO question would be generic padding |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What do you want me to have learned by day 30 about how your titles' events are planned and measured?" | It shows a ramp-up mindset without claiming experience you do not have |
| 2 | "How does the post-event review work today: who attends, and which KPIs does it report?" | It goes straight at the JD's review and KPI line |
| 3 | "Where do events most often slip: in art, engineering or sign-off, and what do you want the producer to catch earlier?" | It signals you think about coordination as catching problems early |
| 4 | "How are the two titles' calendars kept from colliding today?" | It tests how they run the JD's two-titles line |
| 5 | "How does the release checklist work with QA now, and what would you change?" | It connects to the checklist you wrote without claiming more about it |
| 6 | "Beyond retention, which metrics does the team look at most?" | It opens the purchase-metrics topic on your terms and shows you want to learn it |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team | Negative the candidate stated, F2 | "I've never led a team." No slot |
| Has worked on a game with in-app purchases or owned purchase metrics | Negative the candidate stated, F9 | "I've never worked on a game with in-app purchases." No slot |
| Ran live events or time-limited events | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says a weekly content-drop calendar, not events. A1 and A5's slots stay inside the calendar |
| Ran live-service games for four years | Inflated form of F5 | F5's quotes at their own scope. The material says four years as an associate producer and two years on the weekly calendar |
| Owned the KPIs or the post-event review | Inflated form of F3 | F3's quote at its own scope. The material says presenting the monthly numbers |
| Managed the release checklist across releases | Inflated form of F4 | F4's quote at its own scope. The material says writing the checklist |

## Sources

Provided documents: the JD text; your message with your background. No `tuesday-dossier.md` was present.

Searches sent (all refused, none returned a result):

- "Saltmarsh Games values": refused
- "Saltmarsh Games interview process live operations producer": refused
- "Saltmarsh Games mobile studio strategy news": refused
- "Tobias Wrenfield Saltmarsh Games": refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Would have fed a values-style round check and VAL questions; no values-style round is assumed without a source |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | Would have moved the loop and persona weights; they rest on your own description of the session |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | Would have grounded CO and CASE questions in the company's priorities; those banks are generic |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Would have produced an interviewer read and a reverse question tied to his path; both are absent |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Search permission → an interviewer read, persona weights adjusted from his public footprint, a reverse question tied to his path, and CO and CASE questions grounded in the company's own strategy. A deeper pass is also available once searches are permitted: up to 6 more searches and 2 more fetches, several more minutes, run only if you say yes
- The recruiter's prep note → the round type, any focus areas or pre-declared deliverable, and whether Tobias is your future manager, which reweights every bank
- Your own answers to the answer slots on F1, F2, F3 and F5, stated in your own words → those rows upgrade from discovery toward grounded evidence and the guidance gets more of your own story
- An anonymized copy of the release checklist, or a retention report page you presented → F4, F7 and F8 can move from medium or low toward high
- A `tuesday-dossier.md` → verified evidence and prohibited claims from an earlier pass would replace the ones built locally here; never required
- Your full CV → the fit snapshot would quote it directly instead of your message
