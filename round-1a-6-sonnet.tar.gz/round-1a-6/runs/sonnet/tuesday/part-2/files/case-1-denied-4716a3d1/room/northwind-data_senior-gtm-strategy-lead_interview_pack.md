# Interview prep pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy. **Relationship:** peer; both report to the same VP. **Round:** one 60-minute conversation, per the coach's notes. No recruiter focus areas or pre-declared deliverable are known.

## How to use this pack

Personas describe how a question arrives; types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and rehearse only what you actually did.

| Type tag | Meaning |
|---|---|
| EXP | Work-experience deep-dive: do the claims survive scrutiny, and what was actually yours |
| JD | Role and JD-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge: can you think at Northwind's altitude |
| CASE | Live problem from the actual role: structure and reasoning |
| VAL | Values alignment. No question here carries it: no values-style round is documented for this loop and no published Northwind values are in hand, so none is detected |

Provenance labels: `[grounded]` traces to a provided document, `[inferred]` is derived and the derivation is named, `[generic]` is a pattern with no claim about this candidate or this company. Every fit-snapshot quote comes from the coach's notes, not from Priya's CV, which the pack has not seen.

**Highest-ROI prep: D1.** Dan runs sales strategy, and the stated gap is classic sales-ops and quota-setting experience. Expect the question in some form. Rehearse the plain acknowledgment until it is boring.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, the coach's notes | "9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [inferred] | transferability | Your material says product strategy and ops work, not GTM for new lines, with nothing inspected behind it, and the words stay there: "I spent nine years in product strategy and ops at a large consumer-tech company." Answer slot: the JD's two-new-lines wording makes a probe on new offerings likely. If any of that work concerned a new offering, say which and what your part was, in your own words; if none did, or it was not yours, say so plainly and stay with the strategy and ops work |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, the coach's notes | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [inferred] | transferability | Your material says you proposed a change and that it was credited with an uplift, nothing about customer lifecycle stages, and nothing is inspected behind the figure. The words stay at that scope: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." Answer slot: the JD's lifecycle wording makes a probe on which part of the customer's path the change touched likely. If it touched one, say which; if it did not, say so plainly and stay with the change you proposed |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, the coach's notes | "skilled in SQL/Tableau" — the coach's notes | low | [inferred] | discovery | A skill statement, not an analysis, so nothing here says what was built. Answer slot: if you have used SQL or Tableau for a piece of work, say which tool and what question it answered; if your use was limited, say so plainly and say what you would do first with Northwind's data |
| F4 | "partner-motion design experience required" — JD highlights, the coach's notes | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [inferred] | transferability | Your material says a revenue model that was used in negotiations, not a designed motion, with nothing inspected behind it. The words stay at that scope: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: the JD's partner-motion wording makes a probe on what you shaped likely. If the model shaped any terms or structure, say which and how, in your own words; if it informed discussions others led, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights, the coach's notes | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | none | No gap, but a coach's-notes line with nothing inspected behind it, so expect a probe. Lead in the quote's own terms: you set annual volume targets, with consensus across organisations |
| F6 | "AI experience a plus" — JD highlights, the coach's notes | "uses AI tools daily" — the coach's notes | low | [inferred] | discovery | Daily use is stated; what for is not. Answer slot: name the tools and one thing you used them for; if the use is mostly drafting or search, say so plainly. Nothing here supports a claim to have built or led anything with AI |
| F7 | Sales-ops mechanics such as quotas, implied by the interviewer's function (Director of Sales Strategy), not stated in the JD highlights | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [generic] | capability | A gap the coach stated. Words: "I don't have classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |

No requirement in the JD highlights is a gate. Pay, location, authorization and travel terms are not in the notes, so no gate row exists.

## Reading the interviewer

Public-professional signals as supplied in the coach's notes; no search could run (see Sources).

| Signal | Source | Practical implication |
|---|---|---|
| Self-described "relentlessly data-driven" | The interviewer's profile, via the coach's notes | Every number you cite will be probed to its inputs. Know what you can and cannot say about how each figure was counted, and say plainly when you do not know |
| Career spine of "pricing and monetization roles" | The interviewer's profile, via the coach's notes | Case questions will likely arrive in pricing, packaging and unit-economics terms. Say the framework aloud and the hypothesis early |
| One early-stage-startup chapter | The interviewer's profile, via the coach's notes | Expect a probe on pace and scrappiness. The pack holds no quote of yours about startup-style work, so none is coached |
| Peer, same VP | The coach's notes | He is pricing what you cost and add to his own work. Seam, turf and credit questions return in collegial packaging |

**Mirror opportunity (shared vocabulary, not a shared jump):** his path is monetization; F4 carries your side in your own sentence: "built a partner-level revenue model used in carrier negotiations". Use that sentence at its own scope if the revenue-modeling vocabulary comes up; do not stretch it to pricing, which your notes do not state. No quote carries your side of the startup chapter, so it is not offered as a mirror.

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober (A, 5 questions) | Line-by-line probing of the ARR figure, the revenue model and the SQL/Tableau claim | Highest. His own "relentlessly data-driven" is the sharpest signal in the notes, and the peer prior also puts a prober near the top | Know how each figure was counted, name the assumption you would defend least before he does, say plainly when you do not know. Applies to F2, F3, F4 |
| Peer Evaluator (B, 4 questions) | Seam-splitting between sales strategy and emerging-products GTM; credit-sharing; what you need from his team | High. Peer relationship, same VP | Reciprocity: say what you would bring his team, propose seam principles rather than pretending to know the seam, and use F5's sentence at its own scope for disagreement style |
| Case / Strategist (C, 3 questions) | Whitespace, pricing and packaging, and the bundling threat posed live | Mid. His pricing and monetization spine tilts cases toward packaging and unit economics, but this is a peer conversation, not a hiring-manager case round | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic (D, 3 questions) | Quiet probing of the sales-ops gap, partner-motion depth and the day-one weakness | Mid. F7 is a stated gap and a Director of Sales Strategy is its natural owner | Rehearse D1 until it is boring; bridge only from what the quotes carry; calibrated candor over bluffing a competency he owns |
| Conversational (E, 2 questions) | The biography opener and a casual question about AI | Low-mid. A single 60-minute conversation usually opens loosely, and "AI experience a plus" is the kind of topic asked casually | A 90-second arc built from the two quoted chapters; treat the casual AI question as scored |
| Pressure (F, 2 questions) | Time-boxed challenges on the ARR attribution and "why you" | Low. Peers rarely run stress rounds; included because both targets are the most likely places for a hard push | Pause, restate, hold through two follow-ups, concede specifically |
| Values / Behavioral (not banked) | — | Dropped: no values-style round is documented for this loop and no published values are in hand | — |

## Question banks

### A. Data-Driven Prober (weight 1)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR number was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Say the sentence at its own scope first: you proposed the change, and it was credited with the uplift. Answer slot: how the figure was counted, in your own words; if you do not know how it was counted, say so plainly. Answer slot: what the figure is sensitive to, and the assumption behind it you would defend least; name it before he asks. Answer slot: which part was yours; if the credit was shared or assigned by someone else, say so. Never explain a method you cannot repeat under a second question | F2 is the headline metric, and a prober's first target; EXP because it tests attribution and counting honesty, not the role |
| A2 | "What went into the partner-level revenue model, and which input would you trust least?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Say the sentence at its own scope: you built a partner-level revenue model, and it was used in carrier negotiations. Answer slot: the main inputs, in your own words; if you do not remember them, say so plainly. Answer slot: the input you would trust least, named before he does. Answer slot: how the model was used in the negotiations; if you were not in the room, say so | F4 is the only partner evidence and the likeliest place for a prober to dig; EXP because it scores what the model actually was |
| A3 | "Tell me about an analysis you ran yourself in SQL or Tableau." | JD | [inferred] "skilled in SQL/Tableau" | Selection scaffold: pick one analysis where you wrote the query or built the view yourself; it needs the question it answered, the data source, and what was decided or changed after. Hold it to what you can defend line by line. If no such analysis comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach a first Northwind analysis | F3 is low-confidence and the JD names the requirement; JD because it scores the stated qualification, and the open prompt avoids presupposing an analysis |
| A4 | "Everyone says they are data-driven. When has the data told you not to do something you wanted to do?" | EXP | [generic] | Selection scaffold: pick a time a number contradicted your own preference; it needs the number, what you wanted, what you did, and whether the relationship survived. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Do not manufacture a reversal | His self-description raises the theme; EXP because it asks for a past instance; `[generic]` because the pack holds no quote that carries such a story |
| A5 | "You set annual volume targets with cross-org consensus. Where did the data stop and the negotiation start?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Say the sentence at its own scope: annual volume targets, set with consensus across organisations. Answer slot: how the starting numbers were derived, in your own words; if you did not derive them, say so plainly. Answer slot: where people disagreed and what you did; if there was little disagreement, say so | F5 is the evidence for the cross-functional requirement; EXP because the prober tests where analysis ended and persuasion began |

### B. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where do you think the seam is between sales strategy and GTM strategy for new products, and what happens when we disagree?" | JD | [grounded] "set annual volume targets with cross-org consensus" | Propose principles rather than pretending to know the seam; ask him how it works today before giving yours. For how you handle disagreement, use the quoted sentence at its own scope: targets set, with consensus across organisations. Answer slot: how you got there when people disagreed, in your own words; if they rarely did, say so | The role sits beside his; JD because it scores the cross-functional requirement (F5); the peer persona's own stem |
| B2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Open prompt: choose an instance. Where the instance is the quoted one, say the sentence at its own scope: you proposed the change, and it was credited with the uplift. Answer slot: who credited it and whether others' work fed it; if you do not know, say so plainly. Show tact and spine together | The persona's stem; F2's "credited with" invites this probe; EXP because it scores attribution with equals |
| B3 | "What would you need from my team in your first 90 days, and what could you give us?" | JD | [generic] | Reciprocity: lead with a short list of what you would ask, then what you could offer as an offer to build, not a past claim. Any offer about modeling rests only on the revenue-model sentence at its own scope (F4); nothing about your past goes beyond it | Peers price what the hire costs and adds; JD because it scores partnership fit with the role; `[generic]` because it asserts nothing about you |
| B4 | "You will own the GTM for two new lines and I will be looking at some of the same accounts. Walk me through your first 30 days." | JD | [inferred] "9 at a large consumer-tech company in product strategy & ops" | A plan, not a past: clarify what each line is and who owns what already, state what you would look at first, name the seam conversations you would have with him early. Use the quoted background only as your starting point, at its own scope. Answer slot: if any of that background was work on a new offering, say what your part was; if none was, say so plainly | The JD's two-new-lines wording (F1); JD because it scores the headline responsibility, with CASE delivery |

### C. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Enterprise expansion is a stated priority, and a much larger platform vendor is bundling. Where would you look for whitespace first across land, adopt, expand and renew?" | CASE | [grounded] the coach's research note: priorities of enterprise expansion, the Compass launch and profitability; bundling by a much larger platform vendor | Clarify first: which segments are exposed to the bundle, and what each stage is measured on. Then objective, segmentation, approach, metrics, risks. Name the cuts you would pull in SQL and the Tableau view you would want. Challenge one premise respectfully. No claim about your past | F2's requirement, set in the company's own stated context; CASE with CO because it uses Northwind's current priorities. Freshness of the note is unverified |
| C2 | "Should Compass be priced standalone, packaged into an existing tier, or priced on usage? What would make you change your mind?" | CASE | [generic] | Structure aloud: what you need to know first (who buys, what it replaces, how the bundle changes the alternative), then a hypothesis, then the evidence that would flip it. Hold the thesis and concede the one thing that would change it. Do not assert facts about Compass's actual pricing | His pricing spine makes this his native ground; CASE because it is a live decision; `[generic]` because no Compass pricing facts are in hand |
| C3 | "A bigger platform vendor bundles something free that competes with your new line. Sixty seconds: why should a customer still pay us?" | CO | [grounded] the coach's research note: bundling by a much larger platform vendor | Segment before answering: customers for whom the bundle is good enough, and those for whom it is not. Bring one consensus point to prove grounding, then one thesis-driven divergence with its concession. State what you would need to find out. No facts about Northwind's differentiation beyond the note | The note names bundling as the main competitive threat; CO with a Pressure-style time box; the pack differentiates from the consensus answer rather than reciting it |

### D. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Your background does not include classic sales-ops or quota-setting work. How would you work with my team on quotas and coverage for a new product line?" | JD | [grounded] "No classic sales-ops or quota-setting experience." and "set annual volume targets with cross-org consensus" | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment: "I don't have classic sales-ops or quota-setting experience." Then the adjacent quote at its own scope: "I set annual volume targets with cross-org consensus." The pack's observation, not words for you: your material says volume targets, not quotas. Then a plan, said as future: what you would ask his team first and which planning cycle you would learn from. Follow-up one, "targets are not quotas": agree they are different and stay with what the sentence says. Follow-up two, "why not hire someone from sales ops": concede the real gap and restate the plan; do not add experience. Hold, then concede | F7 is the stated gap and he owns the function it points at; JD because it tests the role's fit; the deepest rehearsal means the most follow-ups and exact concession wording, with no more affirmative content than the quotes carry |
| D2 | "What part of a partner motion have you owned yourself?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | The hold is only what the quote carries: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: if any part of the structure or terms was yours to shape, say which and how you decided, in your own words; if none was, say so plainly and describe how the model was used. Hold through two follow-ups by returning to the model, never by adding to it | F4 is where the JD's "required" wording presses hardest, so the objection arrives in some form; JD because it scores the stated requirement |
| D3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience." | Calibrated candor, not bluffing: name the gap you have stated, in the plain acknowledgment "I don't have classic sales-ops or quota-setting experience", then say how you would close it, as a plan. A second answer, if pressed, comes from your own judgment; the pack will not name a second weakness for you | The persona's stem; JD because it scores honest self-assessment against the listed job |

### E. Conversational (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm" and "9 at a large consumer-tech company in product strategy & ops" | A 90-second arc of two chapters, each at its own scope: consulting, then product strategy and ops at the consumer-tech company. Answer slot: why this move, in your own words; if you have no settled reason yet, say what you are still weighing. Do not add roles or scope the quotes do not carry | Opening questions are scored; EXP because it tests whether the story hangs together; F1 is the row it draws on |
| E2 | "What are you actually playing with in AI these days?" | JD | [inferred] "uses AI tools daily" | Answer slot: name the tools and one thing you used them for; if the use is mostly drafting or search, say so plainly. Then ask him what Compass makes of the topic internally. Nothing here supports a claim to have built or led anything with AI | The JD lists AI as a plus, and casual-register questions on a plus are still scored; JD because it scores that line (F6) |

### F. Pressure (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "That ~$400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause and restate. Hold the quoted sentence at its own scope: you proposed the change, and it was credited with the uplift. Answer slot: what part of the delivery or measurement was yours; if none was, say so plainly. Hold through two follow-ups, then concede one specific uncertainty, such as how the figure was counted if you do not know. Never claim you drove or owned the uplift | The persona's stem on F2, the one number Dan will test; EXP because it scores attribution under pressure |
| F2 | "Sixty seconds: why you rather than someone from enterprise sales strategy?" | JD | [grounded] "set annual volume targets with cross-org consensus", "built a partner-level revenue model used in carrier negotiations" and "No classic sales-ops or quota-setting experience." | Three beats and stop. First the stated gap: "I don't have classic sales-ops or quota-setting experience." Then the two quoted sentences at their own scope. Do not add what they prove; let him draw the inference. Hold through a follow-up, then concede the gap again rather than widening the quotes | The persona's stem pointed at the stated gap (F7) against F4 and F5; JD because it scores fit against the listed job |

## Requirement coverage

| Requirement | Questions covering it |
|---|---|
| own GTM strategy for two new product lines | B4, C1, C2, C3 |
| identify whitespace across land/adopt/expand/renew | C1 |
| run independent analysis in SQL and Tableau | A3, C1 |
| partner-motion design experience required | A2, D2 |
| strong cross-functional influence | A5, B1, B2 |
| AI experience a plus | E2, C2 |
| Sales-ops mechanics, implied by his function | D1, D3, F2 |
| Defend the headline number (~$400M) | A1, F1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You have spent your career in pricing and monetization roles, with one startup chapter. What did that chapter change about how you think about sales strategy for a new product?" | Ties to his own path, which turns an interrogation into a peer conversation and shows the research was on him |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer: it shows you are thinking about his load, not only yours |
| R3 | "Where does your team's remit end and this role's begin for the two new lines, and who decides when it blurs?" | Surfaces the seam directly, which a peer evaluator is already testing you on |
| R4 | "When you judge whether an emerging product is landing, which numbers do you look at first?" | Speaks to his data-driven self-description and tells you what you will be measured against |
| R5 | "How is bundling by the larger platform vendor showing up in the conversations your team is having today?" | Uses the research note's competitive threat and gets live information no page gives you |
| R6 | "How do the profitability goal and the Compass launch change what is expected of new lines in their first year?" | Ties the role to two stated priorities and signals commercial judgment |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has set quotas or run sales operations | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I don't have classic sales-ops or quota-setting experience." No slot |
| Calling the annual volume targets quotas | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation: your material says volume targets, not quotas |
| Designed or led a partner motion, or led the carrier negotiations | Inflated form of F4 | F4's quote at its own scope: a model used in negotiations. D2's slot stays inside the model |
| Drove or owned the ~$400M ARR uplift | Inflated form of F2 | F2's quote at its own scope: proposed, and credited with. A1 and F1 slots stay with counting and attribution |
| Owned GTM for new product lines | Inflated form of F1 | F1's quote at its own scope: product strategy and ops. B4's slot stays inside that work |
| Built or led AI products or initiatives | Inflated form of F6 | F6's quote at its own scope: daily use of AI tools. E2's slot asks only what for |

## Sources

Provided documents: the coach's notes (JD highlights, candidate summary, interviewer profile summary, research note on Northwind's three stated priorities and the bundling threat). Neither the full JD nor Priya's CV was seen.

Searches sent, all refused (permission not granted), so nothing was returned and nothing from outside the notes is used:

- "Northwind Data company values principles" — refused
- "Northwind Data Compass AI copilot launch strategy" — refused (aimed at checking the pasted research note)
- "Dan Kovac Director of Sales Strategy Northwind Data" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | Search refused. Would have supplied published value names for VAL theming; no values-style round is documented, so no cheat sheet exists either way |
| 2. `Northwind Data interview process {role family}` | skipped | The coach's notes fix the loop: one 60-minute conversation with a peer, so persona weights follow the stated relationship |
| 3. `Northwind Data strategy` / recent news | unavailable | Search refused. Would have checked the pasted research note's currency and refreshed the CO and CASE grounding; the note's date is unknown |
| 4. `Dan Kovac Northwind Data` | unavailable | Search refused. Would have added his public talks and writing to the interviewer read and to R1 |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights supplied fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full JD text → the F1 to F6 requirement quotes become the JD's own wording, and any mid-list requirement missing from the highlights gets a question
- Priya's CV lines, verbatim → the evidence column quotes her CV rather than the coach's notes, and answers that are now slots can become story maps
- Priya's answers to the answer slots (A1, A2, D2, F1 above all) → the rows that draw on them regenerate with her own words
- The readout or finance memo behind the ~$400M credit → F2's confidence can rise from `medium` to `high`
- The recruiter's prep email, or any stated focus areas or pre-work → coverage of any announced deliverable
- Dan's public talks or posts, as links → a sharper interviewer read and a reverse question tied to his own themes
- Search access, then a dated Northwind strategy source → fresher CO and CASE grounding; an optional deeper pass of up to 6 more searches and 2 more fetches would add a grounding brief, several more minutes
- A `tuesday-dossier.md`, if one exists → verified evidence, the objection chosen from evidence rather than inference, and absolute prohibited claims
