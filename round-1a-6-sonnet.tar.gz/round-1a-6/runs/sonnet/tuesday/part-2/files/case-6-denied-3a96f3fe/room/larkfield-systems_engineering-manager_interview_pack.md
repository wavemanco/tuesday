# Interview prep pack: Engineering Manager, Larkfield Systems (three-round loop)

**Candidate:** Yusuf. **Mode:** loop, three scheduled rounds. **Built on:** your message alone: the one-line role description, the three rounds, and your background. No full JD text, no CV, no interviewer names, and no company research (the searches were refused; see Sources).

| Round | When | Who | Length | Relationship |
|---|---|---|---|---|
| 1 | Tuesday | Director of Engineering | 45 min | Hiring manager, your would-be boss |
| 2 | The Thursday after | Two staff engineers and a product manager | 60 min | Panel |
| 3 | The following Monday | VP Engineering | 30 min | Described by the recruiter as "values and leadership philosophy" |

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: every sentence about your past is a quote from your own message, and wherever the material is silent the guidance is an answer slot for you to fill in your own words or to answer "no, not mine". Question IDs read round, persona letter, number (1A2 is round 1, bank A, question 2).

| Type | What it is really testing |
|---|---|
| VAL | Behavioral and values alignment: past behavior, not generic virtue |
| EXP | Work-experience deep-dive: whether your claims survive scrutiny and what was actually yours |
| JD | Role and JD-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem from the role, solved aloud |

## Prep triage

The same three or four stories will be heard by all three rounds, and interviewers compare notes. Tell each one the same way, at the same scope.

1. Before Tuesday: 1A2 first (the pack's highest-ROI rehearsal), then 1A1, 1A3, 1C1, 1C2. Read the fit snapshot and the prohibited claims once.
2. Before Thursday: 2A2, 2B1, 2B2, 2B3, 2A1, 2D1.
3. Before Monday: 3C1, 3C2, 3A1, 3A3, 3A4, then 3B2 once you have read the company's own material.
4. Everything else is insurance.

## Fit snapshot (shared across all three rounds)

The role description gave one sentence of requirements, so there are seven rows. Requirements are quoted from that sentence; evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads" — your message (role description) | "9 years engineering, 3 as a team lead of 6" — your message; "I've never managed managers" — your message | medium | [grounded] | transferability | Your material shows a team lead of 6 and a stated limit, and it does not say whether the two squads have their own leads. Words at that scope: "I've spent 3 of my 9 years in engineering as a team lead of 6" and "I've never managed managers." Answer slot: the "two squads" line makes a probe on how you would split attention likely. If you have ever had to split your attention across more than one team or group, say what you did, in your own words; if you have not, say so plainly and stay with how you would approach it |
| F2 | "own delivery" — your message (role description) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | The sentence shows a quarter pushed through and an on-call figure that dropped after it. It does not say you owned the team's delivery overall, and it does not say the quarter caused the drop. Words at that scope: "I pushed a reliability quarter through against roadmap pressure, and my team's on-call burden dropped 60% after." Answer slot: the "own delivery" line makes a probe on who made the call likely. If the decision to run the quarter was yours, say how you made it and who you took it to; if it was set or agreed by others, or there was no such decision, say so plainly and stay with the sentence |
| F3 | "hiring" — your message (role description) | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | none | A quote that already reaches hiring in role-relevant terms, with nothing inspected behind it, so expect a probe. Lead with it in its own terms: you run the loop, and about 40 is a count of interviews. The sentence says backend roles, and the role description does not say which roles this job hires |
| F4 | "growth for 11 engineers" — your message (role description) | none given | none | [grounded] | discovery | Your material says nothing on developing people. Answer slot: the "growth" line makes a probe on your actual practice likely. If you have developed anyone on your team, say who and what you did, in your own words; if you have not, or it was not yours to do, say so plainly and say how you would begin with the first conversation |
| F5 | "partner with hardware and product on roadmap" (hardware side) — your message (role description) | "never owned a hardware-adjacent roadmap" — your message | none | [grounded] | capability | A limit you stated, and the role says partner where your sentence says own; the pack reads your sentence at its own scope and no wider. Words: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past |
| F6 | "partner with hardware and product on roadmap" (product side) — your message (role description) | "I pushed a reliability quarter through against roadmap pressure" — your message | low | [inferred] | discovery | The sentence touches roadmap trade-offs and does not say with whom; linking it to product is this pack's derivation. Answer slot: the "product on roadmap" line makes a probe on a product partner likely. If product was part of that conversation, say how you made your case; if the pressure came from elsewhere, or there was no product partner in it, say so plainly and stay with the sentence |
| F7 | "building device-management services" — your message (role description) | none given | none | [grounded] | discovery | Your material says nothing on device-related work. Answer slot: the line makes a probe on the nearest thing you have built likely. If any of your services dealt with devices, say which and what your part was; if none did, say so plainly and say what you would learn first |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| "Lead two squads" (F1) | 1A3, 3A4, 3C1 |
| "building device-management services" (F7) | 2B3, 3B1 |
| "own delivery" (F2) | 1B1, 1B2, 2A2, 3A2, 3C2 |
| "hiring" (F3) | 1C2, 3A3 |
| "growth for 11 engineers" (F4) | 1B3, 3A4 |
| "partner with hardware and product on roadmap", hardware side (F5) | 1A1, 1A2, 2A4 |
| "partner with hardware and product on roadmap", product side (F6) | 2A1, 2A2, 2A3 |

## Round 1: Director of Engineering (hiring manager), Tuesday

### Persona weights

Loop source: your own words establish the three sessions and who runs each. No documented company loop was found, so these weights rest on the relationship priors for a hiring-manager round and on the gaps in the fit snapshot. No interviewer profile exists, so there are no signal adjustments.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the gaps: hardware, managing managers, why now | High. A hiring manager is derisking gaps, and F1 and F5 are limits you stated yourself | Rehearse the most predictable objection until it is boring; bridge only from evidence you stated; give a ramp plan; calibrated candor over bluffing a competency they may own |
| Case/Strategist | Live problems from their roadmap: re-plan, prioritize, develop people | High to medium. Hiring-manager prior, and "own delivery" and "growth" invite live problems | Clarify, objective, approach, metrics, risks; challenge one premise respectfully |
| Data-Driven Prober | Reads your numbers line by line | Medium. Two figures in your message are probe targets: 60% and about 40 interviews | Know how each figure was counted; name the weakest assumption before they do |

### Bank A: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1A1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "never owned a hardware-adjacent roadmap" | Name it before they do, in the quote's own terms: "I've never owned a hardware-adjacent roadmap." Then give what you would do about it as a plan and never as a past: who you would sit with first and what you would ask them, in your own words. Stop at the plan. Keep it under ninety seconds, calm, close to boring | F5 is the stated gap the role presses hardest, so the Skeptic opener lands there. JD because it scores the partnership line; this is the persona stem used as written |
| 1A2 | "You've told us you haven't owned a hardware-adjacent roadmap. How would you partner with the hardware team on this one?" | JD | [grounded] "never owned a hardware-adjacent roadmap" | The highest-ROI rehearsal in this pack. Hold only what the quote carries and say it first: "I've never owned a hardware-adjacent roadmap." Then give your approach as a method: what you would want to learn from hardware in the first weeks, and what you would ask product and hardware to agree on, in your own words. Rehearse three follow-up levels: how you would handle a hardware date that moves; what you would need from the Director; which part you would not pretend to know. Concede the limit at each level and never bridge with hardware work you have not stated. Answer slot: the "partner with hardware" line makes a probe on any hardware contact likely. If you have worked alongside a hardware or embedded team, say how and what your part was, in your own words; if you have not, or it was not yours, say so plainly and return to the method | F5 is a stated gap and the likeliest question to arrive in some form, so a rehearsed non-defensive answer changes the interview. JD because it scores the partner line; Skeptic delivery because it probes the gap |
| 1A3 | "You've told us you haven't managed managers. How would you lead two squads at once?" | JD | [grounded] "I've never managed managers"; "9 years engineering, 3 as a team lead of 6" | Say what you can stand on at its scope: "I've spent 3 of my 9 years in engineering as a team lead of 6." Say the limit: "I've never managed managers." Then give how you would approach two squads as a method: how you would learn each squad's state and set expectations with the Director, in your own words. Answer slot: the "two squads" line makes a probe on splitting attention likely. If you have had to split your attention across more than one team or group, say what you did; if you have not, say so plainly and stay with the method. Asking whether the squads already have leads is a fair part of the answer | F1 holds both the evidence and the limit. JD because it scores "Lead two squads"; the interviewer is pricing the step from one team to two |
| 1A4 | "Why this role, why now, and why industrial IoT?" | EXP | [generic] | The pack does not know your reasons and supplies none. Give your actual reasons in your own words, in two or three sentences, about what you are moving toward in the role as described: "Lead two squads building device-management services". Do not criticize your current employer unprompted. If one of the three parts has no real answer yet, say so plainly rather than inventing one | Motivation consistency is what the Skeptic scores; EXP because it tests whether your story survives cross-examination. No history is cited |

### Bank B: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1B1 | "Two squads depend on a hardware release, and the date just moved up by four weeks. Walk me through how you re-plan." | CASE | [generic] | Clarify first: what is fixed, scope or date or quality; which squad is affected; what product needs. State the objective, lay out options with their trade-offs, say who you talk to in what order, and name a risk and a check-in. Challenge one premise respectfully, for example whether the new date is firm. The question needs no claim about your past, so the guidance makes none | A live problem set in the role's hardware and delivery lines (F2, F5); `[generic]` because it is a pattern for the problem, not a fact about this employer |
| 1B2 | "A service has become noisy for on-call and the roadmap is full. How do you decide what to do?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Structure it: who is affected and how badly, what the roadmap holds and who owns it, your criteria, your options, how you would take it to product, how you would measure it. If you reach for your own example, stay with the sentence: "I pushed a reliability quarter through against roadmap pressure" and the on-call figure dropped "after", which is an ordering and not a cause. Answer slot: the "own delivery" line makes a probe on who made the call likely. If the decision to run the quarter was yours, say how you made it and who you took it to, in your own words; if it was set or agreed by others, or there was no such decision, say so plainly and stay with the sentence | F2 is the nearest evidence for the delivery line. CASE because it is a live decision problem, with EXP content if you use your own example |
| 1B3 | "You'd have 11 engineers across two squads. How do you decide where to invest in each person's growth?" | JD | [grounded] | Structure it: how you would learn each person's goals and gaps before deciding, how you would weigh team need against individual need, how you would check it is working. Answer slot: the "growth for 11 engineers" line makes a probe on your actual practice likely. If you have developed anyone on your team, say who and what you did, in your own words; if you have not, or it was not yours to do, say so plainly and say how you would begin with the first conversation | F4 is the one requirement with nothing in your material behind it, so a hiring manager will test it. The theme comes from the role description's own line |

### Bank C: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1C1 | "Walk me through how the 60% on-call figure was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Four slots, each in your own words: how the figure was counted, what it is sensitive to, the assumption behind it you would defend least (name it before they do), and which part of the result was yours. Say the figure at its scope: your team's on-call burden dropped 60% after the quarter you pushed through. If you do not know how it was counted, say so plainly | F2's figure is the magnet target for a prober; EXP because it tests attribution |
| 1C2 | "What does 'about 40 interviews last year' count, and what was your part in the loop?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Say it at its scope: you run the loop, and about 40 counts interviews, not hires or candidates. Same four slots: how counted, what it is sensitive to, the assumption you would defend least, which part was yours. Answer slot: the "hiring" line makes a probe on who made the offer decision likely. If you decided or recommended who got an offer, say how, in your own words; if the decision sat with others, or the loop has no such step, say so plainly and stay with the loop you run | F3 is your strongest row, which is why a prober tests it. EXP because it tests what was actually yours |

### Reverse questions for round 1

| # | Question | Why it lands |
|---|---|---|
| 1 | "Do the two squads have their own leads today, or would I be the day-to-day lead for both?" | The role description does not say, F1 depends on it, and the answer tells you whether the managing-managers objection is live before Monday |
| 2 | "How do hardware dates and software dates get reconciled today, and where would you want my help most?" | It asks for the hardware seam instead of pretending to know it (F5) |
| 3 | "How are the squads' delivery commitments set and measured now, and who owns them?" | Probes the delivery line (F2) from the owner's side |
| 4 | "What would a good first 90 days look like to you?" | Your future boss's own scoring sheet, handed to you |
| 5 | "How do you like to work with your managers week to week, and what do you need from me?" | The boss relationship; it lets you adapt and signals reciprocity |
| 6 | "Is there anything in my background you'd want me to address?" | Turns the objection they may not say aloud into one you have rehearsed (1A2, 1A3) |

## Round 2: panel of two staff engineers and a product manager, Thursday

### Persona weights

Names and profiles are unknown, so personas cannot be assigned per panelist. The blend assumes the staff engineers lean Peer Evaluator and Data-Driven Prober and the product manager leans cross-functional (Values/Behavioral and Conversational). Correct this if you know otherwise.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Seam-splitting between roles, "what would you need from me", credit and disagreement | High. All three panelists work beside the person who would hold this job, and the role names product partnership | Reciprocity framing; propose seam principles rather than pretending to know the seam; show spine and tact together |
| Data-Driven Prober | Technical credibility, your numbers, how hands-on you were | Medium to high. Staff engineers test whether a manager can still talk shop, and your figures are in the room | Know how each figure was counted; say plainly where you do not know |
| Values/Behavioral | Scenario probes, often from outside the function | Medium. A product manager is cross-functional by relationship | Pick stories with a named stake; "we" for context, "I" for contribution |
| Conversational | Friendly opener that is still scored | Low. One question, but it sets the room | A 90-second arc built only from your own sentences |

### Bank A: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2A1 | "Our teams sit side by side with product. Where is the seam between an EM and a PM on the roadmap, and what happens when you two disagree?" | JD | [grounded] | Propose seam principles rather than claiming to know this seam: who decides the what and the why, who decides the how and the when, how a disagreement gets escalated. Lead with what you would bring the PM, then what you need. Answer slot: the "product on roadmap" line makes a probe on a real disagreement likely. If you have disagreed with a product partner over a roadmap, say what it was and how it ended, in your own words; if you have not, or there was no product partner, say so plainly and stay with the principles | F6 is `low` evidence, so this is where the PM tests it. The theme comes from the role description and the persona stem |
| 2A2 | "Walk me through the reliability quarter you pushed through against roadmap pressure." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Tell the beats the sentence states, in your own words: a reliability quarter, pushed through, against roadmap pressure, and an on-call burden that dropped 60% after. Answer slot: the "product on roadmap" line makes a probe on where the pressure came from likely. If product was part of that conversation, say how you made your case; if the pressure came from elsewhere, or the quarter was agreed and not pushed against anyone, say so plainly and stay with the sentence | F2 and F6 meet here. EXP because the panel cannot verify the story and can only probe it |
| 2A3 | "Product wants a feature this quarter, and your squad says the device service needs hardening first. What do you do?" | CASE | [generic] | Clarify what the deadline costs, what the hardening protects and what evidence exists for each side. State the objective, lay out options, say who decides what, and say how you would take it to the PM and to the staff engineers, separately and together. Challenge one premise, for example whether it must be either-or. It asks about no past, so the guidance claims none | A live problem from F6 and F2, with the PM as the likeliest asker; `[generic]` because it is a pattern |
| 2A4 | "What would you need from the staff engineers on these squads, and what would they get from you?" | JD | [generic] | Reciprocity first: lead with what they would get from you, then what you need from them. Choose only what you would actually offer, and state it as intent and not as history. Propose how you would find out the seam rather than asserting it, including the hardware side | The Peer Evaluator's core question; it also gives you a place to name F5 without being asked |

### Bank B: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2B1 | "How hands-on were you in that reliability quarter?" | EXP | [grounded] "I pushed a reliability quarter through against roadmap pressure" | Say how hands-on you were, in your own words. If your part was setting priorities and clearing the path rather than doing the work, say so plainly; if you did parts of the work, say which. Do not describe work you could not repeat under a second question | Staff engineers test whether a manager's claim has hands behind it (F2). EXP because it probes attribution |
| 2B2 | "Which assumption behind the 60% would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Name the weakest assumption in your own words before they do; the pack names none. If you do not know how the figure was counted, say so plainly. Keep the sentence's ordering: the burden dropped "after" the quarter, which is not a claim about cause unless you can support one | The weakest-assumption move turns a gotcha into a credibility gain (F2) |
| 2B3 | "Tell me about the nearest thing you've worked on to a device-management service." | JD | [grounded] | Pick the system whose job is closest to managing devices, say what it did and what your part was. If no such system comes to mind, say so plainly, then say how you would learn it. Your message shows no device-related work (F7), so this is the likeliest place to need the plain no | F7 is where the staff engineers know the domain and you may not. The theme comes from the role description's own line |

### Bank C: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [inferred] "I pushed a reliability quarter through against roadmap pressure" | Pick a time with a named stake, a moment you did not fold, and a relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. The nearest sentence you gave is the one quoted; your material does not show what was said, to whom, or how it ended, so tell those parts only if they are true and yours | A persona stem; the quote is the pack's derivation of a candidate story (F2), not a confirmed fit |
| 2C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a time the customer's need and an internal number pointed different ways, and name the stake, what you chose and what it cost. If none comes to mind, say so plainly, then give the nearest thing you actually did, or how you would handle it | A persona stem. No published company values were available to theme this, so it rehearses the style and not Larkfield's content |

### Bank D: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2D1 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I pushed a reliability quarter through against roadmap pressure"; "I run our hiring loop for backend roles" | A 90-second arc that uses only these sentences, in this order, in your own words. Then say why this role, using your actual reasons; the pack supplies none. Treat the casual register as scored | F1 to F3 supply the beats. A friendly opener is still the first impression the panel compares notes on |

### Reverse questions for round 2

| # | Question | Why it lands |
|---|---|---|
| 1 | "What could a new manager do in their first month that would genuinely help your squads?" | The reciprocity question for peers; it asks the engineers for their real need |
| 2 | "What is the hardest part of running these services day to day?" | The staff engineers can answer in their own domain, and it shows you where reliability matters here (F2) |
| 3 | "Can you give me a recent example of how engineering and product settled a roadmap disagreement here?" | Aimed at the PM; it tests the seam you will live in (F6) |
| 4 | "How do hardware dates reach your planning, and who tells you when they move?" | The hardware seam from the people who feel it (F5) |
| 5 | "What would you want a new manager to leave alone for the first 90 days?" | Shows respect for their turf, which a Peer Evaluator scores |
| 6 | "What is the on-call arrangement for these squads today?" | Asks for the real state instead of assuming it, and it is the thread your reliability sentence ties to (F2) |

## Round 3: VP Engineering, Monday

### Persona weights

The recruiter's description, "values and leadership philosophy" (your message), documents a values-style round, so Values/Behavioral leads. That the VP is the Director's boss is an assumption, not something you said; if it is wrong, the Case/Strategist and Pressure weights fall. Thirty minutes fits about four to six of these questions, so the triage above puts the most likely ones first.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Leadership philosophy, scenario probes, stories with a stake | High. It is the stated purpose of the round | "We" for context, "I" for contribution; only stories you can stand behind |
| Case/Strategist | Altitude questions: where to invest, how you think about the business | Medium. Executive prior; no company strategy material was available here | Clarify, objective, approach, metrics, risks; say what you would need to learn |
| Pressure | Time-boxed challenge: why you, how much was you | Medium. Executive prior, and two limits you stated sit in plain view (F1, F5) | Pause, restate, anchor in what you stated, hold through two follow-ups, concede specifically |

### Bank A: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3A1 | "What is your leadership philosophy, and where did it come from?" | VAL | [grounded] "I pushed a reliability quarter through against roadmap pressure" | State two or three principles in your own words and give each one decision you actually made that shows it. If a principle is about protecting reliability work under pressure, the sentence you can stand on is the one quoted; the principle itself is yours to word. If no decision comes to mind for one, say so plainly rather than supplying one | The theme is the recruiter's own words for this round. VAL because it scores whether past behavior shows the principle (F2) |
| 3A2 | "How do you handle a decision from above that you disagree with but still have to carry to your team?" | VAL | [generic] | Structure only: where you would voice the disagreement and to whom, how you would commit once it is decided, how you would explain the reason to your team without undermining it. If you reach for a real example, tell it only as it happened. It asks about no past, so the guidance claims none | Leadership philosophy asked as a hypothetical; it tests the same trait as a story question without needing one (F2) |
| 3A3 | "You run your hiring loop for backend roles. What do you look for, and what makes you say no?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Your criteria are yours to word; the pack supplies none. Say it at its scope: you run the loop, and about 40 counts interviews. Answer slot: the "hiring" line makes a probe on the last no likely. If a no was yours to give, say what decided it, in your own words; if the no belonged to others, or the loop has no such step, say so plainly and stay with your own criteria | F3 is your strongest row and the one a VP can probe on judgment and not on facts |
| 3A4 | "If one of the squads had a lead reporting to you, how would you coach them?" | VAL | [grounded] "I've never managed managers" | A method, in your own words: how you would learn what the lead needs, what you would leave to them, how you would check it is working. If asked directly, say first, plainly, "I've never managed managers." Answer slot: the "growth" line makes a probe on whether you have coached anyone likely. If you have developed anyone on your team, say who and what you did; if you have not, say so plainly and stay with the method | F1 and F4 meet here. The hypothetical presupposes nothing about your past; the slot covers the part your material is silent on |

### Bank B: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3B1 | "Where would you put your first two engineering investments on a device-management platform, and what would you need to know first?" | CASE | [generic] | Clarify first: what customers and the business need, the current state, the constraints from hardware and product. Then objective and segmentation, two bets with reasons, metrics, a risk. Say plainly that you would want the company's strategy and customer picture before committing. Challenge one premise respectfully, for example "two" or "first". It asks about no past | F7's domain at VP altitude; `[generic]` because no company strategy was researched |
| 3B2 | "What do you know about where we're headed, and what worries you about it?" | CO | [generic] | This pack has nothing on Larkfield's strategy, because web search was refused here, so the answer has to come from your own reading. Before Monday, read the company's own published material, state only what you have read, name where you read it, and say plainly where you have not looked | CO because it tests homework depth at executive altitude; generic by necessity, and the upgrade menu says what research would add |

### Bank C: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3C1 | "Sixty seconds: why you over someone who has already managed managers?" | JD | [grounded] "I've never managed managers"; "9 years engineering, 3 as a team lead of 6"; "I run our hiring loop for backend roles" | Pause, restate, then say the limit first, plainly: "I've never managed managers." Then what you can stand on at its scope: "I've spent 3 of my 9 years in engineering as a team lead of 6" and "I run our hiring loop for backend roles." Hold through two follow-ups and concede specifically that managing managers is a step you have not taken. Do not bridge with experience you have not stated. Why you rather than someone else is yours to say, from what you have actually done | F1 is the stated limit and the second-most-likely objection after the hardware one. JD because it scores the listed job, gaps included |
| 3C2 | "That reliability result: how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold the sentence: "I pushed a reliability quarter through against roadmap pressure," and the on-call burden dropped 60% after. Concede specifically which parts were your team's or others', in your own words. If asked a second time, repeat the concession and do not fold on the sentence. If you cannot say which part was yours, say that plainly | F2 is where a pressure interviewer tests attribution; EXP because that is what the question scores |

### Reverse questions for round 3

| # | Question | Why it lands |
|---|---|---|
| 1 | "What separates the engineering managers who have done well here from those who haven't?" | It asks the VP for their own definition of success in this round's terms: leadership |
| 2 | "What is the one thing you would want an EM in this organization to be unusually good at in the first year?" | Gives you the VP's scoring sheet in one answer |
| 3 | "How do engineering and hardware leadership make trade-offs together at your level?" | The hardware seam from the top (F5) |
| 4 | "What does the path look like from leading a squad to leading managers here?" | Addresses the managing-managers limit (F1) honestly and signals ambition without claiming experience |
| 5 | "What happens in this organization when a delivery commitment and a reliability concern collide?" | Ties to the thread your reliability sentence carries (F2) and shows you think in the same trade-off |

## Prohibited claims

Built before the banks from the fit snapshot, since no dossier was present. These are the claims a candidate reaches for under pressure and this pack will not coach.

| Not coached | Basis | Honest form |
|---|---|---|
| Managed managers, or led more than one team | Negative the candidate stated, F1 | "I've never managed managers." No answer slot |
| Led two squads or 11 engineers | Inflated form of F1 | F1's quote at its own scope: "3 as a team lead of 6". The limit is the pack's observation, not words for you: your material says a team lead of 6, not two squads or 11 engineers |
| Owned a hardware-adjacent roadmap | Negative the candidate stated, F5 | "I've never owned a hardware-adjacent roadmap." No answer slot |
| Owned the roadmap, or owned delivery overall | Inflated form of F2 | F2's quote at its own scope: you pushed a reliability quarter through against roadmap pressure. The pack's observation: the sentence says pushed through, not owned |
| The reliability quarter caused the 60% drop | Inflated form of F2 | The sentence's own ordering: the on-call burden dropped 60% after you pushed the quarter through |
| Owned hiring for a team, or made the hiring decisions | Inflated form of F3 | F3's quote at its own scope: you run the hiring loop for backend roles, and about 40 counts interviews |

## Sources

**Provided documents:** your message (the role description, the three rounds with their lengths and interviewers, the recruiter's description of round 3, and your background). No dossier was present.

**Searches sent, all refused, nothing returned:**

- "Larkfield Systems industrial IoT company values" — refused
- "Larkfield Systems interview process engineering manager" — refused
- "Larkfield Systems industrial IoT device management strategy news" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Would have moved the values cheat sheet, which is absent: round 3 is a values-style round by the recruiter's words, but no published values are in hand. VAL questions rest on persona stems and the recruiter's phrase only |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Would have checked the company's documented loop. The loop used here comes from your own words, so persona weights rest on relationship priors and your stated rounds |
| 3. `Larkfield Systems strategy` / recent news | unavailable | Would have moved the CO question 3B2 and the CASE framing in 3B1, which are generic |
| 4. `{interviewer name} Larkfield Systems` | n/a | No name was given, so there was no query to form; there is no interviewer read |
| 5. representative `Engineering Manager` JD | skipped | The role description you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Web search access in this session → the company's published values (a values cheat sheet for round 3 and named-value VAL questions), its documented interview loop, and a current strategy sweep for 3B2 and 3B1
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, which also needs web search → a strategy brief for the CO and CASE questions and recent organization context
- The full job description text → the seven rows here come from one sentence; a fuller text may add requirements and turn `[generic]` rows `[grounded]`
- Your CV → evidence beyond your message, which could turn the `discovery` rows F4, F6 and F7 into quoted evidence or confirm the gaps
- Your answers to the answer slots on F2, F4, F6 and F7, in your own words → those four rows and the guidance that draws on them regenerate on your quoted answers
- The names or public profiles of the Director, the panelists and the VP → an interviewer read, personas assigned per panelist, and a reverse question tied to each person's own path
- The recruiter's prep note for each round → coverage of any focus areas or pre-declared deliverables
- A `tuesday-dossier.md` from earlier work on this role → the highest-ROI objection and the prohibited claims would arrive evidence-derived instead of inferred from your message
