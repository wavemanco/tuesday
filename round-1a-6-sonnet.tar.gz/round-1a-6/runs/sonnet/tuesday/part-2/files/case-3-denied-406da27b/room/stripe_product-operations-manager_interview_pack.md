# Interview pack: Product Operations Manager, Stripe (final round)

Relationship to interviewer: not yet known. This pack blends personas for a final round whose sessions and interviewers are unknown.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether your own experience claims survive scrutiny |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company and can think at its altitude |
| CASE | Structure and reasoning on a live problem |

Nothing in this pack states a fact about your past or about Stripe, because neither your CV nor any research reached it. Every row is labeled `[generic]`: a rehearsal pattern for the role family. Where guidance asks for a story, it is a selection scaffold that ends with an honest branch.

## Fit snapshot (worksheet)

No CV, job description or recruiter wording was supplied, so every evidence cell is empty and every requirement is role-family prose, not a quote. Fill the evidence column yourself before the interview: one sentence per row that you could say truthfully.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinates launches or releases across product, engineering and go-to-market teams (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence looks like one named launch or release, your specific part in it, and who else was involved. Selection scaffold: pick a cross-team effort where your own part is easy to state in one sentence; if none comes to mind, say so plainly, then give the nearest work your material does carry, or how you would approach it |
| F2 | Designs or improves a process teams actually follow (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence looks like a process you changed, what it was before, and what changed afterwards that you can point to. Selection scaffold: pick a process change where you can say what was different afterwards; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would start |
| F3 | Uses data and metrics to find problems and judge whether something worked (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence looks like one metric you can explain end to end: how it was counted, what it is sensitive to, and which part was yours. Selection scaffold: pick a number you can defend under two follow-ups; if none comes to mind, say so plainly and say how you would check a metric before trusting it |
| F4 | Influences people without formal authority over them (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence looks like one disagreement, what you did, and where the relationship ended up. Selection scaffold: pick a time you needed a team's buy-in without being their manager; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Communicates clearly and concisely to senior stakeholders (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence looks like one update, memo or review you wrote or ran and who it reached. Selection scaffold: pick one communication you can describe precisely; if none comes to mind, say so plainly and describe how you would structure the first one |
| F6 | Understands the company's products and customers well enough to prioritize (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is first-hand: products you have used or read up on, in your own words. Selection scaffold: name two things you have actually looked at; if none, say so plainly and say what you would learn first. The research that could have grounded this row did not run (see Sources) |

## Persona table

The weights rest on one input: you said final round, and nothing about who runs it. No loop source was read, so the pack does not assert how Stripe structures its final. Weights are close to flat, with a tilt toward the personas a final round usually carries for a role like this. Recalibrate if you know the schedule.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | Live problems about launches, process and metrics | High: a hiring-manager prior, and the role's work is applied judgment | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| B. Skeptic | Probes the thinnest part of your story and your motivation | High: any final round derisks gaps, and your gaps are unknown here | Rehearse the single most predictable objection until it is boring; build bridges only from things you actually did; add a concrete ramp plan |
| C. Peer Evaluator | Seam-splitting and collaboration scenarios | Medium: likely if a product-management or operations peer is among the sessions | Reciprocity framing; propose seam principles, not a pretend seam |
| D. Values/Behavioral | Stories about hard truths and customer-first choices | Medium: no loop source was read, so no values round is assumed | Choose stories where the hard truth actually landed; say "we" for context and "I" for your own part |
| E. Data-Driven Prober | Pushes on how numbers were counted | Medium: product operations leans on metrics | Know what you can and cannot say about each number; name your weakest assumption first |
| F. Conversational | Friendly, loosely structured | Medium-low: still scored | A 90-second arc; treat casual questions as scored |
| G. Pressure | Time-boxed, devil's advocate | Low: tested only if a skip-level or bar-raiser-style session exists | Pause, restate, hold a position through two follow-ups, concede specifically |

## Question banks

Questions with no candidate claims carry the label alone. Highest-ROI prep: **B1**, the day-one weakness question. It arrives in some form in nearly every final round, and a calm, specific, honest answer changes the interview.

### A. Case/Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch the plan for launching a new feature across several teams. What do you need to know first?" | CASE | [generic] | Clarify first (goal, audience, deadline, who must sign off), then objective, segments, approach, metrics, risks. Say the structure aloud. Challenge one premise politely. Makes no claim about your past | The role's core live problem, asked as a plan; F1's requirement |
| A2 | "An adoption metric for a recently launched product dropped 20%. Diagnose it." | CASE | [generic] | Ask how the metric is defined and whether tracking changed before assuming a real drop; then segment, line up timing against releases, form two hypotheses and say what you would check first | Tests F3's requirement as reasoning, not as a past claim |
| A3 | "Two teams want the same launch date and the same limited support capacity. How do you decide who goes first?" | CASE | [generic] | Ask what criteria exist; propose principles (customer impact, reversibility, dependencies); say who you would escalate to and what you would record | Prioritization and influence without authority, F4's requirement |
| A4 | "Big launches follow a process but small changes slip out unannounced. How would you redesign it?" | CASE | [generic] | Start with what a small change can break and who needs to know; propose the lightest process that catches that; say what you would measure to know it works | F2's requirement as a design problem |
| A5 | "What would you want to understand about our products and customers before changing how launches are run?" | CO | [generic] | Name only things you have genuinely looked at or used; if none, say so plainly and say what you would learn in week one. The research that could ground this question did not run, so the pack supplies no company facts | F6's requirement; honest cost of missing research |

### B. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Pick the honest weakest row of your own worksheet above. Three beats: name it in one sentence, name the nearest thing your material does carry, give a 30-day ramp plan. If no weakness comes to mind, say so plainly, then say how you would find out. Hold through two follow-ups; concede specifically, never on the core of what you can do | Highest-ROI prep: the probe aimed at wherever your material is thinnest, which the worksheet's F1 to F6 will show once filled |
| B2 | "Why this role, why here, why now?" | JD | [generic] | Three sentences, each a reason that is actually yours. Drop any reason you would not repeat under a second question. If one of the three is missing, say so plainly rather than inventing it | Motivation consistency is what the Skeptic scores |
| B3 | "What would make you leave this role within a year?" | JD | [generic] | Name a real condition in your own terms, framed as what you need to do your best work, not as a complaint. If none comes to mind, say so plainly and describe what you are looking for | Tests honest self-assessment and stability |
| B4 | "Product operations work looks invisible when it goes well. How would you know you are doing a good job?" | JD | [generic] | Say which signals you would watch and who you would ask. Describe how you would check, not results you have achieved. Concede that some effects are hard to attribute | F3 and F5 requirements, pressed collegially |

### C. Peer Evaluator (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles (who decides, who is informed, how disagreements escalate) instead of pretending to know the seam; add what you would bring to their team. Makes no claim about your past | F4's requirement; reciprocity framing |
| C2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a shared piece of work where your own part is easy to state; use "we" for the team and "I" only for what you did. If none comes to mind, say so plainly and say how you would share credit | Partnership fit |
| C3 | "What would you need from me in your first month?" | JD | [generic] | Ask for context and introductions specific to the work, and offer something back in the same breath. Keep it to two or three concrete asks | Whether the hire adds to or reduces the peer's load |

### D. Values/Behavioral (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: a time with a named stake, a moment you did not fold, and a relationship intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Stock behavioral probe; no published-values source was read, so it is not mapped to named values |
| D2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where the trade-off was real and you can say what you gave up. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would decide | Customer-first judgment, relevant to any operations role |

### E. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a result you can put a number on. How was that number counted?" | EXP | [generic] | Selection scaffold: pick one figure you can explain. State how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If no such number comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would count it | F3's requirement; "I don't know how it was counted" is an honest branch |
| E2 | "What would you measure to know whether a launch process is working?" | CASE | [generic] | Propose two or three measures tied to a stated goal, name what each could miss, and say what baseline you would need first | F2 and F3 requirements as reasoning |
| E3 | "How would you decide a metric is trustworthy enough to base a launch decision on?" | CASE | [generic] | Checks on definition, instrumentation and sample; say what you would do when the data is weaker than the decision needs | Probes the habit of verifying before relying |

### F. Conversational (weight: medium-low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc in your own words: where you started, the turn, why this role. Use only events you can stand behind | The biography opener is scored even when casual |
| F2 | "What are you experimenting with these days in how you work?" | JD | [generic] | Name something real, tool or practice, and what you learned. If nothing, say so plainly and say what you want to try | Genuine interest and communication economy |

### G. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, restate, then one strength you can evidence and one honest concession. Stay inside what you can back with your own words | Composure under a time box |
| G2 | "That result: how much of it was actually you?" | EXP | [generic] | Follow-up to whichever story you tell in E1 or D1. State your own part exactly, credit others by name, and concede what you do not know. Never widen your part to hold the position | Attribution honesty, rehearsed |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| F1 Cross-team launch coordination | A1, A3, C1 |
| F2 Process design | A4, E2 |
| F3 Metrics and data | A2, E1, E2, E3, B4 |
| F4 Influence without authority | A3, C1, C2, C3 |
| F5 Senior communication | B4, F1, G1 |
| F6 Product and customer understanding | A5 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a great first 90 days look like in this role, and what would tell you it went badly?" | Makes success concrete and shows you think in outcomes |
| R2 | "Where does product operations' remit end and product management's begin here, and how is a contested boundary decided?" | Shows awareness of the seam and a preference for explicit principles |
| R3 | "Which recent launch went well here, and what made it go well?" | Draws out real practice, and you can follow up on the answer |
| R4 | "What is the problem on this team you most wish someone would take off your plate?" | Points the conversation at where you could help |
| R5 | "How is this role's success measured, and by whom?" | Shows you will hold yourself to a measure |
| R6 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity question, suited to a peer |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Any claim about your past experience | No CV, message or dossier gave a sentence of yours to build on, so nothing about your history is coached | Selection scaffolds that end in an honest branch; once you give your own sentences, this list is rebuilt from them |

## Sources

Provided documents: your message (company, role, final round). No CV, job description, recruiter notes or dossier.

Searches sent, all refused for lack of permission, none returned results:

- "Stripe operating principles values": refused
- "Stripe interview process product operations manager": refused
- "Stripe strategy news 2026": refused
- "Stripe Product Operations Manager job description": refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Every call was refused. Would have fed a values cheat sheet and VAL mapping; the section is dropped and VAL questions are generic |
| 2. Stripe interview process, product operations | unavailable | Every call was refused. Would have fed persona weights and round structure; weights are flat-ish and no loop is asserted |
| 3. Stripe strategy and recent news | unavailable | Every call was refused. Would have fed CO and strategy-grounded CASE questions; A5 stays generic |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form |
| 5. Representative Product Operations Manager JD | unavailable | Every call was refused. Would have turned F1 to F6 into quoted `[inferred]` requirements and sharpened the JD-tagged questions |

## Upgrade menu

- The job description text → F1 to F6 become quoted `[grounded]` requirements and the JD-tagged questions are re-aimed at its own wording
- Your CV or a paragraph per recent role → the worksheet's evidence column fills with your own quoted sentences, the story maps replace the selection scaffolds, and the prohibited-claims list is built from them
- The interviewers' names and roles, and the schedule if your final is several sessions → tailored persona weights, a reading of each interviewer's public footprint, and per-session mini-packs
- The recruiter's prep email → coverage of any declared focus areas or deliverables
- Permission to run web search → Stripe's published values, loop structure and recent strategy replace the generic rows, which can add a values cheat sheet and company-specific CO questions
- A tuesday-dossier.md from an earlier fit check, if you have one → evidence-based objections and prohibited-claims guardrails in place of the inferred ones
