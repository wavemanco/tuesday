# Interview pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Interviewer:** Dan Kovac, Director of Sales Strategy, a peer (both report to the same VP). One 60-minute conversation.
**Candidate:** Priya.
**Built on:** the coach's notes only (JD highlights, Priya's background summary, Dan's profile summary, a research note). Web searches were not permitted in this session, so nothing here comes from the web.

## How to use this pack

Personas describe how a question arrives. Types describe what it is scored on. Guidance is scaffolding, not a script: say it in your own words, and rehearse only what you actually did.

| Type | What it is scored on | Question IDs |
|---|---|---|
| VAL | Past behavior against the company's published values | B2, G1, G2 |
| EXP | Whether the background survives scrutiny, and what was actually yours | A1, A2, A4, B3, E1, F1 |
| JD | The stated role and its gaps | A3, A5, B1, B4, C1, C2, C3, D3, E2, F2 |
| CO | Company and strategy knowledge | D1 |
| CASE | A live problem set in the role | D2 |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, the coach's notes | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | low | [inferred] | discovery | The quote shows strategy and ops work. It does not show whether any of it was go-to-market for a new product, and the bridge should not be stretched. Answer slot: the role is about two new lines, so expect a probe on what you have taken to market from a blank page. If any of your product strategy work was a launch you shaped, say which and what part was yours, in your own words; if none was, or it was not yours, say so plainly and stay with "product strategy & ops" as you described it |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, the coach's notes | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | The words stay at the quote's scope: you proposed the change, and it was credited with the uplift. The material does not say which stage of a customer's life the change touched. Answer slot: the JD names land, adopt, expand and renew, so expect a probe on where the change worked. If it sat at one of those stages, say which, in your own words; if it did not map to them, say so plainly and stay with the change you proposed |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, the coach's notes | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | No gap in the tools: the quote names both. It is a claim with nothing inspected behind it, and "independent" is the word a prober will test. Lead with the quote in its own terms. Answer slot: if there is an analysis you ran yourself, offer to walk through it; if none comes to mind, say so plainly and say which part you did run |
| F4 | "partner-motion design experience required" — JD highlights, the coach's notes | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | The words are the quote at its own scope: you built a partner-level revenue model, and it was used in carrier negotiations. The material says the model, not the motion, and does not show who designed how partners were chosen or worked with. Answer slot: the JD states partner-motion design as required, so expect a probe on what part of a partner motion you designed. If any of it was yours, say which and how you decided, in your own words; if there was no such design step, or it was not yours, say so plainly and stay with the model you built |
| F5 | "strong cross-functional influence" — JD highlights, the coach's notes | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | none | The quote already speaks to the requirement: you set annual volume targets, with cross-org consensus. Lead with it in those terms and keep the word targets. Expect a probe on how the consensus was reached. Answer slot: if the orgs disagreed, say what and what moved them, in your own words; if they did not, or the steps were not yours, say so plainly and stay with the targets and the consensus |
| F6 | "AI experience a plus" — JD highlights, the coach's notes | "uses AI tools daily" — the coach's notes | low | [inferred] | discovery | The quote is daily tool use. It does not show AI used on analysis, planning or product work, or any AI product. Answer slot: expect a probe on what you use and for what. If any of it is on analysis or planning work, say what, in your own words; if it is general productivity, say so plainly and stay with "uses AI tools daily" |
| F7 | Familiarity with sales ops and quota setting (a role-family expectation, not in the JD highlights; raised by your own note) | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I don't have classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan in your own words and never as a past. Nothing added to make the gap feel smaller |

## Reading the interviewer

Everything here comes from the profile summary in the coach's notes. No search ran, so nothing else is known about Dan.

| Signal (source) | Practical implication | Used in |
|---|---|---|
| "relentlessly data-driven", his profile's self-description (the coach's notes) | Every number you give gets walked back to its inputs. Say how a figure was counted, or say plainly that you do not know | Bank A, F1 |
| "pricing and monetization roles", his career spine (the coach's notes) | Case and economics questions arrive in pricing, packaging and unit-economics terms. Revenue-model talk is his native language | Banks A and D |
| "one early-stage-startup chapter" (the coach's notes) | Expect a probe on how you work with no playbook. Builder stories land well with him; big-company pace is the likely doubt | C3 |
| He is your peer and you report to the same VP (the coach's notes) | He is pricing what you cost and add to his work: the seam, credit and what you would need from him | Bank B, R2, R3 |
| Mirror opportunity | His pricing spine meets F4: "built a partner-level revenue model used in carrier negotiations". Offer it as something you can walk him through, in those words only | A4, B4 |
| Shared career jump | Not offered: no row's evidence carries your side of a startup chapter, and nothing is known about a jump of his beyond the profile summary | none |

## Persona table

Weights were set in three passes: the peer relationship prior, then Dan's signals, then the loop. The loop is one 60-minute conversation with Dan, established by the coach's notes, so no archetype fallback applies and no values-style round is detected.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober | Reads your claims line by line, asks for inputs and denominators | Top, 5 questions. The peer prior puts it first, and "relentlessly data-driven" pushes it up | Know what you can and cannot say about how each figure was counted, name your weakest assumption before he does, and offer to walk through one analysis end to end |
| Peer Evaluator | Seam-splitting, credit, "what would you need from me" | Top, 4 questions. The peer prior puts it first | Reciprocity first: what you bring his team. Propose seam principles instead of pretending to know the seam |
| Skeptic | Quiet, persistent probing of the gaps | Mid, 3 questions. You flagged the sales-ops and quota gap yourself, and his startup chapter points to doubts about big-company pace | Rehearse the single most predictable objection until it is boring. Calibrated candor over bluffing a competency he owns |
| Case / Strategist | A live problem set in the role | Mid, 3 questions. His pricing spine tilts the cases toward packaging and pricing | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise |
| Conversational | Friendly openers that are still scored | Low, 2 questions. Peer conversations open warm | Script the 90-second arc. Treat casual AI questions as scored |
| Pressure | Time-boxed challenges | Low, 2 questions. Not a peer-round prior, so kept as a short composure check | Pause, restate, hold the claim through two follow-ups, concede specifically |
| Values / Behavioral | Scenario probes | Low, 2 questions. No values-style round is detected and no published values are in hand | Choose a story where the hard truth landed. If none comes to mind, say so plainly |

## Question banks

Highest-ROI prep in the pack: **C1**. The sales-ops and quota gap is the objection a Director of Sales Strategy is most likely to raise, and you have already named it yourself.

### A. Data-Driven Prober (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The uplift you were credited with, around $400M in ARR: walk me through how that number was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Start with the quote at its own scope: you proposed the change, and it was credited with the uplift. Answer slot: say how the figure was counted and what it is sensitive to, in your own words; if you do not know how it was counted, say so plainly, and stay with the change you proposed. Do not name a method or a baseline you did not use | F2 holds the one headline figure, so a defend-the-number question is near certain. EXP because it tests what was actually yours and how the figure was built |
| A2 | "Which assumption behind that uplift would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | The weakest-assumption move: name, in your own words, the assumption you would defend least before he asks. If you cannot name one, say so plainly. Answer slot: say which part was yours; if you only proposed the change and nothing after it was yours, say so, and stay with "proposed" and "credited" | F2 again, because a data-driven peer asks the second-level question. Naming the weak point first converts a gotcha into credibility. EXP for the same reason as A1 |
| A3 | "Tell me about an analysis you ran yourself in SQL or Tableau, from question to answer." | JD | [grounded] "skilled in SQL/Tableau" | An open prompt, and the quote carries no story, so this is a selection scaffold. Pick an analysis where you wrote the queries or built the view yourself, where you can name the question, a limit of the data, and what the answer changed. If no such analysis comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F3 is the JD's named tool requirement, and "independent" is what a data-driven peer tests. JD because it scores the stated qualification |
| A4 | "Walk me through the revenue model you built for carrier negotiations: what went in, and what came out." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story-mapped on F4, with only the beats the quote states: a partner-level revenue model, used in carrier negotiations. Describe the inputs and outputs you actually used, in your own words. Where you do not recall a detail, say so. This is where his pricing background meets your material, so keep it concrete and let him draw the inference | F4 is your closest evidence for the required partner-motion line, and revenue models are the interviewer's home ground. EXP because it tests what you built and what you can still explain |
| A5 | "Expansion revenue on a newly launched product is flat while usage is up. What would you pull first, and what would each cut tell you." | JD | [generic] | Structure it aloud: clarify the definitions of expansion and usage, then segment (customer cohort, account size, product tier), then name the cut you would run and what each result would suggest. Make no claim about your past; the question needs none | F3 and the JD's land, adopt, expand, renew line are scored together here. JD content with a CASE delivery, labeled `[generic]` because it is a pattern for the problem, not a fact about Northwind |

### B. Peer Evaluator (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where is the seam between my sales strategy work and GTM for the new lines, and what happens when we disagree." | JD | [generic] | Propose seam principles instead of claiming to know the seam: who owns the question, who owns the number, and what you each need before a decision. Say how you would raise a disagreement with an equal. Ask him where he sees the seam today. Make no claim about your past | Peers reporting to one VP will split work between them, so this is the central peer question. JD because it scores how the role is actually done |
| B2 | "Tell me about a time work spanned teams and you had to decide how credit was shared." | VAL | [generic] | An open prompt with no quote behind it, so this is a selection scaffold. Pick a time with a named stake, where credit was genuinely contestable, and say what you did and how the relationship ended up. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The credit probe is a stock peer question. VAL because it scores collegial behavior over the competence behind it |
| B3 | "Walk me through how you set annual volume targets across orgs." | EXP | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on F5 with only the beats the quote states: annual, volume targets, cross-org consensus. Answer slot: the JD's cross-functional line makes a probe on disagreement likely. If the orgs disagreed, say what and what moved them, in your own words; if they did not, or the steps were not yours, say so plainly and stay with the targets and the consensus. Keep the word targets and do not call them quotas | F5 is your direct evidence for cross-functional influence. EXP because he will test what was yours in that consensus |
| B4 | "What would you need from me in your first month, and what could you give my team." | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" "No classic sales-ops or quota-setting experience." | Reciprocity first. Offer what the quote carries: you can walk his team through the revenue model you built for carrier negotiations. Then the honest ask: you do not have classic sales-ops or quota-setting experience, so you would want to learn those mechanics from him. Said as a plan, in your own words | F4 and F7 together make the strongest reciprocal answer: an offer that rests on your quote and an ask that rests on your stated gap. JD because it scores partnership fit in the role |

### C. Skeptic (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "I don't see classic sales-ops or quota-setting in your background. How would you handle that in this role." | JD | [grounded] "No classic sales-ops or quota-setting experience." "set annual volume targets with cross-org consensus" | The deepest rehearsal in this pack, and the limit comes first. Level 1, say it plainly: "I don't have classic sales-ops or quota-setting experience." Then what your material does carry, at its own scope: you set annual volume targets with cross-org consensus. Do not call targets quotas. Level 2, if he presses on the difference between targets and quotas: say only what you actually know of it; if you do not know it, say so plainly and say how you would learn it from him. Level 3, if he asks what would make this a bad hire: name the limit again and the plan, in your own words, without adding to either. Hold by returning to the same two sentences | F7 is the stated gap and the likeliest objection from a Director of Sales Strategy. JD because it scores the role's context, and the Skeptic persona because it is a quiet probe of a known gap |
| C2 | "Partner-motion design is a hard requirement for this role. What part of a partner motion have you designed yourself." | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Say the quote at its own scope: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if any part of how partners were chosen or worked with was yours to set, say which and how you decided, in your own words; if there was no such step, or it was not yours, say so plainly and describe the model you built. Hold through two follow-ups by returning to the model, never by adding to it | F4 is where the JD's one required line presses hardest on your evidence. JD because it scores the stated requirement |
| C3 | "Both of these lines start with no sales history here. You have spent nine years at a large company. What changes about how you work when there is no playbook yet." | JD | [grounded] "9 at a large consumer-tech company in product strategy & ops" | Tell the nine years at the quote's scope: a large consumer-tech company, in product strategy and ops. Answer slot: the JD's new-lines wording raises a probe on starting from nothing. If any of your work began without a playbook, say what and what you did, in your own words; if it did not, say so plainly and stay with "product strategy & ops". Then say how you would start here | F1 carries the large-company background, and his startup chapter makes the pace doubt likely. JD because it scores the new-lines mandate |

### D. Case / Strategist (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Northwind's priorities include enterprise expansion, the Compass launch and profitability, and a much larger vendor is bundling. Where does that pressure the new lines most, and where does it not." | CO | [grounded] | Use the three priorities and the bundling threat from your research note, in its vocabulary: enterprise expansion, Compass, profitability, bundling. Ask first which of the two lines Compass is, if either. Structure it: where a bundle is hardest to resist, where an emerging product can still land, and what you would want to learn before committing. Challenge one premise respectfully. The note could not be checked against the web here, so treat its facts as yours to verify | The research note supplies current strategy, and strategy fluency is the differentiator for a strategy role. CO because it scores company-altitude thinking |
| D2 | "You are packaging and pricing a new line with no pricing history, and profitability is a stated priority. How do you set it up." | CASE | [grounded] | Clarify first: the buyer, the alternative they have today and the value they get. Then segmentation, a value metric, how packaging could defend against a bundle without a price war, and how you would test it. Tie in profitability from your research note. Make no claim about your past. He lives in this vocabulary, so say the framework aloud and state your hypothesis early | His pricing and monetization spine tilts the cases this way, and profitability is a stated priority in the note. CASE because it asks for live structure in the role's own terms |
| D3 | "How would you look for whitespace across land, adopt, expand and renew for a product that has just launched. What data do you pull first." | JD | [generic] | Clarify what launched and for whom. Then define each of the four stages as a measurable state, say what you would pull at each, and where a gap between stages would point to whitespace. Make no claim about your past. Offer to sketch the queries you would write | The JD's whitespace line is the role's core analytic task. JD content with a CASE delivery; `[generic]` because it is a pattern for the problem |

### E. Conversational / Rapport Builder (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey: consulting, then nine years in consumer tech, and now this role." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc with only the beats the quote states: two years of strategy consulting at a top firm, then nine at a large consumer-tech company in product strategy and ops. Answer slot: why this role and why now is yours alone to say; give your own reason, in your own words. The pack has none to give | An opener like this is always scored for economy and motivation. F1 is the only background sentence in hand. EXP because it tests whether the story hangs together |
| E2 | "What are you actually playing with in AI these days." | JD | [grounded] "uses AI tools daily" | Say the quote at its scope: you use AI tools daily. Answer slot: say what you use them for, in your own words; if it is general productivity and not analysis or planning, say so plainly. Tie your interest to the Compass launch from your research note without claiming any product experience | The JD lists AI as a plus and the company's own launch is an AI copilot, so a casual AI question is scored. JD because it scores the stated plus |

### F. Pressure / Stress (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "That result. How much of it was actually you." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause and restate. Hold: "I proposed the change, and it was credited with the uplift." Hold that through two follow-ups. Concede only what is true and only specifically: if you cannot speak to how it was credited, say so plainly. Never fold on the proposal itself to restore harmony. Answer slot: if you can say what part after the proposal was yours, say it; if none was, say so plainly | F2 is the figure a pressure interviewer goes for. EXP because it tests attribution under pressure |
| F2 | "Sixty seconds: why you over a candidate who has run quotas and sales ops." | JD | [grounded] "No classic sales-ops or quota-setting experience." "set annual volume targets with cross-org consensus" "skilled in SQL/Tableau" "built a partner-level revenue model used in carrier negotiations" | Pause, then three beats in your own words: what you do carry, at the quotes' scope (a partner-level revenue model used in carrier negotiations, annual volume targets set with cross-org consensus, skilled in SQL/Tableau); the plain limit ("I don't have classic sales-ops or quota-setting experience"); and the plan. Do not claim to be the stronger candidate | F7 makes this comparison the live one. JD because it scores fit for the role |

### G. Values / Behavioral (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | A selection scaffold. Pick a time with a named stake, a moment you did not soften it, and an intact relationship afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioral stem, kept short because no values-style round is detected and no published values are in hand. VAL because it scores behavior |
| G2 | "When did you put a customer ahead of an internal metric." | VAL | [generic] | A selection scaffold. Pick a decision where the customer's interest and the metric pulled apart, and say what you chose and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A GTM role often sits on this tension. VAL because it scores behavior, not knowledge |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| "own GTM strategy for two new product lines" | C3, D1, D2, F2 |
| "identify whitespace across land/adopt/expand/renew" | D3, A5 |
| "run independent analysis in SQL and Tableau" | A3, A5 |
| "partner-motion design experience required" | C2, A4, B4 |
| "strong cross-functional influence" | B1, B2, B3 |
| "AI experience a plus" | E2, D1 |
| Sales ops and quota setting (raised by your note, not in the JD highlights) | C1, B4, F2 |
| Company strategy | D1, D2 |
| Values | G1, G2. No published values are in hand, so no values cheat sheet |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You have worked in pricing and monetization, with a stretch at an early-stage startup. What carried over from that stretch into how you do sales strategy now." | Ties to his own career path as his profile describes it. It signals you looked at him, and turns the interview into a peer conversation |
| R2 | "What could a new person in this seat do in their first month that would genuinely help your team." | The reciprocity question for a peer. It shows you are pricing what you add to his work |
| R3 | "Where do you expect the line between your team's work and this role's to be hardest to draw." | Shows you are already thinking about the seam, and gets his version of it before you propose yours |
| R4 | "How would you describe where the two new lines stand today." | Gets the real starting position, and tells you what C3 and D1 will look like in the job |
| R5 | "How do you decide, on your team, that a number is good enough to act on." | Mirrors his self-description as data-driven and surfaces the standard you will be held to |
| R6 | "What does the bundling threat change in how you would sequence the launches." | A strategy question built from your research note, which shows you can think at the company's altitude |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Drove, generated or delivered the ~$400M ARR uplift | Inflated form of F2 | F2's quote at its own scope: you proposed the change, and it was credited with the uplift. The limit is the pack's observation, not words for you: the material says proposed and credited, not delivered |
| Designed or owned the partner motion | Inflated form of F4 | F4's quote at its own scope. The material says the model, not the motion. C2's slot stays inside the model |
| Has sales-ops or quota-setting experience | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I don't have classic sales-ops or quota-setting experience." No slot |
| Setting targets is the same thing as setting quotas | Inflated form of F5 | F5's quote at its own scope: annual volume targets with cross-org consensus. Keep the word targets |
| Has AI or AI-product experience | Inflated form of F6 | F6's quote at its own scope: you use AI tools daily. The material shows no product use |
| Owned go-to-market strategy for a product launch | Inflated form of F1 | F1's quote at its own scope: "product strategy & ops". The material says nothing about a launch |

## Sources

Provided documents: the coach's notes, covering the JD highlights, Priya's background summary, Dan's profile summary and the research note on Northwind's priorities. This pack did not check the research note against any outside source. No dossier was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data` values | unavailable | Query `Northwind Data company values careers` was refused. It would have supplied published value names for the VAL questions and a values cheat sheet |
| 2. `Northwind Data` interview process, sales strategy | unavailable | Query `Northwind Data interview process sales strategy` was refused. The loop is established by the coach's notes, so it would only have shown whether a values round sits elsewhere |
| 3. `Northwind Data` strategy, recent news | skipped | The research note in hand supplies the three priorities and the competitive threat that feed D1 and D2 |
| 4. `Dan Kovac` at `Northwind Data` | unavailable | Query `Dan Kovac Director of Sales Strategy Northwind Data` was refused. It would have added public talks and writing to the interviewer read and to R1 |
| 5. Representative JD | skipped | The JD highlights supplied fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full JD text → the requirement wording in F1 to F6 becomes exact, and any mid-list requirement not in your highlights gets a question
- Priya's CV text → more of her own sentences enter the fit snapshot, so F1, F2, F4 and F6 can become story maps and not answer slots
- Priya's answers to the answer slots in F1, F2, F4, F5 and F6, stated outside a drill → those rows are regenerated from her own words
- Whether Compass is one of the two new product lines → D1 and D2 are retuned to it
- A deeper research pass (up to 6 further searches and 2 further fetches, several more minutes), once web search is allowed → a strategy brief, Dan's public talks and writing, role-family loop reports and recent org context, and a check of the research note
- The recruiter's guidance on focus areas or any pre-declared deliverable → coverage for it
- Prep time available → a prioritized prep schedule
- A `tuesday-dossier.md` from a prior role check → verified evidence and prohibited claims arrive pre-graded, in place of the ones built here
