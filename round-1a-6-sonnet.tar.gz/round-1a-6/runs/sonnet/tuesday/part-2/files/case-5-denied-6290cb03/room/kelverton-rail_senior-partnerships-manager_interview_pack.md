# Interview prep pack: Senior Partnerships Manager, Kelverton Rail

Panel round, Tuesday, 60 minutes: Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). First 15 minutes: your point of view (POV) on operator partnerships for the next 18 months, no slides. The rest is Q&A, and Ross will push on commercials.

## How to use this pack

Personas describe how a question arrives; types describe what is being scored. Guidance is scaffolding, not a script: where a cell says "answer slot", it tells you what to say in the interview and offers two honest branches, and you pick the one that is true.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior demonstrates the company's published values |
| EXP | Whether your claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | Structure and reasoning on a live problem from the role |

No VAL questions appear: no loop source here describes a values round (the recruiter's description is the only loop source, and it names none).

## Prep triage (four hours, over the weekend)

| Order | Time | Do this | Where |
|---|---|---|---|
| 1 | 75 min | Draft the POV spine: pick the lead thesis, the three moves, the thing you would leave out, and the operator close | Section 5 |
| 2 | 45 min | Say the POV aloud twice, timed to 13 to 14 minutes, recording it; cut anything you cannot say in your own words | Section 5, A1 |
| 3 | 50 min | Rehearse the rail-gap answers until they are boring: the highest-ROI prep in this pack is B1, then D1 | B1, B3, D1 |
| 4 | 30 min | Prepare for Ross: how the £4M was counted, what a quota is and is not in your history, and your structure for an operator deal | C1, C4, D2 |
| 5 | 20 min | Choose three reverse questions and say them aloud once | Section 11 |
| 6 | 20 min | Buffer, or one more timed run of the POV on Monday | Section 5 |

Everything else in the pack is insurance.

## 4. Fit snapshot

Requirements come from the recruiter's email (quoted) because no job description was supplied. Rows F3 and F4 are role-family requirements written from no source, so they are plain prose, and they raise no answer slot.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Please land on what it means for the operators themselves." — recruiter's email | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." — your message | medium | [grounded] | transferability | The words stay at the quote: five years in transport consulting, bus and light rail network planning, the operator world from the other side. The material says bus and light rail, not train operating companies, so expect a probe on what carries over. Answer slot: if you saw how rail operators run their services, say what you saw and how, in your own words; if you did not, say so plainly and stay with the network planning you did |
| F2 | "Ross will push on commercials." — recruiter's email | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message; "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | medium | [grounded] | transferability | Words at the quotes' own scope: "I took the ISV channel from 6 partners to 40, roughly £4M of influenced revenue." And the limit you stated: "I've never carried a direct quota; what I have is influenced revenue." Answer slot: Ross's push on commercials makes a probe on partner deal terms likely. If you have worked on pricing, term or revenue-share terms for partners, say what and how, in your own words; if you have not, say so plainly and stay with the partner count and the influenced revenue |
| F3 | Selling into rail operators (role-family, no source) | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't sold into rail specifically." Then how you would learn it, said as a plan and never as a past. Never a claim to rail sales, and nothing added to make the gap feel smaller |
| F4 | Building and running a partner channel (role-family, no source) | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [inferred] | none | Derived from the quote against a role-family requirement. Lead with the quote's own terms: you ran the ISV channel and took it from 6 partners to 40. Expect a probe on how ISV partners differ from operator partners; B2 rehearses it |
| F5 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email | none given | none | [grounded] | discovery | Nothing in the material shows your view yet. Answer slot: if you already hold a view on where operator partnerships should go, say it in your own words; if you have not formed one on part of it, say what you would need to see first |

## 5. Graded deliverable: the 15-minute POV

The recruiter announced this, so it is graded. The structure below is yours to fill; the pack does not know Kelverton's operators, its partners or what the strategy report concludes.

**Facts you can build on** (each from a fit-snapshot row, quoted from its evidence cell):

- F4: "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue."
- F1: "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)."
- F3: "Never sold into rail specifically and never carried a direct quota, only influenced revenue."

**Time map**

| Minutes | Beat | What goes in it |
|---|---|---|
| 0:00 to 1:00 | Frame | Say the structure and your answer first: one sentence on where you would take operator partnerships, then the three moves by name |
| 1:00 to 3:00 | Where you start | The F4 and F1 facts at their own scope, and the F3 limit said once, plainly, in one sentence |
| 3:00 to 10:30 | Three moves | About two and a half minutes each, each ending on one sentence about what changes for an operator |
| 10:30 to 12:00 | What you would leave out | The anti-pick: one thing you would deliberately not do in 18 months, with the reason |
| 12:00 to 14:30 | What it means for the operators | The requested close; see below |
| 14:30 to 15:00 | Hand over | Name the assumption you would test first, and invite the push |

**Three defensible theses (choose one as your spine, and keep the concession)**

| Thesis | One-line version | Mandatory concession |
|---|---|---|
| T1: Operator outcomes first | Judge every partnership by what an operator can see change, not by partner count | Your own record is growth in partner count and influenced revenue (F4), so say this is a view you are bringing, not one you have already run in rail |
| T2: Fewer, deeper | Prioritize a small number of operator partnerships made to work end to end | Your quoted record is breadth, 6 partners to 40 (F4), so depth is a judgment you are offering, not a result you have |
| T3: Bring the operator view in early | Put operators' constraints into how partnerships are designed before they are sold | Your operator-side exposure is bus and light rail network planning (F1), so name what you would verify with Deepa's team about rail |

Recommendation: lead with T1, because the recruiter asked you to land on the operators and T1 makes that the spine rather than the last paragraph. Use T2 or T3 as your divergence from the report (below), whichever the report is least likely to say.

**Differentiating from the market report.** The strategy team's report is equally available to every prepared candidate and was written by the people in or near the room, so reciting it scores as homework and not as judgment. Do three things: bring one item from the report, named as the report's, to show you read it; then one thesis-driven divergence, with your reasons; then the anti-pick, the thing the report might invite that you would say no to. Answer slot: name the report's item and your divergence yourself, in your own words, from your reading; if the report seems to say nothing you would depart from, say that plainly and use the anti-pick to show your judgment. This pack has not seen the report, so it supplies none of its content.

**The requested close: what it means for the operators themselves.** Finish on three short statements, each from the operator's side of the table: what they would notice first, what they would be asked to do differently, and what they get that they do not get today. Answer slot: the second and third depend on how Kelverton's product and operators actually work. Say only what you can support from the report, from your network-planning work (F1) or as a clearly labeled hypothesis; if you do not know, say what you would ask an operator first.

## 8. Persona table

The recruiter's email is the loop source: one 60-minute session, two named people. Weights rest on that, on the relationship priors for a hiring manager, and on the recruiter's line that Ross will push. No prior covers a Commercial Director, so Ross's weighting is a judgment you can change.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | Deepa follows up the POV with live what-if problems | high: a hiring manager and the POV format point the same way | Clarify, then structure; think aloud; challenge one premise respectfully |
| B. Skeptic | Both of you probing the rail and quota gaps | high: F3 is your own stated limit, and it is the most predictable objection | Rehearse the one objection until it is boring; adjacent evidence only; a plan, not a past |
| C. Data-Driven Prober | Ross on the £4M and the 6-to-40 | medium: "push on commercials" points at your numbers | Know how the figure was counted or say plainly that you do not; name the assumption you would defend least |
| D. Pressure | Ross time-boxing and playing devil's advocate on commercials | medium: the recruiter's word is "push", not a style | Pause, restate, hold through two follow-ups, concede specifically |
| E. Conversational | Opening warmth and the walk-through question | low: the 15 minutes are structured, but casual questions are still scored | A 90-second arc from your own quoted sentences |

Not in this loop: Values/Behavioral (no values round described) and Peer Evaluator (no peer on the panel).

## 9. Question banks

### A. Case/Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Talk us through where you'd take our operator partnerships over the next 18 months." | CASE | [grounded] | Section 5 is the build. Say the answer first, then the three moves, the anti-pick and the operator close; aim for 13 to 14 minutes so the push has room | The recruiter's announced deliverable, F5; CASE because it scores structure under open scope |
| A2 | "What would you need to know about our operators before committing to that plan?" | CASE | [generic] | Clarify before you commit: the objective you are serving, which operators you would start with and why, and what would change your mind. Name the one thing you would ask us first | Deepa's natural follow-up to a POV; CASE because it scores clarifying before structuring |
| A3 | "What in your plan would you deliberately not do?" | CASE | [generic] | Name one thing, give the reason in a sentence, and say what would make you reverse it. A plan with no no is a list | The anti-pick from Section 5, asked directly; CASE because it scores judgment |
| A4 | "Our strategy team's report covers this ground. Where does your view differ?" | CO | [inferred] The report's existence comes from your message; its content has not been seen | One item from the report, named as the report's; then one divergence and why; the anti-pick if the report invites something you would decline. Answer slot: name the items yourself from your reading; if you find no departure, say so and use the anti-pick | The report is the one document the panel is certain you have; CO because it scores homework depth, differentiated from the consensus |
| A5 | "Six months in, how would you know it is working for the operators, not just for us?" | CASE | [generic] | Name one operator-side measure and one signal that comes earlier; say who would hold the data. Answer slot: choose the measure from what Kelverton's operators actually care about; if you do not know yet, say you would ask the first operators you meet | Ties to the requested close; CASE because it scores a live measurement design |

### B. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't sold into rail. Why would our operators take your call?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." and "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | The highest-ROI rehearsal in this pack, and the hold is only what your quotes carry. Concede first, in your words: "I haven't sold into rail specifically." Then hold on the sentence you did say: five years in transport consulting, bus and light rail network planning, the operator world from the other side. Hold through two follow-ups by returning to that sentence, never by adding to it. Close with a plan in the future tense: what you would learn from operators in your first weeks | F3 is the likeliest objection and the one aimed at the thin spot; F1 is the adjacent evidence; JD because it scores a stated gap |
| B2 | "How is a partnership with an operator different from the ISV partnerships you ran?" | JD | [grounded] "running the ISV channel" | Name two differences you believe are real and say how you would test each; label them as your view. Answer slot: if you have seen the operator side up close, say how, in your own words; if you have not, say so plainly and say what you would ask first | F4's probe, the natural second question after B1; JD because it scores whether the channel experience transfers |
| B3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Pick one of the two limits you have already stated and say it plainly, then what you would do about it in your first month. Do not offer a third weakness the material does not carry, and do not volunteer a new one | The persona stem for the Skeptic; F3 and F2 supply the only two limits on record |
| B4 | "Why this move, and why now?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | State the facts as you wrote them, then give your actual reason in your own words. Answer slot: the reason connecting your payments years to Kelverton is yours to give; if you have none beyond the opportunity itself, say so | Motivation consistency is what the Skeptic scores; F4 is the career fact it rests on |
| B5 | "Have you worked directly with operators' commercial or operations teams?" | JD | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Answer slot: if you did, say with whom and doing what, in your own words; if not, say so plainly and return to the network planning your sentence states | The recruiter's emphasis on operators raises it; F1 is the only evidence |

### C. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the £4M of influenced revenue was counted." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Answer slots, each in your own words: how it was counted, what it is sensitive to, which assumption you would defend least, and which part was yours. If you do not know how it was counted, say so plainly | Defend-the-number for F2's headline figure; EXP because it scores attribution |
| C2 | "Of the move from 6 partners to 40, which part was yours?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Answer slot: say which part was yours, in your own words; if it was shared or someone else's, say that plainly and return to the quote's own words: you took the channel from 6 partners to 40 | Attribution probe on F4; EXP |
| C3 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | The weakest-assumption move: name the assumption yourself before they do. Answer slot: the assumption is yours to name; if you do not know which one it is, say that | The Prober's stem; credibility is gained by naming it first |
| C4 | "You've never carried a quota. What does influenced mean to a Commercial Director?" | EXP | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Words: "I've never carried a direct quota; what I have is influenced revenue." Answer slot: say what influenced meant in your last role, in your own terms; if you do not know exactly how the company defined it, say so | Ross's likeliest commercial probe; F2 holds your stated limit; EXP |

### D. Pressure (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you, over someone who has sold into rail?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." and "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Pause, restate the question, then concede and hold with only these: "I haven't sold into rail specifically," then the channel you ran from 6 partners to 40. Hold through two follow-ups; never claim to be better, only say what you bring | Time-boxed version of B1; JD because it scores the stated gap |
| D2 | "Commercially, how should we structure an operator partnership: who pays whom, and for what?" | CASE | [generic] | Clarify first: what Kelverton sells, what the operator owns, what a partner would add. Offer two structures, say what you would test, and name what you cannot know without Kelverton's own terms. Do not describe Kelverton's current model; you do not have it | Ross's push on commercials, as a live problem; CASE because it makes no claim about your past |
| D3 | "That plan assumes operators have the capacity to partner. Why would they?" | CASE | [generic] | Hold through two follow-ups: restate what the plan assumes, say what you would check first, and concede that you cannot know the answer until you have spoken to operators | Devil's advocate on A1; CASE; scores holding without folding |

### E. Conversational (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." and "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | A 90-second arc built from those two sentences, in your own order and dates. Answer slot: your material does not say what the earlier years of the nine covered; if they matter to the story, say what they were, in your own words | The standard opener; F4 and F1 are the two facts it rests on |
| E2 | "What do you already know about us?" | CO | [grounded] "(UK rail-tech, ~600 staff, they sell scheduling software to train operating companies)" — your message | Say what you know from the report and from your own reading, and name the source. Do not claim a customer list, a partner list or a strategy beyond what the report says. Answer slot: add one thing from your reading that you found interesting, in your own words | Casual-register homework check; CO |

### Requirement coverage

| Requirement | Questions |
|---|---|
| POV on operator partnerships, 18 months (F5) | A1, A2, A3, A4 |
| Land on what it means for operators (F1) | A5, B1, B2, B5 |
| Commercials (F2) | C1, C2, C3, C4, D2 |
| Selling into rail (F3) | B1, B3, D1 |
| Building and running a partner channel (F4) | B2, B4, C2, E1 |
| Quota and influenced revenue (F2, F3) | B3, C4 |

## 11. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "At 18 months, what would success look like for this role from the operators' side?" (to Deepa) | Takes the POV's close into their vocabulary and tells you what the manager will actually score |
| R2 | "Does this role carry a number, and if so, is it direct or influenced?" (to Ross) | Settles the quota question with the person who will push on it, and shows you are asking about commercials as well as being asked |
| R3 | "Which current operator partnership best shows what you want more of?" (to Deepa) | Anchors your plan in a live example and tells you what good looks like to her |
| R4 | "What did the strategy report get right, and where is it already moving?" | Shows you read it as a working document, not a script |
| R5 | "What is hardest for a new person in this seat to learn about the operators' side?" | Turns B1 into a conversation about ramp, which is where you want it |

## 13. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has sold into rail operators | Negative the candidate stated, F3 | The plain acknowledgment F3 gives: "I haven't sold into rail specifically." No slot |
| Carried a revenue target or quota of £4M | Negative the candidate stated, F2 | "I've never carried a direct quota; what I have is influenced revenue." No slot |
| Generated £4M for the company | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: the material gives the figure as influenced revenue, not what part was yours. C1 and C2 hold the slots |
| Knows how train operating companies run from the inside | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says bus and light rail network planning, not train operating companies |

## 14. Sources

Provided documents: your message (your background and the company description), and the recruiter's email as you quoted it. The strategy report and any job description were not in the conversation, so nothing in this pack rests on their contents.

Searches sent, each refused (web search permission was not granted in this session):

- "Kelverton Rail company values": refused
- "Kelverton Rail interview process partnerships manager": refused
- "Kelverton Rail scheduling software train operating companies strategy news": refused
- "Deepa VP Partnerships Kelverton Rail": refused
- "Senior Partnerships Manager rail technology job train operating companies": refused

Research tier: L1 — searches 5 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Would have decided whether a values cheat sheet applies; no values source in hand, so none is built |
| 2. Interview process, role family | unavailable | Would have checked the loop against the recruiter's description; the pack rests on that description alone |
| 3. Strategy and recent news | unavailable | Would have moved the CO bank (A4, E2) from inferred to grounded; the pack leans on your reading of the report |
| 4. Interviewer, public footprint | unavailable | Would have produced the interviewer read and a path-tied reverse question; absent, and R1 to R5 are role-generic |
| 5. Representative job description | unavailable | Would have grounded F3 and F4's requirements; they are plain prose without a source |

## 15. Upgrade menu

- The job description text → F3 and F4 get quoted requirements, and the JD-tagged questions rest on it
- The strategy report text, or its main recommendations → A4 and the Section 5 differentiation get a named consensus item, divergence and anti-pick instead of slots
- Your CV → the earlier years of the nine become quoted evidence (E1), and C1 to C3 can be checked against the line as written
- Your answers to the slots in C1 and C2 (how the £4M was counted, which part of the growth was yours) → both rows upgrade from slots to stories
- Search access, if enabled → grounds the CO bank and the interviewer read; a deeper pass adds up to 6 more searches and 2 more fetches, and takes several more minutes
- Deepa's and Ross's public professional profiles → the interviewer read, persona weights read from their own published background, and a reverse question tied to their path
- A tuesday-dossier.md from a job-underwriter run → verified evidence and prohibited claims supplied by it, in place of the ones built locally here
