# Interview prep pack: Product Operations Manager, Stripe

**Round:** final round, structure and interviewers not yet known. Built as a blended pack (session mode), not per-session mini-packs.
**Basis:** your message only. No CV, no job description, no interviewer names, and web research was not available (see Sources). Everything below is therefore a pattern for the role family, labeled `[generic]`, with no claim about Stripe or about your past.

## How to use this pack

- Personas describe how a question is asked. Types describe what is being scored.
- Type tags: **VAL** (past behavior against values), **EXP** (your experience under scrutiny), **JD** (the role's stated requirements), **CO** (company and strategy knowledge), **CASE** (a live problem).
- Guidance is scaffolding, not a script. Where a question asks about your past, the pack has no sentence of yours to build on, so each of those cells is a selection scaffold: how to choose a real story, and what to say if none comes to mind. Pick only stories you actually lived.
- Question IDs run by persona. The letter F is skipped so it cannot be confused with fit-snapshot rows F1 to F6.
- **Highest-ROI prep: B1**, "Which part of this role would you be weakest at on day one?" It will be asked in some form in almost any final round, and it is where a rehearsed, non-defensive answer changes the interview most. Once your CV is in, this section is rewritten around your actual biggest gap.

## Fit snapshot

Worksheet variant: no background was provided, so every evidence cell is empty. The requirements are product-operations role-family patterns, written as plain prose with no source, so they carry `[generic]` and raise no answer slots.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinating launches and programs across product, engineering and go-to-market teams (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a launch or program you coordinated across teams, with your specific part in it named plainly. Selection scaffold: pick one where several teams depended on each other and you can say what you owned and what others owned; if no such program comes to mind, say so plainly, then give the nearest cross-team work your material does carry, or how you would run one |
| F2 | Designing and running operating cadences such as planning, reviews and launch readiness (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a recurring process you set up or ran, what it replaced, and whether it was kept. Selection scaffold: choose one you can describe step by step; if you only took part in processes others designed, say so plainly and describe how you used them, or how you would design one |
| F3 | Defining, tracking and diagnosing product and operational metrics (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a number you owned, with how it was counted and what it is sensitive to. Selection scaffold: pick one you can explain from the definition up; if you have not owned a metric, say so plainly, then give the nearest analysis you did, or how you would define the first metric |
| F4 | Influencing senior stakeholders and communicating clearly in writing and live, without direct authority (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a decision you shaped without being the decider, in terms others would recognize. Selection scaffold: pick a case where you disagreed with someone more senior and the relationship survived; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Prioritizing and working through ambiguity with incomplete information (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a situation with no clear owner or answer where you chose an approach and can say why. Selection scaffold: pick one where you can state what you did not know at the start; if every example you have came with clear instructions, say so plainly and describe how you would structure an unclear problem |
| F6 | Scoping what product operations should and should not own, and showing the function's value (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is work where you drew a boundary or showed a function's effect. Selection scaffold: pick an example of choosing what not to take on; if none comes to mind, say so plainly and give your view of where the boundary should sit |

No row is a gate: nothing in your message or in a supplied posting states a term such as location, schedule, pay or work authorization. If the posting has one, it becomes a gate row once you share it.

## Persona table

No loop source establishes how this company's final round is run, so the weights rest on relationship priors for a blend of hiring-manager, peer and cross-functional sessions, not on documented rounds. If your final is several sessions, send the schedule and the weights become per-session.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problems from the role: plan this, diagnose that | 4 questions. A hiring manager buying capability asks for live structure, and the role is a process-and-metrics role | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully |
| Skeptic | Quiet probing of gaps, motivation, why here and why now | 4 questions. Final rounds derisk gaps, and without your CV the likeliest gap cannot be named yet | Rehearse the predictable objection until it is boring. Use only adjacent evidence you actually have, plus a concrete ramp plan |
| Values / Behavioral | Scenario probes, often from outside the function | 3 questions. A cross-functional interviewer is likely somewhere in a final loop. No published values were read, so none are mapped | Choose stories where the hard truth landed. Use we for context and I for your contribution |
| Peer Evaluator | Seam-splitting, credit, what you would need from them | 3 questions. A role that sits between teams is assessed by the teams it touches | Offer what you bring their team. Propose seam principles instead of pretending to know the seam |
| Data-Driven Prober | Defend-the-number probes, two levels deep | 3 questions. A metrics role invites denominator questions on any figure you give | Know how each figure was counted and say plainly when you do not |
| Conversational / Rapport | Friendly, unstructured, still scored | 2 questions. Likely as an opener or closer | Prepare a 90-second arc. Treat casual questions as scored |
| Pressure | Interrupts, time-boxes, tests composure | 2 questions. Lower prior without evidence the loop uses it | Pause, restate the question, hold a position through two follow-ups, concede specifically |

## Question banks

Provenance is `[generic]` throughout: no CV sentence, JD line or research source exists yet for any guidance cell to rest on, so no cell makes a claim about your past.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch how you would set up launch coordination for a new product that three teams are building at once. What do you need to know first?" | CASE | [generic] | Ask clarifying questions before structuring: what counts as launched, who decides readiness, what has slipped before. Then objective, the teams and their dependencies, a cadence, the signals you would track, the risks. Challenge one premise, such as whether one coordination point is right | Live problem from the role's coordination core (F1). CASE because it scores structure and not experience |
| A2 | "A key adoption metric fell 20% week over week. Diagnose it." | CASE | [generic] | First check the definition and the instrumentation before assuming a real drop. Then segment by time, cohort and release, rank hypotheses, say what you would check first and who you would ask. State what would change your mind | Metrics diagnosis is the standard live test for F3. CASE because the answer is a method |
| A3 | "We want one weekly operating review across several product teams. Design it. What is in it and what is out?" | CASE | [generic] | Purpose first, then audience, inputs, decisions versus updates, owner, and how you would know it works. Name the failure mode, a status meeting nobody acts on, and how the design avoids it. Challenge whether one review is the right shape | Tests F2 and F6 together: process design and what the function should own |
| A4 | "What should a product operations function be accountable for, and what should it not own?" | CO | [generic] | Give a principle for the boundary, then name where it meets product management, program management and engineering. Say plainly that you are reasoning from the role family and not from Stripe's published materials, which this pack could not read. Do not assert how Stripe organizes the function | CO and JD overlap here (F6). Kept generic because no Stripe source was read |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | The deepest rehearsal in this pack. Pick the requirement among F1 to F6 where your real evidence is thinnest, name it in one sentence, and give a concrete 30, 60 and 90 day plan to close it. Likely follow-ups: "How would you know you had closed it?" and "Who would you lean on?" Hold the answer through both, then concede specifically what you do not yet know. If you cannot name a weakness, that is the signal to rehearse harder, not to invent a strength | Certain to arrive in some form, and the gap cannot be named until the CV is in (F1 to F6 are all discovery rows). JD because it scores honest self-assessment against the role |
| B2 | "Why Stripe, why this role, and why now?" | CO | [generic] | Three short answers, each true and specific to you. For why Stripe, use only what you have read in primary sources yourself and be ready to name it. If part of why now is push and not pull, say the true part without complaint about an employer | Motivation consistency is the Skeptic's core test. CO because it scores homework depth |
| B3 | "What would make you decide, six months in, that this role is not right for you?" | JD | [generic] | A real answer names a condition you would care about, such as scope or authority, and says what you would do before deciding. Avoid an answer so safe it says nothing | Probes whether the role's reality matches your expectations (F5, F6) |
| B4 | "Product operations can look like overhead. Convince me this role is worth a headcount." | JD | [generic] | Structure it as what changes for other teams, how it would be measured, and when you would stop. Concede where the function becomes overhead: when it adds a layer instead of removing one. Hold the core argument through a second challenge | Pressure-flavored Skeptic question on F6. JD because it scores whether you understand the role's value |

### C. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a clear moment you said it, and a relationship that was intact afterward. Use I for what you said and we for context. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Standard values probe tied to F4. No Stripe value is mapped because none was read |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a case where the two actually conflicted, say what you gave up, and what you did about it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would decide | Probes judgment when a number and a person disagree (F3, F5) |
| C3 | "Tell me about a time you held a position under pressure from someone senior." | VAL | [generic] | Selection scaffold: needs a named stake, a moment you did not fold, and an intact relationship. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Tests F4. VAL because it scores behavior, not the outcome |

### D. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | CASE | [generic] | Propose principles for the seam, such as who decides what and how disagreements escalate, instead of claiming to know this team's seam. Say you would ask them first where it hurts today | Tests F1 and F4 with a peer. CASE because it asks you to reason about a live boundary |
| D2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Selection scaffold: pick work that spanned teams where you can say precisely which part was yours. If you have none, say so plainly and describe how you would share credit. Do not stretch your part | Attribution honesty with equals (F1). EXP because it tests what was actually yours |
| D3 | "What would you need from my team, and what would you bring it?" | JD | [generic] | Lead with what you bring, then what you need, framed as inputs and not demands. Keep both to what a role like this plausibly gives and takes | Reciprocity framing the Peer persona scores (F1, F6) |

### E. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Pick one result from your work you would put on a CV and walk me through how it was counted." | EXP | [generic] | Selection scaffold: choose a figure you can explain end to end. Say how it was counted, what it is sensitive to, which assumption you would defend least, and exactly which part was yours. If you do not know how a figure was counted, say so plainly. If you have no figure, say so and describe the work without one | Every headline number gets a defend-the-number rehearsal (F3). No figure from you exists yet, so this stays a scaffold |
| E2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | A follow-up to E1. Name the weakest assumption in your own words before the interviewer does. It turns a gotcha into a credibility gain | The Prober's standard second level (F3) |
| E3 | "How would you choose which metrics a product team is reviewed on, and which would you refuse to track?" | CASE | [generic] | State the decision each metric supports, then leading versus lagging, then how it can be gamed. Name one metric you would refuse and why | Tests judgment on F3 beyond diagnosis |

### G. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | Prepare a 90-second arc in your own words: where you started, two turning points, why this role next. Each fact must be one you can defend under follow-up. The pack cannot write the arc until it has your CV | Opens most conversations and is scored even in a casual register (F6) |
| G2 | "What are you working on or learning right now that is relevant to this role?" | JD | [generic] | Name something real and current, and say what you took from it. A vague answer here reads as low interest | Casual questions about role topics are scored (F2, F3) |

### H. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, restate, then give two points that are true and checkable. Hold through two follow-ups. Concede specifically what an internal candidate knows that you do not | Tests composure and F6 |
| H2 | "Take any story you have told me today. How much of it was actually you?" | EXP | [generic] | Answer precisely: what was yours, what was a teammate's, what was shared. Shrinking an inflated claim gracefully scores better than defending it | Attribution pressure test across F1 to F5 |

### Requirement coverage

This line is generic because no job description stated requirements. Recheck it against the posting once you share it.

| Requirement | Questions |
|---|---|
| F1 Launch and program coordination | A1, D1, D2, D3 |
| F2 Operating cadences | A3, G2 |
| F3 Metrics and diagnosis | A2, C2, E1, E2, E3, G2 |
| F4 Senior influence and communication | C1, C3, D1 |
| F5 Ambiguity and prioritization | B3, C2 |
| F6 Scope and value of the function | A3, A4, B2, B3, B4, D3, G1, H1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would success look like in the first 90 days, and who would tell me if I were off track?" | Shows you plan to be measured and gives you the real bar |
| R2 | "Which decisions does this role make, and which does it recommend?" | Surfaces authority, the thing a role with no direct reports most depends on |
| R3 | "Where is the hardest cross-team seam this role would sit on right now?" | Signals you are thinking about the work and not the title |
| R4 | "How do you tell whether product operations work is making things better?" | Lets you hear how the function's value is judged here, which you will be judged on |
| R5 | "What did the person or process closest to this role do well that you would want more of?" | Invites a concrete picture of the gap you would fill |
| R6 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity question for a peer: signals partnership, not just need |

## Prohibited claims

No entries. Your message states nothing about your past, so there is no sentence for this pack to inflate and no stated negative to protect. That is not a finding that nothing could be inflated: once your CV is in, this section is rebuilt from it before any question is rewritten.

## Sources

- Provided documents: your message only. No CV, JD, interviewer profile, recruiter note or dossier.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe operating principles values` | unavailable | Search refused by the host, so no published values were read. It would have fed a values cheat sheet and a mapped VAL bank. Section dropped and C1 to C3 left unmapped |
| 2. `Stripe interview process Product Operations final round` | unavailable | Search refused. It would have named the actual loop and set persona weights. The generic-archetype fallback applies and the weights above say so |
| 3. `Stripe strategy news 2026` | unavailable | Search refused. It would have grounded the CO and CASE questions in current priorities. A4 and B2 stay generic |
| 4. `{interviewer name} Stripe` | n/a | No name was given, so no query could be formed. There is no interviewer read |
| 5. `Stripe Product Operations Manager job description` | unavailable | Search refused. It would have turned the six `[generic]` requirement rows into `[inferred]` ones with quotes |

Queries sent, all refused: `Stripe operating principles values`; `Stripe interview process Product Operations final round`; `Stripe strategy news 2026`; `Stripe Product Operations Manager job description`.

## Upgrade menu

- Your CV: every fit-snapshot row becomes quoted evidence, the selection scaffolds become story maps, the Skeptic bank gets your actual biggest gap, and defend-the-number questions are written against your real figures
- The job description text: the six generic requirement rows become grounded rows with quoted requirements, and every stated requirement gets a JD-tagged question; any term in it such as location or work authorization becomes a gate row
- The names and roles of your interviewers, and the schedule if your final is several sessions: persona weights become per-session, with an interviewer read and a tailored reverse question
- The recruiter's prep note: coverage of any pre-declared case, presentation or take-home
- Permission to run web search: Stripe's published values, loop structure and recent strategy, which would add a mapped values sheet and Stripe-specific CO questions. A deeper research pass is also available, up to 6 more searches and 2 more fetches and several more minutes, if you want the strategy brief version
- A tuesday-dossier.md from an earlier run would add verified evidence and a named objection to rehearse, but this pack does not need one
