# Interview pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Loop mode: three rounds on 5 December, built on 26 November 2026.

| Round | Who runs it | Length | What the recruiter said |
|---|---|---|---|
| 1 | The recruiter | 30 minutes | A conversation about the process |
| 2 | Head of Member Services, who would be your manager | 45 minutes | Mostly behavioural |
| 3 | Panel of two branch managers | 60 minutes | Includes a 20-minute case on a complaint escalation; the panel is also the values round and scores against the four values |

Interviewer names are not yet assigned beyond these roles, so there is no interviewer read.

## How to use this pack

- Personas are how a question arrives; types are what it scores. Every question carries both a persona (the bank it sits in) and one type tag.
- Type key: VAL is behavioural and values alignment. EXP is a work-experience deep-dive. JD is role-driven, taken from the posting. CO is company and strategy knowledge. CASE is a live problem.
- Guidance is scaffolding, not a script. Any wording proposed for you to say is pending your approval: keep what is true for you, in your own words, and cut the rest.
- An answer slot is an instruction for the interview, not a question to you. Meet it with either honest branch.
- Question IDs run across the whole pack: A and B are round 1, C to E are round 2, F to H are round 3.
- The highest-ROI rehearsal in this pack is D1, the contact-centre question. The short screen version is B2.

## Fit snapshot (shared across all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says a branch's formal complaints log, not the process end to end, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what sat before and after the log likely. If any of those steps were yours, say which and what you did, in your own words; if the log was where your part ended, or they were not yours, say so plainly and stay with the log you handled |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A limit you stated, so the words are your own: "I've never worked in a contact centre." Then what you would want to learn first, said as a plan and never as a past. The branch side of this line is F1's |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [inferred] | discovery | The quote reaches a monthly complaints spreadsheet and does not show what it counted. Answer slot: the JD's volumes-and-resolution-times line makes a probe on what the sheet counted likely. Say what it counted, in your own words; if you do not know, say so plainly and stay with the spreadsheet you built |
| F4 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your quote says new tellers and a script, and the words stay there: "I trained new tellers on our escalation script." Answer slot: the JD's supervisors line makes a probe on how that differs likely. Say how you trained the tellers, in your own words; if the script was set elsewhere and delivering it was your part, say so plainly. Then how you would approach someone at your own level, as a plan and never as a past |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not establish this. Answer slot: the JD's self-service line makes a probe on digital teams likely. If you have worked with a digital team, say what it was and what part was yours, in your own words; if you have not, say so plainly, and say what you would want to understand first about a member trying to resolve something without staff |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | A self-reported line with nothing inspected behind it, so expect a probe. Say it as it stands: six years in retail banking, the last three as a branch supervisor. Add nothing about what the work consisted of beyond your other quoted lines |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | low | [inferred] | discovery | "Formal" is the quote's word, and the material does not show whether outside rules governed those complaints. Answer slot: the JD's line makes a probe on which rules those complaints fell under likely. If you worked to rules, say which and what your part was, in your own words; if you do not know, or there were none, say so plainly and stay with the log you handled |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A limit you stated, so the words are your own: "I've never presented to anyone above regional level." Then how you would prepare for a first time, said as a plan and never as a past |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | low | [inferred] | discovery | The quote says spreadsheet, not Excel, and the material does not show which program it was built in. Answer slot: the JD's Excel line makes a probe on the program and what the workbook did likely. Say which program you used and what it did, in your own words; if you are unsure, say so plainly and stay with the spreadsheet you built |

Bridge language above is proposed wording, pending your approval.

## Grounding brief

These four points are as you relayed them from the 2026 strategy brief Ashgrove published in July 2026; the brief itself has not been read for this pack. At 26 November 2026 it is four months old.

| Point | Provenance | Where it is used |
|---|---|---|
| Move 40% of member service to digital channels by 2028 | [grounded] | E1, RQ3 |
| Consolidate eight branches into five hubs over 2027 | [grounded] | E2, F3, RQ9 |
| Launch a small-business lending product in Q1 2027 | [grounded] | RQ6 |
| The main competitive pressure is app-only banks | [grounded] | B3 |

---

## Round 1: the recruiter (30 minutes)

### Persona weights

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly, unstructured; logistics asked in a casual register | High, 5 of 8. The recruiter-screen prior; nothing in the email adjusts it | A 90-second arc built only from your quoted beats (A1); treat casual questions on JD topics as scored; use the reverse slot |
| Skeptic, light | Quiet checks on the gaps and on motive | Light, 3 of 8. The recruiter-screen prior includes knockout checks, and F2 and F8 are the limits you have stated | Rehearse the plain acknowledgment once, then a plan, never a past |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F6, F1, F4 and F3: a 90-second arc whose beats are only what these quotes state. Six years in retail banking, the last three as a branch supervisor; the branch's formal complaints log you handled; the new tellers you trained on the escalation script; the monthly complaints spreadsheet you built that your regional manager uses. Close in your own words on why this role; the pack does not supply that reason | The recruiter-screen opener, and the place the 4+ years requirement is heard first (F6). EXP because it tests what you say you did |
| A2 | "What are your salary expectations?" | JD | [generic] | A logistics slot. Give your own figure, or ask for the role's band first; the JD you sent states no pay. If asked what you earn now: "I'd rather focus on the range for this role." Do not give a current figure | One of the four logistics a recruiter screen checks. JD because it is a term of the listed job |
| A3 | "What's your notice period?" | JD | [generic] | A logistics slot. Give your actual notice period, in the terms your own contract states, and nothing added | A logistics term of the job, so JD |
| A4 | "Where would you be based, and how do you feel about moving between sites?" | JD | [generic] | A logistics slot. State where you are based and any limit on travelling between sites, in your own words; if you have no limit, say so plainly. The JD's across-branches line makes travel a likely follow-up | A location term, so JD; the JD's across-branches line is why travel is asked |
| A5 | "Why are you looking to move?" | EXP | [generic] | A logistics slot. Give your actual reason in your own words, in a sentence or two, and keep to what is true. Say the same reason in all three rounds | The reason for leaving is checked for consistency across the loop, so EXP |
| B1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Choose the gap that is truly larger for you. Your stated limits are the contact centre (F2) and presenting above regional level (F8). Say it plainly in your own words, for example "I've never worked in a contact centre", then one sentence on how you would learn it, as a plan. Do not volunteer a third gap you were not asked about | The stock Skeptic opener. The two stated limits are the ones a screen is built to find; JD because it scores the posting's own requirements |
| B2 | "You haven't worked in a contact centre. How would you own complaints there?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | The short screen version of D1. The plain acknowledgment, "I've never worked in a contact centre." Then the branch side at the quote's own scope, "I handled the branch's formal complaints log." Then what you would want to learn first, as a plan in your own words. Stop there; the long version is D1 | F2 is the likeliest objection and a screen is where it is first raised. JD because it presses on the posting's contact-centre line |
| B3 | "Why Ashgrove, rather than an app-only bank?" | CO | [grounded] | Answer only from what is true for you, in your own words. The published wording you can anchor to is the values page ("Members First, Always", "Neighbours, Not Numbers") and the brief's own competitive frame, app-only banks. Use a value only if it is true for you. If no reason comes to mind beyond the job, say so plainly and name what you would want to find out about Ashgrove | Homework depth: the brief names app-only banks as the main competitive pressure. CO because it tests company knowledge |

Answer guidance in this table is proposed wording, pending your approval.

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "Could you tell me who is on the panel in the last round, and whether the escalation case comes in advance or is given live?" | It settles the two structural unknowns for round 3, and a process question is normal at the end of a screen |
| RQ2 | "What would the first ninety days of this role be judged on?" | It turns the JD's four duties into a priority order before round 2 |
| RQ3 | "Where do complaints sit in the move to digital channels by 2028?" | It ties your question to the brief's own target, which shows you read it |

---

## Round 2: Head of Member Services, your future manager (45 minutes)

### Persona weights

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scenario prompts, STAR-shaped stories | High, 4 of 9. The recruiter said "mostly behavioural", which lifts this above the hiring-manager prior | Use a story only where a quoted sentence carries it; where none does, give the honest branch |
| Skeptic | Persistent probing of the gaps | High, 3 of 9. The hiring-manager prior is Case/Strategist plus Skeptic; a manager is derisking F2, F7 and F8 | Rehearse D1 to four follow-ups; concede specifically, never fold on the core claim |
| Case/Strategist | A live problem on the role's own strategy | Low, 2 of 9. The same prior, lowered by "mostly behavioural" | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you helped a colleague handle an escalation better." | JD | [grounded] "trained new tellers on our escalation script" | Story-mapped on F4, at the quote's scope: you trained new tellers on the escalation script. Say it that way. Answer slot: the JD's supervisors line makes a probe on how coaching a peer differs likely. Say how you trained the tellers, in your own words; if the script was set elsewhere and delivering it was your part, say so plainly. Then how you would approach someone at your own level, as a plan | F4 is the evidence behind the coaching duty. The prompt's theme is the JD's escalations line; JD because it scores that duty |
| C2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | A selection scaffold. Pick a time you told someone senior to you something they did not want to hear; it needs the message itself, what you said, and how the working relationship stood afterwards. Choose someone you have actually spoken to in that role. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem for the Values/Behavioral interviewer. F8 and F3 are why seniority and reporting are the live themes for you; VAL because it scores behaviour |
| C3 | "Tell me about a time you worked with another team to fix something for members." | JD | [generic] | A selection scaffold. Name the other team, what was broken for the member, what each side did, and how it ended. F5 shows nothing here yet. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The prompt's theme is the JD's digital-teams line (F5). JD because it scores that duty |
| C4 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F3 and F9, at the quote's scope: you built it, it is monthly, it is about complaints, and your regional manager uses it. Answer slot: the JD's volumes-and-resolution-times and Excel lines make probes on what it counted and which program it was built in likely. Say what it counted and which program you used, in your own words; if you do not know how a figure in it was counted, say so plainly and stay with the spreadsheet you built. Name the assumption in it you would defend least, in your own words, if you know one | The one artifact of yours a prober can ask to see. EXP because it tests what the sheet was and what was yours |
| D1 | "You haven't worked in a contact centre, and this role owns complaints across branches and the contact centre. Why should I think you can own that?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | The highest-ROI prep in this pack, to four levels. Answer: the plain acknowledgment, "I've never worked in a contact centre", then the branch side at the quote's scope, "I handled the branch's formal complaints log", then what you would want to learn first, as a plan. Follow-up one, "What would you do in your first month?": a plan, not a past; say what you would ask and whom. Follow-up two, "A branch log and a contact centre are not the same thing": hold by returning to the log, never by claiming a comparison you have not made; concede plainly "I can't tell you how they compare, because I haven't worked in one." Follow-up three, "And if you find you can't do it?": concede specifically by naming the first point where you would ask for help. Never fold on the core claim, which is only what the quote carries. The limit, named before it is asked: the material shows a branch log and no contact-centre work | F2 sits against the posting's headline duty (F1), so this question will arrive in some form. JD because it scores the stated requirement |
| D2 | "The JD asks for confidence presenting to senior leaders, and you've told me you've never presented to anyone above regional level. How do you close that?" | JD | [grounded] "I've never presented to anyone above regional level"; "I built the monthly complaints spreadsheet our regional manager uses" | The plain acknowledgment in your own words: "I've never presented to anyone above regional level." Then how you would prepare for a first time, as a plan. Hold: do not claim confidence you have not been tested on. If pressed, "I haven't done it, and here is how I would prepare for the first one." The spreadsheet is something you built, not a presentation; do not promote it | F8 is a stated limit. JD because it scores the posting's requirement; the Skeptic delivers it as a quiet follow-up |
| D3 | "You handled the branch's formal complaints log. Which rules did those complaints fall under?" | JD | [grounded] "I handled the branch's formal complaints log" | Answer slot on F7: if you worked to rules, say which and what your part was, in your own words; if you do not know, or there were none, say so plainly and stay with the log you handled. Do not rename "formal" as any other word | The JD asks for experience with regulated complaints and F7's quote says formal; the gap is exactly there. JD because it scores that requirement |
| E1 | "Ashgrove wants 40% of member service on digital channels by 2028. How would you decide which complaints stay with a person?" | CASE | [grounded] | No claim about your past is needed. Structure aloud. Clarify first: what counts as member service in the 40%, and how complaints are counted today. Objective: nothing a member has to be told twice (the Plain Words value) and the resolution times the JD asks you to report. Segment by what the member needs from the exchange. Approach, then the measures the JD names, volumes and resolution times, then risks, including the app-only comparison. Challenge one premise respectfully, such as whether the 40% should apply to complaints at all | The brief's own target, asked as a live problem; CASE because it scores structure. It also touches F5 |
| E2 | "Eight branches become five hubs over 2027. What happens to complaint handling in the changeover?" | CASE | [grounded] | No claim about your past is needed. Clarify who holds complaints across the eight today and what a member in a closing branch is told. Objective: whoever finds a complaint keeps hold of it until it is solved (the Own the Fix value), and each town still has someone to go to (Neighbours, Not Numbers). Then approach, measures, risks. Challenge one premise respectfully, such as whether complaints should stay tracked by their original branch for a time | The brief's second move, asked as a live problem; CASE because it scores structure |

Answer guidance in this table is proposed wording, pending your approval.

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ4 | "How is the contact-centre side of complaints organised today, and who would I work with there?" | It sizes F2 honestly and reads as diligence, not as covering a gap |
| RQ5 | "After the monthly report goes out, who acts on the volumes and resolution times?" | It shows you see reporting as something acted on, which the JD's own duty implies |
| RQ6 | "As the small-business lending product launches in Q1 2027, who will own complaints from those members?" | It ties your question to the brief's third move |
| RQ7 | "What would you most want a new lead to change, and what to leave alone?" | A manager's own answer to it tells you what the role really is |

---

## Round 3: panel of two branch managers (60 minutes, including a 20-minute case)

### Persona weights

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | One scored prompt per published value | High, 4 of 9. The recruiter said the panel is the values round and scores against the four values | Map each value to a quoted story where one carries it, and to a selection scaffold with an honest branch where none does |
| Case/Strategist | The 20-minute escalation case | Mid, 3 of 9. The recruiter named the case; the format is not known | Clarify before structuring; think aloud; one premise challenged respectfully |
| Peer Evaluator | Seam-splitting between a branch and this role | Low, 2 of 9. They are branch managers and the panel is not named; if they manage the supervisors you would coach, this rises | Offer seam principles, not a pretended seam; say what you bring them, not only what you need |
| Conversational | A warm opening | No bank. A panel usually opens warmly; A1's arc covers it | Reuse A1 |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] | A selection scaffold. Pick a decision with a named member, a named alternative that favoured the branch or the process, what it cost, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The value "Members First, Always", in its own words. VAL because it scores whether behaviour shows the published value |
| F2 | "Tell me about a time you made something clearer for a member or a colleague." | VAL | [grounded] "trained new tellers on our escalation script" | Your nearest quoted material is F4's: you trained new tellers on the escalation script. It is a story about training on a script, not about rewording one; tell it as that. Answer slot: the value's "we wrote it wrong" line makes a probe on the wording itself likely. If the script's wording, or any member-facing explanation, was yours to change, say what you changed and why; if it was set elsewhere, say so plainly and stay with the training. For a different story, pick one with a named reader, what confused them, and what changed; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The value "Plain Words", in its own words. VAL because it scores whether behaviour shows the published value |
| F3 | "Tell me about a time you put a branch's or a town's needs ahead of a number." | VAL | [grounded] | A selection scaffold. Name the need, the number it ran against, who you told, and how it ended. Use the word "town" only if it is true of your branch. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The value "Neighbours, Not Numbers". The brief's move from eight branches to five hubs sits next to it, and the panel are branch managers; VAL because it scores the value |
| F4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Story-mapped on F1, at the quote's scope: the log you handled. Answer slot: the value's "keeps hold of it until it is solved" line makes a probe on a single complaint carried through likely. If there was one you carried from the log to an outcome, say what it was and what you did; if the log was where your part ended, or there was no such complaint, say so plainly and tell how you handled the log | The value "Own the Fix", in its own words; VAL because it scores the value. F1's limit applies |
| G1 | "A member has complained about the same issue more than once, and the branch says it has been dealt with. It reaches you as an escalation. Walk us through what you do." | CASE | [generic] | No claim about your past is needed. Structure aloud. Clarify: what the member asked for, what they were told each time, and whether the complaint is a formal one and which rules apply. Objective: a result the member accepts and an explanation they need not hear twice. Approach: who holds it from now until it is solved, what the branch is told, what the member is told in plain words, and by when. Measure: volumes and resolution times, the two the JD names. Risks: the branch disagrees; a rule sets a limit you do not know. Challenge one premise respectfully, such as whether "dealt with" means the member agrees | The recruiter named a complaint-escalation case; the format is not known, so this is a pattern, labelled generic. CASE because it scores structure |
| G2 | "The supervisor who handled it first disagrees with how you've reopened it. How do you work with them?" | CASE | [generic] | No claim about your past is needed. Listen to their account first; agree the facts; return to the member's side; say what you would ask them to do next time; leave them owning their part. Say honestly where you do not know their branch as well as they do | The JD's escalations line (F4), asked as a live problem. CASE because it scores how you reason with someone who disagrees |
| G3 | "The same member has also called the contact centre twice. What changes?" | CASE | [generic] | No claim about your past is needed. Ask what the contact centre records and whom it tells; decide there is one owner from here; say what you would want to see in both records before speaking to the member. Do not pretend to know how the contact centre's system works; ask | F2's requirement, asked as a live problem. CASE because it scores structure and honesty about unknowns |
| H1 | "Our branches sit alongside this role. Where's the seam, and what happens when we disagree about how a complaint should be handled?" | JD | [generic] | Offer principles, not a pretended seam: the member hears one voice; whoever finds the problem keeps hold of it until it is solved; the branch is told before the member is. Then reciprocity: what you would do for their branch, in your own words. Do not claim to know where the seam sits today | A Peer Evaluator stem on the JD's branches-and-escalations duty. JD because it scores the working relationship the posting describes |
| H2 | "How do you handle credit and blame when a complaint spans a branch and the contact centre?" | JD | [generic] | Principles, not a past: credit goes where the work was; the member's outcome comes before who is right; blame stays on the process, not the person. Say this in your own words | A Peer Evaluator stem on the JD's across-branches-and-contact-centre line. JD because it scores it |

Answer guidance in this table is proposed wording, pending your approval.

### Values cheat sheet (round 3, the values round)

| Value (official name) | Working meaning (paraphrased) | Mapped story or scaffold |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | A selection scaffold (F1 in this round's bank); none of your quoted sentences carries a story for it |
| Plain Words | If a member has to be told twice, the wording failed, not the member | F4: "trained new tellers on our escalation script"; a story about training on a script, with an answer slot on the wording, in F2 of this round's bank |
| Neighbours, Not Numbers | Each branch belongs to its town, not only to a metric | A selection scaffold (F3 in this round's bank); none of your quoted sentences carries a story for it |
| Own the Fix | Whoever finds a problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log"; the log is the only beat the quote states, with an answer slot in F4 of this round's bank |

Cheat-sheet mapping is proposed wording, pending your approval.

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ8 | "What would you most want this role to do for your branch?" | It asks the panel to price the role against their own work |
| RQ9 | "How do you expect complaints handling to work for members whose branch becomes part of a hub?" | It touches the brief's second move without asking about anyone's own post; ask it as curiosity about complaints |
| RQ10 | "What could a new person do in their first month that would genuinely help your branch?" | The reciprocity question for a peer-like panel |
| RQ11 | "When a complaint is escalated from your branch, what do you want to hear back, and how fast?" | It makes the JD's escalations duty concrete from the branch's side |

---

## Requirement coverage

| JD requirement | Questions |
|---|---|
| Own the member complaints process end to end | D1, F4, G1 |
| across branches and the contact centre | B2, D1, G3 |
| report monthly on complaint volumes and resolution times | C4, E1 |
| coach branch supervisors on escalations | C1, G2, H1 |
| work with digital teams on self-service journeys | C3, E1 |
| 4+ years in financial-services customer operations | A1 |
| experience handling regulated complaints | D3, G1 |
| confident presenting to senior leaders | D2, C2 |
| comfortable with Excel reporting | C4 |

Published values: F1 to F4 in round 3. Strategy: B3, E1 and E2.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says the log, not the process end to end |
| Handled regulated complaints | Inflated form of F7 | F7's quote at its own scope. The material says formal, not regulated; D3's slot asks only which rules those complaints fell under |
| Has worked in a contact centre | Negative you stated, F2 | The plain acknowledgment F2 gives: "I've never worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment F8 gives: "I've never presented to anyone above regional level." No slot |
| Reported monthly volumes and resolution times in Excel | Inflated form of F3 and F9 | F3's quote at its own scope. The material says a monthly complaints spreadsheet, not what it counted or which program built it; C4's slot stays inside the spreadsheet |
| Coached supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: new tellers and a script. C1's slot stays inside the tellers you trained |

## Sources

Provided documents: the job description you pasted; the values text you copied on 26 November 2026, which you gave as from ashgrovecu.org/about/values and which was not fetched; the recruiter's email about the process; your account of the July 2026 strategy brief, as four points (the brief itself was not read); your background message. No dossier was present.

Searches and fetches sent: none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | skipped | The pasted values text already fixes the four value names and wording used in the cheat sheet and F1 to F4 |
| 2. `{company} interview process {role family}` | skipped | The recruiter's email fixes the three rounds, who runs each, their lengths and the values round; persona weights follow it |
| 3. `{company} strategy` / recent news | skipped | Your four points from the July 2026 brief fix the grounding brief, B3, E1 and E2 |
| 4. `{interviewer name} {company}` | n/a | No interviewer has been named, so there was no query to form; the interviewer read is absent |
| 5. representative `{role title}` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV, or fuller sentences about your work → rows F1, F3, F4, F7 and F9 could move from answer slots to story-mapped rows; nothing here assumes more than your message states
- A copy of the monthly complaints spreadsheet with member details removed → F3 and F9 could rise from low or medium to high, because it is the inspectable artifact this field keeps
- The full text of the July 2026 strategy brief → the grounding brief, B3, E1 and E2 would rest on the brief itself rather than on four relayed points
- How the 20-minute case is delivered, and what it scores → G1 to G3 could become a build section if a deliverable is pre-declared, and round 3 weights would be recomputed
- Interviewer names and titles, once assigned → an interviewer read, persona reweighting, and a reverse question tied to each person's own path
- Your own answers on pay, notice, location and why you are leaving → A2 to A5 would quote your words instead of giving instructions
- The time you have before 5 December → a prioritised prep schedule sized to it
- A `tuesday-dossier.md`, if you have one from an earlier look at this role → underwriter-graded evidence and a named top objection for the Skeptic banks; this pack is complete without it
