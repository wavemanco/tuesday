# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

Prepared for Dara, 26 November 2026. Three rounds on 5 December 2026, built as a loop from the recruiter's email.

- **Round 1:** the recruiter, 30 minutes.
- **Round 2:** the Head of Member Services, who would be your manager, 45 minutes, mostly behavioural.
- **Round 3:** a panel of two branch managers, 60 minutes, including a 20-minute case on a complaint escalation. The panel is also the values round and scores against the four published values.
- **Interviewers:** names not assigned yet, so there is no interviewer read. Persona weights rest on the round types and the recruiter's email.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored. Every question carries one type tag:

| Tag | What it is really testing |
|---|---|
| VAL | Whether past behaviour shows the company's published values, not generic virtue |
| EXP | Whether your account of your own work survives scrutiny, and what was actually you |
| JD | A stated responsibility or requirement in the job description, including its gaps |
| CO | Whether you can think at the company's altitude: strategy, competition, recent moves |
| CASE | Structure and reasoning on a live problem from the actual role |

- Guidance is scaffolding, not a script. Where it coaches a claim about your past, the Provenance cell quotes the sentence of yours it rests on.
- An **answer slot** is an instruction for the interview, not a question for you now. If your answer to one is a sentence or two in your own words, send it and the pack upgrades.
- Provenance labels: `[grounded]` is traceable to a document you gave me; `[inferred]` is a derivation from an adjacent source; `[generic]` is a pattern with no claim about Ashgrove or about you.
- **Highest-ROI prep in the whole pack: C1.** It is the question your material is thinnest against, and it will arrive in some form in Round 2.

## Fit snapshot (shared across all three rounds)

Your evidence is the five sentences in your message and nothing else; no CV was supplied. The requirement column quotes the job description you pasted.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says one branch's log and the escalation script, not the process across branches, so the words stay at that scope: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what happened to a complaint beyond the log likely. If any later stage was yours, say which and what you did, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the log |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You stated the absence, so the words are yours: "Never worked in a contact centre." Then say what you would want to learn first about how a complaint moves between a contact centre and a branch, as a plan and never as a past. Nothing is added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your sentence says a monthly complaints spreadsheet your regional manager uses; it does not say what it counted. Answer slot: the JD names volumes and resolution times, so expect a probe on what yours showed. If it showed either, say which and how it was worked out, in your own words; if it did not, or it showed something else, say so plainly and stay with the spreadsheet you built |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says new tellers and the escalation script, not supervisors: "I trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on supervisors likely. If you have guided any supervisor on an escalation, say who and what your part was; if not, say so plainly and stay with the tellers |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Strong evidence here would be a named piece of work with a digital or online team and the part you played in it. Answer slot: the JD's self-service line makes a probe likely. If you have worked with such a team, say on what and what your part was, in your own words; if you have not, say so plainly and say what you would ask that team first about why members complain |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead with your own terms, "6 years in retail banking, the last 3 as a branch supervisor", rather than the JD's label |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | Your sentence says a formal complaints log; it does not say which rules applied to it. Answer slot: the JD says regulated, so expect a probe on what rules applied to the complaints in your log. If you can name them and say what they meant for how you kept the log, do so in your own words; if you are unsure which applied, or none did, say so plainly and stay with the log |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You stated the absence, so the words are yours: "I've never presented to anyone above regional level." Then how you would prepare for a senior audience, as a plan and never as a past. Nothing is added to make the gap feel smaller |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your sentence says a spreadsheet, not which tool it was built in. Answer slot: the JD names Excel, so expect a probe on what it was built in and what it could do. If it was Excel, say what you did in it; if it was something else, say so plainly and stay with the spreadsheet you built |

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| "Own the member complaints process end to end across branches" | C1, E2, H1 |
| "across branches and the contact centre" | B1, C1, H2 |
| "report monthly on complaint volumes and resolution times" | F1 |
| "coach branch supervisors on escalations" | C3, H3, I1 |
| "work with digital teams on self-service journeys" | D3, E1 |
| "4+ years in financial-services customer operations" | A1, B3 |
| "experience handling regulated complaints" | C2 |
| "confident presenting to senior leaders" | C4, D1 |
| "comfortable with Excel reporting" | F1 |

## Grounding brief: what Ashgrove has said

I hold your summary of the July 2026 strategy brief, not the brief itself.

| Fact | Source | Provenance |
|---|---|---|
| Member-owned, about 900 staff | JD | [grounded] |
| Move 40% of member service to digital channels by 2028 | Your summary of the July 2026 brief | [grounded] |
| Consolidate eight branches into five hubs over 2027 | Your summary of the July 2026 brief | [grounded] |
| Launch a small-business lending product in Q1 2027 | Your summary of the July 2026 brief | [grounded] |
| Main competitive pressure is app-only banks | Your summary of the July 2026 brief | [grounded] |
| The brief is dated July 2026, about four months before your interviews | Your message | [grounded] |

---

## Round 1: recruiter screen (30 minutes)

### Persona weights

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly, unstructured opener; logistics asked casually | High. The recruiter-screen prior is Conversational plus a light Skeptic, and nothing in the email shifts it | Rehearse a 90-second arc built from your own sentences; treat every casual question as scored |
| Skeptic (light) | Quick knockout checks on the JD's contact-centre and senior-presenting lines | Medium. A recruiter checks the lines a hiring manager will press; F2 and F8 are where your material is thinnest | Say the stated absences in your own words before being asked; never bridge them with something you did not say |

### Bank A: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through your journey so far." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F6, F1 and F3, in the sentences' own terms: the 6 years in retail banking, the last 3 as a branch supervisor; then the complaints log and training new tellers on the escalation script; then the monthly complaints spreadsheet you built. Tell it in your own words and stop at 90 seconds. Close with why this role, in your own words; your material says nothing about why, so the pack supplies none | The recruiter's opener, and the account every later round will check for consistency. EXP because it tests that your history is told the same way each time |
| A2 | "What salary are you looking for?" | JD | [generic] | Logistics slot: give your own figure or range, or ask for the role's band first; either is fine, so choose the one that is true for you. If asked what you earn now: "I'd rather focus on the range for this role." | A recruiter screen carries a pay question, and the JD text supplied states no band. JD because it concerns the listed job's terms |
| A3 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period, in your own words | A standard recruiter-screen logistics slot; the only safe answer is your own. JD because it concerns the job's start |
| A4 | "Where are you based, and is the role's location workable for you?" | JD | [generic] | Logistics slot: give where you are actually based and any limit you actually have on where you can work, in your own words | A standard recruiter-screen logistics slot. JD because it concerns the listed job's terms |
| A5 | "What's prompting you to look at a move now?" | EXP | [generic] | Logistics slot: give your actual reason in your own words, and say only what you would repeat to the Head of Member Services in Round 2, because the same reason will be asked again | The recruiter is checking motivation consistency across the loop. EXP because it tests whether your account of your own career is stable |

### Bank B: Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "I don't see contact-centre experience in your background — how would you handle that part of the role?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Concede first, in your own words: "Never worked in a contact centre." Then say what you would ask first about how a complaint travels between a contact centre and a branch, as a plan and not a past. Do not claim it by analogy | F2 is the knockout line a recruiter can check in one sentence. JD because the contact centre is named in the first responsibility |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Choose a weakness that is true. Your material states two absences, F2 and F8; name one yourself, in your own words, before they do, and follow it with how you would close it, as a plan. Do not offer a weakness you do not have | The standard Skeptic stem, and a recruiter notes whether the answer is candid. JD because it scores the stated requirements, gaps included |
| B3 | "The role asks for 4+ years in financial-services customer operations. Where does your experience sit against that?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Give the facts in your own terms: "6 years in retail banking, the last 3 as a branch supervisor." If asked whether that counts as customer operations, describe what the work was and let them judge; do not agree to a label you cannot describe | F6 is the closest match to the years line, and the recruiter's job is to tick it. JD because it screens a stated requirement |

### Reverse questions: Round 1

| # | Question | Why it lands |
|---|---|---|
| RQ1.1 | "Is the 20-minute case in the panel round given in advance, or presented cold on the day?" | A recruiter can answer it, and the answer decides whether the case needs a build section |
| RQ1.2 | "Do you know yet who is on the panel, and will I have their names before 5 December?" | Names unlock an interviewer read and per-member preparation |
| RQ1.3 | "Is there anything the Head of Member Services wants covered in the 45 minutes?" | Recruiter guidance is the highest-leverage input; one answer replaces round-type assumptions |
| RQ1.4 | "How is the role split between the branches and the contact centre today?" | Shows you read the first responsibility, and the answer calibrates how hard the contact-centre gap will be pressed |
| RQ1.5 | "What does the timeline look like after 5 December?" | Closes the loop on process and shows you are planning, not just reacting |

---

## Round 2: Head of Member Services (45 minutes, your future manager)

### Persona weights

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the scale jump, the regulated-complaints line and the senior-presenting line | Highest. A hiring manager derisks gaps, and F1, F2 and F8 give a manager who owns the outcome plenty to press | Rehearse C1 until it is boring; hold what the quotes carry, concede the rest specifically |
| Values/Behavioral | Open prompts such as "tell me about a time" | High. The recruiter described this round as mostly behavioural | Where a quoted sentence carries a story, tell it at its own scope; where none does, use the scaffold and its honest branch |
| Case/Strategist | Live problems from the strategy: digital shift, hub consolidation | Medium. Hiring-manager prior, and the strategy brief gives them a roadmap to test you on | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Data-Driven Prober | Line-by-line questions on the monthly reporting | Lower. The reporting line is one responsibility among several | Say what the spreadsheet showed and how, in your own words, and say plainly where you do not know |

### Bank C: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've handled your branch's complaints log. This role owns the process across every branch and the contact centre — how do you get from one to the other?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "Never worked in a contact centre, and I've never presented to anyone above regional level." | The deepest rehearsal in the pack. Name the limit before it is asked: the hold is only what the quote carries, "I handled the branch's formal complaints log and trained new tellers on our escalation script." First follow-up, on the contact centre: concede in your own words, "Never worked in a contact centre," then say what you would learn first, as a plan. Second follow-up, on what happened after a complaint left your log. Answer slot: if any later stage was yours, say which and what you did; if there was no such step, or it was not yours, say so plainly and return to the log and the script. Hold the log through both follow-ups, concede the scale and the contact centre explicitly and specifically, and never fold on the log | F1 and F2 are the widest gap against the headline responsibility, so this objection arrives in some form from a manager who owns the result. JD because it scores the stated responsibility, gap included |
| C2 | "The role asks for experience handling regulated complaints. What have you handled?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F7, only as far as the quote goes: the formal complaints log. Answer slot: the JD says regulated, so expect a probe on which rules applied to the complaints in your log. If you can name them and say what they meant for how you kept the log, do so in your own words; if you are unsure which applied, or none did, say so plainly and stay with the log. Do not describe regulation you did not work to | The JD names regulated complaints as a requirement, and F7's evidence touches it without showing it. JD because it screens the stated requirement |
| C3 | "The role coaches branch supervisors on escalations. What's your experience of coaching?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F4, at the sentence's own scope: new tellers, our escalation script, trained. Answer slot: the JD names supervisors, so expect a probe on whether you have guided one. If you have, say who, on what, and what your part was; if you have not, say so plainly and stay with the tellers. If asked how you would coach a supervisor who is your equal, answer as a plan, in your own words | F4 is adjacent work, tellers rather than supervisors, so the probe on the difference is likely. JD because it scores a stated responsibility |
| C4 | "The role presents to senior leaders. What's your experience of that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Your own words are the guidance: "I've never presented to anyone above regional level." Say that first, plainly. Answer slot: if you have presented at regional level, say what it was and to whom, in your own words; if what you did there was not a presentation, say so plainly and stop there. Then say how you would prepare for a senior audience, as a plan | F8 is a stated absence, and a manager will want to hear it candidly and with a plan. JD because it scores the stated requirement |

### Bank D: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something they did not want to hear. It needs a named stake, what you said, how they reacted and what stayed intact. If no such time comes to mind, say so plainly, then give the nearest thing you have actually done, or how you would handle it. Use "we" for context and "I" for what you did | A standard behavioural prompt in a mostly behavioural round, and it presses on F8's gap from the side. VAL because it scores behaviour, not a stated requirement |
| D2 | "Tell me about a time you put a member ahead of an internal target." | VAL | [grounded] | Selection scaffold: pick a decision where the member's interest and the easier internal route pointed different ways. It needs the member's situation, the call you made and why, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing you have actually done, or how you would handle it | The theme comes from the first published value, "we decide from the member's side of the counter". VAL because it rehearses the values before the panel round |
| D3 | "Tell me about a time you worked with a team outside your own to get something done." | JD | [grounded] | Selection scaffold: pick a piece of work that crossed team lines. It needs who the other team was, what each side needed and what you personally did. If no such time comes to mind, say so plainly, then give the nearest thing you have actually done, or how you would approach working with a digital team on a member journey | F5 has no evidence given, and the JD's digital-teams line raises this theme. JD because it scores a stated responsibility |

### Bank E: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Ashgrove wants 40% of member service on digital channels by 2028, with app-only banks the main pressure. What should that mean for how we handle complaints?" | CO | [grounded] | Structure aloud: clarify what counts as service moved to digital and which complaint types are in play; state the objective, such as a member not having to explain a complaint twice; segment complaints by channel; propose an approach; name the metrics; name the risks. Challenge one premise respectfully, for example whether every complaint can be resolved in self-service. This question needs no claim about your past, so the guidance makes none | Strategy fluency separates candidates; the brief you hold supplies the facts. CO because it scores whether you can think at the company's altitude |
| E2 | "Eight branches become five hubs through 2027. Walk us through how you'd keep complaint handling consistent while that happens." | CASE | [grounded] | Structure aloud: clarify what changes for members and for supervisors during the move; objective; which complaints are most exposed; approach; metrics; risks. Name the tension with "every branch is part of its town" openly rather than waiting to be asked. No claim about your past is needed | A live problem from the strategy brief, and a likely hiring-manager roadmap question. CASE because it scores structure and reasoning |

### Bank F: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "The role needs Excel reporting. Walk me through the monthly complaints spreadsheet you built — what was it built in, and what did it show?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F3 and F9, with only the beats the sentence states: you built it, it is monthly, it is about complaints, and your regional manager uses it. Answer slot: the JD names Excel, volumes and resolution times, so expect a probe on all three. If it was Excel, say so and what it did; if it counted volumes or resolution times, say how each was worked out, in your own words; if any of that was not so, say so plainly and stay with what you built | The only reporting artifact in your material, so it is where a prober starts. JD because it scores the Excel and monthly-reporting lines, with EXP in how it is probed |

### Reverse questions: Round 2

| # | Question | Why it lands |
|---|---|---|
| RQ2.1 | "Which complaints reach you today, and which do you wish reached you sooner?" | Asks about ownership and escalation from their side, which is what the role exists to improve |
| RQ2.2 | "With eight branches becoming five hubs through 2027, what should the complaints process look like at the end of it?" | Shows you read the strategy brief and asks for the outcome they are steering toward |
| RQ2.3 | "When the small-business lending product launches in Q1 2027, will its complaints sit inside this role?" | Ties a published launch to the role's scope, which a prepared candidate notices |
| RQ2.4 | "Who sees the monthly complaints report, and in what setting?" | Turns the senior-presenting requirement into a concrete expectation you can prepare for |
| RQ2.5 | "What would you want to see from me by month three?" | Lets your future manager define success, and signals you plan to deliver |

---

## Round 3: panel of two branch managers (60 minutes, including a 20-minute case)

The recruiter said this round scores against the four values, so a values-style round is established and the cheat sheet sits here.

### Persona weights

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario prompts mapped to the four published values; stories expected | Highest. The recruiter said the panel scores against the four values | One story or scaffold per value; "we" for context, "I" for contribution; choose stories where the hard truth landed, and where none exists say so |
| Case/Strategist | The 20-minute case on a complaint escalation | High. The recruiter named it as part of this round | Clarify, then objective, approach, who owns it, what the member is told, what is recorded, what is learned |
| Peer Evaluator | Where is the seam, what do you need from us, what happens when we disagree | Medium-high. The role coaches branch supervisors, so branch managers will price what the hire costs and contributes to their branches. This is inferred from the JD, not from anything they have said | Offer seam principles rather than pretending to know their seam; frame what the role gives their branches |

Which panel member suits which persona is unknown until names are assigned.

### Bank G: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you made a call from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick a decision where the member's interest and the branch's easier route pointed different ways. It needs the member's situation, the call you made and why, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I handled the branch's formal complaints log and trained new tellers on our escalation script," at that scope, or how you would handle it | Value 1, "Members First, Always". VAL because the panel scores against this value by name |
| G2 | "Tell me about a time something had to be explained to a member twice." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick a time an explanation, a letter or a script did not land the first time. It needs what was unclear, what you changed and what happened next. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "trained new tellers on our escalation script," at that scope, or how you would handle it | Value 2, "Plain Words": if a member needs it explained twice, the wording was wrong. VAL because it scores this value by name |
| G3 | "Tell me about a time what a branch's town needed and what the figures said were not the same." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Selection scaffold: pick a situation where a local circumstance mattered more than the headline figure. It needs the circumstance, what the figures said, what you did and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "the last 3 as a branch supervisor," at that scope, or how you would handle it | Value 3, "Neighbours, Not Numbers". It is the value most in tension with a role that reports monthly volumes. VAL because it scores this value by name |
| G4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick a problem you found, not one handed to you. It needs how you found it, what you did and who else you involved, and the point it was actually solved. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I handled the branch's formal complaints log," at that scope, or how you would handle it | Value 4, "Own the Fix", and the closest to the JD's end-to-end ownership line (F1). VAL because it scores this value by name |

### Bank H: Case/Strategist (the 20-minute complaint escalation case)

I do not know the case's format or materials, so these three rehearse the structure of an escalation case rather than its content.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Here is a complaint that has been escalated from a branch. Talk us through how you would handle it and what you would want to know first." | CASE | [generic] | Structure aloud. Clarify: what has the member been told, what are they asking for, and what rules or time limits apply to this kind of complaint. State the objective. Name who owns it from here on. Say how the member is told, in plain words. Say what is recorded and what the branch learns. Check whether it is a one-off or a pattern. This question needs no claim about your past, so the guidance makes none | The recruiter named an escalation case; this is its likeliest shape. CASE because it scores structure and reasoning |
| H2 | "Same complaint. It first came in through the contact centre and the member then went to a branch. What changes?" | CASE | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Ask how the contact centre records a complaint and how it is handed to a branch, and who owns it at each point. Where you do not know, say plainly that you would find out first; your own words are "Never worked in a contact centre." Do not bluff the contact centre's process | The JD's first responsibility spans both channels, and F2 is the gap a panel can test live. CASE because the problem is set in the role |
| H3 | "Partway through, the branch supervisor disagrees with your call. What do you do?" | CASE | [generic] | Hold your call through two follow-ups where your reasons are sound; if they raise a fact you did not have, concede it explicitly and change the call. Keep the supervisor in the decision so the escalation is also a coaching moment. This question needs no claim about your past, so the guidance makes none | The role coaches supervisors on escalations, so the panel will test the human side of the case. CASE with Pressure delivery |

### Bank I: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "You would coach our supervisors on escalations. Where is the seam between your job and a branch manager's, and what happens when we disagree?" | JD | [grounded] | Offer principles rather than pretending to know the seam: who decides a member's outcome, who coaches, who reports, and that you would agree it with them rather than assume it. Disagreement: say how you would raise it, with the member's outcome as the shared test. No claim about your past is needed | The panel are the people whose supervisors the role coaches. JD because it scores the stated coaching responsibility from the stakeholder's side |
| I2 | "How do you handle credit and blame when a complaint spans a branch and a central team?" | JD | [generic] | Offer principles: whoever finds the problem keeps hold of it until it is solved, credit goes to the people who did the work, and blame goes to the process, not the person. Keep it short and concrete; this asks how you think, not about your past | The stem is the Peer Evaluator's, and the "Own the Fix" value makes the theme live. JD because it concerns cross-team working |
| I3 | "What would you need from us to make this work?" | JD | [generic] | Lead with reciprocity: what a branch manager gets from the role, such as supervisors coached on escalations and a monthly report on complaints, before what you need. Then name one or two things you would ask for, in your own words | Peers price what a hire adds to their own work, and a generic answer here wastes the slot. JD because it concerns working with the people the role depends on |

### Values and principles cheat sheet

No quoted sentence of yours carries a full story for any of the four values, so each row is a selection scaffold ending in its honest branch.

| Value (official name) | Working meaning (paraphrased) | Mapped story or selection scaffold |
|---|---|---|
| Members First, Always | Decisions are made from the member's side of the counter | Scaffold at G1. Nearest your material carries, at its own scope, F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." If nothing real comes to mind, say so plainly |
| Plain Words | If a member needs something explained twice, the wording failed, not the member | Scaffold at G2. Nearest your material carries, at its own scope, F4: "I handled the branch's formal complaints log and trained new tellers on our escalation script." If nothing real comes to mind, say so plainly |
| Neighbours, Not Numbers | Each branch belongs to its town; members are neighbours, not figures | Scaffold at G3. Nearest your material carries, at its own scope, F6: "6 years in retail banking, the last 3 as a branch supervisor." If nothing real comes to mind, say so plainly |
| Own the Fix | Whoever finds a problem stays with it until it is solved | Scaffold at G4. Nearest your material carries, at its own scope, F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." If nothing real comes to mind, say so plainly |

### Reverse questions: Round 3

| # | Question | Why it lands |
|---|---|---|
| RQ3.1 | "Which escalations from your branches take the most time, and what do you wish a central team did differently?" | Asks for their pain point first, which is what a peer evaluator is listening for |
| RQ3.2 | "How would you want a complaints lead to work with your supervisors: on the floor, or from a distance?" | Surfaces the working model and shows you are planning how to coach, not just that you will |
| RQ3.3 | "How are the changes to the branch network affecting your supervisors day to day?" | Connects to the eight-to-five hub plan and the value about each branch being part of its town, without presuming an answer |
| RQ3.4 | "What does 'Own the Fix' look like in your branch when a problem crosses to another team?" | Asks them to define a value in practice, which shows you took the value seriously |
| RQ3.5 | "What could a new person in this role do in their first month that would genuinely help your branches?" | The reciprocity question for peer interviewers; it turns the panel's opinion into your first-month plan |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log and trained new tellers on our escalation script." The limit is the pack's observation, not words for you: the material says one branch's log and the script, not the process across branches |
| Has contact-centre experience | Negative you stated, F2 | Your own words: "Never worked in a contact centre." No slot |
| Presented to senior leaders or executives | Negative you stated, F8 | Your own words: "I've never presented to anyone above regional level." No slot |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: new tellers and the escalation script. The limit is the pack's observation: the material says tellers, not supervisors |
| Reported complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." The limit is the pack's observation: the material does not say what it counted |
| Handled regulated complaints | Inflated form of F7 | F7's quote at its own scope: a formal complaints log. The limit is the pack's observation: the material does not say what rules applied |
| Built Excel reports | Inflated form of F9 | F9's quote at its own scope: a monthly complaints spreadsheet. The limit is the pack's observation: the material does not say which tool |

## Sources

Provided documents:
- The job description you pasted
- The values text you copied on 26 November 2026 from the company's values page
- The recruiter's email about the three rounds
- Your summary of the July 2026 strategy brief; I have not seen the brief itself
- The background paragraph in your message

No searches or fetches were sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | skipped | The values text you pasted fixes the cheat sheet and the VAL questions; a search could not have moved them |
| 2. `{company} interview process {role family}` | skipped | The recruiter's email fixes the three rounds, their lengths, who runs them, the case and the values scoring, so the persona weights and loop do not depend on a search |
| 3. `{company} strategy` / recent news | skipped | Your summary of the July 2026 brief, about four months old, supplies the facts the CO and CASE questions use |
| 4. `{interviewer name} {company}` | n/a | No names are assigned yet, so there was no query to form; the interviewer read is absent and the upgrade menu says what names would unlock |
| 5. representative `{role title}` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV: every fit row rests on five sentences from your message, and exact lines would let me quote more and may close some answer slots
- A sentence or two, in your own words, on the answer slots at F1, F3, F4, F5, F7 and F9: each slot you answer becomes quoted evidence and upgrades those rows and the questions that draw on them
- Interviewer names and roles: an interviewer read, per-member persona weights for the panel, and a reverse question tied to their own path
- The format of the 20-minute case, cold or with materials in advance: if materials or a presentation are announced, a build section for it, and the three H questions reweighted
- The recruiter's guidance on the Head of Member Services' 45 minutes: replaces round-type assumptions with the stated focus
- The July 2026 strategy brief itself: a fuller grounding brief and CO questions built on more than four facts
- Hours available before 5 December: a prioritised prep schedule
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, covering role-family loop reports and recent organisation context; reply yes to run it
- A tuesday-dossier.md from an earlier check of this role, if you have one: verified evidence and a ready-made list of claims not to make; the pack does not need it
