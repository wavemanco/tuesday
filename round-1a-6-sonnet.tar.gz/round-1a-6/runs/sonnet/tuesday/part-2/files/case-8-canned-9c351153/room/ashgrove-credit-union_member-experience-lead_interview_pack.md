# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara. **Mode:** loop (three rounds, 5 December 2026). **Built:** 26 November 2026.

| Round | Who | Length | What the recruiter said |
|---|---|---|---|
| 1 | The recruiter | 30 min | "30 minutes with me" |
| 2 | Head of Member Services, your future manager | 45 min | "mostly behavioural" |
| 3 | Panel of two branch managers, names not yet assigned | 60 min | "including a 20-minute case on a complaint escalation"; "the values round — they score against the four values" |

## How to use this pack

Personas describe how a question will be asked. Types describe what is being scored. Guidance is scaffolding, not a script: every sentence about your past is one of your own sentences, quoted, and where the pack could not find one it gives you an answer slot instead. An answer slot is an instruction for the interview with two honest branches. Meet either one from your own experience.

Highest-ROI prep in this pack: **E2**, the step from one branch's complaints log to owning the process across branches and the contact centre. It is asked in the recruiter's register at B2 and tested as a live case at G1.

| Tag | Name | What it tests |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behaviour shows Ashgrove's published values |
| EXP | Work-experience deep-dive | Whether your stated experience survives scrutiny |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge | Whether you can think at Ashgrove's altitude |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the role |

## Fit snapshot (shared by all three rounds)

Proposed wording in the last column: pending your approval.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | Say it in your own terms and stop: "6 years in retail banking, the last 3 as a branch supervisor." The JD's phrase is customer operations; your words say retail banking and branch supervisor, so the answer stays in them. Nothing inspected sits behind the line, so expect a probe on it |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | low | [inferred] | discovery | Your material says a formal complaints log and does not show whether outside rules governed its entries. Words: "I handled the branch's formal complaints log." Answer slot: if outside rules or time limits applied to those entries, say what you know of them and what part was yours, in your own words; if none applied, or you do not know, or it was not yours, say so plainly and stay with the log |
| F3 | "Own the member complaints process end to end across branches and the contact centre" — JD (the branches half) | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says one branch's log, not a process across branches. Words stay at that scope: "I handled the branch's formal complaints log." Answer slot: if you saw or handled complaints from any other branch, say how and what part was yours; if not, or it was not yours, say so plainly and stay with the one branch |
| F4 | "Own the member complaints process end to end across branches and the contact centre" — JD (the contact centre half) | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | Your material says a monthly spreadsheet your regional manager uses and does not show what it held. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: say what it counted, in your own words; if it did not track resolution times, or volumes, say so plainly and say what it did track |
| F6 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your material says tellers and a script, not supervisors. Words stay at that scope: "I trained new tellers on our escalation script." Answer slot: if you have advised or coached any supervisor on a live escalation, say what happened and what changed; if not, say so plainly and stay with the tellers |
| F7 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent on this. Answer slot: if you have worked with any digital, product or IT team on something members used, say what it was and what part was yours; if you have not, say so plainly, then say as a plan which complaints you would want a person to keep |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Then how you would prepare, said as a plan and never as a past |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | Your message says spreadsheet and does not name the tool. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: say what it was built in; if it was another tool, say which, and say what you did in it |

## Grounding brief

Facts come from your summary of the strategy brief, which you said Ashgrove published in July 2026. The full brief would add its own vocabulary.

| Fact | Source | How it may come up | Provenance |
|---|---|---|---|
| Move 40% of member service to digital channels by 2028 | Your message (summary of the brief) | D2, G3 and reverse questions; test every self-service idea against the Plain Words value | [grounded] |
| Consolidate eight branches into five hubs over 2027 | Your message (summary of the brief) | D3 and R3's reverse questions; the round 3 panel is two branch managers | [grounded] |
| Launch a small-business lending product in Q1 2027 | Your message (summary of the brief) | A new product brings its own complaint types; a good reverse question for the manager | [grounded] |
| Main competitive pressure is app-only banks | Your message (summary of the brief) | Frames why self-service wording and speed matter; ties to Plain Words | [grounded] |

## Prohibited claims (not coached anywhere in this pack)

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the member complaints process end to end across branches | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says the branch's log, not the process across branches. E2's slots stay inside the log |
| Has handled regulated complaints | Inflated form of F2 | F2's quote at its own scope. The pack's observation: your material says a formal complaints log and does not say what governed its entries. B4's slot asks only what governed the entries |
| Coached branch supervisors on escalations | Inflated form of F6 | F6's quote at its own scope: tellers and a script. The pack's observation: your material does not mention supervisors being coached |
| Reported complaint volumes and resolution times to leaders | Inflated form of F5 | F5's quote at its own scope: a monthly spreadsheet your regional manager uses. The pack's observation: your material does not say what it held or who else saw it |
| Has contact-centre experience | Negative the candidate stated, F4 | The plain acknowledgment F4 gives: "I've never worked in a contact centre." No slot |
| Has presented to senior leaders | Negative the candidate stated, F8 | The plain acknowledgment F8 gives: "I've never presented to anyone above regional level." No slot |

---

# Round 1: the recruiter (30 minutes)

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly and unstructured; pay, notice, location and the reason for leaving arrive as chat | High. Recruiter-screen prior, and the recruiter described a 30-minute conversation with them | A 90-second arc built from your own sentences; treat every casual question as scored |
| Skeptic (light) | Knockout checks on the JD's requirements in a friendly register | Medium. Prior for a recruiter screen, and the JD has requirements your material does not fully show (F2, F4, F8) | Rehearse the single predictable objection until it is boring; concede plainly and give a plan |

## Conversational bank

Proposed answer wording below: pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your journey in banking." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F1, F3, F5 and F6: three beats, each one of your sentences at its own scope. The six years in retail banking and the last three as a branch supervisor; the complaints log you handled and the tellers you trained on the escalation script; the monthly spreadsheet your regional manager uses. Close on why this role in your own words: the pack has no reason from you | The opener every screen starts with; F1, F3, F5 and F6 are the rows the arc draws on. EXP because the recruiter will test the arc against what you say later |
| A2 | "What's behind the move, and why Ashgrove?" | EXP | [generic] | Logistics slot. Give your actual reason for leaving, in your own words, as one sentence you can repeat word for word if asked again. For Ashgrove: if one of the four published values is a real reason for you, name it exactly as published; if none is, say what drew you in your own words | A standing recruiter-screen slot, scored for consistency; EXP because the reason is about your history, and the pack has none from you |
| A3 | "What salary are you looking for?" | JD | [generic] | Logistics slot. Give your own figure, or ask for the role's band first; either is your choice. If asked what you earn now, you can decline and redirect to the range for this role | The JD states no pay terms, so this is the first place a figure is asked; JD because it concerns the listed job's terms |
| A4 | "What's your notice period?" | JD | [generic] | Logistics slot. Give your actual notice period in your own words | A standing screen question; the 5 December date makes the start date a natural follow-up. JD because it concerns the job's terms |
| A5 | "The role works across branches and the contact centre. Any constraints on where or how often you can be on site?" | JD | [grounded] | Logistics slot. Give your own answer on where you can work and how often. The JD names no location or pattern, so it is also fair to ask the recruiter what the role expects; your summary of the brief says eight branches become five hubs over 2027, so the base may change | The JD's own line on branches and the contact centre makes a location question likely; JD because it concerns the job's terms |

## Skeptic bank

Proposed answer wording below: pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role asks for four-plus years in financial-services customer operations. How does your background line up?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Say it in the quote's own terms and stop: "6 years in retail banking, the last 3 as a branch supervisor." Let them ask for more rather than adding to it | A knockout check on the JD's one numeric requirement; F1 is the row. JD because it scores the stated requirement |
| B2 | "The role covers the contact centre as well as branches. What's your experience on the contact-centre side?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script" | Hold-then-concede. Concede first and plainly: "I've never worked in a contact centre." Then stay with what you said at its own scope: the branch's log, the tellers and the script. Then a plan, as a plan: what you would learn first and from whom, in your own words. Do not offer branch work as the equivalent | This is the same objection as E2, in the recruiter's register: F4 is the row, and it will be asked here first. JD because it scores the stated requirement |
| B3 | "The job includes presenting to senior leaders. How comfortable are you with that?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment first: "I've never presented to anyone above regional level." Answer slot: if you have presented at regional level or below, say what and to whom, in your own words; if you have not, say so plainly. Then a plan for how you would prepare, said as a plan | F8 is the row; the JD says "confident presenting to senior leaders", so a recruiter will check it early. JD because it scores the stated requirement |
| B4 | "The role asks for experience handling regulated complaints. What have you handled?" | JD | [inferred] "I handled the branch's formal complaints log" | Say those words, at that scope. Answer slot: expect a probe on what, if anything, governed the entries in the log. If you know, say what and your part, in your own words; if you do not know, or it was not yours, or nothing governed them, say so plainly and stay with the log | F2 is the row, and the thinnest on the JD's own list; the pack's guidance asks only what governed the entries. JD because it scores the stated requirement |

## Round 1 reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "How will the 20-minute case on 5 December be set: is there material beforehand, and what is it scored on?" | You can only prepare the case once you know its format; the recruiter described it, so they can answer |
| R1.2 | "What is the pay band, and what working pattern does the role expect across branches, hubs and the contact centre?" | The JD states neither, and the recruiter holds both |
| R1.3 | "Which branches do the two panel managers run, and how does the hub plan touch them?" | Tells you what the round 3 panel is dealing with, and ties to the 2027 consolidation in the brief |
| R1.4 | "Where does the complaints process sit today between branches and the contact centre, and who owns it now?" | Shows what end to end means in practice and whether the role consolidates or replaces |
| R1.5 | "What happens after 5 December, and when will you decide?" | Closes the logistics and sets your expectation for the follow-up |

---

# Round 2: the Head of Member Services (45 minutes)

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scenario probes: a time you kept hold of a problem, a time you told someone senior something unwelcome | High. The recruiter called the round mostly behavioural, which lifts this above the hiring-manager prior | Story where one of your sentences carries one; a scaffold with its honest branch where none does; "we" for context, "I" for contribution |
| Case / Strategist | Live questions drawn from the role and the 2026 brief | Medium. Hiring-manager prior, and the JD names digital self-service; the recruiter's "mostly" leaves room for it | Clarify, then objective, then segmentation, then approach, then metrics, then risks; think aloud |
| Skeptic | Probing the gaps against the JD: the contact centre, presenting up, coaching supervisors | Medium. Hiring-manager prior; the manager would own the hire's gaps | Rehearse the objection until it is boring; concede plainly and give a plan |

## Values / Behavioral bank

Proposed answer wording below: pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you kept hold of a problem until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: pick a problem with a named stake, a reason it was yours, the steps you took and an end state. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the log at its own scope, or how you would handle it. Answer slot: if any entry stayed with you from first report to resolution, say what it was and what you did; if the log recorded outcomes others resolved, say so plainly | The JD's "own" line and the Own the Fix value both press here; F3 is the row. VAL because it scores behaviour against a published value |
| C2 | "Tell me about a time you delivered an unpopular truth to someone senior." | VAL | [grounded] "I've never presented to anyone above regional level" | Selection scaffold: a named stake, a moment you did not fold, a relationship intact at the end. Your material states a limit on presenting up, so choose a person within the level it carries, or say the limit. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | The JD asks for confidence with senior leaders and F8 is the gap; a behavioural round probes it by story. VAL because it scores behaviour |
| C3 | "Tell me about the branch's formal complaints log and your part in it." | EXP | [grounded] "I handled the branch's formal complaints log" | Story-mapped on F3: the log, the branch, formal complaints, handled by you; those are the beats the quote states. Answer slot: expect a probe on what an entry held, who else touched it and where a complaint went once logged; say what you know and which part was yours; if you only recorded entries, or complaints moved on without you, say so plainly | F3 is the evidence for the process requirement and the likeliest place to be probed. EXP because it tests what was actually yours |
| C4 | "The role includes monthly reporting on complaint volumes and resolution times, in Excel. Tell me about the spreadsheet you built." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F5 and F9: you built it, it is monthly, your regional manager uses it. Answer slots: say what it counted, in your own words; if it did not track resolution times, or volumes, say so plainly; say what it was built in, and if not Excel, which tool, and what you did in it | F5 and F9 are the two JD lines the spreadsheet touches, and it is the one artifact you can offer to walk through. JD because it scores the stated requirement |

## Case / Strategist bank

Proposed answer wording below: pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "The role works with digital teams on self-service journeys. What have you done with a digital team?" | JD | [grounded] | Answer slot. Your material shows none, so this is yours to fill or concede. If you have worked with any digital, product or IT team on something members used, say what it was and what part was yours; if you have not, say so plainly, then say as a plan which complaints you would want a person to keep | F7 is the row; the JD names the requirement and the brief makes digital the direction. JD because it scores the stated requirement |
| D2 | "Ashgrove aims to move 40% of member service to digital channels by 2028. Which complaint types would you keep with a person, and how would you decide?" | CASE | [grounded] | Clarify first: what counts as member service, and how the 40% is measured. Then objective, then segment complaint types by what a member needs, then approach, then metrics, then risks. One test worth saying aloud: if a member needs a self-service answer explained twice, the wording failed, so watch repeat contacts. Challenge one premise respectfully. The question asks nothing about your past, so the guidance makes no claim | The brief's headline target is the likeliest strategy case for this role; the 40% is from your summary of it. CASE because it is a live problem; strategy-grounded as the rubric asks |
| D3 | "Eight branches are due to become five hubs over 2027. What does that change for a complaints process?" | CO | [grounded] | Structure it: who a member goes to, where a complaint is first heard, what stays local, what the report should show. Use only what you know of the plan, and say what you would need to ask. The question asks nothing about your past, so the guidance makes no claim | The consolidation is the brief's structural change and the one that touches branches directly. CO because it tests whether you can think at the company's altitude |

## Skeptic bank

Proposed answer wording below: pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Pick one of the two your material states, and say it plainly: "I've never worked in a contact centre," or "I've never presented to anyone above regional level." Then a plan for it, as a plan, in your own words. Do not name a third gap the pack has not found | F4 and F8 are the two gaps you stated; the question invites you to choose one before the interviewer does. JD because it scores honest self-assessment against the listed job |
| E2 | "This role owns the complaints process across branches and the contact centre. You've had one branch's log. What carries over?" | JD | [grounded] "I handled the branch's formal complaints log"; "Never worked in a contact centre"; "trained new tellers on our escalation script" | **Highest-ROI prep.** Name the limit before it is asked: the branch's log, and no contact centre. Follow-up 1, what carries over: "I handled the branch's formal complaints log," and the tellers and the escalation script, each at its own scope. Follow-up 2, and the contact centre: "I've never worked in a contact centre." Then a plan, as a plan. Follow-up 3, why should we think you can own it end to end: hold by returning to the quote, never by adding to it, and concede the step explicitly: "That is a step beyond a branch's log, and the contact centre is new to me." Then what you would learn first, in your own words | F3 and F4 are the two rows the objection aims at, and it will be asked in some form in every round. JD because it scores the headline responsibility |
| E3 | "The role coaches branch supervisors on escalations. What have you done that is like that?" | JD | [grounded] "trained new tellers on our escalation script"; "the last 3 as a branch supervisor" | Say what you said, at its scope: "I trained new tellers on our escalation script," and the last three years as a branch supervisor. Answer slot: if you have advised or coached any supervisor on a live escalation, say what happened and what changed; if not, say so plainly and stay with the tellers | F6 is the row. JD because it scores the stated responsibility |

## Round 2 reverse questions

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "What do you want the monthly complaints report to help you decide?" | Tells you what to build first, and it is the manager's own use of the report the JD asks you to produce |
| R2.2 | "Where does ownership of complaints sit today between branches and the contact centre, and what would change once one person owned it end to end?" | Defines the scope of the headline responsibility in the manager's own words |
| R2.3 | "How do escalations from branch supervisors reach the contact centre or your team today?" | Surfaces the seam your coaching would sit on, without claiming you know it |
| R2.4 | "Which self-service journeys come first on the way to the 2028 digital target, and where do complaints fit?" | Ties the digital line of the JD to the brief's target |
| R2.5 | "What would the first 90 days look like, and what would you want me to have learned about the contact centre by the end of them?" | Turns the gap you have stated into a plan the manager can react to |

---

# Round 3: the panel of two branch managers (60 minutes, with a 20-minute case)

Names are not yet assigned, so no interviewer read is written. When names arrive the persona table gets a per-member assignment.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scenario probes scored against the four published values | High. The recruiter said the panel is the values round and scores against the four values | Map a story to each value where one of your sentences carries one; a scaffold with its honest branch where none does |
| Case / Strategist | The 20-minute complaint-escalation case | High. The recruiter put a 20-minute case in a 60-minute round | Say your structure aloud first; clarify, then structure, then answer; challenge one premise respectfully |
| Peer Evaluator | Seam-splitting: where the role meets the branches, and what happens when you disagree | Medium. The JD has the role coaching branch supervisors, whose branches these managers run | Reciprocity: what you bring them; propose principles for the seam instead of pretending to know it |

## Values / Behavioral bank

Proposed answer wording below: pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Members First, Always: we decide from the member's side of the counter. Tell me about a time you made a decision from the member's side." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: pick a decision that was yours, with a named member stake and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the log at its own scope, or how you would decide. No sentence of yours carries this story, so the pack supplies none | The value is published; F3 is the nearest row and carries no decision. VAL because it scores behaviour against a named value |
| F2 | "Plain Words: if a member needs it explained twice, we wrote it wrong. Tell me about a time you made something clear enough that it needed saying once." | VAL | [grounded] "trained new tellers on our escalation script" | Selection scaffold, with one slot. Answer slot: if any wording of the escalation script was yours, say which and why; if it was set elsewhere, or you only trained people on it, say so plainly. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would do it | The value is published; F6 is the nearest row and says training, not writing. VAL because it scores behaviour |
| F3 | "Neighbours, Not Numbers: every branch is part of its town. Tell me about a time you weighed a figure against what a branch or its town needed." | VAL | [grounded] "the last 3 as a branch supervisor" | Selection scaffold: a figure, a local need, a decision, what followed. If a time from those three years comes to mind, tell it in your own words; if no such time comes to mind, say so plainly, then say how you would weigh them. No sentence of yours carries this story | The value is published and the panel is two branch managers; F1 is the nearest row. VAL because it scores behaviour |
| F4 | "Own the Fix: whoever finds the problem keeps hold of it until it is solved. When did you find a problem that was not yours and keep hold of it?" | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: how you found it, why you kept it, what you did, how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the log at its own scope, or how you would handle it. The panel round is the one that scores against this value by name, so rehearse one concrete answer | The value is published; F3 is the nearest row. VAL because it scores behaviour |
| F5 | "Tell me about a time a colleague handled an escalation differently from how you would have, and what you did." | VAL | [grounded] "trained new tellers on our escalation script" | Selection scaffold: what was different, what you said, how it ended, what you left alone. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the escalation script and the tellers at that scope, or how you would handle it | The JD has you coaching supervisors on escalations, so disagreement over one is likely; F6 is the nearest row. VAL because it scores behaviour |

## Case bank

Proposed answer wording below: pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "A member has complained three times about the same fee. The branch says it is resolved; the contact centre's record says it is open; the member now says they will close their account. Walk us through what you do." | CASE | [generic] | Say your structure aloud. Clarify: what the fee is, what the member was told, who holds the case now, whether it has been formally logged and what time limits apply here. Objective: the member's problem fixed and one owner. Action today: name the owner, tell the member in plain words what happens next and by when. Cause: why two records disagree. Record and report: what goes into the monthly report. Coach: what the supervisor needs. Challenge one premise, such as whether the records are wrong or the process is. The question asks nothing about your past | The recruiter said the case is a complaint escalation; this is a pattern for it, not Ashgrove's own case. CASE because it is a live problem. Ask the recruiter what the case looks like (R1.1) |
| G2 | "A branch supervisor escalates a complaint late and incomplete, and the member is unhappy. How do you coach them?" | CASE | [generic] | Ask what happened before judging it. Agree the standard in plain words. Pick one thing to change. Follow up on the next escalation. Keep the member's fix separate from the coaching conversation. The question asks nothing about your past | The JD's coaching line, as a live problem. CASE because it asks for a method, not a story |
| G3 | "Your monthly report shows complaints resolved more slowly through the contact centre than in branches. What do you do with that?" | CASE | [generic] | Check the measure first: is the clock the same in both channels? Split by complaint type. Find what differs. Talk to both teams before you present. Take one recommendation, in plain words. The question asks nothing about your past | The JD's reporting line meets the two channels. CASE because it is a live problem |

## Peer Evaluator bank

Proposed answer wording below: pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "You would be coaching branch supervisors on escalations. Where is the seam between your role and ours, and what happens when we disagree about one?" | JD | [grounded] "the last 3 as a branch supervisor" | Propose principles, not facts about the seam: agree who decides before an escalation is live; take disagreements to a named person; never keep the member waiting while you settle it. Reciprocity: say what you would ask them for and what you would offer. Your own sentence is "the last 3 as a branch supervisor"; it states where you stood, and the guidance draws no more from it | F6 is the row; panelists score partnership fit. JD because it scores the coaching responsibility |
| H2 | "How do you handle credit when a fix spans teams?" | VAL | [generic] | Selection scaffold: who did what, how it was said aloud, how it landed. If no such time comes to mind, say so plainly, then say how you would handle it | A standard peer probe; no sentence of yours carries it. VAL because it scores behaviour toward colleagues |

## Values cheat sheet (the panel scores against these)

Values are quoted as the page you copied on 26 November 2026 gives them. Proposed wording: pending your approval.

| Value (official name) | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No sentence of yours carries a story here. Scaffold: a decision that was yours, a member stake, what happened; if none comes to mind, say so plainly and give the nearest thing or how you would decide (F1 above) |
| Plain Words | If a member needs it explained twice, the wording was wrong | No sentence of yours carries a story here. Nearest: F6 "trained new tellers on our escalation script", at its scope; answer slot in F2 above |
| Neighbours, Not Numbers | Every branch is part of its town | No sentence of yours carries a story here. Scaffold: a figure against a local need; if none comes to mind, say so plainly (F3 above) |
| Own the Fix | Whoever finds a problem keeps hold of it until it is solved | No sentence of yours carries a story here. Nearest: F3 "I handled the branch's formal complaints log", at its scope; slots in C1 and F4 |

## Round 3 reverse questions

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "As eight branches become five hubs over 2027, how should the complaints process work for members whose branch becomes part of a hub?" | Ties to the brief and to the branch managers' own work |
| R3.2 | "What does a good escalation from one of your supervisors look like, and what does a poor one cost your branch?" | Surfaces what the coaching has to change |
| R3.3 | "Where do you want me useful to you in the first month, and where should I stay out of the way?" | The reciprocity question for a peer-style panel |
| R3.4 | "What do your members say about self-service and the app?" | Connects the digital target and app-only competition to what branches hear |
| R3.5 | "When a complaint is resolved in a branch, how does the contact centre find out today?" | Probes the seam the role would sit on |

---

## Sources

- Provided: the JD as pasted in your message; the values text you copied on 26 November 2026 from ashgrovecu.org/about/values; the recruiter's email about the process; your summary of the 2026 strategy brief, July 2026 (I have your four points, not the brief); your background in your message.
- No searches or fetches were sent.
- Round structure comes from the recruiter's email (a loop source: it names three sessions and who runs each). A values-style round is detected because the email says the panel scores against the four values.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The values text you pasted is in hand and fixes the cheat sheet and the VAL questions |
| 2. `Ashgrove Credit Union interview process member services` | skipped | The recruiter's email fixes the rounds, who runs each and the case; it fixes persona weights |
| 3. `Ashgrove Credit Union strategy` | skipped | Your summary of the July 2026 brief is in hand and fixes the CO and CASE grounding |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No interviewer has a name yet, so there was no query to form; there is no interviewer read |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD questions |

## Upgrade menu

- Your CV, or the lines behind the complaints log and the monthly spreadsheet → F1, F2, F3, F5, F6 and F9 get firmer evidence, and several `[inferred]` or `discovery` rows can become story-mapped answers
- Your own answers to the slots in F2, F3, F5, F6, F7 and F9, stated outside a drill → those rows quote your words and the matching bank rows turn slots into story maps
- The names and titles of the Head of Member Services and the two panel managers → an interviewer read, per-member persona weights and tailored reverse questions
- The full 2026 strategy brief → CO and CASE questions in its own vocabulary, and a fuller grounding brief
- The recruiter's answers to R1.1 and R1.2 (the case format, pay band, location pattern) → a build section if material is announced, and fewer `[generic]` rows
- How many hours you have before 5 December → a prep triage sized to it
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes: Ashgrove's recent news, public interviewer footprints once named, interview reports for this role family, recent organisation context) — offered once
- A `tuesday-dossier.md` from a separate job-underwriter pass → verified evidence, allowed strategy per weak area, and absolute prohibited claims, in place of the ones built locally here
