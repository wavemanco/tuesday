Web research was refused, so I'm building the pack from your inputs and your research note. I'm writing it now.
Your prep pack for Priya is saved as `/var/tmp/tuesday-measure/1a6/runs/sonnet/tuesday/part-2/rooms/case-1-denied-5273d748/Northwind-Data_senior-gtm-strategy-lead_interview_pack.md`.

I built it as a 60-minute peer conversation with Dan. It has 20 questions across six personas, with type tags, answer guidance and rationale on every row. It also has a fit snapshot, an interviewer read, reverse questions and a "not coached" list.

- **Persona weighting:** I weighted Data-Driven Prober highest (5 questions), then Peer Evaluator and Skeptic (4 each), Case (3), and Conversational and Pressure (2 each). "Relentlessly data-driven" pushed the Prober up, and his pricing background tilts the cases toward packaging and pricing.
- **Top prep item:** C1 is the question to rehearse most. It asks about her stated gap, "No classic sales-ops or quota-setting experience". It has the deepest follow-up structure, because Dan sits near that remit.
- **Quotes and slots:** Everything the guidance says about Priya's past rests on a quote from your message. Where her material stops, as with how the ~$400M was counted or what part of partner-motion design was hers, the guidance is an answer slot, not a supplied detail.
- **No research ran:** All three web searches (values, interview process, Dan) were refused. Company facts come only from your research note, and its freshness is unchecked. The pack has no values cheat sheet or VAL questions for that reason, since no values page was in hand and no values round is detected.

Say the word and I'll play Dan on C1.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Did the recruiter share any focus areas for the conversation with Dan, or a pre-declared deliverable such as a POV or presentation? If so, I'll reweight the banks and build that section.
Can you paste the full JD and Priya's own CV lines? I worked from your summary, and I can proceed without them.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Northwind-Data_senior-gtm-strategy-lead_interview_pack.md -----
# Interview prep pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy at Northwind Data, a peer (both report to the same VP). **Format:** one 60-minute conversation. **Built on:** your inputs only. All three web searches were refused, so nothing here comes from research. Company facts are your research note's, and freshness is unchecked.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did. An answer slot is an instruction for the interview. Answer it from your own experience, or say plainly that the practice was not yours or did not exist.

**Highest-ROI prep: C1.** It is the objection most likely to be asked in some form, so rehearse it until it is boring.

| Tag | Name | What it is really testing | Question IDs in this pack |
|---|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the company's published values | None. No published values were in hand and no values-style round is detected, so none are written. The upgrade menu says what would change this |
| EXP | Work-experience deep-dive | Whether the claims survive scrutiny; what was actually yours | A1, A2, B3, C1, E1, F1 |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included | A3, A5, B1, B4, C2, C3, C4, E2 |
| CO | Company and strategy knowledge | Whether you can think at the company's altitude | D1, D3 |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the actual role | A4, B2, D2, F2 |

## Fit snapshot

The requirements are quoted from the JD highlights in your message. The evidence is quoted from your notes on Priya, not from her CV. Each row's words stay at the quote's own scope.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | Your material says proposed and credited, with nothing inspected behind the figure, and the words stay there: "I proposed a store-surface change credited with a ~$400M ARR uplift." Answer slot: the JD's own-GTM line makes a probe on what part of taking something to market was yours to decide likely. If any part was, say which and how you decided, in your own words; if there was no such decision, or it was not yours, say so plainly and stay with the proposal. The figure will be probed too: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours (A1, A2) |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — the coach's notes; "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | transferability | Both quotes are adjacent work. The material shows a revenue model and annual volume targets, not an analysis of where customers could land, adopt, expand or renew. Words at the quotes' scope: "I built a partner-level revenue model used in carrier negotiations." Answer slot: the JD's whitespace line makes a probe on how you would find it likely. If either piece of work looked across stages of a customer relationship, say how, in your own words; if neither did, say so plainly and give your approach as a plan, never as a past (A5, C3) |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | discovery | The quote names tools, and the material does not show whether the analysis was independent. Words: "I'm skilled in SQL/Tableau." Answer slot: if you ran analyses yourself, from the data to the answer, say which and what they informed, in your own words; if analysts or others pulled the data or built the views, say so plainly and stay with the tools (A3, A4) |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | A model used in negotiations is adjacent to designing a motion, and the words stay at the model: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if any part of how the partner relationship was structured was yours to design, say which and how you decided; if the model informed negotiations others ran, or there was no such design, say so plainly and stay with the model (C2) |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | none | No gap, but a line from your notes with nothing inspected behind it, so expect a probe. Lead with the quote's own terms: you set annual volume targets, with cross-org consensus. Influence is the JD's word, so keep it out of your own history (B1, B3) |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — the coach's notes | medium | [grounded] | discovery | The quote shows use, and the material does not show whether it reaches what the plus is after. Words: "I use AI tools daily." Answer slot: if you can say which tools and for what, do so in your own words; if the use is light or narrow, say so plainly (E2, D2) |
| F7 | Sales-ops and quota-setting fluency for a GTM seat beside Sales Strategy (a role-family expectation; no JD highlight states it) | "No classic sales-ops or quota-setting experience" — the coach's notes | none | [grounded] | capability | A gap wording cannot close, and your note states it. Words: "I don't have classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. Never a claim to have set quotas, and nothing added to make the gap feel smaller (C1, F1) |

## Grounding brief

A short vocabulary check from your research note. Freshness and original sources were not checked.

| Item | Source | Provenance | Feeds |
|---|---|---|---|
| Company: "B2B data-infrastructure SaaS, ~3,000 employees" | your message | [grounded] | All CASE and CO framing |
| Stated priorities: "enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" | your research note | [grounded] | C3, D2, D3 |
| Main competitive threat: "bundling by a much larger platform vendor" | your research note | [grounded] | D1 |

## Reading the interviewer

Public professional footprint only, as you described it. Nothing here comes from a search.

| Signal | Source | Provenance | What it means for this conversation |
|---|---|---|---|
| "relentlessly data-driven" | his profile's self-description, per your note | [inferred] | Every number you give gets probed to its assumptions. The Prober bank is the heaviest, and the weakest-assumption move is your main defense (A1 to A5) |
| "career spine is pricing and monetization roles, with one early-stage-startup chapter" | your note on his profile | [inferred] | Pricing, packaging and unit economics are his native vocabulary, so cases tilt that way (D2, D3). The early-stage chapter suggests a probe on pace and scrappiness, and builder stories would land with him. Your material carries no builder claim, so none is coached |
| Director of Sales Strategy; peer; same VP | your message | [inferred] | He is weighing what you cost his team and what you add to it. Offer reciprocity, not just needs (B4, reverse questions) |

**Vocabulary overlap, not a shared jump:** F4's "built a partner-level revenue model used in carrier negotiations" is the nearest thing in your material to his revenue and monetization vocabulary. Use it in his terms. It is not a claim of pricing work, and no sentence in your material says you did any.

## Persona table

The weights come from three passes: relationship prior, interviewer signals, then the loop. Recalibrate if you know something the pack doesn't.

| Persona (bank) | How it shows up with Dan | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober (A, 5 questions) | Inputs, denominators, "how was that counted", live data puzzles | Highest. A peer prior, and "relentlessly data-driven" pushes it up. F1 is a headline figure | Know what you can and cannot say about how the figure in F1 was counted, and say plainly when you do not know. Name the assumption you would defend least before he does |
| Peer Evaluator (B, 4 questions) | Seam-splitting with his team, "what do you need from me", credit and disagreement | High. The peer prior, and he is pricing what you cost and contribute | Reciprocity: what you bring his team, not just what you need. Propose seam principles instead of pretending to know the seam |
| Skeptic (C, 4 questions) | Quiet, persistent probing of the gaps in F7, F4, F1 and the consumer-to-enterprise move | High. F7 is a gap you stated, and his title puts it near his remit. Whether his team owns quota design is not known from your inputs, so it is worth asking the recruiter. His startup chapter suggests a pace probe | Rehearse C1 until it is boring. Bridges use only what the quotes carry. Concede specifically, never on the core claim |
| Case / Strategist (D, 3 questions) | Live problems from Northwind's stated priorities, tilted to pricing and packaging | Medium. A peer rarely runs a full case, but a Director of Sales Strategy tests whether you can think at the company's altitude, and your note supplies the priorities | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully |
| Conversational / Rapport (E, 2 questions) | The opening biography, a casual question on AI | Medium-low. It will happen at minute one of 60 whatever his style. Casual questions are still scored | A 90-second arc built only from your quoted path. Treat the AI question as scored |
| Pressure / Stress (F, 2 questions) | Time-boxed challenges, interrupting a case | Low. Nothing in his profile signals it, so these items rehearse composure only | Pause, restate, hold the position through two follow-ups, concede specifically |

Values / Behavioral is not weighted. No published values were in hand, and your words establish a single peer conversation, so no values-style round is detected.

## Question banks

### A. Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've said a store-surface change you proposed was credited with a ~$400M ARR uplift. Walk me through how that number was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Open with the sentence at its own scope: "I proposed a store-surface change credited with a ~$400M ARR uplift." Then the four slots a figure raises, each in your own words. Answer slot: if you know how the credit was calculated, say how; if you do not know how it was counted, say so plainly, which is an honest answer. Answer slot: say what the figure is most sensitive to, and which assumption behind it you would defend least, before he asks. If there is an analysis you ran yourself behind it, offer to walk through it end to end; if there is not, do not offer one. Never state a method, baseline or attribution model you cannot repeat under a second question | F1 holds the only quantified claim, and a self-described data-driven peer will go to it first. EXP because it tests whether the claim survives scrutiny |
| A2 | "Which part of that result was actually yours?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | The verb is the boundary: you proposed it, and the result was credited. Say that first, in your own words. Answer slot: if you did more than propose, say what, and how you know it was yours; if the proposal was the extent of your part, say so plainly and describe how you came to propose it. Do not let the uplift stand as something you delivered. Hold through two follow-ups by returning to the quote, never by adding to it | F1 is the figure the attribution probe lands on. EXP because it scores precise ownership, not the number |
| A3 | "Tell me about an analysis you ran yourself in SQL or Tableau, end to end." | JD | [grounded] "skilled in SQL/Tableau" | Selection scaffold, since the quote names tools and no analysis: pick one where you wrote or built the work yourself, with a named question, the data you used, what you checked before trusting it, and what it changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach it. Answer slot: if you ran analyses yourself, say which; if analysts or others pulled the data, say so plainly and stay with "skilled in SQL/Tableau" | F3 is the JD's SQL and Tableau line, and the only evidence is a tool list. JD because it scores the stated requirement; a data-driven peer is the likeliest to test it |
| A4 | "You join an accounts table to a usage table and the total jumps. Walk me through how you would find out why." | CASE | [generic] | A live problem with no claim about your past. Clarify first: the grain of each table, the key you joined on, what the total is supposed to represent. Then hypotheses in order of likelihood (duplicated keys fanning out rows, mismatched grain, a changed filter), then how you would test each, then what you would check before telling anyone the number. Think aloud and say which check you would do first | F3 gives no detail on the depth of SQL, so a live puzzle is how a data-driven peer checks it. CASE because it is delivered live, with the JD's SQL line behind it |
| A5 | "Take one of the two new lines. What data would you pull first to find the whitespace across land, adopt, expand and renew, and what would you refuse to conclude from it?" | JD | [generic] | A live problem with no claim about your past. Clarify which line and what a customer is. Then segment the base (who has landed, adopted, expanded, renewed), say what each stage's data would show, and name what you would not conclude from thin history on a new line. End with the one metric you would trust least and why. If you have no data to anchor a number, say what you would ask for first | F2 shows adjacent work only, so this is where the whitespace requirement is tested live. JD for the requirement, with a CASE delivery |

### B. Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You set annual volume targets with cross-org consensus. How did you get there?" | JD | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on the three things the quote states: the targets, that they were annual, and that there was cross-org consensus. Tell those in your own words. Answer slot: the JD's cross-functional influence line makes a probe on where the orgs disagreed likely. If they disagreed, say about what and what you did; if consensus came easily or the process was set by others, say so plainly and stay with what the quote carries. Say targets, never quotas, which keeps you consistent with C1 | F5 is the evidence for the influence requirement, and a peer will ask how it worked in practice. JD because it scores the stated requirement |
| B2 | "Our teams sit side by side. Where is the seam between your role and mine, and what happens when we disagree?" | CASE | [generic] | No claim about your past. You do not know the seam, so propose principles instead of pretending: who owns which decision, who defines the shared metrics, and where an unresolved disagreement goes (the VP you both report to). Add what you bring his team before what you need from it. Ask him where the seam is today | A peer persona's signature question, written for two people who share a VP. CASE because it asks for live design reasoning, not history |
| B3 | "Tell me about a time you disagreed with a peer in another organisation. What happened?" | EXP | [generic] | Selection scaffold: choose a disagreement where the stakes were real, you held a position without becoming defensive, and the relationship was intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry (F5's volume targets, at their own scope), or how you would handle it. Use we for context and I for your contribution | A peer-credit and disagreement probe, tied to the JD's influence line (F5). EXP because it scores what you actually did, not a stated value |
| B4 | "What would you need from me and my team in your first sixty days, and what would I get from you?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus" | Needs as principles: shared definitions of land, adopt, expand and renew; read access to the data behind them; clarity on which decisions are yours versus his. What you bring, at the quotes' scope: "I built a partner-level revenue model used in carrier negotiations" and "I set annual volume targets with cross-org consensus." Add nothing to them | F4 and F5 are the two pieces of evidence that bear on the seam. JD because it scores what owning the new lines' GTM needs from a neighbouring team |

### C. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "I don't see classic sales-ops or quota-setting experience in your background. How would you handle that in this role?" | EXP | [grounded] "No classic sales-ops or quota-setting experience"; "set annual volume targets with cross-org consensus" | **Highest-ROI prep in the pack.** Pause, restate the question in one line. State the limit before he asks for it: "I don't have classic sales-ops or quota-setting experience." Then what your material carries, at its own scope: "I set annual volume targets with cross-org consensus." Let him draw the line between targets and quotas; do not draw it in your favour. Then the plan, said as a plan: what you would ask to read and learn in your first weeks, and the one thing you would lean on his team for, named in your own words. Hold through three follow-ups. If he asks whether a volume target is just a quota, return to what you set and say how his team's process would be learned. If he asks what you would get wrong first, concede one specific thing in your own words and do not fold the core claim. If he asks why not hire someone who has done it, return to the limit and the quote and add nothing | F7 is your stated gap, and it sits near a Sales Strategy director's remit. EXP because it tests candid self-assessment. It gets the most follow-up levels because it is the question you can be sure of |
| C2 | "Partner-motion design is a required line in this role. What part of a partner motion have you designed yourself?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Hold only what the quote carries: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if any part of how the partner relationship was structured was yours to design, say which and how you decided; if the model informed negotiations others ran, or there was no such design, say so plainly and describe the model. The limit is not a confession. Hold through two follow-ups by returning to the model, never by adding to it | F4 is where the JD's required line presses hardest. JD because it scores a stated requirement and its gap |
| C3 | "Your last nine years were at a large consumer-tech company. What do you expect to be different about land, adopt, expand and renew in enterprise B2B?" | JD | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A view on the role, not a claim about your past. Structure it as hypotheses, labelled as hypotheses, and invite correction: who buys, how long decisions take, what renewal depends on, what expansion depends on. Answer slot: if you have had direct exposure to enterprise buyers, say what and in what capacity; if you have not, say so plainly before the hypotheses. The enterprise-expansion priority is your reason this matters | F2 is adjacent work only, and Northwind's first stated priority is enterprise expansion. JD because the motion is the JD's own line |
| C4 | "Tell me about the closest you've come to owning a go-to-market. What was yours to decide?" | JD | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Open prompt, so a selection scaffold: pick an occasion with a named stake, a decision that was yours, and a result you can describe at its own scope. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry: "I proposed a store-surface change credited with a ~$400M ARR uplift." Do not call that a launch or a go-to-market. The limit is that the quote says proposed | F1 is the closest evidence to owning a GTM, and the JD's first line is about owning one. JD because it scores that requirement and its gap |

### D. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our main threat is a much larger platform vendor bundling against us. For one of the two new lines, how would you shape the go-to-market so bundling doesn't commoditize it?" | CO | [grounded] "bundling by a much larger platform vendor" | No claim about your past. Clarify first: which line, which customer, what is bundled, how much switching is costly. Then segment where a bundle is strongest and weakest, choose an approach (positioning, packaging, who you sell to first), the metric that would tell you it is working (win rate versus price realised), and the main risk. Challenge one premise respectfully: whether bundling hits win rate or price more | Bundling is the competitive threat in your note, and a pricing-minded peer will care about packaging. CO because it scores company altitude, with a CASE delivery |
| D2 | "Compass is our AI copilot launch. How would you think about whether it is sold as an add-on, bundled into existing plans, or offered free to drive adoption, and what would change your mind?" | CASE | [grounded] "an AI copilot launch ('Compass')" | No claim about your past. Say what you need to know first (who the buyer is, what usage looks like, what the copilot costs to serve). Compare the three options on adoption, margin and the bundling threat, and say what evidence would move you between them. Name the assumption you would test first. If you do not know a fact, say so and say how you would get it | Compass is a stated priority, and pricing is his native vocabulary. CASE because it is a live decision, with a CO anchor |
| D3 | "Reaching profitability is one of our stated priorities. Which of land, adopt, expand or renew would you invest in first for the new lines, and why?" | CO | [grounded] "reaching profitability" | No claim about your past. Frame the trade-off: where the next dollar of effort returns most, given a new line has little history. Then name the data you would want, and what would make you change the order. Tie it to the other two priorities in one line, not three | It joins the JD's stages to the profitability priority in a single question. CO because it tests whether you can reason at the company's altitude |

### E. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc with only the beats the quote states: two years in strategy consulting, then nine at a large consumer-tech company in product strategy and ops. Answer slot: say in your own words why this role and why now, since the pack does not supply a reason; if the honest answer is partly "I wanted a new context", say so. Expect "and why now" as the follow-up | Every 60-minute conversation opens here, and a casual opener is still scored. EXP because it tests the story's consistency |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Start at the quote's scope: "I use AI tools daily." Answer slot: say which tools and for what, in your own words; if the use is light or narrow, say so plainly. Do not describe building anything with AI unless you did | F6 is the JD's plus, and a casual question is where a rapport style tests it. JD because it scores a stated line |

### F. Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you, rather than someone who has run quotas and sales ops?" | EXP | [grounded] "No classic sales-ops or quota-setting experience"; "built a partner-level revenue model used in carrier negotiations" | Pause, then restate the question. Hold the position the quotes carry, and no more: state the limit ("I don't have classic sales-ops or quota-setting experience"), then "I built a partner-level revenue model used in carrier negotiations." Let him weigh it. Hold through two follow-ups; concede the limit explicitly, never the core claim | F7 under time pressure; this is C1 delivered as a stress question. EXP because it tests whether the answer holds |
| F2 | "Stop. I only care about the answer. Give me your recommendation now, with what you know." | CASE | [generic] | He interrupts a case you are mid-way through (D1 or D2). Do not drop the structure. Give a provisional answer in one sentence, name the one assumption it rests on, and say what would change it. Concede what you do not yet know. Then continue | It tests composure inside a case, which is where this persona usually appears. CASE because it is the live-problem format under interruption |

### Requirement coverage

| Requirement | Questions that cover it |
|---|---|
| "own GTM strategy for two new product lines" | C4, B4, D1, D3 |
| "identify whitespace across land/adopt/expand/renew" | A5, C3, D3 |
| "run independent analysis in SQL and Tableau" | A3, A4 |
| "partner-motion design experience required" | C2 |
| "strong cross-functional influence" | B1, B2, B3 |
| "AI experience a plus" | E2, D2 |
| Sales-ops and quota-setting (F7, not a JD highlight) | C1, F1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You've spent your career in pricing and monetization. When the two new lines launch, where should pricing sit relative to the GTM motion: decided before it is designed, or after?" | Tied to his own path. It speaks his native vocabulary and asks where the seam between your roles really is |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer. It shows you are thinking about his load, not just yours |
| R3 | "How is bundling showing up in the deals your team sees today, and is it changing how you would position the new lines?" | Anchors to the competitive threat in your note, and asks a data-driven person for evidence rather than opinion |
| R4 | "Which of the metrics for the new lines are you least confident in today?" | Mirrors the weakest-assumption habit you are rehearsing. It invites him to be as candid as you are being |
| R5 | "Your career includes an early-stage startup as well as pricing roles. What from that stage do you wish this team still did?" | Tied to his path again, and turns a probe about pace into a conversation |
| R6 | "What does our VP most want the two of us to agree on in the first ninety days?" | Peer-specific. It surfaces the seam from the one person you both answer to |

## Prohibited claims

What this pack will not coach, and why. Built from the fit snapshot before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Set or carried sales quotas, or has sales-ops experience | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I don't have classic sales-ops or quota-setting experience." What the material carries is "set annual volume targets with cross-org consensus", at that scope. No slot |
| Owned or led a go-to-market, or a launch | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says proposed, not owned or launched. C4's slot stays inside the proposal |
| Drove or delivered the ~$400M ARR uplift | Inflated form of F1 | "Credited with", at its own scope. How it was counted is A1's slot, and the pack states no method |
| Designed partner motions | Inflated form of F4 | F4's quote at its own scope: the material says a model used in carrier negotiations, not a designed motion. C2's slot stays inside the model |
| Influenced stakeholders across functions | Inflated form of F5, borrowing the JD's word | F5's quote at its own scope: volume targets set with cross-org consensus |
| Ran independent analysis in SQL and Tableau | Inflated form of F3 | F3's quote: "skilled in SQL/Tableau". A3's slot asks only what you ran yourself |
| Has AI product or AI go-to-market experience | Inflated form of F6 | F6's quote: "uses AI tools daily". Use is not building |

## Sources

**Provided:** your message (the JD highlights, Priya's background, your description of Dan's profile, and your research note). The research note's original sources and date were not checked.

**Searches sent, all refused:**
- "Northwind Data company values principles" — refused
- "Northwind Data interview process sales strategy" — refused
- "Dan Kovac Director of Sales Strategy Northwind Data" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | The one search was refused. It would have fed a values cheat sheet and values-themed VAL questions, and the upgrade menu offers them |
| 2. `Northwind Data interview process` | unavailable | The one search was refused. It would have named the loop's rounds. Your own words establish one peer session, so the persona weights do not depend on it |
| 3. `Northwind Data strategy` / recent news | skipped | Your research note already supplies the priorities and the competitive threat that feed the CO questions |
| 4. `Dan Kovac Northwind Data` | unavailable | The one search was refused. It would have fed the interviewer read and a reverse question on his talks. The read rests on your description |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Full JD text → the six JD-quoted rows (F1 to F6) move from your highlights to the posting's own wording, and any requirement beyond the highlights gets a row and a JD question
- Priya's CV, or her own sentences for each claim → the evidence cells quote her words rather than your notes, and F1 to F7 and the answer slots in A1 to A3 can be graded more tightly
- Her answers to the answer slots, especially how the ~$400M was counted and what was hers → A1 and A2 move from slots to story-mapped answers, and F1 is regenerated
- Any non-classic exposure to sales ops or quota-setting, if there is some → F7 and C1 get a stronger, still-honest answer
- The recruiter's focus areas, or any pre-declared deliverable for the conversation with Dan → coverage reweighted, and a build section if a deliverable exists
- Northwind's published values page → VAL questions themed on the named values
- Dan's public talks or writing → a reverse question tied to his own themes
- A deeper research pass: up to 6 more searches and 2 more fetches, several more minutes, covering a strategy brief, Dan's footprint, loop reports and recent org context. It needs search permission, and today's searches were refused
- Prep time available → a prioritized schedule for the pack
- A `tuesday-dossier.md` from an earlier review → verified evidence, limits per gap and claims to avoid, in place of the locally built prohibited list
