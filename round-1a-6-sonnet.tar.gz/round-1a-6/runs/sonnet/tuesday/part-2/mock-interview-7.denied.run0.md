Search permission was denied, so I'm building the pack from your message alone. First I'm checking the folder for an existing dossier.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a6/runs/sonnet/tuesday/part-2/rooms/case-7-denied-60ff0152/saltmarsh-games_live-operations-producer_interview_pack.md`. It has 21 questions, plus a fit snapshot, a persona table, reverse questions and a list of claims it won't coach.

- **Research:** My four searches (company values, interview process, strategy, and Tobias) were refused, so the pack uses only your JD and background. It has no company-specific questions, no interviewer read, and no values cheat sheet. The upgrade menu says what a search would add.
- **Assumption:** I built it as a hiring-manager round, because Tobias is the Head of Live Operations.
- **Highest-ROI prep:** The pack's biggest rehearsal item is question B2, about never having worked on a game with in-app purchases. The JD doesn't mention in-app purchases, so I'm treating a question on it as likely rather than certain. B2 has four levels of follow-up, with the exact concession wording written out.
- **Other soft spots:** The JD says two titles and your calendar was for your main title (B3). It also asks for 3+ years of live-service work, and your material doesn't show how your four years add up to that (B4).
- **Answer slots:** Where your material is silent, such as which teams you coordinated with or what changed after your retention presentations, the guidance leaves an answer slot for you to fill in your own words rather than inventing a story.

Say the word and I'll play the Skeptic on B2 as a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, and I can convert the pack to Word.

Is Tobias your future manager, a peer on the team, or more senior? The answer reweights every question bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

For Femi. Interviewer: Tobias Wrenfield, Head of Live Operations. Round: one 60-minute interview, built as a hiring-manager round (the relationship is assumed from his title; you have not said how he relates to the role).

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: where it quotes you, those are your own words from your message, and where it leaves an answer slot, the answer has to come from what you actually did.

| Type | What it is really testing |
|---|---|
| VAL | Whether past behavior shows the values a company publishes, not generic virtue |
| EXP | Whether the claims in your background survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you understand the company and its strategy |
| CASE | Structure and reasoning on a live problem from the role |

This pack was built with no company research (search was not permitted), so there are no CO questions and nothing in it states a fact about Saltmarsh Games beyond the posting you pasted.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title, with nothing inspected behind it, and the words stay there: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's "plan and run" makes a probe on the calendar's contents and timing likely. If you set what went in it or when, say what and how you decided, in your own words; if those were set for you, say so plainly and describe how you ran the weekly calendar |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show which teams your drops involved. Answer slot: the JD names four teams, so expect a probe on which of them you worked with. Say which you worked with on a drop and what you needed from each, in your own words; if you worked with some and not others, or someone else handled it, say so plainly |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your material says you presented monthly retention numbers to the studio head, and the words stay there: "I presented the monthly retention numbers to the studio head." Answer slot inside that sentence: say which numbers you presented and what you told the studio head about them, in your own words; if you do not remember a detail, say so plainly rather than rebuilding it |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | none | No gap in the quote, but a line with nothing inspected behind it, so expect a probe on it. Lead with it in its own terms: you wrote the checklist, and your QA team still uses it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message, and "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | discovery | The years requirement is not a gate, and the quotes do not show which of the four years were on a live game. Answer slot: expect a probe on how the four years add up to the JD's three. Say which of them were on a live game, in your own words; if only the last two were, say so plainly and stay with those two |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap, but nothing inspected behind it. Lead with the quote's own terms: weekly, your main title, the last two years, because specific scope beats an adjective |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | The quote already reaches the requirement: a monthly retention presentation to the studio head. Lead with it as written; a named, regular presentation beats the word comfortable |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | transferability | A written document another team still relies on is adjacent evidence, and it is the only written work in your material. Words: "I wrote the release checklist our QA team still uses." The checklist itself is the inspectable artifact that would raise this row, so it is worth having to hand |
| F9 | Experience with in-app purchases — not in the JD; included because you named it as a limit | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A gap wording cannot close, and you stated it. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Nothing is added to make the gap feel smaller |

## Persona table

Weights start from the hiring-manager relationship prior, which is an assumption (see the question at the end of the message). There are no interviewer signals, because no research on him ran, and no loop source: your message gives one 60-minute session and nothing about its format, so the archetype fallback is Generic, which tilts nothing and leaves the relationship prior standing. No values-style round is detected.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (bank A) | Live problems from the role: plan this calendar, handle this slip, diagnose this metric | High. The hiring-manager prior favors it, and the JD's verbs (plan, coordinate, own) are all things a manager can test with a live problem | Clarify first, then objective, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic (bank B) | Quiet, persistent probing of the gaps: in-app purchases, two titles, how the years add up | High. The hiring-manager prior favors it, and F9, F1 and F5 are where your material is thinnest | Rehearse the in-app-purchases objection (B2) until it is boring; bridge only from what you stated; calibrated candor over bluffing |
| Data-Driven Prober (bank C) | Reads your retention line closely; asks which numbers and what changed | Medium. The JD names retention metrics and KPIs, but the hiring-manager prior does not lead with it | Say exactly which numbers you presented, and say plainly where your knowledge of how they were produced ends |
| Conversational (bank D) | Friendly openers: the journey, what you play, how you write | Medium. A 60-minute session usually opens this way; the register is casual and still scored | A short arc built from your own sentences; treat casual JD questions as scored |
| Pressure (bank E) | Time-boxed challenges: why you, how much was you | Low. Not part of the hiring-manager prior, but your stated limit makes one challenge plausible | Pause, restate, hold through two follow-ups, concede only the specific |
| Peer Evaluator (bank G) | Seam-splitting between teams, credit-sharing | Low. Not a peer relationship as assumed, but the JD is built on coordination | Offer principles for the seam rather than pretending to know it |
| Values / Behavioral (bank H) | Scenario probes about hard truths and priorities | Low. No values-style round is detected and no published values were read | Selection scaffolds that end in the honest branch |

## Question banks

Requirement coverage, JD line to question IDs:

| JD requirement | Questions |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A1, B3, E2 |
| "coordinate design, art, engineering and community teams on each update" | A2, G1, G2 |
| "own the post-event review and the KPIs it reports" | A4, C2, C3 |
| "manage the release checklist with QA" | A5, D3 |
| "3+ years producing live-service games or apps" | B4, D1 |
| "experience running a content calendar" | A1, B3, D1 |
| "comfortable with player-retention metrics" | A3, C1, C3 |
| "clear written communication" | D3 |

The highest-ROI prep in this pack is B2. The in-app-purchases question is the likeliest to be asked in some form, and a calm, specific answer changes the interview. Rehearse it out loud before anything else.

### A. Case / Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You're planning the next live-events calendar for two mobile titles. What do you need to know first?" | CASE | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Clarify before structuring: what the events are for, what each title already has fixed, what art and engineering can deliver and when, what community needs in advance. Then objective, sequence, risks, how you would judge it. Challenge one premise respectfully, such as whether both titles should move in step. If you anchor in your own experience, use your words as written and stop there | F1 and F6 are the requirement; CASE because a manager tests planning live, and JD for the content it tests |
| A2 | "The art for Thursday's event is going to slip two days. Walk me through your next hour." | CASE | [generic] | Confirm the slip and its cause first. Lay out the options (move the date, trim scope, ship part of it), who needs telling and in what order (engineering, design, community, QA), what you would decide yourself and what you would take to someone else, and what you would record for the review. The question needs no claim about your past, so the guidance makes none | F2's requirement, asked as a decision; [generic] because it is a pattern for the problem, not a fact about Saltmarsh |
| A3 | "Retention the day after an event launched came in 20% below plan. Diagnose it." | CASE | [generic] | Clarify the definition and the baseline first. Segment (new against returning players, platform, app version), check what else was live, check with QA whether the release went out as intended, rank the hypotheses, say what you would pull and from whom, and what you would report. Think aloud | F7's requirement as a live problem; CASE because the metric is tested through diagnosis |
| A4 | "Design the post-event review for a two-week event. What is in it, and who reads it?" | CASE | [grounded] "Presented the monthly retention numbers to the studio head" | Structure: purpose, what happened against plan, the numbers (confirm which KPIs the team already tracks rather than inventing a set), causes, what changes for the next event, who reads it. If you anchor in your own work, use your words as written and say what you told the studio head, in your own words | F3 is the requirement; CASE because the review is something a manager asks you to design |
| A5 | "QA finds a blocking bug the evening before an event goes live. What happens next?" | CASE | [grounded] "Wrote the release checklist our QA team still uses" | Structure: severity and scope with QA and engineering first, then the options (fix, hotfix, delay, switch off the affected part), who decides, what you tell design and community and when, and what you change afterward. If you anchor in your own work, say it as written: you wrote the checklist and QA still uses it | F4's requirement; CASE because releases are tested through the day it goes wrong |

### B. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "never worked on a game with in-app purchases" | Pick honestly and say it first. One answer your material supports: "I haven't worked on a game with in-app purchases." Follow it with how you would close it, as a plan. Do not pick a weakness for effect, and do not hide the real one | F9 is the stated limit; JD because it scores the posting's requirements, gaps included |
| B2 | "You haven't worked on a game with in-app purchases. What would you need to learn first to plan events for one?" | JD | [grounded] "never worked on a game with in-app purchases" | The deepest rehearsal. Level one: say the limit plainly before they dig: "I haven't worked on a game with in-app purchases." Level two, the plan. Answer slot: say what you would ask first and who you would ask, in your own words; the pack supplies no mechanics of in-app purchases, and you should not borrow any you could not explain under a second question. Level three, if pushed with "so you would be learning on the job": hold, yes on this one thing, then return to your quotes, each at its own scope (the weekly calendar for your main title, the checklist QA still uses, the monthly retention numbers). Level four, if pushed with "what makes you think events carry over": concede the specific, that you cannot know how much carries over until you have seen how Saltmarsh ties events to purchases, and say what you would look at first. If nothing comes to mind, say so plainly | F9 is the limit you named, and this is where it will press hardest; the likelihood is the pack's reading, not a fact about Saltmarsh. JD because it scores a gap against the role |
| B3 | "You ran the content-drop calendar for your main title. This role covers two titles. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Hold what the quote carries: "I ran the weekly content-drop calendar for our main title for the last two years." Then reason forward as a plan: what you would need to know about the second title, what you would share between the two calendars and what you would keep apart, what clashes you would watch for (shared teams, shared players). Say what you would ask Tobias first | F1 is the requirement; JD because the posting names two titles |
| B4 | "The posting asks for 3+ years producing live-service games or apps. How do your four years add up to that?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" and "I ran the weekly content-drop calendar for our main title for the last two years" | Story-mapped on F5: the four years as an associate producer at a puzzle-game studio, then the last two on the weekly calendar. Keep your title as it was. Answer slot: the JD's three years makes a probe on which years were on a live game likely; say which, in your own words, and if only the last two were, say so plainly and stay with those two. Give only the number you can stand behind | F5 is where the JD's years line meets your material; JD because it scores a stated requirement |

### C. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You presented the monthly retention numbers to the studio head. Which retention numbers were they?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Story-mapped on F7: monthly, and to the studio head, the beats the quote states. Answer slot: the JD's retention line makes a probe on which numbers likely; say which you presented and what you told the studio head about them, in your own words. If you do not remember a definition exactly, say so plainly rather than reconstructing it | F7 is the evidence; EXP because it tests what you actually presented |
| C2 | "After you presented those numbers, what, if anything, changed?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Answer slot: the JD's emphasis on reviews and KPIs makes this probe likely. If something changed, say what and what part of it was yours; if nothing did, or the decision sat above you, say so plainly and return to the monthly presentation | F3 is the requirement; EXP because it tests whether the numbers ever led anywhere |
| C3 | "A post-event review says an event was a success because a number went up. What would make you doubt that?" | CASE | [generic] | Ask: up compared to what, for which players, was anything else live, how is the number counted, did the audience change. Say which you would check first and why. The question needs no claim about your past, so the guidance makes none | F3 and F7 as a reasoning problem; [generic] because it is a pattern, not a fact about Saltmarsh |

### D. Conversational / Rapport Builder (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio", "I ran the weekly content-drop calendar for our main title for the last two years", "Wrote the release checklist our QA team still uses" and "Presented the monthly retention numbers to the studio head" | A 90-second arc built from those four sentences, in that order, each at its own scope. Close on why this role. Answer slot: say your own reason for live operations at Saltmarsh now, in your own words; the pack has no material on your reasons and supplies none | F5, F6, F4 and F7 are the beats; EXP because it is a CV walk-through in a casual register |
| D2 | "What mobile games are you following for how they run their events?" | JD | [generic] | Selection scaffold: pick one you have actually played across an event cycle, say one thing about how its events were paced or announced, and one thing you would do differently. If no game comes to mind, say so plainly, then say which you would study first and what you would look for | Casual questions about the role's hot topics are still scored; [generic] because it asks for your own preferences |
| D3 | "Tell me about a time something you wrote had to be clear to several teams at once." | JD | [grounded] "Wrote the release checklist our QA team still uses" | Story-mapped on F8: you wrote the checklist, and your QA team still uses it. If a better example involves more teams, use that; if not, say so plainly and use the checklist at its own scope. Answer slot: if you made choices about its wording or layout, say what and why, in your own words; if it was built from someone else's draft, say so plainly | F8 is the requirement; JD because the posting names clear written communication |

### E. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a candidate who has already run events for a game with in-app purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years", "Wrote the release checklist our QA team still uses" and "never worked on a game with in-app purchases" | Pause and restate. Hold only what the quotes carry, each at its own scope. Concede the specific without being asked twice: "I haven't worked on a game with in-app purchases." Hold through two follow-ups by returning to the quotes, never by adding to them | F9 is the stated limit; JD because it scores fit against the role under time pressure |
| E2 | "That content-drop calendar: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Hold "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: say which parts you did yourself and which came from others, in your own words; if the contents were set by someone else, say so plainly and stay with what you ran. Concede specifically, never wholesale | F1 and F6 are the claim being tested; EXP because it probes attribution |

### G. Peer Evaluator (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Design, art, engineering and community each want a different date for an event. How do you decide, and who has the last word?" | JD | [generic] | Offer seam principles, not a claim to know Saltmarsh's seam: what each team needs from the date, how you would surface the trade-off, who you would ask where the last word sits. The question needs no claim about your past, so the guidance makes none | F2's requirement as a collaboration scenario |
| G2 | "How do you handle credit when an update involves several teams?" | VAL | [generic] | A principle, not a story: "we" for context, "I" for your own contribution, and name the other teams' parts as theirs. No claim about your past is made here | F2's requirement; VAL because it scores behavior, not a fact |

### H. Values / Behavioral (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not soften it, and a relationship intact afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "Presented the monthly retention numbers to the studio head", at its own scope, or how you would handle it | An open prompt from a standard persona stem; no published values were read, so no value is named |
| H2 | "When did you put a player ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time with a named choice, what the metric would have favored, and what you did. If none comes to mind, say so plainly, then say how you would weigh the two | An open prompt from a standard persona stem; the same limit as H1 |

## Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| R1 | "What would a good first event cycle look like for the person in this role, and what would you want them to have learned by the end of it?" | Shows you are thinking about ramp, and gives you the picture of the first month that your material cannot |
| R2 | "How do the two titles' calendars differ in rhythm, and how does that change the work?" | Turns the two-titles gap (F1) into a question about the job, and tells you what you would be taking on |
| R3 | "How do your titles' events relate to in-app spending, if at all?" | Turns your stated limit (F9) into a learning question, and shows you are asking before assuming |
| R4 | "What does the post-event review look like today, who reads it, and what gets decided from it?" | Speaks to the review and KPI line (F3) and shows you care about decisions, not just numbers |
| R5 | "Where do design, art, engineering and community most often disagree on timing, and who settles it?" | Speaks to coordination (F2) and invites a real answer rather than a pitch |
| R6 | "How would you judge, six months in, that I was doing this job well?" | Prompts the interviewer to say what he is scoring, which is the most useful thing you can leave with |

## Not coached

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team or managed people | Negative you stated: "Never led a team" | The plain acknowledgment: "I've never led a team." Say it only if asked; no slot |
| Has worked on a game with in-app purchases | Negative you stated, F9: "never worked on a game with in-app purchases" | "I haven't worked on a game with in-app purchases." Then the plan, not a past |
| Ran the live-events calendar for two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says a content-drop calendar for your main title |
| Held a producer title | Inflated form of F5 | F5's quote at its own scope: "4 years as an associate producer at a puzzle-game studio" |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope. The material says you presented monthly retention numbers to the studio head; it does not show an owned review |
| Managed releases with QA | Inflated form of F4 | F4's quote at its own scope. The material says you wrote the checklist and QA still uses it; it does not show who ran each release |
| Defined the retention measures the studio tracks | Inflated form of F7 | F7's quote at its own scope; C1's slot asks only which numbers you presented |

## Sources

Provided documents: the job description you pasted, and the background you described in your message. No `tuesday-dossier.md` was present.

Searches sent, each refused (permission to search was not granted):

- "Saltmarsh Games values" — refused
- "Saltmarsh Games interview process live operations producer" — refused
- "Saltmarsh Games strategy news" — refused
- "Tobias Wrenfield Saltmarsh Games" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Would have decided whether a values cheat sheet applies and named any published values for the VAL bank; bank H carries no named values instead |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | Would have replaced the Generic archetype with the real loop and moved persona weights; they rest on the hiring-manager prior instead |
| 3. `Saltmarsh Games strategy news` | unavailable | Would have supplied CO questions and strategy-grounded cases; none are in this pack |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Would have supplied an interviewer read and a reverse question tied to his path; neither is in this pack |
| 5. representative `Live Operations Producer` JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Permission to search → a first pass of up to 6 searches and 2 fetches would supply the loop structure, any published values, recent strategy and an interviewer read; a deeper pass afterward (up to 6 more searches and 2 more fetches, several more minutes) would add strategy cases and a tailored reverse question
- Whether Tobias is your future manager, a peer or more senior → reweights every bank, and drops or adds the peer and pressure rows
- The recruiter's note on format and any pre-announced exercise → coverage of a take-home or presentation, and a real loop in place of the fallback
- The release checklist itself, or a written post-event or retention summary you can show → F4 and F8 move from medium to high, because a document is an inspectable artifact
- Your own answers to the slots in F1, F2, F3 and F5 → those rows get your words in place of a prompt, and B3, B4, C1 and C2 sharpen
- The two titles' names and whether they sell in-app → sharpens B2, R2 and R3 beyond the generic
- A `tuesday-dossier.md` from an earlier review of this role → would supply verified evidence and prohibited claims in place of the ones inferred here
