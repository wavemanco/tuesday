Searches were refused in this session, so I'm building from your notes and will say what that costs. Writing the pack now.
The pack is saved at /var/tmp/tuesday-measure/1a6/runs/sonnet/tuesday/part-2/rooms/case-1-denied-1a50e0db/northwind-data_senior-gtm-strategy-lead_interview_pack.md. It has 22 questions across seven personas, each with a type, provenance, answer guidance and rationale.

**Research was blocked.** All three searches were refused (Northwind values, interview process, Dan's footprint). Everything about Northwind comes from your research note, and the pack says it is unverified. It has no values cheat sheet, and the interviewer read rests only on the profile you gave me.

**Weighting.** I weighted the Peer Evaluator and the Data-Driven Prober highest, five questions each. Dan being a peer sets the Peer Evaluator, and his "relentlessly data-driven" line raises the Prober. The Case and Skeptic banks get three each. Cases lean toward pricing and packaging, which is Dan's home ground.

**Highest-ROI prep is D1.** It is the question "You haven't done classic sales-ops or quota-setting work, so why should Sales Strategy trust your GTM calls?" It has a three-level follow-up ladder, and the "volume targets aren't quotas" concession is built in.

**Claims the pack won't coach.** It won't have Priya claim quota-setting, partner-motion design, pricing work, ownership of the $400M uplift, or AI building. Each is stretched past what you told me. The pack lists each with the honest wording to use instead.

I can play Dan on D1 as a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to Word.

Two questions that would reshape the pack:
1. Did the recruiter say what Dan will focus on, or ask Priya to bring anything, such as a POV, a case or a presentation? That would add a build section and reweight the personas.
2. Can you paste the full JD and Priya's CV bullets word for word? The pack runs on your summaries, and her own sentences would turn several scaffolds into mapped stories. I'll proceed without them if not.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Interview pack: Senior GTM Strategy Lead, Emerging Products — Northwind Data

- **Candidate:** Priya
- **Interviewer:** Dan Kovac, Director of Sales Strategy — her peer, same VP
- **Round:** one 60-minute conversation with Dan (your words); this establishes the loop, so persona weights rest on the relationship and Dan's profile, not on an archetype
- **Built on:** JD highlights in place of the full JD; a summary of Priya's background in place of her CV lines; no web research (every search was refused), so company facts are only those in your research note

## How to use this pack

Personas describe how a question arrives; types describe what is being scored. Guidance is scaffolding, not a script: where a line is in quotation marks it is Priya's own material at its own scope, and where it says answer slot, the answer has to come from her.

| Type | What it scores |
|---|---|
| VAL | Past behavior and how she works with others |
| EXP | Whether her stated experience survives scrutiny, and what was actually hers |
| JD | Whether she can do the listed job, gaps included |
| CO | Fluency in the company's strategy and competitive frame |
| CASE | Structure and reasoning on a live problem |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights in your message | "2 years strategy consulting at a top firm" — the coach's notes; "9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | Your material says strategy consulting and then product strategy & ops, not go-to-market work, with nothing inspected behind it, and the words stay there: "I spent nine years in product strategy & ops at a large consumer-tech company." Answer slot: the JD's two-new-lines requirement makes a probe likely on how any of that work relates to it. If some of it did, say which and what part was yours, in your own words; if none did, or it was not yours, say so plainly and stay with strategy & ops |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights in your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | Your material says a proposed change credited with an uplift, not whitespace work across customer stages, and the words stay there: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." Answer slot: the JD's land/adopt/expand/renew line makes a probe likely on which stage, if any, that change was about. If it was about one, say which in your own words; if it was not about a stage, or you do not know, say so plainly and stay with the change you proposed |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights in your message | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | presentation | The quote names the tools and nothing inspected sits behind it, so the words stay there: "I'm skilled in SQL/Tableau." Answer slot: expect a request for an example. If there is an analysis you ran yourself, say what question it answered and which part was yours; if there is none to name, say so plainly and stay with the tools |
| F4 | "partner-motion design experience required" — JD highlights in your message | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | Your material says a revenue model used in carrier negotiations, not the motion the requirement names. The posting marks it required, but it is an experience requirement, not a gate, so it is graded like the rest, and it is a likely probe. Words: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: expect a probe on how the model was used and which part of that was yours. Say which, in your own words; if the use was not yours, or there was no such step, say so plainly and stay with the model you built |
| F5 | "strong cross-functional influence" — JD highlights in your message | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | presentation | The quote speaks of consensus across orgs, in other terms than influence, and the words stay there: "I set annual volume targets with cross-org consensus." Answer slot: expect a probe on how consensus was reached. If there were disagreements on the way, say what they were and how they were settled, in your own words; if there were none, or it came another way, say so plainly and stay with the targets and the consensus |
| F6 | "AI experience a plus" — JD highlights in your message | "uses AI tools daily" — the coach's notes | medium | [grounded] | presentation | The quote says daily use of tools, and the words stay there: "I use AI tools daily." Answer slot: expect "what for?" Name the tools and what you use them for, in your own words; if it is use and not building, say so plainly, because the quote says use |
| F7 | Sales-ops and quota-setting fluency, the lens a Sales Strategy peer brings; no JD line, a role-family requirement in plain prose | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [grounded] | capability | A gap wording cannot close, and the coach's notes state it. Words: "I haven't had classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. Nothing is added to make the gap feel smaller, and F5's volume targets are not offered as quotas |

## Reading the interviewer

Dan's side is the profile as you summarized it; his public footprint (talks, writing) was not checked because search was refused.

| Signal as supplied | What it means for the conversation | Questions it shapes | Provenance |
|---|---|---|---|
| Self-described "relentlessly data-driven" | Every figure Priya gives is likely to be probed to its assumptions; the weakest-assumption move matters | B1, B2, B5, F1, G2 | [inferred] |
| Career spine in pricing and monetization | Cases land best framed in pricing, packaging and unit economics, his native language; F4's quote is a revenue model, so say revenue model, never pricing | C1, C3, B4 | [inferred] |
| One early-stage-startup chapter | Expect a probe on working without a playbook after nine years at a large company | D3 | [inferred] |
| Peer, same VP | Expect reciprocity and seam questions: what she brings his team, not only what she needs | A1, A3, A4, A5, R2 | [inferred] |

Mirror opportunities: shared vocabulary only. His monetization language sits near F4's revenue model, used at that scope. No shared career jump is offered, because no row's evidence carries a candidate side of one.

## Persona table

| Persona | How it shows up with Dan | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| A. Peer Evaluator (5 questions) | Seam-splitting, "what do you need from me", credit and disagreement scenarios | High: the peer relationship sets this as a dominant persona | Reciprocity framing; propose seam principles rather than pretending to know the seam; spine and tact together |
| B. Data-Driven Prober (5) | Every number walked down to its assumptions | High: the peer prior pairs it with the Peer Evaluator, and "relentlessly data-driven" pushes it up | Know what you can and cannot say about how each number was counted; name the weakest assumption first; say plainly what you do not know |
| C. Case/Strategist (3) | A live GTM problem in pricing or packaging terms, plus the three priorities and the bundling threat from your note | Medium: not a hiring-manager round, but his pricing spine and the role's GTM remit tilt cases toward him | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| D. Skeptic (3) | The no-sales-ops gap and the required partner-motion experience, in collegial packaging | Medium: F7 and F4 are the two biggest gaps and a Sales Strategy peer owns the adjacent turf | Rehearse the single predictable objection until it is boring; bridge only from stated adjacent material; calibrated candor |
| E. Conversational (2) | The "walk me through the journey" opener; a casual AI question | Low to medium: every 60-minute conversation opens somewhere, and AI is the JD's plus | A 90-second arc; treat casual questions as scored |
| F. Pressure (2) | A time-boxed "why you" and an attribution challenge | Low: nothing in the profile signals a stress style, but a data probe can feel like one | Pause, restate, anchor in what you stated; hold through two follow-ups before conceding |
| G. Values/Behavioral (2) | Behavioral prompts from the persona stems and Dan's own words | Low: no loop source names a values round, and no values page was read | Story where one is carried, scaffold with its honest branch where not |

## Question banks

### A. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [grounded] "set annual volume targets with cross-org consensus" | Do not pretend to know his seam. Offer principles: agree who owns which number before anything launches; settle a disagreement on shared data first; take it to the shared VP only after both sides have written down their view. Then one line of your own material at its scope: "I set annual volume targets with cross-org consensus." Answer slot: if there was a disagreement on the way to that consensus, say how it was settled; if there was none, say so plainly and stay with the consensus | F5 is the only evidence that speaks to working across orgs, and a peer prices exactly this. JD for the cross-functional requirement, CASE in delivery |
| A2 | "Walk me through how you built the partner-level revenue model that was used in carrier negotiations." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Tell it in your own words with the beats the quote states: you built a partner-level revenue model, and it was used in carrier negotiations. Answer slot: expect a probe on how the model was used and which part of that was yours. Say which; if the use was not yours, or there was no such step, say so plainly and stay with the model you built | F4 is the evidence for the partner requirement and the likeliest place a peer tests what was actually hers. EXP because it tests attribution |
| A3 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a piece of work that spanned teams where credit could have gone either way. It needs a named stake, what you said and to whom, and a relationship intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem for the peer relationship; no quoted sentence carries a credit story, so this is the scaffold case. VAL because it scores behavior with equals |
| A4 | "What would you need from my team in your first ninety days?" | JD | [grounded] "skilled in SQL/Tableau" | Reciprocity first: what you bring, then what you need. What you bring at its scope: "I'm skilled in SQL/Tableau." What you need is a plan and not a past, so name your own: for example, how his team's targets and numbers are defined and where they live. Ask before you assume | The peer is pricing what the hire costs his team. F3 is the one row that gives a concrete contribution; JD for the cross-functional requirement |
| A5 | "Your numbers and mine disagree on how a new line is doing. Whose do we use?" | CASE | [grounded] "skilled in SQL/Tableau" | Structure aloud: agree the definitions first, reconcile row by row, show the query behind each figure, then decide. Your own material at its scope: "I'm skilled in SQL/Tableau." Answer slot: if you have reconciled differing numbers between teams, say how, in your own words; if you have not, say so plainly and describe how you would | A live seam problem built from F3 and Dan's data-driven self-description; CASE because it asks about no past |

### B. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Keep the quote's own verbs: you proposed the change, and the uplift was credited to it. Answer slots, each in your own words: how it was counted; what it is sensitive to; the assumption behind it you would defend least; which part was yours. "I don't know how it was counted" is an honest branch. Say the weakest assumption before he asks | F2's figure is the headline metric and the first thing a prober goes to. EXP because the score is attribution and counting, not the number |
| B2 | "Which assumption behind that revenue model would you defend least?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Answer slot: name, in your own words, the assumption you know of that you would defend least, and say what you would check first. If you cannot name one, say so plainly and stay with the model you built. Never invent an assumption to sound candid | The standard weakest-assumption probe, aimed at F4's model. EXP because it scores whether she knows her own work |
| B3 | "Tell me about an analysis you ran in SQL and Tableau, end to end. What was the question, and what did the data say?" | JD | [grounded] "skilled in SQL/Tableau" | Selection scaffold: pick an analysis you personally ran, with a question you can state, the cut of the data you used, and what you did with the answer. If no such analysis comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would run one. Offer to walk through it end to end only if you did it yourself | The JD names independent SQL and Tableau analysis, and F3 holds only the tool names. JD because it is a stated requirement |
| B4 | "How would you size the whitespace across land, adopt, expand and renew for a new line, with only the data you'd have in week one?" | CASE | [generic] | Clarify first: which line, which customers, what data exists. Then segment by stage, size each with the data available, state the weakest input, and say what you would pull to firm it up. Think aloud and name the number you trust least | The JD's whitespace line as a live problem, in the quantified form this interviewer favors. F2 is the row it tests |
| B5 | "Walk me through how the annual volume targets were set." | EXP | [grounded] "set annual volume targets with cross-org consensus" | Beats the quote states: you set annual volume targets, with cross-org consensus. Answer slot: say in your own words how a target was arrived at and which part was yours; if you do not know how a figure was derived, say so plainly. Call them volume targets, not quotas | F5's claim in its checkable form, and the nearest his lens will find to F7's gap; hence the scope held at volume targets |

### C. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A much larger platform vendor starts bundling something that competes with one of the new lines. How does that change how you take it to market?" | CASE | [grounded] | Clarify which line and what is bundled, then the objective; segment accounts by how exposed they are; options in pricing and packaging terms, since that is his native frame; the metric that would tell you it is working; the risk. Challenge one premise politely, such as whether the bundle is a real substitute | Your research note names bundling by a much larger platform vendor as the main competitive threat; I could not verify it independently. CASE with CO content |
| C2 | "Our stated priorities are enterprise expansion, the Compass copilot launch and reaching profitability. Where do the two new lines help and where do they pull against those?" | CO | [grounded] | Ask which two lines and how each maps to a priority before answering. Then lay out where each line helps, where it competes for the same investment, and what you would want to know about profitability constraints. Do not assume Compass is one of the two lines; ask | The three priorities come from your research note, unverified by me. CO because it tests altitude and company vocabulary |
| C3 | "A new line is landing logos but customers aren't expanding. How do you find out whether it's pricing, packaging, adoption or the sales motion?" | CASE | [generic] | State hypotheses for each of the four, the data that would separate them, the order you would check, and a decision rule. Say the hypothesis early. Ask what data exists before you commit | The pricing and monetization spine tilts cases toward this; it exercises F2's expand stage without claiming any history |

### D. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You haven't done classic sales-ops or quota-setting work. Why should Sales Strategy trust your GTM calls?" | JD | [grounded] "No classic sales-ops or quota-setting experience." ; "set annual volume targets with cross-org consensus" ; "built a partner-level revenue model used in carrier negotiations" | **Highest-ROI prep in the pack.** Level 1: say the gap plainly, first: "I haven't had classic sales-ops or quota-setting experience." Then the nearest material, each at its scope: "I set annual volume targets with cross-org consensus" and "I built a partner-level revenue model that was used in carrier negotiations." Then a plan, not a past: what you would ask his team first. Level 2, "volume targets aren't quotas": concede at once, "Right, volume targets aren't quotas, and that's the gap," and hold the two quotes without adding to them. Level 3, "what would you get wrong first?": name the one place you would lean on his team, or say you would see how Northwind sets and tracks its targets before forming a view. Never fold on the quotes; never stretch them | The objection is predictable for a Sales Strategy peer and aims at exactly where F7 and F4 are thinnest. JD because it scores the gap against the role; the deepest follow-up ladder in the pack because this is where thickening is most tempting |
| D2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Answer slot: name the requirement where your own experience is thinnest, then the nearest thing you have done, in your own words at its scope. If your material has nothing near it, say so plainly and say how you would close it. Choose honestly; a candidate who names it first looks calibrated | A persona stem built for the Skeptic. F4 and F1 are the likeliest answers, and the quote is the nearest evidence for F4 |
| D3 | "Tell me about a time you worked without an established playbook." | JD | [grounded] "9 at a large consumer-tech company in product strategy & ops" | Selection scaffold: pick a time with no precedent to follow, where you made a call and saw what happened. It needs a named stake, the decision, and the result. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would work without one. Do not claim a playbook-less setting that you did not describe | The JD's new-product-lines requirement plus Dan's startup chapter make a pace-without-process probe likely. F1 only records the setting, so the story is a scaffold |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm" ; "9 at a large consumer-tech company in product strategy & ops" | A 90-second arc with the beats the quotes carry: two years in strategy consulting at a top firm, then nine years in product strategy & ops at a large consumer-tech company. The last beat, why this role at Northwind, is yours to say in your own words; nothing in the material gives a reason, so do not borrow one | The opener is scored even when it feels casual. EXP because it tests whether the story hangs together; F1 holds the beats |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | The line is "I use AI tools daily." Answer slot: name the tools and what you use them for, in your own words; if it is use and not building, say so plainly. Finish with a question about how Compass is being built or sold, to stay conversational | A persona stem, and the JD's AI plus plus the Compass priority from your note make it likely. F6 is the evidence |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "That ARR number: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause and restate. Hold the position the quote carries: you proposed the change, and the uplift was credited to it. Answer slot: say which part beyond the proposal was yours, in your own words; if none, say so plainly. Hold through two follow-ups by returning to the quote, never by adding to it; concede exactly what you do not know | The attribution probe for F2's figure; hold-then-concede is the type bar. EXP because it tests precise attribution |
| F2 | "Sixty seconds: why you over someone who has done sales ops for ten years?" | JD | [grounded] "No classic sales-ops or quota-setting experience." ; "built a partner-level revenue model used in carrier negotiations" ; "set annual volume targets with cross-org consensus" | Pause, restate the question, concede the gap in one sentence: "I haven't had classic sales-ops or quota-setting experience." Then two quotes at their scope and stop. Do not argue that your work counts as theirs | A persona stem. F7 is conceded at once so the hold is on F4 and F5 only |

### G. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time where the stake was named, you said it plainly, and the relationship survived. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem; none of the quotes carries a story, so there is no mapped story. VAL because it scores behavior |
| G2 | "Tell me about a time the data changed your mind." | VAL | [generic] | Selection scaffold: pick a time you held a view, then saw the data say otherwise, and changed course. It needs the view, the evidence and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Raised by Dan's own words, "relentlessly data-driven". VAL because it scores how she handles being wrong |

## Requirement coverage

| Requirement | Questions |
|---|---|
| F1 own GTM strategy for two new product lines | C1, C2, C3, D2, D3, E1 |
| F2 identify whitespace across land/adopt/expand/renew | B1, B4, C3, F1 |
| F3 run independent analysis in SQL and Tableau | A4, A5, B3 |
| F4 partner-motion design experience required | A2, B2, D1, D2, F2 |
| F5 strong cross-functional influence | A1, A3, A4, A5, B5, G1 |
| F6 AI experience a plus | E2 |
| F7 sales-ops and quota-setting (no JD line) | D1, F2 |

Twenty-two questions. The JD list is from highlights, so a mid-list requirement the highlights omit has no question; the full JD closes that.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your background runs through pricing and monetization with an early-stage chapter. What did launching without a playbook teach you, and what would you want the new lines to borrow?" | Tied to Dan's own path; it turns the pace-without-process probe into a peer conversation |
| R2 | "What's one thing a new person on my side could do in the first month that would genuinely help your team?" | The reciprocity question for a peer; it shows she is thinking about his load |
| R3 | "Which of the two new lines is closest to launch, and is Compass one of them?" | The pack does not know; the answer reweights C1, C2 and E2, and she needs to know it |
| R4 | "How does the team decide where whitespace sits across land, adopt, expand and renew today, and which numbers does everyone trust?" | Shows an analysis-first mindset to a data-driven interviewer and surfaces F2's and F3's real context |
| R5 | "How is bundling by the larger platform vendor showing up in deals today, in win-loss data or in pricing pressure?" | Your research note names the bundling threat; asking a pricing person how it shows up reads as diligence |
| R6 | "What would make the first ninety days a clear success for you and the VP?" | Gives the shared-VP seam a concrete shape and helps her prioritize |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has classic sales-ops or quota-setting experience | Negative stated, F7 | The plain acknowledgment F7 gives: "I haven't had classic sales-ops or quota-setting experience." No slot |
| Set sales quotas or targets for a sales organization | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation, not words for her: the material says volume targets with cross-org consensus, not quotas |
| Designed or ran a partner motion | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the material says a revenue model used in carrier negotiations, not a motion |
| Did pricing or monetization work | Inflated form of F4 | F4's quote at its own scope: a revenue model. The limit is the pack's observation; it matters because Dan's own career is in pricing |
| Owned or led GTM strategy for a product line | Inflated form of F1 | F1's quote at its own scope: strategy & ops. The limit is the pack's observation: the material does not show go-to-market work |
| Drove or owned the ARR uplift | Inflated form of F2 | F2's quote at its own scope: proposed, and credited with. The limit is the pack's observation: the material does not say who credited it or how |
| Ran independent analyses in SQL and Tableau | Inflated form of F3 | F3's quote at its own scope: "I'm skilled in SQL/Tableau." B3's slot asks only for an example she can name |
| Built or shipped AI products or features | Inflated form of F6 | F6's quote at its own scope: daily use of AI tools |

## Sources

Provided: your message, which held the JD highlights, the summary of Priya's background, Dan's profile as you described it, and your research note on Northwind's priorities and the bundling threat. No dossier was present. Dan's profile and the research note are as you gave them; I have not checked either.

Searches sent, all refused:

- "Northwind Data B2B data infrastructure company values principles" — refused
- "Northwind Data interview process sales strategy GTM strategy role" — refused
- "Dan Kovac Director of Sales Strategy Northwind Data" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | Every call was refused. It would have fed a values cheat sheet and values-themed VAL questions; neither is in this pack, and G1 and G2 use persona stems and Dan's own words instead |
| 2. `Northwind Data interview process, sales strategy` | unavailable | Every call was refused. It would have checked loop structure; your words already establish one 60-minute conversation, so persona weights stand on that |
| 3. `Northwind Data strategy` / recent news | skipped | Your research note already supplies the priorities and the bundling threat that feed C1, C2 and R5 |
| 4. `Dan Kovac Northwind Data` | unavailable | Every call was refused. It would have fed the interviewer read with talks and writing, and a sharper R1 |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights you supplied fix the snapshot's requirements |

## Upgrade menu

- The full JD text → F1 to F6 requirement quotes become exact, and any mid-list requirement the highlights omit gets a question
- Priya's CV lines word for word → each row's evidence cell upgrades from your summary to her own sentences, and story-mapped guidance replaces scaffolds where her sentences carry a story
- Her own answers to the slots in F1, F2, F4, B1 and B3 → those rows move from a slot to quoted evidence once she states them outside a drill
- Search permission → values, loop and Dan's public footprint, which would sharpen the interviewer read and R1; a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) is available once, after that
- Anything the recruiter said about Dan's focus areas or a pre-declared deliverable → a build section for a graded deliverable, and reweighted personas
- How much prep time you have → a prioritized prep schedule
- A `tuesday-dossier.md` from an earlier underwriting of this role → grading from her confirmed claims, an evidence-derived objection to rehearse, and a prohibited list from her own corrections
