No dossier present. Reading the reference files the playbook names.
Your prep pack is saved as `larkfield-systems_engineering-manager_interview_pack.md`. It's in loop mode: one shared fit snapshot plus a mini-pack for each of your three rounds, 27 questions in all. Each round also has five reverse questions.

The web searches I tried for Larkfield's values, interview process and strategy were refused, so none ran. Everything company-specific comes from your message, and the case questions and values stems are labeled `[generic]`. Because Larkfield's published values weren't in hand, there is no values cheat sheet for the VP round.

The highest-ROI prep is question A1, "Which part of this role would you be weakest at on day one?" Your own words, "never owned a hardware-adjacent roadmap", are the gap the Director is most likely to press. Rehearse the plain acknowledgment and the plan until they feel boring. H1 to H3 reuse that gap, and the fact that you haven't managed managers, at the VP's altitude.

Your two figures, the 60% on-call drop (E1, H2) and "about 40 interviews" (E2), each have a defend-the-number rehearsal. Your sentence says the burden dropped *after* you pushed the quarter, so the pack keeps your wording there and doesn't say the quarter *caused* the drop.

Say the word and I'll play the Skeptic on A1, or the Pressure interviewer on H2.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Two questions would restructure it:
1. Can you paste the full posting text, and either a CV or the resume lines behind your background? The five fit rows currently rest on your role summary.
2. Did the recruiter give any focus areas or pre-announced exercises, such as a case or presentation, for the panel round? That would add a build section for it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview pack: Engineering Manager, Larkfield Systems (loop of three rounds)

Candidate: Yusuf. Mode: loop, one shared fit snapshot and three round mini-packs.

| Round | Who | Length | Relationship |
|---|---|---|---|
| 1 (Tuesday) | Director of Engineering, the hiring manager | 45 min | Your would-be boss |
| 2 (the Thursday after) | Two staff engineers and a product manager | 60 min | Technical stakeholders plus a cross-functional partner |
| 3 (the following Monday) | VP Engineering | 30 min | Skip-level, described by the recruiter as "values and leadership philosophy" |

No interviewer names were given, so there is no interviewer read. Web research did not run (see Sources), so every company-specific claim in this pack comes from your message, and anything else is labeled `[generic]`.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say only what you actually did, in your own words. An answer slot is an instruction for the interview, not a question for you to answer here.

| Tag | Name | What it is really testing |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the values being asked about, not generic virtue |
| EXP | Work-experience deep-dive | Whether your claims survive scrutiny; what was actually you |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge | Homework depth (no CO question here: research did not run) |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the role, live |

## Prep triage

You have about two weeks and three rounds. Do these few things well, in this order:

1. Before Tuesday: A1 and A2 until the plain acknowledgments feel boring, then C1 (your 90-second arc), then B1.
2. Between Tuesday and Thursday: E1 and E2 (defend your two numbers), then D1 and F2.
3. Between Thursday and Monday: G1, G2 and H1 to H3.

Everything else is insurance.

## Fit snapshot (shared across all three rounds)

The role description is the one you pasted; it is a summary, not the full posting. Quotes in the evidence column are your own words from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role description | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message; "I've never managed managers" — your message | medium | [grounded] | transferability | Your material says a team lead of six, with nothing inspected behind it, and does not show leading more than one team or device-management or industrial IoT work. The words stay at that scope: "I've spent three of my nine years as a team lead of six." Answer slot: the two squads make a probe on how you would split your attention likely. If you have ever shared your time across teams, say how; if not, say so plainly and stay with the team of six. If the managers question comes up, your own words were "I've never managed managers" |
| F2 | "own delivery" — role description | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | The sentence carries adjacent work, a reliability quarter pushed through, and does not say what you owned about delivery in general. Words at its scope: "I pushed a reliability quarter through against roadmap pressure." Answer slot: expect a probe on how you decide what ships. If any of those calls were yours, say which and how you decided; if there was no such step or it was not yours, say so plainly and stay with the quarter |
| F3 | "hiring" — "own delivery, hiring and growth for 11 engineers", role description | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | none | The quote already reaches the requirement in role-relevant terms: you run the loop. Lead with it in its own terms. Answer slot: "about 40 interviews" invites a probe on how it was counted and which part was yours. Say whether you conducted them or the loop did, and which; if you do not know how it was counted, say so plainly |
| F4 | "growth for 11 engineers" — "own delivery, hiring and growth for 11 engineers", role description | none given | none | [grounded] | discovery | Your material is silent on growing engineers. Strong evidence here would be a specific person whose path you helped shape and what changed for them. Answer slot: expect a probe. If you have helped anyone grow, say who and how, in your own words; if none, or it was not yours, say so plainly and say how you would start |
| F5 | "partner with hardware and product on roadmap" — role description | "never owned a hardware-adjacent roadmap" — your message | none | [grounded] | discovery | You stated the absence of owning such a roadmap, which is not the same as the requirement to partner on one, and your material is silent on partnering. Words you may use: "I haven't owned a hardware-adjacent roadmap." Answer slot: if you have worked with product or with any hardware-facing team on what gets built, say what and your part in it; if not, say so plainly, then say how you would learn the seam in your first weeks, as a plan and never as a past |

Requirement coverage (which questions cover each requirement):

| Requirement | Question IDs |
|---|---|
| "Lead two squads building device-management services" | A2, B1, B3, C2, H1, I1 |
| "own delivery" | A4, B2, E1, H2, I2 |
| "hiring" | E2, G4 |
| "growth for 11 engineers" | G3 |
| "partner with hardware and product on roadmap" | A1, B2, D1, F2, F3, I1 |

---

# Round 1: Director of Engineering (hiring manager), 45 min

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Quiet probing of the two gaps and the jump in scale | High. The hiring-manager prior is Case/Strategist plus Skeptic, and F1 and F5 are the biggest gaps in the snapshot, so Skeptic goes first | Rehearse the predictable objection until it is boring; plain acknowledgment, then a plan stated as a plan; no bluffing a competency the interviewer owns |
| Case/Strategist (B) | Live problems from the actual role | Medium-high. Second half of the hiring-manager prior; a Director buying capability tests it on the role's own problems | Clarify, then objective, segments, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Conversational (C) | Opening "walk me through" and casual questions on the domain | Medium. Openers are near-certain in a 45-minute slot, but they carry less weight than the first two | A short prepared arc; treat casual questions as scored |

This is built from your description of who runs the round, not from a documented Larkfield process.

## Question bank

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "never owned a hardware-adjacent roadmap" | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." Then the plan, said as a plan: what you would ask hardware and product first. Answer slot: if you have ever worked with product or a hardware-facing team on what gets built, say what and your part; if not, say so plainly and stay with the plan. Hold through two follow-ups by returning to the acknowledgment and the plan, and concede specifically: you do not yet know how hardware constraints shape the roadmap here, and you would learn that first | F5 is the largest stated gap against a requirement the Director owns, so this question arrives in some form. JD because it scores the listed partnership |
| A2 | "You've led a team of six. This role has two squads and eleven engineers. What changes?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I've never managed managers" | Say what you led at its scope: "I've spent three of my nine years as a team lead of six." Answer slot: if you have shared your time across more than one team, say how; if not, say so plainly and stay with the team of six. Then, as a plan only, how you would learn each squad before changing anything. If asked whether you have managed managers, your own words were "I've never managed managers" | F1 is where the scale jump sits; the two squads and eleven engineers come from the role description. JD because it scores the listed responsibility |
| A3 | "Why this move, and why now?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Give your actual reason in your own words, one reason you would repeat unchanged under a follow-up. Use the role's wording only where it is true for you. Keep it to what you are moving toward as well as away from only if both are true | A motivation question is near-certain for a move from a team lead of six at a payments company; categorized EXP because it tests whether your story is consistent |
| A4 | "The role owns delivery. Tell me about a time you held a delivery line against pressure." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped on F2, with only the beats the sentence states: a reliability quarter, pushed through, against roadmap pressure, and the on-call burden dropping 60% after. Tell it in your own words. Answer slot: if you had to trade something away or persuade someone to hold the line, say what and who; if there was no such trade, or the pressure was not yours to answer, say so plainly and stay with the quarter | F2 is your strongest quoted story and the one the JD's delivery line points at. The theme is the JD's, so the question is an open prompt |

### B. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A release goes out and a slice of the field devices stops reporting. You've just inherited both squads. Walk me through your first hour and your first week." | CASE | [generic] | Clarify first: what is known, what is rollback-able, who owns the device side versus the service side. Then objective, segmenting the affected slice, approach, how you would tell the squads and your Director, risks. Challenge one premise, such as whether the release is the cause. The question needs no claim about your past, so the guidance makes none | A live problem set in the JD's device-management services (F1's requirement); `[generic]` because it is a role-family pattern, not a fact about Larkfield |
| B2 | "Product wants a new capability next quarter. Hardware says the device side can't support it until later. How do you plan the quarter for two squads?" | CASE | [generic] | Clarify whose constraint is firm and what is driving product's date. Propose seam principles instead of pretending to know the seam: who decides what, what gets said to whom and when. Name what you would give up and why. The question presupposes nothing about your past | Aimed at F5 and F2's requirements together: partnering on roadmap and owning delivery. `[generic]` because the scenario is a pattern |
| B3 | "What do you want to learn in your first thirty days before you change anything?" | JD | [generic] | A list with an order: the two squads' current commitments, what the engineers say is hard, where hardware and product dependencies bite, how you will be judged. Close on what you would not change yet. No claim about your past | Hiring managers ask this to test judgment under a new scale (F1); the answer is a plan, so no candidate claim is made |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I run our hiring loop for backend roles — about 40 interviews last year."; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | A 90-second arc made only of those beats: nine years engineering, three as a team lead of six, currently at a payments company, then the hiring loop and the reliability quarter at their quoted scope. End on why this role, in your own words. Do not tell the interviewer what the beats prove; let them draw it | The biography question is a near-certainty in a 45-minute round; F1 to F3 supply the beats |
| C2 | "What are you actually playing with in industrial IoT these days?" | JD | [generic] | Answer slot: if you have looked into device management or industrial IoT, say what and what you took from it, in your own words; if not, say so plainly and say what you would read first. Do not describe familiarity you do not have | The role is device-management services (F1), and your material shows no such work, so a casual domain question is scored. `[generic]` because it is a pattern |

### Reverse questions for Round 1

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "What does success look like for the two squads at six months and at twelve?" | You learn the scoring sheet, and it signals you plan from outcomes |
| R1.2 | "Where do the hardware and product roadmaps pull against each other today, and how does that get resolved?" | It turns your largest stated gap into learning, as a peer would |
| R1.3 | "What would you want to see from me in the first ninety days?" | It makes expectations explicit and shows you work to a bar |
| R1.4 | "What is the biggest source of unplanned work for the eleven engineers right now?" | It shows interest in delivery before you are asked to own it |
| R1.5 | "Which parts of this role are you least sure a new hire can cover?" | It invites the Director's own risk read, which you can then address in the next two rounds |

---

# Round 2: Panel, two staff engineers and a product manager, 60 min

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator (D) | Seam-splitting between manager and staff engineers; disagreement and credit | High. Staff engineers will price what an EM adds to or takes from their work | Reciprocity: what you bring them as well as what you need; seam principles, not a pretended seam; disagreement that shows spine and tact |
| Data-Driven Prober (E) | Walks your numbers line by line | High. Your message carries two figures, and a panel with engineers reads them closely | Know what you can and cannot say about how each number was counted; say plainly when you do not know |
| Values/Behavioral, in a Conversational register (F) | The product manager's scenario and partnership questions | Medium-high. The panel blends the top two personas of each member: Peer Evaluator and Prober for the staff engineers, Values/Behavioral and Conversational for the product manager | Stories that carry your own words; "we" for context, "I" for contribution; name the hard truth only where it landed |

## Question bank

### D. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where's the seam between an engineering manager and the staff engineers, and what happens when we disagree?" | JD | [generic] | Offer seam principles, not a map of a seam you have not seen: who decides technical direction, who decides what ships when, what must be agreed before either moves. For disagreement, say how you would state your concern and your reasons, and what you would do once a decision is made. Say it only if it is how you actually work. The question asks for no past, so the guidance makes no claim about yours | The panel's staff engineers sit on the technical side of the partnership the role describes (F5's requirement); `[generic]` because the seam at Larkfield is unknown to this pack |
| D2 | "How do you handle credit when work spans teams?" | VAL | [generic] | A selection scaffold: pick a time work crossed teams, with a named contribution of yours, a named contribution of someone else's, and how you described the split afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard Peer Evaluator stem; VAL because it scores behavior rather than a listed requirement. No quoted sentence of yours carries this story, so it is a scaffold |
| D3 | "What would you need from the staff engineers, and what can you offer them?" | JD | [generic] | Lead with what you offer: clearer priorities, protection of their focus time, a way for their concerns to reach product. Then what you need: their view on technical risk before commitments are made. Frame both as how you intend to work, not as a record | Reciprocity framing is what a peer panel scores; JD because it tests partnership inside the role (F1) |

### E. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through how that 60% on-call number was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The defend-the-number rehearsal, in your own words, with four slots. Answer slot: how it was counted; what it is most sensitive to; the assumption behind it you would defend least; and which part was yours. For each, if you know, say so; if you do not know how it was counted, say that plainly. The sentence says the burden dropped after you pushed the quarter, and your words should stay at that: not that the quarter alone caused the drop | A headline metric on your own account is the probers' first target (F2); EXP because it tests attribution |
| E2 | "You said you run the hiring loop, about forty interviews last year. What was your part in those?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Start from the quote: you run the loop for backend roles. Answer slot: whether you conducted the forty yourself or the loop did, and which; how they were counted; what the figure depends on; and which part was yours. If you do not know any of these, say so plainly. Do not say you decided hires unless that was yours to decide, in your own words | F3 is a CV-style line with nothing inspected behind it, and "about 40" is a figure a prober will ask you to unpack |
| E3 | "How do you stay technically credible with staff engineers as a manager?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Start from the sentence: nine years engineering. Answer slot: if you still review designs or code, or take part in technical decisions, say how and how often, in your own words; if you do not, say so plainly and say how you would keep your judgment current. Do not describe depth you cannot demonstrate on the spot | Staff engineers test whether a manager can follow the technical conversation (F1); JD because it scores the role's technical partnership |

### F. Values/Behavioral (product manager)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | A selection scaffold: pick a time with a named stake, a decision you made rather than one made for you, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard cross-functional stem. None of your quoted sentences mentions customers, so no story is mapped; the honest branch is part of the rehearsal |
| F2 | "Engineering wants a reliability quarter and product wants features. How do you work that out with me?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Structure it: what product needs to see, how you would frame the trade in product's terms, what each side gives up, how you decide together. If you reach for your own quarter, keep to its quoted beats. Answer slot: how you made the case and to whom; if you did not make the case yourself, or it was not made to product, say so plainly and stay with the quarter | The panel's product manager is the partner in F5's requirement, and F2 is your only quoted story on roadmap pressure; CASE because it is a live scenario |
| F3 | "What does a good working relationship between engineering and product look like to you?" | JD | [generic] | Asked in a conversational register, but scored. Say what you would want from product and what product could expect from you, in two or three plain commitments you would actually keep. No claim about your past | A rapport question from a cross-functional interviewer; JD because it scores the roadmap partnership in the role description (F5) |

### Reverse questions for Round 2

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "Where would you want the engineering manager to step back, and where to step in?" (staff engineers) | It shows you respect decision rights before you have any |
| R2.2 | "What could a new engineering manager do in the first month that would genuinely help your work?" (reciprocity) | It turns the panel from interrogators into peers and signals you are thinking about their load |
| R2.3 | "How do product and engineering decide today when a request depends on the device side?" (product manager) | It shows you are already thinking about the seam you have not owned |
| R2.4 | "What works well in how the squads operate that I should not touch?" | It shows restraint and gives you real information |
| R2.5 | "How are reliability and on-call work planned alongside roadmap work?" | It lets you probe the area where your quoted story sits, without asserting anything about Larkfield |

---

# Round 3: VP Engineering, 30 min, "values and leadership philosophy"

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral (G) | Philosophy and values-style scenarios | Highest. The recruiter's own description names "values and leadership philosophy", which lifts it above the skip-level prior | Stories carrying your own words; where none carries a value, a scaffold with its honest branch |
| Pressure (H) | Time-boxed challenge on why you and how much was yours | High. The skip-level prior is Case/Strategist plus Pressure | Pause, restate, anchor in what you stated, hold through two follow-ups, concede specifically |
| Case/Strategist (I) | A strategy-altitude problem | Medium. The other half of the skip-level prior, with 30 minutes it gets at most a question or two | Clarify, structure, state a hypothesis early |

A values-style round is detected here from the recruiter's words as you reported them. Larkfield's published values were not in hand (search did not run), so the values cheat sheet is not in this pack.

## Question bank

### G. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "How would you describe your leadership philosophy?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year."; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Name two or three principles you actually hold. For each, attach one thing you did, using only your own sentences: the hiring loop and the reliability quarter are what your message carries. Where a principle has no instance you can stand behind, say it as an intention, not a record. Do not tell the VP what your stories prove | The recruiter named leadership philosophy as the round's subject, so this is near-certain. F2 and F3 are the only stories your material carries |
| G2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped on F2, with only the beats the sentence states: a reliability quarter, pushed through, against roadmap pressure. Answer slot: if a senior person pushed back and you told them something they did not want to hear, say what and how it landed; if the pressure came from elsewhere or no such conversation happened, say so plainly and stay with the quarter | A values round scores whether behavior shows the value; F2 is the only quoted story near it |
| G3 | "How do you think about growing engineers, including ones who want to become managers?" | VAL | [generic] | Say how you actually approach it, as a way of working. Answer slot: if you have helped anyone grow, say who and how, in your own words; if none, or it was not yours, say so plainly and say how you would start. Do not describe past development you did not do | The role description says growth for eleven engineers (F4), and your material is silent on it |
| G4 | "How do you decide who to hire?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Start from the quote: you run the loop for backend roles. Answer slot: if you set the criteria, say what they were and why; if the criteria were set by others, or there were none written down, say so plainly and describe what you look for in the interviews you do. Never claim you decided hires unless that was yours | F3 is your strongest quoted line against a listed requirement; a VP asking about values often asks about hiring because it shows what a manager protects |

### H. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Hold only what the sentence carries: nine years engineering, three as a team lead of six. Concede the stated limits specifically if pressed: your own words were "I've never managed managers" and "never owned a hardware-adjacent roadmap". Hold through two follow-ups by returning to what you did; never fold the core claim just to restore harmony, and never widen it | Skip-level interviewers test composure; F1 and F5 are what a challenge will land on |
| H2 | "That result, the 60% — how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold the sentence at its scope: you pushed a reliability quarter through against roadmap pressure, and the burden dropped after. Answer slot: which part was yours and which was your team's; if you do not know how much of the drop was due to the quarter, say so plainly. Concede that specifically instead of defending an attribution you cannot repeat under a second question | The attribution probe is the other half of E1; F2 is where it presses |
| H3 | "You haven't managed managers. How would you handle that?" | JD | [grounded] "I've never managed managers" | Start with the plain acknowledgment: "I haven't managed managers." Then a plan, stated as a plan: what you would ask your Director and the VP, and how you would build the habit of working through leads. Answer slot: if you have ever coached a lead or someone who led others, say who and how; if not, say so plainly and stay with the plan. Do not claim a management layer you have not run | The negative is yours, so a skip-level can use it; F1 carries the gap, and the same objection is worth one more rehearsal at VP altitude |

### I. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "Sketch how you'd organize work for two squads building device-management services. What do you need to know first?" | CASE | [generic] | Clarify what each squad owns today and where hardware and product touch it. Then the objective, how you would divide responsibility, what you would measure, the main risks. State a hypothesis early and challenge one premise respectfully | A strategy-altitude problem set in F1's role; `[generic]` because it is a pattern and no claim about your past is made |
| I2 | "How do you balance reliability work against roadmap commitments across two squads?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Give a structure first: what signal tells you reliability is eating the roadmap, how you make the trade visible, how you decide. If you cite your own quarter, keep to its quoted beats. Answer slot: how you decided the quarter was worth the pressure; if the decision was not yours alone, say so plainly | It connects the one quoted story to the role's delivery requirement (F2) at the altitude a VP cares about |

### Reverse questions for Round 3

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "What does good leadership look like in practice here, and what does a manager get recognised for?" | It maps the values round onto behavior you can verify |
| R3.2 | "What is the hardest tradeoff between hardware timelines and the software roadmap this year?" | It shows you are thinking at the altitude the role sits in |
| R3.3 | "How does the company develop managers, and is there a path for leads to move into managing managers?" | It addresses your stated gap (F1) as a growth question |
| R3.4 | "What would make you say in a year that this hire was the right one?" | It gives you the scoring sheet the VP will use |
| R3.5 | "What is something you have changed your mind about as an engineering leader?" | It invites the VP's own philosophy, which is the round's subject |

---

## Prohibited claims

Built from the fit snapshot before any bank was written. Nothing in this pack coaches these.

| Not coached | Basis | Honest form |
|---|---|---|
| Managed managers, or ran a layer of leads | Negative you stated, F1 | The plain acknowledgment: "I haven't managed managers." No slot |
| Owned a hardware-adjacent roadmap | Negative you stated, F5 | The plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." A1's slot asks only about partnering |
| Led two squads or an eleven-person team | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says a team lead of six |
| Owned delivery, or set the roadmap | Inflated form of F2 | F2's quote at its own scope. The material says you pushed a reliability quarter through against roadmap pressure, not that delivery or the roadmap was yours to own |
| Cut on-call burden by 60% | Inflated form of F2 | F2's quote at its own scope: the burden dropped after you pushed the quarter. E1 and H2 stay inside that wording |
| Personally conducted all of about forty interviews, or decided the hires | Inflated form of F3 | F3's quote at its own scope: you run the loop, about 40 interviews last year. E2's slot asks which part was yours |

## Sources

Provided documents: your message (the role description, the three rounds and who runs them, the recruiter's description of Round 3, and your background). No `tuesday-dossier.md` was present.

Searches sent, all three refused because web search permission was not granted:

- "Larkfield Systems industrial IoT company values" — refused
- "Larkfield Systems interview process engineering manager" — refused
- "Larkfield Systems industrial IoT device management strategy news" — refused

No pages were fetched and no user links were read.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Would have supplied the published value names for a Round 3 values cheat sheet; the section is dropped and Round 3's VAL questions rest on the recruiter's words and persona stems |
| 2. `{company} interview process {role family}` | unavailable | Would have named round formats and any case or presentation component; persona weights rest on your account of who runs each round |
| 3. `{company} strategy` / recent news | unavailable | Would have grounded a CO or CASE question in current priorities; the CASE questions here are `[generic]` and there is no CO question |
| 4. `{interviewer name} {company}` | n/a | No interviewer was named, so there was no query to form; there is no interviewer read |
| 5. representative `{role title}` JD | skipped | The role description you gave fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Full posting text → the five fit rows become the posting's own requirement list, and any mid-list requirement it names (a tool, a method) gets a question; today's rows rest on a summary
- A CV or the resume lines behind your background → more quoted evidence for F1 to F4, and a possible story for questions now handled by scaffold (D2, F1)
- Your own words on the answer slots in A1, A2, E1, E2, F2 and G3, stated in your next message → rows F1 to F5 and their banks regenerate with grounded story maps
- Web search permission → the target 1 to 3 rows above run: published values (a Round 3 cheat sheet), documented loop structure, current strategy for a grounded CO or CASE question
- A deeper research pass, offered once → up to 6 more searches and 2 more fetches, several more minutes: strategy brief, interviewer footprint, role-family loop reports, recent org context
- Interviewer names (the Director, the staff engineers, the product manager, the VP) → an interviewer read, persona weights tuned to their public footprint, and a reverse question tied to each one's path
- The recruiter's guidance for each round (focus areas, any case or presentation announced) → graded-deliverable sections if any were pre-declared
- A `tuesday-dossier.md` → evidence-graded strategies per weak area and a prohibited-claims list handed in, replacing the one built locally here
