Your prep pack is saved at /var/tmp/tuesday-measure/1a6/runs/sonnet/tuesday/part-2/rooms/case-7-canned-c83730a2/saltmarsh-games_live-operations-producer_interview_pack.md. I built it for a hiring-manager round with Tobias, so the persona weights depend on that assumption. Saltmarsh's careers page describes one 60-minute interview after the recruiter call, so I assumed that's the one you have: a live-outage tabletop followed by a values conversation.

Say the word and I'll play Tobias on the tabletop (A1), or play the Skeptic on C2, the pack's highest-ROI prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the person this role would report to, and did your recruiter say anything about what the tabletop will cover?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

- **Role:** Live Operations Producer, Saltmarsh Games (mobile, about 350 people)
- **Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed: hiring manager. This is unconfirmed, and the persona weights rest on it.
- **Round:** a 60-minute interview on Friday. Saltmarsh's careers page describes its single interview after the recruiter call as "the Outage Hour": a live-incident tabletop on a simulated outage during a live event, then a values conversation (see Sources). This pack assumes yours is that session.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | Structure and reasoning on a live problem |

An answer slot is an instruction for the interview, not a question for you now. It has two honest branches, and the second always allows that the thing never existed or was not yours.

## Prep triage

The interview is on Friday and the hours you have are unknown, so this is ordered by payoff.

1. Say C2 aloud three times until it is boring. It is the highest-ROI prep in this pack.
2. Do the Outage Hour: talk A1, A2 and A3 aloud, thinking out loud, against a clock. The tabletop is half the session.
3. Prepare B3, then decide for B1 and B2 whether a real instance exists. If none comes to mind, rehearse the honest branch.
4. Pick two reverse questions (RQ1, RQ2, RQ3).

Everything else is insurance.

## Fit snapshot

Gate check: no requirement here is a gate. Years of experience is a requirement, not a gate. F8 does not come from the JD. It comes from Saltmarsh's own announcement and your own message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | discovery | The years are stated in your own words, and your material does not say whether the title ran as a live service. Answer slot: if the main title was updated on an ongoing basis, say how updates reached players, in your own words; if not, say so plainly and stay with the weekly calendar you ran. Say the title as it was, associate producer |
| F2 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your quote is a weekly content-drop calendar for one title; the JD asks about live events across two. Words: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD makes a probe on events likely. If any drops were timed events, say how you handled them; if none were, say so plainly and stay with the weekly calendar |
| F3 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show this. Answer slot: if you worked with any of design, art, engineering or community to ship a drop, say which and how, in your own words; if you did not, or it was not yours, say so plainly and stay with the calendar |
| F4 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your quote is presenting numbers; owning a review and its KPIs is wider. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose which measures went in or reviewed results after a drop, say how; if the numbers were set by someone else or no such review existed, say so plainly and stay with the presenting |
| F5 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | No gap in wording, but a line with nothing inspected behind it, so expect a probe on it. Lead with it in the quote's own terms: you presented them, monthly, to the studio head |
| F6 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | transferability | Your quote is writing the checklist, which QA still uses; managing it is wider. Words: "I wrote the release checklist our QA team still uses." Answer slot: if you ran it release by release with QA, say how a go or no-go was decided; if you only wrote it, or someone else ran it, say so plainly and stay with what you wrote |
| F7 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | A written artifact exists, and the quote already reaches the requirement in other terms. Lead with it as the quote says it: you wrote it, and QA still uses it. Expect a request to see it |
| F8 | "moves Tidepool Tactics and Lantern Row to a season-pass model" — Saltmarsh news, September 2026 (search result) | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. The sources I read do not establish whether the season pass involves in-app purchases, so ask (RQ5) |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team | Negative you stated: "Never led a team" — your message | The plain acknowledgment: "I haven't led a team." No slot |
| Worked on in-app purchases or a season pass | Negative you stated, F8 | The plain acknowledgment F8 gives. No slot |
| Ran live events across two titles | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: the material says one title and weekly drops |
| Owned post-event reviews and the KPIs they report | Inflated form of F4 | F4's quote at its own scope. A4's slot stays with what was presented |
| Managed the release checklist with QA each release | Inflated form of F6 | F6's quote at its own scope. A2's slot asks only whether you ran it |

## Reading the interviewer

Source: search result for a GDC 2026 talk (snippet only; see Sources). Public professional footprint only.

- **Career pattern:** Head of Live Operations at Saltmarsh Games, previously a QA lead at a console studio.
- **Published argument:** the talk is titled "Patch Notes Are a Promise". The snippet gives its argument as: a live team is judged by how often its patch notes describe what actually shipped.
- **Implications:**
  1. Expect questions about what you tell players and when (A3, B2). The studio's second published value, "Ship the Patch Not the Promise", states the same theme.
  2. A QA background makes the release checklist (A2, B3) a likely area of detail. Describe only what you did.
  3. A candor-first style fits: say what you did, what you did not, and what you would learn.
- **Mirror opportunity:** his QA path sits beside F6's "Wrote the release checklist our QA team still uses". Offer your side at that scope only. It is a shared professional adjacency and not a shared jump.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | The Outage Hour tabletop: a simulated outage during a live event | Highest. The careers page documents the tabletop, and a hiring manager's prior is Case plus Skeptic | Clarify, objective, who needs to know, decisions, comms, review. Think aloud; challenge one premise respectfully |
| B. Values/Behavioral | The values conversation after the tabletop | High. The careers page documents a values conversation, so a values-style round is detected, and the three values are named on the values page | One story or an honest scaffold branch per value; "we" for context, "I" for contribution |
| C. Skeptic | Probing the thin rows: coordination, two titles, season pass, associate to producer | Medium-high. F3 and F8 are thin, and the hiring-manager prior includes Skeptic | Rehearse C2 until boring. Bridges only from what you stated, and a ramp plan said as a plan |
| D. Data-Driven Prober | Reading the background line by line: the calendar, the retention numbers | Medium. Not a self-described data-driven interviewer; the weight comes from the claims being brief and uninspected | Know what you can and cannot say about how the numbers were counted, and say so plainly where you do not know |
| E. Pressure/Stress | Time-boxing in the tabletop; "how much was actually you" | Low-medium. Time-boxing is plausible in a tabletop; nothing documents a stress style | Pause, restate, anchor in your sentences, hold through two follow-ups, concede exactly |
| F. Conversational | Opening, and the "any questions?" slot | Low-medium. Usually the first minutes | A 90-second arc; never "I think you've covered everything" |
| G. Peer Evaluator | Not banked | Low. Tobias is a head, not a peer, on the assumption above | If he turns out to be a peer or cross-functional, tell me and I will reweight |

## Question banks

### A. Case/Strategist (the Outage Hour)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Mid-weekend of a live event, players report the reward claim is failing, and the community channel is filling up. What do you ask first, and what do you do in the first thirty minutes?" | CASE | [generic] | Structure it aloud. Clarify first: how many players, whether it is getting worse, what is known and what is a guess. State the objective: stop the harm and tell players the truth. Name who needs to hear what and when: engineering, QA, community, studio leadership. Decide what you would pause and what you would keep running, and set the next update time. The question needs no claim about your past, so the guidance makes none | The careers page documents a live-incident tabletop, which is why this leads the pack. CASE because it is a live problem; `[generic]` because it is a pattern for the exercise, not Saltmarsh's actual scenario. F3's requirement is the JD line it presses on |
| A2 | "The fix is ready, QA has not signed off the checklist, and engineering wants to push. What do you do?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | Ask what the failing check is and what the risk to players is, then lay out options: ship with the known issue stated, hold, ship a smaller fix, and who decides each. Challenge one premise respectfully, that the choice is only ship or hold. Your own sentence is: "I wrote the release checklist our QA team still uses." Answer slot: the JD says to manage the release checklist with QA. If you ran it release by release, say how a go or no-go was decided; if you only wrote it, or someone else ran it, say so plainly and stay with what you wrote | F6 is the evidence for the checklist requirement and the likeliest place a QA-background interviewer presses. JD tag because it scores the stated requirement, with CASE delivery |
| A3 | "While the outage is still live, what do you tell players, and when? Write me the first update." | JD | [grounded] | Say what you know, what you do not, and when the next update comes. Announce only what is built, as the studio's published value puts it: "we announce what is built, not what is hoped". Name who approves wording. Be ready to draft two or three plain sentences aloud or on paper. The question makes no claim about your past, so the guidance makes none | The JD asks for clear written communication (F7), and the values page and the interviewer's talk both return to announcing what shipped. JD tag because it scores that requirement; CASE delivery |
| A4 | "Afterwards, retention for the event came in below plan. Walk me through the post-event review you would run and what you would report." | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Structure it: what the event was meant to do and what was decided before it ran, what happened and for which players, what is known versus guessed, the decision, and what changes in the next calendar. The only past you have is "I presented the monthly retention numbers to the studio head"; stop there. Answer slot: the JD says to own the post-event review and its KPIs. If you chose the measures or reviewed results after a drop, say how; if not, or it was not yours, say so plainly and stay with the presenting | F4 and F5 are where the JD's review and KPI lines meet your evidence. JD because it scores a stated requirement; CASE delivery |
| A5 | "From February 2027, Project Larkspur puts both titles on one shared events calendar and one live-ops group. What do you need to know first to run a calendar across both?" | CO | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Clarify first: what is shared across the two titles and what stays per-title, which teams plug into the shared calendar, and how a collision between the two titles' events would be decided. Challenge one premise respectfully, for example whether one calendar means one cadence. Your own past reaches one title: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if you ever planned around another team's schedule, say how; if not, say so plainly and say what you would learn first | The September 2026 announcement is the studio's current strategy (Sources), and it touches the JD's two-title line (F2). CO tag because it scores strategy fluency; CASE delivery |

### B. Values/Behavioral (the values conversation)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed. Which won?" | VAL | [grounded] | No quoted sentence of yours carries this story, so use selection criteria: pick a time a schedule pulled against what players were experiencing; it needs a named stake, what you did, and what players saw. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Value: "Players Before Plans: when the calendar and the players disagree, the players win" (values page). Scaffold rather than a story because none of your quotes carries one |
| B2 | "Tell me about a time you told people only what was actually built." | VAL | [grounded] | No quoted sentence carries this, so use selection criteria: a moment where saying less was the harder choice, who heard it, and what followed. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Value: "Ship the Patch Not the Promise: we announce what is built, not what is hoped" (values page); it is also the theme of Tobias's talk title |
| B3 | "Tell me about a time a release left the checklist better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | The beats the quote states: you wrote the checklist, and QA still uses it. Tell those in your own words. Answer slot: the value says every release leaves the checklist better than it found it. If the checklist changed after releases, say what changed and why; if it was written once and not revised, or the changes were not yours, say so plainly and stay with what you wrote | Value: "Leave the Build Greener: every release leaves the codebase and the checklist better than it found them" (values page). F6 is your one sentence that sits on it |
| B4 | "Tell me about a time you delivered an unwelcome number to someone senior." | VAL | [generic] "Presented the monthly retention numbers to the studio head" | Your material shows presenting retention numbers to the studio head and does not show how they landed. Selection criteria: a number that was worse than hoped, what you said, and what the person did with it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry: "I presented the monthly retention numbers to the studio head" | A persona-stem question on delivering a hard truth to leadership. F5 is the nearest evidence, and it has no ending in it. Do not supply one |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] | Choose the one that is true for you. The pack's observation: your material shows nothing on coordinating design, art, engineering and community (F3), and nothing on in-app purchases (F8). Name it, then name what you would do in your first week to close it, as a plan | Persona stem for the Skeptic. It picks the thinnest rows, F3 and F8 |
| C2 | "Both titles move to a season pass from February 2027, and you haven't worked on a game with in-app purchases. How do you handle that?" | CO | [grounded] "never worked on a game with in-app purchases" | **The highest-ROI prep in this pack.** Say the plain acknowledgment first: "I haven't worked on a game with in-app purchases." Then a ramp plan, said as a plan and never as a past: what you would read first (past event reviews, and how the season pass is meant to be judged), who you would ask, and what you would want to be able to explain by day thirty. Claim no monetization measures. If pushed on how you would know a season is healthy, concede that you would learn their definition first | The question is premised on your own stated negative and on Saltmarsh's announcement, and it will be asked in some form. F8 is the row it comes from. CO because it needs the studio's strategy |
| C3 | "You're coming from an associate producer role. What changes at producer level, and how do you handle that you haven't led a team?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio"; "Never led a team" | Say your title as it was and the plain acknowledgment: "I haven't led a team." The JD's words are "coordinate" teams and "manage the release checklist", and you can say so as a reading of those words. Then what your quotes carry: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if you worked with design, art, engineering or community on a drop, say how; if not, say so plainly and stay with the calendar | F1 and F3 together. The negative is your own statement, so it is sourced. JD because it scores the requirement |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how you ran the weekly content-drop calendar." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Story-mapped on F2: the weekly calendar, the main title, the two years. Those are the beats the quote states; tell them in your own words. Answer slot: the JD says to plan and run the calendar with several teams. If you set the cadence or the dependencies for a drop, say how; if the cadence was set for you, or there was no such step, say so plainly and describe how you ran it | F2 is the evidence for the calendar requirement and the likeliest first probe. EXP because it tests what was actually yours |
| D2 | "Walk me through the monthly retention numbers you presented." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Say what you presented and to whom, in those words. Answer slot: if you chose the measures or built the numbers, say which and how they were counted, and name the assumption behind them you would defend least; if the numbers came from an analyst or a tool, or you do not know how one was counted, say so plainly and stay with the presenting | F5. You gave no figure, so none is invented, and the slots are only the ones a retention claim raises. EXP because it scores attribution |
| D3 | "How do you decide whether an event worked?" | JD | [generic] | Structure it: the objective set before the event, the measure chosen for it, the comparison point, and what decision follows. The question makes no claim about your past, so the guidance makes none | The JD's post-event review and KPI lines (F4, F5) asked as a decision rather than a record. `[generic]` because it is a pattern for the problem |

### E. Pressure/Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has run live events for two titles?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses" | Pause, restate the question, and answer in what you stated: "I ran the weekly content-drop calendar for our main title for the last two years", and "I wrote the release checklist our QA team still uses." Hold through two follow-ups by returning to those sentences, not by adding to them. Concede specifically: your material shows one title and does not show events across two (F2), and say what you would learn first. Never fold on the core claim to restore harmony | Persona stem for the Pressure interviewer, aimed at F2's gap. JD because it scores the two-title requirement |
| E2 | "That retention work. How much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | "I presented the monthly retention numbers to the studio head" is the whole claim. Answer slot: if you picked the measures or built the numbers, say which part; if someone else did, say so plainly and stay with the presenting. Hold through two follow-ups; concede exactly what was not yours | Persona stem for attribution under pressure. F4 and F5 are the rows it presses on |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey. How did you get from a puzzle studio to this role?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc made only of those four sentences, in order, in your own words. Answer slot: say in your own words why you want this role and this studio; nothing in your material supplies it, and none is supplied here | The biography question is scored even in a friendly register. EXP because it tests whether the arc matches the background |
| F2 | "Which live-service games do you follow closely, and what do you notice about how they run their event calendars?" | JD | [generic] | Pick a real example from your own play and say what you noticed about cadence and communication. If none comes to mind, say so plainly and say how you would study one. The question makes no claim about your past | A casual question on a hot JD topic. Treat it as scored |

## Requirement coverage

| JD requirement | Question IDs | Note |
|---|---|---|
| 3+ years producing live-service games or apps | C3, F1 | |
| Plan and run the live-events calendar for two titles; running a content calendar | A5, D1, E1 | |
| Coordinate design, art, engineering and community teams on each update | A1, A2, C1, C3 | |
| Own the post-event review and the KPIs it reports | A4, D3, E2 | |
| Comfortable with player-retention metrics | A4, D2, E2 | |
| Manage the release checklist with QA | A2, B3 | |
| Clear written communication | A3 | A live writing request is plausible |
| Beyond the JD: season pass, published values | A5, C2 (season pass); B1, B2, B3 (values) | |

## Values cheat sheet

A loop source documents a values conversation, so a values-style round is detected. Names are Saltmarsh's own, from its values page.

| Value | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the schedule and the players' experience conflict, the players' experience wins | No quote carries this. Selection scaffold in B1, ending in its honest branch |
| Ship the Patch Not the Promise | Announce what has been built, not what is hoped for | No quote carries this. Selection scaffold in B2, ending in its honest branch |
| Leave the Build Greener | Each release should leave the codebase and the checklist better than it found them | F6: "Wrote the release checklist our QA team still uses" — your message. Beats beyond that sentence are the answer slot in B3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "Your GDC talk argues that patch notes are a promise. How does that show up in how the team reviews an event afterwards?" | Tied to his own public work; it links the post-event review (F4) to a theme he chose |
| RQ2 | "You came up through QA. What does a healthy release checklist look like, and what makes one go stale?" | Tied to his career path; it sits next to the value "Leave the Build Greener" and invites him to talk about your F6 territory as a peer |
| RQ3 | "Project Larkspur moves to one live-ops group. Where would this role sit after February 2027, and does the JD's two-title scope still hold?" | Shows you read the announcement, and settles what the job is |
| RQ4 | "What would a strong first ninety days look like for this role: what would you want shipped or reviewed?" | Surfaces what he scores, and gives your ramp plan for F3 and F8 a target |
| RQ5 | "How will the season pass be judged: what counts as a good first season?" | Honest curiosity on F8's gap, and it gets you the vocabulary you lack |
| RQ6 | "When the calendar and what players are experiencing disagree, how does the team decide, and can you give me a recent example?" | Maps to "Players Before Plans" and turns the values round into his stories |

## Sources

Provided documents: the JD and your background, both in your message. No `tuesday-dossier.md` was present.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

Searches and fetches sent:

- Search "Saltmarsh Games values" returned https://saltmarshgames.com/values
- Search "Saltmarsh Games interview process live operations producer" returned https://saltmarshgames.com/careers/interviewing
- Search "Saltmarsh Games strategy mobile news" returned https://saltmarshgames.com/news/project-larkspur (search snippet only; the article was not fetched)
- Search "Tobias Wrenfield Saltmarsh Games" returned https://talks.gdconf.example/2026/patch-notes-are-a-promise (search snippet only; the page was not fetched)
- Fetch https://saltmarshgames.com/values returned the three values and their one-line definitions
- Fetch https://saltmarshgames.com/careers/interviewing returned the loop: a recruiter call, then the Outage Hour, with no take-home

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet and B1 to B3, three values by name |
| 2. Saltmarsh Games interview process, live ops producer | yes | Loop structure: the Outage Hour tabletop plus a values conversation; persona weights and the A and B banks follow it |
| 3. Saltmarsh Games strategy and recent news | yes | A5, C2, F8, RQ3. Only the search snippet was read, so details beyond it are not used |
| 4. Tobias Wrenfield, Saltmarsh Games | yes | Reading the interviewer, A3, RQ1, RQ2. Only the search snippet was read |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a grounding brief on Saltmarsh's strategy, a full read of the Larkspur announcement and Tobias's talk, and sharper A5, A3 and reverse questions
- The recruiter's guidance on the Outage Hour (format, what to prepare, any pre-reading) → coverage assumed from round-type priors becomes grounded, and any announced deliverable gets its own build section
- Confirmation that Tobias is the person the role reports to → the persona weights stop resting on an assumption
- Your own answers to the slots on F1, F2, F3, F4 and F6 (what the title was, whether any drops were timed events, whether you worked with design, art, engineering or community, who chose the retention measures, and whether you ran the checklist release by release) → those rows become grounded stories, and A2, A4, D1 and D2 gain beats
- The release checklist itself (a redacted copy) or a redacted monthly retention report → F5, F6 and F7 can move from medium toward high, since each is an inspectable artifact in this field
- The full text of Tobias's talk or slides → A3, B2 and RQ1 can quote his own argument rather than a snippet
- A `tuesday-dossier.md` from an earlier fit check → verified evidence, a named top objection and prohibited claims supplied rather than inferred here
