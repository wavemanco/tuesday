Your prep pack is saved as `/var/tmp/tuesday-measure/1a6/runs/sonnet/tuesday/part-2/rooms/case-7-canned-eec190dc/saltmarsh-games_live-operations-producer_interview_pack.md`. I built it for a hiring-manager session with Tobias, which is the one interview Saltmarsh's careers page describes. That page says the hour is a live-incident tabletop on a simulated outage, then a values conversation, with no take-home.

The pack names C1 as your highest-ROI rehearsal. It's the in-app-purchase question, which Saltmarsh's own news about a season-pass move makes likely. Say the limit first, using your own words ("I haven't worked on a game with in-app purchases"), then give a plan stated as a plan.

I read the Saltmarsh values and interviewing pages in full. The Project Larkspur news and Tobias's GDC talk I saw only as search snippets. Check that talk yourself before you rely on it.

Say the word and I'll play the Skeptic on C1 as a live drill. I can also save a `tuesday-dossier.md` that records the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Does the Live Operations Producer report to Tobias, or is he a different kind of interviewer, such as a skip-level or a peer? The answer reweights every question bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed to be the hiring manager; Saltmarsh's careers page describes the loop's one interview as run by "the hiring manager".
**Format this pack is built for:** one 60-minute session, which the careers page describes as a live-incident tabletop on a simulated outage during a live event, then a values conversation, with no take-home.

## How to use this pack

Personas are how a question arrives (who is asking, in what style). Types are what it scores. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did. An answer slot is an instruction for the interview, not a question for you now: answer whichever branch is true, including "that was not mine" or "there was no such step".

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your background survives scrutiny, and how exactly you attribute it |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company's strategy and can think at its altitude |
| CASE | Structure and reasoning on a live problem from the role |

The highest-ROI prep in this pack is **C1**, the in-app-purchase question. It will be asked in some form, and a calm, short, honest answer changes the interview. Rehearse it until it is boring.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title, and the words stay there: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's "plan and run" makes a probe on the planning side likely. If you planned drops ahead of the week they shipped, say how far ahead and how; if you ran what others had planned, or there was no planning step, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show which teams you worked with on a drop. Answer slot: the JD names four teams, so expect a probe on each. Say which of them you worked with and what you needed from each, in your own words; if a team was not involved, or the coordination was not yours, say so plainly |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | discovery | Your sentence says presenting; it does not show who produced the numbers or whether any per-event review existed. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if any part of the numbers, or of a write-up of what a drop achieved, was yours, say which part and how, in your own words; if it was not, or there was no such write-up, say so plainly and stay with the monthly presentation |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | Reword only the quote: "I wrote the release checklist our QA team still uses." A written document another team still uses is a named record, which beats an adjective, and expect a probe on what it covers. Your material says you wrote it, and the words stay at wrote |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | discovery | Your sentences give four years as an associate producer and two years of weekly drops; they do not say how the title was operated. This is a years requirement, graded like any other row and not a gate. Answer slot: expect a probe on how the title was run after launch. Say how, in your own words; if it was not run as a live service, say so plainly and stay with the weekly calendar |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap: the quote reaches the requirement in role-relevant terms. Lead with it in its own terms, that you ran it, weekly, for two years, and expect a probe because a CV line alone has nothing inspected behind it |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | No gap in wording, but the sentence says presented, so expect probes on how the numbers were counted (D1) and on exactly what part was yours (D1, A5) |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | Reword only the quote: "I wrote the release checklist our QA team still uses." It is the one written artifact your sentences show, and the material shows no other writing sample, so the words stay there |
| F9 | "moves Tidepool Tactics and Lantern Row to a season-pass model" — Saltmarsh news (search snippet, not a JD requirement) | "Never led a team, and never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Never a claim to purchase or monetization work, and nothing added to make the gap feel smaller |

## Reading the interviewer

Public professional footprint only. The talk and career facts below come from one search result's snippet; I did not fetch the page, and its host is not one I could confirm as the conference's own site. Check the talk yourself before leaning on it.

| Item | What the source says | Provenance | What it means for you |
|---|---|---|---|
| Role | Head of Live Operations at Saltmarsh Games | [grounded] your message | He owns the function you would join |
| Talk | "Patch Notes Are a Promise", GDC 2026; his argument: "a live team is judged by how often its patch notes describe what actually shipped" | [inferred] search snippet, page not fetched | Expect precision about what shipped versus what was announced; it matches the value "Ship the Patch Not the Promise" (B2, B5). Describe what you did exactly and let him draw the inference |
| Career pattern | "previously a QA lead at a console studio" | [inferred] same snippet | He may read a release checklist with a QA eye; D3 and B3 are where that lands |
| Mirror opportunity | His QA background beside F4's quote "Wrote the release checklist our QA team still uses" | [inferred] pairing of the snippet with F4 | A shared professional domain, not a shared identity: ask him what he looks for first in a checklist (G2) rather than claiming common ground |

## Persona table

The loop is established by Saltmarsh's careers page (one session with the hiring manager, a tabletop then a values conversation), so the weights rest on the company's documented process, not an archetype.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | Live problems from the role: an outage, a slipped update, a retention dip | High (5 questions). Hiring-manager prior, and the careers page documents the tabletop | Clarify, then objective, who is affected, approach, metrics, risks; think aloud; challenge one premise respectfully |
| B. Values/Behavioral | Scenario probes tied to Players Before Plans, Ship the Patch Not the Promise, Leave the Build Greener | High (5). The careers page documents a values conversation as the hour's second half | Map a story where one of your quoted sentences carries one; where none does, use the selection scaffold and its honest branch; "we" for context, "I" for contribution |
| C. Skeptic | Quiet probing of the gaps: purchases, team size, one title, two titles | Medium (3). Hiring-manager prior, and F9 and F2 are the visible gaps | Rehearse the single most predictable objection until boring; limits said plainly; a ramp plan stated as a plan |
| D. Data-Driven Prober | Reads the retention line, asks how it was counted | Medium (3). The JD asks for KPIs and retention, and his talk theme is accuracy about what shipped | Say plainly what you know and do not know about how a number was counted; name the assumption you would defend least |
| E. Conversational | Friendly opener, "walk me through your background" | Low (2). The hour is structured, but the opener is still scored | A short arc built only from your quoted sentences; treat casual questions as scored |
| F. Pressure | Time-boxed, devil's advocate, "how much of that was you" | Low (2). Likely inside the tabletop rather than as a separate style | Pause, restate, hold the position through two follow-ups, concede specifically |

Not included: the Peer Evaluator, because the interviewer is assumed to be the hiring manager and not a peer. If Tobias is not the person the role reports to, say so and the banks get reweighted.

## Question banks

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The game goes down partway through a live event, and you are the producer on the call. What do you do in the first thirty minutes?" | CASE | [inferred] | Clarify before structuring: what is down, for whom, whether the event clock is still running, who is already working on it. Objective: stop further harm to players and keep what you say honest. Name who you pull in, using the JD's four teams (design, art, engineering, community), and what you ask each. Say what players are told and when, limited to what is known. Decide pause, extend or continue, with reasons, and say what you would record for the review. Think aloud and challenge one premise, such as what "partway through" means for the schedule. This question needs no claim about your past, so the guidance makes none | Derived from the careers page's tabletop on a simulated outage during a live event, whose actual scenario is unknown, so the pattern is inferred. CASE because it scores structure under time pressure, with the JD's coordination line (F2) as its raising requirement |
| A2 | "Day-one retention on this event's new players is below the last event's. How do you find out why?" | CASE | [generic] | Clarify the metric first: how it is defined, the window, which players are counted. Then split the drop: who changed (new players versus returning), what changed (event content, the build, the player mix), and when. Say what you would check first and what would change your mind, then what you would do about it and how you would report it. No claim about your past | A diagnose-it problem on the JD's retention requirement (F7); generic because the data the real scenario would give is unknown. CASE because it scores reasoning, not a right answer |
| A3 | "Saltmarsh is moving Tidepool Tactics and Lantern Row onto one shared events calendar from February 2027. What changes about planning events, and what would you want to know first?" | CO | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Research source: Saltmarsh's September 2026 announcement, read as a search snippet only. Clarify first: what is shared (the calendar only, or budget and teams too), who settles a clash between the two titles. Then structure: objective, how the two player bases differ, approach, metrics, risks. The public announcement is equally available to every prepared candidate, so bring one point from it to show you read it, then one reasoned departure, such as when two titles should not share a slot, with your reasons. Say your own limit: your material is the weekly calendar for your main title, so reason from that and from principles, not beyond it | F1 is the evidence and the limit. CO because it scores whether you can think at the company's current altitude; CASE in delivery because it asks for structure on a problem you have not seen |
| A4 | "Engineering says next week's update is not ready, art says the same, and community has already teased it. What do you do?" | CASE | [inferred] | Sort what is built from what is hoped, since the published value says "we announce what is built, not what is hoped". Lay out the options (ship what is ready, slip the date, cut scope), and what each costs the players and each team. Say who decides and what you would put in front of them. Say what players are told, limited to what exists, and how you would record it for the review. No claim about your past | Derived from the Ship the Patch Not the Promise value and the JD's coordination line (F2). CASE because it asks for a decision, with VAL as its secondary reading |
| A5 | "You are running an event next month. What goes in its post-event review, and who sees it?" | CASE | [grounded] "Presented the monthly retention numbers to the studio head" | Structure: the purpose of the review, what was planned against what shipped, a few KPIs each defined plainly, who reads it and what they are expected to do with it. The nearest thing in your background is "I presented the monthly retention numbers to the studio head", in those words. Answer slot: the JD's "own the post-event review" makes a probe on a review you wrote likely. If you wrote up what a drop achieved, say what was in it; if the monthly numbers were the only review, say so plainly and stay with them | F3 is the thinnest row against a JD line the role owns, so it is rehearsed twice (here and D1). CASE with JD scoring, since it asks you to design the review the posting says you will own |

### B. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and what players needed disagreed." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Selection scaffold, since no sentence of yours carries this story: pick a time you changed or held a plan because of what players needed. It needs a named stake, what you decided, and what happened to the calendar after. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is "I ran the weekly content-drop calendar for our main title for the last two years", or how you would handle it | The prompt is from the published value Players Before Plans ("when the calendar and the players disagree, the players win"); F1 is the nearest evidence. VAL because it scores a specific decision, not familiarity with the slogan |
| B2 | "Tell me about a time you had to correct something you had said was coming." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Selection scaffold: pick a time what you announced and what shipped differed. It needs what was said, what shipped, how you corrected it, and what you changed afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is "Wrote the release checklist our QA team still uses", or how you would handle it. Say what was wrong before what was right | The prompt is from the value Ship the Patch Not the Promise ("we announce what is built, not what is hoped"), the one his GDC talk theme also points at (inferred, snippet only). F4 is the nearest evidence. VAL because it scores honesty about a miss |
| B3 | "Tell me about a time you left a process better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Story-mapped on F4, with only the beats the sentence states: you wrote the release checklist, and QA still uses it. Tell it in your own words. Answer slot: the value says every release leaves the checklist better than it found it, so expect a probe on whether it changed afterwards. If it did, say what changed and why; if it did not, or the changes were not yours, say so plainly and stay with the checklist you wrote | The prompt is the value Leave the Build Greener ("every release leaves the codebase and the checklist better than it found them"). F4 is the only quote that carries this one. VAL because it scores a specific piece of work against the named value |
| B4 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head" | Story-mapped only as far as the sentence goes: you presented the monthly retention numbers to the studio head. Answer slot: if any month's numbers were unwelcome, say what you said and what happened, in your own words; if none were, or you only passed numbers along, say so plainly, then say how you would present a bad number | A standard values stem (the hard truth landing) and the one place F3's sentence meets leadership. VAL because it scores candor under pressure; the second branch protects you from inventing the ending |
| B5 | "When the patch notes and what shipped do not match, what do you do?" | VAL | [inferred] "Wrote the release checklist our QA team still uses" | A hypothetical, so no past is claimed. Confirm what actually shipped first. Correct it publicly and plainly. Then trace which step of the release checklist could have caught it and say what you would change there. You can mention that you wrote a release checklist QA still uses, in those words, as the document you would look at | Derived from the Ship the Patch Not the Promise value and the interviewer's talk title (snippet only); F4 supplies the only artifact. VAL with CASE delivery: a values question asked as a live scenario |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "From February, Tidepool Tactics and Lantern Row move to a season-pass model, and you have not worked on a game with in-app purchases. How would you handle that?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases" | **The highest-ROI rehearsal in this pack.** Say the limit first, before it is pressed: "I haven't worked on a game with in-app purchases." Then give a plan, said as a plan: what you would learn first, from whom, and by when, in your own words. Name only things you would do, never things you did. Hold-then-concede through three levels. If asked "how would you handle an event tied to the pass", return to your plan and what you would ask the owner of it. If asked "so you would learn it on our titles", concede specifically: "Yes, that part, and here is how I would shorten it." If pushed a third time, do not add experience; restate the plan | F9 is the biggest named gap and the one the company's own news makes salient, so this objection arrives in some form. JD-tagged because the role's scope is where the season pass lands; the question's only negative is the one you stated |
| C2 | "You ran the calendar for your main title. This role runs it for two titles. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Story-mapped on F1 at its own scope: a weekly content-drop calendar, for your main title, for two years. Answer slot: expect a probe on planning. If you planned drops ahead of the week they shipped, say how far ahead and how; if there was no planning step, or you ran what others planned, say so plainly. What changes with a second schedule is a plan, said as a plan: how you would keep two schedules from colliding, in your own words | F1 is the evidence and the limit. JD because it scores the "two of our mobile titles" line directly |
| C3 | "The role coordinates design, art, engineering and community on each update. Which of those teams did you work with on your weekly drops?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases" | Answer slot: name which teams you worked with and what you needed from each, in your own words; if a team was not involved, or none of the coordination was yours, say so plainly. If you are asked whether you led those teams, the plain acknowledgment is your own: "I haven't led a team." The JD says coordinate, which is a different word from lead, and your material does not show which of the four you coordinated | F2 is `none given`, so the question is premised only on the JD's four teams, with a slot that lets the premise be false. JD because it scores the coordination line |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the monthly retention numbers you presented. How were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Start with the quote at its scope: "I presented the monthly retention numbers to the studio head." Then answer the four slots in your own words: how a figure was counted, what it is most sensitive to, the assumption behind it you would defend least, and which part was yours. "I don't know how it was counted" is an honest branch. Name your weakest assumption before he does | F7 and F3 hold the figure's only evidence, and a prober goes two levels deeper than the headline. EXP because it scores attribution honesty |
| D2 | "Which retention metrics would you want on the post-event review, and which would you not trust alone?" | JD | [inferred] | A hypothetical, so no past is claimed. Pick a few metrics and define each in a sentence. Say what you would compare each against and what makes each misleading on its own. Say what you would not decide from a single number. Avoid naming a tool or method you have not used | Derived from the JD's "KPIs it reports" and "player-retention metrics" lines (F3, F7). JD because it scores the stated requirement; the guidance supplies structure and no figures |
| D3 | "Walk me through the release checklist you wrote. What does it cover?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Story-mapped on F4 with only its beats: you wrote it, and QA still uses it. Describe what it covers in your own words. Answer slot: the JD's "with QA" makes a probe on the working relationship likely. If you agreed steps with QA, or it changed after releases, say how; if you wrote it alone, or it never changed, say so plainly and stay with the checklist | F4 is the evidence for the JD's checklist line, and this interviewer's QA background (inferred, snippet only) makes it the likeliest place for a deep probe. EXP with JD scoring |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through your background and why this role." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc made only of those clauses, in your own words: four years as an associate producer at a puzzle-game studio, then the weekly drop calendar, the release checklist, the retention presentations. Answer slot: why live operations and why Saltmarsh is yours to say; if you want to tie it to a published value, use one you can back with a real example | F5 is the evidence for the years requirement and the opener is scored. JD with EXP because the arc is the answer to "3+ years" |
| E2 | "What have you been playing lately in live-service mobile?" | CO | [generic] | Answer in your own words, from games you actually play. Pick one live event from one of them and say what you would have asked its producer. If you have not played Tidepool Tactics or Lantern Row, say so plainly, and look at both before Friday if you can, so the question has a concrete answer next time | A casual question on the JD's own subject, still scored. Generic because the pack cannot know what you play, and the suggestion to look at both titles is the pack's, not a fact about the interviewer |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over someone who has already run purchase-driven events?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Never led a team, and never worked on a game with in-app purchases" | Pause and restate. Hold only what the quotes carry: "I ran the weekly content-drop calendar for our main title for the last two years" and "I wrote the release checklist our QA team still uses". Concede the limit specifically and once: "I haven't worked on a game with in-app purchases." Do not claim an equivalent. Through two follow-ups, return to the calendar and the checklist; never add to them | F9 under time pressure. JD because it scores the same requirement as C1 with the register turned up |
| F2 | "That calendar: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Pause, then start from the sentence: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if you decided what went into the drops, say how; if others decided and you ran the calendar, say so plainly and stay with running it. Hold through two follow-ups by returning to what you ran, and concede any limit once and specifically | F1 is the headline claim, and attribution questions exist to catch inflation. EXP because it scores precise attribution |

## Values and principles cheat sheet

The careers page documents a values conversation, and the values page is in hand. Names are the company's own.

| Value | Working meaning, paraphrased | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and players disagree, players win | Selection scaffold, no quote carries it: see B1, ending in its honest branch |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | Selection scaffold, no quote carries it: see B2 and B5, ending in the honest branch. The nearest quote is F4's "Wrote the release checklist our QA team still uses" |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F4: "Wrote the release checklist our QA team still uses", with the slot in B3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| G1 | "Your talk argues a live team is judged by whether patch notes match what shipped. What does that look like here week to week?" | Ties to his own published argument, and hands him a chance to describe the real practice (talk read as a snippet only, so confirm it first) |
| G2 | "You came up through QA. When you read a release checklist, what do you look for first?" | Turns F4 from an interrogation line into a peer conversation about craft, and tells you what he scores |
| G3 | "I read that Tidepool Tactics and Lantern Row move to one shared events calendar from February. How do you see this role changing as that happens?" | Shows you read the company's news and surfaces what the job will really be; it also tells you whether the two-titles line in the JD predates it |
| G4 | "What would you want me to have learned about how the season pass and purchases work by the end of my first month?" | Names the F9 gap on your terms and turns C1's objection into a shared ramp |
| G5 | "Once a post-event review is written, who reads it, and what has one changed?" | Ties to the JD's review ownership and tells you the bar the KPIs are held to |
| G6 | "Is there anything in my background you would want me to address before we finish?" | Gives a Skeptic one more shot at saying the objection aloud, where you can answer it |

## Prohibited claims

What this pack will not coach, and the honest form of each.

| Not coached | Basis | Honest form |
|---|---|---|
| Has worked on a game with in-app purchases, or on its monetization | Negative you stated, F9 | The plain acknowledgment F9 gives: "I haven't worked on a game with in-app purchases." No slot |
| Has led a team | Negative you stated, F9's quote | "I haven't led a team", said if asked. The JD's word is coordinate, which stays an answer slot at C3 |
| Ran live events across two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says a weekly content-drop calendar for your main title, not live events or a second title. C2's slot stays inside the calendar |
| Owned or produced the retention analysis and KPIs | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material says you presented them. D1's slots ask only how a figure was counted and which part was yours |
| Managed releases against the checklist with QA | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the material says you wrote the checklist. D3's slot stays with what it covers and how it was agreed |

## Sources

No `tuesday-dossier.md` was present. Provided documents: the JD text and background in your message.

| Query or fetch | Returned |
|---|---|
| Search: Saltmarsh Games values | https://saltmarshgames.com/values |
| Search: Saltmarsh Games interview process live operations producer | https://saltmarshgames.com/careers/interviewing |
| Search: Saltmarsh Games strategy news mobile | https://saltmarshgames.com/news/project-larkspur (snippet only, not fetched) |
| Search: Tobias Wrenfield Saltmarsh Games | https://talks.gdconf.example/2026/patch-notes-are-a-promise (snippet only, not fetched; host unconfirmed) |
| Fetch: https://saltmarshgames.com/values | Page text: the three values and their definitions |
| Fetch: https://saltmarshgames.com/careers/interviewing | Page text: the loop is a recruiter call, then the Outage Hour, with no take-home |

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet and the VAL prompts in B1 to B3 and B5; the three values by name |
| 2. `Saltmarsh Games interview process live operations producer` | yes | Loop structure: one session with the hiring manager, a tabletop then a values conversation; persona weights and the decision to include the cheat sheet |
| 3. `Saltmarsh Games strategy news mobile` | yes | CO and CASE content in A3 and the reverse questions G3 and G4, from one snippet |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | The interviewer read and G1 and G2, from one snippet |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Whether Tobias is the person the role reports to → reweights every bank if he is not the hiring manager
- Your full CV → F2, F3, F5 and F8 gain quotes and the `discovery` rows can upgrade to `grounded` quotes
- Your answers to the answer slots, stated outside a drill (F1, F2, F3, F5 and D3 especially) → those rows regenerate on your own words
- A redacted copy of the release checklist, one weekly calendar and one monthly retention deck → the artifacts a producer keeps; they would raise F1, F3 and F4 from `medium` toward `high`
- Which two titles the JD's role covers → CO and CASE questions can use the real games instead of the news item's pair
- The recruiter's description of the Outage Hour → the A bank's scenarios stop being `inferred`
- Hours available before Friday → a prep triage sized to your time
- A deeper research pass (L2): up to 6 more searches and 2 more fetches, several more minutes → the full Project Larkspur announcement and the talk page read in full, a grounding brief, and a verified interviewer read; offered once
- A `tuesday-dossier.md`, if you have one → verified evidence and prohibited claims arrive pre-graded, and the objection rehearsed deepest comes from evidence rather than my inference
