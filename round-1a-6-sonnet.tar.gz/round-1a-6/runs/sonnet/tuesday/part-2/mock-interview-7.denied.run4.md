Search permission was denied, so I'm building the pack from your JD and background alone and labeling it that way. Next I'm writing the pack file.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a6/runs/sonnet/tuesday/part-2/rooms/case-7-denied-b39b82c6/saltmarsh-games_live-operations-producer_interview_pack.md`. I built it for a hiring-manager round, assuming Tobias would be your manager. Search permission was denied on all four of my lookups, so nothing in it comes from company research. Questions about Saltmarsh's values, strategy and interview format, and the read on Tobias, are missing or labeled generic. Everything about you comes from your own sentences.

The pack has 20 questions across six interviewer styles, plus six questions for you to ask. Each question has guidance built from your own wording. It also has a fit table against the JD, a list of claims the pack won't coach, and a per-requirement coverage table.

The one to rehearse first is B2: "You have not worked on a game with in-app purchases." You've said you haven't, and nothing else in your background bridges it. The honest answer is the plain acknowledgment, then a plan for getting up to speed, said until it sounds boring.

- I'll play the Skeptic on B2 as a live drill whenever you say the word.
- I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, so you can carry them into later sessions.
- If you'd like the pack as a Word document, say so and I'll convert it.

Would Tobias be your direct manager, and did the recruiter say anything about format or focus, such as a written exercise or other interviewers? The answer reweights the question banks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

- Role: Live Operations Producer, Saltmarsh Games (mobile game studio)
- Interviewer: Tobias Wrenfield, Head of Live Operations
- Round: 60 minutes, Friday. Built as a hiring-manager round, on the assumption that Tobias is the person you would report to
- Built from: the JD text and background you gave me. No company research ran, so company-specific sections are absent or labeled generic (see Sources)

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether your background claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge (no CO questions in this pack: no research ran) |
| CASE | Structure and reasoning on a live problem from the role |

An answer slot is an instruction for the interview, not a question for you now: it names a probe the JD makes likely and gives both honest branches.

## Prep triage

1. B2 first. It is the highest-ROI prep in this pack: say it aloud until the plain acknowledgment sounds boring.
2. B3, then B4 and B5. They are the next three places your material is thinnest against the JD.
3. D1, your 90-second arc, built only from the sentences you gave me.
4. C1: write your own answers to its four slots on paper before you rehearse it.
5. A1, A2 and A4 once each, aloud, structure first.
6. Choose two or three reverse questions from section 11 and have them ready.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your words stay at their scope: "I ran the weekly content-drop calendar for our main title for the last two years." The JD names two titles and live events, and your sentence names one title and content drops, which is the pack's observation, not words for you. Answer slot: expect a probe on whether any drops were time-limited events, and on what a second title changes. If any were events, say which kind and what you set; if the calendar held only content drops, or ran one title alone, say so plainly and describe how you ran it |
| F2 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | Your material gives four years as an associate producer and two years running the calendar. It does not show whether the other two years were on a live title, and the pack will not round either number up. Answer slot: expect the three-year line to be read against those two numbers. Say which years were on a live title and what your role was, in your own words; if only the last two were, say so plainly and stay with the calendar you ran |
| F3 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | The JD says coordinate, and your material is silent on it. Answer slot: expect a probe on how updates were coordinated across disciplines. If running the calendar meant getting design, art, engineering or community to deliver to your dates, say which and how; if it did not, or that was someone else's job, say so plainly and return to the calendar you ran |
| F4 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your words stay at their scope: you presented the monthly retention numbers to the studio head. The sentence says presenting, not producing or defining the numbers, and says nothing about a post-event review. Answer slot: expect a probe on who produced the numbers and whether a review followed content releases. If you built or defined any of it, say how; if someone else produced the numbers and you presented them, say so plainly and stay with the presenting |
| F5 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | Lead with the checklist in the sentence's own terms: you wrote it, and your QA team still uses it. Answer slot: the JD says manage, so expect "how does a release go through it". If you ran releases through it with QA, say how; if you wrote it and QA ran it, say so plainly and stay with that |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a stated line with nothing inspected behind it, so expect a probe. Lead with it in its own terms: weekly, your main title, the last two years, you ran it |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap, but a stated line with nothing inspected behind it. Expect "which numbers and how were they counted", which C1 rehearses |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | A written checklist that a team still uses touches this requirement, but the sentence does not say it was judged clear, and the pack will not say so for you. Answer slot: if you have a piece of your own writing you would point to, name it and let the interviewer judge it; if none comes to mind, say so plainly and stay with the checklist |
| F9 | Team leadership — not a line in the supplied JD; raised by you | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't led a team." Then how you would work across disciplines, said as a plan and never as a past. The JD says coordinate, and this pack reads that as a different thing from lead, which is its observation, not a claim for you |
| F10 | In-app purchase experience — not a line in the supplied JD; raised by you | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would come up to speed, said as a plan and never as a past. No adjacent line of yours bridges it, and nothing is added to make the gap feel smaller |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (A) | Live problems from the role: plan this update, diagnose that drop | High. The hiring-manager prior puts it first, and the JD's verbs (plan, run, coordinate, own) are all things a live problem can test | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully per case |
| Skeptic (B) | Quiet, persistent probing of the gaps | High. The hiring-manager prior puts it first, and F9 and F10 are stated absences while F1, F2 and F3 are thin | Rehearse the single most predictable objection until it is boring; bridge only from lines you actually gave; say the limit plainly |
| Data-Driven Prober (C) | Line-by-line probing of the numbers and how they were counted | Medium. The JD asks you to own KPIs and know retention metrics, and F4 and F7 rest on one sentence about retention numbers | Know what you can and cannot say about how those numbers were counted; say plainly where you do not know |
| Conversational (D) | Friendly openers, the biography question, "what are you playing" | Medium. Almost every manager interview opens this way, and casual questions are still scored | A pre-scripted 90-second arc; treat casual questions about live events as scored; never leave the reverse-question slot empty |
| Pressure (E) | Time-boxed, devil's-advocate questions on attribution | Low. No signal from you or the JD that this interviewer runs a stress style | Pause, restate, anchor in what you actually said, hold through two follow-ups before conceding anything real |
| Values / Behavioral (G) | Past-behavior scenarios | Low. No values-style round is established by your words, and no published values were retrieved. The letter F is skipped so question IDs do not collide with fit-snapshot rows | Choose a story where the hard truth actually landed; where none comes to mind, say so plainly |
| Peer Evaluator | Seam-splitting between adjacent teams | Low, and no bank. It becomes plausible only if Tobias is a peer, not your manager; my closing question would add a bank | Reciprocity framing; propose seam principles |

## Question banks

### A. Case / Strategist (weight: top, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two titles share one update slot next month, and design, art and engineering each say they need two more weeks. How do you decide what ships and what moves?" | CASE | [generic] | Clarify first: what is the update for, who is waiting on it, and what moves if it slips. Then objective, segmentation of what could move, approach, how you would tell whether the call was right, and risks. Challenge one premise out loud, such as what the two weeks are for. The question needs no claim about your past, so this guidance makes none | A live problem from the JD's coordination line (F3's requirement), asked as a decision. CASE because it scores structure; generic because it is a pattern for the problem, not a fact about this studio |
| A2 | "Retention in one title falls 20% in the week after an event ends. Diagnose it." | CASE | [generic] | Clarify: which players, measured against what baseline, over which window. Segment (new versus returning, platform, region, event participants versus not), then separate the event from anything else that changed that week, say what data you would need, and state what you would do while you wait for it. Name what you do not know about how the studio counts retention. No claim about your past | JD content from F7's requirement, CASE delivery. It scores whether retention fluency shows up live |
| A3 | "Walk me through how you would build the first eight weeks of a live-events calendar for a title you do not know yet." | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Structure as a plan: what you would ask first (the player base, the content already in the pipeline, each discipline's lead times), the cadence and mix, review points, and what you would change after week four. When you refer to your own experience, use one sentence in the quote's terms and then return to the plan: the answer is a plan, not a past | F1 is the evidence for the plan-and-run requirement, and the likeliest place to be pushed; JD because it scores a stated responsibility |
| A4 | "An engineering build for Thursday's update fails QA on Wednesday afternoon. Who do you talk to, in what order, and what do you decide?" | JD | [generic] | Clarify what failed and how bad it is, then who must hear first and what each of them needs to decide, the options (ship, ship reduced, delay) with what each costs, and what you would communicate to players and to your own teams. Say aloud what you would want the checklist to have caught. No claim about your past | JD content from F5's requirement and F3's, CASE delivery. A live version of "manage the release checklist with QA" |
| A5 | "After an event ends, what goes into the post-event review, and who needs to see it?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Structure: the result against the goal, which few measures matter and how each is counted, what you think caused the result and how sure you are, what changes next time, who acts on it. Your own line about presenting retention numbers is one sentence, in its own terms. Answer slot: if you also produced or defined any of those numbers, say how; if you only presented them, say so plainly and stay with presenting | F4 is the evidence and where the JD presses hardest; JD because it scores the review and KPIs line |

### B. Skeptic (weight: top, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Pick one honestly and name it in your own words; your own sentence gives two true candidates, and the pack's reading is that F10 is the only absence with no adjacent line of yours bridging it. Say it plainly, then give a first-weeks plan for closing it, as a plan and not a past. Do not name a weakness you do not have in order to sound modest | A standard Skeptic opener for the role; F9 and F10 are the stated absences, so the honest answer already exists and only needs rehearsing |
| B2 | "You have not worked on a game with in-app purchases. How would you come up to speed on the commercial side of a live title?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | The highest-ROI rehearsal in this pack. Open with the plain words: "I haven't worked on a game with in-app purchases." Then a plan: who you would ask, what you would read, what you would look at first in the early weeks, and that you would want the post-event review to show both the player and the commercial result. Name your limit before they ask: "I do not know how it is done here, and I will not pretend to." Likely follow-ups to rehearse: "What would you look at first?" and "What would you expect to get wrong first?" Hold by returning to the plan and the plain acknowledgment, never by reaching for a retention analogy, since your retention line speaks to retention and nothing else | F10 is a stated capability gap with no adjacent evidence, which makes it the objection the pack can least bridge and most needs rehearsed. JD because the commercial side of a live title is the role's context, not a line the JD states |
| B3 | "You have not led a team, and this role pulls design, art, engineering and community together on every update. How do you get four disciplines moving the same way?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." | Start with the plain words: "I haven't led a team." Then the plan: agree one date and one owner per discipline, put the dependencies where everyone sees them, and settle conflicts by what the update is for. Answer slot: if running the calendar meant getting other disciplines to deliver to your dates, say which and how, in your own words; if it did not, say so plainly and return to the calendar you ran | F9 is the stated gap and F3 is silent, so this is where the JD's coordination line presses hardest. JD because it scores the coordination requirement |
| B4 | "The role asks for three or more years producing live-service games. Your background says four years as an associate producer. How much of that was on a live-service title?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." | Say it in the sentences' own terms: four years as an associate producer, and the last two running the weekly content-drop calendar for your main title. Answer slot: say which years were on a live title and what your role was in them; if only the last two were, say so plainly and do not round either number up | F2 is the JD's one numeric screen and the material does not settle it. JD because it scores the experience requirement |
| B5 | "We run two titles at once, and you have run the calendar for one. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold the sentence at its scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer what changes as a plan: shared teams and shared players, who arbitrates a clash, what you would put in one calendar view. Answer slot: if any of your calendar ran alongside other titles or events, say how; if it was one title alone, say so plainly | F1 is the evidence, and the JD's "two of our mobile titles" is the line that stretches it. JD because it scores the plan-and-run requirement |

### C. Data-Driven Prober (weight: mid, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the monthly retention numbers you presented to the studio head. What were they, and how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Four slots, each in your own words, written out before you rehearse: how the numbers were counted, what they are sensitive to, the assumption behind them you would defend least, and which part was yours. The pack supplies no definition and no method. "I do not know how that was counted" is an honest branch, and so is "analytics produced them and I presented them" | F7's line is the headline metric claim and the one a prober reads closely; EXP because it tests attribution |
| C2 | "Which KPIs would you want in a post-event review, and what do you do when two of them disagree?" | JD | [generic] | Say what decision the review serves, then pick a small set of measures tied to what the event was meant to change, say what you would need to know about how each is counted here, and say how you would handle a disagreement (which one the event was designed to move wins the read, and the other becomes a question). No claim about your past | JD content from F4's requirement. Generic because it is a pattern for the problem and asserts nothing about this studio's KPIs |
| C3 | "How would you write up an event that missed its target, for people who were not in the room?" | JD | [inferred] "Wrote the release checklist our QA team still uses." | Structure the writing: result against target first, one line on the likeliest cause marked as a hypothesis, what changes next time, and what the reader needs to do. You may point to the checklist as a piece of your writing in those words and let the interviewer judge it; do not say it was clear. Inferred: the line touches written communication and nothing in it speaks to post-event writing | F8 is low confidence, so this is a coaching note rather than a claim. JD because it scores the writing requirement |

### D. Conversational (weight: mid, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey. How did you get here, and why live ops?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc with exactly these beats and no others: four years as an associate producer at a puzzle-game studio, the last two running the weekly content-drop calendar for your main title, the release checklist your QA team still uses, the monthly retention numbers you presented to the studio head. Answer slot: your reason for moving to live operations and to this studio is yours to give in your own words; if you do not have a settled reason, say what you do know and stay honest about the rest | The biography question arrives in some form in almost every interview, and the arc is built from F2, F4, F5 and F6. EXP because it scores a story |
| D2 | "What are you actually playing these days that has a live-events calendar you watch closely?" | JD | [generic] | Name something you actually play. Say one thing about how its events are paced that you noticed as a player, and one thing you would change, and stop there. If you do not play one now, say so and name what you would study first. Do not name a game you have not played | A casual question about the JD's live-events line, scored as hard as any other; generic because it makes no claim about your history or this studio |
| D3 | "What is the piece of work you are proudest of?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Choose honestly. If it is the checklist, tell it only in the sentence's beats: you wrote it, and your QA team still uses it. If it is something else, tell that in your own words; this pack holds only what your message states | F5 is the line that sounds most like a finished thing; EXP because it scores what you actually did |

### E. Pressure (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has already run live events on two titles?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." | Pause and restate the question. Anchor in the two sentences only: you ran the weekly content-drop calendar for your main title for the last two years, and you wrote the release checklist your QA team still uses. Hold through two follow-ups by returning to them. Answer slot: if the follow-up asks whether you have run more than one title, answer it from the truth, plainly, in your own words | F1 and F5 are the evidence a pressure interviewer tests against a stronger rival. EXP because it scores attribution under pressure |
| E2 | "That checklist: how much of that was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold the sentence at its scope: you wrote it, and your QA team still uses it. Answer slot: if anyone else contributed to it, say who and what; if you wrote it alone, say so plainly. Concede specifically what you cannot speak to, such as what happened to it after you wrote it | F5's wording is the sentence a pressure interviewer tests for inflation. EXP because it scores attribution |

### G. Values / Behavioral (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you had to deliver bad news about a date or a result to someone senior." | VAL | [generic] | No sentence of yours carries a story here, so use selection criteria: pick a time the news was unwelcome, name the stake, the moment you did not soften it, and where the relationship stood afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioral probe for a role that reports dates and results upward; the nearest evidence, F4, says presenting numbers, not that any were unwelcome |
| G2 | "Tell me about a time design, art or engineering wanted something different from what you thought was right for an update." | VAL | [generic] | No sentence of yours carries a story here, so use selection criteria: a real disagreement, what each side wanted, what you did, and what the outcome was. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's coordination line (F3's requirement) produces this question in a behavioral register |

## Requirement coverage

| JD requirement | Questions covering it |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A3, B5, E1 |
| Coordinate design, art, engineering and community teams on each update | B3, A1, G2 |
| Own the post-event review and the KPIs it reports | A5, C2, C1 |
| Manage the release checklist with QA | A4, E2, D3 |
| 3+ years producing live-service games or apps | B4, D1 |
| Experience running a content calendar | A3, B5, D1 |
| Comfortable with player-retention metrics | C1, C2, A2 |
| Clear written communication | C3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good first 60 days look like in this seat, and what would tell you it was not working?" | It turns the interview into a conversation about expectations, and your answer to B1 and B2 then has a landing place |
| R2 | "How do the two titles' calendars interact today: shared teams, shared players, and where do clashes get settled?" | It shows you read "two of our mobile titles" as a coordination problem, which is F1's weak point |
| R3 | "How is a post-event review used here: who reads it, and what has it changed?" | It tells you what "own the KPIs" means in practice, and shows you treat the review as a working document |
| R4 | "How do events and the commercial side of the titles work together today, and who owns that conversation?" | It addresses F10 openly: you are asking how the work is done, not pretending to know |
| R5 | "Where does this role end and design's or engineering's lead begin on an update?" | A seam question; it signals you want the boundaries explicit before the first update |
| R6 | "What would you want a new producer to read or look at before day one?" | It shows preparation and gives you real material to study if you get the job |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team | Negative you stated, F9 | The plain acknowledgment F9 gives: "I haven't led a team." No slot |
| Has worked on a game with in-app purchases | Negative you stated, F10 | The plain acknowledgment F10 gives: "I haven't worked on a game with in-app purchases." No slot |
| Planned and ran a live-events calendar for two titles | Inflated form of F1 | F1's sentence at its own scope. The limit is the pack's observation: the material says one title and content drops. B5's slot stays inside the calendar you ran |
| Owned the post-event review and the KPIs | Inflated form of F4 | F4's sentence at its own scope. The limit is the pack's observation: the material says presenting the numbers, not producing or defining them. A5's slot stays inside the presenting |
| Managed releases with QA | Inflated form of F5 | F5's sentence at its own scope. The limit is the pack's observation: the material says you wrote the checklist QA uses. E2's slot stays inside the writing |
| Has three or more years of live-service production | Inflated form of F2 | F2's two sentences at their own scope. The limit is the pack's observation: the material gives four years as an associate producer and two years running the calendar |

## Sources

Provided documents: the JD text and your background, both in your message. No dossier was present.

Queries sent, all refused (search permission was not granted):
- "Saltmarsh Games company values" — refused
- "Saltmarsh Games interview process live operations producer" — refused
- "Saltmarsh Games mobile studio strategy news" — refused
- "Tobias Wrenfield Saltmarsh Games" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Would have moved the VAL themes and a values cheat sheet, if a values-style round had been detected; neither is in this pack |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | Would have moved persona weights; they now rest on your words and the hiring-manager prior |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | Would have moved the CO bank and made A1 and A2 specific; both are generic cases and the pack has no CO question |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Would have moved the interviewer read and one reverse question tied to his path; both are absent |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Search access, or a pasted values page, careers page or strategy note → company values, the loop, current strategy and Tobias's public footprint: a CO question, specific cases, an interviewer read and a reverse question tied to his path
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes), offered once and needing search access → a strategy brief for the CO and CASE banks
- The recruiter's prep email, or any steer on format → coverage of a written exercise, a presentation or a panel, which would add a graded-deliverable section and strengthen C3
- Which of your four years were on a live title, and whether any calendar drops were time-limited events → upgrades F1 and F2, and B4, B5 and A3, from open slots to your own words
- Whether running the calendar meant getting other disciplines to deliver to your dates → upgrades F3, and B3 and G2
- Who produced the retention numbers and what they covered → upgrades F4 and F7, and C1 and A5
- A tuesday-dossier.md from an earlier run → graded evidence and an absolute prohibited-claims list, never a precondition
