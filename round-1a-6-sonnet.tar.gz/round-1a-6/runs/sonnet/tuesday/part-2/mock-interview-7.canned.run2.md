I've run four searches on Saltmarsh's values, interview loop, strategy and Tobias's public talk. Next I'm fetching the official values page and the interviewing page to get exact wording.
I'm checking the working directory for an existing dossier and reading the dossier hand-off rules, which I need before I can offer one. After that I'll write the pack.
Your prep pack is saved as `saltmarsh-games_live-operations-producer_interview_pack.md`. It has 20 questions across six personas. I assumed Tobias is the hiring manager, because Saltmarsh's own interviewing page says every loop is a recruiter call, then one 60-minute session with the hiring manager. That session, "the Outage Hour", is a live-incident tabletop on a simulated outage during a live event, then a values conversation, and there's no take-home.

What I found, and what the pack is built around:
- **Saltmarsh's three published values:** Players Before Plans, Ship the Patch Not the Promise, and Leave the Build Greener. The values questions are mapped to them.
- **Project Larkspur (September 2026):** it moves both titles to a season-pass model with one shared events calendar from February 2027. I only read this as a search snippet, not the full page.
- **Tobias's public footprint:** his GDC 2026 talk "Patch Notes Are a Promise", and a former QA lead background. This is also from a search snippet only. Your release checklist is the natural shared ground with him.
- **Biggest likely objection:** "you've never worked on a game with in-app purchases", set against the season-pass change. The pack names it as your highest-ROI prep (C1) and rehearses it as a plain acknowledgment plus a plan.

I used only your own sentences as your evidence. Where your material goes quiet (for example, whether you worked across more than one title, or who built the retention numbers), the guidance gives you an answer slot to fill in your own words, or to say plainly that it wasn't yours.

Say the word and I'll play Tobias as the Skeptic on C1, or run the tabletop A1 live.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the person you'd report to if hired, or a skip-level? If the recruiter told you anything about what the tabletop covers, that helps too. The answer reweights the banks.
Do you want a deeper research pass? It's up to 6 more searches and 2 more fetches, and takes several more minutes. It would add the full Larkspur announcement and more on Tobias's talks, and it would sharpen the strategy questions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Built on the assumption that he holds the hiring-manager seat in Saltmarsh's single 60-minute interview, the Outage Hour (the Saltmarsh interviewing page says that loop is a live-incident tabletop on a simulated outage during a live event, then a values conversation, with no take-home). If he is actually a skip-level or a panel member, the persona weights below need redoing.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and only say what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows Saltmarsh's published values, not generic virtue |
| EXP | Whether your own claims survive scrutiny, and exactly which part was you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you can think at the company's altitude: strategy, recent moves |
| CASE | Structure and reasoning on a live problem from the actual role |

Answer slots in the guidance are instructions for the interview, not questions for you now. Fill them in your own words, or take the second branch.

## Prep triage

The interview is Friday and your prep hours are unstated, so this is ordered by what changes the most if you only do a few things.

1. C1, out loud, three times. It is this pack's highest-ROI rehearsal (see the persona table).
2. A1 and A3, out loud, thinking aloud as you go. The tabletop is the first half of the session.
3. B3 and B4, with the answer slots filled in your own words.
4. B2: write the player note once on paper.

Everything else is insurance.

## Fit snapshot

The JD states no gate. "3+ years" is an experience requirement, not a gate, so every row below is graded on confidence and gap type. Rows are numbered R1 to R9 so they do not collide with the question banks' letters.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| R1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says one main title, and does not say mobile or live events, so the words stay at the quote's scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's two-titles line makes a probe on scale likely. If you worked across more than one title, or on a mobile title, say which, in your own words; if you did not, say so plainly and stay with the calendar you ran |
| R2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message; "Never led a team, and never worked on a game with in-app purchases." — your message | low | [inferred] | discovery | The calendar quote touches the requirement without showing which disciplines the drops involved, and your second sentence says you have not led a team: "I haven't led a team." The JD says coordinate, not lead. Answer slot: if design, art, engineering or community each had a part in a drop, say which and what you did with them, in your own words; if the drops involved none of them, or it was not yours, say so plainly and stay with the calendar |
| R3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | The quote is adjacent work: it says presented, not compiled or owned, and the words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose or built any of what was reported, say which part, in your own words; if the numbers came from elsewhere, or you only presented them, say so plainly and stay with presenting them |
| R4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it, so expect a probe on how much of it was you. Lead with the quote's own terms: you wrote it, and QA still uses it |
| R5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | medium | [grounded] | discovery | The quote gives the years and the role, and does not say whether the title was live-service. Answer slot: if the studio's main title was a live-service game, say so in your own words; if it was not, say so plainly and stay with "four years as an associate producer at a puzzle-game studio" |
| R6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | The quote reaches the requirement in role-relevant terms. Lead with it as written: weekly, one main title, two years. Expect a probe because nothing is inspected behind it |
| R7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | The quote reaches the requirement. The likely probe is how those numbers were counted, which D1 rehearses |
| R8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | A checklist someone else still uses is the one written artifact your material shows; it does not show whether it was clear. Answer slot: if you also wrote notes or updates for others, say which, in your own words; if not, say so plainly and stay with the checklist |
| R9 | Familiarity with in-app purchases in live events: a role-family expectation, not in the JD (generic) | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. The Project Larkspur announcement (September 2026, read as a search snippet) says both titles move to a season-pass model from February 2027, which is why this is the likeliest objection. Never a claim to monetisation work, and nothing added to make the gap feel smaller |

## Reading the interviewer

Source: one search result, a conference talk listing, read as a snippet only (the page was not opened). Public professional footprint only.

| Item | What it says | Source |
|---|---|---|
| Career pattern | Head of Live Operations at Saltmarsh Games, previously a QA lead at a console studio | Talk listing, GDC 2026 |
| Self-described argument | In "Patch Notes Are a Promise", a live team is judged by how often its patch notes describe what actually shipped | Talk listing, GDC 2026 |
| Implication 1 | Expect scope-exactness: claims about your own work get tested against what was actually done, which is the same standard as the published value "we announce what is built, not what is hoped" | Talk listing; Saltmarsh values page |
| Implication 2 | QA is his native language, so release checklists and ship-or-hold calls are the vocabulary he will think in during the tabletop | Talk listing |
| Implication 3 | Do not lecture him on release process. Say what you did, at its scope, and ask how his team does it | Pack's reasoning from the two rows above |
| Mirror opportunity | His public path runs from QA lead into live operations; your side of that shared ground is R4: "Wrote the release checklist our QA team still uses." Offer it as a shared professional touchpoint at its own scope and nothing wider | R4 evidence cell |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (bank A) | The tabletop: a simulated outage during a live event, talked through live | Highest. The interviewing page documents the tabletop as the first half of the session, and the hiring-manager relationship prior is Case plus Skeptic | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Values / Behavioral (bank B) | A values conversation on the three published values | Highest, tied with A. The interviewing page documents the values conversation as the second half | Map a story to each value where one of your quoted sentences carries it; where none does, use the scaffold and its honest branch |
| Skeptic (bank C) | Quiet probing of the gaps. C1 is the highest-ROI prep in this pack | High. The hiring-manager prior is Skeptic, and R9 is a stated gap against a titles-wide monetisation change | Rehearse the single objection until it is boring: plain acknowledgment, then a plan |
| Data-Driven Prober (bank D) | Retention numbers probed to their assumptions | Medium. The JD asks for retention comfort and KPI ownership; nothing public from the interviewer says he is analytics-led, so this is not weighted up | Say plainly what you know of how a number was counted and which part was yours |
| Pressure (bank E) | Time-boxed challenge on why you, and on attribution | Medium-low. The page says nothing about stress tactics; it is here because a hiring manager derisking gaps may press | Hold the position the quotes carry through two follow-ups, concede the stated gap specifically |
| Conversational (bank F) | A friendly opener on your journey | Medium-low. Casual openers exist in any session, and they are still scored | A short arc built only from your own quoted sentences |
| Peer Evaluator | Not banked. The documented loop is one hiring-manager session, so there is no peer seat to prepare for | Excluded, with the reasoning shown so you can add it back if you know otherwise | — |

## Question banks

### A. Case / Strategist (weight: highest; 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A simulated outage hits mid-event: a weekend double-reward event is live and players cannot log in. Walk me through your first ten minutes." | CASE | [inferred] | Clarify first, aloud: what is down, who is affected, since when, whether the event clock keeps running. State the objective (limit harm to players, keep the message honest). Then who you pull in (the JD names design, art, engineering and community), what players are told and when, and what you would decide about the event once you know more. Challenge one premise respectfully, for example whether the clock should keep running at all. The question needs no claim about your past, so the guidance makes none | The interviewing page documents a live-incident tabletop on a simulated outage during a live event; the scenario details are a pattern for it, which is why this is inferred. CASE because it scores structure under time pressure; the JD's coordination line (R2) is the requirement behind it |
| A2 | "The fix lands 90 minutes before the event was due to end, and players lost access for most of it. What do you do with the event and the calendar?" | CASE | [inferred] | Name the options (extend, compensate, run as scheduled), the information you would want first, and the criterion that decides between them. Saltmarsh's published value is "when the calendar and the players disagree, the players win", so say aloud which side of that you are testing each option against. State what the decision costs the next scheduled drop. No claim about your past | A second tabletop turn from the same documented format, aimed at the calendar-versus-players tension in the first value; R1 and R6 are the requirements it scores |
| A3 | "Engineering has a hotfix build, and QA says the release checklist is not complete. How do you decide whether it ships?" | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Structure it: which unfinished checks are risk-ranked highest, who decides and who advises, what players are told either way. You may say, at its scope: "I wrote the release checklist our QA team still uses." Answer slot: if a ship-or-hold call ever rested on that checklist, say what happened and what part was yours, in your own words; if none did, or that call was not yours, say so plainly and stay with how you would decide here | The JD's "manage the release checklist with QA" line (R4) meets an interviewer whose public path starts in QA, so a ship-or-hold call is a likely tabletop beat; CASE delivery with JD content |
| A4 | "We are moving to one shared events calendar across the two titles. What do you need to know before you plan it?" | CASE | [inferred] | Ask before structuring: what an event looks like in each title, where events would overlap, who owns each title's content, what a shared calendar is meant to improve. Then objective, approach, metrics, risks. Reason from the announcement only: the Project Larkspur snippet says one shared events calendar from February 2027, and nothing else about its design is known. Challenge one premise, for example whether one calendar means one cadence. No claim about your past | CO and CASE grounded in the current strategy (Larkspur announcement, September 2026, read as a search snippet) joined to the JD's two-titles line (R1); inferred because the snippet is thin |
| A5 | "A weekend event ran, and its retention curve looks flat against the last one. Diagnose it." | CASE | [generic] | Clarify which players and which baseline; list hypotheses (the event itself, a technical issue, a seasonal effect, the measurement); say what you would check first and what you would report from the post-event review. Say what you would not conclude yet. No claim about your past | The JD's post-event review and KPI line (R3, R7) as a live problem; generic because it is a pattern, not a fact about this employer |

### B. Values / Behavioral (weight: highest; 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed. What won?" | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Value: Players Before Plans. Your quote puts you inside a calendar; look there first. Pick one time a scheduled drop pulled against what players needed. It needs a named stake, the decision you made, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The first published value as an open prompt; R6 is why the calendar is the place to look; VAL because it scores the value, not the calendar |
| B2 | "Players lost most of an event to an outage. Write me the player note, two sentences." | VAL | [grounded] | Value: Ship the Patch Not the Promise, "we announce what is built, not what is hoped". Write it, then test each clause: does what it states already exist? Say what happened, what is fixed, what players get only if it is decided. Leave out hopes. Say aloud what you left out and why. No claim about your past | The second published value as a written exercise, which also tests the JD's "clear written communication" (R8); his talk's argument makes it likely. VAL with CASE delivery |
| B3 | "Tell me about a time you left a process better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Value: Leave the Build Greener, "every release leaves the codebase and the checklist better than it found them". Story-mapped on R4: you wrote a release checklist, and QA still uses it, which are the beats the quote states. Answer slot: the value raises "better than it found them", so expect a probe on what was wrong before. If there was a prior version or a specific problem, say what, in your own words; if you wrote it from nothing, or nothing came before it, say so plainly and stay with the checklist and QA's continued use | The third published value, asked as an open prompt; R4 is the one sentence that carries it |
| B4 | "Tell me about a time you delivered an unwelcome number or message to someone senior." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | The quote carries presenting retention numbers monthly to the studio head, and nothing about how any month landed. Answer slot: if any month's numbers were unwelcome, say what you said and how it landed, in your own words; if none were, say so plainly and stay with presenting them monthly. Do not supply an ending the material does not show | A persona-stem open prompt on the Values/Behavioral stem; links to "announce what is built" because retention numbers are what happened. R3 and R7 are the evidence |
| B5 | "Which of our three values would be hardest for you in this job?" | VAL | [grounded] | Pick one honestly; the three are Players Before Plans, Ship the Patch Not the Promise and Leave the Build Greener. Say why in terms of the work itself, and what you would do about it in your first weeks. If you cannot choose, say so plainly and name the one you would test first. No claim about your past | Tests honest self-assessment against the published values; a likely Skeptic move inside a values conversation |

### C. Skeptic (weight: high; 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Both our titles move to a season-pass model from February 2027, and you've never worked on a game with in-app purchases. How do you handle that?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." — "I ran the weekly content-drop calendar for our main title for the last two years." — "Wrote the release checklist our QA team still uses." — "Presented the monthly retention numbers to the studio head." | The highest-ROI rehearsal in this pack. Hold only what the quotes carry: the weekly calendar for two years, the checklist, the monthly retention numbers. Concede the gap in your own plain words: "I haven't worked on a game with in-app purchases." Then a plan, said as a plan: what you would ask and study in your first weeks about how the pass and the events fit together. Hold through two follow-ups by returning to the quotes, never by adding to them | R9 is the largest stated gap and the one the Larkspur announcement presses on; JD because it scores how you would meet an unmet requirement |
| C2 | "This role coordinates design, art, engineering and community on every update, and you've never led a team. How do you get four disciplines to move to a date?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." — "I ran the weekly content-drop calendar for our main title for the last two years." | Plain acknowledgment first: "I haven't led a team." Then note that the JD says coordinate. Answer slot: if design, art, engineering or community each had a part in a drop, say which and what you did with them, in your own words; if the drops involved none of them, or it was not yours, say so plainly and describe what you would do in week one | R2 is a discovery row sitting next to a stated negative; the Skeptic returns to it in collegial packaging |
| C3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Choose from what your material actually shows: the stated gaps are R9 and, as a limit rather than a stated negative, R2. Name one in your own words, say how you would close it in a way you can say as a plan, and stop. Calibrated candor beats bluffing a competency the interviewer owns | The persona stem; asked of every candidate and answered best by one who has rehearsed it |

### D. Data-Driven Prober (weight: medium; 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You presented the monthly retention numbers to your studio head. Walk me through how those numbers were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | The defend-the-number slots, in your own words: how they were counted, what they are sensitive to, the assumption you would defend least, and exactly which part was yours. If you do not know how they were counted, say so plainly. The quote says presented; keep it there | R7 is where a prober starts; EXP because it tests attribution and method honesty |
| D2 | "After a weekend event, which retention measure do you report, and what does it tell you?" | JD | [generic] | Name the measure, the cohort and the baseline you would use and why; say what the measure cannot tell you. No claim about your past | Scores "comfortable with player-retention metrics" (R7) and the post-event review line (R3) as a live choice |
| D3 | "Your post-event review says an event worked. What would make you doubt that?" | CASE | [generic] | Name two or three things you would check before reporting success: the baseline, other changes in the same window, the cohort. Link it to "announce what is built, not what is hoped": say what you would hold back from the report until checked. No claim about your past | A prober's turn on the post-event review (R3), and a bridge to the second value |

### E. Pressure (weight: medium-low; 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a candidate who has run live events on a game with in-app purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." — "Wrote the release checklist our QA team still uses." — "Presented the monthly retention numbers to the studio head." — "Never led a team, and never worked on a game with in-app purchases." | Pause, restate. Hold the position the quotes carry: the two years of the weekly calendar, the checklist, the monthly retention numbers. Hold through two follow-ups. Concede specifically and once: "I haven't worked on a game with in-app purchases." Never fold on what the quotes say to restore harmony | Pressure scores composure on exactly the point C1 rehearses; JD because it presses the requirement list |
| E2 | "That release checklist — how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | The quote says you wrote it and QA still uses it. Answer slot: if others shaped it, say who and what, in your own words; if it was yours alone, say so plainly and stay with "I wrote the release checklist our QA team still uses." | The attribution probe from the Pressure stems, aimed at R4, the row where this interviewer is most expert |

### F. Conversational (weight: medium-low; 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey: how did you get here?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." — "I ran the weekly content-drop calendar for our main title for the last two years." — "Wrote the release checklist our QA team still uses." — "Presented the monthly retention numbers to the studio head." | A 90-second arc built from those four sentences only: four years as an associate producer at a puzzle-game studio; the weekly calendar for two years; the checklist; the monthly retention numbers. Answer slot: why live operations, why Saltmarsh, why now is not in your material; give your own reason in your own words, or if you do not have a settled one, say so plainly and say what draws you to this role | The biography opener is nearly certain in a casual register and is still scored; R5 and R6 are its spine |
| F2 | "Which live-service game's event calendar do you admire, and why?" | JD | [generic] | Name a real game you actually follow and one specific thing about its events, in your own words. If none comes to mind, say so plainly and name what you would study first. No claim about your past | A casual question on a hot JD topic (R1); generic because it asks for your taste, not your record |

## Values cheat sheet

A values-style round is documented: the interviewing page lists a values conversation as the second half of the session.

| Value (official name) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Players Before Plans | When the schedule and what players need conflict, players come first | Scaffold, B1: pick one time a drop pulled against what players needed, with a stake, a decision and an outcome. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | Scaffold, B2: pick one time you held an announcement back, or would, until the thing existed. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | R4: "Wrote the release checklist our QA team still uses." |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "You came to live operations through QA. What did that change about how this team handles a release?" | Tied to his own path (from the talk listing, previously a QA lead at a console studio). It turns a probe on your checklist into a peer conversation |
| 2 | "Your talk argues patch notes are a promise. What does the team check before notes go out?" | Shows you read his argument, and it is the second published value in practice |
| 3 | "From February 2027 Project Larkspur puts the titles under one live-ops group and one events calendar. Which two titles does this role cover, and where does it sit in that group?" | The JD says two titles and names neither; the announcement names two. The answer tells you what you would actually inherit. Source: Larkspur announcement, September 2026, search snippet |
| 4 | "What does a post-event review report today, and which number do you trust least?" | The JD makes the review and its KPIs part of the job; the answer shows how much of it you would own |
| 5 | "What would a good first post-event review from me look like?" | Gives him a concrete bar to describe, and you leave with a target |
| 6 | "I haven't worked on a game with in-app purchases. What would you want me to have learned by the end of my first month?" | Volunteers the stated gap on your terms and turns it into a ramp plan he sets. Your call whether to ask it |

## Prohibited claims

Built before the banks. None of these is coached anywhere in this pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team | Negative stated in your message ("Never led a team, and never worked on a game with in-app purchases.") | The plain acknowledgment: "I haven't led a team." No slot |
| Worked on a game with in-app purchases, or ran monetised events | Negative stated in your message, same sentence | The plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot |
| Ran a live-events calendar across two mobile titles | Inflated form of R1 | R1's quote at its own scope. The limit is the pack's observation, not words for you: the material says one main title and does not say mobile |
| Owned the post-event review and its KPIs | Inflated form of R3 | R3's quote at its own scope. The material says presented, not owned or compiled |
| Managed QA's release process | Inflated form of R4 | R4's quote at its own scope: you wrote the checklist QA still uses |

## Sources

**Provided:** the job description you pasted, and your background as written in your message (the pack's "CV"). No dossier was present.

**Searches sent (4):**

| Query | Returned |
|---|---|
| Saltmarsh Games values | https://saltmarshgames.com/values |
| Saltmarsh Games interview process live operations producer | https://saltmarshgames.com/careers/interviewing |
| Saltmarsh Games strategy news mobile | https://saltmarshgames.com/news/project-larkspur |
| Tobias Wrenfield Saltmarsh Games | https://talks.gdconf.example/2026/patch-notes-are-a-promise |

**Fetches (2):** https://saltmarshgames.com/values and https://saltmarshgames.com/careers/interviewing, both read in full. The Larkspur announcement and the talk listing were read only as search snippets; I did not open those pages.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | The three values by name, the values cheat sheet and bank B |
| 2. `Saltmarsh Games interview process live operations producer` | yes | The loop (a recruiter call, then the Outage Hour), the persona weights and banks A and B |
| 3. `Saltmarsh Games strategy` / recent news | yes | Project Larkspur (September 2026), snippet only: A4, C1, R9 and reverse question 3 |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | The interviewer read, the mirror opportunity and reverse questions 1 and 2, from the snippet only |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The recruiter's prep email or call notes → whether the tabletop scenario is provided in advance, which two titles the role covers, and the level; would sharpen A1 to A4 and reverse question 3
- Your actual CV lines (the pack quotes only your message) → verbatim quotes with any figures, which would upgrade R1, R3, R5 and R8 and add defend-the-number rows
- Your answers to the answer slots, said outside a drill, on R1, R2, R3, R5 and R8 → those rows and their question guidance move from slots to story maps
- The talk itself (or Tobias's public profile), which I read only as a snippet → a firmer interviewer read and more reverse-question material
- A full Project Larkspur announcement, read in full → sharper A4 and C1 and a stronger grounding on the season-pass change
- A `tuesday-dossier.md` from earlier work on this role, if you have one → verified evidence and a prohibited-claims list that would replace this pack's local ones; the pack is complete without it
