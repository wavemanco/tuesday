Searches were refused, so I'll build from what you gave me. I'm writing the prep pack now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a6/runs/sonnet/tuesday/part-2/rooms/case-5-denied-672235f0/kelverton-rail_senior-partnerships-manager_interview_pack.md`.

I built it for a two-person panel, with Deepa as your future manager and Ross pushing on commercials. The pack has 18 questions. Web search was refused, so the Kelverton specifics come only from what you wrote. I also haven't seen the market report. Anything about Kelverton's strategy or market is generic until you paste in the report's key points.

The pack includes a build section for the 15-minute POV, with three theses, each with a concession. It also covers how to differentiate from the report, and how to close on what it means for operators. The most predictable objection is B1: you haven't sold into rail, and you've never carried a quota. That's the one to rehearse hardest.

One thing to settle before Tuesday: "9 years in partnerships" doesn't obviously match 4 years at the payments company plus 5 years of consulting. Decide which years you'd call partnerships work, because someone will ask.

Say the word and I'll run a live drill as Deepa and Ross, starting on B1. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to Word.

1. Can you paste the report's main conclusions, especially anything about operators? A4 and your POV's differentiation rest on them.
2. Do you have the JD text? If so, paste it and I'll replace the recruiter-derived requirements with the real ones.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail

Round: second round, one 60-minute panel. Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). Per the recruiter: a 15-minute spoken POV first, then Q&A, with Ross pushing on commercials.

Built on one assumption: the market report the recruiter attached was not in view when this was written, and no JD was supplied, so requirements come from the recruiter's own words and your message. Rows that would change with either are marked in the upgrade menu.

## How to use this pack

- Personas are how a question is asked. Types are what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you did.
- Type key: VAL is behavioral/values alignment. EXP is work-experience deep-dive. JD is role/JD-driven. CO is company and strategy knowledge. CASE is a hypothetical or live problem.
- An answer slot is an instruction for the interview. It asks nothing of you here.

## Prep triage (about four hours)

1. 75 min: build the POV (section: Graded deliverable). Then say it aloud once against a timer.
2. 45 min: B1, the highest-ROI rehearsal in this pack. Do B2 right after it, because Ross will join the two.
3. 30 min: C1 and C2, the defend-the-number pair. Settle on paper which years were partnerships work (F6).
4. 45 min: re-read the report with the consensus, divergence and anti-pick structure in mind (A4).
5. 45 min: full spoken run of the POV, then B1 and D1 back to back.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" — recruiter email | "took it from 6 partners to 40" — your message | medium | [grounded] | transferability | The quote is channel growth in a payments ISV channel, which is adjacent to operator partnerships and does not reach them. Words: "In my last role I took the ISV channel from 6 partners to 40." Answer slot: expect a probe on whether that model carries to operators. Say what you think carries over and what does not, in your own words; if you do not know, say so plainly |
| F2 | "Please land on what it means for the operators themselves" — recruiter email | "bus and light rail network planning" — your message; "so I know the operator world from the other side" — your message | medium | [grounded] | transferability | Your material says bus and light rail network planning, not train operations. Words: "I spent five years in transport consulting on bus and light rail network planning." Answer slot: "the other side" is your phrase and an interviewer will ask which side of what. Say what you meant in your own words; if it was not train operators, say so plainly and stay with the planning work |
| F3 | "Ross will push on commercials" — recruiter email | "roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | The quote is influenced revenue, not booked or owned revenue, and the words stay there: "roughly £4M of influenced revenue." Answer slot: expect how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Answer each in your own words; "I don't know how it was counted" is an honest branch |
| F4 | A senior partnerships role at a vendor may be measured on a direct revenue number — role-family pattern, no source | "never carried a direct quota, only influenced revenue" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never carried a direct quota, only influenced revenue." Then how you would approach accountability here, said as a plan and never as a past |
| F5 | "they sell scheduling software to train operating companies" — your message | "Never sold into rail specifically" — your message | none | [grounded] | capability | You have stated it. Words: "I have never sold into rail specifically." Then how you would learn it, said as a plan. Nothing added to make the gap feel smaller |
| F6 | "Senior Partnerships Manager" — role title from your message | "9 years in partnerships" — your message | medium | [grounded] | discovery | The quote does not show which years were partnerships work: your message also gives 5 years of transport consulting and 4 years at the payments company. Answer slot: expect "how many of the nine were partnerships". Say which years were, in your own words; if the consulting years were not, say so plainly and lead with the years that were |

## Graded deliverable: the 15-minute POV

Announced by the recruiter, so it is graded. The recruiter's asks: where you would take operator partnerships over 18 months, no slides, and "land on what it means for the operators themselves."

Facts you can build on. F1: "took it from 6 partners to 40". F2: "bus and light rail network planning". Nothing else about your past goes in without a quote behind it.

Timing: 2 min frame, 8 min theses, 3 min operator close, 2 min risks and what you would need from them.

| Thesis | Mandatory concession | Provenance |
|---|---|---|
| Treat operators as co-designers of the roadmap, not as accounts to be managed | It costs Kelverton roadmap control and speed, and it may not suit every operator | [generic] |
| Depth before breadth: a few joint, multi-year outcomes with chosen operators beats a wide programme, if the report shows a small addressable set of operators | Your own channel grew by breadth; the concession is that your ISV playbook may not transfer and you would test it first. It also concentrates risk in a few relationships | [generic] |
| Agree two or three operator outcomes with each partner and report them jointly | Attributing an operator's results to software is hard, and operators may not share the data | [generic] |

These are positions to test against the report, not facts about Kelverton. Keep a thesis only if the report supports it or you can defend it from your own reasoning.

Differentiation: the report is equally available to Deepa, Ross and every other candidate, so reciting it scores as homework. Bring one consensus item to prove you read it, then one divergence with reasons, then the anti-pick: one thing you would say no to or not prioritise. I have not seen the report, so the items are yours to fill in.

The requested close, for the last three minutes: what operators get, what operators must give, and who they call. Say it as a proposal ("I'd propose…"), never as something operators have asked for.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems from the partnerships role; clarify-first scoring | Highest. Deepa is your future manager, which the hiring-manager prior weights to Case plus Skeptic, and the POV itself is a case | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic | The rail gap, the missing quota, why leave payments | High. Same prior; F4 and F5 are your own stated gaps | Rehearse B1 until it is boring; hold what the quotes carry; say plainly what you lack |
| Data-Driven Prober | The £4M and the 6 to 40, line by line | High. The recruiter said Ross will push on commercials, and I am reading that as a prober tilt | Know what you can and cannot say about how each figure was counted; name your weakest assumption first |
| Pressure | Interruptions, time-boxing, "why you" | Medium. Same Ross reading; panels also tend to split roles | Pause, restate, hold through two follow-ups, then concede specifically |
| Conversational | The opening "walk me through your background" | Low but certain: it opens the Q&A | A 90-second arc built only from your quotes |

The loop is established by the recruiter's words: one 60-minute panel, 15 minutes of POV, then Q&A. No archetype fallback is used, and no values-style round is named, so no values sheet is included.

## Question banks

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Talk us through where you'd take our operator partnerships over the next 18 months, and what that means for the operators." | CASE | [grounded] recruiter email | This is the POV. Build it from the deliverable section. Guidance makes no claim about your past beyond F1 and F2 | The recruiter named it; JD content, CASE delivery |
| A2 | "Before you'd commit to that plan, what would you need to know first?" | CASE | [generic] | Clarify before structuring: what "partnership" means commercially here, which operators first, what success is measured as, what constraints exist. Ask rather than assume | Panels score clarify-first on a live problem; the question needs no claim about your past |
| A3 | "Two operators want opposite things from the next release. How do you decide, and what do you tell the other?" | CASE | [generic] | Structure it: what you would ask first, how the decision is made and by whom, what you tell the operator who loses, what you record. Make no claim about having done it | A live problem on the operator relationship; relates to the POV close |
| A4 | "Our strategy team circulated a market report last quarter. Which of its conclusions would you challenge?" | CO | [generic] | One consensus item you agree with, one divergence with reasons, one anti-pick. Fill these from your own reading; I have not seen the report | Shared source, so differentiate rather than recite; CO because it tests company-altitude thinking |
| A5 | "Which operators would you partner with first, and which would you say no to?" | CASE | [generic] | Give your selection criteria first, then apply them. Name operators only if the report or your own research supports it; otherwise stay at criteria level | Tests prioritisation and the willingness to say no, which the differentiation section also needs |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've not sold into rail. Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically"; "bus and light rail network planning" | The highest-ROI rehearsal in this pack: the objection arrives in some form from both panelists. Hold only what the quotes carry: "I have never sold into rail specifically." Then the nearest thing your material does carry: "I spent five years in transport consulting on bus and light rail network planning." Then a plan, said as a plan. Follow-ups to rehearse: what you would do in 90 days, how you would know it was working, how you would handle an operator who doubts a newcomer. Answer slot: if any of your bus and light rail work touched train operators, say so in your own words; if it did not, say so plainly and stay with the planning work | F5 is a gap you stated and F2 is the adjacent evidence; JD because it scores the stated role |
| B2 | "You've never carried a quota. How do you know you can be accountable for a number?" | EXP | [grounded] "never carried a direct quota, only influenced revenue" | Hold: "I've never carried a direct quota, only influenced revenue." Answer slot: if any of the influenced revenue came with a target you were measured against, say what, in your own words; if none did, say so plainly and return to the channel work. Then say how you would approach accountability here, as a plan | F4 is your stated gap; Ross is the likely asker |
| B3 | "Why leave payments, why rail, why now?" | EXP | [generic] | Selection scaffold: pick the one reason that is true and specific, tied to the role rather than to what you are leaving. If no reason comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Motivation consistency is where the Skeptic persona probes |
| B4 | "How does a train operating company's world differ from the bus and light rail operators you planned networks for?" | JD | [grounded] "bus and light rail network planning" | Answer slot: say what you know in your own words; if you do not know a difference, say so plainly and say how you would find out. Do not claim knowledge of train operations your material does not show | F2's limit, asked directly |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the £4M of influenced revenue was counted." | EXP | [grounded] "roughly £4M of influenced revenue" | Answer slot: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Name that assumption before they do. If you do not know how it was counted, say so plainly | F3; every headline number gets a defend-the-number question |
| C2 | "From 6 partners to 40: how was a partner counted at each end, and what part of that growth was yours?" | EXP | [grounded] "took it from 6 partners to 40" | Answer slot: how a partner was counted, what the figure is sensitive to, the weakest assumption, and which part was yours. Say plainly if others contributed | F1; a second headline figure |
| C3 | "How would you tell whether an operator partnership is working commercially?" | CASE | [generic] | A structure: what the operator gets, what Kelverton gets, which measures lead and which lag, and what you could not yet measure. Make no claim about having done it | The commercial thread Ross will pull |
| C4 | "What's the difference between revenue you influenced and revenue you'd be accountable for here?" | JD | [grounded] "never carried a direct quota, only influenced revenue" | Hold: "I've never carried a direct quota, only influenced revenue." Then how you would treat accountability here, as a plan | F4 again, in Ross's register |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a candidate who has sold into rail?" | JD | [grounded] "took it from 6 partners to 40"; "Never sold into rail specifically" | Pause and restate. Hold what the quotes carry: "In my last role I took the ISV channel from 6 partners to 40." Hold through two follow-ups by returning to it. Concede specifically: "I have never sold into rail specifically." Never fold the core claim to restore harmony | F1, F5 |
| D2 | "That growth: how much of it was actually you?" | EXP | [grounded] "took it from 6 partners to 40" | Answer slot: say which part was yours in your own words; if others did parts of it, say so plainly. Hold, then concede the specific limit | Attribution probes exist to catch inflation |
| D3 | "You're in the first commercial conversation with an operator. What do you ask for?" | CASE | [generic] | Answer aloud under interruption: restate, then the one or two things you would ask for and why. Make no claim about having done it | Time-boxed and interruptible, which Ross may do |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "5 years in transport consulting"; "last 4 at a payments company running the ISV channel" | A 90-second arc built only from those two quotes, in your own words. Answer slot: if asked how many years were partnerships, say which, per F6 | Opens most Q&A sections; casual register, still scored |
| E2 | "What would your first month look like?" | JD | [generic] | A plan, said as a plan: who you would meet, what you would read, what you would not yet decide. Make no claim about your past | Closes the loop on B1's day-one weakness |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| "where you'd take our operator partnerships over the next 18 months" | A1, A2, A3, A5 |
| "Please land on what it means for the operators themselves" | A1, A3, B4 |
| "Ross will push on commercials" | B2, C1, C2, C3, C4, D3 |
| Senior Partnerships Manager, partnerships experience | E1, C2, D2, B3 |
| sells scheduling software to train operating companies | B1, B4, D1 |
| The attached strategy report | A4 |
| JD requirements | none, and why: no JD was supplied |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would tell you in the first 90 days that this role is moving operator partnerships forward?" | It asks for the scoring sheet and lets you check it against your POV |
| R2 | "What does the role carry commercially, and is a direct number part of it?" | It meets the F4 gap in the open, rather than leaving it for the panel to raise |
| R3 | "Which operator relationships do you most want strengthened this year?" | It shows you are thinking about operators, not about yourself |
| R4 | "Where does your team disagree with the market report?" | It signals you read it as an argument, not a script |
| R5 | "How do partnerships and commercial divide an operator deal?" | It is a seam question for both panelists |
| R6 | "What does a new person in this seat usually misjudge in the first quarter?" | It signals you plan to be a learner rather than a know-it-all |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has carried a direct quota or revenue target | Negative you stated, F4 | "I've never carried a direct quota, only influenced revenue." No slot |
| Has sold into rail | Negative you stated, F5 | "I have never sold into rail specifically." No slot |
| Knows train operating companies from the inside | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: your material says bus and light rail network planning, not train operations |
| Owned or closed the £4M | Inflated form of F3 | F3's quote at its own scope: "roughly £4M of influenced revenue" |
| Nine years of partnerships work | Inflated form of F6 | F6's quote at its own scope; C1's and E1's slots stay inside the years you can name |

## Sources

Provided: your message, which quotes the recruiter's email. The attached market report was not in view when this was written.

Searches sent, all refused: "Kelverton Rail values"; "Kelverton Rail interview process partnerships manager"; "Kelverton Rail strategy train operating companies scheduling software news"; "Deepa VP Partnerships Kelverton Rail"; "Ross Commercial Director Kelverton Rail".

Research tier: L1 — searches 5 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Every call was refused. It would have fed a values sheet, but no values round is named, so nothing in this pack changed |
| 2. Kelverton Rail interview process | unavailable | Every call was refused. Persona weights rest on the recruiter's description of the loop instead |
| 3. Kelverton Rail strategy | unavailable | Every call was refused. CO and CASE questions are generic, and A4 rests on the report you hold |
| 4. Interviewer names | unavailable | Every call was refused. The interviewer read is absent and no reverse question is tied to their paths |
| 5. Representative JD | unavailable | No call was sent because search was refused earlier. Without a JD, requirements come from the recruiter's words |

## Upgrade menu

- The market report's headline conclusions → A4, the differentiation section and R4 become grounded in what the report says
- The JD text, if you have it → requirements become quoted and the JD-tagged rows become grounded, and it would also surface any location, pay or schedule terms
- Your answers to the slots in F1, F2, F3, F6, B1, B2, C1 and C2 → those rows become story-mapped from your own words
- Public profiles for Deepa and Ross → an interviewer read and a reverse question tied to each one's path
- Search permission → the L1 research pass; a deeper pass, up to 6 more searches and 2 more fetches taking several more minutes, can be offered once that works
- A `tuesday-dossier.md` from a job-underwriter run → verified evidence and prohibited claims arrive pre-graded
