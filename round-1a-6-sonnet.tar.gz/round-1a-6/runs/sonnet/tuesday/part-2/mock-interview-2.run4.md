Search permission was declined, so I'm building the pack from your JD and background only. I'm writing the pack file now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a6/runs/sonnet/tuesday/part-2/rooms/case-2-denied-97707151/atlas-freight_operations-manager_interview_pack.md`. It has 18 questions, a fit snapshot, a persona table, six reverse questions and a list of claims not to make.

I built it for a hiring-manager or panel round with evenly spread persona weights, because you don't know who is interviewing you. The search tool was denied, so I read nothing about Atlas Freight itself. The pack rests only on your JD and what you told me, and the company-specific questions are labeled generic.

- **The question to rehearse most (A2):** "You're over three supervisors today, and this role has twelve across four sites. How do you get from one to the other?" Hold to what you said: "I'm a senior shift manager over three supervisors." Give your own plan for twelve, said as a plan and not as past work.
- **Power BI:** your own words are "never used Power BI," so the pack coaches you to say that plainly and follow it with your plan. One of the reverse questions asks whether the JD's "Excel/Power BI" means you'd need Power BI.
- **Your 40% mis-pick result:** expect questions on how it was counted and how much of it was you. Say what you know about the count, and say plainly if you don't know.
- **Terminal and multi-site work:** your material says warehouse and distribution, not terminal operations or several sites. The pack leaves slots for you to fill from your real experience.
- **The 5+ years of leadership:** the pack asks how many of your seven years were leading people. Say the number you can stand behind.

I can play the Skeptic on A2, the question the pack names as your highest-value prep. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions, or convert the pack to Word.

Do you know the round type, such as a recruiter screen, hiring manager or panel? The recruiter's invite usually says. The answer reweights every question bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

Interviewer: not known. Round type: not known. This pack is built as a full-loop pack with flat persona weights, which is weaker than a pack built for a known round. The assumption is stated in the persona table.

## How to use this pack

Personas describe how a question is asked. Types describe what it is scoring. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether your experience claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company and can think at its altitude |
| CASE | Structure and reasoning on a live problem from the role |

An answer slot is an instruction for the interview, not a question for you now. Where one appears, answer it from your real experience, or say plainly that the practice was not yours.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material says warehouse and distribution operations and a shift manager role, not terminal operations and not several sites. Words stay at the quotes: "I have seven years in warehouse and distribution operations, and I'm a senior shift manager over three supervisors." Answer slot: the JD's four-site line makes a probe on multi-site responsibility likely. If any of your work covered terminal operations or more than one site, say what, in your own words; if none did, say so plainly and stay with the warehouse and distribution work |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Mis-pick rate is adjacent work, not on-time performance or cost per shipment, and the bridge does not stretch it. Words: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if you tracked on-time performance or a cost per unit, say what you tracked and what moved, in your own words; if you did not, say so plainly and stay with the mis-pick result |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | The quote says three supervisors and the JD says twelve; the number stays with its noun. Words: "I'm a senior shift manager over three supervisors." The step up in span is the pack's observation, not a gap you recite. Answer slot: if you are probed on how you would lead twelve, give your own plan in your own words, said as a plan and never as a past |
| F4 | "build reporting in Excel/Power BI" — JD (Excel half) | "solid Excel, never used Power BI" — your message | medium | [grounded] | discovery | "Solid Excel" is a skill, and the material does not show whether you built reporting with it. Answer slot: if you built reports in Excel, say what they showed and who used them; if you did not, say so plainly and say what you used Excel for |
| F5 | "build reporting in Excel/Power BI" — JD (Power BI half) | "solid Excel, never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used Power BI." Then how you would learn it, said as a plan and never as a past. Never a claim to Power BI work. The JD writes the two tools as a pair, so whether Power BI is required over Excel is an open question for the reverse bank |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | Seven years of operations is in your words; how many of them were leading supervisors is not. Answer slot: if you are asked how many years were leadership, say the number you can stand behind; if the leading part is shorter than five years, say so plainly and stay with the seven years of operations |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | The quote reaches the requirement, but it does not say which methodology or which body. Say it at its own scope: "I'm green belt certified." Answer slot: if you are asked which green belt it is, say what your certificate says; if you are asked where you applied it, answer from your own work, or say plainly that you have not yet |

Requirement coverage: each JD requirement and the questions that carry it.

| Requirement | Questions |
|---|---|
| Own daily terminal operations across 4 sites | A1, A3, B3, B5 |
| Drive on-time performance and cost-per-shipment down | B1, B2, B4 |
| Lead a team of 12 supervisors | A1, A2, D3, E1 |
| Build reporting in Excel/Power BI | A1, B4, D2 |
| 5+ years operations leadership | A5 |
| Lean/Six Sigma a plus | C3 |

## Persona table

No loop source was read, so the loop is not established. The weights rest on the Generic archetype (screen, hiring manager, panel) with flat weights. They are built for a likely hiring-manager or panel round because the role owns four sites and a team of supervisors. If you learn the round type, the weights change.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of scale and background fit | High: F1 and F3 are the biggest steps between your material and the JD | Rehearse the single most predictable objection until it is boring; bridge only from what you said; say the limit plainly |
| Case/Strategist | Live problems from the role: diagnose a drop, plan a peak week | High: the JD's measures (on-time performance, cost per shipment) are easy to turn into cases | Clarify, objective, segmentation, approach, metrics, risks; think aloud |
| Data-Driven Prober | Reads your numbers line by line | Medium: the 40% figure is the one number in your material | Know how the figure was counted, or say plainly you do not know |
| Conversational | Friendly, unstructured; still scored | Medium: likely in a screen or opening minutes | A 90-second arc built only from your quoted sentences |
| Pressure | Time-boxes, interrupts, tests composure | Low: expected only in a panel or senior round | Pause, restate, hold through two follow-ups, concede only what the quotes limit |

## Question banks

Highest-ROI prep in this pack: A2. A scale-up from three supervisors to twelve across four sites is the question most likely to arrive in some form, and a rehearsed, non-defensive answer changes the interview.

### A. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "solid Excel, never used Power BI"; "currently a senior shift manager over 3 supervisors" | Pick the gap you can state in your own quoted words and name it first: "I've never used Power BI" or "I'm a senior shift manager over three supervisors." Follow with your own plan for closing it, said as a plan. Do not pick a gap your quotes do not show | Stem question for the Skeptic; F3 and F5 are the two gaps your own words state. JD because it scores the stated requirements |
| A2 | "You're over three supervisors today, and this role has twelve across four sites. How do you get from one to the other?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI rehearsal in this pack, and the hold is only what the quote carries: "I'm a senior shift manager over three supervisors." Concede only the numbers the quote and the JD both show: three today, twelve in this role. Answer slot: if you are probed on how you would lead twelve, give your own plan in your own words, said as a plan and never as a past. Hold through two follow-ups by returning to the quote, never by adding to it | F3 is where the JD presses hardest on your material; JD because it scores the team-size requirement |
| A3 | "I don't see terminal operations in your background — how would you handle that part of the role?" | JD | [grounded] "7 years in warehouse and distribution ops" | Start from the quote: "I have seven years in warehouse and distribution operations." Answer slot: if any of your work touched terminal operations, say what, in your own words; if none did, say so plainly and stay with the warehouse and distribution work, then give your own plan for learning the terminal side | F1 is a transferability row; the stem is the Skeptic's own. JD because it scores the first requirement |
| A4 | "Why this move, why Atlas, why now?" | CO | [generic] | Give your actual reasons in your own words; this pack has none from you and supplies none. For why Atlas, use only what you have learned about the company from its own materials, and say plainly what you have not yet read | Motivation consistency is what the Skeptic scores; CO because it tests homework. `[generic]` because company research was refused and nothing here is about Atlas |
| A5 | "The role asks for five or more years of operations leadership. How many of your years were leading people?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Answer slot: say the number of years you led people that you can stand behind, in your own words; if the leading part is shorter than the five years, say so plainly and stay with the seven years of operations. Do not round up | F6 is a discovery row; a titled-years requirement is probed literally. JD because it scores that line |

### B. Case/Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one of your four terminals dropped ten points over a month. Walk me through your diagnosis." | CASE | [generic] | Clarify first: how on-time is defined, against what, and over which shipments. Then objective, segmentation (by lane, shift, inbound and outbound), approach, metrics, risks. Think aloud; challenge one premise respectfully. The question needs no claim about your past | A live problem from the JD's first measure; `[generic]` because it is a pattern for the problem, not a fact about Atlas |
| B2 | "Cost per shipment is up at one terminal while volume is flat. Where do you look first?" | CASE | [generic] | Clarify which costs are in the figure, then break it down, form a hypothesis and say what you would check to test it. The question needs no claim about your past | The JD's second measure, asked as a diagnosis; `[generic]` for the same reason as B1 |
| B3 | "A peak week is coming and two of your four sites are short-staffed. How do you plan the week?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Structure it: what you would ask first, what you would protect, how you would rebalance across sites. If you use your own surge plan as the example, stay with the quote: "I ran the site's peak-season surge plan two years running." Answer slot: if you are probed on what the plan covered, say what, in your own words; if you do not remember or it was not yours, say so plainly | The surge plan is F1's only multi-condition evidence; CASE because it is a live planning problem |
| B4 | "What would your weekly view of the four terminals look like — which measures, and how would you build it?" | CASE | [grounded] "solid Excel, never used Power BI" | Choose measures from the JD's own: on-time performance and cost per shipment. For the tool, stay at the quote: "I'm solid in Excel and I've never used Power BI." Answer slot: if you have built a report in Excel, say what it showed and who used it; if not, say so plainly and describe what you would build first | F4 and F5 are the reporting rows; CASE because it asks you to design, JD because it scores the reporting requirement |
| B5 | "Atlas runs four sites with twelve supervisors. What do you do in your first thirty days?" | CASE | [generic] | A plan, said as a plan: what you would learn, who you would meet, what you would not change yet. It makes no claim about your past | F1 and F3 are the biggest scale steps; a first-thirty-days plan lets you show structure where your material shows scale limits |

### C. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: if you know how the figure was counted, say so in your own words; if you do not know, say plainly that you do not know how it was counted. Do not describe a baseline or a method you cannot repeat under a second question | F2 carries the one figure in your material, so it is the likeliest probe |
| C2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | The weakest-assumption move, in your own words: name what the figure is most sensitive to, before the interviewer does. Answer slot: if you know one, say it; if you do not, say plainly that you do not | The Prober's stem; naming the weak point first turns a gotcha into a credibility gain |
| C3 | "You're green belt certified. Where have you applied it at work?" | JD | [grounded] "green belt certified" | Say the certification at its own scope: "I'm green belt certified." Answer slot: if you applied it at work, say where and what changed, in your own words; if you have not applied it yet, say so plainly and stay with the certification. Say whether the pick-path redesign used the method only if it did | F7 is the plus in the JD; JD because it scores the requirement, with the probe aimed at the gap between certified and applied |

### D. Conversational (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path" | A 90-second arc with exactly three beats, the ones the quotes state: seven years in warehouse and distribution operations, a senior shift manager over three supervisors, and the mis-pick result. Tell them in your own words and add no further beats | The biography question is asked in every loop and is scored even when it feels casual |
| D2 | "Do you work much with Power BI?" | JD | [grounded] "solid Excel, never used Power BI" | Treat the casual question as scored. Answer from the quote: "I've never used Power BI, and I'm solid in Excel." Then your plan for learning it, said as a plan | F5 is the capability gap; a casual register is where candidates drift into overclaiming |
| D3 | "Tell me how you work with your supervisors day to day." | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Answer in your own words about your own routine; this pack supplies none. Keep the scope at the quote: three supervisors | F3's scale is the follow-up; JD because it scores the leadership requirement |

### E. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a candidate who has run several sites?" | JD | [grounded] "7 years in warehouse and distribution ops"; "ran the site's peak-season surge plan two years running"; "cut mis-pick rate 40% by redesigning the pick path" | Hold what the quotes carry: seven years in warehouse and distribution operations, a peak-season surge plan you ran two years running, and the mis-pick result, each in its own scope. Concede only what the quotes and the JD both show: three supervisors today, twelve in this role. Hold through two follow-ups; never fold on the core claim to restore harmony | The Pressure stem; F1 is where the comparison hurts |
| E2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold the quote: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if others did part of it, say which part and whose; if none did, say so plainly and stay with the redesign | Attribution probes exist to catch inflation; the rehearsal is precise candour |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does on-time performance look like across the four terminals today, and what is driving the gap to where you want it?" | It uses the role's own first measure and shows you are thinking about the job, not only the title |
| R2 | "The posting says Excel/Power BI — which does the team actually use today, and how much of the reporting would be mine to build?" | It surfaces the Power BI question early on your terms |
| R3 | "How are the twelve supervisors spread across the four sites, and what does the team I would inherit look like?" | It addresses the span-of-control step directly and signals you are already planning for it |
| R4 | "What would success look like at ninety days and at one year?" | It shows you are scoring yourself against the interviewer's own measure |
| R5 | "What has changed most in how Atlas runs its terminals over the last year, and what is next?" | It signals interest in the company's direction without asserting anything you have not researched |
| R6 | "What would make someone from a warehouse and distribution background succeed here, and what should they learn first?" | It puts the likeliest objection in the open as a shared planning question |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led or managed a team of twelve supervisors | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material says three supervisors, the JD says twelve |
| Ran terminal operations or owned several sites | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation: the material says warehouse and distribution operations and a shift manager role |
| Drove on-time performance or cost per shipment down | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: the material says mis-pick rate, not on-time performance or cost per shipment |
| Built reporting or dashboards in Excel | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the material says skill in Excel, not reports built |
| Has Power BI experience | Negative the candidate stated, F5 | The plain acknowledgment F5 gives: "I've never used Power BI." No slot |
| Led operations teams for five or more years | Inflated form of F6 | F6's quotes at their own scope. The limit is the pack's observation: the material does not say how many of the seven years were leading people |
| Is Lean Six Sigma certified, or used the green belt on the pick-path redesign | Inflated form of F7 | F7's quote at its own scope: "green belt certified". The limit is the pack's observation: the material does not say which methodology or body, or whether the redesign used it |

## Sources

Provided documents: the JD text you pasted, and your own background description.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

All three searches were sent and refused, so nothing was read and nothing from Atlas Freight's own materials is in this pack.

| Query | Outcome |
|---|---|
| Atlas Freight regional logistics company values | refused |
| Atlas Freight interview process operations manager | refused |
| Atlas Freight regional logistics terminals news strategy | refused |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Search refused. It would have fed a values cheat sheet if a values round were detected; none is, so the loss is small |
| 2. `Atlas Freight interview process operations manager` | unavailable | Search refused. It would have established the loop and set the persona weights; they rest on the Generic archetype instead |
| 3. `Atlas Freight strategy` / recent news | unavailable | Search refused. It would have grounded a CO question in Atlas's current priorities; A4 and R5 stay generic |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form |
| 5. representative `Operations Manager` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Round type and who you are meeting (the recruiter's invite or email usually says) → persona weights recomputed, the bank reordered, and reverse questions retuned
- The interviewer's name → an interviewer read and a reverse question tied to their path
- Permission to search, or a pasted copy of Atlas's values and careers pages → company-specific CO questions, a real loop, and the values cheat sheet if a values round is documented
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → strategy brief and recent-org context for the CO bank; offered once
- Your CV text → seven rows get exact CV quotes instead of your message's wording
- Answers to the slots in F1, F2, F4 and F6 (multi-site work, on-time or cost tracking, reports built in Excel, years leading people) → those rows upgrade from discovery or transferability
- A `tuesday-dossier.md` if you have one → verified evidence, an evidence-based objection and a prohibited-claims list; this pack does not need one
