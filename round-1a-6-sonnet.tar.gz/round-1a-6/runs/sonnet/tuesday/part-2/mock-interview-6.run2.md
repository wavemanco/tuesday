Web search was blocked by the permission prompt. I'll build the pack from what you've told me and note where that limits it. I'm writing the three-round pack file now.
Your prep pack for all three rounds is saved at `/var/tmp/tuesday-measure/1a6/runs/sonnet/tuesday/part-2/rooms/case-6-denied-691ec0c7/larkfield-systems_engineering-manager_interview_pack.md`.

The pack has one shared fit snapshot and a prohibited-claims list. Each round then has its own persona weights, question bank (9 questions each) and six reverse questions.

I couldn't research Larkfield. The three web searches were refused at the permission prompt, so nothing in the pack comes from Larkfield's own material. That has three effects:
- **Persona weights:** they rest on your description of each round.
- **Monday's values questions:** they are scaffolds, not stories matched to Larkfield's published values.
- **Strategy questions:** they are generic.

I assumed Tuesday's Director is your future manager. I did not assume the two staff engineers sit on your squads, because you didn't say.

- **Biggest gap:** your own words flag it. You've "never owned a hardware-adjacent roadmap," and the role has you partnering with hardware on roadmap. T-A2 rehearses it for Tuesday, and it comes back on Thursday (H-C2) and Monday (M-D1).
- **Your 60% and "about 40 interviews":** expect probes on how each was counted and which part was yours.
- **Growth and domain:** your material says nothing yet on growing engineers or on device management. The pack gives you answer slots for both, not invented stories.

Offers, each one line:
- I can run a live drill, starting with T-A2 as the Skeptic.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions.
- I can convert the pack to a Word document.

Questions (any you skip, I'll leave as is):
1. Can you paste your CV or the bullets for your current role? Right now the pack rests only on four sentences from your message.
2. Did the recruiter say what the Thursday panel will focus on, or ask you to bring something such as a presentation or exercise?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview prep pack (loop mode): Engineering Manager, Larkfield Systems

Candidate: Yusuf. Three rounds: Tuesday, 45 min, the Director of Engineering (hiring manager, your would-be boss). The Thursday after, 60 min, panel of two staff engineers and a product manager. The following Monday, 30 min, the VP Engineering (relayed by the recruiter as "values and leadership philosophy"). No names were given for any interviewer.

## How to use this pack

- One shared fit snapshot and prohibited-claims list serve all three rounds. Each round then has its own persona weights, question bank and reverse questions. Question IDs start with the round: T (Tuesday), H (Thursday), M (Monday), then a persona letter and a number.
- Personas are how a question is asked. Types are what it scores. Guidance is scaffolding for a spoken answer, not a script.
- Answer slots (instructions ending without a question mark) are for the interview itself. They ask nothing of you here.

| Tag | What it scores |
|---|---|
| VAL | Whether past behavior shows the values and leadership approach, not generic virtue |
| EXP | Whether your own claims survive scrutiny; what was actually you |
| JD | The stated responsibilities of the role, including your gaps |
| CO | Company and strategy knowledge |
| CASE | A live problem set in the role |

Highest-ROI prep in the whole pack: T-A2, the hardware-roadmap question. The Director will ask it in some form on Tuesday, a panel member will return it in friendlier packaging on Thursday (H-C2), and the VP's version arrives as M-D1. A calm, short, honest answer rehearsed until it is boring changes all three rounds.

## Fit snapshot (shared)

Requirements are the role description as you gave it. Evidence is your own words and nothing else.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role description (your message) | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message; "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | medium | [grounded] | transferability | Your material says a team lead of 6, one team; the role says two squads, and nothing inspected sits behind it. Words at that scope: "Three of my nine years have been as a team lead of 6." Anything wider is an answer slot: if you have ever had to split your attention across more than one group, say how, in your own words; if not, say so plainly and stay with the team of 6. Your stated negative can be given back as it is: "I've never managed managers." |
| F2 | "own delivery" — role description (your message) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | Adjacent work, not delivery ownership: the sentence is about a reliability quarter and its result. Words at that scope: "I pushed a reliability quarter through against roadmap pressure." Answer slot: the role's delivery line makes a probe on who held the delivery commitments likely. If any were yours, say which and how you held them; if not, or they were someone else's, say so plainly and stay with the quarter you pushed through |
| F3 | "own delivery, hiring and growth for 11 engineers" — role description (your message), the hiring part | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | none | The quote already reaches the hiring requirement in role-relevant terms. Lead with it as written: you run the loop, for backend roles. Expect a probe on the figure; the four defend-the-number slots apply (how it was counted, what it is sensitive to, the assumption you would defend least, which part was yours) |
| F4 | "own delivery, hiring and growth for 11 engineers" — role description (your message), the growth part | none given | none | [grounded] | discovery | Your material does not show this either way. Answer slot: if you have helped anyone develop, say who and what, in your own words; if not, or it was not yours, say so plainly and say how you would approach it as a plan, never as a past |
| F5 | "partner with hardware and product on roadmap" — role description (your message) | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | low | [inferred] | discovery | You stated you have not owned a hardware-adjacent roadmap; partnering is a different ask and your material says nothing on it either way. Words you may give back: "I've never owned a hardware-adjacent roadmap." Answer slot: if you have worked alongside hardware or product colleagues on what gets built when, say how, in your own words; if not, say so plainly and return to the sentence |
| F6 | "industrial IoT" and "device-management services" — role description (your message) | none given | none | [grounded] | discovery | Your material does not show domain experience either way. Answer slot: if you have built or run anything near devices or fleets, say what, in your own words; if not, say so plainly and say what you would read or ask first |

No row is a gate: the role description states no term (location, authorization, schedule, pay) you would meet or not.

## Round 1 — Tuesday, Director of Engineering (45 min)

Assumption this round is built on: the Director is your future manager and has read your CV closely. Nothing else is known about them.

| Persona | How it shows up | Weight | Reasoning shown | Counter-move |
|---|---|---|---|---|
| Skeptic | Quiet probing of the gaps: hardware, scale, growth, why now | High | Hiring-manager prior is Case plus Skeptic; your own statements put real gaps (F1, F4, F5) in front of them | Rehearse the one predictable objection (T-A2) until it is boring; bridge only from what you said |
| Case/Strategist | Live problems from the actual role | High | Hiring-manager prior; they are buying capability on their own roadmap | Clarify, structure, answer; say the framework aloud |
| Data-Driven Prober | Reads the CV line by line, asks about the 60% and the 40 | Medium | You gave two numbers; a manager hiring a manager checks them | Know how each was counted; name the weakest assumption first |
| Conversational | Opening "walk me through the journey" | Medium | Almost every first-round interview opens this way | Prepare a 90-second arc from your own sentences |
| Pressure | Time-boxing, devil's advocacy | Low | No sign of a stress format; the hold-then-concede move in T-A2 covers it | Hold through two follow-ups, concede specifically |
| Peer Evaluator | Seam-splitting | Low | They are a boss, not a peer | None needed |

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| T-A1 | "Why this role, and why now?" | JD | [generic] | Give your actual reasons in your own words, two or three sentences. Tie one of them to a line of the role description you really want, quoting it: "lead two squads", "partner with hardware and product on roadmap". Do not borrow a reason you do not hold | Motivation consistency is the Skeptic's first check; JD because it scores fit to the stated role |
| T-A2 | "You haven't owned a hardware-adjacent roadmap, and this role partners with hardware on roadmap. How would you handle that?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | The highest-ROI rehearsal in the pack. Open with the plain sentence you stated: "I've never owned a hardware-adjacent roadmap." Then a plan, said as a plan: whom you would sit with first and what you would ask them. Hold through two follow-ups by returning to the sentence, never by adding to it; concede only that this is new to you. Follow-ups to expect: what the first month looks like, then what you do when you disagree with the hardware lead about timing, answered as an approach and not as a past. Answer slot: if asked whether you have ever worked alongside hardware colleagues, say how if you have, in your own words; if not, say so plainly and return to the sentence. Limit named before it is asked: your material says owned, not partnered | F5 is your largest stated gap against a core line of the role; JD content, Skeptic delivery |
| T-A3 | "You've led a team of 6; this is two squads and 11 engineers. How do you think about your attention across both?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Say what you have: "Three of my nine years have been as a team lead of 6." Then how you would approach two groups, as a plan. Answer slot: if you have had to split your attention across more than one group, say how; if not, say so plainly and stay with the team of 6. If asked about leading through other leads, the sentence you stated applies: "I've never managed managers." | F1 is the scale step; the Director will test whether it is a stretch or a leap |

### B. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| T-B1 | "Sketch your plan for your first quarter with two squads you've just inherited. What do you need to know first?" | CASE | [generic] | Clarify first: what each squad owns, what is already committed to hardware and product, what is on fire. Then objective, how you would split your time, what you would measure, the risks. Think aloud and challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | Live problem from the role description's first line (F1's requirement); a pattern for the problem, not a fact about this team |
| T-B2 | "A hardware release slips six weeks and a feature the product team promised depends on it. Your squad's part is ready. What do you do?" | CASE | [generic] | Clarify (what is promised to whom, what exactly slipped), options, trade-offs, who needs to hear what and when, what you would not do. Say the decision rule before the decision. No claim about your past | Tests F5's requirement and F2's delivery line as a decision, not a record |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| T-C1 | "Walk me through how the 60% was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Say what you can about how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours, each in your own words. If you do not know how something was counted, say so plainly. Name the weakest assumption before they do | Headline figure from F2; EXP because it tests attribution and counting |
| T-C2 | "You pushed a reliability quarter through against roadmap pressure. Tell me what that looked like." | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Tell it at the sentence's own scope: you pushed the quarter through against roadmap pressure, and on-call burden dropped 60%. Answer slot: the role's roadmap-partnership line makes a probe on who the pressure was from and what changed in the plan likely. If you made the case yourself, say to whom and how; if the decision sat with others, or the pressure was informal, say so plainly and stay with the quarter you pushed through | F2 and F5 meet here; it is your strongest story and the one most likely to be pulled apart. JD content, EXP delivery |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| T-D1 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | A 90-second arc of the beats the sentence states: nine years in engineering, three as a team lead of 6, currently at a payments company. Close on why this role, in your own words. Nothing in the arc claims more than the sentence | F1's quote is the only biography in the material; casual openers are still scored |
| T-D2 | "What are you actually looking at in industrial IoT these days?" | JD | [generic] | Answer slot: if you have read, built or tried anything in this space, say what, in your own words; if not, say so plainly and name the first thing you would read | F6 has no evidence; a casual question on the role's domain is still scored |

### Reverse questions, Tuesday

| # | Question | Why it lands |
|---|---|---|
| T-R1 | "What would make the first 90 days a clear success for the two squads, in your eyes?" | Shows you scoring yourself against his definition of owning delivery (F2) |
| T-R2 | "Where do hardware timelines and software commitments collide most today, and how does that get decided?" | Turns the T-A2 gap into a working conversation about the real seam (F5) |
| T-R3 | "How are the two squads split, and who sets priorities between them?" | Shows you thinking about attention across both groups (F1) |
| T-R4 | "How are growth and promotion decisions made here, and what part is the manager's?" | Opens F4 on their terms |
| T-R5 | "What tends to make managers here succeed or struggle in their first six months?" | Asks for the Director's own scoring sheet |
| T-R6 | "How would you want to hear from me when delivery is at risk?" | Signals you already think about escalation as a working agreement |

## Round 2 — Thursday, panel: two staff engineers and a product manager (60 min)

Assumption this round is built on: who the staff engineers report to is not stated, so no question assumes they sit on your future squads. The PM is read as the cross-functional member.

| Persona | How it shows up | Weight | Reasoning shown | Counter-move |
|---|---|---|---|---|
| Peer Evaluator | "What would you need from us, and how do we disagree?" | High | Panel blends each member's top two; staff engineers are priced as peers and are pricing what a manager costs or adds | Reciprocity: what you bring them; propose seam principles, do not pretend to know the seam |
| Data-Driven Prober | Digging into the 60% and the 40 | Medium | Technical specialist prior; the figures are the only numbers they have | Know how each was counted; say plainly where you do not |
| Values/Behavioral | Stories on partnership and customers | Medium | PM is cross-functional, outside the engineering function | Choose stories your own sentences carry; selection scaffold where none does |
| Case/Strategist | Roadmap conflict scenario | Medium | A PM's native format is a prioritization problem | Clarify, structure, state the decision rule |
| Skeptic | The hardware and scale gaps in collegial packaging | Low | Objections from Tuesday return softened; T-A2 is the rehearsal | Same sentence, same limit |
| Conversational | Light opener | Low | Round is 60 min with three people; little room for chat | None needed |

### A. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H-A1 | "How do you handle credit when work spans teams?" | VAL | [generic] | A principle first, then one instance. Selection criteria: a time credit was shared across more than one group, with a named stake and an intact relationship afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Credit-sharing is a stock peer probe; no quoted sentence carries it, so a scaffold |
| H-A2 | "A staff engineer tells you your priority call is wrong, after the squad has already started on it. What happens next?" | CASE | [generic] | Show spine and tact together: listen, ask what they would change, decide who decides, say it out loud, record it. No claim about your past | The disagreement-with-equals scoring; a live problem, nothing premised |
| H-A3 | "Where do you stay out of technical decisions, and where do you step in?" | JD | [generic] | A principle, not a history: what you bring staff engineers (clear priorities, protection from churn) and where the seam is theirs. Propose the principle and ask how it works here | The seam question for a manager hiring into an engineer-dense team (F1's requirement) |
| H-A4 | "How do you run hiring, and what would you change about how we hire?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Lead with the sentence as written: you run the loop, for backend roles. Answer slot: the role's hiring line makes a probe on the loop's stages likely. Describe them as you actually run them, in your own words; if a stage is not yours, say so plainly and stay with what you run. Then an opinion on what you would change, as an opinion | F3 is your most direct evidence and the one panel members will use to size you as a colleague |

### B. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H-B1 | "The 60% drop in on-call burden: what would make that number look better or worse than it is?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Four slots, each in your own words: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. The weakest-assumption move turns a gotcha into credibility | Same figure as T-C1, asked by people closer to the on-call work (F2) |
| H-B2 | "How many of those 40 interviews did you run yourself?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Say what the figure counts and which part was yours, in your own words. If you do not know exactly, say so plainly. Keep to "I run our hiring loop for backend roles." and do not widen it | F3's figure has the same shape as the 60%: counted how, and by whom |

### C. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H-C1 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection criteria: a time with a named stake, a choice you made, and an outcome you can state. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Stock cross-functional values probe; no quoted sentence carries it |
| H-C2 | "Tell me about a time you and a product partner disagreed about what to build next." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Open prompt: choose your instance. If your nearest story is the reliability quarter, tell it only at the sentence's scope: you pushed it through against roadmap pressure. Answer slot: the role's product-partnership line makes a probe on who disagreed and what was agreed likely. If you can say who and what, say it in your own words; if there was no one specific, or you did not decide it, say so plainly and stay with the quarter. If no such time comes to mind, say so plainly | F5's collegial return from the PM; the one place the Skeptic's Tuesday question resurfaces |

### D. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H-D1 | "Product wants a new fleet-wide device capability next quarter. Hardware says the devices cannot support it until a later release. Your two squads are full. Walk us through it." | CASE | [generic] | Clarify what the customer need is and what exactly the device constraint is; list options (reduce scope, phase it, move something out, ask hardware for an earlier slice); state the decision rule and who decides; say what you would tell product and hardware and when. No claim about your past | A prioritization problem at the F5 seam, set in the role's own terms |
| H-D2 | "How would you decide what the two squads stop doing?" | CASE | [generic] | Criteria before choices: customer commitments, risk, cost of delay, engineers' capacity. Show how you would involve the staff engineers in the cut. No claim about your past | F2's delivery requirement asked as a trade-off, not a record |

### Reverse questions, Thursday

| # | Question | Why it lands |
|---|---|---|
| H-R1 | "What could a new manager do in their first month that would genuinely help your work?" | The reciprocity question for the staff engineers |
| H-R2 | "Where does the roadmap conversation between product and engineering get hardest today?" | For the PM; names the F5 seam without confessing it |
| H-R3 | "Where do the squads depend on hardware timelines, and how does that show up in planning?" | Shows you are already thinking about the seam |
| H-R4 | "What part of how the team hires would you change?" | Gives the staff engineers a voice on F3 |
| H-R5 | "What is the best decision a manager here made in the past year, and what made it good?" | Reads their definition of good management |
| H-R6 | "How is on-call handled, and what would you change about it?" | Lets you reach your reliability story from their side |

## Round 3 — Monday, VP Engineering (30 min, "values and leadership philosophy")

Weights rest on the recruiter's words as you relayed them and the skip-level prior. Values cheat sheet: not built, because no published values were in hand (the search was refused). The VAL questions below use selection scaffolds instead.

| Persona | How it shows up | Weight | Reasoning shown | Counter-move |
|---|---|---|---|---|
| Values/Behavioral | Leadership philosophy, stories | High | The recruiter described the round as values and leadership philosophy | One principle in your own words, one story at its own scope |
| Pressure | Time-boxed "why you" | Medium | Skip-level prior is Strategist plus Pressure; 30 minutes forces compression | Pause, restate, hold, concede specifically |
| Case/Strategist | Altitude and company-level thinking | Medium | Skip-level prior; company strategy was not researched, so CO stays generic | Think at their altitude; say what you would learn first |
| Skeptic | Leading through other leads | Medium | Your own statement about managers puts the question on the table | State the limit, then the plan |
| Conversational | Motivation | Low | Half an hour leaves little room | Short, honest, specific to you |

### A. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| M-A1 | "What is your philosophy of leading engineers?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | State the principle in your own words, in one or two sentences, then one story. If it is the reliability quarter, tell it at the sentence's scope: "I pushed a reliability quarter through against roadmap pressure." The principle is yours to say; do not claim the story proves it | The recruiter named leadership philosophy as the round's subject; F2 is the only story in the material |
| M-A2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection criteria: a named stake, a moment you did not fold, an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A stock values stem; no quoted sentence carries it |
| M-A3 | "Tell me about someone you helped grow, and a time it did not work." | VAL | [generic] | Selection criteria: a person, a specific thing you did, what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4 has no evidence and the role owns growth for 11 engineers |

### B. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| M-B1 | "Sixty seconds: why you, over a manager who has already led a bigger team?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company."; "I run our hiring loop for backend roles — about 40 interviews last year." | Pause, restate. Hold only what the sentences carry: "Three of my nine years have been as a team lead of 6" and "I run our hiring loop for backend roles." Hold through two follow-ups; concede specifically that your team has been one of 6. Do not add scope | F1 and F3 are the only things you can hold; a held position the second follow-up cannot break |
| M-B2 | "That on-call result: how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Use I for what you did and we for context. Slot: say which part of the result was yours, in your own words; if part was not yours, say so plainly and return to "I pushed a reliability quarter through against roadmap pressure." | Attribution is the Pressure persona's favourite probe (F2) |

### C. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| M-C1 | "Two squads, hardware and product all want something different from you this quarter. Where do you spend your time?" | CASE | [generic] | Clarify, state the criteria (customer commitments, risk, cost of delay), say what you would delegate and what you would not, and what you would tell each party. No claim about your past | The altitude version of H-D1; F1 and F5 together |
| M-C2 | "What should engineering leadership at a company like this be worried about over the next two years?" | CO | [generic] | Company strategy was not researched, so assert nothing about Larkfield. Think at the level of the role description's own words ("industrial IoT", "device-management services"): what you would want to learn first and why. No claim about your past | F6; honest generic version of a CO question until research is added |

### D. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| M-D1 | "You haven't managed managers. How do you think about leading through other leads?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Words you may give back: "I've never managed managers." Then a plan, said as a plan: how you would learn it and who you would ask. Do not suggest you have done it | F1's stated negative; the VP is the one person likely to say it aloud |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| M-E1 | "What draws you to leading engineers rather than staying hands-on?" | EXP | [generic] | Your actual reason in your own words, short and specific to you; no borrowed reason | Motivation consistency, asked warmly |

### Reverse questions, Monday

| # | Question | Why it lands |
|---|---|---|
| M-R1 | "What does good leadership of engineers look like here? Can you give me a concrete example from the last year?" | Speaks to the round's stated subject and gets you their philosophy in a story |
| M-R2 | "Where do engineering, hardware and product disagree most at company level, and how does that get resolved at your level?" | Shows altitude; touches F5 |
| M-R3 | "How do you think about the balance between delivery commitments and reliability work?" | Lets you hear their view before telling your quarter |
| M-R4 | "What does a first-year manager here most often underestimate?" | Gets the VP's scoring sheet |
| M-R5 | "How do you develop managers here, and where does a manager at my level go from here?" | F1 and F4 in one question |
| M-R6 | "What would you want to be different after my first twelve months?" | Closes on the outcome they will measure |

## Requirement coverage

| Requirement | Questions |
|---|---|
| F1 Lead two squads | T-A3, T-B1, H-D2, M-B1, M-C1, M-D1 |
| F2 Own delivery | T-C2, T-B2, H-D1, H-D2 |
| F3 Hiring | H-A4, H-B2, M-B1 |
| F4 Growth | M-A3 (none other earns one; reverse questions T-R4, M-R5 carry it) |
| F5 Partner with hardware and product | T-A2, T-B2, H-C2, H-D1, M-C1 |
| F6 Industrial IoT, device-management services | T-D2, M-C2 |
| Headline figure: 60% | T-C1, H-B1, M-B2 |
| Headline figure: about 40 interviews | H-B2 |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | Negative you stated, F1 | The plain acknowledgment you gave: "I've never managed managers." No slot |
| Has owned a hardware-adjacent roadmap | Negative you stated, F5 | "I've never owned a hardware-adjacent roadmap." No slot |
| Has led two squads or an organization of 11 | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says a team lead of 6 |
| Owned delivery for the team | Inflated form of F2 | F2's quote at its own scope. The pack's observation: your material says you pushed a reliability quarter through, not that you held the delivery commitments |
| Owned hiring decisions or ran 40 interviews yourself | Inflated form of F3 | F3's quote at its own scope: you run the hiring loop for backend roles. The pack's observation: the figure's counting is not in your material |

## Sources

Provided documents: your message, containing the role description (quoted in F1 to F6), the three-round schedule and who runs each round, your background statements (quoted in the fit snapshot), and the recruiter's description of the VP round as you relayed it. These establish the loop, so no archetype fallback applies, and they document a values-style round for Monday. No dossier was consumed.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

Searches sent, each refused (nothing returned):

1. "Larkfield Systems industrial IoT company values" — refused
2. "Larkfield Systems interview process engineering manager" — refused
3. "Larkfield Systems industrial IoT device management strategy news" — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Would have moved: a values cheat sheet for Monday and the VAL stories mapped to published value names. Monday's VAL questions are scaffolds |
| 2. `{company} interview process {role family}` | unavailable | Would have moved: confirming round formats, any case or presentation. Persona weights rest on your description and the relationship priors |
| 3. `{company} strategy` / recent news | unavailable | Would have moved: CO and CASE questions grounded in current strategy. M-C2 and the reverse questions are generic |
| 4. `{interviewer name} {company}` | n/a | No interviewer name was given, so there was no query to form; no interviewer read, and the reverse questions are role-generic |
| 5. representative `{role title}` JD | skipped | The role description you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV or the bullets for your current role → F1 to F5 evidence cells become inspected quotes, and rows may move from `discovery` or `transferability` toward `none`
- Your answers to the answer slots in F1, F2, F4, F5 and F6 → those rows regenerate with your own words, and T-A2, H-C2 and M-A3 gain a story
- Interviewers' names (the Director, the two staff engineers, the PM, the VP) → an interviewer read, tuned persona weights, and reverse questions tied to each person's own path
- What the recruiter said about the panel's focus, or any exercise or presentation to bring → coverage of anything announced
- Larkfield's published values or careers page, pasted or searchable → a values cheat sheet for Monday and mapped VAL stories
- Deeper research, offered once: up to 6 more searches and 2 more fetches, several more minutes, needs search permission → CO and CASE questions grounded in the company's current strategy
- Hours you can spend before each round → a prep triage
- A tuesday-dossier.md, if you have one → verified evidence and ready-made prohibited claims; the pack is complete without it
