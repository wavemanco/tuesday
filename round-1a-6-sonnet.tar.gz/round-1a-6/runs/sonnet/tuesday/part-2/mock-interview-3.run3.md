I'll read the playbook's reference files before building the pack.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a6/runs/sonnet/tuesday/part-2/rooms/case-3-denied-81341a81/stripe_product-operations-manager_interview_pack.md`.

I built it for a final round with flat persona weights and no job description or CV. Web search was refused in this session, so the pack states nothing about Stripe's values, interview loop or strategy. It has 20 questions, and every row is labeled generic. It also has six reverse questions and an upgrade menu showing what each missing input would add.

Say the word and I'll play the Skeptic on B1, the pack's placeholder for your highest-ROI prep. A CV would replace it with your actual likeliest objection.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Who are you meeting in the final round, and in what relationship to the role (future manager, peer, skip-level, cross-functional)? Did the recruiter give you focus areas, a deliverable or a schedule? The answers would reweight every bank.
2. Can you paste the job description and your CV, or a few lines about your background? Without them I'll keep the pack as it is, but the fit snapshot stays a worksheet and the answer guidance stays scaffolding.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Interview pack: Product Operations Manager, Stripe

**Round:** final round, relationship to interviewers not given. Session mode, with blended persona weights.
**Interviewer(s):** not given.
**Built from:** your message only. No job description, no CV, no research (web search was refused in this session). Every row below is therefore `[generic]`, and nothing in this pack states a fact about Stripe, its values, its loop or its strategy.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. The guidance in each row is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Whether past behavior shows a value, not generic virtue |
| EXP | Whether your experience survives scrutiny; what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you have done your homework on the company and can think at its altitude |
| CASE | Structure and reasoning on a live problem |

Because no CV was given, no row below says anything about your past. Where a question asks for a story, the guidance tells you how to choose one, and every selection ends with an honest branch for when none comes to mind.

## Fit snapshot (worksheet)

No job description was supplied, so the requirements are role-family expectations written as plain prose, not quotes from a posting. No CV was supplied, so every evidence cell is empty. None of these rows is a gate: nothing here establishes work authorization, location or schedule, because no posting or message stated any term.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinate product launches or releases across several teams (role-family expectation, no JD supplied) | none given | none | [generic] | discovery | Strong evidence here is a launch or release you can name, with the teams involved and what part was yours. Selection scaffold: pick one with a named date, named teams and a decision you personally made; if no such launch comes to mind, say so plainly, then give the nearest coordination work your material does carry, or how you would run one |
| F2 | Define, track and report product or operational metrics (role-family expectation, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a metric you can explain end to end: its definition, how it was counted and who used it. Selection scaffold: pick one you could defend to a skeptical analyst; if none comes to mind, say so plainly, then say how you would set up the first version of one |
| F3 | Build or improve recurring processes and operating cadences (role-family expectation, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a process you changed, with what it was before, what you changed and what you saw afterwards. Selection scaffold: pick one where you can separate your change from the team's; if none comes to mind, say so plainly, then describe how you would approach one |
| F4 | Work with engineering, product and go-to-market partners (role-family expectation, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a working relationship across a team boundary, with a disagreement and how it resolved. Selection scaffold: pick one where the other side would describe it the way you do; if none comes to mind, say so plainly, then say how you would build such a relationship in your first weeks |
| F5 | Prioritize among competing requests under ambiguity (role-family expectation, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a time you said no or sequenced requests, with your criteria. Selection scaffold: pick one with a real cost to someone; if none comes to mind, say so plainly, then give the criteria you would use |
| F6 | Use data and tooling to run operations (role-family expectation, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a named tool or analysis you used yourself. Selection scaffold: pick the one you can describe at the level of the steps you took; if none comes to mind, say so plainly, then say what you would want to learn first |

## Requirement coverage

| Requirement | Question IDs | Note |
|---|---|---|
| F1 launch coordination | A1, A5 | |
| F2 metrics | A2, E1, E2 | |
| F3 processes and cadences | A3 | |
| F4 partners | C1, C2, C3, D1 | |
| F5 prioritization | A4, B2 | |
| F6 data and tooling | E2 | none beyond E2: tooling named in a real JD would earn more, and no JD was supplied |

## Persona table

The relationship to your interviewers is unknown, and no loop source was read, so the fallback archetype is Generic: flat starting weights, adjusted below by the relationship priors for the kinds of sessions a final round commonly holds. The weights rest on that pattern and not on any documented Stripe process. Send the schedule and they will change.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | Live problems from the role: plan this, diagnose that | Highest. The hiring-manager prior is Case plus Skeptic and the skip-level prior is Case plus Pressure; Case appears in both. 5 questions | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| B. Skeptic | Probes motivation and the weakest part of the fit | High. It is the other half of the hiring-manager prior. 4 questions | Rehearse the likeliest objection until it is boring; calibrated candor over bluffing |
| C. Peer Evaluator | Seam-splitting, credit, "what would you need from me" | Medium. A final round commonly includes a peer or cross-functional session, but none is confirmed. 3 questions | Reciprocity framing; propose seam principles, not a map you do not have |
| D. Values / Behavioral | Scenario probes on how you behaved | Lower. No values-style round was detected, since no loop source was read. 2 questions | Choose stories where the hard truth actually landed; "we" for context, "I" for contribution |
| E. Data-Driven Prober | Goes two levels deep on any number | Lower. Product operations work is metric-heavy, but the probing needs a CV to aim at. 2 questions | Know how your numbers were counted; say plainly when you do not know |
| F. Pressure | Interrupts, time-boxes, questions motive | Lower. It is a skip-level prior only. 2 questions | Pause, restate, anchor in what you actually did; hold through two follow-ups, then concede specifically |
| G. Conversational | Friendly, unstructured, still scored | Lower, but it arrives in every session as the opener. 2 questions | A 90-second arc for the biography question; treat casual questions as scored |

## Question banks

Every row is `[generic]` and makes no claim about your past, so no candidate sentence appears in any Provenance cell. The highest-ROI rehearsal in this pack is B1, and that choice is provisional: the likeliest objection to you cannot be identified without your background, so B1 is the placeholder that a CV would replace.

### A. Case / Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A product is two weeks from launch, and engineering, support and go-to-market each say they are not ready. What do you do first, and what do you need to know?" | CASE | [generic] | Ask what "ready" means and who decides, and what is fixed (date, scope). State the objective. Split the gaps by risk and by whether they can be reversed after launch. Propose an approach and the check you would run at each step. Name the risk of the plan itself. Challenge one premise: is the date movable | Live problem in the role family (F1); CASE because it scores structure, not the right answer |
| A2 | "A metric your team reports weekly dropped 20%. Diagnose it." | CASE | [generic] | Clarify first: did the definition or the measurement change, and over what window. Then segment by time, cohort and release, form two or three hypotheses, say what data would confirm each, and who you would involve. Think aloud | Stem from the Case persona; covers F2 |
| A3 | "Sketch the plan for a regular cross-team review of launches. What do you need to know first?" | CASE | [generic] | Clarify who attends and which decisions the forum makes. Objective, then design: inputs, owners, cadence, outputs. Say how you would know it works, and name the risk that it becomes a status meeting. Challenge the premise: does it need to exist | Covers F3 as a design problem and presupposes nothing about your past |
| A4 | "Three teams each want your help this quarter and you can take one. How do you choose?" | CASE | [generic] | Name your criteria before the choice, ask what each team loses if you say no, and say who you would involve in the decision. Say how you would tell the two teams you declined | Covers F5; the role's scarce resource is its own time |
| A5 | "Why Stripe, and why this role now?" | CO | [generic] | Give your own reasons in your own words, and make each one something you can defend to a follow-up. This pack could not research current company priorities, so read the company's own published material before the interview and use what you find. If no clear reason comes to mind, say so plainly, then say what draws you to the problem the role works on | Asked in nearly every final round, as CO; weighted here because it is a homework signal |

### B. Skeptic (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | The highest-ROI rehearsal, as a placeholder. Name one real gap in a sentence, then give a concrete ramp plan for it, said as a plan and never as a past. Hold through two follow-ups by returning to the plan. If no gap comes to mind, say so plainly, then say what you would want to learn first | Aimed at the biggest gap, which a CV would identify; JD because it scores fit to the job |
| B2 | "Tell me about an area of this role that is new to you and how you would get up to speed." | JD | [generic] | Pick an area where your honest starting point is clear and your plan is specific: who you would ask, what you would read, what you would build first. If nothing is new to you, say so plainly, then say where you expect the steepest learning | A softer second pass at the gap; covers F5 |
| B3 | "Why are you leaving your current role, and why now?" | EXP | [generic] | Give your actual reason, forward-looking and consistent with what you told the recruiter. Do not criticize anyone. If asked again, repeat the same reason in the same terms | Motivation consistency is the core Skeptic score |
| B4 | "What from your current context would you have to unlearn here?" | EXP | [generic] | Choose one habit that is a strength where you are and a risk here, and say how you would watch for it. If none comes to mind, say so plainly, then say how you would find out | Probes honest self-assessment and the background mismatch |

### C. Peer Evaluator (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | JD | [generic] | Do not pretend to know the seam. Offer principles: who owns the decision, how a disagreement is escalated, what is written down. Ask how they currently handle it | Peer prior; covers F4 |
| C2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Pick a story where credit was shared and the sharing was specific: who did what. If none comes to mind, say so plainly, then say how you would do it | Credit-sharing probe from the Peer persona |
| C3 | "What would you need from me in your first month?" | JD | [generic] | Offer reciprocity first: what you would bring their team. Then two or three concrete asks, such as context and introductions | Reciprocity framing |

### D. Values / Behavioral (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Choose a story with a named stake, a moment you did not soften it, and a relationship that was intact at the end. Use "we" for context and "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Stem from the Values persona |
| D2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Choose a story where the metric and the customer pointed different ways, and say what you gave up. If none comes to mind, say so plainly, then say how you would weigh the two | Stem from the Values persona; this pack could not read the company's published values |

### E. Data-Driven Prober (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Pick a number you reported. Walk me through how it was counted, and which assumption behind it you would defend least." | EXP | [generic] | Choose a figure you can explain from the raw data up. Say how it was counted, what it is sensitive to, the assumption you would defend least, and exactly what part was yours. If you do not know how a figure was counted, say so plainly | The defend-the-number rehearsal, with the weakest-assumption move |
| E2 | "If you were handed our weekly launch dashboard tomorrow, how would you check that it was trustworthy?" | CASE | [generic] | Walk through definitions, sources, freshness and known edge cases, in that order, and say what you would ask the owner. Name one check you would run first | Covers F6 as a live problem |

### F. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, restate the question, and give two reasons you can back with things you have actually done. Hold through two follow-ups, then concede one specific limit rather than folding on the core claim | Stem from the Pressure persona; hold-then-concede |
| F2 | "Pick a result you are proud of. How much of it was actually you?" | EXP | [generic] | Choose a result where you can separate your part from the team's. Say what was yours, what was others', and what you do not know. If it was mostly the team's, say so plainly | Attribution probe; the honest answer is the rehearsal |

### G. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc in your own words: where you started, the thread that connects your moves, and why this role is the next step. Practice it aloud until it fits | The opener in most sessions, and scored |
| G2 | "What are you experimenting with lately in how you work?" | JD | [generic] | Name one real thing and what you have noticed. If nothing comes to mind, say so plainly, then say what you would like to try | Casual question that reads as curiosity and initiative |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does success look like for this role at 90 days and at one year?" | Shows you are scoping outcomes, and the answer tells you what the role is scored on |
| R2 | "Which team relationships does this role depend on most, and where is the seam roughest today?" | Signals you already think in terms of partners and handoffs |
| R3 | "What is a recent launch or process the team is proud of, and what would you change about how it ran?" | Invites a candid story and shows you want the real picture |
| R4 | "How does the team decide what product operations works on, and what it declines?" | Connects directly to prioritization, which a final round scores |
| R5 | "What makes someone struggle in this role?" | Shows self-awareness and gives you a real risk to weigh |
| R6 | "What does the rest of the process look like from here, and who else will I meet?" | Practical, and it lets you prepare for the next session |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| No entries | No candidate sentence exists to widen, and no negative was stated | Every claim about your past that you rehearse must come from your own experience. This pack supplies none |

## Sources

Provided: your message (company, role, final round).

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Search refused. Would have moved: the values cheat sheet and VAL questions by published value name |
| 2. Stripe interview process, product operations | unavailable | Search refused. Would have moved: loop structure and persona weights; the Generic fallback stands in |
| 3. Stripe strategy and recent news | unavailable | Search refused. Would have moved: CO and CASE questions grounded in current strategy |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form |
| 5. Representative Product Operations Manager JD | unavailable | Search refused. Would have moved: the fit snapshot requirements, from role-family prose to `[inferred]` quoted rows |

Queries sent, all refused: "Stripe operating principles values"; "Stripe interview process product operations"; "Stripe strategy news 2026"; "Product Operations Manager job description Stripe".

## Upgrade menu

- Job description text → the six `[generic]` requirement rows become quoted `[grounded]` rows, and each requirement gets a JD question
- CV or a few lines about your background → the worksheet becomes a real fit snapshot, B1 gets replaced by your actual likeliest objection, and the story scaffolds become story maps
- Round and interviewer details (names, roles, relationship to you) → persona weights read from them, an interviewer read, and a reverse question tied to their path
- If your final is several sessions, send the schedule → per-session mini-packs with their own persona weights
- Recruiter's prep email → coverage of any announced focus areas or deliverables
- Web search permission → published values and the values cheat sheet, documented loop structure, and a strategy sweep. A deeper pass (up to 6 more searches and 2 more fetches, several more minutes) can follow
- A `tuesday-dossier.md` from earlier work → verified evidence and absolute prohibited claims to build on
