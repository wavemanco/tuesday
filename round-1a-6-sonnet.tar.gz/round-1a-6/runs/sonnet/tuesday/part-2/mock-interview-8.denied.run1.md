Fixing a stray sibling-skill mention in the pack file, then checking its formatting.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a6/runs/sonnet/tuesday/part-2/rooms/case-8-denied-40ee9a8e/ashgrove-credit-union_member-experience-lead_interview_pack.md`. I built it as a three-round pack for 5 December. The interviewers aren't named yet, so the question styles rest on the round types and the recruiter's own words. It covers all three rounds, the eight JD requirements, and Ashgrove's four values. The values cheat sheet sits with the panel round. I didn't run any web research, because the JD, values, recruiter email and strategy points you pasted already covered what it would have.

The pack names one highest-ROI prep item: the contact-centre objection. The role owns complaints across branches and the contact centre, and your message says you've never worked in one. Rows B1, D1 and I2 rehearse it, and D1 (in round 2, with your future manager) goes deepest. Your other stated gap, presenting above regional level, is rehearsed in D2.

Where your material doesn't say enough, the pack leaves an answer slot for you to fill in your own words, not a suggested answer. It won't coach you to claim anything beyond your own sentences, such as running the complaints process end to end, coaching supervisors, or regulated complaints. Those limits are listed in the "Prohibited claims" section.

Say the word and I'll run a live drill. I'd play the Skeptic on D1, the contact-centre question. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Prepared 26 November 2026 for the three rounds on 5 December 2026. Loop mode: one shared fit snapshot and sources block, then a mini-pack per round.

| Round | Who | Length | Format, from the recruiter's email |
|---|---|---|---|
| 1 | The recruiter | 30 minutes | Screen |
| 2 | The Head of Member Services, who would be your manager | 45 minutes | Mostly behavioural |
| 3 | Panel of two branch managers | 60 minutes | Includes a 20-minute case on a complaint escalation; also the values round, scored against the four values |

Interviewer names are not assigned beyond these roles, so there is no interviewer read; persona weights rest on the round types and the recruiter's own words.

## How to use this pack

Personas are how a question arrives; types are what it scores. Guidance is scaffolding, not a script: the only sentences about your past are your own, quoted. Where the pack cannot know something, it gives you an answer slot, an instruction for the interview that you answer from your own experience or by saying plainly that it was not yours.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the published values |
| EXP | Whether your background survives scrutiny; what was actually you |
| JD | The stated responsibilities and requirements, gaps included |
| CO | Knowledge of Ashgrove and its strategy |
| CASE | A live problem, scored on structure and reasoning |

**Highest-ROI prep: the contact-centre objection.** The role owns the complaints process across branches and the contact centre, and your own message says you have not worked in one. It will be asked in some form in every round. Rows B1, D1 and I2 rehearse it; D1 is the deepest.

## Prep triage

Nine days remain, 26 November to 5 December. In this order:

1. Write your own answers to the answer slots in F1, F3, F4, F5, F7 and F9, in your own words. No row can do this for you, and anything you add outside a drill can sharpen the pack.
2. Say D1 aloud until the plain statement of the gap is boring, then B1 and I2, which use the same words.
3. Say D2 aloud with the same discipline, then the plan half of it.
4. Round 3: one story attempt per value (F1 to F4), then G1 aloud against a 20-minute timer.
5. Round 1 logistics, A2 to A5: write your actual answers on one page.

Everything else is insurance.

## Fit snapshot

Requirements are quoted from the JD you supplied. Evidence is your own words from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD (the branches part) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says one branch's log, not the process end to end, with nothing inspected behind it, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what came after an entry reached the log likely. If any later step was yours, say which and what you decided, in your own words; if the log was where your part stopped, or there was no such step, say so plainly and stay with the log |
| F2 | "Own the member complaints process end to end across branches and the contact centre" — JD (the contact centre part) | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan in your own words and never as a past. Nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your sentence says monthly, and that your regional manager uses it; it does not say what the spreadsheet counted. Answer slot: the JD names volumes and resolution times, so expect a probe on what yours showed. If it counted volumes or how long complaints took to resolve, say so in your own words; if it showed other things, or neither, say so plainly and describe what it did show |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says new tellers and a script, not supervisors, and the words stay there: "I trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on whether any of your training reached other supervisors likely. If it did, say who and what you covered, in your own words; if it was tellers only, or there was no such coaching, say so plainly and stay with the tellers |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Nothing in your material touches this, and you have not said you lack it. Answer slot: if you have worked with a digital team or on a self-service journey in any form, say what it was and what part was yours, in your own words; if not, say so plainly, and say what you would want to learn first about how members use self-service |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe on it. Lead with the years and role in the sentence's own terms, six years in retail banking and the last three as a branch supervisor, rather than borrowing the JD's phrase for your history |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | Your sentence says formal complaints, not regulated ones, and the words stay at "I handled the branch's formal complaints log." Answer slot: the JD's regulated line makes a probe on which rules governed those complaints likely. If a regulator's rules applied to what you logged, say which and what they required of you, in your own words; if you do not know, or that was not part of what you did, say so plainly and stay with the log |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Your sentence does not say what you presented below that level, so nothing is built on it. Then how you would prepare for senior audiences, said as a plan in your own words and never as a past |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your sentence says spreadsheet, not Excel, and the words stay at "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if you built it in Excel, say what it did, in your own words; if it was another tool, say so plainly and say how comfortable you are with Excel today |

No requirement in the JD is a gate in the suite's sense: the years requirement is experience length and stays graded on fit, and the JD states no licence, location, schedule or pay term.

## Requirement coverage

| Requirement | Questions that cover it |
|---|---|
| Own the complaints process end to end, branches | G1, G2 (CASE); H1 (JD); F4 (VAL) |
| Own the complaints process end to end, contact centre | B1, D1 (JD); I2 (EXP); G2 (CASE) |
| Report monthly on volumes and resolution times | C4 (JD) |
| Coach branch supervisors on escalations | C2, H1 (JD) |
| Work with digital teams on self-service journeys | C3 (JD); E1 (CO) |
| 4+ years in financial-services customer operations | B3 (JD); A1 (EXP) |
| Experience handling regulated complaints | B2 (JD); D3 (EXP) |
| Confident presenting to senior leaders | D2 (JD); C1 (VAL) |
| Comfortable with Excel reporting | B4 (JD) |
| The four published values | F1, F2, F3, F4 |
| Pay, notice, location, reason for leaving | A5, A3, A4, A2 |

## Grounding brief: Ashgrove's 2026 strategy

From the July 2026 strategy brief the recruiter sent you, as you summarised it. The brief itself was not in front of this pack, so only these four points are used.

| Item | What the brief says | Provenance | Where it surfaces |
|---|---|---|---|
| Digital shift | Move 40% of member service to digital channels by 2028 | [grounded] | E1; the self-service requirement in F5 |
| Branch network | Consolidate eight branches into five hubs over 2027 | [grounded] | H2; the panel is made of branch managers |
| New product | Launch a small-business lending product in Q1 2027 | [grounded] | E2 |
| Competition | The main competitive pressure is app-only banks | [grounded] | E1 |

---

# Round 1: the recruiter (30 minutes)

## Persona weights

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly, unstructured; logistics asked in a casual register | High. The recruiter-screen prior is Conversational plus a light Skeptic, and the recruiter's own words, "30 minutes with me", point to a screen | A pre-scripted 90-second arc for the journey question; treat every casual question as scored |
| Skeptic | Knockout checks in a friendly register | Light in tone, but the JD's requirements each need a row | Say the stated gaps plainly and early; bridges only from your own sentences |

## Question bank

### A: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped in three beats, each a clause the sentences state, in your own words: six years in retail banking with the last three as a branch supervisor; handling the branch's formal complaints log and training new tellers on the escalation script; building the monthly complaints spreadsheet your regional manager uses. Why this role is your own words, and nothing here supplies it. About ninety seconds | The biography question opens most screens, and F6, F1 and F3 are the rows it draws on. EXP because it tests what you say you did |
| A2 | "What's prompting you to look at a move now?" | EXP | [generic] | Logistics slot: give your own reason, in your own words; nothing here supplies one. If it connects to one of Ashgrove's published values, name which, only if that is true | The reason for leaving is one of the four recruiter-screen logistics rows; EXP because it tests motivation consistency |
| A3 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period, in your own words | A recruiter-screen logistics row; JD because it concerns the listed job's terms |
| A4 | "Where are you based, and is there anything about where or how often you'd be working that we should know?" | JD | [generic] | Logistics slot: state where you can work and how often, as it stands today, in your own words | A recruiter-screen logistics row; JD because it concerns the listed job's terms |
| A5 | "What are you looking for in terms of salary?" | JD | [generic] | Logistics slot, a choice between named options that supplies no figure: give your own number, or ask for the role's band first. If asked what you earn now: "I'd rather focus on the range for this role" | A recruiter-screen logistics row; JD because pay is the listed job's term |

### B: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never worked in a contact centre, and this role owns the complaints process there too. How would you handle that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Part of the highest-ROI rehearsal. Plain statement first, from your own sentence: "I haven't worked in a contact centre." Then a plan in your own words for how you would learn the contact centre's complaints handling: a plan, never a past. Limit named before it is asked for: no sentence of yours carries contact-centre work, so none in this answer bridges to it | F2 is the gap the whole role turns on, and a recruiter checks it first. JD because it scores the stated scope |
| B2 | "The role needs experience handling regulated complaints. What have you handled?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Open with the sentence at its own scope: "I handled the branch's formal complaints log." Answer slot: the JD's regulated line makes a probe on which rules governed those complaints likely. If a regulator's rules applied to what you logged, say which and what they required of you; if you do not know, or that was not part of what you did, say so plainly and stay with the log | F7 is the likeliest knockout check after the contact centre. JD because it scores a stated requirement |
| B3 | "This role needs four or more years in financial-services customer operations. How does your background line up?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Say it at its own scope: six years in retail banking, the last three as a branch supervisor. Use the sentence's words for your history rather than the JD's phrase. Give the years the sentence gives | F6 is the one clean row, and a recruiter confirms it early. JD because it scores a stated requirement |
| B4 | "The role involves regular reporting in Excel. How comfortable are you with that?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Start from the sentence: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if it was built in Excel, say so and what it did; if it was another tool, say so plainly and say how comfortable you are with Excel today | F9 is a mid-list requirement that a screen ticks off quickly. JD because it scores a stated requirement |

## Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| R1.1 | "How many branch supervisors would this role coach, and across how many branches?" | Gets the scope of the coaching line and shows you read it |
| R1.2 | "How does a complaint move between a branch and the contact centre today, as far as you can share?" | Goes to the role's core and gives you the shape of the gap you will be asked about |
| R1.3 | "Is the case in the panel round given on the day, or shared in advance?" | A practical question that shapes your prep for G1 to G3 |
| R1.4 | "How does the panel use the four values when scoring?" | Shows you have read the values by name and tells you how to prepare stories |
| R1.5 | "What happens after the 5 December rounds, and when would you expect to decide?" | A normal close that shows you are planning |

---

# Round 2: Head of Member Services (45 minutes)

## Persona weights

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scenario prompts, STAR-shaped stories | High. The hiring-manager prior is Case plus Skeptic, but the recruiter called this round "mostly behavioural", so Values moves to the top | Map a story to each prompt where your own sentence carries one; where none does, use the selection scaffold and its honest branch |
| Skeptic | Quiet probing of the gaps | Mid. A manager is buying capability and derisking gaps, and your message states two | Rehearse the contact-centre objection until it is boring; calibrated candour over bluffing |
| Case / Strategist | Live problems from the roadmap | Low. The hiring-manager prior says Case, but "mostly behavioural" cuts it to two rows | Clarify, objective, segmentation, approach, metrics, risks; think aloud |

## Question bank

### C: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something they did not want to hear. It needs a named stake, what you actually said, and what happened to the relationship afterwards. If no such time comes to mind, say so plainly, then give how you would handle it | A standard behavioural prompt from the persona stems, and it leans on the senior-audience gap in F8. VAL because it scores behaviour, not capability |
| C2 | "Tell me about a time you coached someone through a difficult escalation." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F4 at its own scope: "I trained new tellers on our escalation script." Answer slot: a probe on what a difficult escalation looked like in that training is likely. If any teller you trained met a real escalation afterwards and you helped, say what happened and what part was yours; if the training was the whole of it, say so plainly and stay with the training | The JD's coaching line is raised by this prompt, and F4 is the thin bridge. JD because it scores the listed responsibility |
| C3 | "Tell me about a time you worked with a team outside your own area to fix something for members." | JD | [grounded] | Selection scaffold, since no sentence of yours covers this: pick a time with a named other team, what each side needed from the other, and what changed for members. If no such time comes to mind, say so plainly, then say how you would work with a digital team on a self-service journey | F5 is a silence in the material, and the JD's digital line is the raising source. JD because it scores a stated responsibility, delivered as a behavioural prompt |
| C4 | "Walk me through the monthly complaints spreadsheet your regional manager uses." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F3 with the beats the sentence states: you built it, it is monthly, your regional manager uses it. Answer slot: the JD names volumes and resolution times, so expect a probe on what it counted. If it counted either, say so in your own words; if it showed other things, or neither, say so plainly. If asked what it was built in, give the tool you used | F3 and F9 are the reporting evidence, and a manager who reads reports will go straight here. JD because it scores the reporting requirement, delivered as EXP |

### D: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The deepest rehearsal in the pack. Plain statement: "I haven't worked in a contact centre." Hold it through two follow-ups by repeating it, not softening it; concede that this is where you start behind, and do not fold on the rest, which stays at "I handled the branch's formal complaints log." Expect a second probe on your first month and a third on earning the contact-centre team's trust; answer both as plans in your own words. Limit named first: no sentence of yours carries contact-centre work | F2 is the objection that will be asked in some form, and this round is where your future manager asks it. JD because it scores the stated scope |
| D2 | "You've never presented to anyone above regional level, and this role presents to senior leaders. What changes for you?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain statement from your own sentence: "I've never presented to anyone above regional level." Then how you would prepare, said as a plan in your own words and never as a past. Concede that the audience is new, and do not claim anything about the level below | F8 is the second stated gap. JD because it scores the stated requirement |
| D3 | "You said formal complaints. What made a complaint formal in your branch?" | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Answer slot: if a rule, policy or threshold decided what went in the log, say what it was in your own words; if you did not set it and do not know its source, or there was no such test, say so plainly and stay with "I handled the branch's formal complaints log." | F7 is where a manager tests whether the log was regulated work. EXP because it checks what you actually did |

### E: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Ashgrove wants 40% of member service on digital channels by 2028. Which complaints would you keep with a person first, and what would you need to know before deciding?" | CO | [grounded] | Clarify before structuring: who the members are, what the 40% covers, what a complaint costs a member when it goes wrong. Then objective, segmentation, approach, metrics, risks, aloud. The brief names app-only banks as the main competitive pressure; say how your answer holds up against that frame. Challenge one premise respectfully. The question asks about no past, so the guidance makes no claim | The brief's headline target meets the JD's self-service line (F5). CO because it scores whether you think at Ashgrove's altitude |
| E2 | "A small-business lending product launches in Q1 2027. What would you want ready in the complaints process before it does?" | CASE | [grounded] | Clarify who the new members are and what a complaint on this product could look like. Then who owns it, how it is reported, and how a member is told in plain words. The question asks about no past, so the guidance makes no claim | The brief's new product is a complaints category that does not exist yet. CASE because it is a live problem set in the role |

## Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| R2.1 | "What would a good first ninety days look like for this role?" | Shows you are planning the ramp, which is the honest answer to the contact-centre gap |
| R2.2 | "Where does the complaints process work well today, and where do members feel it break?" | Asks for the real picture rather than the brochure |
| R2.3 | "How does the 40% digital target change what the complaints process needs by 2028?" | Ties the role to the brief and shows you read it |
| R2.4 | "Who in the contact centre would you want me to learn the process from first?" | Turns the gap into a plan you are already acting on |
| R2.5 | "How do the monthly complaint figures reach senior leaders today, and in what form?" | Surfaces the presenting expectation before you are asked about it |

---

# Round 3: the panel of two branch managers (60 minutes)

## Persona weights

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | One prompt per published value | Top. The recruiter said "the panel is also the values round — they score against the four values" | A story per value where a sentence of yours carries one; the scaffold and its honest branch where none does |
| Case / Strategist | The 20-minute escalation case | Mid. Twenty of sixty minutes, from the recruiter's "20-minute case on a complaint escalation" | Clarify first, then structure, aloud; use Ashgrove's own words where they fit |
| Peer Evaluator | "What would you need from us" | Low-mid. Branch managers sit on the seam between branches and member services | Reciprocity: what you bring them, and seam principles rather than pretending to know the seam |
| Pressure | Time-boxing, motive questions | Low. A hedge for a panel, with names unknown so weights stay flat across the two members | Pause, restate, hold the position through two follow-ups, concede only what is true |

## Question bank

### F: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Members First, Always: we decide from the member's side of the counter. Tell me about a time you decided something from the member's side." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold, since no sentence of yours describes a decision: pick a time with a named member situation, a decision you made, and what it cost internally. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I handled the branch's formal complaints log.", or how you would handle it | The first of four published values, from the page you pasted. VAL because it scores behaviour against the value |
| F2 | "Plain Words: if a member needs it explained twice, we wrote it wrong. Tell me about a time you made something clearer for a member or a colleague." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Nearest sentence, at its scope: "I trained new tellers on our escalation script." Answer slot: if you reworded anything in the script or how it was explained, say what and what changed; if you did not, or there was no such step, say so plainly and stay with the training. Otherwise use the scaffold: a named person, what was unclear, what you changed, what happened | F4's sentence is the closest material to a written script, and the value's wording is the raising source. VAL because it scores behaviour against the value |
| F3 | "Neighbours, Not Numbers: every branch is part of its town. Tell me about a time you weighed a number against the people your branch served." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Selection scaffold: the sentence gives the setting only, six years in retail banking and the last three as a branch supervisor, not the story. Pick a time with a named number, a named group of people, and what you did. If no such time comes to mind, say so plainly, then say how you would weigh it | The panel is made of branch managers and the brief consolidates eight branches into five hubs, so this value will be heard against that backdrop. VAL because it scores behaviour against the value |
| F4 | "Own the Fix: whoever finds the problem keeps hold of it until it is solved. Tell me about a time you kept hold of a problem until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped at the sentence's scope: "I handled the branch's formal complaints log." Answer slot: if you kept hold of a complaint through to a fix, say which stage you held and what ended it; if the log was where your part stopped, or the fix was someone else's, say so plainly and stay with the log | The value's wording raises the probe, and F1 is the only row near it. VAL because it scores behaviour against the value |

### G: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Here is a complaint that has been escalated from a branch. Talk us through how you would handle it." | CASE | [grounded] | The case itself is unseen, so this is structure only. Clarify first: what the member has been told, what has been tried, who holds it now, what rules or time limits apply. Then objective, owner, approach, what you would record and report, risks. Think aloud and challenge one premise. The question asks about no past, so the guidance makes no claim | The recruiter announced a 20-minute case on a complaint escalation. CASE because it is a live problem set in the role |
| G2 | "The branch says the contact centre should own it, and the contact centre says the branch should. Who owns it, and how do you decide?" | CASE | [grounded] | Decide an owner and say why. Ashgrove's own words fit: "whoever finds the problem keeps hold of it until it is solved." Then the seam as principles, not a claimed process. Concede what you would need to check about the contact centre side, in your own words. The question asks about no past, so the guidance makes no claim | The JD's end-to-end line and the Own the Fix value meet here, and it presses the contact-centre gap through F2 without asking about your past. CASE because it is a live problem |
| G3 | "Say the first two sentences you would give the member once you have decided." | CASE | [grounded] | Short, concrete and plain: what has been decided and what happens next, without a term the member would need explained twice. The question asks about no past, so the guidance makes no claim | The Plain Words value turned into a live test. CASE because it scores execution within the case |

### H: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "You'd coach our branch supervisors on escalations. What would you need from branch managers, and what would we get from you?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Reciprocity first: what you bring to a branch, then what you need. Offer seam principles, not a claimed process. A fact you can state is "the last 3 as a branch supervisor"; what that was like is yours to describe in your own words | The coaching line in F4, asked by the people whose supervisors it covers. JD because it scores the listed responsibility |
| H2 | "Eight branches are becoming five hubs over 2027. How should complaints work for members during that change?" | CO | [grounded] | Clarify what changes for members first. Then principles: no member left without an owner, plain explanation of where to go. Tie to Neighbours, Not Numbers: every branch is part of its town. The question asks about no past, so the guidance makes no claim | The brief's consolidation sits against the published value, and the panel is branch managers. CO because it scores strategy fluency |

### I: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "That complaints log. How much of it was actually you?" | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Hold the sentence: "I handled the branch's formal complaints log." Hold through two follow-ups by returning to the sentence, never by adding to it. Answer slot: if anyone shared the log with you or any part was not yours, say so plainly; if it was yours, say it again in the same words | F1 and F7 both rest on this sentence, so this is where attribution gets tested. EXP because it checks what was actually yours |
| I2 | "Sixty seconds: why you over someone who has worked in a contact centre?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "Never worked in a contact centre, and I've never presented to anyone above regional level." | Hold-then-concede. Concede first, in your own words: "I haven't worked in a contact centre." Hold on what your sentence carries: six years in retail banking, the last three as a branch supervisor. Reasons beyond that are yours; nothing here supplies one. Do not fold on the core claim to restore harmony | The same objection as B1 and D1, in its most time-boxed form (F2). EXP because it tests honest self-assessment under pressure |

## Values cheat sheet

Official names and wording from the page you pasted, copied on 26 November 2026 from ashgrovecu.org/about/values.

| Value | Working meaning | Mapped story or scaffold |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." The sentence shows handling, not a decision, so the story is a scaffold ending in its honest branch: say plainly if no such time comes to mind |
| Plain Words | If a member needs it explained twice, the wording was wrong | F4: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Use the training at its own scope; any rewording is the answer slot in F2 |
| Neighbours, Not Numbers | Every branch is part of its town | F6: "6 years in retail banking, the last 3 as a branch supervisor." It gives the setting only; the story is a scaffold ending in its honest branch |
| Own the Fix | Whoever finds a problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Use "I handled the branch's formal complaints log" at its own scope; how far you held a complaint is the answer slot in F4 |

## Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| R3.1 | "Which escalations reach you most often, and what do you wish happened differently?" | Gets the branch managers' view of the seam in their own words |
| R3.2 | "How are branch supervisors supported on difficult complaints today?" | Goes to the coaching line and gives you something to build on |
| R3.3 | "How will the move to five hubs change how complaints reach you?" | Shows you read the strategy and invites the panel's own view of it |
| R3.4 | "What would you need from me in my first month, and what would tell you it's working?" | Reciprocity: asks what you can do for them |
| R3.5 | "What does Neighbours, Not Numbers look like in a complaint at your branch?" | Shows you read the value and asks for a real example |

---

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has worked in, or run, a contact centre | Negative you stated, F2 | The plain acknowledgment from your own words: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F8 | Your own words: "I've never presented to anyone above regional level." Then a plan, never a past |
| Owned the complaints process end to end | Inflated form of F1 | F1's sentence at its own scope. The limit is the pack's observation, not words for you: the material says one branch's log, not the process |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's sentence at its own scope. The limit is the pack's observation: the material says new tellers and a script |
| Reported complaint volumes and resolution times | Inflated form of F3 | F3's sentence at its own scope. The slot in C4 asks only what the spreadsheet counted |
| Handled regulated complaints | Inflated form of F7 | F7's sentence at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: the material says formal, not regulated |
| Built Excel reporting | Inflated form of F9 | F9's sentence at its own scope. The slot in B4 asks only which tool |

## Sources

Provided documents: the JD as you pasted it; the values text as you pasted it, copied 26 November 2026 from ashgrovecu.org/about/values; the recruiter's email on the process; your summary of the four points of the July 2026 strategy brief; and your background in your message. No dossier was present.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove Credit Union values | skipped | The values text you pasted is in hand and fixes the cheat sheet and F1 to F4 |
| 2. Ashgrove interview process, member services | skipped | The recruiter's email names three rounds, who runs each and what each holds, which fixes the loop and the persona weights |
| 3. Ashgrove strategy and recent news | skipped | Your four-point summary of the July 2026 brief, under six months old, fixes E1, E2 and H2 |
| 4. Interviewer name and Ashgrove | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The interviewers' names, once assigned (the Head of Member Services and the two branch managers) → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to each path
- The strategy brief itself, as the recruiter sent it → the grounding brief and E1, E2 and H2 can use its exact wording and numbers rather than four points
- Your own answers to the answer slots in F1, F3, F4, F5, F7 and F9, stated in this conversation → those rows' bridges become quoted evidence and the matching bank rows regenerate
- A line from the recruiter on whether the case in round 3 is given on the day or in advance → G1 to G3 sharpen to the real format
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → recent leadership and organisation context and reports of how Ashgrove runs its rounds; say the word and I'll run it
- A `tuesday-dossier.md`, if you have one → a verified-evidence base and an explicit prohibited-claims list, in place of the one built here
