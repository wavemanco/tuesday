The pack is written and saved. Here's the delivery message.

Your prep pack is saved as `/var/tmp/tuesday-measure/1a6/runs/sonnet/tuesday/part-2/rooms/case-8-canned-57320bcc/ashgrove-credit-union_member-experience-lead_interview_pack.md`. I built it as a three-round loop from the recruiter's email. It has a shared fit snapshot, then a question bank and five reverse questions for each round. No interviewer names are assigned yet, so there's no per-person read.

- **Most important prep:** "You've never worked in a contact centre, and this role owns complaints there too" (B1). It will come up in all three rounds. The pack gives you plain words for it ("I haven't worked in a contact centre"), then what your own quotes carry, then a plan. Presenting above regional level is the second gap, and B4 covers it.
- **Values round:** your material doesn't yet carry a story for any of the four values. C1 to C4 are scaffolds with an honest "nothing comes to mind" branch. Your next step is to find one real story per value.
- **Research:** I ran no searches. Your pasted values, the recruiter's email, the JD and the July brief already fixed everything a search would feed.
- **Timing:** 5 December 2026 is a Saturday, so RA1 asks the recruiter to confirm the schedule in writing.

Say the word and I'll play the Skeptic on B1 as a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, and I can convert the pack to Word.

Could you paste your CV, or just the bullets under your last two roles? It would turn several answer slots (F4 to F7, F9) into quoted evidence. You can say skip and the pack stands.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Three rounds on 5 December 2026: recruiter screen (30 min), Head of Member Services (45 min, your future manager, mostly behavioural), panel of two branch managers (60 min, including a 20-minute complaint-escalation case; also the values round). Interviewer names are not yet assigned, so there is no interviewer read. Built in loop mode: one shared fit snapshot, then a mini-pack per round.

## How to use this pack

Personas are how a question is asked; types are what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows Ashgrove's published values |
| EXP | Whether your experience survives follow-up; what was actually you |
| JD | The job's stated requirements, gaps included |
| CO | Whether you can think at Ashgrove's altitude (strategy, competition) |
| CASE | Structure and reasoning on a live problem from the role |

Answer slots are instructions for the interview, not questions for you now: where a slot offers two branches, either honest branch is a good answer, and "that was not mine, or did not exist" is always allowed.

## Prep triage

Nine days to 5 December; your daily hours are not known, so this is sized by day. All three rounds are on one day, so your answers to the same question must match across rounds (reason for leaving above all).

| When | Do | Where |
|---|---|---|
| Days 1 to 2 | Say the two plain acknowledgments aloud until they are boring, then rehearse B1 to four follow-up levels. This is the highest-ROI prep in the pack | F3, F8, B1, B4 |
| Days 3 to 4 | Find one real story per value from your own work and write its first two sentences. The pack cannot supply them | C1 to C4, cheat sheet |
| Day 5 | Do the escalation case aloud, twice, timed to 20 minutes | C5 to C7 |
| Day 6 | Settle your own answers on pay, notice, location, reason for leaving; time your 90-second arc | A1, A3 to A6 |
| Day 7 | Read the strategy brief once; think aloud through the three strategy questions | B9 to B11 |
| Day 8 | A live drill, if you want one | Drill offer |
| Day 9 | Rest. Everything else is insurance |  |

## Fit snapshot (shared across rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | Six years against the JD's four, and the words stay at the quote's own terms: "I have six years in retail banking, the last three as a branch supervisor." The JD says customer operations and the quote says retail banking, so if asked how they relate, say what the branch role covered, in your own words. Nothing inspected behind it, so expect a probe |
| F2 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your quote carries one branch's log and the script, which is adjacent to owning a process and not the same thing; the words stay there: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Answer slot: the JD's first line makes a probe on what happened to a complaint beyond your branch likely. If any step beyond your branch was yours to run, say which and how, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the log and the script |
| F3 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then a plan in the future tense, in your own words (B1 rehearses it). Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F4 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | discovery | The quote says the formal log; it does not say what made it formal, so reading it as adjacent is this pack's inference. Words stay at: "I handled the branch's formal complaints log." Answer slot: the JD's requirement line makes a probe on what made your log formal likely. If you know what governed it, say so in your own words and say what part was yours; if you do not know, or nothing governed it, say so plainly and stay with the log |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | The quote touches the monthly report and does not say what the sheet held. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: expect a probe on what it showed. If it counted or tracked anything, say what and how, in your own words; if it counted nothing of the kind, or someone else set its columns, say so plainly and stay with the sheet you built |
| F6 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | The quote says spreadsheet; the JD says Excel. Words stay at the quote. Answer slot: if asked which tool it was, say so plainly; if it was something else, say what it was and what you used it for, in your own words |
| F7 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | The quote's audience is new tellers and its activity is training on a script. Words: "I trained new tellers on our escalation script." Answer slot: if you have ever explained an escalation to a supervisor or a peer, say what you did, in your own words; if you have not, say so plainly and describe what you did with the tellers |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A stated absence. Words: "I haven't presented to anyone above regional level." Then how you would prepare for the first one, said as a plan and never as a past. Nothing added to make it smaller |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing either way. Answer slot: if you have worked on or with any online, app or phone self-service for members, say what it was and what you did, in your own words; if you have not, say so plainly and say what you would ask the complaints data to show a digital team |

No row is a gate: the 4+ years line is a length of experience, graded as any other requirement.

## Round 1: recruiter screen (30 minutes)

### Persona weights

| Persona | Weight | Reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | high | Recruiter-screen prior; your recruiter described it only as "30 minutes with me" | A scripted 90-second arc; treat casual questions as scored |
| Skeptic | light | Recruiter screens carry knockout checks in a friendly register; the JD's contact-centre line is the obvious one | Acknowledge the gap in one sentence, then move on to what the quotes carry |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on three quoted sentences, in order: the six years and the last three as a supervisor; the log and the script; the spreadsheet. Tell each at its own scope, add no dates, names or numbers you did not give here, and close with why Ashgrove in your own words (A2) | F1, F2 and F5 are the whole of your stated history, and an arc built on them cannot overreach. EXP because it checks the story holds together |
| A2 | "What drew you to Ashgrove?" | CO | [grounded] | Name one published value you can speak to from your own experience and one line of the July 2026 brief, and say why in your own words; the pack cannot supply your reason. Do not recite the brief. "Own the Fix — whoever finds the problem keeps hold of it until it is solved" sits closest to the JD's first line | Motivation is a Conversational staple and the one answer a recruiter can compare with later rounds. Tagged CO because it tests homework |
| A3 | "What are you looking for on pay?" | JD | [generic] | Logistics slot: give your own figure or range in your own words, or ask for the role's band first. If asked what you earn now: "I'd rather focus on the range for this role". Give no figure you have not chosen | Pay is a screen question in every recruiter round; the only safe answer is yours. JD because it concerns the job's terms |
| A4 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period, in your own words | A knockout check on start date; JD because it is a job term |
| A5 | "Where can you work, and how often?" | JD | [generic] | Logistics slot: say where and how often you can work, as you would to a colleague, then ask where the role will sit. The brief plans eight branches into five hubs over 2027, so the base is worth confirming | A location check; JD for the job's terms. The hub plan is why asking back is natural, not a trick |
| A6 | "Why are you looking to move?" | EXP | [generic] | Logistics slot: give your actual reason in your own words. Say it once and keep it the same in all three rounds. Put it as what you are moving toward | Reason for leaving is scored for consistency across the day, which is why it is rehearsed first. EXP because it tests how your story cross-checks |
| A7 | "The role covers the contact centre as well as branches. What's your contact-centre background?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain words first: "I haven't worked in a contact centre." Then what your quotes carry, at their own scope: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Then one line of plan in your own words. Do not stretch the log to the contact centre | F3 is the single most predictable objection and the recruiter will have read the JD. JD because it scores the stated requirement; Skeptic delivery |
| A8 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pick one of the two things you have stated, the contact centre or presenting above regional level, and pair it with a plan; do not invent a third. Your own judgement of which is the bigger gap is the answer | F3 and F8 are the stated gaps; naming one first, with a plan, is calibrated candour |
| A9 | "What do you know about where Ashgrove is heading?" | CO | [inferred] | Pick one line of the July 2026 brief (40% of member service digital by 2028; eight branches into five hubs over 2027; small-business lending in Q1 2027; app-only banks as the main competitive pressure) and say what it means for complaints work, as your view. It is a view, not a fact about Ashgrove | The brief is the one document every candidate cannot have, so a one-line link from it to complaints is a differentiator. CO; derived from the brief |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RA1 | "Who will I meet in rounds two and three, and has the panel been confirmed? Also, 5 December 2026 is a Saturday: could you confirm the order and times in writing?" | Interviewer identities unlock a per-person read; confirming the schedule is a normal process question |
| RA2 | "Will I be given anything about the 20-minute case in advance, and is it set in a branch, the contact centre, or both?" | Surfaces any pre-declared material the pack should build on, and shows you are planning the case |
| RA3 | "Where will the role be based once the branch hubs are in place?" | Ties your question to the 2027 hub plan in their own brief |
| RA4 | "How does the team measure success in the first six months?" | Shows you think in outcomes and gives you a target for later rounds |
| RA5 | "What happens after the three rounds, and when will you expect to decide?" | Ends on logistics, and keeps you in the process |

## Round 2: Head of Member Services (45 minutes, your future manager)

### Persona weights

| Persona | Weight | Reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | high | Hiring-manager prior: they are buying capability and de-risking gaps, and your two stated absences are the JD's headline lines | Rehearse B1 until it is boring; build every bridge only from what you stated |
| Values/Behavioral | medium | Your recruiter said the round is "mostly behavioural" | Story-mapped where a sentence carries one; otherwise a selection scaffold that ends honestly |
| Case/Strategist | medium | Hiring managers ask live problems from their roadmap; the roadmap here is the July 2026 brief | Clarify, objective, segments, approach, measures, risks; challenge one premise respectfully |

### Question bank: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never worked in a contact centre, and this role owns complaints there too. How would that go?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | The highest-ROI rehearsal in this pack. Level one: "I haven't worked in a contact centre." Level two: what you bring, at the quote's own scope: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Level three, when pressed on a plan: what you would do in your first weeks to learn it from the people who run it, in your own words, as a future plan. Level four, when asked what you would not know yet: name that limit before it is asked for, using the plain acknowledgment again, and add nothing you did not state. Hold through every follow-up by returning to the log and the script, never by adding to them | F3 is where the JD presses hardest and the manager will own the answer; this question will arrive in some form. JD because it scores the stated requirement; the deepest follow-up chain in the pack because the material is thinnest here |
| B2 | "What experience do you have handling regulated complaints?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say what the quote says: "I handled the branch's formal complaints log." Answer slot: the JD's requirement line makes a probe on what made your log formal likely. If you know what governed it, say so in your own words and say what part was yours; if you do not know, or nothing governed it, say so plainly and stay with the log. Never describe rules you did not work to | F4 is the row where inference ends and the quote stops. JD for the requirement; the slot keeps the answer inside the quote |
| B3 | "Walk me through the monthly complaints spreadsheet you built. What did it show, and who used it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say what the quote says: you built it and your regional manager uses it. Answer slot: the JD's reporting and Excel lines make a probe on what the sheet showed and which tool it was likely. If it counted or tracked anything, say what and how, in your own words, and name the assumption behind the figure you would defend least; if it counted nothing of the kind, or someone else set its columns, say so plainly and stay with the sheet. If you do not know how a figure was counted, say that | F5 and F6 are the evidence for two JD lines at once. EXP because it tests what was yours; the weakest-assumption move is built in |
| B4 | "You'd present monthly to senior leaders, and you've never presented above regional level. How would you handle the first one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | "I haven't presented to anyone above regional level." Then a plan in your own words: how you would find out what the senior leaders want from the report and how you would rehearse beforehand. Answer slot: if you have presented to your regional manager or to any group, say who and what, in your own words; if you have not presented at all, say so plainly. Never claim senior-leader experience | F8 is the second stated gap, and the question is what this interview itself tests. JD for the requirement |
| B5 | "Sixty seconds: why you over someone who has run a contact centre complaints team?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Hold-then-concede. Hold only what the quotes carry, in order: six years, the log and the script, the sheet. Under the second follow-up, concede the specific points in your own words: "I haven't worked in a contact centre" and "I haven't presented to anyone above regional level". Do not fold on the quotes, and do not claim to be better than the other candidate | A pressure framing of F3; the hold is whatever the quotes carry, so the second follow-up cannot break it. JD with Pressure delivery |

### Question bank: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B6 | "Tell me about a time you had to tell a colleague that a complaint hadn't been handled properly." | VAL | [generic] | Selection scaffold: pick a time with a named complaint, a moment you told them, their reaction and what changed; say what was yours and what was theirs. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's supervisor-coaching line (F7) makes this likely in a behavioural round. VAL because it asks for behaviour, not a plan |
| B7 | "When did you put a member ahead of an internal target?" | VAL | [generic] | Selection scaffold: pick a time when what the member needed and what the branch wanted pointed different ways; it needs a named stake, what you decided and what it cost you. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The persona-stem form of "Members First, Always". Use the story later in C1 if it is real |
| B8 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time where the hard truth actually landed; it needs the message, who heard it and what happened after. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The monthly report is the role's unpopular-truth channel (F5, F8). VAL |

### Question bank: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B9 | "Ashgrove wants 40% of member service on digital channels by 2028. What does that do to complaints, and what should the process do about it?" | CO | [inferred] | Think aloud: clarify what counts as member service and where complaints sit in that 40%; the objective; segments (branch, contact centre, digital); the approach; what you would report by channel; the risks, including a member who needs a fix explained twice. Challenge one premise respectfully. This asks for a plan, not a past | The brief's headline target applied to the JD's reporting line. Derived, so [inferred]. CO with CASE delivery |
| B10 | "Eight branches become five hubs over 2027. A member whose branch is closing makes a complaint. How should the process treat it?" | CO | [inferred] | Structure it: whose side of the counter you start from; who holds the complaint until it is solved; how you report it so a town is not reduced to a number (their value is "Neighbours, Not Numbers"). Think aloud, state your assumptions. Nothing here asks about your past | The brief's hub plan meets two published values; the tension is the point. Derived from the brief and values, so [inferred] |
| B11 | "Small-business lending launches in Q1 2027. What would you want in place for complaints before the first loan is made?" | CO | [inferred] | Think aloud: who the product is for and who owns its complaints; the escalation path; how terms are explained so no member needs them twice; what supervisors are trained on; what you would measure from day one. Answer as a plan, not as experience | A new product creates a new complaint type; the question tests whether you work at the brief's altitude. Derived, so [inferred] |
| B12 | "This role works with digital teams on self-service journeys. What have you worked on with a digital team, and what would you bring to one?" | JD | [generic] | Answer slot (F9): if you have worked on or with any online, app or phone self-service for members, say what it was and what you did, in your own words; if you have not, say so plainly, then say what you would ask the complaints data to show a digital team. Do not describe digital work you did not do | The JD requirement F9 has no evidence either way, so this is an open check. JD |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RB1 | "What support would a new lead get in learning the contact-centre side of complaints?" | It turns your biggest stated gap into a joint plan with the person who would manage you |
| RB2 | "What do senior leaders want from the monthly complaints report that they do not get today, if anything?" | Shows you think about the reader of the report, which is where your presenting gap lives |
| RB3 | "How do you expect the digital target for 2028 to change this role in its first year?" | Ties your question to their brief and to the JD's self-service line |
| RB4 | "Where do you see the biggest complaint risk in the hub consolidation?" | A strategy-level question from the brief that invites the manager's own view |
| RB5 | "What would make you say, six months in, that hiring me was right?" | Gives you the manager's own success test to prepare against |

## Round 3: panel of two branch managers (60 minutes, 20-minute case, values round)

### Persona weights

| Persona | Weight | Reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | high | Your recruiter said "The panel is also the values round — they score against the four values" | Map a real story to each value where you have one; otherwise the scaffold and its honest branch |
| Case/Strategist | high | A "20-minute case on a complaint escalation" is a third of the round | Clarify, objective, segmentation, approach, measures, risks; think aloud |
| Peer Evaluator | medium | Branch managers sit at the seam between their branches and the role | Reciprocity framing; propose seam principles, do not pretend to know the seam |
| Skeptic | light | Panel prior blends the top two personas of each member's relationship; names are not known, so no per-member split | Same acknowledgments as rounds one and two |

### Question bank: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Members First, Always: tell me about a time you decided something from the member's side of the counter." | VAL | [generic] | Selection scaffold: a decision where the easy branch choice and the member's need differed; it needs the named stake, what you decided and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The first published value, asked by name. A real story from B7 can be reused here |
| C2 | "Plain Words: tell me about a time something you explained to a member or a colleague didn't land the first time." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Your quote carries the training on the script. Answer slot: the values page says "if a member needs it explained twice, we wrote it wrong", so expect a probe on wording. If you ever changed how a script or explanation was worded because it was not clear, say what and why, in your own words; if you did not, or the script was not yours to change, say so plainly and describe how you trained the tellers | F7's quote is the nearest material to a script, and a script is where Plain Words bites. VAL |
| C3 | "Neighbours, Not Numbers: tell me about a time you balanced what the figures said against what a member or a community needed." | VAL | [generic] | Selection scaffold: a decision where a number and a person pointed different ways; the stake, the choice and the cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Link it to B10 if it is real | The role reports numbers monthly while the value says towns come first; expect the tension to be probed. VAL |
| C4 | "Own the Fix: tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Your quote carries the log. Answer slot: if any complaint from that log stayed with you until it was solved, say which and what you did, in your own words; if none did, or you passed them on, say so plainly and describe how you handled the log | The JD's "end to end" line and the value say the same thing, so it is the likeliest value to be probed. VAL |

### Question bank: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C5 | "A member has complained at a branch twice about a charge they say was made in error. The branch supervisor tells you it has been dealt with. The member has now written to head office to say nothing was fixed. You have the file and an hour. Walk us through what you do, and what you tell the supervisor." | CASE | [generic] | A rehearsal pattern, not a prediction of the panel's case. Spend the first three or four minutes clarifying: what "dealt with" means; what the member asked for; what the file records; what deadlines apply to you. Then objective (the member's side of the counter, one named person holding it); segments (what is fact and what is claim); approach (contact the member in plain words, find the cause, fix it, tell the supervisor what you found); measures; risks. Think aloud; challenge one premise respectfully. It needs no claim about your past | The recruiter said "a 20-minute case on a complaint escalation"; the actual scenario is unknown, so this is a pattern for the type. CASE |
| C6 | "The supervisor says you're second-guessing her in front of her team. What do you say?" | CASE | [generic] | Separate the member's outcome from the supervisor's practice: agree the fix first, then what the file shows, then what you would do differently next time together. Keep your tone about the case, not the person | The follow-up that tests coaching under friction (F7). CASE with Peer delivery |
| C7 | "The same charge error shows up in complaints from three branches this month. What do you do with that?" | CASE | [generic] | Think aloud: confirm it is the same cause; who owns the fix; what the monthly report should show and how you say it in plain words; who needs telling first. Nothing here asks about your past | Connects the case to the monthly report (F5). CASE |

### Question bank: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C8 | "Our branches run the front line and you own the process. Where's the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles, not a map you do not have: whoever sees the member first keeps hold of it until a handoff is accepted; who decides the remedy; who reports. On disagreement: bring the member's case, not the process. Reciprocity: say what your side owes the branch. Disagreement story, if you have one: a time you disagreed with a peer or a manager about a complaint and what happened; if none comes to mind, say so plainly | The persona's own stem, applied to the JD's end-to-end line (F2). JD |
| C9 | "A supervisor handles escalations differently from the process you own. How do you coach them without making them feel policed?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Your quote's scope: you trained new tellers on the script. Answer slot: if you have ever explained an escalation to a supervisor or a peer, say what you did, in your own words; if you have not, say so plainly and describe what you did with the tellers. Then how you would approach it as a plan | F7's gap in its sharpest form from the side that would be coached. JD |
| C10 | "What would you need from us as branch managers in your first month?" | JD | [generic] | Reciprocity first: what you would bring them in future tense, such as a plain-words view of their branch's complaints, then what you would need. Do not claim a seam you have not seen | Branch managers weight the reciprocity slot; JD because it scores the working relationship the role needs |

### Question bank: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C11 | "You've worked in branches. Why should we trust you with the contact-centre side?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain acknowledgment first: "I haven't worked in a contact centre." Then what you did bring, at the quote's scope: six years in retail banking, the last three as a branch supervisor. Then the plan from B1. Do not claim any contact-centre knowledge | The branch managers will hear F3 from their side; the answer is the same acknowledgment you used in rounds one and two. JD |

### Values cheat sheet

| Value (official name) | Working meaning (paraphrased) | Candidate story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No row carries a story. Scaffold (C1, B7): a decision where the easy choice and the member's need differed; if none comes to mind, say so plainly |
| Plain Words | If a member needs it explained twice, the wording was wrong | F7: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Beyond that quote it is the answer slot in C2; otherwise scaffold ending in the honest branch |
| Neighbours, Not Numbers | Every branch is part of its town | No row carries a story. Scaffold (C3, B10): a number and a person pointing different ways; if none comes to mind, say so plainly |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F2: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Beyond that quote it is the answer slot in C4 |

Every value has at least one question: Members First in B7 and C1; Plain Words in C2; Neighbours in B10 and C3; Own the Fix in C4 and C5.

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RC1 | "Which complaints take your branch the most time, and what would you want a new complaints lead to fix first?" | Reciprocity: it asks what a new person could do for them first |
| RC2 | "How do you want to hear about a complaint that touches your branch?" | Tests the seam you will own, in their words |
| RC3 | "How will the hub consolidation change who handles complaints day to day?" | Ties your question to the brief for the people who will live through it |
| RC4 | "Where does the current escalation process work least well for your supervisors?" | Invites the coaching conversation the JD describes |
| RC5 | "Which of the four values is hardest to hold in a busy branch?" | Values-round question: it invites a real story and shows you took the values seriously |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| 4+ years in financial-services customer operations | A1, B5, C11 |
| Own the member complaints process end to end across branches and the contact centre | A7, B1, C4, C8, C11 |
| Experience handling regulated complaints | B2 |
| Report monthly on complaint volumes and resolution times | B3, C7 |
| Comfortable with Excel reporting | B3 |
| Coach branch supervisors on escalations | B6, C6, C9 |
| Confident presenting to senior leaders | B4, B8 |
| Work with digital teams on self-service journeys | B9, B12 |

No headline metric appears in your material, so no defend-the-number row was written; if your CV has figures, send them (see the upgrade menu).

## Grounding brief (Ashgrove's 2026 strategy brief, published July 2026)

| Brief line | What it means for complaints work | Provenance | Used in |
|---|---|---|---|
| "move 40% of member service to digital channels by 2028" | Complaints arrive and are measured in more channels | [inferred] | B9, B12 |
| "consolidate eight branches into five hubs over 2027" | Members in changing branches; more handoffs between teams | [inferred] | A5, B10, RC3 |
| "launch a small-business lending product in Q1 2027" | A new product and a new complaint type | [inferred] | B11 |
| "the main competitive pressure is app-only banks" | Members compare Ashgrove's fix speed with an app's | [inferred] | A9 |

The brief is about four months old; recheck for news before 5 December.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the member complaints process end to end | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation, not your words: your material says one branch's log and the script, not the process |
| Handled regulated complaints | Inflated form of F4 | F4's quote at its own scope. B2's slot asks only what made your log formal |
| Reported on complaint volumes and resolution times | Inflated form of F5 | F5's quote at its own scope. B3's slot asks only what the sheet counted |
| Excel reporting experience | Inflated form of F6 | F6's quote at its own scope: a spreadsheet. The tool is an answer slot |
| Coached branch supervisors on escalations | Inflated form of F7 | F7's quote at its own scope: new tellers, the script |
| Contact-centre experience | Negative you stated, F3 | "I haven't worked in a contact centre." No slot |
| Presented to senior leaders | Negative you stated, F8 | "I haven't presented to anyone above regional level." No slot |

## Sources

Provided documents: the job description; the values text you copied from ashgrovecu.org/about/values on 26 November 2026; the recruiter's email on the process; Ashgrove's 2026 strategy brief (July 2026); your background as you wrote it. No dossier was present.

Loop: your recruiter's email establishes the loop (three rounds on 5 December, who runs each, what each holds, and that the panel scores against the four values), so persona weights rest on it and on the relationship priors, not on an archetype.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The values text, copied this morning, fixes the cheat sheet by name; a fetch could not have changed a row |
| 2. `Ashgrove Credit Union interview process member services` | skipped | The recruiter's email fixes the rounds, who runs them and the values panel; a search could not have changed the persona weights |
| 3. `Ashgrove Credit Union strategy` | skipped | The July 2026 brief you were sent fixes B9 to B11 and the grounding brief |
| 4. interviewer name and Ashgrove | n/a | No names yet, only roles; there is no interviewer read |
| 5. representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD questions |

## Upgrade menu

- Interviewer names, when assigned → an interviewer read, persona weights per person on the panel, and a reverse question tied to each one's own path
- Your CV or the bullets under your last two roles → F4 to F7 and F9 evidence cells quoted from it, and any figures become defend-the-number rows
- Your answers to the slots in F2, F4, F5, F6, F7 and F9 → those rows upgrade and B2, B3, B12, C4 and C9 regenerate
- A real story per value, in your own words → C1 to C4 become story-mapped, and the cheat sheet rows follow
- The recruiter's guidance on the 20-minute case (format, materials, whether you present anything) → if anything was pre-declared, a graded-deliverable section is added
- Your daily prep hours → the triage is resized
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes): role-family loop reports and recent organisation context, such as news on the hub consolidation. Offered once; say so if you want it
- A tuesday-dossier.md from an earlier session, if you have one → confirmed evidence and absolute prohibited claims; not needed
