Web search was refused, so I'm building the pack from your JD and background alone and labelling what that costs. Now writing the file.
Your prep pack is saved as `Atlas-Freight_operations-manager_interview_pack.md` in the working directory. I built it for a hiring-manager round, since your note didn't say who you're meeting.

Web search was refused, so I couldn't look up Atlas's values, interview process or strategy. The pack rests on your JD and the six facts in your message. The Sources section lists the three refused searches and what each would have changed.

**Prep priorities**
- **A1 is the one to rehearse most.** The gap that will come up first is going from 3 supervisors to 12. Say that step out loud before they do, then give a plan. Don't stretch the 3 into something bigger.
- **Power BI.** Say "I've never used Power BI" plainly, then give a short plan for learning it. Your Excel line needs an honest answer on what you've actually built in it.
- **The 40% mis-pick figure.** Be ready to say how it was counted and which part was yours, or that you don't know how it was counted.
- **Terminal vs. warehouse.** Your material shows one site and warehouse work, not a freight terminal or four sites. The pack gives you slots to answer honestly either way.
- **The pack has 22 questions across 7 interviewer styles,** a fit table for each JD requirement, six reverse questions, and a list of claims not to make.

I added no figures, events or practices to your background. Where the JD asks for more than you told me, the pack gives an answer slot, where you say what you actually did or say plainly that you didn't.

I can run a live mock of A1 with an interviewer who pushes back, and I can convert the pack to Word. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions.

Two questions that would change the pack:
1. Who are you meeting: your future manager, a peer, or a panel?
2. Can you paste your CV? Without it, only the six facts from your message are quoted, and I can proceed without it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Atlas-Freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

- **Role:** Operations Manager, Atlas Freight (regional logistics, 800 employees)
- **Round:** hiring-manager round, assumed; your note did not say who you are meeting
- **Interviewer:** not known

## How to use this pack

Personas describe how a question is asked; types describe what it is scoring. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did.

| Type | What it is scoring |
|---|---|
| VAL | Whether past behavior shows the company's values, not generic virtue |
| EXP | Whether your CV claims survive scrutiny; what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | How well you know the company's strategy and market |
| CASE | Structure and reasoning on a live problem from the role |

- Provenance labels: `[grounded]` traces to your message or the JD you pasted; `[inferred]` is this pack's derivation; `[generic]` is a role-family pattern with no claim about Atlas or you.
- An answer slot is an instruction for the interview, not a question for you now. Answer it from your own experience, or say plainly that the practice was not yours.
- Highest-ROI prep in this pack: A1, the step from three supervisors to twelve.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "ran the site's peak-season surge plan two years running" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material names one site's surge plan and a shift, not four sites or a terminal, and the words stay at that scope: "I ran the site's peak-season surge plan two years running." and "I am currently a senior shift manager over 3 supervisors." Answer slot: the JD's four-sites line makes a probe on multi-site scope likely. If you have covered more than one site, or worked in a freight terminal, say where and how, in your own words; if not, say so plainly and stay with the shift and the surge plan |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Your material carries a mis-pick figure, not on-time performance or cost per shipment, and the words stay there: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: the JD names two measures, so expect a probe on which you tracked. If you tracked either, say what and how it was counted; if neither, say so plainly and stay with the mis-pick rate. The figure also raises its own slots: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | The twelve is the JD's number; your material carries three. Words: "I am currently a senior shift manager over 3 supervisors." Answer slot: if you have led more than three supervisors at any time, say how many and in what role; if not, say so plainly and stay with the three |
| F4 | "build reporting in Excel/Power BI" — JD | "solid Excel" — your message | low | [inferred] | discovery | The quote is a skill, not a report you built, and the material is silent on what you have built. Words: "I'm solid in Excel." Answer slot: the JD pairs Excel with reporting, so expect a probe on what you have built. If you have built reports or trackers in Excel that others used, say what they tracked and who read them; if not, say so plainly and say what you have used Excel for |
| F5 | "build reporting in Excel/Power BI" — JD | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used Power BI." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message | low | [inferred] | discovery | The quote says seven years in operations, not seven years in leadership, so the pack does not carry them across as leadership years. Answer slot: the JD's 5+ years line makes a probe on leadership tenure likely. If some of your seven years were in a lead or supervisor role, say how many and in what role, in your own words; if fewer than five were, say so plainly and stay with the seven you have stated |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap, but a one-phrase quote with nothing inspected behind it; the certificate is the inspectable artifact. Words: "I'm green belt certified." Name the scheme and issuer as they appear on the certificate, since the quote does not, and expect a probe on where you have used it (D2) |

No requirement in the JD is a gate in the evidence conventions' sense: the years requirement is experience, not a legal or credential bar, so it is graded like any other row.

## Persona table

Starting weights come from the hiring-manager prior, which is an assumption because the round is not known. No loop source establishes Atlas's loop (see Sources), so the generic archetype applies and adds no tilt.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A, 5 questions) | Quiet probing of the scale step, the Power BI gap, warehouse versus terminal | High: a hiring-manager prior, and F3, F5 and F1 each sit where the JD asks for more than the quotes carry | Rehearse the span question (A1) until it is boring; bridges only from your quoted sentences; a plan for the rest |
| Case/Strategist (bank B, 5 questions) | Live operations problems: on-time slipping, cost per shipment rising, a surge | High: a hiring-manager prior, and the JD is built around two measures and four sites | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise |
| Data-Driven Prober (bank C, 3 questions) | Pressure-tests the 40% and what you track | Medium: your only figure is the mis-pick result, and the JD asks for measure-driven reporting | Know what you can and cannot say about how the 40% was counted; say plainly when you do not know |
| Conversational (bank D, 3 questions) | Walk-me-through and casual questions about Lean and the surge | Medium: opening questions arrive in every round and are still scored | A 90-second arc built only from your quoted sentences |
| Pressure (bank E, 2 questions) | Time-boxed comparison with a multi-site candidate | Low to medium: the scale gap invites it, but a hiring manager rarely leads with it | Pause, restate, hold through two follow-ups, concede specifically |
| Peer Evaluator (bank F, 2 questions) | Seam between sites and credit across teams | Low: a hiring manager is the assumed interviewer, though site leads may join a loop | Offer seam principles; reciprocity framing |
| Values/Behavioral (bank G, 2 questions) | Scenario probes; unpopular truths; customer versus metric | Low: no values-style round is detected, and no values page was read | Selection scaffolds ending in the honest branch |

## Question banks

### Bank A: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You lead three supervisors today. This role has twelve. What makes you ready for that step?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI rehearsal in this pack. Hold only what the quote carries: "I am currently a senior shift manager over 3 supervisors." Name the size of the step before they do, as a statement about the role: twelve supervisors is a larger span than the team you lead now. Answer slot: if you have led more than three supervisors at any time, say how many and in what role, in your own words; if not, say so plainly and stay with the three. Then give a plan, spoken as a plan and never as a past: what you would learn before changing anything. Hold through two follow-ups by returning to the three, never by adding to them | F3 is where the JD's scale presses hardest and F1 sits beside it, so this objection arrives in some form; JD because it scores the stated requirement |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "never used Power BI" | Pick the weakness that is true, not the safest one. Your own message names Power BI, and the plain version is "I've never used Power BI." Follow it at once with a plan: what you would do first and who you would ask. A plan is future tense and claims nothing started | F5 is the one gap you stated yourself, so it is the one you can name without inflating; JD because it scores the stated tool requirement |
| A3 | "I don't see Power BI in your background. How would you build our reporting?" | JD | [grounded] "solid Excel, never used Power BI" | Concede the first half in one breath: "I've never used Power BI." Then say what you are solid in: "I'm solid in Excel." Answer slot: if you have built reports or trackers in Excel that others used, say what they tracked and who read them; if not, say so plainly and say what you have used Excel for. Then a plan for the build, spoken as a plan: which two measures first and who reads them | F4 and F5 are the same JD line with two different evidence states; JD because it scores the stated reporting requirement |
| A4 | "Your results come from warehouse and distribution work. How does that carry to terminal operations?" | JD | [grounded] "7 years in warehouse and distribution ops"; "cut mis-pick rate 40% by redesigning the pick path" | Use the quotes at their own scope: "I have 7 years in warehouse and distribution ops" and "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: the JD says terminal operations, which your quotes do not name. If you have worked in a freight terminal or a cross-dock, say where and what you handled; if not, say so plainly and stay with the warehouse and distribution work. What you expect to be different is your view of the work, offered as a view and not as experience | F1 is the row where the JD's setting and the quotes differ; JD because it scores the stated operations requirement |
| A5 | "Why are you leaving your current role, and why Atlas?" | EXP | [generic] | Logistics slot: give your actual reason for leaving, in your own words; nothing in your message states one, so the pack supplies none. For why Atlas, use only what you have actually read or heard; the pack could not research the company, so read Atlas's own site before the interview and bring one true, specific thing. Do not guess at a reason | The Skeptic's why-leave, why-here, why-now probe; EXP because it tests consistency of your story, `[generic]` because no quote or company fact carries it |

### Bank B: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one of our four sites has slipped over a month. Diagnose it." | CASE | [generic] | Clarify first: how on-time is defined and measured, which lanes and shifts, what changed and when. Then objective, segmentation (by site, shift, lane, inbound or outbound, cause), approach, metrics, risks. Think aloud and challenge one premise respectfully, such as whether the slip is real or a measurement change. The question needs no claim about your past, so the guidance makes none | F2's JD line asks you to drive on-time performance; CASE because it is a live problem, `[generic]` because it is a pattern for the problem, not a fact about Atlas |
| B2 | "Cost per shipment is rising while on-time holds. Where do you look first?" | CASE | [generic] | Clarify the definition of cost per shipment before anything else. Then split it into its components, name the trade-off with service, and say which single data cut you would pull first and why. Challenge one premise: whether on-time is holding for the right reasons. No claim about your past | F2's second measure; CASE because it asks for structured diagnosis |
| B3 | "Sketch a peak-season surge plan for four terminals. What do you need to know first?" | CASE | [generic] | Ask for forecast volumes, labor sources, constraints at each site and the service commitments that cannot slip. Then objective, segmentation by site, approach, metrics, risks. Challenge one premise, such as treating the four sites as one pool. Think aloud | F1's four-site line asked as a live plan; CASE because it is a hypothetical, `[generic]` because it presupposes nothing about you or Atlas |
| B4 | "You take over twelve supervisors with uneven results. What do you do in the first 30 days?" | CASE | [generic] | A plan, spoken as a plan: what you would want to learn from each supervisor and each site before changing anything, which two or three measures you would look at first, and how you would tell the difference between a people problem and a process problem. Nothing here is a claim about what you have done | F3's twelve-supervisor line as a role problem; CASE because the answer is a plan, not a past |
| B5 | "All four sites have a problem the same morning. How do you decide where you go first?" | CASE | [generic] | State your criteria out loud: safety, customer commitments that cannot move, what is recoverable, where your presence changes the outcome. Ask what each site already has in hand. Challenge the premise that you must pick only one place | F1's daily-operations line; CASE because it scores prioritisation under load |

### Bank C: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say what you can about how it was counted, in your own words. Answer slot: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly and say who would. Never describe a method you did not use | F2's figure is the only number on your side of the table, so it is where a prober starts; EXP because it tests attribution |
| C2 | "What do you track today for on-time performance and cost per shipment?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: if you track either, say what and how it is counted; if neither, say so plainly and stay with the mis-pick rate, in the words of the quote. Do not supply a definition or a figure you do not use | F2's two JD measures; JD because it scores the stated responsibility |
| C3 | "Which numbers would you put on a daily view across four sites, and why those?" | JD | [generic] | Start from the two measures the JD names: on-time performance and cost per shipment. For each, say how it is defined, who reads it and what action a change would trigger. Add at most two supporting measures and say why. This is a design answer, so it asserts nothing about your past | F4's reporting line asked as a design question; JD because it scores the stated reporting duty |

### Bank D: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running" | A 90-second arc with three beats the quotes state: seven years in warehouse and distribution ops, now a senior shift manager over three supervisors, and the pick-path and surge-plan results. Answer slot for the middle: the quotes carry no employers, dates or titles, so fill them from your own career in your own words. Answer slot for the JD's 5+ years: if some of your seven years were in a lead or supervisor role, say how many and in what role; if fewer than five were, say so plainly and stay with the seven. Close on why this role, using the JD's own words | F6 and F1 are both answered by the arc, and the opener is scored even when it feels casual; EXP with JD because it carries the leadership-years line |
| D2 | "What are you actually playing with in Lean or Six Sigma these days?" | JD | [grounded] "green belt certified" | Say it as it is: "I'm green belt certified." Name the scheme and issuer as on the certificate. Answer slot: if you have applied it at work, say where and what; if you have not since certifying, say so plainly and stay with the certification. If the pick-path redesign came out of that work, say so; if not, keep the two separate | F7's plus-skill, asked casually, which is how it is usually scored; JD because it scores the stated preference |
| D3 | "Tell me about the peak-season surge plan you ran." | EXP | [grounded] "ran the site's peak-season surge plan two years running" | The beats are the ones the sentence states: the plan, the site's, two years running. If asked what the plan contained, or how the two years compared, answer from what actually happened, in your own words; if you do not know a figure, say so plainly. Nothing else in the story comes from the pack | F1's strongest quote and the one a manager will reach for; EXP because it tests what was actually yours |

### Bank E: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you, over someone who has already run several sites?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running" | Pause, restate the question, then hold on the two quotes: "I cut mis-pick rate 40% by redesigning the pick path" and "I ran the site's peak-season surge plan two years running." Answer slot: if you have worked across more than one site, say how; if not, say so plainly and stay with the two. Hold through two follow-ups; concede the comparison specifically, without folding on the quotes | F1 and F3 are where a multi-site rival is strongest; JD because it scores fit against the stated scale |
| E2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold the sentence, in your own words, through two follow-ups. Answer slot: if others worked on it, say what part was yours; if it was yours alone, say so plainly. If you do not know how the figure was counted, say so rather than defending it | F2's figure under the standing attribution probe; EXP because it scores what was actually the candidate's |

### Bank F: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "If two terminals need the same resource on the same day, how do you settle it?" | CASE | [generic] | Offer seam principles rather than pretending to know Atlas's: who has the stronger customer commitment, what is recoverable, who decides when you cannot agree, and how you keep the loser informed. Frame what you bring the other site as well as what you need. No claim about your past | F1's four-site line seen from a site lead's side; CASE because it is a hypothetical |
| F2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time work spanned teams, name who did what, and say which part was yours. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Peer persona's credit-sharing probe; VAL because it tests behavior, `[generic]` because no quote carries a story |

### Bank G: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: choose a time with a named stake, a point where you did not soften the message, and a relationship that was intact afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard values-round stem; VAL because it tests past behavior, `[generic]` because no values page was read |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: choose a decision where the metric and the customer pointed in different directions, name what you chose and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard values-round stem; VAL, `[generic]` for the same reason as G1 |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own daily terminal operations across 4 sites | A1, A4, B1, B3, B5, D3, E1, F1 |
| Drive on-time performance and cost-per-shipment down | B1, B2, C1, C2, C3 |
| Lead a team of 12 supervisors | A1, B4 |
| Build reporting in Excel/Power BI | A2, A3, C3 |
| 5+ years operations leadership required | D1 |
| Lean/Six Sigma a plus | D2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How is on-time performance measured across the four sites today, and where is it weakest?" | It uses the JD's own measure and tells you what you would be asked to fix first |
| R2 | "What does reporting look like now: what lives in Excel and what is already in Power BI?" | It shows you are planning for the tool you have not used, and sizes that gap for you |
| R3 | "How are the twelve supervisors spread across the four sites, and how much does that vary?" | It shows you are already thinking about the span, and tells you how big A1's step really is |
| R4 | "What would a strong first 90 days look like in this role?" | It gets the success measure in the manager's words, which you can reflect back in later rounds |
| R5 | "What is the hardest operating problem the person in this role inherits?" | It shifts the conversation from your gaps to the work, and signals you expect to face a real problem |
| R6 | "What are the next steps and timeline?" | It closes cleanly and gives you a date to follow up against |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran terminal operations across multiple sites | Inflated form of F1 | F1's quotes at their own scope: "I ran the site's peak-season surge plan two years running." The limit is the pack's observation, not words for you: your material names one site's surge plan and a shift, not four sites or a terminal. D3's slot stays inside the surge plan |
| Led twelve supervisors, or more than three | Inflated form of F3 | F3's quote at its own scope: "I am currently a senior shift manager over 3 supervisors." A1's slot asks only whether you ever led more than three |
| Drove on-time performance or cost per shipment down | Inflated form of F2 | F2's quote at its own scope: "I cut mis-pick rate 40% by redesigning the pick path." The limit is the pack's observation: the material carries a mis-pick figure, not the JD's two measures. C2's slot asks only what you track |
| Built Power BI reports or dashboards | Negative you stated, F5 | The plain acknowledgment F5 gives: "I've never used Power BI." No slot |
| Has 5+ years of operations leadership | Inflated form of F6 | F6's quote at its own scope: "7 years in warehouse and distribution ops." The limit is the pack's observation: the material says seven years in operations, not seven years in leadership. D1's slot asks only about your lead or supervisor years |
| Delivered results through Lean or Six Sigma projects | Inflated form of F7 | F7's quote at its own scope: "I'm green belt certified." D2's slot asks only where you have applied it |

## Sources

Provided documents: the job description you pasted, and the six background fragments in your message. No `tuesday-dossier.md` was present.

Loop: no loop source establishes Atlas's loop, so persona weights rest on the hiring-manager assumption above and the generic archetype, not on a documented process. No values-style round is detected, so there is no values cheat sheet.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Query | Outcome |
|---|---|
| Atlas Freight regional logistics company values | refused |
| Atlas Freight interview process operations manager | refused |
| Atlas Freight regional logistics strategy news | refused |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Every call was refused. Would have moved a values-themed VAL bank, and the values cheat sheet only if a loop source documented a values round |
| 2. `{company} interview process {role family}` | unavailable | Every call was refused. Would have moved the loop structure, and with it the persona weights and which banks lead |
| 3. `{company} strategy` / recent news | unavailable | Every call was refused. Would have moved a CO question and made B1 to B5 specific to Atlas instead of `[generic]` |
| 4. `{interviewer name} {company}` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `{role title}` JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Who you are meeting and the round type (future manager, peer, panel, skip-level) → persona weights recomputed from the real relationship, replacing the hiring-manager assumption
- The interviewer's name → an interviewer read and a reverse question tied to their own path
- Your CV text → rows F4 and F6 may gain quotes that reach the Excel-reporting and leadership-years requirements; any `none given` or thin evidence cell can change
- A before-and-after mis-pick report, or the surge plan document itself → F2 and F1 could move from `medium` to `high`, since those are the inspectable artifacts in operations
- Search access, or a deep research pass (up to 6 more searches and 2 more fetches, several more minutes) → the three unavailable rows above become sourced, and B1 to B5 gain Atlas-specific strategy and a documented loop
- The recruiter's note on format, or any take-home or presentation → coverage of a pre-declared deliverable
- A `tuesday-dossier.md` → verified evidence and sourced prohibited claims in place of the ones built locally here; this pack never needs one
