Web search was refused, so I'll build the pack from what you gave me only. I'm writing it now.
Your prep pack is saved at `/var/tmp/tuesday-measure/1a6/runs/sonnet/tuesday/part-2/rooms/case-7-denied-ad9037f8/saltmarsh-games_live-operations-producer_interview_pack.md`.

**Research:** web search was refused here, so none of the four lookups ran. I tried Saltmarsh's values, its interview process, its strategy, and Tobias's public background. Everything in the pack comes from your JD and your background note, and nothing in it is a claim about Saltmarsh. The company-knowledge and values questions are marked `[generic]`, and the interviewer-read section is dropped. If you allow search, I can re-run it and fill those in.

**Assumption:** your message didn't say who Tobias is to you, so I built it as a hiring-manager round. That puts the heaviest weight on live case problems and on questions probing your gaps.

**Highest-ROI prep:** B3, the in-app purchases question. You said you have never worked on a game with in-app purchases, and a mobile live-ops head is likely to probe it. The pack gives you the honest answer as a short plan, with no experience claimed.

Say the word and I'll play the Skeptic on B3, one live drill round.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the person you'd report to, a skip-level, or a cross-functional round, and did the recruiter name any focus areas or a pre-work task such as a presentation or take-home? Either answer reweights the banks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

- **Candidate:** Femi
- **Interviewer:** Tobias Wrenfield, Head of Live Operations. 60 minutes, Friday.
- **Relationship:** not stated. This pack is built as a hiring-manager round, which is an assumption. Section 8 shows how a different answer would reweight it.
- **Research:** none ran, because web search was refused. Nothing here states a fact about Saltmarsh Games, its titles, its process or Tobias beyond the title you gave me. Section 14 has the detail.

## 1. How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding to rehearse from, not a script: say it in your own words, and only what you actually did. Where a cell says "answer slot", it is an instruction for the interview, not a question for you now.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows good judgement and values. No published Saltmarsh values were available, so these rest on generic themes |
| EXP | Whether your own claims survive scrutiny and you can say precisely what was yours |
| JD | A stated responsibility or requirement in the posting, including the gaps |
| CO | Knowledge of the company and its strategy |
| CASE | A live problem set in the role, answered by structuring it aloud |

**Highest-ROI prep in this pack: B3.** You told me you have never worked on a game with in-app purchases. A mobile live-ops head is likely to get to that topic, and B3 is built so the honest answer is ready before it is asked. B1 is second.

## 4. Fit snapshot

The posting has no gate requirements. "3+ years" is a length-of-experience requirement, so it is graded like any other row (F5). Pay, location and schedule are not in the posting, so there are no gate rows.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for one main title. It does not say events, and it does not say a second title, so the words stay at that scope: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's two-titles line makes a probe on what changes with a second title likely. If you ever scheduled around another title's or another team's work, say how, in your own words. If you did not, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show which teams the calendar touched. Answer slot: if you coordinated work with any of design, art, engineering or community, say which and what that involved, in your own words. If none, or it was someone else's job, say so plainly and say how you would start on day one |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | low | [inferred] | discovery | Your material says you presented the numbers, not that you ran a review or owned what it reports, and the pack makes nothing wider of it. Answer slot: if you ran or wrote any review of a drop after it shipped, say what it covered. If you did not, say so plainly and stay with presenting the monthly numbers |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | transferability | Your material says you wrote it and QA still uses it, so the words are: "I wrote the release checklist our QA team still uses." Answer slot: the JD pairs the checklist with QA, so expect a probe on how it runs each release. If you ran it with QA on releases, say how. If you wrote it and others ran it, say so plainly and stay with writing it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years" — your message | low | [inferred] | discovery | Your material gives four years as an associate producer and two years of a weekly content calendar. It does not say whether the main title was a live service, so the pack neither says nor implies it. Answer slot: if the title was run as a live service, say how, in your own words. If it was not, say so plainly and stay with the years and the calendar |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap in the words, but nothing is inspected behind it, so expect a probe. Lead in the quote's own terms: you ran it, weekly, for the main title, for two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | No gap in the words, but nothing is inspected behind it. Lead with what the quote says: you presented them, monthly, to the studio head. The likely probe is how the numbers were counted, which C1 rehearses |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | low | [inferred] | transferability | A written document others still use is adjacent to the requirement and is not proof of clear writing. The words stay: "I wrote the release checklist our QA team still uses." A writing sample would raise this row |
| F9 | The posting asks for no people management. Its closest line is "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team, and never worked on a game with in-app purchases" — your message | none | [grounded] | capability | You stated this one, so the words are yours: "I haven't led a team." Then how you would coordinate people you do not manage, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F10 | No line of the posting mentions in-app purchases. You raised this gap yourself — your message | "Never led a team, and never worked on a game with in-app purchases" — your message | none | [grounded] | capability | You stated this one too: "I haven't worked on a game with in-app purchases." Then how you would get up to speed, said as a plan. Your material does not say whether Saltmarsh's titles sell them, and the pack does not say either |

## 5. Graded deliverables

Dropped: no recruiter-announced deliverable was mentioned.

## 8. Persona table

Relationship prior: a Head of Live Operations most plausibly sits above this role, so I started from the hiring-manager row (Case/Strategist plus Skeptic). That is an assumption. No loop source exists, so no loop adjustment is applied: the fallback archetype is Generic, which is flat, and the weights rest on the relationship prior alone. No interviewer signals were available.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | Live problems from the role: schedule conflicts, a retention dip, a late bug | High. A hiring manager is buying capability, and the JD is all planning and coordination. 5 questions | Clarify, then objective, segments, approach, metrics, risks. Think aloud and challenge one premise respectfully |
| B. Skeptic | Probes the jump from one title and no team lead to two titles and four disciplines | High. Hiring managers de-risk gaps, and F1, F2, F9 and F10 are visible gaps. 5 questions | Rehearse the most predictable objection until it is boring. Bridges use only what you stated. Concede limits plainly |
| C. Data-Driven Prober | Pulls on the retention numbers and the checklist line by line | Medium. F3 and F7 are the evidence a prober tests, and the role owns KPIs. 3 questions | Say what you presented and what you did not build. Say plainly when you do not know how a number was counted |
| D. Conversational | Friendly opener: your journey, what you play, why Saltmarsh | Medium. Almost every first sixty minutes opens this way, and it is still scored. 3 questions | A 90-second arc built from your own sentences. Prepare a real answer to the reverse-question slot |
| E. Pressure | Time-boxed challenge on why you for this scope | Low to medium. Not the default for a hiring manager, but the experience gap invites it. 2 questions | Pause, restate, hold the position through two follow-ups, concede specifically |
| F. Values/Behavioral | Scenario prompts about judgement and speaking up | Low. No values-style round is documented for this loop. 2 questions | Pick a story only where a sentence of yours carries one. Otherwise say so plainly |
| G. Peer Evaluator | How you work with design, art, engineering and community leads | Low in a one-on-one with the head of the function, higher if cross-functional leads join. 2 questions | Offer seam principles instead of pretending to know the seam. Share credit with "we" for context and "I" for contribution |

If Tobias turns out to be a skip-level or executive round, Case and Pressure go up and Prober and Conversational go down. If a cross-functional round, Values and Peer go up.

## 9. Question banks

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two titles | A1, B1, E1 |
| Coordinate design, art, engineering and community teams | A3, B2, G1 |
| Own the post-event review and the KPIs it reports | A2, A5, B5, C2 |
| Manage the release checklist with QA | A4, C3 |
| 3+ years producing live-service games or apps | E1, D1 |
| Experience running a content calendar | B1, D1, E1 |
| Comfortable with player-retention metrics | A2, C1, C2, E2 |
| Clear written communication | A3 |

No CO question is grounded in Saltmarsh's strategy, because research did not run. D3 is the one CO row, and it is `[generic]`.

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two events want the same release week, and both need the same art team and the same QA team. Talk me through how you decide." | CASE | [generic] | Structure it aloud. What you would ask first: what each event is meant to move, and the art and engineering lead times. Then how you would compare them, what you would tell the owner of the event that moves, and what you would record. The question needs no claim about your past, so the guidance makes none | A live problem from the JD's two-titles and coordination lines (F1, F2). CASE because it scores structure, not history |
| A2 | "Retention drops after an event ends. Diagnose it." | CASE | [generic] | Clarify before structuring: which players, which platform, compared with what. Then split event effect from baseline, name what you would check first, and say what would change your mind. Say plainly what you would need data for rather than guessing | The JD's retention line (F7) as a live problem, the stem a data-minded hiring manager reaches for. CASE because it is diagnosis delivered live |
| A3 | "An event is cancelled the day before launch. Give me, aloud, the first message to design, art, engineering and community." | CASE | [generic] | Four beats in a few sentences: what happened, what is changing, what each team does next, and when the next update comes. Plain words, no apology padding. The question needs no claim about your past, so the guidance makes none | Scores the JD's clear-writing and coordination lines (F8, F2) in a form that does not depend on a writing sample |
| A4 | "Thursday's release is ready except for a blocking bug QA flagged tonight. What do you do?" | CASE | [grounded] "Wrote the release checklist our QA team still uses" | Structure the call: what you need to know about the bug, who decides, what each option costs, what you tell the teams. If you draw on your checklist, your words were: "I wrote the release checklist our QA team still uses." Answer slot: if the checklist covered a go or no-go step, say how it worked. If it did not, or the call was not yours, say so plainly and describe how you would make it | F4 is the evidence for the checklist line. CASE because it is a live decision, with JD content |
| A5 | "How would you judge whether an event worked? What goes in the first paragraph of the review?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Pick one or two measures you can define in a sentence, say what each can and cannot show, and say what you would write first. Your own words for the nearest thing you did: "I presented the monthly retention numbers to the studio head." Answer slot: if you wrote up or reviewed a drop after it shipped, say what the write-up covered. If you did not, say so plainly and say how you would build the first one | F3 is the thin row for the post-event review line, and the JD makes it the role's own job. JD because it scores that stated duty, with CASE delivery |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your calendar was for your studio's main title. This role covers two of ours. What changes with two?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Hold what the quote carries: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: if you ever scheduled around another title's or another team's work, say how, in your own words. If you did not, say so plainly, then give a plan: what you would learn first about each title before changing anything. Hold through two follow-ups by returning to the calendar you ran, never by adding to it | F1 is the likeliest place the scale jump is probed. JD because it scores the stated two-title scope |
| B2 | "You haven't led a team, and this role coordinates design, art, engineering and community on every update. How does that work for you?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases" | The plain acknowledgment is yours: "I haven't led a team." Then the plan: how you coordinate people you do not manage. The JD line says coordinate, and the pack makes no claim beyond that. Answer slot: if you coordinated work across any of those disciplines, say which and what that involved, in your own words. If none, say so plainly and describe how you would start. Never describe coordination as leadership | F9 and F2. JD because it scores the coordination line and its gap |
| B3 | "You haven't worked on a game with in-app purchases. If one of our titles sells them, how would you get up to speed before your first event?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases" | The highest-ROI rehearsal, and the limit goes first: "I haven't worked on a game with in-app purchases." Then a plan only, never a past: what you would ask for in week one, who you would learn from, what you would hold off deciding until you had. Follow-up one: "what would you do first?" Say the first concrete step. Follow-up two: "so you can't tell me how they affect an event?" Concede plainly: "Not from experience, no." Then return to the plan. Follow-up three: "does that worry you?" Say what it would cost you and how you would close it. Never claim related monetisation work | F10 is your own stated gap and the one a mobile live-ops head is likeliest to reach for. Rehearsed so the honest answer is ready. JD because it scores a gap against the role |
| B4 | "Which part of this JD would you be weakest at on day one?" | JD | [generic] | Pick the line where your own material is thinnest, name it first, and say how you would close it. This pack's reading of your snapshot: F2 and F3 hold the least evidence. Naming it before you are found there reads as honesty, and picking a safe line reads as avoidance. The guidance makes no claim about your past | The Skeptic's standard stem, and the one the snapshot's thinnest rows make most predictable |
| B5 | "This role owns the post-event review. Tell me about a time you looked back at a release and changed what you did next." | JD | [grounded] "Presented the monthly retention numbers to the studio head" | An open prompt, so choose the instance. Pick a time that has a named release, something you actually saw afterwards, and a change you made. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which in your words is "I presented the monthly retention numbers to the studio head", or say how you would run such a review. Do not supply an outcome you cannot repeat under a second question | F3. JD because the review is a stated duty |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the monthly retention numbers you presented to the studio head: where they came from and what they showed." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Say what you presented, to whom and how often: "I presented the monthly retention numbers to the studio head." Answer slot: if you pulled or built the numbers yourself, say how, in your own words. If they came from an analyst or a tool and you presented them, say so plainly and stay with presenting them. If asked how a number was counted and you do not know, say that plainly. Name the assumption behind a number you would defend least, but only one you actually know about | F7 and F3. EXP because it tests what was actually yours |
| C2 | "Pick one retention measure you would report after an event. What is its weakest point?" | JD | [generic] | Pick one you can define in a sentence, then name its weakest point before they do. If you are unsure how a measure is usually counted, say so rather than guessing. The guidance makes no claim about your past | The JD's retention line as a pick-and-defend question, which is how a prober tests a candidate who has not named a figure |
| C3 | "Walk me through the release checklist you wrote for QA." | EXP | [grounded] "Wrote the release checklist our QA team still uses" | The beats the quote states: you wrote it, and QA still uses it. Tell them in your own words: "I wrote the release checklist our QA team still uses." Answer slot: the JD pairs the checklist with QA, so expect a probe on which steps were yours to set or how it changed. If you set any, say which and why. If it was static, or the steps were not yours, say so plainly and stay with writing it | F4 and F8. EXP because it tests what you did on a line you quoted |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your journey so far." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" | A 90-second arc from your own sentences only: "4 years as an associate producer at a puzzle-game studio"; for the last two years "I ran the weekly content-drop calendar for our main title"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head". Close with your own reason for this role, because the pack does not know it | F5, F6, F4 and F7. It is the question every conversation opens with and it is scored |
| D2 | "What mobile games do you play, and what do you notice about how they run their events?" | JD | [generic] | Name games you actually play and one observation about how one runs its events that you would defend. Do not claim to have analysed another game's economy. The guidance makes no claim about your past | A casual question on the JD's live-events topic, which is scored even when it sounds friendly |
| D3 | "What made you look at Saltmarsh?" | CO | [generic] | Your own reason, in your own words. Nothing in this pack states a fact about Saltmarsh, because research did not run, so any specific you add must be one you read yourself. If you have not looked yet, say what you would want to learn first | The standard motivation probe. `[generic]` because the pack has no sourced company facts, which is the honest cost of the failed research |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: the JD asks for three years producing live-service games. Why should we count your four years as an associate producer?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" and "I ran the weekly content-drop calendar for our main title for the last two years" | Pause, then hold on the quotes: "4 years as an associate producer at a puzzle-game studio", and "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if the title was run as a live service, say how. If it was not, say so plainly and stay with the years and the calendar. If pushed twice, hold, then concede one specific thing, such as "I haven't led a team", without folding on the calendar you ran | F5 and F1. JD because it tests a stated requirement under time pressure |
| E2 | "You presented the retention numbers. How much of that was actually yours?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Hold: "I presented the monthly retention numbers to the studio head." Answer slot: if any of the numbers or the analysis behind them was yours, say which part. If none was, say so plainly and say what you did own, within the quote. Concede explicitly and specifically, and do not fold on what you did present | F3 and F7. EXP because the probe exists to catch inflation |

### F. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | An open prompt, so choose the instance. Pick a time with a named stake, a moment you did not soften it, and a working relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which in your words is "I presented the monthly retention numbers to the studio head". Whether any of those numbers were unwelcome is yours to say, and the pack does not assume it | The standard Values stem. No published Saltmarsh values were available, so the theme is generic |
| F2 | "When did you put the players ahead of an internal metric?" | VAL | [generic] | An open prompt, so choose the instance. Pick a time with a real trade-off, a decision you made or influenced, and a result you can state without embellishing. If none comes to mind, say so plainly, then say how you would weigh it. The guidance makes no claim about your past | The customer-over-metric stem. `[generic]` because it names no sourced Saltmarsh value |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "You sit between design, art, engineering and community. Where does your job end and theirs begin, and what happens when you disagree?" | JD | [generic] | Offer seam principles, not a fixed line: you own the calendar and the information, they own their craft and estimates. Then a disagreement shape: state your view, hear theirs, escalate with options. Where you have a real example, tell it in your own words. If you do not, say so plainly and describe how you would handle it | The JD's coordination line (F2) in the peer's collegial register |
| G2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | "We" for context and "I" for contribution. Your own "I" sentence is: "I wrote the release checklist our QA team still uses." Say what was yours and what other teams did, specifically. If you do not have a cross-team example beyond that, say so plainly | F4 as the one cross-team "I" you quoted |

## 11. Reverse questions

Ask the ones that fit the time left. Skip any that Tobias already answered.

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good first 90 days look like for this producer across the two titles?" | Shows you plan to learn before changing anything (B1, B3) and tells you what success means to him |
| R2 | "How are events sequenced across the two titles today, and who has the final say when two compete for the same week?" | Surfaces the real decision process behind A1, and signals you think about conflicts |
| R3 | "What does the post-event review look like today, and which KPIs does it report?" | The JD makes you its owner. Your F3 evidence is thinnest here, so you want the baseline you would inherit |
| R4 | "Of the four teams I would coordinate, which is hardest to schedule with right now?" | Tells you where the role bites (F2) and shows you are thinking about the people work |
| R5 | "How do in-app purchases figure in event planning for your titles, if at all, and what would you expect me to learn first?" | Raises your stated gap (F10) as a learning plan instead of leaving it for him to find. Ask it only if it has not already come up |
| R6 | "What would make you say, six months in, that this hire was a clear success?" | Generic, but it gets a concrete measure out of the hiring manager and ends on the future |

## 13. Prohibited claims

Built from the fit snapshot before the banks were written. No dossier was available.

| Not coached | Basis | Honest form |
|---|---|---|
| Led or managed design, art, engineering or community teams | Negative you stated, F9 | The plain acknowledgment: "I haven't led a team." Then the plan to coordinate people you do not manage. No slot |
| Has in-app purchase or monetisation experience | Negative you stated, F10 | The plain acknowledgment: "I haven't worked on a game with in-app purchases." Then the plan to learn |
| Ran a live-events calendar, or ran calendars for two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: your material says the weekly content-drop calendar for one main title |
| Owned the post-event review or its KPIs | Inflated form of F3 | F3's quote at its own scope. The pack's observation: your material says you presented the numbers, not that you ran a review |
| Has three or more years of live-service production | Inflated form of F5 | F5's quotes at their own scope. The pack's observation: your material gives four years as an associate producer and does not say whether the title was a live service |
| Owned or built the retention analysis | Inflated form of F7 | F7's quote at its own scope: "Presented the monthly retention numbers to the studio head" |

## 14. Sources

- **Provided documents:** the JD text and your background note, both in your message. No dossier, CV, recruiter notes or interviewer profile were provided.
- **Searches sent, all refused (the permission was not granted):**
  - "Saltmarsh Games mobile studio values" — refused
  - "Saltmarsh Games interview process live operations producer" — refused
  - "Saltmarsh Games strategy news mobile titles" — refused
  - "Tobias Wrenfield Saltmarsh Games Head of Live Operations" — refused
- No page was fetched.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | The VAL bank (F1, F2) would have named published values, and the cheat sheet (section 10) would exist if a values round were documented. Both are generic here, and section 10 is dropped |
| 2. Saltmarsh Games interview process, live-ops producer | unavailable | Loop structure. Persona weights would follow the named rounds instead of the relationship prior alone |
| 3. Saltmarsh Games strategy and recent news | unavailable | The CO and CASE questions would be grounded in current priorities. D3 is the only CO row and is generic |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | The interviewer read (section 7) and any persona adjustment from his published footprint. Section 7 is dropped |
| 5. Representative live-operations producer JD | skipped | You supplied the JD, which fixes the fit snapshot and the JD-tagged questions |

## 15. Upgrade menu

- Allow web search, and I will re-run the four research targets above → values page, loop structure, strategy, Tobias's public footprint: a grounded interviewer read, persona reweights and a real CO and values bank, with generic rows becoming grounded
- Who Tobias is to you (manager, skip-level, cross-functional) → reweights every bank
- The recruiter's prep email or any pre-declared task (a presentation, a take-home) → a build section for it. None was assumed
- Your own answers to the answer slots in A4, A5, B1, B2, B5, C1, C3 and E1 → the matching rows of the fit snapshot become quoted evidence and the guidance becomes story-mapped
- A sanitised sample of the release checklist you wrote, a page of your content calendar and one of your monthly retention decks → raises F4, F6 and F7 from medium to high, and gives F8 a real writing sample
- Whether the main title was run as a live service → settles F5, currently low and discovery
- A `tuesday-dossier.md` from an earlier fit assessment → verified evidence, per-gap strategies and a ranked objection, instead of the ones inferred here
- Time you have before Friday → a prep triage ordered to that time
