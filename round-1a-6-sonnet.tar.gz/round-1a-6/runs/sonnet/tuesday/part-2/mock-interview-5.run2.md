Searches were refused, so I'm building the pack from your message alone and labeling the gaps. Writing it now.
Your prep pack is saved as `kelverton-rail_senior-partnerships-manager_interview_pack.md`. The web searches were refused, so it's built only from your message. That means the CO bank (the company-and-strategy questions), your fit rows and the POV differentiation test are generic. There's no interviewer read and no values section. I also haven't seen the market report, since it wasn't pasted. I assumed Deepa is a hiring-manager-style panelist and Ross a commercial one.

Your POV is built around the thesis to lead with: judge each operator partnership by what changes for the operator, and concede that your own headline figure counts partners. The question to rehearse hardest is B2, "You've never sold into rail. How would you handle that?" The pack uses your own sentences for it and adds nothing.

Say the word and I'll run a live drill. I'd start with Ross on C1 and D1, or with your 15-minute POV against a timer.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the report's headline claims or recommendations? Those would let me replace the generic POV differentiation and the A2 report question with specifics.
Do you have the posting text? If so, I'll check the fit rows against its actual requirements.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail

Round: second round, 60 minutes, panel. Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). The first 15 minutes are a POV from you on where you would take operator partnerships over the next 18 months, no slides, landing on what it means for the operators themselves. The rest is Q&A, and Ross will push on commercials.

Built at research tier L0: the searches were refused, so nothing here comes from outside your message. The market report was not pasted, so nothing here comes from it either.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

| Tag | Meaning |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your CV claims survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem set in the role |

## Prep triage (four hours)

| Order | Time | Do | Where |
|---|---|---|---|
| 1 | 90 min | Choose your spine thesis, write the 15-minute shape, say it aloud three times against a timer | Graded deliverables, G1 to G3 |
| 2 | 60 min | Rehearse the commercial hold aloud: the two plain acknowledgments, then the figures | B2, B3, C1, C4, D1, D2 |
| 3 | 30 min | Re-read the report against the differentiation test and pick your three items | Graded deliverables, differentiation |
| 4 | 30 min | Write your answer to the requested close and your reverse questions | A5, Reverse questions |
| 5 | 30 min | One live drill | Drill offer in the message |

Everything else is insurance.

## Fit snapshot

Requirements are quoted from the recruiter's email as you quoted it to me. No posting was supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" — recruiter's email | "last 4 at a payments company running the ISV channel" — your message; "took it from 6 partners to 40" — your message | medium | [grounded] | transferability | Adjacent work: a payments channel, not operator partnerships, with nothing inspected behind it. Keep the quotes at their own scope: you ran that channel for the last 4 years, and it went from 6 partners to 40. The figure raises four slots. Answer slot: expect how the 6 and the 40 were counted, what the figure is sensitive to, the assumption behind it you would defend least, and which part was yours. Answer each in your own words; if you do not know how it was counted, say so plainly |
| F2 | "Ross will push on commercials" — recruiter's email | "roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | A commercial outcome in the quote's own terms, which is influence and not ownership. Say it as it stands: "roughly £4M of influenced revenue." Answer slot: expect how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so plainly |
| F3 | "Ross will push on commercials" — recruiter's email | "never carried a direct quota, only influenced revenue" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never carried a direct quota, only influenced revenue." Then how you would want a number defined and tracked here, said as a plan and never as a past |
| F4 | "our operator partnerships" — recruiter's email | "Never sold into rail specifically" — your message | none | [grounded] | capability | A gap you have stated. Words: "I've never sold into rail specifically." Then what you would do first to learn it, said as a plan. Nothing is added to make the gap feel smaller |
| F5 | "Please land on what it means for the operators themselves" — recruiter's email | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Adjacent work: bus and light rail network planning, from the consultancy side, which is not train operating companies and not a seat inside an operator. Say it at its own scope. Answer slot: expect a probe on where that work met operators day to day. If it did, say where, in your own words; if it did not, say so plainly and stay with network planning |

## Graded deliverables: the 15-minute POV

The deliverable is a talk, not a document. Its requested close is what it means for the operators themselves, so the last third of the talk is built around that, not around Kelverton's side of the table.

Facts you may build on, and no others about you: F1 ("took it from 6 partners to 40", "last 4 at a payments company running the ISV channel"), F2 ("roughly £4M of influenced revenue"), F4 ("Never sold into rail specifically") and F5 (the quote in that row).

| # | Thesis (a position to argue) | Facts it may draw on | Mandatory concession | Provenance |
|---|---|---|---|---|
| G1 | Judge each operator partnership by what changes for the operator, and report partner counts second | F1: "took it from 6 partners to 40" is a count | The figure on your CV counts partners, so say plainly that the measure you are proposing is not the one that figure used | [generic] |
| G2 | Go deep with a few operators before going wide, then reuse what worked | F1: the same quote runs the other way, from few to many | Depth first is slower to show a number, and Ross will ask what the number is at month six. Say you would agree the measure with him rather than name a figure you have no basis for | [generic] |
| G3 | Spend the first part of the 18 months listening to operators, because rail selling is the part you would need to learn | F4 and F5, quotes as above | It spends part of an 18-month window learning, and you should say so before he does | [generic] |

My read: lead with G1 because it answers the requested close directly, carry G2 as the sequencing, and use G3 as your closing minute, since it turns your stated gap into a plan before Ross reaches it. That is a judgment about the talk, and you may weigh it differently.

Shape, in time: one minute naming what you take "operator partnerships" to mean and asking whether that is right; three minutes on where things stand; seven minutes on the three moves across the 18 months; three minutes on what it means for the operators; one minute on what you would learn first.

Differentiation: the report came from Kelverton's own strategy team, so the panel knows it better than you do, and reciting it scores as homework. Bring one item from it, in its own words, to show you read it. Then bring one place you would go a different way, with your reason. Then name the anti-pick: one kind of operator partnership you would say no to, and the test you would use. I have not seen the report, so I cannot name any of the three for you.

The requested close, in three parts, said as a plan and with no claims about operators' internals: what an operator's team would notice change, what you would ask of them in return, and what they could hold Kelverton to.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | A live plan on the real roadmap | Highest. The first 15 minutes are a strategy talk, and Deepa is your future manager (hiring manager row) | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| B. Skeptic | Quiet probing of rail and quota | High. Both gaps are ones you named, and a future manager prices them (hiring manager row) | Rehearse the one predictable objection until it is boring; plain acknowledgment, then adjacent evidence at its own scope |
| C. Pressure | Time-boxed challenges on commercials | High. The recruiter said Ross will push on commercials | Pause, restate, hold a position through two follow-ups, concede only what is real |
| D. Data-Driven Prober | Counting questions on both figures | Medium. Both figures are on your CV, and a commercial director tests numbers | Know and say how each figure was counted, or say plainly that you do not know |
| E. Conversational | Walk-me-through and motivation openers | Low to medium. Panel openers are usually friendly, and still scored | A 90-second arc, built from your own sentences |
| F. Peer Evaluator | Seam between partnerships and commercial | Low to medium. Deepa and Ross sit side by side in the same panel (panel row) | Offer seam principles, not a claimed seam; reciprocity framing |

I weighted Deepa as hiring manager and Ross as commercial. You may know better, and if you do, say so and I will reweight.

## Question banks

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch the plan for operator partnerships over the next 18 months. What do you need to know first?" | CASE | [generic] | Say what you take "operator partnerships" to mean and check it before you structure. Then objective, segmentation, approach, metrics, risks. The question needs no claim about your past, so the guidance makes none | The POV in Q&A form, rehearsed so the same structure holds under interruption; the recruiter's email raises it |
| A2 | "Where do you agree with the strategy team's report, and where would you go a different way?" | CO | [generic] | One consensus item in the report's own words, one divergence with your reason, one anti-pick. The pack has not seen the report, so name each from your own reading | The report is the shared source, so differentiation is the scored move; see the graded deliverables section |
| A3 | "Which operator relationship would you prioritise first, and what do you do in your first 90 days?" | CASE | [grounded] "Never sold into rail specifically" | Say the sentence once, plainly, in the F4 words: "I've never sold into rail specifically." Then the plan, as a plan: who you would ask, what you would listen for, when you would commit to a view | F4 is where the gap shows up in a live problem; CASE because it scores the plan, not the past |
| A4 | "Which kind of partnership would you say no to, and why?" | CASE | [generic] | A test, not a list: name the criterion you would apply and what the answer costs you. No claims about your past | The anti-pick from the differentiation test; the role's job includes saying no |
| A5 | "What does this mean for the operators themselves? What does an operator notice at month twelve?" | CASE | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | The requested close, in three parts: what they notice, what you ask of them, what they can hold Kelverton to. Use the F5 sentence at its own scope. Answer slot: if your planning work showed what operators notice day to day, say what, in your own words; if it did not, say so plainly and stay with network planning | The recruiter asked you to land here, so it will be asked in some form; F5 is the only evidence on the operator side of the table |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically" | Pick one, from your own material, and say it first. The F4 sentence is one honest answer: "I've never sold into rail specifically." Then the plan | The Skeptic's opening question; F4 and F3 are your two stated limits |
| B2 | "You've never sold into rail. How would you handle that in this role?" | JD | [grounded] "Never sold into rail specifically"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"; "took it from 6 partners to 40" | The highest-ROI rehearsal in this pack, because it will be asked in some form. Hold: say the F4 sentence, then the F5 and F1 quotes at their own scope, in your own words. First follow-up, "plenty of people say that": return to those quotes and add nothing. Second, "who would you learn from first": a plan, not a past. Concede in these words: "Rail is the part I'd need to learn, and I'd say so on day one." Never fold on what the quotes carry, and never stretch them | F4 and F5 are the objection and its only adjacent evidence; JD because it scores the listed job |
| B3 | "You've never carried a direct quota. Why should we trust you with a number?" | EXP | [grounded] "never carried a direct quota, only influenced revenue"; "roughly £4M of influenced revenue" | Plain acknowledgment first: "I've never carried a direct quota, only influenced revenue." Then the figure at its own scope: "roughly £4M of influenced revenue." Answer slot: expect how it was counted and which part was yours; say in your own words, or say plainly that you do not know how it was counted. Do not describe the number as ownership | F3 is the commercial objection Deepa will also price; EXP because it tests attribution |
| B4 | "Why leave payments for rail, and why now?" | EXP | [grounded] "last 4 at a payments company running the ISV channel" | Your reason is yours alone, and the pack does not supply one. Answer slot: give your actual reason in your own words, tied to operators and partnerships; if you cannot yet say it plainly, work it out before Tuesday. Keep the 4 years at their own scope | Motivation consistency is the Skeptic's core test; EXP because it checks your story against your history |

### C. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Roughly £4M influenced. How much of that was actually you?" | EXP | [grounded] "roughly £4M of influenced revenue"; "took it from 6 partners to 40" | Pause and restate. Hold the two quotes at their own scope. Answer slot: say what you counted as influenced and which part was yours, in your own words; if you do not know how it was counted, or part of it was not yours, say so plainly and return to the quotes. Hold through two follow-ups, concede specifically, and never fold on what the quotes carry | The attribution probe that exists to catch inflation; F2 and F1 are its targets |
| C2 | "Sixty seconds: why you over a candidate who has sold into rail?" | JD | [grounded] "Never sold into rail specifically"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"; "took it from 6 partners to 40" | Three beats, each a quote at its own scope, then the concession: "I've never sold into rail specifically." Let the interviewer draw the inference; do not assert what your work proves. Hold through two follow-ups by returning to the quotes | Time-boxed pressure on the same objection as B2; JD because it scores fit for the listed job |
| C3 | "A partner who brings us revenue is hurting an operator relationship. Which do you protect, and what do you tell each?" | CASE | [generic] | State the trade-off, ask what you need to know, make a call, and say what would change it. The question needs no claim about your past, so the guidance makes none | The role's operator-first brief against a revenue-first partner; the recruiter's email raises the operator close |
| C4 | "What number would you put on your first 18 months, and what would make you miss it?" | CASE | [grounded] "never carried a direct quota, only influenced revenue" | Do not invent a figure. Either say what you would need to know and when you would commit to one, or ask what the role's number is today. Say the F3 sentence once if it comes up, then pivot to how you would want it defined. List what would make you miss it, as risks | Ross pushing on commercials, in the form a commercial director asks it |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the £4M was counted." | EXP | [grounded] "roughly £4M of influenced revenue" | Answer slot: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Say each in your own words; if you do not know how it was counted, say so plainly. Name the weakest assumption before he does | A headline metric always gets a defend-the-number question; F2 |
| D2 | "Six to forty: what counted as a partner, and which assumption would you defend least?" | EXP | [grounded] "took it from 6 partners to 40" | Answer slot: what counted as a partner at the start and at the end, whether the count is sensitive to that, and which part was yours, in your own words. If you do not know, say so plainly | The second headline figure; F1 |
| D3 | "What commercial terms have you negotiated with a partner?" | JD | [grounded] "last 4 at a payments company running the ISV channel" | Answer slot: Ross will push on commercials, so expect this. If you negotiated or set terms, say which and what was yours to decide, in your own words; if you did not, or they were set by someone else, or there were none, say so plainly and return to the channel you ran | The recruiter's warning about commercials, in its likeliest form; the guidance does not assume any terms were yours |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"; "9 years in partnerships, last 4 at a payments company running the ISV channel" | A 90-second arc in your own words: the planning years, the partnerships years, the last 4. Use each quote at its own scope and add nothing between them | Casual openers are still scored; F5 and F1 are the arc's only sources |
| E2 | "What drew you to Kelverton?" | CO | [generic] | Your reason, in your own words. The pack has no researched facts on Kelverton and supplies none. Tie it to something you read in the report, which only you have read | A motivation opener; generic because the pack could not research the company |

### F. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Partnerships and commercial sit side by side. Where is the seam, and what happens when we disagree about a deal?" | JD | [generic] | Offer seam principles, not a claimed seam: what you would want agreed up front, and how a disagreement gets decided. Reciprocity: what you bring to Ross's team, not only what you need | Both panelists are in the room; the seam is the likeliest peer probe |
| F2 | "How do you handle credit when a deal spans partnerships and sales?" | EXP | [grounded] "roughly £4M of influenced revenue" | Your figure is influenced revenue, so expect the credit probe. Answer slot: if you agreed how credit was split, say how, in your own words; if no split was agreed, or it was not yours to set, say so plainly and return to the figure at its own scope | The peer-packaged form of C1; F2 |

## Requirement coverage

| Requirement | Questions |
|---|---|
| "where you'd take our operator partnerships over the next 18 months" | A1, A2, A3, A4, the POV build |
| "Please land on what it means for the operators themselves" | A5, C3, the POV build |
| "Ross will push on commercials" | B3, C1, C4, D1, D2, D3, F1, F2 |
| "no slides needed, just talk us through it" | The POV build, A1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would you want to be true of operator partnerships at month eighteen that is not true today?" (Deepa) | It gets her measure of success and ties straight to your POV |
| R2 | "How is partnership success measured on the commercial side today, and where do partnerships and commercial disagree on it?" (Ross) | It shows you expect to be held to a number and want the definition |
| R3 | "What do operators say about Kelverton that surprises you?" | It keeps the conversation on operators, your requested close |
| R4 | "What did the report leave unsettled that you would want this role to help answer?" | It engages the shared source without reciting it |
| R5 | "What would a strong first 90 days look like for someone who has not sold into rail?" | It turns your stated gap into a plan they define |
| R6 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity, aimed at the commercial side of the table |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Carried a number or quota | Negative you stated, F3 | "I've never carried a direct quota, only influenced revenue." No slot |
| Sold into rail | Negative you stated, F4 | "I've never sold into rail specifically." No slot |
| Generated, closed or owned the £4M | Inflated form of F2 | F2's quote at its own scope: "roughly £4M of influenced revenue." The limit is the pack's observation: the quote says influenced, not owned |
| Built the ISV channel from nothing | Inflated form of F1 | F1's quotes at their own scope: you ran the channel for the last 4 years, and it went from 6 partners to 40 |
| Worked on train operating company scheduling or rostering from the operator side | Inflated form of F5 | F5's quote at its own scope: bus and light rail network planning, from the consultancy side |

## Sources

Provided: your message, including the recruiter's email as you quoted it. The market report was read by you and not supplied to me, so none of it is used.

Research tier: L1 — searches 6 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Search refused. Would have moved: published value names for VAL themes. No values-style round is detected, so no cheat sheet was due either way |
| 2. Kelverton Rail interview process | unavailable | Search refused. Would have moved: loop structure. Persona weights rest on the recruiter's own description of this session instead |
| 3. Kelverton Rail strategy and recent news | unavailable | Search refused. Would have moved: the grounding brief and the CO questions, now generic |
| 4. Deepa and Ross, Kelverton Rail | unavailable | Both searches refused. Would have moved: the interviewer read, absent, and the interviewer-linked reverse question |
| 5. Representative role JD | unavailable | Search refused. Would have moved: JD-derived requirements, now only the recruiter's own words |

Queries sent, all refused: "Kelverton Rail company values"; "Kelverton Rail interview process partnerships manager"; "Kelverton Rail strategy train operating companies scheduling software news"; "Deepa VP Partnerships Kelverton Rail"; "Ross Commercial Director Kelverton Rail"; "Senior Partnerships Manager rail technology train operators job description".

## Upgrade menu

- The report's headline claims and recommendations, pasted → A2 and the differentiation test become specific, and CO questions move from generic to grounded
- The posting text → the five fit rows gain JD-quoted requirements, and any requirement beyond the recruiter's words gets its own question
- Search access, or the Kelverton values and strategy pages pasted → the grounding brief, a values check and strategy-grounded CO questions
- Interviewer surnames or profile links → an interviewer read, retuned persona weights and a reverse question tied to their own paths
- A one-line reply from the recruiter on what "operator partnerships" covers → the POV's opening minute stops resting on an assumption
- The report or sheet that shows how the £4M and the 6-to-40 were counted → F1 and F2 can move from medium to high, and D1, D2 and C1 get quotes to rest on
- Your own words on the answer slots in D1, D2, D3, F2 and A5, said outside a drill → those rows regenerate with your sentences in them
- A `tuesday-dossier.md` → verified evidence and a prohibited list from an earlier pass, if you have one
