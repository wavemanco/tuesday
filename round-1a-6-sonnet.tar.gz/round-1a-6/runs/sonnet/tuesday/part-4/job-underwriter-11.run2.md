Web search wasn't granted, so I'm assessing both roles from the text you pasted. I'll mark below what that leaves unchecked.

# Role A: Operations Analyst, Duinvaart Cold Chain (Rotterdam)

## Decision snapshot

**Yes, this is worth your time. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: A1 (Hybrid, three days a week in the Rotterdam office)
- `must_have` — direct: A2, A3, A4, A5a · unclear: A5b (Temperature compliance tracking)
- `important` — adjacent: A6 (Work with depot managers on route changes)
- `preferred` — adjacent: A7 (Dutch a plus)

A5b — nothing in your background on temperature data yet; A6 — a credible bridge, its limit named; A1 — open until you say where you can work.

**Opportunity ledger.** The outputs are concrete (RR4). The employer and posting are unverified (RR3), and the salary is withheld (RR2). Temperature compliance is the one duty with no stated data source (RR1).

- **Hard gates:** none failed; unconfirmed: A1 (Hybrid, three days a week in the Rotterdam office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you can do three office days a week in Rotterdam (A1); (2) the posting and employer check out (RR3); (3) your route-review work is framed as performance review, not route decisions (A6).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam, with a refrigerated fleet | `[grounded]` posting |
| Mandate | Track on-time delivery and temperature compliance, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` posting |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` posting |
| Scope read | An analyst post with named outputs and named counterparts, and no mention of team or budget | `[inferred]` from the posting's responsibilities |
| Market calibration | Not calibrated; no search ran, and the posting states no salary | `[grounded]` posting silent on pay |
| Unknowns | Salary; data source for temperature compliance; whether the role changes routes or only advises; employer details | — |
| Contradictions | None within the posting | `[grounded]` posting only; not checked against a careers page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| A1 | Hybrid, three days a week in the Rotterdam office | hard_gate | unclear | none | hard_gate | You gave no constraints, and your work history is in Amsterdam. Whether the Rotterdam commute works is not established | `[grounded]` posting term; no statement from you | Ask whether this is workable (question A1/B1) |
| A2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier, which is typed self-report with no inspectable artifact yet | `[grounded]` your background | none |
| A3 | Strong SQL | must_have | direct | medium | none | SQL daily; "strong" is a level this evidence doesn't test | `[grounded]` your background | none |
| A4 | Power BI or Tableau | must_have | direct | medium | presentation | Power BI daily, including the on-time delivery dashboard depot managers use. Whether you built it or maintained it is unstated; I read it at the lower level | `[grounded]` your background | Confirm your role on the dashboard (question A6) |
| A5a | Track on-time delivery | must_have | direct | medium | none | The on-time dashboard and weekly route-performance review match this duty directly | `[grounded]` your background | none |
| A5b | Track temperature compliance on a refrigerated fleet | must_have | unclear | none | discovery | Nothing in your background mentions temperature or cold-chain data. Parcel carriers may or may not hold such data; this is open | `[grounded]` silence in your background | Ask (question A5b) |
| A6 | Work with depot managers on route changes | important | adjacent | medium | transferability | You ran the weekly route-performance review for depot managers. The limit: reviewing performance is not stated as proposing or deciding route changes | `[grounded]` your background; limit named | Ask (question A6) |
| A7 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational Dutch is partial credit. The limit: no stated level beyond "conversational" | `[grounded]` your statement | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| GA1 | Office days in Rotterdam (A1, hard_gate) | hard_gate | No location or schedule constraint from you | A failed gate would end this regardless of fit | n/a: the question is whether the gate is met | Your own confirmation | `[grounded]` no constraint given |
| GA2 | Temperature compliance (A5b, must_have) | discovery | Silence on temperature or cold-chain data | It's the duty most specific to this employer, and the one a hiring manager is likeliest to probe | Reporting on temperature-controlled parcels or pharma or food shipments; excursion or SLA-breach reporting; sensor or telematics data in your dashboards | A dashboard screenshot (sanitised) or a report description | `[grounded]` background silent; `[inferred]` that it's the likeliest probe, since the posting names it |
| GA3 | Route changes with depot managers (A6, important) | transferability | Weekly review ran, but changes made or proposed are not stated | It decides whether you describe yourself as informing or driving route changes | A route change you recommended after a review; depot-manager meetings that ended in a decision | A review deck or a before/after on-time figure | `[grounded]` background; limit named |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Temperature compliance source unspecified | unknown | — | "temperature compliance across our refrigerated fleet" | The role may depend on telematics or sensor data you'd have to learn, or on data the team doesn't yet collect well | `[inferred]` from the posting naming the duty without naming a data source | Which systems hold the temperature data, and who owns their quality? | unresolved |
| RR2 | Salary withheld | unknown | — | no figure in the posting | The pay may fall below what you need, or the company may not publish pay; I can't compare it to a market band here | `[grounded]` posting is silent; no band checked | What is the salary range for this post? | unresolved |
| RR3 | Employer and posting not verified | unknown | — | "Duinvaart Cold Chain, Rotterdam" | No search ran, so I can't tell whether the posting is live or matches the company's own careers page | `[grounded]` research did not run | Is this role live on your own careers site, and who would I report to? | unresolved |
| RR4 | Clear outputs and counterparts | positive_signal | — | "build weekly dashboards in Power BI, and work with depot managers" | The role has defined deliverables and named stakeholders | `[grounded]` posting | Who reads the weekly dashboards today? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead the CV with the on-time delivery dashboard depot managers use, and the weekly route-performance review you ran, in your own words | A2, A4, A5a, A6 | `[grounded]` your background | pending your approval |
| P2 | Say plainly where you stand on temperature data, and don't claim cold-chain experience you can't name | A5b | `[grounded]` A5b row | pending your approval |
| P3 | Ask RR1, RR2 and RR3 verbatim at the first call | The register doubles as interview preparation | `[grounded]` register | pending your approval |

Interview preparation is a separate job; mock-interview does it once you've applied.

# Role B: Supply Planner, Kroonhaven Foods (Utrecht)

## Decision snapshot

**Probably not worth your time. Status: `no_go`, because B2, B3 and B6 (all `must_have`) are `absent`.**

**Fit ledger.**

- `hard_gate` — unclear: B1 (On-site in Utrecht)
- `must_have` — adjacent: B4 (Run the weekly S&OP meeting), B7 (Fluent Dutch) · unclear: B5 (Advanced Excel) · absent: B2 (3+ years supply or demand planning in FMCG), B3 (Own the 13-week supply plan), B6 (SAP IBP or a similar planning system)
- `preferred` — none present

B4 — a credible bridge, its limit named; B2, B3 and B6 — no planning evidence to bridge from.

**Opportunity ledger.** The scope is clearly defined (RR7). The employer and posting are unverified (RR6) and the salary is withheld (RR5).

- **Hard gates:** none failed; unconfirmed: B1 (On-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** evidence of planning work you haven't mentioned (forecasting, capacity or S&OP inputs), a planning-system exposure, and Dutch at working fluency. Your own account says none of these exists.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, Utrecht, chilled ready-meals | `[grounded]` posting |
| Mandate | Own the 13-week supply plan, balance production capacity against the forecast, run the weekly S&OP meeting | `[grounded]` posting |
| Working pattern | On-site in Utrecht | `[grounded]` posting |
| Scope read | A full planning-ownership role, not an analyst support post | `[inferred]` from "own" and "run" in the posting |
| Market calibration | Not calibrated; no search ran, and no salary is stated | `[grounded]` posting silent on pay |
| Unknowns | Salary; planning system in use; team size | — |
| Contradictions | None within the posting | `[grounded]` posting only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| B1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | No constraint from you, and your work history is in Amsterdam | `[grounded]` posting term; no statement from you | Ask (question A1/B1) |
| B2 | 3+ years supply or demand planning in FMCG | must_have | absent | none | capability | You've never worked in planning, and a parcel carrier isn't FMCG. A years-of-experience requirement is a screening risk, not a gate | `[grounded]` your statement | Closure path: a planning-adjacent role first |
| B3 | Own the 13-week supply plan and balance capacity against forecast | must_have | absent | none | capability | No planning ownership in your background | `[grounded]` your statement | Same closure path |
| B4 | Run the weekly S&OP meeting | must_have | adjacent | medium | transferability | You ran a weekly route-performance review. The limit: that was operational performance, not a cross-functional supply and demand meeting | `[grounded]` your background; limit named | none |
| B5 | Advanced Excel | must_have | unclear | none | discovery | Your background names SQL and Power BI and is silent on Excel | `[grounded]` silence | Optional: say what you've built in Excel |
| B6 | SAP IBP or a similar planning system | must_have | absent | none | capability | Power BI is a reporting tool, not a planning system, and nothing else is stated | `[grounded]` your background | Closure path: a course or sandbox |
| B7 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational is below fluent, and a planning role that runs a meeting in Dutch will test this | `[grounded]` your statement | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| GB1 | On-site in Utrecht (B1, hard_gate) | hard_gate | No constraint from you | A failed gate would end this | n/a | Your confirmation | `[grounded]` no constraint given |
| GB2 | Planning core (B2, B3, B6) | capability | No planning evidence | Three must-haves are open, and no wording closes them | Realistic closure is a demand-analyst or planning-support role, then a planner post | A planning course certificate | `[grounded]` your statement; `[generic]` that stepping-stone roles are a common route |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR5 | Salary withheld | unknown | — | no figure in the posting | Pay may not match a planner's level; no band was checked | `[grounded]` posting silent | What is the salary range for this post? | unresolved |
| RR6 | Employer and posting not verified | unknown | — | "Kroonhaven Foods, Utrecht" | No search ran, so I can't tell whether the posting is live | `[grounded]` research did not run | Is this role live on your own careers site? | unresolved |
| RR7 | Clear scope and cadence | positive_signal | — | "13-week supply plan … weekly S&OP meeting" | Defined outputs and rhythm | `[grounded]` posting | Who sits in the S&OP meeting today? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P4 | Don't spend application effort here unless planning evidence turns up | B2, B3, B6 | `[grounded]` map rows | pending your approval |
| P5 | Target planning-adjacent analyst roles as a step toward this one | GB2 | `[generic]` role-family pattern | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches, one per company, were refused. They would have confirmed the postings are live and moved RR3 and RR6 |
| 2. Role-family sweep | unavailable | Two salary searches, one per role, were refused. They would have given a market band for the calibration rows and RR2 and RR5 |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Upgrade menu

- Each company's careers page link → RR3 and RR6 close.
- The salary range → RR2 and RR5 close.
- Your answer on temperature or cold-chain data → A5b moves from `unclear`.
- A sanitised dashboard screenshot → A4 can rise toward `high`.
- Permission to search (up to 5 more searches and 2 more fetches) → a deeper pass on both employers.

Do you want a `tuesday-dossier.md` saved for either role, so a later step can read it?

**Questions** (all answerable in a line):

A1/B1 — Where are you based, and can you do three office days a week in Rotterdam for A, or full on-site in Utrecht for B? Is there any pay floor or other non-negotiable I should check against?

A5b — Have you handled temperature, cold-chain or time-critical shipment data at the carrier, and what did you do with it?

A6 — Did you build the on-time dashboard or maintain it, and did your weekly review ever lead to a route change you proposed or made?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.