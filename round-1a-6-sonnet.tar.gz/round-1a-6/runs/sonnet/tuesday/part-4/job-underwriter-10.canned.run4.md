I'm reading the job-underwriter playbook's reference files, and I'm about to run the allowed company checks on Fernquay. Then I'll write the full assessment.
**Yes, it's worth applying, and I found nothing suggesting it isn't legit. Status: `go`.** Everything in the posting that I could check matches what Fernquay publishes (RR1). The WhatsApp message asks for a call and nothing else.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — direct: R1
- `must_have` — direct: R2, R3, R4, R5 · adjacent: R6 (Own the booking flow end to end)
- `important` — adjacent: R7 (First designer, no peers), R8 (Research calls with school owners)

R6 (`medium`) — checkout is one part of a booking flow, not all of it; R7 (`medium`) — squad experience, never solo, the thing to be upfront about.

**Opportunity ledger.** The employer is established and consistent across the sources I read (RR1), and the pay sits inside the sweep's band (RR5). Equity terms (RR2), support for a first designer (RR3) and runway for a customer-funded firm (RR4) are unknowns to ask about. The WhatsApp message asks for a 45-minute video call, with the invite sent by email. Arranging a call by chat is routine, so it gets no register entry.

- **Hard gates:** none failed (R1 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** a request for money, a cheque, bank or ID details, or the invite turning out not to come from Fernquay's own domain. Weak answers on RR2–RR4 would also change it.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. Six people, Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle, funded by its customers | `[grounded]` fernquay.example/about |
| Mandate | First design hire: own the booking flow, run research calls with school owners, ship with two engineers | `[grounded]` posting and careers page |
| Working pattern | Hybrid, two days a week in Galway | `[grounded]` posting and careers page |
| Hiring contact | Ronan Kehoe is listed as co-founder and CEO. He was previously product lead at a Galway travel-software company for five years, which is close to your travel-booking background | `[grounded]` LinkedIn search result (not opened) |
| Scope read | One designer owning one product surface with direct access to two engineers and the founders is a normal scope for a first design hire at a company this size | `[inferred]` from the posting's responsibilities |
| Market calibration | Product designers with 3–5 years in Ireland: median €57,000, interquartile range €51,500–€62,000 (Tillerby 2026, n=520). The posted €52,000–€60,000 sits inside it. The equity (0.5–1%) has no terms to value | `[generic]` role-family sweep; `[grounded]` posted range |
| Unknowns | Equity terms; runway; who sets design priorities | — |
| Contradictions | None between the posting, the careers page and the about page | `[grounded]` careers page fetched, about page read in search result |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week in the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year, so the office days are workable. Your own statement, not yet probed | `[grounded]` your message | none |
| R2 | 3+ years of product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company | `[grounded]` your background | none |
| R3 | Strong Figma | must_have | direct | medium | presentation | Daily use stated. A Figma file would make it inspectable | `[grounded]` your background | Offer: a file or case-study frames |
| R4 | Has run your own user research | must_have | direct | medium | none | Monthly usability sessions with customers you ran. Usability testing is the stated evidence, not discovery interviews | `[grounded]` your background | none |
| R5 | Works directly with engineers | must_have | direct | medium | none | Squad with four engineers | `[grounded]` your background | none |
| R6 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned checkout for a travel-booking product. Limit: checkout is part of a flow, and the evidence doesn't say you owned search, selection or confirmation | `[grounded]` checkout redesign; `[inferred]` that end-to-end ownership is a wider scope | See G1 |
| R7 | First designer, no design peers (inferred from "our first designer") | important | adjacent | medium | transferability | You have always had design colleagues. Limit: no experience setting priorities or tooling alone | `[grounded]` your statement; `[inferred]` requirement from the posting | See G1 |
| R8 | Research calls with school owners | important | adjacent | medium | discovery | Customer sessions are shown. Whether those customers were business owners, and whether any sessions were discovery rather than usability, isn't stated | `[grounded]` your background | See G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | First designer, owning a whole flow (R6, R7) | transferability | Checkout ownership inside a squad; no solo-designer or whole-flow scope on record | The posting's central promise is ownership, so this is where interviewers will probe | Adjacent: running your own usability programme and driving checkout to ship. Limit: you worked with design peers and a larger product surface. Strengthener: the case study they already liked, plus an honest account of what you decided yourself | The checkout case study and any shipped metrics | `[inferred]` bridge from your stated work; `[generic]` that first-designer roles probe this |
| G2 | Research with business owners (R8) | discovery | Customer sessions, but the customer type and session type are not stated | Owner calls are named as part of the job | Sessions with agents, hosts or operators rather than travellers; interviews that shaped a roadmap rather than testing a screen | A session guide or a findings write-up | `[grounded]` your background is silent on this |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer matches the posting | positive_signal | — | "Six people, based in Galway" | Product, size, location and the open role agree across the about page, the careers page and the posting | `[grounded]` about page and careers page | Who will be on the call, and who will I work with day to day? | noted |
| RR2 | Equity terms unstated | unknown | — | "0.5–1% equity" | The percentage may come without vesting, option strike or share-class detail | `[generic]` early-stage hiring pattern | What are the vesting schedule, the strike price and the current share count behind the 0.5–1%? | unresolved |
| RR3 | First designer with no stated design support | unknown | — | "You would be our first designer" | Priorities may come from two founders with limited design direction | `[inferred]` from the posting's silence on who sets design priorities | Who decides design priorities, and how are disagreements settled? | unresolved |
| RR4 | Customer-funded runway | unknown | — | "funded by its customers" | A company funded by customers has no investor runway. That can mean stability or a thin cushion | `[generic]` bootstrapped-company pattern | How many months of runway does the current revenue cover, and how is this hire funded? | unresolved |
| RR5 | Pay in line with market | positive_signal | — | "€52,000–€60,000" | The range is stated and sits inside the Irish sweep for 3–5 years' experience | `[grounded]` posting; `[generic]` Tillerby band | Is the range negotiable within the band? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Accept the call. Open with the checkout case study, since the message says they liked it | See R6 | `[grounded]` the WhatsApp message | pending your approval |
| A2 | Before the call, check that the calendar invite came from a Fernquay address and that the video link matches the one in the email. If in doubt, confirm by writing to the careers page's jobs address | Routine hygiene for any invite | `[grounded]` careers page address | pending your approval |
| A3 | Be upfront that your checkout work was inside a squad and not as a sole designer, and say what you decided yourself | See R6, R7, G1 | `[grounded]` your statement | pending your approval |
| A4 | Ask RR2, RR3 and RR4 verbatim on the call | The register doubles as interview prep | `[grounded]` register | pending your approval |

Since you have a call coming, I can run interview prep and mock questions for it next in a separate step, using the mock-interview module.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway" (About Fernquay, fernquay.example/about) and "Fernquay product designer Galway careers"; fetched "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer). Moved role reality's organization row, the contradictions row and RR1 |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland startup 3-5 years experience 2026", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Moved market calibration and RR5 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe), read as a snippet and not opened. Moved the hiring-contact row and A1 |

## Dossier offer and upgrade menu

I can save all of this as a `tuesday-dossier.md` if you'd like it.

- A Figma file or the checkout case study's frames → R3 could rise to `high`.
- An answer to G2 → R8 firms up or the gap is confirmed.
- Your pay floor and any other non-negotiables → the hard-gates line can check against them.
- A deeper research pass on Fernquay (customers, funding, news; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

1. G2 — In your customer sessions, were the people you spoke to business owners or operators (not just end travellers), and did any sessions aim to discover problems rather than test a design?
2. Constraints — Is there a pay floor, office-day limit or equity stance that would rule this role out for you?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.