Researching Fernquay now: I'm checking whether the company exists, then salary norms and Ronan Kehoe's public profile.
# Job Underwriting Assessment: Product Designer at Fernquay

## Decision snapshot

**Yes, this is worth pursuing, and I found nothing in what you've shared that asks for money or personal details. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Pay €52,000–€60,000)
- `must_have` — direct: R3, R4, R5, R7 · adjacent: R6 (Research calls with school owners), R8 (Own the booking flow end to end)
- `important` — adjacent: R9 (First designer, no design peer)

R8 — checkout is one part of a booking flow, limit named; R9 — adjacent work only, never the sole designer.

**Opportunity ledger.** A small, customer-funded company whose own About page matches the posting (RR4). The posting itself is not confirmed on their site (RR1), the equity terms are unstated (RR2), and the sole-designer scope has no named support or success measure (RR3).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Pay €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the pay band clears your floor — R2; (2) Fernquay confirms the role on its own channels — RR1; (3) you get concrete answers on design support and first-year outcomes — R9, RR3; (4) the equity terms are put in writing — RR2.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. Six people, Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle, funded by its customers | `[grounded]` About page, fernquay.example/about |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship alongside two engineers, work closest with Ronan Kehoe | `[grounded]` posting |
| Terms | €52,000–€60,000 plus 0.5–1% equity; hybrid, two days a week in Galway | `[grounded]` posting |
| Scope read | Wide for one person: flow ownership, research and shipping, with no design peer or stated first-year outcomes | `[inferred]` from the posting's scope against its silence on outcomes |
| Market calibration | The posted band sits inside the middle of the range for product designers with 3–5 years in Ireland (median €57,000; €51,500–€62,000 for the middle half of respondents). This is a market band, never Fernquay's offer | `[generic]` role-family sweep, Tillerby 2026 report snippet; `[grounded]` posting for the figure |
| Counterpart | Ronan Kehoe is listed as co-founder and CEO, and previously product lead at a Galway travel-software company. That overlaps with your travel-booking background | `[grounded]` LinkedIn search result, professional footprint only |
| Unknowns | Equity vesting and share terms; who reviews design work; first-year outcomes; whether the role is listed on Fernquay's own site | — |
| Contradictions | None between posting, About page and WhatsApp message. The About page doesn't give Saoirse's title, which your message says is CTO. I couldn't find the role at the one careers address I tried | `[grounded]` About page; careers fetch returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week at the Galway office | hard_gate | direct | medium | none | You live in Galway, so the location term is met. Your willingness to attend two set days is not stated | `[grounded]` your intake statement; posting | confirm in the call that two office days works for you |
| R2 | Pay €52,000–€60,000 | hard_gate | unclear | none | hard_gate | You gave no pay floor, so I can't say whether the band meets it. The band itself is clear in the posting | `[grounded]` posting; no candidate constraint supplied | G1: state your floor |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company, self-reported with no inspectable artifact yet | `[grounded]` your background | a portfolio or case study link would raise it to high |
| R4 | Strong Figma | must_have | direct | medium | none | Daily Figma use, confirmed in your own words. Strength is not yet inspectable | `[grounded]` your background | share the checkout case study |
| R5 | You have run your own user research | must_have | direct | medium | none | Monthly usability sessions with customers, self-reported | `[grounded]` your background | none |
| R6 | Run research calls with school owners | must_have | adjacent | medium | discovery | Usability sessions are not the same kind of work as open discovery interviews with small-business owners. Whether you did interviews of that kind is unconfirmed | `[grounded]` your background; `[inferred]` on the difference in kind | G2 |
| R7 | Work directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your background | none |
| R8 | Own the booking flow end to end | must_have | adjacent | medium | discovery | You redesigned the checkout flow. Checkout is one stage of a booking flow, so end-to-end ownership is not shown | `[grounded]` your background, which says checkout | G3 |
| R9 | Work as the first designer, with no design peer | important | adjacent | low | transferability | You have not been the only designer anywhere. Owning the checkout redesign inside a squad is the nearest evidence, and its limit is that you had design colleagues or structure around you | `[inferred]` from the posting's "first designer" wording; `[grounded]` your statement | see G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay floor (R2, hard_gate) | hard_gate | No floor given, so the band can't be checked against it | A gate nobody has checked can't stay unchecked in a decision | Your current salary band, or your minimum for a move | Your own figure | `[grounded]` no constraint supplied |
| G2 | Research calls with owners (R6, must_have) | discovery | Usability sessions are confirmed. Open interviews are not | The posting names research calls with school owners as a core duty | Interviewing customers before a redesign; speaking with business owners or operators; calls that shaped a roadmap decision | A research summary, a discussion guide, or a synthesis deck | `[grounded]` background; `[generic]` that discovery and usability are distinct skills |
| G3 | End-to-end flow ownership (R8, must_have) | discovery | You redesigned checkout. The stages before it are not described | The posting asks for the whole flow | Search or availability design; confirmation and changes; mobile versus desktop; work on the stages around checkout | A flow diagram, or the case study they saw | `[grounded]` background |
| G4 | Sole-designer readiness (R9, important) | transferability | Adjacent work only | Bridge: you owned a major flow inside a squad. Limit: you haven't set up research, design process or tooling alone. Strengthener: a small solo project, or the case study's decision log | Setting up a design system; choosing what not to design; any stretch without design leadership | A project written up as "what I decided alone" | `[inferred]` bridge from stated work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed on Fernquay's own site | unknown | — | "We are six people in Galway making booking software for sea-kayak and surf schools" | The posting may be listed elsewhere on their site, or hiring may be run through a channel I didn't search | `[grounded]` careers fetch at the one address I tried returned no page; `[inferred]` that this is a thin test | Where is this role listed on your own site, and is the calendar invite coming from a fernquay address? | unresolved |
| RR2 | Equity terms unstated | unknown | — | "0.5–1% equity" | A customer-funded company has no outside valuation, so the percentage's worth depends on terms not given | `[inferred]` from "funded by its customers" on the About page | What is the vesting schedule, what share class is it, and how is the percentage calculated? | unresolved |
| RR3 | Wide scope, no stated outcomes | risk_signal | low | "own the booking flow end to end... you would be our first designer" | You may be accountable for outcomes with no design mentor and no defined measures of success | `[inferred]` from the posting's scope against its silence on outcomes | What would success look like at six and twelve months, and who reviews design work today? | unresolved |
| RR4 | Details agree across sources | positive_signal | — | "Founded 2023 by Ronan Kehoe and Saoirse Doyle" | The posting, the About page, the co-founder's public profile and the message you received all name the same people and company | `[grounded]` About page, LinkedIn result | What is the next step after this call? | noted |

The WhatsApp message asks for a video call and says an invite is coming by email. It asks for no money, no ID or bank details, and the interview is on video rather than wholly in chat. So it takes no register entry. Scheduling by message is routine, and the one check worth making is whether the email invite comes from the company's own address.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, check that the calendar invite arrived from an address on Fernquay's own domain and that the video link opens a normal video platform. Reply on WhatsApp only to confirm the time | see RR1 | `[grounded]` About page for the domain | pending your approval |
| A2 | Frame checkout as the part of the booking flow you redesigned. Offer to describe how you would approach the stages around it | see R8; claim kept at what you stated | `[grounded]` your background | pending your approval |
| A3 | Ask the RR1, RR2 and RR3 questions verbatim in the call. Bring the salary question to Ronan | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A4 | Mention your four years in travel booking, which overlaps with Ronan's earlier work in travel software | see Role reality, Counterpart row | `[grounded]` his public profile | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway", which returned "About Fernquay" (fernquay.example/about); fetched that page, which matched the posting. Fetched fernquay.example/careers, which returned no page. Moved role reality's organization and contradictions rows, and RR1 |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland Galway startup first designer equity", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). I read the snippet only. Moved the market calibration row |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe). Moved role reality's counterpart row and plan row A4. Saoirse has no search of her own, and her surname comes from the About page |

## Closing

I can write this up as a `tuesday-dossier.md` if you'd like to keep it for later steps.

**Upgrade menu**
- Your pay floor → R2 resolves, and the decision becomes `go` or `no_go` on pay.
- The checkout case study they saw, or a link to your portfolio → R3 and R4 can rise to `high`, and G3 can be answered from it.
- A research summary or discussion guide from your usability sessions → R5 and R6 gain an inspectable artifact.
- The company's own answer on where the role is listed → RR1 closes.
- A deeper research pass on Fernquay (customers, funding, news; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

G1 — What is the lowest salary you'd accept for this move, and does the €52,000–€60,000 range clear it?

G2 — At your Dublin job, did you ever run open interviews with customers before a design existed, as opposed to testing one? What did you ask and what changed because of it?

G3 — Does your checkout redesign include the stages before payment (search, availability, choosing options), or did it start at checkout?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.