I've run three searches (employer, pay band, team lead). Next I'll fetch the employer's careers page to check that the posting is live and matches the advert.
## Decision snapshot

**Yes, apply, once two things check out. R1 and R2, the hard gates, are met on what you state. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3, R6 · adjacent: R5 (Care of housebound adults at home) · unclear: R4 (Clear, timely records on the electronic patient record)
- `important`: direct: R7a, R8 · adjacent: R10 (Own small caseload and care planning), R11 (Leg-ulcer care) · unclear: R7b (Continence care), R9 (End-of-life visits)
- `preferred`: absent: R12 (Doppler assessment)

R5 is a credible bridge with its limit named; R4 is a gap in the CV that you can probably answer; R12 is a named gap with a question for the employer.

**Opportunity ledger.** The advert states its own terms: a supported small caseload (RR3) and a pay range (RR2). Shifts and on-call (RR5), mileage on pool cars (RR4) and whether the posting is live on the employer's own page (RR1) are unconfirmed.

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed on Calderbrook's own careers page (RR1); (2) your record-keeping experience is confirmed in your own words (R4, G1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract. Founded 2015, 410 staff, four locality hubs | `[grounded]` "About Calderbrook Community Health" page, fetched |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin administration, care planning, on an electronic patient record | `[grounded]` advert |
| Caseload and support | A small caseload of your own, supported by a senior community nurse | `[grounded]` advert |
| Scope read | Written as a first-caseload post for a newer community nurse, not a lone-working senior one | `[inferred]` from "small caseload" and "supported by a senior community nurse" |
| Team lead | Rhiannon Mabbott is named as Community Nursing Team Lead. A forum speaker page describes her as leading the Halifax district nursing team after eleven years as a district nurse, and says she spoke in 2025 on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` speaker page, read from the search snippet only |
| Market calibration | A 2026 survey of England community staff nurses at Band 5 (n=1,240) reports median basic pay £34,300 and an interquartile range of £32,400 to £36,600. 61% of respondents were paid mileage and 24% had a pool or lease car. The advert's £31,050–£37,800 is wider than that interquartile range. This is a survey pattern, not Calderbrook's offer | `[generic]` one survey, read from the search snippet; `[grounded]` advert for its own figures |
| Unknowns | Shift pattern and weekends, on-call, induction length before your own caseload, whether Doppler training is provided, closing date, and whether mileage is paid on pool-car journeys | `[grounded]` advert silent on each |
| Contradictions | None found between the advert and the About page. The careers page could not be opened, so the advert has not been cross-checked against it | `[grounded]` About page fetched; careers fetch returned no page |

## Evidence map

R1 and R2 are met on your word and are not checked. The checks are yours: your NMC register entry for R1 and your DVLA driving record for R2. I haven't repeated or used your PIN.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | Registration is stated as active, with revalidation due March 2028. It is your statement and nothing has been inspected, so it is `medium` | `[grounded]` CV | You check your own NMC register entry is current |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Category B licence stated. Pool cars are provided, which the advert gives as the way the post is driven | `[grounded]` CV and advert | You check your licence record is current |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward. A length-of-experience requirement is graded like any other, not as a gate | `[grounded]` CV | none |
| R4 | Clear, timely written records, on an electronic patient record | must_have | unclear | low | discovery | The CV says nothing on record-keeping or systems. Five years on a ward and home visits make some documentation likely, but nothing is stated. A pattern is not evidence of your records | `[grounded]` CV silence; `[generic]` that ward and home-visit nursing involve written records | G1 |
| R5 | Care of housebound adults in their own homes | must_have | adjacent | medium | transferability | 18 months on a discharge-to-assess team, visiting patients at home in their first week after discharge. Limit: short post-discharge episodes, not an ongoing housebound caseload | `[grounded]` CV | Make the bridge and its limit visible (E1, E3) |
| R6 | Wound care | must_have | direct | medium | none | Wound care including pressure ulcers and surgical wounds is stated | `[grounded]` CV | none |
| R7a | Catheter care | important | direct | medium | none | Catheter care is stated | `[grounded]` CV | none |
| R7b | Continence care beyond catheters | important | unclear | low | discovery | The CV names catheter care only. I don't widen it to continence care | `[grounded]` CV | G3 |
| R8 | Insulin administration | important | direct | medium | none | Insulin administration is stated. The advert pairs it with care planning, which is carried in R10 | `[grounded]` CV | none |
| R9 | End-of-life visits | important | unclear | low | discovery | The CV is silent on end-of-life care. Acute medical wards often care for dying patients, which may be a lead, but nothing is stated | `[grounded]` CV silence; `[generic]` that acute medical wards often care for dying patients | G2 |
| R10 | Hold a small caseload and care-plan | important | adjacent | medium | transferability | You told me you have never held your own caseload. The nearest work is the discharge-to-assess visits. Limit: whether those visits were independent, and any care planning in them, is not stated | `[grounded]` your statement and CV | E3 |
| R11 | Leg-ulcer care | important | adjacent | low | transferability | Pressure-ulcer and surgical wound care is near this but is a different kind of wound. Compression therapy and leg-ulcer assessment are not stated | `[grounded]` CV | G4 |
| R12 | Doppler assessment for leg ulcers (desirable) | preferred | absent | none | capability | You have never done one, so there is no evidence. Closure path: ask whether the employer trains new community staff in it (E5) | `[grounded]` your statement | E5 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Records on the electronic patient record (R4, must_have) | discovery | The CV is silent on how you recorded care or on which system | It is an essential on the advert, and it is the one `must_have` row at `unclear`. A short confirmed answer is what moves the status to `go` | Writing visit or ward notes in an electronic system; discharge-to-assess visit records; handover notes; audits of your documentation | A documentation audit result or a record-keeping competency sign-off | `[grounded]` CV silence; `[inferred]` that confirming it moves the decision |
| G2 | End-of-life care (R9, important) | discovery | Nothing stated | End-of-life visits are one of the advert's listed duties | Caring for dying patients on the ward; end-of-life care plans; family conversations; syringe-driver or anticipatory-medicine work, whatever your part was | Training certificates or a competency record | `[grounded]` CV silence |
| G3 | Continence care (R7b, important) | discovery | The CV names catheters only | It is listed beside catheter care in the advert | Bladder or bowel care on the ward; continence assessments; stoma or pad-product work | A competency record | `[grounded]` CV silence |
| G4 | Leg-ulcer care (R11, important) | transferability | Wound care is established. Leg ulcers and compression are not | Leg-ulcer care is one of the advert's first-named duties, so the limit of the bridge matters | Applying compression bandaging under supervision; assessing a leg wound as venous or arterial; tissue-viability referrals | A training certificate or competency sign-off | `[grounded]` CV; `[generic]` that compression therapy is normally taught and signed off |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not yet confirmed on the employer's own page | unknown | — | "Community Staff Nurse, Band 5 — Calderbrook Community Health CIC, Halifax" | The About page says vacancies are on the careers page, and the address I tried returned no page, so the role may simply be listed elsewhere on the site | `[grounded]` About page, careers fetch returned no page | Could you give me the reference and closing date for this role as listed on your careers page? | unresolved |
| RR2 | Pay stated, wider than the survey range | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The advert states its figures, which is a transparent term. The range is wider than a survey interquartile range for the role family, so where you start within it is a question | `[grounded]` advert; `[generic]` survey band | Where in this range would I start, given five years' post-registration experience? | noted |
| RR3 | Supported small caseload stated | positive_signal | — | "You will hold a small caseload of your own, supported by a senior community nurse" | Support is stated, though what it means in practice is not | `[grounded]` advert | What does support look like in the first months: shadowing, caseload build-up, who reviews your decisions? | noted |
| RR4 | Mileage alongside pool cars | unknown | — | "pool cars are provided" … "plus mileage" | The advert doesn't say whether mileage is paid on pool-car journeys or only on personal-car use | `[inferred]` from the two terms in one advert | Is mileage paid on pool-car journeys, or only when using a personal car? | unresolved |
| RR5 | Working pattern unstated | unknown | — | "end-of-life visits" | Visits to the dying may involve weekends, evenings or on-call, and the advert doesn't say | `[inferred]` from the listed duties against the silence on hours | What is the shift pattern, including weekends and any on-call or out-of-hours work? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | `resume_edits_pending_approval`: bring your existing line, "seconded to the discharge-to-assess team, visiting patients at home in their first week after discharge", to the top of the CV, in your own words and no wider | R5. It is the nearest evidence of home-based care | `[grounded]` CV | pending your approval |
| E2 | `resume_edits_pending_approval`: add a records line only if your G1 answer supports it, and only in what you tell me | R4 | `[grounded]` R4 row | pending your approval |
| E3 | State plainly in your supporting statement that you have not held your own caseload and have not done Doppler assessment. Say the advert's support is why this is a sensible step | R10, R12. Being clear about the limits keeps the story checkable | `[grounded]` your statement and advert | pending your approval |
| E4 | Confirm the posting on Calderbrook's own careers page before you send anything | RR1 | `[grounded]` RR1 | pending your approval |
| E5 | Use the informal chat the advert offers. Put RR3, RR4 and RR5 verbatim, and ask whether Doppler and leg-ulcer training is provided to new community staff. The speaker page says Rhiannon Mabbott has spoken on that topic | R12, R11 | `[grounded]` advert and speaker page snippet | pending your approval |
| E6 | Check your own NMC register entry and DVLA record are current before applying | R1, R2 are met on your word | `[grounded]` R1, R2 rows | pending your approval |

If you reach an interview, mock-interview can run a practice round.

## Evidence status

Verified: none yet. Your National Insurance number isn't needed for any of this. I haven't used or repeated it.

Research tier: L1 — searches 3 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax district nursing". Fetched "About Calderbrook Community Health" (calderbrookhealth.example/about). A fetch of calderbrookhealth.example/careers returned no page. Role reality's organization row is established. Posting liveness stays open (RR1) |
| 2. Role-family sweep | yes | Searched "Community Staff Nurse Band 5 district nursing salary £31,050 £37,800 Agenda for Change pay scale 2026/27", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide), read from the snippet. Market calibration `[generic]` and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott), read from the snippet. Role reality's team lead row and E5 |

## Closing

If you'd like these findings saved as a `tuesday-dossier.md` to carry forward, just say so.

**Upgrade menu**

- Your answer to G1 moves R4 and settles condition (2) for `go`.
- The live posting's reference or link from the careers page closes RR1.
- Answers to G2, G3 and G4 move R9, R7b and R11. A competency sign-off record or training certificate, the artifact nurses actually keep, would raise those rows toward `high`.
- Your pay floor, hours, distance and any other non-negotiables turn "checks against them unknown" in the hard-gates line into real checks.
- A deeper research pass on Calderbrook (staffing and leadership changes, public staff or patient reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

G1 — What records did you keep for patients you cared for, ward and discharge-to-assess visits alike? Which system was it, and how soon after a visit or shift did you write the entry?

G2 — Have you cared for patients in their last days of life? What did you personally do?

G4 — Have you applied compression bandaging or assessed a leg ulcer yourself, under supervision or otherwise? Was any training or sign-off recorded?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.