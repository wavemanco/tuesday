Quick status: I've run two searches, one on the firm and one on the pay band. Below is the full read.

# Job Underwriting Assessment: Remote Order Processing Coordinator, Velloway Logistics

## Decision snapshot

**No, don't go ahead: RR1, RR2, RR3 and RR4 are each a severe red flag, and this job is very likely a scam. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Earn up to €26 an hour plus commission)
- `must_have`: direct: R2 · adjacent: R3 (strong attention to detail), R4 (good written English)

R2 — your Excel tracker matches directly; R3 and R4 — adjacent, limits named; R1 — the posting doesn't settle your €30,000 floor.

**Opportunity ledger.** The requests for your bank, tax and passport details (RR1), a €349 payment (RR2), a cheque to lodge and forward (RR3) and a process run wholly on Telegram (RR4) are each severe. The firm can't be established (RR5), the headline rate sits far above the salaried band (RR6), and the HR contact is on a mail domain I can't tie to the firm (RR7).

- **Hard gates:** none failed; unconfirmed: R1 (Earn up to €26 an hour plus commission).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would change this:** for `no_go`, all of these would have to be true:
  - The employer is found independently on its own website, with this role listed there.
  - A written offer arrives from that employer's own domain.
  - Nothing is asked of you in payment, cheque handling or pre-offer ID and bank details.
  - A written rate and weekly hours meet your €30,000 floor (R1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Velloway Logistics; a careers-page search returned nothing, so I can't establish the firm from here | `[grounded]` search returned no results |
| Mandate | Remote order processing; 15–30 hours a week, set your own hours; "No experience needed, full training provided" | `[grounded]` posting |
| Pay as posted | "up to €26 an hour plus commission"; no guaranteed rate, no commission terms | `[grounded]` posting |
| Hiring process | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | `[grounded]` posting |
| Contradictions | The posting says full training is provided and doesn't mention buying equipment; a later message asks you to pay €349 for a "work kit". The same "equipment partner" is to receive both that payment and the balance of the cheque | `[grounded]` posting against the messages |
| Market calibration | The salaried band for order-processing and customer-operations coordinators in Ireland is a median of €31,200 a year (interquartile €28,400–€34,100), about €13.65–€16.40 an hour on a 2,080-hour year. The guide excludes commission-only and freelance work, so it is a band to expect, never this employer's offer | `[generic]` Pennoral 2026 Ireland pay guide, search snippet; `[inferred]` hourly conversion |
| Unknowns | Who the employer is; guaranteed rate; commission terms; contract type; who owns the "equipment partner" | `[grounded]` posting and messages silent |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay meeting your floor of at least €30,000 a year (posting: "Earn up to €26 an hour plus commission", 15–30 hours) | hard_gate | unclear | high | hard_gate | Confidence grades your own stated floor; fit is `unclear` because "up to" is a ceiling and commission is unquantified. At €26 an hour the floor needs about 22 hours a week all year (30,000 ÷ 26 ÷ 52), and 15 hours at €26 is about €20,280 | `[grounded]` posting and your stated floor; `[inferred]` arithmetic | Get a guaranteed rate and hours in writing through the employer's own site (see RR5) |
| R2 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel; stated and specific, no inspectable artifact yet, so `medium`, and expect a probe on formulas | `[grounded]` your message | none; a sanitized tracker would raise it to `high` |
| R3 | Strong attention to detail | must_have | adjacent | medium | transferability | About 60 tickets a day in Zendesk is real volume; it doesn't show accuracy. Limit: no error rate or quality score stated | `[grounded]` your message; `[inferred]` limit from what you haven't said | none needed at `no_go`; a quality score would strengthen it elsewhere |
| R4 | Good written English | must_have | adjacent | medium | discovery | Ticket replies are written work, but you haven't described them or your writing | `[grounded]` your message; `[generic]` that support tickets are written work | none needed at `no_go` |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay against your floor (R1, hard_gate) | hard_gate | An "up to" hourly ceiling, a 15–30 hour range and unspecified commission | A gate: wording can't solve it, only written terms can | Not applicable | A written rate and weekly hours from the employer's own domain | `[grounded]` posting; `[inferred]` that written terms would settle it |
| G2 | Attention to detail (R3, must_have) | transferability | High ticket volume, no accuracy evidence | Only matters if the role verifies | Ticket quality scores, error-free tracker weeks, audits you passed | A quality report or screenshot | `[inferred]` limit from your message |
| G3 | Written English (R4, must_have) | discovery | Written tickets implied, none described | Only matters if the role verifies | Macros you wrote, escalation emails, replies praised by customers | A sanitized reply sample | `[grounded]` your message silent on writing |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Bank, tax and passport details requested before any offer | red_flag | high | "Before your chat interview, please send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up." | Once sent, these details can't be taken back and can be used to open accounts or borrow in your name | `[generic]` pattern for requests like this | To the employer through contact details on its own website, not this chat: "Do you collect IBAN, PPS number and passport copies before an interview, and through which portal?" | confirmed |
| RR2 | Payment demanded for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | A bank transfer is hard to recover once sent; employers don't ask applicants to pay for their own work equipment | `[generic]` pattern for requests like this | See RR1's route: "Do you ask new starters to pay for equipment, and who is your equipment partner?" | confirmed |
| RR3 | Cheque to deposit, then forward most of it | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." | A lodged cheque can show as credited before it clears; if it is later returned, the money you transferred out is yours to cover. This request is very likely a scam. Don't deposit the cheque | `[generic]` how cheque clearing works and a known pattern | See RR1's route: "Do you issue cheques to new hires for forwarding to suppliers?" | confirmed |
| RR4 | Hiring process wholly on chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." | No interview you can place leaves open who you are dealing with; the sender's identity is unresolved | `[grounded]` posting | See RR1's route: "Is your hiring process really chat-only, and who would I report to?" | confirmed |
| RR5 | Employer not established from attributable sources | risk_signal | medium | "Remote Order Processing Coordinator — Velloway Logistics" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR6 | Headline rate far above the salaried band | risk_signal | medium | "Earn up to €26 an hour plus commission" | A top-of-range figure may be a headline rather than what the role pays; the band implies roughly €13.65–€16.40 an hour | `[inferred]` posting against the `[generic]` band | What is the guaranteed hourly rate, and how is commission calculated? | unresolved |
| RR7 | HR contact on a mail domain not tied to the firm | risk_signal | medium | "email velloway.hr@postmail.example" | Messages may not come from the employer the posting names | `[inferred]` from the address against the firm's name | Is this address one the employer uses, as listed on its own website? | unresolved |

Hold off on the payment, the cheque deposit and sending your details, and go no further in the chat, until you have checked each request with the employer, through contact details on the employer's own website rather than the chat or the address these messages came from; who sent them is not yet confirmed. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Stop replying in the chat for now | see RR1 to RR4 | `[grounded]` register | pending your approval |
| A2 | Don't send your IBAN, PPS number or passport photo. I haven't used the IBAN you pasted and it isn't needed for this assessment | see RR1 | `[grounded]` RR1 | pending your approval |
| A3 | Don't pay the €349 and don't lodge the cheque | see RR2, RR3 | `[grounded]` RR2, RR3 | pending your approval |
| A4 | Report the posting to the jobs site and the chat to Telegram; the Gardaí also take fraud reports | Others may be sent the same messages | `[generic]` common reporting routes | pending your approval |
| A5 | Put your effort into other openings in customer operations. Your 60-a-day Zendesk work, training two starters and the Excel tracker are the evidence to lead with. The salaried median in the pay guide is above your €30,000 floor | see R2, RR6 | `[grounded]` your message; `[generic]` the pay band | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics careers remote order processing coordinator"; no results, so the employer is not established. Moved RR5 |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator Ireland salary per hour", which returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). Moved the market calibration and RR6 |
| 3. Hiring manager's public footprint | n/a | No name was given, and a Telegram handle is not a name |

If you'd like, I can save this as a `tuesday-dossier.md` for later use.

## Upgrade menu

- A link to this role on the employer's own careers site, found independently of the chat → RR5 could close.
- A written offer from the employer's own domain, with no payment or cheque in it → RR7 and RR4 could change.
- A written guaranteed hourly rate and weekly hours → R1 and RR6 close.
- A deeper research pass on the firm (up to 5 more searches and 2 more fetches) — say the word and it runs.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.