The searches were declined, so I'm working from your message alone and have marked the research rows `unavailable`. Here is the assessment.

## Decision snapshot

**Yes, this is routine. After a written offer, asking for bank details, a PPS number and a passport is standard onboarding. The offer is worth accepting once the checks below are done. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R10 (Hybrid, two days a week in Limerick), R11 (Salary €38,000–€42,000), R12 (Right-to-work check)
- `must_have` — direct: R1, R3, R4 · unclear: R2 (Irish PAYE, PRSI and USC)
- `important` — direct: R5, R7 · adjacent: R9 (Payroll for 240 staff, monthly) · unclear: R8 (Staff payroll queries) · absent: R6 (Pension changes)

R2 — Irish tax knowledge is unstated in your background, not shown missing; R6 — a stated gap, with possible adjacent work still to surface; R9 — a larger, monthly run than the one you ran.

**Opportunity ledger.** The offer matches the posting's terms (RR4). The employer is unchecked from here (RR1), and the offer leaves the contract terms (RR3) and the pension-change handover (RR2) open.

- **Hard gates:** none failed; unconfirmed: R10 (Hybrid, two days a week in Limerick), R11 (Salary €38,000–€42,000), R12 (Right-to-work check); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer confirmed on its own website — RR1; (2) your answer on Irish payroll experience — R2; (3) the pension-change handover agreed — R6, RR2; (4) the contract terms in writing, and pay and office days within your limits — RR3, R10, R11.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick, with 240 staff on the payroll | `[grounded]` job ad |
| Mandate | Run monthly payroll, process starters, leavers and pension changes, reconcile payroll to the ledger monthly, answer staff queries | `[grounded]` job ad |
| Offer against posting | Permanent, €40,000 (inside €38,000–€42,000), hybrid with two days a week in Limerick, reporting to the Finance Manager. The offer and the ad agree | `[grounded]` ad and offer email |
| What the onboarding asks | After you accept, a portal link for bank details (salary), PPS number (Revenue) and a passport scan (right-to-work check). You bring the original passport on day one | `[grounded]` offer email |
| Is that normal | Payroll, Revenue registration and right-to-work checks need those three items. Asking for them after a written offer that names the role and pay is routine. Asking before any offer is the case your rule of thumb protects against | `[generic]` common employer practice |
| Your two in-person interviews | You met them at their office, and the offer comes from an address on the domain in their name | `[grounded]` your account |
| First-90-days outcomes | Not stated | `[grounded]` ad silent |
| Market calibration | Not done, because the role-family search did not run | — |
| Unknowns | Pension scheme or schemes, team size and cover, contract terms, training on pension changes | `[inferred]` from the ad and offer's silence |
| Contradictions | None between the ad and the offer | `[grounded]` both texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 2+ years running payroll | must_have | direct | medium | none | Three years of fortnightly payroll for 90 staff, stated by you; no inspectable artifact yet | `[grounded]` your background | none |
| R2 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | No jurisdiction or tax rules are named for the hotel-group work. The 2024 certificate may cover them, which is why this is low rather than none | `[grounded]` background silence | G1 |
| R3 | Strong Excel | must_have | direct | medium | none | Daily use, pivot tables and XLOOKUP, stated; no sample inspected | `[grounded]` your background | none |
| R4 | Payroll qualification or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024. It is stated, and the document hasn't been inspected. The ad ties it to no legal bar | `[grounded]` your background | Offer: the certificate would raise this to high |
| R5 | Process starters and leavers | important | direct | medium | none | Stated directly | `[grounded]` your background | none |
| R6 | Process pension changes | important | absent | none | discovery | You say your manager handled these. Routine pension deductions in your payroll runs may still count as adjacent work, so this is not closed | `[grounded]` your statement | G2 |
| R7 | Reconcile payroll to the general ledger monthly | important | direct | medium | none | The same task, monthly, at the hotel group | `[grounded]` your background | none |
| R8 | Answer staff payroll queries | important | unclear | none | discovery | Your background says nothing on it | `[grounded]` background silence | Raise only if the decision turns on it |
| R9 | Payroll for 240 staff, monthly | important | adjacent | medium | transferability | Credible bridge from 90 staff on a fortnightly cycle. Limit: you haven't run 240 staff or a monthly cycle | `[inferred]` bridge from your hotel-group scale | Frame as adjacent; ask RR4's question |
| R10 | Hybrid, two days a week in the Limerick office | hard_gate | unclear | none | hard_gate | The offer states it. Your own limits on days, commute or hours are not given | `[grounded]` offer, constraints not stated | G3 |
| R11 | Salary €38,000–€42,000 | hard_gate | unclear | none | hard_gate | €40,000 is inside the band. Your pay floor is not given | `[grounded]` offer, floor not stated | G3 |
| R12 | Right-to-work check | hard_gate | unclear | none | hard_gate | The offer says a passport scan serves this check. Nothing you've said settles whether any permit limit applies | `[grounded]` offer, status not stated | none needed from you unless a permit limit applies |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Irish tax rules (R2, must_have) | discovery | A payroll background with no stated jurisdiction or tax coverage | It is a must-have and it decides whether you start able to run Irish returns | Filing PAYE returns or reconciling PRSI and USC at the hotel group; the certificate's syllabus; payroll software's Irish tax tables | The certificate's module list, or a sanitized payroll summary | `[grounded]` silence; `[generic]` that interviews probe this first |
| G2 | Pension changes (R6, important) | discovery | A statement that your manager handled changes | The only duty the ad names that you haven't done | Setting up employee pension contributions, processing opt-ins or opt-outs, reconciling pension remittances | A payroll run report showing pension lines | `[grounded]` your statement; `[inferred]` that routine pension work may exist |
| G3 | Your own limits (R10, R11, hard_gate) | hard_gate | Pay inside the band, two office days stated, your limits unknown | A conflict with your own limits would outweigh the fit rows | — | — | `[grounded]` offer terms |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Marrowgate Housing, a housing association in Limerick" | The searches didn't run, so the employer is unchecked from here. A small footprint, a stale posting or an entity that doesn't match the ad are possibilities side by side, none likelier | `[generic]` pattern for employers of this size, not a claim about this one | Can you point me at this role on your own careers page, and confirm in writing the contract I'd be signing? | unresolved |
| RR2 | Pension-change handover not stated | unknown | — | "process starters, leavers and pension changes" | The post may expect pension changes from week one with no handover | `[inferred]` from the ad's duty list against R6 | Which pension scheme or schemes do the 240 staff sit in, and who would show me the process in my first weeks? | unresolved |
| RR3 | Contract terms absent from the offer | unknown | — | "reply to accept within five working days" | The offer states pay, hours pattern and reporting line, but not probation, notice, leave or pension terms | `[inferred]` from the offer email's silence | Can I have the written contract or statement of terms before I accept? | unresolved |
| RR4 | Offer matches the posting | positive_signal | — | "€40,000 a year, reporting to Declan Garvagh, Finance Manager, hybrid with two days a week in our Limerick office" | The terms, the reporting line and the in-person process are consistent | `[grounded]` ad against offer | Who covers payroll when I'm away, and who else is on the team? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check the employer on its own website, and use the contact details there for RR1's question | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask for the written terms (RR3) before you reply, and ask RR2's pension question in the same message | see RR2, RR3 | `[grounded]` register | pending your approval |
| A3 | Reply to accept within the five working days once A1 and A2 are answered | the offer's own deadline | `[grounded]` offer email | pending your approval |
| A4 | When the portal link arrives, find the portal's address on the employer's own website and compare it with the link before you enter anything. Don't send bank, PPS or passport details by plain email or chat | careful handling of those details | `[generic]` common onboarding hygiene | pending your approval |
| A5 | Bring the original passport on your first day, as the offer asks | see R12 | `[grounded]` offer email | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Marrowgate Housing Limerick housing association" and "Marrowgate Housing careers Payroll Administrator Limerick"; both were refused. They would have moved role reality's organization row and RR1 |
| 2. Role-family sweep | unavailable | Searched "payroll administrator salary Ireland Limerick"; refused. It would have moved the market calibration row and R11's comparison |
| 3. Hiring manager's footprint | unavailable | Searched "Declan Garvagh Finance Manager Marrowgate Housing"; refused. It would have moved the scope read and the plan's positioning |

I can give you a dossier file of this assessment to carry into later steps if you'd like one.

**Upgrade menu**

- The Payroll Technician certificate, or its module list → R4 to `high`, and R2 if it covers Irish tax.
- Your answer on Irish payroll experience → G1 closes R2.
- A payroll run report showing pension lines → R6 may move to `adjacent`.
- Your pay floor and office-day limits → R10 and R11 resolve and the hard-gates line firms up.
- The employer's careers page link, once you've found it → RR1 closes and the cap on `conditional_go` lifts.

**Questions**

G1 — Which jurisdiction was the hotel-group payroll in, and did you handle PAYE, PRSI and USC, or their equivalents, yourself? Did your 2024 certificate cover Irish rules?

G2 — Apart from pension changes, did your runs include pension deductions or contributions, and what did you do with them?

G3 — Is €40,000, two days a week in the Limerick office, and a start after your notice period below anything you need?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.