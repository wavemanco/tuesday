Web searches were declined, so everything below comes from what you pasted.

## Decision snapshot

**Yes, asking for bank details, PPS number and passport is routine at this stage. The check that matters is where you enter them. On the job itself: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R10 (Hybrid, two Limerick office days), R11 (€40,000 pay), R12 (Right to work, passport check)
- `must_have` — direct: R1, R3, R4, R6 · unclear: R2 (Irish PAYE, PRSI, USC)
- `important` — direct: R8 · adjacent: R5 (240 staff, monthly cycle) · unclear: R9 (Staff payroll queries) · absent: R7 (Pension changes)

R7 — pension changes, by your own account not yet done; R2 — Irish statutory knowledge not yet stated; R5 (`medium`) — same work at larger scale.

**Opportunity ledger.** Sound on what you've shown. The offer follows two in-person interviews and its pay sits inside the advertised band (RR2). Contract terms and pension-change support aren't shown yet (RR1, RR3).

- **Hard gates:** none failed; unconfirmed: R10 (Hybrid, two days a week in Limerick), R11 (€40,000 salary), R12 (Right to work, passport check); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm R2, that your payroll experience covers Irish PAYE, PRSI and USC; (2) R10, R11 and R12 all work for you; (3) you see the written contract terms before accepting (RR1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick | `[grounded]` ad header and offer |
| Mandate | Run monthly payroll for 240 staff, process starters, leavers and pension changes, reconcile payroll to the general ledger, answer staff queries | `[grounded]` ad |
| Reporting line | Declan Garvagh, Finance Manager | `[grounded]` offer |
| Working pattern | Hybrid, two days a week in the Limerick office; start date agreed after your notice period | `[grounded]` ad and offer |
| Pay | Ad band €38,000–€42,000; offered €40,000, the middle of the band | `[grounded]` ad and offer |
| Scope read | One post owning the whole monthly cycle plus ledger reconciliation | `[inferred]` from the duty list, which names no team |
| Market calibration | Not run, because the salary search was declined | `[generic]` no band available |
| Unknowns | Contract, probation, pension scheme, leave, who supports pension changes | `[grounded]` the offer is silent on all of these |
| Contradictions | None between the ad and the offer: title, hybrid pattern and pay band agree | `[grounded]` both texts as you pasted them |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 2+ years running payroll | must_have | direct | medium | none | 3 years of fortnightly payroll for 90 staff, specific, but no inspectable artifact yet | `[grounded]` your message | a reference or job description would raise to `high` |
| R2 | Working knowledge of Irish PAYE, PRSI, USC | must_have | unclear | low | discovery | Your message doesn't say which tax regime the hotel payroll ran under or what the certificate covers | `[grounded]` message silence | question G1 |
| R3 | Strong Excel | must_have | direct | medium | none | Daily use, pivot tables and XLOOKUP, confirmed and specific, nothing inspected | `[grounded]` your message | none |
| R4 | Payroll qualification or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024; the issuer isn't stated and no copy has been seen | `[grounded]` your message | the certificate would raise to `high` |
| R6 | Process starters and leavers | must_have | direct | medium | none | Done for the hotel group, confirmed, no artifact | `[grounded]` your message | none |
| R8 | Reconcile payroll to the general ledger monthly | important | direct | medium | none | You did the monthly payroll-to-ledger reconciliation | `[grounded]` your message | none |
| R5 | Monthly payroll for 240 staff | important | adjacent | medium | transferability | Same process steps, on 90 staff and a fortnightly cycle. Limit: no 240-headcount volume or monthly cut-off run | `[grounded]` your message; `[inferred]` that the steps carry over | see G3 |
| R9 | Answer staff payroll queries | important | unclear | low | discovery | Not mentioned either way | `[grounded]` message silence | see G4 |
| R7 | Process pension changes | important | absent | none | capability | You haven't done these yourself, your manager did, so no direct or adjacent evidence | `[grounded]` your message | closure path in G2; RR3 |
| R10 | Hybrid, two days a week in the Limerick office | hard_gate | unclear | low | hard_gate | You attended two interviews at their office, but gave no stated limit on commute or days | `[inferred]` from the in-person interviews | G5 |
| R11 | €40,000 salary | hard_gate | unclear | none | hard_gate | In the advertised band; your own pay floor isn't given | `[grounded]` ad and offer; floor not stated | G5 |
| R12 | Right to work, shown by a passport scan and the original on day one | hard_gate | unclear | none | hard_gate | The offer asks for it. Your status isn't stated and doesn't need to be | `[grounded]` offer text; status not stated | G5 |

R12's source is the offer's text, not the ad. It is an inferred gate, taken from the offer's right-to-work check.

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Irish PAYE, PRSI, USC (R2, must_have) | discovery | 3 years of payroll and a 2024 certificate, but no stated tax regime or syllabus | A `must_have`; confirming it is condition (1) | Running payroll through Revenue's systems; applying PRSI classes and USC rates; certificate modules covering them | The certificate module list, or a redacted payslip showing PAYE, PRSI and USC lines | `[grounded]` silence on regime; `[inferred]` that this closes condition (1) |
| G2 | Pension changes (R7, important) | capability | Your manager handled all of them | A named duty in the ad, and you'd own it from the start | Preparing data for your manager's pension changes; scheme-joining paperwork you handled | None yet | `[grounded]` your account; `[generic]` that duties like this are often learned on the job, so closure is a handover |
| G3 | Scale and cycle (R5, important) | transferability | The same steps at 90 staff, fortnightly | Bridges to 240 staff monthly, with the limit named | Month-end cut-offs; peak-month headcounts; any larger site you covered | Headcount in a payroll report | `[inferred]` bridge from the same process steps |
| G4 | Staff queries (R9, important) | discovery | Silent | Listed duty; probably low-stakes | Query handling from staff or managers; escalations you resolved | Any query log or process note | `[grounded]` message silence |
| G5 | Location, pay and right to work (R10, R11, R12, hard_gate) | hard_gate | The offer's terms are stated but your own limits are not | A gate you can't meet can't be fixed by wording | Not applicable | Not applicable | `[grounded]` constraints not given |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Contract terms not in the offer | unknown | — | "starting on a date we agree once your notice period ends" | Probation, pension scheme, leave and notice may sit in a contract that hasn't been sent yet | `[inferred]` from the offer's silence | Can you send the contract and handbook, covering probation, pension scheme, notice and leave, before I accept? | unresolved |
| RR2 | Offer follows two interviews, pay inside the ad's band | positive_signal | — | "€40,000 a year" | The role and terms appear consistent between ad and offer. I couldn't check the sender address against their website | `[grounded]` ad and offer as you pasted them | Is the onboarding portal address listed on your website? | noted |
| RR3 | Pension-change support not described | unknown | — | "process starters, leavers and pension changes" | Pension changes may be done with training or handover, or you may be expected to know them already | `[inferred]` from the duty list against your account | Who handles pension changes now, and what handover or training would I get? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Enter bank, PPS and passport details only in the portal reached through the address on the Marrowgate website, not from an email link alone | Those requests follow a written offer naming role and pay, which is standard onboarding. Caution about handing them over applies before an offer | `[generic]` onboarding pattern | pending your approval |
| A2 | Before accepting, ask for the contract and handbook | see RR1 | `[grounded]` RR1 | pending your approval |
| A3 | Ask Declan Garvagh the pension-change handover question | see R7, RR3 | `[grounded]` R7, RR3 | pending your approval |
| A4 | Accept by reply within the five working days once A2 is answered; mention your notice period | The offer gives five working days | `[grounded]` offer | pending your approval |

Don't paste any of those details here. Nothing in this assessment needs them.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Marrowgate Housing Limerick housing association" was declined. It would have moved role reality's organization and contradictions rows and checked the sender's domain (RR2) |
| 2. Role-family sweep | unavailable | The search "payroll administrator salary Ireland housing association Limerick" was declined. It would have moved the market calibration row and R11 |
| 3. Hiring manager's public footprint | unavailable | A search on the Finance Manager named in the offer was declined. It would have moved the scope read |

## Dossier offer

I can also save all of this as a `tuesday-dossier.md` to carry into later steps, if you'd like.

## Upgrade menu

- Permission to search → the employer's site, the salary band and the manager's public role would fill all three research rows and the market calibration.
- Your answer on G1 → R2 resolves and condition (1) closes.
- Your answer on G5 → R10, R11 and R12 resolve.
- The certificate or a module list → R4 to `high`.
- The employer's answers on RR1 and RR3 → both unknowns close.

## Questions

G1 — Was your hotel payroll run under Irish PAYE, PRSI and USC, and does your certificate cover them?

G5 — Is any term in the offer, such as the two Limerick office days, the €40,000 or the passport check, a problem for you?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.