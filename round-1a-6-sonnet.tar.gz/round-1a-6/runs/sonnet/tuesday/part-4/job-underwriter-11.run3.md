Searches were declined, so everything below comes from your message and the two postings alone.

# Posting 1: Operations Analyst, Duinvaart Cold Chain (Rotterdam)

## Decision snapshot

**Yes, worth your time. RA2, RA3 and RA4, the three `must_have` rows, are `direct`. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: RA1 (Hybrid, three days a week in Rotterdam)
- `must_have`: direct: RA2, RA3, RA4
- `important`: direct: RA6a · adjacent: RA7 (Work with depot managers on route changes) · unclear: RA6b (Temperature compliance tracking)
- `preferred`: adjacent: RA5 (Dutch a plus)

RA7: a credible bridge, its limit named; RA6b: nothing you've told me touches temperature compliance yet; RA1: waiting on your answer about the commute.

**Opportunity ledger.** Nothing in the posting's wording is alarming. The employer is unverified (RRA1) and the pay is not stated (RRA2). The deliverables are concrete (RRA3).

- **Hard gates:** none failed; unconfirmed: RA1 (Hybrid, three days a week in the Rotterdam office); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify, see RRA1; (2) the three-day Rotterdam commute works for you, see RA1; (3) the cold-chain angle is bridged honestly, see RA6b and RA7.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Duinvaart Cold Chain, Rotterdam", a refrigerated-fleet operator. Existence not established. | `[grounded]` JD header |
| Mandate | Track on-time delivery and temperature compliance, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` JD |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` JD |
| Scope read | An analyst post that reports on operations. It doesn't claim decision rights over routes. | `[inferred]` from "work with depot managers on route changes" |
| Market calibration | Not available. No salary band was obtained, so I won't offer one. | `[grounded]` no research result in hand |
| Unknowns | Salary; who you report to; how temperature data is captured; the working language with depots | — |
| Contradictions | None visible within the posting | `[grounded]` posting read |

## Evidence map

Your background is typed prose, so it counts as self-report: `medium` is the ceiling on a first pass.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| RA1 | Hybrid, three days a week in the Rotterdam office | hard_gate | unclear | none | hard_gate | The posting states the term. You haven't told me where you live or what you can commit to, so whether it is met is open. | `[grounded]` JD quote; no constraint from you | Answer the commute question below |
| RA2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | You state 4 years as an operations analyst at a parcel carrier. Specific, but no inspectable artifact yet. | `[grounded]` your stated background | none |
| RA3 | Strong SQL | must_have | direct | medium | none | You use SQL daily. "Strong" is judged by what you can show, such as a redacted query sample. | `[grounded]` your stated background | A redacted query would raise this to high |
| RA4 | Power BI or Tableau | must_have | direct | medium | none | Daily Power BI, including the on-time delivery dashboard your depot managers use. | `[grounded]` your stated background | A redacted dashboard screenshot would raise this to high |
| RA5 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational Dutch is real but not the same as working fluency. The limit stays named wherever this is used. | `[grounded]` your stated Dutch level | State the level plainly; don't round up |
| RA6a | Track on-time delivery | important | direct | medium | none | This is the same measure your dashboard reports. | `[grounded]` your stated background | none |
| RA6b | Track temperature compliance | important | unclear | none | discovery | Nothing you've said touches temperature or other compliance monitoring. Evidence may exist, so this is a discovery gap and not a capability one. | `[grounded]` silence on this | See G2 |
| RA7 | Work with depot managers on route changes | important | adjacent | medium | discovery | You ran the weekly route-performance review and depot managers use your dashboard. Whether the review led to route changes you worked on with them isn't established. | `[grounded]` your stated background | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and schedule (RA1 here, RB1 in posting 2) | hard_gate | The postings state office terms; your constraints are not given | A failed gate caps the decision however strong the fit | Your home city, and whether you would commute or relocate | None needed | `[grounded]` JD terms; your constraints absent |
| G2 | Temperature compliance (RA6b, important) | discovery | Your on-time work is established; compliance monitoring is not | This is half of the role's headline job | Reporting on any SLA, quality or exception-rate target; a perishable or temperature-sensitive flow; exception reports to depots | A redacted report or dashboard page | `[grounded]` silence in your account; `[generic]` that employers in this field weigh it heavily |
| G3 | Route changes with depot managers (RA7, important) | discovery | You ran the review; outcomes of it are not stated | It sets how strongly you can say you've done this work | A route or schedule change that came out of your review; a depot manager acting on your numbers | A review pack or an email thread, redacted | `[grounded]` your stated background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RRA1 | Employer not established from attributable sources | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who I would be interviewing with? | unresolved |
| RRA2 | Pay not stated | unknown | — | (posting gives no figure) | The band may suit you or not; the posting alone can't say. | `[grounded]` JD silent | What salary range is budgeted for this post? | unresolved |
| RRA3 | Concrete deliverables named | positive_signal | — | "build weekly dashboards in Power BI" | The role's output is defined. | `[grounded]` JD states it | What would a good first 90 days look like? | noted |

Hold on committing real effort until RRA1 clears. Check the posting on the company's own website, not through a link someone sent you.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Resume lead line: "Worked daily in SQL and Power BI, including the on-time delivery dashboard used by depot managers; ran the weekly route-performance review." Every clause comes from your own sentence; I did not say "built". | See RA3, RA4, RA6a, RA7 | `[grounded]` your stated background | resume_edits_pending_approval |
| E2 | Say your Dutch is conversational, not fluent, and let it be the "plus" the posting calls it | See RA5 | `[grounded]` your stated Dutch level | pending your approval |
| Q1 | Ask the register questions (RRA1 to RRA3) verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Verify the employer on its own careers site before applying | See RRA1 | `[grounded]` RRA1 | pending your approval |

---

# Posting 2: Supply Planner, Kroonhaven Foods (Utrecht)

## Decision snapshot

**No, not worth your time as posted. RB2 and RB3, both `must_have` rows, are absent (you've never worked in planning). Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: unclear: RB1 (On-site in Utrecht)
- `must_have`: adjacent: RB6 (Fluent Dutch) · unclear: RB4 (SAP IBP or similar planning system), RB5 (Advanced Excel) · absent: RB2 (3+ years supply or demand planning in FMCG), RB3 (Own the 13-week supply plan)
- `important`: adjacent: RB7 (Run the weekly S&OP meeting)

RB2, RB3: no planning work in your account, so the gap is capability, not wording; RB7: a bridge with a clear limit.

**Opportunity ledger.** The employer is unverified (RRB1), pay is not stated (RRB2), and the mandate is concretely defined (RRB3).

- **Hard gates:** none failed; unconfirmed: RB1 (On-site in Utrecht); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **What would change this:** documented planning work in your history, with Dutch you would call fluent, or the employer widening the requirements.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Kroonhaven Foods, Utrecht", a maker of chilled ready-meals. Existence not established. | `[grounded]` JD header |
| Mandate | Own the 13-week supply plan, balance capacity against forecast, run the weekly S&OP meeting | `[grounded]` JD |
| Working pattern | On-site in Utrecht | `[grounded]` JD |
| Scope read | A single-owner planning seat; the posting names no team or tools beyond the system class | `[inferred]` from the JD's silence on team |
| Market calibration | Not available; no band obtained | `[grounded]` no research result in hand |
| Unknowns | Salary; meeting language; planning-system in use | — |
| Contradictions | None visible within the posting | `[grounded]` posting read |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| RB1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | Term stated; your constraints are not given. | `[grounded]` JD; no constraint from you | See G1 |
| RB2 | 3+ years supply or demand planning in FMCG | must_have | absent | none | capability | You say you've never worked in planning. This tier is a stated requirement, not a legal bar, so it is graded on fit. | `[grounded]` your statement | Carry as material risk |
| RB3 | Own the 13-week supply plan; balance capacity against forecast | must_have | absent | none | capability | The core job. No planning work in your account. | `[grounded]` your statement | Carry as material risk |
| RB4 | SAP IBP or a similar planning system | must_have | unclear | none | discovery | Nothing in your account touches a planning system. Possible but unestablished. | `[grounded]` silence | Upgrade menu |
| RB5 | Advanced Excel | must_have | unclear | none | discovery | Not mentioned in your account. | `[grounded]` silence | Upgrade menu |
| RB6 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational Dutch is below the posting's fluent bar. | `[grounded]` your stated Dutch level | Don't claim fluency |
| RB7 | Run the weekly S&OP meeting | important | adjacent | medium | transferability | You ran a weekly route-performance review. Limit: it is a different kind of meeting from a cross-functional planning review, so it is a bridge and not equivalence. | `[grounded]` your stated background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G4 | Planning experience (RB2, RB3, must_have) | capability | No planning work in your account | Two must-haves fail together, so wording can't fix it | Not applicable; closure means a different target role or building planning experience first | Not applicable | `[grounded]` your statement; `[generic]` that planner-adjacent analyst roles are the usual stepping stone |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RRB1 | Employer not established from attributable sources | risk_signal | medium | "Kroonhaven Foods, Utrecht" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who I would be interviewing with? | unresolved |
| RRB2 | Pay not stated | unknown | — | (posting gives no figure) | The posting alone can't say whether pay suits you. | `[grounded]` JD silent | What salary range is budgeted for this post? | unresolved |
| RRB3 | Mandate concretely defined | positive_signal | — | "Own the 13-week supply plan" | The scope is clear; it is simply not yours yet. | `[grounded]` JD states it | What decisions does the planner make alone? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't spend application effort here. If you apply anyway, the register questions above travel with you. | See RB2, RB3 | `[grounded]` map rows | pending your approval |

---

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches sent for "Duinvaart Cold Chain Rotterdam" and "Kroonhaven Foods Utrecht" were refused. They would have moved RRA1 and RRB1, whether each employer exists and the posting is live. |
| 2. Role-family sweep | unavailable | Searches for operations-analyst and supply-planner pay were refused. They would have given market calibration and moved RRA2 and RRB2. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there is no query to form. |

I haven't verified either company or posting.

I can save all of this as a `tuesday-dossier.md` for reuse if you want it.

## Upgrade menu

- Permission to run the searches again → RRA1 and RRB1 may clear or firm up, and role reality gains a pay band.
- A redacted dashboard screenshot or query sample → RA3 and RA4 to `high`.
- Your home city and what commute you'd accept → RA1 and RB1 resolve.
- A temperature-compliance or SLA-style report, redacted → RA6b resolves.
- Any planning-system or Excel modelling evidence → RB4 and RB5 resolve, though RB2 and RB3 would still stand.
- A deeper research pass on both employers (leadership churn, hiring patterns; up to 5 more searches and 2 more fetches). Say the word and it runs.

## Questions

G1: Where do you live, and would you take three days a week in Rotterdam (posting 1) or full on-site in Utrecht (posting 2)?

G2: Have you ever tracked or reported a compliance or service-quality target, such as temperature, SLA or exception rates? What did you own, and who used it?

G3: Did your weekly route-performance review ever lead to a route or schedule change you worked out with a depot manager? What was your part?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.