I've read the job-underwriter playbook. Now I'm running the employer check and a pay and scope check for community nursing roles, then I'll write the assessment.
**Yes, this one is worth applying for. R1 and R2, the two hard gates, are met on your own statement, so the status is `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3 · unclear: R10 (Clear, timely written records)
- `important` — direct: R6a, R8 · adjacent: R4 (Housebound adults at home), R5 (Wound and leg-ulcer care), R9 (Own small caseload) · unclear: R6b (Continence care), R7 (End-of-life visits), R11 (Care planning)
- `preferred` — absent: R12 (Doppler assessment)

R4, R5, R9 — credible bridges with their limits named; R10 (`low`) — the one essential duty the CV is silent on; R12 — no evidence, preferred.

**Opportunity ledger.** Pay is stated and sits across the survey range (RR5), and entry is supported (RR4). Three things are open: the posting is not found on the employer's own careers page (RR1), the mileage terms sit beside "pool cars provided" (RR2), and hours are unstated (RR3).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. The post is confirmed live (RR1).
  2. The informal chat settles mileage, hours and supervision (RR2, RR3, RR4).
  3. Your own records and end-of-life experience are confirmed from your history (R10, R7, G1, G2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015, 410 staff, four locality hubs | `[grounded]` About page, fetched |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin, care planning, on an electronic patient record | `[grounded]` advert |
| Entry support | A small caseload of your own, supported by a senior community nurse | `[grounded]` advert |
| Team lead | Rhiannon Mabbott leads the Halifax district nursing team, after eleven years as a district nurse. At a 2025 forum she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work. The page does not say she is the hiring manager | `[grounded]` forum speaker page, from a search result only |
| Pay | £31,050–£37,800 plus mileage | `[grounded]` advert |
| Market calibration | A 2026 survey of Band 5 community staff nurses in England (n=1,240) reports a median of £34,300 and an interquartile range of £32,400–£36,600. 61% were paid mileage and 24% had a pool or lease car. The advert's range spans that interquartile range and pool cars are provided, which is the minority case in the survey. This is a sample, not this employer's offer | `[generic]` survey, from a search result only; `[grounded]` advert for the range and the pool cars |
| Scope read | A supervised, bounded caseload rather than a fully autonomous district nurse post | `[inferred]` from "small caseload" and "supported by a senior community nurse" |
| Unknowns | Closing date; whether the post is live; rota and weekend or out-of-hours work; mileage terms beside pool cars; whether Doppler training is provided | — |
| Contradictions | The About page says vacancies are on its careers page, but the careers page fetch returned no page, so the posting is not confirmed on the employer's own site | `[grounded]` both fetches |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | Your CV states Adult registration as active, with revalidation due March 2028. Nothing was inspected: stated, not checked | `[grounded]` CV | Check your own entry on the NMC register is current |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Your CV states a full UK licence, category B. Stated, not checked | `[grounded]` CV | Check your own driving record shows the licence current |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward, stated in your CV. A length of experience, so not a gate | `[grounded]` CV | none |
| R10 | Clear, timely written records, on an electronic patient record | must_have | unclear | low | discovery | Your CV says nothing about records or any electronic system. Ward posts generally involve record-keeping, but that is not evidence of clear, timely records. Low rather than none because five ward years leave a thread to pull | `[grounded]` CV silence; `[generic]` that ward posts involve record-keeping | G1 |
| R4 | Care of housebound adults in their own homes | important | adjacent | medium | transferability | 18 months on the discharge-to-assess team visiting patients at home in their first week after discharge is real home practice. Limit: that is post-discharge follow-up, and long-term housebound patients differ | `[grounded]` CV; `[generic]` on how the two patient groups differ | Name the limit honestly; see E1 |
| R5 | Wound and leg-ulcer care | important | adjacent | medium | discovery | Pressure-ulcer and surgical-wound care are stated. Leg ulcers are not mentioned, and the CV may simply not say | `[grounded]` CV | G3 |
| R6a | Catheter care | important | direct | medium | presentation | Stated as a skill in your CV, with no setting or scale. Medium until something is inspectable | `[grounded]` CV | E2 |
| R6b | Continence care beyond catheters | important | unclear | low | discovery | The CV does not mention it | `[grounded]` CV silence | Raise at the informal chat; no question spent |
| R7 | End-of-life visits | important | unclear | low | discovery | The CV is silent on palliative or end-of-life care | `[grounded]` CV silence | G2 |
| R8 | Insulin administration | important | direct | medium | presentation | Stated as a skill in your CV | `[grounded]` CV | E2 |
| R9 | A small caseload of your own, with senior support | important | adjacent | medium | transferability | You have never held your own caseload, in your words. Home visits in the secondment are adjacent. Limit: no ownership or prioritising of a list. The advert pairs the caseload with senior support | `[grounded]` your statement and CV; `[grounded]` advert | See E3 for framing |
| R11 | Care planning | important | unclear | low | discovery | The CV is silent | `[grounded]` CV silence | Folded into G2 if your answer covers it |
| R12 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You have never done one and it is desirable, not essential. A team lead has spoken on Doppler training for staff new to community work. Whether Calderbrook provides it is unconfirmed | `[grounded]` your statement; `[grounded]` forum page | Ask whether it is provided (RR4) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Written records, electronic record (R10, must_have) | discovery | The CV says nothing about records or an electronic system | It is the one essential duty the CV does not address | Notes written at each home visit; handover or care-plan updates; use of any electronic patient record; record-keeping audits or feedback | A documentation audit result, or a competency sign-off for record-keeping (no patient details) | `[grounded]` CV silence; `[inferred]` that resolving it moves the status |
| G2 | End-of-life care and care planning (R7, R11, important) | discovery | The CV is silent on both | End-of-life visits are named in the advert | Caring for patients in their last days on the ward; contributing to anticipatory or care plans; supporting families; any end-of-life training | A training certificate or a sanitised reflective account for revalidation | `[grounded]` CV silence |
| G3 | Leg-ulcer care (R5, important) | discovery | Pressure ulcers and surgical wounds are stated, leg ulcers are not | Leg-ulcer care is named first in the advert, and the team lead has spoken on it | Compression bandaging; leg-ulcer dressings on the ward; a tissue viability link-nurse role | A wound-care competency record | `[grounded]` CV and advert; `[generic]` that this team treats it as a core skill |
| G4 | Own caseload (R9, important) | transferability | The secondment is adjacent, not caseload ownership | The advert sets the caseload as a duty, with supervision attached | The bridge is the visiting itself. Limit: no list of your own. Strengthener: ask how supervised practice leads into the caseload | A supervisor's reference on the secondment | `[grounded]` your statement |
| G5 | Doppler (R12, preferred) | capability | No evidence, by your own statement | Desirable only, but the team lead has spoken on Doppler training | Closure path: ask whether the employer trains it, since the team lead has spoken on Doppler training for staff new to community work | An employer-confirmed training offer | `[grounded]` your statement and the forum page |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not found on the employer's own careers page | unknown | — | "Join our district nursing team caring for housebound adults in their own homes" | The page may not be indexed, the advert may be on another site, or the vacancy may have closed | `[grounded]` the careers fetch returned no page; the reasons are `[generic]` possibilities, none ranked | Is this post still open, and what is the closing date? | unresolved |
| RR2 | Mileage listed beside pool cars | unknown | — | "pool cars are provided … plus mileage" | Mileage may apply only when a personal car is used, or on certain visits | `[inferred]` from the two terms side by side | When is mileage paid if a pool car is provided, and is a pool car available on every shift? | unresolved |
| RR3 | Hours and rota unstated alongside end-of-life visits | unknown | — | "end-of-life visits" | Weekend or out-of-hours work may be part of the post | `[inferred]` from the advert's silence on hours against its end-of-life duty | What is the shift pattern, and how often are weekends or evenings worked? | unresolved |
| RR4 | Supervised entry, and Doppler training spoken of by the team lead | positive_signal | — | "supported by a senior community nurse" | The ramp-up looks structured | `[grounded]` advert and forum page | How much supervised practice comes before the caseload is yours, and is Doppler training provided? | noted |
| RR5 | Pay stated openly | positive_signal | — | "£31,050–£37,800 a year" | A stated range makes comparison possible; your own floor is unknown | `[grounded]` advert; `[generic]` survey | Where in the range would my experience place me? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Take up the informal chat with Rhiannon Mabbott before applying. Ask RR1–RR4 verbatim. | The advert offers it, and the questions settle the conditions | `[grounded]` advert | pending your approval |
| A2 | Check your own NMC register entry and your driving record before you apply | R1 and R2 are stated, not checked, and the checks are yours | `[grounded]` rows R1 and R2 | pending your approval |
| E1 | CV edit: lead with the discharge-to-assess secondment as "visiting patients at home in their first week after discharge" | See R4. Every clause is your own sentence | `[grounded]` CV | `resume_edits_pending_approval` |
| E2 | CV edit: name wound care (pressure ulcers and surgical wounds), catheter care and insulin administration as listed skills | See R6a, R8 | `[grounded]` CV | `resume_edits_pending_approval` |
| E3 | Positioning to say aloud: "I have visited patients at home after discharge but have not held my own caseload, and I would value the senior support this post offers." Do not claim leg-ulcer, end-of-life or Doppler experience. | See R9, R5, R7, R12 | `[grounded]` your statements | pending your approval |

Nothing above is applied until you approve it. That covers the edits table and the advice in E3.

## Evidence status

Verified: none yet.

Your National Insurance number is not needed for this. I have not used or repeated it, and you shouldn't send it with an application.

Research tier: L1 — searches 4 of 5, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Calderbrook Community Health CIC community staff nurse Band 5 district nursing vacancy". Fetched "About Calderbrook Community Health" (calderbrookhealth.example/about). Fetched calderbrookhealth.example/careers, which returned no page. Moved: the employer is established as described; the posting is not confirmed live (RR1) |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse district nursing role expectations own caseload Agenda for Change pay scale", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide), as a search result only. Moved: market calibration and RR5. It returned nothing on role expectations |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook Community Health", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Moved: the team lead row, RR4, A1 |

If you'd like me to produce `tuesday-dossier.md` from this assessment, say so.

## Upgrade menu

- The careers-page link or a closing date → RR1 closes, and the decision likely becomes `go`.
- Answers to G1–G3 → R10, R7, R11 and R5 move.
- Your pay floor, hours and any other must-haves → the hard-gate line and RR3, RR5 check against them.
- A wound-care competency record, an insulin sign-off or a sanitised revalidation account → R6a, R8 and R5 could reach `high`.
- A deeper research pass on Calderbrook (recent news, leadership, staff reports; up to 5 more searches and 2 more fetches) — say the word and it runs.

G1 — Which record system did you use on the ward and in the discharge-to-assess team (paper or electronic), and what did you personally write there?
G2 — Have you cared for patients in their last days, and what did you personally do (no patient details needed)?
G3 — Have you cared for leg ulcers or applied compression bandaging, even a few times, and what was yours to do?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.