Checked the firm and the pay band. The full read is below.

# Job Underwriting — Remote Order Processing Coordinator, Velloway Logistics

## Decision snapshot

**No, don't go ahead. This job is very likely a scam, and I can't establish the firm from here (RR5). RR1, RR2, RR3 and RR4 are each severe, confirmed requests. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Earn up to €26 an hour)
- `must_have` — direct: R2, R4 · adjacent: R3 (Strong attention to detail)

R1 — the posting gives a ceiling rate and no floor; R3 (`low`) — adjacent through volume work, accuracy not evidenced.

**Opportunity ledger.** RR1 (pay for equipment), RR2 (cheque deposit and onward transfer), RR3 (bank, tax and ID details before an offer) and RR4 (hiring wholly by chat) are confirmed and severe. RR5 (employer not established), RR6 (pay terms) and RR7 (contact address) are unresolved.

- **Hard gates:** none failed; unconfirmed: R1 (Earn up to €26 an hour).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would change this:** the demands in RR1, RR2 and RR3 withdrawn. The interview and offer would also have to come with a written offer naming the role and pay, from an employer you can find and check on its own website (RR4, RR5).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Velloway Logistics, as the posting names it. A search for its official site and careers page returned nothing | `[grounded]` posting; `[grounded]` empty search result, so not established |
| Mandate | Remote order processing, 15–30 hours a week, "up to €26 an hour plus commission on every order you process" | `[grounded]` posting |
| Hiring process | Run entirely on Telegram, with "no calls or video interviews" | `[grounded]` posting and the messages you pasted |
| Pay calibration | The ceiling gives €20,280 a year at 15 hours and €40,560 at 30 hours. Your €30,000 floor needs about 22 hours a week at the top rate. The one salary guide found puts salaried Irish order-processing and customer-operations coordinators at a median base of €31,200 (range €28,400–€34,100, n=1,140). It excludes commission-only and freelance work, so it is a band to expect, never this employer's offer | `[inferred]` arithmetic on the posted ceiling; `[generic]` salary band, one search |
| Unknowns | The guaranteed hourly rate, the commission rate, whether you would be an employee or a contractor, who the "equipment partner" is, and who is behind the handle | `[grounded]` the posting and messages are silent on each |
| Contradictions | The posting mentions no equipment purchase. The messages then ask you to buy a laptop and headset, and later to move part of a cheque to the "equipment partner" | `[grounded]` posting set against the messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay: "up to €26 an hour plus commission", 15–30 hours, against your need of at least €30,000 a year | hard_gate | unclear | high | hard_gate | Confidence grades your own stated floor. Fit is `unclear` because the posting states a ceiling only, so the floor is not settled either way | `[grounded]` your constraint and the posting; `[inferred]` arithmetic in Role reality | Written pay terms, but only through the employer's own site contacts, and only if RR1–RR4 are withdrawn |
| R2 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel. Confirmed and specific, with no inspectable file yet | `[grounded]` your background | none |
| R3 | Strong attention to detail | must_have | adjacent | low | transferability | About 60 tickets a day in Zendesk shows volume and process discipline. Accuracy or quality results are not stated, and that is the limit of the bridge | `[grounded]` your ticket volume; `[inferred]` adjacency to detail work | Accuracy evidence, see G2 |
| R4 | Good written English | must_have | direct | medium | none | Zendesk ticket handling is written correspondence, and three years of it is stated | `[inferred]` from the nature of ticket work | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Actual pay terms (R1, hard_gate) | hard_gate | A ceiling of €26 an hour, a 15–30 hour range, commission unstated | Decides whether €30,000 is reachable. It cannot move the status while RR1–RR4 stand | A written offer stating the guaranteed hourly rate, minimum weekly hours and commission rate | A written offer from an employer whose own website you found yourself | `[grounded]` posting silence; `[inferred]` that this alone cannot lift the status |
| G2 | Attention to detail (R3, must_have) | transferability | Volume and a tracker, but no accuracy figure | Matters only for other order-processing roles, where the same evidence would be asked for | Quality or QA scores on your tickets, audit results, error counts in your tracker, feedback from the two new starters you trained | A QA score sheet, a manager's note, or an anonymised tracker extract | `[grounded]` your background; `[generic]` that such roles probe accuracy |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Asked to pay for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | A bank transfer, once made, can be hard to get back, and a refund promised against your first wages is not secured by anything | `[generic]` pattern of requests like this one | Do you ask new hires to pay for equipment, and where is that written in an offer? Ask through contact details you find on the employer's own website | confirmed |
| RR2 | Asked to deposit a cheque and send most of it on | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." | A cheque can show as credit before it clears and be reversed later. Any money you sent on would then be your loss | `[generic]` how cheque clearing works | As RR1: do you send new hires a cheque and ask them to pass part of it on? The first entry's route applies | confirmed |
| RR3 | Bank, tax and ID details requested before any offer | red_flag | high | "please send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up" | These were asked for before a chat interview and before any written offer, so no offer yet exists to justify them. Once given, they can't be taken back | `[grounded]` the request came before any written offer; `[generic]` what such details enable | As RR1: at what stage do you collect these, and through which portal on your own site? | confirmed |
| RR4 | Hiring process run wholly by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." | A chat-only process leaves open who you are dealing with and whether an employer is behind it | `[grounded]` the posting says so; `[inferred]` what it leaves open | As RR1: who would I be working for, and can I speak to someone at the firm? | confirmed |
| RR5 | Employer not established from attributable sources | risk_signal | medium | "Velloway Logistics" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? Ask through contacts you find yourself | unresolved |
| RR6 | Pay stated as a ceiling with commission | risk_signal | low | "Earn up to €26 an hour plus commission on every order you process" | Your actual rate may sit well below the ceiling, and the commission rate is not stated | `[inferred]` from "up to" and the missing rates; `[generic]` salary band in Role reality | What is the guaranteed hourly rate, the minimum weekly hours and the commission rate? | unresolved |
| RR7 | Contact address and chat handle not tied to an employer | risk_signal | low | "email velloway.hr@postmail.example" | The messages come from a chat handle and an address on a general mail domain. Neither can be tied to an employer's own website from here | `[inferred]` from the address and the failed search | Which email address on your own website should applicants use? | unresolved |

Hold off on the payment, the cheque deposit and sending your details, and go no further in the chat, until you have checked each request with the employer, through contact details on the employer's own website rather than the chat or the address these messages came from; who sent them is not yet confirmed.

I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Send none of the three items in RR3. I haven't repeated your IBAN here, and you don't need to paste it, your PPS number or your passport into this chat | See RR3 | `[grounded]` RR3 | pending your approval |
| A2 | Make no transfer for the kit and don't lodge the cheque, then check each request as the hold above says | See RR1, RR2 | `[grounded]` RR1, RR2 | pending your approval |
| A3 | Put your effort into other openings in customer operations or order processing. The salary guide's median of €31,200 sits above your €30,000 floor | See R1, Role reality | `[generic]` one salary guide, salaried roles only | pending your approval |
| A4 | When applying elsewhere, lead with your own facts: three years as a customer service agent at a parcel courier, about 60 tickets a day in Zendesk, two new starters trained, the team's weekly tracker kept in Excel. Add no accuracy figure until G2 is answered | See R2, R3, R4 | `[grounded]` your background | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics official website careers", which returned no results. Not established, so RR5 stands and caps any decision at `conditional_go`; RR1–RR4 make it `no_go` regardless |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator salary Ireland entry level", which returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). It moved the pay calibration in Role reality, RR6 and A3 |
| 3. Hiring manager's public footprint | n/a | No person's name was given. The chat handle is not a name, so there was no query to form |

## Dossier offer

If you'd like, I can save this as a `tuesday-dossier.md` to reuse for other roles.

## Upgrade menu

- The link to the original posting and the jobs site it was on → I can check whether it is live and consistent, which feeds RR5.
- The firm's own website or Irish company registration, which you find yourself → RR5 could resolve either way.
- Written pay terms from an employer you have verified → R1, RR6 and G1 close.
- A QA score, audit result or manager's note on your ticket work → R3 moves toward `medium`.
- A deeper research pass (up to 5 more searches and 2 more fetches) → say the word and it runs.

RR5 — Which jobs site was the posting on, and can you drop the link? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.