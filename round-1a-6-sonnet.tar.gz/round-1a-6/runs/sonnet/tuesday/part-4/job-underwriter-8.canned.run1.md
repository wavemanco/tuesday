I've searched for the firm and for the pay band. Here's the full assessment.

# Job Underwriting: Remote Order Processing Coordinator, Velloway Logistics

## Decision snapshot

**No, don't go ahead, and don't send anything. Status: `no_go`.** These messages ask for a payment, a cheque deposit, and your ID and bank details before any written offer (RR1, RR2, RR3), and the hiring runs wholly in chat (RR4).

**Fit ledger.**

- `hard_gate` — unclear: R1 (Pay of at least €30,000 a year)
- `must_have` — direct: R2, R3, R4

R1 — the posting gives only "up to" figures; R3 (`medium`) — confirmed, formula depth not stated.

**Opportunity ledger.** RR1, RR2 and RR3 ask for money, a cheque deposit and ID and bank details before any written offer, and RR4 runs the whole process through chat, so this job is very likely a scam. RR5 — I can't establish the firm from here. RR6 — the pay is stated only as "up to".

- **Hard gates:** none failed; unconfirmed: R1 (Pay of at least €30,000 a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would change this:** no payment, cheque deposit or ID and bank details asked for before a written offer; the employer established through its own website (RR5); and written terms that meet your €30,000 floor (R1, RR6).

Your passport, PPS number and IBAN aren't needed for this assessment. I haven't repeated the IBAN you pasted, and you shouldn't send it anywhere in this chat.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Velloway Logistics: my search for its official site and careers page returned no results, so the firm is not established | `[grounded]` search returned nothing |
| Mandate | Remote order processing, 15–30 hours a week, "up to €26 an hour plus commission", no experience needed | `[grounded]` posting |
| Hiring process | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | `[grounded]` posting |
| Scope read | The posting lists no equipment cost; the €349 "work kit" appears only in the later message | `[grounded]` posting against the messages you pasted |
| Market calibration | A 2026 Irish pay guide puts salaried order-processing and customer-operations coordinators at a median of €31,200 a year (interquartile range €28,400 to €34,100). It excludes commission-only and freelance work, so it is a rough comparison for an hourly, part-time offer. I read the search snippet, not the full page. | `[generic]` role-family sweep, one search |
| Unknowns | Who the employer is; the guaranteed hourly rate and weekly hours; how commission works; who interviewed you; whether you'd be an employee or a contractor | — |
| Contradictions | The posting says nothing about buying equipment, but the messages ask for €349. The interview was questions in a chat, then "the job is yours". | `[grounded]` posting and your messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay of at least €30,000 a year (your hard constraint) | hard_gate | unclear | high | hard_gate | Confidence grades your stated floor, which is your own and specific. Fit is unclear because the posting says "up to €26 an hour", 15–30 hours and unquantified commission. At the top rate, €30,000 needs about 22 hours a week or more, and nothing guarantees the top rate or the hours. | `[grounded]` your floor and the posting's words; `[inferred]` the arithmetic from the posting's figures | A written rate, guaranteed hours and commission terms from an employer verified independently (RR6) |
| R2 | Strong attention to detail | must_have | direct | medium | none | About 60 Zendesk tickets a day and a weekly team tracker you keep. No accuracy measure was stated, so `medium` and no higher. | `[grounded]` your account in this chat | none |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel. How much formula work it holds isn't stated, so this is confirmed but uninspected. | `[grounded]` your account in this chat | none |
| R4 | Good written English | must_have | direct | medium | none | Three years of ticket handling at volume. Ticket replies are written work, which is my reading, not something you said. No writing sample has been inspected. | `[grounded]` your years and volume; `[inferred]` that ticket handling is written work | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay meets your floor (R1, hard_gate) | hard_gate | "Up to €26 an hour plus commission" and 15–30 hours, with no guaranteed minimum for either | A floor you can't confirm against the terms is the one thing that could matter even if the other concerns cleared | — (this is a term, not experience) | A written offer from a verified employer stating the rate, guaranteed weekly hours and commission | `[grounded]` posting wording; `[inferred]` that the terms leave R1 open |

I'm not asking about G1 now, because the decision doesn't turn on it.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Asked to pay for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | A bank transfer, once sent, is hard to get back. Who sent these messages is unresolved. This request is very likely a scam. | `[generic]` employers don't normally ask applicants to pay for equipment before they start | "Does Velloway Logistics employ people in this role, and does it ask new starters to pay €349 for equipment?" Ask through contact details on the employer's own website, never the Telegram handle or the postmail.example address. | confirmed |
| RR2 | Asked to deposit a cheque and forward part of it | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." | A cheque can be returned unpaid after the money shows in the account, leaving you out of pocket for what you transferred. This request is very likely a scam. | `[generic]` a known pattern for requests like this | "Does Velloway Logistics post cheques to new starters and ask them to forward part of the amount?" Same route as RR1. | confirmed |
| RR3 | Asked for IBAN, PPS number and passport photo before any offer | red_flag | high | "Before your chat interview, please send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up." | These details together can be used to open accounts or apply for credit in your name, and can't be taken back once sent. This request is very likely a scam. | `[generic]` what these details allow once shared | "At what stage does Velloway Logistics collect IBAN, PPS number and passport photo, and through which portal?" Same route as RR1. | confirmed |
| RR4 | Hiring run wholly by chat, with contact off a verified employer domain | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." Also: "Any problems, email velloway.hr@postmail.example." | With the interview and offer both in one chat, nothing you were told can be checked against a written employer record. The address shown isn't shown to be the employer's own domain. Who sent these messages is unresolved. | `[generic]` how chat-only hiring limits checking | "Does Velloway Logistics hold interviews and make offers outside Telegram, and is velloway.hr@postmail.example one of its addresses?" Same route as RR1. | confirmed |
| RR5 | Employer not established from attributable sources | risk_signal | medium | "Velloway Logistics" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. | `[generic]` pattern for companies of this size, not a claim about this one | "Can you point me at the role on your own careers site, and who would I be interviewing with?" | unresolved |
| RR6 | Pay stated only as "up to", commission unquantified | unknown | — | "Earn up to €26 an hour plus commission on every order you process." | At 15 hours a week the top rate gives about €20,300 a year and at 30 hours about €40,600, so the result against your €30,000 floor depends on the guaranteed rate and hours (R1). The salaried median in role reality is for a different pay structure. | `[inferred]` arithmetic from the posting's figures; `[generic]` salaried band | "What is the guaranteed hourly rate and minimum weekly hours, and how is commission calculated?" | unresolved |

Hold off on the payment, the cheque deposit and sending your details, and go no further in the chat, until you have checked each request with the employer, through contact details on the employer's own website rather than the chat or the address these messages came from; who sent them is not yet confirmed.

I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Send nothing more: no €349, no cheque lodged, no IBAN, PPS number or passport photo. Stop replying in the chat. | See RR1, RR2, RR3, RR4 | `[grounded]` register | pending your approval |
| A2 | Look for the firm's own website and its company registration through official sources you find yourself, not links from the chat | See RR5 | `[grounded]` RR5 | pending your approval |
| A3 | Tell the jobs site about the listing | Jobs sites usually have a way to report a listing | `[generic]` | pending your approval |
| A4 | Put your effort into other openings. Your three years of Zendesk ticket work and Excel tracking map to R2, R3 and R4. Your €30,000 floor sits just under the salaried median in the pay guide. When a specific role is on the table, resume-tailor can fit your CV to it. | See R2, R3, R4 | `[grounded]` your background; `[generic]` the pay guide | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics official website careers"; no results, so the firm is not established. Moved role reality's organization row and RR5. |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator Ireland salary hourly rate", which returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). Moved the market calibration row and RR6. |
| 3. Hiring manager's public footprint | n/a | No name was given, only a Telegram handle, so there was no query to form. |

If you want a record to keep, I can save this as a `tuesday-dossier.md`.

## Upgrade menu

- A link to the listing, or a company web page or registration number → RR5, and who the employer is.
- A written statement of the hourly rate, guaranteed weekly hours and commission → R1 and RR6.
- A deeper research pass on the firm (up to 5 more searches and 2 more fetches) — say the word and it runs.

RR5 — Which jobs site was the posting on, and does the listing link to a Velloway Logistics website or page?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.