Search permission wasn't granted, so I assessed both roles from your pasted text only.

## Decision snapshot — First role: Operations Analyst, Duinvaart Cold Chain

**Yes, worth your time. A2, A3 and A4 are `direct`, and no hard gate has failed. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: A1 (Hybrid, three days a week in Rotterdam office)
- `must_have` — direct: A2, A3, A4
- `important` — direct: A5 · adjacent: A7 (Work with depot managers on route changes) · unclear: A6 (Temperature compliance on refrigerated fleet)
- `preferred` — adjacent: A8 (Dutch a plus)

A6 — cold-chain compliance has no evidence yet; A7 (`low`) — route-change influence is unconfirmed.

**Opportunity ledger.** The posting is concrete about duties and tools (AR3). The employer is unchecked because research was refused (AR1), and the salary is not stated (AR2).

- **Hard gates:** none failed; unconfirmed: A1 (Hybrid, three days a week in Rotterdam office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the three office days in Rotterdam are workable for you (A1); (2) the employer and live posting verify (AR1); (3) the temperature-compliance gap is closed or framed honestly as unexercised (A6).

## Decision snapshot — Second role: Supply Planner, Kroonhaven Foods

**No, not as written. B2, B3 and B6 have no planning evidence at all. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — unclear: B1 (On-site in Utrecht)
- `must_have` — adjacent: B4 (Run weekly S&OP meeting), B7 (Fluent Dutch) · unclear: B5 (Advanced Excel) · absent: B2 (3+ years supply or demand planning in FMCG), B3 (Own the 13-week supply plan), B6 (SAP IBP or similar planning system)

B2, B3, B6 — no planning evidence at all; B4 (`low`) — review-running bridge, S&OP limit named.

**Opportunity ledger.** The scope is explicit (BR3). The employer is unchecked (BR1) and the salary is not stated (BR2).

- **Hard gates:** none failed; unconfirmed: B1 (On-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** the status moves only if planning-role experience (B2, B3), planning-system exposure (B6) and Dutch fluency (B7) were different facts. Wording cannot close them. The call is yours.

---

# First role — Duinvaart Cold Chain

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam, a refrigerated-fleet operator | `[grounded]` posting header |
| Mandate | Track on-time delivery and temperature compliance, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` posting |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` posting |
| Scope read | A single analyst post serving depot managers; it does not read as bundled roles | `[inferred]` from the duty list, which names one reporting rhythm and one stakeholder group |
| Market calibration | Not available: the role-family search was refused, and the posting states no salary | — |
| Unknowns | Salary, team size, commute basis for you, and how deep the temperature-compliance work goes | `[grounded]` posting silence |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| A1 | Hybrid, three days a week in Rotterdam office | hard_gate | unclear | none | hard_gate | You gave no location or commute constraint, and your employer is in Amsterdam, so whether three Rotterdam days work is not established | `[grounded]` posting term; your home base is not stated | Ask the A1/B1 question |
| A2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | You state four years as an operations analyst at a parcel carrier. No document was inspected, so `medium` is the intake ceiling | `[grounded]` your stated background | none |
| A3 | Strong SQL | must_have | direct | medium | none | You state daily SQL use. "Strong" is a level claim that nothing inspectable backs yet | `[grounded]` your stated background | A query sample or dashboard spec would raise it |
| A4 | Power BI or Tableau | must_have | direct | medium | none | You state daily Power BI use and a depot-manager on-time dashboard you built | `[grounded]` your stated background | A sanitized dashboard screenshot would raise it |
| A5 | Track on-time delivery | important | direct | medium | none | The on-time dashboard is the same work the posting names | `[grounded]` your stated background | none |
| A6 | Temperature compliance on a refrigerated fleet | important | unclear | none | discovery | Nothing you gave touches temperature-controlled freight or compliance reporting. That is a gap in what I have seen, not proof you have none | `[grounded]` silence in your background | Ask GA1 |
| A7 | Work with depot managers on route changes | important | adjacent | low | discovery | You built the dashboard depot managers use and ran the weekly route-performance review. Whether they attended it or you proposed route changes is not stated, so I took the lower band | `[grounded]` your stated background; the limit is `[inferred]` from what you did not say | Ask GA2 |
| A8 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational Dutch is real but short of working fluency. As a "plus", it is a differentiator and not a barrier | `[grounded]` your stated level | Describe it exactly as "conversational" |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| GA1 | Temperature compliance (A6, important) | discovery | Nothing in your background touches temperature-controlled freight or its reporting | It is the one duty in the posting that is specific to cold chain, and it is what separates this role from a generic delivery-analyst post | Temperature-sensitive parcels such as pharma or food; SLA or breach reporting; exception reports to depot managers | A sanitized exception report or SLA dashboard | `[grounded]` background silence; `[generic]` that cold-chain posts weigh this duty heavily |
| GA2 | Route changes with depot managers (A7, important) | discovery | A dashboard and a weekly review, but no route change you recommended or saw adopted | A recommendation that was acted on is the strongest proof for this duty | A review that led to a depot re-sequencing, a cut-off change or a lane change; a decision traced to your data | A review deck or a before-and-after metric, sanitized | `[grounded]` background; `[inferred]` that it lifts A7 |
| GA3 | Dutch (A8, preferred) | transferability | Conversational Dutch against a role that may use it with depot staff | Spoken Dutch could carry real weight in depot conversations, but the posting calls Dutch only a plus | Depot-floor conversations in Dutch; Dutch-language dashboards or emails | A recent Dutch work email or call | `[grounded]` your stated level; `[generic]` that depot-facing roles use spoken Dutch |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| AR1 | Employer not established, research refused | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | The employer may be too small to have a footprint, the posting may be stale, or it may not represent a live hiring employer. Nothing could be checked here | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your careers site, and who would I be interviewing with? | unresolved |
| AR2 | Salary not stated | unknown | — | Posting lists no pay | The pay may sit below your floor, or the employer may not publish pay | `[inferred]` from the posting's silence | What salary range is budgeted for this post? | unresolved |
| AR3 | Duties and tools are concrete | positive_signal | — | "build weekly dashboards in Power BI, and work with depot managers on route changes" | Scope is defined and matches work you already do | `[grounded]` posting | What would success look like in the first 90 days? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead the CV with the on-time delivery dashboard and the weekly route-performance review, in your own existing wording | See A4, A5, A7 | `[grounded]` your stated background | pending your approval |
| P2 | State your Dutch exactly as "conversational", never "working" or "fluent" | See A8 | `[grounded]` your stated level | pending your approval |
| P3 | Settle the commute question before investing in the process | See A1 | `[grounded]` posting term | pending your approval |
| P4 | Ask AR1, AR2 and AR3's questions verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

If you decide to apply, resume-tailor can tailor your CV to this role.

---

# Second role — Kroonhaven Foods

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, Utrecht, a chilled ready-meals producer | `[grounded]` posting header |
| Mandate | Own the 13-week supply plan, balance production capacity against forecast, run the weekly S&OP meeting | `[grounded]` posting |
| Working pattern | On-site in Utrecht | `[grounded]` posting |
| Scope read | One full planning seat with ownership of the plan itself, not an analyst-support post | `[inferred]` from "own" and "run" against the duty list |
| Market calibration | Not available: the role-family search was refused, and the posting states no salary | — |
| Unknowns | Salary, team size, which planning system is in use, and how strictly the experience years are applied | `[grounded]` posting silence |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| B1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | You gave no location or constraint. Utrecht is a different city from your Amsterdam employer | `[grounded]` posting term; your home base is not stated | Ask the A1/B1 question |
| B2 | 3+ years of supply or demand planning in FMCG | must_have | absent | none | capability | You said you have never worked in planning. This is a length-of-experience requirement, not a gate, and it is graded on evidence | `[grounded]` your own statement | Closure path in GB1 |
| B3 | Own the 13-week supply plan; balance capacity against forecast | must_have | absent | none | capability | No capacity-versus-forecast balancing appears in your background | `[grounded]` your stated background | Closure path in GB1 |
| B4 | Run the weekly S&OP meeting | must_have | adjacent | low | transferability | You ran a weekly route-performance review. S&OP is a cross-functional demand and supply trade-off meeting, which that review did not exercise, so I took the lower band | `[grounded]` your stated background; `[generic]` what S&OP involves | Ask only if you pursue the role |
| B5 | Advanced Excel | must_have | unclear | none | discovery | Excel is not mentioned in your background, and your stated tools are SQL and Power BI | `[grounded]` background silence | Ask only if you pursue the role |
| B6 | SAP IBP or a similar planning system | must_have | absent | none | capability | SQL and Power BI are analytics tools, not planning systems | `[grounded]` your stated tools; `[generic]` that planning systems are a separate category | Closure path in GB1 |
| B7 | Fluent Dutch | must_have | adjacent | medium | transferability | Your Dutch is conversational, which is short of the "fluent" the posting requires | `[grounded]` your stated level against the posting | See GB3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| GB1 | Planning ownership and system (B2, B3, B6; must_have) | capability | No planning work and no planning-system exposure | Three must-haves are open at once, and the role is the planning seat itself | Closure path: planning-system training, or a scoped-down target such as a planning-analyst or supply-chain-analyst post that uses your analytics skill | A planning-system certificate or a forecast-versus-actual analysis you built | `[grounded]` your own statement; `[generic]` that analyst-level planning posts exist |
| GB2 | S&OP-style meeting (B4, must_have) | transferability | A weekly review you ran, in a different domain | It is the closest bridge you have to this role | The review's inputs, decisions and follow-ups, set against a demand-supply trade-off | The review agenda or decision log, sanitized | `[grounded]` background; the limit is `[generic]` |
| GB3 | Dutch fluency (B7, must_have) | transferability | Conversational Dutch against a fluent requirement | Fluency may decide the screen on its own | A formal level result, if one exists | A CEFR result such as a certificate | `[grounded]` your stated level |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| BR1 | Employer not established, research refused | risk_signal | medium | "Kroonhaven Foods, Utrecht" | The employer may be too small to have a footprint, the posting may be stale, or it may not represent a live hiring employer. Nothing could be checked here | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your careers site, and who would I be interviewing with? | unresolved |
| BR2 | Salary not stated | unknown | — | Posting lists no pay | The pay may sit below your floor, or the employer may not publish pay | `[inferred]` from the posting's silence | What salary range is budgeted for this post? | unresolved |
| BR3 | Scope and requirements are explicit | positive_signal | — | "Own the 13-week supply plan ... run the weekly S&OP meeting" | The post is clearly defined, and the requirements stated are the ones the employer will screen on | `[grounded]` posting | Which of the stated requirements are flexible for the right candidate? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P5 | Do not apply to this posting as written | See B2, B3, B6, B7 | `[grounded]` map rows | pending your approval |
| P6 | Look for analyst-level roles in supply chain or planning that use SQL and Power BI, as a stepping-stone toward planning | See GB1 | `[generic]` role-family pattern | pending your approval |
| P7 | If you apply anyway, ask BR1, BR2 and BR3's questions verbatim | See the register | `[grounded]` register | pending your approval |

---

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches "Duinvaart Cold Chain Rotterdam" and "Kroonhaven Foods Utrecht chilled ready meals" were both refused. It would have moved each role reality's organization row and AR1 and BR1 |
| 2. Role-family sweep | unavailable | Searches "operations analyst logistics Rotterdam salary Netherlands" and "supply planner FMCG Netherlands salary requirements" were both refused. It would have moved each market calibration row and the salary entries AR2 and BR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

A deeper research pass would also cover company diligence and recent news (up to 5 more searches and 2 more fetches). Say the word and it runs, if search access is granted.

I can also save this as `tuesday-dossier.md` if you want a file you can reuse later.

## Upgrade menu

- A workable-commute answer, or your location → A1 and B1 resolve, and A1 is the one open hard gate on the role I'd pursue.
- A sanitized exception or SLA report, or any temperature-related reporting you've done → A6 moves off `unclear`.
- A route-change example or review deck → A7 firms up.
- A dashboard screenshot or query sample → A3 and A4 can reach `high`.
- Search access → the employer checks (AR1, BR1) and a salary band for both roles.

## Questions

A1/B1 — Where do you live, and are three days a week in Rotterdam for the first role (and five days in Utrecht for the second) workable for you?

GA1 — Have you ever reported on temperature-sensitive or time-critical freight, or on breach and SLA exceptions? That could be pharma or food parcels, or exception reports sent to depot managers.

GA2 — Did your weekly route-performance review ever lead to a route or depot change that you proposed or backed with data? What did you own, and what happened?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.