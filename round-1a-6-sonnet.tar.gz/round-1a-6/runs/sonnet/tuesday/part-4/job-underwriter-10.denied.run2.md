Web searches were declined, so this first pass rests on your posting and messages, and nothing here has been checked against the web.

## Decision snapshot

**Yes, take the call and apply. I couldn't establish Fernquay from here, so treat the company as unverified until you've checked it yourself (RR1). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Two office days a week in Galway), R2 (Pay €52,000–€60,000 plus equity)
- `must_have` — direct: R3, R4, R5, R6 · adjacent: R7 (Own the booking flow end to end)
- `important` — adjacent: R9 (First and only designer) · unclear: R8 (Research calls with school owners)

R7 — the checkout redesign bridges to the whole flow, limit named; R8 — owner-facing research is untested by what you've told me; R9 — solo-designer evidence is thin.

**Opportunity ledger.** The role as written is concrete, with scope, collaborators, pay range and hybrid terms stated (RR3). The employer is unverified (RR1), design decision rights and support are unstated (RR2), and the equity terms are unstated (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Two office days a week in Galway), R2 (Pay €52,000–€60,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Fernquay verifies through its own site, not through links in the messages (RR1); (2) pay and equity meet your needs (R2, RR4); (3) it is clear who decides design questions and who you can learn from (R9, RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, booking software for sea-kayak and surf schools. This is the posting's own description; I could not check it | `[grounded]` posting |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship alongside two engineers, work most closely with co-founder Ronan Kehoe | `[grounded]` posting |
| Working pattern | Hybrid, two days a week in the Galway office, otherwise flexible | `[grounded]` posting |
| Pay | €52,000–€60,000 plus 0.5–1% equity; vesting, instrument and share base not stated | `[grounded]` posting |
| Scope read | A one-person design function: flow ownership, research and shipping all sit with one hire, with no design peer named | `[inferred]` from "first designer" against the posting's silence on design colleagues |
| Market calibration | Not established. The role-family search did not run, so I give no salary band and no norm for this scope | `[grounded]` the search was refused |
| Unknowns | Equity terms; who has final say on design; contract basis; first-year outcomes; start date; company funding and customer base | — |
| Contradictions | None inside the posting. Your report that there is little about them online is not yet checked against anything | `[grounded]` your message |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two office days a week in Galway | hard_gate | unclear | medium | hard_gate | You live in Galway, but you haven't said whether two fixed office days work for you | `[grounded]` your message; posting | Confirm for yourself before the call |
| R2 | Pay €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | No pay floor given, so I can't say whether the range clears it. The equity can't be valued without its terms (RR4) | `[grounded]` posting; no floor stated | G4: say your floor |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company, in your own words. No CV or portfolio inspected, so `medium` | `[grounded]` your message | A portfolio link would raise it |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" is stated; "strong" would be judged on work shown | `[grounded]` your message | Share a Figma file or case study |
| R5 | You have run your own user research | must_have | direct | medium | none | Monthly usability sessions with customers. This is usability testing, not owner interviews, which is R8 | `[grounded]` your message | none |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | Worked in a squad with four engineers | `[grounded]` your message | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | transferability | Redesigning checkout is a real bridge. Limit: checkout is one stage, and you haven't said whether you owned the wider flow | `[grounded]` your message; `[generic]` that "end to end" usually spans more than checkout | G1 |
| R8 | Run research calls with school owners | important | unclear | low | discovery | Usability sessions with customers don't show interviews with business owners. You may have done some, and I haven't asked | `[grounded]` your message; `[generic]` that owner interviews differ from consumer testing | G2 |
| R9 | First and only designer | important | adjacent | low | transferability | You've worked in a squad but never as the only designer. Whether you set process alone is not established | `[inferred]` from "first designer" in the posting; `[grounded]` your message | Say it plainly on the call (A3) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Whole-flow ownership (R7, must_have) | transferability | Checkout redesign confirmed; wider flow and decision rights not | It is the posting's first responsibility, and it sits at `adjacent` | Owning search-to-confirmation steps, changes and cancellations, or confirmation emails; deciding what shipped | The checkout case study, before/after screens, a flow map | `[grounded]` your message; `[inferred]` it is the likeliest probe |
| G2 | Owner-facing research (R8, important) | discovery | Customer usability sessions only | The role's research is with school owners, who are business users | Interviews with merchants, partners or ops staff; sessions that shaped a back-office tool | A research plan, a synthesis, a sanitised interview guide | `[grounded]` your message; `[generic]` that the role family probes this |
| G3 | Solo-designer capacity (R9, important) | transferability | Squad member, never the only designer | A first-designer post carries no design peer | Setting up a design process or file structure; deciding design questions without a lead | A concrete example of a decision you made alone | `[grounded]` your message |
| G4 | Pay floor (R2, hard_gate) | hard_gate | Range stated, floor not | A gate the inputs don't settle stays open until you answer | n/a | n/a | `[grounded]` posting |
| G5 | Office days (R1, hard_gate) | hard_gate | Galway-based, schedule not confirmed | Same | n/a | n/a | `[grounded]` your message |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools." | The company may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer; none is more likely than the others | `[generic]` pattern for companies of this size, not a claim about this one; `[grounded]` you report finding little online, which I could not check | Can you point me at this role on your own careers site, and who I'd be interviewing with? | unresolved |
| RR2 | Design decision rights and support unstated | unknown | — | "You would be our first designer … work most closely with our co-founder, Ronan Kehoe" | You may own design with no senior peer to review it, and decisions may sit with the co-founder | `[inferred]` from the first-designer scope against the posting's silence on who decides | Who has the final say on design decisions, and how are design–engineering disagreements settled? | unresolved |
| RR3 | Scope, collaborators and pay range stated openly | positive_signal | — | "own the booking flow end to end … ship alongside our two engineers … €52,000–€60,000" | The role is concretely defined, and the pay range is stated | `[grounded]` posting | What does success look like in your first six months? | noted |
| RR4 | Equity terms unstated | unknown | — | "0.5–1% equity" | The percentage may be options or shares, subject to vesting, of an unstated share base; its value can't be estimated | `[inferred]` from the posting's silence on terms | Is it options or shares, what is the vesting schedule, and what share count is the percentage of? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, look up Fernquay's own site yourself (don't use the invite link). Check the role is listed, Ronan and Saoirse appear, and the invite email's sender domain matches the site | RR1. The WhatsApp message only schedules a video call, and asks nothing of you but your time. Scheduling by chat for a call held elsewhere is routine, so the message itself is no cause for concern. Checking the company is just good practice | `[grounded]` the message's content; `[generic]` that chat scheduling is routine | pending your approval |
| A2 | Ask RR1–RR4's verification questions in the call, word for word | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A3 | Open with your checkout redesign and monthly usability sessions. Say plainly that you worked in a squad with four engineers and haven't been the only designer. Bring the checkout case study they mentioned as your "one messy real project" | R7, R9; the posting asks for real work over a polished deck, and every clause traces to your own sentences | `[grounded]` posting quote; your messages | pending your approval |

For rehearsing the call with Ronan and Saoirse, mock-interview is the module for that.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches "Fernquay booking software sea kayak surf schools Galway" and "Fernquay Product Designer Galway careers" were refused. They would have fed role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | Search "product designer salary Ireland Galway startup first designer equity" was refused. It would have fed market calibration and R2 |
| 3. Hiring manager's public footprint | unavailable | Search "Ronan Kehoe Fernquay co-founder" was refused; the name was given, so a query could form. It would have fed the scope read and A3. Public professional footprint only |

I can save all this as a `tuesday-dossier.md` if you want to carry it into later steps.

## Upgrade menu

- Permission to run the three searches above → RR1 and the market calibration could settle, and the scope read gets grounded.
- A link to the live posting on Fernquay's own careers page → RR1 closes or stays open on evidence.
- Your portfolio or the checkout case study → R3–R7 can rise above `medium`; in design, the portfolio is the inspectable artifact.
- Your salary floor and any other non-negotiables → R1 and R2 resolve, and the hard-gates line stops flagging them as unchecked.
- The equity terms in writing → RR4 closes.

G4 — What is the lowest salary you'd accept, and does the 0.5–1% equity count toward that or is it a bonus on top?

G1 — In the checkout redesign, what else did you own beyond the checkout screens (search, confirmation, changes, cancellations), and who made the final calls?

G2 — Have you ever interviewed business users such as merchants, partners or ops staff, as opposed to customers? What did you learn, and what changed because of it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.