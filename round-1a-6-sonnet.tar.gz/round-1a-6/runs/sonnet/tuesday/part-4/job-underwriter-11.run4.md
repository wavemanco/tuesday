## Decision snapshot

**Duinvaart: yes, worth your time. Status: `conditional_go`. Kroonhaven: no, a poor use of your time. Status: `no_go`.**

### Duinvaart Cold Chain, Operations Analyst

**Fit ledger.**

- `hard_gate` — unclear: R1 (Hybrid, three days in Rotterdam office)
- `must_have` — direct: R2, R3, R4
- `important` — direct: R5, R7 · unclear: R6 (Temperature compliance across the refrigerated fleet)
- `preferred` — adjacent: R8 (Dutch a plus)

R6 — no cold-chain evidence either way; R8 (`medium`) — conversational Dutch against a stated plus.

**Opportunity ledger.** The scope is concrete and measurable (RR3), but the pay is unstated (RR2) and I could not verify the employer or the live posting (RR1).

- **Hard gates:** none failed; unconfirmed: R1 (Hybrid, three days in Rotterdam office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1: the Rotterdam three-day commute from Amsterdam works for you; (2) RR1: the employer and the live posting verify on the employer's own careers page; (3) R6: you can name any temperature- or time-critical shipment work, or you accept this as the gap to expect questions on.

### Kroonhaven Foods, Supply Planner

**Fit ledger.**

- `hard_gate` — unclear: R9 (On-site in Utrecht)
- `must_have` — adjacent: R13 (Own the 13-week supply plan and run weekly S&OP), R14 (Fluent Dutch) · unclear: R11 (Advanced Excel) · absent: R10 (3+ years supply or demand planning in FMCG), R12 (SAP IBP or a similar planning system)

R10, R12 — you told me you have never worked in planning; R13 (`medium`) — the weekly route-performance review is a bridge with a stated limit.

**Opportunity ledger.** I could not verify the employer or the live posting (RR4), and pay is unstated (RR5). Neither is the reason for the call, which comes from the fit side.

- **Hard gates:** none failed; unconfirmed: R9 (On-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** R10 and R12 would have to be false, meaning planning-role or planning-system work you haven't mentioned. R14 would also have to move from conversational to fluent. Absent those, this is a role for a later move, not now.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Duinvaart: organization | Duinvaart Cold Chain, Rotterdam, a refrigerated-fleet operator. Not verified against any outside source | `[grounded]` JD header |
| Duinvaart: mandate | Track on-time delivery and temperature compliance, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` JD |
| Duinvaart: working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` JD |
| Duinvaart: scope read | One analyst serving depot managers, with outputs (weekly dashboards, route changes) named. This closely matches the dashboard and weekly review you described | `[inferred]` from the JD's duties against your stated work |
| Duinvaart: unknowns | Pay, team size, reporting line, how much Dutch the day-to-day needs, who owns the temperature data | `[grounded]` JD silence |
| Kroonhaven: organization | Kroonhaven Foods, Utrecht, chilled ready-meals. Not verified against any outside source | `[grounded]` JD header |
| Kroonhaven: mandate | Own the 13-week supply plan for chilled ready-meals, balance production capacity against forecast, run the weekly S&OP meeting | `[grounded]` JD |
| Kroonhaven: working pattern | On-site in Utrecht, no hybrid stated | `[grounded]` JD |
| Kroonhaven: unknowns | Pay, team, planning-system version, how the S&OP forum is staffed | `[grounded]` JD silence |
| Market calibration (both) | Not established: my searches were refused, so I state no salary band and no title norms | `[grounded]` no research result in hand |

## Evidence map

Your background was given in prose, which counts as CV-level evidence. That caps each confidence at `medium` until you show an artifact.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Duinvaart: hybrid, three days a week in the Rotterdam office | hard_gate | unclear | low | hard_gate | You work in Amsterdam now and gave no commute or location limit, so whether this term is met is unsettled | `[grounded]` your Amsterdam employer, JD terms; `[inferred]` home location | G1 |
| R2 | Duinvaart: 2+ years in logistics or operations analysis | must_have | direct | medium | none | 4 years as an operations analyst at a parcel carrier, which is logistics work. Confirmed in prose, no artifact yet | `[grounded]` your background | none |
| R3 | Duinvaart: strong SQL | must_have | direct | medium | none | "SQL daily", confirmed, no inspectable sample. "Strong" will be probed | `[grounded]` your background | offer: a sanitized query or schema description would raise to high |
| R4 | Duinvaart: Power BI or Tableau | must_have | direct | medium | none | Power BI daily, including a dashboard depot managers use | `[grounded]` your background | offer: a screenshot of the on-time delivery dashboard (sanitized) would raise to high |
| R5 | Duinvaart: track on-time delivery | important | direct | medium | presentation | You built the on-time delivery dashboard depot managers use. That is the posting's headline duty, so it should lead your CV | `[grounded]` your background | E1 |
| R6 | Duinvaart: track temperature compliance on a refrigerated fleet | important | unclear | none | discovery | Nothing you gave touches temperature data. Parcel on-time work is a different kind of work, so I don't bridge it | `[grounded]` your background silence | G2 |
| R7 | Duinvaart: work with depot managers on route changes | important | direct | medium | presentation | You ran the weekly route-performance review and depot managers use your dashboard. Whether route changes resulted from it is unstated, so I don't claim it | `[grounded]` your background | E1; ask whether route changes followed |
| R8 | Duinvaart: Dutch a plus | preferred | adjacent | medium | transferability | Conversational Dutch is real but short of fluent. The posting calls Dutch a plus, so it is a bonus, not a bar | `[grounded]` your Dutch level, JD wording | state it as "conversational Dutch" |
| R9 | Kroonhaven: on-site in Utrecht | hard_gate | unclear | low | hard_gate | No hybrid option, and your Utrecht access is unstated | `[grounded]` JD, your Amsterdam employer | answer G1 for both roles |
| R10 | Kroonhaven: 3+ years of supply or demand planning in FMCG | must_have | absent | none | capability | You have never worked in planning. Analyst work on delivery performance is not planning, and it is not FMCG | `[grounded]` your statement | closure path in G3 |
| R11 | Kroonhaven: advanced Excel | must_have | unclear | none | discovery | Your tools are SQL and Power BI. Excel use is unmentioned | `[grounded]` your background silence | none; not worth recovering given R10 and R12 |
| R12 | Kroonhaven: SAP IBP or a similar planning system | must_have | absent | none | capability | A BI tool and SQL are reporting tools, not planning systems | `[grounded]` your background | closure path in G3 |
| R13 | Kroonhaven: own the 13-week supply plan, run the weekly S&OP meeting | must_have | adjacent | medium | transferability | Bridge: you ran a weekly cross-team performance review. Limit: it covered no forecast, capacity or supply balancing, and it wasn't a planning forum | `[grounded]` your background; `[generic]` that S&OP weighs forecast against capacity | none |
| R14 | Kroonhaven: fluent Dutch | must_have | adjacent | medium | transferability | Conversational Dutch against a fluent requirement in a role that leads a weekly meeting | `[grounded]` your Dutch level, JD wording | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Rotterdam office days / Utrecht on-site (R1, R9) | hard_gate | Neither commute is settled by what you gave me | A gate that is not met cannot be solved by wording, and R1 gates the stronger of the two roles | Not an experience gap; it is a term you meet or don't | Your own statement of what commute you accept | `[grounded]` JD terms; `[inferred]` that this is unsettled |
| G2 | Temperature compliance (R6) | discovery | The parcel work you described shows no temperature data | The posting names temperature compliance as the second duty, so a clear answer here changes how you pitch | Tracking chilled, pharma or other temperature-controlled parcels; SLA breach or exception reporting with a time limit; any cold-store or food-safety reporting | An exception report, an SLA definition, or a dashboard view with the sensitive data removed | `[grounded]` your background silence; `[generic]` that cold-chain roles check this early |
| G3 | Planning experience and tools (R10, R12) | capability | No evidence of planning work or a planning system | These are two of the five must-have rows for Kroonhaven, and neither closes quickly | Not asked; you said you have never worked in planning | None | `[grounded]` your statement; `[generic]` that closing this takes a planning-titled step first, and that supply-chain analyst or junior planner roles are the usual bridge |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Duinvaart: employer not established from attributable sources | risk_signal | medium | "Operations Analyst — Duinvaart Cold Chain, Rotterdam" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. The search was refused, so this is unchecked | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be working with? | unresolved |
| RR2 | Duinvaart: pay unstated | unknown | — | no salary in the posting | The figure may fall below what you need, or the company may not publish salary | `[inferred]` from the posting's silence; band not established | What is the budgeted salary range for this role? | unresolved |
| RR3 | Duinvaart: duties and outputs concrete | positive_signal | — | "build weekly dashboards in Power BI, and work with depot managers on route changes" | The role's work is defined, not open-ended | `[grounded]` JD | Who owns the temperature data feeding the dashboards today? | noted |
| RR4 | Kroonhaven: employer not established from attributable sources | risk_signal | medium | "Supply Planner — Kroonhaven Foods, Utrecht" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. The search was refused, so this is unchecked | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be working with? | unresolved |
| RR5 | Kroonhaven: pay unstated | unknown | — | no salary in the posting | The figure may fall below what you need, or the company may not publish salary | `[inferred]` from the posting's silence; band not established | What is the budgeted salary range for this role? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | On your CV, lead with the on-time delivery dashboard depot managers use, then the weekly route-performance review you ran. Describe your Dutch as "conversational Dutch". Add nothing about temperature data or route-change results unless you confirm it | see R5, R7, R8 | `[grounded]` your own sentences | `resume_edits_pending_approval` |
| A1 | Confirm the employer and the live posting on the employer's own careers page before you invest effort | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | In a first conversation, ask RR2 and RR3's questions verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A3 | Skip Kroonhaven for now, and spend the time on analyst roles like Duinvaart | see R10, R12, R14 | `[grounded]` rows named | pending your approval |

E1 and every other row above, including the positioning advice in E1, are proposed only. Nothing changes until you approve. Rewriting the CV against the Duinvaart posting is resume-tailor's job.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page, Duinvaart | unavailable | Sent "Duinvaart Cold Chain Rotterdam"; the call was refused. It would have fed role reality's organization row and RR1 |
| 1. Official site and careers page, Kroonhaven | unavailable | Sent "Kroonhaven Foods Utrecht"; the call was refused. It would have fed role reality and RR4 |
| 2. Role-family sweep, Duinvaart | unavailable | Sent "operations analyst logistics Rotterdam salary Netherlands"; refused. It would have fed the market calibration and RR2 |
| 2. Role-family sweep, Kroonhaven | unavailable | Sent "supply planner FMCG Netherlands salary SAP IBP requirements"; refused. It would have fed the market calibration and RR5 |
| 3. Hiring manager's public footprint | n/a | No name was given |

I will not retry the searches. Everything labeled `[generic]` above stands on pattern only.

I can write this up as a `tuesday-dossier.md` if you want it.

## Upgrade menu

- A sanitized screenshot of your on-time delivery dashboard, or a query sample, would raise R3, R4 and R5 to `high`.
- An answer to G2, or an exception or SLA report, would resolve R6.
- Your commute limit and pay floor would settle R1 and R9, and RR2 and RR5 could be set against your floor.
- Search access, if you grant it, would let me check both employers and give a salary band for each.

## Questions

G1 — From Amsterdam, can you do three days a week in Rotterdam (Duinvaart), and would Utrecht on-site five days (Kroonhaven) work? Do you have a pay floor or any other non-negotiable I should check these against?

G2 — Have you tracked any temperature-controlled, chilled or other time-critical shipments, such as exception or SLA breach reports? What did you own, and is there anything you could show?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.