Search permission was declined, so I'm working only from the text you pasted. The employer checks are marked as not done.

## Decision snapshot

**Duinvaart (Operations Analyst): yes, worth your time, on conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Hybrid, three days a week in Rotterdam)
- `must_have`: direct: R2, R3, R4
- `important`: direct: R5 · adjacent: R7 (Work with depot managers on route changes) · unclear: R6 (Temperature compliance tracking)
- `preferred`: direct: R8

R6 — cold-chain monitoring not evidenced, a question away; R7 — your route-performance review sits next to route changes, decision role unconfirmed.

**Opportunity ledger.** The duties are concrete (RR3). The employer and posting are unverified (RR1) and pay is not stated (RR2).

- **Hard gates:** none failed; unconfirmed: R1 (Hybrid, three days a week in Rotterdam); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the Rotterdam office days work for you, which settles R1; (2) the employer and live posting are verified, which settles RR1; (3) R6 and R7 are presented as adjacent work, never as cold-chain or route-change ownership.

**Kroonhaven (Supply Planner): no, not worth your time. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R9 (On-site in Utrecht)
- `must_have`: adjacent: R13 (Fluent Dutch) · unclear: R11 (Advanced Excel) · absent: R10 (3+ years planning in FMCG), R12 (SAP IBP or similar planning system)
- `important`: adjacent: R15 (Run the weekly S&OP meeting) · absent: R14 (Own the 13-week supply plan)

R10, R12 — planning experience and planning-system work are missing, and you told me you've never worked in planning; R15 — a bridge from your weekly review, limit named.

**Opportunity ledger.** The employer is unverified (RR4) and pay is not stated (RR5).

- **Hard gates:** none failed; unconfirmed: R9 (On-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** R10 and R12 would have to be met by planning work you haven't mentioned, or the employer would have to waive them. R13 would also need to be settled.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Duinvaart mandate | Track on-time delivery and temperature compliance for a refrigerated fleet, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` posting |
| Duinvaart pattern | Hybrid, three days in the Rotterdam office | `[grounded]` posting |
| Duinvaart scope read | An analyst-level reporting role, close to your current title | `[inferred]` from the duties against your 4 years as an operations analyst |
| Kroonhaven mandate | Own a 13-week supply plan for chilled ready-meals, balance capacity against forecast, run the weekly S&OP meeting | `[grounded]` posting |
| Kroonhaven pattern | On-site in Utrecht | `[grounded]` posting |
| Kroonhaven scope read | A plan-owner role, a different job from analyst work | `[inferred]` from "own", "balance" and "run" in the duties |
| Market calibration | Not run, because search was declined, so no pay or scope band for either role | — |
| Unknowns | Salary for both; reporting line; how temperature compliance is measured at Duinvaart | `[grounded]` absent from the postings as pasted |
| Contradictions | None between the postings and your background; employer pages not checked | `[grounded]` the texts you gave me |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Duinvaart: hybrid, three days a week in Rotterdam | hard_gate | unclear | none | hard_gate | You gave no home location or commute limit, so whether the term is met is not established | `[grounded]` no constraint stated | Ask whether it is workable (closing question) |
| R2 | Duinvaart: 2+ years in logistics or operations analysis | must_have | direct | medium | none | 4 years as an operations analyst at a parcel carrier. Confirmed and specific, with no inspectable artifact yet | `[grounded]` your background | none |
| R3 | Duinvaart: strong SQL | must_have | direct | medium | none | You use SQL daily. "Strong" is your own level claim, so expect a technical probe | `[grounded]` your background | A query sample would raise it to high |
| R4 | Duinvaart: Power BI or Tableau | must_have | direct | medium | none | Daily Power BI, including the on-time delivery dashboard depot managers use | `[grounded]` your background | A sanitized dashboard screenshot would raise it to high |
| R5 | Duinvaart: track on-time delivery | important | direct | medium | presentation | Your dashboard is on-time delivery by name, so it should lead your CV | `[grounded]` your background | Edit E1 |
| R6 | Duinvaart: track temperature compliance on a refrigerated fleet | important | unclear | none | discovery | Nothing in what you gave me mentions temperature-controlled or compliance work | `[grounded]` silence in your background | Closing question on R6 |
| R7 | Duinvaart: work with depot managers on route changes | important | adjacent | medium | discovery | You ran the weekly route-performance review. Whether you proposed or decided route changes is not stated, so I take the lower reading | `[grounded]` your review; `[inferred]` that it is next to route changes | Closing question on R7 |
| R8 | Duinvaart: Dutch a plus | preferred | direct | medium | none | Conversational Dutch meets a "plus". Level is self-described | `[grounded]` your background | none |
| R9 | Kroonhaven: on-site in Utrecht | hard_gate | unclear | none | hard_gate | No location or commute constraint stated | `[grounded]` no constraint stated | Moot while the status is `no_go` |
| R10 | Kroonhaven: 3+ years supply or demand planning in FMCG | must_have | absent | none | capability | You said you have never worked in planning, and a parcel carrier is not FMCG | `[grounded]` your statement | Closure path in G3 |
| R11 | Kroonhaven: advanced Excel | must_have | unclear | none | discovery | Your stated tools are SQL and Power BI, and Excel is not mentioned | `[grounded]` silence | none, since R10 and R12 decide the status |
| R12 | Kroonhaven: SAP IBP or similar planning system | must_have | absent | none | capability | SQL and Power BI are reporting tools, not planning systems | `[inferred]` from the tool categories | Closure path in G3 |
| R13 | Kroonhaven: fluent Dutch | must_have | adjacent | medium | transferability | Conversational Dutch is below fluent, and the posting says fluent | `[grounded]` your background | See G4 |
| R14 | Kroonhaven: own the 13-week supply plan | important | absent | none | capability | No planning ownership stated | `[grounded]` your statement | Closure path in G3 |
| R15 | Kroonhaven: run the weekly S&OP meeting | important | adjacent | medium | transferability | You ran a weekly route-performance review. It did not set a supply plan across production and demand | `[grounded]` your review; `[generic]` that S&OP is a cross-functional planning forum | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Temperature compliance (R6, important) | discovery | No cold-chain or compliance work appears in your background | It is half of Duinvaart's headline duty, so an interview will probe it | Reefer or temperature-logger data at the carrier; excursion or claims reporting; any food, pharma or chilled lane; SLA breach reporting | A sanitized report or dashboard page showing a compliance measure | `[grounded]` silence; `[generic]` that headline duties get probed |
| G2 | Route changes with depot managers (R7, important) | discovery | You ran the review, and it is unclear whether you proposed or decided changes | The line decides whether you say "supported" or "led" | Recommendations you made that a depot adopted; a route or sort change your analysis triggered | A review deck or an email trail | `[grounded]` your review |
| G3 | Planning experience and system (R10, R12, R14, R15; Kroonhaven) | capability | You have no planning work or planning-system use | Several Kroonhaven must-haves rest on it. A realistic path is a scoped-down target such as demand or supply planning at a logistics firm, or a planning-tool course | Not applicable until a path is chosen | n/a | `[grounded]` your statement; `[generic]` that planning roles screen on titled years |
| G4 | Dutch level (R13, must_have) | transferability | Conversational, against a fluent requirement | A written or spoken test is plausible | Work meetings or documents in Dutch | A certificate or level score | `[grounded]` your background; `[generic]` that fluent is often tested |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Duinvaart employer and posting not verified | unknown | — | "Operations Analyst — Duinvaart Cold Chain, Rotterdam" | The check was not run, so nothing is known either way | `[grounded]` search declined | Can you point me to this role on your careers page, and say who I would report to? | unresolved |
| RR2 | Duinvaart pay not stated | unknown | — | no salary line in the posting as pasted | The posting may simply omit it, or your paste may be an excerpt | `[inferred]` from the pasted text | What is the salary range for this post? | unresolved |
| RR3 | Duinvaart duties are concrete | positive_signal | — | "Track on-time delivery and temperature compliance across our refrigerated fleet, build weekly dashboards in Power BI" | The role has a defined core | `[grounded]` posting | Who owns the on-time and temperature targets today? | noted |
| RR4 | Kroonhaven employer and posting not verified | unknown | — | "Supply Planner — Kroonhaven Foods, Utrecht" | The check was not run | `[grounded]` search declined | Can you point me to this role on your careers page? | unresolved |
| RR5 | Kroonhaven pay not stated | unknown | — | no salary line in the posting as pasted | As RR2 | `[inferred]` from the pasted text | What is the salary range for this post? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Duinvaart CV lead: "Power BI on-time delivery dashboard used by depot managers" and "Ran the weekly route-performance review". I wrote "used by", not "built", because your wording doesn't say who built it | R4, R5, R7 | `[grounded]` your background, audited clause by clause | `resume_edits_pending_approval` |
| P1 | Duinvaart positioning: open with the on-time dashboard, then say plainly that you haven't done temperature compliance but have done the same kind of delivery-performance monitoring | R5, R6 | `[inferred]` bridge, with its limit named | pending your approval |
| A1 | Verify the employer and live posting before investing effort | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Put Kroonhaven at the bottom of your list. If you apply anyway, don't claim planning experience | R10, R12 | `[grounded]` R10, R12 rows | pending your approval |

For tailoring the CV line by line, resume-tailor is the module to use.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both company searches were refused (Duinvaart Cold Chain, Kroonhaven Foods). It would have moved RR1 and RR4 |
| 2. Role-family sweep | unavailable | The search was refused. It would have given a pay and scope band for both titles |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Upgrade menu

- Permission to search → RR1 and RR4 resolve, and a pay band appears for both titles.
- A sanitized dashboard screenshot or SQL sample → R3 and R4 rise to `high`.
- An answer on temperature or compliance work → R6 and G1 resolve.
- An answer on route changes → R7 resolves.
- Your home location → R1 resolves.

If you'd like, I can save this as a `tuesday-dossier.md` for later steps.

## Questions

R1 — Is three days a week in Rotterdam workable from where you live?

G1 (R6) — Have you worked with temperature or compliance data, for example reefer or logger data, or excursion or SLA-breach reporting? What did you own, and is there something you could share?

G2 (R7) — Has a depot changed a route because of your analysis? What did you recommend, and who decided?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.