I've run four searches, and they confirm the company and the posting. I'm now fetching the careers page to check it matches what you were sent, then I'll write up the assessment.
**Decision snapshot**

**Yes, worth applying. The company and posting check out on the pages I could read, and the WhatsApp message is routine. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: R2 (Salary €52,000–€60,000)
- `must_have`: direct: R3, R4, R5, R6 · adjacent: R7 (Own the booking flow end to end)
- `important`: adjacent: R8 (First and only designer) · unclear: R9 (Research calls with school owners)

R7: the checkout redesign is a credible bridge, and whether you owned more than checkout is unconfirmed; R8: squad work is the bridge, and it is not sole-designer experience; R2: your pay floor hasn't been given yet.

**Opportunity ledger.** The company, the posting and the pay range are stated openly (RR3). Equity terms (RR1) and runway (RR2) are unknown. The WhatsApp invite is routine scheduling for a video call held elsewhere, so it takes no register entry.

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the range clears your own pay floor (R2); (2) you get answers on equity terms and runway before accepting (RR1, RR2); (3) you frame end-to-end ownership and sole-designer scope honestly (R7, R8).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle, "funded by its customers". It makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland | `[grounded]` About page (fernquay.example/about), seen as a search result |
| Posting live | A careers page lists this role: first design hire, hybrid two days a week in Galway, €52,000–€60,000 plus equity, apply with one real project | `[grounded]` careers page fetched |
| Mandate | Own the booking flow, run research calls with school owners, ship alongside two engineers, work most closely with Ronan | `[grounded]` your pasted posting |
| Hiring contact | Ronan Kehoe is co-founder and CEO, and was previously a product lead at a Galway travel-software company for five years | `[grounded]` profile snippet (linkedin.example/in/ronan-kehoe) |
| Scope read | A first-designer post with a defined flow to own, set against two engineers | `[inferred]` from the posting's mandate wording |
| Market calibration | Product designers with 3 to 5 years in Ireland: median base €57,000, interquartile range €51,500 to €62,000. The posted €52,000–€60,000 sits inside that range. This is a band, not this employer's offer | `[generic]` Tillerby survey, n=520; `[grounded]` posting figure |
| Unknowns | Equity terms; runway; Saoirse's title, which I didn't see on the pages I read | `[grounded]` pages read |
| Contradictions | None found. The careers page text I could read is shorter than your pasted posting, so the equity percentage and the dog line aren't confirmed there | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in the Galway office | hard_gate | direct | medium | none | You live in Galway, so the term is met. Medium because it is your own account with nothing to inspect | `[grounded]` your background | none |
| R2 | Salary €52,000–€60,000 | hard_gate | unclear | none | hard_gate | The posting states the figure, but you haven't told me a floor, so I can't say whether the term is met. The band sits mid-market | `[grounded]` posting; `[generic]` survey band | Ask your floor (question R2) |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company. Stated in prose, not yet inspected | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" is confirmed. Strength shows in artifacts, so a case study would raise it | `[grounded]` your background | Link the checkout case study (upgrade menu) |
| R5 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. No artifact yet | `[grounded]` your background | none |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your background | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | transferability | The checkout redesign is real booking-flow work. Limit: nothing you've said shows ownership beyond checkout | `[grounded]` your background; `[inferred]` limit from silence | See G1 |
| R8 | First and only designer (inferred from "our first designer") | important | adjacent | medium | transferability | You have never been the only designer; squad work with engineers is the bridge. Limit: no experience setting design direction alone | `[inferred]` from the posting's "first designer"; `[grounded]` your statement | See G3 |
| R9 | Run research calls with school owners | important | unclear | low | discovery | Your usability sessions were with customers, and who they were and what the sessions covered is unstated | `[grounded]` your background | See G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | End-to-end booking flow ownership (R7, must_have) | transferability | A checkout redesign, but not the steps before or after it | It is the posting's headline responsibility | Search or availability steps, confirmation emails, post-booking changes or cancellations, mobile versus desktop flows | A case study or flow map showing the wider journey | `[grounded]` your background; `[inferred]` that the wider journey is the likely follow-up |
| G2 | Research with small-business owners (R9, important) | discovery | Monthly usability sessions with customers; participants unknown | Interviewing owners differs from testing a checkout with consumers | Sessions with partner or supplier staff, customer-support interviews, any discovery calls | A research plan or sanitized session notes | `[grounded]` your background |
| G3 | Working as the only designer (R8, important) | transferability | Squad work with four engineers | You would set design direction alone | Times you made design calls without a design lead, or set up tools and process | Nothing to request; this is a limit to name | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Equity terms unstated | unknown | — | "0.5–1% equity" | The figure may come with vesting, strike and valuation terms the posting doesn't give | `[generic]` equity offers at small firms usually carry such terms | What are the vesting schedule, the strike price and the latest valuation behind that range? | unresolved |
| RR2 | Runway not stated | unknown | — | "funded by its customers" | A customer-funded company may have limited runway, or may be steadily profitable | `[generic]` pattern for customer-funded companies; `[grounded]` About page | How many months of runway does Fernquay have, and is it profitable? | unresolved |
| RR3 | Pay, scope and process stated openly | positive_signal | — | "€52,000–€60,000 plus 0.5–1% equity" | The range is stated and sits inside the surveyed band, and the ask is one real project | `[grounded]` posting and careers page; `[generic]` survey band | Who reviews the project, and what do they look for? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Reply on WhatsApp to confirm the time, and join only through the link in the emailed invite. First check that the invite came from an address on Fernquay's own domain | Scheduling by chat is routine, and this is a sensible check on the invite | `[generic]` general advice | pending your approval |
| A2 | Positioning: "Lead with the checkout redesign and the monthly usability sessions. Say plainly that you worked in a squad with four engineers and have not been the only designer." | Each clause traces to your own sentences; see R7, R8 | `[grounded]` your background | pending your approval |
| A3 | Ask RR1 and RR2 verbatim on the call, and ask Ronan which parts of the booking flow are in scope | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A4 | Tie your travel-booking background to Ronan's own travel-software history | His footprint suggests he knows that world | `[inferred]` from his public profile | pending your approval |

For the video call itself, the mock-interview module can build a prep pack and run drills if you want one.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway" and "Fernquay Product Designer Galway careers". Fetched "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer). The employer exists as described and the posting is live. This moved the Organization, Posting live and Contradictions rows |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland startup Galway", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). It moved the market calibration row and R2's reasoning |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe). It moved the Hiring contact row and A4 |

I can write this up as `tuesday-dossier.md` if you'd like to keep it.

**Upgrade menu**

- Your pay floor and any other non-negotiables → R2 resolves, and the hard-gates line stops flagging that your constraints weren't given.
- A link to the checkout case study → R4, R5 and R7 can rise toward `high`. For a designer, the inspectable artifact is the portfolio or case study.
- Sanitized notes or a plan from one usability session → R5 and R9 firm up.
- Ronan's answers on equity and runway → RR1 and RR2 close.
- A deeper pass on Fernquay (customer reviews, funding and hiring history; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

R2 — What is the lowest salary you would accept, and are there any other terms you won't trade, such as office days or start date?

G1 — Did you own any part of the booking journey beyond checkout, such as search, confirmation or changes? What was yours, and what did the team own?

G2 — Who were the customers in your monthly usability sessions, and did any sessions involve business owners or partners rather than end consumers?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.