**Yes, this is normal at this stage, and your rule is right for earlier stages. Status: `conditional_go`.** Bank details, a PPS number and passport checks come after a written offer for a named role and salary, from the employer's own domain, following two interviews you attended in person. The thing to control is where you enter them: only in Marrowgate's own onboarding portal, at an address you've checked against their website, and never as email attachments.

I couldn't run any web searches this session, so everything below comes from the ad, the offer and your background only.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Hybrid, two days in Limerick), R2 (Pay €38,000–€42,000)
- `must_have` — direct: R3, R5, R6, R7, R8 · unclear: R4 (Irish PAYE, PRSI and USC)
- `important` — adjacent: R10 (Monthly payroll for 240 staff) · absent: R9 (Pension changes)

R4 — waiting on your confirmation of Irish statutory scope; R9 — you've said you haven't done it yourself, and it is learnable.

**Opportunity ledger.** The offer's terms are written and specific, and €40,000 sits inside the advertised band (RR2). The reporting line is named (RR3). The employer hasn't been checked against public sources, because search didn't run (RR1).

- **Hard gates:** none failed; unconfirmed: R1 (Hybrid, two days in Limerick), R2 (Pay €38,000–€42,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the office days and €40,000 meet your own terms, R1 and R2; (2) the employer and role are confirmed on Marrowgate's own website, RR1; (3) a pension-changes handover is agreed before you start, R9 and RR3.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick | `[grounded]` ad and offer; not checked publicly |
| Mandate | Monthly payroll for 240 staff; starters, leavers, pension changes; monthly payroll-to-ledger reconciliation; staff queries | `[grounded]` ad |
| Offer | Permanent, €40,000, hybrid with two office days, reporting to Declan Garvagh, Finance Manager; accept within five working days | `[grounded]` offer email |
| Contradictions | Title, pay, hybrid pattern and reporting line agree between the ad and the offer | `[grounded]` ad against offer |
| Market calibration | Not done, because the salary search was refused. The offer sits in the middle of the ad's own band | `[grounded]` ad and offer figures |
| Unknowns | Pension scheme and who handles pension changes; start date; what the onboarding portal's address is | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in the Limerick office | hard_gate | unclear | none | hard_gate | You haven't stated your location or commute limits, so whether this meets your terms is not established | `[grounded]` no constraint given | Question H1 |
| R2 | Salary €38,000–€42,000 (offer €40,000) | hard_gate | unclear | none | hard_gate | You haven't given a pay floor. The offer is inside the band | `[grounded]` ad and offer; your floor not given | Question H1 |
| R3 | 2+ years running payroll | must_have | direct | medium | none | Your account: 3 years of fortnightly payroll for 90 staff at a hotel group. Self-reported, nothing inspected | `[grounded]` your background | none |
| R4 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | You haven't said the hotel payroll ran under Irish rules or who issued the certificate | `[grounded]` background is silent on jurisdiction | Question G1 |
| R5 | Strong Excel | must_have | direct | medium | none | Daily use, pivot tables and XLOOKUP, self-reported | `[grounded]` your background | none |
| R6 | Payroll qualification, or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024. The certificate hasn't been inspected | `[grounded]` your background | none |
| R7 | Reconcile payroll to the general ledger monthly | must_have | direct | medium | none | You did the monthly payroll-to-ledger reconciliation at the hotel group | `[grounded]` your background | none |
| R8 | Process starters and leavers | must_have | direct | medium | none | You did starters and leavers at the hotel group | `[grounded]` your background | none |
| R9 | Process pension changes | important | absent | none | capability | You've said you never did these yourself; your manager did. Closing it means learning the scheme's rules on the job | `[grounded]` your statement | Agree a handover (RR3); no question needed |
| R10 | Run the monthly payroll for 240 staff | important | adjacent | medium | transferability | Your payroll ran fortnightly for 90 staff. Limit: you haven't described a monthly pay run or this headcount | `[grounded]` your background against the ad | A bridge is possible; a work sample would narrow it |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Irish statutory knowledge (R4, must_have) | discovery | Your background doesn't say which tax and social-insurance rules the hotel payroll followed | It is a must-have row at `unclear`, and the ad names the three rules | Year-end returns, Revenue payroll submissions, USC or PRSI class corrections | Your certificate's issuer, or a sanitized payslip layout | `[grounded]` silence on jurisdiction |
| G2 | Pension changes (R9, important) | capability | You stated you haven't done these | The ad lists it as a duty | None stated; starters and leavers are nearby but don't exercise pension rules | A handover plan or training from the employer | `[grounded]` your statement |
| G3 | Monthly cycle at 240 staff (R10, important) | transferability | Fortnightly payroll at 90 staff, plus a monthly reconciliation | The scale and cycle differ from what you've run | A monthly cut-off, a multi-site or larger run | A sanitized pay-run checklist | `[grounded]` background against the ad |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not checked against public sources | unknown | — | "Marrowgate Housing, a housing association in Limerick" | Search didn't run, so the role and employer aren't confirmed from public pages. You attended two interviews at their office, which is your own first-hand evidence | `[grounded]` search refused; your account of the interviews | Is the Payroll Administrator role listed on your own careers page, and will the start terms be confirmed in writing? | unresolved |
| RR2 | Pay stated and inside the advertised band | positive_signal | — | "€40,000 a year" against "Salary €38,000–€42,000" | Compensation is transparent and consistent | `[grounded]` ad and offer | Which pension scheme applies, and is the €40,000 the figure it is calculated on? | noted |
| RR3 | Reporting line named in writing | positive_signal | — | "reporting to Declan Garvagh, Finance Manager" | Role has a named owner who can agree a pension-changes handover | `[grounded]` offer | Who covers pension changes while I learn them, and for how long? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before replying, put the RR2 and RR3 questions to Declan Garvagh. The offer's window is five working days | See RR2, RR3, R9 | `[grounded]` offer | pending your approval |
| A2 | Enter bank, PPS and passport scan only in the employer's own onboarding portal. Get its address from the employer's own website, or by calling the office number published there, not from a message. Send none of these by email attachment | Payroll and identity details are standard onboarding after a written offer. The link's origin is the thing worth checking | `[generic]` onboarding pattern | pending your approval |
| A3 | Bring the original passport on day one, as the offer asks | See the offer | `[grounded]` offer | pending your approval |
| A4 | If pensions come up, say: "I've never done pension changes myself — my manager handled those." | Every clause is your own sentence | `[grounded]` your statement | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Marrowgate Housing Limerick housing association careers"; the call was refused. It would have fed role reality and RR1 |
| 2. Role-family sweep | unavailable | Searched "payroll administrator salary Ireland Limerick 2026"; the call was refused. It would have fed the market calibration row |
| 3. Hiring manager's public footprint | unavailable | Declan Garvagh was named, but the search permission was refused. It would have fed the positioning in the plan |

I can offer a one-file `tuesday-dossier.md` of this assessment if you want to keep it.

**Upgrade menu**

- Confirmation of which rules the hotel payroll ran under, and your certificate's issuer → R4 resolves.
- Your pay floor and commute or office-day limits → R1 and R2 settle.
- A copy of the Payroll Technician certificate, or a sanitized pivot or reconciliation sample → R5, R6 and R7 can rise to `high`.
- Permission to run web searches → the employer check (RR1), the market band and the footprint row fill in.

**Questions**

G1 — Did the hotel group's payroll run under Irish PAYE, PRSI and USC, and was your Payroll Technician certificate an Irish one? Who issued it?

H1 (R1, R2) — Does €40,000 with two office days a week in Limerick meet your own terms, such as a pay floor or a commute you'd refuse?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.