Web searches were declined, so this rests on the posting, the WhatsApp message and your background.

## Decision snapshot

**Yes, take the call. Nothing in the posting or the WhatsApp message asks you for money, ID or bank details. I couldn't establish Fernquay itself from here, though, so the answer is conditional: R1 and R2 are unconfirmed hard gates, and RR1 is the unverified employer. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Two days a week at the Galway office), R2 (Salary €52,000–€60,000)
- `must_have`: direct: R3, R4, R5, R6 · adjacent: R7 (Own the booking flow end to end)
- `important`: adjacent: R8 (First and only designer)

R7: checkout redesign, not the whole booking flow; R8: squad work, never the only designer.

**Opportunity ledger.** The employer is not established (RR1), the scope for a sole designer is unspecified (RR2), and the equity terms are missing (RR3). The pay figure is stated up front (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Two days a week at the Galway office), R2 (Salary €52,000–€60,000); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Fernquay verifies as a live employer with this role open, per RR1; (2) your own limits confirm R1 and R2 are met; (3) the sole-designer scope in R7, R8 and RR2 holds up in the call.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, booking software for sea-kayak and surf schools | `[grounded]` posting |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship alongside two engineers | `[grounded]` posting |
| Closest collaborator | Co-founder Ronan Kehoe; the call is with him and Saoirse, the CTO | `[grounded]` posting and WhatsApp message |
| Working pattern | Hybrid: two days a week at the Galway office, the rest flexible | `[grounded]` posting |
| Compensation | €52,000–€60,000 plus 0.5–1% equity; vesting and strike terms unstated | `[grounded]` posting |
| Market calibration | Not calibrated. The role-family search was refused, so no band is claimed and the pay is not compared to the market | `[grounded]` search refused |
| Scope read | One person carrying design ownership, research and delivery with no named design peer | `[inferred]` from the mandate list against a team of six |
| First-year outcomes | Not stated | `[grounded]` posting silent |
| Unknowns | Equity terms; who reviews design; what exists of the booking flow today; company stage and funding | `[grounded]` posting silent |
| Contradictions | None between the posting and the message. The thin online footprint is your report, which I couldn't check | `[grounded]` posting, message and your report |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week at the Galway office | hard_gate | unclear | low | hard_gate | You live in Galway, so location likely works, but you haven't said whether two fixed office days suit you | `[grounded]` your message and the posting | Q1 below |
| R2 | Salary €52,000–€60,000 | hard_gate | unclear | low | hard_gate | The posting states the figure, but your pay floor wasn't given, so I can't say whether the range meets it | `[grounded]` posting; floor not given | Q1 below |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company, stated by you. No CV or portfolio inspected, so `medium` | `[grounded]` your message | A portfolio link would raise it to `high` |
| R4 | Strong Figma | must_have | direct | medium | none | Figma daily, stated. No file inspected | `[grounded]` your message | Link a Figma file or prototype |
| R5 | You have run your own user research | must_have | direct | medium | none | Monthly usability sessions with customers. I read "ran" the narrower way: usability sessions, not necessarily the discovery calls with school owners the role describes. Expect a probe | `[grounded]` your message | Be ready to say who planned the sessions |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | Worked in a squad with four engineers | `[grounded]` your message | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | discovery | You redesigned checkout, which is one part of a booking flow. Whether you owned other steps is unknown | `[grounded]` your message | Q2 below |
| R8 | Work as the first and only designer | important | adjacent | medium | transferability | Four years in a squad is real design delivery. You have never been the only designer, so solo decision-making is untested | `[grounded]` your message | Bring one project and say which decisions were yours (A3) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay and office days against your limits (R1, R2, hard_gate) | hard_gate | Both terms stated by Fernquay; your limits unknown | A failed gate would end the pursuit however strong the fit | — | Your own statement of floor and acceptable office days | `[grounded]` posting and your message |
| G2 | Breadth of booking-flow ownership (R7, must_have) | discovery | Checkout redesign confirmed; nothing on other steps | R7 is the role's core duty, and Ronan will probe how far your ownership went | Designing search, availability, pricing or confirmation screens; deciding a flow without a lead's sign-off | A case study or Figma file covering more than checkout | `[grounded]` your message; `[generic]` that a founder-led call probes ownership |
| G3 | Working as the only designer (R8, important) | transferability | Squad delivery with four engineers | A sole designer makes calls with no design peer. Your work so far had one | Decisions where you chose between options and engineers followed | One real project showing what was yours versus the squad's | `[grounded]` your message; `[inferred]` limit: no solo design ownership |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools." | The company may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer. None is ranked, and your thin results fit each | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Sole-designer scope unspecified | unknown | — | "You would be our first designer: own the booking flow end to end" | The role may carry full design accountability with no design peer, brief or research access stated | `[inferred]` from the mandate against the posting's silence on support | Who reviews design decisions today, and what access to school owners does this role have? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | The value depends on vesting, strike price and dilution, none of which are given | `[inferred]` from the posting's silence | What are the vesting schedule, cliff and strike price, and what has been raised so far? | unresolved |
| RR4 | Pay stated openly | positive_signal | — | "Salary €52,000–€60,000 plus 0.5–1% equity" | The pay gate can be checked now | `[grounded]` posting | Is the range fixed, or does it move with level? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, check the calendar invite came from an address on Fernquay's own domain, matching the company's website | Setting up a video call by WhatsApp message is a routine step, so this is ordinary hygiene and not a condition | `[generic]` role-family pattern | pending your approval |
| A2 | Ask the RR1 to RR3 questions verbatim in the call | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A3 | Lead with the checkout redesign and the monthly usability sessions, and say plainly that you have worked in a squad with four engineers and never as the only designer | The posting asks for a messy real project, and this keeps to what you told me | `[grounded]` your message and the posting | pending your approval |
| A4 | Ask for the equity terms before investing beyond the call | See RR3 | `[grounded]` RR3 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches ("Fernquay booking software sea kayak surf schools Galway", "Fernquay product designer Galway careers") were refused. They would have settled RR1 and role reality's organization and contradictions rows |
| 2. Role-family sweep | unavailable | One search ("product designer salary Ireland startup first designer") was refused. It would have set the market calibration and tested R2 |
| 3. Hiring manager's public footprint | unavailable | One search ("Ronan Kehoe Fernquay co-founder") was refused. It would have informed the scope read and which story to lead with for the call |

Rehearsing the 45-minute call is mock-interview's job, and I can run it if you ask.

If you want, I can save this as a `tuesday-dossier.md` for later steps.

## Upgrade menu

- Allow web search, and I'll rerun targets 1 to 3. That could close RR1, calibrate R2 and sharpen the scope read. A deeper pass after that would use up to 5 more searches and 2 more fetches.
- Your pay floor and office-day limits would settle R1 and R2.
- A portfolio link would raise R3 and R4. A case study that goes beyond checkout would test R7.
- A link to the live posting on Fernquay's own site would close RR1.
- Equity terms would close RR3.

**Questions**

- **G1:** Do you have a pay floor and a number of fixed office days you'd accept, and do €52,000–€60,000 and two Galway office days a week fit inside them?
- **G2:** Beyond checkout, which other steps of the booking journey did you personally design or make the call on, and who signed those off?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.