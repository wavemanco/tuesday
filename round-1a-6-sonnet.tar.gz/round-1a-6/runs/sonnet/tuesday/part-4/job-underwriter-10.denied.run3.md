I'm writing up the full assessment now. The web searches I tried were declined, so I couldn't check Fernquay's existence myself, and the write-up shows that.

## Decision snapshot

**Yes, worth taking the call. As to whether it's legit, I can't confirm that from here: nothing in the posting or the WhatsApp message asks you for money or personal details, but the company itself is unchecked (RR1). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Hybrid, two days a week at Galway office), R2 (Salary €52,000–€60,000 plus equity)
- `must_have`: direct: R3, R4, R5, R6
- `important`: adjacent: R7 (Own the booking flow end to end), R8 (Run research calls with school owners), R9 (First designer on the team)

R7 — checkout is the nearest evidence, whole-flow ownership unconfirmed; R8 — customer sessions bridge to owner calls, its limit named; R9 — squad work bridges, sole-designer ownership untested.

**Opportunity ledger.** The employer could not be checked from here (RR1), the equity terms are not stated (RR2), and the support for a first designer is not stated (RR3). The posting does name a pay band and a co-founder you would work with (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Hybrid, two days a week at Galway office), R2 (Salary €52,000–€60,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer verifies: its own site or careers page shows the role, and the invite comes from its domain (RR1); (2) the pay band and the two office days meet your own limits (R1, R2); (3) the equity terms and the design-review set-up are answered clearly on the call (RR2, RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, described in the posting as six people in Galway making booking software for sea-kayak and surf schools. Not independently established | `[grounded]` posting, as stated by the posting |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship alongside two engineers | `[grounded]` posting |
| Reports to or works with | Co-founder Ronan Kehoe, who also sent your WhatsApp message. The call adds Saoirse, named as CTO, who isn't in the posting | `[grounded]` posting and WhatsApp message |
| Working pattern | Hybrid, two days a week in the Galway office, the rest flexible | `[grounded]` posting |
| Pay | €52,000–€60,000 plus 0.5–1% equity; vesting, cliff and share class unstated | `[grounded]` posting |
| First-year outcomes | Not stated | `[grounded]` posting silent |
| Scope read | A first-designer post at a six-person company spans design, research and shipping together, with no design peer named | `[inferred]` from the posting's three duties against its silence on other designers |
| Market calibration | Not run; no pay or scope comparison against similar roles | `[generic]` no research completed |
| Unknowns | Whether the company exists as described; equity terms; who reviews design decisions; how you would reach school owners for research | — |
| Contradictions | None found between the posting and the WhatsApp message on names or role | `[grounded]` both texts as supplied |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week at the Galway office | hard_gate | unclear | low | hard_gate | You live in Galway (moved back last year), but you haven't said whether two office days suit you, and no constraints were given | `[grounded]` your background; posting | G1 |
| R2 | Salary €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | Pay is stated; your floor was not given, so whether it meets your need is unknown | `[grounded]` posting; no constraint stated | G1 |
| R3 | 3+ years of product design | must_have | direct | medium | none | You state 4 years as a product designer at a Dublin travel-booking company. Confirmed prose, nothing inspectable yet | `[grounded]` your background | A portfolio or employer reference would raise to `high` |
| R4 | Strong Figma | must_have | direct | medium | none | You state daily Figma use. No file or portfolio inspected | `[grounded]` your background | A Figma file or portfolio link would raise to `high` |
| R5 | You have run your own user research | must_have | direct | medium | none | You state running monthly usability sessions with customers | `[grounded]` your background | A sanitized session guide or findings summary would raise to `high` |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | You state working in a squad with four engineers | `[grounded]` your background | none |
| R7 | Own the booking flow end to end | important | adjacent | medium | discovery | You redesigned a checkout flow, which is one stage of a booking journey. Ownership of the stages around it is unstated, so the lower reading holds | `[grounded]` your checkout redesign; `[inferred]` that checkout is one stage of the whole flow | G2 |
| R8 | Run research calls with school owners | important | adjacent | medium | transferability | Your sessions were with customers of a travel-booking company. The posting's school owners are people running small businesses, and whether your participants included business users is unstated | `[grounded]` your background; `[inferred]` that school owners are business operators, from the posting | A sample interview guide for operators would narrow the limit |
| R9 | First designer on the team (inferred from the posting) | important | adjacent | medium | transferability | You have owned a redesign inside a squad but have never been the only designer, in your words. Setting up research habits or design standards without design peers is untested | `[grounded]` your background; posting's "first designer" | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay floor and office-day limits (R1, R2, hard_gate) | hard_gate | The posting states pay and office days. No constraints from you | Settles whether these gates are met, and decides whether the status holds | Any fixed floor, a notice period, caring or commuting limits that affect office days | None; your own statement is the evidence | `[grounded]` posting and your message; no constraints supplied |
| G2 | Whole-flow booking ownership (R7, important) | discovery | A checkout redesign, with ownership beyond checkout unstated | The role's headline duty is the whole flow | Owning search, selection, basket, confirmation or post-booking emails; deciding what shipped; measuring a conversion change | The case study you applied with, a before and after, a shipped-change note | `[grounded]` your background silent beyond checkout; `[generic]` that a first-designer post is judged on whole-flow ownership |
| G3 | Research with business owners (R8, important) | transferability | Customer usability sessions, participants unspecified. Not asked this turn | The role's calls are with small-business owners | Sessions with partner hotels, tour operators or other business users; interviews about how they work | A sample guide or findings summary | `[inferred]` from the posting's "school owners" |
| G4 | Working as the only designer (R9, important) | transferability | Squad ownership of a redesign. You have never been the only designer | The post has no design peer named | Setting up a research cadence, a component library or design standards yourself; making design decisions without a reviewer | One messy real project; the posting says it would rather see one of those than a polished deck | `[grounded]` your background and the posting's preference for one messy real project |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools." | The company may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer. No search could be run here | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | Vesting, cliff, share class and the company's total share count could change what the equity is worth | `[inferred]` from the posting's figure against its silence on terms | What is the vesting schedule and cliff, what class are the shares, and what percentage does this represent of fully diluted shares? | unresolved |
| RR3 | Responsibility with no stated support | unknown | — | "You would be our first designer: own the booking flow end to end" | The role may carry the whole booking flow without a design reviewer or agreed product priorities | `[inferred]` from the posting's scope against its silence on review and decision rights | Who reviews and signs off design decisions, and how would I reach school owners for research? | unresolved |
| RR4 | Pay band and working pattern stated | positive_signal | — | "Salary €52,000–€60,000 plus 0.5–1% equity. Hybrid: two days a week at our Galway office" | The terms are concrete rather than withheld | `[grounded]` posting | What would move a salary within the band? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, look up Fernquay's own website yourself and check that the role appears there and that the emailed invite comes from that site's domain | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Treat the WhatsApp scheduling as routine: a message to arrange a video call whose invite arrives by email is a normal way to set one up. Confirm the time against the emailed invite | The message asks for nothing but a call time | `[generic]` common scheduling practice, not a claim about this firm | pending your approval |
| A3 | Positioning to try: lead with your checkout redesign, your monthly usability sessions and your work in a squad with four engineers, in your own words. Say plainly that you have not been the only designer. Don't claim whole-flow ownership or research with business owners unless G2 or G3 confirm it | see R5, R6, R7, R9 | `[grounded]` your background | pending your approval |
| A4 | On the call, ask the questions from RR1, RR2 and RR3 as written | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A5 | Ask for the equity terms in writing before accepting any offer | see RR2 | `[grounded]` RR2 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Fernquay booking software sea kayak surf schools Galway" and "Fernquay product designer Galway careers"; both refused. Would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | Searched "product designer salary Ireland startup first designer equity 2026"; refused. Would have moved the market calibration row and the pay comparison for R2 |
| 3. Hiring manager's public footprint | unavailable | A name was given (Ronan Kehoe). Searched "Ronan Kehoe Fernquay co-founder"; refused. Would have moved the scope read and which story the plan leads with |

I can save this as `tuesday-dossier.md` if you'd like to build on it later.

## Upgrade menu

- Permission to run the web searches for the three targets above, or a link to Fernquay's own site or careers page, would settle RR1, the organization row and the contradictions row.
- Your pay floor and office-day limits would settle R1 and R2.
- A portfolio link or Figma file would raise R3 and R4 toward `high`, and a sanitized research guide would do the same for R5.
- Your answers to G2 and G4 would firm up R7 and R9.
- The equity terms from Fernquay would close RR2.
- If you want to rehearse the 45-minute call, mock-interview is the module for that.

G1 — Are there any terms here, such as a pay floor or the number of days you can be in a Galway office, that you would not move on?

G2 — At the travel-booking company, which stages of the booking journey did you personally own beyond checkout, what shipped, and what changed as a result?

G4 — Have you ever set up a research habit, a design standard or a shared component set yourself, with no other designer to review it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.