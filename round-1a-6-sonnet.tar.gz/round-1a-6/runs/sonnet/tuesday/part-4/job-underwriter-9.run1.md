Searches weren't permitted here, so this runs on what you pasted, with the online checks marked unavailable.

# Job underwriting: Payroll Administrator at Marrowgate Housing

## Decision snapshot

**Yes, that's normal. Bank details, a PPS number and a passport scan after a written offer are routine onboarding, and none of them is a reason to hold. On the job itself, accept on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: R2 (Hybrid, two days in Limerick), R3 (Pay €38,000–€42,000)
- `must_have`: direct: R4, R6 · unclear: R5 (Irish PAYE, PRSI, USC)
- `important`: direct: R8, R10 · adjacent: R7 (Monthly payroll, 240 staff) · absent: R9 (Pension changes)

R7: a credible bridge, its limits named; R9: you have not done pension changes yourself; R5 (`low`): not yet stated by you.

**Opportunity ledger.** The written offer follows two in-person interviews and comes from the employer's own domain (RR3). Terms beyond the email are not stated (RR2), and the pension duties are not scoped against your experience (RR1).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Hybrid, two days in Limerick office), R3 (Pay €38,000–€42,000); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  - (1) Two days a week in Limerick and €40,000 sit inside your own limits (R2, R3).
  - (2) A written contract arrives before you hand in notice (RR2).
  - (3) You get a clear answer on how much pension work is yours from the start, and what handover there is (RR1, R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick, 240 staff | `[grounded]` JD |
| Mandate | Monthly payroll for 240 staff; starters, leavers, pension changes; monthly payroll-to-ledger reconciliation; staff payroll queries | `[grounded]` JD |
| Offer terms | Permanent, €40,000, reporting to Declan Garvagh (Finance Manager), hybrid two days a week in Limerick, start after your notice period, five working days to accept | `[grounded]` offer email |
| Consistency | Title, hybrid pattern and pay all agree between the ad and the offer; €40,000 sits inside the ad's €38,000–€42,000 | `[grounded]` ad against offer |
| Onboarding requests | Bank details (to pay you), PPS number (for Revenue) and passport (right-to-work check) are normally collected after a written offer. The "never hand these over" rule fits requests made before an offer, or by someone you can't place | `[generic]` role-family pattern, not a claim about Marrowgate |
| Scope read | One post running a 240-staff monthly payroll; team size and payroll software are not stated | `[inferred]` from the JD's silence |
| Market calibration | Not run. The posting's own band is the only pay evidence | `[grounded]` JD; role-family sweep unavailable |
| Unknowns | Team size, payroll system, pension scheme, probation, hours, written contract | `[grounded]` absent from ad and offer |
| Contradictions | None between the ad and the offer. Marrowgate's own site could not be checked | `[grounded]` ad against offer |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | A payroll qualification or working towards one | hard_gate | direct | medium | none | Payroll Technician certificate (2024) is stated; no certificate inspected, so expect to be asked for it | `[grounded]` your message | A copy of the certificate would raise to high |
| R2 | Hybrid, two days a week in the Limerick office | hard_gate | unclear | low | hard_gate | Terms are stated by the employer. Your commute and limits are not. Two interviews at the office show you can get there, not that two days a week works | `[grounded]` JD, offer, your message | G2 |
| R3 | Pay €38,000–€42,000 (offer: €40,000) | hard_gate | unclear | low | hard_gate | The offer is inside the ad's band. Your own floor is not given | `[grounded]` JD, offer | G2 |
| R4 | 2+ years running payroll | must_have | direct | medium | none | 3 years of fortnightly payroll for 90 staff, stated; no artifact inspected | `[grounded]` your message | An employment reference confirming dates would raise to high |
| R5 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | Your message does not say the hotel group's payroll was Irish or which statutory deductions you applied | `[grounded]` your message's silence | G1 |
| R6 | Strong Excel | must_have | direct | medium | none | Daily use, pivot tables and XLOOKUP, stated; "strong" is usually tested in practice | `[grounded]` your message; `[generic]` that it is tested | A sanitized reconciliation workbook would raise to high |
| R7 | Run monthly payroll for 240 staff | important | adjacent | medium | transferability | Same cycle mechanics. Limit: fortnightly at 90 staff, not monthly at 240 | `[inferred]` from your stated run | G3 |
| R8 | Process starters and leavers | important | direct | medium | none | Stated directly | `[grounded]` your message | none |
| R9 | Process pension changes | important | absent | none | capability | You have not done these yourself; your manager handled them | `[grounded]` your message | G4 |
| R10 | Reconcile payroll to the general ledger monthly | important | direct | medium | none | Stated directly | `[grounded]` your message | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Irish PAYE, PRSI, USC (R5, must_have) | discovery | Nothing says the hotel payroll was Irish or which deductions you applied | A must-have; confirming it likely settles R5 | Setting up starters from Revenue payroll notifications; applying PRSI classes; applying USC rates; year-end returns | Certificate syllabus, a sanitized payslip layout, a procedure note | `[grounded]` silence in your message; `[generic]` that these are the usual Irish tasks |
| G2 | Limerick two days a week and €40,000 (R2, R3, hard_gate) | hard_gate | The employer's terms are known; your limits are not | Both are gates, so only you can say whether they are met | Your commute time, days you cannot be in, your minimum salary | None needed | `[grounded]` offer and your message |
| G3 | Monthly payroll at 240 staff (R7, important) | transferability | Fortnightly payroll for 90 staff plus monthly reconciliation carries over. Monthly cadence and 240-staff scale are not evidenced | The nearest thing to a scale objection | Your largest single run, pay elements per run, any monthly cycle you covered | A sanitized run summary | `[inferred]` bridge from your stated run |
| G4 | Pension changes (R9, important) | capability | No direct or adjacent evidence beyond your manager handling them | A stated duty you have not done. Ask how much is yours and what handover exists (RR1) | None known. Check whether your certificate coursework touched pensions in payroll | The employer's answer to RR1 | `[grounded]` your own statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pension duties not scoped | unknown | — | "process starters, leavers and pension changes" | Pension changes may be yours from day one, with no stated handover | `[inferred]` from the JD's silence on training | How much of pension-change processing would be mine from the start, and what handover is there? | unresolved |
| RR2 | Terms beyond the email not stated | unknown | — | "starting on a date we agree once your notice period ends" | The email does not mention a written contract, probation, hours or pension scheme; these may follow separately | `[inferred]` from the email's silence | Will a written contract with probation, hours and pension terms come before I give notice? | unresolved |
| RR3 | Offer follows in-person interviews, names role, pay and manager | positive_signal | — | "we are delighted to offer you the permanent post of Payroll Administrator at €40,000 a year" | The process looks like an ordinary one run in person | `[grounded]` your account of two interviews at their office | Who in the People Team should I send my acceptance and portal questions to? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Enter bank, PPS and passport details only in the onboarding portal. Reach it at the address on Marrowgate's own website, or confirm the link with the People Team by contact details taken from that site. Bring the original passport on day one, as asked | A sensible check on any onboarding link; it is advice, not a hold | `[generic]` onboarding practice | pending your approval |
| A2 | Before replying, ask RR1 and RR2 in your acceptance email or a call. The offer gives five working days from the email's date | see RR1, RR2 | `[grounded]` offer email | pending your approval |
| A3 | Say it plainly: "I haven't processed pension changes myself; my manager handled those. How much would land on me, and what handover is there?" Every clause traces to your sentence | see R9, RR1 | `[grounded]` your message | pending your approval |
| A4 | Hold your resignation until the written contract is in hand | see RR2 | `[generic]` common practice | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search "Marrowgate Housing Limerick housing association" was refused. It would have checked that the employer exists as described and that the posting is live |
| 2. Role-family sweep | unavailable | Search "Payroll Administrator salary Ireland Limerick" was refused. It would have supplied the market calibration |
| 3. Hiring manager's public footprint | unavailable | Search on Declan Garvagh and Marrowgate was refused. It would have informed the scope read and the plan |

## Upgrade menu

- Permission to run the three searches above would fill role reality's calibration and scope rows, and check the employer's own site.
- A copy of your certificate, or its syllabus page, would raise R1 and may settle R5.
- A sanitized reconciliation workbook would raise R6 and R10.
- Your commute and pay floor would settle R2 and R3.
- Marrowgate's answers to RR1 and RR2 would close both entries and could move the status to `go`.

If it would help, I can save this as a `tuesday-dossier.md` for later steps.

**Questions**

G1 (R5): Was the hotel group's payroll run under Irish tax rules, and which of PAYE, PRSI and USC did you apply or reconcile yourself?

G2 (R2, R3): Are two days a week in Limerick and €40,000 within your own limits, meaning your commute and your minimum salary?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.