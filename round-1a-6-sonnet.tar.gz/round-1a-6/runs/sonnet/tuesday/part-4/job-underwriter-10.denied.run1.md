Web search was declined, so this assessment uses only the text you pasted.

## Decision snapshot

**Yes, worth taking the call and carrying on, on conditions. Nothing in the posting or the WhatsApp message asks you for money or personal details, but I couldn't verify Fernquay from here. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Two days a week at the Galway office), R2 (Salary €52,000–€60,000)
- `must_have` — direct: R3, R4, R5, R6 · adjacent: R7 (Own the booking flow end to end)
- `important` — adjacent: R8 (First and only designer)

R7 — a close bridge, ownership scope unconfirmed; R8 — no sole-designer history, the limit named.

**Opportunity ledger.** The employer isn't established from what you could find (RR1), the equity is a percentage with no terms (RR2), and the first-designer scope names no design support (RR3). The posting is specific about scope and pay (RR4), and the message matches the posting's names (RR5). A scheduling message on WhatsApp for a video call is a routine step and gets no register entry.

- **Hard gates:** none failed; unconfirmed: R1 (Two days a week at the Galway office), R2 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Fernquay verifies through a route you find yourself (RR1); (2) the pay band clears your floor (R2); (3) you get the equity terms in writing (RR2); (4) two fixed Galway office days work for you (R1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, booking software for sea-kayak and surf schools. This is the posting's own description and is not independently verified | `[grounded]` posting; `[grounded]` your own search found little |
| Mandate | First designer: own the booking flow, run research calls with school owners, ship alongside two engineers | `[grounded]` posting |
| Reporting line | Works most closely with co-founder Ronan Kehoe; the call also includes Saoirse, the CTO | `[grounded]` posting and message |
| Working pattern | Hybrid, two office days a week in Galway, the rest flexible | `[grounded]` posting |
| Pay | €52,000–€60,000 plus 0.5–1% equity; contract type not stated | `[grounded]` posting |
| Scope read | Broad but coherent for a six-person company: flow design, research and delivery with no design peer | `[inferred]` from the mandate against the team size |
| Market calibration | Not run, because search was declined, so this band is not compared with the market | `[grounded]` no search ran |
| Unknowns | Contract type, equity terms, funding and runway, customer count, who gives design feedback | `[inferred]` from the posting's silence |
| Contradictions | None between the posting and the message | `[grounded]` the two texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week at the Galway office | hard_gate | unclear | low | hard_gate | You live in Galway, but you haven't said whether fixed office days suit you. Confidence grades your statement of the constraint, and none was given | `[grounded]` your move back to Galway; no stated constraint | Q3 |
| R2 | Salary €52,000–€60,000 plus equity | hard_gate | unclear | none | hard_gate | No floor or target was given, so fit against it can't be set | `[grounded]` posting figure; no candidate figure | Q1 |
| R3 | 3+ years of product design | must_have | direct | medium | none | You state 4 years as a product designer. This is self-report with no artifact inspected yet, so `medium` | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | You use Figma daily. A file or case study would raise the band | `[grounded]` your background | Have a Figma file or the checkout case study ready to share |
| R5 | You have run your own user research | must_have | direct | medium | discovery | You ran monthly usability sessions with customers. Whether you planned, recruited and synthesised them, as opposed to joining sessions, isn't stated. The posting's research calls with school owners are conversations, not only usability tests, which this evidence doesn't directly cover | `[grounded]` your background; `[inferred]` the usability-versus-discovery distinction from the posting wording | Be ready to say exactly what you owned in those sessions |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your background | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | discovery | You redesigned a checkout flow in a travel-booking company, which is close. Limit: checkout is one stage of a booking flow, and whether you owned it or contributed isn't stated | `[grounded]` your background; `[inferred]` the limit from the posting's "end to end" | Q2 |
| R8 | First and only designer | important | adjacent | medium | transferability | You've never been the only designer. What carries over is owning a flow redesign and running research. Not exercised: setting design process, working without peer review, or self-directing priorities | `[grounded]` your statement; `[inferred]` what carries over | Name the limit plainly on the call and ask how design feedback works there (RR3) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Booking flow ownership (R7, must_have) | discovery | A checkout redesign, but not how much of the booking journey it covered or who decided | It is the posting's headline responsibility | Deciding the flow structure rather than polishing screens; changing steps before or after payment; a conversion or drop-off result you tracked | The checkout case study, before-and-after flows, any metric you can share | `[grounded]` your summary says "redesigned"; `[inferred]` that ownership scope is what a first-designer role will probe |
| G2 | Own user research (R5, must_have) | discovery | Monthly usability sessions are stated; research design and synthesis are not | The role runs research calls with school owners | Writing the discussion guide, recruiting participants, turning findings into decisions | A research summary or a session guide | `[grounded]` your background; `[inferred]` from the posting's research duty |
| G3 | Sole-designer scope (R8, important) | transferability | Strong adjacent work, with no history of working without peer review | It is the structural difference between your last role and this one | Setting a team's design conventions; making a call with no design peer | A project where you set conventions or standards | `[grounded]` your statement; `[inferred]` the transferable parts |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools." | The company may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to your product, a customer school, or your company page, and who the six are? | unresolved |
| RR2 | Equity stated without terms | unknown | — | "0.5–1% equity" | A percentage alone doesn't show vesting, strike price, share class or dilution, so its value is unclear | `[generic]` how equity offers are usually expressed | What are the vesting schedule, the strike price and the fully diluted share count? | unresolved |
| RR3 | First designer with no named design support | unknown | — | "You would be our first designer" | You may have no design peer for feedback and a broad remit | `[inferred]` from the team description against the mandate | Who reviews design work here, and what does success look like at six months? | unresolved |
| RR4 | Specific scope and a stated pay band | positive_signal | — | "Salary €52,000–€60,000 plus 0.5–1% equity" | Terms and responsibilities are stated, not withheld | `[grounded]` posting | What is the contract type, and is the post permanent? | noted |
| RR5 | Message names match the posting | positive_signal | — | "Ronan from Fernquay here … we loved the checkout case study" | The message and posting agree on the company and Ronan's name, and the message cites your submitted case study. Consistency between two texts is not verification | `[grounded]` both texts | Can you confirm the invite will come from your company's own email domain? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, find the company's own website through your own search and compare its domain with the sender domain on the calendar invite. Join through the invite link only if they match | see RR1, RR5; a check is advice, not a condition on the WhatsApp step | `[generic]` ordinary diligence on a thin-footprint employer | pending your approval |
| A2 | Bring the checkout case study and say plainly what was yours and what the squad's | The posting says "we would rather see one messy real project than a polished deck" | `[grounded]` posting | pending your approval |
| A3 | Lead with three facts from your own words: "I redesigned our checkout flow at a Dublin travel-booking company, ran monthly usability sessions with customers, and worked in a squad with four engineers." Say you haven't been the only designer | Every clause traces to your sentences; no ownership or leadership is added | `[grounded]` your background | pending your approval |
| A4 | Ask RR1, RR2 and RR3's questions verbatim on the call | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A5 | Don't discuss pay until you know your floor (Q1) | see R2 | `[inferred]` from R2's open gate | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Fernquay booking software sea kayak surf schools Galway" and "Fernquay Galway product designer careers"; both refused. It would have moved RR1 and role reality's organization row. Your own failed search stands in for it |
| 2. Role-family sweep | unavailable | Searched "product designer salary Ireland startup first designer"; refused. It would have moved the market calibration row and a pay-versus-seniority check on R2 |
| 3. Hiring manager's public footprint | unavailable | Searched "Ronan Kehoe Fernquay co-founder"; refused. It would have moved the scope read and what to lead with for that reader |

## Closing

I can save this as a `tuesday-dossier.md` if you'd like to keep it.

**Upgrade menu**

- The company's own website or careers page link → RR1 could close or be confirmed.
- The sender domain of the calendar invite → RR5 and A1.
- Your pay floor → R2 resolves.
- Whether two office days work → R1 resolves.
- The checkout case study or Figma file → R4, R5 and R7 could reach `high`.
- Equity terms from Ronan → RR2 closes.
- Search access, so I can run the L1 research (up to 5 searches and 2 fetches) → RR1, the pay calibration and the hiring manager read.

**Questions**

- Q1 (R2) — What's the lowest salary you'd accept, and does equity change that for you?
- Q2 (G1) — How much of the booking journey did your checkout redesign cover, and who made the final calls on its structure?
- Q3 (G2) — In the monthly usability sessions, what did you personally own: the plan, recruiting, running them, writing up findings?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.