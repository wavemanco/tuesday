I've run four searches and found the company's own pages. Next I'll open the careers page to check it matches your posting.
## Decision snapshot

**Yes, worth pursuing. The posting matches Fernquay's own careers page (RR1), and nothing in it or in the WhatsApp message asks you for anything beyond your time. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R7 · unclear: R8 (Salary €52,000–€60,000)
- `must_have` — direct: R1, R2, R3, R4 · adjacent: R5 (Own the booking flow end to end)
- `important` — adjacent: R6 (First designer, no design peers), R9 (Research calls with school owners)

R5 — a credible bridge, its limit named; R6 — never sole designer, a real stretch; R8 — no pay floor given yet.

**Opportunity ledger.** Sound, with open terms. Fernquay's own pages match the posting (RR1) and the salary band sits at the survey median (RR5). The equity terms (RR3), the runway (RR4) and the design support a first designer would get (RR2) are unanswered.

- **Hard gates:** none failed (R7 `direct`); unconfirmed: R8 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your own pay floor is met by the band, or you decide what would make it so — R8; (2) Fernquay gives written answers on equity terms and runway that you are comfortable with — RR3, RR4; (3) you learn who reviews your work and sets design priorities — RR2.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. It has six people, is based in Galway, was founded in 2023 by Ronan Kehoe and Saoirse Doyle, and is "funded by its customers" | `[grounded]` About page (fernquay.example/about), read as a search snippet |
| Mandate | Own the booking flow end to end, run research calls with school owners, ship beside two engineers | `[grounded]` posting |
| Working pattern and pay | Hybrid, two days a week in Galway; €52,000–€60,000 plus equity. The careers page says "plus equity" and does not give the 0.5–1% figure | `[grounded]` posting and careers page |
| Hiring manager | Ronan Kehoe's public profile lists him as co-founder and CEO of Fernquay, and before that product lead at a Galway travel-software company for five years. Saoirse's CTO title comes only from his message | `[grounded]` public profile snippet; `[grounded]` About page for the founder names |
| Scope read | One flow, research and shipping with two engineers is a focused first-designer scope, not several full jobs folded into one title | `[inferred]` from the posting's three duties and its stated team size |
| Market calibration | Product designers with 3 to 5 years in Ireland have a median base of €57,000 (interquartile range €51,500–€62,000; n=520). The posting's band sits inside that range. This is the survey's band, not Fernquay's offer | `[generic]` Tillerby 2026 survey snippet; `[grounded]` posting figure |
| Unknowns | Equity terms, runway, who reviews design today, how priorities are set | — |
| Contradictions | None between your pasted posting and the careers page. The About page names sailing schools and Scotland, which the posting leaves out | `[grounded]` careers page fetched; About snippet |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years of product design | must_have | direct | medium | none | You state 4 years as a product designer at a Dublin travel-booking company. Self-report with nothing inspected yet | `[grounded]` your background message | none |
| R2 | Strong Figma | must_have | direct | medium | none | "Figma daily" is stated and the checkout case study was apparently seen by Ronan. "Strong" is a judgement, and the case study has not been inspected here | `[grounded]` your message and Ronan's message | link the case study to raise to `high` |
| R3 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. Specific, confirmed, no artifact seen | `[grounded]` your message | anonymised session notes or a findings write-up would raise to `high` |
| R4 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers; this role has two | `[grounded]` your message | none |
| R5 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned the checkout flow. Limit: checkout is one stage, and you have not said whether you owned the stages around it | `[grounded]` your message; `[inferred]` that "end to end" spans more than checkout | G1 |
| R6 | First designer: no design peers or lead | important | adjacent | medium | transferability | You have never been the only designer. You owned a checkout redesign, but with other designers around. Limit: no experience setting direction alone | `[grounded]` your message; `[inferred]` from "our first design hire" | G2 |
| R7 | Hybrid, two days a week in Galway | hard_gate | direct | medium | none | You moved back to Galway last year. You have not stated a commute limit, so confidence rests on your residence | `[grounded]` your message and posting | none |
| R8 | Salary €52,000–€60,000 | hard_gate | unclear | none | hard_gate | You have given no pay floor, so whether the band meets it is not established | `[grounded]` posting; no candidate constraint stated | G3 |
| R9 | Research calls with school owners | important | adjacent | medium | transferability | Your sessions were usability sessions with customers. Limit: calls with business owners may be a different kind of research and you have not said | `[grounded]` posting and your message; `[inferred]` that the audience differs | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Booking flow beyond checkout (R5, must_have) | transferability | Checkout redesign confirmed; nothing on the stages before or after it | A must-have at `adjacent`; the bridge from checkout to the whole flow is the first thing a co-founder with a travel-software background will test | Designing search or availability screens, confirmation and change or cancellation flows, or booking emails | A Figma file or case study page showing the wider flow | `[grounded]` your message; `[inferred]` that this is the likeliest probe, from his stated background |
| G2 | Working as sole designer (R6, important) | transferability | You have not been the only designer anywhere | You would set direction with no peer review | Calls you made without a design lead's sign-off; patterns your squad reused | A decision log, or a design-system page you started | `[grounded]` your message |
| G3 | Pay floor (R8, hard_gate) | hard_gate | The posting states a band; your floor is not given | It decides whether this is a go at all, and which equity trade-offs matter | Your own number, and whether equity changes it | None needed; your word is the evidence | `[grounded]` posting; your floor not supplied |
| G4 | Research with business owners (R9, important) | transferability | Usability sessions with customers; no calls with business-side users stated | The role's research is calls with school owners | Interviews with operators, partners or admins rather than end users | A discussion guide or findings summary | `[grounded]` your message and posting |

G4 is not asked about this turn because it ranks below the others.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting matches the company's own pages | positive_signal | — | "Open now: Product Designer, our first design hire. Hybrid, two days a week in Galway. €52,000–€60,000 plus equity." | The posting is live and consistent with Fernquay's own careers and About pages. Only the company's own pages and one professional profile turned up, with no independent customer or press mentions. That is a common footprint for a six-person company founded in 2023 | `[grounded]` careers page fetched, About page and profile as snippets; `[generic]` that thin footprints are common at this size | Which schools use Kelproster today, and could I speak to one before deciding? | noted |
| RR2 | First designer with no design peer | unknown | — | "You would be our first designer" | No design lead, reviewer or system to inherit; priorities may come straight from Ronan | `[inferred]` from the posting's "first designer" and "work most closely with our co-founder" | Who reviews design work today, and who decides priorities between the booking flow and everything else? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | A percentage cannot be valued without vesting, cliff, strike price, share class and what it is a percentage of | `[generic]` pattern for early-stage equity offers | What are the vesting schedule, cliff and strike terms, and what is the share count the percentage applies to? | unresolved |
| RR4 | Runway and seasonality unstated | unknown | — | "funded by its customers" | Revenue depends on school bookings; outdoor sports schools may book seasonally, and whether runway covers a new salary is not stated | `[grounded]` About page for the funding line; `[generic]` for the seasonality pattern | How does seasonality in school bookings affect revenue, and how long is the runway for this hire? | unresolved |
| RR5 | Salary band is in range | positive_signal | — | "€52,000–€60,000" | The band sits around the survey median for 3–5 years. The survey is not Fernquay's offer | `[grounded]` posting figure; `[generic]` survey band | Is the band set by experience, and where would my four years place me in it? | noted |

## Application plan

Every row below is proposed, and each one waits on your approval.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Reply on WhatsApp to confirm a time, and join from the calendar invite in your email, as the message says. Arranging an interview by chat and email is routine. If you want one check, make sure the invite came from an address on the company's domain. | Covers the part that felt odd; no register entry or condition rests on it | `[generic]` hiring practice | pending your approval |
| A2 | Lead with the one real project they asked for, your checkout redesign, then the usability sessions. A line you could say: "I redesigned the checkout flow at a Dublin travel-booking company and ran monthly usability sessions with customers." Say "checkout" rather than "the booking flow" and "squad with four engineers" rather than "led", so that nothing outruns your own words. | The posting asks to see "one messy real project"; see R2, R3, R5 | `[grounded]` posting quote and your sentences | pending your approval |
| A3 | Be upfront about R6: "I haven't been the only designer; here is what I decided myself." Then ask the RR2 question. | An interviewer can check this, so it is better said first | `[grounded]` your message | pending your approval |
| A4 | Settle your salary floor and your view on equity before the call. | R8 is open | `[grounded]` R8 | pending your approval |
| A5 | Put RR1–RR5 questions to Ronan and Saoirse, RR3 and RR4 especially. Ronan's public profile shows five years in travel software, so expect detailed questions on booking flows. | The register doubles as call preparation | `[grounded]` profile snippet; `[inferred]` the likely depth | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway" and "Fernquay product designer Galway careers"; fetched "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer) and saw "About Fernquay" (fernquay.example/about) as a snippet. Moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland startup first designer 2026", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report) as a snippet. Moved market calibration and RR5 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe) as a snippet. Moved role reality's hiring-manager row and A5 |

The careers page fetch returned only the same short text as its snippet. I read the other pages only as search snippets.

I can save this as `tuesday-dossier.md` so later turns pick it up; say the word.

## Upgrade menu

- A link to the checkout case study or Figma file → R2 and R5 can move to `high`.
- Anonymised research notes or a findings write-up → R3 and R9 can move to `high`.
- Your pay floor → R8 closes, and the decision simplifies to `go` or `no_go` on that gate.
- Fernquay's written answers on equity, runway and design support → RR2, RR3 and RR4 close.
- A deeper research pass on Fernquay (customer mentions, company records, news; up to 5 more searches and 2 more fetches) → RR1 and RR4 firm up. Say the word and it runs.
- A rehearsal for the 45-minute call with Ronan and Saoirse → the mock-interview module.

## Questions

G1 — Beyond checkout, which parts of the booking journey did you personally design or decide, and what was yours versus the squad's?

G2 — When you made a design call without a senior designer or design lead reviewing it, what was the call, and what happened?

G3 — What is the lowest base salary you would accept, and does the 0.5–1% equity change that number or sit on top of it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.