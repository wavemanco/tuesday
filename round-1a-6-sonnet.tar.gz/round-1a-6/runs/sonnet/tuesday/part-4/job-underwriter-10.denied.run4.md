Web searches weren't permitted in this session, so this assessment uses only what you've shared, and I've marked what I couldn't check.

## Decision snapshot

**Yes, worth taking the call, with one thing left to verify. Nothing in the posting or the WhatsApp message asks you for money, documents or personal details, but I couldn't confirm Fernquay itself from here (RR1). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Pay €52,000–€60,000 plus equity)
- `must_have` — direct: R3, R4, R5, R6 · adjacent: R7 (Own the booking flow end to end)
- `important` — adjacent: R8 (First, only designer) · unclear: R9 (Research calls with school owners)

R7 — the checkout redesign is a credible bridge to the whole flow, its limit named; R8 (`low`) — your own statement that you've never been the only designer, a gap to weigh; R9 (`low`) — who your sessions were with is not yet stated.

**Opportunity ledger.** The posting is open about pay and names the person you'd work with (RR4). Fernquay's existence and the live posting are not established (RR1). Sign-off, support and first-year success measures are unstated for a first-designer post (RR2), and equity is a percentage range with no terms (RR3).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Pay €52,000–€60,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Fernquay and the live role verify, which is RR1; (2) pay and equity terms meet your own floor, which is R2 and RR3; (3) sign-off and support for a first designer are answered to your satisfaction, which is R8 and RR2.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, booking software for sea-kayak and surf schools. Not established from outside sources (RR1) | `[grounded]` posting |
| Role | First product designer: own the booking flow end to end, run research calls with school owners, ship alongside two engineers | `[grounded]` posting |
| Works most closely with | Co-founder Ronan Kehoe | `[grounded]` posting |
| Working pattern | Hybrid: two days a week in the Galway office, the rest remote | `[grounded]` posting |
| Pay | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting |
| Scope read | One product, one small team, with design, customer research and flow ownership in one post | `[inferred]` from the duties list against "first designer" |
| First-year outcomes | None stated | `[grounded]` posting names none |
| Market calibration | Not established. The salary search didn't run, so I'm not giving a band from memory | `[grounded]` see Evidence status |
| How they contacted you | The co-founder messaged on WhatsApp to book a 45-minute video call with him and the CTO, Saoirse, with a calendar invite emailed. The message asks only for a time. Booking a video interview by chat is a routine step, so the WhatsApp contact is not itself a warning sign | `[grounded]` the message's wording; `[generic]` that chat scheduling for a call held elsewhere is routine |
| Unknowns | Company stage and funding, customers, equity terms, who signs off design, first-year success measures | `[grounded]` posting is silent on each |
| Contradictions | None between the posting and the message. I couldn't cross-check either against Fernquay's own site | `[grounded]` the two texts you gave me |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week at the Galway office | hard_gate | direct | medium | none | You say you moved back to Galway last year, so the term looks met. Medium because it rests on your statement alone | `[grounded]` posting and your statement | none |
| R2 | Pay €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | You haven't given a pay floor, so I can't say if the range meets it. Confidence is `none` because there is no stated constraint to grade | `[grounded]` posting; no floor given | G1: say your floor |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company, as you stated. No CV or portfolio was inspected | `[grounded]` your stated background | A CV or portfolio link would raise it to `high` |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" is stated. Strength is claimed, not yet shown | `[grounded]` your statement | The checkout case study or a Figma file would raise it |
| R5 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. Who planned them and wrote up the findings isn't stated | `[grounded]` your statement | A discussion guide or findings summary would raise it |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your statement | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned a checkout flow, which is one stage of a booking journey. The limit is that nothing yet shows you owned the steps before or after checkout, or owned it alone | `[grounded]` your statement; `[inferred]` that checkout is one stage of a full booking flow | G2 |
| R8 | Working as the first, only designer (inferred from "You would be our first designer") | important | adjacent | low | transferability | You've never been the only designer. What carries over is the research you ran and the squad work. The limit is that you haven't set design direction with no design peers | `[grounded]` your statement; `[inferred]` from the posting's "first designer" | Plan row A4 |
| R9 | Research calls with school owners | important | unclear | low | discovery | The posting asks for calls with business owners. Your sessions were with "customers", and whether those were travellers or business-side users isn't stated | `[grounded]` your statement and the posting | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay floor against the range (R2, hard_gate) | hard_gate | A stated range and equity percentage, and no floor from you | A gate not yet settled keeps the hard-gates line open | Not experience, a term: your minimum pay and any equity expectation | Your own stated figure | `[grounded]` posting range; no floor given |
| G2 | Ownership beyond checkout (R7, must_have) | transferability | A checkout redesign; nothing on other booking steps | R7 is a `must_have` row at `adjacent`, and the role is built on this ownership | Designing availability or date selection, confirmation and amend or cancel steps, or mobile booking; owning a flow with a PM or engineers rather than only a screen | A flow map, or the checkout case study with before and after | `[grounded]` your statement; `[inferred]` that these are the neighbouring stages |
| G3 | Research with business-side users (R9, important) | discovery | Monthly usability sessions with "customers", participants unspecified | The role's calls are with school owners, so who your participants were sets how close your research is | Calls with operators, suppliers or partner businesses; sessions you scoped, ran and wrote up yourself | A discussion guide, session notes or a findings summary | `[grounded]` your statement; the posting asks for owner calls |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools." | Fernquay may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one; `[grounded]` you found little online and my searches did not run | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | First-designer set-up: sign-off, support and success measures unstated | unknown | — | "You would be our first designer: own the booking flow end to end" | Design decisions may rest on one person, with priorities set by the co-founder and no stated measure of a good first year | `[inferred]` from "first designer" against the posting's silence | Who signs off design decisions, what does a good first year look like, and what support does a first designer get? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "0.5–1% equity" | The percentage may come without share or option type, vesting, or funding context | `[inferred]` from a range given with no terms | Is the equity options or shares, what is the vesting schedule, and what is the company's funding and runway? | unresolved |
| RR4 | Pay range and named working partner stated | positive_signal | — | "Salary €52,000–€60,000 plus 0.5–1% equity" | You can check pay against your floor before investing more time | `[grounded]` posting states the range and names Ronan Kehoe | Where in the range would this post sit for my experience? | noted |

## Application plan

Each row is a proposal, not an action I've taken. Everything below, the wording included, is pending your approval.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Reply on WhatsApp with a time that suits, and join through the video link on the emailed invite, checking the invite reached the address you applied with | The message asks only for a time | `[grounded]` the message | pending your approval |
| A2 | Before the call, look for Fernquay's own website or careers page and the role on it. If you can't find them, ask Ronan for the link on the call | See RR1 | `[grounded]` RR1 | pending your approval |
| A3 | Ask the verification questions from RR1, RR2, RR3 and RR4 on the call | The register doubles as call preparation | `[grounded]` register | pending your approval |
| A4 | Lead with: "I redesigned our checkout flow and ran monthly usability sessions with customers at a Dublin travel-booking company." If asked about being the first designer, say: "I haven't been the only designer anywhere; in my squad I redesigned checkout and ran the monthly usability sessions." | See R7, R8. Every clause traces to your own sentences, and it doesn't claim solo ownership | `[grounded]` your statements | pending your approval |

The call is coming up, and `mock-interview` is the module for rehearsing it.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search "Fernquay booking software sea kayak surf schools Galway" was refused, so nothing was read. It would have moved role reality's organization row and RR1 |
| 2. Role-family sweep | unavailable | Search "product designer salary Ireland Galway startup first designer 2026" was refused. It would have moved market calibration, the R2 comparison and RR4 |
| 3. Hiring manager's public footprint | unavailable | A name was given, so I searched "Ronan Kehoe co-founder Fernquay", which was refused. It would have moved the positioning in plan row A4 |

## Offer and upgrade menu

I can save this as a `tuesday-dossier.md` whenever you'd like.

- Permission to search: this runs the three targets above, with up to 5 searches and 2 fetches, to settle RR1, the pay band and Ronan's professional background.
- Your pay floor: R2 and the hard-gates line close.
- A link to the checkout case study or a Figma file: R3, R4 and R7 can move toward `high`.
- A discussion guide or findings summary from your sessions: R5 and R9 firm up.
- Ronan's answers on the call: RR1 to RR3 resolve and the decision firms up.

G1 — What is your pay floor, and does €52,000–€60,000 plus 0.5–1% equity meet it?
G2 — Beyond checkout, which other steps of a booking journey did you design or change, and what part of each was yours?
G3 — Who took part in your monthly usability sessions, and what part of planning them and writing up the findings was yours?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.