I've run two searches: one on the employer and one on the pay band. Next I'm fetching Calderbrook's careers page to check that the posting is live.
# Job Underwriting Assessment: Community Staff Nurse, Band 5 at Calderbrook Community Health CIC, Halifax

## Decision snapshot

**Yes, this is worth applying for. Status: `conditional_go`.** The gate rows R1 and R2 are met, and the open points are R4 (records) and the posting's live status (RR3).

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3, R5, R8 · adjacent: R6 (Leg-ulcer care), R7 (Catheter and continence care) · unclear: R4 (Clear, timely written records)
- `important`: adjacent: R10 (Own small caseload and care planning) · unclear: R9 (End-of-life visits)
- `preferred`: absent: R11 (Doppler assessment)

R6, R7 and R10: credible bridges, limits named; R4 and R9: the CV is silent, waiting on your answers; R11: a desirable, not an essential.

**Opportunity ledger.** A transparent, supported entry-level post: the pay range is stated (RR1) and a senior nurse supports the caseload (RR2). Two things are unconfirmed: whether the vacancy is still live (RR3) and the hours and rota (RR4).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. Your answer on R4 confirms records experience.
  2. The vacancy is confirmed live (RR3).
  3. The leg-ulcer and caseload bridges (R6, R10) are framed as adjacent, never as direct experience.

Your NI number isn't needed for any of this, and I haven't used it. Keep it out of applications until an employer asks for it after a written offer, through their own onboarding portal.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health runs adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract. It was founded in 2015 and has 410 staff across four locality hubs. | `[grounded]` its About page |
| Role | Band 5 district nursing for housebound adults at home. Duties are wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin and care planning, all on an electronic patient record. | `[grounded]` advert |
| Caseload and support | A small caseload of your own, supported by a senior community nurse. | `[grounded]` advert |
| Pay | £31,050–£37,800 plus mileage. Pool cars are provided. | `[grounded]` advert |
| Scope read | A standard entry route into community nursing: a small caseload with named senior support, not an unusually broad mandate. | `[inferred]` from the advert's support line and Band 5 title |
| Market calibration | In a survey of Band 5 community staff nurses in England, median basic pay was £34,300 and the interquartile range £32,400–£36,600. 61% were paid mileage and 24% had a pool or lease car. The advert's range spans that band. The band is what to expect, never this employer's offer. | `[generic]` Wardround 2026 survey; `[grounded]` advert figures |
| Named contact | Rhiannon Mabbott leads the Halifax district nursing team and was a district nurse for eleven years. She has spoken on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work. | `[grounded]` speaker page, Community Nursing Forum |
| Unknowns | Hours, weekend and on-call expectations; induction and supervision arrangements; which electronic patient record system is used; whether the vacancy is still open. | `[grounded]` advert silent on each |
| Contradictions | None between the advert and the About page. The careers page did not load. | `[grounded]` About page read; careers fetch returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | You state active Adult registration, revalidation due March 2028. This is stated, not checked. | `[grounded]` CV | You check your NMC register entry shows active, Adult field |
| R2 | Full UK driving licence (pool cars provided) | hard_gate | direct | medium | none | You state a full category B licence. This is stated, not checked. | `[grounded]` CV | You check your licence record on the DVLA's own service |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as an acute medical ward staff nurse. Experience length is graded as a requirement, not a gate. | `[grounded]` CV | none |
| R4 | Clear, timely written records | must_have | unclear | low | discovery | The CV is silent on documentation and on any electronic record system. | `[grounded]` CV silence | Question R4 below |
| R5 | Wound care | must_have | direct | medium | none | CV names wound care including pressure ulcers and surgical wounds. Wounds at home are not specifically stated. | `[grounded]` CV | none |
| R6 | Leg-ulcer care | must_have | adjacent | medium | transferability | Wound care carries over. Limit: leg ulcers and compression are not mentioned, so the CV does not show that work. | `[grounded]` CV; `[inferred]` adjacency | Bridge case in G3 |
| R7 | Catheter and continence care | must_have | adjacent | medium | transferability | Catheter care is stated. Limit: continence care is not stated. | `[grounded]` CV | Bridge case in G4 |
| R8 | Insulin administration | must_have | direct | medium | none | Stated on the CV. The advert's "care planning" part is carried in R10. | `[grounded]` CV | none |
| R9 | End-of-life visits | important | unclear | low | discovery | The CV is silent. Acute medical wards often care for dying patients, which is a lead for a question and not evidence. | `[grounded]` CV silence; `[generic]` ward pattern | Question R9 below |
| R10 | Own small caseload and care planning, in patients' homes | important | adjacent | medium | transferability | 18 months of first-week home visits in the discharge-to-assess team is real home-based work. Limit: you have never held a caseload, and care planning is not stated. The advert's senior-nurse support softens the step. | `[grounded]` CV and your statement; `[grounded]` advert | Bridge case in G5 |
| R11 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You have not done it. The advert lists it as desirable only. The contact has spoken on Doppler training for staff new to community work, so a training path may exist. | `[grounded]` your statement; `[inferred]` training path | Ask in the informal chat (A1) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Written records (R4, must_have) | discovery | Nothing on documentation or record systems | The only must-have row with no evidence either way, so it holds the decision at `conditional_go` | Electronic record entries on the ward or in the discharge team; handover notes; discharge documentation | A description of the systems used, or a redacted audit result | `[grounded]` CV silence; `[inferred]` that it moves the decision |
| G2 | End-of-life care (R9, important) | discovery | Not mentioned | Community nursing includes end-of-life visits, so an answer shapes which story you lead with | Caring for dying patients on the ward; supporting families; anticipatory medicines or symptom control you took part in; discharge-to-assess patients at end of life | A reference or practice note you can describe | `[grounded]` CV silence; `[generic]` that end-of-life care is a core part of community nursing |
| G3 | Leg-ulcer care (R6, must_have) | transferability | Wound care is stated, with no leg-ulcer or compression work | A must-have at `adjacent`, so the limit needs naming before an interview | Compression bandaging; leg-ulcer dressings on the ward | Competency sign-offs or training certificates | `[inferred]` bridge from stated wound care |
| G4 | Continence care (R7, must_have) | transferability | Catheter care is stated, continence care is not | Half the requirement is evidenced | Bladder and bowel care plans | A competency record | `[grounded]` CV |
| G5 | Own caseload (R10, important) | transferability | Home visits stated; no caseload | The advert says you hold a small caseload, so you need a ready honest framing | Planning your own visit list in the discharge team; follow-up decisions you owned | Description of how visits were assigned | `[grounded]` CV and your statement |
| G6 | Doppler (R11, preferred) | capability | No evidence, and you state none | A desirable, not a blocker | Training, if the employer offers it | The employer's answer | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay stated openly | positive_signal | — | "£31,050–£37,800 a year plus mileage" | A stated range spanning the survey's interquartile range suggests transparent pay | `[grounded]` advert figure; `[generic]` survey band, not this employer's offer | Where in the range would a nurse with five years' ward experience start? | noted |
| RR2 | Supervision stated | positive_signal | — | "supported by a senior community nurse" | A named senior nurse means the caseload is supervised | `[grounded]` advert | How much supervised visiting happens before a caseload is solo? | noted |
| RR3 | Posting live status | unknown | — | "Community Staff Nurse, Band 5 — Calderbrook Community Health CIC, Halifax" | The careers page did not load in my check. That could be a page move, a temporary fault or a closed vacancy. | `[grounded]` the fetch returned no page; `[generic]` pages move and close | Is this vacancy open, and what is the closing date? | unresolved |
| RR4 | Hours and rota unstated | unknown | — | "caring for housebound adults in their own homes" | The advert may leave weekend, on-call or late visiting expectations to later stages | `[inferred]` from the advert's silence | What are the working hours, the weekend rota and any on-call duties? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Use the informal chat the advert offers with Rhiannon Mabbott, and ask the RR2, RR3 and RR4 questions plus the Doppler training path (R11) | The advert names her as the contact. Her public talks cover leg-ulcer clinics and Doppler training for staff new to community work. | `[grounded]` advert; `[grounded]` speaker page | pending your approval |
| E1 | Lead your experience with: "Seconded for the last 18 months from the acute medical ward to the discharge-to-assess team, visiting patients at home in their first week after discharge." | See R10. Every clause is your own sentence, reordered. | `[grounded]` CV | resume_edits_pending_approval |
| E2 | Name wound care (pressure ulcers and surgical wounds), catheter care and insulin administration together, as your CV already states them | See R5, R7, R8. No new claim. | `[grounded]` CV | resume_edits_pending_approval |
| P1 | Say plainly in the chat or interview: "I've worked in patients' homes in the discharge team but haven't held my own caseload, and I haven't done Doppler assessment, so I'd value the support structure and training." | See R10, R11. This is your own statement of both limits, with no spin. | `[grounded]` your statements | pending your approval |

If you want E1 and E2 worked into a full tailored CV, that is resume-tailor's job.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about). The fetch of calderbrookhealth.example/careers returned no page. It moved role reality's organization and contradictions rows and set RR3. |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse district nursing salary Agenda for Change 2026", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). It moved the market calibration row and RR1. |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). It moved the named-contact row and A1. She is the advert's contact for an informal chat, so I have not assumed she is the hiring manager. |

I used only her public professional footprint.

I can save this as a `tuesday-dossier.md` if you want one for later steps.

## Upgrade menu

- Your answer on records (G1) → R4 moves, and the decision likely simplifies to `go`.
- Your answer on end-of-life care (G2) → R9 moves.
- A competency record or training certificate for compression or continence care → R6 and R7 rise toward `high`.
- Your pay floor and hours constraints → hard-gate checks against them become possible.
- A working careers link, or the recruiter confirming the vacancy → RR3 closes.
- A deeper research pass on Calderbrook (staffing, inspection reports, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

G1 — On the ward and in the discharge team, how did you record patient care and visits, on paper or an electronic system? What did you write up yourself, and how soon after a visit or shift?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G2 — Have you cared for patients at the end of their lives, on the ward or in the discharge team? What was your part, and what did you take on yourself?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C1 — Do you have any non-negotiables on pay floor, hours, weekends or on-call work?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.