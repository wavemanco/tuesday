I ran two searches, which are covered in the research tier line below. The full assessment follows.

# Job Underwriting — Remote Order Processing Coordinator, Velloway Logistics

## Decision snapshot

**No — please don't go ahead. RR1, RR2, RR3 and RR4 (each `severity: high`) are confirmed requests or terms in these messages. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R5 (Pay of at least €30,000 a year)
- `must_have` — direct: R1, R2, R3
- `important` — unclear: R4 (A quiet place to work)

R5 — "up to" pay and a 15–30 hour range leave the floor unsettled; R3 (`medium`) — written English inferred from ticket work, no sample seen.

**Opportunity ledger.** The messages ask for payment, a cheque deposit and bank, tax and ID details before any written offer, inside a process run wholly on Telegram (RR1, RR2, RR3, RR4). The employer itself could not be established (RR5), and the pay terms are open (RR7).

- **Hard gates:** none failed; unconfirmed: R5 (Pay of at least €30,000 a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would change this:** a written offer that names the role and its pay, from an employer you can reach through contact details on its own website. That offer would have to come with no payment, no cheque and no details asked for beforehand. Without it, the facts stay as they are.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Velloway Logistics; a search for it and its careers page returned no results, so the employer is not established from here | `[grounded]` search returned nothing |
| Mandate | Remote order processing, 15–30 hours a week, "up to €26 an hour plus commission", no experience needed | `[grounded]` posting |
| Hiring process | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | `[grounded]` posting |
| Contradictions | The posting lists no equipment requirement beyond "a quiet place to work", but the chat later asks for €349 for a "standard work kit" | `[grounded]` posting against your chat messages |
| Unknowns | Employer identity, employee or self-employed status, commission rate, the hourly rate you would actually get | `[grounded]` the posting is silent on each |
| Market calibration | A 2026 Irish pay guide puts salaried order-processing and customer-operations coordinators at a median of €31,200 a year (interquartile range €28,400–€34,100). A ceiling of €26 an hour comes to about €54,000 over a 40-hour week, well above that band for a role advertised as needing no experience. The guide excludes commission-only and freelance work, and I read only its search snippet. The band is what to expect, never this employer's offer | `[generic]` Pennoral 2026 pay guide snippet; `[inferred]` arithmetic from the posted rate |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Strong attention to detail | must_have | direct | medium | none | About 60 tickets a day in Zendesk over 3 years is specific and confirmed, but it is self-report with nothing inspected | `[grounded]` your background | none |
| R2 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel; how deep your formula work goes is not stated | `[grounded]` your background | none |
| R3 | Good written English | must_have | direct | medium | none | Ticket handling implies written replies, but you did not say so and no sample was inspected, so I take the lower band | `[inferred]` from the ticket work | none |
| R4 | A quiet place to work | important | unclear | low | discovery | You have not said | `[grounded]` silence | none; low stakes while the decision stands |
| R5 | Pay of at least €30,000 a year (your stated floor) | hard_gate | unclear | high | hard_gate | Confidence grades your statement of the floor. Fit is `unclear` because "up to €26" over 15–30 hours leaves it open: at the ceiling rate, 15 hours a week is about €20,280 a year and 30 hours about €40,560. €30,000 needs roughly 22 hours a week at the ceiling rate, and commission is unquantified | `[grounded]` your floor and the posting's figures; `[inferred]` the arithmetic | RR7's question |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Whether pay reaches €30,000 (R5, hard_gate) | hard_gate | Only "up to €26 an hour plus commission" and a 15–30 hour range; no rate, commission terms or contract type in writing | If the real rate or hours fall short, the role fails your floor | — | A written offer naming the rate, hours and contract type | `[grounded]` posting terms; `[inferred]` that the floor depends on the hours actually available |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Payment demanded for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | A transfer, once sent, may not come back; employers don't ask applicants to pay for the equipment they will work on | `[generic]` pattern of requests like this | Can you confirm, through your company's own website, that you ask applicants to pay for equipment before starting? | confirmed |
| RR2 | Cheque to lodge, with most of it sent on | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." | A lodged cheque can show as credited and be returned later; whatever you transferred in the meantime would then be yours to cover | `[generic]` how cheque clearing works | See RR1: the same check with the employer covers this request | confirmed |
| RR3 | Bank, tax and ID details before any offer | red_flag | high | "please send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up" | Sent before a written offer from a verified employer, these details can't be taken back | `[generic]` pattern of requests like this | See RR1: please ask the same employer-side check about this request | confirmed |
| RR4 | Hiring run wholly in chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." | Leaves no interview or contract you can place outside the chat, so you can't check who you are dealing with | `[generic]` what a chat-only process leaves open | Is there a named person, a company address and a written contract before any commitment? | confirmed |
| RR5 | Employer not established from attributable sources | risk_signal | medium | "Velloway Logistics" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who I would report to? | unresolved |
| RR6 | Contact address on an unknown mail domain | risk_signal | medium | "email velloway.hr@postmail.example" | I can't tell from here whether that domain is the employer's own, and an offer from an address that isn't theirs would be an offer in doubt | `[inferred]` from the domain against the lack of any company site | Does your company email come from your own domain, and what is it? | unresolved |
| RR7 | Pay terms open | unknown | — | "Earn up to €26 an hour plus commission on every order you process" | The real rate and commission may sit well below the ceiling, which matters against your €30,000 floor (R5) | `[inferred]` from "up to" and the unquantified commission | What is the hourly rate for this post, how is commission calculated, and is it employment or self-employment? | unresolved |

Hold off on the payment, the cheque deposit and sending your details, and go no further in the chat, until you have checked each request with the employer, through contact details on the employer's own website rather than the chat or the address these messages came from; who sent them is not yet confirmed. This job is very likely a scam. Don't deposit the cheque.

I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't pay the €349, deposit the cheque or send any details, and don't paste your IBAN anywhere. I have no use for your PPS number or passport photo and haven't used them | see RR1, RR2, RR3 | `[grounded]` register | pending your approval |
| A2 | Look up Velloway Logistics yourself, for example in the Companies Registration Office's public register and on any company website you can find, and use only contact details from there | see RR5, RR6 | `[generic]` ordinary employer check | pending your approval |
| A3 | If you have sent nothing, there is nothing to undo; if that changes, tell your bank at once | see RR2 | `[generic]` standard advice | pending your approval |
| A4 | Put your effort into other openings in customer operations, where your Zendesk and Excel work matches R1–R3 | the pay guide's median sits at your floor | `[generic]` pay guide snippet | pending your approval |

## Evidence status

Verified: none yet. Your background is self-report, so R1, R2 and R3 stay at `medium`.

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics official website careers"; no results, so the employer is not established. This fed role reality's organization row and RR5 |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator Ireland hourly pay"; it returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). This fed the market calibration row |
| 3. Hiring manager's public footprint | n/a | No name was given, only a Telegram handle, so there was no query to form |

## Dossier and upgrade menu

I can save this as a `tuesday-dossier.md` if you want a record to keep.

- A link to the original posting, or the company's own site if you find one → RR5 and RR6 could close.
- The written pay terms, if you are ever sent them → R5 and RR7 close.
- A deeper research pass on the employer (up to 5 more searches and 2 more fetches) — say the word and it runs.

G1 — Has anyone given you the hourly rate, the commission terms or whether you would be an employee or self-employed in writing, or only the posted "up to €26"?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.