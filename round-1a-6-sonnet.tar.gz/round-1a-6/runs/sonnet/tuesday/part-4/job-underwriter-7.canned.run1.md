I've run three searches (employer, pay band, team lead). Next I'll fetch the careers page to check the posting is live, then write up the assessment.
# Job Underwriting Assessment: Community Staff Nurse, Band 5 at Calderbrook Community Health CIC, Halifax

## Decision snapshot

**Yes, Aoife, this is worth applying for. The two things you flagged, no caseload of your own (R5, `adjacent`) and no Doppler assessment (R11, `absent`), are not hard gates. Status: `go`.**

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3 · unclear: R4 (Clear, timely written records)
- `important` — direct: R7a, R8a, R9a · adjacent: R5 (Hold a small caseload), R6 (Care for housebound adults), R7b (Leg-ulcer care) · unclear: R8b (Continence care), R9b (Care planning), R10 (End-of-life visits)
- `preferred` — absent: R11 (Doppler assessment)

R5 — a credible bridge, its limit named; R7b — a bridge from wound care, leg ulcers not shown; R4, R8b, R9b, R10 — the CV is silent.

**Opportunity ledger.** Nothing in the register is a warning sign. RR1 (posting not seen on the employer's site), RR2 (where in the pay range you would start, and how mileage works with a pool car) and RR4 (caseload build-up and rota) are unknowns to ask about. RR3 (named senior support) and RR5 (a team lead who has spoken on Doppler training for newcomers) are positive signals.

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** the status drops to `hold_pending_answers` if the post turns out to be closed (RR1) or if your own check of your registration or licence status doesn't match your CV (R1, R2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | A community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract. Founded 2015, 410 staff, four locality hubs | `[grounded]` About page fetched |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin administration and care planning, recorded on an electronic patient record | `[grounded]` advert |
| Supervision | A small caseload of your own, supported by a senior community nurse | `[grounded]` advert |
| Essential vs desirable | Essential: NMC Adult registration, full UK licence, one year post-registration, clear timely records. Desirable: Doppler assessment | `[grounded]` advert |
| Scope read | A Band 5 post built for nurses new to a community caseload, not a senior or lead post | `[inferred]` from "small caseload", a named support line and a one-year experience floor |
| Market calibration | The advertised £31,050–£37,800 spans the whole middle half of Band 5 community staff nurse pay in a 2026 England-wide survey (n=1,240, median £34,300, interquartile range £32,400 to £36,600). The same survey reports 61% paid mileage and 24% with a pool or lease car. This is a survey pattern, not this employer's offer, and I read only the search snippet of the page | `[generic]` Wardround 2026 pay guide; `[grounded]` advert for its own range |
| Hiring contact | Rhiannon Mabbott leads the Halifax district nursing team after eleven years as a district nurse. At a 2025 forum she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` forum speaker page |
| Unknowns | Caseload size, induction length, rota and weekend cover, your starting point in the pay range, whether mileage applies when using a pool car | — |
| Contradictions | None between the advert and the About page. The advert itself was not seen on the careers page (RR1) | `[grounded]` About page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | Your CV states Adult registration, active, revalidation due March 2028. This is stated, not checked: the register entry is yours to check | `[grounded]` CV | You check your own register entry before applying |
| R2 | Full UK driving licence (pool cars provided) | hard_gate | direct | medium | none | Your CV states a full category B licence. Stated, not checked: your licence record is yours to check | `[grounded]` CV | You check your own licence status |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years on an acute medical ward against a one-year floor. Experience length is graded on fit, not treated as a gate | `[grounded]` CV | none |
| R4 | Clear, timely written records on an electronic patient record | must_have | unclear | low | discovery | The CV is silent on records and on any electronic system. Ward nursing generally involves documentation, but that is a pattern, not evidence about you | `[grounded]` CV silence; `[generic]` ward documentation pattern | G3 |
| R5 | Hold a small caseload of your own | important | adjacent | medium | transferability | You state you have never held your own caseload. Adjacent: 18 months seconded to the discharge-to-assess team, visiting patients at home in their first week after discharge. Limit: visiting is not owning a list over time | `[grounded]` CV and your statement | G4; ask RR4 |
| R6 | Care for housebound adults in their own homes | important | adjacent | medium | transferability | Your home visits are direct experience of care in the home. Limit: the CV doesn't say your patients were housebound | `[grounded]` CV | G4 |
| R7a | Wound care | important | direct | medium | none | Wound care including pressure ulcers and surgical wounds is on your CV. Confirmed and specific, but no inspectable artifact yet | `[grounded]` CV | A wound-care competency record would raise it to `high` |
| R7b | Leg-ulcer care | important | adjacent | medium | transferability | Wound care carries over. Limit: leg ulcers and compression therapy are not on the CV | `[grounded]` CV | G1 |
| R8a | Catheter care | important | direct | medium | none | Catheter care is on your CV, with no inspectable artifact yet | `[grounded]` CV | A competency record would raise it |
| R8b | Continence care | important | unclear | low | discovery | The CV doesn't mention continence care beyond catheters | `[grounded]` CV silence | G2 |
| R9a | Insulin administration | important | direct | medium | none | Insulin administration is on your CV, with no inspectable artifact yet | `[grounded]` CV | none |
| R9b | Care planning | important | unclear | low | discovery | The CV is silent on care planning. The secondment may involve some, but the CV doesn't say | `[grounded]` CV silence | G2 |
| R10 | End-of-life visits | important | unclear | low | discovery | The CV is silent on end-of-life care | `[grounded]` CV silence | G2 |
| R11 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You state you have never done one. It is desirable only, and the closure path is training in post. The team lead's talk on Doppler training for newcomers suggests it may be offered | `[grounded]` your statement and forum page; `[inferred]` that the team offers it | Ask RR5; claim nothing |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Leg-ulcer care (R7b, important) | transferability | Wound care is on the CV; leg ulcers and compression are not | Leg-ulcer care is named in the advert's opening line of duties, so a stronger bridge here narrows the most visible clinical gap | Dressing venous leg ulcers on the ward; applying or reviewing compression bandaging or hosiery; referring a patient to tissue viability or a leg-ulcer clinic | A competency sign-off, a study-day certificate | `[grounded]` CV mentions pressure ulcers and surgical wounds only |
| G2 | End-of-life, continence and care planning (R10, R8b, R9b, important) | discovery | The CV is silent on all three | They are three of the advert's named duties, and each could move from `unclear` to `direct` | Last-days-of-life care on the ward; bladder and bowel assessments; contributing to a discharge care plan | End-of-life training record, continence competencies, a sanitised discharge care plan | `[grounded]` CV silence |
| G3 | Records on an electronic system (R4, must_have) | discovery | The CV doesn't say which record systems you have used or how you recorded home visits | R4 is the one `must_have` row below `direct` | Using an electronic patient record on the ward or in the discharge team; recording visit notes after seeing patients at home | A record-keeping audit, electronic record training certificate | `[grounded]` CV silence |
| G4 | Own caseload (R5, R6, important) | transferability | No caseload held; home visits only | The advert says you will hold a small caseload. The limit is real and the employer's induction is what closes it | Planning your own day's visits in the discharge team; following your own patients across a week | Your secondment's role description | `[grounded]` your statement; no question this turn, it goes to the employer as RR4 |
| G5 | Doppler (R11, preferred) | capability | None, by your own account | Desirable only; closure is training in post, not a CV edit | n/a | n/a | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not seen on the employer's own site | unknown | — | "Community Staff Nurse, Band 5 — Calderbrook Community Health CIC, Halifax" | The vacancy may be listed on a careers page I couldn't reach: the About page points to one, but I guessed its address and it returned no page | `[grounded]` About page and the failed fetch | Is this post still open, and what is the closing date? | unresolved |
| RR2 | Starting point in the range, and mileage with pool cars | unknown | — | "£31,050–£37,800 a year plus mileage"; "pool cars are provided" | Where you would start may depend on how the employer counts your prior experience, and mileage may apply only to use of your own car | `[inferred]` from the advert's wording | Where in the range would someone with five years' post-registration experience start, and is mileage paid when using a pool car? | unresolved |
| RR3 | Named senior support for a first caseload | positive_signal | — | "supported by a senior community nurse" | The supervision line is stated, which lowers the risk of your first caseload | `[grounded]` advert; `[inferred]` risk reading | How much of the first weeks is shadowed or co-visited before you hold the caseload alone? | noted |
| RR4 | Caseload size, induction and rota not stated | unknown | — | "You will hold a small caseload of your own" | The advert gives no caseload size, induction length, or evening and weekend cover | `[grounded]` advert silence; `[generic]` that community nursing rotas often include extended hours | What is the caseload size, how long is induction, and what is the rota pattern? | unresolved |
| RR5 | Team lead speaks on Doppler training for newcomers | positive_signal | — | "contact Rhiannon Mabbott, Community Nursing Team Lead" | Doppler is listed as desirable, and its team lead has spoken publicly about training staff new to community work in it, so it may be taught in post | `[grounded]` forum page; `[inferred]` that this team teaches it | Is Doppler training provided for new starters, and how soon after joining? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Move the 18-month discharge-to-assess secondment (visiting patients at home in their first week after discharge) to the top of the CV in your own existing words. Keep the wound, catheter and insulin lines visible. Add no claim of a caseload or leg-ulcer work | see R5, R6, R7a, R8a, R9a | `[grounded]` CV | `resume_edits_pending_approval` |
| P1 | In any statement or chat, say plainly that you haven't held your own caseload or done a Doppler assessment, then describe what you did do | see R5, R11 | `[grounded]` your statement | pending your approval |
| P2 | Take up the informal chat with Rhiannon Mabbott before applying, and ask the RR1 to RR5 questions verbatim | The advert invites the chat, and the register doubles as interview preparation | `[grounded]` advert, register | pending your approval |
| A1 | Check your own NMC register entry and licence status before applying. I haven't looked up either number | see R1, R2 | `[grounded]` CV states, not checked | pending your approval |

## Evidence status

Verified: none yet. Your NI number isn't needed for this stage. I haven't used or repeated it, and your NMC number stays out of any lookup.

Research tier: L1 — searches 3 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax". Fetched "About Calderbrook Community Health" (calderbrookhealth.example/about) and tried calderbrookhealth.example/careers, which returned no page. Moved role reality's organization row and RR1 |
| 2. Role-family sweep | yes | Searched "community staff nurse district nursing Band 5 Calderdale salary Agenda for Change 2026", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Moved role reality's hiring-contact row, RR5 and plan row P2 |

If you want a record of this assessment to carry forward, I can write it up as `tuesday-dossier.md`.

## Upgrade menu

- A wound-care, catheter or continence competency sign-off, or an electronic-record training certificate → R7a, R8a and R4 can rise toward `high`.
- Your answers to G1 to G3 → R7b, R10, R8b, R9b and R4 may move from `unclear` or `adjacent` to `direct`.
- A link to the live posting on the employer's own careers page → RR1 closes.
- The employer's answers on pay start and mileage → RR2 closes.
- Help rehearsing the informal chat or an interview is the mock-interview module's job.
- A deeper research pass on Calderbrook (up to 5 more searches and 2 more fetches) → fuller employer diligence for the register. Say the word and it runs.

**Questions** (any order; short answers are fine)

G1 — On the ward or in the discharge team, have you dressed or reviewed leg ulcers, or applied or checked compression bandaging, and was that your own work or supervised?

G2 — Which of end-of-life care, continence care and care planning did you personally do, and in what setting?

G3 — Which electronic record system did you use on the ward and in the discharge team, and how did you record your home visits?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.