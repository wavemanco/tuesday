I've run three searches (employer, pay, team lead). Next I'll fetch the employer's careers page to check the posting is live, then write the assessment.
**Yes, this is worth applying for. Status: `conditional_go`.** Your fit is sound, and the one open condition is confirming the posting is live (RR1).

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3 · unclear: R4 (Clear, timely written records)
- `important`: direct: R7a, R9 · adjacent: R5 (Home-based care of housebound adults), R6 (Wound and leg-ulcer care) · unclear: R7b (Continence care), R8 (End-of-life visits), R10 (Own caseload and care planning)
- `preferred`: absent: R11 (Doppler assessment)

R5 — home visiting is real but short-term; R6 — wound care without leg-ulcer evidence; R10 (`low`) — a caseload you haven't held.

**Opportunity ledger.** The role is plausible and structured: pay and pool cars are stated (RR3), the support set-up is described but not specified (RR2), and I couldn't confirm the posting on the employer's careers page (RR1).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed open on Calderbrook's own site (RR1); (2) your caseload and leg-ulcer limits are stated honestly, not glossed (R6, R10); (3) you can speak to end-of-life care from real examples (R8).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015; 410 staff, four locality hubs | `[grounded]` the About page, fetched |
| Mandate | District nursing for housebound adults at home: wounds and leg ulcers, catheter and continence care, end-of-life visits, insulin, care planning, on an electronic patient record | `[grounded]` advert |
| Supervision | A small caseload of your own, supported by a senior community nurse | `[grounded]` advert |
| Team lead | Rhiannon Mabbott leads the Halifax district nursing team, after eleven years as a district nurse. At a 2025 forum she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` forum speaker page |
| Pay | £31,050–£37,800 plus mileage, pool cars provided | `[grounded]` advert |
| Market calibration | A 2026 survey of community Band 5 staff nurses in England (n=1,240) puts median basic pay at £34,300, with an interquartile range of £32,400 to £36,600. The advert's range spans that interquartile range. 24% of respondents had a pool or lease car, so one is not the norm. This is a band to expect, never this employer's offer | `[generic]` Wardround 2026 pay guide; `[grounded]` advert for the stated figures |
| Unknowns | Caseload size; how support and induction work for a first community post; mileage rate; whether the post is live on the careers page | `[inferred]` from the advert's silence |
| Contradictions | None found between the advert and the About page | `[grounded]` About page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | CV states registration active, Adult field, revalidation March 2028. Stated, not checked: only the NMC register can confirm it | `[grounded]` CV | You check your NMC register entry |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | CV states a full UK licence, category B; pool cars are provided. Stated, not checked | `[grounded]` CV, advert | You check your driving record |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward; the advert sets a length, not a credential bar | `[grounded]` CV | none |
| R4 | Clear, timely written records | must_have | unclear | low | discovery | CV is silent on documentation or electronic records. Ward nursing involves charting, but that is a reading, not your evidence | `[grounded]` CV silence; `[generic]` ward nursing involves routine documentation | Mention any e-record system you've used in the application |
| R5 | Care of housebound adults in their own homes | important | adjacent | medium | transferability | 18 months visiting patients at home in their first week after discharge is genuine home practice. Limit: short post-discharge episodes, not ongoing care of housebound people | `[grounded]` CV | Bridge case in the plan, limit named |
| R6 | Wound and leg-ulcer care | important | adjacent | medium | transferability | Pressure-ulcer and surgical-wound care is credible adjacent work. Limit: no leg-ulcer or compression work stated | `[grounded]` CV | See G3 |
| R7a | Catheter care | important | direct | medium | none | Stated on the CV | `[grounded]` CV | none |
| R7b | Continence care | important | unclear | low | discovery | The CV names catheter care only | `[grounded]` CV silence | Mention any continence work in the application |
| R8 | End-of-life visits | important | unclear | low | discovery | CV silent. Acute medical wards often care for dying patients, but that is not your stated evidence | `[grounded]` CV silence; `[generic]` acute medical wards often provide end-of-life care | See G2 |
| R9 | Insulin administration | important | direct | medium | none | Stated on the CV | `[grounded]` CV | none |
| R10 | Own caseload and care planning | important | unclear | low | discovery | You've never held your own caseload. Whether the discharge-to-assess visits were lone, with your own decisions and plans, isn't stated | `[grounded]` your statement, CV | See G1 |
| R11 | Doppler assessment (desirable) | preferred | absent | none | capability | You've never done one. Preferred only, so a minor risk | `[grounded]` your statement | See G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Own caseload and care planning (R10, important) | discovery | A secondment of home visits, but not whether you visited alone or planned care yourself | This is the nearest your history gets to the caseload the post gives you | Visiting alone and deciding what to do on the spot; writing or updating a care plan; escalating a deterioration to a GP | A discharge-to-assess role description or referral pathway document | `[grounded]` CV; `[inferred]` that this closes the biggest gap in the important tier |
| G2 | End-of-life visits (R8, important) | discovery | The CV does not mention palliative or end-of-life care | It's a named duty of the post | Caring for dying patients on the ward; symptom control; supporting families; discharge for rapid return home to die | A palliative-care training certificate or reflective account | `[grounded]` CV silence |
| G3 | Leg-ulcer care (R6, important) | transferability | Pressure-ulcer and surgical-wound work, with no leg-ulcer or compression work stated | Leg-ulcer care is named in the advert and the team lead has spoken on it | Compression bandaging; venous ulcer assessment; tissue viability link-nurse duties | A competency record or training certificate | `[grounded]` CV and the team lead's talk topics |
| G4 | Doppler assessment (R11, preferred) | capability | No Doppler experience, as you said | Desirable only | None to recall. Closure path: ask whether the employer trains new staff in it | n/a | `[grounded]` your statement; `[inferred]` that the team lead's talk on Doppler training for new community staff suggests training may exist |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed on the employer's careers page | unknown | — | "Community Staff Nurse, Band 5 — Calderbrook Community Health CIC, Halifax" | The address I tried for the careers page returned nothing, which may only mean I guessed it wrong. The post may be live elsewhere on the site | `[grounded]` the fetch returned no page | Can you confirm this post is open, and its closing date? | unresolved |
| RR2 | Support and induction unspecified | unknown | — | "supported by a senior community nurse" | A first community post may come with little structured induction | `[inferred]` from the advert's silence on caseload size and induction | How large is the starting caseload, and what induction and supervision does a first community nurse get? | unresolved |
| RR3 | Pay range and pool cars stated | positive_signal | — | "£31,050–£37,800 a year plus mileage" and "pool cars are provided" | Pay is disclosed and the range sits within the surveyed spread | `[grounded]` advert; `[generic]` the survey comparison | Is the pool car available for the commute, and what is the mileage rate? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Phone Rhiannon Mabbott for the informal chat the advert offers, and ask the RR1, RR2 and RR3 questions plus the Doppler training question (G4) | The advert invites it and she leads the team | `[grounded]` advert and speaker page | pending your approval |
| A2 | Check your NMC register entry and your driving record before applying | R1 and R2 are stated, not checked | `[grounded]` the map | pending your approval |
| E1 | Lead the experience section with the discharge-to-assess secondment, in your own words: "seconded to its discharge-to-assess team, visiting patients at home in their first week after discharge". Say plainly that you haven't yet held your own caseload and haven't done Doppler assessment | Your strongest bridge is R5; the limits are also what an interviewer will probe | `[grounded]` CV and your statements | pending your approval |

If you decide to apply, resume-tailor can turn E1 into a line-by-line edit ledger.

## Evidence status

Verified: none yet. You pasted a National Insurance number; it isn't needed for this and I haven't used it.

Research tier: L1 — searches 3 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax"; fetched "About Calderbrook Community Health" (calderbrookhealth.example/about). The employer exists as described. A fetch of calderbrookhealth.example/careers returned no page, so RR1 stays open |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse district nursing Agenda for Change pay scale 2026/27", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). It fed market calibration and RR3. It did not give the official pay scale |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead", which returned "Rhiannon Mabbott — Community Nursing Team Lead" (communitynursingforum.example/speakers/rhiannon-mabbott). It fed role reality and plan row A1 |

I can also draft this assessment as a `tuesday-dossier.md` for later steps; say so if you'd like it.

**Upgrade menu**

- An answer to G1 → R10 firms up, and the caseload gap is clearer.
- An answer to G2 → R8 moves toward `direct`.
- A leg-ulcer competency record or training certificate → R6 firms up.
- Your NMC register and driving record checks → R1 and R2 move from stated to checked.
- The employer's careers page link or the recruiter's reply → RR1 closes, and the `conditional_go` is likely to become `go`.
- A deeper research pass on Calderbrook (up to 5 more searches and 2 more fetches: staffing, news, public staff reports) — say the word and it runs.

**Questions**

- G1 — In the discharge-to-assess role, did you visit alone, make your own decisions on the spot, and write or update care plans? Give one example.
- G2 — Have you cared for dying patients, whether on the ward or through discharges home to die? What did you do yourself?
- G3 — Have you done any leg-ulcer assessment or compression bandaging, even supervised?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.