I've run four searches, and Fernquay, the posting, the salary band and Ronan all turned up. Next I'm fetching the careers page and the about page to check that they match your posting.
## Decision snapshot

**Yes, worth continuing with. The company and the posting check out against Fernquay's own pages (RR1, RR6), and WhatsApp scheduling is routine (A1). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: R2 (Salary €52,000–€60,000)
- `must_have`: direct: R3, R4, R5, R7 · adjacent: R8 (Own the booking flow end to end)
- `important`: adjacent: R6 (Research calls with school owners), R9 (First designer, no design peers)

R8 — checkout is one stage of a booking flow, its limit named; R9 — adjacent, since you have not held a sole-designer seat.

**Opportunity ledger.** Fernquay is established on its own pages and open about pay and process (RR1, RR4, RR6). The open items are support for a first designer (RR2), equity terms (RR3) and runway (RR5).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your pay floor sits inside the stated range (R2, RR4); (2) the equity terms and runway answers are acceptable (RR3, RR5); (3) support for a first designer is concrete (RR2, R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. It has six people, is based in Galway, was founded in 2023 by Ronan Kehoe and Saoirse Doyle, and is funded by its customers | `[grounded]` About page, fetched |
| Mandate | First design hire: own the booking flow end to end, run research calls with school owners, ship alongside two engineers | `[grounded]` posting and careers page |
| Terms | Hybrid with two days a week in Galway; €52,000–€60,000 plus 0.5–1% equity. The careers page repeats the pay and hybrid terms | `[grounded]` posting and careers page, fetched |
| Process | Apply with one real project to jobs@fernquay.example. The posting says the same: "one messy real project" over a polished deck | `[grounded]` careers page, posting |
| Scope read | Design, research and delivery sit in one seat with no design peer | `[inferred]` from "first designer" plus three responsibility strands |
| Market calibration | The stated range sits inside the Irish interquartile range for 3–5 years' experience (median €57,000; range €51,500–€62,000). This is a national survey, not a Galway figure, and not this employer's offer | `[generic]` Tillerby 2026 Ireland salary report; `[grounded]` posting for the range |
| Hiring manager | Ronan Kehoe is co-founder and CEO, and was previously product lead at a Galway travel-software company for five years. He may read your checkout work from the product side | `[grounded]` profile snippet for the roles; `[inferred]` for the reading |
| Unknowns | Support for a first designer; equity terms; runway; Saoirse Doyle's title (the message calls Saoirse CTO, and the About page gives no title) | `[inferred]` that the two Saoirses are one person |
| Contradictions | None between the posting and the careers page | `[grounded]` both read |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week at the Galway office | hard_gate | direct | medium | none | You say you moved back to Galway last year. This is your own account, with nothing inspected | `[grounded]` your message | none |
| R2 | Salary €52,000–€60,000 | hard_gate | unclear | none | hard_gate | You gave no pay floor, so whether the range meets it is not established. The range is in the posting and sits within the survey band | `[grounded]` posting; `[generic]` survey band | Question R2 below |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer in Dublin, stated by you and not yet inspected | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" is your claim. The checkout case study Ronan mentions would be the inspectable proof, and I have not seen it | `[grounded]` your background | Share the case study and this can rise to `high` |
| R5 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. These were usability sessions, not discovery interviews, and R6 carries that limit | `[grounded]` your background | A session guide or findings write-up would raise it |
| R6 | Research calls with school owners | important | adjacent | medium | transferability | Usability sessions with travel customers carry over. The limit is that nothing shows interviews with small-business owners, which is a different audience and a different kind of conversation | `[grounded]` your background; `[inferred]` on the limit | G3 |
| R7 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your background | none |
| R8 | Own the booking flow end to end | must_have | adjacent | medium | discovery | You redesigned the checkout flow, which is one stage of a booking journey. Whether you owned other stages is not stated | `[grounded]` your background | Question G1 below |
| R9 | First designer: no design peers, you set the practice | important | adjacent | medium | transferability | You said you have never been the only designer. You did own a checkout redesign and a monthly research cadence. The limit is that you have not built practice with no peers | `[grounded]` your message; `[inferred]` on the limit | Question G2 below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning the whole booking flow (R8, must_have) | discovery | A checkout redesign. The other stages of the journey are not described | It is the heart of the job, and it separates "owned checkout" from "owned booking" | Search or availability screens, basket or payment, confirmation and post-booking emails, changes and cancellations, handoff of specs to engineers | The case study, a flow map, before and after metrics | `[grounded]` your background is silent on other stages; `[inferred]` that this is the central claim to firm up |
| G2 | Building practice as the only designer (R9, important) | transferability | You owned checkout and a research cadence inside a larger team | Posting calls this a first design hire, so you would set the practice yourself | Starting a component library or style rules, a research routine, a handoff process, freelance or side projects where you were the only designer | A Figma library you started, a process doc, a side project | `[grounded]` your message; `[generic]` that first-designer roles usually involve setting process |
| G3 | Interviewing school owners (R6, important) | transferability | Usability sessions with consumer customers | It is a different audience (owners of small businesses), and the posting names it as a duty | Calls with business customers, supplier or partner interviews, any research with non-consumers | A research plan, interview guide or synthesis | `[grounded]` your background; `[inferred]` on the audience difference |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer matches the posting on its own pages | positive_signal | — | "Six people, based in Galway. Founded 2023 by Ronan Kehoe and Saoirse Doyle, and funded by its customers." | A real, small, customer-funded firm hiring as posted. The searches returned only its own pages and one profile, with no independent coverage | `[grounded]` About and careers pages, fetched | Who else would I work with day to day, and can I speak to one of the engineers? | noted |
| RR2 | Support for a first designer is unstated | unknown | — | "You would be our first designer: own the booking flow end to end, run research calls with school owners, and ship alongside our two engineers." | Design, research and delivery may sit with one person with no reviewer | `[inferred]` from the scope against the posting's silence on support | Which design decisions are mine alone, who reviews my work, and how do I reach school owners for research? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "0.5–1% equity" | Vesting, grant type, strike price and the share base are not given, so the value is unknown | `[inferred]` from the posting's silence | What are the vesting and cliff, is it options or shares, the strike price, and the fully diluted base the 0.5–1% is measured on? | unresolved |
| RR4 | Pay stated and within the surveyed band | positive_signal | — | "€52,000–€60,000" | Pay is disclosed and sits inside the band for 3–5 years | `[grounded]` posting; `[generic]` survey band | Where in the range would four years' experience land? | noted |
| RR5 | Runway unstated for a customer-funded firm | unknown | — | "funded by its customers" | A revenue-funded firm's hiring depends on its current revenue, and the posting says nothing about runway | `[inferred]` from the funding line | How many months of runway are there, and how is this hire planned into them? | unresolved |
| RR6 | Process open and consistent | positive_signal | — | "we would rather see one messy real project than a polished deck" | The process matches the careers page and asks for work you already have | `[grounded]` posting and careers page | What do the stages after this call look like? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | The WhatsApp scheduling is routine. Check that the calendar invite came from an address at fernquay.example, the domain on the careers page. If it did not, write to jobs@fernquay.example to confirm the call. | Small teams often schedule by chat. I can't confirm the WhatsApp number is Ronan's from here | `[generic]` small-team habit; `[grounded]` careers page domain | pending your approval |
| E1 | Say honestly where you stand: "I redesigned our checkout flow at my Dublin travel-booking company and ran monthly usability sessions with customers. I have worked in a squad with four engineers. I haven't been the only designer, and I'd like to tell you what I owned." Every clause traces to your own sentences | R9, R6 | `[grounded]` your background | pending your approval |
| Q1 | Ask RR2, RR3 and RR5 verbatim on the call | The register doubles as call preparation | `[grounded]` register | pending your approval |
| W1 | Bring one real project, as the careers page asks, and be ready to say what was yours and what the team's | R4, R5, R8 | `[grounded]` careers page | pending your approval |

If you'd like to rehearse for the call with Ronan and Saoirse, the mock-interview module does that.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway" and "Fernquay Product Designer Galway careers". Fetched "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer) and "About Fernquay" (fernquay.example/about). Moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland Galway startup first designer", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Moved the market calibration row, R2 and RR4 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe), read as a search snippet only. Moved role reality's hiring manager row and the framing in E1 |

I can save all this as `tuesday-dossier.md` if you want to carry it forward.

## Upgrade menu

- Your checkout case study or a flow map → R4 and R8 can rise to `high`, and G1 may close.
- A research guide or findings write-up → R5 and R6 strengthen.
- Your pay floor → R2 closes, and RR4 is then set against it.
- A starter Figma library or process doc, or a side project where you were the only designer → G2 narrows.
- Fernquay's answers on equity, runway and support → RR2, RR3 and RR5 close.
- A deeper research pass on Fernquay (customer reports, news, team changes; up to 5 more searches and 2 more fetches) — say the word and it runs.

**R2** — Is there a minimum salary or equity you'd need, and does €52,000–€60,000 meet it?

**G1** — In the checkout redesign, which parts of the booking journey did you personally own, and what changed as a result?

**G2** — Have you ever set up design practice on your own, such as a research routine, a component library or handoff rules, even on a side project? What did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.