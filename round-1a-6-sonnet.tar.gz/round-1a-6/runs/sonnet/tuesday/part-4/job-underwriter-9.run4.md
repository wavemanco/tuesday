Search permission wasn't granted, so this runs on what you pasted and the research accounting below says so.

## Decision snapshot

**Yes, this is normal. Employers ask for bank details, a PPS number and a passport scan once a written offer has been accepted, so you can go ahead with this step. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Pay €38,000–€42,000), R2 (Hybrid, two days a week in the Limerick office)
- `must_have` — direct: R3, R5, R6, R8, R9 · adjacent: R7 (Monthly payroll for 240 staff) · unclear: R4 (Irish PAYE, PRSI and USC)
- `important` — unclear: R11 (Answer staff payroll queries) · absent: R10 (Pension changes)

R7 — a credible bridge, scale and cadence differ; R4 — your background doesn't say the payroll was Irish; R10 — confirmed never done by you, learnable.

**Opportunity ledger.** The written offer is specific and matches the advert (RR2). Two items are open: I couldn't check the employer independently (RR1), and the payroll system and cover arrangements are unknown (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Pay €38,000–€42,000), R2 (Hybrid, two days a week in the Limerick office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Marrowgate is confirmed through its own website — RR1; (2) the written contract matches the offer email — RR2; (3) you ask how pension changes are handled and trained, since R10 is a duty you haven't done.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick | `[grounded]` JD header and offer email |
| Mandate | Run monthly payroll for 240 staff; starters, leavers, pension changes; monthly payroll-to-ledger reconciliation; staff payroll queries | `[grounded]` JD |
| Offer | Permanent, €40,000, reporting to Declan Garvagh, Finance Manager; start date agreed after your notice period | `[grounded]` offer email |
| Working pattern | Hybrid, two days a week in the Limerick office | `[grounded]` JD and offer email agree |
| Process | Two in-person interviews at their office; offer from people@marrowgatehousing.ie; reply within five working days; onboarding portal link sent after you accept | `[grounded]` your account and the offer email |
| Market calibration | Not done: the salary search was refused, so there is no band. €40,000 sits in the middle of the advertised €38,000–€42,000 | `[grounded]` JD and offer figures only |
| Unknowns | Payroll software; pension scheme and who administers it; probation length; who covers or reviews payroll | `[grounded]` the posting is silent on each |
| Contradictions | None between the advert and the offer | `[grounded]` the two texts compared |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Salary €38,000–€42,000 (offer: €40,000) | hard_gate | unclear | none | hard_gate | You haven't stated a pay floor, so I can't say whether €40,000 meets it | `[grounded]` JD, offer; no candidate constraint given | Question 1 |
| R2 | Hybrid, two days a week in the Limerick office | hard_gate | unclear | none | hard_gate | No commute or schedule constraint stated by you | `[grounded]` JD, offer; no candidate constraint given | Question 1 |
| R3 | 2+ years running payroll | must_have | direct | medium | none | Three years of fortnightly payroll, confirmed and specific, with no document inspected | `[grounded]` your background | none |
| R4 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | You didn't say the hotel group payroll was Irish. Your Limerick-area job search and PPS number only hint at it | `[inferred]` from that context | Question 2 |
| R5 | Strong Excel | must_have | direct | medium | none | Daily use, pivot tables and XLOOKUP, confirmed and specific | `[grounded]` your background | none |
| R6 | Payroll qualification or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024. The certificate itself isn't inspected | `[grounded]` your background | A copy of the certificate would raise it to `high` |
| R7 | Run monthly payroll for 240 staff | must_have | adjacent | medium | transferability | You ran fortnightly payroll for 90 staff. The same core work, but a different cadence and about 2.7 times the headcount | `[grounded]` your background | See G3 |
| R8 | Process starters and leavers | must_have | direct | medium | none | Stated directly | `[grounded]` your background | none |
| R9 | Reconcile payroll to the general ledger monthly | must_have | direct | medium | none | You did the monthly payroll-to-ledger reconciliation | `[grounded]` your background | none |
| R10 | Process pension changes | important | absent | none | capability | You've said your manager handled these and you haven't done them. No adjacent work is stated | `[grounded]` your statement | See G4 |
| R11 | Answer staff payroll queries | important | unclear | low | discovery | Not stated. Starters and leavers work often involves staff queries, but that is an inference | `[inferred]` from the starters and leavers work | Question 3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Irish statutory deductions (R4, must_have) | discovery | Nothing says the hotel payroll applied PAYE, PRSI and USC | A must-have currently unclear; the answer likely closes it | Applying tax credits and cut-offs, PRSI classes, USC bands; submitting to Revenue | Payslip layout or a payroll-run checklist, redacted | `[grounded]` background is silent; `[inferred]` that it was Irish |
| G2 | Staff payroll queries (R11, important) | discovery | Not mentioned | An important responsibility with no evidence either way | Explaining payslips, correcting deductions, answering starter and leaver questions | A query log or template reply, redacted | `[grounded]` background is silent |
| G3 | Scale and cadence (R7, must_have) | transferability | Fortnightly for 90 staff against monthly for 240 | The core work carries over, but the scale and cadence haven't been exercised | The monthly reconciliation you already run gives some monthly-close practice | A redacted payroll-run checklist | `[grounded]` your background |
| G4 | Pension changes (R10, important) | capability | You've never done them | A named duty you'd learn on the job | None stated | A training or handover plan from the employer | `[grounded]` your statement. The realistic path is asking for training from the employer (see A3) |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Marrowgate Housing, a housing association in Limerick" | The research that would confirm the employer was refused, so this is unresolved rather than adverse. Your two in-person interviews at their office point the other way | `[generic]` pattern for any employer I haven't been able to check, not a claim about this one | Can you point me at the role on your own careers page? | unresolved |
| RR2 | Offer in writing, matching the advert | positive_signal | — | "permanent post of Payroll Administrator at €40,000 a year" | The terms are specific and match the advert's pay band and hybrid pattern | `[grounded]` JD and offer compared | Will the written contract confirm permanent status, €40,000, probation length and the pension scheme? | noted |
| RR3 | Payroll system and cover not stated | unknown | — | "Run the monthly payroll for our 240 staff" | The role may be a sole-operator function with no named backup or review | `[inferred]` from the JD's silence on team and software | Which payroll software do you use, and who covers or reviews payroll when I'm away? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | After you accept, enter the bank details, PPS number and passport scan only in the onboarding portal. Check the portal address against the one on Marrowgate's own website before you type anything, and don't send these by email | Before an offer, employers don't need this. After a written offer naming the role and pay, they need your bank details to pay you, your PPS number for Revenue, and an ID check for right to work. The portal-address check is cheap protection | `[generic]` normal onboarding practice | pending your approval |
| A2 | Before or when you accept, ask for the written contract and job description, with probation, pension scheme and notice terms | see RR2 | `[grounded]` RR2 | pending your approval |
| A3 | Ask about pension changes in your own words: "I've run starters, leavers and the monthly reconciliation. Pension changes were handled by my manager, so I haven't done those myself. How are they handled here, and is there a handover or training?" | see R10, G4. Each clause traces to your own sentences | `[grounded]` your statements | pending your approval |
| A4 | Put RR1 and RR3's questions to Declan Garvagh or the People Team, using contact details from Marrowgate's own website | see RR1, RR3 | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches "Marrowgate Housing Limerick housing association" and "Marrowgate Housing careers Payroll Administrator marrowgatehousing.ie" were refused. It would have moved RR1 and the contradictions row |
| 2. Role-family sweep | unavailable | The search "payroll administrator salary Ireland Limerick" was refused. It would have moved the market calibration row and R1's context |
| 3. Hiring manager's public footprint | unavailable | Declan Garvagh was named, but search permission was refused and I didn't retry. It would have moved the scope read and A3's framing |

I'd offer to write this up as `tuesday-dossier.md` if you want to keep it.

## Upgrade menu

- Permission to run web searches → RR1 closes or stays open, plus the market calibration for R1.
- Your pay floor and what two office days a week means for you → R1 and R2 move to `direct` or fail.
- The written contract and job description → RR2 firms up, and R4, R10 and R11 can be read against the real duties.
- A copy of your Payroll Technician certificate → R6 to `high`.
- A redacted reconciliation or payroll-run checklist → R5, R9 and G3 to `high`.
- Whether the hotel payroll was Irish → R4.

## Questions

1. R1, R2 — Is €40,000 at or above your pay floor, and are two days a week in the Limerick office workable for you?
2. G1 — Was the hotel group payroll run under Irish PAYE, PRSI and USC?
3. G2 — Did you answer staff queries about payslips or deductions, and who in the team did you handle them for?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.