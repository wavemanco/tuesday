I checked the employer and the pay band, and the assessment is below. I didn't use your IBAN, PPS number or passport details, and I don't need them.

## Decision snapshot

**No, don't go ahead. RR1, RR2, RR3 and RR4 (each `severity: high`) are confirmed requests in the messages you were sent, and this job is very likely a scam. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Annual pay of at least €30,000)
- `must_have`: direct: R2, R3 · adjacent: R4 (Attention to detail)
- `important`: unclear: R5 (A quiet place to work)

R1 — the posting gives a ceiling, not a floor; R4 — a credible bridge, its limit named.

**Opportunity ledger.** The requests are RR1 (pay €349 for equipment), RR2 (deposit a cheque and send most of it on), RR3 (bank, tax and passport details before any offer) and RR4 (hiring run wholly on Telegram). The employer could not be established (RR5), and the commission and contract terms are unstated (RR6).

- **Hard gates:** none failed; unconfirmed: R1 (Annual pay of at least €30,000).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would change this:** a written offer from an employer you have verified yourself, through its own website. It would have to name the pay and hours, and nothing could be asked of you beforehand.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Velloway Logistics. My search for it and the role returned no results, so I can't establish the firm from here | `[grounded]` search returned nothing |
| Mandate | Remote order processing, 15–30 hours a week, "up to €26 an hour plus commission on every order you process" | `[grounded]` posting |
| Hiring process | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | `[grounded]` posting |
| Pay as stated | A ceiling only. The commission rate and the contract type (employee or contractor) are not given | `[grounded]` posting |
| Pay arithmetic | At the top rate, €30,000 a year needs about 22 hours every week. At 15 hours it is about €20,280 | `[grounded]` posting's figures, my arithmetic |
| Market calibration | Salaried order-processing and customer-operations coordinators in Ireland: median €31,200, interquartile range €28,400–€34,100. This is one guide, it excludes freelance and commission-only work, and it is not this employer's offer | `[generic]` one pay guide |
| Contradictions | The posting says "No experience needed, full training provided" and mentions no purchases. The messages then ask you to pay for equipment | `[grounded]` posting against the messages |
| Unknowns | Who the employer is, who the "equipment partner" is, the commission rate, the contract type | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Annual pay of at least €30,000 (your floor) | hard_gate | unclear | high | hard_gate | Confidence grades your own stated floor. The posting gives only "up to €26" over a flexible 15–30 hours, so the floor isn't established | `[grounded]` your statement and the posting | A written rate, guaranteed hours and commission from a verified employer |
| R2 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel. This is self-reported and nothing has been inspected | `[grounded]` your background | none |
| R3 | Good written English | must_have | direct | medium | none | Three years of written customer tickets in Zendesk. Self-reported | `[grounded]` your background | none |
| R4 | Strong attention to detail | must_have | adjacent | medium | transferability | About 60 tickets a day and training two new starters are credible adjacent work. Limit: you haven't described error rates or checking routines | `[inferred]` from your ticket volume | none |
| R5 | A quiet place to work | important | unclear | low | discovery | Your background doesn't say | `[grounded]` background silent | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay floor (R1, hard_gate) | hard_gate | Only a ceiling is stated | Your income need is the one term that decides this | — | A written offer naming rate, hours and commission | `[grounded]` posting wording |
| G2 | Quiet workspace (R5, important) | discovery | Nothing stated | Minor and easy for you to settle | — | — | `[grounded]` background silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Payment for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | A transfer is hard to recover, and the refund depends on wages not yet earned. Employers don't ask applicants to buy their equipment. This request is very likely a scam. Don't pay it | `[generic]` pattern of requests like this | Do you ask applicants to pay for equipment before starting? (put to the employer through contact details on its own website, not through this chat) | confirmed |
| RR2 | Cheque deposit, then onward transfer | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." | A lodged cheque can show in your account before it has cleared and be returned later, which would leave the money you sent as your own loss. This request is very likely a scam. Don't deposit the cheque | `[generic]` pattern of requests like this | See RR1 | confirmed |
| RR3 | Bank, tax and ID details before an offer | red_flag | high | "please send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up" | These details, once shared, can be used to open accounts or apply for credit in your name. They were asked before any offer | `[generic]` pattern of requests like this | See RR1 | confirmed |
| RR4 | Hiring wholly by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." | It leaves no way to confirm who you are dealing with | `[generic]` pattern of chat-only processes | See RR1 | confirmed |
| RR5 | Employer not established from attributable sources | risk_signal | medium | "Velloway Logistics" | The firm may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR6 | Pay terms withheld | unknown | — | "up to €26 an hour plus commission" | The commission rate and the guaranteed hours are missing, so the €30,000 floor can't be tested | `[grounded]` posting wording | What is the commission rate, and what hours are guaranteed? | unresolved |

Hold off on the payment, the cheque deposit and sending your details, and go no further in the chat, until you have checked each request with the employer, through contact details on the employer's own website rather than the chat or the address these messages came from; who sent them is not yet confirmed.

I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Send nothing more in the chat: no payment, no cheque deposit, no IBAN, PPS number or passport photo | see RR1, RR2, RR3 | `[grounded]` register | pending your approval |
| P2 | Look for the firm independently and contact it only through details on its own website. Don't use the Telegram handle or the email address in the messages | see RR5 | `[grounded]` register | pending your approval |
| P3 | If you want to flag it, report the posting to the jobs site you found it on, and Telegram's report option | Reporting is a common step for requests like these | `[generic]` general practice | pending your approval |
| P4 | Put your effort into other openings. A real offer should come with a written contract, pay terms and a company email address | see R1, RR6 | `[generic]` general practice | pending your approval |

## Evidence status

Verified: R1 (your stated floor). Unverified leads: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics careers remote order processing coordinator". It returned no results, so the employer is not established. This produced RR5 and the role reality organization row |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator salary Ireland hourly rate". It returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). This gave the market calibration row |
| 3. Hiring manager's public footprint | n/a | No hiring manager's name was given. The chat handle is not a name |

## Upgrade menu

- A written offer or contract naming the legal entity, rate, hours and commission → R1 and RR6 could be settled.
- A link to the original posting → I could check whether it is live and matches what you pasted.
- A deeper research pass on this firm (up to 5 more searches and 2 more fetches) — say the word and it runs.

One line on a possible addition: I could draft a short, neutral message for you to send through an employer's verified website contact. It would add a safe way to test any future offer, and I'll write it only if you approve.

I'm not asking questions this turn, because no answer would change the decision.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.