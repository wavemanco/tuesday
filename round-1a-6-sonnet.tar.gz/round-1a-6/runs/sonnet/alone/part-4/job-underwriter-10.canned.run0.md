I've read the skill's rules. Next I'm checking whether Fernquay exists online (company site, careers page, market pay for the role), then I'll write the assessment.
**Yes, it's worth taking the call, and Fernquay matches what its own website says about it (role reality, RR4). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Hybrid, two days in Galway), R2 (Salary €52,000–€60,000)
- `must_have` — direct: R3, R4, R5 · adjacent: R6 (Research calls with school owners), R8 (Own the booking flow end to end)
- `important` — direct: R7 · absent: R9 (First or only designer)

R9 — the real stretch, and you flagged it yourself; R6, R8 — credible bridges, limits named in the map.

**Opportunity ledger.** The employer matches its own pages, and the pay and scope are stated openly (RR4). The gaps are what the posting leaves out: equity terms (RR1), design decision rights and resources (RR2), and runway (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Hybrid, two days in Galway), R2 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 meet your own limits on days in Galway and salary floor; (2) RR1's equity terms are answered in writing; (3) RR2's decision rights are concrete, and you are comfortable that R9 means no design peer.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. It has six people, is based in Galway, was founded in 2023 by Ronan Kehoe and Saoirse Doyle, and is funded by its customers | `[grounded]` fernquay.example/about |
| Posting | The careers page lists the same role: first design hire, hybrid, two days a week in Galway, €52,000–€60,000 plus equity. It asks for one real project | `[grounded]` fernquay.example/careers/product-designer |
| Mandate | Own the booking flow, run research calls with school owners, ship alongside two engineers | `[grounded]` posting |
| Scope read | One designer covering end-to-end flow, research and delivery is ordinary for a first design hire at six people, but there is no design peer or manager | `[inferred]` from team size against the stated mandate |
| Hiring manager | Ronan Kehoe is co-founder and CEO. The one result found says he was previously product lead at a Galway travel-software company for five years. Your closest collaborator is probably product-minded, so your checkout work is a relevant story for him | `[grounded]` search result snippet for the first sentence; `[inferred]` for the second |
| Market calibration | €52,000–€60,000 sits inside the middle range for 3–5 years of experience in Ireland (median €57,000; interquartile range €51,500–€62,000). It is a fair offer, not a premium one | `[generic]` Tillerby 2026 Ireland Design Salary Report (one survey, n=520); `[grounded]` posting for the figure |
| Unknowns | Equity terms, design decision rights, tooling and research budget, runway, and what "end to end" covers | — |
| Contradictions | None between your pasted posting and the careers page | `[grounded]` both pages fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week at the Galway office | hard_gate | unclear | none | hard_gate | You live in Galway, which suggests it works, but you gave no constraints. Fit stays unclear until you confirm | `[grounded]` posting; your Galway move | Question 1 |
| R2 | Salary €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | The posting is open about pay. Your floor is not given, so I can't say it clears | `[grounded]` posting | Question 1 |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company. This is a CV statement with no artifact read | `[grounded]` your message | none |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" over four years. A work sample would raise it | `[grounded]` your message | bring the project in A2 |
| R5 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. The limit is that these are evaluative sessions, which differs from the research calls in R6 | `[grounded]` your message | none |
| R6 | Run research calls with school owners | must_have | adjacent | low | discovery | Usability sessions with customers are close, but you haven't said whether you interviewed customers about how they work. Owners of small schools are business customers | `[inferred]` adjacency from your usability sessions | see G1 |
| R7 | Happy working directly with engineers | important | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your message | none |
| R8 | Own the booking flow end to end | must_have | adjacent | medium | discovery | You redesigned the checkout flow, which is part of a booking flow. Whether you owned more than checkout is unstated | `[grounded]` your message; `[inferred]` adjacency | see G2 |
| R9 | First and only designer, with no design peer (implied by "our first designer") | important | absent | medium | transferability | You said you have never been the only designer. Owning checkout decisions inside a squad is the nearest evidence, and it is not the same thing | `[grounded]` your message; `[inferred]` requirement | see G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Research calls with school owners (R6, must_have) | discovery | Usability sessions with customers, with no mention of interviews about how customers work | It is a named duty of the role, and it is the one the posting stresses | Customer interviews before a design, calls with partner businesses, support or sales calls you sat in on | A sanitized interview guide or session plan | `[inferred]` from your description; `[generic]` that interviews of this kind are usual for a B2B first designer |
| G2 | End-to-end booking flow (R8, must_have) | discovery | A checkout redesign | "End to end" probably spans search, availability, payment and confirmation | Any work before or after checkout in the same journey | A flow map or case-study page | `[inferred]` from the posting's wording |
| G3 | No design peer (R9, important) | transferability | Squad work, with design decisions made inside it | The role has no design lead to defer to | Moments you set direction, used or built a component library, or made a call without design review | One example of a design decision you owned | `[inferred]` bridge from your squad work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Equity terms unstated | unknown | — | "0.5–1% equity" | The percentage may be of fully diluted shares, with vesting or exercise terms still to be set | `[generic]` early-stage equity offers are often described by percentage alone | What class of shares is this, what is the vesting schedule, and is the percentage fully diluted? | unresolved |
| RR2 | Design decision rights and resources unstated | unknown | — | "own the booking flow end to end" | Ownership of a flow may sit beside a founder who sets product direction, with no stated budget for research tools | `[inferred]` from the posting's silence, plus Ronan Kehoe's product background | Which design decisions are mine alone, and which go to you? What is the budget for research and tooling? | unresolved |
| RR3 | Runway not published | unknown | — | "funded by its customers" (about page) | A customer-funded business grows only as fast as revenue, so a new salary depends on it | `[generic]` pattern for companies without outside investors | How many months of runway does the company have, and what is the revenue trend? | unresolved |
| RR4 | Pay, scope and expectations stated openly | positive_signal | — | "€52,000–€60,000" and "we would rather see one messy real project than a polished deck" | A transparent posting, and one that asks for real work rather than a polished deck | `[grounded]` posting | Who owns the success measures for the booking flow in year one? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Reply on WhatsApp to confirm a time. Check that the calendar invite arrived from a fernquay.example address. If in doubt, email jobs@fernquay.example, the address on the careers page | Scheduling a video call by message is routine at a small company, and the careers page gives that address for applications | `[generic]` for scheduling by chat; `[grounded]` careers page | pending your approval |
| A2 | Choose one real project to walk through, with the mess left in: your checkout redesign, plus one of the usability sessions with an outcome | The posting asks for a real project | `[grounded]` posting | pending your approval |
| A3 | Ask RR1, RR2 and RR3 verbatim on the call | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A4 | Positioning, offered as one line: "At my Dublin travel-booking company I redesigned our checkout flow and ran monthly usability sessions with customers, working in a squad with four engineers." Say plainly that you have not been the only designer, and say what you would do about it | Every clause traces to your own sentences, and nothing about owning a whole flow or doing generative research is added | `[grounded]` your message | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway" and "Fernquay product designer Galway careers"; fetched "About Fernquay" (fernquay.example/about) and "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer). Role reality: the organization, posting and contradictions rows. The employer is established and the posting is live and consistent, so no failed-attribution entry |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland 3+ years startup Galway", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Market calibration `[generic]`; it showed no salary mismatch |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe). Only the search snippet was read, so the scope read in role reality rests on one line |

I can't confirm from here that the WhatsApp message came from Ronan. His name and role match the company's own page, which is why A1 checks the invite's sender address.

I can write up `tuesday-dossier.md` of this assessment if you'd like to keep it.

**Upgrade menu**
- Your salary floor and Galway-days limit → R1 and R2 move to `direct` or `hard_gate_fail`, and the decision firms up.
- A sanitized interview guide or session plan → G1 and R6 strengthen.
- A flow map or case-study page showing what your redesign covered → R8 and G2 resolve.
- Ronan's reply on equity terms, decision rights and runway → RR1, RR2 and RR3 close.
- A deeper research pass on Fernquay (customer reviews, leadership history, recent news; up to 5 more searches and 2 more fetches) → say the word and it runs.

**Questions**
1. (R1, R2) What are your limits on salary and on days a week in the Galway office, so I can check them against €52,000–€60,000 and two days?
2. (G1) Before designing, have you ever interviewed customers about how they work, as opposed to testing a design with them?
3. (G2) Did your checkout redesign cover only the checkout steps, or more of the booking journey around them?

You can answer in text, paste a voice-note transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.