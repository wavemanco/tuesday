I'll read the skill's reference files first.
I've read the skill's rules. Now I'm checking whether the two employers exist and what the market pays for each role, using four of the five L1 searches.
I couldn't run the searches. WebSearch was refused all four times, so nothing below about either employer or pay is checked, and I've marked it that way. Everything else rests on the two postings and your background.

## Decision snapshot

**Femi, the Duinvaart Operations Analyst role is worth your time. The Kroonhaven Supply Planner role isn't.**

**Duinvaart (A rows): `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: A7 (Hybrid, three days a week in Rotterdam)
- `must_have` — direct: A1, A2, A3, A4a · unclear: A4b (Temperature compliance tracking)
- `important` — adjacent: A5 (Working with depot managers on route changes)
- `preferred` — adjacent: A6 (Dutch a plus)

A4b — cold-chain temperature work isn't evidenced yet; A7 — the Rotterdam days are unconfirmed against where you live.

**Opportunity ledger.** The duties are concrete (RA3), but pay is withheld (RA1), the team's working language is unstated (RA4), and the employer is unchecked (RA2).

- **Hard gates:** none failed; unconfirmed: A7 (Hybrid, three days a week in Rotterdam); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) you can show or honestly describe temperature-compliance work (A4b, G1); (2) three Rotterdam days a week works for you (A7, G3); (3) the posting is confirmed live on Duinvaart's own site (RA2).

**Kroonhaven (B rows): `no_go`.** Capability gaps sit across several `must_have` rows with no realistic closure: B1, B2, B3 and B5 are all `absent`.

**Fit ledger.**

- `hard_gate` — unclear: B8 (On-site in Utrecht)
- `must_have` — adjacent: B6 (Fluent Dutch) · unclear: B4 (Advanced Excel) · absent: B1 (3+ years supply or demand planning in FMCG), B2 (Own the 13-week supply plan), B3 (Balance capacity against forecast), B5 (SAP IBP or similar)
- `important` — adjacent: B7 (Run the weekly S&OP meeting)

B1, B2, B3 and B5 — no planning work exists to point to; B7 — your weekly review is a real bridge to S&OP, with its limit named.

**Opportunity ledger.** Pay is withheld (RB2) and the employer is unchecked (RB1). Neither changes the decision.

- **Hard gates:** none failed; unconfirmed: B8 (On-site in Utrecht); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **What would change this:** evidence of planning work you haven't described, covering B1, B2, B3 and B5. You said you've never worked in planning, so I treat this as settled.

## Role reality

| Role | Element | What it is | Provenance |
|---|---|---|---|
| A | Organization | Duinvaart Cold Chain, Rotterdam, refrigerated fleet. Existence not checked | `[grounded]` posting header; research refused |
| A | Mandate | Track on-time delivery and temperature compliance; weekly Power BI dashboards; work with depot managers on route changes | `[grounded]` posting |
| A | Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` posting |
| A | Scope read | An analyst post, not a planning or ownership post: it reports on performance and advises depots | `[inferred]` from the verbs "track", "build dashboards", "work with" |
| A | Unknowns | Salary, team working language, who sets route changes, how temperature data reaches the analyst | `[grounded]` posting silent on all four |
| B | Organization | Kroonhaven Foods, Utrecht, chilled ready-meals. Existence not checked | `[grounded]` posting header; research refused |
| B | Mandate | Own the 13-week supply plan, balance capacity against forecast, run the weekly S&OP meeting | `[grounded]` posting |
| B | Working pattern | On-site in Utrecht | `[grounded]` posting |
| B | Scope read | A planning post with ownership of the plan, which is a different discipline from performance analysis | `[inferred]` from "own the plan" against your analyst history |
| B | Unknowns | Salary, SAP IBP versus other system, team size | `[grounded]` posting silent |
| Both | Market calibration | Not produced: the role-family sweep was refused | `[generic]` none available |
| Both | Contradictions | None between the two postings and your account | `[grounded]` provided text only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| A1 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | You state 4 years as an operations analyst at a parcel carrier in Amsterdam. Confirmed and specific, no inspectable artifact yet: expect a probe | `[grounded]` your statement | none |
| A2 | Strong SQL | must_have | direct | medium | none | "SQL ... daily" is specific and confirmed. No sample query or artifact seen | `[grounded]` your statement | offer: a sanitized query sample would raise to high |
| A3 | Power BI or Tableau | must_have | direct | medium | none | Power BI daily, including the on-time delivery dashboard your depot managers use. Whether you built it or maintained it is not stated, so the claim stays at "use daily, including" | `[grounded]` your statement | offer: a sanitized dashboard screenshot would raise to high |
| A4a | Track on-time delivery | must_have | direct | medium | none | The on-time delivery dashboard and the weekly route-performance review are on-time tracking | `[grounded]` your statement | none |
| A4b | Track temperature compliance for a refrigerated fleet | must_have | unclear | low | discovery | You haven't mentioned temperature-controlled or compliance-monitored freight. Parcel carriers sometimes handle such freight, but nothing says yours did | `[grounded]` silence in your background; `[generic]` that parcel carriers sometimes carry temperature-sensitive freight | G1 |
| A5 | Work with depot managers on route changes | important | adjacent | medium | transferability | Depot managers use your dashboard and you ran the weekly route-performance review. Limit: you haven't said the review produced route changes or that you proposed them | `[grounded]` your statement; limit is the absence of a stated route-change role | G2 |
| A6 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational Dutch against a "plus". Limit: not fluent | `[grounded]` your statement | state the level plainly |
| A7 | Hybrid, three days a week in the Rotterdam office | hard_gate | unclear | none | hard_gate | The posting states the term. You gave no location or commute constraint, and your last job was in Amsterdam | `[grounded]` posting; no constraint given | G3 |
| B1 | 3+ years supply or demand planning in FMCG | must_have | absent | none | capability | You've never worked in planning. A years-of-experience line is not a gate, but postings like this are likely screened against it literally | `[grounded]` your statement; `[inferred]` literal screening | closure path in G4 |
| B2 | Own the 13-week supply plan for chilled ready-meals | must_have | absent | none | capability | No planning ownership in your background | `[grounded]` your statement | G4 |
| B3 | Balance production capacity against the forecast | must_have | absent | none | capability | No capacity or forecast work described | `[grounded]` your statement | G4 |
| B4 | Advanced Excel | must_have | unclear | none | discovery | You named SQL and Power BI; Excel is not mentioned either way | `[grounded]` silence in your background | none, not decisive alone |
| B5 | SAP IBP or a similar planning system | must_have | absent | none | capability | SQL and Power BI are analytics tools, not planning systems | `[grounded]` your statement | G4 |
| B6 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational against fluent. Limit: the posting asks for fluency, and it sits in its requirements list | `[grounded]` your statement and the posting | none |
| B7 | Run the weekly S&OP meeting | important | adjacent | medium | transferability | You ran a weekly route-performance review. Limit: S&OP balances demand, supply and finance, which a route review doesn't exercise | `[grounded]` your statement; the S&OP comparison is `[generic]` | none |
| B8 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | The posting states the term. You gave no location or commute constraint | `[grounded]` posting; no constraint given | not pursued, since B is `no_go` |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Temperature compliance (A4b, must_have) | discovery | Nothing in your background touches temperature-controlled freight | Half of the first stated duty is temperature compliance, so the answer decides how you frame the application | Parcels with a chilled or pharma lane; excursion or SLA reports; any food or medical customer you reported on | A sanitized report, a KPI definition, a dashboard view | `[grounded]` silence; `[generic]` that a role built around this duty will probe it |
| G2 | Route changes with depot managers (A5, important) | transferability | You ran the weekly review. Whether it led to route changes is not stated | Closes the gap between reporting and advising on routes | A route or schedule change your review prompted; a depot-level exception you escalated | A review agenda, a before-and-after chart | `[grounded]` your statement; `[inferred]` that the review fed route decisions |
| G3 | Rotterdam three days a week (A7, hard_gate) | hard_gate | No location or commute constraint stated | A term you meet or don't, which wording cannot fix | n/a | n/a | `[grounded]` posting; no constraint given |
| G4 | Planning experience (B1, B2, B3, B5, must_have) | capability | No planning work or planning-system use | These are the core of the Kroonhaven post | Closure path, not a recall prompt: planning-system training, or a role closer to planning that your analysis skills feed | A course certificate | `[generic]` closure paths for analysts moving toward planning; no entity claim |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RA1 | Salary not stated | unknown | — | none; the posting has no pay line | Pay may sit anywhere in the market range, and I have no band to compare it with | `[inferred]` from the posting's silence; no band, since the sweep was refused | What salary range is budgeted for this post? | unresolved |
| RA2 | Employer and posting not checked | unknown | — | "Duinvaart Cold Chain, Rotterdam" | Research was refused, so existence and a live posting are unverified. A small firm may simply have a thin footprint | `[generic]` pattern, not a claim about this firm | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RA3 | Concrete duties and outputs | positive_signal | — | "Track on-time delivery and temperature compliance ... build weekly dashboards in Power BI" | The work is defined and measurable | `[grounded]` posting | Which depots and how many vehicles does the weekly dashboard cover? | noted |
| RA4 | Team working language unstated against "Dutch a plus" | unknown | — | "Dutch a plus" | The team may work in Dutch day to day even though it is only a plus | `[inferred]` from the posting's silence on language | What is the team's working language? | unresolved |
| RB1 | Employer and posting not checked | unknown | — | "Kroonhaven Foods, Utrecht" | Same as RA2 | `[generic]` pattern, not a claim about this firm | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RB2 | Salary not stated | unknown | — | none; the posting has no pay line | Same as RA1 | `[inferred]` from the posting's silence | What salary range is budgeted for this post? | unresolved |

## Application plan

For Duinvaart only. Each row is proposed and `pending your approval`.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Resume line: "Worked daily in SQL and Power BI, including the on-time delivery dashboard our depot managers use." | A2, A3, A4a. Every clause is your sentence. It says "including", not "built", because I don't know that you built it | `[grounded]` your statement | `resume_edits_pending_approval` |
| E2 | Resume line: "Ran our weekly route-performance review." | A4a, A5. Your words, nothing added about who attended or what it changed | `[grounded]` your statement | `resume_edits_pending_approval` |
| P1 | Lead the application with the dashboard and the weekly review, because they answer the first two duties the posting lists | A3, A4a, A5 | `[grounded]` posting and your statement | pending your approval |
| P2 | State Dutch as conversational, without rounding it up | A6 | `[grounded]` your statement | pending your approval |
| P3 | Ask RA1, RA2 and RA4 in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Duinvaart Cold Chain Rotterdam" and "Kroonhaven Foods Utrecht"; both were refused. It would have moved whether each employer exists and the posting is live (RA2, RB1) |
| 2. Role-family sweep | unavailable | Searched "operations analyst logistics Rotterdam salary Netherlands" and "supply planner FMCG Netherlands salary SAP IBP"; both were refused. It would have given the market calibration and a pay band (RA1, RB2) |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

One offer beyond the spec: I can screen your next postings against these same hard requirements, so you can drop mismatches like Kroonhaven quickly. I'll do it only if you say yes.

I can also save all of this as `tuesday-dossier.md` whenever you like.

## Upgrade menu

- Permission to run searches → the employer checks (RA2, RB1), a pay band (RA1, RB2) and a market calibration line.
- A sanitized Power BI dashboard screenshot → A3 to `high`. A sanitized SQL sample → A2 to `high`.
- An answer on temperature-controlled freight → A4b resolves and the Duinvaart conditions narrow.
- Your location and commute limit → A7 resolves.
- The hiring manager's name → the scope read and which of your stories to lead with.

G1 — Did your parcel carrier handle any temperature-controlled or compliance-monitored freight, such as a chilled lane, a pharma or food customer, or an excursion report? What did you track and report?
G2 — Did your weekly route-performance review ever lead to a route or schedule change at a depot? What did you do, and what did the depot managers do?
G3 — Where do you live, and does being in the Rotterdam office three days a week work for you?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.