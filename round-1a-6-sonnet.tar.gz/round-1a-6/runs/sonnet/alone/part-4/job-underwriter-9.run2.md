**Yes, this is normal, and the offer looks routine.** The advice never to hand over bank details, PPS number or passport applies to requests that come before a real offer, or from someone you can't verify. Your situation is different.

**Why it looks fine**
- You had two in-person interviews at their office, then a written offer with a named manager, a salary and terms.
- They ask for the documents only after you accept, and through a portal rather than by email.
- Each item has an ordinary purpose. Bank details are for paying you. Your PPSN is needed for Revenue, because the employer has to register you as an employee before the first payroll. The passport is for the right-to-work and ID check, and they've asked for the original on day one.
- You'd be doing this payroll work yourself. You already know why a payroll department needs these details.

**Checks worth doing before you submit anything**
1. **Check the sender.** Look up Marrowgate Housing's number on their own website, not from the email. Phone or email the People Team or Declan Garvagh to confirm the offer is genuine. Confirm that `people@marrowgatehousing.ie` is the domain they actually use.
2. **Check the portal link.** Don't enter details through a link in an email without looking at where it goes. The address should be on marrowgatehousing.ie or a named payroll or HR platform they confirm. If in doubt, ask them to confirm the portal URL by phone first.
3. **Never send these details by reply email.** If anyone asks for them that way, or before you've accepted, stop and ring them.
4. **Ask for the written contract or terms before you accept.** These should cover the start date, probation, pension, notice period and hours. Asking is normal, and five working days is enough time to do it.

If the call confirms the offer and the portal is theirs, go ahead.

**On the role itself**
- You meet most of the requirements: 3 years of payroll, ledger reconciliation, the Payroll Technician cert and strong Excel.
- **Pension changes** are your gap. You've never done them yourself, so tell them now and ask what training or handover you'd get.
- The other differences are scale and frequency. You've run 90 staff on fortnightly payroll, and this is 240 staff monthly.
- I haven't checked Marrowgate against any outside sources, so the confirmation call is the real check.

I can also run a fuller fit assessment or help you draft the questions for the call.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.