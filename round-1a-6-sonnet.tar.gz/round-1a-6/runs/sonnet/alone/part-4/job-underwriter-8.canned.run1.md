# No, I wouldn't go ahead

Send no money, no cheque deposit and no personal details. This job is very likely a scam, because it asks you to pay for equipment, lodge a cheque and give bank, tax and ID details before any written offer, all in a chat-only process. I can't establish the firm from here. The status is `no_go`.

## Decision snapshot

**No, don't go ahead: RR1, RR2, RR3 and RR4 are confirmed severe red flags · `no_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Pay of at least €30,000 a year)
- `must_have` — direct: R3 · adjacent: R2 (Strong attention to detail), R4 (Good written English), R5 (Processing customer orders)
- `important` — unclear: R6 (A quiet place to work)

R2, R4 and R5 — credible bridges from your ticket and tracker work, limits named; R1 — the posting gives only a ceiling, so the floor can't be checked.

**Opportunity ledger.** The role is weak on its own terms whatever your fit: three requests for money, a cheque or personal details (RR1, RR2, RR3), a hiring process run wholly in chat (RR4), an employer I couldn't establish (RR5) and no stated pay floor (RR6).

- **Hard gates:** none failed; unconfirmed: R1 (Pay of at least €30,000 a year); your other constraints (location, hours, contract type) were not given, so checks against them are unknown.
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would change this:** a written offer verifiable through the employer's own website, at least one live interview, no payment or cheque of any kind, and onboarding details entered only in the employer's own portal after that offer.

About your IBAN: don't paste it anywhere in that chat. I won't repeat it. Your passport and PPS number aren't needed for this assessment either.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Velloway Logistics: no website, careers page or other attributable result found, so the employer is not established | `[grounded]` two searches, both empty |
| Role | Remote order processing coordinator, 15–30 hours a week, "set your own hours" | `[grounded]` posting |
| Pay as posted | "Up to €26 an hour plus commission"; no floor, no commission formula | `[grounded]` posting |
| What the posted figure buys | At the €26 ceiling, 15 hours is about €20,280 a year and 30 hours about €40,560; reaching €30,000 needs about 22 hours a week at the ceiling, with the rate and the hours both unguaranteed | `[inferred]` arithmetic on the posting's figures |
| Hiring process | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | `[grounded]` posting |
| Market calibration | Salaried order-processing and customer-operations coordinators in Ireland: median base €31,200, middle half €28,400 to €34,100; the guide excludes commission-only and freelance work, so it is a band to expect, never this employer's offer | `[generic]` Pennoral 2026 Ireland Customer Operations Pay Guide, from a search result snippet |
| Unknowns | Who the employer is; guaranteed hourly rate and minimum hours; commission basis; contract type | — |
| Contradictions | None checkable: no official page was found to compare the posting against | `[grounded]` searches returned nothing |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay of at least €30,000 a year (your constraint) | hard_gate | unclear | high | hard_gate | Confidence grades your constraint, which you stated. Fit is `unclear` because the posting gives only a ceiling ("up to €26 an hour") and variable hours | `[grounded]` your stated constraint and the posting; `[inferred]` arithmetic | RR6's question; Q3 |
| R2 | Strong attention to detail | must_have | adjacent | low | discovery | Keeping a weekly team tracker and working about 60 tickets a day is detail work, but you gave no accuracy or error measure | `[inferred]` from the tracker and ticket volume you described | see G1 |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep the team's weekly tracker in Excel; no file to inspect, so `medium` | `[grounded]` your statement | none |
| R4 | Good written English | must_have | adjacent | medium | discovery | Zendesk ticket work is usually written, but you haven't said your replies were | `[inferred]` from the Zendesk work; `[generic]` that ticket tools are written channels | see G2 |
| R5 | Processing customer orders (the posted responsibility) | must_have | adjacent | medium | transferability | Courier customer service touches orders and deliveries; processing orders as a job is not something you've described | `[inferred]` from your courier role | see G3 |
| R6 | A quiet place to work | important | unclear | low | discovery | Only you can say; the CV is silent | `[grounded]` CV silence | none until you say |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Attention to detail (R2, must_have) | discovery | Tracker upkeep and high ticket volume, no accuracy measure | Would move R2 toward `direct` on a real opening | Error checks, audits or corrections you made | A quality score or a tracker excerpt with no private data | `[inferred]` from what you described |
| G2 | Written English (R4, must_have) | discovery | Zendesk work whose written content isn't stated | The cheapest row to confirm | Written replies, macros or guidance you wrote for the two new starters | A sanitized sample reply | `[inferred]` from the Zendesk work |
| G3 | Order processing (R5, must_have) | transferability | Parcel customer service, no order-entry work stated | Applies to any real openings of this kind | Changing, cancelling or checking delivery orders in a system | A process note you followed or wrote | `[inferred]` from your courier role |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Asked to pay for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages" | Money sent by bank transfer is hard to get back, and a promised refund is only a promise. Who sent this is unresolved | `[generic]` pattern for requests like this; employers don't ask applicants to pay for equipment | Do you require new hires to pay for equipment before they start, and through whom? Ask through contact details you find on the employer's own website, never the chat or the email in these messages; I found no website | confirmed |
| RR2 | Asked to deposit a cheque and forward money | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner" | A cheque can show as credited before it clears and later be returned, leaving the money you forwarded as yours to repay. This request is very likely a scam. Don't deposit the cheque. | `[generic]` pattern for requests like this | As RR1: do you ever send new hires a cheque and ask them to pass part of it on? | confirmed |
| RR3 | Asked for bank, tax and ID details before any offer | red_flag | high | "send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up" | Those details, once sent, can't be taken back and can be used to open accounts or apply for credit in your name. Who sent this is unresolved | `[generic]` pattern for requests like this | As RR1: when and where in your process do you collect these details, and in which portal? | confirmed |
| RR4 | Whole process run in chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | Nothing in the process lets you confirm who is hiring, and the offer arrived in the same chat. What this leaves open is who you are dealing with | `[generic]` pattern: a process wholly in chat gives no independent check | As RR1: can I speak to a named interviewer by phone or video before any offer? | confirmed |
| RR5 | Employer not established from attributable sources | risk_signal | medium | "Velloway Logistics" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR6 | Pay stated only as a ceiling | unknown | — | "Earn up to €26 an hour plus commission" | The guaranteed rate and weekly hours may sit well below what R1 needs | `[inferred]` from the posting's "up to" and the 15–30 hour range, against the `[generic]` band in role reality | What is the guaranteed hourly rate and minimum weekly hours, and how is commission calculated? | unresolved |

Hold off on the payment, the cheque deposit and sending your details, and go no further in the chat, until you have checked each request with the employer, through contact details on the employer's own website rather than the chat or the address these messages came from; who sent them is not yet confirmed.

I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Send nothing: no €349, no cheque deposit, no IBAN, PPS number or passport photo | see RR1, RR2, RR3 | `[grounded]` register | pending your approval |
| A2 | If a cheque arrives, don't lodge it; tell your bank what the message asked | A cheque can be credited provisionally and returned later | `[generic]` how cheque clearing works | pending your approval |
| A3 | Look for the firm on Ireland's company register and find its own website; contact it only through details found there | see RR5 | `[generic]` ordinary employer-checking step | pending your approval |
| A4 | Report the posting to the jobs site you found it on | Others may see it | `[generic]` | pending your approval |
| P1 | For real openings, lead with: "three years as a customer service agent at a parcel courier, about 60 tickets a day in Zendesk; trained two new starters; kept the team's weekly tracker in Excel" | Every clause is yours, from your own message | `[grounded]` your background | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics" and "Velloway Logistics careers order processing coordinator remote"; both returned no results, so the employer is not established. Moved RR5 and role reality's organization row |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator salary Ireland hourly", which returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide), read from the search snippet only. Moved the market calibration row and RR6 |
| 3. Hiring manager's public footprint | n/a | No hiring manager's name was given, so there was no query to form |

I can also write all of this up as a reusable `tuesday-dossier.md` if you'd like one.

**Upgrade menu**

- A link to a live posting or a careers page on the employer's own site → RR5 resolves or hardens.
- The guaranteed hourly rate and minimum weekly hours, from the employer's own channels → RR6 and R1 close.
- Your other constraints (location, hours, contract type) → the hard-gates line stops saying "not given".
- A deeper research pass on the employer (up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

1. (R3, R4, R5) Did your courier work include writing customer replies, and did you ever change or check orders in a system?
2. (R2) Did you track accuracy or error rates anywhere, such as ticket quality scores or tracker checks?
3. (R1) Does the €30,000 need to be before tax and from guaranteed pay, without commission?

Answer any, say "skip" on any, or ignore them; silence counts as skipping.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.