I'll read the skill's reference files first.
Reading is done. Next I'm running the budgeted research: Fernquay's site and careers page, a salary sweep for product designers in Ireland, and Ronan Kehoe's public professional footprint.
**Yes, take the call. Fernquay is established on its own About page, and your background fits. Status: `conditional_go`.**

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Hybrid, two days a week in Galway), R2 (Salary €52,000–€60,000 plus equity)
- `must_have` — direct: R3, R4, R5, R7 · adjacent: R6 (Discovery calls with school owners), R8 (Own the booking flow end to end)
- `important` — adjacent: R9 (First designer, no design peer)

R6 — usability sessions bridge to owner discovery calls, limit named; R8 — your checkout redesign is one part of a booking flow; R9 — you have always had design peers.

**Opportunity ledger.** The scope, pay band and named co-founder are clear (RR3, RR5). Against that, the posting isn't on the company's own pages I could reach (RR1), the equity terms are open (RR2), runway is unknown (RR4), and no one is named to review your design work (RR6).

- **Hard gates:** none failed; unconfirmed: R1 (Hybrid, two days a week in Galway), R2 (Salary €52,000–€60,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. The role is confirmed live through Fernquay's own channel (RR1).
  2. You confirm that the two Galway days and the pay meet your terms (R1, R2).
  3. You get the equity terms (RR2).
  4. The sole-designer gap is framed honestly as adjacent (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. Six people, Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle, funded by its customers | `[grounded]` fernquay.example/about |
| Posting live | I couldn't find it on Fernquay's own pages. The `/careers` address I tried (a guess, not a link you gave me) returned no page | `[grounded]` fetch result |
| Hiring manager | Ronan Kehoe is listed as co-founder and CEO, and was previously a product lead at a Galway travel-software company for five years. That is close to your travel-booking background | `[grounded]` search result snippet; the page itself was not opened |
| Your call partner | Saoirse Doyle is a named co-founder on the About page. Her CTO title isn't stated there | `[grounded]` About page |
| Scope read | You'd be the first designer, owning one product's booking flow, with two engineers and direct founder access | `[grounded]` JD |
| Working pattern | Two days a week in Galway, the rest flexible | `[grounded]` JD |
| Compensation | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` JD |
| Market calibration | A 2026 Irish survey puts product designers with 3 to 5 years at a median base of €57,000 (middle half €51,500–€62,000). The posted range sits inside that, and it is a market band, not Fernquay's offer | `[generic]` Tillerby survey (n=520), search snippet only |
| Unknowns | Equity terms, runway, who reviews design work, whether the role is listed anywhere official | — |
| Contradictions | None. The About page's sailing schools and Scotland go beyond the posting's kayak and surf, but they don't conflict with it | `[grounded]` JD against About page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week at the Galway office | hard_gate | unclear | low | hard_gate | You live in Galway, which suggests it works, but you haven't said the two office days are acceptable | `[grounded]` your move back to Galway; no constraint stated | Question R1, R2 |
| R2 | Salary €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | I don't know your pay floor, so I can't say whether the role meets it | `[grounded]` no constraint given | Question R1, R2 |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a travel-booking company, stated by you and not yet inspected | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" is stated, with no artifact seen | `[grounded]` your background | A Figma file or portfolio link would raise to `high` |
| R5 | You have run your own user research | must_have | direct | medium | none | Monthly usability sessions with customers, stated by you | `[grounded]` your background | A session plan or findings summary would raise to `high` |
| R6 | Research calls with school owners | must_have | adjacent | medium | transferability | Usability sessions with customers carry over. The limit is that talking to business owners about how they run their schools is a different setting | `[inferred]` from the posting's "research calls with school owners" against your usability sessions | G2 |
| R7 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your background | none |
| R8 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned a travel-booking checkout. The limit is that the checkout is one part of a booking flow | `[inferred]` from "end to end" against the checkout work | G3 |
| R9 | Be the first designer, with no design peer | important | adjacent | low | transferability | You owned the checkout redesign, but you have never been the only designer, so setting your own process and reviewing your own work is untested | `[inferred]`; the posting's "first designer" is `[grounded]` | G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Working as the sole designer (R9, important) | transferability | You owned a checkout redesign but always alongside other designers | The call is with two founders. Whether you can work without a design peer is a probable focus | A freelance or side project you designed alone; a period when you were the only designer on a feature; setting up a shared Figma library or review habit | A project link, a Figma library, a written process note | `[inferred]` bridge; `[generic]` that early-hire interviews probe this |
| G2 | Interviewing school owners (R6, must_have) | transferability | Usability sessions with customers, no discovery calls with business owners | The role's research is with owners, not end customers | Calls with travel operators, suppliers or partners; any interview where you learned how a business works rather than testing a screen | Interview guide, synthesis note, a decision it changed | `[inferred]` from your sessions against the posting |
| G3 | End-to-end booking flow (R8, must_have) | transferability | Checkout redesign only | "End to end" is broader than checkout | Work on search, availability, pricing, confirmation emails or cancellations | A flow diagram or before-and-after screens | `[inferred]` from the posting's "end to end" |

For G3 the bridge is the checkout redesign, since checkout is part of any booking flow. The limit is that it covers one stage, and a work sample or flow diagram would narrow it.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not found on Fernquay's own pages | unknown | — | "You would be our first designer" | A six-person company may hire through a job board or direct outreach, so the role may simply not be on its site | `[generic]` pattern for companies of this size, not a claim about this one | Is this role listed on your own site or on a job board, and who would I report to day to day? | unresolved |
| RR2 | Equity terms unstated | unknown | — | "0.5–1% equity" | The percentage means little without the vesting schedule, share class and what it is a percentage of | `[generic]` how equity offers work | What are the vesting terms and share class, and does the percentage refer to current fully diluted shares? | unresolved |
| RR3 | Salary stated and in market range | positive_signal | — | "€52,000–€60,000" | The pay band is disclosed and consistent with market | `[grounded]` JD; `[generic]` survey band | Is the range fixed, or does it move with experience? | noted |
| RR4 | Funded by customers; runway unknown | unknown | — | "funded by its customers" (About page) | A customer-funded company's ability to carry a new salary depends on its revenue, which isn't public | `[inferred]` from About page against the absence of revenue information | How does the current revenue support this hire, and what does the next year's plan assume? | unresolved |
| RR5 | Named reader, defined scope, informal tone | positive_signal | — | "own the booking flow end to end … work most closely with our co-founder, Ronan Kehoe" | The scope is concrete and a decision-maker is named | `[grounded]` JD | What would success look like in your first year? | noted |
| RR6 | No design reviewer named | unknown | — | "You would be our first designer" | With no design peer, your work may be reviewed only by founders and engineers | `[inferred]` from "first designer" | Who will review and challenge my design decisions day to day? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Take the call. Check the calendar invite arrived from an address on the same domain as Fernquay's website and carries the video link | Booking an interview by WhatsApp while sending the invite by email is routine, and it isn't a concern in itself | `[generic]` hiring practice; `[grounded]` Ronan's message says the invite is by email | pending your approval |
| P1 | Prepare to talk through the checkout redesign as a messy real project: what you owned, what the squad decided, what you'd change | The posting asks for "one messy real project", and they liked the case study. This keeps the claim to what you did | `[grounded]` JD and Ronan's message | pending your approval |
| P2 | For R6, describe your usability sessions as they were and name the difference from owner discovery calls | An honest limit reads stronger than a stretched claim | `[grounded]` R6 row | pending your approval |
| Q1 | Ask RR1, RR2, RR4 and RR6 verbatim on the call. Ask RR3 only if the pay range doesn't come up | The register doubles as call preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway", which returned "About Fernquay" (fernquay.example/about). Fetched fernquay.example/careers, which had no page, and fetched the About page. Moved role reality's organization, posting-live and contradictions rows, and RR1 |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland startup 3+ years", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Moved the market calibration row and RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe). Moved role reality's hiring-manager row and the framing in P1 |

I can save this as `tuesday-dossier.md` if you want a copy to keep.

## Upgrade menu

- Your pay floor and office-day limits → R1 and R2 close, and the hard-gates line becomes a firm yes or no.
- A Figma file, portfolio or findings summary → R4 and R5 can reach `high`.
- Any solo or owner-facing work (G1, G2) → R9 and R6 get a stronger bridge.
- A link to the live posting, or the recruiter's reply to RR1 → the posting question closes.
- A deeper research pass on Fernquay (customers, leadership history, any press; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

1. R1, R2 — What are your non-negotiables for this role: your pay floor, how many office days in Galway you'll accept, and anything else that would be a deal-breaker?
2. G1 — Have you ever carried design work with no other designer around, on a project, freelance job or a stretch at work? What did you own, and how did you know it worked?
3. G2 — Have you interviewed business owners, such as travel operators or suppliers, to understand how they work, rather than testing a screen? What did you learn, and what did it change?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.