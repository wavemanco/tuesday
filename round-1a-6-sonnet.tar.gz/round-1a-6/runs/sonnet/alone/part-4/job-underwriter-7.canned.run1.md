I'll read the reference files the skill requires before building the assessment.
I'm reading the last reference file, the research-tier rules, before I write the assessment.
# Job Underwriting Assessment: Community Staff Nurse, Band 5 at Calderbrook Community Health CIC

## Decision snapshot

**Yes, it's worth applying for, on three conditions. Status: `conditional_go`.** Your hard gates are met on your own statements (R1, R2). The open points are written records (R4), leg-ulcer care (R6) and a posting I couldn't confirm on the employer's site (RR1).

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3 · adjacent: R5 (Care of housebound adults in their homes) · unclear: R4 (Clear, timely written records)
- `important`: direct: R7, R9 · adjacent: R6 (Wound and leg-ulcer care) · unclear: R8 (Continence care), R10 (End-of-life visits), R11 (Care planning) · absent: R12 (Holding a small caseload of your own)
- `preferred`: absent: R13 (Doppler assessment for leg ulcers)

R5 is a credible bridge with its limit named. R6 is real for wounds but not evidenced for leg ulcers. R12 and R13 are gaps you've told me about, and the advert treats R13 as desirable and R12 as supported.

**Opportunity ledger.** The role looks well-formed. The pay is stated (RR3), and a pool car, senior support and a named contact are offered (RR4). Two things are unconfirmed: whether the posting is live on the employer's own site (RR1) and the working pattern (RR2).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown. R1 and R2 rest on your own statements and haven't been checked.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. Your answers to G1 show evidence for written records and care planning (R4, R11).
  2. The posting is confirmed on Calderbrook's own careers page (RR1).
  3. Leg-ulcer care is framed as adjacent wound care, not as leg-ulcer experience (R6).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015, 410 staff, four locality hubs | `[grounded]` About page, snippet read |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin administration, care planning, on an electronic patient record | `[grounded]` advert |
| Caseload and support | A small caseload of your own, supported by a senior community nurse | `[grounded]` advert |
| Pay and car | £31,050–£37,800 plus mileage; pool cars provided | `[grounded]` advert |
| Market calibration | A 2026 survey of Band 5 community staff nurses in England gives a median basic pay of £34,300 and an interquartile range of £32,400 to £36,600. The advertised range spans that interquartile range. Mileage was paid to 61% of respondents and 24% had a pool or lease car, so a pool car is not the norm | `[generic]` Wardround survey, snippet only; a pattern, not this employer's offer |
| Scope read | A conventionally scoped entry-level community post. The team lead is a district nurse of eleven years who has spoken on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work, so Doppler training is plausibly a topic she'd discuss | `[grounded]` forum speaker page, snippet; `[inferred]` that this makes training a safe topic to raise |
| First 90 days and first year | Not stated | `[grounded]` advert silent |
| Unknowns | Working pattern and rota, mileage rate, how large "small" is, who the senior nurse is, whether the posting is live on the employer's site | `[grounded]` advert silent |
| Contradictions | None found. The advert text was pasted, not fetched, so it was not compared with a live page | `[grounded]` careers fetch returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | You state active registration as a Registered Nurse (Adult), with revalidation due March 2028. This is stated and not checked, and nothing here can inspect the register | `[grounded]` your CV | You check your own NMC register entry before applying |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | You state a full UK licence, category B. The advert provides pool cars. Stated and not checked | `[grounded]` your CV | You check your own driving record on the government licence service |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward, which is well above one year | `[grounded]` your CV | none |
| R4 | Clear, timely written records | must_have | unclear | low | discovery | The CV is silent on documentation and on any electronic patient record. Ward work probably involved notes, but that is a pattern, not your evidence | `[grounded]` CV silence; `[generic]` that ward nursing involves documentation | G1 |
| R5 | Caring for housebound adults in their own homes | must_have | adjacent | medium | transferability | Eighteen months on a discharge-to-assess secondment, visiting patients at home in their first week after discharge. Limit: that is short-term post-discharge visiting, not a continuing caseload of housebound patients. Strengthener: an example of a return visit or a care plan | `[grounded]` your CV; `[inferred]` the limit, from the "first week" wording | Surface this in the CV, per E1 |
| R6 | Wound and leg-ulcer care | important | adjacent | medium | transferability | Wound care including pressure ulcers and surgical wounds is stated. Leg ulcers and compression therapy are not mentioned | `[grounded]` your CV | G2 |
| R7 | Catheter care | important | direct | medium | none | Catheter care is stated on the CV | `[grounded]` your CV | none |
| R8 | Continence care | important | unclear | low | discovery | Catheter care is stated, but continence care beyond catheters is not | `[grounded]` CV silence | G3 |
| R9 | Insulin administration | important | direct | medium | none | Insulin administration is stated on the CV | `[grounded]` your CV | none |
| R10 | End-of-life visits | important | unclear | low | discovery | The CV is silent. Acute medical wards often care for dying patients, but that is a pattern, not your history | `[grounded]` CV silence; `[generic]` the ward pattern | G3 |
| R11 | Care planning | important | unclear | low | discovery | The CV is silent on writing or updating care plans | `[grounded]` CV silence | G1 |
| R12 | Holding a small caseload of your own, with senior support | important | absent | none | capability | You told me you have never held your own caseload. The advert makes this a duty of the post, supported by a senior community nurse, and not an essential criterion. Carried as a minor risk | `[grounded]` your statement and the advert | Ask what the induction and support look like (RR3) |
| R13 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You told me you have never done one, and the advert lists it as desirable. Closure path: training on appointment | `[grounded]` your statement and the advert | Ask about Doppler training; the team lead has spoken on it |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Written records and care planning (R4 `must_have`, R11 `important`) | discovery | The CV is silent on documentation systems and care plans | R4 is an essential criterion, and the advert says all work is recorded on an electronic patient record | Notes on an electronic record system; discharge or care plans you wrote; documentation audits; handover notes | A sanitised care plan or audit result, or the name of the record system | `[grounded]` CV silence; `[generic]` that a recruiter screens essential criteria literally |
| G2 | Leg-ulcer care (R6 `important`) | transferability | Pressure-ulcer and surgical wound care are stated, and leg ulcers are not | This is the clinical core of the desirable Doppler skill, and its limit decides how R6 is framed | Compression bandaging; venous or leg-ulcer patients on the ward or on home visits; a tissue viability link-nurse role | Training record or competency sign-off | `[grounded]` CV; `[inferred]` that this narrows the R6 bridge |
| G3 | End-of-life visits and continence care (R10, R8 `important`) | discovery | Silent on both | Both are named duties of the post | Last days of life care or anticipatory medication; bladder and bowel care, pads, catheter troubleshooting | A reflective account, a competency list or a ward training record | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed on the employer's own site | unknown | — | "Community Staff Nurse, Band 5 — Calderbrook Community Health CIC, Halifax" | The organisation is established (RR sources above), but the careers page I tried returned no page. The address was my guess, so it may be the wrong URL or the post may be closed | `[inferred]` from the failed fetch; `[generic]` that adverts are often reposted after closing | Is this post still open, and what is its closing date? | unresolved |
| RR2 | Working pattern unstated | unknown | — | "district nursing team caring for housebound adults in their own homes" | The advert gives no hours, rota or weekend and evening pattern | `[grounded]` advert silent | What are the hours, and is there a weekend or evening rota? | unresolved |
| RR3 | Caseload size and support unspecified | risk_signal | low | "You will hold a small caseload of your own, supported by a senior community nurse" | You have never held a caseload, so the size of "small" and the structure of the support decide how manageable the first months are. Low because support is explicitly offered | `[inferred]` from the advert against your statement | How many patients is a new Band 5 expected to carry in the first three months, and who is the senior nurse? | unresolved |
| RR4 | Pay stated and support offered | positive_signal | — | "£31,050–£37,800 a year plus mileage"; "pool cars are provided"; "informal chat about the role" | Pay and a named contact are open, which is transparent for an advert of this kind | `[grounded]` advert; `[generic]` market band | What is the mileage rate? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | `resume_edits_pending_approval`: move the discharge-to-assess secondment to the top of the experience section, reading "Seconded 18 months to the discharge-to-assess team, visiting patients at home in their first week after discharge". This is based on your summary, as I haven't seen the CV document | R5 | `[grounded]` your summary | pending your approval |
| E2 | `resume_edits_pending_approval`: add a line under wound care saying "wound care including pressure ulcers and surgical wounds", and add leg-ulcer wording only if G2 confirms it | R6 | `[grounded]` your summary | pending your approval |
| P1 | Positioning for the informal chat, pending your approval: "On the acute ward I did wound care including pressure ulcers and surgical wounds, catheter care and insulin administration; for the last 18 months, on secondment, I've visited patients at home in their first week after discharge. I haven't done Doppler assessment or held my own caseload, so what training and support does the team give?" | R5, R12, R13 | `[grounded]` your summary | pending your approval |
| A1 | Call Rhiannon Mabbott for the informal chat before applying, and use RR1, RR2 and RR3's questions | RR1, RR2, RR3 | `[grounded]` advert | pending your approval |
| A2 | Check your own NMC register entry and driving record before submitting, as both are yours to check | R1, R2 | `[grounded]` rows R1, R2 | pending your approval |

## Evidence status

Verified: none yet. Your NMC registration (R1) and driving licence (R2) are stated, not checked. I haven't used your registration PIN or National Insurance number, and neither is needed, so you may want to remove the National Insurance number from anything you share.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about). Fetched calderbrookhealth.example/careers, which returned no page. Moved: the organisation row, and RR1's unconfirmed posting |
| 2. Role-family sweep | yes | Searched "community staff nurse district nursing Band 5 salary 2026/27 Agenda for Change pay scale", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved: the market calibration |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook Community Health", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Moved: the scope read and P1 |

## Dossier offer

If you'd like, I can write all of this into a `tuesday-dossier.md` file.

## Upgrade menu

- Your CV as a document would let me quote your wording and test E1 and E2 against it.
- A sanitised care plan, audit result or record-system name would raise R4 and R11.
- A leg-ulcer or compression competency sign-off would narrow R6.
- A link to the live posting, or the closing date, would close RR1.
- The mileage rate and rota would close RR2.
- A deeper pass on Calderbrook (public staff reports, leadership changes, recent news) costs up to 5 more searches and 2 more fetches. Say the word and it runs.

## Questions

G1 (R4, R11): Which electronic patient record systems have you written notes in, and have you written or updated care plans yourself? What did that look like?

G2 (R6): Have you done compression bandaging, or cared for patients with leg ulcers, on the ward or on home visits? What was your part?

G3 (R10, R8): Have you cared for patients at the end of life, or managed continence care beyond catheters? What was yours?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.