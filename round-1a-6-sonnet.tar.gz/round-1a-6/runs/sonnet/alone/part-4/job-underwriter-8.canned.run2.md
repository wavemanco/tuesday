I've finished reading the skill's rules. Next I'll check whether Velloway Logistics can be verified, then write the assessment.
**No — don't go ahead, and don't send anything yet.** The messages ask you to pay for equipment, lodge a cheque and hand over bank, tax and ID details, all before any written offer. Going only on what you've shared, this job is very likely a scam. It carries four severe red flags (RR1, RR2, RR3 and RR4), so the status is `no_go`.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Income of at least €30,000 a year)
- `must_have` — direct: R2, R3, R4 · unclear: R5 (A quiet place to work)

R1 — the posting's pay is a ceiling, not a guarantee; R5 — nothing stated yet.

**Opportunity ledger.** The requests for money, a cheque deposit, bank, tax and ID details, and a chat-only process are RR1, RR2, RR3 and RR4. The employer could not be established from here (RR5), and the pay is open-ended (RR6).

- **Hard gates:** none failed; unconfirmed: R1 (Income of at least €30,000 a year)
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`)
- **What would change this:** the facts would have to differ. The employer would need to be verified through its own website, with no payment, cheque or ID details asked before a written offer, and with interviews held somewhere other than chat. The offer would also need to state hours and pay in writing that meet R1.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Velloway Logistics, as named in the posting. A search for it and the role returned no results, so it is not established from here | `[grounded]` search returned nothing |
| Role | Remote Order Processing Coordinator; 15–30 hours a week, self-set; "up to €26 an hour plus commission"; no experience needed, training provided | `[grounded]` posting |
| Requirements | Attention to detail, spreadsheets, good written English, a quiet place to work | `[grounded]` posting |
| Hiring process | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | `[grounded]` posting |
| Pay against your floor | €26 × 30 hours × 52 weeks is about €40,560 at the ceiling. At 15 hours it is about €20,280. Reaching €30,000 at the top rate takes about 22 hours a week. The commission rate is not stated | `[inferred]` arithmetic on the posting's figures and your €30,000 floor |
| Market calibration | Salaried order-processing and customer-operations coordinators in Ireland: median base €31,200, interquartile range €28,400 to €34,100. The guide excludes commission-only and freelance work, so it is a pattern and not this employer's offer | `[generic]` Pennoral 2026 Ireland pay guide |
| Unknowns | Employer identity, guaranteed hours, commission rate, contract type, who the "equipment partner" is | — |
| Contradictions | The posting lists no cost to the applicant. The later messages ask for €349 and for part of a cheque to be forwarded | `[grounded]` posting against your messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Income of at least €30,000 a year (your constraint) | hard_gate | unclear | high | hard_gate | Confidence grades your own stated constraint. Fit is unclear because the posting gives only "up to €26" for 15–30 hours, with unquantified commission, so the floor is not shown to be met | `[grounded]` your constraint and the posting | see G1 |
| R2 | Strong attention to detail | must_have | direct | medium | none | About 60 tickets a day at a parcel courier, stated by you. No inspectable artifact yet | `[grounded]` your account | none |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel. No sample yet | `[grounded]` your account | none |
| R4 | Good written English | must_have | direct | medium | none | Zendesk ticket handling is written work. This is stated by you and no writing sample has been seen | `[grounded]` your account; `[inferred]` that the tickets were written English | none |
| R5 | A quiet place to work | must_have | unclear | none | discovery | You haven't said either way | `[grounded]` not stated | see G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay meeting your floor (R1, hard_gate) | hard_gate | "Up to €26", hours that vary, commission unquantified | Only a figure in writing can show the floor is met | Not an experience gap; a terms gap | Written guaranteed hours, hourly rate and commission rate from a verified employer | `[grounded]` posting wording |
| G2 | Quiet place to work (R5, must_have) | discovery | Not stated | A posting requirement you can answer yourself | Any suitable home working space | None needed | `[grounded]` your messages are silent on it |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Payment for equipment requested | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | A transfer, once sent, may not be recoverable, and the refund depends on the sender keeping a promise. This request is very likely a scam. Employers don't ask applicants to pay for equipment | `[generic]` how such requests work; `[grounded]` quote | Do you ask applicants to pay for equipment, and did this posting and these messages come from you? (Ask through contact details you find yourself on the employer's own website, never the chat or the email address in these messages.) | confirmed |
| RR2 | Cheque deposit requested | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." | A lodged cheque can be returned unpaid after the money first appears in the account, which would leave the roughly €2,500 you transferred as yours to cover. Don't deposit the cheque | `[generic]` how cheque returns work; `[grounded]` quote and arithmetic | As RR1: did you issue this cheque, and do you ask applicants to forward part of one? | confirmed |
| RR3 | Bank, tax and ID details requested before any offer | red_flag | high | "please send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up" | These details, once shared, can be used beyond this job. They were asked before the "interview" and before any written offer naming role and pay | `[generic]` how disclosed details can be used; `[grounded]` quote | As RR1: do you collect these details before a written offer, and where do you take them? | confirmed |
| RR4 | Hiring and offer run wholly by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." | The interview, the offer and the contact address (an address on a mail-service domain I can't tie to an employer) leave the employer's identity open | `[grounded]` posting and messages | As RR1: is this role hired wholly by chat, and where can I verify the offer? | confirmed |
| RR5 | Employer not established from attributable sources | risk_signal | medium | "Velloway Logistics" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for entities with no web footprint | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR6 | Pay open-ended and above the market band | risk_signal | low | "Earn up to €26 an hour plus commission on every order you process" | The ceiling is well above the salaried median, which is about €15 an hour on a 40-hour week. "Up to" and unquantified commission leave what is actually paid open. I rate this low, not medium, because the band covers salaried roles only | `[generic]` Pennoral band; `[inferred]` hourly equivalent | What are the guaranteed weekly hours and the commission rate per order, in writing? | unresolved |

Hold off on the payment, the cheque deposit and sending your details, and go no further in the chat, until you have checked each request with the employer, through contact details on the employer's own website rather than the chat or the address these messages came from; who sent them is not yet confirmed. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

Nothing here is final until you approve it, and that covers this advice as well as the table rows.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't paste the IBAN you have ready, and don't send a PPS number or passport photo. I don't need them for this assessment either | see RR3 | `[grounded]` RR3 | pending your approval |
| A2 | Make no €349 transfer, lodge no cheque, and make no onward transfer | see RR1, RR2 | `[grounded]` RR1, RR2 | pending your approval |
| A3 | Look for the employer on your own: its website, its careers page, a registered address | see RR5 | `[grounded]` RR5 | pending your approval |
| A4 | Report the posting to the jobs site where you found it | A route that doesn't require replying | `[generic]` jobs sites usually have a report option | pending your approval |
| A5 | If anything has been sent or lodged later, phone your bank at once on the number printed on your card | Speed matters once money moves | `[generic]` standard bank advice | pending your approval |
| A6 | Put your effort into salaried customer-operations roles. Your courier ticket work, trainer role and Excel tracker are directly relevant, and the band median sits near your €30,000 floor | see R2, R3, R4 and the market calibration row | `[generic]` Pennoral band; `[grounded]` your background | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics careers order processing coordinator": no results, so the employer is not established. Moved role reality's organization row and RR5 |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator salary Ireland hourly", which returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). Moved the market calibration row and RR6 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer and upgrade menu

I can save this as `tuesday-dossier.md` if you want a copy to keep.

- The posting's link, or any company website, registered number or address it showed → RR5 may close or deepen.
- Guaranteed hours, rate and commission in writing → R1 and RR6 close.
- The employer's contact details, found on its own website → RR1 to RR4 can be put to the employer.
- A deeper research pass on the employer (up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

RR5 — Did the original posting link to a company website, or show a registered company number or business address? Answer in text, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.