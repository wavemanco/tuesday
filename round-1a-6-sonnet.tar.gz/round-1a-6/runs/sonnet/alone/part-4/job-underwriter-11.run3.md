I'll read the reference files the skill points to before building the assessment.
Status: I've finished reading the skill's rules. Next I'm running a few searches to check that both employers exist, and I'll then write up both roles.
## Decision snapshot

**Duinvaart: yes, worth your time. Status: `conditional_go`.**
**Kroonhaven: no, not as the posting stands, because K2 and K4 (both `must_have`) are absent. Status: `no_go`.**

IDs starting with D are Duinvaart rows and IDs starting with K are Kroonhaven rows. Neither posting was checked against the employer's own site, because the search calls were refused. Both opportunity ledgers say so.

### Duinvaart Cold Chain, Operations Analyst

**Fit ledger.**

- `hard_gate`: unclear: D1 (Hybrid, three days a week in Rotterdam office)
- `must_have`: direct: D2, D3, D4, D5
- `important`: adjacent: D7 (Working with depot managers on route changes); unclear: D6 (Temperature compliance across refrigerated fleet)
- `preferred`: direct: D8

D6 (`none`): nothing yet shows temperature data; D7 (`medium`): close, limit named.

**Opportunity ledger.** The employer and posting are not established from here (DRR1) and the salary is withheld (DRR2). One entry runs the other way: the deliverables are concrete (DRR3).

- **Hard gates:** none failed; unconfirmed: D1 (Hybrid, three days a week in Rotterdam office); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the Rotterdam three-day pattern works for you (D1); (2) the employer and live posting verify (DRR1); (3) D6 is answered, either with real temperature or compliance exposure or with an honest adjacent bridge.

### Kroonhaven Foods, Supply Planner

**Fit ledger.**

- `hard_gate`: unclear: K1 (On-site in Utrecht)
- `must_have`: adjacent: K5 (Fluent Dutch); unclear: K3 (Advanced Excel); absent: K2 (3+ years supply or demand planning in FMCG), K4 (SAP IBP or similar planning system)
- `important`: adjacent: K7 (Running the weekly S&OP meeting); absent: K6 (Owning the 13-week supply plan)

K2, K4 and K6 are absent, and you've said you have never worked in planning; K7 (`medium`) is a real bridge, its limit named.

**Opportunity ledger.** The role itself is clearly scoped (KRR3). The employer is not established from here (KRR1) and the salary is withheld (KRR2). The `no_go` rests on fit, not on the opportunity.

- **Hard gates:** none failed; unconfirmed: K1 (On-site in Utrecht); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **What would have to differ:** evidence of planning work (K2, K6), exposure to a planning system (K4), and Dutch you would call fluent (K5).

## Role reality

| Role | Element | What it is | Provenance |
|---|---|---|---|
| Duinvaart | Organization | Duinvaart Cold Chain, Rotterdam, with a refrigerated fleet | `[grounded]` JD header |
| Duinvaart | Mandate | Track on-time delivery and temperature compliance, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` JD |
| Duinvaart | Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` JD |
| Duinvaart | Scope read | An analyst post: reporting plus stakeholder work, with no stated team or budget | `[inferred]` from the JD's verbs and its silence on both |
| Duinvaart | Market calibration | Not established. The salary and title-norm searches were refused, so there is no band, and the posting states no pay | `[grounded]` JD silence on pay |
| Duinvaart | Unknowns | Salary; whether you would build or inherit the dashboards; how temperature data is captured | — |
| Duinvaart | Contradictions | Not checkable. The JD could not be compared with the employer's own careers page | `[grounded]` no page read |
| Kroonhaven | Organization | Kroonhaven Foods, Utrecht, chilled ready-meals range | `[grounded]` JD header |
| Kroonhaven | Mandate | Own the 13-week supply plan, balance production capacity against forecast, run the weekly S&OP meeting | `[grounded]` JD |
| Kroonhaven | Working pattern | On-site in Utrecht | `[grounded]` JD |
| Kroonhaven | Scope read | A single-range planning post that owns the plan and its meeting, so it is an experienced-hire seat | `[inferred]` from "own" and "run" against the 3+ years requirement |
| Kroonhaven | Market calibration | Not established, for the same reason as above. The posting states no pay | `[grounded]` JD silence on pay |
| Kroonhaven | Unknowns | Salary; the planning system in use; who attends S&OP | — |
| Kroonhaven | Contradictions | Not checkable, as for Duinvaart | `[grounded]` no page read |

## Evidence map

Your background is typed prose, so it counts as self-report: `medium` is the ceiling on a first pass, and `Verified: none yet` applies.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| D1 | Hybrid, three days a week in Rotterdam office | hard_gate | unclear | none | hard_gate | You have not stated where you live or what commute you accept. You worked in Amsterdam, which says nothing about now | `[grounded]` your message, silent on constraints | Q1 |
| D2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier. A years requirement is not a gate | `[grounded]` your background | none |
| D3 | Strong SQL | must_have | direct | medium | none | "SQL ... daily" for four years. No artifact inspected yet | `[grounded]` your background | sanitized query sample would raise to `high` |
| D4 | Power BI or Tableau | must_have | direct | medium | none | Power BI daily, including the depot-manager dashboard | `[grounded]` your background | screenshot of a sanitized dashboard would raise to `high` |
| D5 | Track on-time delivery | must_have | direct | medium | none | You work with an on-time delivery dashboard that depot managers use. What you personally built or owned is not stated, so the verb stays "used" | `[grounded]` your background | none |
| D6 | Track temperature compliance across the refrigerated fleet | important | unclear | none | discovery | Nothing in your background mentions temperature, cold chain or compliance monitoring. Parcel carriers sometimes move chilled goods, so evidence may exist | `[grounded]` background silence; `[generic]` that parcel carriers can carry chilled parcels | Q2 |
| D7 | Work with depot managers on route changes | important | adjacent | medium | discovery | You ran the weekly route-performance review and depot managers use your dashboard. Whether the review produced route changes with them is not stated, so it reads downward | `[grounded]` your background | Q3 |
| D8 | Dutch | preferred | direct | medium | none | Conversational Dutch. The posting gives no level, so it is met on the stated terms | `[grounded]` your background and the JD's "a plus" | state "conversational" honestly |
| K1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | Five days on-site is implied. Your location and flexibility are not stated | `[grounded]` JD; your message silent | Q1 |
| K2 | 3+ years supply or demand planning in FMCG | must_have | absent | none | capability | You said you have never worked in planning, and a parcel carrier is not FMCG. Nothing adjacent turns up in what you gave me | `[grounded]` your statement | closure path in KG1 |
| K3 | Advanced Excel | must_have | unclear | none | discovery | Your tools are SQL and Power BI. Excel is not mentioned either way | `[grounded]` background silence | optional, see KG3 |
| K4 | SAP IBP or a similar planning system | must_have | absent | none | capability | SQL and Power BI are reporting tools, not planning systems. No planning-system use is stated | `[grounded]` background and your statement | closure path in KG1 |
| K5 | Fluent Dutch | must_have | adjacent | medium | transferability | You have conversational Dutch, below the "fluent" the posting asks for. Running S&OP in Dutch would test that | `[grounded]` your statement; `[generic]` that a meeting-leading role tests spoken fluency hardest | see KG2 |
| K6 | Own the 13-week supply plan and balance capacity against forecast | important | absent | none | capability | The core of the role, and the part you have not done | `[grounded]` your statement | closure path in KG1 |
| K7 | Run the weekly S&OP meeting | important | adjacent | medium | transferability | You ran a weekly route-performance review. It is a recurring cross-team operations meeting, but not one that decides supply against demand | `[grounded]` your background | see KG2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and commute (D1, K1; hard_gate) | hard_gate | Both postings tie you to an office. Nothing says whether that works for you | A failed gate caps the status however strong the fit is, and wording cannot fix it | — | Your own statement of where you will work from | `[grounded]` JD terms; your message silent |
| G2 | Temperature compliance (D6, important) | discovery | A strong on-time-delivery record and no mention of temperature or cold chain | It is half of Duinvaart's headline metric pair | Chilled or pharma parcels; SLA or compliance alerts you reported on; any temperature or exception data you queried | A sanitized report or query that touched exception or compliance data | `[grounded]` background silence; `[generic]` that this is half the role |
| G3 | Route changes with depot managers (D7, important) | discovery | The review exists and depot managers use your dashboard. A link between the review and actual route decisions is missing | The JD names this as a core interaction | Route changes agreed after a review; a depot manager who acted on your numbers | A review deck or meeting notes, sanitized | `[grounded]` background; `[inferred]` that a link likely exists |
| G4 | Planning experience (K2, K4, K6; must_have) | capability | You have confirmed no planning work, and no adjacent evidence appeared | Three rows rest on it. Wording cannot close it | A step toward it would be a planning-adjacent analyst post, a forecasting or S&OP-support role, or hands-on use of a planning tool | Evidence of any of those | `[grounded]` your statement; `[generic]` that closure takes a planning post, not CV wording |
| G5 | Dutch fluency and S&OP leadership (K5, K7) | transferability | Conversational Dutch; a weekly review you ran. Limit: neither has been shown to hold at planning-meeting level | Together they decide whether the bridge reads as credible or stretched | A Dutch-language meeting you led; a recognised Dutch-level certificate | The certificate, or an agenda from a meeting you ran | `[grounded]` your statement; `[inferred]` bridge derived from the review |
| G6 | Advanced Excel (K3, must_have) | discovery | No Excel evidence either way | It only matters if Kroonhaven stays in play | Pivot-heavy models, lookup-driven reports | A sanitized workbook | `[grounded]` background silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| DRR1 | Employer not established from attributable sources | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | The employer may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not be a live hiring employer. No search result could be read | `[generic]` pattern for employers that cannot be checked; not a claim about this one | Can you point me at this role on your own careers site, and say who I would interview with? | unresolved |
| DRR2 | Salary withheld | unknown | — | The posting states no salary | The pay may sit anywhere in the market range. Market band not established | `[inferred]` from the posting's silence | What salary is budgeted for this post? | unresolved |
| DRR3 | Deliverables are concrete | positive_signal | — | "build weekly dashboards in Power BI" | The scope is defined and measurable | `[grounded]` JD states it | Which dashboards exist already, and which would I build? | noted |
| KRR1 | Employer not established from attributable sources | risk_signal | medium | "Kroonhaven Foods, Utrecht" | Same possibilities as DRR1, none more likely than the others | `[generic]` pattern for employers that cannot be checked; not a claim about this one | Can you point me at this role on your own careers site, and say who I would interview with? | unresolved |
| KRR2 | Salary withheld | unknown | — | The posting states no salary | As DRR2 | `[inferred]` from the posting's silence | What salary is budgeted for this post? | unresolved |
| KRR3 | Mandate is explicit | positive_signal | — | "Own the 13-week supply plan" | The role has real ownership | `[grounded]` JD | Who signs off the 13-week plan today? | noted |

## Application plan

Everything in this plan is proposed, not final. The edit rows (`resume_edits_pending_approval`), the action rows and the prose below each need your approval.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Duinvaart CV line: "Used SQL and Power BI daily, including the on-time delivery dashboard that depot managers use". Keep "used" until you tell me whether you built or maintained it | see D3, D4, D5; the line traces to your own sentence | `[grounded]` your background | pending your approval |
| E2 | Duinvaart CV line: "Ran the weekly route-performance review" with no added outcome until G3 is answered | see D7 | `[grounded]` your background | pending your approval |
| E3 | State Dutch as "conversational" on any CV or form | see D8, K5; "fluent" would be a claim you can't back | `[grounded]` your statement | pending your approval |
| A1 | Check Duinvaart's live posting and employer on its own website before spending effort | see DRR1 | `[grounded]` DRR1 | pending your approval |
| A2 | Pass on Kroonhaven for now and look for postings that feed into planning | see K2, K4, K6, G4 | `[generic]` role-family pattern | pending your approval |
| A3 | If you apply to Kroonhaven anyway, ask KRR1, KRR2 and KRR3 verbatim and frame K7 as adjacent, never as S&OP ownership | the register travels with you | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches "Duinvaart Cold Chain Rotterdam" and "Kroonhaven Foods Utrecht" were refused. They would have moved the contradictions rows and DRR1/KRR1 |
| 2. Role-family sweep | unavailable | Searches "operations analyst logistics Rotterdam salary Netherlands" and "supply planner FMCG Netherlands salary S&OP" were refused. They would have moved the market calibration rows |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

Both roles are rated on the postings you pasted and your background. Only DRR1 and KRR1 are capped by the missing research.

I can save this as `tuesday-dossier.md` if you'd like to keep it or reuse it later.

## Upgrade menu

- Search access: it would check both employers and postings (DRR1, KRR1) and set a salary band against DRR2 and KRR2.
- Your CV: it would show whether D2 to D5 are presented well or buried, and could turn some `presentation` gaps into proposed edits.
- A sanitized SQL sample or dashboard screenshot: D3 and D4 to `high`.
- Anything on temperature or exception data: D6 closes or becomes a bridge.
- The hiring manager's name at either firm: it would sharpen the scope read and the plan's lead story.

## Questions

1. **D1 / K1:** Where would you be working from, and would three days a week in Rotterdam, or five in Utrecht, be workable?
2. **D6:** Have you ever worked with temperature, chilled-goods or compliance data at the carrier, even as one slice of what you reported on? What did you do with it?
3. **D7:** Did the weekly route-performance review lead to route changes, and what was your part in agreeing them with depot managers?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.