I'm reading the skill's remaining reference files (evidence conventions, risk rules, question rules). After that I'll run the research checks on Fernquay and write up the assessment.
## Decision snapshot

**Yes, it's worth taking the call, but on conditions. Status: `conditional_go`.** On "is it legit": I couldn't check Fernquay from here (web search was refused), so I can't establish the firm either way. Nothing in the posting or the WhatsApp message asks you for money, bank details, tax details or ID (RR7).

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Pay €52,000–€60,000)
- `must_have` — direct: R3, R4, R5, R6 · adjacent: R7 (Own the booking flow end to end)
- `important` — adjacent: R8 (Run research calls with school owners), R9 (You would be our first designer)

R7 — a credible bridge, ownership scope unconfirmed; R8 — usability sessions, not stated as with business owners; R9 — you have not been the only designer.

**Opportunity ledger.** The employer can't be established from here (RR1). Equity terms (RR2), what success looks like (RR4), runway (RR5) and a possible project exercise (RR6) are unknown. The pay range is stated openly (RR3), and the first step is a video call with two named people (RR7).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Pay €52,000–€60,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:**
  1. Fernquay and the role are confirmed on the company's own website or careers page, or by the company (RR1).
  2. Pay and equity terms meet your floor before you invest in any project exercise (R2, RR2, RR6).
  3. R7 is framed as your checkout redesign, not as end-to-end booking ownership.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: six people in Galway making booking software for sea-kayak and surf schools. Not independently confirmed | `[grounded]` posting; `[grounded]` you couldn't find much online |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship alongside two engineers, work most closely with co-founder Ronan Kehoe | `[grounded]` posting |
| Working pattern | Hybrid, two days a week in the Galway office | `[grounded]` posting |
| Pay | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting |
| First-year outcomes | Not stated | `[grounded]` posting silent |
| Scope read | A one-person design function covering flow design, research and delivery with a very small team | `[inferred]` from "first designer", "end to end" and a six-person headcount |
| Market calibration | Not run: the role-family search was refused, so there is no band to set the posting's figure against | `[grounded]` search refused |
| Unknowns | Form and terms of the equity; funding and runway; year-one success measures; whether a project exercise follows | `[grounded]` posting silent on each |
| Contradictions | None between the posting and the WhatsApp message: both name Ronan as co-founder at Fernquay. Not checked against the company's own pages | `[grounded]` the two texts you pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week in the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year, so the location term is met. You haven't said whether two fixed office days suit you; this is intake prose, so medium | `[grounded]` your message and the posting | none |
| R2 | Pay €52,000–€60,000 plus equity | hard_gate | unclear | none | hard_gate | You haven't given a salary floor, so I can't say whether the range meets it. Equity terms are in RR2 | `[grounded]` posting states the range; your floor not given | Question for R2 below |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company. Self-reported, nothing inspected | `[grounded]` your message | none |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" shows use, not strength. The checkout case study Ronan mentions would be the inspectable proof, but I haven't seen it | `[grounded]` your message | Share the case study or a Figma file to raise to `high` |
| R5 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers | `[grounded]` your message | none |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | Worked in a squad with four engineers | `[grounded]` your message | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned your company's checkout flow. Checkout is one stage of a booking flow, so this is a bridge. Whether you owned the steps around it isn't stated | `[grounded]` your message; `[inferred]` that checkout is a stage of a booking flow | Question G1 below |
| R8 | Run research calls with school owners | important | adjacent | medium | transferability | Your sessions were usability sessions with customers. Interviews with business owners aren't stated | `[grounded]` your message | Gap queue G2 |
| R9 | You would be our first designer | important | adjacent | medium | transferability | You have never been the only designer. You did own a redesign and a monthly research cadence inside a squad. First-designer posts usually leave one person to set up process and tooling | `[grounded]` your message; `[generic]` role-family pattern | Gap queue G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Booking flow ownership (R7, must_have) | transferability | A checkout redesign. Nothing on the steps before it (finding a trip, choosing a date, availability) or after it (confirmation, changes) | A `must_have` at `adjacent`; the interview will test its edges | Owning a redesign beyond one screen; deciding something across stages with engineers; changing a step upstream of checkout | The checkout case study; before/after flows | `[grounded]` your message; `[generic]` that interviews test the edge of the bridge |
| G2 | Research with business owners (R8, important) | transferability | Usability sessions with customers; nothing stated about interviewing operators or suppliers | Fernquay's customers are school owners, not consumers | Calls with the businesses listed on your platform; a partner or supplier interview; a discovery call that changed a decision | A research plan, session notes or a synthesis slide (sanitised) | `[grounded]` your message and the posting |
| G3 | Solo design ownership (R9, important) | transferability | Always inside a squad; no stated experience setting up process or tooling | The posting has no design peer to learn from | A component library or file structure you set up; a research cadence you started; a design decision made without a design lead | A file structure screenshot or a short note on what you started | `[grounded]` your message and the posting |
| G4 | Pay floor (R2, hard_gate) | hard_gate | Range stated; your floor not given | A gate I can't settle without it | Not applicable | Not applicable | `[grounded]` posting; your floor not given |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools." | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. None of these is likelier than the others | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | The equity may be options or shares; vesting, strike price and the share count behind the percentage aren't given | `[inferred]` from the posting's silence on terms | What form is the equity, on what vesting schedule, and what share of fully-diluted capital is 0.5–1% today? | unresolved |
| RR3 | Pay range stated openly | positive_signal | — | "Salary €52,000–€60,000" | You can check the range against your own floor before spending time. No market comparison was run | `[grounded]` posting | Is the range fixed, or does it move with experience within it? | noted |
| RR4 | Year-one outcomes not stated | unknown | — | "own the booking flow end to end" | The mandate is broad and the posting says nothing about how success is measured | `[inferred]` from the posting's silence | What should the booking flow have achieved twelve months in? | unresolved |
| RR5 | Funding and runway unstated | unknown | — | "We are six people in Galway" | A team of six may depend on funding or revenue that the posting doesn't describe | `[generic]` pattern for very small teams | Is Fernquay funded or revenue-funded, and how long is the current runway? | unresolved |
| RR6 | Possible project exercise | unknown | — | "we would rather see one messy real project than a polished deck" | A project exercise may follow; its length and whether it is paid aren't stated | `[inferred]` from the posting line | Will there be a project exercise, how long is it expected to take, and is it paid? | unresolved |
| RR7 | Named video interview, nothing asked of you | positive_signal | — | "a 45-minute video call with me and Saoirse, our CTO ... I have emailed you a calendar invite with the video link" | The first step is a conversation with two named people, not a payment or a data request | `[grounded]` the WhatsApp message you pasted | Who else would I meet after this call? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, check that the emailed invite comes from an address on the same domain as Fernquay's own website, and ask Ronan for the site and product link. Arranging a call over WhatsApp with an emailed invite is a routine step for a small company | See RR1, RR7 | `[generic]` how small companies often schedule | pending your approval |
| A2 | Ask the register's questions in the call, starting with RR1, RR2 and RR5 | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A3 | Lead with this line, built only from your own sentences: "At a Dublin travel-booking company I redesigned the checkout flow and ran monthly usability sessions with customers, working in a squad with four engineers." Say plainly that you haven't been the only designer | See R3–R6, R7, R9 | `[grounded]` your message | pending your approval |
| A4 | Have the checkout case study ready, and be ready to say what was yours and what was the squad's | See R4, R7, G1 | `[grounded]` posting and WhatsApp message mention the case study | pending your approval |
| A5 | Don't agree to any project exercise until you know its length and whether it's paid (RR6), and ask about pay and equity terms (R2, RR2) | See R2, RR2, RR6 | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were refused: "Fernquay booking software sea kayak surf schools Galway" and "Fernquay careers Product Designer Galway". It would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | One search was refused: "product designer salary Ireland startup first designer equity 2026". It would have moved the market calibration row and RR3 |
| 3. Hiring manager's public footprint | unavailable | One search was refused: "Ronan Kehoe Fernquay co-founder". It would have moved role reality's scope read and which story the plan leads with |

## Dossier offer and upgrade menu

I can write all this up as `tuesday-dossier.md` if you'd like.

- Permission to search, or a link to Fernquay's website or the original listing: reading a link you give me costs no search. This settles RR1, adds a market band for R2 and RR3, and covers Ronan's public professional footprint. The L1 budget has one search and two fetches left.
- The checkout case study or a Figma file: raises R4 and R7 toward `high` and settles G1.
- A sanitised research note on calls with operators or suppliers: moves R8.
- Your salary floor: closes R2.

## Questions

1. **RR1** — Where did you apply: Fernquay's own site, a jobs board, or through a contact?
2. **R2** — What is the lowest salary you would take for this role?
3. **G1** — In the checkout redesign, did you also own any step before or after checkout, and what was yours versus the squad's?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.