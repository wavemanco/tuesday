I'll read the skill's reference files before building the assessment.
# Job Underwriting Assessment: Remote Order Processing Coordinator, Velloway Logistics

## Decision snapshot

**Should you go ahead? No. Don't send anything or pay anything. RR1, RR2, RR3 and RR4 (each `severity: high`) are requests made in these messages, and together they make this `no_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Pay floor of €30,000 a year)
- `must_have`: direct: R3, R5 · adjacent: R2 (Order processing), R4 (Attention to detail)
- `important`: unclear: R6 (A quiet place to work)

R3, R5: your Excel tracker and written ticket work match directly; R2 (`medium`): a real bridge, its limit named; R1: the posted terms don't settle your floor.

**Opportunity ledger.** The messages ask for bank, tax and ID details before any offer (RR1), a €349 payment for equipment (RR2) and a cheque deposit with part of it sent on (RR3). The hiring also runs only through Telegram (RR4). This job is very likely a scam. Who sent these messages, and whether the employer named in the posting is involved, is not confirmed (RR5). The pay figure is well above the salaried norm I found (RR6).

- **Hard gates:** none failed; unconfirmed: R1 (Pay floor of €30,000 a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would change this:** a written offer naming the role and pay, from an employer you can verify on its own website. It would also need no payment, cheque or upfront bank, tax or ID details. Interviews would have to be held by call or video, not only in chat.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Velloway Logistics: a search for its official site and careers page returned nothing, so the employer is not established | `[grounded]` search returned no results |
| Role and terms | Remote, 15–30 hours a week, "up to €26 an hour plus commission", "no experience needed, full training provided" | `[grounded]` posting |
| Hiring process | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | `[grounded]` posting |
| Posting vs messages | The posting lists no equipment cost; the messages later ask for €349 for a laptop and headset | `[grounded]` posting and messages |
| Market calibration | The Ireland 2026 pay guide gives a median base of €31,200 a year for order processing and customer operations coordinators (interquartile range €28,400 to €34,100). It covers salaried roles only and excludes commission-only and freelance work, so the comparison is loose. | `[generic]` Pennoral 2026 Ireland Customer Operations Pay Guide; the guide is not a statement about this employer |
| Pay read | The €31,200 median is about €15 an hour over 2,080 working hours a year, so "up to €26" sits well above it | `[inferred]` from the guide's median and a full-time hours assumption |
| Unknowns | Who the employer is, contract type, whether hours are guaranteed, commission terms, who "payroll" and the "equipment partner" are | `[grounded]` none of these appear in the posting or messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay floor of €30,000 a year (your constraint) | hard_gate | unclear | high | hard_gate | Confidence grades your own stated floor. At the posting's top rate and top hours, 30 hours × 52 weeks × €26 is €40,560. At its lowest hours, 15 × 52 × €26 is €20,280, below your floor. "Up to" and "15–30" leave it unsettled. | `[grounded]` your stated floor and the posting's terms; `[inferred]` the arithmetic | Only a written offer stating hours and rate would settle it |
| R2 | Order processing (the role's core task) | must_have | adjacent | medium | transferability | You handled about 60 parcel-courier tickets a day. That is adjacent to order processing. Limit: you haven't described order entry or fulfilment work. | `[grounded]` your background; `[inferred]` that the title implies this task | Moot for now; a real posting would be matched to it |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel. It is specific but not inspectable by me. | `[grounded]` your background, self-reported | none |
| R4 | Strong attention to detail | must_have | adjacent | low | discovery | Ticket volume doesn't show accuracy. An error rate, QA score or audit result would. | `[grounded]` your background, no accuracy evidence given | See G2 |
| R5 | Good written English | must_have | direct | medium | none | Zendesk ticket handling is written work, and you trained two new starters. | `[grounded]` your background; `[inferred]` that Zendesk replies are written | none |
| R6 | A quiet place to work | important | unclear | none | discovery | Nothing in your message says either way. | `[grounded]` silence in your message | Only needed for a real role |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay floor against the posted terms (R1, hard_gate) | hard_gate | "Up to €26 an hour" and 15–30 hours do not settle €30,000 a year | A hard gate decides whether any real offer is workable | Not applicable; this is a term to confirm | A written offer stating guaranteed hours, rate and contract type | `[grounded]` posting terms |
| G2 | Accuracy evidence for attention to detail (R4, must_have) | discovery | Volume is stated, accuracy is not | Order work turns on accuracy; a real application would be probed on it | A QA score, a low error rate on tickets, a tracker you reconciled, a process fix you made | A QA report, a team-lead note, a tracker excerpt | `[grounded]` background gives volume only; `[generic]` that order roles probe accuracy |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Bank, tax and ID details requested before any offer | red_flag | high | "please send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up" | Details handed over before a written offer can't be taken back and could be used in your name | `[generic]` pattern of requests like this, not a claim about the sender | Do you ask applicants for bank, tax and ID details before a written offer? Please answer through contact details on your own website. | confirmed |
| RR2 | Payment for equipment requested | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages" | A bank transfer, once sent, is hard to recover, and the refund depends on a first wage that may never arrive | `[generic]` pattern of requests like this | See RR1: is this payment part of your hiring process? | confirmed |
| RR3 | Cheque deposit with part sent on | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner" | A cheque can be returned unpaid after your account shows the funds, leaving you responsible for money you already transferred out. This request is very likely a scam. Don't deposit the cheque. | `[generic]` pattern of requests like this | See RR1: is this cheque and transfer part of your hiring process? | confirmed |
| RR4 | Hiring run wholly in chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews"; later, "you passed the interview and the job is yours" | Nothing in the process lets you check who you are dealing with; the follow-up contact is a "postmail.example" address, not a company domain | `[grounded]` posting and messages; `[generic]` that chat-only hiring leaves identity unchecked | Can I have a call or video interview with someone named on your website? | confirmed |
| RR5 | Employer not established from attributable sources | risk_signal | medium | "Velloway Logistics" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. None of these is ranked as likely. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who I would be interviewing with? | unresolved |
| RR6 | Pay well above the salaried norm | risk_signal | medium | "Earn up to €26 an hour plus commission on every order you process" | "Up to €26" against a median near €15 an hour for salaried roles; the guide excludes commission and freelance work, so the gap may be partly structural | `[inferred]` from the posting's figure against the `[generic]` guide band | What is the guaranteed hourly rate, and what share is commission? | unresolved |

Hold off on the payment, the cheque deposit and sending your details, and go no further in the chat, until you have checked each request with the employer, through contact details on the employer's own website rather than the chat or the address these messages came from; who sent them is not yet confirmed. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't send your IBAN, PPS number or passport photo. I'm not using the IBAN you pasted, and I haven't repeated it. | See RR1; none of these is needed to apply | `[grounded]` RR1 | advice, your call |
| A2 | Don't pay the €349 and don't lodge the cheque | See RR2, RR3 | `[grounded]` RR2, RR3 | advice, your call |
| A3 | Stop replying in the chat. To check the employer, look for its own website and contact details independently. | See RR4, RR5 | `[grounded]` RR4, RR5 | advice, your call |
| A4 | Put your effort into openings with a posted salary and a stated interview step. Your background (ticket volume, trained two starters, Excel tracker) fits order-processing and customer-operations roles. | The Ireland guide's median for such roles is above your €30,000 floor | `[generic]` guide band; `[grounded]` R3, R5 | advice, your call |

I'm proposing no CV or outreach wording for this posting.

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics official website careers"; no results, so the employer is not established. This produced RR5 and the role-reality organization row. |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator Ireland salary per hour", which returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). This produced the market calibration and RR6. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |

Say the word and I'll save this as `tuesday-dossier.md`.

## Upgrade menu

- A link to the live posting on the jobs site, or an official careers page you find independently → RR5 could close, and the posting could be checked against the messages.
- A written offer stating employer name, hours and rate → R1 and RR6 settle.
- QA or accuracy evidence from your courier job → R4 strengthens, for roles that are real.
- A deeper research pass on the employer (up to 5 more searches and 2 more fetches). It can't change the `no_go`, but it can say more about RR5. Say the word and it runs.

## Question

Q1: Have you sent anything to this chat besides your answers to their questions (a document, a number, a payment)? If so, I can say what to do next. Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.