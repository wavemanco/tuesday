I'll read the skill's reference files before building the assessment.
# Job underwriting: Duinvaart Cold Chain and Kroonhaven Foods

Femi, I'm sorry about the layoff. My search permission was declined, so everything below comes from your two postings and your background as you typed it. I've marked what that means for each row.

## Decision snapshot

**Duinvaart, Operations Analyst: Yes, worth applying. Apply to this one first. A2, A3 and A4 (the must-haves) are `direct` · `conditional_go`.**

**Kroonhaven, Supply Planner: No, not a good use of your time as things stand. B2, B3 and B6 (must-haves) are `absent` · `no_go`.**

### Duinvaart (rows A)

**Fit ledger.**

- `hard_gate` — unclear: A1 (Hybrid, three days a week in Rotterdam office)
- `must_have` — direct: A2, A3, A4
- `important` — direct: A5 · adjacent: A7 (Work with depot managers on route changes) · unclear: A6 (Temperature compliance across the refrigerated fleet)
- `preferred` — adjacent: A8 (Dutch a plus)

A6 — temperature work not yet asked about; A7 — route-change role not stated; A8 — conversational Dutch, level named plainly.

**Opportunity ledger.** The employer is not established from here (RA1) and the pay is unstated (RA2). The tools and weekly deliverables are concrete (RA3).

- **Hard gates:** none failed; unconfirmed: A1 (Hybrid, three days a week in Rotterdam office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Rotterdam three days a week works for you — A1; (2) the posting is confirmed live on Duinvaart's own careers page — RA1; (3) temperature-compliance work is either confirmed from your history or carried openly as a limit — A6.

### Kroonhaven (rows B)

**Fit ledger.**

- `hard_gate` — unclear: B1 (On-site in Utrecht)
- `must_have` — adjacent: B4 (Run the weekly S&OP meeting), B7 (Fluent Dutch) · unclear: B5 (Advanced Excel) · absent: B2 (3+ years of supply or demand planning in FMCG), B3 (Own the 13-week supply plan), B6 (SAP IBP or a similar planning system)

B2, B3, B6 — no planning history, as you told me; B4, B7 — bridges with named limits.

**Opportunity ledger.** The employer is not established from here (RB1) and the pay is unstated (RB2). The mandate is clearly stated (RB3).

- **Hard gates:** none failed; unconfirmed: B1 (On-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** B2, B3 and B6 would each need evidence of planning work. Alternatively, Kroonhaven would have to say in writing that planning experience is flexible for this post. Neither is in what you've shared.

## Role reality

**Duinvaart**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam, with a refrigerated fleet | `[grounded]` posting header; existence not checked |
| Mandate | Track on-time delivery and temperature compliance, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` posting |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` posting |
| Scope read | An analyst post: 2+ years asked for, deliverables are dashboards and recommendations, no stated people or budget ownership | `[inferred]` from the 2+ years requirement against the task list |
| Market calibration | Not calibrated: the role-family search was refused, so no pay band is offered | `[grounded]` Research tier line below |
| Unknowns | Salary; contract type; how much Dutch the daily work needs; where the temperature data comes from | `[grounded]` posting silent |
| Contradictions | None visible in the pasted text; not compared against a careers page | `[grounded]` pasted posting only |

**Kroonhaven**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, Utrecht, chilled ready-meals range | `[grounded]` posting header; existence not checked |
| Mandate | Own the 13-week supply plan, balance production capacity against forecast, run the weekly S&OP meeting | `[grounded]` posting |
| Working pattern | On-site in Utrecht | `[grounded]` posting |
| Scope read | A mid-level planning post that owns a plan and chairs a recurring cross-functional meeting | `[inferred]` from 3+ years asked for and the "own" and "run" verbs |
| Market calibration | Not calibrated: the role-family search was refused | `[grounded]` Research tier line below |
| Unknowns | Salary; contract type; who owns the demand forecast; which planning system is in use | `[grounded]` posting silent |
| Contradictions | None visible in the pasted text | `[grounded]` pasted posting only |

## Evidence map

Your background was typed in and has no CV or artifact behind it yet. That caps confidence at `medium`, and I've graded your own statements on that basis.

**Duinvaart**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| A1 | Hybrid, three days a week in Rotterdam office | hard_gate | unclear | none | hard_gate | You haven't said where you live or whether this commute works. Working in Amsterdam is not a statement about it | `[grounded]` no constraint stated | Q1 below |
| A2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | 4 years as an operations analyst at a parcel carrier; self-reported, no artifact | `[grounded]` your background | none |
| A3 | Strong SQL | must_have | direct | medium | none | "SQL daily"; the strength is self-reported | `[grounded]` your background | A sanitized query or a described analysis would raise it |
| A4 | Power BI or Tableau | must_have | direct | medium | none | Power BI daily, including the on-time dashboard depot managers use. Whether you built or maintained it is not stated | `[grounded]` your background | A sanitized dashboard screenshot would raise it to high |
| A5 | Track on-time delivery and build weekly dashboards | important | direct | medium | none | Direct match on the on-time dashboard; the weekly cadence is not stated for your dashboard | `[grounded]` your background | none |
| A6 | Temperature compliance across a refrigerated fleet | important | unclear | low | discovery | Nothing you've said touches temperature or cold-chain data. Compliance-style KPI tracking may exist in your history | `[inferred]` possible adjacency from your KPI work; nothing confirmed | Q2 below |
| A7 | Work with depot managers on route changes | important | adjacent | medium | discovery | You ran the weekly route-performance review and depot managers use your dashboard. Whether reviews led to route changes, and your part in them, is not stated | `[grounded]` your background | Q3 below |
| A8 | Dutch a plus | preferred | adjacent | medium | none | Conversational Dutch against a preference only; state the level plainly | `[grounded]` your statement | none |

**Kroonhaven**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| B1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | No statement from you on location or commute | `[grounded]` no constraint stated | Q1 below |
| B2 | 3+ years of supply or demand planning in FMCG | must_have | absent | none | capability | You said you have never worked in planning. This is an experience requirement, not a gate, but it is also the core of the role | `[grounded]` your statement | Carry as a material risk; see the decision |
| B3 | Own the 13-week supply plan and balance capacity against forecast | must_have | absent | none | capability | Nothing in your background involves capacity-versus-forecast work | `[grounded]` your statement and background | Same as B2 |
| B4 | Run the weekly S&OP meeting | must_have | adjacent | medium | transferability | You ran a weekly route-performance review. Limit: S&OP is a demand-supply-finance planning forum, and nothing you've said covers that content | `[inferred]` bridge from your weekly review; the limit is `[generic]` knowledge of what S&OP covers | G5 in the queue |
| B5 | Advanced Excel | must_have | unclear | low | discovery | You've named SQL and Power BI, not Excel | `[grounded]` background silent | Not worth chasing unless B2 changes |
| B6 | SAP IBP or a similar planning system | must_have | absent | none | capability | A BI tool is not a planning system, and you've never worked in planning | `[grounded]` your statement | none |
| B7 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational Dutch is adjacent. Limit: chairing a meeting and owning a plan in Dutch needs more than conversational | `[grounded]` your statement; the limit is `[inferred]` from the requirement's wording | G6 in the queue |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Rotterdam three days a week (A1) | hard_gate | Nothing on where you live or your commute limits | A gate the inputs don't settle; it sits under the `conditional_go` | A stated home base and a maximum commute | None needed; your statement | `[grounded]` background silent |
| G2 | Temperature compliance (A6) | discovery | KPI tracking is stated, temperature or cold-chain data is not | An important responsibility in the first sentence of the post | Any service-level or threshold-compliance reporting; food, pharma or time-critical parcels; exception reports for late or damaged items | A sanitized compliance report or dashboard page | `[grounded]` background silent; `[generic]` that temperature compliance is a core cold-chain metric |
| G3 | Route changes with depot managers (A7) | discovery | A weekly review and a depot-facing dashboard, but no stated change that came out of them | Turns "adjacent" into a concrete story for the role | A route or schedule change the review prompted; a depot manager acting on your dashboard; a recommendation you made | A review deck or a before/after summary | `[grounded]` background silent on outcomes |
| G4 | On-site in Utrecht (B1) | hard_gate | Same as G1 for a second location | A gate the inputs don't settle | A stated home base and maximum commute | None needed | `[grounded]` background silent |
| G5 | S&OP meeting (B4) | transferability | The weekly review is a real bridge: you ran it, but its content was route performance | The nearest thing to direct evidence for Kroonhaven, though it doesn't offset B2, B3 and B6 | A review you chaired with several departments; a standing agenda you owned | The review's agenda or a sanitized summary | `[inferred]` bridge from the weekly review |
| G6 | Fluent Dutch (B7) | transferability | Conversational; no assessed level | The post asks for fluency in Dutch | A CEFR level from a course or test; work you've done in Dutch | A course certificate or a test result | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RA1 | Employer not established from attributable sources | risk_signal | medium | "Operations Analyst — Duinvaart Cold Chain, Rotterdam" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RA2 | Salary not stated | unknown | — | (No pay figure in the posting as pasted) | The figure may sit anywhere relative to the market; I can't calibrate it with no search | `[inferred]` from the posting's silence | What salary range is budgeted for this post? | unresolved |
| RA3 | Concrete tools and deliverables | positive_signal | — | "build weekly dashboards in Power BI" | The work is defined and matches what you do now | `[grounded]` posting states tool and cadence | What decisions do the weekly dashboards feed, and who reads them? | noted |
| RB1 | Employer not established from attributable sources | risk_signal | medium | "Supply Planner — Kroonhaven Foods, Utrecht" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RB2 | Salary not stated | unknown | — | (No pay figure in the posting as pasted) | Same as RA2 | `[inferred]` from the posting's silence | What salary range is budgeted for this post? | unresolved |
| RB3 | Clearly defined mandate | positive_signal | — | "Own the 13-week supply plan for our chilled ready-meals range" | Scope and ownership are explicit | `[grounded]` posting | Who owns the demand forecast that feeds the plan? | noted |

## Application plan

Everything in this plan, the wording and the advice alike, is proposed and pending your approval. Nothing is final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | `resume_edits_pending_approval`: put "SQL and Power BI daily" and "On-time delivery dashboard in Power BI, used by depot managers" at the top of the Duinvaart version, with "Ran the weekly route-performance review" beside it, and list Dutch as "conversational" | A2, A3, A4, A5, A7 | `[grounded]` your own sentences, each traced | pending your approval |
| E2 | Positioning for Duinvaart: lead with the dashboard and the weekly review with depot managers. Don't claim temperature or cold-chain experience unless G2 confirms it | A4, A5, A6, A7 | `[grounded]` rows A4, A5, A6, A7 | pending your approval |
| E3 | Confirm the posting is live on Duinvaart's own careers page before spending effort | RA1 | `[grounded]` RA1 | pending your approval |
| E4 | Ask RA2 and RA3 verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| E5 | If you apply to Kroonhaven anyway: verify the posting live (RB1), describe the weekly review as a bridge and not as S&OP, and say "conversational Dutch" | B4, B7, RB1 | `[grounded]` rows B4, B7 | pending your approval |
| E6 | Don't count on B2 being waived; experience requirements like this are often applied literally | B2 | `[generic]` hiring-screen pattern, not a claim about Kroonhaven | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Duinvaart Cold Chain Rotterdam" and "Kroonhaven Foods Utrecht"; both were refused. They would have settled RA1 and RB1 and checked the postings against the careers pages |
| 2. Role-family sweep | unavailable | Searched "operations analyst logistics Netherlands salary Rotterdam" and "supply planner FMCG Netherlands salary S&OP SAP IBP requirements"; both were refused. They would have given the market calibration rows and a pay check for RA2 and RB2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I can turn this into `tuesday-dossier.md` whenever you like.

## Upgrade menu

- Your CV, or a sanitized screenshot of the on-time dashboard → A2 to A5 move toward `high`, and any CV wording gets audited line by line.
- Your home base, commute limit and pay floor → A1 and B1 resolve with a confirmed constraint, and the pay rows RA2 and RB2 can be checked against your floor.
- Permission to search → RA1 and RB1 can be settled and the market bands filled in. After that, a deeper pass (up to 5 more searches and 2 more fetches) is available.
- A CEFR level or course certificate → B7 and A8 get an assessed level.
- A hiring manager's name → role reality's scope read and which story to lead with.

## Questions

Q1 (G1, G4) — Where are you based, and would three days a week in Rotterdam, or full on-site in Utrecht, work for you?

Q2 (G2) — Have you ever reported on temperature, service-level or other threshold-compliance data, for example for food, pharma or time-critical parcels? What was your part in it?

Q3 (G3) — Did any weekly route-performance review lead to a route change, and what did you own in it versus the depot managers?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.