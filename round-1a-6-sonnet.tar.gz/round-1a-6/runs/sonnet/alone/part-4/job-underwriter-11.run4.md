I'll read the reference files the skill points to before building the assessment.
## Decision snapshot

**Duinvaart Cold Chain: yes, worth your time. Status: `conditional_go`.**
**Kroonhaven Foods: no, not for this posting as written. KR2, KR3 and KR6 are must-haves that are absent on your own account. Status: `no_go`.**

IDs: `DR` rows are Duinvaart, `KR` rows are Kroonhaven, `RR` rows are the risk register.

**Duinvaart fit ledger**
- `hard_gate`: unclear: DR1 (Hybrid, three days in the Rotterdam office)
- `must_have`: direct: DR2, DR3, DR4
- `important`: direct: DR5a · adjacent: DR6 (Work with depot managers on route changes) · unclear: DR5b (Temperature compliance tracking)
- `preferred`: adjacent: DR7 (Dutch a plus)

DR5b: the cold-chain half of the job, still unconfirmed; DR6: a close match, with the limit being whether your reviews changed routes.

**Duinvaart opportunity ledger.** The mandate is concrete (RR3). Salary is withheld (RR2), and the employer is not yet established from any source (RR1).

- **Hard gates:** none failed; unconfirmed: DR1 (Hybrid, three days a week in the Rotterdam office); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) the posting and employer verify on Duinvaart's own careers page (RR1); (2) the Rotterdam commute works for you (DR1); (3) your temperature-compliance exposure is confirmed, or framed honestly as a gap (DR5b)

**Kroonhaven fit ledger**
- `hard_gate`: unclear: KR1 (On-site in Utrecht)
- `must_have`: adjacent: KR7 (Fluent Dutch) · absent: KR2 (3+ years FMCG planning), KR3 (Own the 13-week supply plan), KR6 (SAP IBP or similar system)
- `important`: adjacent: KR4 (Run the weekly S&OP meeting) · unclear: KR5 (Advanced Excel)

KR2, KR3, KR6: the planning core, absent on your own word; KR4: a credible bridge, its limit named.

**Kroonhaven opportunity ledger.** The scope is clearly stated (RR7). Salary is withheld (RR6), and the employer is not yet established (RR5).

- **Hard gates:** none failed; unconfirmed: KR1 (On-site in Utrecht); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **What would change this:** KR2, KR3 and KR6 would each need confirmed planning work, and KR7 would need to reach fluent. A loosened posting would also do it. None of that is in what you've told me.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| D · Organization | Duinvaart Cold Chain, Rotterdam; whether it exists as described is not established | `[grounded]` JD header; no research result |
| D · Mandate | Track on-time delivery and temperature compliance for a refrigerated fleet, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` JD |
| D · Working pattern | Hybrid, three office days a week in Rotterdam | `[grounded]` JD |
| D · Scope read | An ordinary analyst scope: one data domain, one tool, one stakeholder group. Nothing suggests bundled roles | `[inferred]` from the responsibilities list |
| D · First-year outcomes | Not stated | `[grounded]` JD silent |
| K · Organization | Kroonhaven Foods, Utrecht, chilled ready-meals; whether it exists as described is not established | `[grounded]` JD header; no research result |
| K · Mandate | Own the 13-week supply plan, balance production capacity against forecast, run the weekly S&OP meeting | `[grounded]` JD |
| K · Working pattern | On-site in Utrecht | `[grounded]` JD |
| K · Scope read | A planner-owner post: you hold the plan and chair the meeting, so you are not feeding someone else's plan | `[inferred]` from "Own" and "run" |
| Market calibration (both) | Not established. The salary and role-family searches were refused, and neither posting states pay, so there is no band to compare against | `[grounded]` JDs state no pay; searches refused |
| Unknowns (both) | Salary, team size and reporting line; for D, the data sources behind temperature compliance and how much Dutch the day-to-day needs; for K, whether "a similar planning system" would accept other tools | `[grounded]` JD silence |
| Contradictions | None visible within either posting. I had only the pasted text, so no cross-check was possible | `[grounded]` JDs as pasted |

## Evidence map

Your background is typed prose, so it counts as self-report at `medium` at most. Nothing has been inspected.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| DR1 | Hybrid, three days a week in the Rotterdam office | hard_gate | unclear | none | hard_gate | You gave no constraints and no home location, so whether this is met is unsettled. The confidence grades your statement of a constraint, and there is none yet | `[grounded]` posting term; no constraint stated | G1 |
| DR2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | 4 years as an operations analyst at a parcel carrier is a specific claim. It is capped at `medium` until something inspectable backs it. Years of experience is not a gate | `[grounded]` your background | Share the CV |
| DR3 | Strong SQL | must_have | direct | medium | none | "SQL daily" over 4 years, confirmed as stated, with no artifact inspected | `[grounded]` your background | Share the CV |
| DR4 | Power BI or Tableau; weekly dashboards | must_have | direct | medium | none | Power BI daily, including the on-time delivery dashboard your depot managers use. Whether you built it or maintained it is not stated, so I read it downward | `[grounded]` your background | Dashboard screenshot (sanitised) would raise to `high` |
| DR5a | Track on-time delivery | important | direct | medium | none | Your dashboard and weekly route-performance review are this work | `[grounded]` your background | none |
| DR5b | Track temperature compliance on a refrigerated fleet | important | unclear | low | discovery | Nothing in your background mentions temperature-controlled freight. A parcel carrier may have run some, so this is a lead and not a claim | `[inferred]` from the carrier context, unconfirmed | G2 |
| DR6 | Work with depot managers on route changes | important | adjacent | medium | discovery | You ran a weekly route-performance review and depot managers use your dashboard. Whether it led to route changes you worked on is not stated | `[grounded]` your background | G3 |
| DR7 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational Dutch is partial credit toward a "plus". The limit is that it is not working-level | `[grounded]` your statement | State it as conversational |
| KR1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | The posting is fully on-site, and no location or constraint was given | `[grounded]` posting term; no constraint stated | G1 |
| KR2 | 3+ years of supply or demand planning in FMCG | must_have | absent | none | capability | You said you have never worked in planning, and the parcel carrier is not FMCG. Years of experience is graded as fit, not as a gate | `[grounded]` your statement | G4 |
| KR3 | Own the 13-week supply plan, balancing capacity against forecast | must_have | absent | none | capability | No planning work was stated. Capacity-versus-volume analysis at the carrier may be a thread, but nothing says it exists | `[grounded]` your statement | G4 |
| KR4 | Run the weekly S&OP meeting | important | adjacent | medium | transferability | You ran a weekly route-performance review. The limit is that S&OP reconciles forward demand, supply and finance, which a look-back performance review does not | `[grounded]` your background; `[generic]` what S&OP covers | Name the limit honestly if you apply |
| KR5 | Advanced Excel | important | unclear | low | discovery | An analyst with daily SQL and Power BI likely uses Excel, but nothing states the level | `[inferred]` from your tool stack | Confirm if you apply |
| KR6 | SAP IBP or a similar planning system | must_have | absent | none | capability | SQL and Power BI are reporting tools, not planning systems | `[inferred]` from the tool types; `[grounded]` your statement | G4 |
| KR7 | Fluent Dutch | must_have | adjacent | medium | transferability | Your Dutch is conversational, which is below fluent. The role runs a weekly meeting, so a literal screen on this is a risk | `[grounded]` your statement; `[generic]` that "fluent" is often screened literally | Closure path in G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location terms (DR1, KR1; hard_gate) | hard_gate | No home location or commute limit given | Three office days in Rotterdam and five in Utrecht are different asks, and either could decide it | Where you live and what commute you would accept | none needed | `[grounded]` no constraint stated |
| G2 | Temperature compliance (DR5b; important) | discovery | Your background does not mention it | It is half of Duinvaart's headline responsibility | Temperature-controlled parcels or pharma shipments, cold-chain SLAs, excursion or breach reporting, a temperature field in a dashboard | A dashboard screenshot, an SLA report, a breach summary | `[grounded]` background silent; `[generic]` that this role family probes it |
| G3 | Route changes with depot managers (DR6; important) | discovery | Reviews are clear, outcomes are not | It would turn DR6 from adjacent to direct | A route or depot change that came out of your weekly review, your analysis behind it, who decided | A review deck or an action log (sanitised) | `[grounded]` background silent on outcomes |
| G4 | Planning core and Dutch (KR2, KR3, KR6, KR7; must_have) | capability | No planning work, no planning system, Dutch below fluent | It sinks this posting. A closure path would be a route into the field, not a way to answer this ad | A planning-adjacent analyst or demand-planning junior role at a food or FMCG company; formal Dutch study to a working level | Course certificate, or an SAP IBP or planning-tool course | `[generic]` typical entry routes into planning |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Duinvaart: employer not established from attributable sources | risk_signal | medium | "Operations Analyst — Duinvaart Cold Chain, Rotterdam" | The company may be too new or small for a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. No search could run, so no reason is ranked above another | `[generic]` pattern for employers of this kind, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Duinvaart: salary withheld | unknown | — | No pay stated anywhere in the posting | The figure may sit anywhere against the market; nothing here suggests it is low | `[grounded]` JD silent; no band was researched | What salary range is budgeted for this role? | unresolved |
| RR3 | Duinvaart: concrete mandate | positive_signal | — | "Track on-time delivery and temperature compliance... build weekly dashboards in Power BI" | The tasks, tools and stakeholders are named, so success is measurable | `[grounded]` JD | Where does the temperature data come from, and who owns its quality? | noted |
| RR5 | Kroonhaven: employer not established from attributable sources | risk_signal | medium | "Supply Planner — Kroonhaven Foods, Utrecht" | The same possibilities as RR1, none ranked above another, since no search could run | `[generic]` pattern for employers of this kind, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR6 | Kroonhaven: salary withheld | unknown | — | No pay stated anywhere in the posting | As RR2 | `[grounded]` JD silent | What salary range is budgeted for this role? | unresolved |
| RR7 | Kroonhaven: concrete ownership | positive_signal | — | "Own the 13-week supply plan... run the weekly S&OP meeting" | The role has clear scope and a clear cadence | `[grounded]` JD | What planning system does the team run today? | noted |

Entries RR1 and RR5 cap each posting at `conditional_go` until the employer verifies. For Kroonhaven that cap sits above the `no_go`, which stays.

## Application plan

All of this is proposed and pending your approval. That covers the edit table, the positioning rows and the advice in them.

`resume_edits_pending_approval`

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Verify the Duinvaart posting is live on its own careers page before investing effort | RR1 | `[grounded]` RR1 | pending your approval |
| E1 | CV line: "Operations analyst, 4 years, parcel carrier, Amsterdam: SQL and Power BI daily, including the on-time delivery dashboard our depot managers use; ran the weekly route-performance review." It adds no verb, number or scope beyond your sentence | DR2–DR6 | `[grounded]` your own sentences | pending your approval |
| P1 | Lead the Duinvaart application with the dashboard and the weekly review. State Dutch as conversational. Say nothing about temperature compliance unless G2 confirms it | DR4, DR6, DR7, DR5b | `[grounded]` your statements | pending your approval |
| Q1 | Ask RR1–RR3 verbatim in the loop | the register doubles as interview preparation | `[grounded]` register | pending your approval |
| K1 | If you apply to Kroonhaven anyway, claim no planning, FMCG, SAP IBP or fluent-Dutch experience. Present the weekly review as an adjacent bridge (KR4) and name its limit | KR2, KR3, KR6, KR7 | `[grounded]` the map rows | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches "Duinvaart Cold Chain Rotterdam" and "Kroonhaven Foods Utrecht chilled ready meals" were refused (permission not granted). It would have moved RR1, RR5 and the contradictions row |
| 2. Role-family sweep | unavailable | Searches "operations analyst logistics salary Rotterdam Netherlands" and "supply planner FMCG salary Netherlands SAP IBP requirements" were refused. It would have moved market calibration and RR2, RR6 |
| 3. Hiring manager's public footprint | n/a | No name was given |

If you want the posting-verification and salary checks to run, grant the search permission and I will re-run both targets.

I can write this up as a `tuesday-dossier.md` if you want to keep it.

## Upgrade menu

- Your CV, plus a sanitised dashboard screenshot → DR2–DR4 move toward `high`.
- An answer to G2 → DR5b resolves, which is the biggest remaining swing on Duinvaart.
- An answer to G3 → DR6 may move to `direct`.
- Your home location and commute limit → DR1 and KR1 close.
- Your salary floor → checks against RR2 and RR6 once pay is known.
- The role's posting link, or a recruiter's email domain → RR1 and RR5 can be checked.
- Search permission → targets 1 and 2 run. A deeper pass on both companies (up to 5 more searches and 2 more fetches) is available once, if you say the word.

## Questions

G1 — Where do you live, and what commute would you accept: three days a week to Rotterdam, or five days to Utrecht?

G2 — Did any freight you tracked at the carrier have temperature requirements, and did you report on breaches or delays against them?

G3 — Did your weekly route-performance review ever lead to a route or depot change, and what was your part in it versus the depot managers'?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.