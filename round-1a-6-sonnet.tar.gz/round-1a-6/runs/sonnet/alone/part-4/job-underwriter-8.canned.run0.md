I'll read the skill's reference files before building the assessment.
Checked the company and the pay level online (2 searches), and the assessment is below.

# Job Underwriting: Remote Order Processing Coordinator, Velloway Logistics

## Decision snapshot

**No, I wouldn't go ahead, and I wouldn't send anything. These messages ask you to pay €349, to lodge a cheque and pass most of it on, and to give bank, PPS and passport details before any offer (RR1, RR2, RR3 and RR4, each `severity: high`). Status: `no_go`. This job is very likely a scam.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Salary of at least €30,000 a year)
- `must_have`: direct: R4; adjacent: R3 (Strong attention to detail), R5 (Good written English)
- `preferred`: unclear: R6 (A quiet place to work)

R4 (`medium`): your spreadsheet work is stated in your own words, with no artifact yet; R1: the posting's "up to" rate and variable hours leave the pay unconfirmed.

**Opportunity ledger.** Paying for equipment (RR1), depositing a cheque and passing most of it on (RR2), handing over bank, PPS and passport details before any offer (RR3), and a hiring process run wholly in chat (RR4) are confirmed severe red flags. The employer could not be established from here (RR5). The contact address does not match any employer site I could find (RR6). The pay is a ceiling with no stated commission rate (RR7).

- **Hard gates:** none failed; unconfirmed: R1 (Salary of at least €30,000 a year); other constraints on location or schedule not given, so checks against them are unknown.
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would change this:** a written offer, checked with the employer through contact details on its own website, and none of RR1–RR4 being asked. Your €30,000 floor would also need to be confirmed against a stated rate and weekly hours (R1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics". A search for the company and this role returned no results, so the employer is not established | `[grounded]` search, no results |
| Role | Remote order processing coordinator, 15–30 hours a week, "up to €26 an hour plus commission", no experience needed | `[grounded]` posting as you pasted it |
| Pay arithmetic | At the top rate for 52 weeks, 15 hours is €20,280 a year and 30 hours is €40,560. Reaching €30,000 at the top rate takes about 22 hours a week. "Up to" means the actual rate may be lower, and the commission rate is not stated | `[grounded]` posting figures; the arithmetic is mine |
| Market calibration | A salaried pay guide puts order-processing and customer-operations coordinators in Ireland at a median of €31,200 a year (range €28,400 to €34,100). It excludes commission-only and freelance work, so it is not like-for-like with variable hours. Against that median, €26 an hour is well above the guide's hourly equivalent (about €15 over 2,080 hours) | `[generic]` Pennoral 2026 guide, a pattern and not this employer's offer; `[inferred]` hourly comparison |
| Hiring process | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | `[grounded]` posting quote |
| First-90-days outcomes | Not stated | `[grounded]` posting silent |
| Unknowns | Who the employer is; commission rate; whether you'd be an employee or self-employed; who interviewed you | `[grounded]` posting and messages silent |
| Contradictions | The posting mentions no equipment purchase, but the messages add a €349 "work kit". The cheque is for €2,850 and you would keep €350, which leaves €2,500 to send on, far more than the €349 first asked for | `[grounded]` posting against messages; the subtraction is mine |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay of at least €30,000 a year (your non-negotiable) | hard_gate | unclear | high | hard_gate | Confidence grades the constraint, which is yours and confirmed. Fit is unclear because the rate is a ceiling, hours span 15–30, and commission is unquantified. At 15 hours the top rate falls short | `[grounded]` your stated floor and the posting's figures | Needs a written rate and weekly hours, only after the employer is verified |
| R3 | Strong attention to detail | must_have | adjacent | medium | transferability | You keep your team's weekly tracker in Excel and handled about 60 tickets a day. That is a bridge, but it is not order processing | `[grounded]` your account; `[inferred]` bridge | None needed |
| R4 | Confident with spreadsheets | must_have | direct | medium | none | You maintain the team's weekly Excel tracker. It is self-reported, with no inspectable sample | `[grounded]` your account | A sanitized tracker sample would raise it to `high` |
| R5 | Good written English | must_have | adjacent | medium | transferability | Zendesk ticket work is written customer contact, and you trained two new starters. Neither shows written quality directly | `[grounded]` your account; `[inferred]` that ticket work is written | None needed |
| R6 | A quiet place to work | preferred | unclear | none | discovery | Nothing you've shared says either way | `[grounded]` silence | See G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay floor (R1, hard_gate) | hard_gate | A top rate of €26 an hour and 15–30 hours, with no minimum rate or guaranteed hours | A hard gate, but the red flags decide the status first | Not applicable: a pay term is not something your experience closes | A written offer from a verified employer stating rate, hours and commission | `[grounded]` posting terms |
| G2 | Quiet workspace (R6, preferred) | discovery | Not stated | A preferred requirement, so a minor point beside the register | A room or hours where you can work uninterrupted | Not needed | `[grounded]` silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | A transfer sent can't easily be got back, and a promised refund from the first wages doesn't change that. Employers don't ask new hires to pay for equipment up front | `[generic]` pattern of requests like this; not a claim about the sender | Asked of the employer through contact details on its own website, not Telegram or the email in the messages: "Do you ask new hires to pay an equipment partner before starting, and who is that partner?" | confirmed |
| RR2 | Cheque deposit, then passing money on | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." | A cheque can show as credited and later be returned unpaid, leaving the money you sent on as yours to cover. This request is very likely a scam. Don't deposit the cheque | `[generic]` how cheque clearing works and a known pattern; not a claim about the sender | Same route as RR1: "Do you pay new hires by sending a cheque and asking them to transfer part of it on?" | confirmed |
| RR3 | Bank, tax and ID details before any offer | red_flag | high | "Before your chat interview, please send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up." | These details, once sent, can't be taken back. At that point you had no written offer naming the role and pay | `[generic]` pattern; `[grounded]` the quote shows the stage | Same route as RR1: "Which portal at your own website do you use for payroll details, and when in hiring do you collect them?" | confirmed |
| RR4 | Hiring wholly by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." | No interviewer, interview or written contract that you could check against anything outside the chat | `[grounded]` the quote; `[generic]` that this leaves open who is on the other end | Same route as RR1: "Can I speak to someone on a call, and who would my manager be?" | confirmed |
| RR5 | Employer not established from attributable sources | risk_signal | medium | "Remote Order Processing Coordinator — Velloway Logistics" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR6 | Contact address does not match an employer site I could find | risk_signal | medium | "Any problems, email velloway.hr@postmail.example." | An address on a general mail domain rather than the employer's own gives no way to tie the message to the named employer. The sender's identity is unresolved | `[inferred]` from the address against the failed search | Which email address on your company's own domain can I confirm this offer with? | unresolved |
| RR7 | Pay stated as a ceiling, commission unquantified | unknown | — | "Earn up to €26 an hour plus commission on every order you process." | The usual rate may sit well below €26, and the commission may be small or conditional | `[inferred]` from "up to" and the silence on commission, against the `[generic]` band in role reality | What is the guaranteed hourly rate, and how is commission calculated and paid? | unresolved |

Hold off on the payment, the cheque deposit and sending your details, and go no further in the chat, until you have checked each request with the employer, through contact details on the employer's own website rather than the chat or the address these messages came from; who sent them is not yet confirmed.

I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't send your IBAN, PPS number or passport photo, don't pay the €349, and don't lodge the cheque if it arrives | See RR1, RR2, RR3 | `[grounded]` register | pending your approval |
| A2 | Look for the company's own website through a search of your own and use only contact details found there. If you can't find one, stop replying | See RR5, RR6 | `[grounded]` register | pending your approval |
| A3 | If a cheque arrives, tell your bank, and consider reporting it to the Garda | Banks and police take reports of this pattern | `[generic]` common guidance, not a claim about this sender | pending your approval |
| A4 | Put your effort into salaried customer-operations or order-processing roles posted on an employer's own site. The guide's median of €31,200 sits at your €30,000 floor, and your courier customer service, Zendesk volume, training of two new starters and Excel tracker are the evidence for them | See R3, R4, R5 and the role-reality band | `[generic]` band, which is not an offer; `[grounded]` your background | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: your account of three years at a parcel courier, about 60 tickets a day in Zendesk, training two new starters and keeping the weekly Excel tracker, all self-reported. Your IBAN, PPS number and passport are not needed for this analysis, and I haven't used or repeated them.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics careers order processing coordinator"; no results, so the employer is not established. Moved role reality's organization row and RR5 |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator hourly pay Ireland entry level", which returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). Moved market calibration and RR7 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

If you'd like a record of this, I can write it up as `tuesday-dossier.md`.

## Upgrade menu

- A link to the original jobs-site listing, or any company website or registration number it shows → RR5 and RR6 could close or harden.
- A written offer on an email address at the company's own domain, with rate, hours and contract type → R1 and RR7 close.
- A name for the person who interviewed you → the hiring-manager target could run.
- A deeper research pass on Velloway Logistics (up to 5 more searches and 2 more fetches) → fuller work on RR5. Say the word and it runs.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.