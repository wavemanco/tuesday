Reading the skill's reference files so I can vet the offer properly. Next I'll check what's public about Marrowgate, then give you the verdict.
# Job Underwriting Assessment: Payroll Administrator, Marrowgate Housing

## Decision snapshot

**Yes, this is routine. A written offer that names the role and pay, followed by a request for bank details, your PPS number and a passport scan through an onboarding portal, is a normal onboarding step. On what you've told me the job is worth accepting once three things check out. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Hybrid, two days a week in Limerick), R2 (Salary €38,000–€42,000), R3 (Right to work in Ireland)
- `must_have`: direct: R4, R6, R7, R9, R10 · adjacent: R8 (Monthly payroll for 240 staff) · unclear: R5 (Irish PAYE, PRSI and USC)
- `important`: unclear: R12 (Answering staff payroll queries) · absent: R11 (Pension changes)

R5 — Irish tax rules not yet confirmed for your hotel payroll; R11 — pension changes you haven't done yourself; R8 (`medium`) — a step up in headcount from your 90 staff.

**Opportunity ledger.** The offer matches the ad and came after two in-person interviews (RR1). The employer itself is unchecked because I couldn't run research (RR2). Who handles pension changes and who else is in the payroll function are both unstated (RR3, RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Hybrid, two days a week in Limerick), R2 (Salary €38,000–€42,000), R3 (Right to work in Ireland); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm R1, R2 and R3 work for you; (2) your hotel payroll was run under Irish PAYE, PRSI and USC (R5); (3) the employer and its onboarding portal address are checked against marrowgatehousing.ie before you enter anything (RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick | `[grounded]` JD header; existence not checked (RR2) |
| Mandate | Run monthly payroll for 240 staff; starters, leavers and pension changes; monthly payroll-to-ledger reconciliation; staff payroll queries | `[grounded]` JD |
| Offer terms | Permanent, €40,000, reporting to Declan Garvagh (Finance Manager), hybrid with two Limerick office days, reply within five working days | `[grounded]` offer email |
| Ad versus offer | Title, hybrid pattern, Limerick location and the €38,000–€42,000 band all agree with the offer. No contradiction found. | `[grounded]` JD and offer email |
| First-90-days outcomes | Not stated | `[grounded]` JD silent |
| Scope read | An end-to-end payroll post covering the run, changes and the ledger link. Whether you would be the only payroll person is not stated. | `[inferred]` from the responsibilities listed, against silence on team size |
| Market calibration | Not established. The salary search was refused, so the €40,000 can be compared only with the posting's own band, where it sits inside. | `[grounded]` JD band; no `[generic]` band available |
| Unknowns | Payroll software, team size, how pension changes are handled, probation and pension scheme terms | `[grounded]` none stated in JD or offer |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in Limerick office | hard_gate | unclear | none | hard_gate | You didn't state a location constraint. You attended two interviews in person, which says nothing about commuting twice a week. | `[grounded]` JD and offer; your constraints not given | Confirm it works for you (question in closing) |
| R2 | Salary €38,000–€42,000, offered €40,000 | hard_gate | unclear | none | hard_gate | The offer sits within the posting's band. Your own pay floor wasn't stated. | `[grounded]` JD and offer | Confirm €40,000 is acceptable |
| R3 | Right to work in Ireland (passport check) | hard_gate | unclear | none | hard_gate | The offer asks for a passport scan for a right-to-work check. Nothing you've said settles your status either way. | `[inferred]` requirement from the offer email; `[grounded]` your status not stated | Confirm you can pass the check |
| R4 | 2+ years running payroll | must_have | direct | medium | none | "3 years running fortnightly payroll for 90 staff at a hotel group" exceeds the minimum. Self-reported, nothing inspected. | `[grounded]` your account | A reference or payslip-run sample would raise to high |
| R5 | Working knowledge of Irish PAYE, PRSI, USC | must_have | unclear | low | discovery | You didn't say which country's tax rules the hotel payroll ran under. A 2024 Payroll Technician certificate doesn't settle it by itself. | `[grounded]` your account silent; `[inferred]` jurisdiction gap | See G1 |
| R6 | Strong Excel | must_have | direct | medium | none | "Excel daily, pivot tables and XLOOKUP" matches the requirement. | `[grounded]` your account | A sanitized workbook would raise to high |
| R7 | Payroll qualification or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024. The certificate itself wasn't inspected. | `[grounded]` your account | The certificate document would raise to high |
| R8 | Run the monthly payroll for 240 staff | must_have | adjacent | medium | transferability | You ran fortnightly payroll for 90 staff. The run mechanics carry over, but you haven't stated a monthly cycle or this headcount. | `[grounded]` your account; `[inferred]` bridge | See G3 |
| R9 | Process starters and leavers | must_have | direct | medium | none | You named starters and leavers as part of your hotel payroll work. | `[grounded]` your account | none |
| R10 | Reconcile payroll to the general ledger monthly | must_have | direct | medium | none | "The monthly payroll-to-ledger reconciliation" matches directly. | `[grounded]` your account | none |
| R11 | Process pension changes | important | absent | none | capability | "I've never done pension changes myself — my manager handled those." | `[grounded]` your account | See G2 |
| R12 | Answer staff payroll queries | important | unclear | low | discovery | Nothing in your background says whether you handled staff queries. | `[grounded]` your account silent | See G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Irish tax-rule knowledge (R5, must_have) | discovery | A hotel-group payroll and a 2024 certificate, with the jurisdiction unstated | It is a must-have row, and the answer could move it straight to `direct` | Filing returns or submissions to Irish Revenue; Irish payslips you produced | A sanitized payslip layout or the certificate's syllabus page | `[grounded]` your account |
| G2 | Pension changes (R11, important) | capability | You have not done them | The duty is listed in the ad | Any pension deduction or opt-in/opt-out processing you did without owning the change | Your manager's process notes, if shareable | `[grounded]` your account; closure: ask for handover and training (RR3) |
| G3 | Scale and cycle (R8, must_have) | transferability | 90 staff fortnightly against 240 staff monthly | A fair reading is that you have run payroll end to end at smaller scale | A monthly cycle, or a peak period with larger headcount | A reference confirming volumes | `[inferred]` bridge; limit: the headcount and monthly run are untested |
| G4 | Staff payroll queries (R12, important) | discovery | Silent in your background | Likely part of the day-to-day | Any employee-facing payroll contact | Not needed | `[grounded]` your account silent |
| G5 | Hard gates (R1, R2, R3) | hard_gate | None of your constraints were given | These are terms, not experience, and the status can't clear without them | Not applicable | Not applicable | `[grounded]` your account silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Offer consistent with the ad and the process | positive_signal | — | "permanent post of Payroll Administrator at €40,000 a year ... two days a week in our Limerick office" | The terms match the ad and came after two in-person interviews, so the process ran through the employer and not by chat | `[grounded]` ad, offer and your account | Can you send the written contract, including probation and pension scheme, before I give notice? | noted |
| RR2 | Employer not established from attributable sources | risk_signal | medium | "a housing association in Limerick" | The search didn't run, so this is unchecked, not contradicted. An entity may be small, the posting may be stale, or it may not represent a real hiring employer, and none is ranked as likelier. | `[generic]` pattern for any employer not looked up, not a claim about this one | Can you confirm the web address of the onboarding portal and that your website links to it? | unresolved |
| RR3 | Pension changes unowned by you; handover unstated | unknown | — | "process starters, leavers and pension changes" | The duty is listed while you haven't done it, and the ad is silent on training | `[inferred]` from the JD against your account | Who handles pension changes today, and what training would I get on them? | unresolved |
| RR4 | Team size and tools unstated | unknown | — | "Run the monthly payroll for our 240 staff" | The ad doesn't say whether this is a sole post or part of a team, or which software is used | `[inferred]` from the JD's silence | Who else works on payroll, and which system do you use? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Treat the details request as routine, with one safeguard: reach the portal only through the address on marrowgatehousing.ie, or confirm it with the People Team using contact details from that site. Send nothing by email reply. | Your caution is right before an offer or from an unknown sender. Here the request follows a written offer after two in-person interviews. | `[grounded]` offer email and your account; `[generic]` onboarding pattern | pending your approval |
| A2 | Ask for the written contract or terms before you give notice at your current job | The email isn't the contract, and notice is hard to reverse | `[generic]` how offers usually work | pending your approval |
| A3 | Raise pension changes openly in the first conversation, in your own words: "I haven't processed pension changes myself; my manager handled those." Ask what handover covers (RR3). | Honest and traceable to your own sentence; it lets them plan training | `[grounded]` your account | pending your approval |
| A4 | Describe your payroll experience with its real figures attached: fortnightly payroll for 90 staff, never "payroll for 240" | Keeps the scale claim exactly as you gave it | `[grounded]` your account | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search "Marrowgate Housing Limerick housing association" was refused. It would have confirmed the employer, the live posting and the portal address (RR2, Role reality) |
| 2. Role-family sweep | unavailable | Search "Payroll Administrator salary Ireland Limerick 2026 payroll salary guide" was refused. It would have set a `[generic]` band for the market calibration line |
| 3. Hiring manager's public footprint | unavailable | Search "Declan Garvagh Finance Manager Marrowgate Housing" was refused. It would have informed the scope read and how to position yourself with Declan |

I can build a `tuesday-dossier.md` from this whenever you want it.

## Upgrade menu

- Search permission, so I can check the employer, salary band and Declan's public professional background → clears RR2, fills market calibration, informs A3.
- Your Payroll Technician certificate or a sanitized payslip layout → R5 and R7 toward `high`.
- A sanitized Excel sample → R6 toward `high`.
- Answers to the questions below → R1 to R3 and R5 settle, and the decision likely moves to `go`.
- A deeper research pass on Marrowgate (up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

1. (G5, R1–R3) Is there anything in the offer that's a problem for you: the €40,000, the two Limerick office days, or the right-to-work check?
2. (G1, R5) Was your hotel group's payroll run under Irish PAYE, PRSI and USC?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.