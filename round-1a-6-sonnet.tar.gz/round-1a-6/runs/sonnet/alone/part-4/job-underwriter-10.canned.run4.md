I'll read the skill's reference files first.
I've finished reading the underwriting rules. Next I'm checking whether Fernquay exists as described, what pay is normal for this role, and Ronan Kehoe's public professional background.
# Job underwriting: Product Designer at Fernquay

## Decision snapshot

**Yes, it's worth taking the call, and Fernquay checks out as a real company with a live posting (RR1). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Salary and equity terms)
- `must_have` — direct: R3, R4, R5, R6 · adjacent: R7 (Own the booking flow end to end)
- `important` — adjacent: R8 (Working as first and only designer) · unclear: R9 (Research calls with school owners)

R7 — checkout is a credible bridge to the whole flow, with its limit named; R8 — the first-designer seat is the real stretch.

**Opportunity ledger.** The employer and posting verify, and the pay is stated and in range (RR1, RR2). Three things are unestablished: how much decision authority the role carries (RR3), the equity terms (RR4), and how the company is funded (RR5). The WhatsApp contact is routine scheduling and gets no register entry (see A1).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the pay and equity meet your own floor — R2, RR4; (2) the call shows what design decides alone versus with Ronan — RR3; (3) the solo-designer gap is stated plainly and never papered over — R8.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. Six people in Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle, funded by its customers | `[grounded]` Fernquay "About" page, seen as a search result |
| Posting | The careers page is live and matches what you pasted: first design hire, hybrid with two days a week in Galway, €52,000–€60,000 plus equity, apply with one real project | `[grounded]` careers page, fetched |
| Mandate | Own the booking flow end to end, run research calls with school owners, ship alongside two engineers, work most closely with Ronan | `[grounded]` posting |
| First-90-days and first-year outcomes | Not stated | `[grounded]` posting silent |
| Hiring manager | Ronan Kehoe is co-founder and CEO; before Fernquay he was product lead at a Galway travel-software company for five years | `[grounded]` public profile, seen as a search result |
| Scope read | A wide remit for one person: the full booking flow plus owner research, beside a CEO co-founder and two engineers, with no design peer | `[inferred]` from "first designer", "end to end" and the six-person team |
| Market calibration | €52,000–€60,000 sits inside the range for 3 to 5 years of product design in Ireland (median €57,000, interquartile range €51,500–€62,000). That is a pattern, not this employer's offer. Scope norms for a first designer were not searched | `[generic]` Irish design salary survey; `[grounded]` posting for the band |
| Unknowns | Decision rights; equity terms; runway; first-year outcomes | — |
| Contradictions | None between the posting you pasted and the careers page | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week at the Galway office (hybrid) | hard_gate | direct | medium | none | You say you moved back to Galway last year. Willingness to commit two fixed days is not stated, only your location | `[grounded]` your intake message | none |
| R2 | Salary €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | The posting states the terms, but you gave no salary floor or other non-negotiables, so the gate can't be checked | `[grounded]` posting; your floor not given | Ask for your floor (question R2) |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company, self-reported and not yet inspected | `[grounded]` your intake message | none |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" is stated. No portfolio file has been seen | `[grounded]` your intake message | Share the case study to raise it |
| R5 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers | `[grounded]` your intake message | none |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your intake message | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | discovery | You redesigned your company's checkout flow, which is one stage of a booking flow. What you owned versus the team, and whether your remit reached beyond checkout, is not stated | `[grounded]` your intake message; `[inferred]` that checkout is one stage of the flow | See G1 |
| R8 | Work as first and only designer (inferred from "first designer") | important | adjacent | medium | transferability | You have never been the only designer, so the gap is stated plainly. Adjacent evidence: you redesigned checkout and ran research sessions in a squad. Limit: you have not set priorities or process with no design peer | `[grounded]` your intake message; `[inferred]` requirement from "first designer" | See G2 |
| R9 | Research calls with school owners | important | unclear | low | discovery | You ran usability sessions with customers. Whether they were consumers or business operators is not stated, and owner-operators of small seasonal schools may differ from either | `[grounded]` your intake message; `[generic]` that small-business owners often research differently from consumers | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Own the booking flow end to end (R7, must_have) | discovery | A checkout redesign, with ownership and scope beyond checkout not stated | It is the headline responsibility, and ownership of the whole flow decides how strong the bridge is | Steps before or after checkout that you shaped, such as search, selection, confirmation, changes or cancellations; decisions you made rather than recommended | The checkout case study, a flow map, a before-and-after | `[grounded]` your intake message; `[inferred]` that this is the likeliest probe |
| G2 | First and only designer (R8, important) | transferability | Squad design work with four engineers, never the sole designer | The role has no design peer, so this is the main stretch | Self-directed work, such as setting your own research cadence or deciding what to fix first | The real project the careers page asks for, showing decisions made without a design lead | `[grounded]` your intake message; `[inferred]` bridge and limit |
| G3 | Research with school owners (R9, important) | discovery | Customer usability sessions, participants unspecified | The posting makes owner research a named duty | Sessions with business customers or operators; recruiting participants yourself | A session guide, a research summary | `[grounded]` your intake message |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting verify | positive_signal | — | "Open now: Product Designer, our first design hire" (careers page) | The company is a real, small, hiring employer whose own pages match your posting | `[grounded]` careers and About pages | Who else would I meet after this call? | noted |
| RR2 | Pay stated and in range | positive_signal | — | "€52,000–€60,000 plus equity" | No seniority-pay mismatch: the band is within the range for your experience | `[grounded]` posting; `[generic]` survey range | Is the band negotiable within the range depending on experience? | noted |
| RR3 | Ownership of the flow, but decision rights unstated | unknown | — | "own the booking flow end to end" | Design may carry the outcome while final calls sit with the CEO you work most closely with | `[inferred]` from the ownership language against silence on decision rights | When you and I disagree on the booking flow, who decides, and what does design decide alone? | unresolved |
| RR4 | Equity terms unstated | unknown | — | "0.5–1% equity" | Vesting, strike price and share class could change what the equity is worth | `[generic]` equity value depends on those terms | What are the vesting schedule, strike price and share class, and what is the current share count? | unresolved |
| RR5 | Funding basis | unknown | — | "funded by its customers" (About page) | With no outside investment, hiring a first designer rests on current revenue and runway | `[inferred]` from the About page | How long is the runway, and is this role funded from current revenue? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Take the call. Scheduling by WhatsApp, with the video link in an emailed invite, is routine. As a simple check, confirm the invite comes from a fernquay.example address, the domain on their careers page | see RR1 | `[generic]` hiring practice; `[grounded]` careers page domain | pending your approval |
| A2 | Open by describing the checkout redesign in your own words and what you personally owned, since Ronan wrote that they liked it. Ronan also spent five years in travel software, so booking-flow detail will likely land with him | see R7, G1 | `[grounded]` his message and public profile | pending your approval |
| A3 | Say plainly: "I've worked in a squad with four engineers and haven't been the only designer." Then ask how design decisions get made | see R8, RR3 | `[grounded]` your intake message | pending your approval |
| A4 | Ask RR3, RR4 and RR5 verbatim | The register doubles as call preparation | `[grounded]` register | pending your approval |
| A5 | Bring one messy real project if asked. The posting says they would rather see that than a polished deck | see G2 | `[grounded]` posting | pending your approval |

No CV edits are proposed, because I haven't seen your CV. Rehearsal for the call is mock-interview's job, not this one's.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway" (result: "About Fernquay", fernquay.example/about) and "Fernquay product designer Galway careers"; fetched "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer). Moved the Organization and Contradictions rows. The employer is established, so no standing "employer not established" entry |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland first designer startup 3+ years" (result: "Tillerby 2026 Ireland Design Salary Report", tillerby.example/2026-ireland-design-salary-report). Moved the market calibration row and RR2 (pay only; scope norms for a first designer were not searched) |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder" (result: "Ronan Kehoe — Co-founder, Fernquay", linkedin.example/in/ronan-kehoe). Moved the hiring-manager row and A2 |

I can write all of this up as `tuesday-dossier.md` if you'd like to keep it.

## Upgrade menu

- Your CV or the checkout case study → R3 to R7 can reach `high`, and I can propose CV lines for your approval.
- Your salary floor and any other non-negotiables → R2 resolves and the hard-gates line becomes a real check.
- Their answers on equity terms → RR4 closes.
- A deeper research pass on Fernquay (customer and press mentions, funding and leadership history; up to 5 more searches and 2 more fetches) → RR5 firms up. Say the word and it runs.

R2 — What is the lowest base salary you would accept, and is there any other term (office days, equity, notice period) you would not trade?

G1 — In the checkout redesign, which parts did you own yourself, and did your remit reach beyond checkout, such as search, selection, or changes and cancellations?

G3 — Who took part in your monthly usability sessions (consumers booking trips, or business operators), and who recruited and ran them?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.