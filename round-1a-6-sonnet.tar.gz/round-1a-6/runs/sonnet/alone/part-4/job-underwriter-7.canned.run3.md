I'll read the reference files the skill points to before building the assessment.
Now the L1 research: the employer, the pay band, and the named team lead's public professional footprint.
## Decision snapshot

**Yes, this is worth applying for, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3 · adjacent: R5 (caring for housebound adults at home) · unclear: R4 (clear, timely written records)
- `important`: direct: R6, R8, R10 · adjacent: R13 (own small caseload) · unclear: R7 (leg-ulcer care), R9 (continence care beyond catheters), R11 (end-of-life visits), R12 (care planning)
- `preferred`: absent: R14 (Doppler assessment)

R5 and R13: real bridges, with their limits named. R14: absent, and the advert lists it as desirable. R4, R7, R9, R11 and R12: unclear because your CV is silent on them, which is different from the evidence saying no.

**Opportunity ledger.** The duties, support structure and pay are specific and look sound (RR2, RR3, RR4, RR6). Two things are open: I couldn't confirm the vacancy on Calderbrook's own site (RR1), and the advert leaves out terms such as contract basis and hours (RR5).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:**
  1. The vacancy is confirmed live through Calderbrook's own channels (RR1).
  2. Your records experience is established in your own words before the CV says anything about it (R4, G1).
  3. The caseload and Doppler limits are stated plainly, not papered over (R13, R14), and the terms the advert omits are checked against what you need (RR5).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC runs adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract. It was founded in 2015 and has 410 staff working from four locality hubs. | `[grounded]` "About Calderbrook Community Health" (calderbrookhealth.example/about) |
| Mandate | Join the district nursing team caring for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin administration and care planning, recorded on an electronic patient record. | `[grounded]` advert |
| Supervision | A small caseload of your own, supported by a senior community nurse. | `[grounded]` advert |
| Transport | Pool cars are provided and mileage is paid. | `[grounded]` advert |
| First 90 days / first year | Not stated. | `[grounded]` advert silent |
| Scope read | An ordinary supported community post: the caseload is small and supervised, and the essentials list asks for one year's experience. | `[inferred]` from the advert's "small caseload" and "supported by", against its one-year essential |
| Market calibration | The posted £31,050–£37,800 spans the survey's interquartile range (£32,400–£36,600) and brackets its median (£34,300). The survey covers community staff nurses, Band 5, in England (n=1,240). It is one survey, not the official pay scale, and it describes the market, not Calderbrook's offer. | `[grounded]` advert for the posted figure; `[generic]` "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide) for the band |
| Team lead's public footprint | Rhiannon Mabbott leads the Halifax district nursing team after eleven years as a district nurse. At the 2025 forum they spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work. | `[grounded]` speaker page, "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott) |
| Unknowns | Contract basis (permanent or fixed-term), hours and weekend or out-of-hours expectations, typical caseload size, whether Doppler training is provided, closing date. | `[grounded]` advert silent on each |
| Contradictions | None between the advert and the About page. The vacancy itself wasn't found on the employer's site at the address tried (RR1). | `[grounded]` fetch returned no page at calderbrookhealth.example/careers |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | You state active Adult registration, with revalidation due March 2028. That matches the gate. It is stated and I haven't checked it. | `[grounded]` CV | You check your own entry on the NMC register before applying |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | You state a full UK category B licence. That matches the gate, and pool cars are provided. Stated, not checked. | `[grounded]` CV | You check your own driving record is clean and current |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward. A staff nurse post follows registration, but your registration date isn't on the CV. | `[grounded]` CV; `[inferred]` that the staff nurse post is post-registration | none |
| R4 | Clear, timely written records, on an electronic patient record | must_have | unclear | low | discovery | The CV doesn't mention records or any record system. I won't assume them from the job title. | `[grounded]` CV silence | G1 question |
| R5 | Caring for housebound adults in their own homes | must_have | adjacent | medium | transferability | Eighteen months seconded to the discharge-to-assess team, visiting patients at home in their first week after discharge. Limit: that was short post-discharge work, and the advert describes ongoing care of housebound adults. | `[grounded]` CV and advert | See G5; strengthener is a secondment role description |
| R6 | Wound care | important | direct | medium | none | Wound care including pressure ulcers and surgical wounds. Leg ulcers are a separate wound type and are carried in R7. | `[grounded]` CV | none |
| R7 | Leg-ulcer care | important | unclear | low | discovery | The CV names pressure ulcers and surgical wounds, not leg ulcers. Other wound work is adjacent but isn't leg-ulcer care. | `[grounded]` CV silence | G2 question |
| R8 | Catheter care | important | direct | medium | none | Catheter care is stated on your CV. | `[grounded]` CV | none |
| R9 | Continence care beyond catheters | important | unclear | low | discovery | The CV is silent beyond catheter care. | `[grounded]` CV silence | See G4; no question this turn |
| R10 | Insulin administration | important | direct | medium | none | Insulin administration is stated on your CV. The advert pairs it with care planning, which is R12. | `[grounded]` CV | none |
| R11 | End-of-life visits | important | unclear | low | discovery | The CV is silent. Ward or home end-of-life work may exist but isn't stated. | `[grounded]` CV silence | G3 question |
| R12 | Care planning | important | unclear | low | discovery | The CV is silent on care planning. | `[grounded]` CV silence | See G4; no question this turn |
| R13 | A small caseload of your own, supported by a senior community nurse | important | adjacent | low | transferability | You say you've never held your own caseload. The adjacent evidence is home visiting in the discharge-to-assess work. Whether you visited on your own isn't stated, so I took the lower band. The advert frames the caseload as supported. | `[grounded]` your statement, CV and advert; `[inferred]` that home visiting is the adjacent work | Say it plainly (A2); G5 |
| R14 | Doppler assessment for leg ulcers (desirable) | preferred | absent | none | capability | You've never done a Doppler assessment. Closure path: ask whether the team trains new starters. Rhiannon Mabbott has spoken publicly on Doppler training for staff new to community work. That shows familiarity with the need, not that Calderbrook provides it. | `[grounded]` your statement and speaker page; `[inferred]` that training may be available | Ask in the informal chat (RR6) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Written records on an electronic patient record (R4, must_have) | discovery | The CV says nothing about records or systems. | It is an essential criterion, and it is the one `must_have` row at `unclear`. Closing it could remove a condition. | Writing up your own ward assessments and visits in an electronic system; documenting discharge-to-assess visits yourself; a records audit or a competency sign-off on documentation | An anonymised audit result, a competency record, or your secondment role description | `[grounded]` CV silence; `[inferred]` that closing it would simplify the decision |
| G2 | Leg-ulcer care (R7, important) | discovery | The CV names pressure ulcers and surgical wounds, not leg ulcers. | Leg-ulcer care is the first wound type the advert names. The team lead has spoken publicly on nurse-led leg-ulcer clinics. | Compression bandaging or reduced-compression dressings; assessing or dressing leg ulcers on the ward or on discharge visits | A wound-care competency record, a training certificate, or a ward competency list | `[grounded]` advert and speaker page; `[inferred]` that it is likely to be probed |
| G3 | End-of-life visits (R11, important) | discovery | The CV is silent. | The advert lists end-of-life visits as part of the day-to-day work. | Caring for patients in their last days on the ward; discharge visits for patients going home to die; anticipatory care or symptom-control work | A palliative care training record, or a reflective account you've already written | `[grounded]` advert and CV silence |
| G4 | Continence beyond catheters; care planning (R9, R12, important) | discovery | The CV is silent on both. | Both are duties in the advert. They are lower priority than G1 to G3, so I'm not asking about them this turn. | Continence assessments or bladder and bowel plans; writing or updating patient care plans on the ward or after discharge | A care-plan example with identifiers removed | `[grounded]` advert and CV silence |
| G5 | Bridge from home visiting to a supported caseload (R5, R13) | transferability | Adjacent: 18 months of discharge-to-assess home visiting. Limit: short post-discharge visits, with no ongoing caseload owned. Strengthener: the secondment role description, and a plain account of what you did alone on visits. | It is the main objection this application will meet, and honest framing helps here. | Visits you made on your own; decisions you made on a visit and who you escalated to | The secondment role description or a reference | `[grounded]` CV and your statement; `[inferred]` that it is the likeliest objection |
| G6 | Doppler assessment (R14, preferred) | capability | No evidence, and you've told me you haven't done one. | It is desirable, not essential, so it is a minor risk. | Not applicable. Ask whether the team trains new starters. | Not applicable | `[grounded]` your statement and advert |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Vacancy not found on the employer's own careers page | unknown | — | "Current vacancies are listed on our careers page." (the About page) | The page I tried may sit at a different address, or the vacancy may be advertised on a job board. | `[grounded]` the About page's wording and the failed fetch; `[inferred]` the hypothesis | Where is this vacancy listed on your own careers page, and what is its closing date? | unresolved |
| RR2 | Pay sits within the survey range | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The stated range spans the survey's interquartile range, so it doesn't look low for the post. | `[grounded]` advert; `[generic]` survey | Where in the range would an appointee with five years' ward experience start? | noted |
| RR3 | Supported start stated | positive_signal | — | "supported by a senior community nurse" | The caseload is supervised, which fits someone who hasn't held one before. | `[grounded]` advert | How is the senior nurse's support structured in the first weeks, and how many patients would be on my caseload at the start? | noted |
| RR4 | Pool cars provided and mileage paid | positive_signal | — | "pool cars are provided"; "plus mileage" | A pool car removes the need for your own vehicle. The survey found 24% of community Band 5 nurses had a pool or lease car, so it is a real benefit. | `[grounded]` advert; `[generic]` survey | How are pool cars allocated on a visiting day? | noted |
| RR5 | Terms the advert leaves out | unknown | — | The advert gives no contract basis, hours, weekend or on-call expectation. | The post may be permanent or fixed-term. End-of-life visits may bring out-of-hours work. | `[grounded]` advert silent; `[inferred]` the hypothesis | Is this post permanent, what are the working hours, and are weekend or out-of-hours visits expected? | unresolved |
| RR6 | Team lead has spoken on Doppler training | positive_signal | — | "Doppler assessment for leg ulcers" (desirable) | Rhiannon Mabbott's published talk on Doppler training for new community staff suggests the team knows the need. It doesn't show that Calderbrook funds or provides it. | `[grounded]` speaker page; `[inferred]` the hypothesis | Is Doppler training given to new starters, and over what timeframe? | unresolved |

## Application plan

Everything below is proposed. Nothing is finalized until you approve it, and that covers the CV edits table and the prose advice rows alike.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | The CV edits in the table below | see R5, R6, R8, R10 | `[grounded]` CV | pending your approval |
| A1 | Confirm the vacancy is live through Calderbrook's own careers page, or contact details found on their own site, before investing in the application. | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Use the informal chat with Rhiannon Mabbott. Ask the RR3, RR5 and RR6 questions. Say plainly that you haven't held your own caseload and haven't done a Doppler assessment. | see R13, R14 | `[grounded]` the advert's invitation to chat and your own statements | pending your approval |
| A3 | Describe the discharge-to-assess work as home visiting in the first week after discharge. Don't present it as a district nursing caseload. | see R5, R13 | `[grounded]` CV | pending your approval |
| A4 | Keep leg-ulcer, end-of-life, care-planning and records lines off the CV until you've answered G1 to G3 and confirmed the extraction. | see R4, R7, R11, R12 | `[grounded]` rows | pending your approval |

`resume_edits_pending_approval`

| # | Current wording | Proposed wording | Trace to your sentences | Status |
|---|---|---|---|---|
| E1a | "seconded to its discharge-to-assess team, visiting patients at home in their first week after discharge" (inside the ward post) | Move it up to its own top bullet: "Eighteen months seconded to the hospital's discharge-to-assess team, visiting patients in their own homes in the first week after discharge." | Your sentence, reordered. No new fact or number. | resume_edits_pending_approval |
| E1b | "Wound care including pressure ulcers and surgical wounds; catheter care; insulin administration" | Keep the wording as it is, and move it into a skills line directly below the home-visiting bullet. | Your sentence, repositioned only. | resume_edits_pending_approval |

## Evidence status

Verified: none yet. Your National Insurance number isn't needed for this and I haven't used it. Don't put it on an application until an offer asks for it. Your NMC and licence statements are stated and unchecked; your NMC PIN was not used in any search.

Research tier: L1 — searches 3 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax district nursing", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about). Fetched calderbrookhealth.example/careers: no page at that address. Moved role reality's organization and contradictions rows, and RR1. |
| 2. Role-family sweep | yes | Searched "NHS Agenda for Change Band 5 pay scale 2026/27", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). It returned a survey, not the official pay scale. Moved the market calibration row and RR2, RR4. |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead", which returned the speaker page. Fetched "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). The fetch added nothing beyond the search snippet. Moved role reality's footprint row, RR6 and A2. |

If you'd like it, I can save all this as `tuesday-dossier.md` to carry into later steps.

## Upgrade menu

- Answers to the three questions below → R4, R7 and R11 move off `unclear`. A decision on R4 could remove the second condition.
- An inspectable artifact → raises a row from `medium`. For records, an anonymised audit result or a competency sign-off. For wound care, a competency record or training certificate. For home visiting, the secondment role description.
- Your non-negotiables (pay floor, hours, days, travel) → the hard-gate check against the posting stops being unknown. RR5's terms can then be tested against them.
- The vacancy link or closing date → RR1 closes.
- A deeper research pass on Calderbrook (inspection reports, staff and leadership changes; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

G1 — On the ward and in the discharge-to-assess team, which record system did you use, and were you the one writing up your own assessments and visits?

G2 — Have you cared for leg ulcers yourself, such as compression bandaging, assessment or dressings, on the ward or on discharge visits? What was your part?

G3 — Have you been involved in end-of-life care, on the ward or on a home visit? What did you do yourself?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.