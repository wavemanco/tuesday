# Job Underwriting Assessment — Community Staff Nurse, Band 5, Calderbrook Community Health CIC

## Decision snapshot

**Yes, this one is worth applying for. R1 and R2, the two hard gates, are met on your own account. Status: `go`.**

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3 · unclear: R4 (clear, timely written records)
- `important` — direct: R6a, R7a, R8 · adjacent: R5 (care for housebound adults in their own homes), R10 (a small caseload of your own) · unclear: R6b (leg-ulcer care), R7b (continence care), R9 (end-of-life visits), R11 (care planning)
- `preferred` — absent: R12 (Doppler assessment for leg ulcers)

R5 and R10 — credible bridges, their limits named; R4 — waiting on one answer from you; R12 — a stated gap on a desirable item.

**Opportunity ledger.** The duties, pay range and supervision are stated openly (RR2, RR3). The hiring lead's public footprint fits the posting (RR4). Whether the posting is still live is unconfirmed (RR1), and working hours and mileage are unstated (RR5).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** RR1 resolving as a closed or unlisted post would move the status to `hold_pending_answers`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC, a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015, 410 staff, four locality hubs | `[grounded]` the company's About page, fetched |
| Mandate | Join the district nursing team caring for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin administration and care planning, on an electronic patient record | `[grounded]` JD |
| Support | A small caseload of your own, supported by a senior community nurse | `[grounded]` JD |
| Essentials | Current NMC registration as an Adult Nurse, a full UK driving licence (pool cars provided), at least one year's post-registration experience, clear timely written records | `[grounded]` JD |
| Scope read | An ordinary Band 5 district nursing mix, with no bundled specialisms or leadership duties | `[inferred]` from the duty list against the stated senior support |
| Hiring lead | Rhiannon Mabbott leads the Halifax district nursing team after eleven years as a district nurse. At the 2025 forum she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work. | `[grounded]` forum speaker listing, search snippet only (page not fetched) |
| Market calibration | A 2026 pay survey of community staff nurses at Band 5 in England (n=1,240) gives a median of £34,300 and a middle half of £32,400 to £36,600. The posting's £31,050–£37,800 spans that middle half, so the pay is in line with the market. | `[generic]` survey snippet, not fetched, a pattern and not this employer's offer; `[grounded]` the posting's own figures from the JD |
| Unknowns | Whether the post is still open; hours and any weekend or out-of-hours rota; mileage rate; whether Doppler training is provided; length of the supported period | — |
| Contradictions | None between the JD and the About page on service type or area; the careers page could not be reached (RR1) | `[grounded]` About page fetched; `[inferred]` that the careers address tried may simply have been wrong |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | You state active Adult registration with revalidation due March 2028. This is stated, not checked: a register entry is inspectable and yours to look at. | `[grounded]` CV | Check your own NMC register entry shows Adult nurse, active |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | You state a full category B licence. This is stated, not checked: your licence record is yours to check. | `[grounded]` CV | Check your driving record shows the licence is current |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward. The JD sets a length, so it is graded as experience and not as a gate. | `[grounded]` CV | none |
| R4 | Clear, timely written records, on an electronic patient record | must_have | unclear | low | discovery | The CV is silent on documentation and on any electronic record system. | `[grounded]` CV silence | See G1 |
| R5 | Care for housebound adults in their own homes | important | adjacent | medium | transferability | Eighteen months in the discharge-to-assess team, visiting patients at home in their first week after discharge. Limit: that was short-term, post-discharge visiting, not an ongoing housebound caseload. | `[grounded]` CV | See G4 |
| R6a | Wound care | important | direct | medium | none | Pressure ulcers and surgical wounds are stated. | `[grounded]` CV | none |
| R6b | Leg-ulcer care | important | unclear | low | discovery | Leg ulcers are not mentioned in your wound care. | `[grounded]` CV silence | See G2 |
| R7a | Catheter care | important | direct | medium | none | Catheter care is stated. | `[grounded]` CV | none |
| R7b | Continence care beyond catheters | important | unclear | low | discovery | The CV does not mention it. | `[grounded]` CV silence | See G6 |
| R8 | Insulin administration | important | direct | medium | none | Stated on the CV. | `[grounded]` CV | none |
| R9 | End-of-life visits | important | unclear | low | discovery | The CV is silent. | `[grounded]` CV silence | See G3 |
| R10 | A small caseload of your own, with senior support | important | adjacent | medium | transferability | You state you have never held your own caseload. Limit: home visiting in the secondment is the nearest work, and the JD pairs the caseload with senior support. | `[grounded]` your statement and the JD | See G4 |
| R11 | Care planning | important | unclear | low | discovery | The CV is silent. | `[grounded]` CV silence | See G6 |
| R12 | Doppler assessment for leg ulcers (desirable) | preferred | absent | none | capability | You state you have never done one. The posting lists it as desirable, not essential. | `[grounded]` your statement and the JD | See G5 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Written records and the electronic record (R4, must_have) | discovery | The CV says nothing about documentation or record systems | R4 is the one essential that is not yet `direct`, and one answer could close it | Documenting on an electronic patient record on the ward; writing discharge-to-assess visit notes or handover entries; record-keeping audits | A record-keeping audit result, or a description of the system you used | `[grounded]` CV silence; `[generic]` that records are a standard screening point for community posts |
| G2 | Leg-ulcer care (R6b, important) | discovery | Wound care is stated, but not leg ulcers or compression | Leg-ulcer care is named in the advert and tied to the desirable Doppler skill (R12) | Applying compression bandaging; managing venous leg ulcers on the ward or on discharge visits; leg-ulcer training or a competency sign-off | A competency record or training certificate | `[grounded]` CV and JD; `[inferred]` that the two rows are linked from the JD's wording |
| G3 | End-of-life visits (R9, important) | discovery | The CV is silent on palliative or end-of-life care | End-of-life visits are named in the advert | Caring for dying patients on the ward; supporting anticipatory prescribing or care plans; family communication; discharging patients to die at home | A training record, or a description of a case | `[grounded]` CV silence |
| G4 | Own caseload and home-based working (R5, R10) | transferability | The nearest evidence is the home-visiting secondment | The JD describes supervision for a new caseload holder | The bridge: you visited patients at home alone or in a team. The limit: no ongoing caseload. The strengthener: a short description of how the secondment worked day to day. | A secondment job description or a supervisor reference | `[grounded]` CV and your statement |
| G5 | Doppler assessment (R12, preferred) | capability | No evidence; you state you have not done it | It is a desirable item, and the hiring lead has spoken on Doppler training for staff new to community work | A closure path: ask whether the employer trains it (RR4) | n/a | `[grounded]` your statement and the forum listing |
| G6 | Continence care and care planning (R7b, R11) | discovery | The CV does not mention either | Both are named duties but neither is essential, so they rank below G1 to G3 | Bladder and bowel management on the ward; writing or updating care plans | Training records or care plan templates you have used | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | The posting's liveness is unconfirmed | unknown | — | "Community Staff Nurse, Band 5 — Calderbrook Community Health CIC, Halifax" | The About page says vacancies are on the careers page, but the address I tried returned no page; the posting may be listed at a different address, or it may have closed | `[inferred]` from the About page's wording against the failed fetch | Is this post still open, and where is it on your careers page? | unresolved |
| RR2 | Supported entry to a caseload | positive_signal | — | "You will hold a small caseload of your own, supported by a senior community nurse" | The role expects a nurse new to caseload-holding to be supervised | `[grounded]` JD | How long is the supported period, and how many patients does a new starter carry at first? | noted |
| RR3 | Stated pay and pool cars | positive_signal | — | "£31,050–£37,800 a year plus mileage … pool cars are provided" | Terms are openly stated and span the survey's middle half | `[grounded]` JD; `[generic]` survey band | What is the mileage rate, and which pay point do new Band 5 starters usually join at? | noted |
| RR4 | Doppler training offered to new starters | unknown | — | "Desirable: Doppler assessment for leg ulcers" | The posting does not say whether it is trained in-house, though the hiring lead has spoken publicly on Doppler training for staff new to community work | `[grounded]` forum listing; `[inferred]` from the JD's silence on training | Is Doppler assessment training provided to new starters, and in what timeframe? | unresolved |
| RR5 | Hours and rota unstated | unknown | — | "district nursing team caring for housebound adults" | The JD says nothing about shift pattern, weekends or out-of-hours | `[inferred]` from the JD's silence | What is the working pattern, and is there a weekend or out-of-hours rota? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | CV: lead with the discharge-to-assess secondment, in your own words ("seconded to the discharge-to-assess team, visiting patients at home in their first week after discharge") | See R5 | `[grounded]` CV | `resume_edits_pending_approval` |
| E2 | CV: keep wound care, catheter care and insulin administration visible near the top; add G1 to G3 details once you answer them | See R6a, R7a, R8 | `[grounded]` CV | `resume_edits_pending_approval` |
| A1 | Call Rhiannon Mabbott for the informal chat the advert invites. Questions to ask: RR2, RR4 and RR5. Say what you have not done, plainly (own caseload, Doppler). | The JD invites the call, and the register's questions double as interview preparation | `[grounded]` JD and register | pending your approval |
| A2 | Find the post on the employer's own site and apply there. Check your NMC and driving records before applying. | See RR1, R1, R2 | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Your National Insurance number isn't needed for this assessment and has not been used.

Research tier: L1 — searches 4 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Community Staff Nurse Band 5 district nursing Halifax Calderbrook Community Health CIC vacancy". Fetched "About Calderbrook Community Health" (calderbrookhealth.example/about), and calderbrookhealth.example/careers, which returned no page. Moved: the employer is attributed to a real CIC matching the advert; the posting's liveness is open (RR1) |
| 2. Role-family sweep | yes | Searched "district nurse Band 5 community staff nurse role scope salary Agenda for Change 2026", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved: market calibration, RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook Community Health", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Moved: role reality's hiring lead row, RR4, application plan A1 |

I can create `tuesday-dossier.md` from this assessment whenever you want it.

**Upgrade menu**

- Your NMC register entry and your driving record, checked by you, would move R1 and R2 toward `high`.
- A description or sample of your record-keeping (an audit result, or the system you used) would settle R4.
- A leg-ulcer or compression competency record would move R6b and soften R12.
- The live posting link from the employer's careers page would close RR1.
- Your current pay and your minimum would let me set the £31,050–£37,800 range against your floor; no pay row can be checked against you yet.
- A deeper research pass on Calderbrook (up to 5 more searches and 2 more fetches) is available. Say the word and it runs.

**Questions**

- G1 — Have you documented on an electronic patient record on the ward or in the discharge-to-assess team? What did you record, and how timely were the entries?
- G2 — Have you ever treated leg ulcers, for example with compression bandaging? What was your part, and were you signed off for it?
- G3 — Have you cared for dying patients, on the ward or while arranging a discharge home to die? What was your part?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.