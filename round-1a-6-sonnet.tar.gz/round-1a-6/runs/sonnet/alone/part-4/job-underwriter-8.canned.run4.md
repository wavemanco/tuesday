Checking whether Velloway Logistics can be found as a real employer, and what similar roles normally pay.
This job is very likely a scam, so I wouldn't go ahead. I checked the posting and the messages against what's public. Your IBAN, passport and PPS number aren't needed for this assessment. I haven't used them, and they shouldn't go into that chat.

## Decision snapshot

**No, don't go ahead. RR1, RR2, RR3 and RR4 are confirmed severe red flags, and this job is very likely a scam. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Income of at least €30,000 a year)
- `must_have`: direct: R2, R3 · adjacent: R4 (Good written English)
- `important`: unclear: R5 (A quiet place to work)
- `preferred`: adjacent: R6 (Order or parcel handling familiarity)

R2 and R3 — your tracker and ticket work match what's asked; R1 — "up to" pay with variable hours can't be checked against your floor.

**Opportunity ledger.** The opportunity fails on its own terms, whatever your fit. The requests for equipment payment (RR1), a cheque transfer (RR2), bank and ID details before any offer (RR3) and a chat-only process (RR4) are all severe. The employer isn't established (RR5), and the advertised rate sits far above the market band (RR6).

- **Hard gates:** none failed; unconfirmed: R1 (Income of at least €30,000 a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would change this:** the employer confirmed independently through its own website, every payment, cheque and early-disclosure request withdrawn, and a written contract on its own domain with the pay terms.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics": no careers page or web presence found | `[grounded]` search returned no results; employer not established |
| Mandate | Remote order processing, 15–30 hours a week, paid "up to €26 an hour plus commission" | `[grounded]` posting |
| Pay arithmetic | Up to about €20,300 a year at 15 hours and up to about €40,600 at 30 hours, 52 weeks. These are ceilings, since the posting says "up to" | `[inferred]` from the posting's rate and hours |
| Market calibration | Salaried order processing and customer operations coordinators in Ireland: median €31,200, interquartile range €28,400 to €34,100. That is about €15 an hour at full time, so €26 is far above it. This is a market band, not this employer's offer | `[generic]` Pennoral 2026 pay guide; it excludes commission-only and freelance work |
| Process | The posting says the hiring process is entirely on Telegram. The messages then ask for payment for equipment, which the posting never mentions | `[grounded]` posting and your messages |
| Unknowns | Who the employer is, the contract, the guaranteed hours, the commission basis | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Income of at least €30,000 a year (your constraint) | hard_gate | unclear | high | hard_gate | Confidence grades your constraint, which you stated. The posting gives only a ceiling rate and a 15–30 hour range, so the floor isn't established | `[grounded]` your constraint; posting's "up to" | Written pay terms from an independently verified employer |
| R2 | Strong attention to detail | must_have | direct | medium | none | About 60 tickets a day and a weekly team tracker are sustained accuracy work. This is your own account, with no artifact | `[grounded]` your stated background | none |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep the team's weekly tracker in Excel | `[grounded]` your stated background | none |
| R4 | Good written English | must_have | adjacent | medium | transferability | Ticket handling in Zendesk is written work. Writing quality itself has no sample | `[inferred]` from ticket volume and tool | none |
| R5 | A quiet place to work | important | unclear | low | discovery | Your messages don't say | `[grounded]` silence | Your own call |
| R6 | Order or parcel handling familiarity (implied; "no experience needed") | preferred | adjacent | medium | transferability | Three years at a parcel courier is close, though the posting doesn't define the work | `[inferred]` from your courier role | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Income floor (R1, hard_gate) | hard_gate | Only a ceiling rate and a range of hours | The floor decides whether the role is viable at all | A written contract with a guaranteed minimum, from a verified employer | A signed contract on the employer's own domain | `[grounded]` posting |
| G2 | Quiet workspace (R5, important) | discovery | Not stated | Minor, and only matters if the role verifies | Your home setup | Your own answer | `[grounded]` silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Payment for equipment demanded | red_flag | high | "Please pay €349 by bank transfer to our equipment partner" | A payment sent by transfer is hard to get back. The refund is promised only from future wages | `[generic]` pattern of such requests | Does this employer require staff to buy equipment, and who is its named payee? Ask through contacts on the employer's own website, not the chat | confirmed |
| RR2 | Cheque deposit with onward transfer | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner" | A cheque can be credited and later reversed, which would leave you owing the money you transferred | `[generic]` how cheque clearing works | See RR1; I'd put it to the employer the same way | confirmed |
| RR3 | Bank, tax and ID details requested before any offer | red_flag | high | "Before your chat interview, please send your IBAN, your PPS number and a clear photo of your passport" | These details can't be taken back once sent. They were requested before any offer or interview | `[generic]` what such details enable | See RR1; I'd put it to the employer the same way | confirmed |
| RR4 | Process run wholly by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | Interview and offer happened in chat only, leaving no verifiable employer contact. The sender's identity is unresolved | `[grounded]` posting and messages | See RR1 | confirmed |
| RR5 | Employer not established from attributable sources | risk_signal | medium | "Velloway Logistics" | The entity may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer | `[generic]` pattern, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR6 | Advertised rate far above the market band | risk_signal | medium | "Earn up to €26 an hour plus commission" | The rate is well above the Irish band in role reality for a role needing no experience | `[inferred]` posting against the `[generic]` band | What is the contracted hourly rate and the guaranteed weekly minimum? | unresolved |

**Hold.** Hold off on the payment, the cheque deposit and sending your details, and go no further in the chat, until you have checked each request with the employer, through contact details on the employer's own website rather than the chat or the address these messages came from; who sent them is not yet confirmed. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Send nothing: no IBAN, passport, PPS number or €349, and don't lodge the cheque if it arrives | see RR1, RR2, RR3 | `[grounded]` register | pending your approval |
| A2 | Stop replying in the chat. Report the posting to the jobs site and to An Garda Síochána. If you've already shared anything, tell your bank straight away | The usual steps after requests like these | `[generic]` | pending your approval |
| A3 | Put your effort into openings at employers with a verifiable site and a written contract. Your courier ticket work, Excel tracker and training of new starters fit order-processing and customer-operations roles. Your €30,000 floor sits just under the market median in role reality | see R2, R3, R6 | `[inferred]` from your background against the `[generic]` band | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics careers remote order processing coordinator"; no results. Employer not established (RR5) |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator salary Ireland hourly rate", which returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). Market calibration `[generic]`, and RR6 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer and upgrade menu

I can save this as a `tuesday-dossier.md` if you want it. Two things would add to it:

- The link to the original posting on the jobs site would settle RR5 and show whether the listing is still live.
- A deeper research pass (up to 5 more searches and 2 more fetches) could look for public reports about this name. Say the word and it runs.

## Questions

1. (RR5) Can you share the name of the jobs site and the link to the original posting? You can answer in text, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.