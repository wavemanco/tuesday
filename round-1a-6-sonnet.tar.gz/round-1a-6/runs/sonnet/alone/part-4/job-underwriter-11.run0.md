**Duinvaart is worth applying to. Kroonhaven is not worth a tailored application.** Neither company could be checked, because my web searches were refused. Everything about both employers comes from the postings and your background alone.

## Decision snapshot

### Duinvaart Cold Chain, Operations Analyst: yes, worth your time, because R2, R3 and R4 are direct. Status: `conditional_go`

**Fit ledger.**

- `hard_gate` — unclear: R1 (Hybrid, three days a week in Rotterdam)
- `must_have` — direct: R2, R3, R4
- `important` — direct: R5a, R6 · unclear: R5b (temperature compliance)
- `preferred` — adjacent: R7 (Dutch a plus)

R5b — nothing in your background on temperature compliance yet; R7 (`medium`) — conversational Dutch, limit named.

**Opportunity ledger.** The employer is unverified (RR1) and the pay is withheld (RR2). What the temperature-compliance work involves is unstated (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Hybrid, three days a week in Rotterdam); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify, see RR1; (2) the Rotterdam three-day pattern works for you, see R1; (3) temperature compliance turns out to be a reporting task you can learn, not a regulatory specialism, see R5b and RR3.

### Kroonhaven Foods, Supply Planner: no, R9, R12 and R13 are absent must-haves. Status: `no_go`

**Fit ledger.**

- `hard_gate` — unclear: R8 (On-site in Utrecht)
- `must_have` — adjacent: R10 (Fluent Dutch) · unclear: R11 (Advanced Excel) · absent: R9 (3+ years of supply or demand planning in FMCG), R12 (SAP IBP or similar planning system), R13 (Own the 13-week supply plan)
- `important` — adjacent: R14 (Run the weekly S&OP meeting)

R9, R12, R13 — no planning work in your background, which is what drives the decision; R14 — your weekly review is a bridge with a limit; R11 — likely closable, unconfirmed.

**Opportunity ledger.** The employer is unverified (RR4) and the pay is withheld (RR5). The duties are concrete and checkable (RR6).

- **Hard gates:** none failed; unconfirmed: R8 (On-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would have to differ:** evidence of forecasting, capacity or planning-system work in R9, R12 and R13, or a posting that would take someone without it. G3 asks about the first.

## Role reality

**Duinvaart Cold Chain**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam, running a refrigerated fleet. Existence not verified | `[grounded]` JD header; `[inferred]` that it is a cold-chain carrier from the fleet and temperature wording |
| Mandate | Track on-time delivery and temperature compliance, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` JD |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` JD |
| First-90-days outcomes | Not stated | `[grounded]` JD silent |
| Scope read | A mid-level reporting and analysis post that is well matched to 4 years of analyst work. It reports to nobody named and has no team mentioned | `[inferred]` from "2+ years" against the duty list |
| Market calibration | Not obtained, because research was refused. No salary band is given and none is claimed | `[generic]` |
| Unknowns | Pay; temperature standards and systems; team size; who the manager is | `[grounded]` JD silent on each |
| Contradictions | None visible in the posting alone. The posting was not checked against a careers page | `[grounded]` JD only |

**Kroonhaven Foods**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, Utrecht, with a chilled ready-meals range. Existence not verified | `[grounded]` JD header |
| Mandate | Own the 13-week supply plan, balance production capacity against the forecast, run the weekly S&OP meeting | `[grounded]` JD |
| Working pattern | On-site in Utrecht | `[grounded]` JD |
| Scope read | A core planning post. The requirements read as a role where the planning discipline is the job from week one, not something learned alongside | `[inferred]` from "3+ years", "own", and the planning-system requirement |
| Market calibration | Not obtained, because research was refused | `[generic]` |
| Unknowns | Pay; which planning system is actually in use; the size of the range; who attends S&OP | `[grounded]` JD silent on each |
| Contradictions | None visible in the posting alone | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, three days a week in Rotterdam (Duinvaart) | hard_gate | unclear | none | hard_gate | You are in Amsterdam for work today and have not stated where you live or what commute you accept. Confidence grades your statement of the constraint, and there is none yet | `[grounded]` JD; `[grounded]` no constraint given | G1 |
| R2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | You stated 4 years as an operations analyst at a parcel carrier. Self-reported, nothing inspected | `[grounded]` your background as typed | none |
| R3 | Strong SQL | must_have | direct | medium | none | You stated daily SQL use. Self-reported, no artifact | `[grounded]` your background as typed | offer: a sanitized query or schema description would raise to `high` |
| R4 | Power BI or Tableau | must_have | direct | medium | none | You stated daily Power BI use, including the on-time delivery dashboard your depot managers use. How much of it you built is not stated, so I claim no more than use | `[grounded]` your background as typed | G2 offer: a dashboard screenshot would raise to `high` |
| R5a | Track on-time delivery | important | direct | medium | none | On-time delivery is the dashboard you named | `[grounded]` your background as typed | none |
| R5b | Track temperature compliance across a refrigerated fleet | important | unclear | low | discovery | Nothing you gave touches temperature-controlled freight. A parcel carrier may or may not have handled any, which is why this is open rather than absent | `[grounded]` your background silent; `[generic]` parcel carriers sometimes carry temperature-sensitive items | G2 |
| R6 | Work with depot managers on route changes | important | direct | medium | none | Depot managers use your dashboard and you ran the weekly route-performance review. Limit: you did not say the review changed any route | `[grounded]` your background as typed | none |
| R7 | Dutch a plus | preferred | adjacent | medium | transferability | Your Dutch is conversational, which is below working fluency but counts for a "plus" | `[grounded]` your statement | none |
| R8 | On-site in Utrecht (Kroonhaven) | hard_gate | unclear | none | hard_gate | Utrecht is a different city from Amsterdam and from Rotterdam, and five days on-site is a heavier term than Duinvaart's. No constraint stated | `[grounded]` JD; `[grounded]` no constraint given | G1 |
| R9 | 3+ years of supply or demand planning in FMCG | must_have | absent | none | capability | You said you have never worked in planning. This is a length-of-experience requirement, not a gate (conventions §3), and it is simply not met | `[grounded]` your statement | closure path in the plan |
| R10 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational is a real step below fluent, and S&OP meetings are run in Dutch. The bridge is genuine, and its limit is the job's working language | `[grounded]` your statement | none |
| R11 | Advanced Excel | must_have | unclear | none | discovery | Your SQL and Power BI use is clear and Excel is not mentioned. Analysts in your seat often use it heavily, but that is a pattern, not evidence | `[grounded]` your background silent; `[generic]` analyst roles typically use Excel | offer: say whether you use Excel for modelling |
| R12 | SAP IBP or a similar planning system | must_have | absent | none | capability | SQL and Power BI are reporting tools and are not planning systems | `[grounded]` your background as typed | closure path in the plan |
| R13 | Own the 13-week supply plan, balancing capacity against the forecast | must_have | absent | none | capability | Nothing in your background plans supply against capacity or a forecast | `[grounded]` your background as typed | G3 |
| R14 | Run the weekly S&OP meeting | important | adjacent | low | transferability | You ran a weekly performance review, which is the same running-a-cadence skill. Limit: a route review is not a cross-functional demand and supply negotiation, and nothing says it was one | `[grounded]` your background; `[inferred]` the limit from the S&OP definition | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Commute and on-site terms (R1, R8, hard gates) | hard_gate | No constraints given: no pay floor, commute limit or days-in-office limit | Either gate failing ends that role. Kroonhaven's five days on-site make R8 the likelier one to fail | A fixed home city; a travel time you won't exceed; a minimum salary | Nothing to attach | `[grounded]` no constraints given; `[inferred]` that R8 is the heavier term |
| G2 | Temperature compliance exposure (R5b, important) | discovery | The background names nothing temperature-related | An analyst with no cold-chain exposure can still be hired, but a related example narrows the objection quickly | Tracking delivery exceptions for fragile, pharma, food or hot/cold items; any SLA or breach report; any monitoring of a trailer or locker condition | A sanitized report or dashboard view | `[grounded]` your background silent; `[generic]` that hiring managers weigh domain exposure |
| G3 | Planning-adjacent work (R13, R14, R9) | transferability | You ran a weekly route-performance review and say you never worked in planning | It is the only path from `no_go` to a conversation, and the answer is probably no, but it is the one place to look | Forecasting parcel volumes for depots; depot capacity or staffing plans built from your analysis; a weekly review that fed a cross-team decision | A volume forecast, a capacity sheet or a review pack | `[grounded]` your statement; `[inferred]` that an answer could not reach R9 or R12 |
| G4 | Dutch working level (R10) | capability | Conversational; the role asks for fluent | Utrecht is a Dutch-language operation and fluency is a stated must-have | A recognised language-level result, or work done in Dutch with colleagues | A level certificate if you have one | `[grounded]` your statement; `[inferred]` from "fluent Dutch" in the JD |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources (Duinvaart) | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay withheld (Duinvaart) | unknown | — | no figure appears in the posting | The posting may omit pay by habit, or the figure may be below the market band | `[generic]` postings often omit pay; nothing entity-specific | What salary range is budgeted for this post? | unresolved |
| RR3 | Temperature compliance scope unstated | unknown | — | "temperature compliance across our refrigerated fleet" | It could be reading a feed against a threshold, or owning a regulated audit | `[inferred]` from the posting naming the metric without its standard | Which temperature standards apply, and which systems produce the data? | unresolved |
| RR4 | Employer not established from attributable sources (Kroonhaven) | risk_signal | medium | "Kroonhaven Foods, Utrecht" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR5 | Pay withheld (Kroonhaven) | unknown | — | no figure appears in the posting | The posting may omit pay by habit, or the figure may be below the market band | `[generic]` postings often omit pay; nothing entity-specific | What salary range is budgeted for this post? | unresolved |
| RR6 | Concrete duties and cadence | positive_signal | — | "Own the 13-week supply plan … run the weekly S&OP meeting" | The scope is defined, so success can be judged | `[grounded]` JD states both | Who attends the weekly S&OP, and which functions send input? | noted |

## Application plan

Everything here is proposed. `resume_edits_pending_approval` covers the table and the advice lines beneath it alike, and nothing is final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Duinvaart CV line, from your own sentences: "SQL and Power BI daily, including the on-time delivery dashboard used by depot managers" and "ran the weekly route-performance review". Ownership of the dashboard is not stated, so the line claims use only | R3, R4, R5a, R6 | `[grounded]` your background as typed | `resume_edits_pending_approval` |
| P1 | Put effort into Duinvaart first and apply once the posting verifies | R2, R3, R4 are direct; RR1 caps the status | `[grounded]` map and register | pending your approval |
| P2 | On Duinvaart, say plainly in the cover note that your Dutch is conversational and that you have not worked on temperature compliance. Do not claim cold-chain experience | R5b, R7 | `[grounded]` rows R5b and R7 | pending your approval |
| P3 | Skip a tailored Kroonhaven application unless G3 turns up forecasting or capacity work. A quick unmodified application costs little, but expect a screen-out on R9 | R9, R12, R13 | `[inferred]` from three absent must-haves | pending your approval |
| P4 | Longer term, a planning-systems course plus Dutch lessons would address R10 and R12 | R10, R12 | `[generic]` common closure paths | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches ("Duinvaart Cold Chain Rotterdam", "Kroonhaven Foods Utrecht chilled ready meals") were both refused. It would have confirmed each employer exists and the posting is live, which is why RR1 and RR4 stand |
| 2. Role-family sweep | unavailable | One search (Dutch pay for operations analysts and supply planners) was refused. It would have given a market band for RR2 and RR5 and sharpened the scope read |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer

If you'd like, I can write this up as a `tuesday-dossier.md` you can carry forward.

## Upgrade menu

- Your constraints (home city, commute limit, minimum salary) → R1 and R8 settle, and the hard-gates lines stop saying "not given".
- Live links to either posting or a careers page → RR1 and RR4 can clear, lifting the cap on Duinvaart's `conditional_go`.
- A sanitized SQL sample or a dashboard screenshot → R3 and R4 to `high`.
- Any forecasting or capacity work you did → G3 and possibly R13 and R14.
- A name for the Duinvaart hiring manager → scope read and positioning.
- A deeper research pass on both companies (up to 5 more searches and 2 more fetches); it needs search permission, which was refused the first time.

## Questions

G1 — Which of these are fixed for you: a commute to Rotterdam three days a week, being on-site in Utrecht, and a minimum salary?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G2 — Has your parcel work ever touched temperature-sensitive items or any condition-monitoring metric, such as food, pharma or breach reports? If so, what did you track and who used it?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G3 — Have you ever forecast volumes, planned depot capacity or fed a weekly review into a cross-team decision? What did you own and what happened?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.