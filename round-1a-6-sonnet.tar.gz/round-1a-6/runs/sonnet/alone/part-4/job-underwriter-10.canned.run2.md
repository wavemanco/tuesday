I'll read the reference files the skill requires before building the assessment.
Output truncation is getting in the way; I'll read the files in pieces with the Read tool.
**Yes, this is worth pursuing, and the company is established as described by its own pages (RR1). Status: `conditional_go`.** The WhatsApp message asks only for a call time, and that is routine scheduling (A1). I haven't confirmed who actually sent it.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Salary €52,000–€60,000 plus equity)
- `must_have` — direct: R3, R4, R5, R8 · adjacent: R6 (Research calls with school owners), R7 (Own the booking flow end to end)
- `important` — adjacent: R9 (First designer, no design peers)

R6, R7 — usability sessions and a checkout redesign bridge to owner research and the whole booking flow, limits named; R9 — you have not been the only designer; R2 — your pay floor has not been given.

**Opportunity ledger.** The employer is established from its own pages and the posting matches its careers page (RR1), and the pay is stated and sits inside the survey band (RR5). Open unknowns: runway (RR2), equity terms (RR3), and decision rights and success measures (RR4).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000 plus 0.5–1% equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R2 — the range works against your floor; (2) RR2 and RR3 — runway and equity terms get credible answers; (3) R6, R7 and R9 are framed as adjacent, never as owner-research or sole-designer experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway. It makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. Founded 2023 by Ronan Kehoe and Saoirse Doyle, funded by its customers | `[grounded]` About page fetched |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship with two engineers | `[grounded]` JD |
| Working pattern | Hybrid, two days a week in Galway | `[grounded]` JD; careers page says the same |
| Compensation | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` JD; careers page gives the same range |
| Hiring manager | Ronan Kehoe is co-founder and CEO, and was previously a product lead at a Galway travel-software company for five years. The posting says you would work most closely with him | `[grounded]` JD; `[grounded]` search result for his professional profile (snippet only) |
| Scope read | The three duties are ordinary for a first design hire. What is missing is any stated success measure or decision rights (RR4) | `[inferred]` from the JD's duties against its silence on outcomes |
| Market calibration | A survey of 520 Irish product designers with 3–5 years' experience gives median base pay of €57,000 and an interquartile range of €51,500–€62,000. The posted band sits inside that range. The survey is national and covers base pay only, and I read it from a search snippet | `[generic]` role-family sweep; `[grounded]` JD for the posted figure |
| Unknowns | Runway, equity terms, who decides on booking-flow questions, what success looks like at 6 and 12 months | `[inferred]` from JD silence |
| Contradictions | None material. The site also names sailing schools and Scotland, which the posting leaves out | `[grounded]` About page against JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week at the Galway office | hard_gate | direct | medium | none | You said you moved back to Galway last year. Willingness for two set office days was not stated | `[grounded]` your intake | Covered by the R2 question |
| R2 | Salary €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | The range is stated. You gave no floor, so whether it is met is unsettled | `[grounded]` JD; `[grounded]` no floor given | Ask for your floor (question G4) |
| R3 | 3+ years of product design | must_have | direct | medium | none | You have 4 years at a Dublin travel-booking company. Length of experience is graded as a requirement, not a gate. No inspectable artifact has been seen yet | `[grounded]` your intake | A CV or portfolio link would raise it to high |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" over 4 years shows heavy use. "Strong" is a judgement, and nothing has been inspected | `[grounded]` your intake | Share the checkout case study |
| R5 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. The limit is that this is usability testing, which is not the same as discovery interviews | `[grounded]` your intake | none |
| R6 | Run research calls with school owners | must_have | adjacent | medium | transferability | Usability sessions with customers carry over. Interviews with small-business owners about how they work were not stated. Whether your "customers" were consumers or businesses is also unstated | `[grounded]` your intake; `[inferred]` adjacency | See G2 |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned the checkout flow at a travel-booking company. That is one stage of a booking flow. Your ownership of the stages around it was not stated | `[grounded]` your intake; `[inferred]` adjacency | See G1 |
| R8 | Work directly with engineers, shipping alongside two | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your intake | none |
| R9 | Operate as the first designer, with no design peers | important | adjacent | medium | transferability | Inferred from "our first designer". You said you have never been the only designer, so this is a step up. Your checkout redesign is the nearest evidence | `[inferred]` from the JD's wording; `[grounded]` your intake | See G3; framing in A4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Booking flow ownership (R7, must_have) | transferability | A checkout redesign. Nothing yet on the stages around it | A `must_have` at `adjacent`; this is where the call is most likely to probe | Owning search or availability screens; cancellation or rebooking flows; admin tools used by staff | Before/after screens from the checkout case study, plus any completion or conversion result you can share | `[grounded]` your intake; `[generic]` that "end to end" is probed in a first-designer interview |
| G2 | Owner research (R6, must_have) | transferability | Monthly usability sessions with customers; the interviewee type is unknown | The role's research is with school owners, who are business operators | Calls with partners, suppliers or operators who use your company's tools; support-call listening; discovery interviews | An interview guide, a research plan, or a synthesis page, anonymised | `[grounded]` your intake; `[inferred]` from the JD's research duty |
| G3 | Sole-designer operation (R9, important) | transferability | Squad work only | Nobody else would set design standards | Setting up a component library or file structure; freelance or side projects where you were the designer; making design calls without a design lead | A shared component library or a freelance project | `[grounded]` your intake; `[inferred]` that no design peer is implied |
| G4 | Pay floor (R2, hard_gate) | hard_gate | The range is stated and no floor is given | Whether the gate is met cannot be settled without it | n/a | n/a | `[grounded]` JD against no stated floor |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer exists and the posting is live | positive_signal | — | "Open now: Product Designer, our first design hire. Hybrid, two days a week in Galway. €52,000–€60,000 plus equity." | The role is real and the JD matches what the company publishes | `[grounded]` careers page search result; `[grounded]` About page fetched | Who besides Ronan and Saoirse will I meet, and who would I report to? | noted |
| RR2 | Runway unstated | unknown | — | "funded by its customers" | With no outside investor, pay and equity value depend on revenue, and the posting says nothing about how many schools pay | `[inferred]` from the About page against JD silence | How many schools pay today, and what runway does this hire come with? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "0.5–1% equity" | Without the type (options or shares), vesting and dilution, the percentage cannot be valued | `[inferred]` from JD silence | Is the equity options or shares, what is the vesting, and what are the terms if I leave? | unresolved |
| RR4 | Ownership without stated decision rights or success measures | unknown | — | "own the booking flow end to end" | Ownership may sit under the co-founder's final say, with no agreed measure of success | `[inferred]` from the JD's scope language against its silence on authority | Who makes the final call on booking-flow decisions, and what would success look like at 6 and 12 months? | unresolved |
| RR5 | Pay stated, inside the survey band | positive_signal | — | "Salary €52,000–€60,000 plus 0.5–1% equity" | No seniority-compensation mismatch against the survey's national figures | `[generic]` Tillerby 2026 snippet; `[grounded]` JD for the figure | Where in the range would my experience land? | noted |

## Application plan

All rows are proposed and none is applied.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check that the emailed calendar invite comes from an address on fernquay.example, the domain on the company's own pages, before you click the video link. Reply on WhatsApp only with your time | A message with only a call time and no request for money or personal details is routine scheduling. Small teams often use chat for it. I'm going only on what you've shared and can be wrong, so the call on the invite is yours | `[generic]` for the scheduling pattern; `[grounded]` careers page for the domain | pending your approval |
| A2 | Lead with the checkout redesign. Proposed wording: "I redesigned the checkout flow at a Dublin travel-booking company and ran monthly usability sessions with customers, working in a squad with four engineers." | Each clause traces to your own sentences. Ronan's background in travel software makes this the nearest story for him | `[grounded]` your intake; `[grounded]` profile snippet | pending your approval |
| A3 | Use RR2, RR3, RR4 and RR5 verbatim on the call | The register doubles as your question list | `[grounded]` register | pending your approval |
| A4 | Say plainly that you have not been the only designer before. Proposed wording: "I haven't been the only designer before, so I'd like to hear what you expect me to decide alone." | The first clause is your own statement; the second is a question | `[grounded]` your intake | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway" and "Fernquay careers product designer". Fetched "About Fernquay" (fernquay.example/about). The careers page "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer) came back as a search snippet only. Role reality: the organization and contradictions rows, and RR1 |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland startup first designer 3+ years", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Market calibration and RR5 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe). Role reality's hiring-manager row and A2 |

I stopped at L1 on purpose.

I should be clear about what I can't establish from here. I haven't confirmed that the WhatsApp number is Ronan's, and I haven't seen the calendar invite. That is why A1 is a check you can do yourself.

I also didn't find independent reviews or news about Fernquay. That is unsurprising for a six-person company, and I read it as a thin footprint, not a warning.

I'll write up a `tuesday-dossier.md` of this assessment whenever you want one.

## Upgrade menu

- Your CV, the checkout case study or a portfolio link → R3 and R4 can reach `high`, and G1 gets its artifact.
- Your pay floor and your view on two set office days → R2 and R1 close, and `conditional_go` likely firms up to `go` or `no_go`.
- Anything showing research with business owners or operators → R6 moves toward `direct`.
- Ronan's answers on runway, equity and decision rights → RR2, RR3 and RR4 close.
- A deeper research pass on Fernquay (customers, other staff and employee reports, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

1. **G4 (R2, R1)** — What is your minimum acceptable salary, and are two fixed days a week in the Galway office fine for you?
2. **G1 (R7)** — Beyond checkout, which parts of the booking journey did you personally own or redesign, such as search, availability, cancellations or rebooking, and what happened as a result?
3. **G2 (R6)** — Have you spoken directly to business owners or operators who use your company's tools, and if so, how many, about what, and what did you do with it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.