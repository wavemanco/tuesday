Researching Fernquay now: checking whether the company and posting exist, then a salary check for Irish product designers.
I've checked the company and the posting, and I think it's worth taking the call. Nothing you've shown me is a red flag, and the WhatsApp message is a normal way for a small company to schedule an interview.

## Decision snapshot

**Yes on both: nothing in what you've shown me looks wrong (RR1, RR2), and the role is worth pursuing, with conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Salary €52,000–€60,000)
- `must_have` — direct: R3, R4, R5, R8 · adjacent: R7 (Own the booking flow end to end)
- `important` — adjacent: R6 (Research calls with school owners), R9 (First and only designer)

R7 — checkout is one part of a booking flow; R6 and R9 — credible bridges, limits named; R2 (`none`) — waiting on your pay floor.

**Opportunity ledger.** The employer and the posting agree with each other (RR1), and the stated pay sits inside the market band (RR2). Equity terms (RR3), design authority (RR4) and how long a customer-funded company can carry the salary (RR5) are unanswered.

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your pay floor sits at or below the range — R2; (2) the equity terms are explained — RR3; (3) you have real say over the booking flow — R7, RR4; (4) the sole-designer step is framed honestly as a step up, never as something you've already done — R9.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: six people in Galway, making Kelproster booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. Founded 2023 by Ronan Kehoe and Saoirse Doyle, funded by its customers | `[grounded]` fernquay.example/about |
| Mandate | First design hire. Own the booking flow, run research calls with school owners, ship alongside two engineers | `[grounded]` posting |
| Posting consistency | The careers page repeats the same role, location, hybrid pattern and salary range. It asks for one real project, sent to a jobs@ address on the company's own domain | `[grounded]` careers page fetched |
| People | Ronan Kehoe is listed as co-founder and CEO, with five years as product lead at a Galway travel-software company. That is close to your travel-booking background | `[grounded]` his public professional profile |
| Stated outcomes | None. The posting gives no first-90-day or first-year goals | `[grounded]` posting silent |
| Scope read | A sole designer who owns one product area, does research and ships with engineers is a normal remit at a company this size. It is a bigger step than your squad role | `[inferred]` from the posting's three duties against your squad experience |
| Market calibration | The posting's €52,000–€60,000 is its own figure. For product designers with 3 to 5 years in Ireland, one salary survey gives a median of €57,000 and a middle range of €51,500–€62,000. That is a market pattern, not Fernquay's offer | `[grounded]` posting figure; `[generic]` survey band, read from a search snippet only |
| Unknowns | Equity class, vesting and strike terms; decision rights over the flow; who else reviews design; runway | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week in the Galway office | hard_gate | direct | medium | none | You say you moved back to Galway last year, so the office days are workable. Stated in prose, not confirmed against a commute or personal limit | `[grounded]` your message, posting | none |
| R2 | Salary €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | The posting states the pay but you haven't given a floor, so the gate can't be settled. The range is inside the survey band | `[grounded]` posting; `[generic]` survey band | Ask your floor (question R2) |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company, per your account. No CV or portfolio read yet | `[grounded]` your background | Share the CV or case study to reach `high` |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" is a claim, and the checkout case study they say they liked is the artifact. I haven't seen it | `[grounded]` your background | Share the case study |
| R5 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. That is research you ran. It was usability testing, which is narrower than discovery work | `[grounded]` your background | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned the checkout flow, which is part of a booking flow. Limit: nothing says you covered search, selection or the owner-side set-up. Also, who made the final decisions in your squad is not stated | `[grounded]` your background; `[inferred]` adjacency | Gap G2 |
| R8 | Happy working directly with engineers | must_have | direct | medium | none | Squad with four engineers | `[grounded]` your background | none |
| R6 | Run research calls with school owners | important | adjacent | medium | transferability | Your sessions were with customers. The posting's calls are with small-business owners, probably more open-ended. Limit: owner interviews and discovery work are not evidenced | `[grounded]` your background; `[inferred]` that these calls are discovery-style | Gap G3 |
| R9 | First and only designer | important | adjacent | medium | transferability | You have never been the only designer. That is a stated limit, not a gap in evidence. This requirement is inferred from "first designer" and "end to end" | `[grounded]` your statement; `[inferred]` requirement | Gap G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Sole-designer scope (R9, important) | transferability | You have always worked inside a design team and a squad | They will probe how you decide without a design lead, and this is the biggest step in the role | Calls you made on the checkout redesign without a lead's sign-off; setting your own research cadence; deciding what not to design | The checkout case study, a research summary you wrote | `[grounded]` your statement; `[generic]` that first-designer hires are probed on self-direction |
| G2 | End-to-end booking flow (R7, must_have) | transferability | Checkout only, per what you've said | A "booking flow" for schools may include listings, availability and owner set-up | Any work on search, availability, confirmation emails or owner-side set-up at the travel company | A flow diagram or screens beyond checkout | `[grounded]` your background |
| G3 | Owner research calls (R6, important) | transferability | Usability sessions with customers | Owner interviews are a different skill from usability testing | Interviews with partners, suppliers or trade customers; any research that changed a roadmap | A research plan or summary | `[grounded]` your background |
| G4 | Pay floor (R2, hard_gate) | hard_gate | Not stated | The only gate left open | — | — | `[grounded]` not stated |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting agree | positive_signal | — | "Apply with one real project to jobs@fernquay.example" | The employer exists as described and the role is live | `[grounded]` site, careers page and public profile all agree | Who would I report to, and who else reviews design work? | noted |
| RR2 | Stated pay inside market band | positive_signal | — | "€52,000–€60,000 plus equity" | Pay is not withheld and sits at the survey median | `[grounded]` posting; `[generic]` survey band | Is the range fixed, and what moves someone within it? | noted |
| RR3 | Equity terms unstated | unknown | — | "0.5–1% equity" | The class of shares, vesting and strike price decide what this is worth | `[inferred]` from the posting's silence | What share class is it, how does it vest, and what is the strike price? | unresolved |
| RR4 | Design authority unstated | unknown | — | "own the booking flow end to end" | Ownership may stop short of final decisions, which could sit with the co-founders | `[inferred]` from the posting's silence on decision rights | Which product decisions would I make alone, and which go to you? | unresolved |
| RR5 | Customer-funded runway | unknown | — | "six people" | A customer-funded company's pay rests on revenue, not outside investment | `[generic]` pattern for companies of this size | How many months of salary costs are covered, and how has revenue grown? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | On the WhatsApp contact: scheduling an interview by chat is routine at small companies. Check that the calendar invite came from a fernquay.example address, and that the video link comes from that invite. Share no bank, tax or ID details at this stage | Cheap to do, and it settles who is on the other end | `[generic]` hiring pattern | pending your approval |
| A2 | Bring the checkout case study as your real project and say plainly it was done in a squad with four engineers | Matches what you've said and what they asked for | `[grounded]` your background, careers page | pending your approval |
| A3 | Describe your usability sessions as usability sessions. Say you want to learn owner-style research | Keeps R5 honest and addresses R6 | `[grounded]` R5, R6 | pending your approval |
| A4 | Ask RR1, RR3, RR4 and RR5's questions verbatim on the call | The register doubles as call preparation | `[grounded]` register | pending your approval |
| A5 | Ask Ronan how he worked with designers at his travel-software company | His own background overlaps yours | `[grounded]` public profile | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway" and "Fernquay product designer Galway careers", which returned "About Fernquay" (fernquay.example/about) and "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer). I fetched the careers page. The fetch repeated the search text and added nothing new. It confirmed the employer exists and the posting is live and consistent, which moved RR1 and the role reality rows |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland Galway startup 3+ years 2026", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Market calibration and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe). Role reality's people row and plan row A5 |

## Upgrade menu

- Your pay floor → R2 closes, and the status likely becomes `go` or `no_go`.
- The checkout case study or your CV → R3 and R4 can reach `high`, and G1 and G2 get specific.
- Any research beyond usability sessions → R6 and G3 strengthen.
- A deeper research pass on Fernquay (customer reviews, recent news; up to 5 more searches and 2 more fetches) → RR5 sharpens. Say the word and it runs.

I can also write all of this up as a `tuesday-dossier.md` if you want to keep it.

Questions:

- **R2** — What is the lowest base salary you would accept, and does the equity change that?
- **G1** — On the checkout redesign, which calls did you make yourself, which needed sign-off, and what did the squad decide?
- **G3** — Have you ever run research beyond usability sessions, such as talking to partners or business customers, and did it change what got built?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.