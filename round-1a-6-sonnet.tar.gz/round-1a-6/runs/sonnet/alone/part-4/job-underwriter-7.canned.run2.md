I've read the underwriting rules. Next I'll check whether Calderbrook Community Health CIC and this posting can be found online, then write the assessment.
| | |
|---|---|
| **Decision snapshot** | |

**Yes, this is worth applying for. Status: `go`.** R1 and R2, the hard gates, are met as you've stated them. The gaps are things to prepare for, and none of them blocks an application.

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3, R4, R6, R7 · adjacent: R5 (Catheter and continence care) · unclear: R8 (Clear, timely written records)
- `important`: adjacent: R9 (Leg-ulcer care), R12 (small caseload of your own) · unclear: R10 (End-of-life visits), R11 (care planning)
- `preferred`: absent: R13 (Doppler assessment)

R12: a credible bridge, its limit named; R8, R10, R11: the CV is silent, one answer each; R13: the one gap with no evidence behind it, and the one the posting marks desirable only.

**Opportunity ledger.** Mostly sound. The pay is stated (RR4), the caseload is supported by a senior nurse (RR1), and the employer exists as described (RR2). Two things are open: I couldn't find the posting on the employer's own careers page (RR2), and the posting is silent on caseload size and rota (RR3).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** the NMC register or your driving record not matching what you've told me (R1, R2); the posting turning out not to be live (RR2); or terms on caseload, rota or pay (RR3, RR4) that you can't accept.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC runs adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract. Founded 2015, 410 staff, four locality hubs | `[grounded]` company About page |
| Role | Band 5 community staff nurse on a district nursing team: housebound adults at home, wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin, care planning, all on an electronic patient record | `[grounded]` posting |
| Structure | A small caseload of your own, supported by a senior community nurse | `[grounded]` posting |
| Essentials | Current NMC registration (Adult), full UK licence (pool cars provided), at least one year post-registration, clear and timely records. Doppler is desirable only | `[grounded]` posting |
| Hiring contact | Rhiannon Mabbott leads the Halifax district nursing team, after eleven years as a district nurse. At the 2025 community nursing forum she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` forum speaker page |
| Scope read | A supported entry post into district nursing rather than a senior autonomous one | `[inferred]` from "small caseload" and "supported by a senior community nurse" |
| Pay | £31,050–£37,800 plus mileage | `[grounded]` posting |
| Market calibration | A 2026 pay survey of community Band 5 nurses in England (n=1,240) gives a median basic of £34,300 and an interquartile range of £32,400–£36,600. This posting's range spans that interquartile range and runs wider on both sides. The survey is a band to expect, not this employer's offer | `[generic]` Wardround 2026 pay guide; `[grounded]` posting for the range |
| Unknowns | Caseload size, visits per day, weekend and on-call rota, which EPR system, what Doppler training is offered, where in the range new starters sit | — |
| Contradictions | None between the posting and the About page. The posting itself wasn't found on a careers page (RR2) | `[grounded]` About page; careers address tried and not found |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration, Adult Nurse | hard_gate | direct | medium | none | You state registration as an Adult Nurse is active, revalidation due March 2028. Stated, not checked | `[grounded]` CV | You check your entry on the NMC register before applying |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | You state a full UK licence, category B. Stated, not checked | `[grounded]` CV | You check your licence status on your DVLA driving record |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward. A length of experience, so not a gate | `[grounded]` CV | none |
| R4 | Wound care | must_have | direct | medium | none | CV states wound care including pressure ulcers and surgical wounds | `[grounded]` CV | none |
| R5 | Catheter and continence care | must_have | adjacent | medium | transferability | CV states catheter care. Continence care beyond catheters isn't stated, so the row takes the lower reading | `[grounded]` CV states catheter care only | See G2 |
| R6 | Insulin administration | must_have | direct | medium | none | CV states insulin administration | `[grounded]` CV | none |
| R7 | Caring for housebound adults in their own homes | must_have | direct | medium | none | 18 months seconded to the discharge-to-assess team, visiting patients at home in their first week after discharge. Limit: first-week post-discharge patients, not a long-term housebound caseload | `[grounded]` CV | E1: lead with it |
| R8 | Clear, timely written records on an electronic patient record | must_have | unclear | low | discovery | The CV says nothing about records or any record system. Acute ward nursing involves documentation, but the CV doesn't establish it | `[grounded]` CV silence; `[generic]` that ward nursing involves documentation | See G1 |
| R9 | Leg-ulcer care | important | adjacent | low | transferability | Wound care is stated, but nothing on leg ulcers or compression. Wound care carries over; leg-ulcer assessment and compression weren't stated | `[grounded]` CV states wound care only | See G6 |
| R10 | End-of-life visits | important | unclear | low | discovery | CV silent on end-of-life care | `[grounded]` CV silence | See G3 |
| R11 | Care planning | important | unclear | low | discovery | CV silent on care planning | `[grounded]` CV silence | See G3 |
| R12 | A small caseload of your own | important | adjacent | medium | transferability | You've never held your own caseload. Home visits in the discharge-to-assess role are the adjacent evidence. Limit: you haven't carried a caseload, and the posting says it is supported by a senior nurse | `[grounded]` your statement and CV; `[inferred]` that the support is the posting's answer to this gap | See G5 |
| R13 | Doppler assessment (desirable) | preferred | absent | none | capability | You've never done one. No adjacent evidence | `[grounded]` your statement | Closure path in G7 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Records on an EPR (R8, must_have) | discovery | The CV is silent on documentation and on any record system | A must-have the posting words as "clear, timely written records", so a concrete example answers it directly | Ward electronic observation or notes systems; discharge summaries or home-visit notes in the D2A role; an audit of your records | An audit result or a reference, if you have one | `[grounded]` CV silence; `[generic]` that employers screen this by example |
| G2 | Continence care beyond catheters (R5, must_have) | transferability | Catheter care is stated; continence assessment or bladder and bowel care isn't | Closes the one must-have currently below `direct` for a stated reason | Continence assessments, bladder scanning, bowel care plans, catheter changes or trials without catheter | A competency sign-off | `[grounded]` CV |
| G3 | End-of-life visits and care planning (R10, R11, important) | discovery | The CV says nothing on either; an acute medical ward often sees both | Two important rows, and both are in the posting's duties | Anticipatory medicines, end-of-life care plans, rapid discharge home to die, family conversations, ward or D2A care plans | A care-plan template you used, an EoL training certificate | `[inferred]` from the acute medical setting; `[generic]` that these are common there |
| G5 | Never held a caseload (R12, important) | transferability | The D2A visits are adjacent. A caseload means ongoing responsibility for patients, which you haven't held | The posting builds in senior support, so this is a limit to state, not a blocker | Planning your own day of visits, escalation decisions made alone in D2A | A D2A reference | `[inferred]` from the posting's support wording |
| G6 | Leg-ulcer care (R9, important) | transferability | Wound care is stated; leg-ulcer care isn't | Named in the duties, so it will come up | Compression bandaging, ankle-brachial assessment seen or assisted, leg-ulcer patients on the ward | A training record | `[grounded]` CV |
| G7 | Doppler (R13, preferred) | capability | No evidence. Desirable only | Not required, but easy to raise in the informal chat | A Doppler course or supervised practice in post. Rhiannon Mabbott has spoken on Doppler training for staff new to community work | A course place or a supervised-practice plan | `[grounded]` forum page; `[inferred]` that training is likely on offer |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Supported caseload | positive_signal | — | "supported by a senior community nurse" | A supervised starter caseload is a realistic scope for your experience | `[inferred]` from the posting's wording | Who is the senior nurse, and how often would we review my caseload together? | noted |
| RR2 | Posting not found on the careers page | unknown | — | "Community Staff Nurse, Band 5 — Calderbrook Community Health CIC, Halifax" | The employer matches its About page. The one careers address I tried returned no page, and a search showed no listing. That fits a different careers URL, a stale posting, or a search limit | `[grounded]` About page found, careers address returned no page; `[generic]` that a missing listing has several ordinary causes | Is this post still open, and where is it listed on your site? | unresolved |
| RR3 | Caseload size, rota and visits are unstated | unknown | — | "You will hold a small caseload of your own" | The posting doesn't say how many patients, how many visits a day, or whether weekends or on-call are included | `[grounded]` posting silence | How many patients make up the starting caseload, what does a typical day look like, and is there a weekend rota? | unresolved |
| RR4 | Pay stated | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The posting gives a range, and it sits around the market band | `[grounded]` posting; `[generic]` survey band | Where in the range do new starters usually join? | noted |

## Application plan

Every row below, and the prose under it, is proposed, pending your approval. Nothing is final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with the discharge-to-assess secondment: "Seconded for 18 months to the discharge-to-assess team, visiting patients at home in their first week after discharge." Each clause traces to your own sentence | R7, the posting's core activity. `resume_edits_pending_approval` | `[grounded]` CV | pending your approval |
| A1 | Use the informal chat with Rhiannon Mabbott to ask about Doppler training, caseload size and the starting support. Say plainly that you haven't held a caseload or done a Doppler assessment | R12, R13, RR3 | `[grounded]` posting and forum page | pending your approval |
| A2 | Confirm the post is live on Calderbrook's own site before spending effort on the application | RR2 | `[grounded]` RR2 | pending your approval |
| A3 | Before applying, check your NMC register entry and your DVLA driving record yourself | R1, R2 | `[grounded]` CV | pending your approval |

On positioning (pending your approval): stay with what you have. Lead with the home-visiting experience and the five years on the ward, and name the two limits yourself, no caseload and no Doppler. Don't describe your D2A work as district nursing, and don't claim leg-ulcer, end-of-life or care-planning experience unless you can say what you did.

## Evidence status

Verified: none yet. Every claim above comes from your CV and your message, and none has been confirmed by an inspectable record. Your NI number isn't needed for this and I haven't used it. It's worth leaving it out of anything you paste into a chat.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Calderbrook Community Health careers Community Staff Nurse Band 5 district nursing", both returning "About Calderbrook Community Health" (calderbrookhealth.example/about). Fetched calderbrookhealth.example/careers: no page at that address. Moved the organization row and RR2 |
| 2. Role-family sweep | yes | Searched "community staff nurse band 5 district nursing salary Calderdale Agenda for Change 2026", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved the market calibration row and RR4 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Moved the hiring contact row, A1 and G7 |

## Dossier offer and upgrade menu

I can save all of this as `tuesday-dossier.md` if you'd like to keep it or carry it into later steps.

- A line on your records and the system you used, or an audit result → R8 to `medium` or better, G1 closes.
- Your continence and end-of-life experience, or a competency record → R5 moves toward `direct` and R10 and R11 firm up.
- A leg-ulcer or compression training record → R9 and G6.
- Calderbrook's own listing, or the recruiter's reply on the post → RR2 closes.
- The caseload size, rota and starting pay point from the informal chat → RR3 and RR4 close.
- Your current pay and any hard limits (travel, shifts, weekends) → pay and schedule checks against the role, currently unknown.
- A deeper research pass on Calderbrook (inspection reports, leadership changes, staff reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

## Questions

G1: Where have you written patient notes on an electronic system, in ward or D2A work, and do you have an audit result or a reference to show for them?

G2: Beyond catheter care, have you done any continence work, such as assessments, bladder scanning or bowel care plans?

G3: Have you looked after anyone at the end of life, or written a care plan for a patient going home? What was your part?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.