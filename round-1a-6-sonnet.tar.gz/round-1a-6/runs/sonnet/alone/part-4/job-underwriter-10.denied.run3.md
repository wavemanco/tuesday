I'll read the reference files the skill points to before building the assessment.
**Decision snapshot**

**Yes, take the call. Whether Fernquay is legit, I can't establish from here. Nothing you've pasted asks you for money, documents or personal details. Status: `conditional_go`**, because RR1 (employer not established) caps it and R2 (pay against your floor) is unconfirmed.

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Salary €52,000–€60,000 plus equity)
- `must_have` — direct: R3, R4, R5, R8 · adjacent: R6 (research calls with school owners), R7 (own the booking flow end to end)
- `important` — adjacent: R9 (first designer, no design peers)

R2 — your floor was not given; R6 — usability sessions with customers bridge to owner calls, limit named; R7 (`medium`) — checkout is part of a booking flow, not the whole of one; R9 — you have not been the only designer.

**Opportunity ledger.** The employer is not established from here (RR1), and the equity terms (RR3), funding and runway (RR4) and design review (RR2) are unstated. On the other side, the posting is specific about pay, working pattern and scope (RR5).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Fernquay verifies through its own website and the invite's sender domain — RR1; (2) the band meets your pay floor — R2; (3) the equity terms are explained — RR3; (4) you present R7 and R9 as adjacent, never as end-to-end or sole-designer experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, booking software for sea-kayak and surf schools. This is the posting's description, not independently established | `[grounded]` posting header |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship alongside two engineers | `[grounded]` posting |
| Working pattern | Hybrid, two days a week at the Galway office, the rest flexible | `[grounded]` posting |
| Compensation | €52,000–€60,000 plus 0.5–1% equity. The equity terms are not stated | `[grounded]` posting |
| Process so far | A WhatsApp message from "Ronan", naming the posting's co-founder, asks for a 45-minute video call with him and the CTO, Saoirse. A calendar invite was emailed | `[grounded]` your message |
| Scope read | A broad solo design mandate for a six-person company. It covers flow design, research and shipping, with one named working relationship and no design peer | `[inferred]` from "first designer" and the posting's list of duties |
| Market calibration | Not run, so the band is not set against role-family norms and the figure is the posting's own. The upgrade menu says what would calibrate it | `[grounded]` posting figure; no market claim made |
| Unknowns | Your pay floor; first-90-days outcomes; funding and runway; equity terms; who sets product priorities; who reviews design work | — |
| Contradictions | None between the posting and the message on Ronan Kehoe's name and role. Saoirse is named only in the message, so I can't cross-check her | `[grounded]` both sources as you pasted them |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week at the Galway office | hard_gate | direct | medium | none | You live in Galway, so the location is met. Your own view of two office days was not stated, and your applying suggests it is acceptable | `[grounded]` your background; `[inferred]` acceptance from your applying | Confirm in the call that the two days are fixed |
| R2 | Salary €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | The band is stated, but you have not given a floor or a view on the equity, so nothing settles it | `[grounded]` posting figure; no candidate statement | G1 |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company, self-reported and not yet inspectable | `[grounded]` your background | Portfolio or CV to raise to high |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" is confirmed but specific only as to frequency. The checkout case study they say they saw is the inspectable artifact | `[grounded]` your background | Share the case study or a sanitized Figma file |
| R5 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. Usability testing is one kind of research, and the owner calls are R6 | `[grounded]` your background | Portfolio write-up of a session round |
| R6 | Research calls with school owners | must_have | adjacent | medium | transferability | Customer usability sessions carry over. The limit is that you have not said you spoke with business owners about how they run their work | `[grounded]` your background; `[inferred]` the limit from what you did not mention | G3 |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned a checkout flow. Checkout is one stage of booking, and your scope within that redesign is not detailed. Limit: breadth beyond checkout is unestablished | `[grounded]` your background; `[inferred]` limit from the task wording | G2 |
| R8 | Work directly with engineers, shipping alongside two | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your background | none |
| R9 | First designer: no design peers, you set the process | important | adjacent | medium | transferability | Redesigning a flow and running monthly sessions carry over, but you say you have never been the only designer, so sole-designer work is unevidenced | `[inferred]` requirement from "first designer"; `[grounded]` your statement | Name this honestly in the call (A4) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay and equity against your floor (R2, hard_gate) | hard_gate | The band is stated; your floor is not | A gate not established stays visible and decides whether the conditions can clear | — | Your own floor; their budgeted figure | `[grounded]` posting; no candidate statement |
| G2 | End-to-end booking flow (R7, must_have) | transferability | A confirmed checkout redesign; no detail on what you owned or the stages beyond it | R7 is a `must_have` row at `adjacent`, and a clearer ownership account narrows it | Owning research through handoff on checkout; designing availability or search; owner-side scheduling or admin screens | A sanitized case study, flow diagram or before/after screens | `[grounded]` your background silence on scope; `[generic]` that a first designer's scope is probed on breadth |
| G3 | Research with business owners (R6, must_have) | transferability | Customer usability sessions only | The posting's research is with school owners, a different audience from consumers | Calls with partners, suppliers or business customers; stakeholder interviews inside your company | A discussion guide, session notes or a findings summary | `[grounded]` your background; `[generic]` that audience differences get probed |
| G4 | Sole-designer experience (R9, important) | transferability | Nothing stated; you said you haven't been the only designer | A limit to name rather than hide | Setting up a design process, review habit or component library alone, even inside a squad | A short description of what you set up yourself | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools." | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one; `[grounded]` you report finding little online | Where is this role listed on your own website or careers page, and where is Fernquay registered? | unresolved |
| RR2 | No design peer or reviewer | unknown | — | "You would be our first designer" | The role may carry the whole design function with priorities resting on the co-founder | `[inferred]` from "first designer" and the one named working relationship | Who sets product priorities, and who reviews design work in practice? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | A percentage range does not show what the equity would be worth: instrument, vesting, cliff, strike and dilution are absent | `[inferred]` from the posting giving a range and no terms | Is the equity shares or options, and what are the vesting, cliff, strike price and current share count? | unresolved |
| RR4 | Funding and runway unstated | unknown | — | "We are six people in Galway" | A salary band and a hiring plan rest on funding the posting doesn't describe | `[inferred]` from the posting's silence | How is Fernquay funded, and how many months of runway does the current plan cover? | unresolved |
| RR5 | Pay, working pattern and scope stated up front | positive_signal | — | "Salary €52,000–€60,000 plus 0.5–1% equity. Hybrid: two days a week at our Galway office" | The posting is specific on terms most postings withhold | `[grounded]` posting | Is the band final, or placed by experience? | noted |

## Application plan

Everything here is proposed and nothing is applied. Each row, the prose lines included, is pending your approval.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, find Fernquay's own website and any careers page, and check the role is listed there. Check that the invite email came from an address on that website's domain. Use contact details from the site for any check, not the WhatsApp thread | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | WhatsApp for scheduling a video call is routine, and this message asks for nothing but a time. If anything later asks for payment, an ID or bank details before a written offer, stop and check with them through their website | Your question about the WhatsApp contact | `[generic]` how small firms commonly schedule; `[grounded]` the message as pasted | pending your approval |
| A3 | Ask RR1 to RR4 verbatim in the call, and ask whether the band is final (RR5) | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A4 | Positioning line, spoken or written: "I redesigned our checkout flow at a travel-booking company and ran monthly usability sessions with customers, working in a squad with four engineers. I haven't been the only designer before." Every clause traces to what you wrote; it makes no claim of owning the whole flow | see R7, R9 | `[grounded]` your background | pending your approval |
| W1 | Bring one sanitized walkthrough of the checkout redesign, flaws included, as a work sample. Strip confidential detail from your employer's material | The posting says they would "rather see one messy real project than a polished deck" | `[grounded]` posting quote; R4, R7 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Sent "Fernquay booking software sea kayak surf schools Galway"; refused. It would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | Sent "Product Designer salary Ireland startup Galway first designer Figma"; refused. It would have moved the market calibration row and the pay check on R2 |
| 3. Hiring manager's public footprint | unavailable | Ronan Kehoe is named, but search was refused, so no query was sent. It would have moved role reality's scope read and A4's choice of lead story, limited to his public professional footprint |

If you'd like, I can save this as `tuesday-dossier.md` so a later step can pick it up.

## Upgrade menu

- Search permission, or Fernquay's website and careers page pasted in → target 1 runs or is read, RR1 reduces or confirms, and role reality's organization row firms up.
- Search permission → target 2 runs and R2 can be set against a researched band.
- A portfolio link or sanitized Figma file of the checkout redesign → R4 and R7 move toward `high`.
- Your pay floor and equity view → R2 settles.
- The domain of the invite email's sender, set against the domain on Fernquay's website → RR1 reduces on one check.
- A deeper research pass on Fernquay (funding, leadership, public reports; up to 5 more searches and 2 more fetches) → say the word and it runs once search is permitted.

**Questions**

G1 — Is €52,000–€60,000 plus 0.5–1% equity at or above the pay you would accept?

G2 — On the checkout redesign, what did you personally own (research, flows, UI, handoff), who else designed on it, and did any booking stage beyond checkout (search, availability, owner-side screens) ever fall to you?

G3 — Have you ever spoken with business owners rather than consumers about how they run their work? If so, who, how many, and what changed because of it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.