I'm reading the skill's reference files on risk, decision and research accounting, so the assessment follows its format. Then I'll write it up.
# Job Underwriting Assessment: Payroll Administrator at Marrowgate Housing

## Decision snapshot

**Yes, it's normal. After a written offer, an employer asking for bank details, PPS number and a passport scan is routine onboarding, and the job looks worth accepting on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (right to work in Ireland), R2 (two office days a week in Limerick)
- `must_have` — direct: R3, R5, R6 · adjacent: R7 (monthly payroll for 240 staff) · unclear: R4 (Irish PAYE, PRSI, USC)
- `important` — direct: R8, R9 · unclear: R10 (answering staff queries) · absent: R11 (pension changes)

R7 — a credible step up in scale, its limit named; R11 — a learnable gap, not yet closed; R4 — likely met, waiting on your confirmation.

**Opportunity ledger.** The offer matches the ad on role, pay, hybrid pattern and reporting line (RR1). Two things are still unknown: the written contract terms (RR2) and the support you'd get on pension changes (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (right to work in Ireland), R2 (two office days a week in Limerick); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you see the full written contract before accepting, as in RR2; (2) your hotel-group payroll was run under Irish PAYE, PRSI and USC, as in R4; (3) there is a named route to learn pension changes, as in R11 and RR3.

**On "never hand these over":** that rule protects you from requests made *before* an offer, or by someone you can't place. Here you had two in-person interviews at their office, and the request comes after a written offer that names the role and pay. This is the usual order. They need your bank details to pay you, your PPS number to register you with Revenue, and your passport for the identity and right-to-work check `[generic]`. The one check worth making is below, in A1.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick, about 240 staff. I couldn't check it online. What supports it is your two in-person interviews at their office. | `[grounded]` ad and offer as you pasted them; `[grounded]` your account of the interviews |
| Mandate | Run monthly payroll; process starters, leavers and pension changes; reconcile payroll to the general ledger monthly; answer staff queries | `[grounded]` ad |
| Offer against ad | The same role, €40,000 inside the advertised €38,000–€42,000, permanent, hybrid with two office days, reporting to Declan Garvagh, Finance Manager, start after your notice | `[grounded]` ad and offer agree |
| Onboarding steps | After you accept, a portal link to add bank details, PPS number and a passport scan; original passport on day one | `[grounded]` offer; `[generic]` that these are standard post-offer steps |
| Scope read | One administrator post for 240 staff. The ad doesn't say whether there is a team, a backup or who handles pensions today | `[inferred]` from the ad's silence |
| Market calibration | Not done: the pay search was refused, so €40,000 is not compared with a market band | `[grounded]` evidence status below |
| Unknowns | Contract terms (probation, hours, leave, pension scheme); payroll software; who covers you; the start date | — |
| Contradictions | None between ad and offer | `[grounded]` both texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Right to work in Ireland (the offer's passport check) | hard_gate | unclear | low | hard_gate | You haven't stated your status. You hold a passport, but I don't know which one. | `[grounded]` offer text; status not given | Answer the constraints question below |
| R2 | Two days a week in the Limerick office | hard_gate | unclear | low | hard_gate | The term is clear. Whether it suits you wasn't stated, though you attended two interviews there. | `[grounded]` ad and offer; your constraints not given | Answer the constraints question below |
| R3 | 2+ years running payroll | must_have | direct | medium | none | Three years of fortnightly payroll for 90 staff exceeds the threshold. It is your account, with no artifact. | `[grounded]` your account | none |
| R4 | Working knowledge of Irish PAYE, PRSI, USC | must_have | unclear | low | discovery | You didn't say which country's rules the hotel payroll followed. A certificate and three years make it likely. | `[grounded]` your account, jurisdiction silent | See G1 |
| R5 | Strong Excel | must_have | direct | medium | none | Daily use, pivot tables and XLOOKUP is specific. | `[grounded]` your account | none |
| R6 | Payroll qualification or working towards one | must_have | direct | medium | none | A Payroll Technician certificate from 2024 meets it. A copy would raise the confidence to `high`. | `[grounded]` your account | Keep a copy to hand |
| R7 | Run monthly payroll for 240 staff | must_have | adjacent | medium | transferability | You ran fortnightly payroll for 90 staff and the monthly close and reconciliation. The step up is a monthly cycle at about two and a half times the headcount. | `[inferred]` from your fortnightly payroll and monthly reconciliation | See G2 |
| R8 | Process starters and leavers | important | direct | medium | none | Stated directly. | `[grounded]` your account | none |
| R9 | Monthly payroll-to-ledger reconciliation | important | direct | medium | none | Stated directly. | `[grounded]` your account | none |
| R10 | Answer staff payroll queries | important | unclear | low | discovery | Your summary is silent. Payroll roles usually involve queries, so it may simply be unmentioned. | `[grounded]` your account silent; `[generic]` pattern | See G4 |
| R11 | Process pension changes | important | absent | none | capability | You said your manager handled these and you have never done them. | `[grounded]` your account | See G3 and RR3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Irish payroll rules (R4, must_have) | discovery | Payroll experience and a certificate. Jurisdiction not stated. | It's a must-have, and this is the likeliest interview probe | Revenue payroll submissions, USC and PRSI treatment in your payslips, cert modules covering them | Cert syllabus; a payslip layout with names removed | `[inferred]` from your context; `[generic]` that it's likely to be probed |
| G2 | Monthly cycle at 240 staff (R7, must_have) | transferability | Fortnightly at 90 plus a monthly reconciliation | The scale and cycle are what differs | Any monthly-paid salaried staff you ran; your group's run sizes | A payroll calendar; headcount per run | `[inferred]` from your fortnightly payroll |
| G3 | Pension changes (R11, important) | capability | Never done hands-on | The role names it, and no one yet covers it for you | Preparing or checking inputs for your manager; pension deductions you processed in runs. Count these only if true. | A sanitized checklist of steps you've seen | `[grounded]` your account |
| G4 | Staff payroll queries (R10, important) | discovery | CV silent | It's part of the day-to-day role | Payslip queries at the hotel group | None needed | `[inferred]` from the silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Offer matches the ad on role, pay, hybrid pattern and reporting line | positive_signal | — | "permanent post of Payroll Administrator at €40,000 a year, reporting to Declan Garvagh" | The role is as advertised | `[grounded]` ad against offer | Can the People Team confirm the portal link is theirs? | noted |
| RR2 | Contract terms not yet seen | unknown | — | "reply to accept within five working days" | You may be asked to accept before seeing probation, hours, leave and pension terms | `[inferred]` from the offer's silence on them | Can you send the full contract before the acceptance date? | unresolved |
| RR3 | Support for the pension-change duty | unknown | — | "process starters, leavers and pension changes" | One administrator for 240 staff may have no one to learn pensions from | `[inferred]` from the ad's silence on team and handover | Who handles pension changes now, and what training or handover is there? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before entering anything, find the People Team's phone number or email on marrowgatehousing.ie, typed in yourself. Check the portal link with them. Submit the details only through the portal address their own site gives, never by replying to an email. | A routine step still warrants one check | `[generic]` onboarding practice | pending your approval |
| A2 | Ask for the contract in writing and put RR2's question before you accept. Your five working days is enough time. | See RR2 | `[grounded]` offer deadline | pending your approval |
| A3 | Ask RR3's question, and accept once you've heard a plan for learning pension changes. Say plainly that you haven't done them hands-on. | See R11, RR3 | `[grounded]` R11 row | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches "Marrowgate Housing Limerick housing association" and "Marrowgate Housing careers Payroll Administrator Limerick" were refused. It would have moved the organization row and whether the ad is live. |
| 2. Role-family sweep | unavailable | Search "payroll administrator salary Ireland Limerick 2026" was refused. It would have moved market calibration against €40,000. |
| 3. Hiring manager's public footprint | unavailable | Search "Declan Garvagh Finance Manager Marrowgate Housing" was refused. It would have moved the scope read. |

## Next steps

I can write all of this into `tuesday-dossier.md` if you'd like to keep it.

**Upgrade menu**
- Your answer on Irish rules → R4 and G1 close.
- Any pension work you prepared or checked → R11 narrows.
- A copy of your certificate → R6 to `high`.
- Search access → targets 1–3 run. It would check that the employer and ad exist online and calibrate the pay. A deeper pass would add up to 5 more searches and 2 more fetches.

**Questions** (answer in a line each, or say skip)
1. **R4:** Was the hotel payroll run under Irish PAYE, PRSI and USC?
2. **R11:** Have you prepared, checked or processed any pension changes at all, or only watched your manager?
3. **R1, R2:** Is there anything non-negotiable I haven't covered, such as your right-to-work status, a pay floor, or the commute for two office days?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.