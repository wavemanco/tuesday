Checking whether Marrowgate Housing shows up as a real employer, and what €40k means for this role. Running both searches now.
**Yes, it's normal.** A written offer from the company's own address that follows two in-person interviews, then asks for bank details, PPS number and right-to-work ID, is routine onboarding for a permanent job. Your "never hand those over" rule is right for requests made before an offer. Status: `conditional_go`, on the conditions below.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Hybrid, two days in Limerick), R2 (Salary €38,000–€42,000)
- `must_have` — direct: R3, R5, R6, R7 · unclear: R4 (Irish PAYE, PRSI, USC)
- `important` — direct: R9 · adjacent: R10 (240 staff) · unclear: R11 (staff payroll queries) · absent: R8 (pension changes)

R4 — the one most worth confirming; R8 — hands-on pension changes not yet done, by your own account; R10 — a credible bridge, its limit named.

**Opportunity ledger.** Consistent with the ad and the in-person process (RR2). The employer has not been confirmed from outside sources (RR1), the contract terms are not yet in writing (RR3), and pension-change handover is unclear (RR4). The portal request takes no entry because it is routine.

- **Hard gates:** none failed; unconfirmed: R1 (Hybrid, two days in Limerick), R2 (Salary €38,000–€42,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) Marrowgate is confirmed through its own website, and the portal link sits on its domain — RR1; (2) R1 and R2 meet your own minimums; (3) the written contract arrives before you resign — RR3; (4) the pension-change gap is stated openly and a handover agreed — R8, RR4.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick; its existence is not yet confirmed outside your documents | `[grounded]` ad and offer text, as you pasted them |
| Mandate | Monthly payroll for 240 staff, starters, leavers and pension changes, monthly payroll-to-ledger reconciliation, staff payroll queries | `[grounded]` ad |
| Offer terms | Permanent, €40,000, hybrid with two days in the Limerick office, reporting to Declan Garvagh, Finance Manager; accept within five working days | `[grounded]` offer email |
| Match to the ad | Title, location, hybrid pattern and pay all agree, and €40,000 sits inside the advertised €38,000–€42,000 | `[grounded]` ad compared with offer |
| Process | Two in-person interviews at their office, then an offer from people@marrowgatehousing.ie | `[grounded]` your account; the sender domain matches the firm's name, and I could not check who controls it |
| Market calibration | Not established: the pay-band search did not run, and I won't give a band from memory | `[grounded]` search unavailable |
| Unknowns | Probation, notice period, pension scheme, leave; whether you would be the only payroll person; who handles pension changes today | — |
| Contradictions | None between the ad and the offer | `[grounded]` both texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in the Limerick office | hard_gate | unclear | none | hard_gate | I don't know your commute or constraints; the term itself is stated clearly | `[grounded]` ad and offer; your constraints not given | G3 question |
| R2 | Salary €38,000–€42,000 (offered €40,000) | hard_gate | unclear | none | hard_gate | The offer is inside the band, but I don't know your minimum | `[grounded]` ad and offer; your floor not given | G3 question |
| R3 | 2+ years running payroll | must_have | direct | medium | none | 3 years of fortnightly payroll for 90 staff, as you state it | `[grounded]` your account | a reference or payslip-run sample would raise it |
| R4 | Working knowledge of Irish PAYE, PRSI, USC | must_have | unclear | low | discovery | Your background doesn't say whether the hotel payroll was Irish or what you applied hands-on | `[grounded]` silence in your account | G1 question |
| R5 | Payroll qualification or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024; the certificate itself isn't seen | `[grounded]` your account | the certificate would raise it |
| R6 | Process starters and leavers | must_have | direct | medium | none | Stated as part of your hotel role | `[grounded]` your account | none |
| R7 | Monthly payroll-to-ledger reconciliation | must_have | direct | medium | none | Stated; your payroll was fortnightly, the reconciliation monthly | `[grounded]` your account | none |
| R8 | Pension changes | important | absent | medium | discovery | You say your manager handled these. Related exposure, such as deductions in your runs, hasn't been asked | `[grounded]` your account | G2 question |
| R9 | Strong Excel | important | direct | medium | none | Daily use, pivot tables and XLOOKUP | `[grounded]` your account | none |
| R10 | Run monthly payroll for 240 staff | important | adjacent | medium | transferability | Real payroll ownership at 90 staff, fortnightly. Limit: you haven't run this headcount or a monthly cycle end to end | `[inferred]` from your described scope | name the limit if asked |
| R11 | Answer staff payroll queries | important | unclear | low | discovery | Your background is silent; it is likely part of any payroll role, but I haven't assumed it | `[grounded]` silence in your account | none yet, lower priority |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Irish PAYE, PRSI, USC (R4, must_have) | discovery | Hotel payroll and a 2024 certificate, with no jurisdiction or hands-on tax work stated | It is a must-have, and Irish tax rules are the core of this job | Applying tax credits and cut-offs, PRSI classes and USC rates; submitting payroll returns to Revenue; year-end reconciliations; Irish modules in your certificate | The certificate's module list, a sanitised payslip layout | `[grounded]` background silence; `[inferred]` that Irish exposure is likely given an Irish certificate and employer |
| G2 | Pension changes (R8, important) | discovery | You say your manager handled them; nothing on adjacent exposure | It is a named duty and may be expected from week one (RR4) | Processing pension deductions each run; handling joiner enrolments or opt-outs; reconciling pension payments to the ledger | A run checklist or a procedure note | `[grounded]` your statement; `[inferred]` that it matters early |
| G3 | Your minimums on location and pay (R1, R2, hard gates) | discovery | The terms are known; your limits aren't | A hard gate you can't meet outranks everything else here | Commute time and cost; your current pay and the lowest you'd accept | none needed | `[grounded]` constraints not given |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not yet established from attributable sources; no search ran | risk_signal | medium | "Marrowgate Housing, a housing association in Limerick" | The entity may be too new or small to have a footprint, a listing may be stale, or something else may be unresolved; I have no evidence which | `[generic]` pattern for small employers, not a claim about this one | Which web address should the onboarding portal sit under? | unresolved |
| RR2 | Offer matches the ad and followed in-person interviews | positive_signal | — | "permanent post of Payroll Administrator at €40,000 a year, reporting to Declan Garvagh, Finance Manager" | The role is concrete and consistently described | `[grounded]` ad and offer compared | Who covers payroll when you are away? | noted |
| RR3 | Contract terms absent from the offer email | unknown | — | "starting on a date we agree once your notice period ends" | Probation, notice, pension scheme and leave may follow in a contract | `[inferred]` from the email's silence | Can I have the written contract and terms before I give notice? | unresolved |
| RR4 | Pension-change ownership and handover unclear | unknown | — | "process starters, leavers and pension changes" | These may be expected from day one with no one to hand over | `[inferred]` from the ad's duty list against your experience | Who handles pension changes now, and what handover or training is there? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | When the portal link comes, check it sits on Marrowgate's own domain as shown on its website, or phone the number on that site. Enter the details only in the portal, never by reply email | RR1; the usual care step for onboarding | `[generic]` onboarding practice | pending your approval |
| A2 | Check R1 and R2 against your own minimums before you reply to accept | Hard gates, unconfirmed | `[grounded]` R1, R2 rows | pending your approval |
| A3 | Ask for the written contract before you give notice | RR3 | `[grounded]` RR3 | pending your approval |
| A4 | Tell Declan plainly that pension changes were your manager's, and ask for a handover | R8, RR4; states only what is true | `[grounded]` your statement | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | I tried "Marrowgate Housing Limerick housing association"; search permission was not granted, so nothing came back. It would have settled RR1 and the contradictions row |
| 2. Role-family sweep | unavailable | I tried "payroll administrator salary Ireland Limerick 2026"; refused the same way. It would have given the market calibration line |
| 3. Hiring manager's public footprint | unavailable | A name was given (Declan Garvagh), but no search went out after the refusal. It would have informed the scope read |

I can save this as `tuesday-dossier.md` if you'd like to keep it.

## Upgrade menu

- Permission to search → target 1 could clear RR1, and target 2 would add a pay band for R2.
- Answers to G1 and G2 → R4 and R8 firm up.
- Your minimums → R1 and R2 resolve, and the decision likely simplifies to `go` or `no_go`.
- The written contract → RR3 closes.
- The certificate's module list → R5 and R4 to `high`.

**Questions**

G1 — Was your hotel payroll Irish, and which parts of PAYE, PRSI and USC did you apply yourself, or was that your manager's?

G2 — Have you touched pension changes at all, even deductions or enrolments within your runs?

G3 — Do the two Limerick office days and €40,000 both meet your own minimums?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.