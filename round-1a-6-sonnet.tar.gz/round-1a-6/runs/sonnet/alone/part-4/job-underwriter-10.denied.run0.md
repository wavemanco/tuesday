I'll read the reference files the skill points to before building the assessment.
**Worth applying, and worth taking the call, once you've checked who Fernquay is. Status: `conditional_go`.** Nothing in the posting or the WhatsApp message asks you for money, bank details or ID. I couldn't verify the company myself, because my web searches were refused.

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: R2 (Salary €52,000–€60,000)
- `must_have`: direct: R3, R4, R5, R6 · adjacent: R7 (Own the booking flow end to end)
- `important`: adjacent: R8 (First and only designer)

R7: a credible bridge, its limit named; R8 (`medium`): you've never been the sole designer, so this is the stretch; R2: waiting on your pay floor.

**Opportunity ledger.** The employer can't be verified from here (RR1). The scope of a first-designer post is undefined (RR2), and the equity terms are unstated (RR3). Two entries run the other way: the pay range is stated openly (RR4), and the message refers to your actual checkout case study (RR5).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Fernquay verifies through its own website or careers page, and the invite comes from that domain (RR1). (2) The pay range clears your floor (R2). (3) The call answers what "first designer" means in practice (RR2, R8), and you frame the sole-designer gap honestly.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: six people in Galway, booking software for sea-kayak and surf schools; two engineers; co-founder Ronan Kehoe; CTO Saoirse named in the message | `[grounded]` posting and message, as you pasted them; not independently confirmed |
| Stage | Interview invited: a 45-minute video call with Ronan and Saoirse | `[grounded]` WhatsApp message |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship alongside the engineers | `[grounded]` posting |
| Pay and terms | €52,000–€60,000 plus 0.5–1% equity; hybrid, two days a week in the Galway office | `[grounded]` posting |
| First 90 days | Likely a redesign of the booking flow and your first rounds of owner research calls | `[inferred]` from "own the booking flow" and "run research calls" |
| Scope read | A broad solo post: strategy, research, UI and handoff all sit with one person, with no design peer named | `[inferred]` from "first designer" and the one-person remit |
| Market calibration | Not run. The searches were refused, so I give no salary band and no claim that this range is high or low | `[generic]` none available |
| Unknowns | Equity terms, who decides design questions today, whether Saoirse is one of the "two engineers", how the booking flow performs now | — |
| Contradictions | None between the posting and the message. Ronan is named as co-founder in the posting and signs the message | `[grounded]` the two texts you pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week at the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year, so the office days look workable. You haven't stated this as a constraint, so confidence is medium | `[grounded]` your background | none |
| R2 | Salary €52,000–€60,000 | hard_gate | unclear | none | hard_gate | The range is stated, but your floor isn't, so I can't say whether it meets your terms | `[grounded]` posting; your floor not given | Question R2 below |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company. Self-reported and plausible, with no artifact inspected yet | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | presentation | "Figma daily" is stated. A portfolio or case study would be the inspectable proof for design work | `[grounded]` your background | Share the case study or portfolio link |
| R5 | You have run your own user research | must_have | direct | medium | discovery | Monthly customer usability sessions match "run your own research". It's unclear whether you planned and synthesised them, and whether any were open interviews rather than usability tests | `[grounded]` your background; ownership detail not yet given | Question G2 below |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your background | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned the checkout flow, a core part of a booking flow. Limit: checkout is one stage, and the full journey (discovery, availability, owner-side set-up) isn't shown | `[grounded]` checkout redesign; `[inferred]` the end-to-end scope from "own the booking flow" | Bring the full journey context to the call |
| R8 | First and only designer | important | adjacent | medium | transferability | You've never been the only designer, and you said so. Adjacent work: you ran research and owned the checkout redesign inside a squad. Limit: no evidence of setting design direction alone | `[inferred]` requirement from "You would be our first designer"; `[grounded]` your background | Question G1 below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Solo design ownership (R8, important) | transferability | Strong squad-based design work. No stated stretch of working without design peers | It is the biggest scope difference between this post and your last one, and the call is likely to probe it | A feature you designed without review from another designer; a freelance or side project; a stretch covering for a departed designer | A case study showing decisions you made alone | `[grounded]` your own statement; `[generic]` that interviews for a first-designer post tend to probe it |
| G2 | Research ownership (R5, must_have) | discovery | Monthly usability sessions are stated, but not who planned them, ran them and wrote up the findings | The post has you running research calls with school owners alone | Writing the session plan; recruiting customers; synthesis docs; open interviews before a design existed | Session plans, synthesis notes or a findings deck (sanitised) | `[grounded]` your background silence on ownership |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "I can't find much about them online"; "six people in Galway" | The company may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who I'd be interviewing with? | unresolved |
| RR2 | Scope of a sole-designer post undefined | unknown | — | "You would be our first designer: own the booking flow end to end" | The post may carry the whole design function with no design standards, tooling or review in place | `[inferred]` from "first designer" against silence on existing design assets | What design assets and decisions exist today, and who has been making design calls so far? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | The percentage may come with vesting, strike price or share-class terms the posting doesn't show | `[generic]` equity offers at this stage commonly carry terms beyond the percentage | What are the vesting schedule, any strike price, and the current cap-table position? | unresolved |
| RR4 | Pay range stated openly | positive_signal | — | "€52,000–€60,000" | A stated range gives you something concrete to hold against your floor | `[grounded]` posting | Is the range fixed, or does it move with experience? | noted |
| RR5 | Message refers to your actual application | positive_signal | — | "we loved the checkout case study" | The sender knows what you submitted | `[grounded]` the message you pasted | Who else reviewed the case study, and what stood out? | noted |

Scheduling an interview by WhatsApp is routine when the interview itself is on video, so I've made no register entry for it. The check on it is advice and sits in the application plan (A1).

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, find Fernquay's website and careers page yourself (not through any link in the message) and check that the calendar invite came from an address on that domain | See RR1. Small companies often schedule by chat, so this is routine diligence | `[generic]` | pending your approval |
| E1 | Bring the checkout case study as your "one messy real project": the constraints, wrong turns and decisions, not a polished deck | The posting says they would "rather see one messy real project than a polished deck" | `[grounded]` posting and your case study | pending your approval |
| E2 | Describe your role as it was: you redesigned the checkout and ran monthly usability sessions in a squad, and you haven't been the sole designer. Add how you'd cover that | Keeps the claim at what you owned (R7, R8) | `[grounded]` your background | pending your approval |
| Q1 | Ask the questions from RR1, RR2 and RR3 verbatim in the call | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both searches were refused: "Fernquay booking software sea kayak surf schools Galway" and "Fernquay Product Designer Galway careers". Would have moved the organization row, RR1 and the contradictions row |
| 2. Role-family sweep | unavailable | The search was refused: "product designer salary Ireland startup Galway 3 years experience". Would have moved the market calibration row and a pay-versus-band check on R2 |
| 3. Hiring manager's public footprint | unavailable | The search was refused: "Ronan Kehoe Fernquay co-founder". Would have moved the scope read and which of your stories to lead with |

## Dossier offer

If you'd like a `tuesday-dossier.md` of this analysis to carry forward, say so and I'll emit it.

## Upgrade menu

- Permission to run the three refused searches would let me re-run targets 1–3 and update RR1, the market calibration and the scope read.
- A link to Fernquay's own site or careers page, or the sender domain of the calendar invite, would reduce or close RR1.
- Your salary floor and other non-negotiables would settle R2 and let the hard-gates line check against them.
- Your case study or portfolio link would raise R4, R5 and R7 toward `high`. Session plans or synthesis notes would raise R5.
- The equity terms, once asked, would close RR3.
- A deeper pass (up to 5 more searches and 2 more fetches on funding, hiring patterns and recent news) can run on your word.

## Questions

R2 — What's the lowest salary you'd accept, and is there anything else about these terms (office days, equity) you can't flex?

G1 — Have you ever made design decisions with no other designer to review them, such as a freelance job, a side project, or a stretch covering for someone? What did you decide alone, and what happened?

G2 — For your monthly usability sessions, who planned them, ran them and wrote up what you learned, and did any involve open interviews rather than testing an existing design?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.