I've read the skill's rules. Next I'm checking whether Marrowgate Housing is a real, attributable employer, and what payroll administrators in Ireland usually earn. Then I'll write up the assessment.
**Yes, that's routine. Asking for your bank details, PPS number and a passport check *after* you accept a written offer is normal onboarding, and your offer follows that pattern.** The rule you were taught is about handing these over *before* an offer, or to someone you can't place. Here you've had two in-person interviews at their office and a written offer from a company-domain address that names the role, pay, manager and hours. I could not check Marrowgate independently, because my web searches were refused (see Evidence status). Status: `conditional_go`.

# Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R10 (Salary €38,000–€42,000), R11 (Two office days a week in Limerick), R12 (Right to work in Ireland)
- `must_have` — direct: R1, R3, R4 · unclear: R2 (Irish PAYE, PRSI, USC)
- `important` — direct: R6, R8 · adjacent: R5 (Monthly payroll for 240 staff) · unclear: R9 (Staff payroll queries) · absent: R7 (Pension changes)

R7 — a real gap, which you've already named yourself; R5 — a scale bridge, its limit named.

**Opportunity ledger.** Sound on what you've shared: the offer is specific and matches the ad (RR1). The open items are who backs up the payroll function and who currently handles pension changes (RR2), contract terms beyond salary (RR3), and the independent check I could not run (RR4).

- **Hard gates:** none failed; unconfirmed: R10 (Salary €38,000–€42,000), R11 (Two office days a week in Limerick), R12 (Right to work in Ireland); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the pay and two office days meet your own terms — R10, R11; (2) you get a clear answer on pension-change support and cover — R7, RR2; (3) you have the full contract in writing — RR3.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick, about 240 staff | `[grounded]` ad; not independently checked (RR4) |
| Mandate | Monthly payroll, starters/leavers/pension changes, payroll-to-ledger reconciliation, staff queries; reports to Declan Garvagh, Finance Manager | `[grounded]` ad and offer |
| Pay | Offer of €40,000 sits at the midpoint of the ad's €38,000–€42,000 | `[grounded]` ad and offer |
| Onboarding requests | Bank details, PPS number and passport scan are requested after acceptance, via a portal link sent afterwards. Payroll departments ordinarily need these three things: an account to pay into, a PPS number to report pay to Revenue, and proof of right to work | `[grounded]` offer wording; `[generic]` what payroll ordinarily needs |
| Scope read | A full-cycle payroll post with one named reporting line; whether a team or backup exists is not stated | `[inferred]` from the ad and offer naming only the Finance Manager |
| Market calibration | Not run: the search was refused, so I have no market band for this title and pay | `[generic]` none available |
| Unknowns | Payroll software, who handles pension changes today, contract terms beyond salary | `[grounded]` absent from ad and offer |
| Contradictions | None between the ad and the offer on title, hybrid pattern, location or pay | `[grounded]` both texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 2+ years running payroll | must_have | direct | medium | none | 3 years of fortnightly payroll for 90 staff at a hotel group; self-reported, nothing inspected yet | `[grounded]` your background | none |
| R2 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | Your background doesn't say the hotel group's payroll ran under Irish rules; the Payroll Technician certificate (2024) suggests it may, but I can't tell from the text | `[inferred]` from the certificate and the Limerick role | confirm; see question R2 |
| R3 | Strong Excel | must_have | direct | medium | none | Daily use, pivot tables and XLOOKUP | `[grounded]` your background | none |
| R4 | Payroll qualification or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024; the certificate itself not inspected | `[grounded]` your background | none |
| R5 | Run monthly payroll for 240 staff | important | adjacent | medium | transferability | Your 90-staff run was fortnightly. The reconciliation was monthly, but a monthly pay run and 240 staff are untested. Limit: you haven't run payroll at that headcount or cycle | `[grounded]` your background; `[inferred]` the bridge | frame as adjacent; see RR2 |
| R6 | Process starters and leavers | important | direct | medium | none | Stated as part of your 3 years | `[grounded]` your background | none |
| R7 | Process pension changes | important | absent | none | capability | You've never done these yourself; your manager handled them. A named gap, not a gap in capability to learn | `[grounded]` your own statement | closure path: ask about training and handover; see RR2 |
| R8 | Monthly payroll-to-ledger reconciliation | important | direct | medium | none | You did exactly this at the hotel group | `[grounded]` your background | none |
| R9 | Answer staff payroll queries | important | unclear | low | discovery | Your background doesn't mention staff queries, though they are usual in payroll work | `[grounded]` silence in your background; `[generic]` that queries are usual | none; carried as minor risk |
| R10 | Salary €38,000–€42,000 (offer €40,000) | hard_gate | unclear | none | hard_gate | The offer is inside the band; you haven't stated a pay floor, so I can't say it meets your terms | `[grounded]` ad and offer | question on your constraints |
| R11 | Two office days a week, Limerick | hard_gate | unclear | none | hard_gate | The pattern is clear in the offer; your own commute or schedule limits weren't given | `[grounded]` ad and offer | question on your constraints |
| R12 | Right to work, checked by passport | hard_gate | unclear | none | hard_gate | The offer says they will run a right-to-work check; nothing you've shared states the outcome | `[inferred]` from the offer's onboarding paragraph | none; the check itself is routine |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Irish payroll rules (R2, must_have) | discovery | A payroll background and a 2024 certificate, with no statement that the work was under Irish PAYE, PRSI and USC | It is a `must_have` and the one fit row where the text leaves a real doubt | Running payroll through an Irish system; filing Revenue returns; processing PRSI classes; handling USC rate changes | A payslip layout, a payroll-system name, or the certificate's syllabus | `[grounded]` background silent on jurisdiction |
| G2 | Pension changes (R7, important) | capability | You've never done these yourself; your manager handled them | It is a named duty in the ad, and it would be yours alone if no one else covers it | Processing pension deductions inside a pay run; preparing a pension-change form for your manager to approve; reconciling pension contributions to the ledger | A procedure note or an anonymised sample you prepared | `[grounded]` your statement; `[generic]` that the duty may be learned on the job |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Offer states role, pay, manager and hours, after two in-person interviews | positive_signal | — | "we are delighted to offer you the permanent post of Payroll Administrator at €40,000 a year, reporting to Declan Garvagh, Finance Manager" | The terms are specific and match the ad, which suggests a defined role | `[grounded]` ad and offer | Can you confirm the hybrid pattern and start-date process in the contract? | noted |
| RR2 | Pension changes are in your duties, and the cover for them is unstated | unknown | — | "process starters, leavers and pension changes" | You may be the only payroll processor, with no one to learn the pension steps from | `[inferred]` from the offer naming only a Finance Manager above the post | Who handles pension changes today, and who covers payroll when I'm away? | unresolved |
| RR3 | Contract terms beyond salary are not in the offer email | unknown | — | "Please reply to accept within five working days." | Probation, pension scheme, leave and notice terms may sit in a separate contract | `[inferred]` from the email's silence on them | Can you send the full contract, including probation, pension scheme and notice terms, before I accept? | unresolved |
| RR4 | Independent check of the employer not run | unknown | — | "Marrowgate Housing, a housing association in Limerick" | The two office interviews make this unlikely to matter, but I could not check the organisation, the live posting or the sender's domain against public sources | `[inferred]` from your two in-person visits against my refused searches | Is this post listed on your own careers page? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Enter the bank, PPS and passport details only in the employer's own portal, reached at the address Marrowgate's own website gives, and don't send them by email or message | Routine onboarding is safest done where the employer controls the page; this is a check, not a doubt about the offer | `[generic]` good practice | pending your approval |
| P2 | Ask the RR2 and RR3 questions in writing before you accept, and get the contract before you give notice at your current job | Answers shape R7 and the conditions above | `[grounded]` register | pending your approval |
| P3 | If pension changes come up, say it plainly: you haven't run them yourself, your previous manager did, and you'd want a handover or training | Matches your own words and invents no experience | `[grounded]` R7 row | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search "Marrowgate Housing Limerick housing association" was refused. It would have moved RR4 and the organisation row |
| 2. Role-family sweep | unavailable | Search "payroll administrator Ireland salary 2026 Limerick" was refused. It would have moved the market calibration row |
| 3. Hiring manager's public footprint | unavailable | No search was sent after the refusals; a query on Declan Garvagh's public professional footprint would have moved the scope read |

## Dossier offer and upgrade menu

I can save all of this as a `tuesday-dossier.md` for you to keep.

- Permission to run searches → RR4 closes, and the pay band and the organisation row fill in; a deeper pass on Marrowgate (up to 5 more searches and 2 more fetches) is also available.
- Your answer on Irish payroll experience → G1 and R2 close.
- Your pay floor and any limits on office days → R10 and R11 move to `direct` or `hard_gate_fail`.
- The full contract → RR3 closes.

**Questions**

- R2 — Was your hotel-group payroll run under Irish PAYE, PRSI and USC, and on which payroll system?
- R7 — When your manager handled pension changes, did you prepare or process any part, such as pension deductions in the pay run?
- R10, R11 — Do you have any must-haves (a pay floor, how many office days, a start date, your notice period) that this offer needs to meet?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.