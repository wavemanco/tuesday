I'll read the skill's reference files before building the assessment.
The web search was refused, so none of the research on Fernquay ran. Everything below comes from the posting, the WhatsApp message and what you told me.

# Job Underwriting — Product Designer at Fernquay

## Decision snapshot

**You've already applied, so the question is whether to take the call. Yes, with conditions. Status: `conditional_go`.** On legitimacy: I can't establish Fernquay from here (RR1). Nothing in the posting or the message asks you for money, a cheque or ID details.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Hybrid, two days a week at the Galway office), R2 (Salary €52,000–€60,000)
- `must_have` — direct: R3, R4, R5, R7 · adjacent: R6 (Own the booking flow end to end)
- `important` — adjacent: R8 (Research calls with school owners) · unclear: R9 (You would be our first designer)

R6 — checkout is one stage of a booking flow, the rest not stated; R9 — you've never been the only designer, which this role would make you; R1, R2 — your constraints weren't given.

**Opportunity ledger.** The employer isn't established from here (RR1). Pay and equity ranges are stated, which counts in its favour (RR4). Open unknowns: decision rights (RR2), equity terms (RR3), the work-sample step (RR5) and runway (RR6). The WhatsApp message only schedules a video call held elsewhere, which is routine, and it has no register entry.

- **Hard gates:** none failed (R1, R2); unconfirmed: R1 (Hybrid, two days a week at the Galway office), R2 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer verifies as described, meaning the role is listed on Fernquay's own site and the invite comes from its domain (RR1); (2) the pay and office-days terms suit you (R1, R2); (3) the call shows what you would decide alone as first designer (RR2, R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, booking software for sea-kayak and surf schools. Not independently confirmed | `[grounded]` posting; existence not established, see Evidence status |
| Mandate | First designer; owns the booking flow end to end; runs research calls with school owners; ships with two engineers; works most closely with co-founder Ronan Kehoe | `[grounded]` posting |
| Working pattern | Hybrid, two office days a week in Galway, otherwise flexible | `[grounded]` posting |
| Compensation | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting |
| Market calibration | Not established. The role-family search was refused, so I give no band and won't offer one from memory | — |
| First-year outcomes | None stated beyond owning the booking flow | `[grounded]` posting silent |
| Unknowns | Decision rights against the founders; equity terms; runway; whether there is a work-sample step | `[inferred]` from the posting's silence |
| Contradictions | None between the posting and the message. The message names a CTO, Saoirse, whom the posting doesn't mention, which is a gap rather than a conflict. The company's own site was not checked | `[grounded]` the two texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week at the Galway office | hard_gate | unclear | none | hard_gate | You moved back to Galway last year, but gave no limit on office days or commuting. The term is unconfirmed | `[grounded]` posting and your statement | G1 question |
| R2 | Salary €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | No pay floor was given, so I can't say whether the range meets it | `[grounded]` posting; floor not given | G1 question |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company. Prose is unprobed, so `medium` is the ceiling | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" shows use. How strong it is would show in a file | `[grounded]` your background | A Figma file or prototype link would raise it to `high` |
| R5 | You have run your own user research | must_have | direct | medium | none | "Ran monthly usability sessions with customers". Whether you also wrote the guides and synthesised the findings isn't stated | `[grounded]` your background | A sanitized session guide or findings summary would raise it to `high` |
| R6 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned the checkout flow. Limit: ownership of the stages before and after checkout isn't stated | `[grounded]` your background; `[generic]` that a booking flow usually spans more than checkout | G2 |
| R7 | Work directly with engineers | must_have | direct | medium | none | Worked in a squad with four engineers | `[grounded]` your background | none |
| R8 | Run research calls with school owners | important | adjacent | medium | transferability | Your sessions were with "customers". Limit: school owners are business operators, and you haven't said whether you've researched with business users | `[grounded]` your background; `[inferred]` that the customers were travellers | G4 |
| R9 | You would be our first designer | important | unclear | low | discovery | You've never been the only designer. No evidence yet of owning design with no peer to review it. That is not a capability call, because nothing has been explored | `[grounded]` your statement and the posting | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Office days and pay floor (R1, R2, hard_gate) | hard_gate | Residence in Galway; no stated limit or floor | A failed gate would end this regardless of fit | n/a: these are terms, not experience | Your own limits | `[grounded]` your statement; limits not given |
| G2 | Whole-flow ownership (R6, must_have) | transferability | Checkout redesign confirmed; stages before or after not stated | This is the role's headline duty, and the bridge is only as wide as the ownership you can confirm | Designing search or selection, or confirmation and changes; deciding the flow's structure rather than screens | The checkout case study, a flow map | `[grounded]` your statement; `[generic]` that a first designer's headline duty gets probed |
| G3 | Working without design peers (R9, important) | discovery | Never the only designer; nothing on solo ownership | The role makes you the design function from day one | A stretch with no designer to review your work; setting your own process or research cadence; owning a design area alone | A project you led alone, a process note | `[grounded]` your statement |
| G4 | Research with business users (R8, important) | transferability | Sessions with customers; their type is not stated | Research with school owners is a named duty | Sessions with partners, suppliers or operators; interviews about workflow rather than usability | A sanitized findings summary | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools." | The company may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer; none is ranked as likely | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Authority over the booking flow not stated | unknown | — | "own the booking flow end to end ... You will work most closely with our co-founder, Ronan Kehoe." | Product decisions may sit with the founders while the designer carries the outcome | `[inferred]` from the posting's scope language against its silence on decision rights | Which booking-flow decisions would I make alone, and which would go to you and Saoirse? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "0.5–1% equity" | The range may depend on vesting, share type or later dilution that the posting doesn't give | `[inferred]` from the posting's silence on terms | What is the vesting schedule, what share type is it, and where in 0.5–1% would this role sit? | unresolved |
| RR4 | Pay and equity ranges stated | positive_signal | — | "Salary €52,000–€60,000 plus 0.5–1% equity." | Compensation is disclosed up front | `[grounded]` posting | Where in the salary range is this role budgeted? | noted |
| RR5 | Work-sample step possible | unknown | — | "we would rather see one messy real project than a polished deck." | The process may include a design exercise, with unknown length and pay | `[inferred]` from the posting's wording | Is there a work-sample step, how long would it take, and is it paid? | unresolved |
| RR6 | Runway unknown | unknown | — | "We are six people in Galway" | Equity compensation at a six-person company depends on funding; the posting doesn't say how it is funded | `[generic]` pattern for companies of this size; `[inferred]` from the posting's silence | How is the company funded, and how long is the current runway? | unresolved |

The WhatsApp message needs no entry. It schedules a video call with a CTO and a co-founder, with the invite by email.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, find the role listed on Fernquay's own website, and check that the emailed invite comes from an address on that site's domain. If the site has no such listing, ask where the role is posted | see RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask RR1–RR6 near-verbatim, with RR2 and RR3 first | The register doubles as call preparation | `[grounded]` register | pending your approval |
| P1 | Positioning line, proposed: "In four years at a Dublin travel-booking company I redesigned our checkout flow and ran monthly usability sessions with customers, working in a squad with four engineers." | Every clause comes from your own sentences. Don't add "owned", "led" or "end to end" unless G2 confirms them | `[grounded]` your background | pending your approval |
| P2 | Say plainly that you haven't been the only designer. Say it as "I haven't been the only designer", then give whatever G3 confirms | Your own statement; the interviewers can probe it | `[grounded]` your statement | pending your approval |
| W1 | Offer the checkout case study as your "messy real project", with what you personally decided marked | Their message cites it; this matches the posting's own preference | `[grounded]` their message and the posting | pending your approval |

## Evidence status

Verified: none yet. The message says they "loved the checkout case study". That is their statement, not your confirmed claim, and I haven't seen the case study.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were refused, "Fernquay booking software sea kayak surf schools Galway" and "Fernquay careers product designer". It would have settled whether Fernquay exists as described and whether the posting is live, which feeds RR1 and the contradictions row |
| 2. Role-family sweep | unavailable | One search was refused ("product designer salary Ireland 2026 3-5 years experience startup Galway"). It would have given the market calibration line and a check on the €52,000–€60,000 range |
| 3. Hiring manager's public footprint | unavailable | One search was refused ("Ronan Kehoe Fernquay co-founder"). It would have shaped the scope read and which of your stories to lead with |

## Dossier offer and upgrade menu

I can save this assessment as `tuesday-dossier.md` so it carries forward, if you'd like.

- Permission to run the three research targets → RR1 resolves or firms up, a market band appears, and the scope read gets its basis.
- A link to Fernquay's site or careers page, or what you found when you looked → RR1 updates without search.
- The domain the calendar invite came from, set against the company's own site → A1 closes.
- Your pay floor and any limit on office days → R1 and R2 become `direct` or `hard_gate_fail`.
- The checkout case study, or a flow map → R6 firms up and R4 reaches `high`.
- A sanitized usability-session guide or findings summary → R5 reaches `high`; G4 narrows.
- A link to the co-founder's public professional profile → the scope read and positioning.

## Questions

1. **G1:** Do two office days a week in Galway and a €52,000–€60,000 range both work for you, or is there a floor or a limit I should check the role against?
2. **G2:** At the travel-booking company, which parts of the booking journey did you personally design and decide, and did that include anything before or after checkout?
3. **G3:** Have you ever carried design on your own, even for one product area or a stretch with no designer to review your work? What did you own, and what happened?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.