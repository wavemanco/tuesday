I'll read the skill's reference files first.
Research is done (3 searches, 2 fetches), so here is the assessment.

# Job underwriting: Community Staff Nurse, Band 5 at Calderbrook Community Health CIC

## Decision snapshot

**Yes, this is worth applying for. Status: `go`.**

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3, R5a, R6a, R8 · adjacent: R9 (Caring for housebound adults at home) · unclear: R4 (Clear, timely written records)
- `important`: adjacent: R10 (Own small caseload, care planning) · unclear: R5b (Leg-ulcer care), R6b (Continence care), R7 (End-of-life visits)
- `preferred`: absent: R11 (Doppler assessment)

R9 and R10: near work with the limits named, and caseload ownership not claimed; R4, R5b, R6b and R7: skills the CV doesn't mention; R11: a preferred gap, which the advert marks as desirable.

**Opportunity ledger.** The role is transparent. Pay is stated and in line with the sweep (RR2), supervision is stated (RR5 asks how much), and a named lead offers a chat (RR6). Whether the post is live on the careers page (RR1), the mileage rules (RR3) and the hours (RR4) are unconfirmed.

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** a failed check of your own NMC register entry or driving record (R1, R2), word that the post is closed (RR1), or hours or mileage terms (RR3, RR4) that clash with limits you haven't given me.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | A community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract. Founded 2015, 410 staff, four locality hubs | `[grounded]` About page fetched (calderbrookhealth.example/about) |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin administration and care planning, recorded on an electronic patient record. A small own caseload, supported by a senior community nurse | `[grounded]` advert |
| First-year outcomes | Not stated | `[grounded]` advert silent |
| Working pattern | Hours, rota and weekend cover not stated. Pool cars provided, plus mileage | `[grounded]` advert |
| Scope read | A standard staff-nurse community post: a duty list, a one-year experience floor, and supervision named. No bundled specialisms or authority mismatch visible | `[inferred]` from the duty list and the essential criteria |
| Market calibration | Advert range £31,050–£37,800. The survey's Band 5 community staff nurse median is £34,300 (interquartile range £32,400–£36,600), so the range spans both. In the survey 61% were paid mileage and 24% had a pool or lease car. It is a self-reported sample (n=1,240), not this employer's offer | `[generic]` Wardround 2026 pay guide (snippet only); `[grounded]` advert figures |
| Unknowns | Hours and rota, mileage rate, starting caseload size, whether Doppler training is offered, terms and pension, closing date | `[grounded]` advert silent |
| Contradictions | None between the advert and the About page on what the organization does. The careers page did not load, so whether the post is live is untested | `[grounded]` fetches |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | You state active Adult registration, revalidation due March 2028. Stated, not checked; your own NMC register entry is where it is confirmed | `[grounded]` CV | Check your own register entry (yours to do; I haven't) |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | You state a full UK licence, category B. Stated, not checked; your DVLA driving record confirms it. Pool cars are provided | `[grounded]` CV and advert | Check your own driving record |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward, stated | `[grounded]` CV | none |
| R4 | Clear, timely written records, on an electronic patient record | must_have | unclear | low | discovery | The CV says nothing about records or any electronic system. It signals no problem, but claims nothing | `[grounded]` CV silence; `[generic]` record-keeping is a standard expectation of registered nurses | G3 |
| R5a | Wound care | must_have | direct | medium | none | Pressure ulcers and surgical wounds, stated | `[grounded]` CV | none |
| R5b | Leg-ulcer care | important | unclear | low | discovery | Your wound care is adjacent, but the CV names pressure ulcers and surgical wounds, not leg ulcers | `[grounded]` CV | G2 |
| R6a | Catheter care | must_have | direct | medium | none | Stated | `[grounded]` CV | none |
| R6b | Continence care | important | unclear | low | discovery | The CV states catheter care, not other continence care | `[grounded]` CV | G2 |
| R7 | End-of-life visits | important | unclear | low | discovery | The CV is silent. Acute medical wards may involve end-of-life care, but that isn't claimed for you | `[grounded]` CV silence; `[generic]` ward pattern | Not asked this turn (question budget); see G4 |
| R8 | Insulin administration | must_have | direct | medium | none | Stated. The advert's "care planning" is carried by R10 | `[grounded]` CV | none |
| R9 | Caring for housebound adults in their own homes | must_have | adjacent | medium | transferability | 18 months seconded to a discharge-to-assess team, visiting patients at home in their first week after discharge. The limit: those visits are time-limited, the CV doesn't say what you did on them, and ongoing housebound care is not stated | `[grounded]` CV; `[inferred]` the limit, from the advert's "housebound" against the secondment's one-week window | G1 |
| R10 | Own small caseload and care planning, with senior support | important | adjacent | low | transferability | You have not held your own caseload. Visiting on the secondment and ward patient work are near, but unconfirmed, and the CV doesn't state care planning | `[grounded]` your statement, advert | G1 |
| R11 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You have not done one. The advert lists it as desirable, not essential | `[grounded]` your statement, advert | Ask Rhiannon Mabbott whether training is offered (A1) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Home visiting and caseload (R9, must_have; R10, important) | transferability | Secondment visits are stated. What you decided on a visit, and whether any patients were yours to follow, is not | R9 is a must-have at `adjacent`, and "caseload" is the advert's central responsibility | Deciding on a visit whether to escalate; adjusting a plan; following the same patients across visits | A secondment job description or a reference line on the work | `[grounded]` CV; `[generic]` that a caseload role turns on this |
| G2 | Leg-ulcer and continence skills (R5b, R6b, important) | discovery | The CV names other wound types and catheters only | The advert lists both in its duties | Compression bandaging or leg-ulcer dressings on the ward; bladder and bowel care beyond catheters | A competency record or training certificate | `[grounded]` CV |
| G3 | Written records and the electronic patient record (R4, must_have) | discovery | No record-keeping or system named | A must-have at `unclear`, though a likely quick close | Documenting care on a ward system; recording home visits | A named system, or a records audit result | `[grounded]` CV silence |
| G4 | End-of-life care (R7, important) | discovery | CV silent | Part of the advert's duty list | Caring for dying patients on the ward or on visits | A reference or an end-of-life competency | `[grounded]` CV silence |
| G5 | Doppler assessment (R11, preferred) | capability | No evidence, and you say none | Desirable only | None to recover; the closure path is training | An employer's training offer | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Post not confirmed on the careers page | unknown | — | "Community Staff Nurse, Band 5 — Calderbrook Community Health CIC, Halifax" | The careers address I tried returned no page. That could mean a wrong address, a page elsewhere, or a post that has closed | `[grounded]` fetch returned no page | Is this post open, and what is the closing date? | unresolved |
| RR2 | Pay stated and in line with the sweep | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The range spans the survey's median and interquartile range | `[grounded]` advert; `[generic]` survey band | Where in the range would this post start, and which terms and pension apply? | noted |
| RR3 | Mileage rate and pool-car rules unstated | unknown | — | "pool cars are provided … plus mileage" | The rate, and when pool or own car is used, are not given | `[grounded]` advert silence | What is the mileage rate, and when would I use a pool car? | unresolved |
| RR4 | Hours and cover unstated | unknown | — | "end-of-life visits" | End-of-life visits may need cover outside usual hours | `[inferred]` from the duty list against silence on hours | What are the working hours, and is there weekend or on-call cover? | unresolved |
| RR5 | Caseload size and support undefined | unknown | — | "a small caseload of your own, supported by a senior community nurse" | "Small" and "supported" aren't quantified, which matters given R10 | `[inferred]` from the wording against R10 | How many patients make up a starting caseload, and how much supervised visiting comes first? | unresolved |
| RR6 | Clear scope and a named contact | positive_signal | — | "For an informal chat about the role, contact Rhiannon Mabbott" | The essential and desirable split and a named lead suggest a defined role | `[inferred]` from the advert's structure | How is success measured in a new nurse's first months? | noted |

## Application plan

Nothing here is final until you approve it. That covers the wording in the Why column as well as the table.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with the secondment, in your own words: "seconded to its discharge-to-assess team, visiting patients at home in their first week after discharge" | R9; the line is your CV sentence, moved up, nothing added | `[grounded]` CV | resume_edits_pending_approval |
| E2 | Add a skills line near the top: wound care (pressure ulcers and surgical wounds), catheter care, insulin administration | R5a, R6a, R8; each is as you stated it, with no leg-ulcer or continence claim | `[grounded]` CV | resume_edits_pending_approval |
| E3 | Supporting-statement line: "I have not held my own caseload before. For the last 18 months, seconded to a discharge-to-assess team, I have visited patients at home in their first week after discharge." | R10; the limit is stated first, and every clause traces to your words | `[grounded]` your statement, CV | pending your approval |
| A1 | Take up the informal chat with Rhiannon Mabbott before applying. Ask RR1–RR6 verbatim, and whether Doppler training is offered | The advert offers the chat; R11 is a question, not a claim | `[grounded]` advert | pending your approval |
| A2 | Check your own NMC register entry and DVLA driving record before applying | R1, R2 are stated, not checked | `[grounded]` CV | pending your approval |
| A3 | Leave your National Insurance number off the CV. It isn't needed to assess the role, and I haven't used it | Details like this are normally collected after a written offer | `[generic]` routine onboarding | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "community staff nurse district nursing Band 5 Halifax Calderbrook Community Health CIC vacancy"; both returned "About Calderbrook Community Health". Fetched calderbrookhealth.example/careers (no page) and calderbrookhealth.example/about. Role reality's organization row is grounded; RR1 opened because the post's live status is untested |
| 2. Role-family sweep | yes | Searched "district nurse Band 5 community staff nurse role scope Agenda for Change pay 2026/27", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide), snippet only. Moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | skipped | A name was given. The outputs it feeds, role reality's scope read and the plan's positioning, are already set by the advert's own duties and essentials, which are in hand |

## Dossier offer

I can write this up as `tuesday-dossier.md` if you'd like to keep it.

## Upgrade menu

- A screenshot or note of your NMC register entry and driving-record summary, showing status, class and expiry but no numbers → R1 and R2 move to `high`.
- Your pay floor, hours and any other non-negotiables → the hard-gate line can check them, and for now it can't.
- Any leg-ulcer, compression or continence competency record → R5b and R6b.
- A link to the post on the employer's careers page → RR1 closes.
- A deeper research pass on Calderbrook (contract and leadership history, public staff reports, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

## Questions

G1 (R9, R10): On your D2A visits, what did you decide yourself and what went to a senior or the team? Were any patients yours to follow up across several visits?

G2 (R5b, R6b): Have you done compression bandaging or leg-ulcer dressings, or bladder and bowel care beyond catheters?

G3 (R4): Which electronic patient record systems have you recorded care in, on the ward and on the D2A visits?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.