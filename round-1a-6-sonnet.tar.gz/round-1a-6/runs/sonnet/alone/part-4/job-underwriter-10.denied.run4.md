I'm reading the skill's research rules, then running the company searches. After that I'll write the assessment.
**Yes, it's worth taking the call, and nothing in the WhatsApp message is a warning sign. It asks for a video call and nothing else, with no money, bank details or ID. I couldn't confirm from here that Fernquay exists as described, so the status is `conditional_go`. The conditions are below.** You'd already applied, so I'm treating this as the interview stage.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Salary €52–60k plus equity)
- `must_have` — direct: R3, R4, R5, R8 · adjacent: R7 (Own the booking flow end to end)
- `important` — adjacent: R6 (Research calls with school owners), R9 (First designer, no design peer)

R7 — a credible bridge, its limit named; R9 (`low`) — the largest gap, no sole-designer history; R2 (`none`) — your pay floor isn't given.

**Opportunity ledger.** The scope and pay are disclosed up front (RR4) and the next step is concrete (RR5). Against that, the employer isn't confirmed from here (RR1), the equity terms are unstated (RR2), and success measures and decision rights are unstated (RR3).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52–60k plus equity); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:**
  1. Fernquay is verified as a real, hiring company (RR1).
  2. The €52–60k range clears your own pay floor (R2).
  3. The equity terms are explained (RR2).
  4. You frame R9 honestly as a limit, never as sole-designer experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: six people in Galway, booking software for sea-kayak and surf schools. Not confirmed by any source outside the posting | `[grounded]` posting text only; existence unchecked |
| Mandate | First designer; own the booking flow end to end; research calls with school owners; ship alongside two engineers; work most closely with co-founder Ronan Kehoe | `[grounded]` posting |
| Working pattern | Hybrid, two days a week in the Galway office | `[grounded]` posting |
| Pay | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting |
| Scope read | One designer covering research, design and delivery, with no design peer and two engineers | `[inferred]` from "first designer" against the three listed duties and the headcount |
| Market calibration | Not run: the searches were refused, so there is no band to set the €52–60k against | — |
| First-year outcomes | Not stated | `[grounded]` posting is silent |
| Unknowns | Reporting line and decision rights; equity terms; funding and customer base; success measures | `[grounded]` posting is silent on each |
| Contradictions | None found. The sender is the co-founder the posting names, and the message's call with the CTO fits a six-person team with two engineers | `[grounded]` posting and message compared |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week at the Galway office | hard_gate | direct | medium | none | You live in Galway, so the term is met. Medium because your location is self-reported | `[grounded]` posting and your statement | none |
| R2 | Salary €52–60k plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | You haven't given a pay floor, so the range can't be checked against one | `[grounded]` posting; no constraint stated by you | Question R2 below |
| R3 | 3+ years of product design | must_have | direct | medium | none | 4 years as a product designer at a Dublin travel-booking company. A length of experience, so graded as fit, not as a gate | `[grounded]` your background | Share the case study for `high` |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily"; nothing inspected | `[grounded]` your background | Share a Figma file or the case study |
| R5 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. That is usability research; discovery-style interviews aren't stated (see R6) | `[grounded]` your background | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | discovery | You redesigned the checkout flow, which is one stage of a booking flow. How much of the rest you owned isn't stated | `[grounded]` your background | G1 |
| R8 | Work directly with engineers | must_have | direct | medium | none | Worked in a squad with four engineers | `[grounded]` your background | none |
| R6 | Research calls with school owners | important | adjacent | medium | discovery | Usability sessions with customers are close, but calls with small-business owners about how they run bookings are a different kind of conversation | `[grounded]` your background; `[inferred]` that the kinds differ | G3 |
| R9 | First designer, no design peer | important | adjacent | low | transferability | You've never been the only designer. Your checkout redesign and research sessions are adjacent. Nothing yet shows decisions or process set up without design peers | `[grounded]` your statement; `[inferred]` from "You would be our first designer" | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Booking flow ownership (R7, must_have) | discovery | A checkout redesign. Nothing about earlier or later steps | The role names the whole flow, and Ronan has already seen the checkout case study | Steps before checkout such as availability, date or slot choice; confirmation, change and cancellation; who decided scope | The case study, a flow diagram, a before/after | `[grounded]` your background; `[inferred]` that the posting's "end to end" is the likely probe |
| G2 | No design peer (R9, important) | transferability | Adjacent: you ran your research sessions and redesigned checkout. Limit: those sat inside teams with design peers, and nothing shows design process built from nothing | The "first designer" part of the role is the biggest distance in the map | Decisions you made without design review; a process or tool you introduced | One messy real project you can show, which the posting invites | `[grounded]` your statement and the posting; `[generic]` that first-designer seats hinge on this |
| G3 | Research with school owners (R6, important) | discovery | Usability sessions only | The posting makes owner calls a core duty | Interviews or calls with business owners, not just testing a design | A research plan, a call guide, a synthesis | `[grounded]` your background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools" | You found little online. The company may be too new or small, the posting may be stale, or it may not represent a real hiring employer; I rank none of these as likely. I could not check, as the searches were refused | `[generic]` pattern for companies of this size; `[grounded]` that you found little | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Equity terms unstated | unknown | — | "0.5–1% equity" | Percentage of what, vesting, strike price and dilution aren't given | `[inferred]` from the posting's silence | What are the vesting schedule, cliff and strike price, and which share class is it? | unresolved |
| RR3 | Success measures and decision rights unstated | unknown | — | "own the booking flow end to end" | Ownership may carry accountability without authority over scope | `[inferred]` from the posting's scope language against its silence | What does success look like at 90 days and at one year, and who decides what ships in the booking flow? | unresolved |
| RR4 | Pay range disclosed | positive_signal | — | "€52,000–€60,000 plus 0.5–1% equity" | Transparent on pay | `[grounded]` posting | What drives where in the range an offer lands? | noted |
| RR5 | Concrete next step with named people | positive_signal | — | "a 45-minute video call with me and Saoirse, our CTO … calendar invite with the video link" | The process is specified, with a technical interviewer and an emailed invite | `[grounded]` message | What are the stages after this call? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Take the call. Before it, find Fernquay's own website yourself and check that the calendar invite came from an address on that site's domain. Don't click anything you can't match to it | Scheduling by WhatsApp for a video interview is routine, and checking the invite is cheap. Nothing was asked of you beyond the call | `[generic]` routine scheduling pattern | pending your approval |
| A2 | Open with what you did, in your own terms: you redesigned your company's checkout flow, ran monthly usability sessions with customers, and worked in a squad with four engineers. Say plainly that you haven't been the only designer | Each clause traces to your own sentences. It states R9 as a limit, which is safer than letting an interviewer find it | `[grounded]` your background | pending your approval |
| A3 | Pick one real project you are allowed to share, messy or not, and bring it instead of a polished deck | The posting asks for exactly this, and it is the artifact that would firm up R7 and R9 | `[grounded]` posting | pending your approval |
| A4 | Ask RR1, RR2 and RR3 verbatim on the call | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A5 | Decide your pay floor and your office-day limit before the call | Closes R2 | `[grounded]` R2 row | pending your approval |

No CV edits are proposed, so nothing is pending on that front.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were refused ("Fernquay booking software sea kayak surf schools Galway", "Fernquay careers product designer Galway"). They would have settled whether Fernquay exists as described, whether the posting is live, and RR1 |
| 2. Role-family sweep | unavailable | One search was refused ("first product designer startup Ireland salary equity 0.5% 1% Galway 2026"). It would have supplied the market band for R2 and role reality |
| 3. Hiring manager's public footprint | unavailable | Ronan Kehoe is named, but search wasn't granted, so I sent no query. It would have informed the scope read and what to lead with |

## One closing offer

I can write all of this up as `tuesday-dossier.md` if you want a copy to keep.

**Upgrade menu**

- **Search access:** run targets 1–3 above, which settles RR1 and calibrates R2.
- **The company's website or careers-page link:** closes RR1 faster than any search.
- **The case study or Figma file you applied with:** R3, R4, R5 and R7 move toward `high`, and G1 largely answers itself.
- **Your pay floor:** R2 resolves one way or the other.
- **Equity terms in writing:** closes RR2.

**Questions**

1. **R2** — What is your pay floor, and is there anything else about this role you wouldn't trade, such as office days or equity? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
2. **G1** — Beyond checkout, which parts of the booking flow did you own, and who decided scope? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
3. **G2** — Have you ever made design decisions with no designer reviewing them, or set up a process or tool yourself, and what happened? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.