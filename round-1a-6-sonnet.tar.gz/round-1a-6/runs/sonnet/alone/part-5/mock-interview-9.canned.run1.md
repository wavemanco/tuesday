I've read the skill's rules. Next I'm running a few company and role searches, which won't include your license or SSN, before I build the pack.
Your prep pack is saved as `halvering-elementary_fourth-grade-teacher_interview_pack.md`, with 23 questions. I built it for a panel. I treated Principal Vantongeren as a hiring-manager style of interviewer and the two fourth-grade team members as peers. The posting text wasn't supplied, so some fit rows rest on a typical fourth-grade posting I found, and the pack marks those as inferred.

Your SSN isn't needed for interview prep. I didn't use it or copy it into the pack, and I'd leave it off anything you share for this. I used your license only as you stated it: kind, endorsement and expiry. I didn't use the license number anywhere.

**What stood out**
- **License gate:** your résumé shows the requirement met. Checking it against the state's own record is yours to do before Thursday.
- **Highest-ROI prep:** question A1, "You haven't taught fourth grade. What will be different for you on day one?" It's rehearsed with both likely follow-ups.
- **Your two stated gaps:** you haven't taught fourth grade and you've never been a team lead. The pack coaches you to say both plainly, then use your third-grade years and the 2024 curriculum move at their actual scope. It lists the stretched versions of those claims as ones it won't coach.
- **Research:** the district's published beliefs, its 2026–2029 literacy plan, and the principal's public background as a reading specialist all feed the questions. I read only a summary line of the literacy plan and of her profile, so read the plan itself before Thursday.

Say the word and I'll play the principal as the Skeptic on A1 and run it live. I can also save a `tuesday-dossier.md` with the gaps this prep exposed, or convert the pack to Word.

1. Do you have the text of Halvering's actual posting? It would turn the inferred rows into grounded ones.
2. Do you want a deeper research pass on the district and the principal? It's up to 6 more searches and 2 more fetches, and takes several more minutes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: halvering-elementary_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**Employer:** Orrinsford Community School District (Halvering Elementary School)
**Round:** 45-minute panel on Thursday, per the invite
**Panel:** Principal Dolores Vantongeren and two members of the fourth-grade team (names not given)

## How to use this pack

- **Personas are how a question is asked; types are what it scores.** Every question carries both.
- **Type key:** VAL = behavioral or values alignment. EXP = work-experience deep-dive. JD = role or posting-driven. CO = company and strategy knowledge. CASE = live problem from the role.
- **Provenance labels:** `[grounded]` traces to your own words, the invite, or research listed in Sources. `[inferred]` is derived from a representative posting or an adjacent source. `[generic]` is a pattern with no claim about you or the school.
- **An answer slot** is an instruction for the interview. It asks nothing of you here. Either branch is a good answer when it is true.
- **Guidance is scaffolding, not a script.** Everything proposed for you to say is proposed language, pending your approval. Say only what you actually did, in your own words.
- **Question IDs:** A to E, then V (values) and P (pressure). F1 to F11 are fit-snapshot rows.
- **What this pack rests on:** the invite fixes one panel session and who sits on it. I weighted the principal as a hiring-manager style and the two team members as peers. No source names a values round, so there is no values cheat sheet.

## Fit snapshot

Requirements come from the invite, from the district's published beliefs page, and from a representative fourth-grade posting. That posting is typical wording for the role, not Halvering's own, so its rows are `[inferred]`. Bridge language below is proposed, pending your approval.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" — the invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | Your material states the license, the endorsement and the expiry, with nothing inspected behind it. Say it as written: "I hold an Illinois Professional Educator License with the Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029." Checking the state's own record is yours to do before Thursday |
| F2 | "plan and teach reading, writing, math, science and social studies" — representative posting, K12 Jobs Board | "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [inferred] | discovery | The quote says third grade, not which subjects. Answer slot: postings like this list five subjects, so expect a probe on which were yours. Say which, in your own words; if some were taught by others or not at all, say so plainly and stay with the third grade you taught |
| F3 | "differentiate instruction using assessment data" — representative posting, K12 Jobs Board | none given | none | [inferred] | discovery | Nothing in your material touches this, and it does not show an absence. Answer slot: if you changed what you taught after assessment results, say what the results showed and what changed, in your own words; if you did not, or it was not yours, say so plainly and say what you would look at first |
| F4 | "keep clear classroom routines" — representative posting, K12 Jobs Board | none given | none | [inferred] | discovery | Same shape as F3. Answer slot: if you ran routines you can describe, say which and how they worked, in your own words; if not, say so plainly and describe what you would want in place in a fourth-grade room |
| F5 | "communicate regularly with families" — representative posting, K12 Jobs Board | "I write a weekly email to families." — your CV | medium | [inferred] | none | A CV line with nothing inspected behind it, so expect a probe. Lead with it in its own terms: weekly, written, to families. A named record beats an adjective |
| F6 | "Families Are Partners: each teacher speaks with every family each term." — Orrinsford Mission and Beliefs page | "I write a weekly email to families." — your CV | low | [grounded] | transferability | The quote is a written email, and the belief is about speaking with every family. Say the quote at its own scope. Answer slot: if you have spoken with families directly, say how and how often, in your own words; if not, or it was not yours, say so plainly and stay with the email |
| F7 | "Every Child a Reader: no student leaves third grade without a reading plan." — Orrinsford Mission and Beliefs page | "I led our grade level's move to a new reading curriculum in 2024" and "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | transferability | Both quotes are reading work. Neither shows a reading plan for each student. Say the quotes at their own scope. Answer slot: if each student leaving your class had a reading plan, say how it worked in your own words; if there was no such plan, or it was not yours, say so plainly and stay with the curriculum move and the club |
| F8 | "work with the grade-level team" — representative posting, K12 Jobs Board | "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [inferred] | presentation | The quote already carries team work in other terms. Reworded at its own scope: "Our grade level moved to a new reading curriculum in 2024, and I led that move." Your message also says you have never been a team lead, so the move is not offered as a lead role |
| F9 | "experience in grades 3 to 5 preferred" — representative posting, K12 Jobs Board | "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [inferred] | none | Third grade sits inside the posting's range. Say it plainly: "For six years I taught third grade at a public elementary school in Joliet." |
| F10 | "applying for the Fourth Grade Teacher position at Halvering Elementary School" — the invite | "I've never taught fourth grade" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't taught fourth grade." Then a plan, said in the future tense and never as a past. F9's third grade is neighbouring evidence at its own scope, not a substitute |
| F11 | "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it." — Orrinsford Mission and Beliefs page | none given | none | [grounded] | discovery | Your material is silent here. Answer slot: if assessment results have changed what you taught, say what and how, in your own words; if not, say so plainly and say how you would keep a test from running the teaching |

## Reading the interviewer

Public professional footprint only. The two team members are unnamed, so there is nothing to read for them.

| Public fact | Source | Provenance | What it means for Thursday |
|---|---|---|---|
| Principal of Halvering Elementary School since 2022 | Illinois principals forum speaker page | [grounded] | She leads the building; expect her questions to be about fit with the school and the grade |
| Nine years as a reading specialist before that | Illinois principals forum speaker page | [grounded] | Reading instruction is her native subject. Expect reading questions to be precise (C3, V3) |
| 2025 forum talk, Small Groups, Big Readers, on weekly reading conferences in grades 3 to 5 | Illinois principals forum speaker page | [grounded] | Her own theme may return as a question. Reverse questions 1 and 2 use it. You have shown no conferences in your material, so C3 holds an answer slot |

**Mirror opportunity:** shared vocabulary only. You both work in reading in grades 3 to 5. The quoted sentence that carries your side is "I've run the after-school reading club for the last two years" (F7). No shared career jump is offered, because no row carries your side of one.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy (rehearsal method) |
|---|---|---|---|
| Skeptic (A) | Quiet, persistent probing of the fourth-grade gap and the move | High. The principal's hiring-manager prior includes the Skeptic, and F10 and F8 give it material | Rehearse A1 until it is boring; hold then concede; bridge only from quotes |
| Peer Evaluator (B) | Seam-splitting, credit, "what would you need from us" | High. Two fourth-grade team members are peers by the relationship prior | Reciprocity framing; seam principles, not a seam you have not seen |
| Case/Strategist (C) | Live problems on reading and on the district's plan | Medium. Hiring-manager prior, plus her published reading theme | Clarify, objective, approach, metrics, risks; think aloud |
| Data-Driven Prober (D) | Line-by-line probes of your three reading sentences | Medium. Peer prior; your material carries durations, not figures, so probes land on attribution | Say what each sentence says and no more; concede specifics |
| Conversational (E) | Warm opener, license check, closing invitation | Medium. Assumed from how a panel opens; no source says how this one will | Prepared 90-second arc; never answer "you've covered everything" |
| Values/Behavioral (V) | Questions themed on the district's three beliefs | Low. No source names a values round; the beliefs may still theme questions | Selection scaffold ending in the honest branch |
| Pressure (P) | Time-boxed, challenging | Low. No signal points to it; included so composure is rehearsed | Pause, restate, hold two follow-ups, then concede specifically |

## Question banks

**Highest-ROI prep in this pack: A1.** It will be asked in some form, it aims at the thinnest part of your material, and a calm, honest answer changes the panel. Rehearse it with both follow-ups.

Every row below is proposed language, pending your approval.

### A. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't taught fourth grade. What will be different for you on day one?" | JD | [grounded] "I've never taught fourth grade" and "Six years teaching third grade at a public elementary school in Joliet." | Hold then concede, in three moves. First the plain acknowledgment: "I haven't taught fourth grade." Then the quote at its own scope: "For six years I taught third grade at a public elementary school in Joliet." Follow-up one, why third grade counts: return to the six years and add nothing about what fourth grade requires. Follow-up two, what would you struggle with: concede specifically, that you have not taught the fourth-grade year and would want to see how the team runs it before saying what you know of it. Then a plan in the future tense: what you would ask the team to show you first, in your own words. Answer slot: say what you honestly expect to be different in fourth grade; if you do not know yet, say so plainly | F10 is the stated gap and the grade the invite names; F9 is the nearest evidence. JD because it scores fit to the listed grade. Deepest rehearsal because the question is certain in some form |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" | Name one weakness that is true, in one sentence, then say in the future tense what you would do about it. The fourth-grade year is the one your material states: "I haven't taught fourth grade." Answer slot: if your honest answer is something else, say that instead, in your own words. Do not name a weakness for effect and do not name one you do not hold | The Skeptic stem for a candidate with one stated gap (F10). JD because it scores honest self-assessment against the role |
| A3 | "Have you ever been a team lead?" | EXP | [grounded] "I've never been a team lead" and "I led our grade level's move to a new reading curriculum in 2024" | Plain acknowledgment first, in your words: "I've never been a team lead." Then the quote at its own scope, which is a move your grade level made: "I led our grade level's move to a new reading curriculum in 2024." Stop there. Do not turn the move into a leadership role. Answer slot: if asked what leading the move involved, say which parts were yours, in your own words; if the grade level decided together, or any part was not yours, say so plainly and stay with the move | F8 holds both statements, and they sit close enough that a panel will test where one ends. EXP because it tests attribution |
| A4 | "Why fourth grade, why Halvering, and why now?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." | Your material says where you are, not why you want to move, so the reasons are yours to give. Answer slot: give your actual reason for fourth grade, your actual reason for this school, and why now, in your own words; if you do not have a reason for one of the three yet, say so plainly and give the ones you do have. The district's three published beliefs are worth citing only if one is true for you | The Skeptic's motivation stem. EXP because the reason for moving is scored like a reason for leaving; F9 and F10 are the facts around it |
| A5 | "Which subjects did you teach in third grade?" | JD | [inferred] "Six years teaching third grade at a public elementary school in Joliet." | Answer slot: postings like this list reading, writing, math, science and social studies, so expect this probe. Say which subjects were yours, in your own words; if some were taught by others or not at all, say so plainly and stay with the third grade you taught | F2 is the evidence and the row where the material is silent. JD because it scores the posting's subject list; inferred because that list is typical wording, not Halvering's |

### B. Peer Evaluator (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our team shares the fourth-grade year. Where would you fit, and what happens when we disagree?" | CASE | [generic] | No claim about your past is needed. Ask before you propose: how does the team plan together now, and what is already fixed? Offer principles, not a seam you have not seen: raise a disagreement early and privately, say what you are trying to protect for students, ask what the team's decision rule is, and follow it once it is made. Close with what you would like to learn from them | The team members are the peers; this is the collegial form of the doubt in F10. CASE because it is a live collaboration problem |
| B2 | "How do you handle credit when work spans a whole grade level?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Say what the sentence says: the grade level's move was one you led, in 2024. Use "I" for what was yours and "we" for the grade level. Answer slot: if others carried parts of it, say so plainly and which, in your own words; if you are unsure how to split it, say that and stay with the move | F8 is the only team evidence. EXP because it tests whether you share credit precisely |
| B3 | "What could we do in your first month to help you most, and what could you do for us?" | JD | [grounded] "I write a weekly email to families." and "I've run the after-school reading club for the last two years" | Reciprocity, in two halves. Ask for what you need: how the team plans, its routines, how it handles assessments. Offer only what your quotes carry, the weekly email to families and the after-school reading club, and let them say whether either is wanted. Answer slot: if there is something else you can offer the team, say it in your own words; if not, say you would ask them first | The reciprocity question a peer panel weighs. F5 and F7 are the evidence. JD because it scores working with the grade-level team |
| B4 | "Walk us through the routines you'd want running in a fourth-grade room by the end of the first week, and where you'd match ours." | JD | [inferred] | This is a hypothetical and asks about no past. Answer slot: if the routines you would use are ones you have used, say which and how they worked, in your own words; if you have not run routines like these, say so plainly and describe what you would want in place and why. Then ask what the team's routines are before you decide where to match | F4 is the evidence and the material is silent on it. JD because routines are typical posting wording; inferred for the same reason as A5 |

### C. Case/Strategist (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "The board adopted a literacy plan with a new grades 3 to 5 reading curriculum from fall 2027. As a fourth-grade teacher, where would you start, and what do you need to know first?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Clarify first: what the plan asks of fourth grade, and when. Then objective, approach, risks, thinking aloud. You have seen only a summary line of the plan, so read the full plan before Thursday and say plainly what you do not yet know. One sentence may link your own experience, at its scope: "I led our grade level's move to a new reading curriculum in 2024." Add nothing about what that move involved | The strategy-grounded question from research. F7 is the evidence. CO because it tests homework depth |
| C2 | "A fourth-grader is reading well below grade level. Walk us through your first month with them." | CASE | [generic] | A live problem; no claim about your past. Clarify what the assessments show, what has been tried, and what the family says. Then the objective, a small plan, how you would know it is working, and when you would bring in the team or the family. The district's published line "assessments inform teaching and never replace it" is vocabulary to use only if you agree with it | Reading is the principal's native subject. CASE because it is a live role problem; F2 and F11 are the requirements it touches |
| C3 | "How do you get to know each reader in a class of fourth-graders?" | JD | [inferred] | The principal's published talk is on weekly reading conferences in grades 3 to 5, so expect questions near it. Answer slot: if you have held individual reading check-ins, say how and how often, in your own words; if you have not, say so plainly and describe how you would find out where each reader is. Name no method you have not used | F2 and F7 are the evidence; the interviewer read gives the reason to expect it. Inferred because the link to her talk is this pack's derivation |

### D. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You led your grade level's move to a new reading curriculum in 2024. How much of that was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Hold then concede. Hold: "I led our grade level's move to a new reading curriculum in 2024." Do not widen it to the school or the district. Follow-up one, which parts were yours: answer slot: say which parts, in your own words; if the grade level decided together, or any part was not yours, say so plainly. Follow-up two, what you would do differently: answer slot: if there is something, name it; if not, say so plainly. Concede specifically, from your honest account and never from what such a move usually involves | F8 is the sentence a prober tests first, since it is the only quote with a verb of leadership. EXP because it scores attribution |
| D2 | "You've run the after-school reading club for the last two years. What have you learned from it?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | The sentence carries three beats: a reading club, after school, the last two years. Tell those in your own words. Answer slot: give one thing you actually learned; if nothing has changed in how you teach because of it, say so plainly. Add no attendance figures or outcomes you did not state | F7 holds the club quote. EXP because it tests whether a CV line has depth behind it |
| D3 | "Walk us through the weekly email to families." | EXP | [grounded] "I write a weekly email to families." | The sentence carries three beats: weekly, written, to families. Tell those in your own words. Answer slot: the district's published belief is that each teacher speaks with every family each term, so expect a probe on conversations beyond the email. If you have spoken with families directly, say how and how often; if not, or it was not yours, say so plainly and stay with the email | F5 and F6 are the evidence. EXP because it tests a CV line; the probe on conversations comes from F6 |

### E. Conversational (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Before we begin, can you confirm your license and endorsement?" | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | Say it in the words your CV carries: an Illinois Professional Educator License, the Elementary Education endorsement for grades 1 to 6, registered and active through June 30, 2029. Add nothing. Checking the status on the state's own record before Thursday is yours to do | F1 is the invite's one stated requirement. JD because it scores a stated qualification |
| E2 | "So — walk me through the journey." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." and "I led our grade level's move to a new reading curriculum in 2024" and "I've run the after-school reading club for the last two years" and "I write a weekly email to families." | A 90-second arc in your own order using only these beats: six years of third grade in Joliet, the grade level's move to a new reading curriculum in 2024, the after-school reading club, the weekly email to families. Answer slot: end on why you are here, which only you can say; if you do not have a fourth-grade-specific reason yet, say so plainly and name what draws you to this school | F9 and F7 are the evidence. EXP because a biography question is scored on economy and on whether each claim survives a follow-up |
| E3 | "Is there anything we haven't asked that you'd like us to know?" | EXP | [grounded] "I've run the after-school reading club for the last two years" and "I write a weekly email to families." | Never answer "I think you've covered everything". Pick the one thing you most want them to leave with and say it at its scope: the club, or the weekly email. Answer slot: if there is something else true that you want them to know, say it in your own words | The closing slot is scored as a preparation signal. F5 and F7 are the evidence |

### V. Values/Behavioral (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Families Are Partners is one of our district's beliefs. Tell me about a time you worked with a family as a partner." | VAL | [grounded] "I write a weekly email to families." | No quoted sentence carries a story of working with a family, so this is a selection scaffold: pick a time a family's input changed what you did for a child. It needs the family's concern, what you did, and where things stood afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I write a weekly email to families", or how you would handle it | F6 is the evidence and a thin row. VAL because the belief is published on the district's own page |
| V2 | "Teach for Tomorrow, Not for the Test: what does that mean for how you use assessments?" | VAL | [grounded] | The page words it as "assessments inform teaching and never replace it". Answer slot: if assessment results have changed what you taught, say what they showed and what you changed, in your own words; if not, or it was not yours, say so plainly and say how you would keep a test from running the teaching | F11 and F3 are the rows; the material is silent on both. VAL because the belief is published |
| V3 | "Every Child a Reader is our first belief. What does that mean to you in a fourth-grade room?" | VAL | [grounded] "I led our grade level's move to a new reading curriculum in 2024" and "I've run the after-school reading club for the last two years" | The page words it as "no student leaves third grade without a reading plan". Answer from what you think, using your quotes at their scope: the curriculum move and the club. Answer slot: if each student in your class had a reading plan, say how it worked in your own words; if there was no such plan, or it was not yours, say so plainly and stay with the move and the club. Then say what would change in fourth grade, as a plan | F7 is the evidence. VAL because the belief is published, and reading is the principal's subject |

### P. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Sixty seconds: why you over a candidate who has taught fourth grade?" | JD | [grounded] "I've never taught fourth grade" and "Six years teaching third grade at a public elementary school in Joliet." | Pause and restate the question. Hold: "For six years I taught third grade at a public elementary school in Joliet." Concede out loud: "I haven't taught fourth grade." Claim nothing about other candidates, since nothing in your material compares you with them. Offer what your quotes carry, the curriculum move, the club and the weekly email, and let them judge. Answer slot: if there is something else you honestly bring, say it; if you cannot compare, say so plainly. You do not have to fill all sixty seconds | F10 and F9 again, in the time-boxed form. JD because it scores fit to the grade |
| P2 | "A family emails you, angry about a grade. You have thirty seconds: how do you reply?" | CASE | [generic] | No claim about your past. Acknowledge the concern, ask what they have seen, offer a conversation, and name the next step. The district's published belief that each teacher speaks with every family each term supports offering a conversation | F5 and F6 are the requirement it touches. CASE because it is a live role problem under time pressure |

### Requirement coverage

| Requirement | Question IDs |
|---|---|
| F1 valid Illinois license with elementary endorsement | E1, E2 |
| F2 plan and teach five subjects | A5, C2, C3 |
| F3 differentiate using assessment data | V2, C2 |
| F4 clear classroom routines | B4 |
| F5 communicate regularly with families | D3, V1, P2 |
| F6 speak with every family each term | D3, V1 |
| F7 Every Child a Reader | V3, C3, D2 |
| F8 work with the grade-level team | A3, B1, B2, D1 |
| F9 experience in grades 3 to 5 | A1, E2 |
| F10 the fourth-grade position | A1, A2, P1 |
| F11 assessments inform teaching | V2 |
| District literacy plan (research) | C1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | To the principal: "You came to the principalship after years as a reading specialist. How does that shape what you look for in reading instruction in fourth grade?" | It ties to her own public path and shows you researched her, not only the school |
| R2 | To the principal: "Your talk on weekly reading conferences in grades 3 to 5 covers small groups. How does that show up in a fourth-grade week here?" | It uses her published theme and turns the C3 probe into a conversation |
| R3 | To the team, reciprocity: "What could a new teammate do in the first month that would genuinely help your team?" | The peers are pricing what the hire adds to their load; this shows you are thinking about theirs |
| R4 | "The board's literacy plan includes a new grades 3 to 5 reading curriculum from fall 2027. How is the fourth-grade team preparing, and where would a new teacher plug in?" | It uses current strategy from research and shows altitude beyond one classroom |
| R5 | "What does support look like for a teacher new to the grade, such as planning time with the team or a mentor?" | It names your gap as a plan for learning, and the answer tells you what the first weeks will be |
| R6 | "How do teachers here make the belief about speaking with every family each term work in practice?" | It shows you read the beliefs page and asks for the practical form, which tells you the workload |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Having taught fourth grade, or something equivalent to it | Negative you stated, F10 | The plain acknowledgment: "I haven't taught fourth grade." F9's third grade at its own scope |
| Being or having been a team lead | Negative you stated, F8 | The plain acknowledgment: "I've never been a team lead." The move quote at its own scope |
| Chose, designed or ran the whole curriculum the grade level moved to, or took it school-wide | Inflated form of F8's quote | The quote at its own scope. The limit is the pack's observation: your material says the grade level's move, not who chose the curriculum or how far it spread |
| Founded or built the reading club, or any attendance or result from it | Inflated form of F7's club quote | The quote at its own scope. Your material says you run the club, not how it began or what it produced |
| Speaking with every family each term | Inflated form of F5's and F6's quote | The quote at its own scope. Your material says a weekly email, not conversations |

## Sources

**Provided documents:** the invite text, and the résumé text and background you pasted. Identifying numbers in the pasted text were not used anywhere in this pack or in any search. No dossier was present.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | yes | F6, F7, F11 and V1 to V3. The three belief names and their wording come from the fetched page |
| 2. `{company} interview process {role family}` | skipped | The invite fixes the loop: one 45-minute panel, with who sits on it. Persona weights follow from that |
| 3. `{company} strategy` / recent news | yes | C1 and R4. Only a search summary line was read, not the plan itself |
| 4. `{interviewer name} {company}` | yes | The interviewer read, C3, R1 and R2. Only a search summary line was read |
| 5. representative `{role title}` JD | yes | F2 to F5, F8 and F9, labelled `[inferred]`; A5, B4 and C3 follow |

Queries, in the order sent:

- "Orrinsford Community School District values mission" returned https://orrinsfordschools.example/about/mission-and-beliefs, which was then fetched
- "Orrinsford Community School District strategic plan news" returned https://orrinsfordschools.example/news/board-adopts-literacy-plan, not fetched
- "Dolores Vantongeren Halvering Elementary School principal" returned https://ilprincipalsforum.example/speakers/dolores-vantongeren, not fetched
- "Illinois fourth grade teacher job posting requirements elementary" returned https://k12jobsboard.example/listings/fourth-grade-teacher, which was then fetched

## Upgrade menu

- Halvering's own posting text → F2 to F5, F8 and F9 move from `[inferred]` to `[grounded]`, and A5, B4 and C3 are re-checked against the real list
- The recruiter's note on what the panel will focus on, or any task they announce → coverage of that focus, and a build section if a task is announced
- The names and roles of the two team members → per-member persona weights and a tailored reverse question for each
- Your own answers to any answer slot (F2, F3, F4, F6, F7, F11) → those rows become grounded stories, and the matching questions regenerate
- A copy of your license record as the state shows it → F1 can move from medium to high
- A couple of past weekly emails to families → F5 can move from medium to high
- A `tuesday-dossier.md` from earlier fit work, if you have one → verified evidence and a prohibited-claims list that this pack otherwise builds locally
