I'm reading the last few reference sections of the prep skill before I write your pack. I'll have it shortly.
Before the prep, one thing in the invite: it says the process is "fully remote and is carried out entirely on Telegram", that "your interview will be a text chat here with our support team lead", and that "your offer and onboarding will be completed in this chat as well". A hiring process run wholly by chat is a known scam pattern. A chat alone doesn't show who you're dealing with. Until you've checked the invite, hold off on paying anything, depositing a cheque, or sending documents or bank details. Check it with Lumenvale through contact details you find yourself on its own website or careers page, not through this chat. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as `lumenvale-software_customer-support-specialist_interview_pack.md` in your working directory. It has 20 questions across six interviewer styles, a fit snapshot against the ad's four requirements, reverse questions, and a list of claims the pack won't coach. I built it as a single text-chat round with the support team lead, treated like a hiring-manager round. Web search was refused in this session, so nothing in it is about Lumenvale itself and the company question is marked generic.

The three things most likely to come up:
- **Software experience:** you said you've never worked for a software company, so expect it as the lead's first probe. A1 is the one to rehearse most: say it plainly, then give a forward-looking plan.
- **Escalations:** your message doesn't mention any, so expect a question on one. A3 is a scaffold for it that works either way.
- **Writing:** this interview is a writing sample, so keep replies short and re-read before sending. B1 and B4 practise live replies.

Say the word and I'll play the Skeptic on A1 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Do you have the full job ad text, and any lines from your CV about escalations or the quality of your written replies, that you can paste? They would turn the escalation and writing rows from open gaps into answers drawn from your own words.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: lumenvale-software_customer-support-specialist_interview_pack.md -----
# Interview prep pack: Customer Support Specialist (remote), Lumenvale Software

Interviewer: the support team lead, not named. Format: a text chat. Built as a hiring-manager-style round, since the lead would be the person who judges whether you can do the job. Company research was not available (see Sources), so company-specific questions are labeled `[generic]`.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values (none in this pack: no values round was detected) |
| EXP | Whether your stated experience survives follow-ups, and what was actually yours |
| JD | The ad's stated requirements, including your gaps |
| CO | What you know about the company and its customers |
| CASE | A live problem from the actual job, answered on the spot |

In a text chat your writing is scored while you answer. Keep replies short, in plain sentences, and re-read before sending.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — job ad, as you listed it | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message; "I trained four new starters on our refunds process last year" — your message | medium | [grounded] | none | No gap, but these are lines from your message with nothing inspected behind them, so expect a probe on what the work was. Lead in the quote's own terms: three years, an energy supplier, around 60 calls and emails a day. The figure is one combined count, so keep "calls and emails" together |
| F2 | "experience with Zendesk or a similar ticketing tool" — job ad, as you listed it | "I use Freshdesk every day" — your message | medium | [grounded] | presentation | Name the tool you use, in your own words: "I use Freshdesk every day." The ad says "or a similar ticketing tool", and whether Freshdesk counts as similar is the interviewer's call, so the words stay at the quote. A4 holds the probe on the tool the ad names |
| F3 | "clear written communication" — job ad, as you listed it | "answering around 60 calls and emails a day" — your message | low | [grounded] | discovery | Emails are in the quote; how well they were written is not. Answer slot: the ad's line makes a probe on how you write likely, and this interview is itself a text chat. If any of your replies were reviewed, scored or reused by others, say what happened, in your own words; if none were, say so plainly and stay with the emails you answered |
| F4 | "confidence handling escalations" — job ad, as you listed it | none given | none | [grounded] | discovery | Your material does not show an escalation either way, so this is a gap to open, not a negative. Answer slot: if you handled or passed on any escalation, say what happened and which part was yours, in your own words; if you did not, or it was not yours, say so plainly and stay with the calls and emails you answered |
| F5 | Working inside a software company's product and terminology — role-family requirement, no source | "I've never worked for a software company" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked for a software company." Then how you would learn it, said as a plan in the future tense and never as a past. Never a claim to software work, and nothing added to make the gap feel smaller |

## Persona table

The loop is one text chat with the support team lead, from your own words, so weights come from the hiring-manager prior in the persona model and from the gaps in the snapshot. The lead's own style is unknown.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A) | Quiet probing of "never worked for a software company" and of escalations | High: F5 is a gap you stated and F4 has no evidence either way, and a hiring manager is derisking gaps | Rehearse the software objection until it is boring: plain acknowledgment, then a plan. Highest-ROI prep in this pack: A1 |
| Case/Strategist (bank B) | A customer scenario to answer live, probably in writing | High: hiring-manager prior, and F3 is scored by watching you write | Clarify first, structure the reply, say what you would not promise |
| Conversational (bank C) | Friendly opener, "walk me through your journey" | Medium: any first chat opens this way, and casual questions are still scored | A 90-second arc built only from your own sentences |
| Data-Driven Prober (bank D) | Reads your lines closely: the 60 a day, the four new starters, Freshdesk | Medium: you gave two figures and a tool, each a thing to defend | Know how each number was counted, and say plainly if you do not |
| Pressure (bank E) | "Why you over someone from software support?" | Low to medium: the escalations line invites a composure test, but a text chat softens interruptions | Hold your position through two follow-ups, then concede specifically |
| Peer Evaluator (bank G) | Working with product, billing or other teams | Low: the lead is not a peer, but the job sits between customers and other teams | Offer what you bring them, not only what you need |

## Question banks

Coverage line, requirement to question IDs:

| Requirement | Questions |
|---|---|
| "2+ years in customer support" | C1, C2, D1, D2, E1 |
| "experience with Zendesk or a similar ticketing tool" | A4, D3 |
| "clear written communication" | B1, B4 |
| "confidence handling escalations" | A3, B1, B2, B3 |
| Software-company gap (F5, not an ad line) | A1, A2, B3, B5, E1 |

### A. Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've said you haven't worked for a software company. How would you get up to speed on ours?" | JD | [grounded] "I've never worked for a software company" | The highest-ROI rehearsal in this pack. Level 1: the plain acknowledgment, in your words: "I've never worked for a software company." Then a plan in the future tense: what you would read first, who you would ask, how you would check you had understood. Level 2, if pushed on what worries you most: name one real worry and the step you would take on it. Level 3, if asked what you have done so far: answer slot, if you have looked at their product or help pages before the chat, say what you noted; if not, say so plainly and say what you will read first. Hold the acknowledgment through every follow-up and never describe software work you have not done | F5 is the gap you stated and the likeliest place the lead probes, so it gets the most follow-up levels. JD because it scores whether you can do the listed job despite the gap |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company" | Pick the weakest part honestly rather than a disguised strength. F5 and F4 are the two the pack shows, so choose the one that is true for you. For F5 the words are the quote above, then the plan. Answer slot: if you pick escalations, say whether you have handled any, in your own words; if not, say so plainly and say how you would learn | The stem is the Skeptic's standard opener and lands on F5 and F4 whichever you pick. JD because it scores honest self-assessment against the listed requirements |
| A3 | "Tell me about a time a customer's problem went beyond what you could resolve yourself." | EXP | [grounded] "answering around 60 calls and emails a day" | Selection scaffold: pick one with a named customer problem, what you did, who it went to, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is calls and emails answered, or how you would handle it. Say only what you did, and which part was yours | F4 has no evidence, so this is where the ad's escalation line gets tested. EXP because it scores what was actually yours |
| A4 | "Which ticketing tools have you worked in, and which would be new to you?" | JD | [grounded] "I use Freshdesk every day" | Say it as you said it: "I use Freshdesk every day." Answer slot: if asked about Zendesk, say whether you have used it; if you have, say where and for what, in your own words; if not, say so plainly and return to Freshdesk | F2 is the evidence for the tool requirement and the ad names a different tool. JD because it scores a stated requirement |
| A5 | "Why this move, and why now?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" | Give your actual reason, in your own words. The pack supplies none. If you have no settled reason, say what draws you to this role and keep to what is true | A motivation probe is standard for a move into a new sector, and F5 makes it likelier. EXP because it tests whether your story is consistent |

### B. Case/Strategist (high weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer writes in for the third time about the same unresolved problem, and they're angry. Write me your reply." | CASE | [generic] | Structure: acknowledge the repeat plainly, restate the problem in one line, say what you can do now, say what you cannot promise, say who it goes to next and what you will tell them, say when they will hear back. Short sentences, no templates. The question needs no claim about your past, so the guidance makes none | Combines F3's writing probe and F4's escalation probe in one live problem. CASE because it asks for a reply on the spot |
| B2 | "A customer asks for a refund the policy doesn't allow. What do you do?" | CASE | [generic] | Clarify first: what the policy actually says and what route exists for exceptions. Then say what you can offer, what you cannot, and who decides the rest. Never promise a refund you cannot give | Escalation judgment (F4) in a familiar domain for a refunds-heavy support role. CASE because it is a decision, not a history |
| B3 | "A ticket comes in about a feature you've never seen. What do you do in the next ten minutes?" | CASE | [generic] | Clarify what the customer sees, ask for what you need, check what is documented, tell the customer honestly what you know and do not, and escalate with a clean summary if you cannot resolve it. Never guess | F5 is the gap this tests live, and the summary-on-escalation beat touches F4. CASE because it is a live problem |
| B4 | "A customer says the app logged them out and they lost their work. Write your first reply, here, now." | CASE | [generic] | Greeting, acknowledgment, what you are doing, what you need from them, what to expect next. Do not promise a fix or a cause. Re-read before sending | F3 is scored by watching you write, and a text chat is where that happens. CASE because it is live, JD content |
| B5 | "What do you know about Lumenvale and who our customers are?" | CO | [generic] | No company research was available for this pack, so nothing here is about Lumenvale. Before the chat, read their product and help pages, note two things you can say back in your own words, and say plainly what you did not find | A company-knowledge probe is standard, and F5 raises its weight. CO because it scores homework |

### C. Conversational (medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey. How did you end up in customer support?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" | A 90-second arc: the role and the three years as the quote states them, then your own words for how you got there and where you want to go. Answer slot: give your real route, and if it was not planned, say so | F1 is the headline evidence, so the arc starts there. EXP because it tests whether your story is consistent |
| C2 | "What does a day look like for you at the moment?" | EXP | [grounded] "answering around 60 calls and emails a day"; "I use Freshdesk every day" | Beats the quotes carry: calls and emails, around 60 a day, Freshdesk every day. Anything beyond that is your own words; if a part of the day was not yours, say so | F1 and F2 are the evidence, and a casual day question is still scored. EXP because it tests what the work was |
| C3 | "What do you like most and least about support work?" | JD | [generic] | Pick one true thing you like and one true thing that wears on you. The second must be a real cost, not a strength in disguise | Casual questions about the job itself are scored for honesty. JD because it scores fit with the role |

### D. Data-Driven Prober (medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You said around 60 calls and emails a day. How was that counted?" | EXP | [grounded] "answering around 60 calls and emails a day" | Keep it as you said it: around 60, calls and emails together. Answer slots, each in your own words: how it was counted, what it moves with, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly | F1's figure is the defend-the-number target. EXP because it tests attribution |
| D2 | "You trained four new starters on your refunds process. What was your part, exactly?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Beats the quote carries: four new starters, the refunds process, last year. Answer slot: if you chose what to cover or how, say how; if the content was set by someone else, or the training was shared, say so plainly and stay with the four new starters | F1 holds this as the second figure. EXP because it tests what was actually yours |
| D3 | "How do you use Freshdesk day to day?" | JD | [grounded] "I use Freshdesk every day" | Start from the quote. Answer slot: say what you do in it in your own words; if there are parts of it you have not used, say so plainly | F2 is the tool evidence. JD because it scores the tool requirement |

### E. Pressure (low to medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has already worked in software support?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day"; "I've never worked for a software company" | Hold what the first quote carries, in your words. Concede the second quote plainly. Hold through two follow-ups, then concede only what is true. Never claim to be better than the other candidate | F5 is what this question presses. JD because it scores the fit for the listed job |
| E2 | "Fast isn't the same as good. How did you know your answers were right?" | EXP | [grounded] "answering around 60 calls and emails a day" | Answer slot: if there was any feedback, quality check or customer response you saw, say what, in your own words; if there was none, say so plainly and stay with the calls and emails you answered. Hold your position through two follow-ups, then concede what you do not know | F1's volume invites this challenge and F3 is scored the same way. EXP because it tests attribution |

### G. Peer Evaluator (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Support often needs something from another team. What would you need from them, and what would you give back?" | CASE | [generic] | Offer both sides: what you need to resolve a case, and what you bring them, such as clear summaries. Propose principles for the handoff rather than pretending to know the seam | The job sits between customers and other teams, and F4 involves handing cases on. CASE because it is a working scenario |
| G2 | "Tell me about a time you disagreed with a colleague about how to handle a customer." | EXP | [generic] | Selection scaffold: pick one with a named disagreement, what you said, and an intact working relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A disagreement probe is the peer's standard test. EXP because it asks for a real instance |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What does a strong first month look like for someone new to software support?" | It faces the software gap in F5 without apologising, and gives you the lead's own bar to prepare against |
| 2 | "Which kinds of tickets stay with the first person who picks them up, and which come to you?" | Shows you take escalations seriously, the F4 requirement, and tells you what the lead will test |
| 3 | "How does the team judge whether a written reply was good?" | Written communication is an ad requirement, and the answer tells you the standard |
| 4 | "What happens after this chat? Is there a call or a video conversation next, and what should I prepare for it?" | A prep question: it tells you whether another round exists and what it will cover |
| 5 | "What could a new person do in their first month that would genuinely help your team?" | A reciprocity question: it shows you think about the team's load, not only your own start |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has worked for a software company or in software support | Negative the candidate stated, F5 | The plain acknowledgment F5 gives: "I've never worked for a software company." Then a plan, never a past |
| Owned or designed the refunds process | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says you trained four new starters on it, not that you owned it. D2's slot stays inside the training |
| 60 calls plus 60 emails a day | Inflated form of F1 | The quote at its own scope: "answering around 60 calls and emails a day". The material gives one combined figure |

## Sources

Provided documents: your message, which held the invite text, the ad's four requirements as you listed them, and your background. No `tuesday-dossier.md` was present.

Searches sent, all refused by the host: "Lumenvale Software company values", "Lumenvale Software interview process customer support specialist", "Lumenvale Software news strategy". No page fetches were sent.

Research tier: L1 — searches 3 of 6 sent, all refused; fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale Software values | unavailable | Would have given the company's values by name for values-themed questions; B5 and any values questions stay `[generic]` |
| 2. Lumenvale Software interview process, support role | unavailable | Would have named any later rounds; the one upcoming round comes from your own words, so session-mode weights stand |
| 3. Lumenvale Software strategy and recent news | unavailable | Would have grounded B5 in current priorities; B5 stays `[generic]` |
| 4. Interviewer name and company | n/a | The support team lead is unnamed, so there was no query to form; the interviewer read is absent |
| 5. Representative support specialist JD | skipped | The four requirements you listed fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full job ad text → the four requirement quotes come from the ad itself, and any mid-list requirement you did not mention gets a question
- Any sentence about escalations or the quality of your written replies → F3 and F4 stop being discovery rows, and A3 and E2 become story-mapped
- Your CV → evidence cells draw on CV lines as well as your message, and F1 and F2 may move up from medium
- The support team lead's name or public profile → an interviewer read, tuned persona weights, and a reverse question tied to their path
- Anything the recruiter said about what the chat covers → coverage tuned to it, and a deliverable build section if one was named
- Web search allowed, or Lumenvale's values and product pages pasted → B5 and any values questions move from `[generic]` to `[grounded]`; a deeper research pass is also available, up to 6 more searches and 2 more fetches, several more minutes, offered once
- How much prep time you have → a prioritized schedule instead of the full pack
- A `tuesday-dossier.md`, if you have one → verified evidence and prohibited claims in place of the ones built here
