Your prep pack is saved as /var/tmp/tuesday-measure/1a6/runs/sonnet/alone/part-5/rooms/case-9-canned-ffe87854/halvering-elementary_fourth-grade-teacher_interview_pack.md.

The SSN in your resume text isn't needed for interview prep. I didn't use or repeat it, so you may want to take it off any copy you share.

I built the pack for the panel as the district's hiring page describes it: one 45-minute session with the principal and two teachers. Your license row is marked as met on your own stated details. I left your license number out of the pack and out of every search.

- **Biggest gap:** B1 is the question the pack names as your highest-ROI rehearsal: "I don't see fourth-grade teaching in your background." The pack coaches you to say "I've never taught fourth grade" before they do, and then hold to your six years in third grade.
- **Research:** I ran the standard research pass, and the pack lists each search it used. It found the district's three published beliefs, the principal's background as a reading specialist, and an August 2026 board literacy plan with a new grades 3–5 reading curriculum from fall 2027. The principal and literacy-plan facts come from search excerpts, not full pages.

Say the word and I'll play the skeptical principal on B1 so you can rehearse the follow-ups out loud.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Do you have the posting's full text? Pasting it would replace the two rows built from a representative listing.
2. Did HR or the recruiter say anything about focus areas or what to prepare? It would replace my assumption that the panel covers its published topics.
3. Do you want a deeper research pass? It's up to 6 more searches and 2 more fetches, takes several more minutes, and would add a district strategy brief.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: halvering-elementary_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)

**Round:** one 45-minute panel on Thursday, per your invite: Principal Dolores Vantongeren and two members of the fourth-grade team.
**Built on this assumption:** no posting text was supplied, so requirements come from your invite, the district's own pages, and one representative listing excerpt (labeled inferred where used).

## How to use this pack

Personas describe how a question is asked; types describe what it scores. Guidance is scaffolding, not a script: speak it in your own words, and only about what you actually did.

| Tag | Meaning |
|---|---|
| VAL | Whether your past behavior shows the district's published beliefs |
| EXP | Whether the claims on your CV survive follow-up; what was actually you |
| JD | The role's stated requirements, gaps included |
| CO | What you know about the district and its current direction |
| CASE | A live classroom problem: structure and reasoning |

Label key: `[grounded]` traces to your documents or cited research; `[inferred]` is derived from an adjacent source; `[generic]` is a pattern with no claim about you or the district. An answer slot is an instruction for the interview, not a question for you now: answer it from your own experience or say plainly it was not yours.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — your invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | A gate your material shows met. Say it as written: kind, endorsement, grades, status, expiry. It is a CV line with nothing inspected behind it, so confirming that your public license record reads the same is yours to do |
| F2 | The Fourth Grade Teacher position — your invite | "Six years teaching third grade at a public elementary school in Joliet" — your CV; "I've never taught fourth grade" — your CV | medium | [grounded] | transferability | Words: "I've never taught fourth grade." Then the adjacent work at its own scope: "Six years teaching third grade at a public elementary school in Joliet." Your endorsement line as written covers grades 1–6, which is a reading of your CV, not a district statement. Answer slot: expect a probe on what changes between third and fourth grade. Say what you know in your own words; if you have not looked into it, say so plainly and say how you would find out |
| F3 | Work with the grade-level team — representative listing excerpt, not read in full | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your CV | medium | [inferred] | transferability | Words: "I've never been a team lead." Then the move at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Your material says a grade-level move, and nothing about what leading it involved. Answer slot: the district's panel topic of reading instruction makes a probe on the move likely. Say what you did in it, in your own words; if parts were decided by others, or there was no such step, say so plainly and return to the sentence |
| F4 | "Panels ask about reading instruction, classroom routines and how you work with families." — district hiring page (reading instruction) | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | discovery | Your material says a curriculum move and a club, and does not show what daily reading teaching looks like. Answer slot: describe a typical week of reading in your classroom in your own words; if part of it is set by the curriculum or by others, say which |
| F5 | "Panels ask about reading instruction, classroom routines and how you work with families." — district hiring page (classroom routines) | none given | none | [grounded] | discovery | Your material does not show this. Answer slot: say which routines you run in your classroom, in your own words; if the school sets them, or you run few, say so plainly and say how you would set them up in a new room |
| F6 | "Families Are Partners: each teacher speaks with every family each term." — district mission page | "I write a weekly email to families" — your CV | medium | [grounded] | transferability | The quote says a weekly email; the belief says speaking with every family each term. Hold the email at its own scope. Answer slot: if you speak with families directly, say how and how often in your own words; if the email is the main channel, say so plainly and stay with the email |
| F7 | "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it." — district mission page | none given | none | [grounded] | discovery | Your material does not show this. Answer slot: say what you do with assessment results in your own words; if little or nothing, say so plainly and say how you would |
| F8 | Plan and teach reading, writing, math, science and social studies — representative listing excerpt, not read in full | "Six years teaching third grade at a public elementary school in Joliet" — your CV | medium | [inferred] | discovery | Your CV line does not say which subjects you taught. This requirement comes from an excerpt, which raises no probe by itself; if it comes up, name the subjects you taught in your own words and say plainly which would be new |

## Reading the interviewer

| Item | Detail | Provenance |
|---|---|---|
| Career pattern | Principal of Halvering Elementary School since 2022, after nine years as a reading specialist | [grounded] Illinois principals forum speaker page, search excerpt |
| Published talk | 2025 forum talk "Small Groups, Big Readers", covering weekly reading conferences in grades 3 to 5 | [grounded] same page |
| Self-described style | None found beyond the talk's title and summary; nothing is inferred about personality | [grounded] same page |
| Implication 1 | Expect depth on reading: what a reading week looks like and how readers are grouped (E3, A2, C3) | [inferred] from her career and talk |
| Implication 2 | Your material does not show whether you run reading conferences or small groups; if asked, answer from what you actually do (F4 slot) | [inferred] |
| Implication 3 | Her talk covers grades 3 to 5, so a third-to-fourth move sits inside her range of interest; B1 is where that surfaces | [inferred] |
| Mirror opportunity | Shared vocabulary only, no shared career jump: reading. Offer the club at its own scope, F4: "I've run the after-school reading club for the last two years" | [grounded] |
| The two teachers | Unnamed in the invite; no profile | n/a |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A Peer Evaluator | The two fourth-grade teachers ask about the seam between you and the team, disagreement, and what you'd need | High. The invite names two fourth-grade team members; the peer prior is Peer Evaluator plus Prober. Your CV says you have not taught fourth grade or been a team lead (F2, F3), which peers re-ask collegially | Reciprocity: what you bring and what you'd ask of them; propose seam principles rather than pretending to know their seam; a disagreement story only if a real one comes to mind |
| B Skeptic | The principal probes the gaps: fourth grade, team role, why here, why now | High. The principal's seat is a hiring-manager prior (Case plus Skeptic) and your own CV states two gaps (F2, F3). B1 is the pack's highest-ROI rehearsal | Rehearse B1 until it is boring; say the limit before it is asked; bridge only with the quotes in F2 and F3 |
| C Case/Strategist | Live classroom problems | Medium. The district page says panels ask about classroom routines and reading instruction (F4, F5), and a routines question is naturally a live problem | Clarify, objective, approach, how you'd tell it worked, risks; think aloud; no claims about your past |
| D Values/Behavioral | Stories mapped to the district's three beliefs | Medium. The district says three beliefs guide every hire, and its hiring page names families as a panel topic. No page documents a separate values round, so this is not weighted high | Where a quoted sentence carries a story, use it at its scope; otherwise pick a real instance, and say plainly if none comes to mind |
| E Conversational | Opening biography prompt, friendly reading questions | Medium. No source says how the panel opens; a 90-second arc is cheap insurance | Build the arc only from your quoted sentences (E1) |
| F Prober | Line-by-line reading of your CV for what was yours | Low. Your CV states no figures to defend, so there is no defend-the-number question; the principal's reading background may still bring attribution probes | Hold each sentence at its own scope (F1, F2) |

Pressure/Stress is left out: no source or signal in your material or the district's pages points to it.

## Question banks

### A. Peer Evaluator (weight high, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Tell us what you'd bring to our fourth-grade team, and what you'd hope to learn from us." | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years" | Two halves. Bring: those two sentences at their own scope, in your own words. Learn: something you actually want to ask a fourth-grade team, said in your own words. Add nothing about outcomes | F3 and F4 are the evidence. JD because it scores the team requirement; reciprocity is the peer move |
| A2 | "Tell us about the move to a new reading curriculum at your grade level." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | The beats the sentence states: your grade level, a new reading curriculum, 2024, led. Answer slot: expect a probe on what the move involved and which parts were yours. Say what you did in your own words; if something was decided by others, or there was no such step, say so plainly and return to the sentence | F3 and F4 are where peers dig first; EXP because it tests attribution |
| A3 | "Tell us about a time you and a teammate disagreed about how to teach something." | EXP | [generic] | Selection scaffold: pick a time with a named stake, what you said and how, how it ended, and the working relationship after; "I" for your part, "we" for the team. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Peer stem on disagreement style; F3 is the team requirement it scores |
| A4 | "Where does the team's work stop and a teacher's own classroom begin? What would you share with us and what would you decide yourself?" | CASE | [generic] | Offer principles, not claims about their team: ask what the team already shares, then say your own principle in your own words. No claim about your past is needed | Seam-splitting is the peer's native question; F3 |
| A5 | "You haven't taught fourth grade yet. What would you need from us in your first month?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet" | Open with the limit in your words, then the adjacent work at its scope. Then name what you would actually ask of them, in your own words, and what you'd offer in return (A1). Claim nothing about fourth grade | F2 in collegial packaging; the B1 objection returns here |

### B. Skeptic (weight high, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "I don't see fourth-grade teaching in your background. How would you handle that?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet"; "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | **Highest-ROI prep in this pack.** Hold: "Six years teaching third grade at a public elementary school in Joliet." Concede first, before asked: "I've never taught fourth grade." Then what you know about fourth grade and how you would learn the rest, as a plan in your own words. Answer slot: if you have looked into what fourth grade asks, say what; if you have not, say so plainly and say how you would find out. Follow-ups to rehearse: "What specifically will be different?" and "What if it's harder than you expect?" Hold through both by returning to the sentence and the concession, never by adding experience | F2 is the biggest gap in your material and this question will arrive in some form; JD because it scores the role itself |
| B2 | "You haven't been a team lead. How would you contribute to a fourth-grade team?" | JD | [grounded] "I've never been a team lead"; "I led our grade level's move to a new reading curriculum in 2024" | Say "I've never been a team lead" plainly, then the move at its own scope. Do not call yourself a team lead or describe leading beyond your grade level. Answer slot: if asked what leading the move involved, say what you did in your own words; if parts were others', or there was no such step, say so | F3 gap stated by you; JD because it scores the team requirement |
| B3 | "Walk us through your licensure." | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | Say it as written: Illinois, Professional Educator License, Elementary Education endorsement, grades 1–6, registered and active through June 30, 2029. Add nothing. If asked for details beyond that, answer from your own record, not from memory | F1 is the gate in your invite; a short, clean answer closes it |
| B4 | "Why Halvering, and why fourth grade now?" | EXP | [grounded] | Give your real reasons in your own words. If you tie to the district, use only what is true for you: its beliefs include "Every Child a Reader", and its board adopted a literacy plan in August 2026. If the move has no single reason, say so plainly and say what you want next | F2; the skeptic's why-here, why-now probe. Research per Sources |

### C. Case/Strategist (weight medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "It's the third week of school and your class struggles to settle after transitions. What do you do?" | CASE | [generic] | Structure aloud: what you'd want to see first, the goal, what you'd try, how you'd tell it worked, what could go wrong. No claim about your past is needed | F5; the district page says panels ask about classroom routines |
| C2 | "A fourth grader's first reading assessment comes back well below the class. Walk us through what you do next." | CASE | [grounded] | Clarify what it measured and what else you know; set the goal; small next steps; how you'd keep the family informed; when you'd check again. The district's own line, "assessments inform teaching and never replace it", is theirs: echo it as context, not as something you claim to have done | F7 and F4; CASE because it asks for reasoning on a live problem |
| C3 | "The board adopted a literacy plan this August that includes a new grades 3–5 reading curriculum from fall 2027. How would you get ready to teach fourth grade through that change?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Ask before assuming: what you'd want to know about the plan. Then what you'd learn and how you'd contribute. Quote your move only at its scope. Answer slot: if asked what from your move would carry over, say in your own words; if little would, say so plainly. Don't recite the plan back; they know it | F2, F3, F4. The plan comes from a search excerpt of the district's news page, not read in full |

### D. Values/Behavioral (weight medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Every Child a Reader: no student leaves third grade without a reading plan. Tell us about a time you supported a reader who was behind." | VAL | [grounded] "I've run the after-school reading club for the last two years" | Selection scaffold: pick a real instance with a named reader, what you did, and where it ended up. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, the club at its own scope, or how you would handle it | F4; first published belief, and you teach third grade |
| D2 | "Families Are Partners: each teacher speaks with every family each term. How do you work with families?" | VAL | [grounded] "I write a weekly email to families" | Beats the sentence states: weekly, written, to families. Answer slot: expect a probe on conversations beyond email. If you speak with families directly, say how and how often in your own words; if the email is the main channel, say so plainly and stay with it | F6; the belief and the panel topic both name families |
| D3 | "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it. Tell us about a time assessment results changed what you taught." | VAL | [grounded] | Selection scaffold: a specific unit or group, what the results showed, what you changed, how you knew. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F7; third published belief |

### E. Conversational (weight medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk us through your journey to this point." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families" | A 90-second arc built only from those four sentences, in your own words, ending with why fourth grade and why Halvering (B4) in your own words | F2, F3, F4, F6 together; the casual opener is still scored |
| E2 | "Tell us about the reading club." | EXP | [grounded] "I've run the after-school reading club for the last two years" | Beats the sentence states: after school, a reading club, two years, you ran it. Answer slot: expect a probe on what a session looks like. Say it in your own words; if parts were run by others, say so plainly | F4; the panel asks about reading instruction |
| E3 | "What does a good week of reading look like in your classroom?" | JD | [grounded] | Open: describe an actual week in your own words. Answer slot: if part of it is set by your curriculum, say which; if you are not sure how to describe it yet, say so plainly and say what you aim for | F4; the principal's reading background makes this likely |

### F. Prober (weight low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "How much of the curriculum move was your decision, and how much was decided elsewhere?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Hold the sentence at its scope: your grade level's move. Answer slot: say which parts were yours; if something was decided by others, or you made no decision in it, say so plainly and return to the sentence. Concede specifically, not in general | F3; an attribution probe |
| F2 | "Which subjects did you teach in third grade, and which would be new to you in fourth?" | JD | [inferred] "Six years teaching third grade at a public elementary school in Joliet" | Name the subjects you taught, in your own words, and say plainly which would be new. The subject list comes from a representative listing, so treat it as typical for the role, not this team's practice | F8, F2; line-by-line reading of your CV |

### Requirement coverage

| Requirement | Question IDs |
|---|---|
| License gate (F1) | B3 |
| Fourth Grade Teacher (F2) | B1, A5, B4, C3, F2 |
| Grade-level team (F3) | A1, A2, A3, A4, B2, F1 |
| Reading instruction (F4) | E3, E2, A2, C3, D1 |
| Classroom routines (F5) | C1 |
| Families (F6) | D2 |
| Assessments inform teaching (F7) | C2, D3 |
| Subjects (F8) | F2 |
| Belief: Every Child a Reader | D1 |
| Belief: Families Are Partners | D2 |
| Belief: Teach for Tomorrow, Not for the Test | D3 |

## Reverse questions

| # | Question to ask them | Why it lands |
|---|---|---|
| 1 | "Your talk covered weekly reading conferences in grades 3 to 5. What does that look like in fourth grade at Halvering now?" | Ties to the principal's own published work; shows you looked at her, not only the school |
| 2 | "You came to the principal's seat after nine years as a reading specialist. How has that shaped what you want to see in a fourth-grade reading block?" | Ties to her career path; turns an interview into a peer conversation |
| 3 | To the two teachers: "What could a new fourth-grade teacher do in the first month that would genuinely help the team?" | The reciprocity question for peers; signals you are pricing the team's load |
| 4 | "The board's literacy plan includes a new grades 3–5 reading curriculum from fall 2027. How will fourth-grade teachers be involved before then?" | Shows current awareness of a specific recent move without reciting it |
| 5 | "What would a good first term look like for a new fourth-grade teacher here?" | Gets the success bar in their words, which tells you what is scored |
| 6 | "What are the next steps after today, and what's the timeline?" | Practical; the district page says references follow the panel, so the next step is real |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | Negative you stated, F2 | "I've never taught fourth grade." Then the third-grade quote at its scope. B1 and A5 slots stay on what you know and would learn |
| Has been a team lead | Negative you stated, F3 | "I've never been a team lead." Then the move at its scope |
| Led the school's or district's move to the new curriculum | Inflated form of F3 | The quote at its own scope: "I led our grade level's move to a new reading curriculum in 2024." The pack's observation: your material says a grade-level move |
| Chose, wrote or designed the curriculum | Inflated form of F3 | The same quote at its scope. F1 and A2 slots ask only which parts were yours |
| Speaks with every family each term | Inflated form of F6 | "I write a weekly email to families." The pack's observation: your material says email |

## Sources

Provided documents: the invite text and your resume text. A government ID number in the resume text was neither used nor repeated.
No dossier was supplied.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| # | Target | Status | What it moved, or would have |
|---|---|---|---|
| 1 | District values | yes | F6, F7, D1 to D3: three beliefs by name, fetched from the mission page |
| 2 | Interview process | yes | Panel structure and panel topics, fetched from the hiring page; persona weights follow it |
| 3 | Strategy and recent news | yes | C3 and reverse question 4: board literacy plan, August 2026, from a search excerpt only |
| 4 | Interviewer public footprint | yes | Reading the interviewer, reverse questions 1 and 2, E3 |
| 5 | Representative JD | yes | F3 and F8, labeled inferred; the excerpt was cut off mid-sentence and the cut part is not used |

Searches sent, by query:
- "Orrinsford Community School District mission values" → https://orrinsfordschools.example/about/mission-and-beliefs
- "Orrinsford Community School District teacher interview process panel" → https://orrinsfordschools.example/careers/how-we-hire-teachers
- "Orrinsford Community School District strategic plan news" → https://orrinsfordschools.example/news/board-adopts-literacy-plan
- "Dolores Vantongeren principal Halvering Elementary School" → https://ilprincipalsforum.example/speakers/dolores-vantongeren
- "fourth grade teacher job description Illinois elementary school" → https://k12jobsboard.example/listings/fourth-grade-teacher

Pages fetched: the mission page and the hiring page above.

## Upgrade menu

- The posting's full text → F3 and F8 move from `[inferred]` to `[grounded]`, and the JD-tagged questions gain stated requirements
- The recruiter's prep note or focus areas → coverage assumed from the panel's published topics gets replaced by theirs
- The two teachers' names and roles → per-member persona weights and a reverse question tied to each path
- Your own answers to the slots in F2 to F8 → each quoted into the snapshot, rows regenerated, confidence raised where it earns it
- A copy of your public license record → F1 moves from medium to high
- The full text of the board's literacy plan → C3 and reverse question 4 rest on the plan itself, not an excerpt
- A `tuesday-dossier.md` from an earlier fit review → verified evidence and strategy limits per gap, in place of this pack's local prohibited list
