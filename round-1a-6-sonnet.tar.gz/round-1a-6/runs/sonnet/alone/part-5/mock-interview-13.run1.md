I'll read the reference files the skill points to before building the pack.
Your prep pack is written, and I'm now sending the summary. I built it for the recruiter screen with Hannah, from her stated agenda and the advert. Web search permission was refused, so there's no research on Quillmoor or Hannah. The pack says so in its Sources section, and company knowledge comes only from the advert.

The pack is saved at `/var/tmp/tuesday-measure/1a6/runs/sonnet/alone/part-5/rooms/case-13-denied-9a682b84/quillmoor-diagnostics_operations-coordinator_interview_pack.md`. It has 18 questions and 6 reverse questions.

- **Her four topics (A1–A4):** Pay, notice, hybrid and reason for moving are almost certain to come up. Your own words fill each one, with nothing added. For example, "I'm hoping for £42,000", and that two days at Avonmouth is fine but you wouldn't want more than three. If she asks what you earn now, the pack gives you a line to decline without a figure.
- **Notice period (A3):** You haven't given me yours, so that answer is for you to fill in. The pack supplies none.
- **Highest-ROI rehearsal (B1):** This is "what's the closest thing you've coordinated?" to the advert's production scheduling across planning, the warehouse and QA. Your material says delivery scheduling for three depots, so the pack holds you to that and doesn't stretch it.
- **SAP and Excel:** For SAP, you say "Never used SAP" and add that you run an in-house stock system. Your stock-count sentence doesn't say Excel, so B3 is a slot for you to answer yourself.
- **Stock-discrepancy figure (C1, D2):** The pack coaches how it was counted and which part was yours. It doesn't supply a method or a baseline.
- **Prohibited claims:** The pack lists things it won't coach, such as "has ERP experience" and "open to Reading". These sit beyond what you told me.

Say the word and I'll run a live drill as Hannah on B1. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to Word.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor-diagnostics_operations-coordinator_interview_pack.md -----
# Interview pack: Operations Coordinator, Quillmoor Diagnostics

Recruiter screen with Hannah Lowther (Talent Partner): a 30-minute phone call, Thursday at 2pm, booked on LinkedIn. She will ring the mobile number on your application. Her stated agenda: salary expectations, notice period, how the hybrid pattern would work for you and what is prompting a move, then the team and next steps. Session mode, first version.

## How to use this pack

Personas describe how a question is asked; types describe what it is scoring. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it is scoring |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether the claims on your background survive scrutiny, and what was actually yours |
| JD | The advert's stated duties, requirements and terms, gaps included |
| CO | What you know about the company and why this one |
| CASE | A live problem from the role, reasoned aloud |

Provenance labels: `[grounded]` traces to something you or Hannah wrote, or to the advert; `[inferred]` is derived from an adjacent source; `[generic]` is a role-family pattern with no claim about you or Quillmoor. In the question banks, your own sentences follow the label wherever the guidance rests on them. Where a cell says "answer slot", it is an instruction for the interview, not a question for you now.

The highest-ROI rehearsal in this pack is B1. Hannah's four logistics topics (A1 to A4) are certain to come up, but each needs only your own words. B1 is the objection most likely to follow you into later rounds, because it sits where your material is thinnest against the advert's headline duty.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material says deliveries for three depots, not production schedules, with nothing inspected behind it, and the words stay there: "I schedule deliveries for our three depots." Answer slot: the advert's planning, warehouse and QA line makes a probe on who you coordinated with likely. If any of the deliveries you scheduled involved agreeing timing with other teams, say which teams and what part was yours, in your own words; if none did, or it was not yours, say so plainly and stay with the deliveries |
| F2 | "track supplier deliveries and chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it, so expect a probe. Lead with the sentence in its own terms: you chase suppliers when orders slip. A named action beats an adjective |
| F3 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | No gap, but a figure with nothing inspected behind it, so expect the prober's questions: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Keep "about a third" as "about", and keep the order of your own sentence |
| F4 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material does not show whether you report on delivery or dispatch performance. Answer slot: if you report on how deliveries perform today, say what and how often, in your own words; if you do not, say so plainly and stay with "I schedule deliveries for our three depots and chase suppliers when orders slip." |
| F5 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | No gap: your quote already reaches the requirement in role-relevant terms. Say it as you wrote it |
| F6 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [grounded] | discovery | Your sentence says a spreadsheet and does not say which tool. Answer slot: if it was in Excel, say so and what you built in it, in your own words; if it was another tool, or someone else did the building, say so plainly and stay with the spreadsheet you rebuilt |
| F7 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system." — your message | medium | [grounded] | transferability | The advert calls ERP a plus. Your words are your own sentence, both halves: "Never used SAP — we run our own in-house stock system." Your material says an in-house stock system, not an ERP. Answer slot: if you want to say what you use the in-house system for, say it in your own words; if you would not call it similar, say so plainly. Then how you would learn SAP, said as a plan and never as a past |
| F8 | "£38,000–£44,000" — advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | No gap: your figure sits inside the advertised band. The words are your own, nothing added: "I'm hoping for £42,000." |
| F9 | "Hybrid: two days a week at our Avonmouth site in Bristol." — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | No gap: the advert's two days sits inside your stated limit. The words are your own sentence, both halves, nothing added |
| F10 | "what's prompting a move" — Hannah's message | "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | medium | [grounded] | none | No gap. Say it in your own words and add nothing to it; if she follows up, your own words were that sentence |
| F11 | "your notice period" — Hannah's message | none given | none | [grounded] | discovery | Your material does not state your notice period. Logistics slot: give your actual notice period, in your own words |

## Persona table

The loop beyond this call is not documented (no loop source covers it), so the weights below are for this call only: Hannah's own stated agenda plus the recruiter-screen prior.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly, unstructured; her four named topics asked as chat | Highest. Hannah told you her agenda, and every item on it is logistics or motivation asked conversationally. Casual questions are still scored | Answer each logistics topic in your own words (A1 to A4); a short arc for the "tell me about your role" opener (A5) |
| Skeptic (light) | Quiet knockout checks against the advert: ERP, spreadsheet tool, reporting, production scheduling | Second. A recruiter screen checks the advert's requirements against your background in a friendly register; F1, F4, F6 and F7 are where your material is thinnest | Rehearse B1 until it is boring; hold your own sentences and say plainly where a practice was not yours |
| Data-Driven Prober | Asks how your stock-discrepancy figure was counted | Third. A recruiter may probe one figure lightly; a hiring manager would probe it hard, so rehearsing it now pays twice | C1 and C2: name what you know about how it was counted, and say plainly what you do not know |
| Pressure / Stress | Time-boxed "why you" or "how much was actually you" | Low. Nothing in Hannah's message signals it; D1 and D2 are insurance | Pause, restate, hold your own sentences through two follow-ups |
| Case / Strategist | A live problem set in the role | Lowest for this call, more likely from a hiring manager later; the loop is undocumented, so this is a prior, not a finding | Clarify, then structure, then answer; E1 and E2 are generic practice |

## Question banks

### A. Conversational / Rapport Builder (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So what's prompting a move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Logistics slot, filled by your own words: say what you said to me, that your Bristol office is closing next year and the only offer is relocating to Reading, which you don't want. Add nothing to it. If she follows up, your own words were that sentence | She named it in her message, so it is certain. F10 holds the statement; EXP because it tests whether your story is consistent |
| A2 | "What salary are you looking for?" | JD | [grounded] "I'm hoping for £42,000." | Logistics slot, filled by your own words: "I'm hoping for £42,000." Nothing added. If asked what you earn now, you can decline without a figure: "I'd rather focus on the range for this role" | Her first listed topic. F8 shows your figure inside the advertised band; JD because the pay band is the advert's own term |
| A3 | "What's your notice period?" | JD | [grounded] | Logistics slot: give your actual notice period, in your own words. This pack does not know it and does not supply one | Her second listed topic. F11 is silent on it; JD because it fixes the earliest start for the listed job |
| A4 | "How would the hybrid pattern work for you? It's two days a week at Avonmouth." | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Logistics slot, filled by your own words: both halves of your sentence, that two days at Avonmouth is fine and that you wouldn't want more than three. Add nothing. If she asks about the commute, your own words were that sentence | Her third listed topic. F9 shows two days inside your limit; JD because the pattern is the advert's own term |
| A5 | "Walk me through what you do today." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip."; "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | A 90-second arc with three beats, each a clause your sentences state: four years as a logistics coordinator at a building-supplies wholesaler; you schedule deliveries for three depots and chase suppliers when orders slip; you rebuilt the stock-count spreadsheet and discrepancies fell by about a third over a year. Tell them in your own words and stop there. Anything further is an answer slot only if she asks, and then it is what you actually did | The opener to every screen. F5, F2 and F3 supply the beats; EXP because it tests whether the background holds together |
| A6 | "What do you know about Quillmoor, and why us?" | CO | [grounded] | The advert says Quillmoor is a diagnostic-test manufacturer with about 400 staff, and that the role coordinates schedules between planning, the warehouse and QA. Say what you have actually read about them. Answer slot: if you have looked at their site or news, say what stood out, in your own words; if you have not, say so plainly and say what drew you to the role as advertised. Web research was not available for this pack, so nothing beyond the advert is supplied here | Almost every screen asks it. CO because it tests homework; `[grounded]` on the advert alone, since company research could not run |

### B. Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role coordinates production schedules between planning, the warehouse and QA. What's the closest thing you've coordinated?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | The highest-ROI rehearsal in this pack. Level one, the hold: "I schedule deliveries for our three depots and chase suppliers when orders slip." Level two, if she asks about other teams, an answer slot: if any of the deliveries you scheduled involved agreeing timing with other teams, say which teams and what part was yours, in your own words; if none did, or it was not yours, say so plainly. Level three, if she presses on production: return to the deliveries and say plainly that production scheduling is the part of the advert your material does not show. Hold through each follow-up by returning to the sentence, never by adding to it | F1 is the gap between a wholesaler's delivery scheduling and a manufacturer's production scheduling, the advert's headline duty. JD because it scores a stated duty; this is the objection that follows you into later rounds |
| B2 | "Have you used SAP, or a similar ERP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Say your own sentence, both halves: never used SAP, and you run your own in-house stock system. Answer slot: if you want to say what you use the in-house system for, say it in your own words; if you would not call it similar, say so plainly. Then, as a plan and not as a past, how you would learn SAP | F7 is a stated gap against an advert "plus". JD because it is a listed qualification; the honest short answer is the strong one |
| B3 | "The advert asks for confidence with Excel. What do you do in it?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Say what the quote says: you rebuilt the stock-count spreadsheet. Answer slot: if it was in Excel, say so and what you built in it, in your own words; if it was another tool, or part of it was someone else's work, say so plainly and stay with the spreadsheet you rebuilt | F6 holds no tool name, so this probe is likely. JD because Excel is a stated requirement |
| B4 | "The role reports weekly on on-time dispatch. What reporting do you do today?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Answer slot: if you report on how deliveries perform today, say what and how often, in your own words; if you do not, or it is not yours, say so plainly and stay with "I schedule deliveries for our three depots and chase suppliers when orders slip." | F4 is the one advert duty no sentence of yours speaks to. JD because it scores a stated duty |
| B5 | "Which part of this advert would you be weakest at on day one?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Name the gap you have already stated: "Never used SAP." Then how you would learn it, as a plan and not as a past. Do not add weaknesses your material does not show, and do not claim strengths beyond your sentences. Hold the answer through one follow-up by returning to it | F7 is the only gap you stated yourself. JD because it scores honest self-assessment against the listed requirements |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about that drop in stock discrepancies. How was it counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Start from your sentence: you rebuilt the spreadsheet and discrepancies fell by about a third over a year. Answer slots, each in your own words: how it was counted; what the figure is sensitive to; the assumption behind it you would defend least; which part was yours. Where you do not know how it was counted, say so plainly. This pack supplies no method, baseline or assumption | F3 is the one figure on your background, so it is the one a prober goes to. EXP because it tests attribution and the number |
| C2 | "Tell me about a time a supplier was late and how you handled it." | EXP | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Selection scaffold: pick one real instance; it needs the order, what you did and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry: "I chase suppliers when orders slip." Tell only what you did | The advert's "chase late orders" raises it. EXP because it asks for a real instance, and F2's sentence has no instance in it |
| C3 | "How do you schedule deliveries across the three depots?" | EXP | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Say what the sentence says: you schedule deliveries for three depots. Answer slot: if there is a method you use to decide order or timing, say what it is, in your own words; if there is no set method, or the choice was not yours, say so plainly and stay with the three depots | F1 and F2 carry the practice but not how it works. EXP because it tests what was actually yours |

### D. Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we put you forward?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip."; "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Pause, restate the question, then sixty seconds from your own sentences: four years as a logistics coordinator at a building-supplies wholesaler; you schedule deliveries for three depots and chase suppliers when orders slip; you rebuilt the stock-count spreadsheet and discrepancies fell by about a third over a year. If pushed on the gap, concede the one you stated: never used SAP. Do not add claims | F5, F2 and F3 are the whole case in your own words. JD because it scores fit against the advert |
| D2 | "That drop in discrepancies. How much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Hold your sentence: you rebuilt the spreadsheet and discrepancies fell by about a third over a year. Answer slot: which part of the drop was yours; if others or other changes contributed, say who or what, in your own words; if you do not know, say so plainly. Hold through two follow-ups by returning to the sentence, then concede only what you actually do not know | F3 is the figure attribution probes aim at. EXP because the question tests precise attribution under pressure |

### E. Case / Strategist (lowest weight for this call)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A supplier tells you a delivery your production schedule depends on will land two days late. What do you want to know first, and who do you tell?" | CASE | [generic] | Structure it aloud: what is late, how much of the schedule it holds up, and whether there is an alternative supply or sequence; then who needs to know (the advert names planning, the warehouse and QA); then what you would record and what you would watch next. The question needs no claim about your past, so the guidance makes none | A live problem from the advert's schedule and late-order duties. `[generic]` because it is a pattern for the problem, not a fact about Quillmoor; more likely from a hiring manager later |
| E2 | "The system shows more units of an item than the warehouse can find. How do you work out why?" | CASE | [generic] | Structure it aloud: confirm the count first, then trace recent movements in and out, then check for records not yet updated, then correct the record and note the cause. The question needs no claim about your past, so the guidance makes none | A live problem from the advert's stock-records duty. `[generic]` because it is a problem pattern, not a claim about this employer |

### Requirement coverage

| Advert requirement | Covered by |
|---|---|
| Coordinate production schedules between planning, the warehouse and QA | B1, C3, E1 |
| Track supplier deliveries and chase late orders | C2, C3, E1 |
| Keep stock records accurate | C1, D2, E2 |
| Report weekly on on-time dispatch | B4 |
| 2+ years in operations or logistics coordination | A5, D1 |
| Confident with Excel | B3 |
| ERP experience (SAP or similar) a plus | B2, B5 |
| £38,000–£44,000 | A2 |
| Two days a week at Avonmouth | A4 |
| Hannah's topics: notice period, reason for moving | A3, A1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What happens after this call: who would I meet next, and in what format?" | It shows you are thinking about the process, and the answer tells you whether to prepare for a hiring-manager conversation, a task or a panel |
| R2 | "What would the hiring manager say is hardest about the first three months in this role?" | It invites an honest picture of the job and lets you hear which of F1, F4 or F7 matters most to them |
| R3 | "How is the two-day pattern at Avonmouth set: fixed days, or agreed with the team?" | It is a practical question on a topic Hannah has just raised, and it shows you have thought about the pattern |
| R4 | "Which systems does the team use for scheduling and stock today, and is training on them part of getting started?" | It addresses the ERP "plus" openly, without claiming experience you have not stated |
| R5 | "How is on-time dispatch measured today, and who receives the weekly report?" | It shows you have read the reporting duty closely, and the answer tells you what F4's probe will be aiming at |
| R6 | "What is the timeline for decisions, and what start date are you working towards?" | It follows from the notice period she asks about and gets the timing on the table early |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated production schedules between planning, the warehouse and QA | Inflated form of F1 | F1's sentence at its own scope: "I schedule deliveries for our three depots and chase suppliers when orders slip." The limit is the pack's observation: your material says deliveries for three depots, not production schedules. B1's slot stays inside the deliveries |
| Has ERP experience, or has used a system like SAP | Inflated form of F7 | F7's sentence at its own scope: "Never used SAP — we run our own in-house stock system." The limit is the pack's observation: your material says an in-house stock system, not an ERP. B2's slot asks only what you use it for |
| Confident with Excel | Inflated form of F6 | F6's sentence at its own scope: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." The limit is the pack's observation: your sentence says a spreadsheet, not which tool. B3's slot asks only what the tool was |
| Cut stock discrepancies by a third | Inflated form of F3 | F3's sentence at its own scope, "about a third" included, in your own order of events. The limit is the pack's observation: your material does not say how the figure was counted or what else changed. C1 and D2 ask only for what you know |
| Open to more than three days a week at Avonmouth | Contradicted by your quote, F9 | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." |
| Open to relocating to Reading | Contradicted by your quote, F10 | "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." |

## Sources

Provided documents: the advert text you pasted; Hannah Lowther's LinkedIn message (her agenda, as she wrote it); your own background and stated positions in your message. No dossier was present.

Searches sent, each refused (web search permission was not granted, and none were retried):

- `Quillmoor Diagnostics values`: refused
- `Quillmoor Diagnostics interview process operations coordinator`: refused
- `Quillmoor Diagnostics Avonmouth news`: refused
- `Hannah Lowther Talent Partner Quillmoor Diagnostics`: refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | All calls refused. Would have fed a values cheat sheet and VAL questions; neither is in the pack, and no values-style round is detected for this call |
| 2. `{company} interview process {role family}` | unavailable | All calls refused. Would have named later rounds; persona weights rest on Hannah's own message and the recruiter-screen prior, for this call only |
| 3. `{company} strategy` / recent news | unavailable | All calls refused. Would have grounded A6 and a strategy-based CASE question; A6 rests on the advert alone and E1 and E2 are `[generic]` |
| 4. `{interviewer name} {company}` | unavailable | All calls refused. Would have supported an interviewer read and a reverse question tied to Hannah's path; both are absent |
| 5. representative `{role title}` JD | skipped | The advert you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Web search enabled, then the research targets re-run (company values, interview process, strategy and news) → A6 becomes grounded beyond the advert, a strategy-based CASE question joins the bank, and later-round persona weights stop resting on a prior. A deeper pass is also available once, at up to 6 more searches and 2 more fetches and several more minutes
- Hannah's LinkedIn profile text pasted → an interviewer read and a reverse question tied to her own path
- Your notice period, stated in your own words → A3's logistics slot becomes your quoted sentence
- Whether your stock-count spreadsheet was in Excel, and whether you report on delivery or dispatch performance → F6 and F4 move out of `discovery` and B3 and B4 become story-mapped
- Your CV text, or the stock-count spreadsheet's before-and-after discrepancy figures → F1 to F7 currently rest on your message alone, and the figures are the inspectable artifact that could lift F3 above `medium`
- A prep note from Hannah or the hiring manager on the next stage, such as a task or presentation → a build section for any announced deliverable and sharper persona weights
- A `tuesday-dossier.md` from an earlier evidence review, if you have one → verified evidence and prohibited claims arriving ready-made; this pack does not need it
