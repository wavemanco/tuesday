Before the prep, one thing in the invite: it says the hiring process "is carried out entirely on Telegram" and that "your offer and onboarding will be completed in this chat as well". A hiring process run wholly by chat is a known scam pattern. A chat alone doesn't show who you're dealing with. Until you've confirmed who sent it, I'd hold back any documents, ID, tax or bank details, and any payment. Check with Lumenvale through contact details you find yourself on its own website or careers page, not through this chat or anything the sender gives you. The invite may not come from who it names. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as `lumenvale-software_customer-support-specialist_interview_pack.md`. I built it for a text chat with your future manager, assuming the support team lead is that person. It has 19 questions across six interviewer styles, a fit table built from your own words, and six reverse questions. Web search was refused in this session, so nothing in it comes from research on Lumenvale.

The biggest gap is that you've never worked for a software company. B1 rehearses that question, and it's the most valuable thing to practise.

Say the word and I'll play the Skeptic on B1 in a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is the support team lead the person you'd report to?
Can you paste the full job ad, or shall I stay with your summary of it?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: lumenvale-software_customer-support-specialist_interview_pack.md -----
# Interview prep pack: Customer Support Specialist (remote), Lumenvale Software

- Round: one text chat with the company's support team lead (unnamed)
- Built on one assumption: the team lead is your future manager, so the hiring-manager prior sets the persona weights
- Research: web search was refused in this session, so the company facts below come only from your message; see Sources

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did. Because the interview is typed, deliver each answer as three to five short messages rather than one block.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows good judgment on values; here the themes are generic, since no Lumenvale values were read |
| EXP | Whether what you say about your work holds up under follow-ups |
| JD | The requirements in the ad, including the gaps |
| CO | Company and strategy knowledge; none in this pack, since no strategy research ran |
| CASE | A live problem from the role, scored on structure |

## Fit snapshot

Requirements are quoted from your message, where you described the ad; the full ad text was not supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — the ad, as you described it | "3 years as a customer service advisor at an energy supplier" — your message | medium | [grounded] | none | No gap on length, but a self-reported line with nothing inspected behind it, so expect a probe. Use the line's own terms: three years, customer service advisor, energy supplier. The ad says customer support and you said customer service advisor, so keep your own title |
| F2 | "experience with Zendesk or a similar ticketing tool" — the ad, as you described it | "I use Freshdesk every day" — your message | medium | [grounded] | presentation | The words: "I use Freshdesk every day." Your material names Freshdesk, not Zendesk. Answer slot: the ad names Zendesk, so expect a probe on it. If you have used Zendesk, say where and how much; if you have not, say so plainly and stay with Freshdesk |
| F3 | "clear written communication" — the ad, as you described it | "answering around 60 calls and emails a day" — your message | medium | [grounded] | discovery | Your line gives volume across calls and emails together, and says nothing about what your written replies were like. Answer slot: this interview is itself typed, so the ad's line is tested live. If you can describe a kind of reply you wrote and what it was for, say so in your own words; if you cannot, say so plainly and stay with "around 60 calls and emails a day" |
| F4 | "confidence handling escalations" — the ad, as you described it | none given | none | [grounded] | discovery | Your material says nothing on escalations. Answer slot: the ad's line makes a probe likely. If you have handled an escalated contact, say what it was and what part was yours; if you have not, or it was not part of your role, say so plainly and say how you would handle one |
| F5 | Support experience at a software company (a role-family expectation, not stated in the ad as you described it) | "I've never worked for a software company" — your message | none | [generic] | capability | Your own words are the whole acknowledgment: "I've never worked for a software company." Then how you would learn the product, said as a plan and never as a past. Nothing is added to make the gap feel smaller, and F1, F2 and F6 stay at their own scope |
| F6 | No matching requirement in the ad as you described it | "I trained four new starters on our refunds process last year" — your message | medium | [grounded] | none | Not a requirement, so no gap, but a specific line that invites "which part was yours". Keep to its terms: four new starters, the refunds process, last year |

## Persona table

The invite's own words establish this loop: one text chat with the support team lead. Nothing establishes a later round, so this is a session-mode pack.

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (bank A) | Live ticket scenarios; "write me the first reply now" | High. A team lead sets the hiring-manager prior, which is Case plus Skeptic, and a text chat makes a live writing task easy to run | Ask one clarifying question, then structure the answer in short messages |
| Skeptic (bank B) | Probes on the missing software background, the tool, and escalations | High. F5 is a stated gap, F2 names a different tool, and F4 has no evidence | Rehearse B1 until it is boring: acknowledge plainly, then the plan |
| Conversational (bank C) | Friendly openers about your last three years | Medium. A chat register makes casual questions likely, and they are still scored | A short biographical arc built only from your own quoted lines |
| Data-Driven Prober (bank D) | Asks how the figures were counted | Low. Two figures in your material (F3, F6) can be probed, but this relationship's prior puts the Prober below the top two | Know what you can and cannot say about each figure, and say plainly when you do not know |
| Pressure (bank E) | Challenges such as "why you over someone with software experience" | Low. The prior for this relationship does not lead with it, but F5 invites one such challenge | Hold through two follow-ups, then concede specifically |
| Values / Behavioral (bank F) | "Tell me about a time" prompts | Low. No loop source documents a values round and no values page was read, so these are generic | Pick the instance before the chat, or be ready to say plainly that none comes to mind |

## Question banks

The highest-ROI prep in this pack is B1: the question about never having worked for a software company. It will be asked in some form, and it is the one where the temptation to stretch is strongest.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in for the second time about a problem nobody fixed, and asks for a manager. What is your next message, and what do you do behind it?" | CASE | [generic] | Clarify first, in one line: when does the team bring in a manager. Then structure it: open by acknowledging the repeat in the customer's own terms; say what you will do and when they will hear back; read what is already on the ticket so they are not asked twice; decide whether it is yours to settle or needs handing on, and if it is handed on, write the handover so nobody has to ask again. Promise no outcome you do not control. The question needs no claim about your past, so the guidance makes none | F4 has no evidence, so this lets you show reasoning on escalations without claiming a history. CASE because it is a live decision; generic because it is a pattern, not a fact about this employer |
| A2 | "A customer is demanding a refund the policy does not allow. What do you say, and when do you escalate?" | CASE | [grounded] "I trained four new starters on our refunds process last year" | Structure: say first what you can do, then what you cannot and why, in plain words; then name the point at which you would hand it on and what you would write in the handover. If it helps, mention once, in these words, "I trained four new starters on our refunds process last year", and stop there. The structure rests on no other claim about your past | JD content (the escalations line, F4) set in refunds, the ground F6 shows you know. CASE delivery because it asks for a decision, not a record |
| A3 | "Three customers write in within minutes about the same product bug you have never seen. What do you do in the first ten minutes?" | CASE | [generic] | Clarify: where does the team log known issues. Then: acknowledge each customer separately, tell none of them a fix you have not confirmed, group the reports, and hand the pattern to whoever owns the product with one clear summary: what customers see, how many, since when. Say plainly that you would not guess at workarounds. The question asks about no past | F5 is the stated gap, and this lets you show how you would work without product knowledge. CASE because it is live; generic because no product facts were read |
| A4 | "A customer writes: 'Your app lost my work and nobody is helping. Fix it now.' Write me the first reply, here." | JD, CASE | [generic] | The answer is the evidence, since the ad's written-communication line is tested live. Keep it to a few short lines: one line that names what happened to them, one question that would help diagnose it, one next step with a time frame. No jargon, no promise of recovery. The question asks about no past | F3's requirement is written communication, and this chat is a typed medium. JD because it tests the stated line; CASE because it is delivered live |
| A5 | "Two customers write in at once: one with a quick question, one angry about something complicated. Who do you answer first, and why." | CASE | [generic] | Clarify: does the team have priority rules. If it does, follow them and say so. If it does not, say what you would weigh, such as how long each will take and what is at stake for each customer, and what you would tell the second customer while they wait. State the trade-off you are accepting. The question asks about no past | A prioritisation case from the role, with no claim about the past. Included so a Case-led lead sees structure beyond the escalation scenarios |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have never worked for a software company. How will you get up to speed on our product?" | JD | [grounded] "I've never worked for a software company" [grounded] "3 years as a customer service advisor at an energy supplier" [grounded] "I use Freshdesk every day" | The highest-ROI rehearsal in the pack. Start with the acknowledgment, which is your own sentence: "I've never worked for a software company." Then hold only what your quotes carry: three years as a customer service advisor at an energy supplier, and "I use Freshdesk every day". Then the plan, said as future tense: use the product as a customer would, read its help material, ask the lead which issues come up most. Hold through two follow-ups by returning to the quotes, never by adding to them. If asked why you would learn it faster than someone who has done it before, do not claim that you do; say what you would do, and concede that you do not know yet what the product's customers need. Say plainly what you would ask first | F5 is the biggest gap in the material and the objection a lead hires against. JD because it tests a stated fit gap, and the hold-then-concede structure applies |
| B2 | "The ad says Zendesk or a similar tool. What have you used?" | JD | [grounded] "I use Freshdesk every day" | Say it in your own words: "I use Freshdesk every day." Answer slot: if you have used Zendesk, say where and how much; if you have not, say so plainly and stay with Freshdesk. Compare the two tools only where you know both first-hand | F2 is where the ad names a tool your material does not. JD because it scores a stated requirement directly |
| B3 | "Tell me about a time you handled an escalated contact." | EXP | [generic] | Pick one occasion before the chat. It needs a named stake, what you did, and how it ended. If an occasion comes to mind, say what part was yours and what was someone else's. If no such time comes to mind, say so plainly, then say how you would handle one, as a plan | F4 has no evidence, so the honest branch has to be ready. EXP because it scores whether the story is yours; generic because the prompt is a pattern |
| B4 | "Why move from an energy supplier into software support?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" | Answer slot: give your own reason, in your own words, in two or three short messages. This pack does not know it and will not write it for you. Keep it consistent with what you say in B2 and B5 | A motivation probe is the Skeptic's standard consistency check, and F5 makes it sharper. EXP because it tests whether your account hangs together |
| B5 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company" | Pick the one you would honestly say. Your own material points to product knowledge, in your words "I've never worked for a software company", and it shows nothing on escalations. Name one, say what you would do about it in the first weeks as a plan, and concede the rest. If you have handled escalations, say so plainly; the pack cannot say it for you | The stem every Skeptic uses. JD because it asks you to score yourself against the ad, and F5 and F4 are where an honest answer lands |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So tell me about your last three years. What does a normal day look like?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" [grounded] "answering around 60 calls and emails a day" [grounded] "I use Freshdesk every day" [grounded] "I trained four new starters on our refunds process last year" | Four or five short messages, in this order and only with these beats: three years as a customer service advisor at an energy supplier; around 60 calls and emails a day; Freshdesk every day; last year you trained four new starters on the refunds process. Say each in your own words and add no other duty. End by saying why this role | An opener with a friendly register is still scored on economy. F1, F3, F2 and F6 are the beats your material carries, and nothing more is claimed |
| C2 | "You trained four new starters last year. How did that come about, and how did it go?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Say what you trained them on and how many, as your sentence has it. Answer slot: how it came about and how it went, in your own words; if the sessions or materials were set by someone else, or it was a one-off, say so plainly. Do not describe a formal trainer role | F6 is a checkable line, and the likeliest follow-up is which part was yours. EXP because it tests attribution |
| C3 | "What do you like about writing to customers compared with phoning them?" | JD | [grounded] "answering around 60 calls and emails a day" | Say honestly which channel you prefer and why. The role is written, so say how you would make writing work for you, as a plan. Your quote covers calls and emails together, so do not say how many were emails | Casual but aimed at the ad's written-communication line (F3). JD because it scores that line in a friendly register |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You said around 60 calls and emails a day. How was that counted?" | EXP | [grounded] "answering around 60 calls and emails a day" | Say "around 60", as you did, not a firmer figure. Answer slot, four parts: how it was counted; what it varied with; the assumption behind it you would defend least; which part was yours. If you do not know how it was counted, or do not know the split between calls and emails, say so plainly | F3's figure is the likeliest number to be probed, and the weakest-assumption move turns a gotcha into credibility. EXP because it tests attribution to the figure |
| D2 | "Walk me through a typical Freshdesk ticket from arrival to close." | EXP | [grounded] "I use Freshdesk every day" | Describe the steps as you actually do them, in order, in your own words. If your team's set-up differs from what the interviewer expects, say plainly what yours did. Do not add features you have not used | F2 is the tool claim, and this checks it with a walk-through. EXP because it tests what you actually did |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "In sixty seconds: why you over someone who has already worked in software support?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier" [grounded] "I use Freshdesk every day" [grounded] "I trained four new starters on our refunds process last year" [grounded] "I've never worked for a software company" | Pause, then three or four short messages. Hold what your quotes carry: three years as a customer service advisor at an energy supplier, "I use Freshdesk every day", "I trained four new starters on our refunds process last year". Concede specifically: "I've never worked for a software company." Do not argue that you are better; say what you would bring and what you would need to learn. Hold through two follow-ups by returning to the quotes, never by adding to them | The Pressure persona tests composure on F5. JD because it scores fit for the stated role |
| E2 | "You said you trained four people. How much of that was actually you?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Hold what the sentence says, in its terms. Answer slot: say which parts were yours, such as the sessions, the materials, or deciding who to train; if any were set by someone else, or were not yours, say so plainly and stay with the training you did. Concede what you do not know. Never widen it | The "how much was you" stem applied to F6. EXP because it tests attribution under pressure |

### F. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "When have you put a customer's problem ahead of getting through your queue?" | VAL | [generic] | Pick the instance before the chat. It needs a named stake, what you chose and what it cost you, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would weigh it | A standard support-role behavioral prompt. Generic because no Lumenvale values were read, so this tests no named value |
| F2 | "Tell me about a time you had to deliver an unpopular truth." | VAL | [generic] | Pick one beforehand. It needs who it was said to, what you said, and how it landed, including if it landed badly. If no such time comes to mind, say so plainly and say how you would handle one | The values stem every behavioral interviewer uses. Generic for the same reason as F1 |

### Requirement coverage

| Ad requirement (as you described it) | Questions |
|---|---|
| "2+ years in customer support" | C1, B4, E1 |
| "experience with Zendesk or a similar ticketing tool" | B2, D2 |
| "clear written communication" | A4, C3 |
| "confidence handling escalations" | A1, A2, B3 |
| Software-company background (F5, not in the ad as you described it) | B1, B5, A3, E1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a good first 30 days look like for someone coming from outside software?" | It shows you have thought about the gap and turns the biggest objection into a plan |
| R2 | "What do the most common tickets look like, and which ones get escalated?" | It shows you are thinking about the work, and the answer tells you what B3 and A1 are really aiming at |
| R3 | "How are escalations handed to product or engineering, and how are handovers written?" | It shows care about written handovers, which is the written-communication line in practice |
| R4 | "Which ticketing tool does the team use day to day?" | The answer tells you how close F2 is to the real job, and whether to prepare for a specific tool |
| R5 | "What happens after this chat: is there a further stage, such as a call or video conversation, and what should I prepare?" | It tells you what to prepare next and gives you the shape of the process |
| R6 | "How is the team's time split across chat, email and calls, and what hours does the team cover?" | It shows practical interest in the written work and tells you whether the hours suit you |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Having worked for a software company | Negative you stated, F5 | The plain acknowledgment F5 gives: "I've never worked for a software company." No slot |
| Having led or run new-starter training | Inflated form of F6 | F6's quote at its own scope: "I trained four new starters on our refunds process last year." The limit is the pack's observation: your material says four starters and the refunds process, not who designed or led the training. C2 and E2 stay inside that |
| Answering around 60 emails a day (or 60 calls) | Inflated form of F3 | F3's quote at its own scope: "answering around 60 calls and emails a day." The quote gives one figure for calls and emails together |

## Sources

Provided documents: your message, which carried the invite text, your summary of the ad, and your background. No dossier was supplied.

Searches sent, all refused: "Lumenvale Software company values"; "Lumenvale Software interview process customer support specialist"; "Lumenvale Software strategy news". No fetches. No URLs came back.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | Every call was refused. It would have fed a values cheat sheet; section dropped, and bank F is generic |
| 2. `Lumenvale Software interview process customer support specialist` | unavailable | Every call was refused. It would have named further rounds; the one round here rests on the invite's own words |
| 3. `Lumenvale Software strategy news` | unavailable | Every call was refused. It would have fed CO questions; none are in the pack |
| 4. `{interviewer name} Lumenvale Software` | n/a | The interviewer is unnamed, so there was no query to form; the interviewer read is absent |
| 5. representative `Customer Support Specialist` JD | skipped | Your summary of the ad's four requirements fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full text of the job ad → the four requirement rows quote the ad's own words instead of your summary, and any hours, time-zone or location terms become gate rows
- Lumenvale's values or careers page pasted in, or permission to search → a values section with mapped stories, and CO questions; a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) is available once search is permitted
- Anything you can say on escalations, if you have handled one → F4 and B3 become story-mapped instead of an answer slot
- Material you hold that someone else could read, such as a sample reply with details removed or the outline you used to train the four new starters, if you have one → F3 and F6 rise from medium toward high
- Your CV → every row quotes the CV line instead of your message, and the fit snapshot gains rows
- The recruiter's guidance on what the chat will cover, or the interviewer's name → persona weights and the reverse questions tune to them
- A `tuesday-dossier.md` from an earlier run → verified evidence and prohibited claims arrive pre-graded, replacing the ones this pack built locally
