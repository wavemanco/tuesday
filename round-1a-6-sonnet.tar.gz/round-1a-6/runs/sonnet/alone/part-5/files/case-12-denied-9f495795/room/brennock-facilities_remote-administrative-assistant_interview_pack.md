# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

Candidate: Aoife. Round: a 30-minute video call with the office manager (the invite's own description). Interviewer name: not given. Relationship to the role: not stated, so this pack treats the office manager as a hiring-manager-style interviewer.

## How to use this pack

Personas describe how a question arrives (who is asking, in what style). Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Behavioural or values question: does past behaviour show the employer's published values |
| EXP | Work-experience deep-dive: does your own history survive follow-up questions |
| JD | Role-driven: can you do the listed duties, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem from the role, answered by structuring it aloud |

Answer slots are instructions for the interview, not questions for you to reply to here. Where a slot says "say so plainly", that is a full, respectable answer.

The highest-ROI rehearsal in this pack is A2, the supplier-invoices question. It will arrive in some form, and your material sits closest to it without reaching it.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as you listed its duties | "ran the appointment book for four physios" — your message | medium | [grounded] | presentation | Your quote reaches the requirement in other terms, and the words stay in the quote's own: "I ran the appointment book for four physios." It is a confirmed line with nothing inspected behind it, so expect a probe on it |
| F2 | "booking travel" — the ad, as you listed its duties | none given | none | [grounded] | discovery | Your material does not show travel booking. Answer slot: the ad's travel line makes a probe likely. If you have booked travel for anyone, say what you booked and for whom, in your own words; if you have not, or it was not yours, say so plainly and stay with the appointment book |
| F3 | "preparing documents in Word and Excel" (Word) — the ad, as you listed its duties | "I'm good with Word" — your message | low | [inferred] | discovery | The quote is a self-rating and names no task, so it cannot carry a story. Answer slot: if you have prepared documents in Word, say which in your own words; if you have not, or it was not yours, say so plainly and stay with "I'm good with Word" |
| F4 | "preparing documents in Word and Excel" (Excel) — the ad, as you listed its duties | "okay with Excel" — your message | low | [inferred] | discovery | The quote is a hedged self-rating and names no task, and it stays hedged: "I'm okay with Excel." Answer slot: if there are spreadsheet tasks you have done, name them in your own words; if there are none, or they were not yours, say so plainly and stay with "okay with Excel" |
| F5 | "processing supplier invoices" — the ad, as you listed its duties | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Adjacent work, not the same work: your material says chasing, the ad says processing, and the words stay at chasing: "I chased unpaid invoices." Answer slot: the ad's supplier-invoices line makes a probe on invoice handling likely. If you processed any invoices yourself, say how in your own words; if you did not, or it was not yours, say so plainly and stay with chasing |
| F6 | "Remote Administrative Assistant" — the invite | none given | none | [grounded] | hard_gate | A term, not a skill: your material does not establish whether working remotely suits your situation. Surfaced here, not bridged, and no words are offered for it |

Background carried from your message, for reference: "two years as a receptionist at a physiotherapy clinic" — your message.

## Persona table

The weights rest on one documented session: the invite describes a single 30-minute video call with the office manager, so no archetype fallback is used. Relationship is assumed hiring-manager-style; if the office manager is a peer or a team lead, say so and the weights move.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet probing of the thin spots: travel, invoices, Excel | 5 questions. The ad's duties on travel, invoices and Excel are where F2, F4 and F5 are thinnest, and a hiring-manager-style round carries a Skeptic prior | Rehearse the single most predictable objection (A2) until it is boring; bridge only from the quotes; say the limit plainly and give a plan, not a past |
| B. Case / Strategist | A small live task from the job: a clash in a calendar, an odd invoice, a trip to book | 5 questions. Every duty in the ad is a task, so a short call can test F1 to F5 directly, and the hiring-manager prior includes live problems | Clarify first, then structure, then answer; think aloud; ask what is missing before assuming |
| C. Conversational | Friendly opener, "walk me through your journey" | 3 questions. A short video call usually starts here, and casual questions are still scored | A 90-second arc built only from your own sentences; treat casual questions about Word and Excel as scored |
| D. Data-Driven Prober | Follow-ups two levels deep on one line of your background | 3 questions. F1, F4 and F5 are single lines, which a prober can open up | Know what each line does and does not cover; return to the line's own words under follow-up |
| E. Pressure | A short, time-boxed challenge | 2 questions. Low weight: nothing in the invite points to a stress style, but one challenge question is cheap to rehearse | Pause, restate, hold the position the quotes carry, concede only what is true |

## Question banks

### A. Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "okay with Excel" | Name the duty where your material is thinnest, plainly, then give a plan and stop. Your own words on Excel were "okay with Excel", so if Excel is the one, say it at that level. Answer slot: if travel booking or supplier invoices is thinner for you, say that instead and say what you would do in your first weeks to get up to speed, as a plan, not a past. No pre-apology | F4 and F2 are the likeliest answers to this question; JD because it scores the listed duties, Skeptic because it tests self-assessment |
| A2 | "The role processes supplier invoices. What invoice work have you done yourself?" | JD | [grounded] "chased unpaid invoices" | The highest-ROI rehearsal in this pack. The hold is only what the quote carries: "I chased unpaid invoices." Answer slot: if you processed any invoices yourself, say how in your own words; if you did not, or it was not yours, say so plainly and stay with chasing. Hold through two follow-ups by returning to the quote, never by adding to it. Concede only what you are sure is true | F5 is where the ad's wording and your material are furthest apart in terms, so this objection arrives in some form; JD because it scores a stated duty |
| A3 | "Your background is a clinic reception desk. How does that become an administrative assistant job?" | JD | [grounded] "two years as a receptionist at a physiotherapy clinic", "ran the appointment book for four physios", "chased unpaid invoices" | Three beats, each a clause from your own sentences: two years as a receptionist at a physiotherapy clinic; you ran the appointment book for four physios; you chased unpaid invoices. Tell them in your own words and let the interviewer draw the link. Answer slot: if other duties from the ad were part of the receptionist job, say which in your own words; if none were, say so plainly and stay with the appointment book and the invoices | F1 and F5 are the evidence for the move; JD because it scores fit to the listed duties, with the Skeptic framing a background mismatch |
| A4 | "Tell me about a time you booked travel for someone." | JD | [grounded] "ran the appointment book for four physios" | Selection scaffold, since no quote of yours carries travel: pick a time you arranged a trip for someone, with a named need, a constraint you had to work around, and a way you confirmed it was right. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I ran the appointment book for four physios", or say how you would go about it | F2 has no evidence, so this is the Skeptic's likeliest probe after invoices; JD because the ad lists travel |
| A5 | "Why this job, and why now?" | JD | [generic] | Give your actual reason in your own words, in two or three sentences, and keep it to what is true; this pack does not supply one. Answer slot: if you are drawn by a specific duty in the ad, name that duty; if you are not sure yet, say what you want from your next role | A motivation question is likely in a short call for any role; JD because it tests fit to this one, and it is `[generic]` because it makes no claim about your past |

### B. Case / Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The office manager asks you to move a meeting that three people have already accepted. Walk me through it." | CASE | [generic] | Structure it aloud: ask what is driving the move and how fixed the new time is; check everyone's availability before promising anything; offer one or two options; tell all three people the new time in writing and confirm they can make it. The question needs no claim about your past, so the guidance makes none | A live problem from the ad's calendars duty (F1's requirement), asked as a decision; CASE because it scores structure |
| B2 | "A supplier's invoice arrives and the amount is different from what was agreed. What do you do?" | CASE | [generic] | Structure it: do not approve or pay it yourself; check the invoice against what was agreed; ask whoever approves spending what they want done; record what you found; reply to the supplier once you know. Think aloud and say what you would need to know first | A live problem from the ad's supplier-invoices duty (F5's requirement); CASE because it scores reasoning and knowing where your authority ends |
| B3 | "Book a trip for me: two cities, leaving Monday, a hard 9am meeting on Tuesday. What do you need to know first?" | CASE | [generic] | Clarify before structuring: who is travelling and from where, budget, preferences, what is fixed and what can flex, who approves the booking. Then give options, confirm the choice, and send an itinerary in writing. The question needs no claim about your past | A live problem from the ad's travel duty (F2's requirement); CASE because it scores clarifying questions, which is the honest ground when travel is new to you |
| B4 | "I have a long list of figures in Excel and need totals by supplier by Friday. How would you approach it?" | CASE | [grounded] "okay with Excel" | Clarify first: what the totals are for, whether the list is clean, what format I want back, and whether Friday is a hard deadline. Then describe your approach using only the Excel features you actually know, at the level of your own words: "okay with Excel". Answer slot: if there is a feature you are not sure of, say so plainly and say how you would find out. Never name a feature you could not use | F4 is a hedged self-rating, so this is where it is tested; CASE because it scores approach, not features |
| B5 | "Turn these rough meeting notes into a one-page summary in Word for the team by end of day. What do you ask before you start?" | CASE | [grounded] "I'm good with Word" | Ask before you begin: who reads it, what they need to do with it, which points matter most, who signs it off, what the deadline allows. Then say how you would check it before sending. If asked about your Word skills, stay at your own words: "I'm good with Word" | F3's requirement tested as a task; CASE because it scores clarifying and checking, which is the whole of the guidance |

### C. Conversational (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your journey so far." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic", "ran the appointment book for four physios", "chased unpaid invoices" | A 90-second arc with three beats, each a clause from your own sentences: two years as a receptionist at a physiotherapy clinic; you ran the appointment book for four physios; you chased unpaid invoices. Tell it in your own words. Answer slot: end with your own reason for wanting this role; if you do not have one ready, say what you want from your next job | The opener is the likeliest casual question; EXP because it scores whether your account of your history is clear and consistent with F1 and F5 |
| C2 | "What did you enjoy most about running the appointment book?" | EXP | [grounded] "ran the appointment book for four physios" | The quote carries the facts: you ran the appointment book for four physios. What you enjoyed is yours to say in your own words, and it has to be true. Keep it short and tie it, if it is true, to something in the ad | F1 is the strongest line, so a friendly interviewer will return to it; EXP because it checks you can speak about your own work |
| C3 | "What do you use Word and Excel for day to day?" | JD | [grounded] "I'm good with Word", "okay with Excel" | Stay at your own words: "I'm good with Word" and "okay with Excel". Answer slot: if there are particular tasks you use either for, name them in your own words; if there are none, or you do not use them day to day, say so plainly and stay with the levels you gave. Never raise the level in the room | F3 and F4 are self-ratings with no task behind them; JD because the ad lists both, asked in a casual register |

### D. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You ran the appointment book for four physios. How did that work in practice?" | EXP | [grounded] "ran the appointment book for four physios" | Hold to the quote's own beats: the appointment book; four physios. Answer slot: the ad's calendars line makes a probe on how the book was kept likely. If there was a way you kept it in order, say what it was in your own words; if the book worked differently, or part of it was not yours, say so plainly and stay with "I ran the appointment book for four physios" | F1 is a confirmed line with nothing inspected behind it, so a prober opens it first; EXP because it checks the line survives detail |
| D2 | "Tell me about the unpaid invoices you chased. What happened?" | EXP | [grounded] "chased unpaid invoices" | Say what the quote says: you chased unpaid invoices. Answer slot: if you kept track of what was owed, say how in your own words; if no record was yours, say so plainly and stay with "chased unpaid invoices". Do not add a figure, a success rate or a method that you cannot repeat under a second question | F5 is the adjacent line; EXP because the probe is on what you actually did |
| D3 | "How would you describe your Excel level?" | JD | [grounded] "okay with Excel" | Say it as you said it: "I'm okay with Excel." Answer slot: if there are tasks you have done in it, name them in your own words; if there are none, or they were not yours, say so plainly. If you say you would close the gap, say it as a plan, with the first thing you would learn, never as a past | F4 is hedged and the ad names Excel, so a prober presses it; JD because it scores a listed duty |

### E. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone with more office administration experience?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic", "ran the appointment book for four physios", "chased unpaid invoices" | Pause, restate the question, then hold the position your quotes carry: two years as a receptionist at a physiotherapy clinic, running the appointment book for four physios, chasing unpaid invoices. Hold it through two follow-ups by returning to those lines. Concede, specifically, that other candidates may have more years in an office; do not claim more than your own sentences say | F1 and F5 are the held position; EXP because it scores holding a stated record under challenge |
| E2 | "That appointment book: how much of it was actually you?" | EXP | [grounded] "ran the appointment book for four physios" | Hold the word you used: "ran". Answer slot: if anyone shared the book, or covered it at times, say so plainly in your own words; if it was yours, say it was yours and stay at that. Do not widen "ran the appointment book for four physios" into anything larger, and do not shrink it to please the interviewer | F1 is the line a challenge targets; EXP because attribution honesty is what is scored |

### Requirement coverage

| Requirement | Questions |
|---|---|
| managing calendars | A3, B1, C2, D1, E2 |
| booking travel | A4, B3 |
| preparing documents in Word | B5, C3 |
| preparing documents in Excel | A1, B4, C3, D3 |
| processing supplier invoices | A2, B2, D2 |
| Remote Administrative Assistant (F6) | none, because it is a gate row: a term your material does not establish, not a skill to rehearse |

No VAL or CO question appears: this pack ran at L0, so no published values or strategy are in hand, and nothing in the invite documents a values round.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a good first month look like in this role?" | It shows you are planning to be useful early, and the answer tells you what to practise first |
| R2 | "Of calendars, travel, documents and invoices, which takes up most of the week?" | It tells you where to spend your remaining prep time, and shows you think in terms of workload |
| R3 | "Which tools do you use for calendars and for invoices?" | You can prepare for the actual tools, and it signals you are thinking about how the work gets done |
| R4 | "When two people ask me for things that clash, how do you want me to decide which comes first?" | It turns the calendar scenario in B1 into a working agreement, and shows judgement about priorities |
| R5 | "Who approves and who pays when a supplier invoice comes in, and where does my part of that stop?" | It shows you know where your authority ends, which is what B2 rehearses |
| R6 | "Is this call the whole process, or is there a next step?" | It tells you how much more preparation to plan for, and it is a normal question to close on |

## Prohibited claims

Built from the fit snapshot before the banks. Each entry is a claim this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Managed calendars for staff or senior people | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: your material says an appointment book for four physios, not other people's calendars. D1's slot stays inside the appointment book |
| Processed supplier invoices | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation: your material says chasing unpaid invoices, not processing supplier invoices. A2's slot asks only what you did yourself |
| Advanced or confident Excel skills | Inflated form of F4 | F4's quote at its own scope: "okay with Excel". B4 and D3 stay at that level |
| Expert Word skills | Inflated form of F3 | F3's quote at its own scope: "I'm good with Word". B5 and C3 stay at that level |

## Sources

Provided documents: the invite text, the ad's duties as you listed them, and your description of your background.

Research tier: L0 — no searches

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. company values | unavailable | No search was sent; this pack was built at L0 from your material only. Would have moved: a values cheat sheet and VAL questions. Nothing in the invite documents a values round, so none is built |
| 2. interview process for this role family | unavailable | No search was sent; the invite's own description of one 30-minute video call with the office manager is the loop source, so persona weights rest on it. A search would have moved: question mix and any further rounds |
| 3. company strategy and recent news | unavailable | No search was sent. Would have moved: CO questions, which are absent from this pack |
| 4. interviewer name and company | n/a | No interviewer name was given, only "our office manager", so there was no query to form; the interviewer read is absent |
| 5. representative role JD | skipped | The ad's duties as you listed them fix the fit snapshot rows and the JD-tagged questions |

## Upgrade menu

- The full text of the ad → F1 to F5 requirement cells become verbatim ad quotes instead of your summary of them, and any duty you did not mention gets its own row and question
- Your CV → more of your own sentences in the evidence column, which can lift F2, F3 and F4 from `none` or `low` and give the banks real stories where scaffolds stand now
- Your answers to the answer slots in F2 to F5, said outside a practice session → those rows regenerate on what you actually did, and the matching banks follow
- Whether working remotely suits your situation → F6 is a gate row and stays a gate until your material establishes it
- The office manager's name and role, if you learn them → an interviewer read, persona weights tuned to them, and a reverse question tied to their own path
- Any note from the employer about what the call will cover → the persona weights and coverage line move to match it
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a grounding brief on the company and CO questions that stand `[generic]` or absent now
- A `tuesday-dossier.md` from an earlier session → verified evidence rows and your own limits on what not to claim, in place of what this pack inferred
