# Interview pack: Operations Coordinator, Quillmoor Diagnostics

Interviewer: Hannah Lowther, Talent Partner. Relationship: recruiter screen, a 30-minute phone call on Thursday at 2pm. She will ring the mobile number on your application.

## How to use this pack

Personas are how a question arrives; types are what it scores. Guidance is scaffolding for your own words, not a script. Wherever the guidance is a slot ("if you did this, say how"), answer it from what actually happened.

Hannah's own message names four topics: salary expectations, notice period, how the hybrid pattern would work for you, and what is prompting a move. She then covers the team and next steps. Those four are rows A1 to A4, and a recruiter screen is still scored.

| Type | What it scores |
|---|---|
| VAL | Behaviour against the company's published values (none used in this pack: no values round is documented) |
| EXP | Whether your CV claims survive scrutiny |
| JD | Whether you can do the job as advertised, gaps included |
| CO | What you know about the company |
| CASE | A live problem from the role |

Highest-ROI prep: B2, the ERP question. It is the one gap you have stated yourself, and a recruiter can screen on it literally.

## The fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — the advert | "I schedule deliveries for our three depots" — your message | medium | [grounded] | transferability | Your material says deliveries for three depots, not production schedules or work with planning or QA, and the words stay there: "I schedule deliveries for our three depots." Answer slot: the advert's planning, warehouse and QA line makes a probe on working across functions likely. If your scheduling brought you into contact with any of them, say which and how, in your own words; if it did not, say so plainly and stay with the depot deliveries |
| F2 | "track supplier deliveries" — the advert | "I schedule deliveries for our three depots" — your message | low | [grounded] | discovery | The quote touches deliveries without showing whether you tracked what suppliers were delivering. Answer slot: if you tracked supplier deliveries, say how, in your own words; if you did not, or it was not yours, say so plainly and stay with scheduling deliveries and chasing suppliers |
| F3 | "chase late orders" — the advert | "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it, so expect a probe. Lead in the quote's own terms: you chase suppliers when orders slip |
| F4 | "keep stock records accurate" — the advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | medium | [grounded] | none | No gap, but a headline figure with nothing inspected behind it, so expect the how-was-it-counted probe (C1, C2). Say it as you said it: you rebuilt the spreadsheet, and discrepancies fell by about a third over a year |
| F5 | "report weekly on on-time dispatch" — the advert | none given | none | [grounded] | discovery | Your material is silent on reporting. Answer slot: if you have produced regular reports on deliveries or dispatch, say what they covered and how often, in your own words; if not, say so plainly and stay with the depot deliveries |
| F6 | "confident with Excel" — the advert | "I rebuilt our stock-count spreadsheet" — your message | low | [grounded] | discovery | The quote says spreadsheet, not Excel. Answer slot: if the spreadsheet was in Excel, say so and what you did in it, in your own words; if it was another tool, say so plainly |
| F7 | "ERP experience (SAP" — the advert | "Never used SAP" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "Never used SAP." Then how you would learn it, said as a plan and never as a past. Never a claim to SAP or ERP work |
| F8 | "or similar) a plus" — the advert | "we run our own in-house stock system" — your message | low | [grounded] | discovery | The quote says your employer runs its own system, not whether you use it or what you do in it. Answer slot: if you work in that system yourself, say what you do in it, in your own words; if you do not, or it is not yours to use, say so plainly |
| F9 | "2+ years in operations or logistics coordination" — the advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | No gap. Say it as you said it, with the four years and the role |
| F10 | "Hybrid: two days a week at our Avonmouth site in Bristol" — the advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" — your message | high | [grounded] | none | A term you have stated as met. Your own words are the answer, and nothing is added to them |
| F11 | "£38,000–£44,000" — the advert | "I'm hoping for £42,000" — your message | high | [grounded] | none | A term you have stated as met. Your own words are the answer, and nothing is added to them |
| F12 | "your notice period" — Hannah's LinkedIn message | none given | none | [grounded] | hard_gate | Your material does not establish it |

## Persona table

The loop source is Hannah's own message: one 30-minute call with her, then she describes the team and next steps. Nothing documents later rounds, so this pack weights this call only, and later rounds are an upgrade-menu item.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly opener, the four logistics topics she named, "walk me through your background" | Highest. Her message lists the four topics and the call is a recruiter screen, where the register is friendly and still scored | Give each logistics answer in your own words and stop. Prepare a 90-second background arc from A5. Treat casual questions as scored |
| Skeptic (light) | Knockout checks on the advert's mid-list items: SAP, Excel, production scheduling, the weekly report | Medium. The advert lists these, and a recruiter can screen on them literally | Rehearse B2 until it is boring. Where the material is silent, use the slot; where you have a stated limit, say it plainly |
| Data-Driven Prober | Asks how the one-third figure was counted | Low to medium. A recruiter may ask once; a hiring manager will ask more, and nothing here documents that round | Know what you can and cannot say about how the figure was counted; "I don't know how it was counted" is an honest answer if true |
| Case / Strategist | A live supplier-delay or stock-mismatch problem | Low in this call, higher with a hiring manager later | Clarify first, then structure, then answer. The three cases need no claim about your past |
| Pressure | A short "why you over someone with SAP" challenge | Low. Possible as a time-boxed probe | Pause, hold what your quotes carry, concede the SAP gap in one sentence |

No Values or Peer bank: no values round is documented, and no peer is in this call.

## Question banks

### A. Conversational / Rapport Builder (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What salary are you looking for?" | JD | [grounded] "I'm hoping for £42,000" | Your own words: "I'm hoping for £42,000." Say it and stop. If asked what you earn now: "I'd rather focus on the range for this role." No figure | She named salary expectations as a topic; F11 holds your figure |
| A2 | "What's your notice period?" | JD | [grounded] | Give your actual notice period, in your own words | She named notice as a topic; F12 shows your material does not establish it |
| A3 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | Your own words: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." If she follows up on the commute or on the days, your own words again, nothing added | She named the hybrid pattern as a topic; F10 holds your terms |
| A4 | "What's prompting a move?" | EXP | [grounded] "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Your own words: "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." If she follows up, your own words again, nothing added | She named the reason for the move as a topic; the recruiter row of the persona priors counts it among the logistics |
| A5 | "So, walk me through your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip" | A 90-second arc with the beats your sentences state: the four years as a logistics coordinator at a building-supplies wholesaler, scheduling deliveries for three depots, chasing suppliers when orders slip. Tell it in your own words and add nothing you did not tell me | F9 and F3 are the rows an opener draws on; EXP because it tests what the CV line carries |
| A6 | "What do you know about Quillmoor, and what interests you in this role?" | CO | [grounded] | This pack has no researched company facts, because the searches were refused. Use the advert's own lines, such as "Coordinate production schedules between planning, the warehouse and QA" and "track supplier deliveries", and say in your own words what in them draws you. Say only what you have read yourself; if there is nothing beyond the advert, say so plainly and say what in it draws you | Motivation and homework are scored in a recruiter screen; `[grounded]` on the advert alone, since the question asks for no claim about your past |
| A7 | "Tell me about a time a supplier's order slipped and you chased it." | EXP | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" | The beats the sentence states: orders slipping, you chasing suppliers. Answer slot: choose one order you remember and say what you did and what happened, in your own words; if no instance comes to mind, say so plainly, then describe how you chase suppliers | F3 is the advert's "chase late orders" line; the open prompt takes its theme from that line |

### B. Skeptic (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this advert would be your weakest on day one?" | JD | [grounded] "Never used SAP — we run our own in-house stock system"; "I schedule deliveries for our three depots" | Pick one plainly. Your material shows two candidates: ERP, which you have stated, and production scheduling, which F1 shows reaching only to depot deliveries. Name one, say it in your own words, then say how you would start closing it, as a plan and not a past | The most direct form of the gap probe; F7 and F1 are the two rows it can land on |
| B2 | "The advert says SAP or similar. What ERP experience do you have?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | The highest-ROI rehearsal in this pack. Hold: say it first, before she asks twice: "Never used SAP." Follow-up 1, "anything similar?": answer slot: the advert says "or similar", so expect this probe. If you work in your employer's in-house stock system yourself, say what you do in it, in your own words; if you do not, or it is not yours to use, say so plainly. Follow-up 2, "how quickly could you pick up SAP?": say what you would do first, as a plan; if you do not know how long it takes, say so. Follow-up 3, "is that a problem for this role?": the advert lists ERP as "a plus", which you can say; concede that you have not used SAP, and do not argue the in-house system is equivalent | F7 is the one gap you have stated yourself and F8 is where the probe widens; JD because it scores a stated line of the advert | 
| B3 | "You've come from a wholesaler. How would scheduling production differ from scheduling deliveries?" | JD | [grounded] "I schedule deliveries for our three depots"; "4 years as a logistics coordinator at a building-supplies wholesaler" | Stay inside the quote: you schedule deliveries for three depots. Answer slot: the advert's planning, warehouse and QA line makes a probe on working across those functions likely. If your scheduling brought you into contact with any of them, say which and how, in your own words; if it did not, say so plainly and say how you would find out what each of them needs | F1 is where the advert's first duty presses hardest |
| B4 | "Could the site pattern ever be more than two days a week?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | Your own words again: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." Nothing added | F10 is the row a follow-up on the hybrid pattern draws on |
| B5 | "How confident are you in Excel?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | The quote says you rebuilt a spreadsheet. Answer slot: if it was Excel, say so and what you did in it, in your own words; if it was another tool, say so plainly | F6 is the advert's Excel line, and the quote does not name the tool |
| B6 | "Have you reported on on-time dispatch before?" | JD | [grounded] "I schedule deliveries for our three depots" | Answer slot: if you have produced regular reports on deliveries or dispatch, say what they covered and how often, in your own words; if not, say so plainly and stay with the depot deliveries | F5 is the advert's weekly reporting line, and your material is silent on it |

### C. Data-Driven Prober (weight: low to medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Four slots, each in your own words: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. "I don't know how it was counted" is an honest answer if true. Do not name a method or a baseline you did not use | F4's headline figure is the likeliest thing to be probed |
| C2 | "How do you know the rebuild is what moved the number?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Answer slot: say what you know about why the figure fell, in your own words; if you do not know whether other things contributed, say so plainly and stay with what you said: you rebuilt the spreadsheet and discrepancies fell by about a third over a year | F4's two facts sit in one sentence, which invites the causal probe; the guidance does not adopt the link |

### D. Case / Strategist (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A supplier says a delivery will be two weeks late and production is waiting on it. What do you do first?" | CASE | [generic] | Structure it: find what is affected and by when, get the supplier's firm date and the cause, list the options, tell the people affected early, and record it. The question needs no claim about your past, so the guidance makes none | F2 and F3 are the advert's supplier lines, asked as a decision |
| D2 | "The warehouse count and the system disagree on a part. Walk me through what you would do." | CASE | [generic] | Structure it: check the count, check recent movements, find the cause before correcting the record, and say how you would stop it recurring. The guidance makes no claim about your past | F4 is the advert's stock-records line, asked as a decision |
| D3 | "Planning wants a job moved forward, but QA has not released the batch. How do you handle it?" | CASE | [generic] | Structure it: clarify what each side needs and by when, say what you can and cannot decide, put the facts to both, and escalate with options. The guidance makes no claim about your past | F1 is the advert's planning, warehouse and QA line, asked as a decision |

### E. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we shortlist you over someone who has used SAP?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip"; "Never used SAP — we run our own in-house stock system" | Pause, then hold only what the quotes carry: four years as a logistics coordinator at a building-supplies wholesaler, scheduling deliveries for three depots, chasing suppliers when orders slip. Concede in one sentence: "Never used SAP." Through two follow-ups, return to the same facts and never add to them | F7 is where a time-boxed challenge lands; JD because the advert states ERP as a plus |

## Requirement coverage

| Requirement | Questions |
|---|---|
| Coordinate production schedules between planning, the warehouse and QA | B1, B3, D3 |
| Track supplier deliveries | D1 |
| Chase late orders | A7, D1 |
| Keep stock records accurate | C1, C2, D2 |
| Report weekly on on-time dispatch | B6 |
| 2+ years in operations or logistics coordination | A5 |
| Confident with Excel | B5 |
| ERP experience (SAP or similar) a plus | B1, B2, E1 |
| Hybrid, two days a week at Avonmouth | A3, B4 |
| £38,000–£44,000 | A1 |
| Notice period (Hannah's topic) | A2 |
| Reason for the move (Hannah's topic) | A4 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How does the Operations Coordinator work with planning, the warehouse and QA day to day, and who would I sit closest to?" | It shows you have read the advert's first duty, and it tells you what F1 means in practice |
| R2 | "Which system holds the stock records, and what training comes with it?" | It raises the system question on your terms and tells you how much the F7 gap would matter |
| R3 | "How is on-time dispatch measured at the moment, and who reads the weekly report?" | It shows you have read the advert's reporting line and tells you what F5 involves |
| R4 | "How are the two on-site days at Avonmouth usually set: fixed days, or agreed with the team?" | It asks about the hybrid pattern from the company's side, once your own terms are on the table |
| R5 | "Is this a new role or a replacement, and what would the first month look like?" | It shows how the team sees the job and what the first month would test |
| R6 | "What are the next steps, and who would I meet next?" | It confirms the loop beyond this call, which this pack could not establish |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has SAP or other ERP experience | Negative you stated, F7 | Your own words: "Never used SAP." Then a plan for learning it, never a past. B2's slot asks only what you do in the in-house system |
| Coordinated production schedules between planning, the warehouse and QA | Inflated form of F1 | F1's quote at its own scope: "I schedule deliveries for our three depots." The limit is the pack's observation: the material says deliveries for three depots, not production schedules |
| Is confident with Excel | Inflated form of F6 | F6's quote at its own scope: "I rebuilt our stock-count spreadsheet." The limit is the pack's observation: the material says spreadsheet, not Excel. B5's slot asks only which tool it was |
| The rebuild is what cut discrepancies by a third | Inflated form of F4 | F4's quote as you said it. C2's slot stays inside the quote |

## Sources

Provided documents: the advert text you pasted, Hannah Lowther's LinkedIn message as you quoted it, and your own account of your background, all in your message. No dossier was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor Diagnostics values | unavailable | The search "Quillmoor Diagnostics values" was refused. It would have fed A6 and the reverse questions |
| 2. Quillmoor Diagnostics interview process, operations coordinator | skipped | No call was sent: Hannah's own words fix the one upcoming session, which feeds the persona weights and the banks |
| 3. Quillmoor Diagnostics strategy or recent news | unavailable | The search "Quillmoor Diagnostics Avonmouth Bristol news" was refused. It would have fed A6 and the reverse questions |
| 4. Hannah Lowther, Quillmoor Diagnostics | unavailable | The search "Hannah Lowther Talent Partner Quillmoor Diagnostics" was refused. It would have fed an interviewer read, which is absent |
| 5. Representative Operations Coordinator advert | skipped | The advert you supplied fixes the fit snapshot and the JD questions |

## Upgrade menu

- Search permission for company research → A6 and the reverse questions rest on real company facts, and an interviewer read becomes possible; this pack was built without any because the searches were refused
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a strategy brief to sharpen A6 and the reverse questions
- Your notice period → A2 and F12 take your own words
- Your stock-count spreadsheet or the discrepancy counts → F4 can rise from medium to high, and C1 and C2 can name what the figure rests on
- A sample of a delivery or dispatch report you produced → F5 moves from discovery to a quoted row
- Whether the spreadsheet was Excel, and what you do in your employer's stock system → F6 and F8 become quoted rows
- The schedule for any later rounds, and who runs them → per-round mini-packs with their own persona weights
- A `tuesday-dossier.md` → verified evidence and any prohibited claims carried in from an earlier check, for a sharper pack
