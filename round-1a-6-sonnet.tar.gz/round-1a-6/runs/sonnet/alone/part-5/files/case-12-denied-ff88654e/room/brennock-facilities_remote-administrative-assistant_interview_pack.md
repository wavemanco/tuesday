# Interview pack: Remote Administrative Assistant, Brennock Facilities Ltd

- Role: Remote Administrative Assistant
- Company: Brennock Facilities Ltd
- Round: one 30-minute video call with the office manager (name not given). Built as a hiring-manager-style round, since the office manager's relationship to you was not stated.

## How to use this pack

Personas describe how a question is asked. Types describe what it is scoring. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

| Type | What it is really testing |
|---|---|
| VAL | Whether past behaviour shows how you work with others and handle friction |
| EXP | Whether what you say about your experience holds up under follow-up questions |
| JD | Whether you can do the listed duties, including the ones your material does not yet show |
| CO | Whether you have done your homework on the employer |
| CASE | How you structure a small live problem from the role |

The highest-ROI prep in this pack is B2. It sits where the ad's supplier-invoice duty meets your chasing of unpaid invoices, and it will be asked in some form.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as you described it | "I ran the appointment book for four physios" — your message | medium | [grounded] | presentation | The ad's word is calendars and yours is appointment book, so use yours: "I ran the appointment book for four physios." The material does not say what the book held or how clashes were handled, and nothing here adds it |
| F2 | "booking travel" — the ad, as you described it | none given | none | [grounded] | discovery | Your material is silent on travel, so this is a question for you, not a gap the pack can word. Answer slot: the ad's booking-travel line makes a probe on trips you have arranged likely. If you have arranged travel for anyone, say whose, what it involved and what part was yours, in your own words; if you have not, or it was not yours, say so plainly and say how you would go about a first booking |
| F3 | "preparing documents in Word and Excel" — the ad, as you described it (Word part) | "I'm good with Word" — your message | medium | [grounded] | none | No gap, but a self-rating with nothing inspected behind it, so expect a probe. Say it as you did: "I'm good with Word." Be ready to say in your own words what you have made in it; the pack supplies no task |
| F4 | "preparing documents in Word and Excel" — the ad, as you described it (Excel part) | "okay with Excel" — your message | low | [grounded] | discovery | Your quote touches Excel without showing what you have done in it, and "okay" is your word, so keep it. Answer slot: the ad's Word-and-Excel line makes a probe on what you have made in Excel likely. If you have done particular tasks, name them as they were; if your use has been limited, say so plainly and say what you would practise first |
| F5 | "processing supplier invoices" — the ad, as you described it | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Your quote carries chasing, not processing, and the pack does not close that distance: "chased unpaid invoices." The material does not show which side of the invoice you stood on. Answer slot: the ad's supplier-invoice line makes a probe on handling invoices the firm has to pay likely. If you handled any, say what you did, in your own words; if you did not, or it was not yours, say so plainly and stay with the chasing |

## Persona table

Weights come in three passes. Relationship prior: an office manager on a short call reads as a hiring-manager-style round, which leans Case and Skeptic. Interviewer signals: none, since no name or profile was given. The loop: your invite describes one 30-minute video call with the office manager, which establishes a single session, and no values-style round is documented.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (bank A) | Small live problems taken from the ad's duties: a diary clash, a trip to arrange, an invoice that does not match, a document to finish | High: all four duties are practical, and a 30-minute call has room for scenarios (F1 to F5) | Clarify first, then structure, then say what you would record. Think aloud |
| Skeptic (bank B) | Quiet probing of the move from reception to administration, and of invoices, travel and Excel | High: F2, F4 and F5 are the thin rows, and probes go where the material is thin | Rehearse B2 until it is boring. Keep to your own sentences and state limits plainly |
| Conversational (bank C) | A friendly walk through your background and a casual question on Word and Excel | Medium: a short call with an office manager is often chatty, and casual questions are still scored | Prepare a 90-second arc from your own sentences. Treat the casual Word and Excel question as scored |
| Data-Driven Prober (bank D) | Line-by-line questions on the appointment book and the invoices | Low: the only figure in your material is the four physios (F1), and nothing outcome-based is claimed | Know exactly what you did in each line, and say plainly where you do not know |
| Peer Evaluator (bank E) | Questions on where your work ends and theirs begins | Low: depends on whether the office manager is your future manager or a peer, which is not known | Propose seam principles instead of pretending to know the seam |
| Pressure | Interruptions, time-boxed answers | Low: nothing in the invite points to a stress format. No bank | If it happens, pause, restate the question, and hold your position through two follow-ups |
| Values/Behavioral | Scenario probes against published values | Low: no values-style round is documented and no published values were read. No bank, though E2 rehearses one behavioural question | n/a |

## Question banks

### Bank A: Case/Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two people want the same Thursday-afternoon slot, and a third is travelling that day. How do you sort it out?" | CASE | [generic] | Structure it: what you would ask each person first (how fixed the slot is, what the alternatives are), what can move, what you would offer, how everyone is told in writing, and what you would record. The question needs no claim about your past, so the guidance makes none | The calendar duty (F1) asked as a decision rather than a record. CASE with JD content; [generic] because it is a pattern, not a fact about this employer |
| A2 | "A colleague needs to be in another city for a morning meeting and back for a late-afternoon one the next day. What do you need to know before you book anything?" | CASE | [generic] | Clarify before you book: dates and fixed times, budget, whether changes need to be allowed, who approves, traveller preferences, what must be sent to the traveller afterwards. Order them aloud, then say what you would do first. No claim about your past | The travel duty (F2) as a live problem, so the pack can prepare you without any claim about trips you may not have arranged |
| A3 | "A supplier invoice arrives and its amount does not match what was ordered. What do you do with it?" | CASE | [generic] | Structure: do not pass it on as it is, find out what was ordered and delivered and by whom, note the difference, contact the supplier or the person who ordered, record what was agreed, and say who approves before it moves. No claim about your past | The invoice duty (F5) as a decision, which lets you show judgement without claiming processing experience |
| A4 | "I send you a rough draft in Word and ask for a clean, finished document by end of day. What do you check before sending it back?" | CASE | [generic] | Talk through your own checks in order: what the document is for and who reads it, the content you were given, the layout and consistency, a final read, and what you would flag to me. Use only checks you would genuinely make | The Word duty (F3) as a task. CASE rather than JD because it tests the order of your checks, not a claim about skill |
| A5 | "I give you a spreadsheet of this month's travel costs and ask for a total for each person. How do you start, and how do you check your answer?" | CASE | [grounded] "okay with Excel" | Start with clarifying questions (what the columns are, what is included), then say what you would do and how you would check it a second way. Answer slot: name the Excel steps you have actually used, in your own words; if this task is beyond what you have done, say so plainly and say how you would find out how | F4 is the thin row and the likeliest one to be tested live. The question's task is the ad's Excel line, and the guidance does not assume you know any particular function |

### Bank B: Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "okay with Excel" "chased unpaid invoices" | Pick the one that is true from your own list, in your own words: your words on Excel were "okay with Excel", and on invoices "chased unpaid invoices". Name it plainly, then give a plan for the first weeks, said as a plan and never as a past | F2, F4 and F5 are the thin rows, so this is the cleanest place for calibrated candour. JD because it scores fit to the listed duties |
| B2 | "The job involves processing supplier invoices. What have you done with invoices?" | EXP | [grounded] "chased unpaid invoices" | The highest-ROI rehearsal in this pack, and the hold is only what the quote carries: "I chased unpaid invoices." Answer slot: the ad's supplier-invoice line makes a probe on whether any invoices you handled were ones to be paid likely. If any were, say what you did with them, in your own words; if none were, or it was not yours, say so plainly and describe the chasing. Follow-up 1 will ask for specifics: give only what you did. Follow-up 2 will ask what you would do with a supplier invoice on day one: answer as a plan and say who you would ask first. Hold by returning to the chasing, never by adding to it | F5 is where the ad's duty and your material are furthest apart, so this question arrives in some form. EXP because it tests what was actually yours |
| B3 | "You've been a receptionist. Why should we see you as an administrative assistant?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" "I ran the appointment book for four physios" "chased unpaid invoices" | Hold on what you said: "two years as a receptionist at a physiotherapy clinic", the appointment book for four physios, the chasing of unpaid invoices. Describe them and let the interviewer draw the conclusion. Answer slot: the ad lists duties your material does not show; for any one you have not done, say so plainly and say how you would learn it | The role-change objection in its plainest form (F1, F5). Guidance rehearses honest description, not an argument you assert for yourself |
| B4 | "What made you look at a remote role, and why now?" | VAL | [generic] | Give your actual reason in one or two sentences, in your own words. A true, modest reason holds up better than a polished one. The guidance supplies no reason, because it has to be yours | Motivation consistency is scored in short calls. VAL rather than EXP because it tests your reasons, not your record |
| B5 | "Tell me about a time you arranged travel for someone." | JD | [grounded] "I ran the appointment book for four physios" | Selection scaffold: pick a time you arranged a trip or journey for someone else. It needs who it was for, what the constraints were and what you did yourself. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I ran the appointment book for four physios", or say how you would handle it | The travel duty (F2) as an open prompt. The question presupposes no event, so the honest branch is built in |

### Bank C: Conversational (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey: how did you get to where you are?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" "I ran the appointment book for four physios" "chased unpaid invoices" "I'm good with Word" "okay with Excel" | A 90-second arc built only from those sentences, told in your own words: the reception role, the appointment book, the chasing, then Word and Excel as you rated them. Close with why this role, as your own reason, which the pack does not supply | The biography question is where casual interviews score you first (F1 to F5). EXP because it tests whether your story matches your material |
| C2 | "Tell me about the Word and Excel side of things. How comfortable are you?" | JD | [grounded] "I'm good with Word" "okay with Excel" | Use your own ratings, "I'm good with Word" and "okay with Excel", at their own strength. Answer slot: for each, name what you have made or done in it; if you have not done a given kind of task, say so plainly and say what you would practise | F3 and F4 differ in strength, so the answer should too. A casual question on a duty the ad lists is still scored |
| C3 | "What did you like most about running the appointment book?" | EXP | [grounded] "I ran the appointment book for four physios" | Answer from your real experience in your own words: what part you liked and why. Add no outcomes or incidents you did not tell me about | Warms the call and tests genuine interest (F1). EXP because it is anchored to your own sentence |
| C4 | "What do you know about us and what we do?" | CO | [generic] | Say only what you have read yourself on the employer's own site or careers page. If you have read little, say so plainly and ask what you should know. The pack holds no company facts, because its searches did not run | Homework depth is scored even in a short call. [generic] because the company searches were refused, so nothing here is a fact about this employer |

### Bank D: Data-Driven Prober (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how you ran the appointment book for four physios." | EXP | [grounded] "I ran the appointment book for four physios" | Tell it at the quote's scope: the book, the four physios, in your own words. Answer slot: the ad's calendar line makes a probe on how clashes were handled likely. If clashes came up, say what happened and what part was yours; if they did not, or it was not yours, say so plainly and describe how you ran the book | F1 is the evidence for the calendar duty and the likeliest place to be probed |
| D2 | "Tell me about chasing those unpaid invoices. What did that involve?" | EXP | [grounded] "chased unpaid invoices" | Say what the chasing was, in your own words, and no more than that. Answer slot: if you kept or used any record of what was outstanding, say what it was and whose it was; if there was none, say so plainly and describe what you did | F5 is the only invoice evidence, so a prober will go to its edges |

### Bank E: Peer Evaluator (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Where is the line between what I'd hand you and what you'd decide yourself?" | CASE | [generic] | Offer principles, not a map: ask what is yours to decide and what needs a check, agree what you flag and when, and say how you would confirm back what you have understood. No claim about your past | A seam question for the case where the office manager is a peer or day-to-day supervisor. CASE because it asks for a working arrangement |
| E2 | "Tell me about a time you disagreed with someone about how something should be done." | VAL | [generic] | Selection scaffold: pick a time the disagreement was real, you stated your view, and the working relationship was intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or say how you would handle it | The one behavioural question in a pack with no values-style round, drawn from the Peer persona's stems |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "managing calendars" (F1) | A1, D1, C3 |
| "booking travel" (F2) | A2, B5 |
| "preparing documents in Word" (F3) | A4, C2 |
| "preparing documents in Excel" (F4) | A5, C2, B1 |
| "processing supplier invoices" (F5) | A3, B2, D2 |
| The move from reception to this role | B3, B4, C1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a good first month look like in this role?" | Shows you are planning to contribute, and the answer tells you what is weighted most |
| R2 | "Of the duties in the ad, which take up most of the week and which come up only occasionally?" | Lets you aim your practice at the heavy ones, such as Excel or invoices |
| R3 | "What do you use for calendars, travel bookings and invoices, so I can get familiar with them early?" | Turns your thin rows (F2, F4, F5) into a plan to get ahead of them |
| R4 | "Who would I work with most day to day, and how do you like work to be handed over?" | Shows you think about the working relationship and gives you the seam for E1 |
| R5 | "What happens after this call?" | A question about the process, and it tells you how to plan your next days |
| R6 | "What could a new person do in their first month that would genuinely help you?" | A reciprocity question that moves the conversation from being scored to working together |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed calendars | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios." The limit is the pack's observation: the material says the appointment book, not calendars. D1's slot stays inside the book |
| Processed supplier invoices | Inflated form of F5 | F5's quote at its own scope: "chased unpaid invoices." The limit is the pack's observation: the material says chasing, not processing. B2's slot asks only what you handled |
| Advanced skill in Word or Excel | Inflated form of F3 and F4 | Your own ratings at their own strength: "I'm good with Word" and "okay with Excel." C2's slot asks only what you have made |

## Sources

- Provided documents: the invitation email as you pasted it, your description of the ad's duties, and your note about your background.
- Research tier: L1 — searches 3 of 6, fetches 0 of 2
- Searches sent, all refused, so nothing from them is used: `Brennock Facilities Ltd values`; `Brennock Facilities Ltd interview process administrative assistant`; `Brennock Facilities Ltd strategy recent news`.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | The search was refused. It would have moved the CO bank (C4); no values-style round is documented, so no values cheat sheet was built |
| 2. `{company} interview process {role family}` | unavailable | The search was refused. It would have moved persona weights; the weights rest on your invite's one 30-minute call and the hiring-manager prior |
| 3. `{company} strategy` / recent news | unavailable | The search was refused. It would have moved C4 and the grounding of CO questions; C4 is [generic] |
| 4. `{interviewer name} {company}` | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. representative `{role title}` JD | skipped | Your description of the ad's duties fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full ad text → F1 to F5's requirement cells become exact quotes, and any duty missing from your description gets a row and a question
- Your CV → F1 to F5 gain a second source for your own sentences, and some medium rows may rise
- Your own answers to the slots in F2, F4 and F5 → those rows move from discovery to evidence, and B2, B5 and C2 become story-mapped instead of slots
- Whether the office manager is your future manager or a peer → persona weights are recomputed, and bank E grows or shrinks
- The office manager's name and public professional background → an interviewer read and a reverse question tied to their path
- Permission to run company searches, or a company page you have read yourself and pasted → C4 and the CO questions become specific, and a values cheat sheet is built if a values-style round turns up
- A `tuesday-dossier.md` from an earlier session → graded evidence and prohibited claims arrive ready-made
