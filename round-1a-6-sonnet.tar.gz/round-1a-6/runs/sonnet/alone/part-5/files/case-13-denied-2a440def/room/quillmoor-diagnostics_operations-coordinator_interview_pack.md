# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** recruiter screen, a 30-minute phone call, Thursday at 2pm. Hannah Lowther, Talent Partner, will ring the mobile number on your application.

**Her stated agenda, in her words:** "your salary expectations, your notice period, how the hybrid pattern would work for you and what's prompting a move", then the team and next steps. The pack is built on that agenda.

## How to use this pack

- Personas describe how a question is asked. Types describe what it scores. Every question carries one of each.
- Type key: **VAL** is values alignment. **EXP** is a deep-dive on your own experience. **JD** is a stated requirement or term of the job. **CO** is knowledge of the company. **CASE** is a live problem.
- No VAL questions appear. Nothing in this pack establishes a values round, and the company's published values could not be retrieved.
- Guidance is scaffolding, not a script. Where a cell says "answer slot", it is an instruction for the interview: answer from your own experience, in your own words.
- **Highest-ROI prep: B1.** It is the likeliest objection to your application, and it gets the deepest rehearsal.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — the advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material says delivery scheduling across three depots and chasing suppliers, not production schedules, and the words stay there: "I schedule deliveries for our three depots." Answer slot: the advert's coordination line makes a probe on who your scheduling works with likely. Name them in your own words; if it is mostly your own call, or there was no one, say so plainly and stay with the depots and suppliers |
| F2 | "track supplier deliveries and chase late orders" — the advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | The quote reaches the chasing. "Track" is not in it, and C3 covers that as an answer slot. Lead with the chasing in the quote's own terms, because a named activity beats an adjective, and expect a probe on it |
| F3 | "keep stock records accurate" — the advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | No gap in the requirement's terms, but a figure with nothing inspected behind it, so expect a probe on how it was counted (C1, C2, E2). Keep the sentence whole, as you said it |
| F4 | "report weekly on on-time dispatch" — the advert | none given | none | [grounded] | discovery | Your material is silent on reporting. Answer slot: if you produce any regular report on deliveries, say what it covers and how often; if you do not, say so plainly and stay with scheduling the depots' deliveries |
| F5 | "2+ years in operations or logistics coordination" — the advert | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | none | No gap, but a single line with nothing inspected behind it. Lead with it in the quote's own terms: the four years, the role, the wholesaler |
| F6 | "confident with Excel" — the advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | The quote says spreadsheet, not Excel, and this row's bridge is the pack's derivation. Answer slot: if that spreadsheet was in Excel, say what you did in it, in your own words; if it was another tool, or you are less sure of Excel than the advert asks, say so plainly and stay with the spreadsheet |
| F7 | "ERP experience (SAP or similar) a plus" — the advert | "Never used SAP — we run our own in-house stock system." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't used SAP." The in-house system stays at the quote's scope: "we run our own in-house stock system." Answer slot: the advert's "or similar" makes a probe on that system likely. If you work in it yourself, say what for; if you do not, say so plainly. Then how you would learn SAP, said as a plan and never as a past |
| F8 | "£38,000–£44,000" — the advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | The pack's observation: your figure sits inside the advert's band. Your own word is the strongest evidence a pay figure can have. Give it as you said it, and add nothing |
| F9 | "Hybrid: two days a week at our Avonmouth site in Bristol" — the advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | The pack's observation: your sentence covers the advert's two days. Give it as you said it, and add nothing |

## Requirement coverage

| Requirement | Questions |
|---|---|
| Coordinate production schedules (F1) | B1, D1, D3 |
| Track supplier deliveries, chase late orders (F2) | A1, C3, D1 |
| Keep stock records accurate (F3) | C1, C2, D2, E2 |
| Weekly on-time dispatch report (F4) | B4 |
| 2+ years coordination (F5) | A1, E1 |
| Excel (F6) | B3 |
| ERP, a plus (F7) | B2 |
| Pay band (F8) | A2 |
| Hybrid, two days at Avonmouth (F9) | A4 |
| Recruiter agenda: notice period | A3 |
| Recruiter agenda: what is prompting a move | A5 |

## Persona table

| Persona | How it shows up in this call | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Conversational / rapport | Friendly, unstructured; Hannah's four agenda items arrive as chat | High. Her message names pay, notice, hybrid and the reason for the move as the call's content, and all four are logistics asked in a friendly register | Know your four answers in your own words. Treat the casual questions as scored |
| B. Skeptic | Quiet knockout checks against the advert's requirements | Medium. The advert has a mid-list tool (SAP) and a production-coordination line your material covers only at delivery scope. A recruiter checking fit would probe there | Rehearse B1 until it is boring. Use only what your own sentences state, and say plainly where they stop |
| C. Data-driven prober | Asks how the stock figure was counted | Low. One figure is in your material and a recruiter is unlikely to go two levels deep, but the figure is a magnet for it | Know what you can and cannot say about the figure, and say plainly what you do not know |
| D. Case / strategist | A quick situational question from the job's own work | Low. Hannah's agenda does not include one, but the hiring manager's round probably will | Clarify, then structure, then answer; think aloud |
| E. Pressure | A time-boxed "why you" or an attribution challenge | Low. Her agenda reads as courteous, so this is insurance | Pause, restate, hold through two follow-ups, concede specifically |

Weights rest on Hannah's stated agenda and the recruiter-screen pattern. No source establishes later rounds, so they are not prepared for here.

## Question banks

### A. Conversational / rapport builder (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through your background and what you do day to day." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." | Story-mapped on F5 and F2: the four years as a logistics coordinator at a building-supplies wholesaler, then scheduling deliveries for three depots and chasing suppliers when orders slip. Those are the beats the quotes state, so tell them in your own words in about 90 seconds and let her draw the inference. Answer slot: if she asks who your scheduling works with, name them in your own words; if it is mostly your own call, or there was no one, say so plainly and stay with the depots and suppliers | The opener of almost any screen, and where F5 and F2 are first heard. EXP because it tests what was actually yours |
| A2 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | Logistics slot, in your own words: "I'm hoping for £42,000." Say it, then stop. If she comes back to the figure, give those same words again. If asked what you earn now: "I'd rather focus on the range for this role." | F8 is a stated term she named first. JD because pay is the advert's stated term |
| A3 | "What's your notice period?" | JD | [grounded] | Logistics slot: give your actual notice period in your own words. If you do not know it exactly, say so and say you will confirm it. Your material states no notice period, so the pack supplies none | She named it in her agenda. No fit row exists, since the advert states no start date |
| A4 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Logistics slot, in your own words: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." If she follows up on it, give the same words again | F9 is a stated term she named. JD because the advert sets the two-day pattern |
| A5 | "What's prompting a move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Logistics slot, in your own words, kept whole: "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." That is the whole answer. If she follows up, give those words again | She named it in her agenda. EXP because it checks that the story is consistent. No fit row exists, since the advert states no requirement here |
| A6 | "What do you know about Quillmoor, and why this role?" | CO | [generic] | Selection scaffold. No verified company facts are in this pack. Say what draws you in the advert's own lines, such as tracking supplier deliveries or keeping stock records accurate. Add one thing about Quillmoor you have read yourself on its own website. If you have not had time to look, say so plainly and say which line of the advert caught your interest | A recruiter's standard homework check. CO because it tests preparation. `[generic]` because the company searches were refused |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this job would be furthest from what you do now?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | **Highest-ROI rehearsal.** The hold is only the quote: "I schedule deliveries for our three depots and chase suppliers when orders slip." Level 1, if she asks how that compares with the job: describe what the sentence says, in your own words, and let her draw the comparison. Answer slot: the advert's coordination line makes a probe on who your scheduling works with likely. Name them in your own words; if it is mostly your own call, or there was no one, say so plainly and stay with the depots and suppliers. Level 2, if she asks what would be new: say in the future tense how you would learn the production side, in your own words, as a plan and not as a past. Level 3, if she presses: return to the quote and concede its scope plainly, and never extend it | F1 is where the advert's first line presses hardest and the material is thinnest, so this objection will arrive in some form. JD because it scores a stated requirement, in a Skeptic's delivery |
| B2 | "Have you used SAP or a similar system?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Say it plainly: "I haven't used SAP." Then the quote at its own scope: "we run our own in-house stock system." Answer slot: if you work in that system yourself, say what for; if you do not, say so plainly. Then how you would learn SAP, as a plan and not a past | F7 is the one stated negative in your material, and the advert marks ERP as a plus. JD because it scores a stated plus |
| B3 | "How confident are you in Excel?" | JD | [inferred] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Start from the sentence as you said it. Answer slot: if that spreadsheet was in Excel, say what you did in it, in your own words; if it was another tool, or you are less sure of Excel than the advert asks, say so plainly and stay with the spreadsheet | F6 is a discovery gap: the quote says spreadsheet and does not say which tool. `[inferred]` because the link from spreadsheet to Excel is the pack's own |
| B4 | "The role reports weekly on on-time dispatch. Where would you be starting from?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Answer slot: if you produce any regular report on deliveries, say what it covers and how often; if you do not, say so plainly and stay with "I schedule deliveries for our three depots and chase suppliers when orders slip." Add nothing about reports you have not produced | F4 is a discovery gap against a stated duty. JD because it scores the advert's reporting line |

### C. Data-driven prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that fall of about a third was counted." | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Say the sentence as you said it. Answer slots, in your own words: how discrepancies were counted, if you know; the assumption behind the figure you would defend least, named before she does; which part was yours. If you do not know how it was counted, say so plainly | F3's figure is the CV-style number a prober goes to. EXP because it tests attribution and method |
| C2 | "A third over a year — against what?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: if there was a baseline, say what it was in your own words; if there was no formal baseline, or you do not know it, say so plainly and return to the sentence | The same figure from a second angle. EXP because it checks the number survives a follow-up |
| C3 | "How do you keep track of which supplier orders are due and which have slipped?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Answer slot: the advert asks to track supplier deliveries. If you keep any record of what is due, say what it is, in your own words; if you rely on something else, or tracking is not your job, say so plainly and stay with the chasing | F2's "track" half is not in the quote. JD because it scores the advert's tracking line |

### D. Case / strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A supplier says a delivery will be a week late, and QA's next batch depends on it. What do you do first?" | CASE | [generic] | Structure only, with no claim about your past: what you need to know first (what is late, what it holds up, how firm the new date is), what you would do about it, who needs telling, and what you would record and chase | The job's own core problem as a live case, covering F1 and F2's requirements. `[generic]` because it is a pattern for the problem |
| D2 | "The records say there is more stock than the shelf holds. Walk me through it." | CASE | [generic] | Structure only: confirm the count, check what moved recently, find where the records and the shelf diverge, fix the cause, and record what you changed | F3's requirement as a live case. `[generic]` for the same reason |
| D3 | "Planning wants a rush order, the warehouse is full and QA has not released the last batch. How do you sort it?" | CASE | [generic] | Structure only: clarify the priorities and constraints with each function, set out the options, decide with whoever owns the call, and tell everyone affected | F1's three-function seam as a live case. `[generic]` because it is a pattern for the problem |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we move you forward?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." "Never used SAP — we run our own in-house stock system." | Use only those sentences, in your own words, and let her draw the inference. Hold through two follow-ups by returning to them. If pressed on SAP, concede specifically: "I haven't used SAP." | F5, F2 and F3 are the material you have, and F7 is the limit you will be pressed on. JD because it scores fit to the advert, in a Pressure delivery |
| E2 | "That drop in discrepancies — how much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Say what the sentence states: "I rebuilt our stock-count spreadsheet." Answer slot: if you can say how much of the fall followed from the rebuild, and what else changed over the year, say it in your own words; if you do not know, say so plainly. Never present the fall as all yours | F3's sentence joins the rebuild and the fall with "and". EXP because it is an attribution probe |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Who would I work most closely with across planning, the warehouse and QA, and who would I report to?" | The advert names those three functions, so it shows you read the seam |
| 2 | "What does on-time dispatch look like today, and what would good look like six months in?" | It picks up the advert's weekly reporting line and asks what success means |
| 3 | "Which systems does the team work in day to day, and how much of the job sits in SAP rather than Excel?" | The advert calls SAP a plus, so this finds its real weight |
| 4 | "What would the first month look like for the person who joins?" | It shows you are thinking about starting, and her answer tells you what is new |
| 5 | "What happens next, and roughly when?" | She said she would cover next steps, so this confirms the timeline |
| 6 | "What has the team found hardest to hire for in this role?" | It invites her honest view of the role's pressure points |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated production schedules between planning, the warehouse and QA | Inflated form of F1 | F1's quote at its own scope: "I schedule deliveries for our three depots and chase suppliers when orders slip." The limit is the pack's observation: the material says deliveries and chasing, not production schedules. B1's slot stays inside the deliveries |
| Has used SAP | Negative you stated, F7 | The plain acknowledgment: "I haven't used SAP." No slot |
| Has ERP experience through the in-house system | Inflated form of F7 | F7's quote at its own scope: "we run our own in-house stock system." The limit is the pack's observation: the material says the company runs the system, not that you use it or that it is an ERP |
| Confident or advanced in Excel | Inflated form of F6 | F6's quote at its own scope: a spreadsheet. The limit is the pack's observation: the material says spreadsheet, not Excel. B3's slot asks only which tool and what you did in it |
| Cut stock discrepancies by a third through the rebuild alone | Inflated form of F3 | F3's quote at its own scope: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." The limit is the pack's observation: the sentence joins the two with "and" and does not say how the fall was counted |
| A salary range, a floor, flexibility on £42,000, or a current-pay figure | Not stated by you | F8's quote: "I'm hoping for £42,000." If asked what you earn now, decline and redirect to the range for this role |

## Sources

Provided documents: the advert, your background notes and Hannah Lowther's message, all pasted into your request. No dossier was present.

Searches sent, each refused (permission was not granted):

- "Quillmoor Diagnostics values about us" — refused
- "Quillmoor Diagnostics news Avonmouth" — refused
- "Hannah Lowther Talent Partner Quillmoor Diagnostics" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | Every call was refused. It would have grounded A6 in published facts and could have supported VAL questions, so A6 stays `[generic]` |
| 2. `Quillmoor Diagnostics interview process operations coordinator` | skipped | Hannah's own message fixes this session: one 30-minute call and its agenda. Later rounds do not change this pack |
| 3. `Quillmoor Diagnostics strategy` / recent news | unavailable | Every call was refused. It would have given A6 a current fact and the reverse questions a company-specific one |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | Every call was refused. It would have supplied an interviewer read and a reverse question tied to her path; both are absent |
| 5. representative `Operations Coordinator` JD | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Permission to search → the company values, news and Hannah's public professional footprint become sources: A6 and the reverse questions move off `[generic]`, and an interviewer read becomes possible. A deeper pass of up to 6 more searches and 2 more fetches, several more minutes, would add a company brief for the CASE bank
- Your notice period → A3 becomes your own words, quoted, instead of an instruction
- Your own answers to the slots in B1, B2, B3, B4 and C1 to C3 → F1, F4, F6 and F7 can move from `discovery` or `transferability` toward `presentation` or `none`, and F3's defence gets sharper
- Your actual stock-count spreadsheet and any delivery or dispatch report you produce, in whatever form you keep them → F3, F4 and F6 can rise from `medium`, `none` and `low` toward `high`
- A `tuesday-dossier.md` → verified evidence for F1, F4, F6 and F7, and a sourced objection to replace the inferred one in B1
- The schedule of any later rounds → per-round mini-packs with their own persona weights
