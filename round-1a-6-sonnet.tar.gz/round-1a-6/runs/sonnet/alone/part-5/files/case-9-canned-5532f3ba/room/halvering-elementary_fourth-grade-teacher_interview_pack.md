# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

- **Employer:** Orrinsford Community School District
- **Round:** one 45-minute panel on Thursday: Principal Dolores Vantongeren and two members of the fourth-grade team (names not given)
- **Candidate:** Grace

## How to use this pack

Personas describe how a question arrives (who is asking, in what register). Types describe what is being scored. Every question carries one persona letter, one type tag, a provenance label with the candidate's own quoted sentences, answer guidance and a rationale. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Tag | Meaning |
|---|---|
| VAL | Whether past behavior shows the district's published beliefs |
| EXP | Whether your stated experience survives scrutiny; what was actually you |
| JD | The stated job: what the role asks, including the gaps |
| CO | Homework on the district's current direction |
| CASE | A live problem from the role, reasoned aloud |

Provenance labels: `[grounded]` traces to your material or to a page listed in Sources; `[inferred]` is derived from a representative posting or an adjacent source, with the derivation named; `[generic]` is a pattern with no claim about you or the district. "Answer slot" lines are instructions for the interview, not questions for you to answer here.

## Fit snapshot

The district published no posting text in your material, so the role's requirements come from the invite, the district's own hiring and beliefs pages, and a representative fourth-grade posting (labeled `[inferred]` where used). Every evidence cell is your own words.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | The gate is met as your CV states it: an Illinois PEL, an elementary endorsement covering grades 1–6, active through June 30, 2029. It is a CV line with nothing inspected behind it, so the band is medium. Checking the record is yours to do; the license number is not repeated anywhere in this pack |
| F2 | "reading instruction" — the district's page on how it hires teachers | "I led our grade level's move to a new reading curriculum in 2024" — your CV, "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | transferability | Your material says a move you led and a club you run, with nothing inspected behind either, and the words stay at that scope: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: the district says its panels ask about reading instruction, so expect a probe on what the move meant for how you teach reading. Say which parts of it were yours and which were decided elsewhere; if the move did not change your own teaching, say so plainly and describe the club |
| F3 | "classroom routines" — the district's page on how it hires teachers | "Six years teaching third grade at a public elementary school in Joliet" — your CV | low | [grounded] | discovery | Six years of third grade touches classroom routines without showing any. Answer slot: if you set routines in your own classroom, say which and why, in your own words; if routines were set by the school or someone else, or there were none worth naming, say so plainly and describe how you ran your room |
| F4 | "how you work with families" — the district's page on how it hires teachers | "I write a weekly email to families" — your CV | medium | [grounded] | none | No gap: the weekly email names families in role-relevant terms. It is a CV line with nothing inspected behind it, so expect a probe on what the emails contain. Lead with it in the quote's own terms: you write one every week, to families |
| F5 | "each teacher speaks with every family each term" — the district's mission and beliefs page | "I write a weekly email to families" — your CV | low | [grounded] | discovery | The district's belief names speaking with every family, and your material says an email to families, not conversations; that is the pack's observation, not words for you. Answer slot: if you also speak with families, say how and how often, in your own words; if the email is your main contact, say so plainly and say what you would add, as a plan |
| F6 | "the Fourth Grade Teacher position at Halvering Elementary School" — invite | "I've never taught fourth grade" — your CV | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never taught fourth grade." Then how you would get ready for it, said as a plan and never as a past. Never a claim to fourth-grade teaching, and nothing added to make the gap feel smaller |
| F7 | "plan and teach reading, writing, math, science and social studies" — representative posting, K12 Jobs Board | "Six years teaching third grade at a public elementary school in Joliet" — your CV | low | [inferred] | discovery | Typical for the role, not necessarily this team's practice. Your CV gives the grade and the years, not the subjects. Answer slot: expect a probe on which subjects you taught; say which, in your own words, and if one was taught by someone else, say so plainly and stay with the ones you taught |
| F8 | "assessments inform teaching and never replace it" — the district's mission and beliefs page; "differentiate instruction using assessment data" — representative posting | none given | none | [grounded] | discovery | Nothing in your material speaks to assessment. Answer slot: the district's belief raises it, so expect a probe on how results shape what you teach next. If results changed your teaching, say how, in your own words; if they did not, or that was set at school level, say so plainly and say how you would want to use them |
| F9 | "work with the grade-level team" — representative posting | "I led our grade level's move to a new reading curriculum in 2024" — your CV, "I've never been a team lead" — your CV | low | [inferred] | transferability | Typical for the role, not necessarily this team's practice. The move is yours to describe at its scope, and the limit is yours to state plainly: "I've never been a team lead." Answer slot: expect a probe on how the move involved your grade-level colleagues; say how, in your own words, and if the move was mostly your own work, or someone else coordinated it, say so plainly |
| F10 | "no student leaves third grade without a reading plan" — the district's mission and beliefs page | "Six years teaching third grade at a public elementary school in Joliet" — your CV, "I've run the after-school reading club for the last two years" — your CV | low | [grounded] | discovery | The belief names reading plans by the end of third grade, and your material says the years and a club, not plans. Answer slot: if your third graders had reading plans, say who wrote them and what they held; if there was no such plan, or it was not yours, say so plainly and describe the club |

Highest-ROI prep in this pack: **A1**, the fourth-grade gap (F6). It is stated in your own material, so the panel can see it, and the whole job turns on how you hold it. Second: **A2**, the team-lead limit (F9).

## Reading the interviewer

Public professional footprint only. The two teammates are unnamed, so nothing is read for them.

| Fact | Source | What it suggests | Provenance |
|---|---|---|---|
| Principal of Halvering Elementary School since 2022, after nine years as a reading specialist | Illinois principals forum speaker page | Reading instruction is her home ground: expect depth there, and answer from what your quotes carry rather than stretching | [grounded] |
| Her 2025 forum talk, Small Groups, Big Readers, covered weekly reading conferences in grades 3 to 5 | Same page | Small-group reading work in the grades you taught is a likely theme; ask about it (reverse questions 1 and 2) rather than claiming a practice of your own | [grounded] |

Mirror opportunity: her talk covers grades 3 to 5, and F7's evidence reads "Six years teaching third grade at a public elementary school in Joliet". That is shared vocabulary for a question to ask her, not a shared practice to claim. No shared career jump is offered: no fit row carries your side of one.

## Persona table

The loop is established by the district's hiring page: one 45-minute building panel of the principal and two grade-level teachers, asking about reading instruction, classroom routines and families. So this is a blended panel, not an archetype fallback. The hiring page names no round that assesses values, so no values-style round is detected; the district's three beliefs still theme the VAL questions as published sources.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Provenance |
|---|---|---|---|---|
| Skeptic (weight 5) | Quiet probing of the fourth-grade gap and the team-lead limit | Highest: F6 and F9 hold stated limits, and a panel of three has three chances to ask. A principal sits in the hiring-manager prior, which pairs Skeptic with Case | Rehearse A1 until it is boring: hold the quoted facts, concede the gap specifically, never add to the facts | [grounded] |
| Case / Strategist (weight 4) | Live problems from the role, likely from the principal | High: the hiring page lists reading instruction, routines and families, which are all problem-shaped, and the principal is the hiring-manager prior | Clarify first, then structure, then answer; say your framework aloud | [grounded] |
| Peer Evaluator (weight 4) | The two teammates asking how you would work beside them | High: two of three panelists are grade-level teachers, and the peer prior is Peer plus Prober | Reciprocity: what you bring them, not only what you need; offer principles for the seam rather than pretending to know it | [grounded] |
| Values / Behavioral (weight 3) | Questions mapped to the three published beliefs | Medium: the district's page says the three beliefs guide every hire, but the hiring page names no values round | Map a story to a belief only where your quotes carry one; otherwise use the scaffold and its honest branch | [grounded] |
| Conversational (weight 2) | Opening biography and casual reading talk | Low weight but near-certain to open the panel; casual questions are still scored | A 90-second arc built only from your quoted sentences | [generic] |
| Data-Driven Prober (weight 2) | A teammate reading your CV line by line | Lower: your CV carries no figures to probe, so the probing lands on practices instead | Say plainly what you can and cannot say about each line | [generic] |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| Valid Illinois PEL with an elementary endorsement (F1) | none, and why: your material shows it met, so there is nothing to rehearse beyond stating it as written |
| Reading instruction (F2) | A5, C1, D1, G1 |
| Classroom routines (F3) | B3 |
| Working with families (F4, F5) | C2, D3, G2 |
| Fourth grade (F6) | A1, A3, A4, D4 |
| Subjects (F7) | D4 |
| Assessment (F8) | C3, D2 |
| Team (F9) | A2, B1, B2, B4 |
| Reading plans (F10) | C1 |

Your CV carries no figures, so there are no defend-the-number questions; the Prober bank probes practices instead.

## Question banks

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've taught third grade for six years and never fourth. Why do you think you can do this job?" | JD | [grounded] "I've never taught fourth grade", "Six years teaching third grade at a public elementary school in Joliet", "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | Hold-then-concede. Open with the facts in their own terms: "I've never taught fourth grade." Then the six years in third grade in Joliet, and the elementary endorsement covering grades 1–6. Hold that position through two follow-ups by returning to those facts, never by adding to them or claiming the grades are alike. Concede specifically. Answer slot: if there is a part of fourth grade you expect to be new to you, name it; if nothing comes to mind, say so plainly and say how you would find out in your first week, as a plan | F6 is the stated gap and the likeliest objection, so this is the deepest rehearsal in the pack; JD because it scores fit to the stated role |
| A2 | "You haven't been a team lead. How do you see yourself fitting on a fourth-grade team?" | JD | [inferred] "I've never been a team lead", "I led our grade level's move to a new reading curriculum in 2024" | Say the limit plainly: "I've never been a team lead." Then the move, at its own scope: "I led our grade level's move to a new reading curriculum in 2024", the move, not the team. Answer slot: if you worked with grade-level colleagues on the move, say how, in your own words; if the work was mostly your own, or someone else coordinated, say so plainly and stay with the move. Then say what you would want from teammates and what you would offer them, as intentions and not as a past | F9 pairs a led move with a stated limit; `[inferred]` because the team requirement comes from a representative posting, not this team |
| A3 | "Why leave your current school for fourth grade here?" | JD | [grounded] no claim about your past; the district facts are from its own pages in Sources | The material does not carry your reason, so it is yours to give. Answer slot: give your actual reason in one or two sentences, in your own words. Then name one thing the district itself says that genuinely draws you: its belief "Every Child a Reader", or its August 2026 literacy plan with a new grades 3–5 reading curriculum from fall 2027. Name it only if it is true for you | The motivation probe a Skeptic always asks; F6 makes "why this grade, why now" sharper |
| A4 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade", "I've never been a team lead" | Choose a real one, not a disguised strength. Your own stated limits are available: "I've never taught fourth grade" and "I've never been a team lead". Name one, then give a concrete plan for closing it, said as a plan and never as a past. Hold your choice through a follow-up | The standard Skeptic stem; F6 and F9 are where it lands for this candidate |
| A5 | "Your resume says you led your grade level's move to a new reading curriculum. How much of that was you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Tell it at the sentence's own beats: a new reading curriculum, a move your grade level made, in 2024, and you led it. Answer slot: say which parts were yours and which were decided elsewhere, in your own words; if the district or someone else made the decisions and you led the move itself, say so plainly. Never widen the verb or the scope | F2's likeliest probe; the district's page says its panels ask about reading instruction, so attribution on the one reading-curriculum line is where this lands |

### B. Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you disagreed with a colleague about how to teach something." | EXP | [generic] | Selection scaffold: pick a real time with a named stake, a moment you held your view or changed it, and a working relationship intact at the end. "We" for context, "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Peers test disagreement style among equals; EXP because it asks for a real instance and scores what was actually yours; F9 is the row it protects |
| B2 | "What would you need from us in your first month, and what would you bring to the team?" | JD | [grounded] "I write a weekly email to families", "I've run the after-school reading club for the last two years", "I led our grade level's move to a new reading curriculum in 2024" | Reciprocity first. What you bring is what the quotes carry, at their scope: the weekly family email, the reading club, the curriculum move. What you need is yours to say; a request to learn how the fourth-grade team plans and pairs up is a fair, honest ask. Do not describe how any of the three worked beyond what the quotes say | The peer prior's reciprocity question; F2 and F4 are the evidence it draws on |
| B3 | "How would you set up classroom routines in your first two weeks with a new class?" | CASE | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | Structure it as reasoning, not history: what you would establish first, how students learn it, how you would check it is working. Answer slot: if you set routines in your own classroom, say which and why; if routines were set by the school or someone else, say so plainly and describe how you ran your room. Do not present a routine as yours unless it was | The district's hiring page names classroom routines as a panel topic (F3); CASE because it asks for reasoning on a live problem |
| B4 | "How do you handle credit when work spans several teachers?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | State the principle: name who did what, "we" for context, "I" for your contribution. When you reach the move, keep to the quote: you led the move. Answer slot: say which parts were yours and which were colleagues', in your own words; if you cannot separate them, say so plainly | The Peer stem on credit; F9 is where the claim is thinnest |

### C. Values / Behavioral (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "We believe no student leaves third grade without a reading plan. You taught third grade. What does that look like in your room?" | VAL | [grounded] "Six years teaching third grade at a public elementary school in Joliet", "I've run the after-school reading club for the last two years" | Answer slot: if your third graders had reading plans, say who wrote them and what they held, in your own words; if there was no such plan, or it was not yours to write, say so plainly and describe the club you run after school. Do not describe a plan you did not use | Maps the belief "Every Child a Reader" to F10; the belief is the raising source, and the second branch lets the premise be false |
| C2 | "Each teacher here speaks with every family each term. How do you stay in touch with families?" | VAL | [grounded] "I write a weekly email to families" | Lead with the quote in its own terms: you write an email to families every week. Answer slot: if you also speak with families, say how and how often; if the email is your main contact, say so plainly and say what you would add, as a plan. Do not say you speak with every family each term unless you do | Maps "Families Are Partners" to F5; F4 is the evidence that stands |
| C3 | "Tell me about a time you used a test result to change how you taught, not just to report it." | VAL | [grounded] no claim about your past; the belief is the district's own words in Sources | Selection scaffold: pick a time with a named result, a change you made because of it, and what followed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would want to use results | Maps "Teach for Tomorrow, Not for the Test" ("assessments inform teaching and never replace it") to F8, where nothing is carried |

### D. Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "The board's literacy plan brings a new reading curriculum to grades 3–5 from fall 2027. What would you want to know about it, and how could you help?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Clarify first: what the curriculum is, when fourth grade would see it, what the team needs ahead of it. If you mention your own move, keep it at the quote's scope and do not say the two are alike. Answer slot: if there is something your move taught you that bears on this, say what, in your own words; if nothing carries over, say so plainly and ask your questions | The one question grounded in the district's current strategy (the August 2026 literacy plan in Sources); F2 is the only evidence that touches it |
| D2 | "A quick check shows a third of your class missed the main idea of a passage. What do you do next?" | CASE | [inferred] derived from F8's requirement (the district's belief on assessment and the posting's differentiation line); no claim about your past | Think aloud: what you would check first, how you would decide who needs what, what you would teach next, how you would know it worked. No claim about your past is needed. If asked whether you have done this, say what is true | A live problem from F8, where your material is silent |
| D3 | "A parent emails on Sunday night, upset about their child's reading progress. Walk me through your next day." | CASE | [grounded] "I write a weekly email to families" | Structure: acknowledge, look at what you know of the child, reply on a stated timeline, set a follow-up, keep the principal informed if the situation calls for it. Mention your weekly email only if it fits, at its own scope: you write one every week | Families are a named panel topic (F4, F5); CASE because it asks for reasoning under a live problem |
| D4 | "Plan a week for a fourth-grade class across reading, writing, math, science and social studies. Where do you start?" | CASE | [inferred] derived from F7's representative posting; "Six years teaching third grade at a public elementary school in Joliet" | Clarify before planning: what the team already uses, how pacing is set, what data exists on this class. Then structure the week. Answer slot: say which of those subjects you taught in third grade; if one was taught by someone else, say so plainly and stay with the ones you taught. Do not claim fourth-grade materials you have not used | Covers the subjects requirement (F7) and the fourth-grade gap (F6) in one live problem |

### E. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey. How did you get here?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet", "I led our grade level's move to a new reading curriculum in 2024", "I've run the after-school reading club for the last two years", "I write a weekly email to families" | A 90-second arc built only from the four quotes: six years in third grade in Joliet, the curriculum move, the reading club, the weekly email. Answer slot: why you are applying for this job is your own reason and your material does not carry it; give it in a sentence, in your own words. Tell the arc in your words and stop when the beats run out | The near-certain opener; the arc is the one place all four of your quotes sit together |
| E2 | "Tell me about the reading club. What do the kids do there?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Describe it in your own words. The quote carries only that you run it, after school, and have for two years. Answer slot: what happens in a session is yours to say; if parts of it were set by someone else, say so plainly. A casual question about a topic the principal knows well is still scored | A casual question on the reading topic; F2 and F10 are the rows it feeds |

### G. Data-Driven Prober (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "You've run the reading club for two years. How do you know it's working?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Answer slot: if you looked at anything to judge the club, say what and what you saw, in your own words; if you did not, say so plainly and say what you would want to look at. Do not name a measure you did not use | The Prober asks for evidence on a line with no figures (F2); the second branch lets the premise be false |
| G2 | "What goes in your weekly email to families?" | EXP | [grounded] "I write a weekly email to families" | Describe it in your own words; the quote carries only that you write one each week, to families. Answer slot: if families reply, say what kinds of replies and what you do with them; if replies are rare or there are none, say so plainly. Do not describe a reply you have not had | F4 is a CV line with nothing inspected behind it, so a reader of the CV asks what is in it |

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| 1 | To the principal: "You spent nine years as a reading specialist before becoming principal. How does that show up in how reading is run in fourth grade here?" | Ties to her own path, and signals you researched her, not only the district | [grounded] |
| 2 | To the principal: "Your 2025 talk, Small Groups, Big Readers, covered weekly reading conferences in grades 3 to 5. What has that looked like at Halvering since?" | Opens a peer conversation on her public work; it asks and claims nothing of your own | [grounded] |
| 3 | "The literacy plan adds a new grades 3–5 reading curriculum from fall 2027. How is the fourth-grade team preparing for it?" | Shows you read the district's own plan, and turns your one curriculum line into a question rather than a claim | [grounded] |
| 4 | To the teachers: "What could a new fourth-grade teacher do in the first month that would genuinely help your team?" | The peer reciprocity question: it asks what you can give before what you need | [generic] |
| 5 | "What does support look like for a teacher who is new to fourth grade?" | Names your stated gap (F6) as a planning question and shows you intend to close it | [generic] |
| 6 | "What happens after the panel?" | The district's page says references are taken up after the panel, so this is a practical close that costs nothing | [grounded] |

## Prohibited claims

Claims this pack will not coach, built from the fit snapshot before the question banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | Negative you stated, F6 | The plain acknowledgment F6 gives: "I've never taught fourth grade." Then a plan, never a past |
| Has been a team lead, or led the grade-level team | Negative you stated, F9 | "I've never been a team lead", plus the move at its own scope: "I led our grade level's move to a new reading curriculum in 2024" |
| Chose, designed or wrote the new reading curriculum | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation, not words for you: your material says a move you led, not who chose or wrote the curriculum. A5's slot stays inside the move |
| Speaks with every family each term | Inflated form of F4 and F5 | F4's quote at its own scope. The limit is the pack's observation: your material says an email to families, not conversations. C2's slot asks only how and how often you also speak with families |

## Sources

Provided: the invite text (quoted in F1, F6 and the title block) and your pasted CV text (every evidence cell). No dossier was consumed.

Research tier: L1 — searches 5 of 6, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. District values | yes | Three beliefs by name (Every Child a Reader, Families Are Partners, Teach for Tomorrow, Not for the Test): themed C1 to C3 and fit rows F5, F8 and F10. No values-style round was detected, so there is no values cheat sheet |
| 2. Interview process | yes | Loop: one 45-minute building panel of the principal and two grade-level teachers; topics reading instruction, classroom routines and families. Fixed the persona table and rows F2 to F4 |
| 3. Strategy and recent news | yes | The August 2026 literacy plan: D1, A3 and reverse question 3 |
| 4. Interviewer | yes | The principal's public footprint (since 2022, nine years as reading specialist, a 2025 talk): the interviewer read and reverse questions 1 and 2. The two teammates are unnamed, so no query could be formed for them |
| 5. Representative posting | yes | No posting text was supplied, so a typical fourth-grade posting supplied F7, F8's second clause and F9, all `[inferred]`. Its search snippet was cut off mid-sentence in the qualifications, so nothing from the qualifications is quoted |

Queries and what came back:

| Query | Result |
|---|---|
| Orrinsford Community School District mission values | https://orrinsfordschools.example/about/mission-and-beliefs |
| Orrinsford Community School District teacher interview process panel | https://orrinsfordschools.example/careers/how-we-hire-teachers |
| Orrinsford Community School District strategic plan news | https://orrinsfordschools.example/news/board-adopts-literacy-plan |
| Dolores Vantongeren principal Halvering Elementary School | https://ilprincipalsforum.example/speakers/dolores-vantongeren |
| fourth grade teacher job description Illinois elementary school responsibilities qualifications | https://k12jobsboard.example/listings/fourth-grade-teacher |

Fetch: https://orrinsfordschools.example/about/mission-and-beliefs, read in full to take the third belief's name and all three definitions from the page itself.

## Upgrade menu

- The full posting for this role → rows F7 and F9 move from `[inferred]` to `[grounded]`, and A2 and D4 are re-grounded in the posting's own lines
- HR's email or any note on what to prepare or bring, such as a sample lesson → a build section for each announced deliverable
- The names of the two fourth-grade teachers → an interviewer read for each, persona weights per panelist, and a reverse question tied to each one's path
- Your own answers to the answer slots in F2, F3, F5, F7, F8, F9 and F10, said outside a drill → those rows move from discovery to your quoted evidence, and the matching guidance becomes a story map
- The state's record of your license, showing the endorsement and status → F1 can move from medium to high
- How many hours you have before Thursday → a prioritized prep schedule sized to the time
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → a grounding brief on the literacy plan and the principal's published talks, plus a check for loop reports on this district
- A `tuesday-dossier.md` from an earlier session, if you have one → verified evidence and prohibited claims carry in directly; the pack never needs one
