# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

Orrinsford Community School District. A 45-minute panel on Thursday with Principal Dolores Vantongeren and two members of the fourth-grade team. Built on one assumption: the panel runs as the district's own hiring page describes it.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding for your own words, not a script, and every claim about your past is a sentence you wrote, quoted next to it.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the district's published beliefs |
| EXP | Whether your CV's claims survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, including its gaps |
| CO | Whether you know the district and its current direction |
| CASE | How you reason through a live classroom problem |

Provenance labels: `[grounded]` traces to your documents or a cited page, `[inferred]` is derived from a representative posting or an adjacent source, `[generic]` is a pattern with no claim about this employer or about you. An answer slot is an instruction for the interview, not a question for you now.

**Highest-ROI prep in this pack: A1.** You will be asked about moving to fourth grade in some form, and a calm, specific answer changes the whole panel.

## Fit snapshot

Requirements come from your invite, the district's own pages, and a representative posting (not the Halvering posting, which was not supplied), so those rows are `[inferred]`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" — your invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | A gate, and your material shows it met: kind, issuer, endorsement, status and expiry are all stated. Nothing has been inspected behind the CV line, so expect the district to verify it, and that check is yours to have ready. The pack needs no licence number and uses none |
| F2 | "plan and teach reading, writing, math, science and social studies" — representative posting, K12 Jobs Board (k12jobsboard.example/listings/fourth-grade-teacher) | "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [inferred] | transferability | Your quote gives the grade, the years and the school type, not which subjects. Words: "For six years I taught third grade at a public elementary school in Joliet." Answer slot: a probe on which subjects were yours to teach is likely. Say which, in your own words; if some were taught by someone else or not at all, say so plainly and stay with the third-grade years |
| F3 | "Fourth Grade Teacher position" — your invite | "I've never taught fourth grade" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't taught fourth grade." Then how you would learn the grade, said as a plan and never as a past. Never a claim to fourth-grade work. The pack's observation: six years in the grade below is adjacent (F2), but no sentence shows fourth-grade work |
| F4 | "Panels ask about reading instruction, classroom routines and how you work with families" — Orrinsford "How we hire teachers" page | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | discovery | Both sentences touch reading but neither shows how reading was taught day to day. Words: those two sentences at their own scope. Answer slot: the principal's published talk on weekly reading conferences in grades 3 to 5 makes a probe on how you taught reading likely. If you held reading conferences or taught reading in a set structure, say how often and what you did, in your own words; if you did not, or it was not yours to set, say so plainly and return to the curriculum move and the club |
| F5 | "communicate regularly with families" — representative posting, K12 Jobs Board | "I write a weekly email to families." — your CV | medium | [inferred] | none | No gap, but a CV line with nothing inspected behind it. Lead with it in the quote's own terms: weekly, and to families. Expect a question on what a typical email says |
| F6 | "each teacher speaks with every family each term" — Orrinsford "Mission and Beliefs" page | "I write a weekly email to families." — your CV | medium | [grounded] | transferability | An email is written; the belief speaks of speaking with each family. Words: "I write a weekly email to families." Answer slot: if you have spoken with families individually, say how and when; if the email has been the main channel, or those conversations were not yours to have, say so plainly and stay with the weekly email |
| F7 | "work with the grade-level team" — representative posting, K12 Jobs Board | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your message | medium | [inferred] | none | The first sentence reaches working with a grade-level team, at its own scope: you led the move. Keep the second sentence as its own plain acknowledgment: "I've never been a team lead." Never merge the two into "I led the team" |
| F8 | "differentiate instruction using assessment data" — representative posting, K12 Jobs Board | none given | none | [inferred] | discovery | Your material is silent here, and the district's belief is that "assessments inform teaching and never replace it". Answer slot: if you used assessment results to change what you taught, say what and how, in your own words; if you did not, or it was not yours to decide, say so plainly and say how you would start |
| F9 | "classroom routines" — Orrinsford "How we hire teachers" page | none given | none | [grounded] | discovery | Your material is silent here, and the panel names routines as a topic. Answer slot: if you set routines in your own room, say which and why, in your own words; if the school set them, say so plainly and say which you would keep |

## Reading the interviewer

Public professional footprint only, from one source: ilprincipalsforum.example/speakers/dolores-vantongeren.

| Fact | Practical implication |
|---|---|
| Principal of Halvering Elementary since 2022, after nine years as a reading specialist | Reading instruction is her home ground. Expect probes that go below "I ran a reading club" into how reading was taught (F4) |
| 2025 forum talk "Small Groups, Big Readers" covered weekly reading conferences in grades 3 to 5 | If conferences come up, answer from what you actually did; do not describe conferences you did not hold. The F4 slot is built for this |
| Her talk covers grades 3 to 5 | Third and fourth grade sit in her band. Your sentence "I've run the after-school reading club for the last two years" (F4) is the honest bridge: say it plainly and let her draw the link |
| Path from reading specialist to principal | A reverse question about that path is the strongest rapport move (reverse question 1) |

The two fourth-grade team members are not named, so there is no read on them; the persona table treats them as peers.

## Persona table

The loop rests on the district's careers page and your invite, not on an archetype: one 45-minute building panel, the principal and two grade-level teachers, covering reading instruction, classroom routines and families.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A) | Quiet, persistent probing of the fourth-grade gap and why you are moving | Highest. F3 is a stated gap and the title is the whole job, so the panel will test it from the first minutes | Rehearse A1 until it is boring: hold the six years, concede the grade, give a plan |
| Peer Evaluator (bank B) | The two fourth-grade teachers asking what you would need from them and what you bring them | High. They are the team you would join, and F7 is your team-facing evidence | Offer principles for the seam between third and fourth grade rather than pretending to know it |
| Case / Strategist (bank C) | The principal setting classroom problems: a struggling reader, assessment results, a school day | Medium-high. The district says panels ask about reading instruction and routines, and a principal who was a reading specialist will use live problems | Clarify first, structure second, think aloud |
| Conversational (bank D) | Friendly openers: tell us about yourself, what drew you here | Medium. Every panel opens this way, and it is still scored | Pre-script the 90-second arc from your four CV sentences |
| Values / Behavioral (bank E) | Questions keyed to the three published beliefs | Medium-low. The careers page names no values round, so no values-style round is detected, but the beliefs "guide every hire" and the panel's family and reading topics map onto them | One honest story or scaffold per belief |
| Data-Driven Prober (bank F) | A teacher reading your CV line by line | Low-medium. Your CV holds no figures, so there is no number to defend; the probe lands on what was yours in the curriculum move | Know what you can and cannot say about each CV sentence, and say so plainly |
| Pressure | Interrupting, time-boxing | Low, and no bank. Nothing in the loop source suggests it, and a school panel of this shape rarely runs this way | Not rehearsed here; the hold-then-concede move in A1 and A4 covers the closest case |

## Question banks

Requirement coverage first, so you can see what each requirement is rehearsed by.

| Requirement | Questions |
|---|---|
| F1 licence | — none, and why: the gate is shown met in your material, and the panel's published topics do not include it; one sentence stating it is enough |
| F2 subjects taught | C3, D1 |
| F3 fourth grade | A1, A2, A3, A5 |
| F4 reading instruction | A5, C1, F1, F2, E1 |
| F5 regular family communication | E2 |
| F6 speaking with every family | E2 |
| F7 grade-level team | A4, B1, B2, B3 |
| F8 assessment data | C4, E3 |
| F9 classroom routines | C3 |

### A. Skeptic (weight 1, five questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't taught fourth grade before. What would your first weeks with this class look like?" | JD | [grounded] "I've never taught fourth grade" — your message; "Six years teaching third grade at a public elementary school in Joliet." — your CV | The highest-ROI rehearsal in this pack. Hold only what the quote carries: "For six years I taught third grade at a public elementary school in Joliet." Concede specifically: "I haven't taught fourth grade." Then give the plan, in the future tense: what you would ask the two fourth-grade teachers first, and what you would watch before changing anything. Follow-up 1, "isn't that a big adjustment?": agree it is a different grade and return to the plan. Follow-up 2, "what if it takes you a term?": say what you would do to shorten it, in your own words, and promise no timeline you cannot back. Answer slot: if you have worked with fourth graders in any setting, say where and what you did; if you have not, say so plainly and return to the six years | F3 is the one gap you stated, and the title makes it the first objection; JD because it scores the listed job, and it carries the deepest rehearsal because it is the likeliest question |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" — your message | Name one weakness you can stand behind, and say it in a sentence. The material supports the grade (F3); where your material is silent (F8, F9) you may name those instead only if they are true for you. Then give the one thing you would do about it. If you cannot name one without guessing, say so plainly and say who you would ask | F3 and the silent rows are where this question lands; JD because it scores fit against the job |
| A3 | "You've spent six years in third grade. Why move now, and why Halvering?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." — your CV | Say the six years in the quote's own terms. Answer slot: give your actual reason for moving and for choosing this school, in your own words; if your reason is simply that you want fourth grade, say that plainly, and tie it to one published belief you can honestly speak to (see D3) | F3 raises motivation, and your material says nothing about why you are moving; EXP because it tests consistency between the CV and the story |
| A4 | "You led your grade level's move to a new reading curriculum, but you haven't been a team lead. How do you describe your part?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your message | Hold: "I led our grade level's move to a new reading curriculum in 2024." Concede, in its own sentence: "I've never been a team lead." Do not merge them into "I led the team." Answer slot: if asked what the move involved, say which parts were yours and which belonged to others, in your own words; if some of it was decided above the grade level, say so plainly and return to the quote | F7 holds both a lead sentence and a stated negative, and a panel that includes teammates will test the seam between them |
| A5 | "Your reading curriculum move was in third grade. How would fourth-grade reading change what you do?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV; "Six years teaching third grade at a public elementary school in Joliet." — your CV | Say the move at its own scope, then say what you would ask rather than what you know: what fourth-grade reading time looks like here, and what the team needs students to arrive with. Answer slot: if you already know how fourth-grade reading differs, say what and how you know; if you do not, say so plainly and return to the plan | F3 meets F4 here, and the principal's background is in reading; JD because it tests reading instruction in the new grade |

### B. Peer Evaluator (weight 2, three questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our fourth graders come to us from third grade. What would you want us to know from the third-grade side, and what do you need from us?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." — your CV | Reciprocity: say you taught third grade for six years, then offer two or three things you would ask them about what fourth grade needs students to arrive with. Propose principles for the seam rather than claiming to know it. Do not describe what third graders leave knowing unless you can say it from your own classroom | F7 and F3 meet at this seam, and peers weigh what a hire adds to their load; JD because it scores the team-facing part of the job |
| B2 | "Tell us about a time you and a colleague disagreed about how to teach something." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Selection scaffold: pick a real disagreement with a named stake, a position you held, and a working relationship intact afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry: "I led our grade level's move to a new reading curriculum in 2024", at its own scope, with no disagreement added | F7 is your collaboration evidence and your material does not show a disagreement; EXP because it asks for a real instance |
| B3 | "You run an after-school reading club. How would something like that fit a team that already has its own routines?" | EXP | [grounded] "I've run the after-school reading club for the last two years" — your CV | Say the club in the quote's terms: two years, after school. Answer slot: if you want to continue something like it here, say so and say you would ask the team first; if you do not, say that plainly. If asked what the club does, describe it in your own words; the pack knows nothing about it | F4 and F7 meet here, and peers price extra load; EXP because it asks about something you did |

### C. Case / Strategist (weight 3, four questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A student in your class is reading well below grade level in October. What do you do in the first month?" | CASE | [generic] | Structure it: clarify what you know about the student and what the data shows, set the objective, choose the approach, say how you would know it is working, and say how you would bring the family in. Think aloud, and challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | The theme comes from the published belief "Every Child a Reader" and the panel's reading-instruction topic (F4); CASE because it is a live classroom problem |
| C2 | "The board adopted a literacy plan with a new grades 3–5 reading curriculum from fall 2027. What would you want to know before it reaches fourth grade?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Prove homework with one fact: the plan exists and includes a grades 3–5 curriculum from fall 2027. Then diverge: ask what is changing for fourth grade and what the team wants from a new teacher before then. Say your 2024 move in its own words and no further. Answer slot: if asked what the move taught you, say what you actually learned; if nothing you can name, say so plainly and return to the quote. Do not offer to lead the rollout | F4 is the closest evidence you hold, and a new curriculum is the live strategy fact; CO because it scores current district knowledge |
| C3 | "Walk me through how you run a day in your classroom, from arrival to dismissal." | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." — your CV | Tell the day in your own words, naming two or three routines you can defend and why each exists. Answer slot: if you set the routines, say which; if the school set them, say so plainly and say which you would keep. Say which subjects you taught in the day; if some were taught by someone else, say that | F2 and F9 are both silent in your material, and the panel names routines as a topic; JD because it scores the listed job |
| C4 | "A third of your class missed the same skill on a unit assessment. What do you do?" | CASE | [generic] | Clarify first: which skill, and whether the miss is in the teaching or the test. Then decide how you would reteach, how you would check it worked, and how the results sit beside what you see in the room. The question needs no claim about your past, so the guidance makes none | F8 has no evidence and the district's belief is that assessments "inform teaching and never replace it"; CASE because it is a live problem |

### D. Conversational (weight 4, three questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — tell us about yourself and what brought you to fourth grade." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." — your CV; "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV; "I write a weekly email to families." — your CV | A 90-second arc built only from those four sentences, in your own words and without adding detail. Answer slot: give your own reason for fourth grade; if you have no reason beyond wanting the role, say so plainly | Every panel opens this way and it is scored; EXP because it tests whether your story matches your CV (F2, F4, F5) |
| D2 | "What do you love about teaching reading?" | VAL | [grounded] "I've run the after-school reading club for the last two years" — your CV | Answer from your own experience; link to the club only in the quote's terms. If a particular student or moment is true, tell it, and keep it unidentified; if none comes to mind, say what you like about the work in plain terms | A principal who was a reading specialist (F4) will ask this in a casual register, and it is scored; VAL because it tests the belief "Every Child a Reader" |
| D3 | "What drew you to Orrinsford and to Halvering?" | CO | [grounded] | Pick the one published belief you can honestly speak to: "Every Child a Reader", "Families Are Partners" or "Teach for Tomorrow, Not for the Test". Say the belief by name and say why it matters to you, in your own words. If none fits you, say so plainly and say what did draw you | The beliefs are published on the district's page; CO because it scores homework, and the guidance makes no claim about your past |

### E. Values / Behavioral (weight 5, three questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you helped a student who was not reading at level." | VAL | [grounded] "I've run the after-school reading club for the last two years" — your CV | Selection scaffold: pick a real student, say what you noticed, what you did and how it ended, with no identifying detail. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry: the club, at its own scope | The belief "Every Child a Reader" names no student leaving third grade without a reading plan, and your material does not show such a story (F4); VAL because it tests that belief |
| E2 | "Teachers here speak with every family each term. What does staying in touch with families look like for you?" | VAL | [grounded] "I write a weekly email to families." — your CV | Say it in the quote's terms: "I write a weekly email to families." Answer slot: if you have spoken with families individually, say how and when; if the email has been the main channel, say so plainly and say what you would add to reach every family each term | The belief "Families Are Partners" is published, and F5 and F6 differ in exactly this way; VAL because it tests that belief |
| E3 | "Tell me about a time assessment results changed what you taught." | VAL | [grounded] | Selection scaffold: pick a real instance, say what the results showed, what you changed and how you checked. If no such time comes to mind, say so plainly, then say how you would start. The guidance makes no claim about your past | The belief "Teach for Tomorrow, Not for the Test" says assessments inform teaching and never replace it, and F8 has no evidence; VAL because it tests that belief |

### F. Data-Driven Prober (weight 6, two questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Walk me through that move to a new reading curriculum in 2024." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | The beats are the ones the sentence states: the grade level, the move, 2024, and that you led it. Tell them in your own words. Answer slot: if asked how you know it worked, answer from what you saw or were told; if you do not know, say so plainly and return to the quote. Your CV holds no figure, so no number to defend | F4 and F7 rest on this one sentence, and a teacher reading your CV will go straight to it; EXP because it tests what was yours |
| F2 | "What have you learned from running the reading club?" | EXP | [grounded] "I've run the after-school reading club for the last two years" — your CV | Two years, after school, at its own scope. Answer slot: say what you actually learned, in your own words; if attendance or results were tracked, say what; if not, say so plainly | F4 includes this sentence and nothing else shows what the club does; EXP because it tests how much you can say about it |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "You came to the principal's seat after nine years as a reading specialist. How does that shape what you hope to see in fourth-grade reading time?" | Ties to her own path, and shows you researched her, not only the school |
| 2 | "What could a new fourth-grade teacher do in the first month that would genuinely help your team?" | The reciprocity question for peers; it turns the F3 gap into a partnership |
| 3 | "The literacy plan brings a new grades 3–5 reading curriculum from fall 2027. What is fourth grade preparing for between now and then?" | Shows you read the plan without reciting it |
| 4 | "What does a strong first term in fourth grade look like for someone new to the grade?" | Surfaces the bar you will be measured against |
| 5 | "How does the team arrange for each teacher to speak with every family each term?" | Shows you read "Families Are Partners" and asks for the practical detail |
| 6 | "References are taken up after the panel. What are the next steps, and when should I expect to hear?" | Process, and it keeps the close concrete |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade, or knows fourth-grade expectations | Negative you stated, F3 | "I haven't taught fourth grade." Then a plan, said as a plan. No slot beyond A1's |
| Has been a team lead, or led the grade-level team | Negative you stated, F7 | "I led our grade level's move to a new reading curriculum in 2024", at its own scope, and "I've never been a team lead." |
| Can lead, or has led, a district-wide literacy curriculum rollout | Inflated form of F4 and F7 | The quote at its own scope. The pack's observation: your material says your grade level's move, not the district's, and the 2027 curriculum is the board's |
| Speaks with every family each term | Inflated form of F6 | "I write a weekly email to families." The pack's observation: an email is written, the belief speaks of speaking. E2's slot stays inside the email |

## Sources

Provided: your invite text and your CV text. The CV also holds a number that is not needed for any of this and was not used.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Orrinsford Community School District mission values` | yes | Returned orrinsfordschools.example/about/mission-and-beliefs, which was then fetched: three beliefs by name. Themes banks C, D, E and reverse questions 3 and 5 |
| 2. `Orrinsford Community School District teacher interview process panel` | yes | Returned orrinsfordschools.example/careers/how-we-hire-teachers, which was then fetched: one 45-minute building panel, panel topics, references after. Fixes the loop and persona weights, and F4 and F9 |
| 3. `Orrinsford Community School District strategic plan news` | yes | Returned orrinsfordschools.example/news/board-adopts-literacy-plan (search snippet only, page not fetched): the August 2026 literacy plan. Moved C2 and reverse question 3 |
| 4. `Dolores Vantongeren principal Halvering Elementary School` | yes | Returned ilprincipalsforum.example/speakers/dolores-vantongeren (snippet only). Moved the interviewer read and reverse question 1 |
| 5. `Fourth Grade Teacher job posting Illinois elementary school responsibilities qualifications` | yes | Returned k12jobsboard.example/listings/fourth-grade-teacher (snippet only), a representative posting, not Halvering's. Moved F2, F5, F7 and F8, all `[inferred]` |

## Upgrade menu

- The full Halvering posting text → F2, F5, F7 and F8 become `[grounded]` against the district's own wording, and any requirement the posting stresses gets its own question
- Any note from HR about what the panel will cover, or something to bring such as a sample lesson → a build section for each declared deliverable
- Your answers to the slots in F2, F4, F6, F8 and F9, told outside a drill → those rows become story-mapped answers instead of slots
- The licence's official registration record, showing kind, endorsement, status and expiry as the issuer holds them → F1 moves from `medium` to `high`
- A document from the 2024 curriculum move, such as an adoption plan or meeting notes → F4 and F7 move from `medium` to `high`
- The names of the two fourth-grade team members → an interviewer read on their public footprint and a tailored reverse question for each
- A deeper research pass, up to 6 more searches and 2 more fetches, several more minutes → a strategy and district-context brief for C2 and the reverse questions
- A `tuesday-dossier.md` from an earlier evaluation of this role → verified evidence and any prohibited claims, which would replace the ones built here
