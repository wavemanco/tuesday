# Interview prep pack: Customer Support Specialist, Lumenvale Software

Interviewer: the support team lead, by text chat (the interviewer's name is not known). Built as a hiring-manager-style round, since the team lead is the person assessing you for the job.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script. Because your interview is a typed chat, "speakable" here means short typed messages you could send in about two minutes.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows a value, with a specific example |
| EXP | Whether your own experience holds up under follow-up questions |
| JD | The job ad's stated requirements, including your gaps |
| CO | What you know about the company |
| CASE | A live problem like the ones the role faces |

Labels: `[grounded]` rests on something you wrote; `[inferred]` is derived from it or from the ad; `[generic]` is a pattern for the role with no claim about you or the employer.

## Fit snapshot

The ad's requirements are quoted as you described them in your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — job ad, as you described it | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message | medium | [grounded] | none | No gap on length, but it is a self-reported line with nothing inspected behind it, so expect a probe on it. Lead with the quote's own terms: three years, customer service advisor, an energy supplier. Say "answering", as the quote does |
| F2 | "experience with Zendesk or a similar ticketing tool" — job ad, as you described it | "I use Freshdesk every day" — your message | medium | [grounded] | presentation | Say the tool and how often, in the quote's words: "I use Freshdesk every day." The ad names Zendesk and your material does not mention it, so claim Freshdesk only |
| F3 | "clear written communication" — job ad, as you described it | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | Emails are the nearest thing the quote touches, and it does not show how clearly you wrote them. Answer slot: the ad's line makes a probe on your written replies likely, and this chat is itself a writing sample. If anyone commented on your written replies, say what was said; if no one did, say so plainly and stay with the emails you answered |
| F4 | "confident handling escalations" — job ad, as you described it | none given | none | [grounded] | discovery | Your material does not show escalations either way. Answer slot: the ad raises escalations, so expect a probe. If you handled escalated cases, say what happened and which part was yours; if escalations went to someone else, or there were none, say so plainly and stay with the calls and emails you answered |
| F5 | familiarity with a software company's product and customers (role-family expectation, no source quoted) | "I've never worked for a software company" — your message | none | [generic] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked for a software company." Then how you would learn the product, said as a plan and never as a past |
| F6 | showing colleagues how things are done (role-family expectation, no source quoted) | "I trained four new starters on our refunds process last year" — your message | medium | [generic] | none | The quote already reaches it. Keep its terms: trained, four new starters, the refunds process, last year. Say "trained", not "managed" or "led" |

## Persona table

Weights start from the hiring-manager prior and are adjusted by what you told me: one session, a text chat, run by the support team lead.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | Live customer scenarios, answered in writing | High. The hiring-manager prior favours live problems, and the ad's escalation and written-communication lines are testable in a chat | Clarify first, then structure, then write the reply. Your typed answers are the sample being judged |
| B. Skeptic | Probes the software gap, the move, escalations | High. F5 is a gap you stated and F4 is silent | Rehearse B1 until it is boring: acknowledge, hold what you have, give a plan |
| C. Conversational | Friendly opener, casual questions that are still scored | Medium. A chat with a team lead often opens loosely | Have a short typed arc ready; treat casual questions as scored |
| D. Data-Driven Prober | Digs into your numbers and tool use | Medium. You gave two figures and a tool | Say how each figure was counted, or say you do not know |
| E. Pressure | Time-boxed or blunt questions | Low to medium. A chat can be made brisk | Take a moment, restate, hold your position, concede only what is true |
| F. Values / Behavioural | "Tell me about a time" prompts | Low. No values-style round is established for this session | Pick a real example or say plainly that none comes to mind |
| Peer Evaluator | Not banked | Low. One interviewer, who is the team lead and not a peer | None needed |

The loop rests on your own words: one session, a text chat with the support team lead. The pack knows nothing about the round beyond that.

## Question banks

Highest-ROI prep: B1, the question on the software gap. It rests on a limit you stated yourself, so it is the one most likely to be asked and the one a rehearsed, steady answer helps most.

### A. Case / Strategist (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in for the third time about the same problem and says they want to cancel. What do you do first?" | CASE | [generic] | Structure it: what you would read first, what is still unresolved, what you can fix yourself and what needs someone else, what you would tell the customer and by when, and what you would record. The question needs no claim about your past, so the guidance makes none | A live problem of the kind a support lead sets; CASE because it scores structure and not a past claim |
| A2 | "A customer is angry and the fix needs another team, who cannot act until tomorrow. Type me the message you would send." | CASE | [generic] | Write the reply in the chat as if it were real: acknowledge the problem plainly, say what happens next and when, say who has it, and promise nothing you cannot control. Short, clear sentences | Tests F3 and F4's requirements in one task; CASE because the answer is produced live |
| A3 | "How do you decide whether to keep a case or escalate it?" | JD | [generic] | A hypothetical, so structure it: what you can resolve with what you have, what needs authority or knowledge you lack, how long the customer has already waited, and how you hand over so the customer need not repeat themselves. Make no claim about past escalations here; B3 covers those | The ad's escalation line, asked as a decision; JD with CASE delivery |
| A4 | "A customer replies with one line: 'it still doesn't work.' What do you write back?" | CASE | [generic] | Clarify before fixing: ask for the one or two details you most need, say what you will do with them, and keep it short. Say what you would not assume | Clear writing under little information; CASE because it is a live reply |

### B. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never worked for a software company. Which part of this job would be hardest on day one?" | JD | [grounded] "I've never worked for a software company" | Hold, then concede. Concede first and plainly: "I've never worked for a software company." Then say what you do carry, at its own scope: "I use Freshdesk every day." Then a plan said as a plan: how you would learn the product in your first weeks, in your own words. If pushed on how fast you would be useful, concede that you cannot give a date for knowledge of a product you have not seen, and return to the plan. Hold that position through two follow-ups | The highest-ROI rehearsal: F5 is a limit you stated, so it will be asked in some form. JD because it scores a stated expectation; the pressure structure comes from its type |
| B2 | "What makes you want to move from an energy supplier into software?" | EXP | [generic] | Give your actual reason, in your own words; the pack supplies none. The pack holds nothing on what Lumenvale makes, so any reason tied to the product must be one you can back with something you have actually looked at | The motivation probe a Skeptic runs on a sector change; EXP because it tests your own account |
| B3 | "Tell me about a time you handled an escalation." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Selection scaffold: pick one case that went beyond what you could resolve yourself, with a named stake, what you did, and where it ended. The ad raises escalations, so expect this. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, the calls and emails you answered, or how you would handle it | F4 is silent in your material, so this is where the probe lands; EXP because it tests your own account |
| B4 | "Which ticketing tools have you used?" | JD | [grounded] "I use Freshdesk every day" | Say what the quote says: "I use Freshdesk every day." Answer slot: if you have used another tool, name it; if not, say so plainly and stay with Freshdesk. Do not claim Zendesk | F2 is the tool requirement; JD because it scores the ad's line |

### C. Conversational (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So tell me a bit about yourself and what you do now." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day"; "I use Freshdesk every day" | A short typed arc built only from those beats: customer service advisor at an energy supplier, three years, around 60 calls and emails a day, Freshdesk daily. Then your own reason for this role. Add no beat the quotes do not state | The biography opener is scored even when it sounds casual; EXP because it sets up every later probe |
| C2 | "I see you trained new starters. Tell me about that." | EXP | [grounded] "I trained four new starters on our refunds process last year" | Tell it with the beats the quote states: four new starters, the refunds process, last year. Say "trained". If asked for more, answer from what you remember or say you do not remember | F6 is a strength the quote carries, so use it fully and no further; EXP because it tests what you actually did |
| C3 | "What do you know about what we make?" | CO | [generic] | The pack holds nothing on Lumenvale's product, so it cannot tell you. Say plainly what you have actually looked at. If you have not looked yet, look at the company's own website before the chat and say what you found. Never claim to have used the product | A casual question that is scored; CO, `[generic]` because no company research could be used |

### D. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You said around 60 calls and emails a day. How was that counted?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Keep the figure as you gave it: around 60, calls and emails together. In your own words: how it was counted, what it varies with, which part of it you are least sure of, and what was yours. If you do not know how it was counted, say so plainly | F1 holds the figure; EXP because probers test numbers first |
| D2 | "How do you use Freshdesk day to day?" | JD | [grounded] "I use Freshdesk every day" | Start with the quote. Then describe what you actually do in it, in your own words, and name only features you use. If asked about a feature or a tool you have not used, say so | F2 again, tested for depth; JD because it scores the ad's tool line |
| D3 | "You trained four new starters on refunds. Which part of that was yours?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | In your own words: what you covered, and what was done by others if anyone else was involved. If it was shared, say so plainly. Keep "four", "refunds" and "last year" as you gave them | A prober's attribution question on F6's figure; EXP |

### E. Pressure (weight: low to medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "One minute: why should we pick you over someone who has worked in software support?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day"; "I've never worked for a software company" | Hold, then concede. Hold on what you carry: three years answering around 60 calls and emails a day. Concede what is true: "I've never worked for a software company." Do not claim equivalence. Hold through two follow-ups by returning to those facts | A time-boxed test of whether you stay steady on F5; JD |
| E2 | "One line only: which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company" | One line, then stop: name the software gap as you said it, and add that you would learn the product. Resist adding a second weakness or a long defence | B1 in its time-boxed form; JD |

### F. Values / Behavioural (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "When did you put a customer ahead of an internal target?" | VAL | [generic] | Selection scaffold: pick a real case with a named customer need, the internal pressure on the other side, what you decided, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard values prompt; no published values were read, so it is `[generic]` |
| F2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: a real moment you told someone senior something unwelcome, what was at stake, and how the relationship stood afterwards. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioural stem; VAL, `[generic]` |

## Requirement coverage

| Requirement | Questions |
|---|---|
| 2+ years in customer support | C1, D1, E1 |
| Zendesk or a similar ticketing tool | B4, D2 |
| Clear written communication | A2, A4 |
| Confident handling escalations | A3, B3, A2 |
| Software company familiarity (role-family) | B1, B2, C3, E1, E2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good first month look like for someone new to software support?" | Turns the software gap into a plan you are already thinking about |
| R2 | "Which ticketing tool does the team work in, and how do new starters get trained on it?" | Shows you care about the tool requirement and gets you the real answer |
| R3 | "How does the team handle escalations, and what would you expect of a new Specialist?" | Shows you take the escalation line seriously and tells you what the expectation is |
| R4 | "How does the team review or coach written replies?" | Shows you care about writing quality, which this chat is already testing |
| R5 | "Is there a call or video step after this chat, or does the rest stay in text? I would like to know how to prepare." | A process question with a prep reason: it tells you whether to rehearse spoken answers too |
| R6 | "What are customers writing in about most at the moment?" | Starts building the product knowledge C3 shows you lack |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has used Zendesk | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day." The limit is the pack's observation: your material names Freshdesk and not Zendesk |
| Has worked in a software company or in software support | Negative you stated, F5 | "I've never worked for a software company." No slot |
| Resolved or closed a number of tickets a day | Inflated form of F1 | F1's quote at its own scope: "answering around 60 calls and emails a day". The quote says answering, and says calls and emails, not tickets |
| Managed, led or mentored new starters | Inflated form of F6 | F6's quote at its own scope: "I trained four new starters on our refunds process last year" |

## Sources

Provided documents: your message, with the invite text, the ad's requirements as you described them, and your background. No dossier was supplied.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

Searches sent, each refused by the host: "Lumenvale Software company values"; "Lumenvale Software interview process customer support specialist"; "Lumenvale Software strategy news".

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | Would have fed C3 and any values mapping; nothing used, so C3 and Bank F are `[generic]` |
| 2. `Lumenvale Software interview process customer support specialist` | unavailable | Would have fed persona weights; they rest on your own description of one text chat with the support team lead |
| 3. `Lumenvale Software strategy news` | unavailable | Would have fed C3 and a company-specific CO question; none is included |
| 4. interviewer name and company | n/a | The support team lead is not named, so no query could be formed |
| 5. representative Customer Support Specialist JD | skipped | The ad's requirements, as you quoted them, fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full job ad text → F1 to F4 quote the ad itself, and any requirement you did not mention gets a row and a question
- Your CV → each fit-snapshot row can quote your own CV lines, and F3 and F4 may upgrade from `discovery`
- Your answers to the F3 and F4 slots, said outside a practice → those rows regenerate on what you actually said
- The support team lead's name → an interviewer read and a reverse question tied to their path
- The company's own careers or values page, pasted → C3 and Bank F can use the company's real wording
- Search access, if you grant it → the three refused targets can run, which feeds C3, persona weights and a values sheet if a values round is documented
- A `tuesday-dossier.md` from an earlier session → verified evidence and any prohibited claims it holds would replace what this pack infers
