# Interview pack: Remote Administrative Assistant, Brennock Facilities Ltd

Candidate: Aoife. Format: a 30-minute video call with the office manager (your own account of the format). The interviewer's name is not given. The relationship is assumed to be the person you would work for or alongside day to day, so the weights below follow a hiring-manager round.

## How to use this pack

- Personas are how a question is asked. Types are what it is scored on.
- Types: VAL (behaviour against published values), EXP (whether your experience survives follow-up), JD (a stated duty or requirement), CO (company and strategy knowledge), CASE (a live problem set in the role).
- Guidance is scaffolding, not a script. Say it in your own words.
- An answer slot is an instruction for the interview, not a question for you now. Each has two honest branches. Either is fine, and the second one (it was not mine, or I did not do it) is never a confession.
- Provenance labels: grounded means traceable to something you gave me, inferred means derived from it with the derivation named, generic means a pattern for the role with no claim about you or the employer.
- The highest-ROI prep in this pack is B1. It is the question aimed at where your material is thinnest.

## Fit snapshot

The requirements are the four duties as you described the ad. Evidence is your own words.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as you described it | "I ran the appointment book for four physios" — your message | medium | [grounded] | presentation | Say it in the quote's own terms: you ran the appointment book for four physios. Keep four attached to physios, which is what it counts. A line with nothing inspected behind it, so expect follow-ups on it |
| F2 | "booking travel" — the ad, as you described it | none given | none | [grounded] | discovery | Your material does not show travel booking either way. Answer slot: the ad lists booking travel, so a probe on it is likely. If you have booked travel for anyone, say what and for whom, in your own words; if you have not, say so plainly and say how you would go about learning it |
| F3 | "preparing documents in Word and Excel" — the ad, as you described it | "I'm good with Word, okay with Excel" — your message | medium | [grounded] | discovery | Say it with its own polarity and do not lift okay to good. Your quote rates the two programs and does not show what you have made in them. Answer slot: the ad names both programs, so expect a probe on what you have made in each. If you have made something in either, say what, in your own words; if you have not, say so plainly and stay with how you rate yourself |
| F4 | "processing supplier invoices" — the ad, as you described it | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Keep the quote at its own scope: you chased unpaid invoices. Your material does not say whose invoices they were. Answer slot: the ad's invoice line makes a probe on your part in them likely. If your part went beyond chasing, say what, in your own words; if it did not, say so plainly and stay with the chasing |

Background quotes carrying no requirement of their own: "two years as a receptionist at a physiotherapy clinic" — your message.

## Persona table

The loop rests on your own account: one session, a conversation with the office manager. No values-style round is detected, so no values persona is weighted. Weights start from the hiring-manager prior and are adjusted for the format.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (A) | Small live problems taken from the four duties | High. The hiring-manager prior favours it, and each duty can be set as a short scenario in a 30-minute call | Clarify first, then structure, then answer. Think aloud. The cases need no claim about your past |
| Skeptic (B) | Quiet probing of the thinnest rows | High. The hiring-manager prior favours it, and F2, F3 and F4 are where the material is thinnest | Rehearse the single most predictable objection (B1) until it is boring. Use only what your quotes carry and say the limit plainly |
| Conversational (C) | A friendly opener and open prompts that are still scored | Medium. A short video call usually opens with a chat, and this one is likely to | Keep a 90-second arc ready that uses only the beats your sentences state |
| Data-Driven Prober (D) | Follow-ups on the lines in your background | Low. There are few figures to defend, but the lines you gave are short enough to be probed word by word | Know exactly what each line covers and what it does not |
| Pressure (E) | Interruptions, attribution challenges | Low. Nothing in the format signals a stress style | Pause, restate, hold on what your quotes carry, concede specifically |
| Peer Evaluator (F) | Collaboration scenarios | Low. Weighted up only if the office manager turns out to be a colleague rather than your manager | Offer working principles rather than pretending to know their setup |

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two people want the same hour in a shared diary and both say theirs is urgent. What do you do?" | CASE | [generic] | Structure it aloud: who has authority to decide, what can move, what each person actually needs, what alternative you can offer, and how you confirm and record the outcome. The question needs no claim about your past, so the guidance makes none | The calendar duty in F1 set as a decision rather than a record |
| A2 | "A manager asks you to book a trip for next week. What do you ask before you book anything?" | CASE | [generic] | Clarify before acting: who is travelling, dates and times, budget and any approval needed, preferences, and how changes are handled. Then say what you would send back and when. No claim about your past | The travel duty in F2 as a live problem, so the topic is rehearsed even though your material is silent on it |
| A3 | "An invoice arrives from a supplier and the total does not match what was ordered. What do you do?" | CASE | [generic] | Say you would hold it rather than process it, then who you would check with and what you would record. Say what you would not decide alone. No claim about your past | The invoice duty in F4 as a live problem. It tests judgement and does not depend on experience |
| A4 | "Here is a list of forty supplier invoices with dates and amounts. The manager wants to know what falls due this week. How would you set that up?" | CASE | [generic] | Think aloud: what columns you need, how you would sort or filter, how you would total, how you would check the result. Where you do not know a feature, say so plainly and say how you would find it | The Excel duty in F3 as a task. Honest uncertainty here is better than a guessed function name |
| A5 | "You are handed a page of rough notes and asked for a clean one-page document for a meeting tomorrow. What do you do?" | CASE | [generic] | Ask who it is for and what it must do, then structure, draft, check, and send with time left for a correction. No claim about your past | The Word duty in F3 as a task |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I'm good with Word, okay with Excel" "chased unpaid invoices" | The highest-ROI rehearsal in this pack. Level one: pick the weakest part from your own material and say it in your own words. The pack's observation is that your material rates Excel as okay and says chasing, not more, about the invoices. Level two, if they ask what okay means: answer slot: if you have made something in Excel, say what, in your own words; if you have not, say so plainly. Level three, if they ask why take the risk: concede the limit specifically, then give a plan for your first weeks as a plan and never as a past. Hold on "I'm good with Word, okay with Excel", and add nothing to it | F3 and F4 are the thinnest rows, so this objection arrives in some form. JD because it scores the stated requirements. Skeptic because it asks you to find your own gap |
| B2 | "Booking travel is part of this job. What experience do you have with it?" | JD | [grounded] "I ran the appointment book for four physios" | Answer slot: if you have booked travel for anyone, say what and for whom, in your own words; if you have not, say so plainly. Then the part your quote carries: "I ran the appointment book for four physios", and how you would learn the travel side | The ad's travel line (F2) with no evidence behind it. The second branch lets the premise be false |
| B3 | "The role involves processing supplier invoices. How does that compare with what you did at the clinic?" | JD | [grounded] "chased unpaid invoices" | Say it at its own scope: "I chased unpaid invoices." Answer slot: if your part went beyond chasing, say what, in your own words; if it did not, say so plainly and stay with the chasing | F4 is adjacent work, so the comparison is the likeliest probe. The guidance does not adopt the premise that the two are alike |
| B4 | "What is drawing you from a clinic front desk to a remote admin role, and why now?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | Your material gives no reason, and the pack will not supply one. Give your actual reasons in your own words, in under a minute, starting from the sentence you gave: two years as a receptionist at a physiotherapy clinic | The usual motivation probe for a change of setting. EXP because it tests whether your story is consistent |
| B5 | "Tell me about a time you had to organise your own workload with little supervision." | EXP | [grounded] "I ran the appointment book for four physios" | Selection scaffold: pick one occasion with a named stake, how you decided what came first, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: "I ran the appointment book for four physios", or how you would handle it | The role is remote, so working without supervision is a likely theme. Open prompt, so it supplies no event |

### C. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your journey." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | A 90-second arc with three beats the sentence states: two years, receptionist, a physiotherapy clinic. Then your own reason for this role, in your own words. Nothing about the clinic beyond your quotes in F1 and F4 | The usual opener, and it is scored even though it feels casual |
| C2 | "Tell me about something you have made in Word or Excel that you were pleased with." | JD | [grounded] "I'm good with Word, okay with Excel" | Selection scaffold: pick one thing, say what it was for and who used it. If no such thing comes to mind, say so plainly, then give the nearest thing your material carries: "I'm good with Word, okay with Excel" | A casual question on a hot duty from F3. Open prompt, so it supplies no event |
| C3 | "What would you hope to have learned by the end of your first month?" | JD | [grounded] "I'm good with Word, okay with Excel" | A plan, not a past: name the thing you rate lowest, your own words being "okay with Excel", and how you would close it. Do not name a course or tool you have not looked into | Turns B1 into a forward-looking answer. It claims nothing about your past |
| C4 | "Is there anything about your experience we have not covered?" | EXP | [grounded] "I ran the appointment book for four physios" | Use it to land one beat the quote states: "I ran the appointment book for four physios". Add nothing it does not say | Never answer that everything has been covered. The slot is scored |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about the appointment book you ran. What was in it?" | EXP | [grounded] "I ran the appointment book for four physios" | Say what you can from experience, in your own words, and keep four attached to physios. If you cannot say how something worked, say so plainly. The quote carries the appointment book and four physios, and nothing else | F1 is a one-line claim, so this is the first follow-up. The question is premised on the quote only |
| D2 | "Tell me about the unpaid invoices. What was your part?" | EXP | [grounded] "chased unpaid invoices" | "I chased unpaid invoices" is the part your quote carries. Answer slot: if you did anything else with them, say what; if the chasing was all, say so plainly | F4 is where an attribution probe lands. The second branch lets the chasing be all |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "You have sixty seconds: why should we choose you over someone who has worked in an office admin role?" | JD | [grounded] "I ran the appointment book for four physios" | Pause, restate, then hold on what your quote carries: "I ran the appointment book for four physios". Hold through two follow-ups. If pushed on Excel, concede specifically with your own words, "okay with Excel", and do not fold on the rest | A time-boxed version of B1's objection. The hold is only what F1 carries |
| E2 | "How much of that appointment book was actually you?" | EXP | [grounded] "I ran the appointment book for four physios" | Hold on the quote: you ran it. Answer slot: if anyone shared it with you, say who and what stayed yours; if it was yours alone, say so plainly. Never widen the claim to cover more than the book | Attribution probes are asked of every line. The question presupposes only the quote |

### F. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "If you and a colleague both thought a task was yours, how would you sort it out?" | CASE | [generic] | Offer principles, not claims about this team: ask early, say what you think, agree who owns it, write it down. No claim about your past | A seam question in collegial packaging. It is weighted up only if the office manager is a colleague |
| F2 | "Tell me about a time a colleague saw something differently from you." | EXP | [grounded] "I ran the appointment book for four physios" | Selection scaffold: pick one disagreement, what each side wanted, how it ended, what you would do the same. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: "I ran the appointment book for four physios", or how you would handle it | The peer stem, kept as an open prompt so it supplies no event |

### Requirement coverage

| Requirement | Questions |
|---|---|
| managing calendars | A1, B5, D1, E1, E2 |
| booking travel | A2, B2 |
| preparing documents in Word and Excel | A4, A5, B1, C2, C3 |
| processing supplier invoices | A3, B1, B3, D2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a typical week of diary, travel and invoice work look like for this role?" | It shows you read all four duties, and the answer tells you which one to rehearse most |
| R2 | "Which tools do you use today for diaries, travel booking and invoices, and how much of the Excel work is routine?" | It gets the Excel level on the table early, in your terms, instead of leaving it to a probe |
| R3 | "Who would I be working for day to day, and how do you like work handed over?" | It settles the relationship this pack assumed and shows you are thinking about working together |
| R4 | "What would a good first month look like?" | It echoes C3 and gives you the yardstick they will use |
| R5 | "What are the next steps after this call, and what is the timescale?" | A process question with a prep reason: it tells you what else to prepare for |
| R6 | "What could a new person do in their first month that would genuinely help you?" | A reciprocity question. It signals you think about their load, and it matters most if the office manager is a peer |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed calendars for a team | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios". The limit is the pack's observation: your material says an appointment book for four physios, not the wider wording |
| Strong Excel skills | Inflated form of F3 | F3's quote at its own scope: "I'm good with Word, okay with Excel". The limit is the pack's observation: your material rates Excel as okay |
| Processed supplier invoices | Inflated form of F4 | F4's quote at its own scope: "chased unpaid invoices". The limit is the pack's observation: your material says chasing, and does not show whose invoices they were |

Booking travel is not listed. No quote of yours speaks to it, so it is silence and not an inflated claim, and F2 carries it as an answer slot.

## Sources

Provided: your message, covering the four duties as you described them, your background, and the interview format it gave.

No dossier was supplied.

Searches sent (all refused by the host, so nothing came back):

- `Brennock Facilities Ltd values` — refused
- `Brennock Facilities Ltd interview process administrative assistant` — refused
- `Brennock Facilities Ltd news strategy` — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Brennock Facilities Ltd values` | unavailable | Every call was refused. It would have supplied published values for VAL theming. No values-style round is detected, so no values cheat sheet is built either way |
| 2. `Brennock Facilities Ltd interview process administrative assistant` | unavailable | Every call was refused. It would have named the loop. The loop here rests on your own account of one call with the office manager, so the persona weights stand on that and not on an archetype |
| 3. `Brennock Facilities Ltd news strategy` | unavailable | Every call was refused. It would have supplied current context for a CO question, so the banks carry no CO question |
| 4. `{interviewer name} Brennock Facilities Ltd` | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. representative `Remote Administrative Assistant` JD | skipped | The four duties you gave fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full ad text → the four requirement quotes come from the ad itself and not from your description, and any mid-list duty the description left out gets a question
- Whether the office manager is your day-to-day manager or a colleague → persona weights recomputed, with Peer up or down and the reverse questions retuned
- The office manager's name → an interviewer read and a reverse question about their own path
- Anything you can say, in your own words and outside a drill, about travel booking (F2), what you have made in Word or Excel (F3), or your part in the invoices (F4) → those rows gain quoted evidence and the answer slots in B1 to B3 and C2 become story-mapped
- Web search permission → the three company searches run, so published values, the loop and recent news can ground a CO question
- A tuesday-dossier.md from an earlier run → verified evidence for F2 to F4 and a ready-made list of claims to avoid
