# Interview pack: Customer Support Specialist, Lumenvale Software

Round: one text chat with the support team lead (your invite's words). Interviewer name: not given. Relationship assumed: the person you would work under, so hiring-manager weights apply.

## How to use this pack

Personas describe how a question arrives; types describe what it is scoring. Guidance is scaffolding, not a script: say it in your own words, typed in short, clear messages, because in this round the writing is itself part of what is scored.

| Type | Meaning |
|---|---|
| VAL | Behavioral or values alignment: past behavior, not slogans |
| EXP | Work-experience deep-dive: whether your own claims survive a follow-up |
| JD | Role and job-ad requirements, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem from the actual role |

Provenance labels: `[grounded]` rests on your words or a document you gave me; `[inferred]` is derived and the derivation is named; `[generic]` is a role-family pattern with no claim about Lumenvale or about you. The research searches for this pack were refused (see Sources), so every company-facing item is `[generic]`.

## Fit snapshot

The requirements are quoted from your description of the ad, since the full ad text was not supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — the ad, as you described it | "3 years as a customer service advisor at an energy supplier" — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe on the role. Say it in the quote's own terms: 3 years as a customer service advisor at an energy supplier |
| F2 | "experience with Zendesk or a similar ticketing tool" — the ad, as you described it | "I use Freshdesk every day" — your message | medium | [grounded] | presentation | Your message names Freshdesk, not Zendesk, and the ad's own words allow "a similar ticketing tool". Words: "I use Freshdesk every day." Let the interviewer judge the similarity; add no Zendesk claim, no feature and no practice to it |
| F3 | "clear written communication" — the ad, as you described it | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | The quote covers calls and emails together and does not show how clear the writing was; the bridge should not be stretched. Answer slot: the ad's written-communication line makes a probe on your replies likely. If you have a habit that keeps a reply clear, say what it is in your own words; if there is none you can name, say so plainly and stay with the emails you answered |
| F4 | "confidence handling escalations" — the ad, as you described it | none given | none | [grounded] | discovery | Your material does not show escalations either way. Answer slot: expect a probe on a real one. If you handled an escalation, say what the situation was, what you did and what happened, in your own words; if escalations went to someone else or never reached you, say so plainly and say how you would handle one |
| F5 | sharing process knowledge with new colleagues (role-family requirement, no source) | "I trained four new starters on our refunds process last year" — your message | medium | [generic] | none | Say it as quoted: four new starters, the refunds process, last year. Expect a probe on how much of the training was yours (D2, D3) |
| F6 | familiarity with a software company's product and customers (role-family requirement, no source) | "I've never worked for a software company" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked for a software company." Then how you would learn the product, said as a plan and never as a past. Nothing added to make the gap feel smaller |

## Persona table

Weights rest on the relationship prior for a hiring-manager conversation, adjusted for the loop your invite describes (one text chat with the support team lead). There is no interviewer profile and no published loop report, so nothing else moves them. If the lead turns out to be a peer, say so and the banks reweight.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | Live support scenarios: an angry repeat customer, a product you do not know yet | High: hiring-manager prior, and the ad's escalation line is easiest to test as a scenario. 4 questions | Clarify first, then structure, then answer; think aloud in short messages |
| B. Skeptic | Probes the gaps: energy not software, Freshdesk not Zendesk, escalations | High: hiring-manager prior, and F6 and F2 are the visible gaps. 5 questions, including the highest-ROI one | Rehearse the software question until it is boring; bridge only from your own quoted words |
| C. Conversational / Rapport | Friendly openers: your journey, what you know of the company | Medium: a chat format suits it, and it is scored anyway. 3 questions | A short arc built from your own sentences; treat casual questions as scored |
| D. Data-Driven Prober | Reads your numbers: around 60 a day, four new starters | Medium: both figures are in your message. 3 questions | Know what you can and cannot say about how each figure was counted; say plainly when you do not know |
| E. Values / Behavioral | Past-behavior stories | Low: no source I read names a values round. 2 questions, all generic | Pick a real instance; if none fits, say so plainly |
| F. Pressure | Time-boxed or devil's-advocate challenges | Low: no signal either way; the prior puts it below A and B. 2 questions | Pause, restate, hold a position through two follow-ups, concede specifically |
| G. Peer Evaluator | Seam-splitting between teams | Low: the interviewer is described as your lead, not a peer. No bank | Reciprocity framing if it appears |

## Question banks

Highest-ROI prep: B1. The software question will arrive in some form, and it is aimed at the one gap you stated yourself.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in for the third time about the same unresolved problem, and they are angry. Walk me through your first reply and what you do next." | CASE | [generic] | Structure it aloud: what you would check first, how you acknowledge it, what you can settle yourself, what you would pass on and to whom, and what you would tell the customer about timing. The question needs no claim about your past, so the guidance makes none | A live problem from the ad's escalation line (F4's requirement), asked as a decision; generic because it is a pattern for the problem, not a fact about Lumenvale |
| A2 | "A customer says a feature is not working, and you do not yet know our product well. How do you handle the first ten minutes?" | CASE | [generic] | Say what you do not know out loud, ask what they see and what they were trying to do, use whatever internal resources the team has, and promise only what you can keep. Nothing here describes your past | Tests the software gap (F6) as a live problem instead of a CV line; CASE because it is a scenario, JD content |
| A3 | "Tell me about an escalation you handled." | JD | [grounded] | Selection scaffold: pick one case with a named situation, what you did, and what changed afterward. Answer slot: if you handled one yourself, say it in your own words and which part was yours; if escalations went to someone else or never reached you, say so plainly and say how you would handle one. If no case comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4 is the row with no evidence at all and the ad names it, so this is the likeliest unscripted miss; JD because it scores a stated requirement |
| A4 | "The ad mentions Zendesk or a similar ticketing tool. What have you used, and how do you pick up a new one?" | JD | [grounded] "I use Freshdesk every day" | Say it as written: "I use Freshdesk every day." Say plainly that it is Freshdesk, not Zendesk. Answer slot: if you have learned a new tool at work before, say which and how, in your own words; if Freshdesk is the only one, say so and say what you would do first in a new tool | F2 is the evidence for the tool requirement and the wording gap is visible; JD because it scores the ad's own line |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have been at an energy supplier, not a software company. Why do you think you can do support for a software product?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier", "I've never worked for a software company" | The highest-ROI rehearsal in this pack. Hold what the quotes carry: "I haven't worked for a software company. I have 3 years as a customer service advisor at an energy supplier." Then a plan in your own words for learning the product in your first weeks, said as a plan and never as a past. Hold through two follow-ups by returning to those two sentences; concede plainly that the product knowledge is still to be learned. Never answer by claiming software support you have not done | F6 is the gap you stated, so this objection arrives in some form; JD because it scores fit against the job |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company", "I use Freshdesk every day" | Pick the one that is true for you. One answer your own words already support: "I haven't worked for a software company." Pair it with how you would close it. Do not offer a weakness you do not have or a strength you cannot back | The standard Skeptic stem; F6 and F2 are where the honest answer sits |
| B3 | "You say you use Freshdesk every day. What does that actually cover?" | EXP | [grounded] "I use Freshdesk every day" | Answer slot: say what you actually do in Freshdesk, in your own words; if there are parts of it you do not use or that someone else handles, say so plainly and stay with what you do | F2's quote has nothing inspected behind it; EXP because it tests what was actually yours |
| B4 | "The ad asks for clear written communication. How do you make sure a reply is clear before you send it?" | JD | [grounded] "answering around 60 calls and emails a day" | Say what you actually do, in your own words. Answer slot: if you have a habit you follow, name it; if you do not have one you can name, say so plainly and say what you would check first. Keep the figure attached to calls and emails | F3 is a thin row on a requirement this round tests by being a written chat; JD because it scores the ad's line |
| B5 | "Why are you moving from energy into software?" | EXP | [generic] | Give your own actual reason in one or two sentences, in your own words, and say what draws you to this role. The pack supplies no reason | Motivation consistency is the Skeptic's second probe after fit; the reason is yours alone, so the pack writes none |

### C. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your journey into customer support." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" | The beats the sentence states: the role, the three years, the energy supplier. Answer slot: why you took the role and what you want next are yours to say in your own words; if there was no plan behind it, say so plainly | F1 is the whole of your stated history; a rapport opener is the likeliest first question |
| C2 | "What do you know about Lumenvale and what we do?" | CO | [generic] | Say only what you have read yourself: the product, who it is for, anything on their site. The pack could not research the company, so it supplies none. If you have read little, say so plainly and ask what the lead would most want you to know | Homework check asked casually; generic because the searches were refused |
| C3 | "What is something you have picked up recently that has made handling tickets easier for you?" | EXP | [grounded] "I use Freshdesk every day" | Selection scaffold: pick a small thing you actually changed in how you work, say what it was and what it did for you. If no such thing comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Casual question on the ad's tool line (F2); the theme comes from that line |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You said around 60 calls and emails a day. How was that counted?" | EXP | [grounded] "answering around 60 calls and emails a day" | Say it as written: around 60 calls and emails a day, not tickets. Answer slot: the four probes are how the figure was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Answer each in your own words; where you do not know how it was counted, say so plainly | F3's figure is the number most likely to be probed; EXP because it tests whether the number survives |
| D2 | "Tell me about training the four new starters." | EXP | [grounded] "I trained four new starters on our refunds process last year" | The beats the sentence states: four new starters, the refunds process, last year. Answer slot: if you set what was taught or how, say so; if it was a process someone else designed and you delivered it, say so plainly | F5 is a quoted figure and a responsibility; the probe is on what part was yours |
| D3 | "How much of that training was actually you, and how much was the team?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Hold the sentence: "I trained four new starters on our refunds process last year." Hold it through two follow-ups, then concede specifically what was shared, in your own words. Never fold on the core line to keep the peace | Attribution probe on F5; also practices the hold-then-concede structure |

### E. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "When did you put a customer's need ahead of a quick close?" | VAL | [generic] | Selection scaffold: pick a real instance with a named stake, what you did instead, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem; no published Lumenvale values were read, so it is generic |
| E2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: choose a case where the hard point actually landed, with who, what you said, and the result. If none comes to mind, say so plainly and say how you would handle it | Persona stem; included so the style is not new to you |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over someone who has already worked in software support?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier", "I trained four new starters on our refunds process last year", "I've never worked for a software company" | Hold what the quotes carry and nothing wider, then concede the gap specifically: "I haven't worked for a software company." Hold through two follow-ups; do not claim what the other candidate has | F1, F5 and F6 together are the case you can make and its limit; JD because it scores comparative fit |
| F2 | "Convince me you can stay calm with an upset customer. Go, right now, in this chat." | JD | [generic] | Pause, restate the question, then answer in short messages: what you do first, what you say, what you do next. Make no claim about your past | Tests the ad's escalation line (F4's requirement) under time pressure |

## Requirement coverage

| Requirement | Questions |
|---|---|
| "2+ years in customer support" | B1, C1, F1 |
| "experience with Zendesk or a similar ticketing tool" | A4, B3, C3 |
| "clear written communication" | B4, A1 |
| "confidence handling escalations" | A1, A3, F2 |
| sharing process knowledge with new colleagues (F5) | D2, D3 |
| familiarity with a software company's product (F6) | B1, B2, A2, B5 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good first month look like for someone in this role?" | Shows you are thinking about doing the job, and tells you what to learn first (F6) |
| R2 | "Which tools does the team use for tickets, and how long do new starters usually take to get comfortable in them?" | Puts the Zendesk and Freshdesk wording gap on the table calmly (F2) and shows you plan to learn |
| R3 | "How does the team decide what gets escalated, and what do people on the first line resolve themselves?" | Shows you take the escalation line seriously and gives you the real standard (F4) |
| R4 | "What kinds of customers does the team support, and what do they most often write in about?" | Starts closing the software gap with real detail (F6) and shows curiosity beyond the ad |
| R5 | "How does the team measure good support?" | Lets you hear what clear written communication means here (F3) |
| R6 | "Is there a call or video step after this chat, and who would it be with?" | Tells you whether to prepare spoken answers as well as written ones, so you can plan your prep time |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Used Zendesk | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day." The limit is the pack's observation: your message says Freshdesk, not Zendesk |
| Handled 60 tickets a day in a ticketing tool | Inflated form of F2 and F3: the figure belongs to calls and emails | F3's quote at its own scope: "answering around 60 calls and emails a day" |
| Led or ran training for the team | Inflated form of F5 | F5's quote at its own scope: "I trained four new starters on our refunds process last year" |
| Has worked in software or SaaS support | Negative you stated, F6 | The plain acknowledgment F6 gives: "I haven't worked for a software company." No slot |

## Sources

Provided documents: the invite text and your description of the ad and your background, all in your message. The loop (one text chat with the support team lead) rests on the invite's own words.

Searches sent: "Lumenvale Software company values" — refused. "Lumenvale Software strategy recent news" — refused. No fetches.

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Both calls refused. Would have moved: named values for the VAL bank (E1, E2 stay generic) |
| 2. `{company} interview process {role family}` | skipped | The invite fixes the loop as one text chat with the support team lead; persona weights follow it |
| 3. `{company} strategy` / recent news | unavailable | Refused. Would have moved: a grounded CO question in place of C2 |
| 4. `{interviewer name} {company}` | n/a | The interviewer is described only as the support team lead, so there is no name to query; the interviewer read is absent |
| 5. representative `{role title}` JD | skipped | Your description of the ad's four requirements fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full ad text → F1 to F4 requirements become quoted from the ad itself, and any mid-list requirement gets a question
- Anything the recruiter said about this chat's focus or length → coverage tuned to it instead of round-type priors
- The support team lead's name → an interviewer read, retuned persona weights and a reverse question tied to their path
- The company's published values or a strategy page, pasted → E1 and E2 and C2 move from `[generic]` to `[grounded]`
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes), which needs search access this session did not grant → a grounded strategy brief and CO and CASE questions
- An escalation you handled, a habit that keeps your written replies clear, and what you do in Freshdesk, in your own words → F4, F3 and F2 move off `none` and `low` confidence, and A3, B4 and B3 become story-mapped
- A `tuesday-dossier.md` from an earlier session → verified evidence and prohibited claims carried in, never required
