I'll read the reference files the skill points to before building the pack.
The pack is saved. I'm now writing up the message that presents it.

Your prep pack is saved at `/var/tmp/tuesday-measure/1a6/runs/sonnet/alone/part-5/rooms/case-13-denied-47eff6f5/Quillmoor_operations-coordinator_interview_pack.md`. I built it for the 30-minute recruiter call with Hannah, using her four topics, the advert and what you told me. It has 18 questions, a fit snapshot, a persona table, six reverse questions and a list of claims it won't coach.

- **Highest-ROI prep:** B2, "what have you coordinated that's like production scheduling between planning, the warehouse and QA?" Your material says deliveries for three depots, not production schedules. The pack has you say exactly that, then answer an honest slot about whether any of it involved other teams.
- **Hannah's four topics (A1–A4):** pay, hybrid and your reason for leaving use your own sentences as you gave them, with nothing added. Notice period has no figure, because you didn't give one. A2 tells you to give your actual notice period.
- **No SAP:** the pack has you say "I've never used SAP" and then give a plan for learning it. The advert calls ERP a plus, not a requirement.
- **Questions only you can answer:** is the stock-count spreadsheet Excel, and do you produce any regular delivery or dispatch report? The pack leaves these as slots rather than guessing.
- **Company research didn't run.** Web search wasn't permitted, so I used nothing outside the advert and your message. "What do you know about us?" (B4) stays at the advert's level, and there's no interviewer read for Hannah.

Say the word and I'll play the Skeptic on B2, the highest-ROI question, with live follow-ups.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quillmoor_operations-coordinator_interview_pack.md -----
# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** recruiter screen, a 30-minute phone call with Hannah Lowther, Talent Partner. Thursday, 2pm. She will ring the mobile number on your application.
**Her stated agenda (her LinkedIn message):** your salary expectations, your notice period, how the hybrid pattern would work for you, and what is prompting a move. Then she tells you about the team and the next steps.
**Built on:** the advert, Hannah's message and your own account. There is no interviewer profile, and company research could not run (see Sources).

## How to use this pack

- **Personas describe how a question is asked. Types describe what is being scored.** Every question carries one of each.
- **Guidance is scaffolding, not a script.** Say the quoted words in your own voice. Where a cell says "answer slot", the honest answer comes from you, in the interview. Either branch of a slot is a good answer.
- **Highest-ROI prep: B2**, the production-scheduling question, and then the four logistics rows A1 to A4. Everything else is insurance.

| Type | What it is scoring |
|---|---|
| VAL | Whether past behaviour shows the company's published values. None is used here, because no values-style round is documented for this call |
| EXP | Whether your own account holds up: what was actually you |
| JD | The advert's stated duties, requirements and terms, including where you are thin |
| CO | What you know about the company and how you think at its level |
| CASE | A live problem set in the role, answered by structuring it aloud |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — the advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material says deliveries for your three depots, not production schedules, and the words stay there: "I schedule deliveries for our three depots." Answer slot: the advert's planning, warehouse and QA line makes a probe on who your scheduling involved likely. If any of it meant agreeing timing with other teams, say which teams and how, in your own words; if it did not, or none of it was yours, say so plainly and stay with the deliveries |
| F2 | "track supplier deliveries" — the advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | low | [inferred] | discovery | Your sentence says chase, not track, and the bridge does not stretch it. Answer slot: if you keep any record of when supplier orders arrive, say what it is; if you do not, say so plainly and stay with the chasing |
| F3 | "chase late orders" — the advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | No gap in terms, but a line with nothing inspected behind it, so expect a probe. Lead with it in your own terms: you chase suppliers when orders slip, because a stated duty beats an adjective |
| F4 | "keep stock records accurate" — the advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | The sentence reaches the requirement in role terms, and the figure is the likeliest thing to be probed. Keep its verb and its scope: you rebuilt the spreadsheet, and discrepancies fell by about a third over a year. Expect the four figure slots: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. "I don't know how it was counted" is an honest answer |
| F5 | "report weekly on on-time dispatch" — the advert | none given | none | [grounded] | discovery | Nothing in your material touches reporting. Answer slot: if you produce any regular report on deliveries or dispatch, say what it covers and how often; if you do not, say so plainly and stay with scheduling deliveries and chasing suppliers |
| F6 | "2+ years in operations or logistics coordination" — the advert | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | none | Your quote reaches the requirement in its own terms. Say it as written. It is a stated length of time, not a legal or credential bar, so it is not a gate |
| F7 | "confident with Excel" — the advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | Your sentence says spreadsheet, not Excel, so the bridge does not say Excel. Answer slot: name the program your stock-count spreadsheet is in; if it is Excel, say so, and if it is something else, say which and say plainly that it is not Excel |
| F8 | "ERP experience (SAP or similar) a plus" — the advert | "Never used SAP — we run our own in-house stock system." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used SAP." Then how you would learn it, said as a plan and never as a past. The advert calls ERP a plus, not a requirement |
| F9 | "ERP experience (SAP or similar) a plus" — the advert | "Never used SAP — we run our own in-house stock system." — your message | low | [inferred] | transferability | Your sentence says the company runs an in-house stock system, not that you operate it, and the words stay at that scope. Answer slot: if you work in that system day to day, say what you do in it; if you only use its outputs, or someone else operates it, say so plainly |
| F10 | "£38,000–£44,000" — the advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | Your own figure, in your own words. The pack adds nothing to it |
| F11 | "Hybrid: two days a week at our Avonmouth site in Bristol" — the advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | Your own sentence, at its own scope. The pack adds nothing to it |
| F12 | "what's prompting a move" — Hannah's LinkedIn message | "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | medium | [grounded] | none | Your reason, whole. The pack adds nothing to it, and no follow-up in this pack asks you for more on it |

## Persona table

| Persona | How it shows up on this call | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder (bank A) | Hannah's four stated topics asked in a friendly register, plus "walk me through your background" | Highest. The recruiter-screen prior is Conversational plus a light Skeptic, and her message names the four topics, so bank A rehearses them one for one | A pre-scripted 90-second arc for the background question (A5). For each logistics topic, your own sentence from Provenance, and then stop |
| Skeptic (bank B) | Quiet probing of the manufacturing gap, the ERP gap and "why us" | Second. The prior is "light", but the fit snapshot's biggest gap, F1, is where it bites, so bank B is deliberately five to six deep and carries the pack's highest-ROI question | Rehearse B2 until it is boring: say what your sentence carries, name the limit before it is asked for, and answer the slots honestly |
| Data-Driven Prober (bank C) | A line-by-line read of your own account, with the one-third figure as the target | Medium. It is a short call, but a figure on your own account is where a screener tests whether it is yours | Know what you can say about how the figure was counted, and say plainly where you do not know |
| Case / Strategist (bank D) | A quick live problem from the role | Low to medium. A recruiter may ask one short "what would you do" question, and the advert's duties give two natural ones | Clarify, structure, then answer, aloud. These are generic and make no claim about your past |
| Pressure (bank E) | A 60-second "why you" or "how much was you" | Low. Nothing in Hannah's message suggests stress tactics | Pause, restate, hold the quoted sentence through two follow-ups, concede specifically |

## Question banks

### Bank A: Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | Say it as you told me: "I'm hoping for £42,000." Then stop and let her respond. If she follows up on the figure, your own words were the same sentence, and nothing is added to it. If she asks what you earn now, you can decline without a figure: "I'd rather focus on the range for this role." | Hannah's first named topic, and F10 holds your figure. JD because the advert states a band |
| A2 | "What's your notice period?" | JD | [generic] | Answer slot: give your actual notice period, as your contract states it. If you are not sure, say so plainly and say you will check your contract and confirm. The pack supplies no figure | Hannah's second named topic. Your material says nothing about it, so there is no fit row and the slot is yours to fill. JD because it is a term of taking the job |
| A3 | "How would two days a week at Avonmouth work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Your own words: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." Say that sentence at that scope. If she asks about the commute or the pattern again, your own words were that same sentence, and nothing is added to it | Hannah's third named topic. F11 holds your words. JD because the advert states the hybrid pattern |
| A4 | "What's prompting a move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Say it whole, in your own words, at a steady pace: "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." If she follows up, your own words were that same sentence, and nothing is added to it | Hannah's fourth named topic. F12 holds your reason. EXP because it is about your own circumstances |
| A5 | "So, walk me through your background and what you do now." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | A 90-second arc with three beats, each a clause the quotes state: four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots and chasing suppliers when orders slip; rebuilding the stock-count spreadsheet, with discrepancies falling by about a third over a year. Keep the third beat's verb as your sentence has it: "fell". End the arc there. You do not have to volunteer A4 | F6, F3 and F4 are the evidence this arc draws on. It is the opening question of a friendly call and is still scored, so it is EXP |

### Bank B: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "What draws you to diagnostics manufacturing, coming from building supplies?" | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." | Answer slot: your reason for this sector is not in my material, so the pack supplies none. Say your own reason in your own words; if the sector itself is not what draws you, say so plainly and stay with your own sentence: "I schedule deliveries for our three depots and chase suppliers when orders slip." | F6 is the quoted background the question starts from. EXP because it asks about your own motive, and the premise, building supplies, is yours |
| B2 | "The role coordinates production schedules between planning, the warehouse and QA. What have you coordinated that's like that?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | **The highest-ROI rehearsal in this pack.** Hold only what the sentence carries: "I schedule deliveries for our three depots and chase suppliers when orders slip." The limit, named before it is asked for, is the pack's own observation: your material says deliveries, not production schedules. Answer slot: if any of your scheduling meant agreeing timing with other teams, say which teams and how, in your own words; if it did not, or none of it was yours, say so plainly and stay with the deliveries. Follow-up 1, "who did you work with?": the same slot again, naming teams only if they were involved. Follow-up 2, "what happened when two teams wanted different things?": if such a situation arose, say what it was and what you did; if none did, say so plainly and return to the quote. Follow-up 3, "how would you learn our production schedule?": say what you would ask first and who you would ask, as a plan in the future tense | F1 is the advert's headline duty and the largest gap in the snapshot, so this question arrives in some form. JD because it scores a stated requirement, and the Skeptic delivery is how a recruiter derisks it |
| B3 | "Which part of this advert would be your weakest on day one?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Choose from your own material. If you pick ERP, your own sentence is the answer, at its scope: "Never used SAP — we run our own in-house stock system." Then a plan, said as a plan: how you would learn it. If you pick the production-scheduling side instead, that is B2's slot. Do not say the in-house system is the same as SAP | F8 and F9 are the stated ERP gap and its adjacent evidence. The advert calls ERP a plus, so it is the gap you are asked to name, not the one that sinks you. JD because it tests honest self-assessment against the advert |
| B4 | "What do you know about Quillmoor?" | CO | [grounded] the advert's own words: "diagnostic-test manufacturer, about 400 staff" | Answer slot: say what you have looked at, in your own words. If you have read more than the advert, say where; if you have not, say so plainly and say what the advert told you: it describes a diagnostic-test manufacturer of about 400 staff. Company research could not run for this pack, so it adds nothing beyond the advert | A friendly "why us" is the usual place a recruiter scores homework. CO because it tests company knowledge, and it stays at the advert's level because nothing else was verified |
| B5 | "How confident are you with Excel?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: name the program your stock-count spreadsheet is in. If it is Excel, say so and say what you rebuilt, in your own words; if it is another program, say which, and say plainly that it is not Excel. Do not name functions or features you did not use | F7 is the evidence for the Excel requirement and says spreadsheet, not Excel. JD because it scores a stated requirement |
| B6 | "The role reports weekly on on-time dispatch. What reporting do you do today?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Answer slot: if you produce any regular report on deliveries or dispatch, say what it covers and how often; if you do not, say so plainly and stay with your own sentence: "I schedule deliveries for our three depots and chase suppliers when orders slip." | F5 has no evidence in the material, so the slot is the honest form. JD because it scores a stated duty |

### Bank C: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said discrepancies fell by about a third over a year. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Four slots, each in your own words: how the discrepancies were counted; what the figure is sensitive to; the assumption behind it you would defend least; which part was yours. If you do not know how it was counted, say so plainly. A method you cannot repeat under the second question is worse than none. Say "about a third" and "fell", as your sentence has them | F4's figure is the magnet target for this persona. EXP because it tests what was actually yours |
| C2 | "Walk me through what you rebuilt in the stock-count spreadsheet." | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Say it at its scope: you rebuilt the stock-count spreadsheet. Answer slot: say what changed in it, in your own words; if anyone else did part of the rebuild, say so plainly; if you cannot say what changed, say that | F4 and F7 both rest on this sentence. EXP because it asks what the work actually was |
| C3 | "Take me through what you do when an order slips." | EXP | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | The beats the sentence states: an order slips, and you chase suppliers. Answer slot: say what else you do, in your own words; if you also re-plan a delivery, say how; if you hand it on, or nothing more happens, say so plainly and stay with chasing suppliers. If asked how you track what is due, answer F2's slot: say what record you keep, if any, and if none, say so plainly | F3 is the evidence for chasing late orders, and F2 is where tracking is thin. EXP because it asks what you actually do |

### Bank D: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A supplier tells you a part for next week's build will arrive three days late, and the warehouse has already planned around the original date. What do you do first?" | CASE | [generic] | Clarify first: what exactly is late, what depends on it, and how firm the new date is. Then say who needs to know. The advert names planning, the warehouse and QA as the teams this role works between. Then your options, and what you would record. Think aloud. The question needs no claim about your past, so the guidance makes none | A live problem from the advert's coordination and chase-late-orders duties. `[generic]` because it is a pattern for the problem, not a fact about this employer |
| D2 | "On-time dispatch fell this week. How do you find out why?" | CASE | [generic] | Clarify first: how on-time is defined and measured here, and what changed. Then break the figure into groups, find the biggest contributor, check causes with the people who run it, and say what you would report. Think aloud. The question needs no claim about your past, so the guidance makes none | A live problem from the advert's weekly on-time dispatch line. `[generic]` because it is a pattern for the problem |

### Bank E: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: we could hire someone who already knows SAP. Why you?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "Never used SAP — we run our own in-house stock system." | Pause and restate the question. Hold what the quotes carry: the four years as a logistics coordinator, the three depots, the chasing. When pushed, concede specifically: "I've never used SAP." Hold through two follow-ups by returning to your own sentences, never by adding to them. Do not claim you learn quickly, since nothing in your material says so. Say how you would learn it, as a plan | F6 and F8 are the strength and the limit in one question. JD because it scores the ERP requirement, and Pressure is how it is delivered |
| E2 | "That one-third. How much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Hold your sentence: you rebuilt the spreadsheet, and discrepancies fell by about a third over a year. Answer slot: say which part of the fall you would credit to the rebuild and which to anything else, in your own words; if you cannot separate them, say so plainly. Hold through two follow-ups; concede only what you cannot separate | F4's figure under attribution pressure. EXP because it tests what was actually yours |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| "Coordinate production schedules between planning, the warehouse and QA" | B2, D1 |
| "track supplier deliveries" | C3 |
| "chase late orders" | C3, D1 |
| "keep stock records accurate" | C1, C2, E2 |
| "report weekly on on-time dispatch" | B6, D2 |
| "2+ years in operations or logistics coordination" | A5, E1 |
| "confident with Excel" | B5, C2 |
| "ERP experience (SAP or similar) a plus" | B3, E1 |
| "£38,000–£44,000" | A1 |
| "Hybrid: two days a week at our Avonmouth site in Bristol" | A3 |
| "what's prompting a move" | A4 |
| "your notice period" (Hannah's message) | A2 |
| Why this sector and this company | B1, B4 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What happens after this call, and who would I meet next?" | Hannah has said she will cover next steps, so this confirms who is in the loop and gives you something specific to prepare for |
| R2 | "Which people in planning, the warehouse and QA would I work with most, and where do they sit?" | It shows you took the advert's coordination line seriously, and it lets you hear how the role is shaped before B2 is asked of you again |
| R3 | "How is on-time dispatch measured today, and what is the weekly report used for?" | It tells you what the F5 duty looks like in practice and lets you answer it from facts |
| R4 | "Which systems does the team use for stock and supplier tracking?" | The advert asks for ERP experience as a plus, so the answer tells you what you would be learning |
| R5 | "What would the two days at Avonmouth usually be spent on, and which days does the team come in?" | It follows the hybrid pattern Hannah named and shows how you would plan your week |
| R6 | "What would a good first three months look like for this role?" | It turns the call into a conversation about the job, and the answer tells you what the team is scoring |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated production schedules between planning, the warehouse and QA | Inflated form of F1 | F1's quote at its own scope: "I schedule deliveries for our three depots." The limit is the pack's observation: your material says deliveries, not production schedules. B2's slot stays inside the deliveries |
| Tracked supplier deliveries | Inflated form of F2 | F3's quote at its own scope: you chase suppliers when orders slip. B-bank and C-bank slots ask only what record you keep, if any |
| Cut stock discrepancies by a third through the rebuild | Inflated form of F4 | F4's quote as written: you rebuilt the spreadsheet, and discrepancies fell by about a third over a year. C1 and E2 ask only how it was counted and which part was yours |
| Confident Excel user | Inflated form of F7 | F7's quote at its own scope: a stock-count spreadsheet you rebuilt. B5's slot asks only which program it is in |
| Has ERP experience | Negative you stated, F8 | The plain acknowledgment F8 gives: "I've never used SAP." Then a plan, said as a plan. No slot |
| Operates the in-house stock system | Inflated form of F9 | F9's quote at its own scope: the company runs its own in-house stock system. The slot asks only what, if anything, you do in it |
| Any pay figure, range or flexibility, or any office-day number, other than your own quoted words | Your constraints, F10 and F11 | Your quotes as written. The pack adds nothing to them |

## Sources

Provided documents: the advert for Operations Coordinator at Quillmoor Diagnostics; Hannah Lowther's LinkedIn message; your own account of your background, pay, location and reason for leaving. No `tuesday-dossier.md` was present.

Searches sent, all refused: "Quillmoor Diagnostics values" (refused); "Quillmoor Diagnostics interview process operations coordinator" (refused); "Quillmoor Diagnostics Avonmouth news" (refused); "Hannah Lowther Quillmoor Diagnostics" (refused).

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor Diagnostics values | unavailable | Every call was refused. It would have named published values for B4 and VAL themes. Nothing moved |
| 2. Quillmoor Diagnostics interview process, operations coordinator | unavailable | Every call was refused. It would have checked loop structure. Hannah's own message establishes this one session, so the persona priors stand and no archetype fallback was needed |
| 3. Quillmoor Diagnostics strategy and recent news | unavailable | Every call was refused. It would have grounded B4 and a reverse question in current news. B4 stays at the advert's level |
| 4. Hannah Lowther Quillmoor Diagnostics | unavailable | Every call was refused. It would have supported an interviewer read and a reverse question tied to her path. Both are absent |
| 5. Representative Operations Coordinator advert | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your notice period, said outside a drill → A2's slot becomes your own words, quoted whole, and a fit row appears
- Your prep time before the call → a prioritized triage of this pack, sized to the time you have
- Your answers to the slots in F1, F2, F5, F7 and F9, said outside a drill → each becomes quoted evidence, and those rows and the banks resting on them regenerate
- Your CV text → more of your own sentences to map to questions, so fewer questions fall back to selection scaffolds
- An inspectable artifact for F4, if one exists, such as the stock-count spreadsheet's discrepancy log showing the fall → F4 moves from medium toward high, and C1's slots can be answered from it
- Hannah's LinkedIn profile text, pasted → an interviewer read and a reverse question tied to her own path
- Web search access → the four unavailable rows above become yes: published values, loop structure, current strategy and a grounded B4. A deeper pass would add up to 6 more searches and 2 more fetches, and several more minutes
- A `tuesday-dossier.md` from job-underwriter → verified evidence and prohibited claims, with the highest-ROI objection derived rather than inferred, never a prerequisite
