I'll read the reference files the skill points to before building the pack.
The pack is built and saved. Here it is.

Your prep pack is saved as `/var/tmp/tuesday-measure/1a6/runs/sonnet/alone/part-5/rooms/case-13-denied-17250f38/quillmoor-diagnostics_operations-coordinator_interview_pack.md`. I built it for the recruiter screen with Hannah, using the four topics she listed. Web search wasn't permitted, so nothing in it comes from outside what you pasted. The company question (B3) is generic, and there's no read on Hannah herself.

Say the word and I'll play Hannah on B1, the SAP question. The pack names it as your most predictable objection, since you've told me you've never used SAP.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

What is your notice period? It's the one thing Hannah plans to ask that your material doesn't settle, and your answer would fill A2 in your own words.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor-diagnostics_operations-coordinator_interview_pack.md -----
# Interview pack: Operations Coordinator, Quillmoor Diagnostics

- **Role:** Operations Coordinator, Quillmoor Diagnostics (diagnostic-test manufacturer, about 400 staff)
- **Interviewer:** Hannah Lowther, Talent Partner. Recruiter screen, Thursday at 2pm, a 30-minute phone call to the mobile number on your application
- **Built on:** Hannah's own message, which names four topics (salary expectations, notice period, how the hybrid pattern would work for you, what's prompting a move) and then says she will describe the team and next steps
- **Candidate:** Sam

## How to use this pack

Personas describe how a question is asked; types describe what it scores. Guidance is scaffolding for your own words, not a script: every sentence about your past is one you wrote, quoted beside the question it supports, and an "answer slot" is an instruction for the interview, not a question for you now.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your experience claims survive follow-up |
| JD | The advert's stated responsibilities and requirements |
| CO | What you know about the company and why you want it |
| CASE | A live problem from the role, thought through aloud |

No question here is tagged VAL: your message describes one recruiter call, and nothing in it names a values round.

## Fit snapshot

Requirements are quoted from the advert or from Hannah's message; evidence is your own sentences from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" — the advert | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | none | The quote reaches the requirement in role-relevant terms, and four years is the number it carries. It is confirmed, with nothing inspected behind it, so say it as stated: the role, the employer type and the years |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" — the advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material says delivery scheduling for three depots, not production scheduling, and the words stay there: "I schedule deliveries for our three depots." Answer slot: the advert's planning, warehouse and QA line makes a probe on who you coordinate with likely. If scheduling deliveries means working with other teams, say which and what part was yours; if it does not, or the schedule was set for you, say so plainly and stay with the deliveries |
| F3 | "track supplier deliveries and chase late orders" — the advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | The quote reaches "chase late orders" in near the advert's own terms. It says schedule and chase, not track, so use those verbs. Confirmed with nothing inspected behind it, so expect a request for an example (C4) |
| F4 | "keep stock records accurate" — the advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | The quote reaches the requirement in role-relevant terms. It is a headline figure, so expect a defend-the-number probe (C1, D2). The sentence has two clauses, the rebuild and the fall, and does not say one caused the other, so the words stay as you wrote them |
| F5 | "report weekly on on-time dispatch" — the advert | none given | none | [grounded] | discovery | Your material does not show this either way. Answer slot: if you have reported on delivery timing, say what, to whom and how often, in your own words; if you have not, or it was not yours, say so plainly, and say what you would track first |
| F6 | "confident with Excel" — the advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | The sentence says spreadsheet, not Excel, and not what the rebuild consisted of. Answer slot: if the spreadsheet was in Excel, say what you did in it, in your own words; if it was another tool, or the rebuilding was not yours to do, say so plainly |
| F7 | "ERP experience (SAP or similar) a plus" — the advert | "Never used SAP — we run our own in-house stock system." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used SAP." Your material does not show whether the in-house stock system does what an ERP does, so no claim is made there. Answer slot: if you work in the in-house stock system, say what you use it for, in your own words; if your use is narrow, say so plainly. Then how you would learn SAP, said as a plan and never as a past |
| F8 | "£38,000–£44,000" — the advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | Your figure is inside the advertised band, so there is nothing to bridge. Say it as you stated it |
| F9 | "Hybrid: two days a week at our Avonmouth site in Bristol." — the advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | Your stated pattern meets the advert's two days. Say it in your own words; if asked more, return to the same sentence rather than adding to it |
| F10 | "your notice period" — Hannah's message | none given | none | [grounded] | hard_gate | Your material does not establish your notice period. Nothing in this pack supplies one |

## Persona table

The weights rest on one relationship prior (a recruiter screen: conversational with a light skeptic) and on your account of the call. No interviewer research ran, so there are no interviewer-signal adjustments.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Conversational / recruiter | Friendly, structured around Hannah's four named topics, then biography | High: her message lists the topics in order and describes a 30-minute call | Say each logistics answer in your own words, from the quoted sentences in A1 to A5. Casual questions are still scored |
| B. Skeptic | Quiet probing of the advert's named gaps and "why us" | Medium: the advert names SAP, and your own message says you have not used it; a screen is where knockout checks happen | Rehearse B1 until it is boring. Say the limit plainly, then the plan |
| C. Data-driven prober | Asks how the stock-count figure was counted, and for an example | Medium-low: a recruiter may note the figure for the next round more than dig into it | Know how it was counted, or say plainly you do not know |
| D. Pressure | A time-boxed pitch, or "how much was you" | Low: unusual in a recruiter screen, but a 60-second pitch is a common time box | Pause, restate the question, hold on the quoted sentences, concede only what is true |
| E. Case / strategist | A quick live problem from the role | Low: more likely at a later round with a hiring manager; included because the advert describes tasks that make easy cases | Clarify, structure, think aloud. These are `[generic]` patterns |

## Question banks

### A. Conversational / recruiter

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | Logistics slot filled with your own words: "I'm hoping for £42,000." Say it once, plainly. If she comes back to it, give the same sentence again. If asked what you earn now, a decline only: "I'd rather focus on the range for this role." | F8 is a gate row the material shows met, and Hannah lists pay first. JD because the advert states a band |
| A2 | "What's your notice period?" | JD | [grounded] | Logistics slot: give your actual notice period, exactly as your contract states it. If you are unsure of the exact terms, say that plainly rather than estimating | F10 is the one gate row your material does not settle, and Hannah named it. JD because notice is a term of the listed job |
| A3 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Logistics slot filled with your own words: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." If she asks about the commute or about three days, give those same words again | F9 is shown met by your own statement; the advert's pattern is two days. JD because the advert states it |
| A4 | "What's prompting a move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Logistics slot filled with your own words: your office is closing next year, the only offer is relocating to Reading, and you do not want that. Keep it factual and short. If she asks more, return to those same words | Hannah named it as her fourth topic. EXP because it tests the story you tell about your own career |
| A5 | "So, walk me through the journey." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | A 90-second arc with only the beats the sentences state: four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots and chasing suppliers when orders slip; rebuilding the stock-count spreadsheet. Tell them in your own words and end where A4 begins | F1, F3 and F4 are the three strongest rows, and a biography question is the likeliest opener after logistics. EXP because it tests what you did |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The advert lists ERP experience, SAP or similar, as a plus. What systems have you worked in?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | The highest-ROI prep in this pack. Hold only what the quote carries: "I've never used SAP." Limit named before it is asked: your material does not show whether the in-house system does what an ERP does, so claim nothing there. Answer slot: if you work in the in-house stock system, say what you use it for, in your own words; if your use is narrow, say so plainly. Follow-up one, how fast could you learn SAP: say how you would learn it, as a plan, and name a time you picked up a system only if you did. Follow-up two, would it hold you back: the advert's own word is "a plus"; concede the gap in the same plain words and do not fold the rest of your answer | F7 is the one requirement where you have stated the absence and the advert names it, so this question is the most predictable objection. JD because it scores a stated requirement |
| B2 | "This role coordinates production schedules between planning, the warehouse and QA. How close is that to what you do now?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Start at your own scope: "I schedule deliveries for our three depots." Answer slot: if scheduling deliveries means working with other teams, say which and what part was yours; if it does not, or the schedule was set for you, say so plainly and stay with the deliveries | F2 is adjacent work, and the advert's coordination line is where the material is thinnest after F7. JD because it scores a stated responsibility |
| B3 | "What interested you in Quillmoor?" | CO | [generic] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Selection scaffold: pick reasons you can truthfully give that the advert itself supports, such as the kind of work it describes or the site; no company research was available, so the pack names none. Pick one thing in the advert that matches work you already do and say it in your own words. If no specific reason comes to mind, say so plainly, then give the nearest thing your material does carry, which is the quoted sentence above, or how you would approach the role | A "why us" question is likely in any screen. CO because it tests homework; `[generic]` because no research ran |
| B4 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Name only a weakness you can say plainly. The one you have stated is "I've never used SAP." Follow it with how you would learn it, as a plan. Do not volunteer a list | A stock Skeptic stem aimed at F7. JD because it scores fit to the listed job |

### C. Data-driven prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You mentioned discrepancies fell by about a third over a year. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slots, each in your own words: how the discrepancies were counted; what the figure is sensitive to; the assumption behind it you would defend least; which part was yours. If you do not know how something was counted, say so plainly | F4 carries the only figure you gave. EXP because it tests whether the number survives a second question |
| C2 | "What did rebuilding the stock-count spreadsheet involve?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Say it at its own scope: "I rebuilt our stock-count spreadsheet." Answer slot: the advert asks for confidence with Excel, so expect a probe on the tool. If it was in Excel, say what you did in it; if it was another tool, or the rebuilding was not yours to do, say so plainly | F6 is the advert's Excel line and the quote says spreadsheet. JD because it scores the stated requirement |
| C3 | "This role reports weekly on on-time dispatch. What reporting have you done on delivery performance?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Answer slot: if you have reported on delivery timing, say what, to whom and how often, in your own words; if you have not, or it was not yours, say so plainly and stay with the quoted sentence: you schedule deliveries for three depots. Add what you would track first | F5 is the one requirement with no evidence at all. JD because it scores the stated reporting duty |
| C4 | "Tell me about a time a supplier's order slipped and you chased it." | EXP | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Pick one occasion of your own. The sentence states two beats: you schedule deliveries for three depots, and you chase suppliers when orders slip. Whatever else happened on that occasion is yours to say if it happened. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F3 is the advert's chase-late-orders line, and recruiters ask for an example of it. EXP because it tests what you actually did |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you for this role?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Pause, restate the question, then three beats in your own words: the four years at the wholesaler, the scheduling and chasing, the stock-count rebuild. If interrupted, return to the quotes rather than adding to them. Hold through two follow-ups, and concede only what is true: "I've never used SAP." | A time-boxed pitch is the most common pressure format in a screen. JD because it scores fit to the listed job |
| D2 | "That stock-count result: how much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Hold what the sentence says: you rebuilt the spreadsheet, and discrepancies fell. Answer slot: if the rebuild drove the fall, say how you know; if other things changed too, or you do not know how much was down to the spreadsheet, say so plainly. Hold through two follow-ups and concede that specifically | F4 invites an attribution probe, and the sentence does not state a cause. EXP because it tests attribution |

### E. Case / strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A supplier tells you a delivery that production needs on Monday will be a week late. What do you do first?" | CASE | [generic] | Clarify first: what is late, who depends on it, how firm the new date is. Then options, who to tell across planning, the warehouse and QA, what you would record, and when you would check again. Think aloud. The question needs no claim about your past, so the guidance makes none | A live problem from the advert's supplier-chasing and scheduling lines (F2, F3). `[generic]` because it is a pattern, not a fact about this employer |
| E2 | "The system shows more units of a part than the shelf count does. How do you approach it?" | CASE | [generic] | Verify the count, trace recent movements, check anything received or dispatched but not yet recorded, correct the record, note the cause, and say how you would stop it recurring. No claim about your past | The advert's stock-records line (F4) as a live problem. `[generic]` for the same reason as E1 |
| E3 | "On-time dispatch fell this week. How would you find out why?" | CASE | [generic] | Clarify the definition of on time first, then split the drop by where it arose and what changed, and say what you would report. No claim about your past | The advert's weekly dispatch reporting (F5) as a live problem. `[generic]` |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| "2+ years in operations or logistics coordination" | A5, D1 |
| "Coordinate production schedules between planning, the warehouse and QA" | B2, E1 |
| "track supplier deliveries and chase late orders" | C4, E1 |
| "keep stock records accurate" | C1, D2, E2 |
| "report weekly on on-time dispatch" | C3, E3 |
| "confident with Excel" | C2 |
| "ERP experience (SAP or similar) a plus" | B1, B4 |
| "£38,000–£44,000" | A1 |
| "Hybrid: two days a week at our Avonmouth site in Bristol." | A3 |
| Notice period and reason for leaving (Hannah's message) | A2, A4 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Who would I work most closely with across planning, the warehouse and QA?" | It ties to the advert's coordination line and shows you have read it |
| R2 | "What would a good first three months look like in this role?" | It turns the call toward what success is, which a recruiter can usually describe |
| R3 | "Which systems does the team work in day to day, and what training comes with them?" | It puts the ERP point on the table from the other side, as a question about how you would get up to speed |
| R4 | "How is on-time dispatch measured today, and what does the weekly report look like?" | It ties to the reporting line, where your material is thinnest, and signals interest in doing it well |
| R5 | "Are the two site days fixed days of the week, or agreed with the team?" | It is practical, and it uses the pattern Hannah asked about |
| R6 | "What are the next steps and timings after this call, and who would I meet?" | It shows you are planning the process, and gives you something to hold her to |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has used SAP or another ERP | Negative you stated, F7 | F7's sentence at its own scope, and the plain acknowledgment it supports: "I've never used SAP." B1's slot covers the in-house system and nothing wider |
| Coordinated production schedules between planning, the warehouse and QA | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: the material says delivery scheduling for three depots, not production scheduling. B2's slot stays with who you coordinated with on the deliveries |
| Cut stock discrepancies by a third by rebuilding the spreadsheet | Inflated form of F4 | F4's sentence at its own scope. The pack observes that it states the rebuild and the fall as two clauses and does not say one caused the other. D2's slot asks only how you know |
| Rebuilt the stock-count in Excel and is confident with Excel | Inflated form of F6 | F6's sentence at its own scope. The pack observes that it says spreadsheet, not Excel. C2's slot asks only which tool |

## Sources

Provided documents: the advert you pasted; Hannah Lowther's LinkedIn message you pasted; your own description of your background and what you would tell her. No dossier was present.

Searches sent, both refused because web search was not permitted in this session:

- "Quillmoor Diagnostics Avonmouth Bristol news" — refused
- "Hannah Lowther Talent Partner Quillmoor Diagnostics" — refused

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor Diagnostics values | skipped | Feeds only a values cheat sheet, which a one-call recruiter screen as you described it does not call for |
| 2. Quillmoor Diagnostics interview process, operations coordinator | skipped | Your own account of the call (one phone call with Hannah) already fixes the loop and the persona weights |
| 3. Quillmoor Diagnostics strategy and recent news | unavailable | Would have grounded B3 in current company facts instead of leaving it `[generic]` |
| 4. Hannah Lowther, Quillmoor Diagnostics | unavailable | Would have allowed an interviewer read and a reverse question tied to her path |
| 5. representative operations coordinator JD | skipped | The advert you pasted already fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Permission to search the web → B3 and a company-grounded CO question become `[grounded]` instead of `[generic]`, and an interviewer read for Hannah becomes possible; a deeper pass would be up to 6 further searches and 2 further fetches and take several more minutes
- Your notice period → F10 is settled and A2 is filled with your own words
- Your answer on whether the stock-count spreadsheet was in Excel (F6), and whether you have ever reported on delivery timing (F5) → those rows can be upgraded from `discovery` and the slots in C2 and C3 replaced with your own words
- A before-and-after stock-count discrepancy record, if you have one → F4 can move from `medium` to `high`
- Your CV text → evidence cells can quote your CV as well as your message
- A `tuesday-dossier.md` from an earlier session → verified evidence and any prohibited claims it holds would replace the ones this pack built locally
