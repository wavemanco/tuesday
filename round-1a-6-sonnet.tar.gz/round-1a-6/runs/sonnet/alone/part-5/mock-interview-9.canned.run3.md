Reading the skill's reference files is done. I'm now running the default research pass on the district, the school, the principal's public profile and a representative fourth-grade posting.
Your prep pack is saved as `halvering-elementary_fourth-grade-teacher_interview_pack.md`. I built it for the Thursday panel with Principal Vantongeren and two fourth-grade teachers. No posting text was supplied, so the posting-based rows rest on a typical fourth-grade posting and are marked inferred.

- **Highest-ROI prep:** A1 and A2, then G1. They cover "you haven't taught fourth grade" and "you haven't been a team lead", and they use only what you told me.
- **The license:** your Illinois license looks like it meets the invite's requirement, so I treated it as met. I didn't check the registration, so that's yours to confirm before Thursday.
- **Your ID details:** I didn't need your social security number or license number and didn't use either. I'd keep both out of anything you send before an offer.

I can run a live drill as the principal on A1, the question the pack names as the highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Can you paste the posting's text? Doing so would turn the inferred rows into grounded ones.
2. Did HR or anyone at the school say what the panel will cover, such as a sample lesson, a writing task or a topic list? A named deliverable would add its own build section.
3. Do you want a deeper research pass, up to 6 more searches and 2 more fetches over several more minutes? It would add a district-strategy brief and more on the panel format.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: halvering-elementary_fourth-grade-teacher_interview_pack.md -----
# Interview pack: Fourth Grade Teacher, Halvering Elementary School

**District:** Orrinsford Community School District
**Round:** one 45-minute panel on Thursday: Principal Dolores Vantongeren and two members of the fourth-grade team (names not given)
**Candidate:** Grace

Built on this assumption: no job posting was supplied, so the posting-based rows use a representative fourth-grade posting and are labeled `[inferred]`; no sample lesson or other deliverable has been announced.

## 2. How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether your past behavior shows the district's published beliefs |
| EXP | Whether your own account of your work holds up under follow-ups |
| JD | Whether you can do the listed job, including its gaps |
| CO | Whether you know the district and where it is heading |
| CASE | How you reason through a live classroom problem |

**Highest-ROI prep:** A1 and A2, then G1. "You have not taught fourth grade" and "you have not been a team lead" will be raised in some form, and a calm, short, honest answer to them changes the whole panel.

## 4. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — your invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | A gate your material shows met: kind, issuer, endorsement and status are all stated. It is your own statement with nothing inspected behind it, and checking the registration is yours to do before Thursday. Say it plainly in the quote's own terms: you hold an Illinois Professional Educator License with an Elementary Education endorsement for grades 1–6 |
| F2 | "the Fourth Grade Teacher position" — your invite | "I've never taught fourth grade" — your message; "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [grounded] | transferability | Your words: "I've never taught fourth grade." Then the adjacent work at its own scope: "Six years teaching third grade at a public elementary school in Joliet." The quote says third grade, six years, a public school in Joliet, and nothing about what carries over. Answer slot: the position title makes a probe on what differs in fourth grade likely. If you have worked with fourth-grade students or content in any setting, say where, in your own words; if not, say so plainly and stay with the third-grade years. How you would learn fourth grade goes as a plan, never as a past |
| F3 | "plan and teach reading, writing, math, science and social studies" — K12 Jobs Board posting (representative, not this district's) | "Six years teaching third grade at a public elementary school in Joliet." — your CV | low | [inferred] | discovery | The material does not show which subjects you taught. Answer slot: if you taught reading, writing, math, science and social studies, say which, in your own words; if some were taught by someone else or you did not teach them, say so plainly and name the ones you did |
| F4 | "no student leaves third grade without a reading plan" — Orrinsford Mission and Beliefs page | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years." — your CV | medium | [grounded] | transferability | Both quotes are reading work, and neither says anything about individual reading plans. Say each at its own size: a move your grade level made in 2024, a club you have run for two years. The district's August 2026 literacy plan includes "a new grades 3–5 reading curriculum from fall 2027" (news snippet), so the curriculum quote is the nearest of your sentences to what they are doing. Answer slot: the district's reading-plan line makes a probe on individual students' plans likely. If any students in your room had a reading plan, say how, in your own words; if your school did not use them or they were not yours, say so plainly and stay with the move and the club |
| F5 | "communicate regularly with families" — K12 Jobs Board posting (representative, not this district's) | "I write a weekly email to families." — your CV | medium | [inferred] | none | No gap, but a CV line with nothing inspected behind it, so expect a probe. Lead with it in the quote's own terms: you write it, it is weekly, it goes to families |
| F6 | "each teacher speaks with every family each term" — Orrinsford Mission and Beliefs page | "I write a weekly email to families." — your CV | low | [grounded] | transferability | An email is adjacent to speaking with families, and the quote does not say whether you also talk with them. Words: "I write a weekly email to families." Answer slot: the district's line makes a probe on direct conversations likely. If you speak with families directly, say how and how often, in your own words; if the email is your main channel, or you do not speak with every family, say so plainly and stay with the email |
| F7 | "work with the grade-level team" — K12 Jobs Board posting (representative, not this district's) | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead." — your message | medium | [inferred] | presentation | The first quote already speaks to your grade level, so say it as written and at that size: a move, a grade level, 2024. Keep your own limit beside it: "I've never been a team lead." Expect a probe on how much of the move was yours; D1 rehearses it |
| F8 | "differentiate instruction using assessment data" — K12 Jobs Board posting (representative, not this district's) | none given | none | [inferred] | discovery | The material says nothing on this. Answer slot: if you used assessment results to change what or how you taught, say what, in your own words; if you did not, or the school ran its own process, say so plainly and say how you would use assessment data |
| F9 | "keep clear classroom routines" — K12 Jobs Board posting (representative, not this district's) | none given | none | [inferred] | discovery | The material says nothing on this, and the district's hiring page names routines as a panel topic. Answer slot: if you can name a routine you actually run, say it in your own words; if none comes to mind, say so plainly and say how you would set one up |

## 7. Reading the interviewer

| Fact (public professional footprint only) | Source | Provenance | Practical implication |
|---|---|---|---|
| Principal of Halvering Elementary School since 2022, after nine years as a reading specialist | Illinois principals forum speaker page (search snippet) | [grounded] | Reading questions will likely come from someone who has taught reading specialist-level detail; B1, B3 and D2 are your rehearsal |
| Her 2025 forum talk, "Small Groups, Big Readers", covered weekly reading conferences in grades 3 to 5 | Same page (search snippet) | [grounded] | Expect questions about how reading time is organized. Describe only the reading practice you actually run; do not adopt her vocabulary for yours |
| Mirror opportunity: shared vocabulary is reading. Pair it with "I've run the after-school reading club for the last two years." (F4) | F4 evidence | [grounded] | Say the sentence as written and let her ask the follow-up |
| No shared career jump is offered | No row carries your side of one | [grounded] | Her path runs from reading specialist to principal; nothing in your material shows a matching move |
| The two fourth-grade team members | Names not given | [grounded] | No read is possible; C-bank rehearses the peer style |

## 8. Persona table

Loop: the district's hiring page describes one 45-minute building panel of the principal and two grade-level teachers, so persona weights blend the principal's relationship (hiring manager: Case/Strategist and Skeptic) with the two teachers' (peer: Peer Evaluator and Prober). No separate values round is documented, so there is no values cheat sheet; the three published beliefs still theme the E-bank.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Quiet probing of fourth grade, team experience and why now | High: F2 and F7 hold your own stated limits, and the principal is the hiring manager | Rehearse A1 until it is boring: your own plain statement, then the third-grade quote at its own size; concede what you do not know |
| Case/Strategist (B) | Live reading and routine scenarios | High: the hiring page names reading instruction and classroom routines, and the principal's background is reading | Clarify first, then structure, then think aloud; make no claim about your past unless a quote carries it |
| Peer Evaluator (C) | Teammates asking what you would need and what you bring | High: two grade-level teachers sit on the panel | Reciprocity: what you need, and what your own quotes say you have done |
| Prober (D) | Follow-ups on how much of the move and the club were yours | Medium: no figures are on your CV, but "led" and "run" invite attribution probes | Name your part in your own words, or say plainly you do not know how to size it |
| Values/Behavioral (E) | Stories mapped to the three published beliefs | Medium: the beliefs page says they guide every hire, but no values round is documented | Pick a real instance per belief; if none comes to mind, say so and give the nearest thing |
| Conversational (F) | Opening biography and casual reading questions | Medium: panels usually open this way, but the hiring page does not say | A 90-second arc built only from your four quotes |
| Pressure (G) | Time-boxed "why you" | Low: nothing documented suggests a stress format | Pause, restate, hold through two follow-ups |

## 9. Question banks

### A. Skeptic (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of teaching fourth grade would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" — your message; "Six years teaching third grade at a public elementary school in Joliet." — your CV | The highest-ROI rehearsal in this pack. Open with your own words: "I've never taught fourth grade." Then the adjacent years at their own size: six years teaching third grade at a public school in Joliet. Answer slot: name the part you would be weakest at in your own judgment, in your own words; if you are not sure, say so plainly. Say what you would do first as a plan, not a past. Hold through two follow-ups by returning to those two sentences, never by adding to them | F2 is the biggest gap and the likeliest opening probe; JD because it scores the position itself |
| A2 | "You haven't been a team lead. What would you bring to our fourth-grade team?" | JD | [grounded] "I've never been a team lead." — your message; "I led our grade level's move to a new reading curriculum in 2024" — your CV | Say "I've never been a team lead." Then the move at its own size: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: if asked what that involved, name the part that was yours, in your own words; if you cannot size your part, say so plainly and stay with the sentence. Stop there; do not widen the move into a role | F7 pairs a stated limit with a strong sentence, and the two sit close enough to be tested against each other |
| A3 | "Why Halvering, and why now?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Give your own reason in one or two sentences. If it connects to the board's August 2026 literacy plan, which includes "a new grades 3–5 reading curriculum from fall 2027", say so; you can add the quoted move, at its own size, as the nearest thing you have done. Answer slot: if you have no particular reason tied to the plan, say so plainly and give your real one | F4 and the news item give this question a grounded hook; CO because it tests homework |
| A4 | "You've taught third grade for six years. Why move to fourth?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." — your CV | Give your own reason in one sentence, without supplying one here. If part of the reason is wanting fourth grade itself, say that, and claim nothing about fourth-grade skill. Answer slot: if a follow-up asks what you will miss from third grade, answer from your own experience; if nothing comes to mind, say so plainly | F2 raises the motivation probe: why leave, why here, why now |

### B. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A student in your room is reading well below grade level in October. What do you do in the first two weeks?" | CASE | [generic] | Clarify first: what the assessment shows and what has been tried. Then state the goal, your approach, how you would tell it is working, and the risks. Think aloud and name your weakest assumption. The question needs no claim about your past, so the guidance makes none | The district's first belief is that every child is a reader (F4's requirement), asked here as a decision |
| B2 | "The board adopted a new grades 3–5 reading curriculum starting fall 2027. If you were on the team bringing it in, what would you want to know first?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Clarify before structuring: what is changing, the timeline, what training and materials exist, how families will hear about it. Then, if it fits, say the quoted sentence at its own size and stop. Answer slot: if asked what that move taught you, say one thing you actually learned, in your own words; if you would rather not claim a lesson, say so plainly | The district's current strategy is the literacy plan in the news item; F4 is the nearest sentence you have |
| B3 | "How would you plan a week of reading time for a class with a wide range of readers?" | CASE | [inferred] derived from the principal's public talk topic (small-group reading in grades 3 to 5) | Structure it: what you would learn about the readers first, how you would group, how you would check progress, what you would change. Describe your approach as how you would plan, not as something you have done, unless you want to add a practice you actually run | The principal's footprint points at reading organization; a pattern question, not a claim about her school |
| B4 | "How would you set up your first week so the routines hold?" | CASE | [grounded] | Structure it: which routines matter most, how you teach and rehearse them, how you check they stick. Answer slot: if you want to ground it in your own room, name a routine you actually run, in your own words; if none comes to mind, say how you would design one | F9; the hiring page names classroom routines as a panel topic |

### C. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you disagreed with a colleague about how to teach something, and how it ended." | EXP | [generic] | Selection scaffold: pick a real disagreement with a named stake, what you said and did, and how the working relationship stood afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F7's team requirement, asked as a peer would ask it |
| C2 | "You haven't taught fourth grade. What would you need from us, and what would you bring us?" | JD | [grounded] "I've never taught fourth grade" — your message; "I've run the after-school reading club for the last two years." — your CV; "I write a weekly email to families." — your CV | Needs: name, in your own words, what you would ask the team first. Brings: say the two sentences at their own size, the club you have run for two years and the weekly email to families, and let them ask. Do not promise to lighten their load | F2 returns in collegial form; a reciprocity framing is the peer persona's counter |
| C3 | "How should a grade-level team divide the work of bringing in a new reading curriculum?" | CASE | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Offer principles rather than pretending to know their seam: who needs to know what, who decides what, how disagreements get settled. Answer slot: if asked how your own grade level did it, say what you did in your own words; if you do not remember the split, say so plainly and stay with the sentence | F4 and F7 give a real curriculum move to measure the answer against |
| C4 | "Which subjects did you teach in third grade, and where would you lean on us?" | JD | [inferred] "Six years teaching third grade at a public elementary school in Joliet." — your CV | Answer slot: if you taught reading, writing, math, science and social studies, say which, in your own words; if some were taught by someone else, say so plainly. Where you would lean on the team is your own judgment | F3's discovery gap; the subject list is the representative posting's, framed as typical |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "On the move to the new reading curriculum, how much of it was you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Hold-then-concede. Say the sentence at its size, then name the part that was yours in your own words. Answer slot: if you cannot say exactly how the work was divided, say so plainly rather than estimating. Hold through two follow-ups by returning to the sentence | F7; "led" is the word a prober tests |
| D2 | "Tell me about the after-school reading club you run." | EXP | [grounded] "I've run the after-school reading club for the last two years." — your CV | Say what the sentence says: after school, reading, run by you, two years. Answer slot: if asked who attends or what a session looks like, answer from what you actually do; if there is something you do not track, such as attendance or outcomes, say so plainly | F4 gives the club as your nearest reading work, and the probe falls on its details |
| D3 | "What changed in how you teach between your first year in third grade and your sixth?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." — your CV | Answer slot: name what actually changed, in your own words; if little changed, say so plainly and say what you would still want to improve | F2; six years is the one number on your CV, and probers test what it contains |

### E. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you worked to help one child with their reading." | VAL | [grounded] "I've run the after-school reading club for the last two years." — your CV | Belief: Every Child a Reader. Selection scaffold: pick one child, with no name, what you noticed, what you did, and what happened. The club sentence carries the club, not a single child's story. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4; the first published belief |
| E2 | "Each of our teachers speaks with every family each term. What would that look like in your year?" | VAL | [grounded] "I write a weekly email to families." — your CV | Belief: Families Are Partners. Say the email at its own size. Answer slot: if you speak with families directly, say how often, in your own words; if you do not speak with every family, say so plainly and say how you would build it in | F6; the second published belief |
| E3 | "Tell me about a time assessment results changed what you taught." | VAL | [grounded] | Belief: Teach for Tomorrow, Not for the Test. Selection scaffold: pick a real instance, what the results showed, what you changed, and what you did with the result afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F8; the third published belief |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey: how did you get from third grade in Joliet to this chair?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." — your CV; "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years." — your CV; "I write a weekly email to families." — your CV | A 90-second arc in this order: the six years, the move, the club, the email, each at its own size, then your own reason for fourth grade in your own words. Answer slot: if you have no single reason, say so plainly and give the main one | F2, F4, F5, F7; the opener is scored even when it feels casual |
| F2 | "What are you actually playing with in reading these days?" | JD | [grounded] "I've run the after-school reading club for the last two years." — your CV | Answer slot: name what you are actually trying or reading, in your own words; if nothing new comes to mind, say so plainly and stay with the club, at its own size | F4; the principal's background makes reading the natural casual topic |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over a teacher who has already taught fourth grade?" | JD | [grounded] "I've never taught fourth grade" — your message; "Six years teaching third grade at a public elementary school in Joliet." — your CV; "I led our grade level's move to a new reading curriculum in 2024" — your CV | Pause and restate. Hold-then-concede: concede first and plainly, "I've never taught fourth grade", then the six years and the move at their own size. Hold through two follow-ups by returning to them; concede specifically what you do not know, and do not claim to be better than anyone | F2 under time pressure; the stem comes from the Pressure persona |
| G2 | "A parent emails you, upset that their child isn't reading at level. What do you write back?" | CASE | [generic] | Pause, then structure: acknowledge the concern, say what you will look at, say when you will follow up. The question needs no claim about your past, so the guidance makes none | F5 and F6, asked as a live decision |

### Requirement coverage

| Requirement | Question IDs |
|---|---|
| F1 licence | — none, and why: a term your own statement shows met, which an HR file normally covers rather than a panel |
| F2 fourth grade | A1, A4, C2, D3, G1 |
| F3 subjects | C4 |
| F4 reading | A3, B1, B2, B3, C3, D2, E1, F2 |
| F5 regular family communication | G2 |
| F6 speaking with every family | E2, G2 |
| F7 grade-level team | A2, C1, C3, D1 |
| F8 assessment data | E3 |
| F9 classroom routines | B4 |

## 11. Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R1 | "You spent nine years as a reading specialist before becoming principal. How has that shaped the way reading is taught across grades 3 to 5 here?" | Ties to her own path and signals you read her footprint, not just the district's | [grounded] |
| R2 | "The board's new grades 3–5 reading curriculum starts in fall 2027. What would you want a fourth-grade teacher to be doing before then?" | Shows you read the literacy plan and turns the curriculum move on your CV into a forward question | [grounded] |
| R3 | "What could a new teacher on the fourth-grade team do in their first month that would genuinely help you?" | Reciprocity for the two teachers on the panel: it asks about their load, not only yours | [generic] |
| R4 | "What does a strong first term look like for a teacher who is new to fourth grade?" | Raises your gap yourself, in a forward direction, and gets you the bar in their words | [generic] |
| R5 | "How do teachers here fit speaking with every family each term alongside everything else?" | Shows you read the second belief and asks how it works in practice | [grounded] |
| R6 | "What are the next steps after the panel, and when should I expect to hear?" | A plain close; the district's hiring page says references are taken up after the panel | [grounded] |

## 13. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade, or has fourth-grade experience | Negative you stated, F2 | "I've never taught fourth grade." with the third-grade quote at its own scope; no slot beyond what A1 gives |
| Has been a team lead, or led the grade-level team | Negative you stated, F7 | "I've never been a team lead." beside "I led our grade level's move to a new reading curriculum in 2024" at its own scope |
| Chose, designed or wrote the new reading curriculum | Inflated form of F4 and F7 | The quote at its own scope. The limit is the pack's observation: your material says the move, not the selection or the design. A2, C3 and D1 stay inside the move |
| Founded or built a reading program | Inflated form of F4 | "I've run the after-school reading club for the last two years." The material says run, not started. D2's slot stays inside what you run |
| Speaks with every family each term | Inflated form of F6 | "I write a weekly email to families." The material says an email, not a conversation with every family. E2's slot asks only what you do |

## 14. Sources

Provided documents: your invite and your pasted CV. Two items in your message were not needed and were not used: the social security number and the license number.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

Queries sent:

- `Orrinsford Community School District mission values` → https://orrinsfordschools.example/about/mission-and-beliefs
- `Halvering Elementary School Orrinsford Community School District` → no results
- `Dolores Vantongeren principal Halvering Elementary` → https://ilprincipalsforum.example/speakers/dolores-vantongeren (snippet only, not fetched)
- `Illinois fourth grade teacher job posting elementary interview panel` → https://k12jobsboard.example/listings/fourth-grade-teacher (snippet only, truncated mid-sentence in the qualifications) and https://orrinsfordschools.example/careers/how-we-hire-teachers
- `Orrinsford Community School District strategic plan news 2026` → https://orrinsfordschools.example/news/board-adopts-literacy-plan (snippet only, not fetched)

Fetched: the Mission and Beliefs page; the "How we hire teachers" page.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Orrinsford values` | yes | The three published beliefs themed the E-bank and rows F4 and F6; no values-style round is documented, so there is no cheat sheet |
| 2. interview process | yes | The loop: one 45-minute building panel; persona weights blend principal and peers. Surfaced partly by the query listed under target 5; the query naming the school returned nothing |
| 3. strategy and recent news | yes | The August 2026 literacy plan, from a snippet only; fed B2, A3, R2 |
| 4. interviewer name | yes | The principal's role history and talk topic, from a snippet only; fed section 7, B3, R1 |
| 5. representative fourth-grade posting | yes | Rows F3, F5, F7, F8, F9 and C4; the snippet cuts off mid-sentence, so qualifications are not in the pack |

## 15. Upgrade menu

- The posting's full text → rows F3, F5, F7, F8 and F9 move from `[inferred]` to `[grounded]`, and the district's own qualifications list gets checked against the banks
- Anything HR or the school said about the panel, such as a sample lesson, a writing task or a topic list → a build section for each announced deliverable; usually one email to the contact on the invite
- The names and roles of the two fourth-grade team members → a read of each, and a reverse question tuned to them
- Your own answers to the answer slots, said outside a drill → rows F2, F3, F4, F6, F8 and F9 regenerate from your quoted words
- A copy of your license or the official state record of it → F1 moves from `medium` toward `high`; checking the registration stays yours
- A `tuesday-dossier.md` from an earlier evidence review, if you have one → verified evidence and a ready-made prohibited-claims list
