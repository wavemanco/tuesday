Search permission wasn't granted, so I'm building your pack from what you've told me. The invite has serious warning signs, so the message will open with those.
Before the prep, one thing in the invite: it asks you to "please transfer the €95 equipment registration fee to our supplier's account, IBAN ..." and to "please also reply with a photo of your passport and your bank details before the interview". It also says successful candidates "deposit the cheque and send the balance on to the vendor". Fees, passport photos and bank details before any offer, and cheques you deposit and then pass on, are a known scam pattern. The fee, the cheque arrangement and the passport and bank-details request are very likely a scam. Please hold all of it (no payment, no cheque deposit, no passport photo, no bank details) until you've checked the invite with the employer it names. Use contact details you find yourself on its own website or careers page, never the sender's email, number or answers. If you want the invite weighed, job-underwriter can check it as a separate request. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

Your prep pack is saved as `/var/tmp/tuesday-measure/1a6/runs/sonnet/alone/part-5/rooms/case-12-denied-08215582/Brennock-Facilities-Ltd_remote-administrative-assistant_interview_pack.md`. I built it for the one 30-minute video call with the office manager that your note describes.

**What to expect:**
- **Likeliest probes:** supplier invoices (you've chased unpaid ones, which isn't the same as processing them), booking travel, and Excel. Your note says you're only "okay with Excel".
- **Practical scenarios:** clashing diary requests, a trip to book, and an invoice that doesn't match an order.
- **Your strongest ground:** running the appointment book for four physios.
- **How to prepare:** the highest-ROI rehearsal is A2, the invoices question. State only what you actually did, and say plainly what you haven't done.

Search permission wasn't granted, so I couldn't research the company. The company-knowledge question (C3) is generic and the pack has no values sheet.

Say the word and I'll play the Skeptic on A2 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Could you paste the ad's own text and the clinic lines from your CV, so the rows built on your summary can quote the actual documents?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Brennock-Facilities-Ltd_remote-administrative-assistant_interview_pack.md -----
# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

Interviewer: the office manager (name not given). Round: one 30-minute video call, per your note. Prepared for: Aoife.

## How to use this pack

- Personas describe how a question is asked. Types describe what it scores.
- Type key: VAL = values and behaviour; EXP = a deep-dive on your experience; JD = the stated duties of the job; CO = what you know about the company; CASE = a live problem set in the role.
- Provenance key: `[grounded]` comes from something you wrote, `[inferred]` is this pack's derivation, `[generic]` is a pattern for the role with no claim about you or the company.
- Guidance is scaffolding, not a script. Say it in your own words, and say only what you actually did.
- Answer slots (marked "Answer slot") are instructions for the interview. They ask for no reply here.
- Highest-ROI prep in this pack: A2. Someone moving from reception into invoice handling will almost certainly be asked about it, and a calm, honest, rehearsed answer changes the call.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — your message, the ad as you described it | "I ran the appointment book for four physios" — your message | medium | [grounded] | presentation | Say it in those terms and at that scope: "I ran the appointment book for four physios." Let the interviewer connect it to calendars. It is a line with nothing inspected behind it, so expect a probe on it |
| F2 | "booking travel" — your message, the ad as you described it | none given | none | [grounded] | discovery | Your material says nothing on travel, so the words are an answer slot. The ad's travel line makes a probe likely. If you have booked travel for anyone, at work or not, say what and for whom, in your own words; if not, say so plainly and say how you would go about a first booking |
| F3 | "preparing documents in Word and Excel" — your message, the ad as you described it (Word half) | "I'm good with Word, okay with Excel" — your message | low | [inferred] | discovery | The sentence rates you on Word and names no document. Answer slot: the ad's Word line makes a probe on what you have prepared likely. Say what kinds of documents you have prepared, in your own words; if you have not prepared any for work, say so plainly and stay with "I'm good with Word" |
| F4 | "preparing documents in Word and Excel" — your message, the ad as you described it (Excel half) | "I'm good with Word, okay with Excel" — your message | low | [inferred] | discovery | "Okay" is your own rating and the words stay at it: "I'm okay with Excel." Answer slot: the ad's Excel line makes a probe on what you have used it for likely. Say what you have used it for, in your own words; if you have not used it for work, say so plainly and stay with "okay with Excel" |
| F5 | "processing supplier invoices" — your message, the ad as you described it | "chased unpaid invoices" — your message | low | [inferred] | transferability | Your material says chasing unpaid invoices, not processing supplier invoices, and the words stay there: "I chased unpaid invoices." Answer slot: the ad's supplier-invoices line makes a probe on the other side of that work likely. If any of what you did was processing supplier invoices, say what and which part was yours; if none of it was, or it was not yours, say so plainly and stay with chasing unpaid invoices |

## Persona table

The round is one session with the office manager, from your own note: "The interview is a 30-minute video call with our office manager." — your message. No interviewer profile and no documented process for this company was available, so weights come from the round type and from the fit snapshot, and you should adjust them if you know more.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet probing of the move from reception, and of the duties your material does not carry | High. One manager across a short call tends to test the duties where F2, F4 and F5 are thinnest | Rehearse A2 until it is boring. Use only adjacent things you actually said, and say the limit plainly |
| B. Case / practical scenarios | Small live problems from the job: clashing diary requests, a trip to book, an invoice that does not match | High. For an administrative role the manager sees how you think by giving you the day-to-day problems | Clarify first, then order your steps, then say how you would confirm and record |
| C. Conversational | Friendly opener, journey, what draws you here | Medium. A 30-minute video call opens with it, and it is still scored | Prepare a 90-second arc built only from your own sentences |
| D. Data-driven prober | Which part was yours, how many, what tools | Medium. Your lines carry a number and two software ratings, which invite follow-ups | Say what you know and say plainly when you do not know |
| E. Peer | What you need from the manager, how you raise a mistake | Low to medium. The office manager is also a day-to-day colleague | Offer what you bring as well as what you need |
| F. Pressure | A time-boxed challenge on the gaps | Low. Short administrative screens rarely run hot, but the Skeptic can turn firm | Pause, restate, hold twice, concede the specific gap and keep the core |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I'm good with Word, okay with Excel", "chased unpaid invoices" | Selection scaffold: pick the one area where you are genuinely least ready, say it first and plainly, then say what you would do in your first week to close it. Your material is silent on travel and carries only "okay with Excel" and "chased unpaid invoices" against the ad's Excel and supplier-invoice lines, so one of those is the likeliest honest choice. Hold-then-concede: name it without apology and do not offset it with claims. If you cannot name one, say so plainly and name the one you would ask to be shown first | F2, F4 and F5 are the thinnest rows, so this probe is the likeliest opener of the Skeptic bank. JD because it scores the stated duties, with the gaps included |
| A2 | "You've chased unpaid invoices. How does that connect to processing supplier invoices?" | JD | [grounded] "chased unpaid invoices" | The highest-ROI rehearsal in this pack. Hold only what the quote carries: "I chased unpaid invoices." Answer slot: if any of what you did was processing supplier invoices, say what and which part was yours, in your own words; if none of it was, or it was not yours, say so plainly and stay with chasing unpaid invoices. Hold through two follow-ups by returning to that sentence, never by adding to it. Concede specifically what you have not done, and say what you would want to be shown first | F5 is where the ad's invoice duty presses hardest on your material, so this objection arrives in some form. JD because it scores a stated duty, with Skeptic delivery |
| A3 | "Tell me about a time you arranged travel for someone." | JD | [grounded] "I ran the appointment book for four physios" | Selection scaffold: pick an occasion where you booked a trip or journey for someone else, at work or not. It needs what was asked, what you booked and how you checked it was right. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I ran the appointment book for four physios", or how you would go about a first booking | F2 has no evidence, so the travel line is a free miss unless an honest answer is ready. JD because the ad names booking travel, EXP in delivery |
| A4 | "What draws you to an administrative assistant role rather than another reception job?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | Your material gives no reason for the move, so the reason is an answer slot: say your actual reason in your own words. If the honest reason is the duties themselves, say which of the ad's duties interest you and why. Do not invent a story of dissatisfaction or ambition | Motivation consistency is what the Skeptic scores. EXP because it tests how the clinic work connects to this move |
| A5 | "This role is remote. How would you keep on top of your work without a team around you?" | JD | [generic] | A structure, not a story: how you would plan the day, how you would show your manager what is done and what is waiting, and when you would raise a problem. The question needs no claim about your past, so the guidance makes none | The job title names remote working, so a probe on self-management is likely. CASE in delivery, JD because the title is the source |

### B. Case / practical scenarios

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Two people ask you for the same slot in my diary and both say it is urgent. What do you do?" | CASE | [generic] | Structure it: what you would ask each person, what you would check with the diary's owner, what you would offer the person who loses the slot, and how you would confirm and record the outcome. No claim about your past is needed, so none is made | The calendar duty (F1) is a headline duty, so a live diary problem is the likeliest case. CASE because it asks for a decision rather than a record |
| B2 | "I need to be in another city next Tuesday morning and back Wednesday evening, on a limited budget. What do you ask me first, and then what do you do?" | CASE | [generic] | Clarify before you act: who is travelling, fixed times, budget limit, any preferences, who approves. Then options, then confirmation, then a single itinerary document. Keep it as a plan. Do not describe past trips unless you actually booked them | F2 has no evidence, so a case is the safest way to show how you would approach travel. CASE for the structure it tests, JD for its source |
| B3 | "A supplier invoice arrives that does not match what I remember ordering. What do you do?" | CASE | [generic] | Structure it: do not process it yet, check what records exist of the order, ask the person who placed it, contact the supplier if still unclear, and log what you found and who approved. Say what you would escalate and when | The invoice duty (F5) is where your material is thinnest, and a structured case lets you show care without claiming experience. CASE for the delivery, JD for the duty |
| B4 | "Here is a spreadsheet of supplier invoices with due dates scattered through it. How would you set it up so nothing is paid late?" | CASE | [generic] | Clarify first: which columns exist, who needs to see it. Then describe only what you would actually do in Excel. If you would need to look up how, say so plainly and say how you would learn it. Do not name functions you have not used | F4 sits at your own rating of "okay", so a plan that shows reasoning and honest limits is stronger than claimed skill. CASE for the structure, JD for the Excel line |
| B5 | "I need a one-page agenda and a follow-up note for a visitor tomorrow. What would you ask me first?" | CASE | [generic] | Clarify before drafting: purpose, attendees, time, tone, who signs it off, and where it should be saved. Then a draft for approval, not a final | F3 covers Word, and this case tests process rather than the software. CASE for the structure, JD for the document duty |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your journey so far." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic", "I ran the appointment book for four physios", "chased unpaid invoices", "I'm good with Word, okay with Excel" | A 90-second arc made only of those four sentences, in your own words: the two years at the clinic, the appointment book for four physios, the unpaid invoices you chased, then Word and Excel at the ratings you gave. Close with why this role, which is an answer slot: say your actual reason in your own words | The journey question opens most conversational rounds and is scored like any other. EXP because it tests whether the story matches the CV |
| C2 | "What did you enjoy most about running the appointment book?" | EXP | [grounded] "I ran the appointment book for four physios" | Answer from what you actually enjoyed, in your own words, and keep it at the book you ran for four physios. If nothing stood out, say what you find interesting about scheduling work in general. The pack does not supply a reason | F1 is your strongest row, so a friendly question about it is likely. EXP because it tests whether your interest in the work is genuine |
| C3 | "What do you know about our company, and what appeals to you here?" | CO | [generic] | No research on this company could be used, so the pack gives you nothing about it. Name only what you have read yourself in the ad and in any company pages you have found. The duties named in the ad as you described them are safe to mention: managing calendars, booking travel, Word and Excel documents and supplier invoices. If you have read little about the company, say so plainly and talk about those duties | Homework depth is scored even in a friendly register. CO because it tests knowledge of the company, and it is generic because nothing about the company was established |

### D. Data-driven prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You ran the appointment book for four physios. Which part of that was yours, and which was set by someone else?" | EXP | [grounded] "I ran the appointment book for four physios" | Hold the sentence: "I ran the appointment book for four physios." Answer slot: say which parts of running it were yours, in your own words; if you did not set any part of it, say so plainly and describe how you worked within it | F1 is a CV-style line with nothing inspected behind it, so a prober asks which part was yours. EXP because it tests attribution |
| D2 | "Roughly how many appointments a week did that book cover?" | EXP | [grounded] "I ran the appointment book for four physios" | Give a figure only if you actually know it and say how you know it. If you do not know, say "I don't know the exact figure" rather than estimating. Do not name the assumption behind a figure unless you know it | "Four physios" is the one figure your material carries, so a prober asks how big the book was. EXP because it tests defend-the-number honesty |
| D3 | "What have you used Excel for?" | EXP | [grounded] "I'm good with Word, okay with Excel" | Start with your own rating: "I'm okay with Excel." Answer slot: say what you have used it for, in your own words; if you have not used it for work, say so plainly and stay with "okay with Excel". Never rate yourself higher than you did in your note | F4 is a self-rating at "okay", and the ad's Excel line makes a probe on it likely. EXP because it tests whether the rating holds up |

### E. Peer

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "What would you need from me to do this job well?" | JD | [generic] | Reciprocity framing: ask how work arrives, where files and records live and who approves what, then say what you will offer in return, such as telling me early when something is blocked. This is about future behaviour, so it makes no claim about your past | A peer-style manager prices what the hire adds to their own load. JD because it is about how the job runs |
| E2 | "If you spotted a mistake in something I had prepared, how would you tell me?" | VAL | [generic] | Show spine and tact together: check you are right first, raise it privately and early, say what you saw and what you suggest, and leave the decision with me. No claim about your past is needed | Disagreement style with an equal is a standard peer probe. VAL because it scores behaviour, though no published company value was available |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why should we pick a receptionist over someone who has already done administrative work?" | EXP | [grounded] "I ran the appointment book for four physios", "chased unpaid invoices" | Pause, restate the question, then hold on what you said: "I ran the appointment book for four physios" and "I chased unpaid invoices." Concede the specific gap in your own words, naming what the ad asks that your material does not show, and say what you would learn first. Do not claim administrative duties you did not do | The pressure persona tests whether you hold a position without bluffing. EXP because the answer rests on your own sentences, and F2 and F5 are what you would concede |
| F2 | "Okay with Excel is not good enough for our invoices. Convince me." | JD | [grounded] "I'm good with Word, okay with Excel" | Hold the rating you gave: "I'm okay with Excel." Do not argue it up. Concede specifically that you would need to be shown the invoice sheet, say what you would check first and how you would learn what you do not know. Answer slot: if you have used Excel for something close to invoice records, say what, in your own words; if not, say so plainly | F4 is the row a firm interviewer can press hardest. JD because it scores the Excel duty, with Pressure delivery |

### Requirement coverage

| Requirement | Questions covering it |
|---|---|
| "managing calendars" | A3 for the nearest thing, B1, C1, C2, D1, D2 |
| "booking travel" | A3, B2 |
| "preparing documents in Word and Excel" | B4, B5, C1, D3, F2 |
| "processing supplier invoices" | A1, A2, B3, B4, F1 |
| Remote working, from the job title | A5 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a good first month look like for this role?" | It shows you think about outcomes, and the answer tells you what is prioritised first |
| R2 | "How does work reach the assistant day to day, and who decides priorities when requests clash?" | It follows from B1 and shows you have thought about the real job |
| R3 | "Which tools do you use for the calendar and for tracking supplier invoices, and what training is there?" | It shows you check tools early, and it speaks to your Excel rating without overclaiming |
| R4 | "How is remote working organised: core hours, check-ins and how the team stays in touch?" | It follows from A5 and tells you how the day will run |
| R5 | "What could a new person do in their first month that would genuinely help you?" | A reciprocity question for a colleague-style interviewer, and it signals you are thinking about their load |
| R6 | "What are the next steps after this call, and roughly when would I hear?" | It is a process question that lets you plan around the timeline |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Processed supplier invoices | Inflated form of F5 | F5's quote at its own scope: "I chased unpaid invoices." The limit is the pack's observation, not words for you: the material says chasing, not processing. A2's slot stays inside the chasing |
| Skilled or advanced in Excel | Inflated form of F4 | F4's quote at its own scope: "I'm okay with Excel." D3's slot asks only what you have used it for |
| Managed the calendars of a whole team or practice | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios." |

## Sources

Provided documents: your message, which holds the invite text, your description of the ad and your background. No dossier was supplied. Nothing from outside your message went into the fit snapshot or the banks.

Queries sent: "company values Brennock Facilities Ltd" (refused); "interview process remote administrative assistant Brennock Facilities Ltd" (refused).

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Every call was refused. It would have fed a values cheat sheet and the CO bank; neither is in this pack |
| 2. `{company} interview process {role family}` | unavailable | Every call was refused. The one-session loop rests on your own note, which fixes the session and who runs it, so the persona weights use it |
| 3. `{company} strategy` / recent news | unavailable | No call was sent, because search permission was not granted. It would have moved C3 from generic to grounded |
| 4. `{interviewer name} {company}` | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. representative `{role title}` JD | skipped | Your description of the ad fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The ad's own text → the five requirement cells quote the ad instead of your description of it, and any duty your summary left out gets a row and a question
- The clinic lines of your CV → each evidence cell can quote your CV, and a sample of the appointment book layout or an invoice-chasing log, with patient details removed, would raise F1 and F5 from the confidence they have now
- Your own words on the answer slots in F2 to F5 → the travel, Word, Excel and invoice rows become story-mapped answers in A2, A3, D3 and F2
- The interviewer's name → an interviewer read, retuned persona weights and a reverse question tied to their own path
- Company values, careers page or process pages you have found, pasted in → the CO bank and a values sheet become grounded, and a deeper research pass is also available: up to 6 more searches and 2 more fetches, several more minutes
- The time you have to prepare → a prioritised schedule sized to it
- A tuesday-dossier.md → verified evidence and limits per weak area, so inferred rows become grounded
