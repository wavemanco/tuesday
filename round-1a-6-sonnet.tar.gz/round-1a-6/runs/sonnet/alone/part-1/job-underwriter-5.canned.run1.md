Checking that the posting and company page are live and match what you pasted, then I'll write the assessment.
## Decision snapshot

**Yes, this is worth applying to. R3, R4, R5, R6, R7 and R8 read `direct` and R9 (BigQuery) reads `adjacent`. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver), R2 (Salary $148,000–$166,000)
- `must_have`: direct: R3, R4, R5, R6, R7, R8
- `important`: adjacent: R9 (BigQuery); unclear: R10 (Data contracts for analysts), R11 (Ingestion from app and CRM)

R9 is a credible bridge with its limit named. R10, R11 are responsibilities your background doesn't mention.

**Opportunity ledger.** The employer and posting check out (RR5), and the stated pay is competitive (RR2). Three things are unknown: the reporting line and team shape (RR1), the equity terms (RR3) and what "remote" requires (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver), R2 (Salary $148,000–$166,000); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your location and pay floor meet R1 and R2; (2) BigQuery is framed as adjacent, never as experience (R9); (3) scope and team shape verify concrete in interviews (RR1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` About page fetched |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` careers page fetched |
| Stated requirements | 5+ years data engineering; strong SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` careers page |
| Terms | $148,000–$166,000 plus equity; Remote (US) or Denver office | `[grounded]` careers page |
| First-year outcomes | Not stated. The posting gives no 90-day or first-year deliverables | `[grounded]` careers page silent |
| Scope read | "Build and run" suggests end-to-end ownership of the reporting pipelines. Whether that is one domain or the whole data stack is not stated | `[inferred]` from the mandate wording against the posting's silence on team size |
| Market calibration | The posted range runs from $3,000 below the report's median ($151,000) to $2,500 above its 75th percentile ($163,500). Series C sits inside the report's Series B–D cohort. Six years sits inside the report's typical 5–8 for "Senior". The report's typical scope is one domain's pipelines with no direct reports. This is a pattern, not this employer's offer | `[grounded]` posted figures and your pay report; `[generic]` that the report's cohort and scope norms describe the market |
| Unknowns | Hiring manager (the posting names none), team size, new role or backfill, equity terms, remote expectations | `[grounded]` posting silent |
| Contradictions | None. The live careers page and About page match what you pasted | `[grounded]` both pages fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | The posting allows two arrangements. You haven't said where you are or whether you need US work authorization. Confidence is `none` because no statement of yours exists to grade | `[grounded]` JD; no constraint stated | Location question in the closing block |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | The pay is stated, but your floor isn't, so I can't tell whether it meets your terms. The range's position against the market is in role reality | `[grounded]` JD; no floor stated | Floor question in the closing block |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company is above the threshold. This is self-reported with nothing inspectable yet. It is an experience requirement, not a gate | `[grounded]` your stated background | A CV or LinkedIn profile would corroborate it |
| R4 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily" matches the requirement. "Strong" is the JD's word and your level hasn't been probed. Hiring loops for this level usually include a technical exercise | `[grounded]` your stated background; `[generic]` on the technical exercise | A code sample or a described hard problem would raise it |
| R5 | dbt | must_have | direct | medium | none | You built the dbt project, about 180 models, on Snowflake. It is specific and self-reported, with no artifact inspected | `[grounded]` your stated background | A sanitized dbt docs page or lineage screenshot would raise it to `high` |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse, and the requirements line asks only for "a cloud warehouse". The JD's BigQuery-specific language is carried separately in R9 | `[grounded]` your background against the JD's requirements line | None |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow is named in the JD and in your background. What you owned (writing DAGs or running the platform) is unstated | `[grounded]` your stated background | None beyond the CV |
| R8 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite. Ownership is stated and no artifact has been inspected | `[grounded]` your stated background | A sanitized suite config or run report would raise it to `high` |
| R9 | BigQuery (named in the mandate; requirements say "a cloud warehouse") | important | adjacent | medium | transferability | Your Snowflake and dbt work carries over. You have never used BigQuery, so its specifics are unexercised | `[inferred]` requirement from the JD's mandate wording; `[grounded]` your stated gap | See G3 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | Great Expectations and dbt tests are neighbouring practice. Nothing you said covers agreements with analysts or other consumers | `[grounded]` your background silent | G1 |
| R11 | Ingestion from the app and CRM | important | unclear | low | discovery | Six years of pipeline work makes ingestion plausible. Your source systems and ingestion tooling are unstated | `[grounded]` your background silent | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Data contracts (R10, important) | discovery | Testing practice exists. Nothing says you agreed schemas or SLAs with downstream consumers | The posting names contracts in the mandate, so the answer shapes how you pitch the role | Schema or freshness agreements with analysts; dbt model contracts or tests tied to a consumer's needs; alerting that notified a consuming team | A sanitized contract doc, a dbt contract config, or an incident write-up | `[grounded]` background silent; `[inferred]` that it matters because the JD names it |
| G2 | App and CRM ingestion (R11, important) | discovery | The source systems behind your payroll pipelines are not stated | The posting names these two source types explicitly | Loading CRM data (Salesforce or similar) or app event or database data into the warehouse; using managed connectors or custom extractors | An architecture diagram or an ingestion DAG list, sanitized | `[grounded]` background silent |
| G3 | BigQuery (R9, important) | transferability | Snowflake plus about 180 dbt models carry over. BigQuery's specifics are unexercised | The mandate names the warehouse, so an interviewer is likely to test it | A BigQuery sandbox project with a dbt-bigquery run and a short write-up | A repo link with a README | `[generic]` that dbt reduces warehouse-specific syntax but not warehouse-specific cost or performance tuning; `[inferred]` the limit from your stated no-BigQuery history |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Reporting line and team shape not given | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | The role may be the sole data engineer owning the whole stack, or one engineer in a team with defined domains | `[inferred]` from the mandate wording against the posting's silence on team size and manager | Who does this role report to, and how many data engineers and analysts are on the team? | unresolved |
| RR2 | Posted pay is competitive | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The employer is transparent on pay, and the band reads as competitive for a Series C company | `[grounded]` posted figures against your pay report; `[generic]` that the report's cohort describes this market | Where in the range would a candidate with six years' experience land? | noted |
| RR3 | Equity terms unstated | unknown | — | "plus equity" | The grant may be material or token, and its instrument and vesting are unknown | `[inferred]` from the posting naming equity with no detail | What is the equity instrument, the typical grant size at this level, and the vesting schedule? | unresolved |
| RR4 | Remote expectations unstated | unknown | — | "Remote (US) or our Denver office" | Remote hires may be expected to overlap core hours or visit Denver periodically | `[inferred]` from the posting giving the arrangement with no conditions | Is remote fully remote, with what timezone overlap or travel to Denver expected? | unresolved |
| RR5 | Employer and posting verified | positive_signal | — | "Accepting applications. Senior Data Engineer — Pellucid Learning" | The employer exists as described, and the posting is live and consistent. The standing employer-not-established entry does not apply | `[grounded]` careers page and About page fetched | Is this a new position or a backfill? | noted |

## Application plan

Every row below is proposed, table and prose alike, and nothing is final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead your summary with the dbt project (about 180 models on Snowflake), the Airflow orchestration and the Great Expectations suite, in your own wording and figures | See R5, R7, R8 | `[grounded]` your stated background | pending your approval |
| E2 | State BigQuery plainly as not yet used, and say how your Snowflake and dbt work maps to it. Don't claim BigQuery experience | See R9 | `[grounded]` your stated gap | pending your approval |
| W1 | A small dbt-bigquery project on the free sandbox, linked from your application and described as a self-directed exercise, not production work | See G3 | `[inferred]` from the R9 limit | pending your approval |
| Q1 | Ask RR1, RR3, RR4 and RR5's questions in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Your background is self-report at intake, so no row is above `medium`.

Research tier: L1 — searches 0 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer) and "About Pellucid Learning" (pellucidlearning.com/about), checking your pasted text against the live pages. They matched, and the posting is live. This moved role reality's organization and contradictions rows and RR5, and left the standing entry unraised |
| 2. Role-family sweep | skipped | Your pay report supplies the band, seniority and scope norms. That fixes the market calibration row and RR2 |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there was no query to form |

I can save all of this as `tuesday-dossier.md` if you want it.

## Upgrade menu

- A CV, or a link to one → presentation edits to E1, and corroboration of R3.
- A sanitized dbt docs page or lineage screenshot, or a Great Expectations suite config → R5 and R8 to `high`.
- Your location and pay floor → R1 and R2 close, and the hard-gates line resolves.
- Answers to G1 and G2 → R10 and R11 firm up.
- A hiring manager's name, or a recruiter's note on the team → RR1 and the scope read, plus which story the plan leads with.
- A deeper research pass on Pellucid Learning (funding and leadership churn, employee reports, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

R1, R2 — Where are you based, do you need US work authorization sorted, and is $148,000 at or above your pay floor?

G1 — Have you agreed schemas, freshness or quality terms with analysts or other consumers of your data, and what did you own?

G2 — Which source systems did your pipelines ingest from, and was any of it CRM or application data?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.