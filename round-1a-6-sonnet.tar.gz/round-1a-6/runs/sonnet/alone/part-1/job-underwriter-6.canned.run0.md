I'll read the skill's reference files before building the assessment.
## Decision snapshot

**Yes, go for it, with the forecast and billing-data gaps (R6, R8a) stated plainly. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol hybrid, two office days), R2 (Salary £61,500–£67,000 plus share options)
- `must_have`: direct: R3, R4, R7 · adjacent: R5 (Strong SQL and spreadsheet modelling), R6 (Experience owning a forecast) · unclear: R8b (Working with finance on revenue data) · absent: R8a (Working with finance on billing data)

R6: a credible bridge, its limit named; R8a: your own statement, no closure yet; R8b (`low`): waiting on an answer.

**Opportunity ledger.** The base pay is stated and sits inside the market band (RR5), and the hiring manager you were given matches a public profile at the company (RR6). Reporting line, team, success measures and option terms are all unstated (RR2, RR3, RR4), and I couldn't find the posting on Quillfield's own site (RR1).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days), R2 (Salary £61,500–£67,000 plus share options); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Bristol two days a week (R1) and the pay band (R2) fit your own limits; (2) the interview shows billing data (R8a) is learnable on the job rather than expected from day one, via RR2; (3) forecast ownership (R6) is shared or taught, not assumed on day one, via RR2 and RR3.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield makes invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol, 96 employees, Series A (£11M) closed April 2025 | `[grounded]` "About Quillfield" page |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting for sales and finance; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Terms | Bristol, hybrid, two office days a week; £61,500–£67,000 plus share options | `[grounded]` posting |
| First-year outcomes | None stated | `[grounded]` posting is silent |
| Scope read | The hiring manager is publicly titled Head of Revenue Operations, so this Lead probably joins an existing function. The posting states no reporting line, team or decision rights | `[inferred]` from the public title against the posting's silence |
| Hiring manager | Tamsin Achebe, Head of Revenue Operations at Quillfield; previously sales operations manager at Corvane Payments for four years | `[grounded]` search result, public professional footprint only |
| Market calibration | The posting's base range brackets the survey median (£64,200) and sits inside its interquartile range (£57,800–£70,400). The survey covers UK B2B software, n=438, and isn't Bristol-specific. It says nothing about the options. I didn't research whether the scope is normal for the title | `[grounded]` posting figure; `[generic]` Ledgerline 2026 UK Revenue Operations Pay Guide |
| Unknowns | Reporting line and team; who signs off the forecast; billing system; option terms; success measures; the posting on Quillfield's own site | `[grounded]` posting silences |
| Contradictions | None between the posting and the About page (Bristol, invoicing software) | `[grounded]` both read |

## Evidence map

Your background is from your message, which counts as self-report at intake. No CV has been seen, so nothing here is above `medium`.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid: two days a week in the office | hard_gate | unclear | none | hard_gate | You gave no location or schedule limit, so there is nothing to test the term against | `[grounded]` posting; no constraint given | Q3 |
| R2 | Salary £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | You gave no pay floor. The base is stated; the options' value isn't | `[grounded]` posting; no constraint given | Q3 |
| R3 | 4+ years in revenue operations, sales operations or similar analytics at a B2B software company | must_have | direct | medium | none | Your 5 years in sales operations, the last 2 running revenue operations for the UK team, meet the years and the function. You said "B2B payments company"; the posting says "B2B software company", and whether that wording matches is unconfirmed | `[grounded]` your background against posting | Describe what your employer sells exactly as it is, no stretch |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified, and you rebuilt the pipeline and renewal dashboards. Specific, but nothing inspected yet | `[grounded]` your background | Salesforce's certification verification page would raise it to `high` |
| R5 | Strong SQL and spreadsheet modelling | must_have | adjacent | medium | discovery | SQL weekly and Excel daily show use. They don't show depth or any modelling, which is what "strong" and "modelling" ask for | `[grounded]` your frequencies; no model or query described | G4 |
| R6 | Experience owning a forecast | must_have | adjacent | medium | transferability | You have not owned the company forecast; finance did. Adjacent: you run the monthly pipeline review with the sales director. Limit: that review is not a forecast you were accountable for or presented to a CFO | `[grounded]` your own statement | G2 |
| R7 | Build the pipeline and renewal reporting that sales and finance run on | must_have | direct | medium | none | You rebuilt the pipeline and renewal dashboards. Whether finance used them is unstated | `[grounded]` your background | Sanitised screenshots would raise it to `high` |
| R8a | Experience working with finance on billing data (the posting says "billing or revenue data") | must_have | absent | none | capability | You said you have never worked on billing data. The "or revenue data" wording means R8b can still meet the requirement | `[grounded]` your own statement | G3 |
| R8b | Experience working with finance on revenue data | must_have | unclear | low | discovery | Renewal dashboards plausibly touched revenue figures, but you haven't said whether finance was involved | `[inferred]` from the renewal dashboards you described | G5 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and pay terms (R1, R2) | hard_gate | No limits stated, so the gates are untested | Either term failing would end the case whatever the fit | Commute or relocation to Bristol; a base-salary floor | None needed; your own limits | `[grounded]` no constraints given |
| G2 | Owning a forecast (R6, must_have) | transferability | A monthly pipeline review with the sales director; finance owned the forecast | Forecast ownership is in the requirements and the mandate, so it is the most likely objection | Calling commit or best-case numbers in the review; supplying pipeline inputs finance used in its forecast; explaining a forecast miss | A sanitised review deck or the pipeline-to-forecast sheet | `[grounded]` your statement; `[generic]` that forecast ownership is where such a role gets probed |
| G3 | Billing data (R8a, must_have) | capability | Stated absence | No evidence either way beyond your word, so this is a real gap, not a presentation one | A closure path: a small self-built exercise joining invoice-style records to CRM accounts in SQL, offered as a work sample only if you approve | The exercise itself | `[grounded]` your statement |
| G4 | SQL and spreadsheet depth (R5, must_have) | discovery | Frequency of use only | "Strong" and "modelling" need an example | A query that fed a dashboard; a renewal-rate or pipeline-coverage model; a spreadsheet others relied on | A query or workbook, sanitised | `[grounded]` frequencies only |
| G5 | Revenue data with finance (R8b, must_have) | discovery | Renewal dashboards, finance involvement unknown | Resolving it could meet R8 despite R8a | Reconciling renewal values with finance; pipeline totals finance used; a renewal-reporting fix agreed with finance | A reconciliation sheet or an email thread, sanitised | `[inferred]` from the renewal dashboards |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not found on the employer's own careers page | unknown | — | "Revenue Operations Lead, Quillfield. Bristol, hybrid" | The role may sit at another address on Quillfield's site, or be advertised only through the jobs board | `[inferred]` from one fetch of quillfield.co.uk/careers returning "No page", a single address I chose | Where is this role listed on Quillfield's own careers page? | unresolved |
| RR2 | Scope, reporting line and decision rights unstated | unknown | — | "own our CRM and billing data, build the pipeline and renewal reporting… and run the quarterly revenue forecast with the CFO" | Four areas sit under one Lead title with no team or sign-off named, beside a Head of Revenue Operations in the same function | `[inferred]` from the posting's silence and the public title | Who does this role report to, who else is on the team, and who signs off the forecast the CFO sees? | unresolved |
| RR3 | No success measures | unknown | — | Same mandate sentence; no outcomes stated | A demanding mandate with no stated definition of success | `[inferred]` from the posting's silence | What would success look like at six and twelve months? | unresolved |
| RR4 | Option terms unstated | unknown | — | "plus share options" | Without grant size, vesting and exercise terms, total pay can't be compared | `[inferred]` from the posting's silence | What are the grant size, vesting schedule and exercise terms? | unresolved |
| RR5 | Base pay stated, within market | positive_signal | — | "£61,500–£67,000" | The posting is transparent on base pay and the band is not low for the title | `[grounded]` posting figure; `[generic]` Ledgerline band, not Bristol-specific | Where in the band does an offer usually land, and what decides it? | noted |
| RR6 | Hiring manager matches a public profile | positive_signal | — | Your recruiter: "the hiring manager is Tamsin Achebe" | The name and title are consistent with a public profile at the company | `[grounded]` search result | Will Tamsin be in the interview loop, and who else will I meet? | noted |

## Application plan

Every row is proposed. Nothing is finalized without your approval, and that covers the advice in the Why column as well as the drafted lines. Each line traces to your own sentences; I didn't add any claim.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with: "Salesforce admin certified; two years running revenue operations for the UK team within five years in sales operations at a B2B payments company; rebuilt the pipeline and renewal dashboards; run the monthly pipeline review with the sales director." Claim nothing on forecast ownership or billing data | These are your strongest rows (R3, R4, R7) | `[grounded]` your own sentences | pending your approval |
| P1 | If asked about the forecast and billing, say: "Finance owned our company forecast; I run the monthly pipeline review with our sales director. I haven't worked on billing data." | Matches R6 and R8a exactly, so nothing gets tested and found thinner | `[grounded]` your own sentences | pending your approval |
| P2 | Tamsin Achebe's public path runs through sales operations at a payments company, so your payments background is one to lead with, as a fact about your career and not a guess at what she wants | See RR6 | `[grounded]` search result | pending your approval |
| Q1 | Ask RR2, RR3 and RR4 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Ask the recruiter for the link to the role on Quillfield's own careers page (RR1) | Costs one message | `[grounded]` RR1 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company" and read "About Quillfield" (quillfield.co.uk/about); fetched quillfield.co.uk/careers, which returned "No page". Established the company and matched the posting's description, and produced RR1 |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK Bristol B2B software", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved the market calibration row and RR5 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Moved the scope read, RR6 and P2 |

I can write all of this to `tuesday-dossier.md` if you'd like a copy to carry forward.

**Upgrade menu**

- Your CV, or confirmation of what your employer sells: R3 and R7 firm up and the presentation of R4 can be checked.
- Salesforce's certification verification page: R4 to `high`.
- Sanitised pipeline and renewal dashboard screenshots: R7 to `high`.
- A sanitised SQL query or workbook: R5 resolves one way or the other.
- Your location and pay floor: R1 and R2 become met or failed.
- The recruiter's answers on reporting line, team, options and where the role is listed: RR1 to RR4 close.
- A deeper research pass on Quillfield (funding and leadership changes, hiring patterns, candidate and employee reports, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

**Questions**

Q1 (R8b, G5): Have you reconciled renewal or pipeline figures with finance, or built reporting finance relied on? What was yours, and what happened?

Q2 (R6, G2): In your monthly pipeline review, do you call or adjust a forecast number such as commit or best case, or only present pipeline? Who signs the number off?

Q3 (R1, R2, G1): Does Bristol two days a week work for you, and is £61,500–£67,000 above your pay floor?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.