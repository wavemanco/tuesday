I'm midway through reading the skill's reference files so the assessment follows its required shape. I still need the evidence-model and question rules, and then I'll check the posting.
# Job Underwriting Assessment: Senior Data Engineer at Pellucid Learning

## Decision snapshot

**Yes, it's worth applying, but not yet unconditionally. Status: `conditional_go`.** R9 and R10 are hard gates I can't check, because you haven't given me your location, work eligibility or pay floor.

**Fit ledger.**

- `hard_gate` — unclear: R9 (Remote US or Denver), R10 (Salary $148,000–$166,000)
- `must_have` — direct: R1, R2, R3, R4a, R5, R6
- `important` — adjacent: R4b (BigQuery warehouse); unclear: R7 (Data contracts), R8 (Ingestion from app and CRM)

R4b — a credible bridge, its limit named; R7 and R8 — the background is silent, worth a question.

**Opportunity ledger.** Pay is stated and the register reads it as sound (RR1). Equity terms, team shape and success measures are unknown (RR2, RR3, RR4).

- **Hard gates:** none failed; unconfirmed: R9 (Remote US or Denver), R10 (Salary $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R9 and R10 confirmed against your own location, eligibility and pay floor; (2) the team and ownership question in RR3 gets a concrete answer; (3) BigQuery (R4b) is framed as adjacent experience and never as experience you have.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` company's own About page, fetched. The funding figure is the company's own statement; I did not check it independently |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` posting |
| Terms | 5+ years of experience, Remote (US) or Denver office, $148,000–$166,000 plus equity | `[grounded]` posting |
| Scope read | Looks like ownership of one domain's pipelines (app and CRM to warehouse to contracts), with no direct reports named | `[inferred]` from the posting's three responsibilities against the report's typical scope |
| Market calibration | The posting's range sits against the report's Series B–D senior base median of $151,000 and interquartile range of $139,000–$163,500. Its floor is just under the median and its ceiling is above the interquartile top. The posting's 5+ years and scope fit the report's typical 5–8 years and single-domain ownership with no reports. I see no seniority-pay mismatch. This band is a pattern (n=2,310), not this employer's offer | `[grounded]` posting figures and the recruiter's pasted report; `[generic]` the band as a role-family pattern |
| First-90-days and first-year outcomes | Not stated | `[grounded]` posting silent |
| Unknowns | Team size and reporting line; who decides the data contracts; equity terms; success measures; how much BigQuery ramp-up is expected | — |
| Contradictions | None. The careers page matches the pasted posting and reads "Accepting applications", and the About page matches the pasted company text | `[grounded]` both pages fetched |

## Evidence map

Your background is prose you typed, so it counts as self-report. Nothing reaches `high` until there's an inspectable artifact.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years at a B2B payroll company. That clears the stated minimum. It's confirmed and specific but has no inspectable artifact yet, so expect a probe | `[grounded]` your stated background | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | Stated as daily use. No sample is inspected yet | `[grounded]` your stated background | none |
| R3 | dbt | must_have | direct | medium | none | You built the dbt project, about 180 models, on Snowflake. Specific, but no artifact is inspected | `[grounded]` your stated background | A sanitized lineage graph or docs page would raise this to `high` |
| R4a | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse, so the requirement as written is met | `[grounded]` your stated background; `[grounded]` posting wording | none |
| R4b | BigQuery specifically | important | adjacent | medium | transferability | The posting names BigQuery as its warehouse. You have not used it, and you said so. Your dbt-on-Snowflake work carries over. The limit is that you have not exercised BigQuery's own cost, partitioning or access model. Name that limit wherever the bridge is used | `[grounded]` your statement of no BigQuery use; `[generic]` that dbt and SQL skills commonly carry across warehouses, with a ramp-up on the warehouse's own features; `[inferred]` requirement from the posting's "dbt-modelled warehouse in BigQuery" | See G1 |
| R5 | Orchestration with Airflow or similar | must_have | direct | medium | none | You state Airflow as your orchestrator. No DAG is inspected | `[grounded]` your stated background | A sanitized DAG excerpt would raise this to `high` |
| R6 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite, which is specific and on point. No artifact is inspected | `[grounded]` your stated background | A sanitized suite config or a coverage summary would raise this to `high` |
| R7 | Data contracts analysts depend on | important | unclear | low | discovery | Your background doesn't mention contracts. Your tests and dbt models may be adjacent evidence, but nothing confirms you defined agreements with consumers | `[grounded]` background silence | See G2 |
| R8 | Ingestion from the app and CRM | important | unclear | low | discovery | Your background doesn't say which sources you ingested, or how | `[grounded]` background silence | See G3 |
| R9 | Remote (US) or the Denver office | hard_gate | unclear | none | hard_gate | The posting states the terms. You haven't given your location or work eligibility, so I can't call the gate met | `[grounded]` posting terms; `[grounded]` no candidate statement | The one gate question below |
| R10 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | The posting states the pay. You haven't given a floor, so I can't say whether it clears | `[grounded]` posting figure; `[grounded]` no candidate statement | The one gate question below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R4b, important) | transferability | Dbt and Snowflake work, no BigQuery use | The posting names it, so a reader may probe the gap | A BigQuery trial or sandbox project; a dbt-bigquery adapter project run for learning | A small public sample project, clearly described as a personal exercise | `[grounded]` your statement of no BigQuery use; `[generic]` that the named warehouse is the likeliest probe |
| G2 | Data contracts (R7, important) | discovery | Silent on agreements with downstream consumers | It's a named responsibility, so what counts as a contract here matters | Schema or freshness agreements with analysts; dbt contract or test rules consumers relied on; change notices when a model's columns shifted | A sanitized contract doc, a dbt model YAML, or a changelog | `[grounded]` background silence |
| G3 | App and CRM ingestion (R8, important) | discovery | Silent on ingestion sources and tooling | Ingestion from these two sources is the first thing the mandate names | Loading product-event or CRM data (for example Salesforce or HubSpot) into the warehouse; building or maintaining a connector or sync | A pipeline diagram or ingestion DAG excerpt | `[grounded]` background silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay range stated and in line with the pasted report | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range is transparent and plausible for the seniority | `[grounded]` posting figure against the recruiter's report; `[generic]` that this is a transparent practice | Is the range tied to level, or negotiable within it? | noted |
| RR2 | Equity terms unstated | unknown | — | "plus equity" | The grant type, size and vesting may be unspecified because they are set per offer | `[generic]` that equity terms are commonly given at offer stage | What is the equity grant type, vesting schedule and approximate range for this level? | unresolved |
| RR3 | Team shape, reporting line and ownership unstated, with no hiring manager named | unknown | — | "Build and run the pipelines" | You may be one of a few engineers, or the only one, with decision rights over contracts unclear | `[inferred]` from the posting's silence on team and its three responsibilities | Who is on the data team, who would I report to, and who decides the data contracts with analysts? | unresolved |
| RR4 | No success measures for the first 90 days or year | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | The mandate may be defined by backlog more than by outcomes | `[inferred]` from the posting's silence on outcomes | What would success look like at 90 days and at 12 months? | unresolved |

## Application plan

Nothing here is final until you approve it. That covers every row and the advice in it. Each is proposed, and none adds a claim your evidence doesn't hold.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Surface your 180-model dbt project, the Airflow orchestration and the Great Expectations suite you set up as separate outcome lines, in the posting's own terms (dbt, orchestration, data quality testing) | See R3, R5, R6 | `[grounded]` your stated background | pending your approval |
| E2 | State Snowflake as your warehouse and BigQuery as new to you. Don't list BigQuery as a skill | See R4b | `[grounded]` your statement of no BigQuery use | pending your approval |
| W1 | Optional: a small personal dbt-on-BigQuery sample project, labelled as a learning exercise | See G1 | `[inferred]` from R4b's transferability gap | pending your approval |
| Q1 | Ask RR2, RR3 and RR4's questions with the recruiter before the loop, and again in interviews | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 0 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer) and "About Pellucid Learning" (pellucidlearning.com/about), checking your pasted text. Both match, and the posting reads "Accepting applications". Moved role reality's organization and contradictions rows, and the standing employer-not-established entry does not apply |
| 2. Role-family sweep | skipped | Your pasted Datawright report fixes market calibration and the mismatch check, the outputs this target feeds |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there was no query to form |

## Dossier offer

I can write this up as `tuesday-dossier.md` if you want a file to keep.

## Upgrade menu

- Your CV, or the prose background as a file → each `medium` row can be checked against what you actually wrote.
- A sanitized dbt lineage graph or docs page → R3 to `high`.
- A sanitized Airflow DAG excerpt → R5 to `high`.
- A sanitized Great Expectations config or coverage summary → R6 to `high`.
- Your answers on G2 and G3 → R7 and R8 resolve or move to a firm gap.
- Your location, eligibility and pay floor → R9 and R10 close, and the status likely moves to `go` or `no_go`.
- The recruiter's answers to RR2, RR3 and RR4 → the opportunity ledger closes.
- A hiring manager's name → role reality's scope read, and which story the plan leads with.
- A deeper pass on Pellucid Learning (funding and leadership changes, recent news; up to 5 more searches and 2 more fetches) → say the word and it runs.

## Questions

R9, R10 — Do this role's terms, Remote (US) or Denver and $148,000–$166,000 plus equity, fit your location, work eligibility and pay floor?

G2 — Have you defined or maintained agreements with analysts or other consumers about what a model's columns, freshness or tests guarantee? What did you own, and how were changes handled?

G3 — Which source systems did you ingest into your warehouse (product events, a CRM such as Salesforce or HubSpot), and what did you personally build?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.