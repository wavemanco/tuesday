I'll read the skill's reference files before building the assessment.
I'm checking whether Novaline is a verifiable employer and what the market pays for this role. Both searches run now.
# Job Underwriting — Head of Growth, Novaline

## Decision snapshot

**No, this isn't worth pursuing as posted. R1 and R2, both hard gates, fail. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (Base pay $70–85k plus equity), R2 (On-site Austin, five days a week)
- `must_have` — direct: R3 · unclear: R4 (SEO, brand, PR, partnerships, sales ops), R5 (8+ years growth leadership)
- `important` — unclear: R6 (Thrive on ambiguity), R7 (Team of one to start)

R4 — five channels outside what you described; R5 — leadership years not split out from the nine.

**Opportunity ledger.** Your "something feels off" has support in the posting itself. The terms conflict with both of your constraints (RR1, RR2). The seat bundles seven functions with no team, no stated success measures and an after-hours expectation (RR3, RR4, RR5). The employer is unverified (RR7). One signal runs the other way: the CEO reporting line (RR6).

- **Hard gates:** failed: R1 (Base pay $70–85k plus equity), R2 (On-site Austin, five days a week)
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`)
- **What would change this:** both gates would have to differ, with a base at or above your $150k floor and a remote arrangement from Portland. Neither can be solved by how you word an application. Whether to revise either constraint is your call.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, "Series A, profitable since day one". These are the posting's own claims, not checked | `[grounded]` posting header |
| Mandate | Own all revenue growth: paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Team and reporting | A team of one to start. Reports to the CEO, with a dotted line to the board | `[grounded]` posting |
| Hours | "evenings and weekends when it matters is just who we are" | `[grounded]` posting |
| Location | On-site in Austin, five days a week, "no exceptions" | `[grounded]` posting |
| Compensation | $70–85k base plus "meaningful equity upside". The equity amount and terms are unstated | `[grounded]` posting |
| First-90-days and first-year outcomes | None stated. The posting says success metrics "will evolve as we learn" | `[grounded]` posting |
| Scope read | Seven functions in one seat, with no bench, reads as several roles folded into one title and one salary | `[inferred]` from the function list against "team of one" and the stated band |
| Market calibration | Not calibrated. The role-family search was refused, so no market band appears here. The posting's figure is the only number in hand | `[grounded]` posting figure; no `[generic]` band available |
| Unknowns | Equity terms, budget, decision rights, success measures, headcount plan | — |
| Contradictions | None checked against a careers page, because that search was refused | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Base pay of $70–85k plus equity (against your $150k base floor) | hard_gate | hard_gate_fail | high | hard_gate | The top of the posted range is below your stated floor. The floor is on base, so unquantified equity does not close it. Confidence grades your own stated constraint | `[grounded]` posting quote and your stated floor | None. Wording cannot solve a pay gate |
| R2 | On-site in Austin five days a week (against your remote-only, Portland, no-relocation constraint) | hard_gate | hard_gate_fail | high | hard_gate | The posting says "no exceptions", and you will not relocate | `[grounded]` posting quote and your stated constraint | None. Wording cannot solve a location gate |
| R3 | Own paid acquisition and lifecycle/CRM | must_have | direct | medium | none | You owned paid, lifecycle and experimentation at two B2C subscription companies, with Braze named and a controlled budget through $8M to $40M ARR. It is confirmed and specific but has no inspectable artifact yet, so expect a probe | `[grounded]` your own account | A sanitized growth report or ARR dashboard would raise this to `high` |
| R4 | Own SEO/content, brand, PR, partnerships and sales ops | must_have | unclear | low | discovery | What you described does not mention these five. Silence is not absence | `[grounded]` silence in your description | See G1 |
| R5 | 8+ years of growth leadership | must_have | unclear | medium | discovery | You have 9 years in growth, with lead and then Head titles. It is not stated how many of those years were leadership. A years requirement is a risk, not a gate | `[grounded]` your account; the leadership split is not given | See G2 |
| R6 | Thrive on ambiguity, with metrics that evolve | important | unclear | low | discovery | Nothing you described speaks to this either way | `[grounded]` silence | See G3 |
| R7 | Operate as a team of one to start | important | unclear | low | discovery | You built and managed teams of 3–7. Working with no bench is not described | `[grounded]` your account; solo operation not stated | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Channels beyond paid and lifecycle (R4, must_have) | discovery | Nothing on SEO/content, brand, PR, partnerships or sales ops | It is the widest part of the mandate, but it cannot move the decision past the two gates | A content or SEO program you directed; a partnership or affiliate deal you closed; a launch with PR | A channel report, or a partner agreement summary | `[grounded]` silence in your description |
| G2 | Leadership years within the nine (R5, must_have) | discovery | 9 years in growth, but the split between individual-contributor and lead years is unknown | The posting's "8+ years" would be read literally | The start date of your first lead title and the team you led then | Dates on a CV or LinkedIn | `[grounded]` your account |
| G3 | Ambiguity and solo operation (R6, R7, important) | discovery | No example of building a function without a team | These are probe topics for a one-person seat | A function you started alone; a period when your goals shifted mid-year | A short account of how you set metrics | `[grounded]` silence; `[generic]` that this seat type probes these topics |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posted pay is below your stated floor | red_flag | high | "$70–85k base plus meaningful equity upside" | The posted band is incompatible with your base floor. This says nothing about the market | `[grounded]` posting quote and your stated floor | What is the base range for this role, and is it fixed? | confirmed |
| RR2 | On-site requirement conflicts with remote-only | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions." | The requirement is incompatible with your remote-only constraint | `[grounded]` posting quote and your stated constraint | Is the five-day on-site requirement fixed for this role? | confirmed |
| RR3 | Seven functions, one seat, no team | risk_signal | medium | "Own all revenue growth end to end: paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops. You will be a team of one to start" | Several full roles may be folded into one title at one salary. Severity is held at medium because this is a pattern, not a confirmed mismatch | `[generic]` bundled-specializations pattern; `[grounded]` quote | What budget and headcount are committed for the first 12 months? | unresolved |
| RR4 | After-hours expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | After-hours work may be routine rather than exceptional | `[inferred]` from "just who we are" | How often did the last person in a growth seat work evenings or weekends? | unresolved |
| RR5 | Accountability with no stated definition of success | risk_signal | medium | "success metrics will evolve as we learn" | You may be held to revenue outcomes with no agreed measure | `[inferred]` from "own all revenue growth" beside this quote | What does success look like at 90 days and at 12 months, and who sets it? | unresolved |
| RR6 | Senior reporting line | positive_signal | — | "Report to the CEO with a dotted line to the board" | Growth has CEO and board visibility. Decision rights over budget are still unknown | `[grounded]` posting quote | Which decisions, including budget, does this role make alone? | noted |
| RR7 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply on this posting as written | See R1, R2 | `[grounded]` R1, R2 rows | pending your approval |
| A2 | If you proceed anyway, ask RR1 and RR2's questions verbatim before investing any time, then RR3 to RR5 | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A3 | No resume edits or outreach language are proposed | The decision rests on terms, not presentation | `[grounded]` map | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Novaline e-commerce enablement startup Austin careers Head of Growth" was refused, so nothing was read. It would have moved the organization and contradictions rows and RR7 |
| 2. Role-family sweep | unavailable | The search "Head of Growth salary startup Series A base salary range 2026" was refused. It would have moved the market calibration line and RR3's hypothesis |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Dossier offer

I can save this assessment as `tuesday-dossier.md` if you want to keep it.

## Upgrade menu

- Granting search permission would let me re-run targets 1 and 2. That would settle RR7 and add a market band. It would not change `no_go`, which rests on R1 and R2.
- A sanitized growth report or ARR dashboard from the $8M to $40M scale-up would raise R3 to `high`.
- Which of SEO, brand, PR, partnerships or sales ops you have owned would resolve R4 (G1).
- The start date of your first lead title would resolve R5 (G2).
- Novaline's written pay and location terms would matter only if they differ from the posting.
- The hiring manager's name would let me read their public professional footprint for the scope read.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.