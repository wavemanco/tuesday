I'll read the reference files the skill points to before building the assessment.
Still preparing: I've read the skill's rules and will now check the company and pay band with a few searches. Then I'll write the assessment.
**Yes, it looks worth applying to, on two conditions: `conditional_go`.** Your background lines up with the posting's requirements. The two conditions are checks only you can make, your location and your pay floor. You haven't told me either, so they stay open (R1, R2).

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote US or Denver), R2 (Salary $148,000–$166,000)
- `must_have` — direct: R3, R4, R5, R6, R7
- `important` — adjacent: R8 (BigQuery warehouse); unclear: R9 (Ingestion from app and CRM), R10 (Data contracts for analysts)

R8 — a credible bridge with its limit named; R9, R10 — the posting names them and your background is silent, so they are open questions and not gaps.

**Opportunity ledger.** The employer and the live posting check out against its own pages (RR1), and the stated pay is competitive (RR2). Team size, reporting line, equity terms and whether pay varies by location are not stated (RR3, RR4, RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver), R2 (Salary $148,000–$166,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 are confirmed against your own location and pay floor, with RR5 settling whether the range moves by location; (2) BigQuery is presented as adjacent, never as experience (R8).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016 in Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` the company's own About page, fetched. Only the employer's own pages came back, so funding and headcount are the company's own statement and not independently confirmed |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from the app and CRM, a dbt-modelled warehouse in BigQuery, and data contracts for analysts | `[grounded]` JD |
| Stated requirements | 5+ years data engineering; strong SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Terms | $148,000–$166,000 plus equity; Remote (US) or Denver office | `[grounded]` JD |
| Hiring manager | Not named | `[grounded]` JD silent |
| Scope read | Three areas (ingestion, warehouse modelling, contracts) are named under one reporting purpose. Whether that is one domain or several, and who else works on the warehouse, is not stated | `[inferred]` from the JD's three named areas against its silence on team size |
| Market calibration | The Datawright 2026 report puts a Senior Data Engineer at Series B–D companies at a $151,000 median base, with an interquartile range of $139,000–$163,500. It describes "senior" as typically 5–8 years and scope as one domain's pipelines with no direct reports. The posting's low end is $3,000 below that median and its high end is $2,500 above the 75th percentile. Your 6 years sits inside the 5–8 range | `[generic]` the Datawright report (found by search, matching the copy your recruiter sent), a band and not this employer's offer; `[grounded]` the posting's own figures |
| Unknowns | Team size and reporting line; equity terms; whether pay varies between remote and Denver; the app and CRM source systems | — |
| Contradictions | None. The careers page is live ("Accepting applications") and its text matches what you pasted | `[grounded]` careers page, fetched |

## Evidence map

Your background was given in prose, so it counts as self-report: `medium` is the ceiling until an artifact is inspected.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You have not stated where you live or work from, so the term cannot be checked. No claim exists to grade | `[grounded]` JD term; your location not given | Closing question 1 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | You have not stated a pay floor. The posting's range is stated, but the gate depends on your number | `[grounded]` JD figure; your floor not given | Closing question 1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You stated 6 years at a B2B payroll company, which meets the stated minimum. The posting tiers years as a requirement, not a legal or credential gate. Confirmed in your message, with no inspectable artifact yet | `[grounded]` your stated background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You stated Python and SQL daily. "Strong" is the posting's word, and your sentence supports daily use, not a level | `[grounded]` your stated background | A code sample or repository would raise this to `high` |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | You built your company's dbt project on Snowflake, about 180 models. Snowflake is a cloud warehouse, so the stated requirement is met; the BigQuery detail is R8 | `[grounded]` your stated background | A sanitized project structure or model-lineage screenshot would raise this to `high` |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | You stated Airflow for orchestration. Your exact role in it (building, maintaining or using DAGs) was not stated | `[grounded]` your stated background | A sanitized DAG sample would raise this to `high` |
| R7 | Experience with data quality testing | must_have | direct | medium | none | You set up your company's Great Expectations test suite, which matches the requirement | `[grounded]` your stated background | A sanitized suite or checkpoint config would raise this to `high` |
| R8 | A dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | The posting names BigQuery in its mandate, and the requirements say "a cloud warehouse". Your dbt-on-Snowflake work carries over. It did not exercise BigQuery itself, so you have never used it. Funders of this kind often differ in cost and partitioning models between warehouses, so expect a probe | `[grounded]` your stated Snowflake work and no BigQuery use; `[generic]` that warehouse differences are a common interview probe | See gap G1; a small dbt-on-BigQuery project would narrow the limit |
| R9 | Ingestion from the app and CRM | important | unclear | low | discovery | You described orchestration and dbt but not the source systems you ingested from. Payroll products have app and CRM-style sources, so evidence may exist but is not stated | `[grounded]` your background is silent on sources; `[inferred]` that it may exist | See gap G2 and closing question 2 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | Your Great Expectations suite is related, but a contract (an agreed schema or freshness guarantee with downstream users) was not mentioned, so I am not treating it as direct | `[grounded]` your background is silent on contracts; `[inferred]` the Great Expectations link | See gap G3 and closing question 3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8, important) | transferability | Confirmed dbt-on-Snowflake work, about 180 models; no BigQuery use | The one named technology you have not used; stating the limit plainly reads stronger than hiding it | Any BigQuery use at all, including a personal or side project, a migration you assisted, or a dbt adapter you configured | A small public dbt project run against BigQuery, or a short note on how your Snowflake choices map to BigQuery | `[grounded]` your background; `[generic]` that a stated limit holds up better than a hidden one |
| G2 | App and CRM ingestion (R9, important) | discovery | Airflow and dbt established; the source systems you ingested from are not stated | The mandate leads with ingestion, so which sources you handled decides how direct this row is | Loading data from a product database or event stream; pulling from a CRM or similar SaaS API; an ingestion tool or custom connector you set up | A pipeline diagram, a DAG listing sources, or a README | `[grounded]` your background silent on sources |
| G3 | Data contracts (R10, important) | discovery | A Great Expectations suite is established; any agreement with analysts on schema, freshness or ownership is not | The posting names contracts that "analysts depend on", so an agreement you held with downstream users would count | A schema or freshness guarantee you agreed with analysts; a documented ownership or alerting arrangement; breaking-change handling in dbt | A contract document, a dbt model config with tests, or a runbook | `[grounded]` your background silent on contracts |
| G4 | Location and pay terms (R1, R2, hard_gate) | hard_gate | Terms stated in the JD; your location and floor not given | These are the gates the decision hinges on | Not applicable: this is a yes/no on your own constraints, not a recall prompt | Nothing to attach | `[grounded]` constraints not given |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting established and consistent | positive_signal | — | "Accepting applications. Senior Data Engineer — Pellucid Learning." | The employer exists as described and the posting is live | `[grounded]` the company's own About and careers pages, fetched | Is this a new role or a backfill, and when did it open? | noted |
| RR2 | Pay stated and in line with the role-family band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | A stated range lets you plan against it; it sits near the top of the market band | `[grounded]` the posting's figures; `[generic]` the Datawright band | Where in the range would you expect to offer for my background? | noted |
| RR3 | Team size and reporting line not stated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | The role may be the sole data engineer or one of several, which changes the scope | `[inferred]` from the JD's silence on team and manager | How large is the data team, who does this role report to, and who else owns the warehouse? | unresolved |
| RR4 | Equity terms unstated | unknown | — | "plus equity" | Equity could be options or shares, with vesting and strike unknown, so its value cannot be assessed from the posting | `[inferred]` from the JD naming equity without terms | What form does the equity take, and what are the vesting terms and current strike or valuation? | unresolved |
| RR5 | Pay may vary by location | unknown | — | "Remote (US) or our Denver office" | One range is quoted for two locations; the employer may adjust pay by location | `[inferred]` from the posting giving one range for two work modes | Does the range depend on where I work from, remote or Denver? | unresolved |

## Application plan

Everything in this section is proposed, nothing applied: the resume edits are `resume_edits_pending_approval`, and each other row carries its own approval status.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Summary line: "Six years of data engineering at a B2B payroll company; Python and SQL daily." | R3, R4; every clause is your own sentence | `[grounded]` your stated background | pending your approval |
| E2 | Bullet: "Built our dbt project on Snowflake — about 180 models." | R5; your wording, with nothing added | `[grounded]` your stated background | pending your approval |
| E3 | Bullet: "Set up our Great Expectations test suite." | R7; your wording, with nothing added | `[grounded]` your stated background | pending your approval |
| E4 | Tools line: "Airflow for orchestration" | R6; kept at your wording because your exact role in it is unconfirmed | `[grounded]` your stated background | pending your approval |
| P1 | Positioning on BigQuery: say plainly that your warehouse work is dbt on Snowflake and you have not used BigQuery yet, then name the specific parts that carry over | R8; an adjacent bridge with its limit named holds up better in an interview than a hidden gap | `[grounded]` R8; `[generic]` on how interviewers treat a stated limit | pending your approval |
| A1 | Confirm with the recruiter whether the range varies by location, and ask about equity terms | RR5, RR4, R2 | `[grounded]` register | pending your approval |
| Q1 | Ask the verification questions in RR1 to RR5 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| W1 | Optional: a small dbt project run against BigQuery as a work sample. It would be a sample and never presented as BigQuery experience | R8, G1 | `[inferred]` from R8's limit | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning online tutoring K-12 Denver Series C", which returned "About Pellucid Learning" (pellucidlearning.com/about); fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer). It confirmed the posting is live and matches what you pasted, and moved role reality's organization and contradictions rows. No failed-attribution entry is raised |
| 2. Role-family sweep | yes | Searched "Senior Data Engineer salary 2026 Series B-D median base dbt BigQuery", which returned "Datawright 2026 Data Engineering Pay Report" (datawright.example/2026-data-engineering-pay-report), matching the figures your recruiter sent. It moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there was no query to form. A name would feed role reality's scope read and which story the plan leads with |

## Dossier offer

I can write this up as a `tuesday-dossier.md` you can keep or reuse, whenever you want it.

## Upgrade menu

- Your location and pay floor → R1 and R2 close, and the decision likely moves to `go` or `no_go`.
- A sanitized DAG, dbt project structure, test suite config or code sample → R4, R5, R6 and R7 rise to `high`.
- Any BigQuery use, including a side project → G1 and R8 strengthen.
- Detail on source systems and any analyst agreements → R9 and R10 resolve.
- The hiring manager's name → role reality's scope read, and which story the plan leads with.
- A deeper research pass on Pellucid Learning (funding, leadership changes, hiring patterns, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

## Questions

1. G4 — Where do you live or plan to work from (US remote, or Denver), and what is your pay floor? Do the posting's terms meet both? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
2. G2 — Did you ingest data from a product database, event stream, CRM or similar SaaS API? What did you own, and what did the pipeline feed? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
3. G3 — Did you agree any schema, freshness or ownership guarantee with analysts or other downstream users, and how was it enforced or documented? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.