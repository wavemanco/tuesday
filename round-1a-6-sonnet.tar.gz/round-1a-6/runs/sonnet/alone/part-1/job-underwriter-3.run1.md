I'll read the reference files the skill points to before building the assessment.
## Decision snapshot

**No, this isn't worth pursuing as posted. R1 and R2, both hard gates, fail on the posting's own terms. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (Compensation $70–85k base), R2 (On-site in Austin, 5 days a week)
- `must_have` — direct: R3, R4, R5, R6
- `important` — unclear: R7 (SEO/content), R8 (Brand and PR), R9 (Partnerships), R10 (Sales ops), R11 (Team of one)

R1, R2 — the terms conflict with your two non-negotiables, and wording can't fix that; R4 (`medium`) — the $8M-to-$40M story, confirmed in prose and waiting on an artifact; R7, R8, R9, R10 — nothing in what you've told me touches them.

**Opportunity ledger.** The scope is seven functions with no team, an unstated budget and unstated metrics, which is what RR1, RR2 and RR4 record. RR3 records the always-on language. The employer could not be established from here (RR6). The CEO reporting line and the "profitable" claim are the only entries running the other way (RR7).

- **Hard gates:** failed: R1 (Compensation $70–85k base), R2 (On-site in Austin, 5 days a week).
- **Severe red flags:** none found.
- **What would change this:** the employer would have to offer a base at or above $150k and a remote arrangement from Portland, and RR6 would have to verify. Your fit is not what's holding the status down.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` posting header; stage and profitability are the posting's own claims, unchecked (RR6) |
| Mandate | Own revenue growth end to end: paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Reporting | CEO, with a dotted line to the board | `[grounded]` posting |
| Team and budget | "A team of one to start"; no budget stated | `[grounded]` posting |
| Working pattern | On-site Austin, 5 days, "no exceptions"; evenings and weekends "when it matters" | `[grounded]` posting |
| Compensation | $70–85k base plus unquantified "meaningful equity upside" | `[grounded]` posting |
| Success metrics | None stated; "will evolve as we learn" | `[grounded]` posting |
| First-90-days outcomes | Not stated and not derivable from the posting | `[inferred]` from the posting's silence |
| Scope read | Seven functions that are usually separate specialisms, handed to one person, with a title and years requirement that sit at the senior end | `[inferred]` from the function list against "team of one" and "8+ years" |
| Market calibration | Not established. The salary search was refused, so I won't put a market figure on this role. | `[grounded]` search refused; nothing substituted |
| Unknowns | Budget, equity size and terms, how "dotted line to the board" works in practice, headcount plans | — |
| Contradictions | None found within the posting; the careers page was not checked | `[grounded]` posting only |

## Evidence map

Your background was given in prose, so everything below is self-report. `medium` is the ceiling for it, except your own stated constraints.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Compensation: $70–85k base (your floor: $150k base) | hard_gate | hard_gate_fail | high | hard_gate | The confidence grades your statement of the floor, which is specific and yours. The top of the posted range is well under your floor, so the gate fails. | `[grounded]` posting and your stated floor | Only the employer changing the pay resolves it |
| R2 | On-site in Austin 5 days a week, "no exceptions" (you: remote-only, in Portland, not relocating) | hard_gate | hard_gate_fail | high | hard_gate | The confidence grades your stated constraint. The posting rules out remote work in terms and you rule out relocating, so the gate fails. | `[grounded]` posting and your stated constraint | Only the employer changing the terms resolves it |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | You state 9 years in growth, with growth lead and Head of Growth titles. How many of those years were in titled leadership isn't stated, so the lead-title portion is unconfirmed. Years of experience are graded as fit, not as a gate. `[generic]` Posted year counts like this are often screened literally. | `[grounded]` your summary; `[generic]` screening note | Confirm your titled-leadership years if you pursue it |
| R4 | Own revenue growth end to end | must_have | direct | medium | none | You scaled one company from $8M to $40M ARR over three years with a budget you controlled. That is specific and plausible, but there is no inspectable artifact yet. | `[grounded]` your summary | A sanitized growth model or board-deck excerpt would raise it to `high` |
| R5 | Paid acquisition | must_have | direct | medium | none | You state that you owned paid at two B2C subscription companies. | `[grounded]` your summary | A channel P&L or budget-allocation view would raise it |
| R6 | Lifecycle/CRM | must_have | direct | medium | none | You state that you owned lifecycle and are deep in Braze. | `[grounded]` your summary | A journey map or retention readout would raise it |
| R7 | SEO and content | important | unclear | none | discovery | Nothing in your summary covers SEO or content. The gap is not yet classified as a capability gap, because it hasn't been explored. | `[grounded]` your summary's silence | Only worth exploring if the gates move |
| R8 | Brand and PR | important | unclear | none | discovery | Your summary is silent on both. | `[grounded]` your summary's silence | As R7 |
| R9 | Partnerships | important | unclear | none | discovery | Your summary is silent. | `[grounded]` your summary's silence | As R7 |
| R10 | Sales ops | important | unclear | none | discovery | Your summary is silent. | `[grounded]` your summary's silence | As R7 |
| R11 | Operating as a team of one | important | unclear | low | discovery | You built and managed teams of 3–7. Executing every channel yourself with no support is a different exercise, and you haven't described it. | `[grounded]` your summary's team sizes; `[inferred]` that managing differs from solo execution | As R7 |

## Gap recovery queue

The queue holds no questions. Every row here matters only if R1 and R2 move.

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content, brand/PR (R7, R8; important) | discovery | Your summary covers paid, lifecycle and experimentation and says nothing on organic or earned channels | The posting bundles them into one mandate, so they are part of what "end to end" means here | An SEO or content programme you commissioned or directed; a launch or press push you ran or scoped; brand-spend decisions you made | A content-performance report, a launch brief, a channel mix review | `[grounded]` summary silence; `[inferred]` that they'd be probed as part of "end to end" |
| G2 | Partnerships, sales ops (R9, R10; important) | discovery | Nothing stated on either | The posting lists both with no team to hand them to | Affiliate or referral deals; co-marketing; working with a sales team on lead routing or attribution; CRM-to-revenue reporting | A partner programme doc, an attribution setup, a pipeline dashboard | `[grounded]` summary silence |
| G3 | Solo execution (R11; important) | discovery | Team management is evidenced; being the only hands is not | The posting says "team of one to start" | A period where you ran several channels yourself; a zero-to-one launch with no support staff | A before/after of a launch you ran alone | `[grounded]` your team sizes; `[inferred]` the limit |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay below your floor, with a seniority and scope that may not be priced to match (R1) | red_flag | medium | "$70–85k base plus meaningful equity upside" | The pay may sit below what a senior, seven-function mandate usually carries. A market search was refused, so this is unconfirmed. Severity stays at the lower value for that reason. | `[generic]` pattern for bundled senior mandates, not a claim about this employer | What is the budgeted base for this role, and is it flexible? How is the equity sized and structured? | unresolved |
| RR2 | Several specialisms folded into one title | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops" | One person may be accountable for outcomes across roles that are usually separate. | `[generic]` bundled-specialization pattern | What does a successful first year look like, and what hires or agency budget are planned? | unresolved |
| RR3 | Always-on expectations | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Extra hours may be a standing expectation rather than an exception. | `[generic]` always-on pattern | How often did the team work evenings or weekends in the last quarter? | unresolved |
| RR4 | Demanding mandate with no stated success measures | risk_signal | medium | "success metrics will evolve as we learn" | You may be accountable to the CEO and the board with no agreed definition of success. | `[inferred]` from the posting's reporting line against its silence on metrics | Which numbers will I be judged on in the first six and twelve months? | unresolved |
| RR5 | Responsibility without stated budget or authority | unknown | — | "a team of one to start — we believe in players who don't need a bench" | Spend and hiring authority are not described. | `[inferred]` from the posting's silence | What budget and hiring authority does this role hold? | unresolved |
| RR6 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR7 | Senior reporting line | positive_signal | — | "Report to the CEO with a dotted line to the board" | The role sits close to decision-makers. | `[grounded]` posting | Who sits on the board, and how often would I present to them? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply as posted | R1 and R2 fail, and the posting says "no exceptions" on location | `[grounded]` posting and your constraints | proposed |
| A2 | Only if you want to test flexibility: ask the employer through a contact on its own website whether remote work and a base at or above $150k are possible, before any application effort | Only the employer changing terms can clear R1 or R2, and the posting's "no exceptions" makes remote the likelier refusal | `[inferred]` from the posting's wording | pending your approval |
| A3 | If a flexed offer ever appears, put RR1–RR5's verification questions to the employer verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A4 | Spend the effort on openings that are remote and pay at or above your floor | Your paid, lifecycle, experimentation and scale evidence (R4, R5, R6) is the strong part of your profile | `[grounded]` map rows | proposed |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Austin Head of Growth careers"; the call was refused (search permission not granted). It would have moved RR6, and with it whether the posting is live and matches the pasted text. |
| 2. Role-family sweep | unavailable | Searched "Head of Growth salary Series A startup 2026 base salary range"; the call was refused. It would have moved the market calibration row and RR1's severity. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |

## Upgrade menu

- A link to the live posting or Novaline's careers page → RR6 can close or stay open, and role reality's contradictions row gets checked.
- Search permission → targets 1 and 2 can run, setting the posted base against a market band and checking whether the employer exists as described.
- Any statement from the employer on pay or remote work → R1 and R2 can move, and the status with them.
- Your titled-leadership years, and any SEO, brand/PR, partnership or sales-ops history → R3 firms up and R7–R10 stop being blank.
- A sanitized growth model or board-deck excerpt → R4 to `high`.
- The hiring manager's name → role reality's scope read and which story the application plan leads with.

I can write all of this up as `tuesday-dossier.md` if you want a copy to keep or reuse. I'd skip it unless you expect Novaline to come back with different terms.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.