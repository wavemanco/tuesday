I'll read the skill's reference files before building the assessment.
**No. As posted, R1 and R2, your two hard constraints, both fail. Status: `no_go`.**

## Decision snapshot

**Fit ledger.**

- `hard_gate`: hard_gate_fail: R1 (Base pay $70–85k), R2 (On-site Austin five days a week)
- `must_have`: direct: R4, R5, R6 · unclear: R3 (8+ years growth leadership)
- `important`: unclear: R7 (SEO/content), R8 (Brand, PR, partnerships, sales ops), R9 (Team of one)

R4, R5, R6: your paid, lifecycle and $8M-to-$40M scaling work reads directly against the posting; R3, R7, R8, R9: your intake is silent on these, which is not the same as a no.

**Opportunity ledger.** RR1 and RR2 are confirmed conflicts with your constraints. RR3, RR4, RR5 and RR6 are unresolved risk signals, and they are what is probably making this feel off. The posting asks one person to run many functions with no stated team, budget or success measure. RR7 runs the other way. RR8 is the standing check on whether the employer exists as described, and it could not be run.

- **Hard gates:** failed: R1 (Base pay $70–85k), R2 (On-site Austin five days a week)
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`)
- **What would change this:** the base would have to be at or above your $150k floor (R1), and the Austin on-site rule would have to give way to remote from Portland (R2). Both would have to differ. The posting says "no exceptions" on location, so wording on your side cannot close either gate.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an "e-commerce enablement startup, Series A, profitable since day one". These are the posting's own claims, and none has been verified | `[grounded]` JD header; verification not run |
| Title and seniority | Head of Growth, reporting to the CEO "with a dotted line to the board"; "8+ years growth leadership required" | `[grounded]` JD |
| Mandate | "Own all revenue growth end to end": paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` JD |
| Team and resources | "A team of one to start"; no budget or headcount plan stated | `[grounded]` JD for the quote; `[inferred]` for the budget silence |
| Working pattern | "Evenings and weekends when it matters is just who we are"; on-site Austin, 5 days a week, "no exceptions" | `[grounded]` JD |
| Compensation | "$70–85k base plus meaningful equity upside"; equity is not quantified | `[grounded]` JD |
| Success metrics | "Success metrics will evolve as we learn"; no first-90-day or first-year outcomes stated | `[grounded]` JD |
| Market calibration | Not available. The role-family search was refused, so no band is given and nothing is set against the stated pay | `[grounded]` search refused; no `[generic]` band offered |
| Unknowns | Budget, headcount after "to start", equity terms, how success will be measured | `[inferred]` from the JD's silence |
| Contradictions | A "Head of" title and an 8+ year bar sit beside a team of one and a base range that stops short of your floor. Nothing could be checked against the company's careers page | `[inferred]` from the JD's own terms; careers page not checked |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Base pay: "$70–85k base" | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own stated floor ("at least $150k base"), which is specific and confirmed. Fit fails because the posted range tops out below it | `[grounded]` JD quote and your stated constraint | None. Only the employer changing the range resolves it |
| R2 | Location: "On-site in our Austin office 5 days a week — no exceptions" | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your statement that you are remote-only, live in Portland and will not relocate. Fit fails because the posting rules out remote work in terms | `[grounded]` JD quote and your stated constraint | None. Only the employer changing the terms resolves it |
| R3 | "8+ years growth leadership" | must_have | unclear | medium | discovery | You gave 9 years in growth and roles as growth lead, then Head of Growth. How many of those years were in lead or head roles is not stated, so this resolves downward until you say. A years-of-experience requirement is not a gate | `[grounded]` your intake; `[inferred]` that the leadership years are unconfirmed | Confirm the years in lead and head roles, if the gates ever move |
| R4 | Paid acquisition | must_have | direct | medium | none | You said you owned paid at both companies. Confirmed and specific, but intake prose has no inspectable artifact yet, so `medium` | `[grounded]` your intake | None |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You said you owned lifecycle and are deep in Braze. Same ceiling: confirmed, with no inspectable artifact yet | `[grounded]` your intake | None |
| R6 | Own revenue growth end to end | must_have | direct | medium | none | Your wording: scaled one company from $8M to $40M ARR over three years with a budget you controlled. The scope of your ownership within that growth is not stated, so I carry only your words | `[grounded]` your intake | An ARR or board-report excerpt would raise this to `high` |
| R7 | SEO/content | important | unclear | low | discovery | You listed paid, lifecycle and experimentation, with no SEO or content work. Silence, not absence | `[grounded]` intake silence | Raise only if R1 and R2 change |
| R8 | Brand, PR, partnerships and sales ops | important | unclear | low | discovery | Nothing in your intake touches these. They are left for the same reason as R7 | `[grounded]` intake silence | Raise only if R1 and R2 change |
| R9 | Work as "a team of one to start" | important | unclear | low | discovery | You built and managed teams of 3–7. Whether you have run growth with no team is not stated | `[grounded]` your intake | Raise only if R1 and R2 change |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content and R8's brand, PR, partnerships, sales ops (R7, R8, important) | discovery | Intake covers paid, lifecycle and experimentation only | It would matter only if R1 and R2 changed, because the decision rests on the gates | Channel work you owned or inherited; launches with partners; any content program tied to growth | A channel report or program brief | `[grounded]` intake silence; `[inferred]` that closing this cannot move the status |
| G2 | Years in lead and head roles (R3, must_have) | discovery | 9 years in growth, with titles but no durations for the lead roles | The posting's bar is 8+ years of leadership, and the split decides whether R3 is direct | Dates for the growth lead and Head of Growth roles | Titles and dates on a CV or profile | `[grounded]` intake; `[inferred]` that it matters only if the gates change |
| G3 | Solo operation (R9, important) | discovery | Managed teams of 3–7; no stated stretch without a team | The posting starts you as a team of one | Any stretch running growth alone at either company | A short role description | `[grounded]` intake; `[inferred]` as above |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay below your floor (see R1) | red_flag | high | "$70–85k base plus meaningful equity upside" | The posted base cannot meet a $150k floor, and the equity has no stated terms to weigh against it | `[grounded]` JD against your stated floor | Is the $70–85k base fixed, and what does the equity consist of? | confirmed |
| RR2 | On-site rule against remote-only (see R2) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | The role cannot be done from Portland on the posting's terms | `[grounded]` JD against your stated constraint | Is the five-day on-site requirement open to any change for this role? | confirmed |
| RR3 | Possible seniority-compensation mismatch | risk_signal | medium | "8+ years growth leadership required" beside "$70–85k base" | The range may sit below what the seniority and "Head of" title would command | `[inferred]` from the posting's own figures; no market band sourced, so unconfirmed | How was the base range set for a role with this seniority? | unresolved |
| RR4 | Many functions, no team or stated budget | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops. You will be a team of one to start" | The role may carry accountability without the headcount or budget to deliver it | `[inferred]` from the JD's scope against its silence on resources; `[generic]` that bundled specializations are a recognised posting pattern | What budget and headcount are committed, and what comes after "to start"? | unresolved |
| RR5 | No definition of success | risk_signal | medium | "success metrics will evolve as we learn" | Accountability for revenue growth with no agreed measure | `[inferred]` from the JD's own wording | What will be measured in the first year, and who decides? | unresolved |
| RR6 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | An open-ended after-hours expectation. You gave no schedule constraint, so this is a risk signal, not a gate | `[inferred]` from the JD; `[generic]` that this phrasing signals always-on norms | How often have evenings and weekends been needed in the last year? | unresolved |
| RR7 | Senior reporting line | positive_signal | — | "Report to the CEO with a dotted line to the board" | The seat has CEO access, which suggests real standing | `[grounded]` JD; the claim itself is unverified | Which decisions does this role make without CEO sign-off? | noted |
| RR8 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply to this posting as written | R1 and R2 both fail and the posting closes off one of them in terms | `[grounded]` R1, R2 rows | pending your approval |
| A2 | If you still want to test the terms, ask the employer the RR1 and RR2 questions verbatim before investing any time | They are the only facts that could reopen the decision | `[grounded]` register | pending your approval |
| A3 | Filter future postings on remote and a stated base at or above $150k first, then check the role's scope | Your two gates settle most postings before fit does | `[grounded]` your stated constraints | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Austin Series A"; the call was refused. It would have fed the organization and contradictions rows and RR8 |
| 2. Role-family sweep | unavailable | Searched "Head of Growth salary range Series A startup 2026 base compensation"; the call was refused. It would have fed the market calibration row and RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I'd offer to save this as `tuesday-dossier.md` if you want to keep or reuse it.

**Upgrade menu**

- Permission to run the two refused searches: the market calibration row and RR3 get a sourced band, and RR8 can be checked.
- A link to the live posting or Novaline's careers page: contradictions and RR8 close.
- Your growth-lead and Head of Growth dates: R3 resolves.
- An ARR or board-report excerpt behind the $8M-to-$40M scaling, a Braze program summary or a paid-channel report: R6, R5 and R4 can rise to `high`.
- The hiring manager's name: the role-reality scope read and the application plan can account for that reader.
- A deeper pass on Novaline (up to 5 more searches and 2 more fetches): say the word. It cannot move the `no_go`, so I'd run it only if you want the company checked for its own sake.

No questions this turn: nothing I could ask would move R1 or R2.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.