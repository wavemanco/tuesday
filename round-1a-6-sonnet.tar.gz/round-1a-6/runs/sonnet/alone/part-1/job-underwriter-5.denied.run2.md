I'll read the skill's reference files before building the assessment.
The JD and company text are pasted, so I'll make a quick check that they're live and match the company's own pages. That is the only research target the pasted inputs don't already settle.
## Decision snapshot

**Yes, this looks worth applying to, on conditions. R1 and R2 are hard gates I can't check against your limits yet, and the employer is unverified (RR1). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote (US) or Denver), R2 (Salary $148,000–$166,000 plus equity)
- `must_have` — direct: R3, R4, R5, R6, R7, R8
- `important` — adjacent: R9 (dbt-modelled warehouse in BigQuery) · unclear: R10 (ingestion from app and CRM), R11 (data contracts analysts depend on)

R9 — a credible bridge from Snowflake, its limit named; R10, R11 — nothing in what you've told me yet, so they are open questions, not negatives.

**Opportunity ledger.** The stated terms look sound: pay sits inside the market band (RR5), scope is concretely named (RR6), and the raise is recent (RR7). The open items are the unverified employer (RR1) and three unknowns: the manager and team (RR2), the equity terms (RR3) and on-call expectations (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm R1 and R2 are met against your own limits; (2) RR1 clears, meaning the posting is live on the company's own careers page; (3) BigQuery is framed as adjacent (R9), never as BigQuery experience.
- **What would flip it:** if R1 or R2 fails and the terms can't move, the status becomes `no_go`, however strong the fit elsewhere.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026). Not checked against the company's own pages, because both fetches were refused | `[grounded]` pasted about-page text |
| Mandate | Build and run the pipelines behind reporting: ingestion from app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts analysts depend on | `[grounded]` JD |
| Requirements | Must-have: 5+ years data engineering, strong SQL and Python, dbt and a cloud warehouse, Airflow or similar, data quality testing. Preferred: none stated. Implied by the responsibilities: ingestion work and data contracts (R10, R11) | `[grounded]` JD; `[inferred]` for the implied pair, from the mandate sentence |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Compensation | $148,000–$166,000 plus equity; the equity terms are not stated | `[grounded]` JD |
| Scope read | One domain's pipelines (reporting), no direct reports mentioned, which matches the report's typical scope | `[inferred]` from the JD's silence on reports, set against the pasted report's scope line |
| Market calibration | Report: Senior Data Engineer at Series B–D companies, base median $151,000, interquartile range $139,000–$163,500, "Senior" typically 5–8 years. The range's floor sits $3,000 below the median and its ceiling $2,500 above the upper quartile. The report is what to expect, never this employer's offer, and it assumes the posting's "salary" means base | `[grounded]` pasted Datawright 2026 report (n=2,310, supplied by your recruiter) and JD; `[inferred]` the comparison and the base assumption |
| First 90 days and first year | Not stated. The earliest ramp is probably learning the BigQuery warehouse and the existing dbt models before owning ingestion | `[inferred]` from the JD naming BigQuery as the warehouse |
| Unknowns | Hiring manager and team size; equity instrument and vesting; on-call expectations; first-year outcomes; whether "Remote (US)" carries state restrictions | `[grounded]` JD silence |
| Contradictions | None between the pasted JD and the pasted company text; neither was checked against the live site | `[grounded]` pasted text only |

## Evidence map

I worked from your typed background, which counts as self-report, so `medium` is the ceiling for now.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you'd work from. Confidence grades your statement of the constraint, and none was given | `[grounded]` JD term; no candidate constraint supplied | Answer G1 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | Your pay floor wasn't given. The range sits inside the pasted market band, which says nothing about your floor | `[grounded]` JD range; no candidate constraint supplied | Answer G2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You stated 6 years of data engineering at a B2B payroll company. Self-reported, no dates or titles inspected | `[grounded]` your background | CV with dates would confirm |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. "Strong" is a level, and nothing inspectable shows it yet | `[grounded]` your background | A sanitized SQL or Python sample would raise it |
| R5 | dbt | must_have | direct | medium | none | You built your company's dbt project on Snowflake, about 180 models. "About" is kept; your share versus the team's isn't stated | `[grounded]` your background | A dbt docs lineage page or sanitized project listing would raise it |
| R6 | A cloud warehouse | must_have | direct | medium | none | The JD says "a cloud warehouse" and Snowflake is one. BigQuery is a separate row (R9) | `[grounded]` JD wording and your background | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | You use Airflow for orchestration. DAG count and ownership aren't stated | `[grounded]` your background | A sanitized DAG view would raise it |
| R8 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite. Coverage and what it caught aren't stated, so "set up" is as far as the claim goes | `[grounded]` your background | A checkpoint config or data docs page would raise it |
| R9 | dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | Bridge: the dbt modelling and SQL work carries over. Limit: you have not used BigQuery, so its cost model, partitioning and dbt adapter specifics are untested. Medium, taking the lower band of the Snowflake claim and the inferred bridge | `[inferred]` bridge from your Snowflake dbt work; `[generic]` that warehouses differ in dialect and cost model | A small dbt project on BigQuery (W1) would narrow the limit |
| R10 | Ingestion from app and CRM | important | unclear | low | discovery | Airflow work implies pipelines, but your sources aren't stated. This is a gap in what I know, not a negative | `[inferred]` from the Airflow claim; JD responsibility | Answer G3 |
| R11 | Data contracts analysts depend on | important | unclear | low | discovery | Your Great Expectations suite and dbt tests are nearby, but agreed schemas or SLAs with consumers aren't stated, so I'm not treating them as the same | `[inferred]` from the GE suite; JD responsibility | Answer G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Where you'd work from (R1, hard_gate) | hard_gate | Nothing on your location against "Remote (US) or our Denver office" | A failed gate caps the status however strong the fit | — | — | `[grounded]` JD term; `[grounded]` no constraint supplied |
| G2 | Pay floor (R2, hard_gate) | hard_gate | The range is stated; your floor isn't | A floor above $166,000 would fail the gate | — | — | `[grounded]` JD range; no floor supplied |
| G3 | Ingestion from app and CRM (R10, important) | discovery | Pipelines implied, sources unstated | It is the first named responsibility, so it is likely to be probed | Loading product-database tables; syncing a CRM or billing API; a managed connector or custom extract jobs | A sanitized DAG, an ingestion README, a source-to-table diagram | `[grounded]` your background silent on sources; `[generic]` that the first-named duty gets probed |
| G4 | Data contracts (R11, important) | discovery | Tests exist; agreed guarantees with consumers aren't stated | It is named as what analysts depend on, so evidence either way shapes your pitch | Agreeing column definitions or freshness expectations with analysts; versioned or documented table interfaces; alerting analysts when a test failed | Contract or schema docs, a freshness SLA, a test-failure runbook | `[grounded]` your background silent; `[generic]` for the practice's usual elements |
| G5 | BigQuery (R9, important) | transferability | dbt and SQL on Snowflake; no BigQuery | The posting names it as the warehouse; the bridge narrows the likeliest objection | Adjacent: dbt models, incremental builds, warehouse cost tuning on Snowflake | A small public dbt-on-BigQuery project | `[inferred]` bridge; `[generic]` that this is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources; the check did not run | risk_signal | medium | "Founded 2016, Denver. 264 employees. Series C ($52M, February 2026)." | Both fetches were refused, so nothing is checked against the company's own pages. The posting may be stale, the pasted text may differ from the live page, or the employer may not be as described; none is more likely from what I have | `[generic]` pattern for a pasted posting not yet checked, not a claim about this company | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Hiring manager, team and first-year outcomes not named | unknown | — | "The posting names no hiring manager" | The role may report into a larger data team or be a team of one | `[grounded]` JD silence | Who would I report to, how large is the data team, and what should be delivered in the first year? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "$148,000–$166,000 plus equity" | The equity may be options or RSUs, with vesting and valuation unknown | `[grounded]` JD states "plus equity" only | What form is the equity, roughly how much, on what vesting schedule, and at what current valuation? | unresolved |
| RR4 | On-call expectations unstated against "build and run" | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | "Run" may include an on-call rotation | `[inferred]` from the verb "run" against the JD's silence | Is there an on-call rotation for pipeline failures, and how often are people paged? | unresolved |
| RR5 | Pay range sits inside the market band | positive_signal | — | "$148,000–$166,000 plus equity" | No seniority-compensation mismatch against the pasted report: the median is $151,000 and the interquartile range $139,000–$163,500 | `[grounded]` JD and pasted report; `[inferred]` the comparison | Is the range base only, and is there a bonus on top? | noted |
| RR6 | Scope concretely named | positive_signal | — | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts our analysts depend on" | The mandate is specific and one domain, with no direct reports mentioned | `[grounded]` JD | What does the current BigQuery and dbt project look like today? | noted |
| RR7 | Recent funding | positive_signal | — | "Series C ($52M, February 2026)" | The raise was about nine months before today's date, which is a lower near-term runway concern | `[grounded]` pasted text and today's date; `[generic]` for the runway reading | Is this role funded from the Series C budget, and is it new or a backfill? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Resume lines, each tracing to your own sentence: "Built the dbt project on Snowflake (about 180 models) at a B2B payroll company"; "Used Airflow for orchestration"; "Set up the Great Expectations test suite"; "Daily SQL and Python". Move these above any tools list | See R3 to R8 | `[grounded]` your own sentences | `resume_edits_pending_approval` |
| A1 | State the BigQuery gap plainly in the application, beside the Snowflake dbt record, e.g. "I haven't used BigQuery; my dbt work is on Snowflake." | See R9; the posting names BigQuery, so it is better said than found | `[grounded]` your statement | pending your approval |
| W1 | Build a small public dbt project on BigQuery as a work sample. Claim it only after it exists, and as a project, not as job experience | See R9 | `[generic]` closure path | pending your approval |
| A2 | Open the careers page on pellucidlearning.com yourself and confirm the posting is live and matches the pasted text before investing in the loop | See RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask the verification questions of RR2, RR3 and RR4 verbatim in early conversations | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 0 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two fetches were sent as a check on your pasted text, "pellucidlearning.com/careers/senior-data-engineer" and "pellucidlearning.com/about". Both were refused because fetch permission wasn't granted, so I didn't retry. They would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | skipped | Your pasted Datawright report fixes the market calibration row and RR5, so a search would add nothing |
| 3. Hiring manager's public footprint | n/a | The posting names no manager, so there is no query to form |

## Dossier offer and upgrade menu

I can write this up as `tuesday-dossier.md` if you want to keep it. Say the word.

- Fetch access for the two pages, if you grant it → RR1 and the organization row close or sharpen.
- Your location, pay floor and any other non-negotiables → R1 and R2 settle, and the "constraints not given" flag leaves the hard-gates line.
- Your CV with dates → R3 is checked against titles, and any buried evidence for R4 to R8 shows up as presentation edits.
- Sanitized artifacts → R5 (dbt docs lineage page), R7 (Airflow DAG view), R8 (Great Expectations checkpoint config), R4 (SQL or Python sample); each could take its row from `medium` to `high`.
- Answers to G3 and G4 → R10 and R11 firm up.
- The hiring manager's name, which your recruiter may have → target 3 runs and sharpens the scope read and which story to lead with.
- A deeper research pass (funding and leadership changes, recent news; up to 5 more searches and 2 more fetches) → feeds RR1 and the register. Say the word and it runs, once access is granted.

## Questions

G1 — Where would you be working from: US remote, Denver, or somewhere that doesn't fit "Remote (US) or our Denver office"?

G2 — Is a base of $148,000–$166,000 plus equity at or above your floor?

G3 and G4 — Take one pipeline you owned from source system to analyst-facing table: what was the source, and what did you and its consumers agree it would guarantee?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.