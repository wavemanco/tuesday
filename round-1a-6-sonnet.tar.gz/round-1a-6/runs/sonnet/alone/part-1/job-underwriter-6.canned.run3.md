Checking the company, the market band and the hiring manager's public footprint now, then I'll write the assessment.
# Job Underwriting — Revenue Operations Lead, Quillfield

## Decision snapshot

**Yes, it's worth going for, on conditions. Status: `conditional_go`.** I assumed you're still evaluating, not yet applying.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Bristol hybrid, two office days), R2 (salary £61,500–£67,000)
- `must_have` — direct: R3, R5 · adjacent: R6 (SQL and spreadsheet modelling) · unclear: R4 (at a B2B software company), R8 (finance on billing or revenue data) · absent: R7 (owning a forecast)
- `important` — direct: R9 · absent: R10 (owning billing data)

R7 — you've said you have never owned the forecast; R10 — you've said you have never worked on billing data; R8 — open on whether your renewal work counted as revenue data.

**Opportunity ledger.** The pay is stated and the employer checks out (RR4). Four things are open: forecast scope (RR1), billing-data ownership (RR2), reporting line and team (RR3), and whether the posting appears on Quillfield's own site (RR5).

- **Hard gates:** none failed (R1, R2); unconfirmed: R1 (Bristol hybrid, two office days), R2 (salary £61,500–£67,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the location and pay terms fit your own limits — R1, R2; (2) the forecast turns out to be shared work you can credibly grow into, not one you must already own — R7, RR1; (3) you accept ramping up on billing data from a standing start — R10, RR2; (4) the posting is confirmed on Quillfield's own channels — RR5.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants, founded 2018 in Bristol, 96 employees, £11M Series A closed April 2025 | `[grounded]` search result "About Quillfield" (quillfield.co.uk/about) |
| Mandate | Own the CRM and billing data; build the pipeline and renewal reporting that sales and finance run on; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Terms | Bristol, hybrid, two office days a week; £61,500–£67,000 plus share options | `[grounded]` posting |
| Hiring manager | Tamsin Achebe, Head of Revenue Operations at Quillfield, previously sales operations manager at Corvane Payments for four years. This matches what the recruiter told you | `[grounded]` fetched page "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe) |
| Scope read | A RevOps lead working beneath a Head of RevOps, with data ownership, reporting and a forecast in one remit. Plausible for a company of this size, but decision rights over the forecast are unclear | `[inferred]` from the posting's three duties plus the manager's title |
| Market calibration | UK B2B software revenue operations leads: median base £64,200, interquartile range £57,800–£70,400 (n=438). The posted band sits inside that range, close to the median. The survey is not Bristol-specific and says nothing about this employer's offer | `[generic]` survey "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example); `[grounded]` posting for the band |
| Outcomes | No first-90-day or first-year outcomes, team size or reporting line stated | `[grounded]` posting silent |
| Contradictions | None between the posting and the About page. The posting is not confirmed on Quillfield's own site: quillfield.co.uk/careers returned no page | `[grounded]` fetch result |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two office days a week | hard_gate | unclear | none | hard_gate | You haven't stated location or commute limits, so the term can't be checked. Nothing here is a failure | `[grounded]` posting; your constraints not given | Ask in R1/R2 question |
| R2 | Salary £61,500–£67,000 plus options | hard_gate | unclear | none | hard_gate | You haven't stated a pay floor. The band is stated but unchecked against it | `[grounded]` posting; your floor not given | Ask in R1/R2 question |
| R3 | 4+ years in revenue operations, sales operations or similar analytics | must_have | direct | medium | none | You stated 5 years in sales operations, the last 2 running revenue operations for the UK team. A length-of-experience term is not a gate. Self-reported, so `medium` | `[grounded]` your message | none |
| R4 | The 4+ years at a B2B software company | must_have | unclear | low | discovery | Your employer is a B2B payments company. Whether the posting counts it as software isn't settled by what you've said | `[grounded]` your message and the posting; `[inferred]` the match is open | Note how you describe the product (G4) |
| R5 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified, stated. The posting accepts either system. A credential ID or sanitized admin work would take this to `high` | `[grounded]` your message | Optional: certificate reference |
| R6 | Strong SQL and spreadsheet modelling | must_have | adjacent | low | discovery | You use SQL weekly and Excel daily. That is frequency of use. Strength and any actual modelling are not yet described | `[grounded]` your message | See G5 |
| R7 | Experience owning a forecast | must_have | absent | none | discovery | You stated you've never owned the company forecast; finance did. Your monthly pipeline review with the sales director is real, adjacent work. Whether you fed numbers into finance's forecast is not yet known, so this is not yet closed as a capability gap. The pipeline review is a different activity from forecast ownership | `[grounded]` your message; `[inferred]` that any pipeline-to-forecast input remains to be found | G1 question |
| R8 | Experience working with finance on billing or revenue data | must_have | unclear | low | discovery | You stated no billing-data work. The posting says "billing or revenue data", and your renewal dashboards may be revenue data. Whether finance used them or you worked with finance on them is not stated | `[grounded]` your message and the posting wording | G2 question |
| R9 | Build pipeline and renewal reporting for sales and finance | important | direct | medium | none | You rebuilt your pipeline and renewal dashboards. Whether finance was an audience is unstated | `[grounded]` your message | Feeds G2; offer a sanitized screenshot |
| R10 | Own the billing data | important | absent | none | capability | You stated you've never worked on billing data, and nothing adjacent has been described. This is a plain gap, carried as a risk with a closure path | `[grounded]` your message | Closure path in the application plan |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R7, must_have) | discovery | You run the monthly pipeline review but finance owned the forecast. Your inputs to it are not described | The one must-have currently `absent`; a real input role would give an honest bridge, and none leaves the gap stated plainly | Supplying pipeline coverage or commit numbers to finance; sitting in forecast calls; reconciling the pipeline view to finance's number | A sanitized pipeline review pack or forecast-input sheet | `[grounded]` your message; `[inferred]` that this could narrow the gap |
| G2 | Finance on billing or revenue data (R8, must_have) | discovery | No billing work. Renewal dashboards could count as revenue data if finance relied on them | The posting says "or", so this may be closeable; a bridge must state that billing itself was not touched | Renewal or contract-value reporting finance relied on; reconciling CRM numbers with finance's | A sanitized renewal dashboard or reconciliation note | `[grounded]` posting wording; `[inferred]` the bridge is possible |
| G3 | Billing data ownership (R10, important) | capability | No direct or adjacent evidence | A responsibility the role would hand you on day one | Not a recall gap. Closure is learning the billing system and invoice-to-revenue flow | A short worked example of a billing-to-CRM reconciliation, built before interviews | `[grounded]` your message; `[generic]` that employers often accept a ramp-up on a secondary duty |
| G4 | Software employer (R4, must_have) | discovery | "B2B payments company" doesn't say whether the product is software | A literal screen on the sector wording could catch it | How your employer's product is described on its own site | The employer's product page | `[grounded]` your message; `[generic]` that screens are often literal |
| G5 | SQL and spreadsheet modelling depth (R6, must_have) | discovery | Frequency stated; depth not | Strong modelling is the likely forecast-adjacent skill | A model you built that others used; SQL you wrote for pipeline or renewals | A sanitized query or workbook | `[grounded]` your message |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Forecast scope unclear | unknown | — | "run the quarterly revenue forecast with the CFO" | The role may own the model, or only supply pipeline inputs to a CFO-led forecast. That decides how much of R7 matters | `[inferred]` from "with the CFO" against silence on decision rights | Which parts of the forecast does this role own: the model, the pipeline inputs, or the presentation to the CFO? | unresolved |
| RR2 | Billing data ownership and tooling unstated | unknown | — | "own our CRM and billing data" | The role may include source-of-truth duties for billing records that go beyond reporting on them | `[inferred]` from the word "own" against silence on the billing system | Which billing system is this, and is there a finance data owner already? | unresolved |
| RR3 | Reporting line and team unstated | unknown | — | "Revenue Operations Lead" | Tamsin is Head of Revenue Operations, so the role likely sits beneath them, but the posting names no team or direct reports | `[inferred]` from Tamsin's title against the posting's silence | Who does this role report to, and are there direct reports or analysts? | unresolved |
| RR4 | Pay stated, in range, plus options | positive_signal | — | "£61,500–£67,000 plus share options" | A disclosed band close to the market median points to a transparent offer. Option terms are still unknown | `[grounded]` posting; `[generic]` survey band | What are the option terms: vesting, strike price and share count? | noted |
| RR5 | Posting not found on Quillfield's own careers address | unknown | — | "Revenue Operations Lead, Quillfield" | The role may be listed elsewhere on the site, or the board may hold a stale or aggregated copy | `[grounded]` fetch returned no page at that address; `[generic]` reasons for such gaps | Can you point me to this role on Quillfield's own careers page? | unresolved |

## Application plan

**`resume_edits_pending_approval`** (each line traced to your own words; nothing about forecasting or billing is added):

| # | Proposed line | Source | Status |
|---|---|---|---|
| E1 | "Ran revenue operations for the UK team (last 2 of 5 years in sales operations at a B2B payments company)" | your "5 years… the last 2 running revenue operations for the UK team" | `resume_edits_pending_approval` |
| E2 | "Rebuilt the pipeline and renewal dashboards" | your "I rebuilt our pipeline and renewal dashboards" | `resume_edits_pending_approval` |
| E3 | "Run the monthly pipeline review with the sales director" | your "I run the monthly pipeline review with our sales director" | `resume_edits_pending_approval` |
| E4 | "Salesforce admin certified; SQL (weekly use), Excel (daily use)" | your message | `resume_edits_pending_approval` |

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Cover-note sentence on the forecast gap: "I have not owned a company forecast, as finance did that. What I run is the monthly pipeline review with our sales director." | Says the limit before an interviewer finds it. Traces to your own sentences | `[grounded]` your message | pending your approval |
| P2 | Lead with E1 and E3 for Tamsin, who ran sales operations at a payments company before RevOps | Tamsin may read your background as familiar. A reader's likely view, not a known preference | `[inferred]` from Tamsin's page | pending your approval |
| P3 | Ask RR1, RR2 and RR3 verbatim at the first call | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| P4 | Before interviews, build a short billing-to-CRM reconciliation example (even from public sample data) so R10 has a visible start | Turns a pure gap into a started one without claiming experience | `[generic]` closure pattern | pending your approval |
| P5 | Ask the recruiter to confirm the posting on Quillfield's careers page | Closes RR5 | `[grounded]` RR5 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 2 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company Bristol" (result: "About Quillfield", quillfield.co.uk/about); fetched quillfield.co.uk/careers, which returned no page. Moved role reality's organization row and RR5 |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary Bristol B2B SaaS" (result: "Ledgerline 2026 UK Revenue Operations Pay Guide", ledgerline.example). Moved market calibration and RR4 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield"; fetched "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Moved the hiring manager row, scope read and P2. No talks or writing were found |

I offer a dossier file (`tuesday-dossier.md`) that holds this assessment for later turns. Say the word and I'll write it.

## Upgrade menu

- Your pay floor and your view on two Bristol office days → R1, R2 move to `direct` or `hard_gate_fail`. A failure would make the decision `no_go`.
- What you fed into finance's forecast → R7 may become `adjacent`. A pipeline review pack would back it.
- Whether finance used your renewal dashboards → R8 and R9 firm up. A sanitized dashboard screenshot would take R9 to `high`.
- How your employer's product is described → closes R4.
- A sanitized SQL query or Excel model → R6.
- The posting's address on Quillfield's own careers page, or the recruiter's email domain → closes RR5.
- A deeper research pass on Quillfield (funding and leadership changes, hiring patterns, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

1. R1/R2 — What is your pay floor, and is two days a week in a Bristol office workable for you?
2. G1 (R7) — On the forecast finance owned, did you supply any of its inputs, such as pipeline numbers or commit calls, or sit in the forecast discussions? What exactly did you contribute?
3. G2 (R8) — Did finance rely on your renewal or pipeline numbers, or did you reconcile them with finance's figures? Who checked them?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.