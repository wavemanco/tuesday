I'm reading the rest of the skill's worked-report reference, which sets the output shape. After that I'll run the research and write the assessment.
**Yes, apply, on conditions.** R1 and R2 are hard gates, and I can't check them against your location or pay floor because you haven't given me either. The employer check also couldn't run (RR1). Status: `conditional_go`.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote US or Denver), R2 (Salary $148,000–$166,000)
- `must_have` — direct: R3, R4, R5, R7, R8
- `important` — adjacent: R6 (BigQuery); unclear: R9 (Ingestion from app and CRM), R10 (Data contracts for analysts)

R6 — a credible bridge from Snowflake, its limit named; R9, R10 — nothing in your background either way yet, asked below.

**Opportunity ledger.** The pay is in line with the report you were sent (RR2), and the funding stage matches the pasted company page (RR5). Three things are open: the employer is unverified (RR1), the scope may be broader than one domain (RR3), and the posting names no manager, team or success measures (RR4, RR6).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver), R2 (Salary $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. You confirm R1 and R2 against your own location and pay floor (G3). A failed gate would make this `no_go`.
  2. The posting is confirmed live on the company's own careers page (RR1).
  3. BigQuery is presented as adjacent to your Snowflake work, never as BigQuery experience (R6).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Live online tutoring for K-12 schools in 31 US states; Denver; founded 2016; 264 employees; Series C ($52M, February 2026). I couldn't check this against the live site | `[grounded]` the about-page text you pasted |
| Mandate | Build and run reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Terms | Remote (US) or Denver; $148,000–$166,000 plus equity | `[grounded]` JD |
| Scope read | The mandate spans ingestion, modelling and contracts. That reads as broader than the one-domain norm, so you could be one of very few data engineers | `[inferred]` from the JD's three-part mandate against the report's "ownership of one domain's pipelines" |
| Seniority fit | Your 6 years sits inside the 5–8 years the report calls typical for "Senior" | `[grounded]` your background and the report figures you quoted |
| Market calibration | The posted range runs from $3,000 below the report's median ($151,000) to $2,500 above its 75th percentile ($163,500). Series C falls in the report's Series B–D cohort. The report is the one your recruiter sent. I haven't seen it or checked it independently | `[grounded]` figures as you quoted them; the search sweep didn't run |
| First 90 days and first year | Not stated | `[grounded]` JD silence |
| Unknowns | Hiring manager, team size, reporting line, equity terms, success measures | `[grounded]` JD silence |
| Contradictions | None between the JD and the about text as pasted | `[grounded]` both pasted texts |

## Evidence map

Your background was typed into the chat, so I treat it like a CV. That keeps every claim at `medium` until you show me an artifact.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you live or work from, so I can't tell whether the terms fit | `[grounded]` JD; no statement from you | G3 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | You haven't given a pay floor, so I can't check the range against it | `[grounded]` JD; no statement from you | G3 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You stated 6 years at a B2B payroll company. A tenure requirement isn't a gate. It's confirmed but unproven by any document | `[grounded]` your background | none; the CV's dates will carry it |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You stated daily use of both. No artifact has been shown | `[grounded]` your background | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | You built the dbt project (about 180 models) on Snowflake, which is a cloud warehouse. The limit is that it was not BigQuery (see R6) | `[grounded]` your background | none; a model count or repo excerpt would raise it |
| R6 | BigQuery as the warehouse | important | adjacent | medium | transferability | The posting names it in the mandate. You haven't used it. What carries over is the modelling and dbt work on another cloud warehouse. What doesn't is BigQuery's own features and cost behaviour. The "important" tier is my reading, since the JD lists only "a cloud warehouse" | `[inferred]` tier from the mandate wording; `[generic]` that warehouses differ in these specifics | G4 |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | You use Airflow, which the JD names | `[grounded]` your background | none |
| R8 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite. "Set up" is the claim, and I haven't widened it to owning or running it | `[grounded]` your background | none; ownership detail is for the CV |
| R9 | Ingestion from the app and CRM | important | unclear | low | discovery | The JD lists it as a responsibility. Your background says nothing on source ingestion. This is a lead, not evidence | `[grounded]` JD; your background silent | G1 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | Tests and a dbt project sit near this, but you haven't described agreements with the people who consume the data | `[grounded]` JD; your background silent | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Ingestion from app and CRM (R9, important) | discovery | Pipelines and orchestration, but nothing on bringing data in from an application or a CRM | It's the first item in the mandate, and a "yes" would turn an unknown into a strength | Loading product-database extracts or events; syncing Salesforce-style or HubSpot-style CRM data; building or maintaining connectors or a CDC job | A pipeline diagram, a DAG listing, a README | `[grounded]` background silent; `[inferred]` weight from the mandate's order |
| G2 | Data contracts (R10, important) | discovery | dbt tests and Great Expectations are adjacent, but no agreement with consumers is described | The JD names the contracts as something analysts depend on | Agreed schemas or freshness expectations with analysts; failing tests that blocked a release; documented model owners | A test config, a model YAML with tests, an SLA note | `[grounded]` background silent |
| G3 | Location and pay (R1, R2, hard_gate) | hard_gate | Neither stated | A failed gate ends the application whatever the fit elsewhere | A home location and a base-pay floor | None needed; your statement is the evidence | `[grounded]` constraints not given |
| G4 | BigQuery (R6, important) | transferability | Adjacent Snowflake and dbt work. Nothing on BigQuery itself | Interviewers for a BigQuery shop will likely probe it | A small dbt-on-BigQuery project, only if you choose to build one | The project repo | `[generic]` that a named stack gets probed; `[inferred]` bridge from your dbt-on-Snowflake work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Founded 2016, Denver. 264 employees. Series C ($52M, February 2026)." | The search I sent was refused, so the company page and live posting are unchecked. The pasted texts are consistent with each other, but the entity may not match them, or the posting may be stale | `[generic]` pattern for any unverified employer, not a claim about this one | Can you point me to this role on your careers page, and who I'd interview with? | unresolved |
| RR2 | Pay in line with the report you were sent | positive_signal | — | "$148,000–$166,000 plus equity" | The range overlaps the report's interquartile range and tops out above its 75th percentile | `[grounded]` JD and the report figures you quoted | Where in the range would my experience place me, and how is the equity structured? | noted |
| RR3 | Mandate broader than one domain | risk_signal | low | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts our analysts depend on" | You may be one of few data engineers, covering work the report treats as separate domains | `[inferred]` from the JD's three parts against the report's one-domain norm | How many data engineers are there, and who owns ingestion versus modelling? | unresolved |
| RR4 | No hiring manager, team or reporting line named | unknown | — | "The posting names no hiring manager." | Not enough to judge scope, seniority of peers or support | `[grounded]` JD silence | Who would I report to, and how is the data team structured? | unresolved |
| RR5 | Recent funding and a named, modern stack | positive_signal | — | "Series C ($52M, February 2026)" | Funding is recent and the stack is concrete | `[grounded]` the pasted about text, which I couldn't check live | What is the funding earmarked for in the data team's plans? | noted |
| RR6 | No stated success measures | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | The JD gives no first-90-day or first-year outcomes, so success is undefined | `[grounded]` JD silence | What would success look like in the first six months? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check the posting is live on the company's own careers page, and apply through it | see RR1 | `[grounded]` RR1 | pending your approval |
| E1 | Lead the CV with the dbt project ("about 180 models", on Snowflake) and the Great Expectations test suite you set up, in your own numbers | see R5, R8 | `[grounded]` your background | pending your approval |
| E2 | State Snowflake plainly and name BigQuery as new to you, with no wording that implies BigQuery use | see R6 | `[grounded]` your background | pending your approval |
| Q1 | Ask RR2, RR3, RR4 and RR6's questions verbatim in the first conversations | The register doubles as interview preparation | `[grounded]` register | pending your approval |

Beyond-spec offer: I can sketch a small dbt-on-BigQuery exercise that would narrow R6. It would be adjacent evidence only and I'd build it only if you ask.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Pellucid Learning senior data engineer careers Denver online tutoring"; the call was refused. It would have checked the employer, the live posting and role reality's contradictions row. It left RR1 standing |
| 2. Role-family sweep | unavailable | Searched "senior data engineer salary 2026 dbt BigQuery Airflow US pay report"; the call was refused. It would have cross-checked the market calibration and RR3. The calibration rests on your report's figures alone |
| 3. Hiring manager's public footprint | n/a | The posting names no one, so there was no query to form |

I can offer a one-time `tuesday-dossier.md` write-up of all this whenever you want it.

## Upgrade menu

- Your location and pay floor → R1 and R2 resolve, and the decision becomes `go` or `no_go`.
- Answers to G1 and G2 → R9 and R10 move from `unclear` toward `direct`, and the CV gets two more bullets.
- Your CV, a DAG listing, or a dbt model and test config → R3 to R8 can reach `high`.
- The live careers-page link → RR1 closes.
- Search permission, plus a deeper pass (up to 5 more searches and 2 more fetches) → the refused L1 targets run, plus company diligence and recent news.
- The hiring manager's name → RR4 and the scope read sharpen.

G1 — At the payroll company, did you bring data in from an application database, a CRM or another outside source? What did you own, and how did you know it kept working?

G2 — Did you set or enforce expectations with analysts about what a table guarantees, such as schema, freshness, or tests that fail loudly? What was yours versus the team's?

G3 — Where are you based (or able to work from), and is there a base-pay figure below which you wouldn't proceed?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.