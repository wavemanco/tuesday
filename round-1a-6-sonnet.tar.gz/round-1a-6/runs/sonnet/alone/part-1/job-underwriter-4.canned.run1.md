I'll read the skill's reference files before building the assessment.
**Yes, apply, but find out the working pattern first.** Your two worries aren't what's blocking you. R11 (pet-insurance domain) is a `preferred` row at `adjacent`, and the posting asks for no people management. The open question is R1: the posting says fully remote, and the company's own careers page says something different. Status: `conditional_go`.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK))
- `must_have` — direct: R2, R3, R4, R5, R7, R8 · unclear: R6 (Monitor rating models)
- `important` — adjacent: R9 (Recommendations for underwriting and product)
- `preferred` — direct: R10 · adjacent: R11 (Pet-insurance domain)

R1 — a gate the posting contradicts itself on; R6 (`low`) — "maintained" is not the same as monitoring; R9 — underwriting side evidenced, product side silent; R11 — a credible bridge, its limit named.

**Opportunity ledger.** The posting is live, specific and owned by a named Director, but its terms conflict: the JD says remote while the careers page says Leeds four days a week (RR1). Pay is withheld (RR2), authority over price changes is unstated (RR3), scope is concrete (RR4), and the employer is not established beyond its careers page (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the real working pattern is confirmed and works for you (R1, RR1); (2) the budgeted pay meets your floor (RR2); (3) R6 monitoring experience is either confirmed or carried as a stated limit (G2).
- **What would flip it:** if remote is firm for you and the Leeds pattern is the real one, R1 becomes `hard_gate_fail` and the status becomes `no_go`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product; the role reports to the Director of Pricing | `[grounded]` JD header; careers page fetched (brindlemoor.co.uk/careers/senior-pricing-analyst) |
| Posting status | Live, "Accepting applications", on the employer's own domain | `[grounded]` careers page fetched |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Working pattern | **Contradiction.** JD: "Fully remote (UK)". Careers page: "Leeds office four days a week" | `[grounded]` both quoted; neither is treated as the right one |
| People management | The JD lists no line-management requirement | `[grounded]` JD |
| First-year outcomes | Not stated in the JD or the careers page | `[grounded]` both read |
| Hiring manager | Odile Varga, Director of Pricing. A search result describes a 2025 Insurance Pricing Forum talk, "Small Books, Loud Errors", on monitoring rating models in small books, and six years as head of pricing analytics at Calloway Re | `[grounded]` search-result snippet only; the profile page was not fetched |
| Scope read | A single-product, senior individual-contributor post. Your five years against "4+ years" clears the stated minimum | `[inferred]` from the JD's responsibilities and silence on reports; years from your own statement |
| Market calibration | A 2026 survey of UK insurers and insurtechs (n=612) puts senior pricing analysts at a median base of £58,400, interquartile range £52,100 to £64,900. This is a band, never Brindlemoor's offer, and the posting withholds pay (RR2) | `[generic]` role-family sweep, Pricewell 2026 survey, read as a search-result snippet; `[grounded]` JD silent on pay |
| Unknowns | Pay; team size; who decides price changes; which working pattern is current; the employer's size and funding | `[grounded]` none stated in the JD or the careers page |

## Evidence map

Your background was typed in, so it counts as CV-equivalent self-report. That puts `medium` at the ceiling, and nothing here is `high` until you give me an inspectable artifact.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | The JD and the careers page disagree, and you have not stated your location or working-pattern needs, so there is no constraint to grade | `[grounded]` JD and careers page; no candidate constraint given | Ask G1 and RR1's question |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years pricing analytics at a UK motor insurer, the last 2 as senior analyst: confirmed and specific, nothing inspected | `[grounded]` your intake message | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily": specific, but no artifact | `[grounded]` your intake message | A sanitised notebook or query would raise it to `high` |
| R4 | GLM experience | must_have | direct | medium | none | "Built and maintained the GLM rating model for our young-driver book" | `[grounded]` your intake message | A sanitised model spec would raise it to `high` |
| R5 | Build rating models | must_have | direct | medium | none | The same GLM build claim, covering the building half of "build and monitor" | `[grounded]` your intake message | none |
| R6 | Monitor rating models | must_have | unclear | low | discovery | "Maintained" is adjacent to monitoring, not the same. Of the two readings, the lower one holds until you say what the maintaining involved | `[grounded]` the word "maintained"; `[inferred]` that monitoring may be part of it | Ask G2 |
| R7 | Design and read price tests | must_have | direct | medium | none | "Ran 14 price tests last year with the underwriting team" covers running them. How much you designed versus read out is not stated, so claim only what you tell me | `[grounded]` your intake message | State your design and readout role when you update the CV |
| R8 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting, which is the audience the JD names | `[grounded]` your intake message | Deck excerpt would raise it to `high` |
| R9 | Turn results into recommendations for underwriting and product | important | adjacent | low | discovery | The underwriting side is evidenced by R7 and R8. Nothing mentions product, and the lower reading holds | `[grounded]` your intake message; silence on product | Add a G3 question next turn |
| R10 | Insurance experience a plus | preferred | direct | medium | none | Motor insurance is insurance | `[grounded]` your intake message | none |
| R11 | Pet-insurance domain, inferred from "our pet-insurance product" | preferred | adjacent | medium | transferability | Rating, GLMs and price testing on a motor book carry over. A pet book has its own rating factors and claims drivers that you have not worked with | `[inferred]` from the JD's product line; `[generic]` that pet and motor books differ in factors | See G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Working pattern (R1, hard_gate) | hard_gate | JD says remote, careers page says Leeds four days a week; your location and constraints are not given | A gate that decides between `conditional_go` and `no_go` | Not experience: a term, settled by the employer's answer | The recruiter's or Odile's written confirmation, or the live posting's text | `[grounded]` both sources quoted; `[inferred]` that it could flip the decision |
| G2 | Monitor rating models (R6, must_have) | discovery | "Maintained" does not say what the upkeep was | R6 is the one `must_have` row below `direct`, so resolving it matters most to fit | Actual-versus-expected tracking by segment; periodic model reviews or refits; dashboards that flagged drift; monitoring packs for underwriting | A sanitised monitoring pack, dashboard screenshot or review note | `[grounded]` CV-equivalent silence; `[inferred]` closing it removes the main fit doubt |
| G3 | Product-side recommendations (R9, important) | discovery | Underwriting recommendations are evidenced, product ones are not | Half of the JD's recommendation duty names product | A test result that changed a price, a rating factor, a cover or a feature; a readout to a product owner | A sanitised review-deck excerpt | `[grounded]` silence on product |
| G4 | Pet-insurance domain (R11, preferred) | transferability | Motor GLM and price-test work | A preferred row, but the one the JD's product line makes visible | The bridge: rating and testing method carry over. The limit: no pet-specific factors or claims history. The strengthener: see the offer below | None needed to claim the bridge | `[inferred]` bridge from the claims you gave; `[generic]` that pet factors differ from motor |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern contradicts the employer's own page (R1) | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | One source may be out of date, or the role's terms may have changed; I can't tell which | `[grounded]` both quotes; reasons stay side by side, none ranked as likely | Is this role fully remote, or based in the Leeds office four days a week? | unresolved |
| RR2 | Pay withheld | unknown | — | The posting states no figure | The offer may sit anywhere in the market band, so it may or may not meet your floor, which I don't have | `[generic]` band from the survey snippet; `[grounded]` JD silent | What salary range is budgeted for this post? | unresolved |
| RR3 | Authority over price changes and team size unstated | unknown | — | "turn the results into recommendations for underwriting and product" | The role may advise without deciding, and may be a sole analyst or part of a team | `[inferred]` from the JD's wording against its silence | Who decides on price changes after a recommendation, and who else is on the pricing team? | unresolved |
| RR4 | Scope is concrete and owned | positive_signal | — | "Own pricing analytics for our pet-insurance product" | Duties are named and the role reports to a named Director | `[grounded]` JD and careers page | What would you want the first monitoring cycle on the pet rating model to show? | noted |
| RR5 | Employer not established beyond its careers page | unknown | — | The careers page is the only Brindlemoor source I read | Size, stage and funding are unknown; most small employers simply have a small footprint | `[generic]` pattern, not a claim about this employer; `[grounded]` one page read | Roughly how large is the company and the pricing team? | unresolved |

## Application plan

The plan table is proposed only, and each row's status says so. The edits table carries its own marker.

`resume_edits_pending_approval` — I haven't seen your CV, so these lines use your own words and change only their order:

| # | Proposed line | Traces to | Status |
|---|---|---|---|
| E1 | Built and maintained the GLM rating model for the young-driver book | "Built and maintained the GLM rating model for our young-driver book" | `resume_edits_pending_approval` |
| E2 | Ran 14 price tests with the underwriting team last year | "Ran 14 price tests last year with the underwriting team" | `resume_edits_pending_approval` |
| E3 | Present the quarterly pricing review to the head of underwriting | "I present the quarterly pricing review to the head of underwriting" | `resume_edits_pending_approval` |

Add the calendar year to E2. Add no outcomes or numbers beyond what you've told me.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before investing in the application, ask which working pattern is current | R1, RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Put the verification questions of RR1 to RR4 to them in the loop, verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A3 | If asked, say plainly that you haven't worked in pet insurance and haven't managed anyone | The first is R11's limit, and the JD lists no management requirement | `[grounded]` your statements; `[grounded]` JD | pending your approval |
| A4 | Lead the cover note with E1, E2 and E3, your three most role-relevant facts; leave R6 and R9 unclaimed until G2 and G3 are answered | Keeps claims within your stated evidence | `[grounded]` R4, R7, R8 rows | pending your approval |

Interview rehearsal is the sibling skill mock-interview's job, not this one's.

Offer, beyond spec: a one-page note mapping your young-driver GLM to a pet book's rating factors, labelled as your reasoning and not as experience. It would strengthen G4's bridge, since R11 is your most visible gap, and I'd build it only on your approval.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech careers"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). Role reality's posting status and working-pattern contradiction; RR1, RR5 |
| 2. Role-family sweep | yes | Searched "Senior Pricing Analyst pet insurance UK remote salary", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey), read as a snippet. Market calibration `[generic]` and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga), read as a snippet. Role reality's hiring-manager row |

## Closing

I can save all of this as `tuesday-dossier.md` for later turns if you'd like.

**Upgrade menu**

- Your CV, with a sanitised model spec, a notebook, a price-test readout or a quarterly-review deck → R3, R4, R7 and R8 can move from `medium` to `high`.
- Your location, whether remote is firm, and your pay floor → R1 settles and RR2 can be compared against it. I'm assuming you're evaluating, not yet applying.
- The employer's answer on working pattern → R1 and RR1 close, and the decision simplifies to `go` or `no_go`.
- The budgeted salary → RR2 closes and is set against the band.
- A deeper pass on Brindlemoor (funding, leadership changes, recent news; up to 5 more searches and 2 more fetches) → RR5 could close. Say the word and it runs.

**Questions**

- G1 — Is four days a week in Leeds workable for you, or is fully remote a firm requirement?
- G2 — When you maintained the young-driver GLM, what did you do to check it kept performing, and is there anything sanitised you could share, such as a monitoring pack or a dashboard?
- RR2 — What is the lowest base salary you would accept?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.