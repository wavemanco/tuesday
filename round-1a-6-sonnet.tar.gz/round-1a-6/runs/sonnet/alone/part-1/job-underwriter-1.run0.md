I'll read the skill's reference files before building the assessment.
Running the L1 research now: two searches, one on Harborlight Health and one on senior product analyst pay and scope.
## Decision snapshot

**Yes, apply. You fit this role, and the status is `conditional_go`.** It stays conditional because I couldn't verify the employer or the posting (RR1) and the pay and location are unstated (RR2, RR3).

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R5
- `important` — adjacent: R6 (Define and maintain the metrics layer), R7a (Partner with product managers to turn analysis into roadmap decisions) · unclear: R7b (Partner with clinicians), R8 (Mentor two junior analysts)
- `preferred` — adjacent: R9b (Regulated personal-data handling, as a bridge to the HIPAA plus) · absent: R9a (Healthcare data experience, HIPAA)

R6 — you described governed dashboards, not metrics-layer ownership; R7b and R8 — nothing in what you gave me on clinician partnership or mentoring; R9a — no healthcare data work, on a preferred row.

**Opportunity ledger.** Concrete in what it asks, with a named team to mentor and named partners (RR6). The employer is unverified (RR1), pay and location are withheld (RR2, RR3), and support for the metrics layer and the success measures are unstated (RR4, RR5).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify (RR1); (2) pay, location and work arrangement meet your own constraints (RR2, RR3); (3) the mentoring and clinician rows (R8, R7b) are either confirmed from your history or framed honestly as new to you.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up, about 400 people, Series C, with a care-navigation app. Not independently checked (RR1) | `[grounded]` JD header, as pasted |
| Mandate | Own product analytics for the app: metrics layer, A/B tests, self-serve Looker dashboards, partnering with product managers and clinicians, mentoring two junior analysts | `[grounded]` JD |
| Seniority and team | Senior individual contributor with two direct mentees. Reporting line and hiring manager not given | `[grounded]` JD; `[inferred]` that mentoring two analysts means informal or lead-level management, not a manager title |
| Scope read | A broad but coherent senior analytics remit, running from metric definitions through experiments to stakeholder translation. It leans toward owning the whole analytics surface for one product | `[inferred]` from the six listed duties |
| First-90-day and first-year outcomes | Not stated | `[grounded]` JD silence |
| Pay and location | No figure, no location, no remote or on-site policy in the pasted text | `[grounded]` JD silence |
| Market calibration | Not available, because the role-family sweep was refused. I won't offer a pay band from memory | `[generic]` fallback: none given |
| Unknowns | Pay; location and work arrangement; analytics-engineering support behind the metrics layer; how success is measured; who the hiring manager is | `[grounded]` JD silence |
| Contradictions | None within the pasted JD. The careers page was not checked | `[grounded]` JD read; careers page unchecked |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | You stated 6 years of product analytics at a consumer-subscription company. Self-reported, so medium until a CV with dates is seen | `[grounded]` your prose background | Share the CV so dates can be read |
| R2 | Expert SQL | must_have | direct | medium | none | "SQL daily on a Snowflake warehouse" shows sustained use. It doesn't show the level "expert" implies, and screens for this role family often test it live | `[grounded]` your prose; `[generic]` on screens | Be ready for a live SQL exercise; a sanitized example of your hardest query would raise confidence |
| R3 | Experiment design at scale | must_have | direct | medium | none | You designed and ran the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift, at about 2M subscribers. Whether that counts as "at scale" for Harborlight is the employer's call, and its user base is unknown | `[grounded]` your prose | A sanitized experiment readout would raise it to high |
| R4 | Looker or a similar BI tool; self-serve dashboards | must_have | direct | medium | none | You built the company's Looker instance from scratch, 40+ governed dashboards. "Governed" is stated; "self-serve" by non-analysts is not | `[grounded]` your prose | Confirm who used the dashboards without an analyst |
| R5 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads and present to the VP Product monthly | `[grounded]` your prose | A sanitized memo would raise it to high |
| R6 | Define and maintain the metrics layer | important | adjacent | low | discovery | Governed dashboards suggest shared definitions, but you haven't said you defined or maintained a metrics or semantic layer. Taking the lower band | `[inferred]` from "governed dashboards" | Gap G1 |
| R7a | Partner with product managers to turn analysis into roadmap decisions | important | adjacent | medium | discovery | You present to the VP Product monthly. You haven't said what roadmap decisions those analyses changed | `[grounded]` your prose | Name one decision your analysis changed, if you have one |
| R7b | Partner with clinicians | important | unclear | none | discovery | Nothing in your background mentions specialist or domain-expert stakeholders | `[grounded]` silence in your prose | Gap G3 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Your background is silent on mentoring or reviewing others' work | `[grounded]` silence in your prose | Gap G2 |
| R9a | Healthcare data experience (HIPAA) a plus | preferred | absent | none | capability | You said you have never worked in healthcare. A plus, not a requirement | `[grounded]` your statement | Closure path in G4; minor risk given preferred priority |
| R9b | Regulated personal-data handling (bridge to R9a) | preferred | adjacent | medium | transferability | You handled GDPR/CCPA consumer PII and built the consent-state model for your warehouse. The limit: this was consumer privacy law, not health data, and HIPAA's own rules are untouched | `[grounded]` your prose; `[generic]` that HIPAA has its own rules | Gap G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R6, important) | discovery | Governed Looker dashboards, but no stated ownership of metric definitions | The JD lists this first; resolving it could lift R6 to `direct` | Writing LookML or dbt models; a metric dictionary; settling a disputed definition such as "active subscriber" or "retained" | A metric-definition doc, a LookML excerpt, a sanitized model diagram | `[grounded]` your prose silence; `[inferred]` that it leads the JD's duties |
| G2 | Mentoring (R8, important) | discovery | Nothing on mentoring in your background | The JD names two juniors, so the gap will likely be probed | Reviewing a colleague's SQL or analyses; onboarding a new analyst; informal coaching | A review checklist or onboarding doc you wrote | `[grounded]` your prose silence; `[generic]` that mentoring duties get probed |
| G3 | Clinician partnership (R7b, important) | discovery | No specialist or domain-expert stakeholders mentioned | Clinicians are named as a partner group, and your domain is new to them | Working with nutrition, quality or operations specialists to shape what you measured | A project note showing the joint work | `[grounded]` your prose silence |
| G4 | Health-data bridge (R9a, R9b, preferred) | transferability | Consent-state model and GDPR/CCPA handling, with no health data | A preferred row, but the bridge is your one route to the healthcare theme | The consent-state model's rules for what data may be used and when | A one-page description of the consent model; closure path: complete a short HIPAA basics course and say so honestly | `[grounded]` your prose; `[generic]` that HIPAA rules differ from GDPR/CCPA |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "digital-health scale-up, ~400 people, Series C" | I couldn't check the employer because my searches were refused. It may be real and simply unchecked. Other possibilities side by side: too new or small, a stale posting, or not a hiring employer | `[generic]` pattern, not a claim about this company | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay not stated | unknown | — | "Senior Product Analyst — Harborlight Health" (no figure in the posting as pasted) | The band may sit above or below your floor; many postings omit it | `[generic]` | What salary range is budgeted for this role? | unresolved |
| RR3 | Location and work arrangement not stated | unknown | — | "care-navigation app" (no location or remote policy in the posting) | It could be remote, hybrid or on-site; only you know what you can accept | `[grounded]` JD silence | Where is this role based, and what is the remote or hybrid policy? | unresolved |
| RR4 | Support for the metrics layer unstated | unknown | — | "define and maintain the metrics layer" | The role may also carry the data modeling and pipelines behind the layer, which bundles specializations | `[inferred]` from the JD's silence on engineering support | Who owns the data pipelines behind the metrics layer, and is there analytics-engineering support? | unresolved |
| RR5 | First-year outcomes not stated | unknown | — | "Own product analytics for our care-navigation app" | Accountability may be broad with no stated definition of success | `[inferred]` from the JD's silence | What should this person have delivered at 90 days and at one year? | unresolved |
| RR6 | Concrete scope and named team | positive_signal | — | "mentor two junior analysts" | Defined duties, named partners and a named team suggest a real, resourced role | `[grounded]` JD | Who are the two analysts, and how long have they been on the team? | noted |

## Application plan

These blocks are all proposed, and each is `pending your approval`. Every line below is built from your own sentences.

**Resume edits — `resume_edits_pending_approval`**

| # | Proposed line | Traces to your words | Provenance | Status |
|---|---|---|---|---|
| E1 | Built the company's Looker instance from scratch: 40+ governed dashboards | "Built the company's Looker instance from scratch — 40+ governed dashboards" | `[grounded]` your prose | pending your approval |
| E2 | Designed and ran the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift | "Designed and ran the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift" | `[grounded]` your prose | pending your approval |
| E3 | Built the consent-state model for our warehouse; handled GDPR/CCPA consumer PII | "built the consent-state model for our warehouse"; "handled GDPR/CCPA consumer PII" | `[grounded]` your prose | pending your approval |

I left out any wording like "healthcare-ready" or "HIPAA-compliant". Nothing you said supports it.

**Other actions**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with experimentation and Looker first, then the memo and VP Product work. These are your five `direct` must-haves | see R3, R4, R5 | `[grounded]` map rows | pending your approval |
| A2 | Treat the health-data gap as stated and honest: you've handled consumer PII and built a consent model, and you haven't worked with health data. Don't stretch the bridge | see R9a, R9b | `[grounded]` your statement | pending your approval |
| A3 | Ask RR1 through RR5 verbatim when you talk to the recruiter or hiring manager | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Harborlight Health care navigation app careers Senior Product Analyst"; the call was refused. It would have moved RR1 and the contradictions row in role reality |
| 2. Role-family sweep | unavailable | Searched "senior product analyst digital health salary range experimentation Looker"; the call was refused. It would have moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## One offer

I can save this as `tuesday-dossier.md` if you want a file to update as answers come in.

## Upgrade menu

- Permission to search, so I can run targets 1 and 2 → RR1 and market calibration, which cap the status at `conditional_go` until the employer checks out.
- A link to the live posting or careers page → RR1 and the contradictions row.
- Your pay floor, location and work-arrangement limits → I can build hard-gate rows against RR2 and RR3.
- Your CV as a document, with dates → R1 firms up beyond prose.
- A sanitized experiment readout or metrics memo → R3 and R5 to `high`.
- A metric-definition doc or LookML excerpt → R6.
- The hiring manager's name → the scope read and which story to lead with.

## Questions

1. **Constraints** — What is your pay floor, and which locations or remote arrangements can you accept? Anything non-negotiable matters most.
2. **G1** — Did you define or maintain shared metric definitions, such as a semantic layer or LookML models, that others relied on? What did you own?
3. **G2** — Have you mentored, onboarded or reviewed the work of more junior analysts? What was your role?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.