I'll read the reference files the skill requires before building the assessment.
**Yes, apply, with conditions. Status: `conditional_go`.** Your evidence covers each requirement the posting lists, and no gate row has failed. The employer is unverified and the location gate is unconfirmed, so the status is conditional. Your two worries are covered below. The posting never asks for people-management (R1–R10 contain no such row), and your lack of pet-insurance experience is one adjacent row (R9), not a blocker.

**Fit ledger.**

- `hard_gate`: unclear: R1 (UK-based, fully remote)
- `must_have`: direct: R2, R3, R4, R5a, R6a, R7 · unclear: R5b (Monitor rating models), R6b (Design price tests)
- `important`: adjacent: R9 (Pet-insurance product knowledge) · unclear: R8 (Recommendations reaching product)
- `preferred`: direct: R10

R5b, R6b — one recall question each; R9 — a credible bridge, its limit named; R1 — nothing stated about where you live.

**Opportunity ledger.** Brindlemoor could not be checked because the research calls were refused (RR1). Salary is withheld (RR2), and team size and reporting line are unstated (RR3). The posting does name concrete outputs (RR4).

- **Hard gates:** none failed (R1 `unclear`); unconfirmed: R1 (UK-based, fully remote); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify (RR1); (2) you confirm you are UK-based and remote suits you (R1); (3) the pet-insurance bridge is framed as adjacent, never as pet-pricing experience (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product; its existence and the live posting are unverified | `[grounded]` JD header; research refused |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing; no public footprint was checked | `[grounded]` your message; research refused |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | Reads as a hands-on analytics seat on one product, since "own" appears and no team or reports are mentioned. The posting doesn't say whether anyone else does pricing there | `[inferred]` from the JD's wording against its silence on team |
| First-year outcomes | Not stated in the posting | `[grounded]` JD silent |
| Market calibration | Not available: the role-family sweep did not run, so there is no salary band or title norm to set against the posting | `[grounded]` search refused |
| Unknowns | Salary; direct reports and team; who else works on pricing; tooling; contract terms | `[grounded]` JD silent |
| Contradictions | None found within the material provided. The JD could not be compared with a careers page | `[grounded]` no page was read |

## Evidence map

Your background was given in prose, so it counts as CV-equivalent self-report. `medium` is the highest band an unprobed claim can reach.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | UK-based, fully remote | hard_gate | unclear | low | hard_gate | You haven't stated where you live or whether remote suits you. A UK motor insurer employer suggests UK-based, but that is a reading, not your statement | `[inferred]` from your UK motor insurer role | Ask Q1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You state 5 years of pricing analytics, the last 2 as senior analyst. Years are graded as fit here, not as a gate | `[grounded]` your prose background | Offer a CV or LinkedIn history to raise it |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily", confirmed but no artifact inspected. Expect a technical probe | `[grounded]` your prose background | A sanitised query or notebook would raise it |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for your young-driver book | `[grounded]` your prose background | A model documentation excerpt would raise it |
| R5a | Build rating models | must_have | direct | medium | none | Same claim as R4: you built the young-driver GLM rating model | `[grounded]` your prose background | As R4 |
| R5b | Monitor rating models | must_have | unclear | low | discovery | You said "maintained", which doesn't say whether you tracked performance, drift or lift against actuals. I haven't assumed it | `[grounded]` your wording; practice not stated | Ask Q3 |
| R6a | Run price tests | must_have | direct | medium | none | You ran 14 price tests last year with the underwriting team | `[grounded]` your prose background | A sanitised test readout would raise it |
| R6b | Design price tests | must_have | unclear | low | discovery | "Ran" doesn't say whether you set the hypothesis, split, sample size or success measure, or whether others did | `[grounded]` your wording; design role not stated | Ask Q2 |
| R7 | Present to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your prose background | A review deck, sanitised, would raise it |
| R8 | Recommendations reach product, not only underwriting | important | unclear | low | discovery | You have underwriting-side evidence (R6a, R7); nothing stated about product teams | `[grounded]` your prose background silent on product | Held in queue as G3, not asked this turn |
| R9 | Pet-insurance product knowledge (not a listed requirement; implied by the role) | important | adjacent | medium | transferability | Rating a motor book carries over in method (GLMs, tests, underwriting partnership). Limit: you've had no pet-insurance work, so no pet rating factors or pet claims data | `[inferred]` from the JD's "pet-insurance product" scope; `[grounded]` your statement that you've never worked on pet insurance | Bridge case in plan P2 |
| R10 | Insurance experience a plus | preferred | direct | medium | none | Five years at a UK motor insurer | `[grounded]` your prose background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Monitor rating models (R5b, must_have) | discovery | You maintained the young-driver GLM; monitoring isn't stated | A named duty in the JD; a clear answer moves R5b to `direct` | Tracking actual-versus-expected by segment; drift or lift reviews; triggering a refit; a dashboard others used | A monitoring pack, a refit note, a dashboard screenshot | `[grounded]` your wording; `[inferred]` that a clear answer resolves the row |
| G2 | Design price tests (R6b, must_have) | discovery | 14 tests run with underwriting; your part in design isn't stated | The JD asks you to design and read tests | Writing the test hypothesis; choosing splits and sample sizes; defining the success measure; the readout | A test plan, a readout deck | `[grounded]` your wording; `[inferred]` that a clear answer resolves the row |
| G3 | Recommendations to product (R8, important) | discovery | Only underwriting audiences evidenced | The JD names both audiences | A pricing change taken to a product or commercial owner; a joint review | A recommendation memo, sanitised | `[grounded]` your prose background |
| G4 | Pet-insurance knowledge (R9, important) | transferability | Motor rating carries over in method; no pet-specific work | The likeliest objection from the hiring side | Any exposure to non-motor lines; reading about pet rating; a short self-directed analysis | A short, sanitised or public-data work sample | `[inferred]` derived from your motor background; `[generic]` that this is the likeliest objection |
| G5 | UK-based, fully remote (R1, hard_gate) | hard_gate | Location and remote suitability unstated | A gate: unconfirmed means unsettled | n/a | n/a | `[grounded]` your message silent on location |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer; the research that could have checked was refused, so none of these is ranked likelier | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Salary withheld | unknown | — | no salary figure appears in the posting | The band may sit above or below what a senior seat pays, or the employer may simply not publish pay; no band was available to compare | `[inferred]` from the posting's silence; `[grounded]` search refused | What salary range is budgeted for this role? | unresolved |
| RR3 | Team, reports and decision rights unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | "Own" may mean sole pricing analyst with no team, or may lead a small function; the JD names recommendations to underwriting and product, not decisions | `[inferred]` from the JD's "own" and "recommendations" against its silence on team | Does this role have direct reports, and who else works on pricing? | unresolved |
| RR4 | Responsibilities tied to concrete outputs | positive_signal | — | "build and monitor rating models, design and read price tests" | The work is specific rather than vague, which usually makes success checkable | `[grounded]` JD states the duties | What would a successful first year look like? | noted |

## Application plan

The three lines in the first block are your own sentences, with only the tense of the third changed.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | CV line: "Built and maintained the GLM rating model for the young-driver book." | see R4, R5a | `[grounded]` your sentence | resume_edits_pending_approval |
| E2 | CV line: "Ran 14 price tests last year with the underwriting team." | see R6a; says "ran", not "designed", until G2 is answered | `[grounded]` your sentence | resume_edits_pending_approval |
| E3 | CV line: "Present the quarterly pricing review to the head of underwriting." | see R7 | `[grounded]` your sentence | resume_edits_pending_approval |

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Order the application to lead with the GLM model, then the price tests, then the underwriting presentation, because those are the three evidence rows aligned with the JD's duties | see R4, R6a, R7 | `[grounded]` the map's `direct` rows | pending your approval |
| P2 | If asked about pet insurance, say plainly that your rating experience is motor and that you have not worked on pet insurance. Bridge on method (GLMs, tests, underwriting partnership) and name the limit | see R9 | `[grounded]` your statement; `[inferred]` bridge | pending your approval |
| P3 | Don't claim line management. The JD lists none, and RR3 is the question to ask | see RR3 | `[grounded]` JD requirement list | pending your approval |
| A1 | Verify the employer and live posting on Brindlemoor's own careers page before sending an application | see RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask RR1–RR4's questions verbatim in the loop | the register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Brindlemoor pet insurance insurtech careers"; the call was refused. It would have confirmed the entity and live posting (RR1, role reality's contradictions row) |
| 2. Role-family sweep | unavailable | Searched "senior pricing analyst insurance UK salary remote"; the call was refused. It would have given a market calibration and a salary band for RR2 |
| 3. Hiring manager's public footprint | unavailable | A name was given, so I searched "Odile Varga Director of Pricing Brindlemoor"; the call was refused. It would have sharpened the scope read and which of your stories to lead with |

I'd offer the dossier file `tuesday-dossier.md` if you want a saved version of this assessment, and it's yours on a yes.

**Upgrade menu**

- Search permission → I rerun the three declared research targets, which could move RR1, RR2, the scope read and the plan's lead story.
- A sanitised price-test readout or test plan → R6a to `high`, and it may resolve R6b.
- A sanitised model documentation excerpt, or a monitoring pack → R4, R5a and R5b firm up.
- A sanitised review deck → R7 to `high`.
- Your CV → exact wording to audit in E1–E3 and any evidence it buries.
- Your salary floor and any other must-haves → R1 and RR2 can be checked against them.

**Questions**

- **Q1 (G5):** Are you UK-based with the right to work there, and does fully remote suit you?
- **Q2 (G2):** In the 14 price tests, which parts did you own personally: the hypothesis, the split and sample, the success measure, the readout?
- **Q3 (G1):** After your GLM went live, how did you track whether it was still performing, and what did you do when it wasn't?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.