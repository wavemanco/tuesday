I'll read the reference files the skill requires before building the assessment.
**No, you're not wasting your time on this role, but you're a stretch candidate, not a match. R1b (3+ years of PM experience in a PM role) is absent, and R1a and R2 are only adjacent. Status: `conditional_go`.**

Web search was refused in this session, so nothing about Quartzline has been checked. Every statement about the employer or the market below is labeled `[generic]`, `[inferred]` or `[grounded]` accordingly.

## Decision snapshot

**Fit ledger.**

- `must_have`: direct: R7, R8 · adjacent: R1a (PM work without the title), R2 (shipped API or platform products) · absent: R1b (3+ years PM experience, titled)
- `important`: direct: R3 · adjacent: R4 (own the roadmap), R5 (specs and delivery with squads) · unclear: R6 (adoption metrics), R9 (launches with sales and support), R10 (agile delivery)

R1b — the titled-years row, absent; R1a, R2 — adjacent, limits named; R7 (`medium`), R8 (`medium`) — direct on resume claims, no artifact yet; R6, R9, R10 — unclear, resume silent.

**Opportunity ledger.** The scope reads concrete (RR5). The employer is unverified (RR1), and pay, reporting line and success measures are unstated (RR2, RR3, RR4). Whether the titled-years must-have is applied literally is unknown (RR6).

- **Hard gates:** none stated; candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed live on Quartzline's own careers site (RR1); (2) the employer says it will consider PM-adjacent work without the title (RR6, R1b); (3) your materials never claim a PM title or roadmap ownership you haven't held (R1a, R4).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B. Not independently confirmed (RR1). | `[grounded]` JD header, unverified |
| Mandate | Own the roadmap for the partner-facing API platform. Run discovery with integration partners. Write specs and drive delivery with two engineering squads. Define and track adoption metrics. Coordinate launches with sales and support. | `[grounded]` JD |
| Requirements | 3+ years PM experience, marked must-have. Shipped API or platform products, technical fluency, stakeholder management and agile delivery are listed requirements. | `[grounded]` JD |
| First 90 days / first year | Not stated. | `[grounded]` JD silent |
| Scope read | One product surface, two squads, and full-cycle PM duties from discovery to launch. At a company this size, product leadership above this role may be thin. | `[inferred]` from the responsibility list; `[generic]` for the size pattern |
| Market calibration | Not established: the role-family sweep did not run, and the posting gives no pay. Pattern only: a "3+ years PM" line usually marks a mid-level post. Solutions and integration backgrounds are a common route into API-platform PM roles, not a guaranteed one. | `[generic]` role-family pattern, not a claim about Quartzline |
| Unknowns | Pay, manager, existing product leadership, success measures, whether titled years are flexible. | `[grounded]` JD silent on each |
| Contradictions | None inside the JD. JD against careers page not checked. | `[grounded]` JD; check not run |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years PM experience: the work, without the title | must_have | adjacent | medium | transferability | You did requirements documents, roadmap-input sessions and coordination with PMs and engineers over 7 years. The limit is that you were the vendor-side integration lead, not the owner of a product. | `[grounded]` your CV prose | Strengthen via G1 and the W1 work sample |
| R1b | 3+ years PM experience: a held PM role | must_have | absent | none | transferability | You have never held a PM title, so there is nothing to credit. A posting that lists titled years as must-have is often screened on that line before adjacent work is read. | `[grounded]` you stated no PM title; `[generic]` screening pattern | Ask RR6 early. Wording cannot close this row. |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ client integrations of your vendor's REST APIs. That is deep use and delivery of an API product, not evidence you shipped one. | `[grounded]` your CV prose | Answer G2 |
| R7 | Technical fluency: API docs, schemas | must_have | direct | medium | none | You are comfortable in Postman and SQL and read OpenAPI specs, and you designed integration architecture. This is your own claim, with no artifact yet. | `[grounded]` your CV prose | Optional: the playbook, sanitized, would raise this to `high` |
| R8 | Stakeholder management across engineering and customers (the JD also lists sales, handled in R9) | must_have | direct | medium | none | You coordinated your engineers, client engineers and PMs, and ran client workshops. Sales is not evidenced here. | `[grounded]` your CV prose | none |
| R3 | Run discovery with integration partners | important | direct | medium | none | Your scoping workshops and quarterly roadmap-input sessions collected client feedback. Your clients are not necessarily Quartzline-style integration partners. | `[grounded]` your CV prose; `[inferred]` that clients map to partners | none |
| R4 | Own the roadmap | important | adjacent | medium | transferability | You gathered feedback for product. No prioritization or decision authority is evidenced, so frame it as input to the roadmap, never ownership. | `[grounded]` your CV prose | Answer G2 |
| R5 | Write specs and drive delivery with two squads | important | adjacent | medium | transferability | Your requirements documents and coordination of custom builds are real. Specs for a standing squad's backlog are not evidenced. | `[grounded]` your CV prose | Answer G2 |
| R6 | Define and track adoption metrics | important | unclear | low | discovery | Your resume is silent. A prior-conversation lead (an internal triage tool that support agents adopted) is unconfirmed, so it is a question and not evidence. | `[grounded]` resume silence; `memory_lead` unconfirmed | Answer G1 |
| R9 | Coordinate launches with sales and support | important | unclear | low | discovery | Client go-lives are not the same as product launches with sales and support. Your resume doesn't establish the second. | `[grounded]` resume silence | Upgrade menu item |
| R10 | Agile delivery | important | unclear | low | discovery | Your resume doesn't mention sprints, backlogs or similar. | `[grounded]` resume silence | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Adoption measurement and ownership (R6, important; R1a, must_have) | discovery | Your resume has no adoption metrics or product-ownership evidence. An unconfirmed lead suggests an internal tool support agents used. | It is your only potential evidence of defining a problem, building a solution and measuring uptake. That is the center of the PM claim. | A tool, process or playbook you defined, built or rolled out, with some measure of use, even informal | A usage screenshot, a rollout note, a before/after of ticket handling | `[grounded]` resume silence; `[inferred]` that this matters most, since R1a and R6 rest on it |
| G2 | Product impact beyond integrations (R2, must_have; R4, R5, important) | transferability | You delivered integrations, and you fed feedback to product. Nothing shows what shipped from it. | R2 is a must-have, and shipped-product evidence is what separates adjacent from direct. | A custom build that became a product feature; an API change or doc fix your feedback caused; a requirements document an internal squad built from | A feature ticket, a changelog entry, a spec excerpt, a sanitized requirements doc | `[grounded]` resume silence; `[generic]` that shipped output is what PM interviews probe |
| G3 | Titled PM years (R1b, must_have) | transferability | No PM title. Adjacent work exists (R1a). | A held-role requirement can't be closed by wording. | n/a | n/a | `[grounded]` your stated history |
| G4 | Agile delivery (R10, important) | discovery | Silent on agile practice. | Probably confirmable quickly if the practice is simply missing from the resume. | Sprint planning or backlog refinement you took part in; user stories you wrote or reviewed; Jira boards you used | A sanitized board screenshot or a story you wrote | `[grounded]` resume silence |

For G3, the closure path depends on RR6. If Quartzline says titled years are firm, the realistic path is to target roles that don't require them, such as product-owner or technical-product roles at API-first companies `[generic]`, or to apply anyway knowing the odds.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The company may be too new or small for a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. Search was refused here, so none of these is ranked. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Compensation not stated in the posting provided | unknown | — | (no pay figure in the pasted JD) | The post may sit below your expectations, or the pay may be in a part of the posting you didn't paste. | `[inferred]` from the JD's silence | What is the budgeted salary range for this post? | unresolved |
| RR3 | Reporting line and product leadership unstated | unknown | — | "Own the roadmap for our partner-facing API platform" | You may own the roadmap with no senior product leader above you. That matters for a first PM title. | `[inferred]` from the JD's silence on reporting | Who does this role report to, and who else is in product? | unresolved |
| RR4 | Success measures unstated | unknown | — | "define and track adoption metrics" | Targets for the first year may not exist yet. | `[inferred]` from the JD naming metrics without targets | What would a good first year look like for this role? | unresolved |
| RR5 | Concrete scope and named collaborators | positive_signal | — | "two engineering squads"; "coordinate launches with sales and support" | The post has real resources and collaborators, not a lone-owner mandate. | `[grounded]` JD | Who owns the squads' priorities today? | noted |
| RR6 | Titled-years must-have may be applied literally | risk_signal | medium | "3+ years product management experience (must-have)" | A literal screen would cut you at R1b whatever the rest of the map says. The employer may flex for adjacent backgrounds. | `[generic]` hiring pattern; `[grounded]` JD marks it must-have | Would you consider a candidate with 7 years leading API integrations and PM-adjacent work but no PM title? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask the recruiter RR6's question before investing in tailoring. | It decides whether R1b is a wall or a hurdle. | `[grounded]` RR6 | pending your approval |
| E1 | Lead the resume with your own words: "Led 30+ client integrations of our REST APIs end to end: scoping workshops, requirements documents, integration architecture, UAT, go-live." | R2, R5, R7 | `[grounded]` your CV prose | `resume_edits_pending_approval` |
| E2 | Move "Ran quarterly roadmap-input sessions collecting client feedback for product" into your top bullets. | R3, R4. It is input to the roadmap, not ownership. | `[grounded]` your CV prose | `resume_edits_pending_approval` |
| E3 | Keep "Wrote the internal integration playbook the whole team uses" prominent. | R7, R5 | `[grounded]` your CV prose | `resume_edits_pending_approval` |
| P1 | In your cover note, say first that you haven't held a PM title. Then give the work: "For seven years I've been the vendor-side lead on REST API integrations with client engineers, writing requirements, running scoping workshops and collecting roadmap input." Don't write "PM experience", "owned the roadmap" or "managed squads". | R1a, R1b, R4. Every clause traces to your own sentences. | `[grounded]` your CV prose | pending your approval |
| W1 | Build a one-page spec and adoption-metrics plan for an improvement to an API you know. Label it an exercise, not shipped work. | Narrows the R5 and R6 limits. | `[grounded]` R5, R6 rows | pending your approval |
| Q1 | Ask the questions in RR1, RR2, RR3, RR4 and RR6 verbatim in the loop. | The register doubles as interview preparation. | `[grounded]` register | pending your approval |
| A2 | Seek an introduction through a contact at Quartzline before applying cold. | Referrals often get adjacent backgrounds read. It's a pattern, not a fact about this employer. | `[generic]` hiring pattern | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: a prior-conversation mention of an internal request-triage tool that support agents adopted; details unconfirmed, and it prompts a question (G1) only. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search "Quartzline logistics technology API platform careers Product Manager" was refused, so the employer is unestablished (RR1). It would have moved RR1 and the contradictions row. |
| 2. Role-family sweep | unavailable | Search "platform API product manager B2B salary requirements transition from solutions engineer" was refused. Market calibration and the pay check (RR2) fall back to `[generic]`. |
| 3. Hiring manager's public footprint | n/a | No name was given, so no query could be formed. |

---

If you'd like, I can write this up as `tuesday-dossier.md` to keep.

**Upgrade menu**

- Allow web search, and I rerun targets 1 and 2. That could close RR1 and give a real pay band for RR2.
- A link to the live posting on Quartzline's careers page would settle RR1.
- An artifact for the triage tool (usage numbers, a rollout note) would move R6 and R1a.
- A feature, changelog entry or spec that came from your feedback would move R2, R4 and R5.
- Your integration playbook, sanitized, would raise R7 to `high`.
- Evidence of working with sales or support on launches would move R9.
- Sprint or backlog practice would move R10.
- The recruiter's answer on titled years would settle RR6, and with it R1b's weight.
- The hiring manager's name would let me read the role's scope against their public background.

**Questions**

- **G1 (R6, R1a):** An earlier conversation hinted you built an internal request-triage tool that support agents adopted. Is that right? If so, what did you own (defining the problem, building it, rolling it out), how did you know agents adopted it, and is there anything to show?
- **G2 (R2, R4, R5):** Did any of your client feedback, custom builds or requirements documents end up shipped in your vendor's product or APIs? What was your part, and what changed?
- **Constraints:** Do you have non-negotiables a move would have to meet, such as a pay floor, location or onboarding terms?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.