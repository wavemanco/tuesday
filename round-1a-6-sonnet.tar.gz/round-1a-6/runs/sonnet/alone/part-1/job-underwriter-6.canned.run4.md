Let me use the Read tool instead.
# Job Underwriting Assessment — Revenue Operations Lead at Quillfield

## Decision snapshot

**Yes, go for it, on the conditions below. Status: `conditional_go`.** R7 (forecast), R8 and R9 (finance and billing data) are the stretch rows you named yourself. R1 and R2 are terms I can't check until you tell me your limits.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Bristol office, two days a week), R2 (Base £61,500–£67,000)
- `must_have` — direct: R3, R4, R5, R10 · adjacent: R7 (Owning a forecast), R8 (Finance on billing or revenue data) · unclear: R6 (Spreadsheet modelling) · absent: R9 (Owning billing data)

R7 — adjacent through the pipeline review, the forecast number never yours; R8 — adjacent through renewal reporting, finance contact unconfirmed; R9 — billing data new to you, by your own account.

**Opportunity ledger.** Sound on what is shown: the stated pay sits inside the market band and the mandate is spelled out (RR1). Open items are share-option terms (RR2), who owns the forecast number (RR3), scope across three jobs (RR4), the posting's absence from Quillfield's own site (RR5) and success measures (RR6).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol office, two days a week), R2 (Base £61,500–£67,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the Bristol terms and the pay range work for you (R1, R2); (2) the recruiter or Tamsin confirms the forecast is shared with the CFO and learnable on the job, not expected on day one (R7, RR3); (3) billing data is presented as new to you and renewal reporting as the nearest work, never as billing experience (R8, R9); (4) the role is confirmed live on Quillfield's own site (RR5).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield makes invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol, 96 employees, £11M Series A closed April 2025 | `[grounded]` quillfield.co.uk/about, search-result text; the page itself was not opened |
| Mandate | Own the CRM and billing data; build the pipeline and renewal reporting that sales and finance run on; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern and pay | Bristol, hybrid, two office days a week. £61,500–£67,000 plus share options | `[grounded]` posting |
| Hiring manager | Per your recruiter, Tamsin Achebe. Her public listing reads Head of Revenue Operations at Quillfield, previously sales operations manager at Corvane Payments for four years | `[grounded]` you for the name; `[grounded]` linkedin.example/in/tamsin-achebe, search-result text only |
| Scope read | Three distinct jobs under one title: CRM administration, billing-data ownership, forecasting. A Head of Revenue Operations also exists, so the Lead's reporting line and team are unclear | `[inferred]` from the three responsibilities and the manager's listed title |
| First-year outcomes | Not stated. A reasonable reading is the quarterly forecast run with the CFO and the reporting live | `[inferred]` from the responsibilities list |
| Market calibration | Ledgerline's 2026 UK pay guide gives a median base of £64,200 for a revenue operations lead in UK B2B software (n=438), interquartile range £57,800–£70,400. The posting's range brackets that median. The guide is national, not Bristol-specific | `[generic]` Ledgerline, search-result text; `[grounded]` posting figure |
| Unknowns | Reporting line; team size; share-option terms; who owns the forecast number; success measures | — |
| Contradictions | No contradiction between your description and Quillfield's about text. The posting could not be matched on Quillfield's own site because its careers page returned nothing | `[grounded]` fetch of quillfield.co.uk/careers returned no page |

## Evidence map

Your background is typed into the conversation, so it counts as CV-equivalent self-report. No claim reaches `high` until there is something inspectable.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol office, hybrid: two days a week in the office | hard_gate | unclear | none | hard_gate | You gave no location or schedule limit, so the term is neither met nor failed. Confidence is `none` because there is no statement of yours to grade | `[grounded]` posting; no constraint given | Question 1 |
| R2 | Base £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | You gave no pay floor. The figure is stated, so this settles as soon as you share your minimum | `[grounded]` posting; no floor given | Question 1 |
| R3 | 4+ years in revenue operations, sales operations or similar analytics role at a B2B software company | must_have | direct | medium | none | You state 5 years in sales operations, the last 2 running revenue operations for the UK team. Limit: you describe the employer as a B2B payments company, and whether that reads as "B2B software company" is unstated | `[grounded]` your message | none |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified, which meets one of the two named options. The certification itself has not been seen | `[grounded]` your message | offer: a certification record would raise to high |
| R5 | Strong SQL | must_have | direct | medium | none | You use SQL weekly. That is frequency, not depth, so "strong" is untested and a technical probe is likely | `[grounded]` your message | offer: a sanitized query sample would raise to high |
| R6 | Spreadsheet modelling | must_have | unclear | low | discovery | You use Excel daily. Nothing says you have built models (scenario, renewal, forecast), only that you use the tool | `[grounded]` your message, silent on modelling | offer: a one-line description or sanitized copy of the largest model you built |
| R7 | Experience owning a forecast | must_have | adjacent | medium | transferability | You have not owned the company forecast; finance did. Adjacent work: you run the monthly pipeline review with your sales director and rebuilt the pipeline dashboards. Limit: you have not set or defended the number for finance leadership | `[grounded]` your statements; `[inferred]` that pipeline review is the sales-side input to a forecast | see G1 |
| R8 | Experience working with finance on billing or revenue data | must_have | adjacent | low | transferability | You rebuilt renewal dashboards, which report revenue-linked data. You did not say you worked with finance on them, so the bridge is thin | `[grounded]` your message; `[inferred]` the bridge | see G2 |
| R9 | Own the billing data | must_have | absent | none | capability | You have never worked on billing data, and the renewal reporting in R8 is the nearest work. This is a real gap that wording cannot close | `[grounded]` your statement | see G3 |
| R10 | Build the pipeline and renewal reporting sales and finance run on | must_have | direct | medium | none | You rebuilt your pipeline and renewal dashboards. Limit: who used them, finance included, is not stated | `[grounded]` your message | offer: a sanitized dashboard screenshot would raise to high |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning a forecast (R7, must_have) | transferability | A monthly pipeline review you run, rebuilt pipeline dashboards, and finance as owner of the forecast | The posting makes the quarterly forecast with the CFO part of the mandate. This is the largest distance between you and the role | Giving finance pipeline-coverage or conversion assumptions; making a commit or best-case call in the review; comparing forecast with actual afterwards; bridging bookings to revenue | A sanitized pipeline-review pack, a forecast-versus-actual report, a dashboard showing coverage | `[grounded]` your statements; `[inferred]` that the review feeds forecasting |
| G2 | Working with finance on billing or revenue data (R8, must_have) | transferability | Renewal dashboards, with no stated link to finance or billing sources | It is a stated requirement, and the nearest work to R9 | Reconciling renewal figures to finance's numbers; agreeing a definition of renewal or recurring revenue with finance; fixing a mismatch between CRM and finance data | Sanitized metric definitions, a data dictionary, a reconciliation note | `[grounded]` your message; `[inferred]` that the dashboards touch revenue data |
| G3 | Owning billing data (R9, must_have) | capability | No billing experience, by your own account | The role owns this data from the first day | Nothing in your history reads as billing today. Closure path: learn the basics (invoices, subscriptions, credit notes), then build a small sanitized exercise tying invoice exports to CRM opportunities | A short exercise note, once built | `[grounded]` your statement; `[generic]` that billing-data basics are learnable alongside a CRM background |
| G4 | Spreadsheet modelling (R6, must_have) | discovery | Daily Excel use, no model described | Forecasting leans on it | A renewal or pipeline scenario model; a quota or capacity model; anything with assumptions that others changed | A sanitized workbook | `[grounded]` your message, silent on modelling |
| G5 | Office days and pay terms (R1 and R2, hard_gate) | hard_gate | Terms stated, your limits not | A hard gate cannot be fixed with wording | Your minimum base; how many office days a week you can sustain in Bristol | Not applicable | `[grounded]` posting; no constraint given |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay and terms stated up front, inside the market band | positive_signal | — | "Salary £61,500–£67,000 plus share options" | The posting is transparent on pay, and the range brackets the market median | `[grounded]` posting; `[generic]` Ledgerline band, national figure | What is the budgeted base for the successful candidate within that range? | noted |
| RR2 | Share options with no terms given | unknown | — | "plus share options" | The options may be worth little or a lot depending on strike, vesting and dilution | `[inferred]` from the posting's silence on terms | What are the number, vesting schedule and strike for this role's options? | unresolved |
| RR3 | Forecast ownership and reporting line unclear | unknown | — | "run the quarterly revenue forecast with the CFO" | The Lead may support a forecast the CFO owns, or own it from the start. A Head of Revenue Operations also exists, so the reporting line is open | `[inferred]` from the posting's wording and the manager's listed title | Who owns the forecast number, who does this role report to, and does it have a team? | unresolved |
| RR4 | Three jobs under one title | risk_signal | low | "own our CRM and billing data, build the pipeline and renewal reporting … and run the quarterly revenue forecast" | CRM administration, billing data and forecasting are usually separate specialisms, so the scope may be wide for a Lead at a 96-person company. Pay is at the market median, which lowers the concern | `[inferred]` from the responsibilities list; `[generic]` that these are often separate roles | What support does this role have: team, finance analyst time, billing-system admin? | unresolved |
| RR5 | Posting not matched on Quillfield's own site | unknown | — | "Revenue Operations Lead, Quillfield" | The role may be recent, listed only on the jobs board, or the careers page may sit at another address. The employer itself is established | `[grounded]` careers fetch returned no page; `[grounded]` about page found | Can you confirm this role is live on Quillfield's own careers page? | unresolved |
| RR6 | No stated success measures | unknown | — | "You will own our CRM and billing data" | The posting lists duties and no first-year outcomes, so what success means is open | `[inferred]` from the posting's silence | What would a good first year look like for this role? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Move "rebuilt the pipeline and renewal dashboards" to the top of your CV experience, in your own words, with no added scope or audience | R10, your strongest direct row | `[grounded]` your message | resume_edits_pending_approval |
| E2 | Keep "ran revenue operations for the UK team" and "run the monthly pipeline review with our sales director" as the two lead lines, worded as you wrote them | R3, R7 | `[grounded]` your message | resume_edits_pending_approval |
| E3 | If asked about the forecast, say what is true: finance owned the company forecast and you ran the monthly pipeline review with your sales director. Say billing data is new to you, with renewal reporting as your nearest work | R7, R8, R9 | `[grounded]` your statements | pending your approval |
| A1 | Before investing in interviews, ask the recruiter RR3's question (forecast ownership and reporting line) and RR5's (live on Quillfield's site) | Settles conditions 2 and 4 | `[grounded]` RR3, RR5 | pending your approval |
| A2 | Use the register's verification questions verbatim with Tamsin | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| P1 | Lead the conversation with the pipeline-and-renewal rebuild and the monthly review (R10, R7). Her public listing shows a sales-operations background at a payments company, so your route is a familiar one | The positioning rests on your strongest rows and on her listed career | `[grounded]` her search-result listing | pending your approval |
| W1 | Optional: a one-page sanitized note on how your renewal dashboard defines its figures, and what they tie to | Supports R8, R10; depends on your answer to G2 | `[grounded]` G2 | pending your approval |

## Evidence status

Verified: none yet. Your background is self-reported and sits at the intake ceiling of `medium` at most. Unverified leads: none from earlier conversation. Rejected inferences: none.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software careers Bristol", which returned "About Quillfield" (quillfield.co.uk/about). Fetched quillfield.co.uk/careers, which returned no page. Moved: the organization row, the contradictions row, RR5 |
| 2. Role-family sweep | yes | Searched "revenue operations lead salary UK B2B software Bristol", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved: market calibration, RR1 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Moved: the hiring-manager row, the scope read, plan row P1 |

I can write this up as a `tuesday-dossier.md` for you to keep and update if you'd like one.

## Upgrade menu

- Your minimum base and your view on Bristol two days a week → R1 and R2 settle, and the hard-gates line closes.
- A Salesforce certification record → R4 to `high`. A sanitized SQL sample → R5 to `high`. A sanitized dashboard screenshot → R10 to `high`.
- A sanitized pipeline-review pack or forecast-versus-actual report → G1's bridge strengthens.
- Metric definitions or a reconciliation note for your renewal numbers → G2, and R8 improves.
- The recruiter's answers on forecast ownership, reporting line, team and options → RR2, RR3, RR4 and RR6 close.
- A link to the role on Quillfield's own careers page → RR5 closes.
- A deeper research pass on Quillfield (funding, leadership churn, hiring patterns, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

1. R1, R2 — Do both terms work for you: a Bristol office two days a week, and a base of £61,500–£67,000?
2. G1 — Have you ever set or defended a number that finance or leadership used, such as a commit call, a coverage assumption or a quarterly bookings estimate? What was yours, and what was finance's?
3. G2 — When your renewal dashboards reported revenue, whose numbers did they reconcile to? Did you ever work with finance to settle a definition or fix a mismatch?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.