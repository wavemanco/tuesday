I'll read the reference files the skill points to before building the assessment.
**Short answer: probably yes, but not yet. Settle the work location first. Status: `hold_pending_answers`.** R2, R3, R4, R5a, R6 and R7 land `direct` on what you wrote. The hold is on R1, because the posting and the employer's own careers page disagree on where you'd work.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK))
- `must_have` — direct: R2, R3, R4, R5a, R6, R7 · unclear: R5b (Monitor rating models)
- `important` — direct: R8a · unclear: R8b (Recommendations for product)
- `preferred` — direct: R9

R1 — the posting and its careers page disagree on remote; R5b — monitoring not yet evidenced in what you wrote; R8b — product-side input not yet evidenced.

**Opportunity ledger.** The role is live on the employer's own site (RR3), but its work pattern differs between sources (RR1), pay is unstated (RR2), and team size and decision rights are unstated (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **What would change this:** the awaited answer is G1, whether Leeds four days a week is workable for you.
  - If it is workable, or the employer confirms remote in writing, the status moves to `conditional_go`. The conditions are R5b and R8b evidenced, and RR2 (pay) checked against the band below.
  - If you need remote and the employer confirms Leeds four days a week, R1 becomes `hard_gate_fail` and the status is `no_go`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor's own careers page lists this role as "Accepting applications" and describes "our pet-insurance product". Stage and size were not established from the fetched text | `[grounded]` careers page fetched |
| Mandate | "Own pricing analytics for our pet-insurance product"; build and monitor rating models, design and read price tests, make recommendations to underwriting and product | `[grounded]` JD as you gave it |
| Reporting line | The careers page says the role "reports to the Director of Pricing". The page doesn't name her, so that this is Odile Varga is a reading of your JD | `[grounded]` careers page; `[inferred]` that the Director is Odile Varga, from your JD naming her as hiring manager |
| Work pattern | Your JD says "Fully remote (UK)". The careers page says "Leeds office four days a week". I haven't resolved this | `[grounded]` both sources quoted |
| Compensation | The JD as given states no figure. The Pricewell 2026 survey snippet gives a median base of £58,400 and an interquartile range of £52,100 to £64,900 for senior pricing analysts at UK insurers and insurtechs (n=612). I read the snippet only and did not open the page. This is a market band, not Brindlemoor's offer (RR2) | `[generic]` survey snippet; `[grounded]` JD silence on pay |
| Pet-insurance specifics | The JD asks for "insurance experience a plus" and does not ask for pet-insurance experience | `[grounded]` JD |
| People management | The JD lists no line-management requirement | `[grounded]` JD |
| Hiring manager's public footprint | Odile Varga, Director of Pricing. She spoke at the 2025 Insurance Pricing Forum on "Small Books, Loud Errors", about monitoring rating models in small books, and was previously head of pricing analytics at Calloway Re for six years. I read this from a search snippet only | `[grounded]` search result for her public profile |
| Unknowns | Pay; team size; who signs off rate changes; which work pattern applies | `[grounded]` JD and careers page silent |
| Contradictions | The work pattern above, JD against careers page | `[grounded]` both quoted |

## Evidence map

Your background is self-report at this stage, which caps confidence at `medium`. R1 grades your own statement of a constraint, and you haven't stated one.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | You stated no work-pattern constraint. The JD and the careers page conflict, so whether the term is met isn't established | `[grounded]` JD and careers page | G1 question; employer's written confirmation of the work pattern |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | "5 years pricing analytics at a UK motor insurer, the last 2 as senior analyst", confirmed and specific, no document seen | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily"; no inspectable artifact | `[grounded]` your background | none |
| R4 | GLM experience | must_have | direct | medium | none | "Built and maintained the GLM rating model for our young-driver book" | `[grounded]` your background | none |
| R5a | Build rating models | must_have | direct | medium | none | The same GLM claim covers building | `[grounded]` your background | none |
| R5b | Monitor rating models | must_have | unclear | low | discovery | "Maintained" may include monitoring, but you haven't said what you did to monitor the model. Carried at the lower reading | `[grounded]` your wording; `[inferred]` that maintenance may include monitoring | G2 question |
| R6 | Design and read price tests | must_have | direct | medium | none | "Ran 14 price tests last year with the underwriting team". That says you ran them, not that you designed them or read the results; I keep your wording | `[grounded]` your background | If you designed the tests, say so. Only then would "design" appear in what you send |
| R7 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | "Present the quarterly pricing review to the head of underwriting" | `[grounded]` your background | none |
| R8a | Recommendations for underwriting | important | direct | medium | none | Fourteen tests run with the underwriting team, plus the quarterly review you present | `[grounded]` your background | none |
| R8b | Recommendations for product | important | unclear | low | discovery | Nothing you wrote mentions a product or commercial stakeholder | `[grounded]` your background silent | G3 question |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer. The JD doesn't name pet insurance | `[grounded]` your background and JD wording | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Work pattern (R1, hard_gate) | hard_gate | The JD says fully remote and the careers page says Leeds four days a week; you've stated no constraint | A gate term. The status flips between `conditional_go` and `no_go` on it | Not applicable: this is a term, not experience | A recruiter or employer email stating the work pattern | `[grounded]` both sources |
| G2 | Monitoring rating models (R5b, must_have) | discovery | "Maintained" is the nearest word; no monitoring practice is described | A must-have, and Odile Varga's public talk is about monitoring models. Resolving it likely moves the case toward `conditional_go` | Tracking actual against expected on the live GLM; drift checks or refit triggers; a monitoring pack that flagged a segment; a back-test after a rate change | A sanitized monitoring pack, dashboard screenshot or model-review note | `[grounded]` your wording; `[inferred]` from her talk title that monitoring matters to her |
| G3 | Product-side recommendations (R8b, important) | discovery | Underwriting is covered; product isn't mentioned | An important row, so it can't tip the decision alone | A test result taken to a product or commercial owner; a pricing change agreed outside underwriting | A paper or slide summarising a recommendation | `[grounded]` your background silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Work pattern differs between sources (see R1) | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | The posting may have been revised, one source may be out of date, or your copy may come from a different version. The text doesn't show which | `[inferred]` from the two sources' differing text | Is this role fully remote, or based in the Leeds office four days a week? | unresolved |
| RR2 | Pay not stated | unknown | — | No figure in the JD as given | The offer may sit inside, above or below the market band, or the employer may not publish pay | `[inferred]` from the JD's silence, set against the `[generic]` band | What salary range is budgeted for this role? | unresolved |
| RR3 | Role live on the employer's own careers page | positive_signal | — | "Accepting applications. Senior Pricing Analyst… Own pricing analytics for our pet-insurance product; reports to the Director of Pricing." | The role is real and has a named reporting level | `[grounded]` careers page fetched | What would you want this role to have delivered after its first six months? | noted |
| RR4 | Team and decision rights unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | "Own" with no team or sign-off described may mean a sole analyst or a shared remit; the page doesn't say | `[inferred]` from "own" against the page's silence | Who else is on the pricing team, and who signs off a rate change? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Resolve the work pattern before investing effort: ask through the contact route on Brindlemoor's own careers page | RR1, R1 | `[grounded]` RR1 | pending your approval |
| P1 | Lead with the GLM rating model you built and maintained, and the 14 price tests you ran with underwriting, in your own words | These are the JD's lead items (R4, R5a, R6) | `[grounded]` R4, R5a, R6 | pending your approval |
| P2 | Add monitoring detail only if G2 confirms it, with specifics. Don't write monitoring claims before then | Her public talk is on monitoring; an unconfirmed claim would fail a probe (R5b) | `[inferred]` from her talk title; `[grounded]` R5b | pending your approval |
| P3 | Say plainly that your insurance work is motor, not pet. Don't claim pet-specific knowledge | The JD asks for insurance experience, not pet (R9) | `[grounded]` JD wording; `[generic]` candidates changing lines are commonly asked what transfers and what doesn't | pending your approval |
| P4 | If asked about management, say you haven't line-managed. Don't describe your senior-analyst work as leadership | The JD lists no management requirement | `[grounded]` JD; `[grounded]` your statement | pending your approval |
| P5 | Ask RR1, RR2 and RR4 verbatim before the final stage | The register doubles as interview preparation | `[grounded]` register | pending your approval |

I haven't drafted CV lines because I haven't seen your CV. Resume edits will be proposed as `resume_edits_pending_approval` once I have it.

## Evidence status

Verified: none yet. All of your background is self-report at intake. I've assumed the stage is evaluating.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance careers Senior Pricing Analyst" and fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). It confirmed the employer and a live posting, and surfaced the work-pattern contradiction (R1, RR1) |
| 2. Role-family sweep | yes | Searched "senior pricing analyst pet insurance UK salary remote", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey), read as a snippet only. It set the pay band in role reality (RR2) |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga), read as a snippet only. It fed role reality's footprint row and P2 |

I can write all of this up as `tuesday-dossier.md` if you'd like to keep it.

## Upgrade menu

- Your CV: presentation gaps and confidence on R2 to R9 could be set properly, and edits proposed.
- A sanitized monitoring pack, dashboard screenshot or model-review note: R5b moves toward `direct` and `medium` or better.
- A recruiter or employer email stating the work pattern: R1 and RR1 close.
- Your minimum acceptable salary: RR2 can be set against the £52,100 to £64,900 interquartile range.
- A product-side recommendation you've written: R8b closes.
- A deeper pass on Brindlemoor (funding, leadership changes, public reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

**G1** — Would four days a week in the Leeds office work for you, or is fully remote a requirement?

**G2** — What did you personally do to monitor the young-driver GLM once it was live, and is any of it, such as a monitoring pack, shareable in sanitized form?

**G3** — Have you taken a price-test result to a product or commercial owner rather than underwriting, and what changed because of it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.