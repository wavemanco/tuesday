Checking whether Harborlight Health shows up publicly, and what the market pays for this role, before I build the assessment.
**Yes, apply, with three conditions. Status: `conditional_go`.** R1, R2, R3, R4 and R6 (years of product analytics, SQL, experimentation, Looker, written communication) are `direct`. I couldn't verify the employer, because search permission was refused (see Evidence status).

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R6 · unclear: R5 (Define and maintain the metrics layer)
- `important` — direct: R7a · unclear: R7b (Partner with clinicians), R8 (Mentor two junior analysts)
- `preferred` — adjacent: R9b (HIPAA-type handling of regulated personal data) · absent: R9a (Healthcare data experience)

R5 — probably closable with one answer from you; R7b, R8 — your background is silent, not negative; R9a, R9b — a bridge exists and its limit is named in the map.

**Opportunity ledger.** The role reads as defined and sound, but it is unverified: I couldn't establish the employer (RR1), pay and location aren't stated (RR2, RR3), and it's unclear whether a metrics layer already exists (RR4) or how tightly experiments are constrained (RR5). The scope and named team count in its favour (RR6).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) the posting is live on Harborlight's own careers page (RR1); (2) pay and location, once stated, meet your constraints (RR2, RR3); (3) you can say truthfully what you owned in a metrics layer, or it is framed as adjacent (R5, RR4)

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C | `[grounded]` JD header; not independently checked |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, self-serve Looker, roadmap partnership with PMs and clinicians, mentoring two juniors | `[grounded]` JD |
| Scope read | Senior individual contributor with light people-leadership (two juniors), not a manager role | `[inferred]` from "mentor two junior analysts" and no stated direct-report line |
| First 90 days | Probably take stock of the metrics layer and the test backlog | `[inferred]` from "define and maintain the metrics layer" and the JD stating no outcomes |
| Market calibration | Not run, so there is no pay band to compare against | `[grounded]` the role-family sweep was refused |
| Unknowns | Pay, location or remote policy, reporting line, whether a metrics layer exists, test volume | `[grounded]` absent from the JD as pasted |
| Contradictions | None visible within the JD; no second source to compare against | `[grounded]` JD only |

## Evidence map

Your background is typed prose, so it counts as CV-equivalent self-report. That puts the ceiling at `medium` until an inspectable artifact exists.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | 6 years stated. Experience length is graded as fit, not as a gate | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | "SQL daily on a Snowflake warehouse". You did not rate yourself "expert", so I haven't written that for you | `[grounded]` your background | a sanitized complex query would raise it |
| R3 | Experiment design at scale | must_have | direct | medium | none | "30+ A/B tests a year", plus the pricing test behind an 11% retention lift, at ~2M subscribers. Healthcare experiments typically run on smaller populations and extra review, which is a probe to expect | `[grounded]` your background; `[generic]` healthcare testing pattern | a sanitized test readout would raise it |
| R4 | Looker or similar BI tool | must_have | direct | medium | none | Built the company's Looker instance from scratch, 40+ governed dashboards | `[grounded]` your background | a dashboard screenshot would raise it |
| R5 | Define and maintain the metrics layer | must_have | unclear | low | discovery | "Governed dashboards" suggests shared definitions, but you didn't say who owned metric definitions or any modelling layer. I won't assume it | `[grounded]` your background is silent on the layer itself | see gap G1 |
| R6 | Written communication with non-technical stakeholders | must_have | direct | medium | none | Monthly metrics memo the exec team reads; monthly presentation to the VP Product | `[grounded]` your background | none |
| R7a | Partner with product managers on roadmap decisions | important | direct | medium | none | Monthly presentation to the VP Product shows the partnership. Whether it changed roadmap decisions isn't stated, though the pricing test points that way | `[grounded]` your background | none |
| R7b | Partner with clinicians | important | unclear | none | discovery | Nothing in your background touches clinical or domain-expert partners | `[grounded]` background silent | see gap G2 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Silent on mentoring or managing analysts | `[grounded]` background silent | see gap G3 |
| R9a | Healthcare data experience | preferred | absent | none | capability | No healthcare experience, as you said. Preferred tier, so a minor risk | `[grounded]` your statement | closure path in G4 |
| R9b | HIPAA-type handling of regulated personal data | preferred | adjacent | medium | transferability | GDPR/CCPA consumer PII, plus a consent-state model you built. The limit: health information under HIPAA carries its own rules, such as de-identification and vendor agreements, which these laws did not exercise | `[grounded]` your background; `[generic]` HIPAA differs from consumer-privacy law | see gap G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R5, must_have) | discovery | "Governed dashboards" but no statement of who defined metrics or in what tool | The JD lists it first among responsibilities, and resolving it could take R5 to `direct` | Writing LookML models or explores; owning a metric dictionary; setting the definition of retention or churn that others used; a metric-governance review | A metric dictionary page, a sanitized LookML snippet, a definitions doc | `[grounded]` background silent; `[inferred]` it is the JD's lead duty |
| G2 | Clinician partnership (R7b, important) | discovery | No domain-expert stakeholders mentioned | This role works with clinicians, and a different stakeholder from PMs | Working with culinary, nutrition or food-safety specialists; any subject-matter experts who reviewed your analyses | A write-up or deck co-presented with a specialist | `[grounded]` background silent; `[generic]` that clinician partnership is a real part of such roles |
| G3 | Mentoring (R8, important) | discovery | Silent | Mentoring is a stated duty and the JD names two juniors | Onboarding an analyst, reviewing others' SQL or dashboards, running office hours, or formally managing | An onboarding doc or review checklist | `[grounded]` background silent |
| G4 | Healthcare and HIPAA (R9a, R9b, preferred) | capability for R9a, transferability for R9b | Privacy handling is real; the healthcare domain is absent | It's a "plus", so a minor risk. The bridge to R9b is credible but has a limit | Anything touching health, wellness, dietary or benefits data | A short description of the consent-state model's scope | `[grounded]` your statement; `[generic]` the limit above. Closure path for R9a: HIPAA fundamentals training, or accept it as a stated gap |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "digital-health scale-up, ~400 people, Series C" | The entity may be too new or small for a footprint, the posting may be stale, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your careers site, and who I would report to? | unresolved |
| RR2 | Pay not stated | unknown | — | The JD as pasted gives no salary | Pay may be listed elsewhere, or withheld until later | `[inferred]` from the JD's silence | What is the budgeted range for this role? | unresolved |
| RR3 | Location and work arrangement not stated | unknown | — | The JD as pasted names none | Unknown; could matter against your constraints | `[inferred]` from the JD's silence | Is the role remote, hybrid or on-site, and where? | unresolved |
| RR4 | Metrics layer may not exist yet | unknown | — | "define and maintain the metrics layer" | "Define" may mean the role builds it from nothing, which is a bigger job than maintaining one | `[inferred]` from the verb "define" | Does a metrics layer exist today, and in what tool? | unresolved |
| RR5 | Experiment constraints in a care setting | unknown | — | "design and analyze A/B tests" | Tests touching care pathways may face clinical-safety review and smaller user bases than a consumer subscription | `[generic]` healthcare product pattern | How many tests ran last year, and who approves one that touches a care pathway? | unresolved |
| RR6 | Defined responsibilities and a named team | positive_signal | — | "mentor two junior analysts" | Scope and team size are stated rather than vague | `[grounded]` JD | Who does this role report to? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting on Harborlight's own careers page before investing effort | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask RR2 to RR5 in the recruiter screen | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A3 | Raise the healthcare gap yourself, briefly, in the cover note. Suggested wording: "I haven't worked in healthcare. I have handled GDPR/CCPA consumer PII and built our warehouse's consent-state model." Each clause traces to your own sentences | see R9a, R9b | `[grounded]` your statement | pending your approval |
| A4 | Do not claim HIPAA or healthcare data experience anywhere | see R9a, R9b | `[grounded]` your statement | pending your approval |

Proposed CV edits, `resume_edits_pending_approval`. Each keeps your own scope, verb and numbers:

| # | Proposed line | Traces to your sentence |
|---|---|---|
| E1 | "Built Looker from scratch at a ~2M-subscriber meal-kit company: 40+ governed dashboards" | "Built the company's Looker instance from scratch — 40+ governed dashboards" |
| E2 | "Designed and ran the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift" | Your sentence, unchanged |
| E3 | "Write the monthly metrics memo read by the exec team; present monthly to the VP Product" | "I write the monthly metrics memo the exec team reads and present to the VP Product monthly" |

Keep the 11% as you stated it. If it is percentage points rather than relative, say which.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search "Harborlight Health care navigation app careers Senior Product Analyst" was refused (permission not granted). It would have confirmed the employer and the live posting, so RR1 stays open |
| 2. Role-family sweep | unavailable | Search "senior product analyst digital health salary range Looker experimentation" was refused. It would have set a pay band for the market calibration line and RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given |

I don't treat the refused searches as evidence either way about Harborlight.

I can save this assessment as `tuesday-dossier.md` if you want a copy to carry forward.

**Upgrade menu**

- Search permission → I retry targets 1 and 2, which could close RR1 and set a pay band for RR2.
- The posted salary and location → RR2 and RR3 close, and gate rows can be built against your constraints.
- A sanitized metric dictionary or LookML snippet → R5 moves toward `direct`, and R4 can reach `high`.
- A sanitized readout of the pricing test, including whether the 11% is relative or in points → R3 can reach `high`.
- An onboarding doc or review checklist you wrote → R8 resolves.
- The hiring manager's name → role reality's scope read and which story to lead with.

**Questions**

C1 — Do you have non-negotiables this role's terms could touch, such as a pay floor, remote or location needs, or work authorization? This is the one answer that could turn `conditional_go` into `go` or `no_go`.

G1 — In your Looker work, did you own the metric definitions or the modelling layer (such as LookML), or did someone else? What did you personally define, and did others rely on it?

G3 — Have you onboarded, mentored or managed analysts, even informally? What did you do, and with how many people?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.