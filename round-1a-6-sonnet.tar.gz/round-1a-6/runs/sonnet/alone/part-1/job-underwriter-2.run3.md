I'll read the reference files before building the assessment.
I've finished the evidence and decision references. I'm now reading the research-tier and output rules, then I'll run the L1 research and write the assessment.
## Decision snapshot

**No, you're not wasting your time on the pivot, and this role is worth one targeted attempt. A cold application is the weaker route, so I'd reach the team through a referral or the recruiter. Status: `conditional_go`.** Your own sentences back everything below. You've never held a PM title, and the posting makes 3+ years of PM experience a must-have (R1).

**Fit ledger.**

- `must_have` — direct: R3 · adjacent: R1 (3+ years PM experience), R2 (Shipped API or platform products), R4 (Own the roadmap)
- `important` — direct: R5, R7 · adjacent: R6 (Specs and delivery with two squads) · unclear: R8 (Sales and support launch coordination), R9 (Adoption metrics), R10 (Agile delivery)

R1 — work beside PMs, not a PM title; R2 — shipped integrations for clients, not a product you owned; R4 — fed roadmap input, no evidence yet that you set priorities; R9 and R10 — your CV is silent, and your answers could close them.

**Opportunity ledger.** The scope is concrete (RR4). The employer could not be checked from here (RR1), the pay and location are withheld (RR2), and the decision rights over the roadmap are unstated (RR3). Whether "3+ years" means titled years is unknown (RR5).

- **Hard gates:** none failed; none unconfirmed (the posting states no gate terms); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and the live posting verify (RR1); (2) the recruiter or hiring manager confirms adjacent product-facing experience can meet the 3+ years bar (R1, RR5); (3) roadmap and prioritisation authority proves concrete (R4, RR3); (4) R1, R2 and R4 are always framed as adjacent, never as PM experience you haven't had.

Stage assumed: evaluating.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B | `[grounded]` JD header, not independently checked (research did not run, see Evidence status) |
| Role | Product Manager, Platform APIs: roadmap for a partner-facing API platform, partner discovery, specs, delivery with two engineering squads, adoption metrics, launches with sales and support | `[grounded]` JD |
| First-90-days and year-one outcomes | Not stated. Adoption metrics are to be "defined", with no target given | `[grounded]` JD silent |
| Scope read | One product area, two squads, external partners: an individual-contributor PM post, not a people-management one | `[inferred]` from "two engineering squads" and the absence of any reports |
| Seniority read | A "3+ years" ask is typically a mid-level PM post | `[generic]` role-family pattern |
| Market calibration | Not established: the role-family sweep could not run and the posting withholds pay | `[grounded]` search refused; JD silent on pay |
| Unknowns | Salary, location or remote terms, roadmap decision rights, whether "3+ years" is literal | `[grounded]` JD silent |
| Contradictions | None inside the JD; the careers page was not checked | `[grounded]` JD text; check not run |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years product management experience | must_have | adjacent | medium | transferability | You have 7 years beside PMs and fed product roadmap input, but no PM title. A length-of-experience requirement is a tiered must-have, not a hard gate, so adjacent work counts as evidence. Limit: nothing stated shows you owned a product's priorities. Titled-years bars are often screened literally by recruiters and filters | `[grounded]` your CV-equivalent prose; `[generic]` literal screening of titled-years bars | G1 question; ask the recruiter whether adjacent experience counts (RR5) |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ client integrations of your employer's REST APIs through go-live, and wrote the internal integration playbook. Limit: that is shipping implementations of someone else's API, not shipping the API product. An unconfirmed lead about a request-triage tool may add direct evidence | `[grounded]` CV-equivalent prose; `[inferred]` adjacency; memory lead held as a question only | G1 question |
| R3 | Technical fluency: API docs and schemas | must_have | direct | medium | none | You state Postman, SQL, OpenAPI reading and end-to-end REST integration architecture. Medium because nothing has been inspected yet | `[grounded]` CV-equivalent prose | A sanitized playbook excerpt would raise to high |
| R4 | Own the roadmap for the partner API platform | must_have | adjacent | medium | transferability | You ran quarterly roadmap-input sessions collecting client feedback for product. Limit: you supplied input to product; nothing shows you decided what was built or in what order | `[grounded]` CV-equivalent prose | G1 question |
| R5 | Discovery with integration partners | important | direct | medium | presentation | Scoping workshops and quarterly client feedback sessions are discovery work, but the CV frames them as solutions work rather than product discovery | `[grounded]` CV-equivalent prose | Edit E1, pending your approval |
| R6 | Write specs and drive delivery with two engineering squads | important | adjacent | medium | transferability | You wrote requirements documents and coordinated your engineers, client engineers and PMs on custom builds. Limit: nothing says you drove a squad's delivery or backlog | `[grounded]` CV-equivalent prose | Fold into the G3 question |
| R7 | Stakeholder management across engineering and customers | important | direct | medium | none | You coordinated engineers, client engineers and product managers, and ran client workshops and UAT | `[grounded]` CV-equivalent prose | none |
| R8 | Coordinate launches with sales and support | important | unclear | none | discovery | The CV mentions neither sales nor support, and go-lives are client implementations, not product launches | `[grounded]` CV silence | G4 in the gap queue |
| R9 | Define and track adoption metrics | important | unclear | none | discovery | The CV states no metrics; roadmap-input sessions are not metrics work | `[grounded]` CV silence | G2 question |
| R10 | Agile delivery | important | unclear | none | discovery | The CV never mentions sprints, backlogs or agile ceremonies | `[grounded]` CV silence | G3 in the gap queue |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Product ownership (R1, R2, R4, must_have) | transferability | Strong integration and feedback work; nothing showing you owned a product's priorities or release. Your earlier mention of a request-triage tool that support agents adopted is unconfirmed | These are the three adjacent must-haves, and a confirmed owned tool could be the one direct example of building something others adopted | A tool or process you designed that others used; a feature you argued onto a roadmap; a playbook rollout you drove | A short write-up of the tool, usage numbers, a note from its users | `[grounded]` CV prose; memory lead unconfirmed; `[generic]` that PM screens weigh owned-and-adopted evidence |
| G2 | Adoption metrics (R9, important) | discovery | No metrics stated anywhere | Adoption is the posting's own named measure of success | Time-to-go-live across your 30+ integrations; integrations live versus started; support tickets per integration; playbook usage | A dashboard screenshot, a SQL query or a quarterly report | `[grounded]` CV silence; `[inferred]` that your SQL work may have produced such figures |
| G3 | Agile delivery and squad work (R10, R6) | discovery | No sprint or backlog language | The JD names two squads and agile delivery | Joining sprint reviews; writing tickets or acceptance criteria; prioritising custom builds with engineers | A sample ticket or spec, sanitized | `[grounded]` CV silence |
| G4 | Launches with sales and support (R8) | discovery | Client go-lives only | Launch coordination is a named duty | A client go-live that fed sales or support playbooks; training support on new integrations | A launch checklist or handover document | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The search was refused, so nothing was found either way. The company may be too new or small for a footprint, the posting may be stale, or it may not be a live hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who I would be interviewing with? | unresolved |
| RR2 | Salary and location withheld | unknown | — | none: the posting as pasted states no salary or location | The posting may simply not publish them. The band cannot be set against your floor until they are known | `[grounded]` JD silent | What salary range and location or remote terms are budgeted for this post? | unresolved |
| RR3 | Roadmap authority and success measures unstated | unknown | — | "Own the roadmap for our partner-facing API platform" | The role may carry the roadmap while sales or partners drive priorities | `[inferred]` from "own the roadmap" against the JD's silence on decision rights and targets | Who decides roadmap priorities when partner requests and sales asks conflict, and how will success be measured in year one? | unresolved |
| RR4 | Concrete scope: named product area, two squads, adoption metrics, launches | positive_signal | — | "drive delivery with two engineering squads; define and track adoption metrics" | The scope is defined enough to judge | `[grounded]` JD | Who owns the adoption metrics today? | noted |
| RR5 | Whether "3+ years" requires titled PM years | unknown | — | "3+ years product management experience (must-have)" | A hiring manager may treat adjacent experience as enough, or the filter may be literal | `[generic]` titled-years requirements are often screened literally; the posting is silent on flexibility | Would substantial product-facing experience without a PM title, such as roadmap input and API integration leadership, be considered for this role? | unresolved |

I'm going only on what you've shared, and I can get this wrong. Nothing here is a demand placed on you, so the register holds no hold on any action, and the calls are yours.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Reach the team via a referral or the recruiter, and ask RR5 before investing in a full application | A cold application meets the literal 3+ years bar first | `[generic]` titled-years bars are often screened literally; see R1, RR5 | pending your approval |
| A2 | Verify the live posting on Quartzline's own careers page before applying (RR1) | Cheapest loss to avoid | `[grounded]` RR1 | pending your approval |
| A3 | State plainly in any cover note that you haven't held a PM title, and lead with the 30+ integrations and the roadmap-input sessions | Honest framing survives follow-up questions. Wording to be finalized from your confirmation | `[grounded]` your CV-equivalent prose | pending your approval |
| A4 | Use RR3's and RR5's verification questions verbatim in conversations | The register doubles as interview preparation | `[grounded]` register | pending your approval |

`resume_edits_pending_approval`

| # | Current line (yours) | Proposed line | Source | Status |
|---|---|---|---|---|
| E1 | "Ran quarterly roadmap-input sessions collecting client feedback for product" | "Ran quarterly roadmap-input sessions collecting client feedback for product" moved to the top of the summary, with "30+ client integrations of our REST APIs, end to end" beside it | your two sentences, unchanged in wording | pending your approval |
| E2 | "Wrote the internal integration playbook the whole team uses" | Same wording, moved out of a duties list into a headline achievement | your sentence | pending your approval |

I haven't proposed a PM title or any "owned" or "launched" language, because none traces to your sentences.

## Evidence status

Verified: none yet. Unverified lead: a request-triage tool that support agents adopted, recalled from earlier context and not confirmed by you, so it is a question and not a claim.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Quartzline logistics technology partner API platform Series B careers"; the call was refused, so nothing was returned. It would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | Searched "platform API product manager salary range B2B SaaS Series B career transition from solutions engineer"; the call was refused. It would have moved the market calibration row and the mismatch check on pay (RR2) |
| 3. Hiring manager's public footprint | n/a | No name was given, so no query could be formed |

## Dossier offer

Say the word and I'll save all of this as a `tuesday-dossier.md` you can reuse.

## Upgrade menu

- Your answer on the triage tool, with a write-up or usage figures → R2 and R4 could move toward direct, and G1 closes.
- A sanitized playbook excerpt → R3 to `high`.
- Any adoption or time-to-go-live figures, even from a SQL query → R9 resolves.
- A sample ticket or spec → R6 and R10 resolve.
- The recruiter's answer on the 3+ years bar → RR5 closes and the decision likely simplifies.
- Search permission → targets 1 and 2 rerun, giving RR1 and a pay band. A deeper pass on Quartzline (funding, leadership churn, recent news; up to 5 more searches and 2 more fetches) is also available on your say-so.
- The hiring manager's name → role reality's scope read and which story to lead with.

**Questions**

- **G1** — Tell me about the request-triage tool support agents adopted: did you design it, who used it, and what happened after? Attach a write-up or usage figures if you have them.
- **G2** — Across your 30+ integrations, did you track anything like time-to-go-live or completion rates, and what did you do with those figures?
- **RR2** — What are your non-negotiables for this move: salary floor, location or remote terms, and work authorisation?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.