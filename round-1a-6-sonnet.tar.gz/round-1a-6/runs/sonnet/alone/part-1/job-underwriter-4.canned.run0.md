I'll read the skill's reference files before building the assessment.
Research is finished: I checked Brindlemoor's careers page, a pay survey, and the Director of Pricing's public profile. Here is the assessment.

# Job Underwriting Assessment — Senior Pricing Analyst at Brindlemoor

## Decision snapshot

**Yes, worth a serious look. R2, R3, R4, R5, R6a and R7 land `direct`. But don't apply until the work-pattern contradiction on R1 (RR1) is settled. Status: `hold_pending_answers`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK))
- `must_have` — direct: R2, R3, R4, R5, R6a, R7 · unclear: R6b (monitor rating models)
- `important` — unclear: R10 (recommendations for underwriting and product)
- `preferred` — direct: R8 · adjacent: R9 (pet-insurance product knowledge)

R1 — the one answer that can flip the status; R6b (`low`) — the monitoring half of the role is unconfirmed; R9 (`medium`) — a bridge with its limit named.

**Opportunity ledger.** The JD and Brindlemoor's own careers page disagree on where the job is done (RR1). The salary is withheld (RR2), the company's stage and size are not established (RR3), and who signs off rate changes is unstated (RR5). One entry runs the other way: the named Director of Pricing has spoken publicly on monitoring rating models (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:**
  1. Your answer on remote working (G1). If fully remote is a requirement and the Leeds pattern stands, the status becomes `no_go` on R1.
  2. Brindlemoor confirming the work pattern (RR1).
  3. Your pay floor against the band in role reality (RR2).
  
  If R1 and RR1 resolve in your favour, the status moves to `conditional_go`, with R6b and R9 framed honestly.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, a pet-insurance product. The careers page lists the role as live and says it reports to the Director of Pricing. Stage, size, funding and the "insurtech" label are not established | `[grounded]` careers page fetched; `[grounded]` JD header for "insurtech" |
| Mandate | Own pricing analytics for the pet-insurance product: build and monitor rating models, design and read price tests, make recommendations for underwriting and product | `[grounded]` JD |
| Working pattern | The JD says "Fully remote (UK)". The careers page says "Leeds office four days a week" | `[grounded]` JD and careers page, which conflict |
| Compensation | Not stated in the JD or the careers page snippet | `[grounded]` JD silent |
| Market calibration | UK senior pricing analyst, insurers and insurtechs: median base £58,400, interquartile range £52,100 to £64,900. It is a market band and not this employer's offer | `[generic]` Pricewell 2026 pay survey, one salary search, snippet only |
| Hiring manager | The Director of Pricing spoke at the 2025 Insurance Pricing Forum ("Small Books, Loud Errors", on monitoring rating models in small books). Previously head of pricing analytics at Calloway Re for six years | `[grounded]` public profile, search snippet only |
| Scope read | An individual-contributor post reporting to a Director. The JD lists no line-management requirement, so never having managed anyone is not a stated gap | `[grounded]` JD silent on management; `[inferred]` individual-contributor from the absence of any reports named |
| Unknowns | Salary; team size; first-year outcomes; who signs off rate changes; company stage and funding | `[grounded]` JD and careers page silent |
| Contradictions | Remote versus Leeds four days (R1, RR1) | `[grounded]` as above |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | The JD and the careers page conflict, and you have not stated a location or schedule constraint, so there is nothing to grade | `[grounded]` JD and careers page | G1, then RR1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in pricing analytics at a UK motor insurer, self-reported with nothing inspectable yet | `[grounded]` your message | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily". "Strong" rests on your word alone | `[grounded]` your message | A sanitized query or notebook would raise this to `high` |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for your young-driver book | `[grounded]` your message | Sanitized model documentation would raise this to `high` |
| R5 | Experience presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your message | none |
| R6a | Build rating models | must_have | direct | medium | none | Same GLM build evidence as R4 | `[grounded]` your message | none |
| R6b | Monitor rating models | must_have | unclear | low | discovery | "Maintained" does not establish monitoring: tracking performance, drift or refit triggers. Low, not none, because there is a concrete thread to pull | `[grounded]` your message; `[inferred]` that maintenance may include monitoring | G2 |
| R7 | Design and read price tests | must_have | direct | medium | discovery | You ran 14 price tests last year with the underwriting team. Whether you owned the design as well as the readout is not stated, so it is read downward until confirmed | `[grounded]` your message | G3 |
| R8 | Insurance experience a plus | preferred | direct | medium | none | Five years at a UK motor insurer | `[grounded]` your message | none |
| R9 | Pet-insurance product knowledge (not asked for by the JD, which says only "insurance experience a plus") | preferred | adjacent | medium | transferability | Motor pricing methodology carries over. Limit: you have never worked on pet insurance, so pet-specific rating factors and claims patterns are untested | `[inferred]` requirement from the role owning a pet product; `[grounded]` your motor experience | G5 |
| R10 | Recommendations for underwriting and product | important | unclear | low | discovery | Underwriting-side reporting is evidenced by the quarterly review. Product-facing work is not mentioned | `[grounded]` your message, silent on product | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Work pattern (R1, hard_gate) | hard_gate | JD says remote, careers page says Leeds four days, your constraint not given | A failed gate caps the status, and only your requirement and the employer's written terms settle it | Not an experience gap. It is a term | The employer's written confirmation of the work pattern | `[grounded]` the two sources; `[inferred]` that one may be out of date |
| G2 | Monitoring rating models (R6b, must_have) | discovery | You built and maintained a GLM. Monitoring after launch is not described | A must-have, and the Director's public talk is on this topic. Resolving it likely lifts R6b and shapes the lead story | Tracking actual against expected loss ratios after a release; drift checks or refit triggers; a monitoring pack for underwriting; investigating a segment that moved | A sanitized monitoring pack or dashboard screenshot, a model-governance note | `[grounded]` CV-equivalent silence; `[inferred]` from the Director's talk topic that this matters to the reader |
| G3 | Owning test design (R7, must_have) | discovery | 14 tests run with underwriting; design versus readout ownership is unstated | "Design and read" is the JD's wording, and an interview will ask what was yours | Choosing test cells; sizing or duration decisions; setting success measures; writing the readout | A sanitized test design note or readout deck | `[grounded]` your message; `[generic]` that interviews probe ownership |
| G4 | Product-facing recommendations (R10, important) | discovery | Only underwriting is mentioned | The JD names product as a recipient | A pricing recommendation that went to a product or commercial team | A readout or recommendation memo | `[grounded]` JD wording |
| G5 | Pet-insurance bridge (R9, preferred) | transferability | Motor GLM and tests carry over. No pet exposure | The likeliest objection to your application. Preferred tier, so a risk rather than a blocker | A written outline of how you would approach rating a new product line | A short work sample, proposed in the plan | `[inferred]` bridge from your motor work; `[generic]` that this is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Work pattern contradicts across sources (R1) | risk_signal | medium | JD: "Fully remote (UK)". Careers page: "Leeds office four days a week" | One source may be out of date, the posting may have been written for a different arrangement, or the role may be hybrid with exceptions. None is ranked as likely | `[inferred]` from the two sources disagreeing | Is this role fully remote, or office-based in Leeds four days a week, and is that fixed? | unresolved |
| RR2 | Salary withheld, against a market band | unknown | — | The JD states no pay | The offer may sit inside or outside the band in role reality, or Brindlemoor may not publish salaries | `[generic]` band, set against `[grounded]` JD silence | What is the budgeted base salary for this post? | unresolved |
| RR3 | Company stage, size and funding not established | unknown | — | JD header: "Brindlemoor (insurtech)" | The first search for the company returned no results, so size and stage are open. The careers page and the Director's profile show a live role, so this does not set the standing employer-not-established entry | `[grounded]` first search returned no results; `[generic]` that small companies often have thin footprints | How large is the pricing team, and what stage is the company at? | unresolved |
| RR4 | Named Director of Pricing speaks publicly on rating-model monitoring | positive_signal | — | Public profile: "Small Books, Loud Errors" | The monitoring half of the role may be a real working priority. A talk topic is not a statement of this role's priorities | `[grounded]` public profile snippet; `[inferred]` relevance to this role | How is rating-model performance monitored today, and what would this role own? | noted |
| RR5 | Decision rights over rate changes unstated | unknown | — | "turn the results into recommendations for underwriting and product" | The role may recommend while others decide, with no stated authority or success measures | `[inferred]` from the JD's "recommendations" wording and its silence on sign-off | Who signs off a rate change, and what would success look like in the first year? | unresolved |

## Application plan

Every row is proposed, not applied. Each carries its own status.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before investing in an application, ask Brindlemoor to confirm the work pattern, using the contact route on its own careers page | See R1, RR1 | `[grounded]` RR1 | pending your approval |
| E1 | `resume_edits_pending_approval`: lead with three lines drawn from your own words. "Built and maintained the GLM rating model for the young-driver book." "Ran 14 price tests with the underwriting team." "Present the quarterly pricing review to the head of underwriting." I haven't seen your CV, so these replace nothing yet | See R4, R6a, R7, R5. "Ran" stays "ran" until G3 settles design | `[grounded]` your message | pending your approval |
| E2 | Cover-note line: "I have not worked on pet insurance; I bring five years of UK motor pricing, including building and maintaining a GLM rating model." | See R9. Names the limit rather than hiding it | `[grounded]` your message | pending your approval |
| W1 | A short work sample: your approach to rating a new product line | Narrows the R9 bridge. Content would come from your own method | `[inferred]` from the R9 limit | pending your approval |
| A2 | If asked about management: "I haven't managed anyone" | The JD names no line-management requirement | `[grounded]` JD silent, your message | pending your approval |
| Q1 | Ask the register's verification questions verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A3 | If G2 confirms monitoring work, lead with that story for the Director's talk topic | The reader has published on monitoring rating models | `[inferred]` from the talk topic | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech", which returned no results, and "Brindlemoor careers Senior Pricing Analyst", which returned "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). Fetched that page. Moved: the working-pattern contradiction (R1, RR1), the posting being live, and RR3 (company details not established) |
| 2. Role-family sweep | yes | Searched "senior pricing analyst insurance UK remote salary", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). Moved: the market calibration and RR2. Survey read from the snippet only |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga). Moved: the hiring-manager row, RR4, and plan row A3. Read from the snippet only |

If you'd like these findings carried forward, say so and I'll write them to `tuesday-dossier.md`.

## Upgrade menu

- Your remote or hybrid requirement → R1 resolves, and the status moves to `conditional_go` or `no_go`.
- Brindlemoor's written answer on work pattern → RR1 closes.
- Your pay floor → RR2 is set against the band.
- An answer to G2 → R6b rises and the lead story is chosen.
- An answer to G3 → R7's gap closes.
- A sanitized model document, query sample or monitoring pack → R3, R4 or R6b toward `high`.
- Any product-facing recommendation → R10 (G4).
- A deeper pass on Brindlemoor (funding, leadership changes, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

G1 — Is working fully remote a requirement for you, or are four days a week in a Leeds office workable?

G2 — After your young-driver GLM went live, what did you personally do to monitor it: what you tracked, how often, and what you did when it drifted?

RR2 — What is the lowest base salary you would accept?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.