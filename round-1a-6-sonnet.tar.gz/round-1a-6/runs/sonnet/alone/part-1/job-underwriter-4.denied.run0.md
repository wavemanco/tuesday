I'll read the reference files the skill requires before building the assessment.
Running the company and market searches now, before I write up the assessment.
**Yes, go for this one, on conditions.** R1, R7 and R9 are still open and the employer is unverified (RR1). Status: `conditional_go`. The JD lists no pet-specific requirement and no people-management duty. It asks for "insurance experience" only as "a plus" (R11). I assumed your stage is evaluating.

My web searches were refused, so nothing below about Brindlemoor comes from outside your message. The accounting is under Evidence status.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote, UK-based)
- `must_have` — direct: R2, R3, R4, R5, R6, R8 · unclear: R7 (Design price tests)
- `important` — adjacent: R10 (Own pricing analytics for the whole product) · unclear: R9 (Recommendations to product)
- `preferred` — direct: R11

R10 — a credible bridge, its limit named; R7 (`low`) — design ownership unconfirmed; R9 (`low`) — product audience not yet evidenced.

**Opportunity ledger.** Unverified rather than troubling: the employer is not established from research (RR1), pay is not stated (RR2), and team shape and decision rights are open (RR3). One entry runs the other way: the duties and requirements are specific and consistent with each other (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK-based); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 confirmed; (2) the role and employer verified through Brindlemoor's own careers page (RR1); (3) test-design and product-facing claims (R7, R9) used only as far as you confirm them, and the move from motor to pet framed plainly as a move (R11).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, described as an insurtech with a pet-insurance product; existence and posting not independently established | `[grounded]` JD header, as you supplied it |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reporting line | Hiring manager Odile Varga, Director of Pricing; her public footprint was not researched | `[grounded]` your message |
| Working pattern | Fully remote (UK) | `[grounded]` JD |
| People management | No line-management duty or requirement appears in the posting | `[grounded]` JD text provided |
| Scope read | Reads as a lead-analyst post on one product; team size and decision rights are not stated | `[inferred]` from "Own" in the mandate against the JD's silence on team and authority |
| First-year outcomes | Not stated; likely early work is taking over monitoring of the existing rating models and test readouts | `[inferred]` from the listed duties |
| Market calibration | Not available: the role-family sweep did not run, so no pay band or title norm is given here, and none is implied | n/a — no research ran |
| Unknowns | Salary; team size; who signs off rating changes; tooling and data volume; how mature the product is | — |
| Contradictions | None visible within the text provided; the careers page was not checked | `[grounded]` JD text provided |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK-based | hard_gate | unclear | low | hard_gate | Your message places you at a UK insurer, but it does not say where you live or your right to work. The gate is not settled by that | `[inferred]` from the UK employer in your background | Ask whether the gate is met (R1 question below) |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years pricing analytics, the last 2 as senior analyst. Self-reported, so `medium` is the ceiling until an artifact is seen | `[grounded]` your background message | none |
| R3 | Build and monitor rating models | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. "Maintained" carries the monitoring; the monitoring itself is not described | `[grounded]` your message; `[inferred]` that maintenance includes monitoring | none |
| R4 | GLM experience | must_have | direct | medium | none | Same evidence as R3, stated directly | `[grounded]` your message | A model-documentation or factor-summary extract would raise to `high` |
| R5 | Strong SQL and Python | must_have | direct | medium | none | "Daily" use stated, without a described piece of work | `[grounded]` your message | Offer a sanitized query or notebook as an inspectable artifact |
| R6 | Run and read price tests | must_have | direct | medium | none | You ran 14 price tests with the underwriting team last year | `[grounded]` your message | A sanitized test readout would raise to `high` |
| R7 | Design price tests (not only run them) | must_have | unclear | low | discovery | "Ran" does not say who set the design: groups, duration, success measure. The JD says "design and read". Carried as unclear, not assumed in your favour | `[grounded]` your wording; `[generic]` that "design" and "run" are different claims at interview | Gap queue G1 |
| R8 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. Actuarial audiences are not mentioned | `[grounded]` your message | A sanitized review deck would raise to `high` |
| R9 | Recommendations for product, not only underwriting | important | unclear | low | discovery | Your evidence is all with underwriting; nothing yet shows work with a product team | `[grounded]` your message's silence on product | Gap queue G2 |
| R10 | Own pricing analytics for the whole pet product | important | adjacent | medium | transferability | You owned the model for one book (young drivers). Limit: owning a whole product's pricing is wider, and that breadth is not evidenced | `[grounded]` your message; `[inferred]` that "Own" means whole-product scope | Gap queue G3 |
| R11 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer meets the wording. Pet is a different line and you have not worked on it. Pet rating usually turns on different factors from motor, so expect domain questions | `[grounded]` your message; `[generic]` on pet versus motor rating | Say "motor to pet" plainly (plan row P1) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Design price tests (R7, must_have) | discovery | 14 tests run with underwriting; nothing on who chose the design | A must-have row at `unclear`; settling it could lift the row to `direct` or confirm a limit | Choosing control and test groups; setting how long a test runs or how big it must be; writing the test plan before launch; agreeing the success measure with underwriting | A sanitized test plan or readout | `[grounded]` your message; `[generic]` that design ownership is what this duty is read as |
| G2 | Recommendations to product (R9, important) | discovery | Underwriting audience only | The JD names product as a recipient of the recommendations | Taking a test result or model finding to a product, proposition or commercial team; a pricing change that shaped a product feature | A sanitized recommendation note or meeting paper | `[grounded]` your message's silence on product |
| G3 | Whole-product ownership (R10, important) | transferability | Owned one book's GLM | The adjacent case is credible; its limit is breadth | Pricing work across more than one book; a rate review covering a whole product; being the single analyst on a model end to end | A sanitized scope description or model inventory | `[inferred]` bridge from the young-driver model |
| G4 | UK-based remote working (R1, hard_gate) | hard_gate | UK employer, location and work rights unstated | A gate term; only a fact about your situation settles it | Not an experience question | Your own statement is enough | `[grounded]` your message's silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small for a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer; none of these is ranked as likely | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your own careers site, and who I would be interviewing with? | unresolved |
| RR2 | Salary not stated | unknown | — | No pay figure appears in the posting as provided | The post may withhold pay, or the figure may be missing from the copy you pasted | `[inferred]` from the JD's silence | What salary range is budgeted for this post? | unresolved |
| RR3 | Ownership asserted, decision rights and team unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | The analyst may advise on rate changes without sign-off authority, or may be the only pricing analyst | `[inferred]` from "Own" against the JD's silence on team and authority | Who sits in the pricing team, and who signs off a rating change? | unresolved |
| RR4 | Duties and requirements specific and consistent | positive_signal | — | "build and monitor rating models, design and read price tests" | Scope appears defined, with requirements mapping onto the duties | `[grounded]` JD | What would success look like in the first year? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Move your GLM build-and-maintain work and the 14 price tests with underwriting to the top of the CV, ahead of tools and skills lists, adding no new facts | see R3, R4, R6 | `[grounded]` your message | resume_edits_pending_approval |
| P1 | Say plainly that your insurance pricing is motor, new to pet, and that the GLM and test workflow carries over; never imply pet experience | see R11 | `[inferred]` from R11 | pending your approval |
| P2 | Do not raise people management; if asked, say you have not line-managed, since the JD asks for none | see Role reality, People management | `[grounded]` JD | pending your approval |
| A1 | Find the role on Brindlemoor's own careers page before investing effort | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Prepare one sanitized test walk-through: what was tested, who set the design, the result, the decision | see R7, R9 | `[grounded]` R7, R9 rows | pending your approval |
| A3 | For Odile Varga as Director of Pricing, lead with the test-and-present story (R6, R8) before the model | see R6, R8 | `[inferred]` from her title only; no footprint was researched | pending your approval |
| Q1 | Ask RR1 to RR4's questions in the loop | the register doubles as interview preparation | `[grounded]` register | pending your approval |

Nothing in this plan, the prose rows included, is final until you approve it.

## Evidence status

Verified: none yet. Unverified leads: none. Everything in the evidence map rests on your typed background, which is self-report; no document has been read.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Brindlemoor pet insurance insurtech" and "Brindlemoor careers Senior Pricing Analyst"; both refused. Would have moved: role reality's organization and contradictions rows, and RR1 |
| 2. Role-family sweep | unavailable | Searched "senior pricing analyst insurance UK salary remote 2026"; refused. Would have moved: role reality's market calibration and the RR2 check against a band |
| 3. Hiring manager's public footprint | unavailable | Searched "Odile Varga Director of Pricing"; refused. Would have moved: role reality's scope read and plan row A3 |

If you'd like a saved record of this assessment, I can write it up as `tuesday-dossier.md`.

## Upgrade menu

- Search permission granted: the three targets above rerun, which would settle RR1, give a pay band against RR2, and ground A3.
- Your location and right-to-work status: closes R1, the only gate row.
- Your pay floor or other non-negotiables: adds gate rows, so pay can be checked against RR2.
- A sanitized price-test plan or readout: raises R6 toward `high` and settles R7.
- A sanitized slide from the quarterly pricing review: raises R8 toward `high`.
- A model-documentation or factor-summary extract for the young-driver GLM: raises R3 and R4 toward `high`.
- Your CV itself, since only your typed summary has been read: lets E1 be drafted against your real wording.

R1 — Are you based in the UK, and are you able to work remotely for a UK employer without needing sponsorship?

R7 — On the 14 price tests, which parts of the design were yours (what was tested, how groups were split, how long each ran), and what pricing decision followed?

R9 — Have you taken pricing results to a product or commercial team, not only underwriting, and what changed as a result?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.