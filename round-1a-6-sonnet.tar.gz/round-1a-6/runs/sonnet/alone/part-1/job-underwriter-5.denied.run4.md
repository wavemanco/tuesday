I'll read the reference files the skill requires before building the assessment.
**Yes, it's worth applying, with conditions.** R3, R4, R5, R6, R7 and R8 (the six `must_have` rows) are all `direct`. R1 and R2 are the gates, and they depend on your own location and pay floor. Status: `conditional_go`. I couldn't confirm the employer from outside the text you pasted (RR1), which caps the status there.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote (US) or our Denver office), R2 (Salary $148,000–$166,000 plus equity)
- `must_have` — direct: R3, R4, R5, R6, R7, R8
- `important` — adjacent: R9 (a dbt-modelled warehouse in BigQuery); unclear: R10 (the data contracts our analysts depend on), R11 (ingestion from our app and CRM)

R9 (`medium`) — a Snowflake-to-BigQuery bridge, its limit named; R10, R11 — your background is silent on both; R1, R2 — waiting on your own location and pay floor.

**Opportunity ledger.** The pay is stated, and it sits around the provided market median (RR5). The employer is not established from here (RR1). The team, reporting line, run duties and equity terms are unstated (RR2, RR3, RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or our Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting and employer verify against Pellucid's own careers page (RR1); (2) your location and pay floor fit R1 and R2; (3) the BigQuery bridge is framed as adjacent, never as BigQuery experience (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` the About text you pasted; not independently confirmed |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, and the data contracts analysts depend on | `[grounded]` JD |
| Stack and terms | dbt, BigQuery, Airflow or similar, data quality testing; Remote (US) or Denver; $148,000–$166,000 plus equity | `[grounded]` JD |
| First-year outcomes | None stated | `[grounded]` JD silence |
| Scope read | Three named areas (ingestion, warehouse, contracts) and no people management in the requirements. That is compatible with the report's typical scope of one domain's pipelines and no direct reports. The JD names no team, so I can't tell whether you'd be one of several engineers or the only one | `[inferred]` from the JD set against the report's scope description |
| Market calibration | Senior DE at Series B–D: base median $151,000, interquartile range $139,000–$163,500, "Senior" typically 5–8 years (Datawright 2026, n=2,310). The posting's $148,000 sits just under the median and its $166,000 just over the upper quartile. Your 6 years fall inside the 5–8 band. Series C falls inside the sample's B–D stage range. The report is base pay, so the equity is on top and unquantified | `[generic]` band, from the report your recruiter sent; I have the figures you gave, not the report itself, and ran no search. `[grounded]` the posting's figures. `[inferred]` that "Salary" means base |
| Unknowns | Hiring manager (none named), team size, whether the seat is new or a backfill, equity terms, on-call or "run" duties | `[grounded]` JD silence |
| Contradictions | None between the JD and the About text as you pasted them. Neither has been checked against the live pages | `[grounded]` both pasted texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or our Denver office | hard_gate | unclear | none | hard_gate | The posting allows US-remote or Denver. Your location and US work authorization aren't in what you gave me, so the gate isn't established. Confidence is `none` because you've stated no constraint to grade. | `[grounded]` JD; your silence. `[inferred]` that "Remote (US)" means living in the US | Closing question R1, R2 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | The range is stated, but you gave no pay floor, so whether it clears your constraint is not established. The market comparison is in role reality and RR5. | `[grounded]` JD; your silence | Closing question R1, R2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You describe 6 years of data engineering at a B2B payroll company. That is stated and specific, but it's self-report with no inspectable artifact yet. A length requirement is graded as fit, not as a gate. | `[grounded]` your prose background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily" is confirmed use. "Strong" can't be inspected from prose. Expect a probe. | `[grounded]` your prose background | Optional: a sanitized code sample would raise it to `high` |
| R5 | dbt | must_have | direct | medium | none | "Built our dbt project on Snowflake — about 180 models". It's specific and states ownership of the build. Limited inspectable proof so far. | `[grounded]` your prose background | A dbt docs or lineage screenshot would raise it to `high` |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse. The requirement list says "a cloud warehouse", not BigQuery, which appears only in the mandate (R9). | `[grounded]` your prose background; JD wording | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | "Airflow for orchestration" is confirmed use. Your own depth (writing DAGs versus maintaining them) isn't stated, so I don't claim more. | `[grounded]` your prose background | A sanitized DAG or project structure would raise it to `high` |
| R8 | Experience with data quality testing | must_have | direct | medium | none | "I set up our Great Expectations test suite" is specific and states ownership. No inspectable artifact yet. | `[grounded]` your prose background | A suite config or expectation list would raise it to `high` |
| R9 | A dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | You've never used BigQuery. The bridge is the same dbt and SQL practice on a different warehouse. The limit is that you've exercised none of BigQuery's own behaviour: its cost model, partitioning and clustering choices. | `[inferred]` bridge from your dbt-on-Snowflake work. `[generic]` that warehouses differ in cost and layout mechanics | See G3 |
| R10 | The data contracts our analysts depend on | important | unclear | low | discovery | Your background doesn't mention contracts. Your test suite and 180-model project may touch this, but that's unconfirmed, so it stays a lead and not a claim. | `[grounded]` your silence. `[inferred]` the lead | G1 in the closing question |
| R11 | Ingestion from our app and CRM | important | unclear | low | discovery | You mention Airflow orchestration but not which source systems your pipelines ingested. | `[grounded]` your silence | G2 in the closing question |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Data contracts (R10, important) | discovery | No mention of schema, freshness or ownership agreements with analysts | The JD names the contracts as something analysts depend on, so it's likely a probe. Resolving it moves a row from unclear toward direct | Enforced dbt tests or model contracts that analysts relied on; a published freshness or SLA agreement; the Great Expectations suite alerting a data consumer; agreeing a column definition with an analyst team | A sanitized dbt schema file, an SLA note, or an alert runbook | `[grounded]` your silence. `[generic]` that contracts are probed in roles that name them |
| G2 | App and CRM ingestion (R11, important) | discovery | Orchestration is stated, but not which sources fed the pipelines | The mandate leads with ingestion, so the source types are the likeliest follow-up | Pulling from a product database or event stream; syncing a CRM or a third-party API; handling schema drift or backfills | A sanitized DAG or source list | `[grounded]` your silence. `[inferred]` the mandate's emphasis from the JD's order |
| G3 | BigQuery (R9, important) | transferability | Strong dbt and SQL on Snowflake, no BigQuery | It's named in the mandate but not in the requirement list, so it reads as learnable. The limit is that you have no BigQuery history | Not applicable: you said you've never used it. The strengthener is a small BigQuery sandbox project (E3) | A small public or sanitized dbt-on-BigQuery project | `[inferred]` from the JD's wording. `[generic]` that adjacent-warehouse moves are common |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states. Founded 2016, Denver. 264 employees. Series C ($52M, February 2026)." | The entity may be too new or small to have a footprint I could reach, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Team, reporting line and scope boundaries unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | The seat may be one of several engineers or the sole one, and the scope may exceed one domain | `[inferred]` from the JD's silence on team set against the report's typical scope | Who would I report to, how big is the data team, and is this a new seat or a backfill? | unresolved |
| RR3 | "Run" duties unstated | unknown | — | "Build and run the pipelines" | Running pipelines may include on-call or after-hours support | `[inferred]` from the word "run" and the JD's silence on schedule | Is there an on-call rotation for these pipelines, and how often does it page? | unresolved |
| RR4 | Equity unquantified | unknown | — | "Salary $148,000–$166,000 plus equity" | The grant's type, size and vesting aren't given, so its value can't be set against the base | `[grounded]` JD wording | What equity is offered at this level: type, size, vesting, and the latest valuation basis? | unresolved |
| RR5 | Pay stated up front, near the provided market median | positive_signal | — | "$148,000–$166,000 plus equity" | The posting is transparent about base pay, and its range straddles the median and runs just past the upper quartile | `[grounded]` JD figures and the figures you gave from the report. `[inferred]` that "Salary" is base | Which part of the range is budgeted for this seat? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting is live on Pellucid's own careers page and that the text matches what you pasted; apply there | RR1 | `[grounded]` RR1 | pending your approval |
| E1 | Proposed resume line: "Built the dbt project on Snowflake (about 180 models); set up the Great Expectations test suite; Airflow for orchestration; Python and SQL daily." Each clause quotes your own sentence. Nothing claims contracts, BigQuery or ingestion sources | R5, R7, R8, R4 | `[grounded]` your prose background | resume_edits_pending_approval |
| E2 | Proposed answer on BigQuery: "I haven't used BigQuery; my warehouse work has been dbt on Snowflake." This states the gap and nothing more | R9 | `[grounded]` your prose background | pending your approval |
| E3 | Optional work sample: a small dbt project on a BigQuery sandbox. Add it to your CV only after it exists | R9, G3 | `[inferred]` closure path for a transferability gap | pending your approval |
| A2 | Ask your recruiter whether they know the hiring manager and the reporting line, since the posting names none | RR2 | `[grounded]` the posting names no hiring manager | pending your approval |
| Q1 | Ask RR2, RR3 and RR4's verification questions verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | One search ("Pellucid Learning Denver online tutoring K-12 Series C") and one fetch (pellucidlearning.com/careers/senior-data-engineer) were each refused for lack of permission, and nothing came back. This would have moved RR1 and role reality's organization and contradictions rows |
| 2. Role-family sweep | skipped | The report's figures you pasted fix the market calibration and scope read, and RR5. No search was sent |
| 3. Hiring manager's public footprint | n/a | The posting names no one, so there was no query to form |

I can write this up as `tuesday-dossier.md` if you'd like to carry it forward.

## Upgrade menu

- **Your current CV:** lets me check whether R3–R8 are communicated well, or buried, and tighten E1.
- **Inspectable artifacts:** a dbt docs or lineage screenshot, a sanitized DAG or project structure, or a Great Expectations suite config. These would raise R5, R7 and R8 from `medium` to `high`.
- **Your answers to G1 and G2:** these move R10 and R11 off `unclear`.
- **Your location, work authorization and pay floor:** these settle R1 and R2.
- **The hiring manager's name:** feeds the scope read and which story the plan leads with.
- **Web access for this session:** this closes RR1 by checking the careers page and the company. A deeper pass on funding, leadership changes and news would then be up to 5 more searches and 2 more fetches, and I'd run it only on your say-so.

**Questions**

- R1, R2 — Do the location terms (remote anywhere in the US, or Denver) and the pay range ($148,000–$166,000 plus equity) both work for you?
- G1 — Did you define or enforce agreed expectations between your pipelines and the analysts using them, such as dbt tests or contracts they relied on, a freshness or SLA agreement, or alerts from your Great Expectations suite? What did you own, and what happened?
- G2 — Which source systems did your pipelines ingest at the payroll company (app databases, event streams, a CRM, third-party APIs), and which did you build yourself?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.