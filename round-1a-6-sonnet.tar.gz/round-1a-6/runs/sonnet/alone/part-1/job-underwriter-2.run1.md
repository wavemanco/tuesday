*The host declined both web searches, so this runs on your JD and resume alone.*

## Decision snapshot

**No, applying isn't a waste of your time, but R1a (3+ years of titled PM experience) is absent and will be the hurdle. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R3, R4a · adjacent: R1b (PM experience, adjacent work), R2 (Shipped API or platform products) · unclear: R4b (Stakeholders across sales), R5 (Agile delivery) · absent: R1a (3+ years titled PM experience)
- `important` — direct: R6 · adjacent: R7 (Own roadmap, write specs, drive two squads), R9 (Launches with sales and support) · unclear: R8 (Define and track adoption metrics)

R1a — titled years absent, which no wording changes; R1b (`medium`) — adjacent work, its limit named; R2 (`medium`) — integrations delivered, not an API product shipped.

**Opportunity ledger.** The employer isn't established from here (RR1) and the posting leaves open whether adjacent experience counts toward the three years (RR2). Pay, location and level are unstated (RR3), and so are success targets (RR5). The scope is named: a partner API platform, two squads and defined responsibilities (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. The posting verifies on Quartzline's own careers page (RR1).
  2. You get an answer that adjacent experience can count toward the three years (R1a, RR2).
  3. Your title stays honest in everything you send (R1a, R1b).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B; not independently confirmed | `[grounded]` JD header |
| Mandate | Own the roadmap for the partner-facing API platform; discovery with integration partners; specs; delivery with two engineering squads; adoption metrics; launches with sales and support | `[grounded]` JD |
| First-90-days outcomes | Not stated. Likely: partner discovery plus an adoption baseline | `[inferred]` from "run discovery with integration partners" and "define and track adoption metrics" |
| Scope read | A full-cycle product-owner remit for one platform, with no level label such as "Senior" or "Associate" | `[inferred]` from the responsibilities list and the JD title line |
| Market calibration | Not run, because the role-family search was declined, so no pay band is stated | — |
| Unknowns | Pay, location or remote policy, level, roadmap decision rights, success targets, and your non-negotiables | `[grounded]` JD silence |
| Contradictions | None inside the JD; not checked against a careers page | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years product management experience, titled | must_have | absent | none | capability | You confirmed you have never held a PM title. A years requirement isn't a gate, and the adjacent work is carried in R1b | `[grounded]` your statement | Carry as the main risk; test it with RR2's question |
| R1b | The same requirement, met by adjacent work | must_have | adjacent | medium | transferability | Quarterly roadmap-input sessions for product, coordinating PMs and engineers on custom builds, and requirements documents. The resume doesn't show you owning prioritisation or release decisions | `[grounded]` resume | See G2 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ client integrations of your vendor's REST APIs and wrote the integration playbook. The resume doesn't show you owning an API's design, release or versioning | `[grounded]` resume | See G1 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI reading and integration architecture are stated and specific. No inspectable artifact yet | `[grounded]` resume | Offer: a sanitized architecture diagram or playbook excerpt raises it to `high` |
| R4a | Stakeholder management across engineering and customers | must_have | direct | medium | none | You coordinated your engineers, client engineers and PMs, across 30+ client engagements | `[grounded]` resume | Offer: a playbook excerpt |
| R4b | Stakeholder management with sales | must_have | unclear | low | discovery | The resume is silent on sales | `[grounded]` resume silence | See G3 |
| R5 | Agile delivery | must_have | unclear | low | discovery | UAT and go-live are stated; no delivery method is | `[grounded]` resume silence | See G4 |
| R6 | Run discovery with integration partners | important | direct | medium | presentation | Scoping workshops and quarterly client-feedback sessions are discovery work. The resume frames them as implementation | `[grounded]` resume | Edit E1, pending approval |
| R7 | Own roadmap, write specs, drive delivery with two squads | important | adjacent | medium | transferability | You fed roadmap input and wrote requirements. Who decided priorities, and whether specs went to squads, isn't shown | `[grounded]` resume | See G2 |
| R8 | Define and track adoption metrics | important | unclear | low | discovery | The resume is silent. A prior-conversation lead about a triage tool is unconfirmed, so it only prompts a question | `[grounded]` resume silence; memory_lead | See G1 |
| R9 | Coordinate launches with sales and support | important | adjacent | medium | transferability | Client go-lives are launches of a kind. Product launches with sales and support aren't shown | `[grounded]` resume | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Shipped product and adoption (R2, R8) | discovery | Nothing in the resume. A memory lead suggests an internal request-triage tool that support agents adopted, unconfirmed | If confirmed and specific, it could be your clearest evidence of building something people adopted | What the tool did, what you decided or specified, who used it, how you knew it worked | A spec, screenshot, usage figures or the ticket history | `[grounded]` resume silence; `[inferred]` it could move R2 and R8 |
| G2 | Ownership of priorities (R1b, R7) | discovery | Roadmap input is stated; the decision is not | Separates "informed the roadmap" from "owned it", which is the PM line | A client request you pushed into a release; a trade-off you argued; specs engineers built from | Session notes, a requirements doc, a release note | `[grounded]` resume; `[generic]` PM interviews probe this line |
| G3 | Sales and launch work (R4b, R9) | discovery | Silent on sales or support involvement | R4b is a must-have row currently `unclear` | Joint client calls with sales; go-live handoffs to support; enablement material | A handoff doc or launch checklist | `[grounded]` resume silence |
| G4 | Agile delivery (R5) | discovery | Method not stated | A must-have row currently `unclear` | Sprints with client builds, backlog grooming, standups with engineers | A board export or sprint notes | `[grounded]` resume silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Titled-years requirement may be screened literally | risk_signal | low | "3+ years product management experience (must-have)" | A recruiter screen could drop R1a before R1b and R2 are read, or adjacent experience could be negotiable | `[generic]` how must-have screens often work; `[grounded]` the JD flags it must-have | Would leading API integrations and running roadmap-input sessions count toward the three years? | unresolved |
| RR3 | Pay, location and level unstated | unknown | — | "Product Manager, Platform APIs — Quartzline" (no pay, location or level) | Pay may sit above or below your floor, which I can't judge without a band or your constraints | `[grounded]` JD silence | What are the salary range, work location or remote policy, and level? | unresolved |
| RR4 | Scope and responsibilities explicit | positive_signal | — | "Own the roadmap for our partner-facing API platform ... drive delivery with two engineering squads" | The role has a defined product, team and mandate | `[grounded]` JD | Which roadmap decisions does this role make alone? | noted |
| RR5 | Success targets unstated | unknown | — | "define and track adoption metrics" | The role sets the metrics, so targets may not exist yet | `[inferred]` from the JD wording | What does success look like in year one, and what adoption baseline exists today? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting on Quartzline's own careers page before investing effort | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask RR2's question early, and try a referral or a direct note to the hiring manager rather than a cold application | Adjacent-background candidates often get past literal screens through a person | `[generic]` hiring pattern | pending your approval |
| P1 | In your first two sentences, say you haven't held a PM title, that you led 30+ client integrations of your employer's REST APIs, and that you ran quarterly roadmap-input sessions | Honest framing, traced to your own sentences (R1a, R1b, R6) | `[grounded]` your resume and statement | pending your approval |
| W1 | A one-page sanitized synthesis from one roadmap-input session, if you can share it | Evidence for R6 and R7 | `[grounded]` R6, R7 rows | pending your approval |
| A3 | Also look at API, integration or platform PM postings that don't flag 3+ PM years as must-have | R1a is the hurdle here | `[generic]` role-family pattern | pending your approval |
| Q1 | Ask RR1 to RR5's questions verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

`resume_edits_pending_approval` — nothing here is final until you approve it:

| # | Current | Proposed | Source | Audit note |
|---|---|---|---|---|
| E1 | Not provided as a summary line | "Solutions engineer and implementation lead, 7 years: took 30+ client integrations of our REST APIs from scoping through go-live; coordinated our engineers, client engineers and product managers on custom builds; ran quarterly sessions collecting client feedback as roadmap input for product." | Your own sentences | Each clause traces to your text. It claims no PM title, no roadmap ownership and no metrics |

## Evidence status

Verified: none yet. Unverified lead: a possible internal request-triage tool, which only prompts G1.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Quartzline logistics technology partner API platform careers Product Manager"; refused. It would have settled RR1 and the organization row |
| 2. Role-family sweep | unavailable | Searched "platform API product manager salary Series B B2B SaaS requirements transition from solutions engineer"; refused. It would have given market calibration and a pay band against RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Upgrade menu

- A sanitized architecture diagram or playbook excerpt → R3 and R4a toward `high`.
- A spec, screenshot or usage figures for the triage tool → R2, R8 and R1b strengthen.
- Notes from one roadmap-input session, or a release note a client request shaped → R7 and R6 strengthen.
- A link to the live posting on Quartzline's careers page, or the recruiter's email domain → RR1 closes.
- Your pay floor, location and other non-negotiables → gate rows get built and RR3 is checked.
- The hiring manager's name → the scope read and which story to lead with.
- Search access, or a deeper research pass (up to 5 more searches and 2 more fetches) → the missing role-family band and company diligence; say the word and it runs.

I can also write this up as `tuesday-dossier.md` if you'd like a copy to keep.

G1 — An earlier conversation suggested you built an internal request-triage tool that support agents adopted. Is that right? If so, what did you decide or specify yourself, who used it, and how did you know it worked?
G2 — On a roadmap-input session or a custom build, can you name a client request you pushed into a release? Who made the final call, and what did you write that engineers built from?
G3 — Have you worked directly with sales or support on a client go-live, and what was your part?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.