I'm reading the skill's decision-snapshot and research-accounting rules, then I'll write the assessment.
Yes, apply. You fit well on what the posting calls essential. The status is `conditional_go` because I couldn't verify Harborlight Health from here.

**Short answer:** Your strongest evidence lines up directly with the core requirements. The real gaps are smaller: the metrics layer, mentoring, and healthcare/HIPAA. None of them is a blocker on what you've told me.

## Decision snapshot

**Yes, you're a fit, and worth applying to once the posting verifies. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R5 · unclear: R6 (Define and maintain the metrics layer)
- `important` — adjacent: R7 (Partner with clinicians) · unclear: R8 (Mentor two junior analysts)
- `preferred` — adjacent: R9 (Healthcare data experience, HIPAA)

R6 — likely strong, but the CV doesn't show it; R9 — a bridge with a stated limit.

**Opportunity ledger.** The scope is clearly written and names concrete tools and partners (RR3). Pay is withheld (RR2), and the employer couldn't be confirmed because searches were refused (RR1).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the role is live on Harborlight's own careers page (RR1); (2) the pay range is workable for you (RR2); (3) healthcare is framed as adjacent, never as HIPAA experience (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up of about 400 people at Series C | `[grounded]` JD header; not independently verified (RR1) |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, self-serve Looker, roadmap partnership | `[grounded]` JD |
| Team shape | Senior individual contributor with two junior analysts to mentor, so mentoring is a duty and not a full management role | `[inferred]` from "mentor two junior analysts" with no mention of hiring or performance reviews |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Market calibration | Not run, because the role-family search was refused. Pay and title norms are unknown | `[generic]` |
| Unknowns | Pay; whether a metrics layer already exists or is to be built; reporting line; how much clinician access you'd get | `[grounded]` JD silent |
| Contradictions | None within the JD; not checked against a careers page | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | You state six years in consumer-subscription product analytics. This is a CV-level claim with no inspectable artifact | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake over a 2M-subscriber base is the right shape. "Expert" is probed in interviews, and a query sample would help | `[grounded]` your background | optional: a sanitized query sample would raise to high |
| R3 | Experiment design at scale | must_have | direct | medium | none | You designed and ran the program at 30+ tests a year, including the pricing test behind an 11% retention lift. This is your strongest row, but it is stated and not documented | `[grounded]` your background | a sanitized test write-up would raise to high |
| R4 | Looker or similar BI tool | must_have | direct | medium | none | You built the instance from scratch with 40+ governed dashboards, which exceeds "Looker or similar" | `[grounded]` your background | a dashboard screenshot would raise to high |
| R5 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads and present monthly to the VP Product | `[grounded]` your background | a redacted memo would raise to high |
| R6 | Define and maintain the metrics layer | must_have | unclear | low | discovery | "Governed dashboards" and the consent-state model suggest metric definitions work, but you haven't said you owned a semantic or metrics layer such as LookML or a metric dictionary. I won't assume it | `[inferred]` from governed dashboards; `[grounded]` CV silent on the layer itself | G1 |
| R7 | Partner with product managers and clinicians | important | adjacent | medium | transferability | PM and VP Product partnership is direct. Clinicians are a different stakeholder, and nothing you've said exercised clinical expertise in decisions | `[grounded]` VP Product work; `[grounded]` no clinician evidence | G3 |
| R8 | Mentor two junior analysts | important | unclear | low | discovery | Your background is silent on mentoring or reviewing others' work | `[grounded]` background silent | G2 |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | You have GDPR/CCPA consumer-PII handling and built the consent-state model, which is real privacy-governed data work. It has not exercised PHI, HIPAA safeguards or clinical data. It is only preferred | `[grounded]` your background | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R6, must_have) | discovery | Governed dashboards and a consent-state model, but no stated ownership of metric definitions | It is the first-listed responsibility and a must-have, so resolving it is the biggest swing in the map | Writing LookML or a metric dictionary; agreeing a canonical "active subscriber" or "retention" definition across teams; deprecating conflicting metrics; a governance review | A metric-definition doc, LookML excerpt, or definitions page (sanitized) | `[grounded]` CV silence; `[generic]` that this role family probes metric ownership |
| G2 | Mentoring (R8, important) | discovery | Nothing stated on supervising or coaching others | The role names two juniors, so an interviewer will ask | Reviewing a junior's queries or test designs; onboarding a new analyst; running an analytics office hour; training PMs on self-serve Looker | A teaching doc or onboarding guide | `[grounded]` CV silence; `[generic]` that interviews probe this |
| G3 | Clinician partnership and healthcare data (R7, R9) | transferability | Strong PM partnership, plus privacy-governed consumer data (GDPR/CCPA, consent model). Limit: no clinical stakeholders and no PHI or HIPAA handling. Strengthener: a short, honest note on how the consent-state model worked, and some reading on HIPAA basics (self-study, not experience) | R9 is only preferred, so this is a talking point and not a blocker | Working with a domain specialist, such as a nutritionist or food-safety lead, on a metric or test | A one-page description of the consent-state model | `[grounded]` background; `[generic]` that digital-health teams usually weigh domain fluency |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "digital-health scale-up, ~400 people, Series C" | The company may be too new or small to rank in search, the posting may be stale or aggregated, or it may not represent a real hiring employer. None of these is more likely than the others | `[generic]` pattern, not a claim about this company | Can you point me at the role on Harborlight's own careers page, and who would I interview with? | unresolved |
| RR2 | Compensation not stated | unknown | — | no figure in the posting | The posting withholds pay, so I can't compare it with what a senior analyst at a Series C digital-health company usually earns. Withholding is itself worth a question | `[grounded]` JD silent; `[generic]` no market band was sourced | What is the budgeted range for this level? | unresolved |
| RR3 | Scope and partners are concrete | positive_signal | — | "own product analytics for our care-navigation app… partner with product managers and clinicians" | The mandate names specific tools, stakeholders and deliverables, which reads as a defined role | `[grounded]` JD | Which three decisions did analytics change last quarter? | noted |
| RR4 | Metrics layer: build or maintain? | unknown | — | "define and maintain the metrics layer" | It may already exist, or "define" may mean building it from scratch alongside the day job | `[inferred]` from "define and maintain" | Is there an existing metrics layer, and who owns it today? | unresolved |

## Application plan

All rows are proposals. Nothing below is final or sent until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with the experimentation program: "Designed and ran the experimentation program (30+ A/B tests a year), including the pricing test behind an 11% retention lift" | R3 is your strongest direct row. The wording keeps your stated role and claims no more than you said | `[grounded]` your background | pending your approval |
| E2 | Describe the consent-state model as: "Built the warehouse consent-state model used to handle GDPR/CCPA consumer PII." Do not write HIPAA, PHI, or "healthcare experience" | R9 is adjacent, and the wording stays within what you did | `[grounded]` R9 row | pending your approval |
| E3 | Add a mentoring line only if G2 confirms it, and use the confirmed facts | R8 is unclear | `[grounded]` R8 row | pending your approval |
| A1 | Confirm the posting on Harborlight's own careers page before investing effort | see RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask the questions in RR2 and RR4 at the recruiter screen | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search "Harborlight Health care navigation app careers Senior Product Analyst" was refused. It would have confirmed the employer and the live posting; RR1 is carried instead |
| 2. Role-family sweep | unavailable | Search "senior product analyst digital health salary range 2026" was refused. It would have set a pay band for RR2 and a market-calibration line |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Dossier offer

I can write all of this up as a `tuesday-dossier.md` you can keep and reuse. Say so and I'll produce it.

## Upgrade menu

- Permission to run web searches → employer check (RR1) and a pay band (RR2); a deeper L2 pass on funding, leadership and recent news is also available (up to 5 more searches and 2 more fetches).
- A sanitized metric-definition doc or LookML excerpt → R6 moves to `direct`, and G1 closes.
- A teaching or onboarding artifact → R8 moves.
- A redacted exec memo, test write-up, or dashboard screenshot → R3, R4 and R5 to `high`.
- Your pay floor, location and work-authorization constraints → hard-gate checks become real instead of unknown.
- The hiring manager's name → scope read and which story to lead with.

## Questions

G1 — Did you own how core metrics (retention, active subscriber, conversion) were defined across the company, for example in LookML or a metric dictionary? What did you decide, and who relied on it?

G2 — Have you mentored, reviewed or onboarded other analysts, even informally? What did you do and for how long?

C1 — What are your non-negotiables for this move (pay floor, remote or location, work authorization)? The posting doesn't state any of these, so I can't yet check them.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.