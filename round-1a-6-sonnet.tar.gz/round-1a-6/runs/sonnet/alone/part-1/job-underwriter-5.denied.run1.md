I'm reading the skill's reference files so the assessment follows its required format. Next are the research-tier rules, the decision snapshot rules, and the evidence-map vocabulary.
## Decision snapshot

**Yes, worth applying, on conditions. R1, R2, R3, R5 and R6, the must-have rows, are `direct`. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R9 (Remote US or Denver), R10 (Pay $148,000–$166,000)
- `must_have` — direct: R1, R2, R3, R5, R6
- `important` — adjacent: R4 (BigQuery warehouse); unclear: R7 (Ingestion from app and CRM), R8 (Data contracts for analysts)

R4 — a credible bridge, its limit named; R7 and R8 — your background is silent on them, so they're unasked rather than failed.

**Opportunity ledger.** The pay is disclosed and calibrated against your recruiter's report (RR2). The employer and live posting aren't yet verified (RR1), the equity has no terms (RR3), and the scope is wider than the report's typical senior post (RR4).

- **Hard gates:** none failed; unconfirmed: R9 (Remote US or Denver), R10 (Pay $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting and employer verify on the company's own careers page (RR1); (2) your location, work authorization and pay floor fit R9 and R10; (3) BigQuery is presented as adjacent and never as experience (R4).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C of $52M in February 2026 | `[grounded]` the About text you pasted; not independently checked (RR1) |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Requirements | 5+ years data engineering; strong SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Compensation | $148,000–$166,000 plus equity, with no equity terms stated | `[grounded]` JD |
| Location | Remote (US) or the Denver office | `[grounded]` JD |
| Market calibration | The report puts Senior Data Engineer at Series B–D companies at a base median of $151,000 (IQR $139,000–$163,500) and typical scope at one domain's pipelines with no reports. The posting's range runs from just under the median to above the IQR's top (RR2). Your 6 years sits inside the report's typical 5–8 years for "Senior" | `[grounded]` the Datawright 2026 report you supplied (n=2,310) for figures and the "typical" description; `[generic]` that this is the role-family norm, not a claim about this employer |
| Scope read | The JD covers ingestion, warehouse modelling, contracts and running the pipelines, which is broader than the report's one-domain norm. The role may be a first or sole data engineer, or the JD may be written loosely (RR4) | `[inferred]` from the JD's four responsibilities against the report's typical scope |
| First-year outcomes | Not stated | `[grounded]` JD silence |
| Unknowns | Hiring manager and team size; equity terms; whether the posting is live; your location, authorization and pay floor | — |
| Contradictions | None between the JD and the About text you pasted. Neither was checked against the live site | `[grounded]` pasted inputs only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years of data engineering at a B2B payroll company. It's specific and confirmed, with no inspectable artifact yet | `[grounded]` your stated background | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | You say you use both daily, and the 180-model dbt project is SQL-heavy by nature. Strength is self-reported | `[grounded]` your stated background | a code sample or repo would raise to high |
| R3 | dbt and a cloud warehouse | must_have | direct | medium | none | You built the dbt project (about 180 models) on Snowflake, which is a cloud warehouse. The JD's requirement line says "a cloud warehouse"; BigQuery is separate in R4 | `[grounded]` your stated background | a sanitized model list or lineage screenshot would raise to high |
| R4 | The dbt-modelled warehouse is BigQuery | important | adjacent | medium | transferability | The adjacency is dbt modelling on Snowflake. The limit is that you've never used BigQuery, so its dialect, partitioning and cost controls are unexercised | `[inferred]` adjacency from Snowflake plus dbt; `[generic]` that warehouses differ in these respects | see gap queue G3 |
| R5 | Orchestration with Airflow or similar | must_have | direct | medium | none | You used Airflow for orchestration at the payroll company | `[grounded]` your stated background | none |
| R6 | Experience with data quality testing | must_have | direct | medium | none | You set up your company's Great Expectations test suite, which is ownership and not just use | `[grounded]` your stated background | a sanitized suite overview would raise to high |
| R7 | Ingestion from the app and CRM | important | unclear | low | discovery | Your background doesn't say what sources you ingested. Payroll platform and CRM ingestion may exist, but nothing in hand establishes it | `[grounded]` silence on ingestion sources | see gap queue G1 |
| R8 | Data contracts that analysts depend on | important | unclear | low | discovery | A 180-model dbt project and a test suite suggest analyst-facing guarantees, but you haven't said whether they were formal contracts or who consumed them | `[grounded]` silence on consumers and contracts; `[inferred]` that the project may have involved them | see gap queue G2 |
| R9 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't stated where you're based or your work authorization. Confidence is `none` because no constraint has been given | `[grounded]` JD term; your constraints not given | Q1 |
| R10 | Pay $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | You haven't stated a pay floor, so the range can't be checked against it. RR2 covers the market comparison | `[grounded]` JD term; your floor not given | Q1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Ingestion from app and CRM (R7, important) | discovery | Nothing on which sources fed your pipelines or how | It's one of the JD's headline responsibilities, and a clear answer could move R7 to `direct` | Loading from a product database or event stream; syncing a CRM such as Salesforce or HubSpot, or a billing or HRIS system; managed connectors or custom extractors | A pipeline diagram, a DAG screenshot, or a sanitized source list | `[grounded]` silence; `[generic]` that these are common ingestion sources |
| G2 | Data contracts for analysts (R8, important) | discovery | The test suite and dbt project are on record. Who consumed the models and whether expectations were agreed with them aren't | The JD names contracts as a responsibility, so a concrete example would firm up the row | Schema or freshness guarantees agreed with analysts; dbt tests or exposures tied to a dashboard; a change-notice process for breaking changes | A sanitized contract doc, dbt `schema.yml` excerpt or exposures list | `[grounded]` silence; `[inferred]` that your work may include it |
| G3 | BigQuery (R4, important) | transferability | Snowflake plus dbt, with no BigQuery use | It's the stated warehouse. The bridge is credible, but the limit should be said out loud | A small personal dbt-on-BigQuery project using the free sandbox, if you choose to build one | The repo itself, described as a learning project | `[inferred]` bridge from your Snowflake and dbt work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not yet established from attributable sources | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states" | My searches were refused this run, so the company description and the live posting rest on the text you pasted alone. It may simply be unchecked, or the posting may be stale | `[grounded]` both searches refused; `[generic]` pattern for any unchecked posting, not a claim about this company | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay disclosed and calibrated | positive_signal | — | "$148,000–$166,000 plus equity" | The range's midpoint is $157,000, above the report's $151,000 median. The top, $166,000, is above its $163,500 upper-quartile bound. The bottom, $148,000, is just under the median | `[grounded]` JD figures against the supplied Datawright report | Is the range final for this level, and where in it do offers usually start? | noted |
| RR3 | Equity named without terms | unknown | — | "plus equity" | The grant could be material or nominal; at a Series C company its value depends on type, strike and valuation basis | `[grounded]` JD gives no terms | What is the equity: type, size, vesting, and the valuation basis? | unresolved |
| RR4 | Scope breadth and reporting line unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | The post may be a first or sole data engineer covering ingestion to contracts, which is wider than the report's one-domain norm. The JD names no manager | `[inferred]` from the JD's responsibilities against the supplied report's typical scope | Who is on the data team today, who does this role report to, and what should be delivered in the first year? | unresolved |

## Application plan

Every row below is proposed and awaits your approval, including the advice rows. I haven't written anything for you to send.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Resume lines that mirror the JD only with what you told me: "6 years of data engineering at a B2B payroll company"; "Built a dbt project of about 180 models on Snowflake"; "Orchestrated pipelines with Airflow"; "Set up the Great Expectations test suite" | R1, R3, R5 and R6; the lines add nothing beyond your own statements | `[grounded]` your stated background | resume_edits_pending_approval |
| E2 | Where BigQuery comes up, say plainly that you haven't used it and that your dbt warehouse work has been on Snowflake | R4; this is the limit stated and never a claim | `[grounded]` your stated background | pending your approval |
| A1 | Open the careers page on the company's own site and confirm the posting is live before spending effort | RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | In a first call, ask the verification questions of RR3 and RR4 verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | I searched "Pellucid Learning online tutoring K-12 Denver Series C" and "Pellucid Learning careers senior data engineer". Both were refused, so nothing was read. It would have fed role reality's organization and contradictions rows; as it is, it leaves RR1 standing |
| 2. Role-family sweep | skipped | The Datawright report you pasted already fixes the market calibration line and the pay comparison in RR2 |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so no query could be formed |

I can make `tuesday-dossier.md` from this assessment if you'd like to keep it.

## Upgrade menu

- A working search, or a link to the live careers page → RR1 closes, and the organization and contradictions rows in role reality get checked.
- Your location, work authorization and pay floor → R9 and R10 resolve, and the hard-gates line stops saying "unknown".
- A sanitized dbt model list, lineage screenshot or Great Expectations suite overview → R3 and R6 rise to `high`.
- Ingestion sources and consumer examples (G1, G2) → R7 and R8 could reach `direct`.
- The hiring manager's name → role reality's scope read and which story the application plan leads with.

## Questions

Q1 — What are your non-negotiables on location, work authorization and pay floor? (R9, R10)

G1 — Which sources did your pipelines ingest from, such as the product database, a CRM, billing or HR systems, and were they managed connectors or code you wrote?

G2 — Did analysts or other teams depend on your dbt models or tests, and were there agreed guarantees such as freshness, schema or change notices? What did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.