I'll read the skill's reference files before building the assessment.
## Decision snapshot

**No, not on this evidence, but this role is a reach. R4 and R5 are `direct` and R2 and R3 are `adjacent`, while R1 (3+ years of product management) is `absent` and no wording can change that. Status: `conditional_go`.**

I'm assuming you're at the evaluating stage, since you didn't say otherwise.

**Fit ledger.**

- `must_have` — direct: R4, R5 · adjacent: R2 (Roadmap, specs, delivery with two squads), R3 (Shipped API or platform products) · unclear: R6 (Agile delivery) · absent: R1 (3+ years PM experience)
- `important` — direct: R7 · unclear: R8 (Adoption metrics), R9 (Launches with sales and support)

R1 — no PM title, and no workaround by wording; R2, R3 — bridges whose limits are named; R6, R8, R9 — unanswered, not negative.

**Opportunity ledger.** The role is concretely scoped on its face (RR4). The employer is not established from here (RR1), pay is not stated (RR2), and decision rights over the two squads are not stated (RR3).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Quartzline and the live posting verify (RR1). (2) A person at Quartzline reads your application with R1 stated plainly, through a referral, direct outreach, or a recruiter confirming that titled PM years aren't screened literally. (3) Your answers on R6 and R8 don't contradict the rows as mapped. If the posting turns out to screen R1 literally, this becomes `no_go` for this posting.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B | `[grounded]` JD header; not checked against an outside source |
| Mandate | Own the roadmap for the partner-facing API platform; run discovery with integration partners; write specs; drive delivery with two engineering squads; define and track adoption metrics; coordinate launches with sales and support | `[grounded]` JD |
| Stated outcomes | No first-90-days or first-year outcomes are stated | `[grounded]` JD as provided |
| Hard terms | No location, schedule, pay or authorization terms in the JD as provided | `[grounded]` JD as provided |
| Scope read | One product area (the partner API platform) with two squads and a 3+ year bar: a mid-level PM post, not an entry-level one | `[inferred]` from "own the roadmap", "two engineering squads" and "3+ years" |
| Pivot context | Solutions and implementation engineers who move into platform or API product roles usually do it where technical fluency is scarce, and often through referral or an adjacent-title role rather than a cold application against a titled-years requirement | `[generic]` role-family pattern, not a claim about Quartzline |
| Market calibration | Not run: the role-family sweep was refused, so there's no pay or title band here | `[grounded]` the sweep was refused (see Evidence status) |
| Unknowns | Pay; location; who the role reports to; decision rights over squad priorities; who the hiring manager is | `[grounded]` JD silence |
| Contradictions | None visible inside the JD. It hasn't been checked against a careers page | `[grounded]` JD as provided |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years product management experience | must_have | absent | none | discovery | You've never held a PM title, so the titled-years reading has no evidence behind it. The work near it is credited in R2, R3 and R7, not here. Whether you owned a product-like thing is still open (G1). | `[grounded]` your statement; `[generic]` that titled-years requirements are often read literally | Answer G1. Never assert PM years on any document. |
| R2 | Own the roadmap, write specs, drive delivery with two engineering squads | must_have | adjacent | medium | transferability | You wrote requirements documents and integration architecture, ran quarterly roadmap-input sessions "collecting client feedback for product", and coordinated "our engineers, the client's engineers, and product managers". Limit: your sessions fed product's roadmap, and nothing says you set priorities or ran squads. | `[grounded]` your resume summary, confirmed in prose only | Answer G3. A sanitized spec would raise it. |
| R3 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ client integrations of "our REST APIs" and wrote the internal playbook. Limit: this is implementing and documenting the vendor's APIs for clients, and nothing says you designed or released one. | `[grounded]` your resume summary | Answer G3. |
| R4 | Technical fluency: API docs and schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI specs, plus integration architecture work across 30+ builds. Confirmed and specific, but nothing inspectable has been shared yet. | `[grounded]` your resume summary | none |
| R5 | Stakeholder management across engineering and customers | must_have | direct | medium | none | You coordinated your engineers, client engineers and PMs, and ran client scoping workshops through UAT and go-live. | `[grounded]` your resume summary | none |
| R6 | Experience with agile delivery | must_have | unclear | none | discovery | The resume is silent on sprints, backlogs or ceremonies. UAT and go-live are delivery work but not evidence of agile practice. | `[grounded]` resume silence | Answer G2. |
| R7 | Run discovery with integration partners | important | direct | medium | presentation | Scoping workshops and quarterly sessions collecting client feedback for product are discovery activity. Limit: your clients are vendor customers, and the JD's partners may be a different relationship. | `[grounded]` your resume summary; `[inferred]` that the two populations overlap | Surface it higher (E1). |
| R8 | Define and track adoption metrics | important | unclear | low | discovery | Nothing in the resume covers it. An unconfirmed note from a prior conversation mentions an internal tool support agents adopted, which is a lead and not evidence. | `[grounded]` resume silence; `[inferred]` the lead is relevant | Answer G1. |
| R9 | Coordinate launches with sales and support | important | unclear | none | discovery | Your go-lives were client-side launches. The resume doesn't mention sales or support coordination. | `[grounded]` resume silence | Not asked this turn; listed in G4. |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owned product-like work and adoption (R1, R8) | discovery | No owned product, tool or metric on the resume. A prior-conversation note mentions an internal triage tool, unconfirmed. | It's the only route to narrowing R1, and it would start filling R8. | A tool or process you decided to build; deciding what a support or client team got; counting who used it; changing it after feedback | Usage numbers, a screenshot, a one-page description | `[grounded]` resume silence; `[inferred]` that it could move R8 |
| G2 | Agile delivery (R6) | discovery | Nothing on sprint cadence, backlog or planning. | A must-have row at `unclear` that a short answer could close. | Sprint planning with your own or client engineers; running UAT in sprint cycles; backlog grooming on a custom build | A sprint board export or a release plan | `[grounded]` resume silence |
| G3 | Shaping versus implementing APIs (R2, R3) | transferability | Strong integration work. The bridge to shipping or shaping an API is unspoken, and the limit is that the work implemented someone else's product. | These two must-haves decide how credible the bridge reads. | A change request from your sessions that became a release; a doc or SDK sample you authored; a spec that engineers built from | A sanitized spec, a changelog entry, a playbook excerpt | `[grounded]` resume; `[generic]` that this is the usual objection for this move |
| G4 | Sales and support launch coordination (R9) | discovery | Silent on the resume. | An important row, below the three asked about. | Handing a go-live to support; briefing sales on a new capability | A handover note | `[grounded]` resume silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | No search result either way, because the searches were refused. The entity may be too new or small for a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who I'd be interviewing with? | unresolved |
| RR2 | Compensation not stated | unknown | — | The JD as provided contains no pay figure. | Pay may sit anywhere in the role-family range, or the employer may not publish it. | `[grounded]` JD silence | What salary range is budgeted for this role? | unresolved |
| RR3 | Decision rights unstated | unknown | — | "Own the roadmap … drive delivery with two engineering squads" | The role may carry roadmap accountability without authority over squad priorities. | `[inferred]` from the ownership language against silence on decision rights | Who sets squad priorities, and which roadmap decisions does this role make alone? | unresolved |
| RR4 | Concrete responsibilities and a metrics mandate | positive_signal | — | "define and track adoption metrics" | The role is described in specific, checkable terms. | `[grounded]` JD | Which adoption metrics are tracked today, and what are their current targets? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't rely on a cold application. Try a referral, or direct outreach to the hiring side, so a person reads R2, R3 and R7 alongside a plainly stated R1. | see R1 | `[generic]` how titled-years requirements are often screened; no claim about Quartzline | pending your approval |
| A2 | Say in your first lines that you haven't held a PM title, then lead with the roadmap-input sessions, the playbook and the 30+ integrations. Claim no PM years. | see R1, R2, R7 | `[grounded]` your resume sentences | pending your approval |
| A3 | Also look at roles that don't mark titled PM years as a must-have, such as technical or platform PM roles at the associate or mid level, or integration-focused product roles. | see R1 | `[generic]` role-family pattern | pending your approval |
| E1 | Move "Ran quarterly roadmap-input sessions collecting client feedback for product" near the top, wording unchanged. | see R7 | `[grounded]` your sentence | `resume_edits_pending_approval` |
| E2 | Move "Wrote the internal integration playbook the whole team uses" near the top, wording unchanged. | see R2 | `[grounded]` your sentence | `resume_edits_pending_approval` |
| E3 | Summary line: "Solutions engineer and implementation lead, 7 years, leading client integrations of REST APIs at an enterprise-software vendor; moving into product management." | see R3, R4 | `[grounded]` each clause traces to your sentences | `resume_edits_pending_approval` |
| W1 | A one-page spec for one partner-facing API improvement drawn from a real, sanitized integration pain point of yours. | see R2, R3 | `[grounded]` R2, R3 rows | pending your approval |
| Q1 | Ask RR1, RR2, RR3 and RR4's questions verbatim in the loop. | The register doubles as interview preparation | `[grounded]` register | pending your approval |

I only have your resume in prose, so E1–E3 are ordering and summary changes and not edits to your actual text.

## Evidence status

Verified: none yet. Unverified lead: a prior-conversation note that you built an internal request-triage tool support agents adopted. It's unconfirmed, and it's the basis for question G1 only.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Quartzline logistics technology API platform careers Product Manager"; the call was refused. It would have fed role reality's organization and contradictions rows and confirmed or cleared RR1. |
| 2. Role-family sweep | unavailable | Searched "platform API product manager salary B2B SaaS Series B requirements solutions engineer transition to product management"; the call was refused. It would have fed market calibration and RR2. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |

I'd like to offer a one-page `tuesday-dossier.md` of this assessment to carry into later turns.

**Upgrade menu**

- Search permission, or a pasted careers page or live posting link → RR1 closes or confirms, and pay and title get calibrated against a band.
- The recruiter's email domain or the posting's own URL → the employer check without searching.
- Your actual resume text → E1–E3 become real edits, and the R2, R3, R4 and R5 rows are checked against your wording.
- Inspectable artifacts: a sanitized spec or requirements doc (R2, R3), a playbook excerpt (R2, R5), usage numbers for the triage tool (R8) → each could take its row from `medium` or `low` toward `high`.
- Your non-negotiables (pay floor, location, authorization) → the hard-gates line stops reading "unknown".
- The hiring manager's name → the scope read and which story to lead with.

**Questions**

G1 — Did you build an internal request-triage tool that support agents adopted? If so, what did you decide to build, what did you own, and how did you know whether people used it?

G2 — Have you worked in sprint cycles with engineers on a custom build (planning, backlog, release), and in what role?

G3 — Did any change to the API, its docs or its tooling actually ship because of your input or a spec you wrote? What did you own, and what did the engineers decide?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.