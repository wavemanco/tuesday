Web search wasn't permitted, so this runs on the posting and what you told me.

## Decision snapshot

**No, this isn't worth pursuing. R1 and R2, both hard gates, fail on pay and location. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: hard_gate_fail: R1 (Compensation $70–85k base), R2 (On-site Austin, 5 days a week)
- `must_have`: direct: R3, R4, R5 · unclear: R6 (SEO/content)
- `important`: unclear: R7 (Brand and PR), R8 (Partnerships and sales ops)

R1, R2: pay and location fail on terms, not on skill; R3, R4, R5: a credible match on paper; R6, R7, R8: the CV is silent.

**Opportunity ledger.** The posting asks for several roles' worth of work from one person at a junior-looking base (RR3, RR4). It adds always-on hours and metrics that are undefined (RR5, RR6). Your instinct that something is off is supported by RR1 to RR6. On the other side, the CEO reporting line is a real positive if it holds (RR9).

- **Hard gates:** failed: R1 (Compensation $70–85k base), R2 (On-site Austin, 5 days a week).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would change this:** the employer would have to offer a base of at least $150k and let you work remotely from Portland. The posting says "no exceptions" on location. Only the employer changing terms resolves it, and no wording on your side can.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` JD header; existence and claims not verified |
| Mandate | All revenue growth: paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` JD |
| Team | Team of one to start, reporting to the CEO with a dotted line to the board | `[grounded]` JD |
| Hours | "Evenings and weekends when it matters is just who we are" | `[grounded]` JD |
| Location | On-site in Austin, 5 days a week, "no exceptions" | `[grounded]` JD |
| Pay | $70–85k base plus "meaningful equity upside"; no equity figures given | `[grounded]` JD |
| Scope read | Several specializations folded into one title, with no stated team, budget or decision rights | `[inferred]` from the responsibility list against the JD's silence on resources |
| Market calibration | Not established. The search for the market band was refused, and I won't quote a figure from memory. The posting's own $70–85k stands as stated. | `[grounded]` JD for the figure; no band available |
| Unknowns | Budget, equity terms, success metrics, who the CEO is, whether remote is truly off the table | `[grounded]` JD silence |
| Contradictions | "Must thrive on ambiguity" beside "8+ years leadership required" for a team of one is not a contradiction, but the title and pay point different ways | `[inferred]` from title and base |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay: "$70–85k base" against your floor of $150k | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own stated floor. Fit fails because the top of the posted range is below it. | `[grounded]` JD quote and your confirmed constraint | None. Only the employer changing the offer resolves it. |
| R2 | Location: "On-site in our Austin office 5 days a week — no exceptions" against remote-only, Portland | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own stated constraint. Fit fails because the JD rules out remote and you won't relocate. | `[grounded]` JD quote and your confirmed constraint | None. Same as R1. |
| R3 | "8+ years growth leadership" | must_have | direct | medium | none | 9 years, with Growth lead then Head of Growth. Stated by you, with no inspectable artifact yet. | `[grounded]` your background as stated | None |
| R4 | Paid acquisition | must_have | direct | medium | none | You owned paid at two B2C subscription companies and controlled a budget while scaling $8M to $40M ARR. The scale figure rests on your word. | `[grounded]` your background as stated | None |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You owned lifecycle and have deep Braze skills. | `[grounded]` your background as stated | None |
| R6 | SEO/content | must_have | unclear | none | discovery | Nothing you gave me mentions SEO or content. | `[grounded]` your background is silent | Recall prompt G1 |
| R7 | Brand and PR | important | unclear | none | discovery | Nothing you gave me mentions brand or PR. | `[grounded]` your background is silent | Recall prompt G2 |
| R8 | Partnerships and sales ops | important | unclear | none | discovery | Nothing you gave me mentions either. | `[grounded]` your background is silent | Recall prompt G3 |

## Gap recovery queue

These matter only if the terms ever change. The pay and location gaps can't be closed from your side.

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content (R6, must_have) | discovery | Paid, lifecycle and experimentation are covered; organic search is not mentioned | A `must_have` row at `unclear`. It would matter only if R1 and R2 were met. | Owning content or SEO budget; working with an SEO agency; organic-traffic targets inside a growth plan | A traffic dashboard, a content calendar, a channel-mix report | `[grounded]` background silent; `[generic]` that growth heads at subscription companies often oversee organic |
| G2 | Brand and PR (R7, important) | discovery | Nothing stated | A secondary requirement in a bundled mandate | Launch announcements, press handling, brand campaigns you ran | A campaign brief or press coverage | `[grounded]` background silent |
| G3 | Partnerships and sales ops (R8, important) | discovery | Nothing stated | B2B motions may differ from your B2C subscription history | Affiliate or channel deals; CRM or pipeline reporting for a sales team | A partner agreement or pipeline report | `[grounded]` background silent; `[inferred]` that a B2B enablement firm leans on these more than a B2C one |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay below your floor (see R1) | red_flag | high | "$70–85k base plus meaningful equity upside" | The posted range tops out below half your $150k floor; equity is unquantified | `[grounded]` JD figure against your stated floor | What is the maximum base for this role, and what equity is on offer in shares, percent and vesting? | confirmed |
| RR2 | Fixed on-site against remote-only (see R2) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | The role is closed to anyone who stays in Portland | `[grounded]` JD against your stated constraint | Is any remote arrangement possible for the right candidate? | confirmed |
| RR3 | Seniority and mandate against the pay | risk_signal | medium | "8+ years growth leadership required" with "$70–85k base" | A full-function leadership scope is priced like a junior or mid-level post. Market band not established because the search was refused. | `[inferred]` from the JD's own scope and pay | What was this budgeted against, and what do comparable leaders at Novaline earn? | unresolved |
| RR4 | Bundled specializations, no resources | risk_signal | medium | "You will be a team of one to start — we believe in players who don't need a bench" | Seven functions with no stated team, budget or hiring plan | `[inferred]` from the responsibility list against the JD's silence on resources | What budget and headcount are committed for the first year? | unresolved |
| RR5 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Extended hours may be routine, and the base does not compensate for them | `[inferred]` from the JD's wording | How often did the last person in this function work evenings or weekends? | unresolved |
| RR6 | Success metrics undefined on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | You would be accountable without an agreed measure | `[inferred]` from the JD's wording | What outcomes define success at 6 and 12 months? | unresolved |
| RR7 | Equity unquantified | unknown | — | "meaningful equity upside" | "Meaningful" has no figure attached | `[grounded]` JD silence | What percentage, strike and vesting schedule are offered? | unresolved |
| RR8 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to the role on your own careers site, and who would I report to? | unresolved |
| RR9 | CEO reporting line and board contact | positive_signal | — | "Report to the CEO with a dotted line to the board" | Real seniority and visibility, if the posting is accurate | `[grounded]` JD | What decisions would you own without CEO sign-off? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply to this posting as written | see R1, R2, RR1, RR2 | `[grounded]` the register | pending your approval |
| A2 | If you still want to test it, ask the employer one thing before spending any effort: the maximum base and whether remote from Portland is possible, using RR1 and RR2's questions | Only the employer can change these terms | `[grounded]` RR1, RR2 | pending your approval |
| A3 | Make no CV changes for this role | R3, R4 and R5 already read direct, and the open gaps cost more effort than the posting is worth | `[grounded]` the map | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Novaline e-commerce enablement startup Austin Series A" was refused, so I could not confirm the company exists as described or that the posting is live. It would have filled the organization row and moved RR8. |
| 2. Role-family sweep | unavailable | The search "Head of Growth salary startup Series A base compensation 2026" was refused. It would have given the market calibration line and sized RR3. |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so no query could be formed. |

## Closing

This assessment can be saved as `tuesday-dossier.md` if you want a file to keep.

**Upgrade menu**

- A link to the live role on Novaline's own careers page, or a permitted search: confirms the employer and closes RR8.
- A permitted salary search: sets a market band against RR3.
- Evidence of SEO, brand, PR or partnerships work, such as a traffic dashboard or campaign brief: moves R6, R7 and R8.
- The employer's written answer on maximum base and remote work: would turn RR1 and RR2 from confirmed into a different decision.

No questions this turn, since nothing you could answer would change the status.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.