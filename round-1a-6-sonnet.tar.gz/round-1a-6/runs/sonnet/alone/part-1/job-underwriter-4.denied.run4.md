I'll read the reference files the skill points to before building the assessment.
**Yes, apply. Status: `conditional_go`.** The fit is strong on every stated must-have I could map, and nothing in the material fails a hard gate. The conditions are that R1 is confirmed and that the employer and posting check out (RR1).

I couldn't verify Brindlemoor, so what follows rests on your JD and background alone.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote, UK)
- `must_have` — direct: R2, R3, R4, R5a, R6, R7a, R8 · unclear: R5b (Monitor rating models), R7b (Recommendations for product)
- `preferred` — direct: R9 · adjacent: R10 (Pet-insurance domain knowledge)

R5b — monitoring not yet evidenced; R7b — a product audience not yet evidenced; R10 — a credible bridge, its limit named; R1 — awaiting your confirmation.

**Opportunity ledger.** The duties are concrete (RR4). The employer and posting are unverified (RR1), the pay is withheld (RR2), and whether the post carries reports is unstated (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm you can work from the UK without sponsorship, as the JD's "Fully remote (UK)" implies — R1; (2) the live posting is verified on Brindlemoor's own careers site — RR1; (3) the pet-insurance bridge is framed as adjacent, never as pet experience — R10.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, described in the JD as an insurtech, pricing a pet-insurance product | `[grounded]` JD header; entity unverified (RR1) |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing | `[grounded]` your message |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| First-year outcomes | Not stated in the JD | `[grounded]` JD silent |
| People management | The JD lists no line-management duty; whether the post has reports is unstated (RR3) | `[grounded]` JD silent |
| Scope read | A hands-on analytics post reporting into a Director of Pricing, spanning models, tests and stakeholder recommendations | `[inferred]` from the JD's duty list and your stated hiring manager |
| Market calibration | Not calibrated: the role-family sweep did not run, so no title, scope or pay band is offered, and the posting states no pay | `[grounded]` JD silent on pay; sweep unavailable |
| Unknowns | Salary; contract type; team size and reports; tooling; first-year outcomes; whether "UK" means UK-resident or a UK employer | `[grounded]` JD silent on each |
| Contradictions | None inside the pasted JD; JD against careers page unchecked | `[grounded]` JD; check not run |

## Evidence map

Your background was typed into the conversation, so it counts as self-report: `medium` is the ceiling until you share an artifact.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK | hard_gate | unclear | low | hard_gate | You gave no location or right-to-work statement. A UK motor insurer employer suggests UK base but settles nothing | `[grounded]` your employer is UK-based; `[inferred]` location from that | G1: confirm the gate is met |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years of pricing analytics at a UK motor insurer, 2 as senior analyst; confirmed and specific, no artifact yet | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily"; no artifact inspected, so expect a probe | `[grounded]` your background | A sanitized query or notebook would raise it to `high` |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book; specific, not inspectable yet | `[grounded]` your background | A sanitized factor table or model spec would raise it to `high` |
| R5a | Build rating models | must_have | direct | medium | none | Same GLM build evidence as R4 | `[grounded]` your background | none |
| R5b | Monitor rating models | must_have | unclear | low | discovery | "Maintained" is the only word near monitoring; it doesn't say what was tracked, how often, or what changed | `[grounded]` your wording; resolved downward | G2 |
| R6 | Design and read price tests | must_have | direct | medium | none | You ran 14 price tests last year with underwriting. "Ran" doesn't say whether you designed them, such as hypotheses and sizing. Interviews for this role family tend to probe that | `[grounded]` your background; `[generic]` the probe | A sanitized test readout would raise it to `high` |
| R7a | Recommendations for underwriting | must_have | direct | medium | none | You run the tests with the underwriting team and present the quarterly review to its head | `[grounded]` your background | none |
| R7b | Recommendations for product | must_have | unclear | none | discovery | Nothing in your background mentions a product audience | `[grounded]` your background silent | G3 |
| R8 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your background | A sanitized review deck would raise it to `high` |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | 5 years at a motor insurer | `[grounded]` your background | none |
| R10 | Pet-insurance domain knowledge (not in the JD; the product itself is the basis) | preferred | adjacent | medium | transferability | Bridge: motor GLM rating and test work is the same discipline. Limit: you have not worked on pet insurance, and nothing in your motor work exercised its pet-specific factors, such as breed and age, or its claims trends. Name that limit wherever the bridge is used | `[inferred]` adjacency from your motor GLM work; `[generic]` that pet factors differ from motor | Strengthener: a short note on how you'd approach pet rating factors |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and work eligibility (R1, hard_gate) | hard_gate | Nothing states where you're based or your right to work | A gate the inputs don't settle; wording can't fix a miss | n/a: it is met or it isn't | none needed | `[grounded]` your message silent |
| G2 | Monitoring rating models (R5b, must_have) | discovery | "Maintained" is the only word near monitoring | "Monitor" is half of the JD's first duty, so this decides how R5 reads | Tracking actual versus expected loss ratios after a rate change; re-fit cycles; drift or lift reports; alerts when a factor misbehaved | A sanitized monitoring dashboard or report | `[grounded]` your wording; `[inferred]` that it matters to the first duty |
| G3 | Recommendations for product (R7b, must_have) | discovery | Your audience so far is underwriting only | The JD names product as a recipient of your recommendations | A test result that changed a product feature, cover tier, excess or renewal rule; a pricing paper for product or commercial colleagues | A sanitized recommendation memo or deck slide | `[grounded]` your background silent |
| G4 | Pet-insurance knowledge (R10, preferred) | transferability | Motor GLM and test work, no pet exposure | Likeliest objection to your application, though preferred rather than required | n/a: the bridge and its limit are in R10 | A short note on pet rating factors | `[inferred]` bridge from R10; `[generic]` that this is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. The check could not run here | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay withheld | unknown | — | the JD states no salary | The figure may sit anywhere relative to your expectations; I have no band to compare it with | `[grounded]` JD silent; `[inferred]` that this is worth a question | What salary band is budgeted for this post? | unresolved |
| RR3 | Reporting scope unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | "Senior" and "own" could mean a sole analyst or a lead with reports or mentees; the JD says neither | `[inferred]` from the JD's wording against its silence on reports | Does this post have direct reports or mentoring duties now, and are any expected within the first year? | unresolved |
| RR4 | Duties stated concretely | positive_signal | — | "build and monitor rating models, design and read price tests, and turn the results into recommendations" | The work is defined and tied to one product | `[grounded]` JD | What would a successful first year look like? | noted |

## Application plan

Nothing here is final until you approve it. That covers the edits table and every positioning row alike.

`resume_edits_pending_approval` (I haven't seen your CV, so there is no current wording to compare; each line traces to your sentences):

| # | Proposed line | Your source sentence | Status |
|---|---|---|---|
| E1 | Built and maintained the GLM rating model for the young-driver book at a UK motor insurer | "Built and maintained the GLM rating model for our young-driver book" | pending your approval |
| E2 | Ran 14 price tests with the underwriting team last year | "Ran 14 price tests last year with the underwriting team" | pending your approval |
| E3 | Present the quarterly pricing review to the head of underwriting | "I present the quarterly pricing review to the head of underwriting" | pending your approval |
| E4 | Senior analyst for the last 2 of 5 years in pricing analytics at a UK motor insurer | "5 years pricing analytics … the last 2 as senior analyst" | pending your approval |

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the GLM build (R4), the price tests (R6) and the quarterly review (R8). Say plainly that your rating and test work is in motor, not pet | The map's strongest rows; the bridge is honest about R10's limit | `[grounded]` R4, R6, R8, R10 rows | pending your approval |
| P2 | If asked about management, say you haven't managed anyone, and ask RR3's question early | No JD requirement touches it, but the JD doesn't say whether the post has reports | `[grounded]` your message and JD silence | pending your approval |
| A1 | Check the live posting on Brindlemoor's own careers site before investing in the application | RR1 caps the decision until verified | `[grounded]` RR1 | pending your approval |
| Q1 | Ask the register's questions (RR1 to RR4) verbatim in the loop, pay included | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches "Brindlemoor pet insurance insurtech" and "Brindlemoor careers Senior Pricing Analyst" were refused by the host. Would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | Search "senior pricing analyst pet insurance UK salary remote" was refused. Would have moved market calibration and RR2 |
| 3. Hiring manager's public footprint | unavailable | Search "Odile Varga Director of Pricing Brindlemoor" was refused. Would have moved the scope read and P1's choice of story to lead with |

## Upgrade menu

- Paste Brindlemoor's careers page or the live posting link: RR1 and role reality's contradictions row can close, and reading a link you give me costs no research budget.
- Allow web search: targets 1 to 3 run with the L1 budget left (1 search, 2 fetches). A deeper company pass (up to 5 more searches and 2 more fetches) can follow if you want it.
- Your CV, plus sanitized artifacts: a model spec or factor table (R4), a query or notebook (R3), a test readout (R6), the quarterly review deck (R8). Each would take its row from `medium` to `high`.
- Your non-negotiables (pay floor, location, notice period): the hard-gate checks run against them, and RR2 can be set against a floor.
- Answers to G2 and G3: R5b and R7b resolve, and R5 and R7 read cleanly.

I can write all of this to `tuesday-dossier.md` if you'd like a file to keep. Say the word.

G1 — The posting says "Fully remote (UK)". Are you based in the UK with the right to work there without sponsorship?
G2 — On the GLM model you maintained, did you track its performance after launch? If so, how, and did anything change as a result?
G3 — Have you taken price-test results to anyone beyond underwriting, such as product, marketing or finance? What did you recommend, and what happened?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.