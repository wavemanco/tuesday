I'll read the reference files the skill calls for before building the assessment.
Both research calls (one search, one page fetch) were refused, so I'm working from what you pasted.

# Job Underwriting Assessment — Senior Data Engineer, Pellucid Learning

## Decision snapshot

**Yes, it's worth applying — on conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote (US) or Denver), R2 (Salary $148,000–$166,000)
- `must_have` — direct: R3, R4, R5, R6, R7, R8
- `important` — adjacent: R9 (BigQuery as the warehouse); unclear: R10 (Ingestion from app and CRM), R11 (Data contracts for analysts)

R9 — a credible bridge, its limit named; R10 and R11 — the CV is silent on them, not contradicted.

**Opportunity ledger.** Sound on what the posting states, but unchecked and thin in places. Pay is stated and sits inside the market band (RR3). The hiring manager and team are unnamed (RR2), equity terms are unstated (RR4), and "run" leaves on-call open (RR5). The posting itself could not be independently checked (RR1).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver), R2 (Salary $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting and company details are confirmed on the live careers page (RR1); (2) your location and pay floor are checked against R1 and R2; (3) BigQuery is framed as adjacent experience, never as experience (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` the about-page text you pasted; not independently checked (RR1) |
| Mandate | Build and run reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` pasted JD |
| Working pattern and pay | Remote (US) or Denver office; $148,000–$166,000 plus equity | `[grounded]` pasted JD |
| First-year outcomes | Not stated | `[grounded]` pasted JD is silent |
| Scope read | The three duties look like one reporting domain end to end, with no reports mentioned. Whether "run" includes on-call is open (RR5) | `[inferred]` from the JD's three duties against the Datawright description of typical scope |
| Market calibration | Datawright reports base median $151,000 (IQR $139,000–$163,500) for Senior Data Engineers at Series B–D companies, and "Senior" typically means 5–8 years. The posting's low end is $3,000 under the median and its top end is $2,500 over the upper quartile. Your 6 years sits inside that seniority range | `[generic]` Datawright 2026 report (n=2,310) as sent by your recruiter; `[grounded]` JD for the posting's figures |
| Unknowns | Hiring manager, team size, reporting line, equity terms, on-call, how ingestion is done today | — |
| Contradictions | None between the pasted JD and the pasted about page. The live page was not compared | `[grounded]` the two pasted texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You have not stated where you are or what you will accept. Nothing to grade yet | `[grounded]` no constraint given | Question G1 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | The posting states the range. Your pay floor was not given, so whether the range meets it is unknown | `[grounded]` JD states range; no floor given | Question G1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You stated 6 years of data engineering at a B2B payroll company. Specific, but only your own statement so far | `[grounded]` your background | A dated CV or LinkedIn history would raise it |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. Specific on frequency, with no artifact inspected | `[grounded]` your background | A code sample or repo would raise it |
| R5 | dbt | must_have | direct | medium | none | You built the dbt project, about 180 models, on Snowflake. The JD's wording is dbt, with the warehouse separate | `[grounded]` your background | Sanitized dbt docs or a model excerpt would raise it |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse. The JD's general wording is met, and its BigQuery specifics are R9 | `[grounded]` your background | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow named as your orchestrator. What you built or owned in it isn't stated | `[grounded]` your background | A sanitized DAG excerpt would raise it |
| R8 | Experience with data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite, so ownership is stated | `[grounded]` your background | A sanitized suite config would raise it |
| R9 | BigQuery warehouse | important | adjacent | medium | transferability | dbt modelling on Snowflake carries over. The limit: you have not used BigQuery. How closely dbt practice carries between warehouses varies by feature | `[grounded]` your statement; `[generic]` on carry-over | Bridge in G2 |
| R10 | Ingestion from the app and CRM | important | unclear | low | discovery | Your background doesn't say what feeds your models or who built ingestion | `[grounded]` background silent | Question G3 |
| R11 | Data contracts analysts depend on | important | unclear | low | discovery | Nothing stated about agreed schemas or guarantees with downstream users | `[grounded]` background silent | Question G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and pay fit (R1, R2) | hard_gate | The posting's terms are known and your constraints are not | A failed gate would end the decision whatever the fit elsewhere | — | none needed | `[grounded]` no constraints given |
| G2 | BigQuery (R9, important) | transferability | Adjacent: about 180 dbt models on Snowflake. Limit: no BigQuery use. Strengthener: a small dbt project run on BigQuery | The posting names BigQuery in its first line, so it will likely come up | A side project or course run on BigQuery; any BigQuery exposure at work, even as a consumer | A repo or README of a small dbt-on-BigQuery project | `[grounded]` your statement; `[inferred]` that it will come up |
| G3 | Ingestion from app and CRM (R10, important) | discovery | Models are described and ingestion is not | It is the first duty named | Loading from application databases or a SaaS source such as a CRM; managed connectors or custom extractors; owning a failing sync | A pipeline diagram or ingestion README | `[grounded]` background silent |
| G4 | Data contracts (R11, important) | discovery | Testing is described and agreements with consumers are not | The JD names contracts as something analysts depend on | Agreeing schemas, freshness or column definitions with analysts; Great Expectations checks tied to such an agreement; a breaking-change process | A contract doc, schema-change policy or test spec | `[grounded]` background silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not independently established | risk_signal | medium | "Founded 2016, Denver. 264 employees. Series C ($52M, February 2026)" | The posting may be stale or the live page may differ from the pasted text, or the company details may be unconfirmed for another reason. My checks were refused, so this reflects an unchecked page and says nothing about the company | `[generic]` pattern for any unchecked posting, not a claim about this company | Can you point me at this role on your careers page, and who would I interview with? | unresolved |
| RR2 | Hiring manager, team and reporting line unnamed | unknown | — | "The posting names no hiring manager" (your note) | Unknown whether this is a first data hire or one of several | `[grounded]` posting silent | Who does this role report to, and who else is on the data team? | unresolved |
| RR3 | Pay stated and inside the market band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The stated range overlaps the middle of the IQR, so no seniority-pay mismatch appears | `[generic]` Datawright band, `[grounded]` JD figure | Is the range firm, or does it flex by level? | noted |
| RR4 | Equity terms unstated | unknown | — | "plus equity" | The size, type and vesting could change the total value materially | `[grounded]` JD silent | What is the equity type, grant range and vesting schedule? | unresolved |
| RR5 | "Run" leaves on-call and incident duty open | unknown | — | "Build and run the pipelines" | Operating pipelines may carry out-of-hours duty. The posting is silent | `[inferred]` from the word "run" | Is there an on-call rotation, and how many engineers share it? | unresolved |

## Application plan

All rows are proposed. Nothing is final until you approve it, the advice rows included.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Summary line: "Six years of data engineering at a B2B payroll company. I built our dbt project, about 180 models, on Snowflake, used Airflow for orchestration, and set up our Great Expectations test suite." | R3, R5, R7, R8; each clause traces to your own sentences | `[grounded]` your background | resume_edits_pending_approval |
| E2 | Open with dbt, orchestration and data quality, in that order | It follows the order of the JD's requirements | `[grounded]` JD order | pending your approval |
| E3 | Say plainly: "My dbt work has been on Snowflake; I haven't used BigQuery yet." | R9; keeps the adjacent framing honest | `[grounded]` your statement | pending your approval |
| W1 | A small dbt project run on BigQuery, public on GitHub | Narrows the R9 limit (G2) | `[grounded]` R9 | pending your approval |
| Q1 | Ask RR2, RR4 and RR5 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Open the live careers page and apply through it | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask your recruiter for the hiring manager's name and reporting line | RR2; your recruiter already sent the pay report | `[grounded]` your input | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Pellucid Learning online tutoring K-12 Denver Series C $52M" and fetched pellucidlearning.com/careers/senior-data-engineer. Both were refused, so nothing came back. It would have moved role reality's contradictions row and RR1 |
| 2. Role-family sweep | skipped | The Datawright report you pasted already fixes the market calibration and the pay check (RR3) |
| 3. Hiring manager's public footprint | n/a | The posting names no one, so there was no query to form |

## Dossier offer and upgrade menu

I can save this as `tuesday-dossier.md` if you'd like to carry it forward.

- The live posting text or a link confirmation → RR1 closes, and the decision can move from `conditional_go` toward `go`.
- Your location and pay floor → R1 and R2 resolve.
- Answers to G3 and G4 → R10 and R11 move.
- A sanitized dbt model excerpt, DAG, or Great Expectations config → R5, R7 and R8 from `medium` to `high`.
- The hiring manager's name from your recruiter → role reality's scope read and which story to lead with.
- A deeper research pass on Pellucid (funding, leadership churn, hiring patterns, recent news; up to 5 more searches and 2 more fetches) is available on your say-so. It needs search and fetch permissions approved first.

## Questions

G1 — Where are you based (US remote, or able to work from Denver), and is a $148,000–$166,000 base within what you'd accept?

G3 — Have you built or owned ingestion from application databases or a CRM into your warehouse? What did you own and with what tools?

G4 — Did you ever agree schemas, freshness or quality guarantees with the analysts who used your models? What was agreed, and who set it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.