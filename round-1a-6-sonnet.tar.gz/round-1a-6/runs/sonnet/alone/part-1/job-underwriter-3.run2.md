I'll read the skill's reference files first.
**No — not worth pursuing as posted: R1 (pay) and R2 (location) are hard gates that fail. Status: `no_go`.** You're right that something is off. The role itself shows several warning signs (RR5–RR8), and they sit on top of the two failed gates.

I'm treating this as the evaluating stage, since you didn't say otherwise.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (Base pay $70–85k), R2 (On-site Austin, five days a week)
- `must_have` — direct: R3a, R4, R5 · unclear: R3b (Years spent in lead roles)
- `important` — unclear: R6 (SEO and content), R7 (Brand, PR, partnerships), R8 (Sales ops), R9 (Team of one)

R1, R2 — failed gates, whatever the fit on other rows; R4 (`medium`) — paid acquisition matches your history; R6, R7, R8 — channels your summary doesn't mention.

**Opportunity ledger.** Your instinct has rows behind it. The posting's pay and on-site terms conflict with your constraints (RR1, RR2). It folds seven functions into a team of one (RR5), with always-on language (RR6) and metrics that are still undefined (RR7). It does not state a budget (RR8), and it did disclose pay up front (RR9). I could not check the employer or calibrate the pay band (RR3, RR4).

- **Hard gates:** failed: R1 (Base pay $70–85k), R2 (On-site Austin, five days a week).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would change this:** the posted base would have to reach your $150k floor, and the five-day on-site term would have to become remote from Portland. Each of those fails on its own, so both would have to change.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, Series A, "profitable since day one". This is the posting's own description and I haven't verified it. | `[grounded]` JD header |
| Mandate | "Own all revenue growth end to end": paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` JD |
| Reporting | CEO, with a dotted line to the board | `[grounded]` JD |
| Team | "A team of one to start" | `[grounded]` JD |
| Working pattern | "Evenings and weekends when it matters"; on-site in Austin five days a week, "no exceptions" | `[grounded]` JD |
| Compensation | $70–85k base plus "meaningful equity upside", with no equity figures given | `[grounded]` JD |
| First-90-days and first-year outcomes | None stated, and none can be derived. The JD says success metrics "will evolve". | `[grounded]` JD silence |
| Scope read | The title and the 8+ years requirement describe a senior function head, but the seat is one person covering seven functions at a $70–85k base. | `[inferred]` from the JD's title, years and function list against its pay and team lines |
| Market calibration | Not established. The role-family sweep did not run, so I give no market band and you shouldn't assume one. | `[grounded]` research record (see Evidence status) |
| Unknowns | Marketing budget, decision rights, equity terms and the plan for adding a team. | `[grounded]` JD silence |
| Contradictions | None inside the JD's own text. I did not compare it against the company's careers page. | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Compensation: "$70–85k base plus meaningful equity upside" (your constraint: at least $150k base) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own stated floor, which is specific and confirmed. The fit fails because the posted maximum is below your floor. | `[grounded]` JD and your stated constraint | Nothing to fix with wording; only the employer changing the terms resolves it |
| R2 | Location: "On-site in our Austin office 5 days a week — no exceptions" (your constraint: remote only, in Portland, no relocation) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated constraint. The fit fails because the JD rules out remote work in terms that leave no flex. | `[grounded]` JD and your stated constraint | Same as R1 |
| R3a | "8+ years growth leadership required": years in growth | must_have | direct | medium | none | You state 9 years in growth. This is intake prose with no inspectable artifact yet, so `medium`. | `[grounded]` your summary | none |
| R3b | The same requirement: years specifically in lead roles | must_have | unclear | low | discovery | You hold "Growth lead, then Head of Growth" titles, but your summary doesn't say how many of the 9 years were in lead roles. I took the reading that claims less. A years-of-experience requirement is likely to be screened literally. | `[grounded]` your summary's silence; `[generic]` on literal screening | Confirm the dates of each lead title (see G1) |
| R4 | Paid acquisition | must_have | direct | medium | none | You state you "owned paid" and "controlled" a budget while growing one company from $8M to $40M ARR over three years. Confirmed and specific, but no inspectable artifact yet. | `[grounded]` your summary | A sanitized channel-spend or ARR dashboard export would raise this to `high` |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You state you owned lifecycle and are deep in Braze, SQL and GA4. Confirmed, with limited proof. | `[grounded]` your summary | A sanitized Braze campaign report would raise this to `high` |
| R6 | SEO/content | important | unclear | none | discovery | Your summary doesn't mention SEO or content. Not mentioned is different from not done, so I haven't called it a capability gap. | `[grounded]` your summary's silence | See G2 |
| R7 | Brand, PR and partnerships | important | unclear | none | discovery | Same silence in your summary. | `[grounded]` your summary's silence | See G3 |
| R8 | Sales ops | important | unclear | none | discovery | Same silence in your summary. | `[grounded]` your summary's silence | See G4 |
| R9 | Working as a team of one ("players who don't need a bench") | important | unclear | low | discovery | You built and managed teams of 3–7 and owned several channels, but a seven-function solo seat is a different shape. | `[grounded]` your summary; `[inferred]` that it differs from a managed team | See G5 |

## Gap recovery queue

I'm asking nothing here. The two failed gates fix the status, so none of these answers could move it. They would matter only if both gates changed.

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Years in lead roles (R3b, must_have) | discovery | Titles stated, with no dates per title | The JD ties "8+ years" to leadership | Dates for each growth-lead and Head of Growth role | A CV with date ranges | `[grounded]` your summary; `[generic]` on literal screening |
| G2 | SEO/content (R6, important) | discovery | No mention | The JD lists it as a core channel | Content programs you commissioned, organic landing-page work, SEO ownership at either company | An organic-traffic report | `[grounded]` your summary's silence |
| G3 | Brand, PR, partnerships (R7, important) | discovery | No mention | The JD lists all three | Partner launches, affiliate or referral deals, press placements | A partner agreement or coverage list | `[grounded]` your summary's silence |
| G4 | Sales ops (R8, important) | discovery | No mention | A B2B enablement company's sales ops may differ from B2C subscription | CRM routing, lead scoring, pipeline reporting you owned | A pipeline dashboard | `[grounded]` your summary's silence; `[inferred]` that the JD's sales ops differs from your B2C context |
| G5 | Solo breadth (R9, important) | discovery | Team leader, not a one-person function | The seat has no bench | Stretches where you ran several channels yourself | A role description from an early-stage period | `[grounded]` your summary |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posted pay is below your floor (R1) | red_flag | high | "$70–85k base plus meaningful equity upside" | The posted range cannot meet a $150k base floor. | `[grounded]` JD figure against your stated floor | Is $70–85k the full budgeted base range for this seat? | confirmed |
| RR2 | Five-day on-site term conflicts with remote-only (R2) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | The JD rules out remote arrangements. | `[grounded]` JD against your stated constraint | Is the five-day on-site term fixed for this seat? | confirmed |
| RR3 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The company may be too new or small for a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. I could not check, because the search was refused. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your own careers site, and who I would interview with? | unresolved |
| RR4 | Seniority and pay may not match the mandate | risk_signal | medium | "Head of Growth", "8+ years growth leadership required", "$70–85k base" | A head-of-function title with a seven-function scope may be priced below what that scope normally commands. I have no market band to confirm it. | `[inferred]` from the JD's title, scope and base figure | What does the company's own pay band say for this level, and how is the equity sized? | unresolved |
| RR5 | Bundled specializations on a team of one | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops"; "a team of one to start" | Several full roles are folded into one seat. | `[inferred]` from the JD's function list against its team line | Which of these functions would you expect me to run myself, and which will be hired or outsourced, and when? | unresolved |
| RR6 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | The role may carry routine off-hours work. | `[inferred]` from the JD's wording | How often do evenings and weekends come up in a typical month? | unresolved |
| RR7 | Accountability without defined success | risk_signal | medium | "Own all revenue growth end to end"; "success metrics will evolve as we learn" | You could be accountable for revenue with no agreed definition of success. | `[inferred]` from the JD's two lines | What would a successful first year look like, and who sets the targets? | unresolved |
| RR8 | Budget and decision rights not stated | unknown | — | "Report to the CEO with a dotted line to the board" | The JD names no marketing budget or authority over spend. | `[inferred]` from the JD's silence | What marketing budget and spend authority come with this role? | unresolved |
| RR9 | Pay disclosed and reporting line stated | positive_signal | — | "Compensation: $70–85k base"; "Report to the CEO" | The posting is open about pay and gives direct access to the CEO. | `[grounded]` JD | Who currently owns growth decisions at the CEO level? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply to this posting as written | See R1, R2 | `[grounded]` the two failed gates | pending your approval |
| A2 | If you want to keep the door open, send one message asking only whether the base range and the on-site term are fixed for this seat. Don't propose workarounds. | The posting says "no exceptions", so a reply is unlikely to move either term | `[grounded]` JD wording | pending your approval |
| A3 | If you proceed anyway, ask RR1–RR8 verbatim, starting with RR5, RR7 and RR8 | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A4 | No CV edits proposed (`resume_edits_pending_approval`: none) | No edits are warranted while the gates fail | `[grounded]` the two failed gates | pending your approval |

Nothing in this plan is final until you approve it, including any advice in prose.

## Evidence status

Verified: none yet. Stage assumed: evaluating.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | I sent one search, "Novaline e-commerce enablement startup Austin Head of Growth". The host refused it and I did not retry. It would have moved role reality's organization and contradictions rows and RR3. |
| 2. Role-family sweep | unavailable | I sent one search, "Head of Growth salary startup Series A base salary range". The host refused it and I did not retry. It would have moved role reality's market calibration and RR4. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |

Neither missing target could change the status, because R1 and R2 fix it.

If it's useful, I can write this up as `tuesday-dossier.md` for you to keep.

**Upgrade menu**

- **Search permission:** a search that confirms the live posting and a pay band would settle RR3 and RR4, but neither moves `no_go`.
- **The employer's answer on pay and on-site terms:** it would re-open R1 and R2, and it is the only input that can change the status.
- **A CV with date ranges per title:** it would settle R3b.
- **A sanitized ARR or channel-spend dashboard, or a Braze campaign report:** it would raise R4 and R5 to `high`.
- **Evidence on SEO, brand/PR/partnerships or sales ops:** it would settle R6–R8, and it matters only if both gates change.
- **The hiring manager's name:** it would sharpen the scope read and which story to lead with.

**Questions:** none. Nothing I could ask would change a status that R1 and R2 fix.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.