Still reading the skill's remaining reference files (row shape, output rules, research tiers). Then I'll write the assessment.
# Job underwriting: Product Manager, Platform APIs at Quartzline

Your question was whether you're wasting your time, so that comes first.

## Decision snapshot

**No, this isn't a waste of time, but it is a stretch on R1a: you have no titled PM years, and the JD marks them a must-have. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R3 · adjacent: R1b (PM-type work toward 3+ years), R2 (Shipped API or platform products), R4 (Roadmap ownership), R5 (Specs and delivery with two squads) · absent: R1a (Titled PM experience, 3+ years)
- `important` — direct: R9a · adjacent: R6 (Discovery with integration partners) · unclear: R7 (Adoption metrics), R8 (Launches with sales and support), R9b (Stakeholders in sales), R10 (Agile delivery)

R1a — the title gap, a stated must-have; R3 (`medium`) — direct, waiting on an artifact.

**Opportunity ledger.** The employer is unverified because no search ran (RR1). Pay, work location and first-year outcomes are all unstated (RR2, RR3, RR4). Whether "3+ years" is read as titled years is open (RR5). The posting does name its squads and a partner-facing scope (RR6).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and the live posting verify on Quartzline's own careers page (RR1); (2) someone confirms that product-adjacent work without the title can count toward the 3+ years (RR5, R1a, R1b); (3) the bridges are framed as adjacent, never as PM or roadmap ownership (R2, R4, R5).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B; not independently checked | `[grounded]` JD header only |
| Mandate | Own the roadmap for the partner-facing API platform; run discovery with integration partners; write specs and drive delivery with two engineering squads; define and track adoption metrics; coordinate launches with sales and support | `[grounded]` JD |
| Tiering | The JD labels only the 3+ years "must-have". I tiered the other must-have rows (R2, R3, R4, R5) from how central they are to the mandate | `[inferred]` from the JD's responsibilities list |
| First-year outcomes | Not stated | `[grounded]` JD silence |
| Scope read | A single-product-area PM seat with two squads, which reads as a mid-level post, not a director-level one | `[inferred]` from the squad count and the 3+ years floor |
| Market calibration | Not obtained. The role-family search was refused, so no pay band or title norm is stated | none |
| Unknowns | Pay; work location; reporting line; new seat or backfill; whether titled years are strict | none |
| Contradictions | None inside the material provided. I did not check the JD against Quartzline's careers page | `[grounded]` JD read; check not run |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years product management experience, as titled | must_have | absent | none | capability | You said you have never held a PM title, so there are no titled years to show. Literal screens on this line would likely fail you, though I don't know how Quartzline applies it | `[grounded]` your statement; `[generic]` that years requirements are often screened literally | RR5's question to the recruiter; closure path in G1 |
| R1b | 3+ years of PM-type work, not titled | must_have | adjacent | medium | transferability | Your work near PM: requirements documents, scoping workshops, coordinating engineers and product managers on custom builds, quarterly roadmap-input sessions. Limit: you stood on the vendor-delivery side, and you didn't say you owned a product backlog or its prioritization. Self-reported and not yet probed | `[grounded]` your resume summary; `[inferred]` adjacency to PM work | G2 and G3 answers; a sanitized artifact would raise it |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ client integrations of your employer's REST APIs and wrote the internal integration playbook. Limit: you didn't say you built or shipped an API product, only that you integrated clients onto one and wrote an internal playbook | `[grounded]` your resume summary; `[inferred]` adjacency | G2 |
| R3 | Strong technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL and OpenAPI reading, plus integration architecture across 30+ client integrations. Nothing inspectable yet | `[grounded]` your resume summary | A sanitized architecture diagram or the playbook's table of contents would raise it to `high` |
| R4 | Own the roadmap | must_have | adjacent | medium | transferability | You ran quarterly roadmap-input sessions collecting client feedback for product. Limit: that is input to a roadmap, and you didn't say you decided priorities | `[grounded]` your wording; `[inferred]` that product managers held the decisions, from your coordinating with them | G2 |
| R5 | Write specs and drive delivery with two engineering squads | must_have | adjacent | medium | transferability | You wrote requirements documents and coordinated your engineers, the client's engineers and product managers on custom builds. Limit: nothing says you drove a squad's delivery or worked from a product backlog | `[grounded]` your resume summary; `[inferred]` adjacency | G4 |
| R6 | Run discovery with integration partners | important | adjacent | medium | transferability | Scoping workshops and the quarterly feedback sessions are close to partner discovery. Limit: they were for scoping implementations and feeding product, and you didn't mention discovering new product opportunities | `[grounded]` your resume summary; `[inferred]` adjacency | none now; G2 may add evidence |
| R7 | Define and track adoption metrics | important | unclear | low | discovery | Nothing in your background mentions adoption measures. A count of go-lives is throughput, not adoption | `[grounded]` resume silence | G3 |
| R8 | Coordinate launches with sales and support | important | unclear | low | discovery | Your go-lives are launches of a kind, but you didn't mention sales or support handoffs | `[grounded]` resume silence | G4 |
| R9a | Stakeholder management: engineering and customers | important | direct | medium | none | You coordinated your engineers, client engineers and clients through 30+ integrations | `[grounded]` your resume summary | none |
| R9b | Stakeholder management: sales | important | unclear | low | discovery | Sales isn't mentioned | `[grounded]` resume silence | G4 |
| R10 | Agile delivery | important | unclear | low | discovery | Your delivery method on custom builds isn't stated | `[grounded]` resume silence | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Titled PM years (R1a, must_have) | capability | No PM title and no stated product-owner stint | If the 3+ years is applied literally, this row decides the screen. Wording can't close it and I won't suggest any | None to ask for. Closure paths: apply with a referral, target a role that hires on product-adjacent work, or take a titled step first (associate or technical PM, or a product-owner scope inside your current company) | n/a | `[grounded]` your statement; `[generic]` that these are the usual closure paths |
| G2 | Shipped API or platform product, roadmap ownership (R2, R4, R1b) | transferability | The adjacent work is the integrations, the playbook and the roadmap-input sessions. The limit is that none is stated as a product you owned and shipped. An earlier-conversation note about a request-triage tool is unconfirmed | These are must-haves at `adjacent`. A confirmed owned artifact is what moves R2 and R4 toward `direct` | A tool or workflow you specified that engineers built and others adopted; an integration pattern you productized; a playbook feature requested and shipped | A short spec, release note, usage screenshot or roadmap excerpt, sanitized | `[grounded]` your summary; `[inferred]` the bridge; unconfirmed memory note used only as a question |
| G3 | Adoption metrics (R7, important) | discovery | No measure of use or adoption is stated | The JD asks you to define and track adoption. An example would also support R1b | Go-live rate, time to first successful call, teams using the playbook, support-ticket volume after launch | A dashboard screenshot or a quarterly review slide | `[grounded]` resume silence; `[inferred]` that this is a common PM interview probe |
| G4 | Sales and support launch coordination, agile delivery (R8, R9b, R10, important) | discovery | These aren't stated | Lower decision impact than G2 and G3, so no question this turn | Handoffs to support at go-live; enabling sales on integration scope; sprint ceremonies on custom builds | A launch checklist, handoff doc or sprint board | `[grounded]` resume silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | No search ran, so this is unchecked, not a failed lookup. The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay not stated | unknown | — | No compensation figure in the posting as provided | The range may or may not suit a mid-career pivot; without a band I can't say | `[inferred]` from the posting's silence | What is the budgeted salary range for this post? | unresolved |
| RR3 | Work location and arrangement not stated | unknown | — | No location or arrangement in the posting as provided | A mismatch with your needs can't be ruled out until you state them | `[inferred]` from the posting's silence | Is this remote, hybrid or office-based, and where? | unresolved |
| RR4 | First-year outcomes not stated | unknown | — | "define and track adoption metrics" | Success may not yet be defined for the seat, and the role may be asked to define it as well as hit it | `[inferred]` from the one measurement phrase against the lack of any target | What would you want shipped or moved in the first year? | unresolved |
| RR5 | Whether "3+ years" means titled PM years | unknown | — | "3+ years product management experience (must-have)" | It may be read as titled years. How Quartzline applies it is unknown | `[generic]` that such lines are often applied literally; this employer's practice not known | Would substantial product-adjacent work without a PM title count toward the 3+ years? | unresolved |
| RR6 | Concrete scope and engineering capacity named | positive_signal | — | "drive delivery with two engineering squads"; "partner-facing API platform" | A defined seat with named capacity, not an open-ended mandate | `[grounded]` JD names both | Is this a new seat or a backfill, and who does the role report to? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check the role and the company on Quartzline's own careers page before spending effort | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Put RR5's question to the recruiter, or to a referral if you can find one, before a full application | R1a, RR5. A referral or recruiter conversation is a common way to learn how a requirement is applied | `[grounded]` RR5; `[generic]` on how requirements get applied | pending your approval |
| A3 | In the application, call the roadmap-input work what you called it: sessions collecting client feedback for product. Don't describe it as product management or as owning a roadmap. Name the limit when asked | R4, R1b, R2, R5, and the reframing audit | `[grounded]` your own wording | pending your approval |
| E1 | Move your integration bullet up and keep it in your words: "Led 30+ client integrations of our REST APIs end to end — scoping workshops, requirements documents, integration architecture, UAT, go-live". It adds no new fact | R2, R3, R9a. Traces to your summary line | `[grounded]` your resume summary | resume_edits_pending_approval |
| E2 | Move the roadmap-input bullet near the top of that role, unchanged: "Ran quarterly roadmap-input sessions collecting client feedback for product". Don't extend it | R4, R6. Traces to your summary line | `[grounded]` your resume summary | resume_edits_pending_approval |
| E3 | Surface the playbook as it stands: "Wrote the internal integration playbook the whole team uses". Don't add adoption or impact claims you haven't given me | R2, R7. Traces to your summary line | `[grounded]` your resume summary | resume_edits_pending_approval |

Offer, beyond this spec: I can sketch a one-quarter plan for building titled-equivalent product evidence from where you are, such as a scoped internal tool or an API proposal your team adopts. I'll build it only if you say yes.

## Evidence status

Verified: none yet. Unverified leads: a note from an earlier conversation about a request-triage tool adopted by support agents. It is unconfirmed and used only to prompt G2.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Quartzline logistics technology partner API platform careers" was refused. It would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | The search "platform API product manager B2B SaaS requirements career transition from solutions engineer" was refused. It would have moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Closing

I can write this up as `tuesday-dossier.md` whenever you want it.

**Upgrade menu**
- Permission to run web search → Quartzline's careers page and role-family pay and title norms; RR1 and RR2 and the market calibration row.
- Answers to G2 and G3 → R2, R4, R1b and R7 can move.
- A sanitized architecture diagram or the playbook's table of contents → R3 to `high`.
- The recruiter's answers on RR2, RR3 and RR5 → pay, location and how strict the titled years are.
- The hiring manager's name → the scope read and which story to lead with.
- Your non-negotiables → the hard-gates line gets real checks.

**Questions**

G2 — I have an unconfirmed note from an earlier conversation about a request-triage tool that support agents adopted. If it was yours, what did you decide to build or change, who used it, and what showed it worked? If not, is there something else you specified that engineers built and others adopted?

G3 — On your integrations or the playbook, did you track any adoption measure, such as go-live rate, time to first successful call or number of teams using the playbook? What did it show?

Hard-gates line — What are your non-negotiables for a move: pay floor, remote or office, contract type?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.