I've read the posting and the skill's rules. Now I'm running the research it calls for: Quillfield's own site, UK pay for this role, and Tamsin Achebe's public professional footprint.
**Yes, apply, but go in knowing two of the must-haves are real gaps (R7, R8a). Status: `conditional_go`.**

Jargon gloss: R-numbers are requirement rows in the evidence map below, and RR-numbers are risk-register entries.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol, two office days), R2 (£61,500–£67,000 pay)
- `must_have`: direct: R3, R4, R5 · adjacent: R6 (Spreadsheet modelling), R7 (Experience owning a forecast) · unclear: R8b (Working with finance on revenue data) · absent: R8a (Billing data)
- `important`: direct: R9 · adjacent: R10 (Run quarterly forecast with the CFO)

R7 — the forecast gap, bridged only by what you can show; R8a — billing absent by your own account; R8b — still open to recovery.

**Opportunity ledger.** No red flag. The pay is stated and sits inside the market figure (RR3). The open items are scope and team (RR1), the CRM and billing systems (RR2), the posting not yet confirmed on Quillfield's own site (RR4), who builds the forecast (RR5) and the share-option terms (RR6).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol, two office days), R2 (£61,500–£67,000 pay); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the location and pay terms suit you (R1, R2); (2) the forecast bridge holds up, from your own evidence or from RR5 showing the CFO shares the forecast work (R7, R10); (3) you state the billing gap plainly and the employer treats it as learnable (R8a, RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants, founded 2018 in Bristol, 96 employees, £11M Series A closed April 2025 | `[grounded]` quillfield.co.uk/about, from a search result |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting for sales and finance; run the quarterly revenue forecast with the CFO | `[grounded]` JD |
| Working pattern and pay | Bristol, hybrid, two office days a week; £61,500–£67,000 plus share options | `[grounded]` JD |
| Hiring manager | Tamsin Achebe, Head of Revenue Operations at Quillfield, previously sales operations manager at Corvane Payments for four years | `[grounded]` LinkedIn search result, matches the recruiter's account |
| First-year outcomes | None stated in the posting | `[grounded]` JD silence |
| Scope read | CRM, billing data, reporting and forecasting sit in one post, with no team or tools named; the post likely reports to the Head of RevOps | `[inferred]` from the JD's scope list against its silence on team, and from her title |
| Market calibration | The posted band sits near the middle of the market figure: Ledgerline 2026, revenue operations lead, UK B2B software, n=438, median base £64,200, interquartile range £57,800–£70,400. Read from the search result, not the full guide. It is a market figure, never Quillfield's offer | `[generic]` pay guide; `[grounded]` JD band |
| Unknowns | CRM and billing system; team size; who builds the forecast; share-option terms; success measures | n/a |
| Contradictions | None between the JD and the About page. The posting itself was not found on Quillfield's own site, and the one careers URL I tried returned no page, so that check is inconclusive | `[grounded]` About page and the failed fetch |

## Evidence map

I worked from your account in the chat, which counts as self-report. No CV was seen, so `medium` is the ceiling for now.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two days a week in the office | hard_gate | unclear | none | hard_gate | The posting states it. You gave no location or schedule constraint, so there is nothing to check it against | `[grounded]` JD; constraints not given | Constraint question below |
| R2 | Pay £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | The posting states the band. You gave no pay floor or current pay | `[grounded]` JD; band context `[generic]` pay guide | Constraint question below |
| R3 | 4+ years in revenue operations, sales operations or similar at a B2B software company | must_have | direct | medium | none | 5 years in sales operations, 2 of them running RevOps for the UK team. Your employer is a B2B payments company; whether it reads as "B2B software" is not stated, so describe it as it is | `[grounded]` your account; `[inferred]` sector reading | none |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified, and you rebuilt the pipeline and renewal dashboards. The certification was not seen | `[grounded]` your account | The certification record would raise it to `high` |
| R5 | Strong SQL | must_have | direct | medium | none | SQL weekly. Frequency does not establish the level "strong" implies | `[grounded]` your account | A sanitized query or analysis would raise it |
| R6 | Spreadsheet modelling | must_have | adjacent | medium | discovery | Excel daily is established. Assumption-driven models are not stated | `[grounded]` your account | See G4 |
| R7 | Experience owning a forecast | must_have | adjacent | medium | transferability | Adjacent: you run the monthly pipeline review with the sales director. Limit: you have never owned the company forecast, because finance did | `[grounded]` your account | See G1 |
| R8a | Billing data ("own our CRM and billing data"; finance work "on billing or revenue data", billing limb) | must_have | absent | none | capability | You have never worked on billing data | `[grounded]` your account | See G2 |
| R8b | Working with finance on revenue data (the "or revenue data" limb of the same JD line) | must_have | unclear | low | discovery | Renewal dashboards and finance's ownership of the forecast suggest contact with finance. Nothing you shared establishes joint work on revenue figures | `[inferred]` from the dashboards against silence on finance work | See G3 |
| R9 | Build the pipeline and renewal reporting sales and finance run on | important | direct | medium | none | You rebuilt both sets of dashboards. Whether finance used them is unconfirmed (R8b) | `[grounded]` your account | A sanitized screenshot would raise it to `high` |
| R10 | Run the quarterly revenue forecast with the CFO | important | adjacent | medium | transferability | Adjacent: a monthly review with a sales director. Limit: no stated forecast ownership or CFO-level exposure | `[grounded]` your account | See G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R7, must_have; R10, important) | transferability | Bridge: you run the monthly pipeline review. Limit: finance owned the company forecast, and you have not said you built any forecast | The role runs the quarterly forecast with the CFO, so this is the gap most likely to decide the application | A UK-team pipeline or commit forecast you produced; a bookings or renewal forecast that fed finance's number; the assumptions you set for a roll-up; a forecast-versus-actual variance review | A sanitized forecast workbook, a pipeline review deck, a variance report | `[grounded]` your account; `[inferred]` that it decides the application, from the JD's forecast duty |
| G2 | Billing data (R8a, must_have) | capability | No direct or adjacent evidence, by your own account | The JD makes billing data part of the job and not only a requirement | None identified. If you have touched invoice or subscription exports even read-only, that would change the type | n/a | `[grounded]` your account |
| G3 | Finance work on revenue data (R8b, must_have) | discovery | The renewal dashboards may have fed finance; the shared account does not say | A `must_have` row currently `unclear`, and the one most likely to move up | Renewal figures finance used or reconciled; ARR or renewal-rate definitions agreed with finance; month- or quarter-end numbers you supplied | A sanitized dashboard screenshot, a definitions note, a reconciliation sheet | `[grounded]` your account; `[inferred]` that it may move up |
| G4 | Spreadsheet modelling (R6, must_have) | discovery | Daily Excel use, with no model described | A `must_have` row currently `adjacent` | Scenario, quota, capacity or commission models with assumption tabs | A sanitized workbook | `[grounded]` your account |
| G5 | Location and pay terms (R1, R2, hard_gate) | hard_gate | The posting states both terms; none of yours were given | Either term could fail outright, whatever the fit | n/a | n/a | `[grounded]` JD; constraints not given |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Wide scope, no team or tools named | unknown | — | "own our CRM and billing data, build the pipeline and renewal reporting… and run the quarterly revenue forecast" | This may be a one-person function, with the Head of RevOps above it | `[inferred]` from the JD's scope against its silence on team | Who is on the revenue operations team today, and who does this role report to? | unresolved |
| RR2 | CRM and billing systems unnamed | unknown | — | "HubSpot or Salesforce administration" | The role may inherit HubSpot rather than your Salesforce, and the billing system is unnamed | `[inferred]` from the either-or wording | Which CRM and which billing system would I own? | unresolved |
| RR3 | Pay stated, inside the market figure | positive_signal | — | "£61,500–£67,000 plus share options" | A stated band within the market range suggests a transparent offer | `[grounded]` JD; `[generic]` pay guide | What is the budgeted level within the band, and how are options structured? | noted |
| RR4 | Posting not confirmed on the company's own site | unknown | — | "Revenue Operations Lead, Quillfield" | Quillfield and the hiring manager both exist, and the posting may simply sit on a jobs board only | `[grounded]` About page and LinkedIn result; `[inferred]` that the posting is live | Can you point me to this role on Quillfield's own careers page? | unresolved |
| RR5 | Who builds the forecast | unknown | — | "run the quarterly revenue forecast with the CFO" | "With the CFO" may mean the CFO builds the model and this role runs inputs and process, which would narrow R7 | `[inferred]` from the word "with" | Who owns the forecast model today, and what would this role own on day one? | unresolved |
| RR6 | Share options unvalued | unknown | — | "plus share options" | Terms are unstated, so the options cannot yet be weighed against the salary | `[grounded]` JD silence | What is the grant size, vesting schedule and strike price basis? | unresolved |

## Application plan

Everything in this plan, the wording and the actions alike, is proposed. Nothing is final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with "5 years in sales operations, 2 running revenue operations for the UK team" and the rebuilt pipeline and renewal dashboards. Say "ran the monthly pipeline review with the sales director". Do not say forecast ownership or billing-data experience | See R3, R7, R9; both stay outside what the evidence supports | `[grounded]` your account | pending your approval |
| E2 | State the billing gap plainly once, and pair it with the renewal reporting you did build | See R8a, R9 | `[inferred]` the pairing is derived from those rows | pending your approval |
| Q1 | Put RR1, RR2, RR4 and RR5 to the recruiter before investing in the application | The register doubles as screening questions | `[grounded]` register | pending your approval |
| A1 | Lead the conversation with Tamsin Achebe with your own sales-operations-to-RevOps path. Her public record shows a similar route | See role reality, hiring manager row | `[inferred]` from the search result's career line | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company Bristol careers", which returned "About Quillfield" (quillfield.co.uk/about). Fetched quillfield.co.uk/careers, which returned no page. It confirmed the employer exists as described (role reality, organization row). It could not confirm the posting live (RR4) |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK B2B software Bristol", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). It moved the market calibration row and RR3. It showed no pay mismatch |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). It moved the hiring-manager and scope rows and A1 |

I can write this up as a saved `tuesday-dossier.md` if you'd like.

**Upgrade menu**

- Your location and pay floor → R1 and R2 resolve, and the hard-gates line becomes a clear met or fail.
- Any forecast artifact, such as a sanitized workbook, a pipeline review deck or a variance report → R7, R10 and R6 firm up, and R7 can reach `high`.
- Your CV, a dashboard screenshot and the Salesforce certification record → R4 and R9 can reach `high`, and I can propose truthful CV edits for your approval.
- Anything showing joint work with finance on revenue figures → R8b resolves, and G3 closes.
- The recruiter's answers on systems, team and forecast split → RR1, RR2 and RR5 close.
- A deeper research pass on Quillfield, covering funding, leadership and hiring patterns plus recent news (up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

1. **G1** — Have you ever built, called or defended a forecast for a team, such as UK pipeline commit or bookings, even where finance owned the company number? What was yours, and who saw it?
2. **G3/G2** — What did you do with finance: did your renewal dashboards feed or reconcile to their revenue figures, and have you ever touched invoice or subscription-billing exports, even read-only?
3. **R1/R2** — Do Bristol with two office days a week and the £61,500–£67,000 band work for you?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.