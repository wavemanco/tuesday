I'll read the skill's reference files before building the assessment.
## Decision snapshot

**On fit, yes. On the role as posted, not yet: the JD says fully remote, but Brindlemoor's own careers page says "Leeds office four days a week" (R1, RR1). Settle that before you spend application effort. Your two gaps, pet insurance and management, aren't asked for in the JD (see role reality). Status: `hold_pending_answers`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK))
- `must_have` — direct: R2, R3, R4, R5, R6a, R7 · unclear: R6b (Monitor rating models)
- `important` — direct: R8a · unclear: R8b (Recommendations to product)
- `preferred` — direct: R9

R1 — two employer sources disagree and your own limit isn't stated; R6b — your CV-level claim is "maintained", monitoring isn't described; R7 (`medium`) — ran 14 tests, design ownership unconfirmed; R8b — no product audience evidenced.

**Opportunity ledger.** The posting is live on Brindlemoor's own site with a named reporting line (RR3). Its working pattern contradicts the JD (RR1), pay is unstated (RR2), and success measures, team shape and sign-off authority are unstated (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Awaited answers:** Brindlemoor's actual working pattern (RR1), and your own position on Leeds four days a week (G1). If the pattern is Leeds four days and you can't do it, R1 becomes `hard_gate_fail` and the status `no_go`. If remote is confirmed, or Leeds suits you, the status moves to `conditional_go`, conditioned on G2. G3 and G4 shape your positioning, not the decision.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product. The role is listed on brindlemoor.co.uk and "accepting applications". Size and stage are not established | `[grounded]` JD header; careers page fetched |
| Mandate | Own pricing analytics for the pet-insurance product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reporting line | Reports to the Director of Pricing, Odile Varga | `[grounded]` careers page; JD names her as hiring manager |
| Working pattern | JD: "Fully remote (UK)". Careers page: "Leeds office four days a week" | `[grounded]` both texts quoted |
| Contradictions | The working pattern above, between the JD you hold and the careers page. Where your JD came from isn't known to me | `[grounded]` |
| Line management | The JD states no line-management or team-lead requirement. Team size is unstated | `[grounded]` JD silence |
| Domain | The JD asks for no pet-insurance experience. It lists "insurance experience a plus", and your motor background counts toward that (R9) | `[grounded]` JD; your message |
| Level | The title is "Senior"; your current title is senior analyst, so the seniority matches and the role is not obviously a step up | `[grounded]` JD title and your message |
| First-year outcomes | Not stated | `[grounded]` JD silence |
| Hiring manager | Odile Varga, Director of Pricing; previously head of pricing analytics at Calloway Re for six years; spoke at the 2025 Insurance Pricing Forum on "Small Books, Loud Errors" (monitoring rating models in small books) | `[grounded]` search-result snippet (page not opened) |
| Scope read | The JD's "monitor" duty and the hiring manager's published talk topic point at the same thing. Monitoring is probably where this role gets probed | `[inferred]` from the JD duty against the talk title |
| Market calibration | UK senior pricing analyst, insurers and insurtechs: median base £58,400, interquartile range £52,100 to £64,900 (n=612). The posting withholds pay, so this is the band to expect, not Brindlemoor's offer (RR2). Your pay floor was not given | `[generic]` Pricewell 2026 survey snippet; `[grounded]` JD for the missing figure |
| Unknowns | Working pattern, pay, team shape, sign-off authority on rating changes, success measures | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | The JD says "Fully remote (UK)"; the careers page says "Leeds office four days a week". You have stated no working-pattern limit, so neither text can be checked against you. `none` grades the absent statement, not the role | `[grounded]` JD; careers page; no constraint stated | G1 question; RR1 to the employer |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years pricing analytics at a UK motor insurer, specific and confirmed; self-reported, nothing inspected | `[grounded]` your message | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily" is a specific claim of use. "Strong" is the JD's bar for depth, so expect a probe | `[grounded]` your message | optional: an anonymised query or notebook would raise it to `high` |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for the young-driver book; specific, no artifact inspected | `[grounded]` your message | optional: an anonymised model specification or factor summary would raise it to `high` |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. The JD says "underwriting or actuarial", so underwriting meets it; an actuarial audience is not claimed | `[grounded]` your message | none |
| R6a | Build rating models | must_have | direct | medium | none | The same young-driver GLM as R4 | `[grounded]` your message | none |
| R6b | Monitor rating models | must_have | unclear | low | discovery | You wrote "maintained". Monitoring is a practice you haven't described, and reading "maintained" as "monitored" would resolve upward. `[generic]` maintaining a rating model usually involves some monitoring, which is why it's worth asking. It is not evidence about your work | `[grounded]` your message; `[generic]` pattern | G2 |
| R7 | Design and read price tests | must_have | direct | medium | discovery | You ran 14 price tests last year with the underwriting team. "Ran" doesn't say whether you designed them, so ownership of the design is unconfirmed | `[grounded]` your message | G3 |
| R8a | Recommendations to underwriting | important | direct | medium | none | The underwriting audience is carried by R5 and R7 | `[grounded]` your message | none |
| R8b | Recommendations to product | important | unclear | low | discovery | Your message names no product audience. Low, not none, because a pricing review plausibly reaches product teams | `[grounded]` your message silence; `[inferred]` the plausibility | G4, deferred this turn |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer. Pet-specific experience is not what the JD asks for | `[grounded]` JD; your message | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Working pattern (R1, hard_gate) | hard_gate | Two employer texts disagree and you haven't stated a limit | It can move the status to `go`-track or to `no_go` | Not an experience question: whether you can work the pattern Brindlemoor actually sets | Brindlemoor's written confirmation, reached through a contact on its own careers site | `[grounded]` both quotes; `[inferred]` that it can decide the status |
| G2 | Monitoring rating models (R6b, must_have) | discovery | "Maintained" the young-driver GLM; no monitoring described | A listed duty, and the hiring manager's published talk topic is monitoring | Tracking actual against expected results by segment after a rate change; drift or lapse reports; refresh triggers for the GLM | An anonymised monitoring report or dashboard screenshot | `[grounded]` your message; `[inferred]` the talk-topic link |
| G3 | Designing price tests (R7, must_have) | discovery | 14 tests run with underwriting; design role unconfirmed | "Design and read" is the JD's wording, and an interviewer will ask what was yours | Choosing test cells; sizing them; setting the success measure; reading the result and recommending | An anonymised test brief or read-out | `[grounded]` your message; `[generic]` that interviews probe design ownership |
| G4 | Recommendations to product (R8b, important) | discovery | No product audience evidenced | One half of the JD's recommendation duty | Presenting a test result or rate change to a product owner or a product committee | A review pack excerpt showing a product audience | `[grounded]` your message silence. Question deferred: ranked below G1 to G3 within this turn's budget |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern differs between JD and careers page (R1) | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | The JD may be an older or different version, the pattern may have changed, or one text may be wrong; none is ranked as likelier. Medium rather than high: it is a mismatch between texts, and it becomes decisive only if R1 fails for you | `[inferred]` from the two quotes | Is this role fully remote, or based in the Leeds office four days a week? | unresolved |
| RR2 | Pay unstated against an unknown floor (R1 sits apart; floor not given) | unknown | — | No salary in the JD as pasted or the careers page text retrieved | The figure may sit near the survey band in role reality, or Brindlemoor may not publish it | `[inferred]` from the withheld figure against the `[generic]` band | What salary range is budgeted for this role? | unresolved |
| RR3 | Live posting on the employer's own site with a named reporting line | positive_signal | — | Careers page: "Accepting applications … reports to the Director of Pricing" | The opening is current and sits under a defined manager | `[grounded]` careers page fetched | When are you hoping to have the role filled? | noted |
| RR4 | Success measures, team shape and sign-off authority unstated | unknown | — | JD: "Own pricing analytics for our pet-insurance product" | "Own" may include sign-off on rating changes or may stop at recommending them; team size is unknown | `[inferred]` from the JD's scope language against its silence | What would a good first year look like, and who signs off rating changes? | unresolved |

## Application plan

Every row and the draft below are proposals. Nothing is final until you approve it, and approval of one block doesn't cover another.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the working pattern with Brindlemoor before drafting, through a contact on its own careers site | R1, RR1 | `[grounded]` the contradiction between the two texts | pending your approval |
| E1 | Use the draft opening below in place of your current CV summary | R2 to R5, R6a, R7 | `[grounded]` your message | pending your approval |
| P1 | Lead with the GLM model and the price tests. Add the monitoring work only once G2 is answered | The hiring manager's published talk topic is monitoring | `[inferred]` from the talk title; `[grounded]` the talk title | pending your approval |
| P2 | Say plainly that pet insurance is new to you, then point to the motor pricing evidence | Candour holds up under follow-up; the JD doesn't ask for pet experience | `[grounded]` your message; JD | pending your approval |
| Q1 | Ask the RR1, RR2 and RR4 questions verbatim at the first call | The register doubles as interview preparation | `[grounded]` register | pending your approval |

**Draft CV opening — `resume_edits_pending_approval`:**

> Pricing analyst at a UK motor insurer for five years, the last two as senior analyst. Built and maintained the GLM rating model for the young-driver book. Ran 14 price tests last year with the underwriting team. Present the quarterly pricing review to the head of underwriting. Use SQL and Python daily.

Each sentence restates something you wrote. Monitoring, test design and product audiences are left out until G2 to G4 are confirmed, and nothing here touches management or pet insurance.

## Evidence status

Verified: none yet. Your background was taken from your message, which stands at CV level: it is self-reported and capped at `medium` until something inspectable is seen.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech" (no results) and "Brindlemoor careers Senior Pricing Analyst"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). The role is live on the employer's own site, so no failed-attribution entry is raised. It exposed the working-pattern contradiction (R1, RR1). The general company search found nothing, so size and stage stay not established |
| 2. Role-family sweep | yes | Searched "senior pricing analyst pet insurance UK salary remote", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). Read from the result snippet only. It set the market calibration and RR2. The survey covers insurers and insurtechs generally, not pet or remote roles specifically |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga). Read from the snippet only. It fed role reality's hiring-manager and scope rows and plan row P1 |

I can write this up as `tuesday-dossier.md` if you want a portable copy.

## Upgrade menu

- Your working-pattern limit (can you do Leeds four days a week, and is remote a firm requirement) → R1 and G1 close, and the status resolves to `no_go` or `conditional_go`.
- Brindlemoor's written answer on the working pattern → RR1 closes.
- Your pay floor, and the salary range when Brindlemoor gives one → RR2 closes against the band in role reality.
- Your actual CV → the rows built from your message are checked against it, and any presentation gaps surface.
- An anonymised monitoring report or test read-out → R6b and R7 can be graded on something inspectable, and R7 can reach `high`.
- An anonymised query, notebook, or GLM specification → R3 and R4 can reach `high`.
- The source of your JD copy → explains the RR1 contradiction.
- A deeper research pass on Brindlemoor (funding, leadership changes, staff and candidate reports, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

G1 — How do you stand on working from Leeds four days a week: is that something you can do, or is fully remote a firm requirement for you?

G2 — Did you monitor the young-driver GLM after it went live, and if so, what did you track and what did it lead you to do?

G3 — Of the 14 price tests, which parts were yours: designing the test, running it, or reading the result and recommending to underwriting?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.