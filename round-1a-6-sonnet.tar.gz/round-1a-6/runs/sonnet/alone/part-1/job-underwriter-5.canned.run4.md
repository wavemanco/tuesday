I'll read the reference files the skill points to before building the assessment.
Research is done (one page fetch, one search), so here is the full read.

## Decision snapshot

**Yes, it's worth applying. R3, R4, R5, R6, R7 and R8 (the `must_have` rows) are all `direct`. The open items are two checks only you can answer, R1 and R2. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote (US) or our Denver office), R2 (Salary $148,000–$166,000 plus equity)
- `must_have`: direct: R3, R4, R5, R6, R7, R8
- `important`: adjacent: R9 (BigQuery warehouse); unclear: R10 (Ingestion from our app and CRM), R11 (data contracts our analysts depend on)

R9 (`medium`): a credible Snowflake-to-BigQuery bridge, its limit named; R10 and R11: no evidence yet, recoverable by a question.

**Opportunity ledger.** The pay is stated and sits at or above the band you were sent (RR1). The employer matches its own pages and the posting is live (RR5). Scope, equity terms and success measures are unstated (RR2, RR3, RR4). The funding figure rests on the company's own page (RR6).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or our Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your location and your pay floor clear R1 and R2; (2) R9 is framed as adjacent, never as BigQuery experience; (3) the scope and on-call questions in RR2 come back reasonable.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 US states, founded 2016 in Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` company About page, as returned by search |
| Posting status | Live ("Accepting applications"); the fetched text matches what you pasted | `[grounded]` careers page fetched |
| Mandate | Build and run the pipelines behind tutoring-platform reporting: app and CRM ingestion, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` JD |
| Terms | $148,000–$166,000 plus equity; Remote (US) or Denver | `[grounded]` JD |
| Scope read | The JD names no team, manager or reports. "Build and run" reads as end-to-end ownership of these pipelines, probably one domain, and likely a small data team | `[inferred]` from the JD's silence on team and its "build and run" wording |
| Market calibration | The band is for Senior DE at Series B–D companies. Median base $151,000, IQR $139,000–$163,500, n=2,310. The posting's range runs from just under the median to above the IQR's top. The report says "Senior" typically means 5–8 years and one domain with no reports, and this posting's 5+ years sits at the low end of that. The band is a pattern, not this employer's offer | `[grounded]` posting figures and the figures in the report you pasted; `[generic]` that the band applies to this employer |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Unknowns | Hiring manager, team size and reporting line, on-call expectation, equity type and size, interview stages, success measures | `[grounded]` JD silent on each |
| Contradictions | None between the pasted JD and the fetched careers page | `[grounded]` careers page fetched |

## Evidence map

Your background is typed prose, with no CV or artifacts, so every claim sits at the intake ceiling of `medium`.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or our Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you are or what you'll accept, so the gate is unsettled | `[grounded]` JD; your constraints not given | Question G1 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | The pay is stated, but your floor wasn't given. Nothing here says it fails | `[grounded]` JD; your floor not given | Question G1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years of data engineering at a B2B payroll company. This is prose self-report with no document yet | `[grounded]` your intake message | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You state daily use of both. "Strong" is unproven beyond your statement, and an interviewer will probe the level | `[grounded]` your intake message; `[generic]` that interviews probe depth | none |
| R5 | dbt | must_have | direct | medium | none | You built the dbt project, about 180 models, on Snowflake. Confirmed, but no inspectable artifact yet | `[grounded]` your intake message | Offer: a sanitized dbt docs page or project tree would raise it to `high` |
| R6 | A cloud warehouse | must_have | direct | medium | none | The JD asks for "a cloud warehouse" generically, and Snowflake is one. BigQuery appears only in the role description, so it is carried at R9 | `[grounded]` JD wording and your Snowflake statement | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | You state Airflow for orchestration. What you owned (authoring DAGs versus operating them) and the scale are unstated | `[grounded]` your intake message | Be ready to say what you personally built |
| R8 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite, which is a stated ownership claim. Coverage and enforcement are unstated | `[grounded]` your intake message | Offer: a sanitized suite config or check list would raise it to `high` |
| R9 | A dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | Snowflake and BigQuery are both cloud warehouses queried in SQL, so your dbt and modelling work carries over. The limit: you have never used BigQuery, so its partitioning, clustering, cost model and dbt adapter specifics are unexercised | `[grounded]` JD and your statement; `[generic]` on what differs between the two warehouses | Gap G4 |
| R10 | Ingestion from our app and CRM | important | unclear | none | discovery | You haven't described ingestion work. The payroll role plausibly involved some, but that is a lead, not evidence | `[grounded]` your intake is silent | Question G2 |
| R11 | Data contracts our analysts depend on | important | unclear | none | discovery | You haven't described contracts or agreements with downstream users. Your GE suite may be adjacent, but that is unconfirmed | `[grounded]` your intake is silent | Question G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and pay floor (R1, R2) | hard_gate | The JD allows remote (US) or Denver and pays $148,000–$166,000. Your location and floor are unknown | A gate cannot be settled by wording, and only your answer closes it | n/a, these are your own terms | none needed | `[grounded]` JD; your constraints not given |
| G2 | Ingestion from app and CRM (R10, important) | discovery | The intake describes dbt, Airflow and GE work, but not how data got into the warehouse | The JD names ingestion first in its responsibilities, so silence leaves an important row empty | Loading product-database or event data into Snowflake; syncing a CRM or billing system; managed connectors or custom Python loaders; handling schema drift or backfills | A sanitized DAG listing or a pipeline diagram | `[grounded]` intake silence; `[generic]` that this is a core part of the role family |
| G3 | Data contracts (R11, important) | discovery | A GE suite exists, but nothing says it was agreed with or enforced for analysts | The JD names contracts as something analysts depend on, and a candidate who has worked this way can say so concretely | Agreeing column definitions or freshness expectations with analysts; failing a pipeline on a test; naming owners per model; versioning schema changes | The GE suite config, a dbt tests file, or a model owners list | `[grounded]` intake silence; `[inferred]` that your GE work may touch it |
| G4 | BigQuery (R9, important) | transferability | Adjacent evidence: about 180 dbt models and warehouse modelling on Snowflake. Limit: no BigQuery use, so none of its specifics | It is the one named tool you lack, and it is the likeliest probe in an interview | Bridge case: your dbt and SQL transfer, and the limit gets stated up front. Strengthener: a small dbt-on-BigQuery project, which would close part of the limit only once it is real | A public repo or write-up of the practice project | `[inferred]` bridge from your Snowflake work; `[generic]` that the warehouse-specific features differ |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay stated and in band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range is transparent and sits at or above the median of the report you were sent | `[grounded]` posting and pasted report figures; `[generic]` that the report's band maps to this employer | Where in the range does this role land, and what drives it? | noted |
| RR2 | Scope, team and on-call unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | You may be the only data engineer carrying both build and run, or this may be one domain with a team around it | `[inferred]` from the JD's silence on team and reporting line; `[generic]` that "run" often includes operational duty | Who is on the data team, who would I report to, and what is the on-call expectation? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "plus equity" | The type, size, vesting and valuation may materially change the offer's value | `[grounded]` JD gives no terms | What is the equity grant: type, size, vesting, and the valuation it is priced at? | unresolved |
| RR4 | Success measures unstated | unknown | — | "the data contracts our analysts depend on" | Without outcomes, accountability for analysts' dependence on you could be open-ended | `[inferred]` from the JD listing duties and no first-year outcomes | What would success look like at 90 days and at a year? | unresolved |
| RR5 | Employer attributable and posting live | positive_signal | — | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states. Founded 2016, Denver. 264 employees." | The company exists as described on its own pages, and the posting is consistent and open | `[grounded]` About page and careers page | What are the interview stages, and who would I meet? | noted |
| RR6 | Funding rests on the company's own page | unknown | — | "Series C ($52M, February 2026)" | The figure is the company's own statement and wasn't independently corroborated in this pass | `[grounded]` About page only | What is the hiring plan for the data team over the next year? | unresolved |

## Application plan

Every row is proposed, none applied. There is no CV in hand, so the baseline is your own sentences.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check R1 and R2 against your own location and pay floor before spending effort | Gates are yours to settle | `[grounded]` R1, R2 rows | pending your approval |
| P1 | Lead the application with dbt (about 180 models), Airflow and the Great Expectations suite, since R5, R7 and R8 are the rows most directly asked for | These rows are `direct` and the JD names them | `[grounded]` R5, R7, R8 rows | pending your approval |
| P2 | Say plainly in the application that your warehouse experience is Snowflake and you haven't used BigQuery yet, then name the dbt and SQL work that carries over | Stating the limit yourself reads stronger than being asked | `[inferred]` from R9's limit; `[generic]` that interviews probe tool gaps | pending your approval |
| W1 | A small practice project: a handful of dbt models on BigQuery with tests. You may describe it as a practice project only once it exists | The one named tool you lack (R9, G4) | `[inferred]` strengthener for R9 | pending your approval |
| Q1 | Ask RR2, RR3 and RR4's questions verbatim with the recruiter or in the loop | They are your interview preparation | `[grounded]` register | pending your approval |

Proposed resume lines, each traced to your own sentence.

| # | Your sentence | Proposed line | Status |
|---|---|---|---|
| E1 | "Built our dbt project on Snowflake — about 180 models." | "Built the dbt project on Snowflake (about 180 models)." | resume_edits_pending_approval |
| E2 | "I set up our Great Expectations test suite." | "Set up the Great Expectations data quality test suite." | resume_edits_pending_approval |
| E3 | "Airflow for orchestration." | "Used Airflow for orchestration." (it doesn't claim designing or owning the DAGs, since you haven't said) | resume_edits_pending_approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer). Searched "Pellucid Learning online tutoring K-12 Denver Series C", which returned "About Pellucid Learning" (pellucidlearning.com/about). Role reality's organization, posting-status and contradictions rows, and RR5 and RR6. The funding figure was not corroborated outside the company's own page |
| 2. Role-family sweep | skipped | The pasted pay-report figures and its scope norms already fix the market calibration and RR1, so a search could not change them |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there is no query to form |

I can save all of this as `tuesday-dossier.md` if you want to keep it or reuse it.

**Upgrade menu**

- Your location and pay floor → R1 and R2 close, and the decision likely moves to `go`.
- A CV → the fit rows can be graded against a document, and the resume lines can be written against what it says.
- A sanitized dbt docs page, project tree, GE suite config or Airflow DAG listing → R5, R7 and R8 can move from `medium` to `high`.
- The hiring manager's name → the scope read and which of your stories to lead with.
- A deeper research pass on Pellucid (funding corroboration, leadership churn, public employee reports, recent news; up to 5 more searches and 2 more fetches) → RR6 and RR2 sharpen. Say the word and it runs.

**Questions**

G1 — Are you in the US and fine with remote or Denver, and does $148,000–$166,000 clear your minimum base?
G2 — Have you owned moving data from an application database, event stream or CRM-type system into your warehouse? If so, what did you build, and what broke?
G3 — Did you ever agree table definitions, freshness or test rules with the analysts who used your data, and who decided what the Great Expectations suite checked?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.