Web search was denied, so this assessment runs on what you pasted.

# Job underwriting: Senior Product Analyst, Harborlight Health

## Decision snapshot

**Yes, apply. You're a strong fit on the core of the job. Status: `conditional_go`.**

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4, R6
- `important`: direct: R7a · unclear: R5 (metrics layer), R7b (clinicians), R8 (mentor two junior analysts)
- `preferred`: adjacent: R9 (healthcare data experience, HIPAA)

R9 is a credible bridge with its limit named; R5, R7b, R8 are unconfirmed and each waits on your answer.

**Opportunity ledger.** The role's duties are concrete and it comes with named reports (RR4). Three things are not established: the employer itself (RR1), the pay (RR2) and the work arrangement (RR3).

- **Hard gates:** none stated; candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Harborlight and the live posting verify on its own careers site (RR1); (2) pay and location or work arrangement are acceptable to you (RR2, RR3); (3) your metrics-layer work is confirmed as real, specific experience (R5).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up of about 400 people at Series C, with a care-navigation app | `[grounded]` JD header. Not independently checked (see RR1). |
| Mandate | Own product analytics for the app: metrics layer, A/B tests, self-serve Looker dashboards, roadmap partnership with PMs and clinicians, and mentoring two junior analysts | `[grounded]` JD |
| First-year outcomes | Not stated | `[grounded]` the JD gives none |
| Scope read | An experienced individual-contributor post with light people-leadership: two named mentees, no stated headcount or management title | `[inferred]` from "mentor two junior analysts" against the title and the silence on line management |
| Compensation | Not stated, and your pay floor wasn't given, so the pay-fit check is open. The posting withholds the figure, which is worth a question (RR2) | `[grounded]` the JD is silent |
| Market calibration | Not established. Both searches were refused, so no pay band is shown rather than one from memory | `[grounded]` the searches were refused |
| Unknowns | Pay; location or remote policy; first-year outcomes; who owns the metrics layer today; how much clinician input shapes the roadmap | `[grounded]` the JD is silent on each |
| Contradictions | None between the JD and your background. A JD-versus-careers-page check could not run | `[grounded]` no second source in hand |

## Evidence map

Your background is typed prose, which has the same standing as a CV: leads for verification, not proof. No row can exceed `medium` until you give me something inspectable.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years of product analytics at a ~2M-subscriber meal-kit company clears the stated minimum. Confirmed in your words, with nothing inspectable yet | `[grounded]` your stated background | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake across six years supports "expert". The level is self-assessed. Technical screens for this title usually test SQL live | `[grounded]` your stated background; `[generic]` on screening practice | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | You designed and ran the program, with 30+ tests a year and the pricing test behind an 11% retention lift. Expect a probe on your share of the credit for that lift and on sample sizes and power. "At scale" is met in user numbers, but test-level detail is unconfirmed | `[grounded]` your stated background; `[generic]` on interview probing | Optional: a sanitized test-readout or experiment-framework doc would raise this to `high` |
| R4 | Looker or a similar BI tool | must_have | direct | medium | none | You built the Looker instance from scratch, with 40+ governed dashboards | `[grounded]` your stated background | A screenshot of a sanitized dashboard would raise this to `high` |
| R5 | Define and maintain the metrics layer | important | unclear | low | discovery | Governed dashboards and a monthly metrics memo are near neighbours. You haven't said you owned metric definitions, a semantic layer or LookML models, so I don't assert it | `[inferred]` from the governed-dashboards claim; nothing stated on metric definitions | Question G1 |
| R6 | Strong written communication with non-technical stakeholders | must_have | direct | medium | presentation | The monthly exec-team memo and monthly VP Product presentation match this closely. You didn't offer the memo as an artifact, and showing one would lift it | `[grounded]` your stated background | Offer: a sanitized memo excerpt would raise this to `high` |
| R7a | Partner with product managers to turn analysis into roadmap decisions | important | direct | medium | none | Monthly presentation to the VP Product and the pricing test that changed a retention outcome both fit. A specific roadmap decision traced to your analysis isn't named | `[grounded]` your stated background | none |
| R7b | Partner with clinicians | important | unclear | none | discovery | Nothing in your background mentions clinicians or other domain experts as stakeholders | `[grounded]` background silent | Fold into G2 only if relevant. Not asked separately |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | You didn't mention mentoring, onboarding or managing analysts. It may exist and be unmentioned | `[grounded]` background silent | Question G2 |
| R9 | Healthcare data experience (HIPAA), "a plus" | preferred | adjacent | medium | transferability | You handled GDPR and CCPA consumer PII and built the warehouse consent-state model. Limit: this is not healthcare data. It did not exercise PHI handling, HIPAA's minimum-necessary or de-identification rules, or business-associate arrangements. It's preferred, so a gap here is an interview risk and not a barrier | `[grounded]` your stated work; `[generic]` on what HIPAA-regulated work involves | See G3. Frame as adjacent, never as HIPAA experience |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R5, important) | discovery | Governed dashboards and an exec metrics memo, but no statement that you defined or maintained the metric definitions | This is the first responsibility the JD lists. Confirming it would turn R5 from `unclear` to a strong row | Writing the canonical definition of retention, churn or active subscriber; maintaining LookML models or a dbt layer; ending metric disputes between teams; versioning a metric after a change | LookML or dbt snippets, a metric-definition doc, a data dictionary | `[grounded]` background silent on definitions; `[inferred]` that confirmation lifts the row |
| G2 | Mentoring (R8, important) | discovery | No mention of mentoring | The role names two junior analysts. Even informal mentoring is relevant | Onboarding new analysts; reviewing others' SQL or experiment designs; running office hours; coaching a peer into a promotion | A mentoring plan, a review checklist, or a named mentee outcome | `[grounded]` background silent |
| G3 | Healthcare data (R9, preferred) | transferability | A consent-state model and GDPR/CCPA handling | Your strongest honest bridge to HIPAA-adjacent work. The limit is that it isn't healthcare data | Access controls, de-identification, retention rules, audits or DPIAs on the consent model | A sanitized consent-model diagram or design doc | `[grounded]` your stated work; `[generic]` on what HIPAA work involves |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "digital-health scale-up, ~400 people, Series C" | I couldn't check the employer because both searches were refused. Possible reasons, none more likely than another: it checks out as described; the posting is stale or aggregated; it isn't a real hiring employer | `[generic]` pattern, not a claim about this company | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay withheld, floor not given | unknown | — | none (the JD states no pay) | The figure may fall below or within your expectations, or the company may simply not publish it | `[generic]` pattern for postings that withhold pay | What salary range is budgeted for this role? | unresolved |
| RR3 | Location and work arrangement unstated | unknown | — | none (the JD names no location or remote policy) | It may conflict with a constraint you have but haven't stated | `[grounded]` the JD is silent | Where is this role based, and what are the in-office expectations? | unresolved |
| RR4 | Concrete responsibilities and a named team | positive_signal | — | "mentor two junior analysts" | The scope is specific, with named duties, a named team and a named BI tool | `[grounded]` JD states each | Who owns the metrics layer today, and what shape is it in? | noted |

## Application plan

Every row below is a proposal. Nothing is final CV or outreach language until you approve it, and that covers the prose advice as well as the table.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Verify Harborlight and the live posting on its own careers site before spending application effort | RR1 | `[grounded]` RR1 | pending your approval |
| E1 | Lead the CV with the experimentation program (30+ tests a year, the pricing test) and the Looker build, since these hit R3 and R4 directly | R3, R4 | `[grounded]` your stated background | pending your approval |
| E2 | Name the consent-state model and the GDPR/CCPA work as "adjacent privacy and consent experience", never as healthcare or HIPAA experience | R9, truthfulness limits | `[grounded]` R9 row | pending your approval |
| E3 | Add metrics-layer or mentoring bullets only if you confirm them (G1, G2) | R5, R8 | `[grounded]` rows R5 and R8 | pending your answer |
| Q1 | Ask RR1, RR2, RR3 and RR4's questions verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Harborlight Health care navigation app careers"; the host refused the call. It would have moved role reality's contradictions row and RR1 |
| 2. Role-family sweep | unavailable | Searched "senior product analyst digital health salary range Looker experimentation"; the host refused the call. It would have moved role reality's market calibration and RR2's pay comparison |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer

If you want a portable record of this assessment, I can write it up as `tuesday-dossier.md`.

## Upgrade menu

- Approving web search → rows 1 and 2 run, which could clear RR1 and give a pay band for RR2.
- A deeper research pass (up to 5 more searches and 2 more fetches) → leadership, funding and hiring patterns for RR1. Say the word and it runs, once search is allowed.
- A sanitized exec metrics memo → R6 to `high`.
- A sanitized dashboard screenshot or test readout → R4 and R3 to `high`.
- LookML or a metric-definition doc → R5 moves from `unclear` to a strong row.
- Your pay floor, location and any other non-negotiables → hard-gate rows for each, so the hard-gates line reflects checks against you. Today it reads that they were not given.
- The hiring manager's name → positioning for that reader.

## Questions

**G1** — Did you personally define or maintain the company's core metric definitions (for example retention or active subscriber), for instance in LookML or a metrics doc? What did you own, and did others rely on it? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**G2** — Have you mentored, onboarded or reviewed the work of other analysts, formally or informally? Who, and what changed for them? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**C1** — What are your non-negotiables on pay floor, location or remote, and anything else that would end the conversation? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.