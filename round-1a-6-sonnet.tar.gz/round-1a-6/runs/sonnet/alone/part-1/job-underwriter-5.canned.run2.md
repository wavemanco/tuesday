I've read the skill's rules. Next I'll check the posting and company against their live pages, then write the assessment.
**Yes, worth applying: `conditional_go`.** R3, R4, R5, R6, R7 and R8 are `direct`. Two hard gates, R1 and R2, are unconfirmed because I don't know your location, work authorization or pay floor.

# Job Underwriting: Senior Data Engineer, Pellucid Learning

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver office), R2 (Pay $148,000–$166,000 against your floor)
- `must_have`: direct: R3, R4, R5, R6, R7, R8
- `important`: adjacent: R9 (BigQuery); unclear: R10 (Ingestion from app and CRM), R11 (Data contracts)

R9 (`medium`): a credible bridge, its limit named; R10, R11: not yet asked, which is not the same as absent.

**Opportunity ledger.** Pay is stated and the funding stage is named (RR2, RR6). The unknowns are team structure and first-year outcomes (RR1), equity terms (RR3), whether BigQuery is expected at hire (RR4) and who has authority over data contracts (RR5).

- **Hard gates:** none failed (R1, R2); unconfirmed: R1 (Remote US or Denver office), R2 (Pay $148,000–$166,000 against your floor); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 is met: you can work remote from the US or from Denver, with the authorization that needs. (2) The range clears your own pay floor (R2). (3) BigQuery is framed as adjacent, never as experience you have (R9, RR4).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` company's own about page, fetched via search. The funding figure is the company's own statement, not independently checked. |
| Mandate | Pipelines behind the platform's reporting: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD, matched on the live careers page |
| Requirements | 5+ years data engineering; SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Compensation | $148,000–$166,000 plus equity; equity terms not stated | `[grounded]` JD |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Scope read | Ownership of reporting pipelines and the contracts analysts consume; team size, reporting line and decision rights are not stated | `[inferred]` from the mandate wording against the JD's silence |
| Market calibration | The posting's range runs from just under the report's median ($151,000) to above its upper quartile ($163,500). The report's typical scope is one domain's pipelines with no direct reports, which fits this mandate as written. I'm treating "salary" as base pay. | `[generic]` Datawright 2026 report, Senior Data Engineer at Series B–D, n=2,310, supplied by your recruiter; `[grounded]` JD for the posting's figure; `[inferred]` that the figure is base |
| Unknowns | Hiring manager (none named), data team size, equity terms, who owns upstream schema changes, whether BigQuery experience is expected at hire | `[grounded]` JD and careers page name none of these |
| Contradictions | None found between what you pasted and the live pages | `[grounded]` careers page fetched, about page via search |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location and work authorization were not given, so whether the term is met is not established. Confidence is `none` because there is no statement of yours to grade. | `[grounded]` JD term; no candidate statement | Q on G1 |
| R2 | Pay $148,000–$166,000 plus equity, against your floor | hard_gate | unclear | none | hard_gate | No pay floor was given. The range sits above the report median, so a clash is less likely than not, but that is a reading, not a check. | `[grounded]` JD range; `[generic]` report band; no candidate statement | Q on G2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years at a B2B payroll company. Stated in prose, so `medium` until inspected: expect a probe. Six years falls inside the report's 5–8 range for "Senior". | `[grounded]` your stated background; `[generic]` report's seniority range | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You state daily use of both. A claim of "strong" has no artifact behind it yet. | `[grounded]` your stated background | A sanitized query or repo excerpt would raise this to `high` |
| R5 | dbt | must_have | direct | medium | none | You built the project, about 180 models on Snowflake. Your own count, not yet inspected. | `[grounded]` your stated background | A dbt docs screenshot or lineage graph would raise this to `high` |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse, and the JD asks for "a cloud warehouse" without naming one. BigQuery is a separate row (R9). | `[grounded]` JD wording; your stated background | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | You state Airflow was your orchestrator. Scale and ownership are not yet stated. | `[grounded]` your stated background | none |
| R8 | Experience with data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite. The coverage and what it caught are not yet stated. | `[grounded]` your stated background | A sanitized suite config or data-docs page would raise this to `high` |
| R9 | BigQuery, named in the mandate ("a dbt-modelled warehouse in BigQuery") | important | adjacent | medium | transferability | Adjacent evidence is Snowflake plus dbt. The limit is that you have never used BigQuery, so its cost model and dialect differences are unexercised. The JD asks only for "a cloud warehouse", so this is not a listed requirement. | `[grounded]` your statement and the JD wording; `[inferred]` that the transfer is credible | A small BigQuery project (W1) narrows the limit |
| R10 | Ingestion from the app and CRM | important | unclear | none | discovery | Your background doesn't mention how data entered your pipelines. This is a discovery gap, not a finding of absence. | `[grounded]` JD; your background silent | Q on G4 |
| R11 | Data contracts analysts depend on | important | unclear | none | discovery | Your background doesn't mention formal contracts or schema agreements. Your test suite may be adjacent, which I won't assume. | `[grounded]` JD; your background silent | G5, not asked this turn (question budget) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and authorization (R1, hard_gate) | hard_gate | The posting allows remote US or Denver. Where you'd work from is not given. | A failed gate would force `no_go` however strong the fit | Your state of residence and whether you can work in the US without sponsorship | None needed; your own statement | `[grounded]` JD term, no candidate statement |
| G2 | Pay floor (R2, hard_gate) | hard_gate | Range $148,000–$166,000 plus equity; your minimum isn't known | The one term that could still turn a good fit into a poor offer | Your minimum base, and how you'd value the equity | None needed | `[grounded]` JD; no candidate statement |
| G3 | BigQuery (R9, important) | transferability | Snowflake plus dbt, no BigQuery use | The mandate names it, so an interviewer is likely to ask | Reading BigQuery documentation, a dbt-bigquery sandbox project, any BigQuery exposure at a prior employer | A small public repo or a sanitized write-up | `[inferred]` bridge from Snowflake and dbt; `[generic]` that a named stack tool draws questions |
| G4 | Ingestion from app and CRM (R10, important) | discovery | Nothing about your ingestion sources | It is the first responsibility the JD lists | Loading from application databases, CRM or SaaS APIs, CDC or file drops, and who owned the loaders | A pipeline diagram or an ingestion DAG screenshot | `[grounded]` JD and your background silent; `[generic]` that reporting pipelines start from ingestion |
| G5 | Data contracts (R11, important) | discovery | Nothing about schema agreements with producers or consumers | The JD names the contracts as something analysts depend on | Agreed schemas with upstream teams, breaking-change processes, test suites that gated releases | A contract doc or a sanitized schema-change process | `[grounded]` JD and your background silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Team shape and first-year outcomes unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | You may be the sole data engineer, or one of a team. Success measures are not defined in the posting. | `[inferred]` from the JD's silence on both | How large is the data team, who does this role report to, and what should be delivered in the first year? | unresolved |
| RR2 | Pay stated, in the upper part of the market band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | Transparent pay, with a floor just under the report's median and a ceiling above its upper quartile | `[grounded]` JD; `[generic]` report band | Where in the range would you expect to hire for someone with my background? | noted |
| RR3 | Equity terms unstated | unknown | — | "plus equity" | The equity may be a meaningful or a token part of the package | `[inferred]` from the JD naming equity and giving no terms | What is the equity grant, vesting schedule and strike or valuation basis? | unresolved |
| RR4 | BigQuery named in the mandate but not in the requirements | unknown | — | "a dbt-modelled warehouse in BigQuery" against "dbt and a cloud warehouse" | The team may treat BigQuery as learnable on the job, or may screen for it | `[inferred]` from the mismatch between mandate and requirement wording | Is BigQuery experience expected at hire, or is a ramp-up from another warehouse planned for? | unresolved |
| RR5 | Contract ownership against decision rights | unknown | — | "the data contracts our analysts depend on" | The role may define contracts without authority over the application changes that break them | `[inferred]` from the JD's responsibility wording against its silence on authority | When the app team changes a schema, who decides and who is notified? | unresolved |
| RR6 | Funded growth-stage company | positive_signal | — | "Series C ($52M, February 2026)" | Funding stage matches the report's Series B–D cohort. The figure is the company's own and has not been checked independently. | `[grounded]` company about page; `[generic]` report cohort | Where does the data team sit in the company's current priorities? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with the dbt project in your own terms: built the dbt project, about 180 models, on Snowflake | See R5; `medium` confidence, so expect a probe | `[grounded]` your stated background | pending your approval |
| E2 | Give data quality testing its own line: set up the Great Expectations test suite | See R8 | `[grounded]` your stated background | pending your approval |
| W1 | A small BigQuery sandbox project modelled in dbt, described as a learning project and never as production work | See R9; narrows the limit on the bridge | `[inferred]` from the R9 gap | pending your approval |
| A1 | State openly in any cover note that BigQuery is new to you and that Snowflake plus dbt is the transferable base | See R9, RR4; adjacent work is not BigQuery experience | `[grounded]` R9 row | pending your approval |
| A2 | Ask RR1, RR3, RR4 and RR5 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A3 | Settle R1 and R2 before spending time on the loop | See G1, G2 | `[grounded]` R1, R2 rows | pending your approval |

## Evidence status

Verified: none yet. Everything about your background is self-reported prose. Rows R3–R8 sit at `medium`, the ceiling for unprobed material.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning online tutoring K-12 Denver Series C", which returned "About Pellucid Learning" (pellucidlearning.com/about). Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer). The posting is live ("Accepting applications") and matches your pasted text, and the about page matches the company description. It moved role reality's organization and contradictions rows. The employer is established from its own pages, so no failed-attribution entry was raised. |
| 2. Role-family sweep | skipped | Your pasted Datawright report already fixes the market calibration line and the pay comparison in R2 and RR2, so a search could not change them. |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there was no query to form. |

## Closing

I can emit this as `tuesday-dossier.md` whenever you want a file to carry forward.

**Upgrade menu**

- Your location, work authorization and pay floor → R1 and R2 move from `unclear` to `direct` or `hard_gate_fail`, and the decision settles.
- A CV or LinkedIn export → R3–R8 are checked against the document, and E1 and E2 become specific edits.
- A sanitized dbt docs page or lineage graph, an Airflow DAG screenshot, or a Great Expectations data-docs page → R5, R7 or R8 can rise to `high`.
- An answer on ingestion → R10 resolves, and R11 follows when you're ready for it.
- The hiring manager's name, once known → role reality's scope read and which of your stories to lead with.
- A deeper research pass on Pellucid Learning (independent funding check, leadership changes, hiring patterns, public employee reports, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

G1 — Where would you work from, and do you have US work authorization without sponsorship?
G2 — What is the minimum base salary at which this role is worth taking?
G4 — In your payroll role, what data did your pipelines pull in, from where, and who built and ran those loaders?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.