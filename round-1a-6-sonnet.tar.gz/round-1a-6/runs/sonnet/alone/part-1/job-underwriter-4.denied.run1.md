I'll read the reference files the skill points to before building the assessment.
**Yes, apply. You have direct evidence on R2, R3, R4, R5, R6 and R7, the must-have rows. The JD lists no people-management requirement, so never having managed anyone isn't a gap. Status: `conditional_go`.** Two things hold it at conditional: I couldn't establish the employer (RR1), and nothing you've given me settles the UK location gate (R1).

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote, UK)
- `must_have` — direct: R2, R3, R4, R5, R6, R7
- `important` — adjacent: R9 (Pet-insurance product domain) · unclear: R8 (Recommendations to product)
- `preferred` — direct: R10

R4 (`medium`) — specific and confirmed, no artifact inspected yet; R9 — a credible bridge from motor, its limit named; R8 — nothing in hand on product recommendations; R1 — nothing in hand settles UK location.

**Opportunity ledger.** Unverified rather than bad. The employer couldn't be checked (RR1), pay and team shape are unstated (RR2, RR3), and no first-year outcomes are given (RR4). RR5 runs the other way: the requirement list is specific and matches your work.

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting verifies on Brindlemoor's own careers page — RR1; (2) you confirm UK base and right to work — R1; (3) the pet gap is framed as adjacent, never as pet expertise — R9.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech, with a pet-insurance product; the entity is not verified | `[grounded]` JD header; research unavailable (see Evidence status) |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing; public footprint not researched | `[grounded]` as given |
| Scope read | An individual-contributor senior post. The JD states no direct reports, team size or management duty, so "never managed anyone" touches no stated requirement. Whether you'd be the only pricing analyst on the product is unknown | `[inferred]` from the JD's silence on reports against its list of analytical duties |
| First-year outcomes | Not stated. Likely candidates are taking over rating-model monitoring and running a price-test programme | `[inferred]` from the JD's "build and monitor rating models" and "design and read price tests" |
| Market calibration | Not run; no pay band is offered, and I won't give one from memory | `[grounded]` search refused |
| Unknowns | Salary; team size and reporting line; success measures; data and tooling; whether it's a new build or an inherited model | `[grounded]` JD is silent on each |
| Contradictions | None between the JD and what you told me; JD against careers page not checked | `[grounded]` inputs compared |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK | hard_gate | unclear | low | hard_gate | No statement from you on UK residence or right to work. Working at a UK insurer suggests it but doesn't establish it | `[inferred]` from "UK motor insurer"; your constraints not given | Gate question in the closing block |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years of pricing analytics against 4+. No CV in hand, so dates are unchecked | `[grounded]` your background summary | Share your CV to check dates |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Daily" use is confirmed. "Strong" is your own assessment, with nothing inspectable yet | `[grounded]` your summary | A sanitised notebook or query sample would raise to `high` |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. Limit: one motor book | `[grounded]` your summary | A sanitised model spec or factor-selection note would raise to `high` |
| R5 | Build and monitor rating models | must_have | direct | medium | none | "Built and maintained" is confirmed. Monitoring is inferred from "maintained", so what monitoring you ran isn't stated | `[grounded]` build; `[inferred]` monitoring, from "maintained" | Tell me which monitoring you ran before it goes on the CV |
| R6 | Design and read price tests | must_have | direct | medium | none | You ran 14 price tests last year with underwriting. "Ran" doesn't say how much of design versus readout was yours; separate those out for interviews | `[grounded]` your summary | Be ready to say what was yours in test design, and what in the readout |
| R7 | Present to underwriting or actuarial leads; recommendations for underwriting | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your summary | A sanitised review deck excerpt would raise to `high` |
| R8 | Recommendations for product | important | unclear | low | discovery | Your summary covers underwriting only; nothing says you've fed product or proposition decisions | `[grounded]` your summary's silence | See G2 |
| R9 | Pet-insurance product domain | important | adjacent | medium | transferability | You've never worked on pet. The GLM, test and review skills carry over; pet-specific rating factors and claims behaviour were not exercised. Pet rating typically uses factors such as species, breed and age and has to track vet-cost inflation | `[grounded]` your statement; `[inferred]` requirement, since the JD asks for pet only by naming the product; `[generic]` pet rating pattern | See G1 |
| R10 | Insurance experience (plus) | preferred | direct | medium | none | 5 years at a UK motor insurer | `[grounded]` your summary | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance domain (R9, important) | transferability | Motor GLM, tests and reviews; no pet exposure | R9 is the most visible difference between you and the posting | Frequency and severity modelled separately; claim-cost inflation trend in a rating review; renewal-price tests; any non-motor or add-on cover you priced | A sanitised model summary or review excerpt | `[grounded]` your statement; `[generic]` that this is the likeliest objection for a motor-to-pet move |
| G2 | Recommendations to product (R8, important) | discovery | The review goes to underwriting; no product link is stated | Resolving it could move R8 to `direct` and sharpens how you present R7 | A test result that changed a cover, excess or add-on; a review item taken up by a product or proposition team; work with a product owner | A review slide or test readout showing the decision it led to | `[grounded]` your summary's silence |
| G3 | UK location and right to work (R1, hard_gate) | hard_gate | Not stated | The only gate; unconfirmed, so it stays on the snapshot until you say | n/a — a term, not experience | n/a | `[grounded]` your summary's silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. My searches were refused, so this is not a finding about the company | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Salary not stated | unknown | — | no figure in the JD as given | The pay may sit above or below your floor; I can't set it against a band without the sweep | `[grounded]` JD silent; band not available | What salary range is budgeted for this post? | unresolved |
| RR3 | Team shape and resources unstated against "own" | unknown | — | "Own pricing analytics for our pet-insurance product" | You may be the sole analyst on the product, with responsibility unmatched by data, tooling or decision rights | `[inferred]` from "own" against the JD's silence on team and authority | Is this a team of one, who does the role report to, and what data and tooling exist for pet pricing? | unresolved |
| RR4 | No first-year outcomes | unknown | — | the JD lists duties, no outcomes | Success may be undefined for a post that "owns" the area | `[inferred]` from the duty-only wording | What would a good first year look like for this role? | unresolved |
| RR5 | Specific, coherent requirement list with a named Director of Pricing as hiring manager | positive_signal | — | "build and monitor rating models, design and read price tests, and turn the results into recommendations for underwriting and product" | The scope reads as a defined pricing-analytics job rather than a bundled one | `[inferred]` from the JD's internal consistency | Which decisions will the first price test I run feed? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Proposed CV line: "Built and maintained the GLM rating model for the young-driver book. Ran 14 price tests with the underwriting team in [year]. Present the quarterly pricing review to the head of underwriting." Every clause comes from your sentences; add the year yourself | See R4, R6, R7 | `[grounded]` your summary | `resume_edits_pending_approval` |
| P1 | Positioning order: lead with the GLM model, then the price-test programme, then the review you present to underwriting | The JD's own order is rating models, tests, recommendations | `[grounded]` JD order against your summary | pending your approval |
| P2 | Proposed note for the pet gap: "My rating-model work has been in motor rather than pet insurance; the GLM and price-test work is what I'd bring." It claims nothing beyond what you said | See R9 | `[grounded]` your statement | pending your approval |
| A1 | Find the role on Brindlemoor's own careers page before putting in serious effort | See RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask the RR1 to RR4 verification questions verbatim in the screen | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none. Rejected inferences: none. R5's monitoring and R6's design-versus-readout split are the two claims to firm up first.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Brindlemoor pet insurance insurtech" and "Brindlemoor careers Senior Pricing Analyst"; search permission wasn't granted, so both were refused. It would have moved role reality's organization row and RR1 |
| 2. Role-family sweep | unavailable | Searched "senior pricing analyst pet insurance UK salary remote"; refused. It would have moved market calibration and the pay check in RR2 |
| 3. Hiring manager's public footprint | unavailable | Searched "Odile Varga Director of Pricing"; refused. It would have moved the scope read and P1's positioning |

## Dossier offer

If you want a saved record of this assessment, I can write it up as `tuesday-dossier.md`.

## Upgrade menu

- Search permission granted → rerun targets 1–3: RR1 clears or hardens, market calibration returns, and the Odile Varga footprint feeds P1. A deeper pass could follow later (up to 5 more searches and 2 more fetches).
- Your CV → E1 checked against your actual wording, and R2's dates confirmed.
- A sanitised notebook, model spec or review-deck excerpt → R3, R4 and R7 toward `high`.
- Your pay floor, or the posted salary → RR2 closes against your floor.
- Answers to G1 and G2 → R9's bridge firms up and R8 resolves.

## Questions

R1 — Are you based in the UK, and do you have the right to work there without sponsorship?

G1 — Have you priced anything outside motor, or modelled claim-cost trend or renewal pricing in a way you could point to? What was yours, and what happened?

G2 — Has a price-test result or a pricing-review item ever changed a product, cover or excess decision? Who took it up, and what did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.