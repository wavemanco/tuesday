I'll read the reference files the skill points to before building the assessment.
**Yes, apply. R2, R3, R4, R5, R6, R7a and R8 are `direct` must-haves, and not having worked on pet insurance (R10) or managed anyone doesn't block you. Status: `conditional_go`.** The conditions are below. I couldn't check Brindlemoor itself, so it comes with a verify-first step.

# Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (UK-based, fully remote working)
- `must_have` — direct: R2, R3, R4, R5, R6, R7a, R8 · unclear: R7b (Recommendations for product)
- `preferred` — direct: R9 · adjacent: R10 (Pet-insurance domain knowledge)

R10 — a credible bridge from motor, its limit named; R7b — no product-facing evidence yet; R5 (`medium`) — tests run is confirmed, your design role is not.

**Opportunity ledger.** The employer is unverified (RR1), pay is unstated (RR2), and the team and sign-off authority are unstated (RR3). The posting names concrete deliverables (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (UK-based, fully remote working); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting verifies as live on Brindlemoor's own careers page, see RR1; (2) you confirm UK location and right to work, see R1; (3) the pay range clears your floor, see RR2 (you haven't told me your floor); (4) the product-recommendations gap is closed by an example or framed honestly, see R7b.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, described as an insurtech with a pet-insurance product; existence and posting not independently verified | `[grounded]` JD header as you pasted it |
| Hiring manager | Odile Varga, Director of Pricing; public footprint not researched | `[grounded]` your message |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Direct reports | The JD states none and names no management requirement, so "never managed anyone" touches no stated requirement | `[grounded]` JD silence |
| First-year outcomes | None stated | `[grounded]` JD silence |
| Scope read | Single-product pricing ownership, with the team size and sign-off route not given | `[inferred]` from "Own pricing analytics" against the JD's silence on team |
| Market calibration | Not available: the role-family sweep did not run, so no pay band is offered | `[grounded]` research not run |
| Unknowns | Salary; team size; who signs off rating changes; success measures | `[grounded]` JD silence |
| Contradictions | None between the JD and your background; the careers page was not checked | `[grounded]` inputs compared |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | low | hard_gate | The posting is UK-only remote. You haven't said where you live or your right to work. Your UK employer is indirect context only | `[grounded]` JD quote; `[inferred]` from your UK employer | Ask G1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You state 5 years in pricing analytics at a UK motor insurer, 2 as senior analyst. Self-reported with no document yet. A years requirement is not a gate | `[grounded]` your background statement | none |
| R3 | Build and monitor rating models | must_have | direct | medium | none | You built and maintained the young-driver GLM rating model. "Maintained" is the nearer word to "monitor", so I haven't assumed live-performance tracking | `[grounded]` your background statement | State in the CV what maintaining involved, only if true |
| R4 | GLM experience | must_have | direct | medium | none | Directly stated: the GLM rating model for the young-driver book. No inspectable artifact yet | `[grounded]` your background statement | none |
| R5 | Design and read price tests | must_have | direct | medium | discovery | You ran 14 price tests with underwriting last year. "Ran" does not say whether you designed them or read the results, and ambiguity resolves to the lesser claim | `[grounded]` your background statement | Ask G3 |
| R6 | Strong SQL and Python | must_have | direct | medium | none | Daily use is stated. "Strong" rests on your word with no sample | `[grounded]` your background statement | Optional: a sanitized query or notebook would raise it to `high` |
| R7a | Turn results into recommendations for underwriting | must_have | direct | medium | none | You worked the tests with underwriting and present the quarterly pricing review to the head of underwriting. Whether outputs were framed as recommendations is not stated | `[grounded]` your background statement | none |
| R7b | Turn results into recommendations for product | must_have | unclear | low | discovery | Nothing you've said mentions a product team or product decisions | `[grounded]` silence in your background | Ask G2 |
| R8 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. The JD says "or", so actuarial leads are not required | `[grounded]` your background statement | none |
| R9 | Insurance experience a plus | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your background statement | none |
| R10 | Pet-insurance domain knowledge (inferred requirement) | preferred | adjacent | medium | transferability | The JD names a pet product but asks only for insurance experience, so I tiered this `preferred`. Motor GLM rating carries over as technique. Limit: you haven't priced pet cover, and pet rating factors and claims patterns differ from motor | `[inferred]` from the product named in the JD; `[generic]` that rating factors differ by line | Frame it as adjacent, see E2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | UK location and right to work (R1, hard_gate) | hard_gate | Nothing states your location or work eligibility | A term, not experience: wording can't fix it, and it decides whether the rest matters | Not applicable | Nothing to attach | `[grounded]` inputs silent |
| G2 | Recommendations for product (R7b, must_have) | discovery | Underwriting-facing work is clear. Nothing shows pricing analysis shaping a product decision | The JD names product as an audience, so this is the one must-have with no evidence yet | A test or analysis that changed cover levels, excess, discounts, add-ons or renewal pricing; a pricing view given to a product, proposition or commercial team; a quarterly review item that led to a product change | A sanitized review slide or test readout | `[grounded]` background silent on product; `[generic]` that pricing roles commonly serve product teams |
| G3 | Test design vs test running (R5, must_have) | discovery | 14 tests run is clear. Your part in design and in reading results is not | "Design and read" are the JD's own verbs, and a screener will probe which you owned | Choosing the test and control split; setting duration or sample size; picking the success measure; reading results and flagging adverse selection or risk-mix effects | A sanitized test plan or readout | `[grounded]` the "ran" wording; `[generic]` that test-design ownership is commonly probed |
| G4 | Pet-domain bridge (R10, preferred) | transferability | Motor GLM work is the adjacent evidence. Pet-specific exposure is none | Preferred only, but a named limit reads stronger than a hidden one | Not applicable: no question needed, and the bridge is in E2 | Not applicable | `[inferred]` from R4 and R9 |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. No search result is in hand either way | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Salary not stated | unknown | — | The JD you pasted contains no pay figure | The figure may sit below what a senior analyst expects, or may simply not be published in the posting | `[grounded]` JD silence; `[inferred]` that it may fall short | What salary range is budgeted for this post? | unresolved |
| RR3 | Team, reports and sign-off authority unstated | unknown | — | "Own pricing analytics" | The role may carry ownership without decision rights over rating changes, or may be a team of one | `[inferred]` from the JD's ownership wording against its silence on authority | Who signs off rating changes, and does this role have, or expect to have, direct reports? | unresolved |
| RR4 | Concrete deliverables named, with a named hiring manager | positive_signal | — | "build and monitor rating models, design and read price tests" | The work is specific and measurable, and you know who you'd report to | `[grounded]` JD wording and your message | What would a successful first six months look like? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | CV lines, each traced to your own sentence:<br>• "5 years in pricing analytics at a UK motor insurer, the last 2 as senior analyst."<br>• "Built and maintained the GLM rating model for the young-driver book."<br>• "Ran 14 price tests with the underwriting team" (add the year).<br>• "Present the quarterly pricing review to the head of underwriting." | R2, R4, R5, R8. I used "ran" because you did, not "designed" or "led" | `[grounded]` your background statement | pending your approval |
| E2 | Pet-domain framing for a cover note or screening call: "I haven't worked on pet insurance; my rating-model work has been on a motor young-driver book." Say it plainly rather than hiding it | R10 | `[grounded]` your statement | pending your approval |
| E3 | If management comes up, say plainly that you haven't line-managed. Don't raise it unprompted, since the JD asks for none | Direct reports row in role reality | `[inferred]` from the JD's silence | pending your approval |
| E4 | Lead with price tests and underwriting presenting for Odile Varga's role, since those are the JD's strongest direct matches | R5, R7a, R8 | `[inferred]` from the JD's wording; her footprint was not researched | pending your approval |
| A1 | Confirm the posting is live on Brindlemoor's own careers site before spending effort | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask RR2 and RR3 verbatim in the first screening call | The register doubles as interview preparation | `[grounded]` register | pending your approval |

Everything in this section that proposes wording or action, the table and the prose lines, is a proposal and is final only when you approve it.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search host refused permission, so nothing came back. It would have settled RR1 (does Brindlemoor exist as described, and is the posting live) and role reality's contradictions row |
| 2. Role-family sweep | unavailable | Same refusal. It would have supplied the market calibration line and a pay band against RR2 |
| 3. Hiring manager's public footprint | unavailable | Same refusal, although a name was given. It would have informed E4's positioning |

If you'd like it, I can write all of this up as a `tuesday-dossier.md` to carry forward.

## Upgrade menu

- A link to the live posting or Brindlemoor's own careers page, which I can read as a provided document: this works on RR1 and checks your pasted JD.
- Your pay floor and where you're based: R1 resolves, RR2 gets a real comparison, and the hard-gates line stops flagging unknown constraints.
- Your actual CV: R2 to R9 can move from self-reported prose toward `high` where a document supports them, and E1 becomes a true edit table.
- A sanitized test readout or pricing-review slide: R5, R7a and R7b move up, and R3 can show monitoring.
- A sanitized SQL or Python sample: R6 goes to `high`.
- Search access enabled: targets 1 to 3 can run. A deeper L2 pass (leadership, funding and news; up to 5 more searches and 2 more fetches) is offered once and only runs on your say-so.

## Questions

G1 — Are you based in the UK, with the right to work there without sponsorship?

G2 — Where has your pricing analysis fed a product decision, and what did you own?

G3 — Across the 14 price tests, which part did you personally own: the design, the running, or reading the results?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.