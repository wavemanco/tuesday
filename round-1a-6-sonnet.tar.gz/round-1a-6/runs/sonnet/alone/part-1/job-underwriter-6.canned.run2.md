Reading the posting is done. Now I'm running the three research searches: Quillfield itself, pay norms for this role, and Tamsin Achebe's public professional footprint.
**Yes, apply, on conditions · `conditional_go`.** R1 and R2 (location and pay) can't be checked against your terms yet, because you haven't given me any. R7 (owning a forecast) is only adjacent for you, and R8a (billing data) is absent on your own account.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Bristol hybrid, two office days), R2 (salary £61,500–£67,000 plus share options)
- `must_have` — direct: R3, R5 · adjacent: R7 (owning a forecast) · unclear: R4 (at a B2B software company), R6 (strong SQL and spreadsheet modelling), R8b (working with finance on revenue data) · absent: R8a (working with finance on billing data)
- `important` — direct: R9

R7 — a bridge, its limit named; R8a — billing data, absent on your own account; R4, R6, R8b — discovery gaps, open until answered.

**Opportunity ledger.** The employer matches its posting (RR6) and the pay is stated inside the sampled band (RR5). The open items are:
- whether the role is live on Quillfield's own site (RR1);
- where it sits against the Head of Revenue Operations, and who owns the forecast today (RR2);
- team and resources (RR3);
- option terms (RR4);
- first-year measures (RR7).

- **Hard gates:** none failed (R1, R2); unconfirmed: R1 (Bristol hybrid, two days a week in the office), R2 (salary £61,500–£67,000 plus share options); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) Bristol with two office days and the pay range both work for you — R1, R2; (2) what the pipeline review feeds is confirmed and the forecast is framed as adjacent, not owned — R7, G2; (3) you judge the billing-data gap (R8a) closable, and the loop answers RR2 and RR3 — role reporting line, team and resources.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield makes invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol, 96 employees, £11M Series A closed April 2025 | `[grounded]` About Quillfield page (quillfield.co.uk/about) |
| Mandate | "own our CRM and billing data, build the pipeline and renewal reporting our sales and finance teams run on, and run the quarterly revenue forecast with the CFO" | `[grounded]` posting |
| Working pattern | Bristol, hybrid, two days a week in the office | `[grounded]` posting |
| Compensation | £61,500–£67,000 plus share options; option terms not stated | `[grounded]` posting |
| Hiring manager | You were told Tamsin Achebe. A public profile lists her as Head of Revenue Operations at Quillfield, previously sales operations manager at Corvane Payments for four years. The posting names no hiring manager, so her role in this hire rests on the recruiter's word | `[grounded]` recruiter statement via you; search result "Tamsin Achebe — Head of Revenue Operations, Quillfield" (profile not opened) |
| Scope read | A step up from running RevOps for one UK team: company-wide forecast with the CFO and ownership of billing data. With a Head of RevOps already in post, this "Lead" likely sits beneath or beside her | `[inferred]` from the posting's mandate against your stated UK-team scope, and from her title |
| Market calibration | The sweep returned pay only: "revenue operations lead, UK B2B software" median base £64,200, interquartile range £57,800–£70,400 (n=438). The posted range sits inside it. It is UK-wide, not Bristol-specific, so scope norms for the title are not established | `[generic]` Ledgerline 2026 pay guide band; `[grounded]` the posting's own figure |
| Unknowns | Reporting line, team size, who owns the forecast today, option terms, first-year outcomes, whether the role is on Quillfield's own careers page | `[grounded]` posting silence |
| Contradictions | None found between the posting, your description (an invoicing software company) and the About page. The company's careers page could not be read (see evidence status) | `[grounded]` About page and posting |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid: two days a week in the office | hard_gate | unclear | none | hard_gate | The posting sets the term. You gave no location or commute constraint, so there is nothing to test it against. | `[grounded]` posting quote; no candidate statement | G1 question |
| R2 | Salary £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | No pay floor given, so the range can't be tested. The options are unvalued. | `[grounded]` posting quote; no candidate statement | G1 question |
| R3 | 4+ years in revenue operations, sales operations or a similar analytics role | must_have | direct | medium | none | You describe 5 years in sales operations, the last 2 running revenue operations for the UK team. It is self-reported with no CV or artifact inspected, so `medium`. | `[grounded]` your message | Share your CV so dates and titles can be checked |
| R4 | At a B2B software company | must_have | unclear | medium | discovery | Your employer is a B2B payments company. Whether it sold software is not established. Quillfield sells invoicing and payments software, so payments-domain work may read as relevant to them. | `[grounded]` your message and About page; `[inferred]` that the domain overlap helps | See G6 |
| R5 | HubSpot or Salesforce administration | must_have | direct | medium | none | You are Salesforce admin certified. The certificate is not inspected, and the posting accepts either CRM. Which CRM Quillfield runs is not stated. | `[grounded]` your message and posting wording | Certificate or Trailhead profile would raise to `high` |
| R6 | Strong SQL and spreadsheet modelling | must_have | unclear | medium | discovery | You use SQL weekly and Excel daily. That confirms use, but not "strong" or "modelling" as opposed to reporting. | `[grounded]` your message | See G5 |
| R7 | Experience owning a forecast | must_have | adjacent | medium | transferability | You run the monthly pipeline review with the sales director, but finance owned the company forecast. The review is adjacent work. You have not owned a forecast, and the posting's version is quarterly with the CFO. Whether the review's output fed finance's forecast is unknown. | `[grounded]` your statements; `[inferred]` adjacency | See G2 |
| R8a | Working with finance on billing data | must_have | absent | none | capability | You have never worked on billing data and have stated nothing adjacent. The posting says "billing or revenue data", so R8b could carry the requirement alone. R8a stays absent regardless. | `[grounded]` your statement and posting wording | Closure path in G4; carried as a material risk |
| R8b | Working with finance on revenue data | must_have | unclear | low | discovery | Your renewal dashboards may count if their figures came from, or were checked with, finance. You haven't said so. It is a lead only. | `[grounded]` posting wording, your dashboards; `[inferred]` that renewal figures are revenue data | See G3 |
| R9 | Build pipeline and renewal reporting that sales and finance teams run on | important | direct | medium | none | You rebuilt your pipeline and renewal dashboards. Whether finance teams used them is not stated, so "finance" is not claimed for you. | `[grounded]` your message | A sanitized screenshot would raise to `high` |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and pay terms (R1, R2; hard_gate) | hard_gate | The posting states both terms. Your location, commute tolerance and pay floor are not given. | A failed gate caps the decision at `no_go` however strong the fit. This is the answer most able to move the status. | Not applicable: this asks whether the term is met | None needed | `[grounded]` posting terms, no stated constraints |
| G2 | Forecast ownership (R7, must_have) | transferability | The monthly pipeline review with the sales director is confirmed. Finance owned the company forecast. | The posting names the forecast as a responsibility, so it is the likeliest probe. A stronger bridge narrows it. | Pipeline commit and upside categories you maintained; numbers you supplied that finance's forecast used; a forecast-accuracy or coverage analysis | A sanitized review deck or a forecast-accuracy sheet | `[grounded]` your statements; `[generic]` that forecast ownership is a common probe for this title |
| G3 | Revenue data with finance (R8b, must_have) | discovery | Renewal dashboards exist. Where their values came from, and whether finance used or reconciled them, is not stated. | If it holds, the "or" in the posting may let R8b carry the requirement while R8a stays open. | Renewal values reconciled to finance's numbers; contract or invoice values in a dashboard; a bookings or ARR report finance checked | A sanitized dashboard screenshot or a reconciliation sheet | `[grounded]` your message and posting wording; `[inferred]` the "or" may let R8b carry it |
| G4 | Billing data (R8a, must_have) | capability | No direct or adjacent evidence, by your own account. | A must-have with nothing behind it. It is the clearest point where the role goes beyond your history. | Closure path: a small self-built exercise turning invoice-style sample data into recurring-revenue figures in SQL, described as a learning exercise, not as experience | The exercise itself, if you choose to do it | `[grounded]` your statement; `[generic]` that such an exercise is a common way to close this kind of gap |
| G5 | SQL and modelling depth (R6, must_have) | discovery | Weekly SQL and daily Excel are confirmed. Depth is not. | "Strong" is the posting's word, and this is the easiest row to raise with an artifact. | A multi-table query behind a dashboard; a model with assumptions and scenarios you built | A sanitized query or workbook | `[grounded]` your message |
| G6 | Sector fit (R4, must_have) | discovery | "B2B payments company" is stated. Whether it sold software is not. | It decides whether R4 reads as met or as a sector stretch. | The product your employer sold and how customers used it | A one-line product description | `[grounded]` your message; posting wording |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Role not confirmed on the company's own careers page | unknown | — | "Revenue Operations Lead, Quillfield" (Tallyboard listing) | The role may sit only on the job board, or be listed at a path I didn't find. A guessed careers address returned no page. | `[inferred]` from one guessed address returning nothing | Can you point me to this role on Quillfield's own careers page? | unresolved |
| RR2 | Reporting line and forecast ownership today | unknown | — | "run the quarterly revenue forecast with the CFO" | A Head of Revenue Operations exists, so the forecast may be shared with her or in transition. | `[inferred]` from her public title against the posting's mandate | Who owns the quarterly forecast today, and how does this role sit against the Head of Revenue Operations? | unresolved |
| RR3 | Team and resources not stated | unknown | — | "You will own our CRM and billing data, build the pipeline and renewal reporting ... and run the quarterly revenue forecast" | One role may carry four areas, with no reports or analyst support named. | `[inferred]` from the posting's silence | Does the role have reports or analyst support, and which CRM and billing systems does it own? | unresolved |
| RR4 | Share option terms not stated | unknown | — | "plus share options" | Grant size, vesting and strike may change what the package is worth. | `[generic]` pattern that option value depends on terms | What is the grant size, vesting schedule and strike price? | unresolved |
| RR5 | Pay stated, inside the sampled band | positive_signal | — | "£61,500–£67,000" | The range sits within the interquartile range of a UK-wide pay guide. On that evidence it is not a seniority-pay mismatch. | `[grounded]` posting figure; `[generic]` Ledgerline band | Where in the range would you place a hire with my background? | noted |
| RR6 | Employer matches the posting | positive_signal | — | "Bristol, hybrid" | The About page describes an invoicing and payments software company in Bristol, 96 people, with recent Series A funding. | `[grounded]` About Quillfield page | What does the revenue organization look like today? | noted |
| RR7 | First-year outcomes not stated | unknown | — | "own our CRM and billing data ... run the quarterly revenue forecast" | A demanding mandate with no stated success measures leaves the first-year bar open. | `[inferred]` from the posting naming duties but no outcomes | What would a successful first year look like for this role? | unresolved |

## Application plan

Everything in this table is proposed. Nothing is final until you approve it, and that covers the CV lines and the advice rows alike. Each CV line uses your own words.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | CV line: "Rebuilt our pipeline and renewal dashboards" | R9, closest to the posting's reporting duty | `[grounded]` your message | `resume_edits_pending_approval` |
| E2 | CV line: "Run the monthly pipeline review with the sales director" | R7, R3. Kept as you said it, with no forecast wording | `[grounded]` your message | `resume_edits_pending_approval` |
| E3 | CV line: "Sales operations, 5 years, B2B payments company; the last 2 running revenue operations for the UK team" | R3 | `[grounded]` your message | `resume_edits_pending_approval` |
| E4 | CV line: "Salesforce admin certified" near the top | R5 | `[grounded]` your message | `resume_edits_pending_approval` |
| N1 | Add no forecast, billing or finance wording to the CV or outreach unless your answers to G2 and G3 confirm it | R7, R8a, R8b | `[grounded]` rows R7, R8a, R8b | pending your approval |
| P1 | Lead with the dashboards rebuild and the monthly review (R9, R3), the work closest to the posting's own "pipeline and renewal reporting" wording | Her public title is Head of Revenue Operations | `[grounded]` posting wording, search result | pending your approval |
| W1 | A sanitized dashboard screenshot or pipeline-review deck | Raises R9, supports R7 | `[grounded]` rows R7, R9 | pending your approval |
| W2 | The G4 learning exercise, if you want to close the billing gap | R8a | `[generic]` closure pattern | pending your approval |
| A1 | Ask RR2, RR3 and RR7 in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A2 | Check the role on Quillfield's own careers page, or ask the recruiter for it | RR1 | `[grounded]` RR1 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company", which returned "About Quillfield" (quillfield.co.uk/about). Fetched quillfield.co.uk/careers, which returned no page, so the role's presence on the company's own site is not established. Moved role reality's organization and contradictions rows and RR1 and RR6 |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary Bristol UK B2B software", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved the market calibration row and RR5. Scope norms for the title were not returned |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). I read the snippet only. Moved role reality's hiring manager and scope rows, RR2 and P1 |

I can share the dossier as `tuesday-dossier.md` whenever you want it.

## Upgrade menu

- Your location, commute tolerance and pay floor → R1 and R2 can be checked, and the decision settles or flips.
- A sanitized pipeline-review deck or forecast-accuracy sheet → R7's bridge strengthens or resolves.
- A sanitized dashboard screenshot, or a note on where the renewal figures came from → R9 to `high`, and R8b resolves.
- A sanitized SQL query or workbook → R6 to `high`.
- Your CV and the Salesforce certificate → R3 and R5 to `high`.
- What your employer's product was → R4 resolves.
- A link to the role on Quillfield's careers page, or the recruiter's email domain → RR1 closes.
- A deeper research pass on Quillfield (funding, leadership changes, public staff reports, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

**G1** — Is Bristol with two office days a week workable for you, and what is your pay floor against £61,500–£67,000? Is any of that a hard limit?

**G2** — In your monthly pipeline review with the sales director, which numbers did you own, and did they feed the forecast finance builds? What did you personally produce?

**G3** — Did your renewal dashboards use contract, invoice or renewal values, and did anyone in finance use or check them with you? What part was yours?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.