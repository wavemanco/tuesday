I'll read the skill's reference files before building the assessment.
**Yes, apply, but first find out whether the role is remote or based in Leeds. The posting you pasted says remote and Brindlemoor's own careers page says otherwise (R1, RR1). Status: `conditional_go`.** Not having worked on pet insurance is a bridge, not a gate: R9 sits at `adjacent` (important tier). The posting asks for no line management (see Role reality).

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK))
- `must_have` — direct: R2, R3, R4, R5a, R6, R7a, R8 · unclear: R5b (Monitor rating models), R7b (Recommendations to product)
- `important` — adjacent: R9 (Pet-insurance pricing)
- `preferred` — direct: R10 (Insurance experience)

R1 — the posting and the careers page disagree on location; R5b and R7b — not yet evidenced, recoverable by recall; R9 — a bridge, its limit named.

**Opportunity ledger.** The work is concretely named (RR4), but one live conflict sits on location (RR1). Pay is withheld (RR2), the team shape is unstated (RR3) and the company's stage is unknown (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the working pattern is confirmed compatible with your situation (R1, RR1); (2) you can evidence monitoring of a rating model and recommendations to a product audience (R5b, R7b); (3) the pet-insurance bridge is framed as adjacent, never as pet experience (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech; its own careers page lists this post and the pet-insurance product | `[grounded]` careers page fetched |
| Mandate | Own pricing analytics for the pet-insurance product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` pasted JD |
| Working pattern | Your JD says "Fully remote (UK)". The careers page says "Leeds office four days a week". I have not resolved this | `[grounded]` both texts quoted |
| Reporting line | Reports to the Director of Pricing, Odile Varga | `[grounded]` careers page and JD |
| Line management | Neither the JD nor the careers page asks for it or mentions direct reports | `[grounded]` JD and careers page silence |
| First-year outcomes | Not stated | `[grounded]` JD silence |
| Scope read | Four named responsibilities on one product reads as one coherent analyst role, not several roles folded into one | `[inferred]` from the JD's four responsibilities against the single product |
| Hiring manager | Odile Varga: Director of Pricing; spoke at the 2025 Insurance Pricing Forum on "Small Books, Loud Errors" (monitoring rating models in small books); previously head of pricing analytics at Calloway Re for six years. Read from a search snippet only | `[grounded]` search result snippet |
| Market calibration | UK senior pricing analyst at insurers and insurtechs: median base £58,400, interquartile range £52,100 to £64,900. Basis: one pay survey (n=612) seen as a search snippet, not fetched. The posting withholds pay, so this is a band, never Brindlemoor's offer (RR2) | `[generic]` role-family sweep; `[grounded]` posting silent on pay |
| Unknowns | Pay; team size and authority; company stage; whether the post is remote | — |
| Contradictions | JD "Fully remote (UK)" against careers page "Leeds office four days a week" (R1, RR1) | `[grounded]` both quoted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | "Fully remote (UK)" | hard_gate | unclear | none | hard_gate | The careers page contradicts it with "Leeds office four days a week". You have stated no location constraint, so there is no candidate claim to grade | `[grounded]` both texts; your constraints not given | G1: confirm whether Leeds four days is workable; RR1 asks Brindlemoor |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You describe 5 years of pricing analytics at a UK motor insurer, the last 2 as senior analyst. This is a length-of-experience requirement, not a gate. Typed background, nothing inspected yet | `[grounded]` your statement | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily." Strength is not evidenced beyond daily use | `[grounded]` your statement | offer: a sanitized query or notebook would raise to high |
| R4 | GLM experience | must_have | direct | medium | none | "Built and maintained the GLM rating model for our young-driver book" | `[grounded]` your statement | offer: sanitized model documentation would raise to high |
| R5a | Build rating models | must_have | direct | medium | none | Same evidence as R4: you built the young-driver GLM rating model | `[grounded]` your statement | none |
| R5b | Monitor rating models | must_have | unclear | low | discovery | You said "maintained" the model. Maintenance does not say what monitoring you ran, so I take the lower reading | `[grounded]` your wording; `[generic]` that "monitor" in pricing roles usually means checks on model performance after launch | G2 |
| R6 | Design and read price tests | must_have | direct | medium | none | "Ran 14 price tests last year with the underwriting team." "Ran" does not say which of design and analysis was yours, so be ready to say | `[grounded]` your statement | prepare a plain account of your part in each stage |
| R7a | Turn results into recommendations for underwriting | must_have | direct | medium | none | Tests run with the underwriting team, and you present the quarterly pricing review to the head of underwriting | `[grounded]` your statement | none |
| R7b | Recommendations for product | must_have | unclear | none | discovery | Nothing in what you gave touches a product audience, and I will not assume it | `[grounded]` silence in your account | G3 |
| R8 | Experience presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. Actuarial audiences are not mentioned | `[grounded]` your statement | none |
| R9 | Pet-insurance pricing, inferred: the role owns "pricing analytics for our pet-insurance product" | important | adjacent | medium | transferability | Your motor GLM and test work carry over as method. The limit: you have never worked on pet insurance, so its rating factors and claims patterns are untested by your history. The JD asks only that insurance experience be "a plus" | `[inferred]` adjacency from your motor work; `[generic]` that pet and motor pricing use different rating factors | G4 |
| R10 | Insurance experience, a plus | preferred | direct | medium | none | 5 years at a UK motor insurer | `[grounded]` your statement | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location terms (R1, hard_gate) | hard_gate | The pasted JD says remote; the careers page says Leeds four days a week; your constraints are not given | Whether the gate is met decides whether this role is open to you at all, and no wording changes that | None needed; this is a fact about your circumstances and the role's terms | The employer's confirmation, via the careers page contacts | `[grounded]` both quotes |
| G2 | Monitoring rating models (R5b, must_have) | discovery | "Maintained" the young-driver GLM, with nothing on what you checked after launch | The posting names "monitor" beside "build", and the manager has published on monitoring models; resolving this closes a must-have | Tracking actual against expected over time; checking whether the model's relativities held on live business; triggering a refit or a rate change from what monitoring showed | A monitoring pack, dashboard screenshot, or refit note, sanitized | `[grounded]` posting wording and her published talk topic; `[inferred]` that this is the likeliest probe |
| G3 | Recommendations for product (R7b, must_have) | discovery | Your audiences are underwriting and the head of underwriting | The posting names product beside underwriting as a recipient | A test result that went to a product or proposition owner; a pricing change that fed a product decision; a launch where you advised on price | A test readout or memo, sanitized | `[grounded]` posting wording, your account silent |
| G4 | Pet-insurance pricing (R9, important) | transferability | Motor GLM and test work; no pet exposure | A bridge with its limit named reads stronger than a claim you cannot back | Reading about pet rating factors before interview; any pet or small-line, sparse-data pricing you have touched | A short note of what you read and how it maps to your model | `[inferred]` bridge from your motor work; `[generic]` that pet and motor factors differ |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Location terms conflict (R1) | risk_signal | medium | JD "Fully remote (UK)"; careers page "Leeds office four days a week" | One text may be out of date, or the working pattern may not be settled | `[grounded]` the two quotes; `[inferred]` that either may be stale | Is this role fully remote, or based at the Leeds office four days a week? | unresolved |
| RR2 | Pay withheld | unknown | — | No figure in the JD or the careers page | The offer may sit inside or outside the band in role reality; your floor is not given, so no comparison is possible yet | `[grounded]` pay absent; `[generic]` band, one survey snippet | What salary range is budgeted for this post? | unresolved |
| RR3 | Team shape and authority unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | The role may be the product's sole pricing analyst, with decisions made above it | `[inferred]` from the ownership wording against the JD's silence on team | Who else sits in pricing, and which decisions does this role make rather than recommend? | unresolved |
| RR4 | Work concretely named | positive_signal | — | "build and monitor rating models, design and read price tests" | Day-to-day work is defined, which makes it checkable at interview | `[grounded]` JD | What would a good first six months look like in this role? | noted |
| RR5 | Company stage unknown | unknown | — | "Brindlemoor (insurtech)" | A search for the company returned nothing beyond its own careers page; a thin footprint is a pattern for small companies, not a claim about this one | `[grounded]` search result; `[generic]` thin-footprint pattern | What stage is Brindlemoor at, and who underwrites the pet product? | unresolved |

I'm going only on what you've shared and what I found, and I can get this wrong. The check and the call on location are yours.

## Application plan

All rows below, including the advice in the Action cells, are proposed and pending your approval. I have not seen your CV, so I propose no CV edits.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before investing in the application, confirm the working pattern with Brindlemoor through the contact details on its own careers page | see RR1, R1 | `[grounded]` RR1 | pending your approval |
| A2 | Lead with three things in your own words: you built and maintained the young-driver GLM rating model, you ran 14 price tests last year with the underwriting team, and you present the quarterly pricing review to the head of underwriting. Keep "ran" as "ran" and do not upgrade it to "led" or "owned" | see R4, R5a, R6, R7a, R8 | `[grounded]` your statements | pending your approval |
| A3 | Say plainly that your insurance pricing is motor and you have not worked on pet insurance; frame it as adjacent method and read up before interview | see R9 | `[grounded]` your statement | pending your approval |
| A4 | Do not raise management proactively; if asked, say you have not managed anyone | see Role reality: line management | `[grounded]` JD silence | pending your approval |
| A5 | Prepare one short sanitized monitoring example, if G2 produces one | see R5b | `[grounded]` the row | pending your approval |
| A6 | Ask the register's questions verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech" (no results, so company stage is not established, RR5) and "Brindlemoor careers Senior Pricing Analyst"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). The posting is live. It moved Role reality's working pattern and contradictions rows, R1 and RR1 |
| 2. Role-family sweep | yes | Searched "senior pricing analyst UK pet insurance salary remote", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey), read as a snippet. It moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga), read as a snippet. It moved the hiring manager row, G2 and A2 |

I can save this as a `tuesday-dossier.md` you can keep and update as answers come in; say the word.

**Upgrade menu**

- Your location and pay constraints → R1 becomes a firm pass or fail, and RR2 can be set against your floor.
- Brindlemoor's answer on remote versus Leeds → R1 and RR1 close, and the decision likely simplifies to `go` or `no_go`.
- A sanitized model document, query or notebook, and a test readout → R3, R4, R5a and R6 move toward `high`.
- Answers to G2 and G3 → R5b and R7b close.
- Reading the manager's talk or profile in full, not as a snippet → sharper positioning in A2.
- A deeper research pass on Brindlemoor (funding, leadership, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

- G1 (R1) — Is working from the Leeds office four days a week workable for you, or is fully remote a must?
- G2 (R5b) — After the young-driver GLM went live, what did you check to see whether it was still performing, and what did you do when it drifted?
- G3 (R7b) — Has any price test or pricing change of yours gone to a product or proposition owner rather than underwriting, and what did you recommend?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.