I'll read the reference files the skill requires before writing anything.
The prep pack is saved as `/var/tmp/tuesday-measure/1a6/runs/sonnet/alone/part-2/rooms/case-7-denied-15b3a6a5/saltmarsh-games_live-operations-producer_interview_pack.md`. I built it assuming Tobias Wrenfield is the hiring manager for a single 60-minute round, since you didn't say how Tobias relates to the role.

All four of my web searches (company values, interview process, strategy, and Tobias) were refused. So the pack has no facts about Saltmarsh Games or about Tobias beyond what you told me. The questions on the company and strategy are generic, and there's no section on Tobias. The fit snapshot, the question banks and the "not coached" list use only your JD and your own sentences. The sources section lists each refused search.

The pack names one question as the highest-ROI prep. It's B1, the question about owning the KPIs when you've never worked on a game with in-app purchases. The pack puts it first in the prep order.

Say the word and I'll play the Skeptic on B1, with live follow-ups and feedback against that question's guidance. I can also save a `tuesday-dossier.md` with the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, I'll convert it.

Who is Tobias to the role: the person you'd report to or someone else in the loop, and did the recruiter say anything about format or what to prepare? The answer reweights every question bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

- **Candidate:** Femi
- **Role:** Live Operations Producer, Saltmarsh Games (mobile game studio, about 350 people)
- **Interviewer:** Tobias Wrenfield, Head of Live Operations
- **Round:** one 60-minute interview on Friday. The relationship was not stated; this pack assumes Tobias is the hiring manager for the role. If that is wrong, the persona weights and banks need reweighting.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for your own words, not a script, and it is never a source of facts about your past: anything about your experience comes from your own sentences, quoted in the fit snapshot.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows good judgment under the kind of pressure the role brings (no published Saltmarsh values were retrieved) |
| EXP | Whether your background claims survive follow-up questions |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you did your homework on the company |
| CASE | A live problem from the role, scored on structure and reasoning |

An answer slot is an instruction for the interview: say your own answer to it, or say plainly that the practice was not yours or did not exist.

## Prep triage

Built for the short runway before Friday. Do these in order; the rest is insurance.

1. Say B1 aloud until it is boring: three full runs, including both follow-ups. It is the highest-ROI prep in this pack.
2. Answer B2, B3 and A3 aloud once each. They cover the calendar and the years requirement, the two lines of the JD your material reaches least directly.
3. Time the D1 arc to 90 seconds.
4. Work out, before Friday, how the retention numbers you presented were counted and what you do not know about it, then run C1 once.
5. Run one case, A1 or A2, aloud with the structure: clarify, objective, options, metrics, risks.
6. Pick three reverse questions from section 11.

Everything else in the pack is insurance.

## Fit snapshot

No requirement in the JD as supplied is a gate: "3+ years" is an experience length, not a term you meet or do not.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message | medium | [grounded] | discovery | Your material gives four years as an associate producer; it does not show which years, if any, were on a live-service title. Words stay at the quote: "I've spent four years as an associate producer at a puzzle-game studio." Answer slot: the JD's years line makes a probe on how the four years divide likely. Say what you worked on in each year, in your own words; if you cannot divide them, say so plainly and stay with the calendar you ran |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap, but a message line with nothing inspected behind it, so expect a probe. Lead with the quote's own terms: you ran it, it was weekly, it was for the main title, for the last two years |
| F3 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for the main title; it does not say live events, and it does not reach a second title. Words stay at that scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's two-titles line makes a probe on work beyond the main title likely. If you planned or ran anything beyond it, say what and how, in your own words; if not, say so plainly and stay with the main title |
| F4 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message; "Never led a team" — your message | low | [inferred] | discovery | Derived from the calendar line touching the requirement; the material does not show which teams you worked with. Answer slot: the JD names four disciplines, so expect a probe on which you worked with. Say which and what you needed from each, in your own words; if some were not groups you worked with, say so plainly. If asked about leading people, your own words: "I've never led a team." |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your material says you presented the monthly retention numbers; it does not say who produced them or whether a review followed a drop. Words stay at that scope: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's review line makes a probe likely. If you also decided what the numbers covered, or reviewed a drop after it shipped, say how, in your own words; if the numbers came from someone else or no such review existed, say so plainly and stay with presenting them |
| F6 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | transferability | Your material says you wrote the checklist and that QA still uses it; it does not say who ran releases against it. Words: "I wrote the release checklist our QA team still uses." Answer slot: the JD's manage-with-QA line makes a probe likely. If you also ran releases against it with QA, say how, in your own words; if not, or it was not yours, say so plainly and stay with having written it |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | No gap, but a message line with nothing inspected behind it, so expect a probe on how the numbers were counted (C1). Lead with the quote's terms: monthly, retention, presented to the studio head |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | low | [inferred] | discovery | Derived from the checklist as a written artifact; it is the one piece of writing in your material. Answer slot: if you wrote anything else a drop or a review would use, say what, in your own words; if not, say so plainly and stay with the checklist |
| F9 | Monetization measures in a mobile live-ops review (role-family, not in the JD, which says only "the KPIs it reports") | "never worked on a game with in-app purchases" — your message | none | [generic] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |

## Persona table

No interviewer profile or loop source was retrieved, so the weights come from the relationship prior for a hiring manager (Case/Strategist and Skeptic) and from the gaps in the fit snapshot. Recalibrate if you know something this pack does not.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (bank A) | Live problems from the role: a calendar clash, a blocked release, a retention dip | High: the hiring-manager prior, and the JD's verbs (plan, coordinate, review) are all things a live problem can test | Clarify, objective, options, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic (bank B) | Quiet, persistent probing of the gaps | High: the hiring-manager prior, plus F3, F5 and F9, where your material is thinnest against the JD | Rehearse B1 until it is boring; hold what your quotes carry, concede the rest specifically, and give a ramp plan as a plan |
| Data-Driven Prober (bank C) | Questions on the retention numbers and how a drop is judged | Medium: the JD names retention metrics and you present them monthly (F7); no interviewer signal pushes it higher | Know what you can and cannot say about how the numbers were counted; say plainly when you do not know |
| Conversational (bank D) | The opener and the why-us questions | Medium: any 60-minute conversation opens this way, and casual questions are still scored | A timed 90-second arc; treat the writing question as scored |
| Pressure (bank E) | Interruptions and attribution challenges | Low: not a hiring-manager prior and no interviewer signal | Pause, restate, hold through two follow-ups, concede specifically |
| Values/Behavioral (bank F) | Behavior stories | Low: no loop source was retrieved, and the generic fallback archetype reads no values-style round | Selection criteria, with the honest branch when no story comes to mind |
| Peer Evaluator (bank G) | Seam and credit questions with design or engineering leads | Low: the assumed interviewer is the head of the function; rises if the loop includes a session with those leads | Propose seam principles; frame what you bring, not only what you need |

## Question banks

### A. Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have two mobile titles and one calendar slot next Thursday for each. Design wants a new event on both, and engineering says it can ship only one safely. What do you ask first, and what do you decide?" | CASE | [generic] | Structure it aloud: what you would ask first (what the event is for, what "safely" means, QA status), the objective, the options (ship one, ship a reduced version of both, move one), who decides and what you bring them, and what you would record for the post-event review. The question needs no claim about your past, so the guidance makes none | A live problem built from the JD's two-titles and coordination lines (F3, F4), asked as a decision; CASE because it scores structure |
| A2 | "Day-7 retention on one title dropped after last week's event. Diagnose it." | CASE | [generic] | Clarify first: how the metric is defined, which cohorts, what else shipped that week. Then segment, form two hypotheses and say what data would separate them, who you would ask for it, and what you would not conclude yet. Plan language only: "I would". No claim about your past | The JD's retention line (F7) as a live problem; CASE because the delivery is a diagnosis, JD because the content is the stated requirement |
| A3 | "How would you build a live-events calendar that spans two titles without the two colliding?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Story-mapped on F3, at the quote's scope: the calendar was weekly, it covered content drops, it was for the main title, and you ran it for the last two years, told in your own words. Answer slot: the JD's two-titles line makes a probe on work beyond the main title likely. If you planned or ran anything beyond it, say what and how; if not, say so plainly and stay with the main title. Then the plan for two titles, said as a plan: what you would need to see across both before fixing a slot | F3 is where the JD's headline duty presses hardest; JD because it scores the stated requirement |
| A4 | "An update is due Friday. Thursday afternoon QA finds a blocking bug and engineering says the fix lands Monday. What do you do?" | CASE | [generic] | Clarify severity and who owns the call, then the options (delay, ship without the feature, hotfix), what you tell design, art and community and when, and what you would change on the checklist afterward. Plan language only; no claim about your past | The JD's checklist and coordination lines (F4, F6) as a live decision |
| A5 | "Pick one of our two titles. What would you want to understand about its live events before changing anything?" | CO | [generic] | The pack could not retrieve anything about Saltmarsh's titles, so it supplies no facts about them. Speak only about what you have seen yourself, as a player or on a store page, before Friday; if you have not, say so plainly and ask about the current event cadence and what the team treats as a good event. Two or three questions you would want answered, in your own words | CO rather than CASE because it scores homework depth; `[generic]` because research was unavailable, so it cannot be tied to Saltmarsh's current strategy |

### B. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role owns the KPIs the post-event review reports, and you haven't worked on a game with in-app purchases. How do you get to owning those KPIs?" | JD | [grounded] "never worked on a game with in-app purchases", "Presented the monthly retention numbers to the studio head" | The highest-ROI rehearsal in this pack: hold, then concede. Pause and restate the question. Concede the stated negative first and specifically: "I've never worked on a game with in-app purchases." Hold what your quote carries: "I presented the monthly retention numbers to the studio head." Then the ramp, as a plan in your own words ("I would"): which numbers you would ask to see in the first weeks and who you would ask. Follow-up 1, "What do you do in month one?": the same plan, one level more specific, still a plan. Follow-up 2, "Why should retention matter without purchase data?": do not widen the quote; say what you have handled, say what you have not, and return to the plan. Answer slot: if you have worked with any measure beyond retention, say which; if not, say so plainly and stay with retention | F5 and F9 are where the material is thinnest against the KPI line, so this objection arrives in some form; this objection is inferred from the fit snapshot, not taken from a dossier. JD because it scores a stated requirement |
| B2 | "Your calendar was for your studio's main title. This role covers two titles. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Hold the quote at its scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: if you planned or ran anything beyond the main title, say what and how; if not, say so plainly. Then what changes, as a plan in your own words: what you would want to see across both titles before fixing a slot. Concede that two titles is new ground only if your answer to the slot was no | F3 again, in Skeptic delivery, so the same gap is rehearsed in a second register |
| B3 | "The JD asks for 3+ years producing live-service games or apps. Which of your four years were on a live-service game?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio", "I ran the weekly content-drop calendar for our main title for the last two years" | Hold what the quotes carry: four years as an associate producer at a puzzle-game studio, and the weekly content-drop calendar for the main title for the last two. Answer slot: say what you worked on in each of the four years, in your own words; if you cannot divide them, say so plainly and stay with the calendar. Do not round the years up or stretch them to fit the JD's number | F1 is the likeliest place a years requirement is tested; EXP because it tests whether the claim survives follow-up |
| B4 | "You haven't led a team, and this role coordinates four disciplines on every update. How do you get work out of people you don't manage?" | JD | [grounded] "Never led a team", "I ran the weekly content-drop calendar for our main title for the last two years" | Concede first and plainly: "I've never led a team." Hold the quote: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD names design, art, engineering and community, so expect a probe on which of them you worked with. Say which and what you needed from each, in your own words; if some were not groups you worked with, say so plainly. The method for people you don't manage is a plan, said as one ("I would") | F4 and its stated negative; JD because the coordination line is the stated requirement |
| B5 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never worked on a game with in-app purchases", "Never led a team" | A selection scaffold: pick the gap your own words already name, "I've never worked on a game with in-app purchases" or "I've never led a team", whichever the JD's KPI line or its coordination line presses on harder for you. Name it plainly, then the ramp as a plan in your own words. Do not pick a gap you have not stated just to sound candid | F9 and F4 as the self-assessment version of B1 and B4; JD because it scores honest self-assessment against the listed duties |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which retention numbers did you present to the studio head, and how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Say what you presented, in the quote's terms: monthly, retention, to the studio head. Answer slot, the four slots a metric raises: in your own words, how the numbers were counted, what they are sensitive to, the assumption behind them you would defend least, and which part of the work was yours. Where you do not know how something was counted, say so plainly; that is an honest branch, and a made-up method is the one thing a second question breaks | F7 is a message line with nothing inspected behind it, and a prober checks exactly that; EXP because it tests attribution and knowledge of your own numbers |
| C2 | "When an event ends, how do you decide whether it worked?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | The method, as a plan: what you would want stated before the event, what you would compare, what you could not conclude, and what you would do next. Answer slot: the JD's review line makes a probe likely. If you have reviewed a drop after it shipped, say how it worked; if there was no such review, or it was not yours, say so plainly and stay with presenting the monthly numbers | F5, the review and its KPIs; JD because it scores the stated duty |
| C3 | "Two events ran back to back and retention rose after the second one. Can you credit it?" | CASE | [generic] | Clarify first: what the first event did, how long effects last, what else changed. Then confounds (overlap, cohort mix, an unrelated release), the comparison you would want, and what you would say if the data could not separate the two. Saying what you cannot conclude is the point. No claim about your past | A prober's causal-credit probe on the JD's retention line (F7); CASE because it is a live problem |

### D. Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio", "I ran the weekly content-drop calendar for our main title for the last two years", "Wrote the release checklist our QA team still uses", "Presented the monthly retention numbers to the studio head" | A 90-second arc whose beats are the four quotes, each at its own scope: four years as an associate producer at a puzzle-game studio; the weekly content-drop calendar for the main title for the last two years; the release checklist QA still uses; the monthly retention numbers presented to the studio head. Close with why live operations and why this studio, in your own words: the pack supplies no reason, and one you did not give would not survive the next question | The biography question is the one nearly every 60-minute conversation opens with; EXP because it is your own path |
| D2 | "Why Saltmarsh, and why mobile?" | CO | [generic] | Your true reason, in your own words. The pack retrieved nothing about Saltmarsh, so it supplies no company facts; anything you say about the studio should be something you read or played yourself, and if you have not looked yet, do so before Friday rather than guess | CO because it scores homework depth; `[generic]` because research was unavailable |
| D3 | "How do you keep design, art, engineering and community on the same page about an update, in writing?" | JD | [inferred] "Wrote the release checklist our QA team still uses" | The structure of the note, as a plan: what it must say, what each discipline needs from it, and how you would know it was read. Answer slot: the JD's written-communication line makes a probe on your writing likely. If you wrote anything else a drop or a review would use, say what; if not, say so plainly and stay with the checklist, which your quote says QA still uses | F8, the thinnest of the JD's lines in your material; `[inferred]` because the checklist is the only written artifact in it |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That release checklist: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Pause, restate, then hold: "I wrote the release checklist our QA team still uses." Answer slot: if QA or anyone else shaped it, say what they added; if you wrote all of it, say so; if you cannot separate your part from theirs, say so plainly. Hold through two follow-ups by returning to the quote, never by adding to it; concede only what you cannot separate | F6 is a claim with an artifact behind it, so attribution is the probe; EXP because it tests what was yours |
| E2 | "Sixty seconds: why you over a candidate who has worked on a game with in-app purchases?" | JD | [grounded] "never worked on a game with in-app purchases", "I ran the weekly content-drop calendar for our main title for the last two years", "Wrote the release checklist our QA team still uses" | Concede first: "I've never worked on a game with in-app purchases." Then in sixty seconds, what you do have, as the quotes state it: the weekly calendar for the main title for the last two years, and the checklist QA still uses. Do not claim parity, and do not argue that your work proves anything; describe it and let the interviewer judge. End with the ramp as a plan | F9 under time pressure; JD because it scores fit against the listed duties |

### F. Values/Behavioral (weight 2)

No published values were retrieved and no values-style round was detected, so these are open prompts built on persona stems, not mapped to Saltmarsh's values.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection criteria: pick a time with a named stake, a moment you said the hard thing plainly, and a relationship that was intact after. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioral stem; `[generic]` because no loop source or published value was available |
| F2 | "When did you put the player ahead of a schedule or a metric?" | VAL | [generic] | Selection criteria: a specific decision, what it cost the schedule or the number, and what you did about that cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Live operations decisions trade player experience against cadence, so the stem fits the role; `[generic]` for the same reason |

### G. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our design and engineering leads will both want slots in the calendar. Where is the seam between your job and theirs, and what happens when we disagree?" | JD | [generic] | Propose seam principles rather than claiming to know the seam: who owns the what, who owns the when, and who decides when slots conflict. Say what you bring them (a calendar they can plan against) as well as what you need. Disagreement as a plan in your own words, showing spine and tact together. No claim about your past | F4's coordination line, asked collegially |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection criteria: a piece of work that crossed teams, what was yours, and how you named the others. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. "We" for context, "I" for what was yours | A peer's credit probe; `[generic]` because it needs no claim the pack can support |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A1, A3, B2 |
| "coordinate design, art, engineering and community teams on each update" | A4, B4, G1 |
| "own the post-event review and the KPIs it reports" | A2, B1, C2 |
| "manage the release checklist with QA" | A4, E1 |
| "3+ years producing live-service games or apps" | B3, D1 |
| "experience running a content calendar" | A3, B2, D1 |
| "comfortable with player-retention metrics" | A2, C1, C3 |
| "clear written communication" | D3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good first ninety days look like for this producer across the two titles?" | It shows you are planning the ramp rather than hoping the gaps go unnoticed, and the answer tells you what the team treats as the real starting point |
| R2 | "Which KPIs does the post-event review report today, and which would the producer own versus read?" | It turns the KPI line, where your material is thinnest, into a scoping conversation and gets you the real list |
| R3 | "How are post-event reviews used today: who reads them, and what has changed because of one?" | It shows you care about the review as a decision tool, not a document, and surfaces how much weight the role carries |
| R4 | "When design, art, engineering and community want the same slot, how does the calendar get settled today?" | It addresses the coordination line directly and tells you whether the producer holds authority or facilitates |
| R5 | "How do the two titles differ in cadence, and what should I understand about each first?" | It shows the specific-to-the-company curiosity A5 and D2 rehearse, and it answers the two-titles question you will otherwise have to guess at |
| R6 | "What would make you say, six months in, that this hire worked?" | It lets the interviewer state the scoring sheet in their own words, and you can tie your last answer to it |

## Prohibited claims

Built from the fit snapshot before the banks were written. No dossier was present.

| Not coached | Basis | Honest form |
|---|---|---|
| Four years producing live-service games | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material gives four years as an associate producer, not which were live-service. B3's slot stays inside those years |
| Ran live events across two titles | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material says a weekly content-drop calendar for the main title. A3's and B2's slots stay inside the main title |
| Owned the post-event review and its KPIs | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation: the material says you presented the monthly retention numbers. C2's slot stays inside the numbers you presented |
| Managed the release checklist with QA | Inflated form of F6 | F6's quote at its own scope. The limit is the pack's observation: the material says you wrote the checklist and that QA still uses it. E1's slot stays inside who shaped it |
| Led a team | Negative you stated, F4 | The plain acknowledgment: "I've never led a team." No slot |
| Has worked with in-app purchases | Negative you stated, F9 | The plain acknowledgment: "I've never worked on a game with in-app purchases." No slot |

## Sources

**Provided documents:** your message (the JD text and your background). No dossier was present.

**Searches sent, all refused:**

- `Saltmarsh Games values` — refused
- `Saltmarsh Games interview process live operations producer` — refused
- `Saltmarsh Games strategy news mobile` — refused
- `Tobias Wrenfield Saltmarsh Games` — refused

No pages were fetched. Nothing in this pack states a fact about Saltmarsh Games or about Tobias Wrenfield beyond what your message gave.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | The search was refused. Would have moved: a values cheat sheet and mapped VAL questions, if a values-style round had been documented; bank F stays generic |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | The search was refused. Would have moved: loop structure and persona weights; they rest on the hiring-manager prior and a generic fallback instead |
| 3. `Saltmarsh Games strategy news mobile` | unavailable | The search was refused. Would have moved: CO and CASE questions grounded in current strategy; A5 and D2 are generic |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | The search was refused. Would have moved: the interviewer read and one reverse question tied to the interviewer's path; both are absent |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Search access for Saltmarsh values, interview process and current strategy (the four searches were refused this run) → a VAL bank mapped to published value names if a values round is documented, persona weights from the real loop, and CO and CASE questions grounded in current strategy instead of generic ones
- A deeper research pass (up to 6 further searches and 2 further fetches, several more minutes, needs search access) → a grounding brief, interviewer talks and writing, and loop reports for this role family
- Tobias Wrenfield's public profile, talks or writing, if you have them → an interviewer read, persona weights adjusted to what has been published, and a reverse question tied to the interviewer's own path
- The recruiter's prep email, or the interview invite → the round format, whether other sessions follow, and coverage of any pre-declared deliverable
- Your answers to the answer slots in F1, F3, F4, F5, F6 and F8 → those rows quote your own words, and the slots in the banks become story maps instead of instructions
- The release checklist itself, a sample monthly retention report, or an exported calendar, shared as files → F6 and F7 move from medium toward high, since each is an inspectable artifact
- Your CV, if you have one beyond the summary you gave me → rows quoting a CV line instead of your message, and any role or project the summary dropped
- A `tuesday-dossier.md` from a prior underwriting pass → verified evidence and a sourced objection list in place of the inferred one in B1, and a sourced prohibited list in place of the locally built one
