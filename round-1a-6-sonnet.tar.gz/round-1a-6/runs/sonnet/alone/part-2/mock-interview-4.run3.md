I'll read the reference files the skill points to before building the pack.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a6/runs/sonnet/alone/part-2/rooms/case-4-denied-befe0d5f/quartzline_product-manager-platform-apis_interview_pack.md`. I built it for a hiring-manager round, from your dossier and the 45-minute format.

- **Highest-ROI prep:** A1 is the objection the underwriter named: "You have never held the PM title or owned a roadmap." The pack has you concede what the dossier lets you concede, then hold only what your confirmed integration work says. It also has you name the limit before they do. F1 is the 60-second version of the same answer.
- **Gaps handled per the dossier:** There is no bridge and no answer slot on the roadmap gap. Agile delivery is a "here's what I'd want to confirm" answer.
- **Research:** My three web searches on Quartzline's values, interview loop and strategy were refused, so none of that is in the pack. It leans on your dossier, and the case questions are generic.
- **Length:** It has 19 questions, 6 reverse questions and a prohibited-claims list.

Say the word and I'll play the Skeptic on A1 and run it live with follow-ups.
I can also save a `tuesday-dossier.md` update recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

Interviewer: the hiring manager (name not given). Format: one 45-minute conversation, Thursday. Built from your tuesday-dossier.md (dossier_version 1.1, generated 2026-08-14).

Highest-ROI prep in this pack: **A1**, the objection the underwriter named ("You have never held the PM title or owned a roadmap..."). It will arrive in some form, and a rehearsed, non-defensive answer changes the interview. Rehearse A1, then F1 (its 60-second version), then A2 and A3.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your claims survive scrutiny: what was actually you |
| JD | Whether you can do the listed job, including its gaps |
| CO | Company and strategy knowledge |
| CASE | Structure and reasoning on a live problem from the role |

"Answer slot" means an instruction for the interview, not a question for you now: it names the interviewer's likely probe, then gives two honest branches. Either branch is a good answer. Where the dossier marks an area as an acknowledged gap, there is no slot and no bridge, only a plain acknowledgment and a plan.

## Fit snapshot

Requirement lines are the dossier's `role_profile` text, which stands in for the job description. Evidence cells hold your confirmed sentences from the dossier and nothing else. Rows F1, F2 and F6 take their confidence, gap type and strategy from the underwriter. The dossier carries no evidence map, so this pack graded F3, F4 and F5 itself, hence `[inferred]`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [grounded] | transferability | Strategy is bridge, and the underwriter's condition is that it is positioned as adjacent, never as PM experience. Words stay at the quote's scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." The limit is the pack's observation: your material shows integration work, with no product title or roadmap in it. Answer slot: the JD's 3+ years line makes a probe on how many years of this work likely; give your own count of the years you did this work, and say plainly that it was integration delivery |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile | none given | none | [grounded] | capability | The dossier records this as an acknowledge_gap area ("Owning a roadmap and prioritization authority (R1 sub-claim)"), so the words come only from that field and from `prohibited_claims: "Having owned a product roadmap"`: "I haven't owned a roadmap." Then a plan, said as a plan and never as a past: how you would learn the roadmap process and who holds which decisions in the first weeks. No bridge and no slot here, and F5 is never offered as roadmap ownership |
| F3 | "Shipped API or platform products" — dossier role_profile | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [inferred] | transferability | The quote is work on client integrations of APIs, and the words stay there. The pack's observation: it does not show an API or platform product being released. Answer slot: the JD's "Shipped API or platform products" line makes a probe on what you released likely; if any part of those go-lives was a release you owned, say which and what was yours, in your own words; if what you led was client integrations, not an API or platform product, say so plainly and stay with the integrations |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | low | [inferred] | discovery | REST API integrations and a playbook touch this requirement without showing API documentation or schemas. Answer slot: if you read, wrote or reviewed API documentation or schemas, say which and in what situation, in your own words; if the integrations did not involve them, say so plainly and stay with the integrations and the playbook |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [inferred] | transferability | Confirmed with limited inspectable proof, so expect a probe and name the limit yourself: say what the sessions were and what they fed, at that scope. The quote reaches clients and product; it does not show engineering or sales. Answer slot: the JD's "engineering, sales, customers" line makes a probe on the other two likely; if you worked with engineering or sales in those sessions or the integrations, say how, in your own words; if you did not, say so plainly and stay with clients and product |
| F6 | "Agile delivery experience" — dossier role_profile | none given | low | [grounded] | discovery | Strategy is clarify, and no verified entry speaks to agile delivery, so nothing is quoted. Answer slot: expect a probe on "Agile delivery experience"; if you worked in an agile delivery cycle with engineering teams, say how and what was yours, in your own words; if you never worked that way, say so plainly and say what you would want to confirm about how this team defines it |

No requirement in the dossier is a gate: "3+ years" is an experience requirement, so it is graded as a gap, not a hard gate.

## Persona table

Relationship prior for a hiring-manager round: Case/Strategist and Skeptic dominate. Your own words ("a 45-minute conversation with the hiring manager") establish the one session, so no archetype fallback was needed. Weights are my judgment; recalibrate if you know something I don't.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet, persistent probing of the title and roadmap gap, and of why you want this now | 5. Hiring-manager prior (they are de-risking a gap), and the underwriter named this objection from evidence you confirmed | Rehearse A1 until it is boring: concede what is sourced, hold only what the quotes carry, name the limit first, offer a plan |
| B. Case/Strategist | Live problems from the role's own responsibilities: partner blockers, roadmap choices, adoption, a spec | 4. Hiring-manager prior; the JD's responsibilities (roadmap, partner discovery, specs, adoption metrics) are the raw material | Clarify, then structure, then answer; ask about the two unknowns (decision rights, how adoption is measured) as part of the structure |
| C. Data-Driven Prober | Presses on the 30+ figure and on the playbook: how counted, what was yours | 3. The count and the playbook are the two claims with something to inspect, so they are where a close reader digs | Know what you can and cannot say about how the number was counted, and say plainly where you do not know |
| D. Conversational | "Walk me through the journey"; casual questions about API tooling or working with engineers | 3. A 45-minute conversation has an opening biography slot, and casual questions on JD topics are still scored (generic pattern) | A 90-second arc built only from your confirmed sentences |
| E. Peer Evaluator | Where the seam sits between you and the two squad leads, and credit when work spans teams | 2. The interviewer is a manager, not a peer, but the role works across two squads and the JD's authority question is open | Propose seam principles; do not pretend to know the seam, and ask how decision rights are set |
| F. Pressure | Time-boxed or interrupted versions of A1 and of "how much was you" | 2. Not in the hiring-manager prior, but the A1 objection can arrive as "sixty seconds" | Pause, restate, concede what is sourced, hold the rest through two follow-ups |

No values-style round is detected (no loop source names one, and your note describes one hiring-manager conversation), so there is no values bank and no values cheat sheet.

## Question banks

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The deepest rehearsal in the pack, and the underwriter's own pick. Order: concede, hold, name the limit, offer a plan. Concede first and specifically, in words sourced by dossier `prohibited_claims: "Having held a product manager title or role"` and `prohibited_claims: "Having owned a product roadmap"`: "I haven't held the product manager title, and I haven't owned a roadmap." Hold only what the quote carries: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Say the limit before they do: this is adjacent work, offered as adjacent, not as PM experience. Then a plan, said as a plan: how you would learn the two squads' current priorities and who decides what. Follow-up 1 (a PM with three years has made the prioritization calls): concede specifically, sourced by `prohibited_claims: "Having set prioritization for an engineering squad"`: "I haven't set prioritization for an engineering squad." Then return to the quote. Follow-up 2 (so why take the risk): return to the quote again and ask what they would need to see to be confident (RQ6). Never add to the quote; describe what you did and let them draw the inference | The underwriter named this objection from evidence you confirmed, and F1 and F2 are where it presses. JD because it scores the must-have in R1; the Skeptic delivery is how a hiring manager de-risks it |
| A2 | "The role wants shipped API or platform products. What have you shipped?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Start at the quote's scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Answer slot: the JD's "Shipped API or platform products" line makes a probe on what you released likely; if any part of those go-lives was a release you owned, say which and what was yours, in your own words; if what you led was client integrations, not an API or platform product, say so plainly and stay with the integrations. Never describe an integration as a product you shipped | F3 is a must-have and the likeliest second probe after A1. The premise is the JD's, and the guidance does not adopt it |
| A3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] | Name the roadmap and prioritization first, in the sourced plain acknowledgment: dossier `acknowledge_gap` area "Owning a roadmap and prioritization authority (R1 sub-claim)" supports "I haven't owned a roadmap." Then the plan, as a plan: ask which decisions sit with the squad leads and which with this role, and ask for the current adoption baseline. No bridge on this one; the underwriter looked for evidence and found none | F2, rehearsed so the honest answer is ready. A candidate who names the real gap first, with a plan, is easier to believe on everything else |
| A4 | "Why move from integration delivery into product, and why now?" | EXP | [generic] | A selection scaffold, because your material states no motive. Pick the true reason, in your own words, and make it about this role's own content (the partner-facing API platform, discovery with integration partners), not about escaping your current job. It has to be consistent with what you said in A1 and A3. If no clear reason comes to mind, say so plainly, then give the nearest thing you can stand behind, or how you would test whether the move is right for you | Motivation consistency is what the Skeptic scores. Tagged EXP because it tests whether the story you tell about your path holds together; F1 is the evidence it sits beside |
| A5 | "How have you worked with engineering squads on delivery — agile or otherwise?" | JD | [grounded] | Strategy is clarify, and no verified entry speaks to agile delivery, so this guidance quotes nothing about your past. Answer slot: the JD's "Agile delivery experience" line makes a probe on it likely; if you worked in an agile delivery cycle with engineering teams, say how and what was yours, in your own words; if you never worked that way, say so plainly and say what you would want to confirm about how these two squads define it | F6, a preferred requirement the dossier marks discovery. The honest answer either way is short, and the confirming question doubles as diligence |

### B. Case/Strategist (weight 4)

These ask about no past; they presuppose nothing about you.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A partner says an authentication change is blocking their go-live, and the two squads each say it's the other's area. Walk me through your first week." | CASE | [generic] | Clarify first: what exactly is blocked, for which partner, how severe, by when. Then: who has the decision (ask, since decision rights are an open question in this role), what unblocks the partner fastest versus what fixes it properly, what you tell the partner and when, and what you record so it does not recur. Challenge one premise respectfully, for example whether it is really a two-squad problem | Tests the JD's "drive delivery with two engineering squads" and "run discovery with integration partners" together, in the hiring manager's native territory |
| B2 | "You inherit the partner API roadmap with six requests and capacity for two. How do you choose?" | CASE | [generic] | Objective first (what adoption means here and its current baseline, which you would ask for), then segment partners and requests, name your criteria out loud, say what evidence you would want for each, and say who you would decide with. State the risk of the choice and how you would find out you were wrong. Ask what the squad leads would weigh differently | The roadmap responsibility, taken as a live problem. It lets you show structure on the one area where your material is silent, without claiming a past |
| B3 | "Partner API adoption drops 20% quarter on quarter. Diagnose it." | CASE | [generic] | First question: how is adoption defined and measured today? (The dossier lists this as an open unknown, so asking is honest, not a dodge.) Then segment: new versus existing partners, endpoints, versions, regions; separate a measurement or instrumentation change from a real change; check for a release, a deprecation or a partner-side event. Say which one cut you would look at first and why | The JD's adoption-metrics responsibility. Diagnosis cases reward asking about the metric before explaining it |
| B4 | "Pick one change to the partner API. What goes on the first page of the spec?" | CASE | [generic] | The problem and the partner evidence for it; who it is for; what success looks like and how adoption would show it; scope and non-scope; the open questions and who answers them; the dependencies on the two squads. Say aloud which parts you would draft alone and which you would write with an engineer | The JD's "write specs" responsibility. A spec first page shows prioritization thinking without needing prioritization authority |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've said you led 30+ client integrations. How was that number counted?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Say what the quote says, keeping the number on its noun: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Four answer slots, each in your own words: how the count was made; what it is sensitive to; the assumption behind it you would defend least; which part was yours. If you do not know how the count was made, say so plainly. Supply no method, time period or team size you did not state | The headline figure in your material, and the first thing a close reader tests. F1 and F3 both rest on it. EXP because it scores attribution |
| C2 | "Take one of those integrations — what did requirements and UAT look like, and what did you decide yourself?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Choose one integration you can walk end to end, and keep to the stages the quote names: scoping, requirements, architecture, UAT, go-live. Answer slot: say which of those stages were yours to decide and which were shared, in your own words; if "led" meant coordinating other people's decisions, or a stage was not yours, say so plainly and describe how you ran it. Use "we" for context and "I" for what you did | A prober's follow-up goes two levels below the headline. This is that follow-up, rehearsed so "what was actually you" is a rehearsed answer rather than a discovery |
| C3 | "You wrote the integration playbook your team uses — what's in it, and how do you know it's used?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Say it at the quote's scope: "I wrote the internal integration playbook my team uses." Answer slot: say what the playbook covers, in your own words; on how you know it is used, if you know, say how you know; if you do not, say so plainly. The dossier records the playbook as inspectable, so offer to walk through it end to end. Do not describe sections or adoption you did not state | The playbook is the one piece of inspectable proof behind your material, so a prober will go there. F4 is where it helps most, and only at its own scope |

### D. Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey. How did you get to this conversation?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc, three beats, each only what its quote says: the 30+ integrations, the playbook, the quarterly roadmap-input sessions feeding client evidence to product. The third is confirmed with limited inspectable proof, so say it at that scope, and if asked for something to look at, say plainly what exists and what does not. Close on why this role, in your own words. Say that the work is adjacent to product, and do not call it product experience | The biography slot opens most conversations and is scored even when it feels casual. F1, F4 and F5 supply the beats |
| D2 | "What are you actually playing with in API tooling these days?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | A casual question on a JD topic (API docs, schemas), and still scored. Answer slot: if you read, write or review API documentation or schemas, say which and what you do with them, in your own words; if you do not, say so plainly and stay with the REST API integrations and the playbook. Only name tools you actually use | F4, the discovery row. The casual register is the danger; this question is the same probe as the direct one |
| D3 | "Tell me about working with engineers on something hard." | EXP | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | An open prompt on the JD's engineering-stakeholder and squad-delivery lines. Choose one instance from your integrations, and answer slot: say which of the stages involved engineering teams and what you did with them, in your own words; if there was little engineering contact, or the engineers were not people you worked with directly, say so plainly and describe the stakeholders you did work with. Name a stake, a moment of friction and how it ended, if you have one | F5 shows no engineering evidence, so this question is where that gap is closed or acknowledged. EXP because it tests a real instance |

### E. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "You'll sit between two squad leads. Where's the seam between you and them, and what happens when you disagree?" | CASE | [generic] | Offer seam principles, not a map: who owns the outcome versus who owns how it is built, decisions made on stated evidence, disagreements named early and escalated on a fixed path. Say plainly that you would ask how decision rights are set before assuming (RQ1). Make no claim about having set a squad's priorities; you haven't | The JD asserts authority over the squads, and the dossier flags that as unverified. This question lets you surface it as diligence instead of as a worry |
| E2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Use the quote's own division of credit: "I wrote the internal integration playbook my team uses." That sentence already separates who wrote it from who uses it. Answer slot: if a disagreement or a credit question came up around it, say what happened and what you did; if none did, say so plainly and describe how you would handle it | A collegial version of the attribution probe in C2. Tagged EXP because it tests a real instance, with F4's playbook as the only quote that carries a division of credit |

### F. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over a PM who has done this for three years?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The 60-second cut of A1. Pause and restate the question. Concede in one sentence, sourced by `prohibited_claims: "Having held a product manager title or role"`: "I haven't held the product manager title." Hold the quote: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Close on the plan from A1 and stop; do not fill the silence | The same objection under a time box. Holding the A1 structure when interrupted is the skill this scores |
| F2 | "That integration work — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold through two follow-ups by returning to the quote, never by adding to it: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Answer slot: say which stages were yours alone and which were shared, in your own words; if any were not yours, say so plainly. Concede that specifically and do not fold on the core claim | The pressure delivery of C2. F1's quote is the one claim to defend, and conceding a specific stage costs less than defending all of it |

### Requirement coverage

| Requirement or responsibility (source) | Questions | Note |
|---|---|---|
| R1 "3+ years product management experience" | A1, A4, F1, D1 | The underwriter's named objection |
| R1 sub-claim: "Own the roadmap for the partner-facing API platform" | A1, A3, B2 | Acknowledge, never bridge |
| R2 "Shipped API or platform products" | A2 | |
| R3 "Technical fluency: API docs, schemas" | D2, C3 | |
| R4 "Stakeholder management across engineering, sales, customers" | D3, E1, E2, D1 | |
| R5 "Agile delivery experience" | A5 | |
| "Run discovery with integration partners" | B1, B2 | CASE only; no past claimed |
| "Write specs and drive delivery with two engineering squads" | B1, B4, E1 | |
| "Define and track adoption metrics" | B3 | |
| Headline figure: the 30+ integrations | C1, C2, F2 | Defend-the-number coverage |

## Reverse questions

The interviewer's name was not given, so these are role-generic. Their risks come from the dossier, and the first two are the underwriter's own employer questions.

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The dossier's open risk: decision authority is asserted in the JD but not evidenced. The answer is something you need before accepting, and it reads as diligence |
| RQ2 | "How is partner API adoption measured today, and what is the current baseline?" | The second open risk: adoption metrics are a named responsibility with no stated baseline. It also tells you whether B3-style questions describe a real situation |
| RQ3 | "What does this role need to have delivered by the end of its first quarter, and how would you tell?" | Turns the conversation to outcomes you can plan toward, which is where your plan from A1 lives |
| RQ4 | "How do the two squads run delivery today: cadence, planning, who sets scope?" | The honest follow-through on F6's clarify strategy: you ask how they define agile delivery instead of guessing |
| RQ5 | "Where do partner integrations get stuck today, and what feeds the roadmap now?" | Invites them to place the integration work in F1 and F5 in their own picture, without you claiming a seat in it |
| RQ6 | "What would you want to see from someone coming from outside a PM title to be confident in the hire?" | Hands the A1 objection to the interviewer to state, and their answer tells you what to emphasize in the time left. Ask it late, after RQ1 and RQ2 |

## Prohibited claims

What this pack will not coach, and why. The first three are the underwriter's `prohibited_claims`; the last two are inflated forms of your own sentences, added by this pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier `prohibited_claims` | F1's quote at its own scope, plus the sourced plain acknowledgment "I haven't held the product manager title." |
| Having owned a product roadmap | Dossier `prohibited_claims` and the `acknowledge_gap` area for the R1 sub-claim | The plain acknowledgment "I haven't owned a roadmap," then a plan said as a plan. No bridge and no slot |
| Having set prioritization for an engineering squad | Dossier `prohibited_claims` | The plain acknowledgment "I haven't set prioritization for an engineering squad," used when a follow-up presses on prioritization |
| Having shipped an API or platform product | Inflated form of F3 | F3's quote at its own scope; the limit is the pack's observation that the material shows client integrations, not a product release. A2's slot stays inside the integrations |
| Having run product discovery with partners | Inflated form of F5 | F5's quote at its own scope: roadmap-input sessions feeding client evidence to product. The slot asks only about engineering and sales contact in those sessions |

## Sources

Provided documents: tuesday-dossier.md (dossier_version 1.1, generated by job-underwriter on 2026-08-14). Sections consumed: `role_profile` (requirement and responsibility lines, standing in for the JD; its `unknowns` fed the reverse questions as analysis), `handoff_to_mock_interview` (verified evidence, weak areas with their allowed strategies, the objection, risks, employer questions, prohibited claims) and `decision` (context only). Not present in the dossier: `evidence_map`, `evidence_state` and `risk_register`, which is why F3, F4 and F5 are graded by this pack. Your message supplied the round (a 45-minute conversation with the hiring manager, Thursday).

Searches sent: "Quartzline company values", refused; "Quartzline interview process product manager", refused; "Quartzline API platform strategy news", refused. No pages fetched. Nothing about Quartzline's values, loop or strategy appears in this pack except what the dossier carries.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | The one search was refused. It would have supplied the published value names for a values bank, but no values-style round is detected, so it would have moved a values cheat sheet only if a loop source later named such a round |
| 2. `Quartzline interview process product manager` | unavailable | The search was refused. It would have checked the loop; here your own words fix the session, so persona weights rest on the hiring-manager prior |
| 3. `Quartzline API platform strategy news` | unavailable | The search was refused. It would have fed CO questions, so the pack has none, and the B bank is generic |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative Product Manager JD | skipped | The dossier's role_profile fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Web search permitted → Quartzline's published values, a documented loop and current strategy: CO questions that stop being generic, and a values bank if the loop names a values round. A deeper pass would add a grounding brief (up to 6 more searches and 2 more fetches, several more minutes)
- The interviewer's name → a reading of their public footprint, persona weights adjusted from it, and a reverse question tied to their own path
- The recruiter's prep note, if you have one → stated focus areas, or any deliverable they declared, which would get its own build section
- The current posting text → checks whether the dossier's requirement lines (generated 2026-08-14) still stand, and may turn `[inferred]` JD-tagged rows into `[grounded]` ones
- Your own answers to the answer slots in F1, F3, F4, F5 and F6 → each answer enters the fit snapshot word for word, and the rows that draw on it are regenerated
- Whatever the quarterly roadmap-input sessions produced, such as an agenda or notes → a specific artifact that could lift F5 from medium to high
- An evidence map in the dossier → F3, F4 and F5 graded by the underwriter instead of by this pack
