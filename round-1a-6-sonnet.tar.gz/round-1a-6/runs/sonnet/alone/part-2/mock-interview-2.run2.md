I'll read the reference files the skill points to before building the pack.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a6/runs/sonnet/alone/part-2/rooms/case-2-denied-7cd75dc4/atlas-freight_operations-manager_interview_pack.md`. I built it for an unknown round with flat persona weights, since you don't know who is interviewing you. It has 20 questions, a fit snapshot of the JD against your background, and six reverse questions.

My web searches on Atlas Freight were refused, so nothing in the pack comes from outside research. The company question (E2) is generic, and there is no company-values section. Pasting their values or careers page would fix that.

- **Highest-ROI prep (A1):** "You manage three supervisors; this role has twelve across four sites. What changes at that size?" The pack has you hold what your material says, concede the gap plainly, and answer with a plan.
- **Your stated gap:** the pack uses only your own words, "I've never used Power BI," and then a plan for starting. It doesn't coach any claim of Power BI experience.
- **The 40% mis-pick figure:** you'll likely be asked how it was counted. "I don't know exactly" is an honest answer, and the pack says so.
- **Years of leadership:** the pack avoids calling your seven years "operations leadership." The JD requires 5+ years of leadership, so count how many of your seven you actually led people.

Say the word and I'll play the skeptical interviewer on A1 and give feedback against that question's guidance.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Who are you meeting next week (a recruiter, your would-be manager, a peer, an executive or a panel), and did anyone say what it will focus on or ask you to prepare something?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Operations Manager, Atlas Freight: interview prep pack

- Role: Operations Manager, Atlas Freight
- Interviewer and relationship: not given
- Built for an unknown round, so persona weights are flat. That makes this pack noticeably weaker than one built for a known round; the upgrade menu says what fixes it.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether the claims in your background survive scrutiny, and what was actually you |
| JD | Whether you can do the job as the posting lists it, including its gaps |
| CO | How much you know about the company and its direction |
| CASE | Structure and reasoning on a live problem from the role |

Question IDs run by persona: A, B, C, D, E, G. The letter F is skipped so a question never collides with a fit-snapshot row (F1 to F7). No published company values were available, so the Values/Behavioral bank is tagged EXP or JD, not VAL.

## Prep triage

Sized to a week. If you have less, stop after item 3. Everything else is insurance.

1. A1, out loud, with both follow-ups, until the concession sounds boring. This is the highest-ROI prep in the pack.
2. C1, C3 and D1: settle what you actually know about how the 40% was counted, and rehearse "I don't know exactly" if that is the truth.
3. A2, A3 and D3: one plain sentence on Power BI, then how you would start learning it.
4. A4: work out how many of your seven years you led people.
5. B1 and B2: say the case structures aloud once each.
6. E1: time your 90-second arc.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD, your message | "currently a senior shift manager over 3 supervisors" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material shows a shift managed and a site's surge plan run, which is adjacent to this line and does not show four sites; that limit is the pack's observation. Words stay at the quotes' scope: "I'm currently a senior shift manager over 3 supervisors." Answer slot: expect a probe on how far your ownership reaches. Say which decisions on your shift and in the surge plan were yours to make; if a decision was someone else's, or there was no such decision, say so plainly and stay with the shift and the plan |
| F2 | "drive on-time performance and cost-per-shipment down" — JD, your message | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Your material gives an accuracy result from a redesign, which is adjacent to this line and reaches neither measure it names; that is the pack's observation. Words: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot, in your own words: how the 40% was counted, what it is sensitive to, the assumption behind it you would defend least, and which part of the redesign was yours; "I don't know how it was counted" is an honest branch |
| F3 | "lead a team of 12 supervisors" — JD, your message | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | The quote carries three supervisors against the JD's twelve; the gap is one of scale, stated here as the pack's observation. Words: "I'm a senior shift manager over 3 supervisors." Answer slot: if the number of people you led was ever different from three, say when and how many; if not, say so plainly and stay with the three, then say how you would approach a larger team as a plan, never as a past |
| F4 | "build reporting in Excel/Power BI" (Excel half) — JD, your message | "solid Excel" — your message | low | [inferred] | discovery | A self-assessment that touches the line and does not show what you make with it. Words: "My Excel is solid." Answer slot: say what you use Excel for, in your own words; if others read what you make, say who; if it is for your own use, say so plainly |
| F5 | "build reporting in Excel/Power BI" (Power BI half) — JD, your message | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used Power BI." Then how you would start learning it, said as a plan and never as a past. Nothing is added to make the gap feel smaller |
| F6 | "5+ years operations leadership required" — JD, your message | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | The quotes show seven years in the field and a current leadership role, and do not show how many of the seven years were leading people. The JD marks the line required, so treat it as a risk to settle in your own words rather than a gate. Answer slot: give your own count of the years you led people and the role; if fewer than five, say so plainly and say what you led |
| F7 | "Lean/Six Sigma a plus" — JD, your message | "green belt certified" — your message | medium | [grounded] | none | The quote already reaches the line. Lead with it in its own terms: "I'm green belt certified." Nothing inspected sits behind it, so expect a probe. Answer slot: if asked where you have used it, say where; if you have not used it in your work, say so plainly |

## Persona table

Weights are flat: no interviewer, round type or loop source was given, so none can tilt them, and the pack falls back to the generic archetype (screen, hiring manager, panel). Banks are ordered by where your material is thinnest, not by a weight.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Quiet, persistent probing of span, tools and years | Equal prior. F1, F3 and F5 sit furthest from the JD's lines, so this style has the most to press on | Rehearse A1 until it is boring; bridges only from the quotes in F1 and F3; the limit said plainly |
| Case/Strategist (B) | Live problems on on-time performance, cost and peak | Equal prior. The JD's own lines are measures, so a live problem on them is natural | Clarify, objective, segment, approach, metrics, risks; think aloud; challenge one premise |
| Data-Driven Prober (C) | Line-by-line questions on the 40% | Equal prior. F2 holds the only figure in your material, and figures draw this style | Know what you can and cannot say about how the figure was counted; name the weakest assumption before they do |
| Pressure (D) | Interruptions, time-boxing, "how much was you" | Equal prior. The same figure and the span gap are what this style tests | Pause, restate, hold two follow-ups, then concede one specific thing |
| Conversational (E) | Friendly biography and company questions that are still scored | Equal prior. Every round has some of this | A 90-second arc from your own sentences; treat casual questions about the JD's topics as scored |
| Values/Behavioral (G) | Story prompts on candor, team change and customers | Equal prior. No loop source or published values were available, so no values round is detected | Choose stories where the hard truth landed; if none comes to mind, say so plainly |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You currently manage three supervisors; this role has twelve across four sites. What changes at that size?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI rehearsal in this pack. Hold what the quote carries: "I'm a senior shift manager over 3 supervisors." Concede the specific gap in plain words: twelve supervisors across four sites is a bigger span than that sentence covers. Then answer "what changes" as a plan, not a past: say what you would want to learn first about each site and each supervisor, and how you would spend your first weeks, in your own words; this pack supplies no method. Follow-up 1, "have you led more than that": if the number you led was ever different from three, say when and how many; if not, say so plainly and return to the three. Follow-up 2, "so we'd be taking a chance": concede the step is real, return to the three and to your plan, and reach for no bigger claim | F1 and F3 sit furthest from the JD's own lines, so a skeptic starts here; JD because it scores the stated team and site requirements |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "never used Power BI" | Name the JD line your own material carries least, plainly, then the plan. One honest option is already yours: "I've never used Power BI." Follow with how you would start learning it, as intent in your own words. If another line is weaker for you, name that one instead; never name a weakness you do not hold to look humble | F5 is a stated gap and this question invites it; F1 and F3 are the other likely answers. JD because it scores fit against the posting |
| A3 | "The role asks for reporting in Excel and Power BI. Where are you with each?" | JD | [grounded] "solid Excel"; "never used Power BI" | Say both halves in one breath so neither sounds hidden. Excel: "My Excel is solid." Answer slot: say what you use Excel for, in your own words; if others read what you make, say who; if it is for your own use, say so plainly. Power BI: "I've never used Power BI." Then how you would start, as intent and in your own words | F4 and F5 split one JD line into two halves, and each half has a different honest answer |
| A4 | "The posting asks for five or more years of operations leadership. How many of your seven years were leading people?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Hold the sentence at its scope: "I have 7 years in warehouse and distribution ops." Answer slot: give your own count of the years you led people and in what role; if it is fewer than five, say so plainly and say what you led. Do not fold the seven into a leadership figure; the quote says seven years in the field | F6 sets a required line against a quote that does not say how many years were leadership, and this question tests exactly that |

### B. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance has slipped at two of the four terminals this month. How do you diagnose it?" | CASE | [generic] | A live problem, so the guidance makes no claim about your past. Clarify first: how on-time is defined and measured, over what window, and what changed. Then state the objective, segment the problem (by site, lane, shift, customer, cause of delay), form two or three hypotheses, say which data tests each fastest, name the metrics you would watch and the risk of acting too early. Think aloud and challenge one premise respectfully, such as whether two sites slipping together points to something shared. Stop at about 90 seconds | F2 names the measures this case exercises; CASE because it is a live problem on the role's own measure |
| B2 | "You're asked to take cost-per-shipment down without letting on-time performance slip. Where do you look first, and what do you give up?" | CASE | [generic] | Confirm the target for each measure before structuring; the JD's wording, "drive on-time performance and cost-per-shipment down", can be read two ways for the first measure. Then clarify how cost-per-shipment is built and which costs the role controls, segment it, look first where the most cost sits, and name the trade-off out loud. Say what you would test before committing to a change | F2 again, as a trade-off rather than a diagnosis; CASE because the answer is a structured decision |
| B3 | "Peak season is six weeks out and the forecast is well above last year. What do you do in your first week?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Story-mapped on the quote: "I ran the site's peak-season surge plan two years running." Those are the beats it states, told in your own words. If the interviewer asks for more than those beats, answer from what actually happened, or say plainly that you do not remember or it was not yours. Then structure the hypothetical as a plan: what you would ask first about the forecast, capacity, labour and customer commitments, what you would decide first, and what you would check each week | F1 holds the surge plan, the nearest material to daily operations; CASE because it is asked as a live problem, EXP in delivery |
| B4 | "You inherit four sites that each report performance their own way. What do you do first?" | CASE | [grounded] "never used Power BI" | A live problem, so no claim about your past. Clarify what each site reports, to whom and how often; agree definitions before building anything; decide what goes in a first version and who must be consulted; say how you would show the result. If the answer points to Power BI, say "I've never used Power BI" and where you would start, as a plan, rather than implying experience | F4 and F5 are the reporting line; CASE because it asks how you would set it up, not what you have done |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say the sentence at its own scope: "I cut mis-pick rate 40% by redesigning the pick path." Then the four slots, each in your own words: how the 40% was counted; what it is sensitive to; the assumption behind it you would defend least, named before they ask; which part was yours. If you do not know how it was counted, say so plainly; that is stronger than a method you cannot repeat under a second question. Give before and after figures only if you have them | F2 holds the only figure in your material; Prober because it asks for the denominator |
| C2 | "What exactly did you change in the pick path, and what did you leave alone?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Anchor on the quote's own words: you redesigned the pick path. Answer slot: describe the change as it actually was, in your own words; if a team, a vendor or your manager shaped part of it, say which part; if you do not remember a detail, say so rather than reconstruct it. This pack adds no further beats | F2's redesign is the claim behind the figure, and a prober tests it for substance; EXP because it asks what was actually done |
| C3 | "Was anything else changing while the new pick path went in?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | This is the question that finds the weakest assumption, so name yours before they do. If something else changed, say what and whether you separated its effect; if nothing else changed, or you did not separate the effects, say so plainly. Claim no cleaner attribution than you can repeat | F2 attribution; EXP because it scores precise honesty about causes |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That result — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold: "I cut mis-pick rate 40% by redesigning the pick path." Hold it through the first follow-up. Then concede specifically where the sentence leaves it open: say which parts were yours and which were others', in your own words; if you cannot separate them, say so. Never fold on the core to restore harmony, and never widen it | F2 is the claim a pressure interviewer tests for attribution; EXP because it scores what was actually yours |
| D2 | "Sixty seconds: why you over a candidate who already runs several sites?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "ran the site's peak-season surge plan two years running"; "green belt certified" | Three beats, one breath each: "I'm a senior shift manager over 3 supervisors." "I ran the site's peak-season surge plan two years running." "I'm green belt certified." Do not compare yourself to the other candidate's record; you cannot state it. Concede once, specifically: your span today is smaller than the role's. Then stop; the pause is part of the test | F1, F3 and F7 supply what can be said; JD because it scores fit, in a time-boxed pressure delivery |
| D3 | "You've never used Power BI and we need reporting from the first month. Is this the wrong hire?" | JD | [grounded] "never used Power BI"; "solid Excel" | Pause and restate the point in your words. Say "I've never used Power BI" without hedging, and "My Excel is solid." Do not accept "first month" as given if it is news to you; ask what the first reports would be, then say how you would start learning, as a plan. Concede that the gap is real; promise no date you cannot back | F5 is the stated gap this question presses; JD because it scores the reporting line |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "ran the site's peak-season surge plan two years running"; "green belt certified" | A 90-second arc built only from these sentences: the seven years in warehouse and distribution ops, where you are now, the surge plan, the green belt. Tell it as a line, not a list. Why this role, and why now, is yours to say in your own words; this pack supplies no reason. Close on why Atlas Freight in one sentence, and stop | F1, F3, F6 and F7 are the pool; EXP because the biography question is scored on what you actually did |
| E2 | "What do you know about Atlas Freight, and where do you think we're headed?" | CO | [generic] | This pack could not research Atlas Freight, so it holds nothing on its strategy, and borrowing a same-named company's would be worse. Before the interview, read the company's own site, its careers page and recent news, and note where each fact came from. In the room, say what you found and where you found it; if you found little, say so plainly and start from what your own JD gives you. Then turn it into a question about priorities | Company knowledge is scored in casual registers too; generic because the research was unavailable, and the upgrade menu says what fixes that |
| E3 | "You're green belt certified. Tell me about that." | JD | [grounded] "green belt certified" | Lead in the quote's own terms: "I'm green belt certified." Say what the certification was and what it covered, in your own words. Answer slot: if asked where you have used it, say where; if you have not used it in your work, say so plainly. Do not stretch "green belt" into a method or title the quote does not name | F7 is the one row where the quote already reaches the JD's plus; JD because it scores the stated plus |

### G. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to a manager or someone senior." | EXP | [generic] | A selection scaffold. Pick a time with a named stake, a moment you said the hard thing, and a relationship still intact afterwards; say what was true, to whom, what you said and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | A stock Values stem from the persona model; it carries no claim about this company and no row of your material |
| G2 | "Tell me about a time you had to change how a team of supervisors worked." | JD | [generic] | A selection scaffold. Pick a time you changed a routine or standard with people who reported to you; say what it was, who pushed back, how you handled it and what stuck. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would approach it | F3's team line is the raising source; JD because it scores the leadership requirement |
| G3 | "When did you put a customer ahead of an internal metric?" | EXP | [generic] | A selection scaffold. Pick a time with a named customer need, the metric it cost, and what you decided and why. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would decide | A stock Values stem from the persona model; carries no claim about your past |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| "Own daily terminal operations across 4 sites" | A1, B1, B3, D2 |
| "drive on-time performance and cost-per-shipment down" | B1, B2 |
| "lead a team of 12 supervisors" | A1, G2 |
| "build reporting in Excel/Power BI" | A2, A3, B4, D3 |
| "5+ years operations leadership required" | A4, E1 |
| "Lean/Six Sigma a plus" | D2, E3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "How are on-time performance and cost-per-shipment defined and reported across the four sites today, and who owns the numbers?" | It shows you define a measure before you try to move it, and the answer tells you what B1 and B2 should look like here |
| 2 | "What does reporting look like today, and what would you want built first?" | It gets you the real scope of the Excel and Power BI line (F4, F5) before you promise anything on it |
| 3 | "Of the twelve supervisors, how long have they been in role, and how are they developed today?" | It shows you think about the team as people with different needs, and it speaks to the span gap in F3 |
| 4 | "How do the four sites differ in volume, equipment or customer mix, and where is the biggest performance gap?" | It surfaces the site-by-site differences behind F1 and shows you plan to learn them first |
| 5 | "How is peak handled here, and who owns the surge plan today?" | It gives you a natural place to bring in the surge-plan quote from F1 once you hear how peak runs |
| 6 | "What would make you say in six months that this hire was the right one?" | It turns the interview into a statement of the manager's own bar, which you can then rehearse against |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned daily terminal operations across four sites | Inflated form of F1 | F1's quotes at their own scope: "currently a senior shift manager over 3 supervisors"; "ran the site's peak-season surge plan two years running". The limit is the pack's observation: the material says a shift and a site's surge plan, not four sites. Slots stay inside the shift and the plan |
| Led a team of twelve supervisors | Inflated form of F3 | F3's quote at its own scope: "currently a senior shift manager over 3 supervisors". A1's slot asks only whether the number you led was ever different from three |
| Drove on-time performance and cost-per-shipment down | Inflated form of F2 | F2's quote at its own scope: "cut mis-pick rate 40% by redesigning the pick path". The material shows an accuracy result and neither measure; C1 to C3 and D1 stay inside the redesign and the figure |
| Built reporting in Excel | Inflated form of F4 | F4's quote at its own scope: "solid Excel". A3's slot asks only what you use Excel for |
| Has used Power BI | Negative you stated, F5 | The plain acknowledgment F5 gives: "I've never used Power BI." No slot, only a plan for starting |
| Seven years of operations leadership | Inflated form of F6 | F6's quote at its own scope: "7 years in warehouse and distribution ops". The material does not say how many of the seven years were leadership; A4's slot is your own count |

## Sources

Provided documents: your message, containing the JD text and your background. No dossier was supplied.

Searches sent, all refused, so nothing from the web is in this pack:

- "Atlas Freight regional logistics company values" — refused
- "Atlas Freight interview process operations manager" — refused
- "Atlas Freight regional logistics strategy news" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Every call was refused. It would have fed a values cheat sheet and VAL questions; neither is in this pack |
| 2. `Atlas Freight interview process operations manager` | unavailable | Every call was refused. It would have fed the loop structure and the persona weights, which are flat instead |
| 3. `Atlas Freight strategy` / recent news | unavailable | Every call was refused. It would have fed company-specific CO and CASE questions; E2 is generic instead |
| 4. `interviewer name Atlas Freight` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Operations Manager` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Who you are meeting and the round type → persona weights replace the flat ones, plus an interviewer read and a reverse question tied to their path
- The recruiter's notes, if any, on focus areas or anything to prepare → coverage of a pre-declared deliverable and a sharper bank
- Your own answers to the answer slots in F1, F2, F3, F4, F6 and F7 → those rows gain quoted evidence, and A1, A3, A4, C1 to C3, D1 and E3 regenerate from it
- The green belt certificate's issuing body and level → F7 moves from medium toward high
- The site scorecard or accuracy report behind the 40% → F2 moves from medium toward high, and C1 can name what the figure was counted against
- Atlas Freight's values or careers page pasted in, or web search allowed → a values cheat sheet and company-specific questions, none of which are in this pack
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a strategy brief behind the CO and CASE banks; offered once
- A tuesday-dossier.md → verified evidence and prohibited claims in place of the ones this pack built locally
