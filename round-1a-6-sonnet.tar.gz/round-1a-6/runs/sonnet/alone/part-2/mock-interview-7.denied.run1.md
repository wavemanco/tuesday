I'll start by reading the reference files the skill points to.
I've saved the pack and am writing up the hand-off now.

Your prep pack is saved as `saltmarsh-games_live-operations-producer_interview_pack.md` in the working directory. It has 21 questions across seven interviewer styles, plus a fit snapshot, reverse questions and a list of claims it won't coach.

**Assumptions and gaps:**
- **Interviewer role:** I assumed Tobias is your future manager, so the pack leans on a Skeptic and a Case/Strategist.
- **Blocked research:** All four web searches (values, interview process, strategy, Tobias) were refused in this session. Nothing about Saltmarsh or Tobias comes from outside your message, and there are no company-specific or strategy questions.
- **Highest-ROI prep:** A1, "You haven't worked on a game with in-app purchases." The pack has you say that gap plainly and then give a plan for getting up to speed.
- **Where the pack stays at your own scope:** The JD says live events, two titles and post-event KPIs. Your material says a weekly content-drop calendar for one main title and a monthly retention presentation. Those rows carry answer slots, so you say what you actually did or say plainly it wasn't yours.

Say the word and I'll play the Skeptic on A1.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the person you'd report to, and did the recruiter mention any format or exercise for the hour? The answer reweights the banks.
If you can allow web search or paste in Saltmarsh's values and careers pages, I'll rebuild the company-specific sections. Can you do either?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

Candidate: Femi. Interviewer: Tobias Wrenfield, Head of Live Operations. Round: 60 minutes, Friday. Relationship: assumed hiring manager (you did not say who you report to if hired). If that is wrong, the persona weights below change.

## How to use this pack

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did.

An answer slot is an instruction for the interview, not a question for you now. It names what an interviewer is likely to probe and gives two honest branches: say what you did, or say plainly it was not so or not yours and return to what your own words already carry.

Type key:

| Tag | Meaning |
|---|---|
| VAL | Whether past behavior shows how you work with others, not generic virtue |
| EXP | Whether your own claims survive scrutiny; what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Knowledge of the company and its strategy (none in this pack, see Sources) |
| CASE | A live problem from the role, reasoned aloud |

## Fit snapshot

Requirements are quoted from the JD you pasted. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title, not a live-events calendar and not two titles, and the words stay there: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's live-events line makes a probe on events likely. If any of the drops were time-limited events, say which and what that changed in how you planned; if all were regular drops, say so plainly. Likewise, if you ever planned around a second title, say how; if you did not, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | low | [inferred] | discovery | The quote touches coordination only if the calendar needed other teams, and your material does not show that. Answer slot: the JD names four teams, so expect a probe on which of them you worked with on a drop. Name those you actually worked with, in your own words; if the drops did not involve any of them directly, or someone else did that coordination, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says a monthly presentation of retention numbers, not a review after an event and not a choice of which KPIs were reported. The words stay at that scope: "Presented the monthly retention numbers to the studio head." Answer slot: if any of those monthly presentations looked at what a particular update or event did, say what; if none did, or you did not choose what was reported, say so plainly and stay with the presentation |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap in the quote's own terms, but a claim with no checklist inspected behind it, so expect a probe. Lead with the two facts the quote carries: you wrote it, and your QA team still uses it. Answer slot: if you are asked whether you ran it at each release, say what you did; if you wrote it and others ran it, say that |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | medium | [grounded] | discovery | The quote gives four years as an associate producer, which is above the stated number on its face. It does not show whether the title was run as a live service. Answer slot: the JD says live-service, so expect a probe on what kept the game live. Say in your own words what that was; if it was not run as a live service, say so plainly and stay with the calendar you ran |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap. Lead with the quote's own terms: weekly, your main title, two years. A named cadence and duration beat an adjective. Expect a probe on it because nothing is inspected behind it |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | presentation | Reword only the quote: "I presented the monthly retention numbers to the studio head." It does not say who produced the numbers, how they were counted, or what was done with them, so those are slots in C1 |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | Reword only the quote: "I wrote the release checklist our QA team still uses." Say it as a document others still work from, and leave the word clear to the interviewer |
| F9 | Familiarity with in-app purchases in mobile live events (a role-family requirement, not in the JD) | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [generic] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Never a claim to in-app purchase work, and nothing added to make the gap feel smaller |

No row is a gate: the JD's "3+ years" is an experience length, which is graded like any other row (F5). Nothing in the JD is a licence, location, pay or schedule term, so no gate row appears.

## Persona table

Weights rest on the hiring-manager prior plus what the JD and your stated gaps show. No source I could read documents this company's loop, so I fell back to a generic loop with flat tilt beyond that, and I say so. Nothing about Tobias is used beyond the title you gave me.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet probing of what the background lacks | High. The hiring-manager prior puts it first, and you have stated two gaps yourself (F9). The JD asks for 3+ years of live-service production (F5) | Rehearse A1 until it is boring. Say the gap plainly first, then the quote that limits it: "I ran the weekly content-drop calendar for our main title for the last two years." |
| B. Case / Strategist | Live problems from the actual role: plan this, diagnose that | High. The hiring-manager prior; the JD is a planning and review role | Clarify, then objective, segments, approach, metrics, risks. Think aloud, challenge one premise politely |
| C. Data-Driven Prober | Asks how a number was counted and what it assumes | Medium. The JD names retention metrics and KPIs, and your one metrics claim is a presentation (F7) | Know what you can and cannot say about how the numbers were counted. Say plainly what you do not know |
| D. Conversational | Friendly opener, unstructured questions | Medium. Most 60-minute interviews open this way; the casual questions are still scored | A 90-second arc built only from your four quoted sentences (D1) |
| E. Pressure | Interrupts, time-boxes, questions attribution | Low. Nothing in the material signals it, but attribution probes ("how much was you") turn up in any register | Hold through two follow-ups by returning to your quote, concede the specific limit, never fold the core claim |
| F. Peer Evaluator | Seam-splitting between teams | Low. Tobias heads the function, so he is not a peer; a design or engineering lead could appear in the loop, which no source I could read establishes | Propose seam principles, not a map you do not know; offer what you bring their team |
| G. Values / Behavioral | Scenario probes on how you work | Low. No source I could read documents a values round, so none is detected, and the fallback archetype for an unestablished loop (generic) assumes none | Pick a real instance, or say plainly none comes to mind, then give the nearest thing your material carries |

## Question banks

Ordered by weight. Highest-ROI prep in the pack: A1, because it goes straight at the gap you named yourself and it will be asked in some form.

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't worked on a game with in-app purchases. How do you get up to speed on how live events and revenue connect?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "Presented the monthly retention numbers to the studio head." | Hold then concede. Open with your plain acknowledgment: "I've never worked on a game with in-app purchases." Then what your material does carry, at its own scope: "Presented the monthly retention numbers to the studio head." Then a plan, said as a plan: name two or three things you would ask to see in your first weeks, in your own words. Follow-up one will press on the gap: hold by repeating the acknowledgment, no hedging, and do not widen the retention sentence. Follow-up two will ask what worries you most: name the one piece you would be slowest on, in your own words. Never imply you have done this work | The highest-ROI prep. F9 is where the material is thinnest and the one gap you stated, so some version of this arrives. JD because it scores a requirement of the role; Skeptic delivery because it presses a gap |
| A2 | "You've never led a team. This role coordinates design, art, engineering and community on every update. How do you get people you don't manage to deliver?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." | Acknowledge first: "I've never led a team." Then the calendar sentence at its scope. Answer slot: if running the calendar meant asking people outside your own team to commit to dates, say how, in your own words; if the dates were set by someone else, or you did not ask others for them, say so plainly and stay with the calendar. Then say how you would do it here as a plan: agree dates and owners early, and say when you would raise a slip with Tobias | F2 is the weakest-evidenced coordination row, and coordination without authority is the usual probe on it. JD because it tests the stated duty |
| A3 | "Your calendar was for one title. We run two. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | The sentence at its scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if you ever planned around a second title or had to trade one title's drops against another's, say what happened; if you did not, say so plainly. Then what you would do about two titles as a plan: what you would ask for in the first week | F1: the JD says two titles and your sentence says one main title. JD because it scores that line |
| A4 | "A weekly drop calendar isn't a live-events calendar. Where do they differ, and what have you done?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Concede what the JD line says and your sentence does not: your sentence says drops. Answer slot: if any of your drops were time-limited events, say which and what that changed in how you planned; if they were all regular drops, say so plainly. Do not describe event planning you did not do | F1's gap, the likeliest follow-up to A3. JD because it tests the stated duty |
| A5 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Choose one, say it first, and give a ramp. Pick from what you have stated yourself or from the slots in F1 to F3, whichever is truly the weakest. Avoid a weakness that is a strength in disguise: it reads as dodging. If you pick the in-app purchase gap, you already have A1's words | A standard Skeptic stem; rehearsed because most candidates hedge it. JD because it is scored against the posting |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have one open slot on the events calendar next month across two titles. How do you decide what goes in it, and what do you need to know first?" | CASE | [generic] | Clarify first: what the slot is for, how each title is doing, what engineering can deliver, what is already booked. Then objective, the options for the slot, how you would compare them, the metrics you would watch, the risks. Think aloud and challenge one premise politely | F1's requirement as a live problem. A pattern for the problem, not a fact about this company |
| B2 | "An event ended Sunday. Retention for players who joined during it looks weaker than usual. Diagnose it." | CASE | [generic] | Clarify the definitions and the comparison first. Then split by cohort, check what else changed that week, and say what you would look at and in what order. Close with what would change your mind, and what you cannot know from the numbers alone | F3's post-event review, set as a diagnosis. Generic: no claim about your past |
| B3 | "Design, art, engineering and community each tell you their piece of next week's update will be a day late. What do you do?" | CASE | [generic] | Ask what is actually slipping and what depends on it, and whether the date or the scope is fixed. Then lay out options such as cutting scope or moving the date, who decides, how you tell the teams, and what you record afterwards | F2's coordination, set as a decision. Generic |
| B4 | "What do you want on the release checklist before an update goes live, and what do you do when QA and the calendar disagree?" | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Start from your own sentence at its scope: you wrote it, and your QA team still uses it. Answer slot: if you are asked what is on it or why an item is there, say what you actually know; if an item was inherited or you do not remember the reason, say so plainly. Then structure the disagreement: what each side is protecting, what is non-negotiable, who decides, how it gets recorded | F4's claim, rehearsed as a decision. Expect an interviewer who hired for this line to test it |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You presented the monthly retention numbers to the studio head. Walk me through how those numbers were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot, four parts in your own words: which retention measure it was, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you also produced the numbers, say so; if someone else did, say that plainly. If you do not know how a figure was counted, say so plainly rather than guess. Stay at the sentence's scope | F7's only claim, and the prober's usual target. EXP because it tests what was yours |
| C2 | "Retention for one cohort rose after an event. How would you know the event caused it?" | JD | [generic] | Name what else could explain it, what comparison you would want, and what you could and could not conclude from the numbers. Name the assumption you would defend least before they do | Retention metrics (F7) set as a reasoning problem. Generic |
| C3 | "Which two KPIs would you put at the top of a post-event review, and why?" | JD | [generic] | Tie each KPI to a decision it would change, and say what the event was meant to do first. Say plainly that you would check the studio's own definitions in week one. Do not describe a review you ran unless your own words in F3 carry it | F3's KPI line. Generic: a pattern for the problem |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey. How did you get here?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc with four beats, each a clause your sentences carry: four years as an associate producer at a puzzle-game studio, the weekly content-drop calendar for your main title for two years, the release checklist your QA team still uses, the monthly retention numbers presented to the studio head. Answer slot: say in your own words why live operations and why Saltmarsh. Nothing here supplies a reason | The standard opener; casual but scored. EXP because it checks that your four sentences hang together |
| D2 | "Tell me about the release checklist your QA team still uses." | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Two facts the sentence carries: you wrote it, and your QA team still uses it. Answer slot: if you are asked how it started or what it replaced, say so in your own words; if there was nothing before it, or you do not remember, say so plainly. Let the interviewer decide how clear it is | F4 and F8: the one artifact in your material others still work from |
| D3 | "What are you actually playing with in live ops these days?" | JD | [generic] | Name games you really play or follow, and one real event you noticed and what you made of it. Use only what you actually saw; if there is none, say what you do watch and why. The question is casual and scored | The JD's live-events focus, asked casually. Generic |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has run live events with in-app purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Never led a team, and never worked on a game with in-app purchases." | Pause, restate the question. Hold on the sentence your material carries: "I ran the weekly content-drop calendar for our main title for the last two years." Concede the specific limit: "I've never worked on a game with in-app purchases." Hold through two follow-ups by returning to the calendar; do not add to it. End with what you would do in the first weeks, as a plan | F5 and F9 together, in the time-boxed register |
| E2 | "That release checklist. How much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Answer slot: if QA or others contributed, say who and what; if it was entirely yours, say that. Return to the sentence through two follow-ups: you wrote it, and your QA team still uses it | F4's attribution probe, the one a pressure interviewer uses on any claimed document |

### F. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Live ops and engineering sit side by side. Where is the seam, and what happens when we disagree?" | CASE | [generic] | Offer principles, not a map you do not know: who owns the date, who owns the scope, how disagreement gets escalated and recorded. Then reciprocity: what you bring the engineering team, such as a clear calendar and early notice | F2's coordination from the peer's side. Generic |
| F2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time work of yours crossed teams, where credit could have gone either way, and how you handled it. If no such time comes to mind, say so plainly, then say how you would handle it | A standard peer stem; scored for tact and spine. Generic |

### G. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not soften it, and a working relationship intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard values stem; no source I could read names this company's values |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time with a real trade-off, the metric you gave up, and what you decided. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Same as G1. In a live-ops role the customer is the player, which the interviewer may say aloud |

### Requirement coverage

| JD requirement | Question IDs |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A3, A4, B1, D1 |
| "coordinate design, art, engineering and community teams on each update" | A2, B3, F1, F2 |
| "own the post-event review and the KPIs it reports" | B2, C2, C3 |
| "manage the release checklist with QA" | B4, D2, E2 |
| "3+ years producing live-service games or apps" | D1, E1 |
| "experience running a content calendar" | A3, A4, D1 |
| "comfortable with player-retention metrics" | C1, C2, C3 |
| "clear written communication" | D2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Of the two titles, where does the events calendar most need help over the next quarter?" | It shows you think at the calendar level, and it tells you which title to learn first |
| R2 | "How do the two titles earn revenue, and which of those numbers sit in the post-event review?" | It turns your stated gap into a day-one learning question instead of a worry, and you get the answer a prober would otherwise test |
| R3 | "What does QA's role in the release checklist look like today, and what would you want changed?" | It ties to the one artifact you have written and shows you would work with the process rather than replace it |
| R4 | "When design, art, engineering and community disagree about an update's date, who decides?" | It asks the authority question A2 raises, and the answer tells you how much of the job is persuasion |
| R5 | "Is there a post-event review you would point me to as the standard you want?" | It asks for a concrete example of the work you would own, which a prepared candidate does and a generic one does not |
| R6 | "What would a strong first 90 days look like, and how would you know I was on track?" | It asks for the scoring sheet directly and shows you plan to be measured |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has worked on a game with in-app purchases | Negative you stated, F9 | "I've never worked on a game with in-app purchases." No slot; the ramp is a plan |
| Has led a team | Negative you stated, F9 | "I've never led a team." The calendar sentence at its own scope. A2's slot asks only about asking others for dates |
| Ran a live-events calendar for two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says a weekly content-drop calendar for your main title |
| Owned post-event reviews and the KPIs they report | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says a monthly presentation of retention numbers |
| Produced or analysed the retention numbers | Inflated form of F7 | F7's quote at its own scope. C1's slot asks only which part was yours |
| Managed each release with QA | Inflated form of F4 | F4's quote at its own scope: you wrote it, and your QA team still uses it |

## Sources

Provided documents: the JD text and your background, both from your message. No dossier was consumed.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Query "Saltmarsh Games values" was refused. It would have fed a values cheat sheet; none is built, and no values round is detected in any case |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | Query refused. It would have named the loop's rounds; persona weights rest on the hiring-manager prior and the generic fallback instead |
| 3. `Saltmarsh Games mobile studio strategy news` | unavailable | Query refused. It would have fed a CO or CASE question on current strategy; none is in this pack |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Query refused. It would have fed an interviewer read and one tailored reverse question; both are absent |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

Nothing about the company or Tobias in this pack comes from outside your message. The company name and role come from you.

## Upgrade menu

- Search access, or the company's values page and careers or interview page pasted in → a CO question on current strategy, loop structure in place of the generic fallback, a values sheet if a values round turns up, and persona weights read from the documented loop
- Tobias's profile or a link to anything he has written or said publicly → an interviewer read and a reverse question tied to his own path
- Your answers to the slots in F1, F2, F3 and F5 (event versus regular drops, a second title, which teams you worked with, whether the monthly presentations looked at specific updates, what kept the game live) → those rows become quoted evidence and A2, A3, A4, B4, C1 and D1 get story-mapped guidance
- Your release checklist or a sample monthly retention deck → F4, F7 and F8 can rise from medium to high, since those are the artifacts that field keeps
- The recruiter's email on format, and whether any exercise or presentation is expected → a build section for it, and persona weights for the actual rounds
- A deeper research pass, if search is allowed: up to 6 more searches and 2 more fetches, several more minutes → a strategy grounding brief and loop reports from candidates
- Hours you have before Friday → a prioritised schedule of the questions to rehearse first
- A tuesday-dossier.md from an earlier engagement → verified evidence in place of the quotes above, and a stated strategy for each weak area
