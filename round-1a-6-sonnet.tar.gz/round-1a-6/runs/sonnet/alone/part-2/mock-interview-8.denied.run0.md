I'll read the reference files the skill points to before building the pack.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a6/runs/sonnet/alone/part-2/rooms/case-8-denied-3e449c2f/ashgrove-credit-union_member-experience-lead_interview_pack.md`. It's a loop pack: one shared fit snapshot, then a mini-pack for each of the three rounds on 5 December. It rests on the JD, the four values, the recruiter's email, your four-point strategy summary and your background note. I did no web research, because your material already covered each target. No interviewers are named yet, so there's no interviewer read.

I'll play the Head of Member Services on C1, the contact-centre objection. The pack names it as the highest-ROI prep. I can also run the round 3 escalation case live.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Do you have your CV text to paste? It would upgrade several fit rows, and I'll proceed without it.
How many hours can you give this before 5 December? That sizes a prep schedule.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Date of loop:** 5 December 2026 (prepared 26 November 2026)
**Mode:** Loop, three rounds, one shared fit snapshot and a mini-pack per round

| Round | Who | Length | Shape |
|---|---|---|---|
| 1 | The recruiter | 30 min | Screen |
| 2 | Head of Member Services, who would be your manager | 45 min | Mostly behavioural |
| 3 | Panel of two branch managers | 60 min | 20-minute complaint-escalation case, plus the values round scored against the four values |

No interviewer has been named, so there is no interviewer read. Round 3's panel is described by role only.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is scored.
- Type key: **VAL** = behaviour against the published values. **EXP** = whether your experience survives scrutiny. **JD** = a requirement in the job description. **CO** = knowledge of Ashgrove and its strategy. **CASE** = a live problem from the role.
- Provenance: `[grounded]` traces to something you supplied. `[inferred]` is derived from an adjacent source. `[generic]` is a pattern with no claim about you or Ashgrove.
- **Answer slot** = an instruction for the interview, not a question for you now. Answer it truthfully either way. "I wasn't involved in that" is a good answer.
- Guidance is scaffolding, not a script. Say it in your own words and add nothing your own sentences do not carry.
- The highest-ROI prep in the whole pack is **C1**, the contact-centre objection. It will be asked in some form in rounds 1, 2 and probably 3.

## The fit snapshot (shared by all three rounds)

No requirement in the JD is a gate. A gate is a term you meet or do not, such as a licence or a legal bar. Every requirement here is experience or skill, so each is graded on evidence and gap type.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says one branch's log, not the process end to end, with nothing inspected behind it. The words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what came before and after the log likely. If any of that was yours, say which part and what you did, in your own words; if nothing before or after the log was yours, say so plainly and stay with the log |
| F2 | "the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | Your material says a monthly spreadsheet your regional manager uses, not what it counted. The words stay at that: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names volumes and resolution times, so expect a probe on what the spreadsheet counted. If it counted either, say which, how it was counted and which assumption you would defend least; if it counted something else, say what; if you do not know how a figure in it was counted, say so plainly |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The quote says spreadsheet, not which software, and an ambiguity resolves downward. The words stay: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names Excel, so expect a probe on the tool. If it was Excel, say so and what you did in it, in your own words; if it was another tool, say which, plainly |
| F5 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | Your material says formal complaints in a branch log and does not say what governed them. The words stay: "I handled the branch's formal complaints log." Answer slot: the JD's wording makes a probe on the rules around the complaints you handled likely. If any rules or time limits applied to them, say which and what they required of you, in your own words; if none did, or you did not work to them, say so plainly and stay with the log |
| F6 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your material says new tellers and an escalation script, not supervisors. The words stay: "I trained new tellers on our escalation script." Answer slot: expect a probe on moving from tellers to supervisors. If you have helped any supervisor with an escalation, say how, in your own words; if not, say so plainly and stay with the tellers |
| F7 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent on digital work, so the words are an answer slot. If you have worked with a digital, web or IT team on something members used, say what and which part was yours; if you have not, say so plainly and stay with the complaints log you handled |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't presented to anyone above regional level." Then how you would prepare, said as a plan and never as a past. The quote does not say what you have presented at regional level, so nothing here claims it |
| F9 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | The quote already carries the length. Lead with it in its own terms: "6 years in retail banking, the last 3 as a branch supervisor." Say branch plainly and let them draw the "customer operations" inference; the JD's phrase is theirs, not yours |

## Grounding brief: Ashgrove's strategy, in their vocabulary

I did not see the July 2026 brief itself, only the four points you gave me from it. It is under six months old as of today.

| Item | What your note says | Provenance | How to use it |
|---|---|---|---|
| Who they are | "member-owned, about 900 staff" — your JD text | [grounded] | Say "members", not "customers" |
| Digital shift | Move 40% of member service to digital channels by 2028 | [grounded] | Every prepared candidate will name this one. Use it to prove you read the brief, then add a view (A6, E1) |
| Branches | Consolidate eight branches into five hubs over 2027 | [grounded] | Sensitive for a branch-manager panel. Treat it with care (G3). Which branches is not in the material |
| New product | Launch a small-business lending product in Q1 2027 | [grounded] | A new product brings a new kind of member and new complaints. Ask about it; never assert it (reverse questions) |
| Competition | The main competitive pressure is app-only banks | [grounded] | Handling a complaint well is part of the answer to an app-only bank (E2) |

---

# ROUND 1: the recruiter (30 minutes)

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly, unstructured; pay, notice, location, reason for leaving, "walk me through the journey" | High. Recruiter-screen prior, and the recruiter's note gives only "30 minutes with me", so nothing says it will be more technical | Treat every casual question as scored. Say your own answers on the four logistics. Rehearse the 90-second arc (A5) |
| Skeptic (light) | Quiet knockout checks on the two gaps you have named | Medium. Recruiters check the obvious gaps before passing you on, and F2 and F8 are the obvious ones | Concede the stated negatives in plain words, then stop (B1, B2). Full rehearsal is in C1 |

## Bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What salary are you looking for?" | JD | [generic] | Logistics slot, in your own words: give your own figure, or ask for the role's band first and answer once you have heard it. If asked what you earn now: "I'd rather focus on the range for this role." Nothing here supplies a number | One of the four logistics a recruiter screen covers. The JD gives no band, so the pack has no anchor and supplies no figure |
| A2 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period and the earliest date you could start, in your own words | Second logistics item. You have stated nothing on it, so the answer is yours alone |
| A3 | "Where could you be based, and how would you feel about working between sites?" | JD | [generic] | Logistics slot: say where you can actually be based and how often you could work at other sites. The brief says eight branches become five hubs over 2027, so say what you can really manage, not what sounds flexible | Third logistics item. The JD says "across branches and the contact centre", so site questions are likely |
| A4 | "What's prompting you to look at a move now?" | EXP | [generic] | Logistics slot: give your actual reason in your own words, in two or three sentences, and end on what draws you to this role. The pack does not know your reason and does not supply one | Fourth logistics item, tagged EXP because it is a story about your own choices. Motivation consistency across the three rounds is what gets compared |
| A5 | "So, walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" "I handled the branch's formal complaints log" "trained new tellers on our escalation script" "I built the monthly complaints spreadsheet our regional manager uses" | A 90-second arc in this order, each beat one of those sentences: six years in retail banking, the last three as a branch supervisor; the branch's formal complaints log; training new tellers on the escalation script; the monthly complaints spreadsheet your regional manager uses. Tell each in your own words and add no fact, figure or outcome the sentences do not carry. Answer slot: why this role, in your own words, since your material does not carry it | The opener of nearly every screen, and the quotes are the only safe pool. F9, F1, F6 and F3 are the evidence |
| A6 | "What do you know about us, and why Ashgrove?" | CO | [grounded] your four-point summary of the July 2026 brief | Bring one fact to show you read the brief. The 40% digital target by 2028 is the one every prepared candidate names. Then add one view of your own that departs from it: what happens to a complaint when a member moves between a digital channel and a person. Then why Ashgrove, in your own words, since your material does not carry your reason | The brief is equally available to rival candidates, so recite one item and then diverge. CO because it tests homework at the company's altitude |
| B1 | "The role covers the contact centre, and I don't see contact-centre experience in your background. How do you see that?" | JD | [grounded] "Never worked in a contact centre" | Light version for a screen. Concede in plain words: "I haven't worked in a contact centre." Then one sentence of plan, said as a plan: what you would learn first. Stop there; C1 carries the full rehearsal | F2 is the first knockout a screen checks. The negative has its source in your message, so the Question may state it |
| B2 | "The role presents to senior leaders. What's your experience there?" | JD | [grounded] "I've never presented to anyone above regional level" | Say it plainly: "I haven't presented to anyone above regional level." Then one sentence on how you would prepare, said as a plan. Answer slot: if you have presented anything at regional level, say what the occasion was; if you have not, say so plainly and stop | F8 is the second gap a screen will test. Concede, then stop; over-explaining it is what turns a gap into an objection |

## Reverse questions for round 1

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "How is complaint handling split today between branches and the contact centre?" | It is un-researchable from outside and tells you the real shape of F1 and F2 before round 2 |
| R1.2 | "In the panel round, is the case given in advance or on the day, and does it come with any documents?" | The 20-minute case is the largest single block of the loop, so process details change how you prepare |
| R1.3 | "What does the Head of Member Services most want from this hire in the first six months?" | Tells you what to emphasise in round 2, and shows you are already thinking about the manager's problem |

---

# ROUND 2: the Head of Member Services, who would be your manager (45 minutes, mostly behavioural)

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the contact-centre gap, the "end to end" mandate, regulated complaints and digital | High. The hiring-manager prior is to derisk gaps, and F2, F5, F7 and F8 are the open ones | Rehearse C1 until it is boring. Hold what your quotes carry and concede what you have said you lack |
| Values/Behavioral | "Tell me about a time" prompts mapped to the role: coaching, escalation, working across teams | High. The recruiter says this round is mostly behavioural, which lifts it above the hiring-manager prior | For each prompt, choose a real instance from your own work, using the selection criteria in the guidance. If none comes to mind, say so plainly |
| Case/Strategist | One or two strategy questions on the digital shift and app-only competitors | Lower. The hiring-manager prior says live problems, but "mostly behavioural" points away from it. Two or three questions, not a bank | Clarify first, structure second, think aloud, challenge one premise respectfully |

## Bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "I don't see contact-centre experience in your background. How would you handle that part of the role?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log" "trained new tellers on our escalation script" | **Highest-ROI prep in the pack.** Hold-then-concede. Concede first, before they press: "I haven't worked in a contact centre." Name the limit before it is asked for: your material is branch work and says nothing about how a contact centre runs. Hold your sentences at their own scope: "I handled the branch's formal complaints log" and "I trained new tellers on our escalation script." Then a plan, said as a plan: how you would learn their process before changing anything. Follow-up 1, "What's different about complaints in a contact centre?": answer slot, say what you expect to differ and say plainly what you do not yet know. Follow-up 2, "Why should I take that risk?": hold the two sentences, add nothing, and say what you would need to learn. Follow-up 3, "The team will test you. What do you do the first time they say you don't get it?": concede it is true where it is, ask them to show you, and keep the member's side as your test. Do not fold on the core: your branch complaints work is real, and it is also all your material carries | F2 is the biggest gap against the JD's headline requirement, so this arrives in some form. JD because it scores the stated requirement. It gets the most follow-up levels in the pack |
| C2 | "Walk me through how you handled the formal complaints at your branch." | EXP | [grounded] "I handled the branch's formal complaints log" | Story-map only what the quote states: the branch, the formal complaints, the log. Tell it in your own words. Answer slot: the JD asks about regulated complaints and end-to-end ownership, so expect probes on the rules around what you handled and on what you did once a complaint was logged. If any rules or time limits applied, say which and what they required of you; if any step after logging was yours, say which; if none applied or none was yours, say so plainly and stay with the log | F1 and F5 are where the JD presses hardest on your material. EXP because it tests what was actually yours |
| C3 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say what it is in the quote's words. Answer slot: the JD names volumes and resolution times, so expect probes on what it counted. If it counted either, say which, how each was counted, what it was most sensitive to and which assumption you would defend least, before they ask; if it counted something else, say what; if you do not know how a figure was counted, say so plainly. Second slot: which tool it was built in, in your own words | F3 and F4. EXP because a prober will treat anything you built as something to defend. The weakest-assumption move turns a gotcha into credibility |
| C4 | "Tell me about a time you worked with a digital or product team on something members used." | JD | [grounded] the JD's "work with digital teams on self-service journeys" | Selection scaffold: pick a time you worked with a digital, web or IT team on something members used. It needs what they asked of you, what you gave them, and what changed afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F7 is silence in your material, so this is an open prompt and the guidance makes no claim about your past |
| D1 | "Tell me about a time you told a colleague their handling of a complaint wasn't right." | VAL | [grounded] "trained new tellers on our escalation script" | Selection scaffold: pick a real time. It needs a named complaint-handling moment, what you said, and the working relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is "I trained new tellers on our escalation script", or how you would handle it | The JD's "coach branch supervisors on escalations" raises this theme. F6 is the nearest evidence, and it is a different audience |
| D2 | "Tell me about a time you worked with a team whose way of working you didn't know." | VAL | [grounded] the JD's "across branches and the contact centre" | Selection scaffold: pick a real time. It needs what you did not know, how you found out, and what you did differently as a result. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The role spans branches, the contact centre and digital teams, and F2 and F7 are the two you have not worked in |
| D3 | "What does owning a complaint end to end mean to you?" | JD | [grounded] "I handled the branch's formal complaints log" | Define it in your own words. A definition is a view and not a claim about your past. Then your experience at its own scope: "I handled the branch's formal complaints log." Do not describe your log work as end to end; let them ask how far it went. Answer slot: if you saw any complaint through beyond the log, say what; if you did not, say so plainly and stay with the log | F1 is the heart of the JD. Asking it as a definition checks whether you will inflate the log into the whole process |
| E1 | "We aim to move 40% of member service to digital channels by 2028. Which complaints should never be handled in self-service?" | CO | [grounded] your summary of the July 2026 brief | Clarify first: does the 40% include complaints. Structure by what the member needs, such as a simple status check, a dispute, or a problem that has already been through more than one person. Name what must stay with a person and what the member is told when it moves. Challenge one premise respectfully. The brief is equally available to rival candidates, so bring the 40% to show grounding and then your own view | The brief's digital target meets the JD's self-service journeys. CO because it needs their strategy at their altitude |
| E2 | "App-only banks are our main competitive pressure. How should complaint handling feel next to theirs?" | CO | [grounded] your summary of the July 2026 brief | Think aloud: what does a member want after a problem. Tie to the values: Plain Words and Own the Fix. Do not claim to know how any named competitor handles complaints | The brief's competitive frame. CO because it tests thinking at the company's altitude |
| E3 | "Imagine you present the month's complaints picture to our senior leaders in five minutes. What do you say first?" | CASE | [grounded] "I've never presented to anyone above regional level" | Structure it: the headline in one sentence, then volumes and resolution times (the JD's two measures), then the one driver, then the decision you want. Plain words. Time-box. Concede "I haven't presented to anyone above regional level" only if asked | F8 as a live problem. A structure is a rehearsal aid; the quote is the only claim about you |

## Reverse questions for round 2

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "What would you want to have changed by month six?" | Shows you think in outcomes and tells you what the manager will measure you on |
| R2.2 | "Where do complaints get stuck today between branches and the contact centre?" | Own the Fix in practice, and it shows you are looking at the end-to-end mandate, not only your slice |
| R2.3 | "How do the digital teams decide which self-service journeys to build first, and how does complaints data feed in?" | F7 is your gap. This turns it into curiosity about how the teams work together |
| R2.4 | "Who reads the monthly complaints report, and what decisions has it changed?" | Reporting is the JD's second headline task, and it checks that the work you would do is read by someone |
| R2.5 | "How is the small-business lending launch in Q1 2027 expected to change the complaints you handle?" | Shows you read the brief and are asking about it, not asserting anything |

---

# ROUND 3: panel of two branch managers (60 minutes, including a 20-minute case and the values round)

## Persona weights

I have treated the panel as values-round interviewers, because the recruiter says "The panel is also the values round — they score against the four values." The names are not assigned, so there is no per-member read.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | One or more prompts per published value, expecting a specific decision, not the slogan | Highest. The recruiter says they score against the four values, so every value is likely to be probed | Choose a real instance for each value. Where none comes to mind, say so plainly and give the nearest thing your material carries |
| Case/Strategist | The 20-minute escalation case, plus strategy questions on the hubs | High. 20 of 60 minutes is a third of the round | Clarify, structure, think aloud, name the limit of what you know. Own the Fix and Plain Words are your tests |
| Peer Evaluator | Seam questions: who decides what between a branch and you | Lower. The JD has you coaching branch supervisors, and whether those supervisors sit in these managers' branches is not established, so ask in the interview | Offer principles for the seam, not a claim to know their branch. Ask what they need from you |

## Bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you decided from the member's side of the counter when it wasn't the easy option." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: pick a real time. It needs the member's situation (no names), what the easy option was, what you did, and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is "I handled the branch's formal complaints log", or how you would handle it | Members First, Always, from their published wording. A story, not the slogan, is the bar |
| F2 | "Tell me about a time something you wrote or said had to be explained twice." | VAL | [grounded] "trained new tellers on our escalation script" | Map only the quote: "I trained new tellers on our escalation script." Answer slot: if any wording of the script, or of anything sent to a member, was yours to change, say what and why; if none was, say so plainly and stay with the training | Plain Words. The only quote near it is the script, and a script is words, but your material does not say you wrote it |
| F3 | "Part of this role is monthly numbers on complaints. How do you keep a branch's town in view when you report them?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say what the spreadsheet is, in the quote's words. Answer slot: if any column or note in it showed the context behind a figure, say what; if it was numbers only, say so plainly, and say what you would add, as a plan. Then give your view on how a figure can hide a branch | Neighbours, Not Numbers meets the JD's reporting. The value sets numbers against neighbours, and the role reports numbers, so expect this tension |
| F4 | "Tell me about a complaint you kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: pick a real case. It needs what you found, what you did, who else was involved, and how it ended. If an escalation meant it left your hands, say so plainly. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Own the Fix: "whoever finds the problem keeps hold of it until it is solved." F1 is the nearest evidence |
| F5 | "Escalating means handing a problem on. How does that sit with Own the Fix?" | VAL | [grounded] "trained new tellers on our escalation script" | Give it as a view: you can hand on the work and keep hold of the outcome, so the member always knows who is still holding it. Then your experience at its own scope: "I trained new tellers on our escalation script." Answer slot: if the script said who keeps hold of a complaint after escalation, say so; if it did not, say so plainly | The value and the escalation process pull against each other, and the panel will notice. F6 is the nearest quote, and nothing claims the script settled it |
| G1 | "A member complained in branch last week. The supervisor escalated it, and now the member has phoned the contact centre and been told something different. They're upset, and it lands on your desk. What do you do?" | CASE | [generic] | The 20-minute case, shape only, and nothing here claims Ashgrove's actual process. Roughly three minutes clarifying: what the member was told by each channel, what they want, and any time limits that apply (ask, do not assume). Five minutes structuring: one owner for the member from now on, the member's side first, what is known and what is not. Eight minutes on approach: contact the member in plain words before anything else, find why two channels said different things, tell the supervisor what happened without blame. Four minutes closing: what you would record, how you would check the member is satisfied, and what you would feed back. Say the structure aloud, and challenge one premise respectfully. Do not claim to know how a contact centre works unless asked, and if asked use C1 | The recruiter says 20 of the 60 minutes are a complaint-escalation case, and this covers the full chain: branch, contact centre, supervisor and member. [generic] because it is a pattern, not a fact about Ashgrove |
| G2 | "The supervisor tells you they followed the script exactly. Now what?" | CASE | [generic] | The coaching follow-up. Do not treat it as blame: find what the script did not cover, what the supervisor saw that the script did not, and what should change in the script. Plain Words applies here too. Say how you would coach without taking the supervisor's ownership away | Probably the panel's follow-up to G1. F6 is your coaching evidence and is at tellers, so offer principles and no claim of having done this |
| G3 | "Branches are consolidating from eight to five hubs over 2027. What happens to complaints, and to the towns?" | CO | [grounded] your summary of the July 2026 brief | Treat it with care. The panel are branch managers, and the brief does not say which branches change. Do not assume theirs. Say what you would watch in the complaints data during a change, and tie it to Neighbours, Not Numbers: every branch is part of its town. Ask them what they most want protected, and listen | The brief's consolidation point, in front of the people it affects most. CO and also a values test of tone |
| H1 | "Where's the line between what a branch supervisor decides and what you'd take over?" | JD | [generic] | Offer principles, not a claim to know their branches: the member's problem has one owner at a time; the supervisor keeps what is theirs to settle; you take over what crosses a branch or channel. Then ask where they would draw it | The seam, in peer packaging. JD because "coach branch supervisors on escalations" and "end to end across branches" meet here |
| H2 | "One of our supervisors escalates almost everything. How would you coach them?" | CASE | [grounded] "trained new tellers on our escalation script" | Ask why first. Coach by what they are afraid of, not by telling. Say what you would need from the branch manager. Then your experience at its own scope: "I trained new tellers on our escalation script." Answer slot: if you have coached anyone who escalated too much, say what happened and what you did; if not, say so plainly and stay with the tellers | F6 as a live problem. Reciprocity: what you need from the branch manager is part of the answer |

## Values cheat sheet (round 3)

| Value (their name) | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Selection scaffold, F1's nearest quote: "I handled the branch's formal complaints log". Pick a real time you chose the member's side when it was not the easy option; if none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it |
| Plain Words | If a member needs it explained twice, it was written wrong | F6: "trained new tellers on our escalation script". Slot as in F2: whether any wording was yours to change |
| Neighbours, Not Numbers | Every branch is part of its town | Selection scaffold. F3 is the nearest quote: "I built the monthly complaints spreadsheet our regional manager uses". Pick a real time a figure hid something about a branch or a member; if none comes to mind, say so plainly |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log". Slot as in F4: whether any complaint was yours to see through |

## Reverse questions for round 3

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "How do your supervisors escalate today, and what would you want from me when they do?" | Reciprocity: it asks what a new person could do for them, not only what you need |
| R3.2 | "What do your supervisors find hardest about escalating?" | It shows you start from the supervisor's side, which is the coaching job in the JD |
| R3.3 | "How are your branches preparing for the hubs, and what do you most want complaints handling to protect?" | Neighbours, Not Numbers in practice, and it lets them say what the consolidation means to them without you assuming |
| R3.4 | "Which of the four values is hardest to hold in a busy week, and where have you seen it done well?" | It tells you how they apply the values they score you against |

---

## Requirement coverage

| JD requirement | Questions that cover it |
|---|---|
| "Own the member complaints process end to end" | C2, D3, G1 |
| "the contact centre" | B1, C1 |
| "report monthly on complaint volumes and resolution times" | C3, E3 |
| "comfortable with Excel reporting" | C3 |
| "coach branch supervisors on escalations" | D1, G2, H1, H2 |
| "work with digital teams on self-service journeys" | C4, E1 |
| "experience handling regulated complaints" | C2, G1 |
| "confident presenting to senior leaders" | B2, E3 |
| "4+ years in financial-services customer operations" | A5 |

Strategy questions: A6, E1, E2, G3. Each of the four values has a VAL question: F1 to F4, with F5 as the tension.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says one branch's log, not the process. C2 and D3 stay inside the log |
| Has handled regulated complaints | Inflated form of F5 | F5's quote at its own scope. The pack's observation is that your material says formal complaints, not what governed them |
| Reported monthly on complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope. The pack's observation is that your material says a monthly spreadsheet, not what it counted |
| Has Excel reporting skills | Inflated form of F4 | F4's quote at its own scope. The pack's observation is that the quote says spreadsheet, not the software |
| Coached supervisors on escalations | Inflated form of F6 | F6's quote at its own scope. The pack's observation is that the material says new tellers |
| Worked in a contact centre, or owned contact-centre complaints | Negative you stated, F2 | The plain acknowledgment: "I haven't worked in a contact centre." No slot |
| Presented to senior leaders | Negative you stated, F8 | The plain acknowledgment: "I haven't presented to anyone above regional level." No slot |

## Sources

**Provided documents:** the job description; the four values as pasted, copied on 26 November 2026 from ashgrovecu.org/about/values; the recruiter's email on the three rounds; your four-point summary of the July 2026 strategy brief (I did not see the brief itself); your background statement. No `tuesday-dossier.md` was present.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values text fixes the four names and glosses, so the values cheat sheet needed nothing more |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | The recruiter's email fixes the three rounds, their lengths and who runs them, so persona weights follow it |
| 3. `Ashgrove Credit Union strategy` | skipped | Your four-point summary of the July 2026 brief supplies the priorities and competitive frame for the CO questions and the grounding brief |
| 4. interviewer name and company | n/a | No interviewer has been assigned, so there is no query to form. The upgrade menu says what a name would unlock |
| 5. representative `Member Experience Lead` JD | skipped | The supplied JD fixes the fit snapshot and every JD-tagged question |

## Upgrade menu

- **Your CV text** → the evidence cells in F1 to F9 could quote CV lines as well as your message, and rows F3, F4, F5 and F6 may move from discovery or transferability.
- **Your answers to the answer slots in F1, F3, F4, F5, F6 and F7**, given outside a drill → each becomes quoted evidence, and the rows that draw on it, with their questions, are regenerated.
- **A copy of the monthly spreadsheet's layout with no member data** → F3 and F4 could move from `medium` toward `high`, because it is the inspectable artifact for complaints reporting.
- **The interviewers' names once assigned** → an interviewer read, persona weights tuned to each one's public professional footprint, and a reverse question tied to each one's own path.
- **One email to the recruiter** asking whether the round 3 case comes with documents, and what "regulated" means in this role → F5 and G1 move from `[generic]` and discovery toward `[grounded]`.
- **Hours available before 5 December** → a prep triage sized to your time, with an explicit "everything else is insurance" line.
- **A deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes) → the strategy brief itself, role-family loop reports and recent organisational context for Ashgrove, tightening the CO and CASE questions. Offered once; say yes to run it.
- **A `tuesday-dossier.md` from an earlier evidence review** → user-confirmed evidence and a `prohibited_claims` list replace the local ones built here.
