I've read the skill's rules and your dossier. I'm now running three searches on Quartzline (values, interview process, strategy) before I write the pack.
Web search was denied, so the pack runs on your dossier alone and says so in its Sources. Writing it now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a6/runs/sonnet/alone/part-2/rooms/case-4-denied-a6550789/quartzline_product-manager-platform-apis_interview_pack.md`. It has 20 questions across six personas and a requirement-coverage table. It also has six reverse questions, a prohibited-claims list and a fit snapshot.

I built it for a hiring-manager round, since that's what you described. The web searches on Quartzline were refused, so nothing in the pack comes from outside your dossier. The company-specific "why Quartzline" question (D3) is a generic scaffold. There's no values cheat sheet.

The pack's highest-ROI prep is A1, your dossier's objection ("never held the PM title or owned a roadmap"). It's rehearsed with the concession first, your three verified quotes at their own scope, and the limit named before they ask. It ends with a ramp plan and three follow-up levels.

The dossier only graded R1 and R5, so I graded R2 to R4 and the responsibility rows myself. Please check those rows. The "seven years of integration leadership" line is dossier prose rather than a verified entry, so nothing in the pack relies on it.

Several answer slots (A4, A5, C1–C3 and others) need your own answers, or a plain "that wasn't me".

Say the word and I'll play the Skeptic on A1 as a live drill.
I can also save your `tuesday-dossier.md` with a `pack_feedback` section recording the gaps this prep exposed.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

Round: hiring-manager conversation, 45 minutes. Interviewer name: not given. Built from your tuesday-dossier.md (conditional_go).

## How to use this pack

Personas describe how a question is asked; types describe what is scored. Guidance is scaffolding, not a script, and all proposed wording here is pending your approval: change anything that is not what you would truthfully say.

| Type | What it scores |
|---|---|
| VAL | Past behavior against the company's published values |
| EXP | Whether your claims survive scrutiny; what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem from the actual role |

Provenance labels: `[grounded]` traces to your dossier, `[inferred]` is a derivation, `[generic]` is a role-family pattern with no claim about you or Quartzline. Words about your past rest on the quotes in the fit snapshot and on nothing else. An answer slot is an instruction for the interview: answer it from your own experience, or say plainly the practice was not yours.

Quote key used below:

- Q1: "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"
- Q2: "Wrote the internal integration playbook her team uses"
- Q3: "Ran quarterly roadmap-input sessions feeding client evidence to product"

## Fit snapshot

Proposed language, pending your approval. Rows F1, F2 and F6 carry the dossier's own grades and strategies. The other rows are this pack's grades, because the dossier's weak-area list covers only R1 and R5.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1 (must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | low | [grounded] | transferability | Strategy: bridge. The pack's observation: your material is integration delivery and client input to product, not product management, and the dossier's condition is that it is positioned as adjacent, never as PM experience. Words stay at the quotes' scope: 'I led 30+ end-to-end client integrations of the vendor's REST APIs.' Plain acknowledgment, sourced by prohibited_claims: "Having held a product manager title or role": 'I haven't held a product manager title.' |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibilities | none given | none | [grounded] | capability | Strategy: acknowledge_gap, so no bridge. Words come only from the dossier fields acknowledge_gap area "Owning a roadmap and prioritization authority (R1 sub-claim)" and prohibited_claims: "Having owned a product roadmap": 'I haven't owned a roadmap.' Then a ramp plan said as a plan, never as a past: learn which decisions sit with the squad leads, learn how adoption is measured, before changing anything. Nothing added to make the gap feel smaller |
| F3 | "Shipped API or platform products" — dossier role_profile R2 (must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | medium | [grounded] | transferability | Not on the dossier's weak-area list, so graded here. Your material says client integrations of the vendor's REST APIs, with go-live as one step; it does not say what the API product itself was. Words stay at Q1's scope. Answer slot: the JD's R2 line makes a probe on what you delivered likely. If you can say which of scoping, requirements, architecture, UAT and go-live were yours to decide, say it in your own words; if some were not yours, or there was no such decision, say so plainly and stay with the integrations you led |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3 (important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | medium | [grounded] | discovery | The quotes touch REST APIs and architecture; they do not show whether API docs or schemas were part of that work. Answer slot: the requirement's own words make a probe likely. If you read, wrote or used them on these integrations, say which and what you did with them; if the work did not involve them, or they were not yours, say so plainly and stay with the integrations and the playbook |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4 (important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [grounded] | transferability | The quotes carry client-facing work and a channel to product; they do not show engineering or sales. Answer slot: on the integrations you led, say which other teams you worked with and what you did with them, in your own words; if the work did not involve engineering or sales, say so plainly and stay with the clients |
| F6 | "Agile delivery experience" — dossier role_profile R5 (preferred) | none given | low | [grounded] | discovery | Strategy: clarify. No verified entry speaks to this requirement. Answer slot: the requirement's own wording makes a probe likely. If you worked in sprints or similar cycles with engineering, say how and what your part was; if you never worked that way, say so plainly, then ask: 'Here is what I'd want to confirm: how do your squads run delivery?' |
| F7 | "Run discovery with integration partners" — dossier role_profile responsibilities | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [grounded] | discovery | Confirmed, with limited inspectable proof, so expect a probe and volunteer the limit. The quote says clients and product, not integration partners. Answer slot: if the sessions or the integrations put you in direct conversation with clients about what they needed, say what you asked and what you did with the answers; if not, say so plainly and stay with the sessions as quoted |
| F8 | "Write specs and drive delivery with two engineering squads" — dossier role_profile responsibilities | "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | medium | [grounded] | transferability | A playbook is not a spec, and the quote does not mention squads. Words stay at the playbook. Answer slot: the requirements step in Q1 may have fed engineers; if you wrote requirements that engineers built from, say what and how; if not, say so plainly and stay with the playbook |
| F9 | "Define and track adoption metrics" — dossier role_profile responsibilities | none given | none | [grounded] | discovery | The material is silent, which is discovery and not capability. Answer slot: if you tracked any measure of how clients used or adopted what you integrated, say what it counted and how; if not, say so plainly and say what you would ask first |

## Persona table

Weights start from the hiring-manager prior in the pack's persona model (Case/Strategist plus Skeptic), then adjust for the dossier.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the title gap and roadmap ownership | High. HM prior, and the dossier names this objection | Rehearse A1 until boring; name the limit before it is asked for |
| Case / Strategist | Live problems on partner adoption and squad trade-offs | High. HM prior, and the JD's duties are case-shaped | Clarify, objective, segments, approach, metrics, risks; think aloud |
| Data-Driven Prober | Defends the 30+ and the playbook | Medium. Q1 carries a headline number and Q3 is medium confidence | Know what you can and cannot say about each; say plainly when you do not know |
| Conversational | Opens with the journey question | Medium. A 45-minute HM conversation usually opens this way, and it is still scored | A 90-second arc built only from Q1, Q2, Q3 |
| Peer Evaluator | Seam with the two squad leads | Low to medium. The dossier flags squad-lead authority as unevidenced | Propose seam principles; do not pretend to know the seam |
| Pressure | Time-boxed "why you" | Low. No signal of a stress style | Pause, restate, hold through two follow-ups, concede specifically |
| Values / Behavioral | Scenarios tied to published values | Low. No values page was read and no source documents a values round, so no bank | See the upgrade menu |

## Question banks

Highest-ROI prep in this pack: A1. The dossier's underwriter named this objection, and it will be asked in some form.

### A. Skeptic (highest weight)

Proposed language, pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | Four beats. (1) Concede first and plainly, with sources prohibited_claims: "Having held a product manager title or role" and prohibited_claims: "Having owned a product roadmap": 'I haven't held a product manager title, and I haven't owned a roadmap.' (2) The adjacent case at its own scope: 'I led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping to go-live. I wrote the internal integration playbook my team uses. I ran quarterly roadmap-input sessions feeding client evidence to product.' (3) Name the limit yourself: that is adjacent work, not product management. Q3 is confirmed with limited inspectable proof, so expect the probe. Answer slot: if asked what came of the evidence you fed to product, say what you know; if you do not know, or nothing changed, say so plainly and stay with the sessions you ran. (4) A ramp plan, future tense: learn which decisions sit with the squad leads and how adoption is measured before changing anything. Follow-up 1, "isn't that delivery work?": agree it is adjacent and return to the quotes. Follow-up 2, "what would you get wrong in the first 90 days?": answer from the ramp plan, never by claiming practice you lack. Follow-up 3, "which quote is closest to PM work?": pick one, at its scope, and restate the limit | The dossier's likely_interviewer_objections item, so the deepest rehearsal. F1 and F2 are where it presses. JD because it scores the must-have; Skeptic is how it arrives |
| A2 | "Have you ever owned a roadmap or set priorities for an engineering squad?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Plain acknowledgment, sourced by acknowledge_gap area "Owning a roadmap and prioritization authority (R1 sub-claim)" and prohibited_claims: "Having owned a product roadmap" and prohibited_claims: "Having set prioritization for an engineering squad": 'I haven't owned a roadmap, and I haven't set prioritization for an engineering squad.' Then Q3 at its scope only: 'I ran quarterly roadmap-input sessions feeding client evidence to product.' Then the ramp plan. No slot here, and no bridge past Q3 | F2 is an acknowledge_gap area, so the honest form is short and sourced. JD because it scores the roadmap duty |
| A3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Choose the weakest part you can state plainly. F2's sourced sentence is the safest: 'I haven't owned a roadmap.' Then the ramp plan. If you pick adoption metrics (F9) or agile (F6), use those rows' slots and say nothing about practice you have not done | Skeptic stem; F2, F6 and F9 are the candidate weak points. JD because it scores the whole duty list |
| A4 | "Tell me about an API or platform product you've shipped." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | An open prompt, so choose the instance. Tell Q1's beats in your own words: the integrations, and the five steps it names. Do not relabel them as a product you owned. Answer slot: the JD's R2 line makes a probe on what you delivered likely. If you can say which of scoping, requirements, architecture, UAT and go-live were yours to decide, say it; if some were not yours, or there was no such decision, say so plainly and stay with the integrations you led | F3 is graded by this pack, not the dossier, and a must-have is probed. JD because it scores R2 |
| A5 | "How have you worked inside an agile delivery team?" | JD | [grounded] | Strategy: clarify. No verified entry speaks to this, so the answer is question-shaped. Answer slot: the JD's R5 line makes a probe likely. If you worked in sprints or similar cycles with engineering, say how and what your part was; if you never worked that way, say so plainly, then ask: 'Here is what I'd want to confirm: how do your squads run delivery?' | F6 is a clarify area. JD because R5 is a stated preference |

### B. Case / Strategist (highest weight)

Proposed language, pending your approval. These ask nothing about your past, so the guidance makes no claim about it.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A partner says their integration has been live for two months but sends almost no traffic. How do you find out why?" | CASE | [generic] | Clarify first: what "live" means (keys issued, first call, production traffic), what the partner expected. Objective: a working definition of activation. Segment partners by integration type and size. Approach: diagnose by funnel stage, then talk to the partner. Metrics and risks last. Think aloud and challenge one premise politely | The role runs partner adoption. CASE because it is a live problem; `[generic]` because it is a pattern, not a fact about Quartzline |
| B2 | "How would you measure adoption of a partner-facing API?" | CASE | [generic] | Open by asking what adoption means here and what the baseline is today, which is also a reverse question. Then a small set: activation, depth of use, retention. Name the weakest assumption in your own definition before they do | Adoption metrics are a stated duty (F9) and the dossier lists them as unknown. CASE with JD content |
| B3 | "Two squads, and a strategic partner's request that conflicts with the other squad's commitment. How do you decide?" | CASE | [generic] | First move: clarify decision rights, meaning which decisions are the PM's and which are the squad leads'. Then criteria, who must agree, and how the decision is recorded. It is a plan, not a past, so claim no experience of setting squad priorities | The dossier flags squad authority as unevidenced (F2, F8). CASE because it is a live trade-off |
| B4 | "Partners ask for a change to the API's response format that would break existing integrations. What goes in the spec before engineering starts?" | CASE | [generic] | Structure: the problem, who is affected, options, migration and versioning, how success is measured, open questions, who decides. Ask what the versioning policy is today before proposing one | Covers "write specs" (F8) and technical fluency (F4). CASE with JD content |
| B5 | "Walk me through how you'd run discovery with a new set of integration partners in your first month." | CASE | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Mostly a plan: who you would talk to, what you would ask, how you would synthesize, how the evidence reaches the squads. If you mention your own sessions, only at scope: 'I ran quarterly roadmap-input sessions feeding client evidence to product.' Answer slot: if asked what you asked in them, say what you asked; if you do not recall or it was not your question set, say so plainly and stay with the sessions as quoted | F7 covers discovery. CASE because it is forward-looking |

### C. Data-Driven Prober

Proposed language, pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You led 30+ integrations. Walk me through how that number was counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Say what the quote says, with 30+ staying attached to client integrations. Four answer slots, each in your own words: how it was counted, including what made something count as one; what it is sensitive to; the assumption you would defend least; which parts were yours. If you do not know how a part was counted, say so plainly. The playbook is the inspectable piece: 'I wrote the internal integration playbook my team uses, and I can walk you through it' | A headline number is a prober target. EXP because it tests attribution |
| C2 | "What's in the playbook, and how much of it is yours?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | The beats the quote states: you wrote it, and your team uses it. Answer slot: say what is in it from the document itself; if a section came from others, say so plainly. Offer to walk through it end to end | Q2 is high confidence and inspectable, so it is the strongest thing to show. EXP |
| C3 | "Tell me about the roadmap-input sessions you ran." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Tell what the quote states: quarterly, client evidence, fed to product. Volunteer the limit: this one has little inspectable proof. Answer slot: if you know what product did with the evidence, say what you saw; if you do not know, or nothing changed, say so plainly and stay with the sessions. Never describe a result you did not see | Medium-confidence evidence, which a prober will find. EXP |

### D. Conversational

Proposed language, pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey. How did you get here?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc of three beats in your order: the integrations, the playbook, the sessions, each at its quote's scope. Close with why this role, in your own words. If the true reason is not a product ambition, say what it is. Never state a motive you do not hold | A casual opener is still scored. EXP because it tests whether the story holds together |
| D2 | "What are you actually playing with in the API space these days?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | An open prompt. Pick something real you have read or used recently and say what you did with it. If nothing comes to mind, say so plainly, then give the nearest thing your material carries, or how you would learn Quartzline's API docs first | R3 is an important requirement (F4). JD delivered casually |
| D3 | "Why Quartzline, and why this role?" | CO | [generic] | No company research could run, so this is a selection scaffold. Say only what you can verify from Quartzline's own public material before Thursday, plus your true reason. If you cannot say why Quartzline specifically, say so plainly and talk about the role | CO is expected in any HM chat, and the pack could not source company facts, so it is `[generic]` |

### E. Peer Evaluator

Proposed language, pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "The two squad leads have their own roadmaps. Where's the seam between you and them, and what happens when you disagree?" | CASE | [generic] | Say you do not yet know where the seam sits here, and propose principles: which decisions are the PM's alone, which are the leads', which are joint, and who has the final say when they disagree. Then ask which of those the team has already settled | The dossier's unresolved risk is squad-lead authority. CASE because it is a live collaboration problem |
| E2 | "How do you handle credit and disagreement when work spans teams?" | EXP | [generic] | An open prompt. Pick a time you disagreed with someone outside your team about scope or a go-live decision, with a named stake, what you actually said, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A peer-style probe that may return in collegial packaging. EXP |

### F. Pressure

Proposed language, pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over a PM with three years of this?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | A time-boxed A1. Pause and restate the question. About 10 seconds on the concession ('I haven't held a product manager title, and I haven't owned a roadmap', sourced as in A1), 20 on Q1 at its scope, 20 on the limit and ramp plan. Hold through two follow-ups by returning to the quote. Concede the title and the roadmap specifically and never claim to be the stronger candidate | Pressure delivery of the dossier's objection. JD content |
| F2 | "That result — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold the quote as written, including "Led". Answer slot: name which steps were yours and which were shared; if any belonged to someone else, say so plainly. Concede specifically and never fold on the core claim | Attribution probe on the headline claim. EXP |

### Requirement coverage

| Requirement | Questions |
|---|---|
| R1: 3+ years product management experience | A1, A2, A3, F1 |
| Own the roadmap | A1, A2, A3, B3, E1 |
| R2: Shipped API or platform products | A4, C1, F2 |
| R3: Technical fluency | B4, D2, C2 |
| R4: Stakeholder management | E1, E2, B3 |
| R5: Agile delivery | A5 |
| Run discovery with integration partners | B5, C3 |
| Write specs and drive delivery with two squads | B4, B3, C2 |
| Define and track adoption metrics | B2, A3 |

## Reverse questions

| # | Question | Why it lands | Source |
|---|---|---|---|
| R1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The JD asserts roadmap ownership but the dossier finds squad authority unevidenced, so the answer tells you what the job is | [grounded] dossier questions_for_employer |
| R2 | "How is partner API adoption measured today, and what is the current baseline?" | The role names adoption metrics but no baseline is stated; the answer shows how success will be judged | [grounded] dossier questions_for_employer |
| R3 | "How are conflicts between the two squads' priorities settled today?" | Tests the same authority risk from the process side | [grounded] dossier opportunity_risks_to_validate |
| R4 | "How do your squads run delivery, and what does a planning cycle look like?" | It is the question-shaped answer to the agile clarify area and shows diligence | [grounded] dossier uncertain_or_weak_areas |
| R5 | "What would a strong first 90 days look like, and what would make you doubt the hire by day 90?" | Invites candor about the gap you have already conceded and shows you plan to be measured | [generic] |
| R6 | "How would you want me to build a track record on the roadmap side, which I haven't done, in the first six months?" | Turns the acknowledged gap into a mentoring conversation | [generic] |

## Prohibited claims

Built before the banks and binding on every cell above.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims | 'I haven't held a product manager title.' plus Q1 at its own scope |
| Having owned a product roadmap | Dossier prohibited_claims and acknowledge_gap area | 'I haven't owned a roadmap.' plus Q3 at its own scope, as input and nothing more |
| Having set prioritization for an engineering squad | Dossier prohibited_claims | 'I haven't set prioritization for an engineering squad.' |
| Describing the integration work as product management experience | Inflated form of F1; the dossier's condition is adjacent positioning | Q1 at its own scope. The pack's observation: your material says integration delivery, not product management |
| Having shipped an API or platform product | Inflated form of F3 | Q1 at its own scope. The pack's observation: your material says client integrations of the vendor's REST APIs, not the API product itself |
| Having written specs for, or driven delivery with, engineering squads | Inflated form of F8 | Q2 at its own scope. The pack's observation: your material says a playbook, not specs or squads |

## Sources

- Provided: your tuesday-dossier.md, version 1.1, pasted in conversation. It supplied role_profile (requirements and responsibilities), handoff_to_mock_interview (verified_candidate_evidence, uncertain_or_weak_areas, likely_interviewer_objections, opportunity_risks_to_validate, questions_for_employer, prohibited_claims) and decision (context only). No evidence_map or evidence_state was present.
- The decision summary's "seven years of integration leadership" is not a verified entry, so no cell rests on it.
- Searches sent, all refused by the host: "Quartzline company values", "Quartzline interview process product manager", "Quartzline API platform strategy news". Nothing in this pack comes from outside the dossier.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Would have fed a values cheat sheet; none is built, and D3 is a `[generic]` scaffold |
| 2. `Quartzline interview process product manager` | unavailable | Would have shown whether a values round exists; persona weights rest on your stated round and the HM prior |
| 3. `Quartzline` strategy / recent news | unavailable | Would have grounded a company-strategy CO or CASE question; B1 to B5 are `[generic]` or dossier-grounded |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form |
| 5. Representative JD | skipped | The dossier's role_profile fixes the requirements and the JD-tagged questions |

## Upgrade menu

- The interviewer's name → an interviewer read, persona weights tuned to their public footprint, and a reverse question tied to their own path
- The recruiter's prep email or process details → whether a values round exists, and any pre-declared deliverable
- Quartzline's own values and strategy pages pasted in (search was refused here) → a values cheat sheet and company-specific CO and CASE questions in place of D3 and the `[generic]` cases
- Your answers to the answer slots, written out of the interview (F3 to F9, A1, A4, A5, B5, C1 to C3) → each becomes quoted evidence and the rows and cells that draw on it are regenerated
- One roadmap-input session's agenda or notes → could raise F7 and Q3 from medium confidence; any adoption or usage report you have seen or kept → could move F9 off `none`
- The raw CV behind the confirmed claims → checks the quotes against the source
- Prep time available → a prioritized schedule
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) if search is permitted → company strategy and interviewer footprint
