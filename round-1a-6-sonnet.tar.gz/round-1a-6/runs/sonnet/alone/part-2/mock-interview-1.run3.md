I'll read the skill's reference files before writing anything.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a6/runs/sonnet/alone/part-2/rooms/case-1-denied-ab9a51ff/northwind-data_senior-gtm-strategy-lead_interview_pack.md`. It has 22 questions across seven personas, and each has a type tag, a provenance label, answer guidance and a rationale.

I built it for a peer round with Dan, using your summaries of the JD, Priya's background and his profile. All three of my web searches (company values, loop structure, Dan's public footprint) were refused, so nothing is independently verified. Company facts come only from your research note. The interviewer read rests only on your description of Dan.

- **Weights:** Data-Driven Prober and Peer Evaluator lead at 5 questions each, because of his "relentlessly data-driven" line and the peer relationship. Case/Strategist and Skeptic have 3 each, with the cases tilted toward pricing, packaging and unit economics. Conversational, Pressure and Values have 2 each. I left out a values cheat sheet because nothing shows a values round in this loop.
- **Highest-ROI prep (D1):** Dan owns sales strategy, so the "no classic sales-ops or quota-setting" gap is where he is most likely to press. The guidance has Priya name the gap first, and it works through four follow-ups. It also keeps "volume targets" separate from "quotas", because her material only says targets.
- **Where the evidence is thin:** the $400M ARR line is quoted as "proposed… credited with", so A1, A2 and F1 rehearse that scope and don't claim she drove it. The partner-motion requirement is matched only by the carrier revenue model, so D2 asks for what is hers to design and doesn't claim a motion she may not have built.
- **Answer slots:** guidance contains slots where your notes don't show what happened, such as how the ARR was counted or which analysis she ran herself. Priya fills those in her own words, and the pack supplies none of them.

Say the word and I'll play Dan as the Skeptic on D1 and give feedback against that question's guidance.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the full JD text and Priya's CV bullets word for word? The quotes in the fit snapshot currently come from your summary, and verbatim lines would turn several answer slots into story-mapped answers.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Interview pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy, Priya's peer (same VP). **Format:** one 60-minute conversation, as you described it.

Built on your summary of the JD and of Priya's background. No web research succeeded in this run (all three searches were refused), so company facts come only from your research note and the interviewer read comes only from your description of his profile. Nothing here is verified beyond what you supplied.

**The highest-ROI prep in this pack is D1**, the "no classic sales-ops or quota-setting" objection. Dan's own function is where that gap bites, and he is a peer who owns the craft. Rehearse it until it is boring.

## How to use this pack

Personas describe how a question arrives (who is asking, in what style). Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did. An "answer slot" is an instruction for the interview, not a question for this conversation.

| Type | What it is really testing |
|---|---|
| VAL | Behavioral and values alignment: whether past behavior shows the traits the company or role needs |
| EXP | Work-experience deep-dive: whether the CV's claims survive scrutiny, and what was actually yours |
| JD | Role and JD-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge: whether you can think at the company's altitude |
| CASE | Hypothetical or live problem: structure and reasoning on a problem from the actual role |

## Fit snapshot

Requirements are the JD highlights you gave me. Evidence is Priya's own words as you gave them, quoted exactly.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights | "then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes; "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | Adjacent work, and the limit is the pack's observation: the material shows consumer product strategy, not B2B GTM for new lines. Words stay at scope: "For nine years I was in product strategy and ops at a large consumer-tech company," and "I proposed a store-surface change that was credited with a ~$400M ARR uplift." Answer slot: the JD's "two new product lines" makes a probe on taking something new to market likely. If any of your work took a new product or surface to market, say what and which part was yours; if none did, or it was not yours, say so plainly and stay with the work you quoted |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights | none given | none | [grounded] | discovery | Your material does not show this either way, so the words are an answer slot. If any of your work identified untapped revenue or usage, say what you found and how, in your own words; if none did, say so plainly and describe how you would structure it for the two new lines (rehearsed in A5) |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | discovery | The quote names the tools and does not show an analysis run independently. Answer slot: pick one analysis you personally ran and be ready to walk it end to end; if no such analysis comes to mind, say so plainly and say how you would approach the first one at Northwind (rehearsed in A4) |
| F4 | "partner-motion design experience required" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | Adjacent work at its own scope: "I built a partner-level revenue model that was used in carrier negotiations." Your material says the model, not the motion, and not the negotiating. Answer slot: if any part of how the company worked with those partners, beyond the model, was yours to design, say what and how you decided; if there was no such step, or it was not yours, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | none | The quote already reaches the requirement in role-relevant terms: you set annual volume targets, with consensus across orgs. A CV-level line with nothing inspected behind it, so expect a probe on how the consensus formed; lead with the quote's own terms |
| F6 | "AI experience a plus" — JD highlights | "uses AI tools daily" — the coach's notes | medium | [grounded] | transferability | Daily use is adjacent to AI experience in a GTM role and does not reach building or shipping with it. Words: "I use AI tools daily." Answer slot: if you have built anything with them, say what and how far it went; if your use is as a user, say so plainly |
| F7 | Sales-ops and quota-setting fluency, which the pack infers from Dan's function and the JD's land/adopt/expand/renew line (unquoted, the pack's inference) | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [grounded] | capability | A gap wording cannot close, and it has been stated. Words: "I don't have classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |

## Reading the interviewer

Only your description of his profile is available; the search for his public footprint was refused. Nothing below goes beyond what you wrote.

| What your note says | Implication for the conversation |
|---|---|
| Director of Sales Strategy, Priya's peer, same VP | He prices what this hire costs and contributes to his own work. Expect seam, credit and disagreement questions (bank B) |
| Self-described "relentlessly data-driven" | Every number gets probed to its assumptions. Know how each figure was counted, and say plainly when you don't (bank A) |
| Career spine is "pricing and monetization roles" | Case questions tilt to pricing, packaging and unit economics (C2, C3). He owns the craft behind F7, so calibrated candor beats bluffing |
| "one early-stage-startup chapter" | Expect a probe on building from nothing (D3). Builder stories land; invented ones do not |

**Mirror opportunity.** Shared professional vocabulary: his monetization work and F4's quote, "built a partner-level revenue model used in carrier negotiations", both live in revenue economics. The material does not say Priya set prices, so the mirror is the vocabulary only. His startup chapter has no counterpart sentence in Priya's evidence, so it is not offered as a shared jump.

## Persona table

The loop rests on your own words: one 60-minute conversation with a peer. No archetype fallback was needed. Weights start from the peer-round prior and move on the signals in the table above.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober (bank A, 5 questions) | CV read line by line, inputs and denominators asked for | Very high: peer prior, and the "relentlessly data-driven" signal moves it up | Know what you can and cannot say about how each number was counted; name the weakest assumption before he does; offer to walk one analysis end to end |
| Peer Evaluator (bank B, 5) | Seam-splitting, credit, disagreement, "what would you need from me" | High: the peer prior, same VP | Reciprocity framing; propose seam principles rather than pretending to know the seam; disagreement stories with spine and tact |
| Case/Strategist (bank C, 3) | Live problems on Northwind's own priorities | Medium: pricing and monetization spine tilts the cases toward pricing, packaging and unit economics | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise |
| Skeptic (bank D, 3) | Quiet probing of F4 and F7, the new-lines build, in his own territory | Medium: two gap rows sit in his function. Carries the highest-ROI item | Name the gap first, bridge only from what you stated, give a plan, never claim his craft |
| Conversational (bank E, 2) | Biography opener, then a casual AI question | Low-medium: a single long conversation likely has an opening, and the AI "plus" can arrive as chat | Pre-script a 90-second arc; treat casual questions as scored |
| Pressure (bank F, 2) | Attribution and "why you" in sixty seconds | Low: no signal for it, but F1's figure invites it | Pause, restate, hold the core claim through two follow-ups, concede only what is specific |
| Values/Behavioral (bank G, 2) | Behavioral stems | Low: no values-style round is documented for this loop, and your note describes one conversation | Selection scaffolds with an honest branch; no values cheat sheet, since none was detected |

## Question banks

### A. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The ~$400M ARR figure on your CV: walk me through how that number was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Open with the quote at its own scope: you proposed the change, and the ~$400M ARR uplift is what it was credited with. Then four slots, each in your own words: how the figure was counted, what it is most sensitive to, the assumption behind it you would defend least, and which part was yours. For each, if you know, say it; if you do not know how it was counted or what it rests on, say so plainly and return to the proposal. Name the weakest assumption before he asks | F1 holds the one headline figure, and a data-driven peer's first probe lands on a figure. EXP because it tests whether the claim survives scrutiny; Prober because it asks for counting, not narrative |
| A2 | "Which part of that uplift was yours, and which part belonged to other people?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold the sentence as written: you proposed the change. Answer slot: if any part beyond the proposal was yours, say which part and what you did; if the proposal was your part, say so plainly. Do not widen "proposed" into led or drove | Attribution probe in collegial packaging, from F1. EXP because it tests what was actually the candidate's |
| A3 | "You built a partner-level revenue model. What went into it, and which input would you trust least?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story-mapped on F4: the model, which you built; partner-level; used in carrier negotiations. Those are the beats the quote states. "Used in" is the quote's scope and does not say you sat in the negotiations. Answer slot: he will probe the model's inputs and structure; describe them in your own words and name the input you would trust least before he asks. If you do not recall how an input was sourced, say so plainly | F4 is the evidence for the partner requirement and the thing a data-driven peer can interrogate. EXP because it tests ownership of the model |
| A4 | "Tell me about an analysis you ran yourself in SQL or Tableau, from question to answer." | JD | [grounded] "skilled in SQL/Tableau" | Your material carries the tools, not an analysis, so this is a selection scaffold. Pick one analysis you personally ran end to end: the question you started with, where the data came from, what you queried or charted, what you found, what changed because of it. If no such analysis comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach the first one at Northwind. Offering to walk it end to end suits a prober | F3 is the JD's SQL and Tableau line, and the requirement most likely to be tested by this interviewer. JD because it scores a listed skill; the story is a candidate's choice |
| A5 | "For two new lines, how would you find whitespace across land, adopt, expand and renew: what would you pull first, and what would make you distrust it?" | CASE | [generic] | A live problem, so no claim about your past. Clarify first: how each stage is defined, what data exists for lines this new, what the unit of account is. Then the objective, segmentation by stage, the first pull and the result you would distrust, then risks. Think aloud and challenge one premise, such as whether "whitespace" means unsold accounts or under-adopted ones | F2 has no evidence, so the honest preparation is the method. CASE delivery of a JD requirement; `[generic]` because it is a pattern for the problem |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam between us, and what happens when we disagree?" | JD | [generic] | Propose seam principles rather than claiming to know the seam. Offer a hypothesis from his title and the JD, that the seam sits where a new product line meets the existing sales motion, and ask where he would draw it. Principles to offer: one owner per number, shared definitions before debates, disagreements go to the shared VP only after a joint written view. Close with reciprocity: what his team gets from yours | Peer stem; the JD's cross-functional line is scored here. JD because it tests the role's stated collaboration |
| B2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on F5: the annual volume targets, which you set, with consensus across orgs. Those are the beats the quote states. "We" for context, "I" for what you set. Answer slot: he will probe who else contributed and how credit was shared; say what happened in your own words. If the targets were not yours alone to set, or credit was never contested, say so plainly | Peer Evaluator's credit-sharing probe. VAL because it scores behavior toward peers |
| B3 | "Tell me about a time you changed the mind of a team that didn't report to you." | JD | [grounded] "set annual volume targets with cross-org consensus" | The quote carries three beats: annual volume targets, across orgs, consensus. Who disagreed and what moved them is not in the quote, so it is an answer slot: say who held a different view and what changed it, in your own words. If consensus came with no one disagreeing, say that plainly and do not construct a conflict. If a clearer example sits elsewhere, test it: a named stake, a position that moved, a relationship intact | F5 against the JD's cross-functional influence line. JD because it scores that requirement |
| B4 | "What would you need from me in your first ninety days?" | JD | [grounded] "skilled in SQL/Tableau" | Ask for three things: his view of where the sales motion meets the new lines, shared data definitions and access, and introductions. Then reciprocity as a plan: share early analysis in the tools you are skilled in so his team can challenge it | Peer stem. The reciprocity half is what converts a peer from evaluator to ally |
| B5 | "Tell me about a time you disagreed with a peer and it didn't resolve neatly." | VAL | [generic] | Selection scaffold: pick a disagreement with a named stake, where you held your view with tact and the relationship stayed intact, and say plainly what remained unresolved. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Peer Evaluator scores disagreement style with equals. `[generic]` because the material carries no disagreement story |

### C. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Compass is one of the company's stated priorities. Sketch the go-to-market for an AI copilot launch: what do you need to know first?" | CO | [grounded] "an AI copilot launch ('Compass')" | Your research note, not independently verified. Clarify first: is Compass one of the two lines, who is the first buyer, what does land look like against expand. Then objective, segmentation, an approach per stage (land, adopt, expand, renew), metrics, risks. Link it to the enterprise-expansion priority from the same note. No claim about your past | The strategy-grounded differentiator question. CO because it needs company altitude; CASE delivery |
| C2 | "A much larger platform vendor bundles a rival product into its suite. What happens to your plan?" | CASE | [grounded] "bundling by a much larger platform vendor" | Clarify what bundled means (included free, discounted, tied to a contract) and who is exposed. Segment by exposure, then responses in his language: packaging, pricing, unit economics, plus integration or partner routes. Metrics: win/loss, discount depth, attach, renewals at risk. Challenge one premise: is the bundle a substitute or only adjacent | The note's named competitive threat, in the angle his pricing spine prefers. CASE; the company frame is the note's |
| C3 | "Profitability is a stated priority. How would you decide which of the two lines gets selling effort first, and what must a land deal look like to be worth it?" | CASE | [grounded] "reaching profitability" | Clarify what economics are available and the time horizon. Compare the lines on expected payback and strategic value. For a land deal, weigh price against cost to acquire and expansion potential, and use leading indicators because the lines are new. If it touches how targets are set for sellers, say that is where you would lean on his team's practice | Unit economics is his native language and profitability is a stated priority. CASE tagged because it is a live problem; CO content |

### D. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "I don't see classic sales-ops or quota-setting in your background. How would you handle that in this role?" | JD | [grounded] "No classic sales-ops or quota-setting experience." and "set annual volume targets with cross-org consensus" | **Highest-ROI prep.** Name the gap yourself, early, before he does: "I don't have classic sales-ops or quota-setting experience." Then the adjacent sentence at its scope: "I set annual volume targets with cross-org consensus." The pack's observation is that your material says targets, not quotas, so do not let one stand in for the other. Then a plan, said as a plan: learn how his team builds and carries its numbers, ask for a seat in a planning cycle, ask where the new lines plug in. Follow-up 1, "How is a volume target different from a quota?": if you know differences from your own work, say them; if you do not, say so plainly and ask how his team draws the line. Follow-up 2, "So you'd learn my craft on the job?": concede specifically, yes on classic sales-ops mechanics, and hold what you quoted. Follow-up 3, "What if the number is wrong on day one?": say what you would check first. Follow-up 4, "Why take that risk?": return to the quoted work. Never say it is "basically the same thing" | F7 is the stated gap and F5 the nearest quote. JD because it scores a requirement; Skeptic delivery. Arrives in some form in nearly any version of this conversation, and a rehearsed non-defensive answer changes the interview |
| D2 | "Partner-motion design experience is required for this role. Tell me how your background meets it." | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | State the quote at its scope: "I built a partner-level revenue model that was used in carrier negotiations." The pack's observation is that the material says the model, not the motion. Answer slot: if any part of how the company worked with those partners, beyond the model, was yours to design, say what and how you decided; if there was no such step, or it was not yours, say so plainly and stay with the model | F4 against the JD's "required". The word "required" makes this the second most predictable probe |
| D3 | "These are new product lines with little precedent. What have you built from a blank page?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | The quote carries one build: the model, partner-level, used in carrier negotiations. Answer slot: he will probe whether there was precedent. If there was nothing before it, say so; if it built on an earlier model or inherited approach, say that plainly. Do not dress a big-company example as scrappiness; say what you had to work with | F1 and F4 against the "two new product lines" line. The interviewer read flags a startup chapter, so resourcefulness is likely tested |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey: consulting, then consumer tech, and now here." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc with three beats: two years of strategy consulting at a top firm; nine years at a large consumer-tech company in product strategy and ops; then why this role. The third beat is an answer slot: give your actual reason in your own words, and point at something in the JD you want. The pack supplies no reason | F1's background, opened casually. EXP because it tests the CV's thread; Conversational delivery |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Say which tools and what for, in your words. The quote carries use: "I use AI tools daily." Answer slot: if you have built anything with them, say what and how far it went; if your use is as a user, say so plainly. Compass is an AI copilot, so a user's view of such tools is legitimate, as long as you call it that | F6, the JD's "plus", asked casually and still scored |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "That ARR number: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause and restate. Hold: "I proposed the change; the ~$400M ARR uplift is what it was credited with." Follow-up 1, "Credited by whom, on what basis?": say what you know; if you do not know, say so plainly. Follow-up 2, "So you can't say it caused the uplift?": concede specifically what you cannot say, and do not fold on the proposal. The pack's observation is that your material says credited, not caused | Persona stem, aimed at F1's figure. EXP because it tests attribution |
| F2 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations", "set annual volume targets with cross-org consensus", "skilled in SQL/Tableau" and "No classic sales-ops or quota-setting experience." | Build the sixty seconds from the first three sentences at their scope and nothing wider. Then concede one thing specifically: "I don't have classic sales-ops or quota-setting experience." Do not claim internal knowledge of Northwind | Persona stem. JD because the answer is scored against the stated requirements; Pressure delivery |

### G. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a message that was unwelcome, and a relationship intact after. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem. No values-style round is documented, so low weight; included so the style is not new live |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a named customer need, an internal metric that pulled the other way, and what you chose and why. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem. Same reason as G1 |

### Requirement coverage

| Requirement | Questions |
|---|---|
| own GTM strategy for two new product lines | C1, C3, D3 |
| identify whitespace across land/adopt/expand/renew | A5, C1 |
| run independent analysis in SQL and Tableau | A4, B4 |
| partner-motion design experience required | D2, C2 |
| strong cross-functional influence | B1, B2, B3 |
| AI experience a plus | E2, C1 |
| Sales-ops and quota-setting gap (F7) | D1, F2 |
| Headline figure on the CV (F1) | A1, A2, F1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| H1 | "Your path runs through pricing and monetization roles and an early-stage startup. What from the startup chapter do you still use here?" | Tied to his own path, and turns an interrogation into a peer conversation; shows you researched him |
| H2 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer: it asks what you can give, not only what you need |
| H3 | "Where do you see the seam between your team and mine, and which decisions need both of us?" | Surfaces the seam from B1 in his words and shows you think in terms of ownership |
| H4 | "How does your team look at whitespace across land, adopt, expand and renew today, and where is the data weakest?" | Speaks his data-driven language and tells you what you would inherit |
| H5 | "Is Compass one of the two lines this role covers, and how is bundling by the larger vendor shaping the plan?" | Shows homework and settles a question the pack cannot answer from your note |
| H6 | "What would you and the VP want to see from this role by day ninety?" | Gets the success criterion from a peer who shares the VP |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Drove or delivered the ~$400M ARR uplift | Inflated form of F1 | F1's quote at its own scope: proposed, credited. The limit is the pack's observation: the material says proposed and credited, not drove or delivered |
| Negotiated the carrier deals or set carrier terms | Inflated form of F4 | F4's quote at its own scope: the model was used in the negotiations. The material says the model, not the negotiating |
| Designed a partner motion | Inflated form of F4 | F4's quote at its own scope. D2's slot stays inside the model |
| Has set sales quotas or run sales ops | Negative the coach stated, F7 | The plain acknowledgment F7 gives: "I don't have classic sales-ops or quota-setting experience." No slot |
| Volume targets are the same as quotas | Inflated form of F5 | F5's quote at its own scope: annual volume targets, cross-org consensus. The material says targets, not quotas |
| Built or shipped AI products or AI-driven GTM | Inflated form of F6 | F6's quote at its own scope: uses AI tools daily. E2's slot asks only what you built, if anything |

## Sources

**Provided documents:** your message, which supplied the JD highlights, the summary of Priya's background (quoted as the coach's notes), the description of Dan's profile, and your research note (three stated priorities and the main competitive threat). The research note's source and date were not provided, so its currency is unverified. No dossier was present.

**Searches sent (all refused):**
- "Northwind Data company values principles": refused
- "Northwind Data interview process strategy operations": refused
- "Dan Kovac Director Sales Strategy Northwind Data": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | The search was refused. It would have supplied value names for VAL themes. A values cheat sheet would not have been built regardless, because no loop source documents a values-style round |
| 2. Northwind Data interview process, role family | unavailable | The search was refused. It would have named the loop's rounds. Persona weights rest on your own words: one 60-minute conversation with a peer |
| 3. Northwind Data strategy, recent news | skipped | Your research note supplies the priorities and competitive threat that feed C1 to C3 |
| 4. Dan Kovac, Northwind Data | unavailable | The search was refused. The interviewer read rests only on your description of his profile |
| 5. Representative JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Full JD text → any requirement outside the highlights gets a row and a JD-tagged question, and the six highlight rows get checked against the posting's own wording
- Priya's CV bullets verbatim, plus the readout or memo that credited the ~$400M ARR uplift and the revenue model's workbook (inputs redacted) → F1, F3 and F4 can move from medium toward high, and A1 to A3 become story-mapped beats rather than slots
- Priya's own answers to the answer slots in F1, F2, F3, F4, F6 and in A2, A3, A4, B2, B3, D2, D3, E2 → those rows become grounded quotes, and the bridges become her words
- Web search permitted, or Dan's public profile text pasted → a real interviewer read, with talks and writing, and a sharper H1
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a grounding brief on Northwind's strategy and org context, and sharper C1 to C3. Offered once
- The recruiter's prep email → stated focus areas and any announced deliverable; a documented loop would also settle whether a values round exists elsewhere in the process
- A `tuesday-dossier.md` → verified evidence, per-gap strategy and an evidence-derived objection ranking in place of the inferred one in D1; never a prerequisite
