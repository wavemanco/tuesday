I'll read the reference files the skill requires before writing anything.
Web search was refused, so I'll build the pack from your JD and background alone. I'll label everything not traceable to them as generic. Writing the file now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a6/runs/sonnet/alone/part-2/rooms/case-7-denied-d90d619a/saltmarsh-games_live-operations-producer_interview_pack.md`.

I built it for a hiring-manager round, since your note gives Tobias's title but not how he relates to the role. Web search was refused in this session. That means nothing in the pack comes from company research, and anything not from your JD or your own words is labeled `[generic]`. The searches that were refused (company values, interview process, strategy, Tobias's background) are listed in the Sources section.

The pack has 20 questions across seven interviewer styles. The deepest rehearsal is B1, the two gaps you named. Say "I haven't worked on a game with in-app purchases" and "I haven't led a team" plainly, then move to what you did do and how you would learn the rest.

Say the word and I'll play the Skeptic on B1 as a live drill, with follow-ups.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the person you'd report to, and did the recruiter say anything about the interview's format or what to prepare? The answer reweights the question banks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

- **Role:** Live Operations Producer, Saltmarsh Games (mobile game studio, about 350 people)
- **Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed: hiring manager, since your note gives his title and not his relationship to the role. If that is wrong, the persona weights change (see the upgrade menu).
- **Interview:** 60 minutes, Friday.
- **Built on:** your pasted JD and your background as you described it. Web search was not permitted in this session, so nothing here comes from company research. Anything not traceable to your JD or your own words is labeled `[generic]`.

## How to use this pack

- **Personas are how a question is asked; types are what it scores.** Each bank is one persona. Each question carries one type tag.
- **Type key:**
  - **VAL**: whether past behavior shows good judgment on values-style themes. No published Saltmarsh values were read, so these are generic behavioral prompts.
  - **EXP**: whether your own claims survive scrutiny, and what was actually you.
  - **JD**: a stated responsibility or requirement in the posting, including its gaps.
  - **CO**: company and strategy knowledge. This pack has none, because the research that would feed them could not run.
  - **CASE**: a live problem from the role, scored on structure.
- **Guidance is scaffolding, not a script.** Say it in your own words. Where a cell says "answer slot", it is an instruction about the interview and not a question for you now. Answer it from your own experience, or say plainly that the practice was not yours.
- **Bank letters skip F** so they never collide with the fit-snapshot rows F1 to F10. The banks are A, B, C, D, E, G and H.

## Prep triage

Sized to the time before Friday, assuming a day or less. Reorder if you have more.

1. **B1, then G1**, aloud, until the two plain acknowledgments are boring: "I haven't worked on a game with in-app purchases" and "I haven't led a team." This is the highest-ROI prep in the pack.
2. **D1**: the 90-second arc, built from your four quoted lines.
3. **The answer slots in F1, F2, F3 and F5**: write two sentences each, in your own words, including the honest branch where the practice was not yours.
4. **A2 and A3**: say the structure aloud (clarify, objective, segments, approach, metrics, risks).
5. **Three reverse questions** from section 11, chosen so one touches purchases.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title, with nothing inspected behind it, and the words stay there: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's live-events and two-titles wording makes a probe on how the calendar was set likely. Say which parts of the weekly calendar were yours to set and which came from others, in your own words; if it was set for you, or shared, say so plainly and describe how you ran it |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | low | [inferred] | discovery | The sentence shows a calendar and not whom it was coordinated with, so this is a lead and not a story. Answer slot: the JD names four teams, so expect a probe on each. Say which of design, art, engineering and community you worked with directly on drops, in your own words; if some were not part of it, or none were, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented monthly retention numbers, which is adjacent to reporting KPIs, and the words stay at that scope: "Presented the monthly retention numbers to the studio head." Answer slot: the JD's post-event review line makes a probe on the numbers likely. If you added anything to them before presenting, say what, in your own words; if you presented what others produced, say so plainly and stay with the numbers you presented |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | The quote already reaches the requirement in other terms, and the bridge rewords only the quote: "I wrote the release checklist our QA team still uses." Lead with the checklist and with QA still using it. It is a line with nothing inspected behind it, so expect a probe on it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | The years and the calendar are your words, and your title is associate producer; say it that way. Your material does not say whether the main title was live-service. Answer slot: the JD's live-service wording makes a probe likely. If the title was live-service, say what made it so, in your own words; if it was not, say so plainly and stay with the calendar you ran. Years of experience are not a gate in this posting |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it. Lead with it in its own terms: you ran it, weekly, for the last two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap, but expect a probe on how those numbers were counted (C1). Lead with what you presented and to whom, in the quote's terms |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | A written document other people still use is the named record you have, and the bridge rewords only the quote: "I wrote the release checklist our QA team still uses." Offering the checklist itself as a sample would upgrade this row (upgrade menu) |
| F9 | Not in the JD; included because you raised it: games with in-app purchases | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap your wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F10 | Not in the JD; included because you raised it: leading a team | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | Words: "I haven't led a team." The JD says coordinate, not manage, so the live question is F2. Then how you would get dates from people who do not report to you, said as a method you would use and never as a past |

## Persona table

The weights are my judgment, shown so you can correct them. Pass 1 is the relationship prior for a hiring-manager round, which favors Case/Strategist and Skeptic. Pass 2, interviewer signals, adds nothing: only his title is known, and his footprint could not be searched. Pass 3, the loop, adds nothing either: no loop source was read, so the fallback is the generic archetype (screen, hiring manager, panel) with no tilt. Your sentence "Never led a team, and never worked on a game with in-app purchases." is the one signal I weighted, toward Skeptic.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | Live problems from the job: plan a calendar, handle a slipped asset, diagnose a retention dip | Highest. A head of live operations has live problems at hand, and the JD describes planning, coordination and KPIs that translate directly to cases | Clarify, then objective, segments, approach, metrics, risks, thinking aloud. Challenge one premise politely |
| B. Skeptic | Quiet, persistent probing of the gaps: purchases, team leadership, one title versus two, why leave | Highest. A hiring manager derisks gaps, and you have named two yourself | Rehearse the most predictable objection (B1) until boring. Bridge only from your quoted lines; where there is none, say the limit plainly and give a plan |
| C. Data-Driven Prober | Reads your lines closely and asks for inputs and assumptions | Medium. The JD asks you to own KPIs and be comfortable with retention metrics, and you quote monthly retention reporting | Know what you can and cannot say about how each number was counted. Name the weakest assumption first |
| D. Conversational/Rapport | Friendly openers such as "walk me through the journey" | Medium. Most 60-minute interviews open this way, and casual questions are still scored | A 90-second arc built from your lines. Never answer "you've covered everything" to the reverse-question slot |
| E. Peer Evaluator | Seam-splitting between live ops and engineering, art, design, community | Low. He is likely senior to you in this role, but the JD's four-team coordination means the seam question can arrive from anyone | Offer seam principles and reciprocity rather than pretending to know the seam |
| G. Pressure | Time-boxed challenges such as "sixty seconds: why you" | Low. No signal for it, but G1 and G2 test how you hold a position | Hold through two follow-ups, then concede specifically and never fold the core |
| H. Values/Behavioral | Scenario probes on judgment | Low. No loop source and no published values page was read, so no values round is established. These are generic behavioral prompts from the persona stems | A story only where one of your lines carries it; otherwise a selection scaffold with the honest branch |

## Question banks

### Bank A: Case/Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch the plan for a four-week live-events calendar across two titles that share one art team. What do you need to know first?" | CASE | [generic] | Clarify before structuring: what each title's calendar looks like today, which team constraints are shared (the JD names design, art, engineering and community), and what the post-event review has to report. Then the objective, the two titles as segments, a draft cadence, the metrics you would watch, and the risks, thinking aloud. Challenge one premise politely, such as whether the two titles should share a cadence. The question needs no claim about your past, so the guidance makes none | The JD's calendar-for-two-titles line (F1's requirement) asked as a live problem, so it scores structure and not experience. `[generic]` because it is a pattern for the problem and not a fact about Saltmarsh |
| A2 | "An event you scheduled for next Thursday needs an art asset that art says will land two days late. Engineering's release window closes Wednesday. Walk me through the next hour." | CASE | [generic] | Ask first: is the asset essential to the event or cosmetic, can the Wednesday window move, and who decides. Then lay out the options in your own words, with what each costs, who has to be told (community for what players are told, QA for the release checks), and what you would record afterwards. Say which fact would change your answer. No claim about your past | Tests the coordination the JD asks for (F2's requirement) and the release-checklist link (F4's requirement) under a deadline. CASE because it scores the sequence of questions and decisions |
| A3 | "Day-7 retention on a recent event cohort came in below the usual range. Diagnose it." | CASE | [generic] | Ask what was measured and against what: which retention measure, which cohort, compared with what range, and what else shipped that week. Then separate the event's effect from everything else, name the assumption you would defend least before the interviewer does, and say what you would check first and what you would not conclude yet. If you do not know how a figure is counted, say so | F7's requirement as a diagnosis rather than a claim. CASE on structure, with Prober delivery |
| A4 | "The role owns the post-event review and the KPIs it reports. What does a review you would be proud of contain, and who needs to read which part?" | CASE | [generic] | Start from the decision the review should support: what was planned, what happened, what the team changes next. Then the KPIs: agreed before the event, each with a stated comparison and its weakest assumption. Say who reads which part, and how you would find out what the team already tracks before changing it. No claim about your past | F3's requirement asked as a design problem, so the answer does not depend on having owned a review. CASE with JD content |

### Bank B: Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't worked on a game with in-app purchases. How would you get up to speed on the commercial side of a live event?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." and "Presented the monthly retention numbers to the studio head." | **The highest-ROI rehearsal in this pack.** Say the plain acknowledgment first and without apology: "I haven't worked on a game with in-app purchases." Then stay with what you have said: "Presented the monthly retention numbers to the studio head." Then a plan, said as a plan: what you would ask to see first, whom you would ask, and what you would read, in your own words, with no timeline and no claim to know how purchases are tracked. Follow-up on how long until you are useful: return to the plan and give no number. Follow-up on whether this is central to the role: agree it matters if the role's KPIs touch purchases, and ask how much they do | F9 is the gap you stated, and it is the one a head of live operations at a mobile studio is likely to press, since the JD asks you to own KPIs (F3's requirement). That ranking is my judgment from your material and not a finding, and it is why this is the deepest rehearsal. JD because it scores a stated requirement and its gap |
| B2 | "The role runs the calendar for two titles. What you've described is one title. What changes when it's two?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Say it at its scope: "I ran the weekly content-drop calendar for our main title for the last two years." Then answer as thinking and not as experience: what you would need to know first about the second title, what the two calendars share (teams, release windows, QA), where they would collide, and how you would keep one view of both. Name the part you are least sure of | F1 is where the JD's headline responsibility outruns your evidence, so this arrives in some form. The guidance keeps to the quote's scope because the pack has no source for work beyond one title |
| B3 | "You haven't led a team. This role coordinates design, art, engineering and community on each update. How do you get dates from people who don't report to you?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." and "I ran the weekly content-drop calendar for our main title for the last two years." | Plain acknowledgment first: "I haven't led a team." Then the method you would actually use, in your own words: what you ask each team for, how a dependency becomes visible, and what you do when a date slips. Answer slot: the JD names four teams. Say which of design, art, engineering and community you worked with directly on drops; if some were not part of it, or none were, say so plainly and stay with the calendar you ran | F10 is a stated gap and F2 is the JD's coordination line, so the objection arrives as "no authority, many teams". JD content with Skeptic delivery |
| B4 | "Why leave a puzzle studio for this role, and why now?" | EXP | [generic] | Your material states no reason, so the words are yours. Answer slot: give your actual reason in your own words, and make it about the work in the JD (the calendar, the post-event review, the release checklist), without giving a reason you would not repeat on a second question. For why Saltmarsh, say only what you actually know of the company; if that is not much, say so and say what you want to learn | The Skeptic's motivation-consistency probe. EXP because it scores whether your story holds across follow-ups. `[generic]` because no company research ran |

### Bank C: Data-Driven Prober (medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You presented the monthly retention numbers to the studio head. Walk me through how those numbers were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Say what the quote carries: "I presented the monthly retention numbers to the studio head." Then four slots, each in your own words: which retention measure it was, how it was counted, which assumption behind it you would defend least, and which part was yours. Answer slot: if you built or changed the numbers, say what; if they came from someone else and you presented them, say so plainly. If you do not know how a figure was counted, say so | F7 and F3 rest on this one line, so a prober will start here. EXP because it tests attribution and counting. This is the defend-the-number row for your only metric |
| C2 | "Which KPIs would you want in a post-event review, and how would you tell a good event from a bad one?" | JD | [generic] | Define success before the event, not after: the comparison, the cohort, the window. Name each KPI's weakest assumption. Where the KPI depends on something you have not seen (such as purchases, B1), say so and say what you would ask to see. No claim about your past | F3's requirement asked directly. JD because it scores the stated KPI ownership |
| C3 | "Retention moved the week after a content drop. How do you know the drop caused it?" | CASE | [generic] | Name what else could have moved it: the cohort mix, other releases, calendar effects, a bug. Say what comparison would separate them, and what you would not conclude from one drop. Say plainly if you would need data you do not have. No claim about your past | A prober's attribution check. CASE because the answer is a structure for ruling things out |

### Bank D: Conversational/Rapport (medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey. How did you get here?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." and "I ran the weekly content-drop calendar for our main title for the last two years." and "Wrote the release checklist our QA team still uses." and "Presented the monthly retention numbers to the studio head." | A 90-second arc in four beats, one per quoted line, in order: the four years as an associate producer, the weekly calendar, the checklist QA still uses, the retention numbers you presented. Tell each at the quote's own scope, in your own words. Last beat, answer slot: give your actual reason for this role in one sentence, in your own words. End on the role's work and not your CV | The rapport-style opener is scored for economy and fit. F5, F6, F4 and F7 supply the beats. EXP because it checks your account against your lines |
| D2 | "What live events have you seen lately in games you play that you thought were done well?" | JD | [generic] | A selection scaffold: pick an event you actually saw in a game you actually played, and say what made it work or not in calendar terms (cadence, how clear it was to players, how much it asked of them). If none comes to mind, say so plainly, then name the nearest thing you have noticed or what you would want to study | A casual question about the job's hot topic, which is still scored. `[generic]` because it asks about your own taste, which this pack cannot supply |
| D3 | "Tell me about the release checklist you wrote." | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Story-map on the beats the quote states: you wrote it, and QA still uses it. Say both in your own words. Answer slot: the JD's QA line makes a probe on how it was used on releases likely. If you were part of how QA used it, say what part; if you wrote it and others used it, say so plainly and stay with the checklist you wrote | F4 and F8 are your strongest artifact-backed lines, and a conversational interviewer will pick it up. EXP because it tests what was actually yours |

### Bank E: Peer Evaluator (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Live ops and engineering sit side by side. Where's the seam when an update slips, and what happens when we disagree?" | JD | [generic] | Offer principles and not a map of a seam you have not seen: what each side owns, what each needs from the other and by when, who decides, and what gets written down. Add reciprocity: what you would bring to their work. No claim about your past | F2's requirement from a collegial angle. JD because it scores the coordination duty |
| E2 | "How do you handle credit when work spans design, art, engineering and community?" | VAL | [generic] | A selection scaffold: pick a time work spanned teams and credit could have blurred. It needs named teams, what each did, and what you said. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | The peer stem on credit-sharing. VAL because it scores behavior, though no company values were read |

### Bank G: Pressure (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why should we hire you over someone who has already run live events on a game with in-app purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." and "Wrote the release checklist our QA team still uses." and "Never led a team, and never worked on a game with in-app purchases." | Pause and restate. Hold only what the quotes carry: "I ran the weekly content-drop calendar for our main title for the last two years" and "I wrote the release checklist our QA team still uses." Concede the part that is true, specifically: "I haven't worked on a game with in-app purchases." Hold through two follow-ups by returning to those lines. Do not claim to ramp faster or to know the commercial side | The Skeptic's gap (B1) in a time-boxed form. JD with Pressure delivery. The hold is limited to what the quotes carry because a hold you cannot back is the one the second follow-up breaks |
| G2 | "That calendar — how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Say the sentence at its scope. Answer slot: say which parts of the calendar were yours to set and which came from others (design, art, engineering, community); if it was set for you or shared, say so plainly and describe how you ran it. Hold through two follow-ups by returning to what you ran, and concede anything that was shared | The attribution probe on F1 and F6. EXP because it tests precise credit |

### Bank H: Values/Behavioral (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] "Presented the monthly retention numbers to the studio head." | A selection scaffold: pick a time a number or message was unwelcome to someone senior. It needs a named stake, what you said, and how it landed. Your material says you presented the monthly retention numbers to the studio head; whether any month was unwelcome is not in it. If one was, say what and how it landed; if none was, say so plainly, then give the nearest thing or how you would handle it | A standard values-round stem, here tied to F7's setting. VAL, `[generic]` because no values page or loop source was read |
| H2 | "When did you put a player ahead of an internal metric?" | VAL | [generic] | A selection scaffold: pick a player-facing decision that cost an internal number. It needs the decision, the metric it cost, and whether you would do it again. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would decide | The customer-over-metric stem, adapted to players, for a live-ops role. No claim about your past is made |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two titles | A1, A2, B2, G2 |
| Coordinate design, art, engineering and community on each update | A2, B3, E1, E2 |
| Own the post-event review and the KPIs it reports | A3, A4, C1, C2, C3 |
| Manage the release checklist with QA | D3, A2 |
| 3+ years producing live-service games or apps | D1, G2 |
| Experience running a content calendar | B2, D1, G2 |
| Comfortable with player-retention metrics | A3, C1, C2, C3 |
| Clear written communication | D3, A4 |
| Raised by you, not the JD: in-app purchases, team leadership | B1, G1, B3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What does a good first quarter look like for this role, and what would tell you it wasn't going well?" | It asks him to define the scorecard before you are on it, and the answer shows what he weighs. |
| 2 | "How are the two titles' calendars planned today: one view or two, and where do they collide?" | It picks up the JD's two-titles line, so the answer fills the gap B2 exposes. |
| 3 | "Which KPIs does the post-event review report today, and who reads it?" | It ties to the JD's review-and-KPIs line and tells you what you would own and how it is read. |
| 4 | "Do the two titles carry in-app purchases, and how much does the review report on them?" | It asks for the one fact B1 depends on, in a way that shows you are already learning the commercial side. |
| 5 | "What does the release checklist look like with QA today, and what would you most want changed?" | It connects the checklist you wrote to theirs and shows you think about it as a working document. |
| 6 | "Of design, art, engineering and community, which seam is hardest to schedule with today?" | It shows you expect coordination to be the work, and it tells you where the first friction will be. |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led or managed a team | Negative you stated, F10 | The plain acknowledgment: "I haven't led a team." No slot |
| Worked on a game with in-app purchases, or owned monetization | Negative you stated, F9 | The plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot |
| Planned and ran live events across two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says a weekly content-drop calendar for your main title. The slot in F1 stays inside which parts of that calendar were yours to set |
| Owned the post-event review and the KPIs it reports | Inflated form of F3 | F3's quote at its own scope. The material says you presented monthly retention numbers. C1's slot asks only which part of those numbers was yours |
| Managed the release process with QA | Inflated form of F4 | F4's quote at its own scope. The material says you wrote the checklist QA still uses. D3's slot asks only what part you played in how it was used |

## Sources

Provided documents: the JD pasted in your message, and your background as you described it in your message. No dossier was present.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | The search was refused. It would have fed a values cheat sheet and company-specific VAL questions; the VAL bank is generic instead |
| 2. Saltmarsh Games interview process, live operations | unavailable | The search was refused. It would have named the real rounds and set persona weights from them; weights rest on the hiring-manager prior and a generic loop |
| 3. Saltmarsh Games strategy and recent news | unavailable | The search was refused. It would have grounded CO and CASE questions in current priorities; A1 to A4 are generic instead |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | The search was refused. It would have produced an interviewer read and a reverse question tied to his path; both are absent |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

Queries sent, all refused:

- "Saltmarsh Games mobile game studio company values"
- "Saltmarsh Games interview process Live Operations Producer"
- "Saltmarsh Games mobile news 2026"
- "Tobias Wrenfield Head of Live Operations Saltmarsh Games"

## Upgrade menu

- **Search permission, or pasted company material** (the values page, the careers page, any strategy notes) → a values cheat sheet if a values round shows up, CO and CASE questions grounded in current priorities, a documented loop, and persona weights read from it
- **Tobias's public profile or talks, pasted** → an interviewer read, persona tilt from his career pattern, and a reverse question tied to his path
- **Who Tobias is to the role, and anything the recruiter said about format or preparation** → persona weights confirmed or rebuilt, and a build section for any pre-declared deliverable
- **Your answers to the slots in F1, F2, F3 and F5, in your own words** → each row moves from a probe you must answer live to a quoted bridge, and the matching bank rows become story-mapped
- **The release checklist itself, or a redacted monthly retention deck** → F4, F7 and F8 move from medium toward high, since those are the inspectable artifacts for this field
- **A deeper research pass if search is permitted** (up to 6 more searches and 2 more fetches, several more minutes) → the strategy brief, interviewer talks, loop reports and recent org context
- **A `tuesday-dossier.md` from an earlier evaluation of this role** → verified evidence and sourced prohibited claims in place of the ones built here
