I'll read the reference files before building the pack.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a6/runs/sonnet/alone/part-2/rooms/case-6-denied-dc74e5c4/Larkfield-Systems_engineering-manager_interview_pack.md`. It's in loop mode: one shared fit snapshot, then a mini-pack for each of your three rounds. Each mini-pack has its own persona weights, 8 questions and 5 reverse questions. The host refused all three of my web searches about Larkfield, so nothing in it is researched. The company-specific questions are labeled `[generic]`, and there is no values cheat sheet. I also haven't seen the full JD or a CV, only the paragraph you gave me.

The prep that matters most is B2, the hardware-roadmap objection. You told me you've never owned a hardware-adjacent roadmap, and the JD asks you to partner with hardware on the roadmap. The pack expects that question in all three rounds, in different forms: B2 in R1, E3 in R2 and H1 in R3.

Say the word and I'll play the Skeptic on B2, with follow-ups.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Can you paste the full JD and your CV? The snapshot rests on a one-paragraph role description, and the full text would firm up several rows. If you'd rather skip it, the pack stands as is.
2. Do you want a deeper research pass? I'd need web search allowed, since my three searches were refused. It would cover the Larkfield lookups plus up to 6 more searches and 2 more fetches, and would take several more minutes. It would ground the company-strategy question and add a values cheat sheet for the VP round.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Larkfield-Systems_engineering-manager_interview_pack.md -----
# Interview prep pack: Engineering Manager, Larkfield Systems (loop of three rounds)

**Candidate:** Yusuf. **Mode:** loop — one shared fit snapshot, then a mini-pack per round.

| Round | When | Who and what | Relationship |
|---|---|---|---|
| R1 | Tuesday, 45 min | Director of Engineering, the would-be boss | Hiring manager |
| R2 | The Thursday after, 60 min | Panel: two staff engineers and a product manager | Peers and cross-functional partner |
| R3 | The following Monday, 30 min | VP Engineering, described by the recruiter as "values and leadership philosophy" | Skip-level, values-style |

The loop comes from your own words, which name each round's interviewers and length, so the persona weights rest on what you told me and not on an archetype. No interviewer names were given, so there is no interviewer read.

**What this pack was built on:** the one-paragraph role description and background you gave me, as quoted below. I have not seen the full JD or a CV. My three web searches about Larkfield were refused by the host, so nothing here is company-researched: company-specific questions are labeled `[generic]`, and there is no values cheat sheet or grounding brief (see Sources).

## How to use this pack

- **Personas are how a question arrives; types are what it scores.** Each round weights the personas differently, with the reasoning shown so you can recalibrate if you know something I don't.
- **Type key:** VAL = behavioral/values alignment. EXP = work-experience deep-dive. JD = role and JD-driven. CO = company and strategy knowledge. CASE = hypothetical or live problem.
- **Guidance is scaffolding, not a script.** Every claim about your past rests on a sentence you wrote, quoted in the Provenance column. An "answer slot" is an instruction for the interview, not a question for you now: say what is true, in your own words, or say plainly that the practice was not yours.
- **Highest-ROI prep in the whole pack: B2**, the hardware-roadmap objection. It will come in some form in all three rounds (B2 in R1, E3 in R2, H1 in R3).

## Fit snapshot (shared across all rounds)

Requirements are quoted from the role description you gave me ("JD" below means that description). Evidence is your own sentences.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (the leading-two-squads part) — JD | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | medium | [grounded] | transferability | Your material shows a team of six led for three years, not two squads, and the JD adds "eleven engineers". The words stay at that scope: "three years as a team lead of 6". Answer slot: the JD's two-squad line makes a probe on the step up likely. If you led more than one team, or a team that grew past six, say how, in your own words; if not, say so plainly and describe how you would run two squads |
| F2 | "own delivery, hiring and growth for 11 engineers" (the hiring part) — JD | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | none | The quote reaches the requirement in role-relevant terms. Lead with it in its own terms: you run the loop, for backend roles, and the figure is interviews. A figure raises a probe, so answer slot: how the 40 was counted, what it is sensitive to, the assumption you would defend least, and which part was yours; "I don't know exactly how it was counted" is an honest branch |
| F3 | "own delivery, hiring and growth for 11 engineers" (the delivery part) — JD | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | The quote is a reliability quarter and an on-call result, not ownership of a delivery commitment, and it says "after", not "because". Keep your verb: you "pushed" it through. Answer slot: the JD's delivery line makes a probe on delivery commitments likely. If you owned any, say which and how you handled them; if not, say so plainly and return to the reliability quarter. The 60% raises the same four-part slot as F2 |
| F4 | "own delivery, hiring and growth for 11 engineers" (the growth part) — JD | none given | none | [grounded] | discovery | Your material says nothing about developing engineers, so the words are an answer slot: the JD's growth line makes a probe on how you develop people likely. If you have grown anyone's role or career, say who or what and which part was yours, in your own words; if not, say so plainly and say how you would start with eleven engineers |
| F5 | "Lead two squads building device-management services" (the device-management part) — JD | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | low | [grounded] | discovery | The quote shows an engineering career and a payments employer; it does not show whether any of the work was near device management. Answer slot: if anything you have worked on resembles device management, say what it was and how close; if not, say so plainly and say what you would learn first |
| F6 | "partner with hardware and product on roadmap" (the hardware part) — JD | "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | none | [grounded] | discovery | You stated that you have not owned a hardware-adjacent roadmap, and the words for that are yours: "I haven't owned a hardware-adjacent roadmap". The JD says partner, not own, and your material is silent on working alongside hardware. Answer slot: if you have worked alongside a hardware team in any way, say what and how close; if not, or if it was not yours, say so plainly |
| F7 | "partner with hardware and product on roadmap" (the product part) — JD | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | low | [inferred] | discovery | The quote mentions roadmap pressure without saying who applied it or how it was resolved, so this is a lead, never a claim of product partnership. Answer slot: if the pressure came from product, say how it was worked through and which part was yours; if it came from elsewhere, or you did not resolve it, say so plainly |

Reading of the snapshot: F2 is the only row with gap type `none`. F6 is where the JD presses hardest on what you told me, and F1 and F3 are the rows the step up in scope will test.

---

# ROUND 1 — Tuesday, hiring manager (Director of Engineering)

## R1 persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the gaps: scope step-up, the hardware roadmap, domain | High. A hiring manager who would be your boss is derisking gaps (relationship prior), and F6 is a gap you stated yourself that the JD raises | Rehearse B2 until it is boring; bridges only from stated adjacent evidence (F1, F3); a concrete ramp plan |
| Case/Strategist | Live problems from the real role: two squads, delivery, hardware dependencies | High. Same prior; hiring managers test how you structure before how you answer | Clarify, objective, approach, metrics, risks; think aloud; challenge one premise politely |
| Conversational | Opening "walk me through your journey", then friendly follow-ups | Medium. 45 minutes almost always opens with a biography, and casual questions are still scored | A 90-second arc built from your own sentences; treat casual JD questions as scored |

Prober, Pressure, Values and Peer styles are low-weight in this round; they get their depth in R2 and R3.

## R1 question bank (8 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You inherit two squads building device-management services, and one of them keeps missing its dates. What do you want to know first, and what do you do in your first month?" | CASE | [generic] | Structure it aloud: first ask what "missing dates" means and how it is measured, then what is inside the squad's control and what depends on others. Then state your objective for the month, your approach, how you would know it was working, and the risk you would watch. Challenge one premise politely, for example whether the dates were realistic when set. The question needs no claim about your past, so the guidance makes none | A live problem set in the JD's two-squad delivery line (F1, F3), asked as a decision rather than a record; CASE because it scores structure; generic because it is a pattern, not a fact about Larkfield |
| A2 | "Product wants a feature for a hardware launch date, and your team says reliability work has to come first. How do you handle it?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Answer it as a decision first: what you need to know (what date, what the reliability work protects, what slips if each side wins), your options, how you would decide, and how you would keep the product relationship intact. If asked whether you have faced it, your own words are the quote: you pushed a reliability quarter through against roadmap pressure, and the on-call burden dropped 60% after. Answer slot: if the pressure came from product, say how it was worked through and which part was yours; if it came from elsewhere, or someone else resolved it, say so plainly and stay with the quarter | The JD's roadmap-partnership line (F7) meets your strongest story here; CASE because the question is a hypothetical, with the story as backup only if asked |
| A3 | "Sketch your first ninety days with these two squads." | CASE | [generic] | A plan, not a past: learn first (how each squad's work and dependencies actually run), then build relationships with each of the eleven engineers and with the hardware and product counterparts, then pick a small number of changes and say what you would deliberately leave alone for now. Say how you would find out what each engineer wants from their growth. It says what you would do, never what you have done | Covers the JD's growth and delivery lines (F3, F4) without claiming a past for F4, where your material is silent; generic because it is a role-family pattern |
| B1 | "You've led a team of six. This is two squads and eleven engineers, in a domain that isn't payments. What makes you ready for that step?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Hold what the quote carries: nine years in engineering, three of them as a team lead of 6. Then concede explicitly: two squads and eleven engineers is a larger scope than a team of six, and the JD's domain is device management while your current employer is a payments company. Answer slot: if you led more than one team or a team that grew past six, say how, in your own words; if not, say so plainly and describe how you would run two squads (where your time would go, who you would lean on). Hold through two follow-ups by returning to the team of six; never add to it | F1 and F5 are where the scope-and-domain objection lands; JD because it scores the stated requirement; Skeptic delivery |
| B2 | "You haven't owned a hardware-adjacent roadmap, and this role partners with hardware on the roadmap. How will you handle that side of the job?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | **The highest-ROI prep in this pack.** Level 1: say the plain acknowledgment first, in your words: "I haven't owned a hardware-adjacent roadmap." Then stop; do not hedge. Answer slot: if you have worked alongside a hardware team in any way, say what and how close; if not, or if it was not yours, say so plainly. Level 2 (interviewer: "what do you do in month three when hardware slips?"): answer as a plan, not a past: find out how hardware dates reach the squads, agree with the Director who the counterparts are, ask the engineers on the squads what they have seen. Level 3 ("what if you misjudge it?"): concede that you will learn some of it by getting it wrong, and say how you would surface that early. Hold by returning to the acknowledgment and the plan | F6 is a gap you stated and the JD raises; this is the one objection you can be sure arrives, in some form, from every interviewer. JD because it scores a named requirement; Skeptic delivery |
| B3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Name the weakness the JD itself raises and your own words already carry: the hardware-adjacent roadmap, with the plain acknowledgment from B2 and the same ramp plan. Do not swap in a milder weakness; a swapped-in one is the first thing a skeptic tests. The JD as you gave it does not ask for managing managers, so do not volunteer it. If asked directly, the words are yours: "I haven't managed managers." Then stop | F6 again, asked as an open prompt; JD because it scores the stated requirement; the question is a standard Skeptic stem |
| C1 | "Walk me through your journey, and what draws you to this role." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | A 90-second arc with the beats the quote states: nine years in engineering, three as a team lead of 6, currently at a payments company. Answer slot: what draws you to this role is yours to say; give your actual reason in your own words, and if it is mostly the domain or the scope, say which. Do not end the arc on a claim the quote does not carry | Almost certain to open a 45-minute round; EXP because it scores whether the biography holds up; F1 supplies the beats |
| C2 | "You run the hiring loop for backend roles. Tell me about it, including the figure on interviews." | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Keep both halves at the quote's scope: you run the loop, for backend roles, and the figure is about 40 interviews, not hires and not the whole company's hiring. Answer slot: how the 40 was counted, what it is sensitive to, the assumption you would defend least, and which part was yours; "I don't know exactly how it was counted" is an honest answer | F2 is your clearest match to the JD, and a figure is where probers go first; EXP because it tests attribution |

---

# ROUND 2 — The Thursday after, panel (two staff engineers and a product manager)

## R2 persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober | The staff engineers asking for the denominator on your numbers and how your hiring loop decides | High. Technical senior ICs price whether a manager's claims are real; F2 and F3 each carry a figure | Know what you can and cannot say about how the 60% and the 40 were counted, and say plainly when you do not know |
| Peer Evaluator | The product manager and the engineers asking where the seam is, what you need from them and what they get from you | High. A panel's prior blends the top two personas of each member's relationship (peer, cross-functional), and the PM sits on the roadmap line (F7) | Reciprocity framing; propose seam principles, not a seam you do not know; disagreement stories with spine and tact |
| Case/Strategist | A live, role-set problem, probably from a staff engineer | Medium. Panels with senior ICs often use a short live problem; this is a judgment from the panel's makeup, not a documented format | Think aloud; clarify first; say who decides what |

I do not know which panel member will play which role beyond their titles. Skeptic and Values styles can appear from any member; the objection in B2 returns here in collegial packaging as E3.

## R2 question bank (8 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Your on-call burden dropped 60%. How was that number counted?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Say what the quote says and no more: the burden dropped 60% after the reliability quarter, which is "after", not necessarily "because". Answer slot: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours; "I don't know exactly how it was counted" is an honest answer. Name the weakest assumption before they do | F3's headline metric; a defend-the-number question is the first thing a technical panel asks of any figure; EXP because it scores attribution |
| D2 | "You pushed a reliability quarter through against roadmap pressure. What was the pressure, and how did it get resolved?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Keep your verb: you "pushed" it through; do not upgrade it to "decided" or "convinced" unless that is what happened. Answer slot: say what the pressure was and who it came from, and how the question was settled, in your own words; if the decision was not yours alone, or there was no single decision, say so plainly and stay with the quarter and the 60% | F3 and F7 together: it tests whether the story survives a second question, and the engineers will want the tradeoff; EXP |
| D3 | "What does your hiring loop actually test, and who designed it?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Start with the quote: you run the loop, for backend roles. Answer slot: what the loop tests is yours to describe, in your own words; who designed it is the probe, so if you set it, say how you decided, and if you inherited it or changed only part of it, say so plainly and describe how you run it. Do not claim hires, only interviews | The engineers are deciding whether you will hire people they respect; F2 is a CV line with nothing inspected behind it, so expect depth; EXP |
| E1 | "Product and engineering sit side by side. Where is the seam between your squads and product, and what happens when we disagree?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Offer seam principles, not a seam you do not know: agree early who decides what, disagree in the open, bring options not complaints when a date moves. Reciprocity: say what you would offer product (for example, early notice when an engineering constraint will move a date), as a plan. If asked for a real instance, your own words are the quote at its scope. Answer slot: if the roadmap pressure in it came from product, say how it was worked through and which part was yours; if not, say where it came from | The PM's seat is the JD's "partner with product" line (F7); Peer stem; JD because it scores the stated requirement |
| E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | A principle first, in your own words, then pick one real instance from your own work that shows it: it needs a named piece of cross-team work, what was whose, and how credit was said aloud. If no such instance comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. The pack supplies no instance because none of your sentences carries one | A standard Peer stem; VAL because it scores behavior against collaboration values; nothing in the material answers it, so it is the scaffold case |
| E3 | "What would you need from hardware in your first month, and what would hardware need from you?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | This is B2 in collegial packaging, so the same hold: the plain acknowledgment "I haven't owned a hardware-adjacent roadmap", then a plan. Reciprocity as a plan, not a past: learn how hardware's dates are set and what changes them, and offer back early visibility into software constraints. Answer slot: if you have worked alongside a hardware team in any way, say what and how close; if not, say so plainly | F6 returning from a peer instead of a boss; the PM and engineers are pricing what you cost them; JD because it scores the stated requirement |
| F1 | "A device-management service your squad runs starts timing out for a fraction of devices after a release. Talk me through your first hour as the manager, not as the debugger." | CASE | [generic] | Clarify first (what is affected, since when, what changed), then who is doing what: you protect the engineers' focus, make sure someone owns communication, agree a rollback criterion with the on-call engineer. Say what you would decide yourself and what you would leave to the engineers. The question needs no claim about your past, so the guidance makes none | A live problem set in the JD's device-management line (F5); generic because it is a pattern for the problem; CASE because the panel scores role clarity under pressure |
| F2 | "A staff engineer tells you a service design won't scale and wants a quarter to rework it, while product wants that quarter for a launch. How do you decide?" | CASE | [generic] | Clarify what "won't scale" means and by when, then lay out options (partial rework, staged work, deferral), the decision criteria, who decides, and how you would communicate the outcome to both sides. State the one assumption you would defend least. No claim about your past | Echoes the reliability-versus-roadmap tension in F3 and F7 as a decision rather than a record; CASE |

---

# ROUND 3 — The following Monday, VP Engineering ("values and leadership philosophy")

## R3 persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario prompts on how you lead, what you stand for, what you would do under pressure | High. The recruiter's own words name a values-and-philosophy round, so this is guaranteed in this session | Stories only from your own quoted sentences; "we" for context, "I" for contribution; where the hard truth did not land, say so |
| Pressure / skip-level | Time-boxed answers, "why you", "how much was actually you" | High. A 30-minute skip-level round with an executive prior; composure is scored | Pause, restate, anchor in what you said, hold through two follow-ups before conceding anything real |
| Conversational / Strategist | Open questions on the company and your direction | Medium. A short executive conversation often closes on altitude; I could not research Larkfield, so company-specific content here is generic | Ask rather than recite; have two specific observations from Larkfield's own public pages before Monday |

Larkfield's published values were not in hand, so there is no values cheat sheet. The questions below take their theme from the recruiter's words, "values and leadership philosophy".

## R3 question bank (8 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "How do you think about what a good engineering manager does?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure"; "I run our hiring loop for backend roles — about 40 interviews last year" | Your philosophy is yours to state; the pack will not write it. Give two or three principles in your own words. For each, name one thing from your quotes that shows it (the reliability quarter, the hiring loop), at their scope. Where a principle has nothing behind it yet, say plainly that it is how you intend to work, not something you have done | The recruiter named "leadership philosophy"; VAL because it scores whether your behavior matches your stated principles; F2 and F3 are your only quoted behaviors |
| G2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The quote carries a reliability quarter, roadmap pressure, and a 60% drop in on-call burden. Those are the beats, in your own words. Answer slot: if getting the quarter through involved telling someone senior something unwelcome, say what and how it landed; if it did not, or it landed badly, say so plainly. If this is not your story for the question, use a selection scaffold: pick a time you told someone senior something they did not want to hear, with a named stake and an intact relationship afterward; if none comes to mind, say so plainly | The Values stem mapped to the one story your material carries (F3, F7); VAL; the pull to supply a tidy ending is the failure to avoid |
| G3 | "Tell me about a time you put someone's growth ahead of a delivery date." | VAL | [generic] | Your material carries nothing on this (F4), so it is the scaffold case: pick a time you made room for someone's development when a date was at stake, with a named person or role, what you gave up, and what changed for them. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | The JD's "growth" line (F4) turned into a leadership-values prompt; VAL; the honest branch matters because nothing quoted covers it |
| G4 | "Where does this role take you in three years?" | VAL | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Answer slot: what you actually want next is yours to say. If it includes leading other managers, say that plainly beside the fact in your own words, "I haven't managed managers", and let the interviewer judge; do not claim readiness. If it does not, say what you do want | A leadership-philosophy round often tests ambition against what you have actually done; you stated the negative yourself, so the acknowledgment has a source; VAL |
| H1 | "Sixty seconds: why you over a manager who has already run hardware-adjacent teams?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I run our hiring loop for backend roles — about 40 interviews last year"; "I've never managed managers and never owned a hardware-adjacent roadmap" | Pause, restate, then hold only what the quotes carry: nine years in engineering, three as a team lead of 6, you run the backend hiring loop. Concede specifically that you have not owned a hardware-adjacent roadmap, and say how you would close that. Do not invent a rival or a ranking. Hold through two follow-ups by returning to these, never by widening them | F6 and F1 under time pressure; EXP because it scores honest self-assessment; Pressure stem |
| H2 | "That 60% on-call drop: how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Use "we" for context and "I" for contribution. The quote gives you the push: you "pushed a reliability quarter through". Answer slot: what others did, how the 60% was counted, and the assumption you would defend least; if you do not know how it was counted, say so. Concede plainly anything that was not yours; do not fold on the part that was | F3's headline metric under attribution pressure; EXP; the core hold-then-concede drill of this round |
| I1 | "What do you see happening in industrial IoT, and where does Larkfield fit?" | CO | [generic] | I could not research Larkfield, so this has no grounded content. Before Monday, read Larkfield's own public pages and recent news and bring two specific observations; do not recite from memory. In the room, say what you have read, ask where you are wrong, and tie it to what engineering has to deliver. Answer slot: any view of industrial IoT is yours to give in your own words; if you have none yet, say so and ask | An executive round tests company altitude; CO because it scores homework; generic for lack of research, and the upgrade menu says what would fix that |
| I2 | "What do you want your engineers to say about you a year from now?" | VAL | [generic] | Answer slot: this is a philosophy question, so the answer is yours, in your own words. Pick one or two things you could point to behavior for; if the evidence for one is the reliability quarter or the hiring loop, say it at the quote's scope. Do not claim an outcome you have not seen | A conversational close to a values round; VAL; nothing quoted answers it, so it is a scaffold |

---

## Requirement coverage (all rounds)

| JD requirement (from the role description you gave) | Covered by |
|---|---|
| "Lead two squads building device-management services" | A1, A3, B1, F1, I1 |
| "own delivery ... for 11 engineers" | A1, A2, D1, D2, F2, H2 |
| "own ... hiring ... for 11 engineers" | C2, D3 |
| "own ... growth for 11 engineers" | A3, G3 |
| "partner with hardware ... on roadmap" | B2, B3, E3, H1 |
| "partner with ... product on roadmap" | A2, E1, D2 |
| "industrial IoT, ~600 people" (company context, not a task) | I1 — none otherwise, and why: it is company context, not a requirement |

Headline figures: the 60% is covered by D1 and H2, and the 40 interviews by C2. The recruiter's "values and leadership philosophy" is covered by G1 to G4 and I2.

## Reverse questions, by round

**R1 — Director of Engineering**

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "What should the two squads' delivery look like in six months, and what is in the way today?" | Shows you are scoping the job before you own it, and gives you the real priorities to test F1 and F3 against |
| RQ2 | "How do hardware and software roadmap decisions get made here, and where do they get stuck?" | Moves B2's objection onto the interviewer's ground: you are asking to learn the seam you told them you have not owned |
| RQ3 | "Where would you want me strongest in my first month, and where would you expect to cover for me?" | Names the ramp openly and invites the manager into it, which is stronger than waiting for the weakness probe |
| RQ4 | "What did earlier managers of these squads do that worked, and what did not?" | Avoids repeating a failure and tells you what the Director values in a manager |
| RQ5 | "How do you like to be kept informed, and what makes you step in?" | A would-be boss answers it from their own habits, and your follow-up shows you manage up |

**R2 — Panel**

| # | Question | Why it lands |
|---|---|---|
| RQ6 | "What do you most want from a manager that you have not always had?" | Asked of the staff engineers: it shows you are pricing what the team needs from you, not defending your own plan |
| RQ7 | "Which decisions should a manager never make without you?" | Signals respect for senior ICs' turf, which is the peer test |
| RQ8 | "Where does the roadmap process between product, hardware and the squads work well, and where does it strain?" | Asked of the PM: lets them describe the seam you cannot yet see (F7) |
| RQ9 | "What could a new manager do in the first month that would genuinely help you?" | The reciprocity question; it turns the panel from judges into partners |
| RQ10 | "What is the on-call and reliability situation for these services today?" | Ties to the reliability quarter in F3 without claiming it applies here |

**R3 — VP Engineering**

| # | Question | Why it lands |
|---|---|---|
| RQ11 | "What does good leadership look like here when it is going well, and what does it look like when it is not?" | Lets the VP state the philosophy you are being scored against |
| RQ12 | "Can you point to a decision this company made that reflects what it says it values?" | Substitutes for the values research I could not do: it asks for values as behavior |
| RQ13 | "How do you develop engineering managers here, and what does the path beyond this role look like?" | Answers G4 from their side and shows you are thinking about the path to managing managers without claiming readiness |
| RQ14 | "Where is engineering investing next year, and what does that mean for these squads?" | Gives you the strategic altitude I could not research |
| RQ15 | "What would make this hire a success from where you sit, a year in?" | Closes on the outcome the VP scores you against |

## Prohibited claims (shared across rounds)

Built from the fit snapshot before the banks were written. The pack will not coach these, and the honest form for each is below.

| Not coached | Basis | Honest form |
|---|---|---|
| Led or managed other managers | Negative you stated, F6 | "I haven't managed managers." Plain acknowledgment from your own sentence; no slot |
| Owned a hardware-adjacent roadmap | Negative you stated, F6 | "I haven't owned a hardware-adjacent roadmap." No slot on the owning claim; the slot is only on working alongside hardware |
| Led two squads, or eleven engineers | Inflated form of F1 | F1's quote at its own scope: three years as a team lead of 6. The limit is the pack's observation, not words for you: your material shows a team of six |
| Owned delivery for a roadmap | Inflated form of F3 | F3's quote at its own scope: you pushed a reliability quarter through. The material shows a reliability quarter, not a delivery commitment |
| Cut on-call burden by 60% through your reliability quarter alone | Inflated form of F3 | The quote says the burden dropped 60% after the quarter. How it was counted and what part was yours are the slots in D1 and H2 |
| Hired about 40 engineers, or ran hiring for the company | Inflated form of F2 | F2's quote at its own scope: you run the loop for backend roles, and the figure is interviews |

Not listed because your material is silent, so each is an answer slot instead: device-management experience (F5), developing engineers (F4), and working alongside hardware or product (F6, F7).

## Sources

**Provided documents:** your message (the role description, the three rounds, and your background). No CV, full JD, interviewer profile, assessment or `tuesday-dossier.md` was provided or consumed.

**Searches sent (all three refused by the host; nothing returned):**

- "Larkfield Systems industrial IoT company values" — refused
- "Larkfield Systems interview process engineering manager" — refused
- "Larkfield Systems industrial IoT device management strategy news" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Would have moved the values cheat sheet for R3 and grounded the VAL questions in published values; neither exists in this pack |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Would have moved the loop structure; it moved nothing, because your own words already establish the three rounds and who runs each |
| 3. `Larkfield Systems strategy` / recent news | unavailable | Would have moved I1, RQ12 and RQ14 and a grounding brief; I1 is therefore generic |
| 4. `interviewer name Larkfield Systems` | n/a | No interviewer names were given, so there was no query to form; the interviewer read is absent |
| 5. representative `Engineering Manager` JD | skipped | The role description you gave fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full JD text → F1 to F7 become `[grounded]` on the full posting, and any requirement the one-paragraph summary dropped gets a question
- Your CV → medium rows can only rise with something inspectable; for an engineering manager that is the on-call report or incident trend behind the 60% (F3) and the interview scorecard or loop document behind the 40 interviews (F2)
- Your own answers to the answer slots (F1, F3, F4, F5, F6, F7) → each regenerates its row and the questions that draw on it, with your words quoted
- Each interviewer's name and public profile → an interviewer read, persona weights per panel member and a reverse question tied to each person's path
- The recruiter's notes for each round (focus areas, any exercise or presentation) → coverage for pre-declared deliverables and a sharper round-by-round weighting
- Larkfield's published values, or the recruiter's description of them → a values cheat sheet for R3 and grounded VAL questions
- A strategy or recent-news brief for Larkfield (or search access for the research that was refused) → grounded CO questions and a grounding brief
- A `tuesday-dossier.md` from an earlier evidence-check → verified claims, allowed strategies per weak area and a standing prohibited-claims list
