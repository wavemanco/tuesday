I'll read the skill's reference files before building the pack.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a6/runs/sonnet/alone/part-2/rooms/case-3-denied-1b8026d8/stripe_product-operations-manager_interview_pack.md`.

I built it for a final round with unknown structure and near-flat persona weights. It has 20 questions across seven interviewer styles, a worksheet fit snapshot, a requirement-coverage table and six reverse questions.

The web searches I tried were refused, so nothing in it comes from research on Stripe. That means no Stripe values, loop structure or strategy questions, and every row is labeled `[generic]`. Your CV and the job description would change the most. The upgrade menu at the end of the file lists the rest.

Say the word and I'll play the Skeptic on B1, the question the pack names as its highest-ROI prep. I can also save a `tuesday-dossier.md` recording the gaps this prep exposes, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Two questions would restructure it:
1. Who is your final round with (hiring manager, a peer, a skip-level, a cross-functional panel), and is it one session or several? Also, did the recruiter mention focus areas or anything you must prepare, such as a presentation or exercise?
2. Can you paste the job description and a few lines from your CV? I'll build the pack without them if you'd rather not, but the weakest-area answer and your story maps depend on them.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe

Round: final round. Interviewer name, relationship and number of sessions: not given. This pack is built on role-family patterns alone, because no CV, job description or research result was available. Every row is labeled `[generic]` for that reason.

## How to use this pack

- Personas describe how a question is asked. Types describe what is being scored.
- Guidance is scaffolding, not a script. Where a question asks about your past, the guidance tells you what a strong answer needs and how to choose the story. It supplies no story, because this pack holds none of your sentences. You choose the story from your own experience, and every detail you say aloud has to be yours.
- Where no story comes to mind, the honest move is to say so plainly, then give the nearest thing your experience does carry, or how you would handle it.

Type key:

| Tag | Meaning |
|---|---|
| VAL | Whether past behavior shows a value, not generic virtue |
| EXP | Whether your claims about your own work survive scrutiny, and what was actually you |
| JD | Whether you can do the role as described, gaps included |
| CO | Company and strategy knowledge. None here: no strategy research ran |
| CASE | A live problem, scored on structure and reasoning |

## Fit snapshot (worksheet)

You have shared no CV or job description, so this is the worksheet variant. Requirements are role-family patterns written without a source, so they are plain prose and raise no answer slots. Every evidence cell is empty until you supply your own sentences.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinating work across engineering, go-to-market and support teams around launches or changes (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a named launch or change, the teams involved, and your part in it, in your own words. Selection scaffold: pick a time work crossed several teams and you were the one keeping it moving; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Designing or improving a process so teams work better (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a process you set up or changed, what it replaced, and what happened after. Selection scaffold: pick a process change where you can say what was different afterwards; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Using data to decide or to show whether something worked (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a metric you used, how it was counted, and what decision it informed. Selection scaffold: pick one number you can explain end to end, including what it does not capture; if no such number comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Influencing people you have no authority over (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a disagreement, who held the decision, and what you did that moved it. Selection scaffold: pick a time you needed a decision from someone who did not report to you; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Prioritizing competing requests under ambiguity (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a moment you had to say no or not yet, and how you decided. Selection scaffold: pick a time two requests competed for the same time; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

No gate rows: nothing supplied states a term such as location, authorization or schedule. A job description would show whether any exists.

## Requirement coverage

| Requirement | Questions |
|---|---|
| F1 cross-team coordination | A1, A3, E1, E3 |
| F2 process design | A3, B4, C3 |
| F3 data and metrics | A2, C1, C2, C3 |
| F4 influence without authority | A4, D1, E2 |
| F5 prioritization under ambiguity | A4, B4 |
| Company and strategy knowledge | none, and why: no strategy research ran, so a CO question would be written from memory |

## Persona table

No source establishes this loop. "Final round" says nothing about how many sessions there are or who runs them. The weights below rest on the generic archetype (screen, hiring manager, panel) with near-flat weights, not on Stripe's documented process. If your final is several sessions, send the schedule and the pack will split into per-session mini-packs.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | Live problems about launches, metrics and process | Highest. A final round for an operations role usually tests structure under live problems. Reasoning is from the role family, not from Stripe | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise |
| B. Skeptic | Gaps, motivation, why this move | High. Final rounds derisk the hire, and your gaps are unknown to this pack | Rehearse the weakest-area question until it is boring. Give the real answer and a ramp plan |
| C. Data-Driven Prober | Pushes on any number you cite | Medium. Any metric you mention invites it | Know how each number was counted and say plainly if you do not |
| E. Peer Evaluator | Seam with product and engineering peers | Medium. Operations roles sit between teams | Offer seam principles, not a map you do not know |
| D. Values/Behavioral | Behavior stories against published values | Medium-low. No loop source shows a values round, and no values page was read | Prepare two flexible stories you can bend to a value named on the day |
| F. Pressure | Time-boxed challenges to your motives | Low-medium | Hold, then concede specifically |
| G. Conversational | Casual opener, still scored | Low-medium. Likely as an opener | A 90-second arc you can say aloud |

## Question banks

Highest-ROI prep: B1. A weakest-area question arrives in some form in nearly every final round, and this pack cannot yet see your weakest row. This choice is `[generic]`. A CV would let me aim it.

### A. Case/Strategist (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two weeks before a launch, engineering says it is ready and the support team says they cannot support it. Walk me through what you do." | CASE | [generic] | Ask first what "ready" means to each side and who owns the launch decision. Then state the objective, list two or three options with their costs, say what you would do and what you would watch. Challenge one premise out loud. The question asks about no past, so this guidance claims none | Tests F1 as a live decision rather than a story. CASE because it scores structure |
| A2 | "An adoption metric for a product has dropped 20 percent over a month. How do you diagnose it?" | CASE | [generic] | Clarify the definition and the time window. Separate a measurement change from a real change, then segment, then line up what changed that month. Say which data you would pull first and what would change your mind | Tests F3. The 20 percent is the interviewer's hypothetical, not your figure |
| A3 | "You are asked to set up a process for how product feedback reaches the teams that build. Where do you start?" | CASE | [generic] | Start by learning what exists and who uses it, before designing anything. Name how you would know it is working and the risk of a process nobody uses. Say what you would not build yet | Tests F1 and F2 together. Operations interviewers listen for restraint |
| A4 | "Three teams each want your help this quarter and you can only support two. How do you choose?" | CASE | [generic] | State your criteria aloud before applying them. Say how you would tell the third team, and what you would offer them instead | Tests F4 and F5 |

### B. Skeptic (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name a real area, taken from the fit snapshot row where you have the least to say, and say what you would do in the first 30 days about it. Never answer "none". If your honest weak area is one the role leans on heavily, say that plainly and keep to the plan | The highest-ROI prep in this pack. JD because it scores the role-family requirements, not a posting you supplied |
| B2 | "Why this move, and why Stripe, and why now?" | EXP | [generic] | Your reasons have to be your own. A reason specific to Stripe has to come from something you have read and checked yourself, because this pack could not research the company. If you do not yet have one, research before the interview and treat that as the main prep gap | EXP because it scores consistency of your own story |
| B3 | "What would make this role the wrong move for you?" | JD | [generic] | Answer from what you actually care about. A real condition said calmly beats a flattering non-answer. If you cannot name one, say what you are still trying to learn about the role | Skeptics test whether the motivation survives a counterfactual |
| B4 | "Walk me through your first 90 days." | CASE | [generic] | Structure it as learn, then map, then one small visible improvement, with a check-in point. Say what you would not change in the first month. Make no claim about what you have done before | Tests F2 and F5 and gives the skeptic a concrete ramp plan |

### C. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Pick a number from your work that you are proud of. Walk me through how it was counted." | EXP | [generic] | You choose the number. Be ready to say how it was counted, what it is sensitive to, which assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. If no such number comes to mind, say so plainly, then give the nearest thing your material does carry | Open prompt, since this pack holds none of your figures. Tests F3 |
| C2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | Name it before being pushed. Say what you checked and what you did not. Never invent a baseline or a method you did not use | Follow-up to C1. The weakest-assumption move turns a gotcha into credibility |
| C3 | "What would you measure to know whether a new internal process is working, and which of those measures would you distrust?" | CASE | [generic] | Pick one outcome measure and one behavior measure. Say how each could be gamed or misread. Ask what decision the number would feed | Tests F2 and F3 without needing your history |

### D. Values/Behavioral (2)

No published Stripe values were read, so these use common behavioral stems. If you can name a value the interviewer cites, adapt the story you choose.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Choose a moment where the hard truth actually landed and say what changed. Use "we" for context and "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem. Tests F4 |
| D2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Choose a time with a named trade-off and a result you can state without embellishment. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem |

### E. Peer Evaluator (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Where is the seam between product operations and product management, and what happens when we disagree?" | CASE | [generic] | Offer principles rather than a map: who decides what, how disagreements surface early, and what you do when you disagree and lose. You do not know their team's actual seam, so ask what it is today | Tests F1 and F4 |
| E2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Say what you actually do in practice, in your own words. If no example comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem. Tests F4 |
| E3 | "What would you need from me in your first month, and what would you bring?" | CASE | [generic] | Answer both halves. Make the ask small and specific, and offer something your own experience supports | Reciprocity framing. Tests F1 |

### F. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over someone who has done this exact job before?" | EXP | [generic] | Pause, restate, and answer with the closest thing you have actually done. Concede specifically what you have not done. Hold the core claim through two follow-ups and never claim experience you lack | Hold-then-concede. The claim held must come from your own material, which this pack does not have |
| F2 | "That result: how much of it was actually you?" | EXP | [generic] | Separate what you did from what the team did, in one sentence each. Concede the shared parts freely, because a candidate who claims everything loses the room | Follow-up to any story you tell. Attribution honesty |

### G. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | Build a 90-second arc of three or four moves from your own career, each one something you did, ending on why this role. Say it aloud until it is under two minutes | The likeliest opener, and still scored |
| G2 | "What drew you to product operations as a discipline?" | EXP | [generic] | Answer in your own words. Say what you enjoy about the work, not what you think the role should sound like | Tests genuine interest |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What does a good first 90 days look like for this role, and what would make you say it had gone well?" | Shows you are thinking about outcomes, and gives you the scoring sheet |
| 2 | "Where do product operations and product management divide work today, and where is that line still moving?" | Shows seam awareness and invites a peer-level answer |
| 3 | "What is a process or program this team built that you would now do differently?" | Invites candor and shows you expect trade-offs |
| 4 | "How does the team decide what product operations works on, and what does it say no to?" | Mirrors the prioritization the role requires |
| 5 | "What would a new person do in their first month that would genuinely help your team?" | Reciprocity question, strong with peers |
| 6 | "What is still unresolved about this role that you would like the person in it to help figure out?" | Surfaces the real ambiguity and signals comfort with it |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| No entries | You shared no CV, no stated negative and no sentence about your past, so there is nothing to inflate and nothing contradicted | Not applicable. This is the state of the inputs, not a finding that your background has no limits. It fills in once your material arrives |

## Sources

Provided documents: your message naming the company, the role and the round. No CV, job description, interviewer information or recruiter guidance.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Search refused, no results. It would have moved the values cheat sheet, which is dropped |
| 2. Stripe interview process, product operations | unavailable | Search refused, no results. It would have fixed the loop structure and persona weights, which now rest on the generic archetype |
| 3. Stripe strategy and recent news | unavailable | Search refused, no results. It would have supplied CO questions, which are absent |
| 4. Interviewer name and Stripe | n/a | No name was given, so there was no query to form |
| 5. Representative Product Operations Manager JD | unavailable | Search refused, no results. It would have grounded the fit snapshot requirements, which are role-family patterns instead |

Queries sent, all refused: "Stripe operating principles values"; "Stripe interview process Product Operations Manager final round"; "Stripe strategy news 2026"; "Stripe Product Operations Manager job description responsibilities".

## Upgrade menu

- Web search allowed in this session → rows 1, 2, 3 and 5 above rerun: Stripe's published values by name, the documented loop, current strategy and CO questions, and a representative JD so the fit snapshot rows can be sourced instead of `[generic]`. A deeper pass, with up to 6 more searches and 2 more fetches and several more minutes, can follow if you want it
- The job description text → the five role-family requirements become quoted ones, mid-list requirements get their own questions, and any gate such as location or work authorization is surfaced
- Your CV or a few lines on your background → the fit snapshot fills with your own sentences, the weakest-area question B1 is aimed at your real gap, and the story-selection scaffolds become story maps
- The interviewer's name and role → persona weights read from their public footprint, and a reverse question tied to their own path
- The recruiter's guidance, including any exercise, presentation or focus areas → a build section for each declared deliverable, and coverage tuned to stated focus areas
- The schedule, if your final is several sessions → per-session mini-packs with their own persona weights
- A tuesday-dossier.md from job-underwriter → verified evidence, allowed strategies for weak areas, and the objection worth the deepest rehearsal, instead of a generic guess
