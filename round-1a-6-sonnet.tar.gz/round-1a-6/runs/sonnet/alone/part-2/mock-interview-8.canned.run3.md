I'll read the reference files the skill points to before building the pack.
Your prep pack is saved as `ashgrove-credit-union_member-experience-lead_interview_pack.md`. I built it in loop mode, with one shared fit snapshot and a mini-pack for each of the three rounds on 5 December. Interviewer names aren't assigned yet, so persona weights come from each round's role and from what the recruiter said about it.

**What stands out for you, Dara**
- **Highest-ROI prep: C1, in Round 2.** Your future manager will press on the distance between "own the process across branches and the contact centre" and what you've told me: you handled the branch's formal complaints log, and you've never worked in a contact centre. C1 rehearses that with three follow-ups. The same objection comes back in the panel as H2 and I1.
- **Presenting above regional level is the second gap.** You've said you've never done it, so B3 and C4 rehearse saying so plainly and then giving a plan.
- **Excel is unconfirmed.** Your message says "spreadsheet", so the pack doesn't claim Excel. F1 has you say what you built it in.
- **Several answer slots need your own words.** The JD asks about regulated complaints, digital teams and coaching supervisors, and your material doesn't speak to them. Those spots have two honest branches, and either is a good answer. Reply with your real answers and I'll rebuild those rows.
- **The panel round is built on the four published values.** The values cheat sheet maps each value to your quoted sentences where one fits. Where none does, it gives a selection scaffold.
- **The research tier was L1 with zero searches.** Your pasted values text, the recruiter's email and the July strategy brief already covered every research target, so nothing was fetched.

I can run a drill as the skeptical Head of Member Services on C1.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara. **Loop:** three rounds on 5 December: (1) 30 minutes with the recruiter; (2) 45 minutes with the Head of Member Services, who would be your manager, mostly behavioural; (3) 60 minutes with a panel of two branch managers, including a 20-minute case on a complaint escalation, which is also the values round, scored against the four values.

**Built as:** loop mode (three scheduled rounds), one shared fit snapshot and a mini-pack per round. Interviewer names are not assigned yet, only roles, so there is no interviewer read; persona weights come from each round's relationship and from the recruiter's description of it.

**Highest-ROI prep in this pack:** question C1 (Round 2). A manager buying capability will press on the distance between owning the complaints process across branches and the contact centre and what your material carries: "I handled the branch's formal complaints log" and "Never worked in a contact centre". It will be asked in some form, and the same objection returns in Round 3 as H2 and I1. Rehearse C1 until it is boring.

## How to use this pack

- **Personas describe how a question arrives; types describe what it scores.** Rehearse both: the same question lands differently from a friendly recruiter, a skeptical future manager and a values panel.
- **Type key.** VAL: whether past behaviour shows the company's published values. EXP: whether the claims in your background survive scrutiny. JD: the listed job's responsibilities, requirements and terms. CO: company and strategy knowledge. CASE: a live problem from the role.
- **Guidance is scaffolding, not a script.** Say it in your own words. Every claim about your past rests on a sentence you wrote, quoted in the Provenance column; where the material is silent, the guidance is an **answer slot**: an instruction with two honest branches, either of which is a good answer.
- **Provenance labels.** `[grounded]` traces to a document you provided. `[inferred]` is this pack's derivation, named. `[generic]` is a rehearsal pattern with no claim about Ashgrove or about you.
- Question IDs run by persona across the whole loop (A, B in Round 1; C to F in Round 2; G to I in Round 3), so you can ask for a drill by ID.

## Fit snapshot (shared by all three rounds)

Requirements are quoted from the JD you pasted. Evidence is your own words from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | Your quote reaches the years line in other terms, and the words stay its own: "I have 6 years in retail banking, the last 3 as a branch supervisor." Do not rename the work in the JD's vocabulary; let the interviewer judge the match. Expect a probe, since nothing has been inspected behind the line |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | Your material says a formal complaints log at one branch and does not show what governed it. Words: "I handled the branch's formal complaints log." Answer slot: the JD asks for complaints experience of a particular kind, so expect a probe on what governed the log. If it was kept under outside rules or deadlines, say which and how they shaped what you did; if it was an internal procedure only, or you do not know what governed it, say so plainly and stay with the log |
| F3 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Words: "I handled the branch's formal complaints log." The limit is the pack's observation: your material says the branch's log, not the process across branches. Answer slot: the JD's end-to-end line makes a probe on the stages around the log likely. If any stage beyond the log was yours to run or change, say which and what you did; if the log was the whole of your part, or the rest was not yours, say so plainly and stay with the log |
| F4 | "Own the member complaints process end to end across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I have never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names two measures, so expect a probe on what the spreadsheet showed. If it counted complaints arriving or how long they took to close, say which and how each was counted; if it showed something else, or one of them was not in it, say so plainly and stay with what it did show |
| F6 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Words: "I trained new tellers on our escalation script." The limit is the pack's observation: your material's audience is new tellers, the JD's is supervisors. Answer slot: the JD's line is about supervisors, so expect a probe on coaching people at or near your own level. If you have coached a supervisor or a peer on an escalation, say what the situation was and what you did; if not, say so plainly and stay with the tellers |
| F7 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent. Answer slot: the JD names digital teams, so expect a probe. If you have worked with a digital or product team on anything members use themselves, say what and which part was yours; if you have not, say so plainly and say what you would ask such a team first |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Then how you would prepare for it, said as a plan. Your material does not say what you have presented at regional level or to whom, so the pack says nothing about that |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | Your message says spreadsheet, not Excel; the pack does not close that for you. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names a specific tool, so expect a probe on what the spreadsheet was built in. Say what it was and what you did in it, in your own words; if it was something other than the JD's tool, say so plainly and stay with what you built |

No row is a gate: nothing in the JD is a licence, authorisation, location or pay term, and length-of-experience lines such as F1 are graded like any other requirement.

## Grounding brief: what Ashgrove's July 2026 strategy says

From the 2026 strategy brief the recruiter sent you, as you relayed it. Published July 2026, so about four months old on the day this pack was built. Say these in the brief's own terms; do not turn the readings into predictions in the room.

| # | What the brief says | Provenance | Reading for the complaints role | Provenance of the reading |
|---|---|---|---|---|
| S1 | "move 40% of member service to digital channels by 2028" | [grounded] | The JD's digital-teams line (F7) and self-service journeys sit on this target; complaints about digital journeys and about hand-offs between channels are the questions to be ready for | [inferred] |
| S2 | "consolidate eight branches into five hubs over 2027" | [grounded] | The panel are branch managers; a member complaint about the change itself is a plausible case, and it is not yours to defend or criticise | [inferred] |
| S3 | "launch a small-business lending product in Q1 2027" | [grounded] | A new product usually brings new kinds of member contact; a good question to ask, not a claim to make | [inferred] |
| S4 | "the main competitive pressure is app-only banks" | [grounded] | Members may compare how a complaint is handled with how an app-only bank would handle it, which fits the Plain Words and Members First values | [inferred] |

## Round 1: Recruiter screen (30 minutes)

### Persona weights

| Persona | Weight | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|---|
| Conversational / Rapport Builder (A) | High: 6 questions | Friendly, unstructured; logistics and the biography question | Likely: recruiter-screen prior is conversational plus logistics, and the recruiter's own note describes this round as a 30-minute conversation with them. Casual questions here are still scored | A 90-second arc built only from your quoted sentences; treat pay, notice, location and reasons as scored; never answer "I think you've covered everything" to the reverse-question slot |
| Skeptic, light (B) | Low: 3 questions | Quiet knock-out checks on the JD's headline lines | Possible: the recruiter will have your background against the JD and the three biggest distances are F4, F8 and the complaints experience (F2) | Say the gap plainly first, in the words you actually have, then the plan; a short answer is the strong one here |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey." | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | A 90-second arc in four beats, each a clause your quotes state, told in your own words: 6 years in retail banking; the last 3 as a branch supervisor; you handled the branch's formal complaints log and trained new tellers on the escalation script; you built the monthly complaints spreadsheet your regional manager uses. Stop there; your quotes carry no further beats, so add none. Answer slot: end on why this role; give your actual reason in a sentence, in your own words | F1 is where the years line is first scored, so this is JD in conversational delivery; the other rows it draws on (F2, F5, F6) are the lines a recruiter will pick up and probe |
| A2 | "What do you know about where Ashgrove is heading, and why does that interest you?" | CO | [grounded] | Choose one or two items from the Grounding brief and say them as the brief says: S1 and S2 are the two with the most to say about member service. Add one thing you would want to find out as a question, not a prediction. The recruiter sent you the brief, so reciting it scores as homework and no more; one item plus one open question scores as judgement. Answer slot: give your own reason this matters to you, in a sentence | The recruiter supplied the brief, so company knowledge is expected from the first conversation; CO because it scores homework and altitude, not experience |
| A3 | "What's prompting you to look at a move now?" | EXP | [generic] | Logistics slot: give your actual reason for looking, in one or two sentences, in your own words. The pack supplies none. Keep it to what is true; nothing more is needed | Every recruiter screen carries a reason-for-leaving question and the only safe answer is your own; EXP because it tests consistency of motivation |
| A4 | "What are your salary expectations?" | JD | [generic] | Logistics slot: give your own figure or range, or ask for the role's band first; both are yours to choose, and the pack supplies no number. If asked what you earn now: "I'd rather focus on the range for this role." | Pay is the listed job's term and a standard recruiter-screen item; JD because it concerns this role's terms |
| A5 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period, in the terms you were given, in your own words | A start-date check the recruiter needs before scheduling beyond the loop; JD because it is a term of the job |
| A6 | "The role covers branches and the contact centre. Where would you be based, and what travel would work for you?" | JD | [generic] | Logistics slot: give where you can work from and how often you can be at other sites, in your own words. The pack supplies no location or travel limit | The JD's across-branches line makes this a likely logistics question; JD because it concerns the job's working pattern |
| B1 | "Tell me about the formal complaints you've handled." | JD | [grounded] "I handled the branch's formal complaints log" | Open in the quote's words: "I handled the branch's formal complaints log." Answer slot: the JD asks for complaints experience of a particular kind, so expect a probe on what governed the log. If it was kept under outside rules or deadlines, say which and how they shaped what you did; if it was an internal procedure only, or you do not know what governed it, say so plainly and stay with the log. Keep it to about a minute; a recruiter wants the headline | F2 is the first requirement a recruiter checks against a CV; JD because it scores the stated requirement |
| B2 | "This role covers the contact centre as well as branches. How do you feel about that?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | Say the gap first, plainly: "I have never worked in a contact centre." Then the plan, said as a plan and never as a past: what you would ask to see and whom you would sit with before changing anything, in your own words. Then return to what you do have: "I handled the branch's formal complaints log." Add nothing about contact-centre work | F4 is a stated absence on a headline line, so a recruiter will raise it lightly here; it is rehearsed deeply in C1. JD because it scores the responsibility |
| B3 | "The role presents to senior leaders. What's the most senior audience you've presented to?" | JD | [grounded] "I've never presented to anyone above regional level" | Say it in your words: "I've never presented to anyone above regional level." Answer slot: if you have presented at regional level, say what and to whom, in your own words; if you have not presented at all, say so plainly. Then how you would prepare for a first leadership presentation, said as a plan | F8 is a stated absence on a requirement the manager will return to in C4; JD because it scores the stated requirement |

### Reverse questions: Round 1

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "What does the 20-minute case in the panel round give me beforehand, and is there anything I should bring?" | Format is un-researchable and the recruiter can usually say; it tells you whether to prepare a structure from scratch or around a given brief |
| R1.2 | "Who will the Member Experience Lead work most closely with across the branches and the contact centre?" | Shows you read the role as cross-channel; the answer maps the people behind C1 and I1 |
| R1.3 | "Which of the four values do people find hardest to show in the panel round?" | Tells the recruiter you have read the values and takes the panel seriously as a scored round |
| R1.4 | "What has changed in how the role is shaped since the July strategy brief?" | Signals you read a four-month-old document as live, and invites any update the brief does not carry |
| R1.5 | "What happens after 5 December, and by when should I expect to hear?" | Closes the logistics cleanly and shows you are planning around their process |

## Round 2: Head of Member Services, your future manager (45 minutes, mostly behavioural)

### Persona weights

| Persona | Weight | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic (C) | Highest: 4 questions | Quiet, persistent probing of the distance between the JD and your material | Very likely: the hiring-manager prior is Case plus Skeptic, because they are buying capability and derisking gaps; F3, F4, F6 and F8 are all distances they own the outcome of | Rehearse C1 until it is boring; hold what the quotes carry, concede specifically, never fold on the core |
| Values / Behavioral (D) | Mid: 2 questions | "Tell me about a time" prompts | Likely: the recruiter described this round as mostly behavioural, which lifts this persona above the hiring-manager prior | Story-map from a quoted sentence where one carries it; a selection scaffold ending in its honest branch where none does |
| Case / Strategist (E) | Mid: 3 questions | Live problems on the manager's real roadmap | Likely: the manager's roadmap includes the 40% digital target (S1) and the cross-channel ownership in the JD | Clarify before structuring; use Ashgrove's own words; challenge one premise respectfully |
| Data-Driven Prober (F) | Low: 2 questions | Line-by-line on the reporting claim | Possible: reporting is a headline responsibility and the spreadsheet is the one artifact you built | Say what you know about how each figure was counted and say plainly what you do not |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've handled your branch's complaints log and you haven't worked in a contact centre. This role owns the whole process across both. Where does that leave you?" | JD | [grounded] "I handled the branch's formal complaints log"; "Never worked in a contact centre" | The deepest rehearsal, three follow-ups. Hold: say both facts first, before they do, in your words: "I handled the branch's formal complaints log, and I've never worked in a contact centre." Follow-up 1, "that's one branch": do not widen the quote; concede specifically that your material is the branch's log. Answer slot: the JD's end-to-end line makes a probe on the stages around the log likely; if any stage beyond the log was yours to run or change, say which and what you did; if the log was the whole of your part, or the rest was not yours, say so plainly. Follow-up 2, "how would you learn the contact centre": the plan, said as a plan: whom you would sit with, what you would ask to see, what you would hold off changing until you had; in your own words, nothing in the past tense. Follow-up 3, "and if the branches and the contact centre do it differently": say you would find out how each does it before deciding anything; do not claim a view you have not formed. Never fold on the core: the branch log is real experience | F3 and F4 are the largest distance between the JD's headline responsibility and the material, so this objection arrives in some form; named the highest-ROI prep in the pack. JD because it scores the headline responsibility |
| C2 | "Walk me through what happens to a formal complaint in your branch, from the moment it's raised." | EXP | [grounded] "I handled the branch's formal complaints log" | Walk only the part your quote carries: you handled the log. Answer slot: the JD's end-to-end line makes a probe on stages likely. Say which stages you handled, in your own words and in the order they happened; where a stage was someone else's, say so and say whose; if you do not know where a complaint went after the log, say that plainly. If outside rules or deadlines governed the log, say which and how they shaped your handling; if it was an internal procedure only, say so | F2 and F3 together: the manager asks for the denominator behind the headline claim. EXP because it tests what was actually yours |
| C3 | "This role coaches branch supervisors on escalations. You've trained tellers. What's different about coaching a supervisor?" | JD | [grounded] "trained new tellers on our escalation script"; "6 years in retail banking, the last 3 as a branch supervisor" | Hold: "I trained new tellers on our escalation script." Concede specifically that the JD's audience is supervisors and your material's is new tellers. Answer slot: if you have coached a supervisor or a peer on an escalation, say what the situation was and what you did; if not, say so plainly and stay with the tellers. Then what you would ask a supervisor before coaching them, as an approach, in your own words | F6 is a change of audience, which a manager prices carefully since the role's coaching reaches people at your own level; JD because it scores the stated line |
| C4 | "What have you presented, and to whom?" | JD | [grounded] "I've never presented to anyone above regional level" | Hold-then-concede in two steps. Say it in your words: "I've never presented to anyone above regional level." Answer slot: if you have presented at regional level, say what and to whom, in your own words; if not, say so plainly. Then the plan, as a plan: how you would prepare for a first leadership presentation, and what you would ask this manager about what leaders want from a complaints report. Offering to run it past them first is a plan, not a past | F8 is the one stated absence the person you are talking to will personally rely on closing; JD because it scores the stated requirement |
| D1 | "Tell me about a time you coached someone through a difficult escalation." | EXP | [grounded] "trained new tellers on our escalation script" | Your quote carries the training of new tellers on the script; start there only if the story you pick sits inside it. Selection: a named person, what the difficulty in the escalation was, what you said or showed them, and what happened to them afterwards; if no such time comes to mind, say so plainly, then give the nearest thing your material carries, in the quote's words, or how you would coach it | The JD's coaching line is the theme (F6); EXP because it tests whether the story is yours |
| D2 | "Tell me about a time you had to tell someone senior something they didn't want to hear." | EXP | [generic] | Selection: the thing said, to whom, how you made it land, and how the relationship stood afterward; choose a story where the hard truth actually landed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it. The pack supplies no story | A manager who will receive monthly reporting wants to know whether unwelcome numbers reach them; the theme is the standard Values/Behavioral stem. EXP because it tests a past event |
| E1 | "Ashgrove wants 40% of member service on digital channels by 2028. What happens to complaints?" | CO | [inferred] derived from the brief's 40% digital line (S1) | Clarify first: what counts as "member service" in the 40%. Then say your hypotheses as hypotheses: complaints about the digital journeys themselves; members for whom digital is not the right channel; hand-offs between digital, branches and the contact centre. Metrics: volumes and resolution times by channel, which are the JD's own measures. Risk: counting a drop in branch complaints as improvement when members have only moved channel. No claim about your past | S1 is the largest planned change to the manager's world; CO because it scores strategic altitude |
| E2 | "How would you work with digital teams on self-service journeys?" | JD | [generic] | Approach, no claim about your past: bring what complaints show about where members get stuck as input; agree with the digital team what "done" means from the member's side; ask for complaints to be tagged by journey; check any new wording against Plain Words. Answer slot: if you have worked with a digital or product team on anything members use themselves, say what and which part was yours; if you have not, say so plainly and say what you would ask such a team first | F7 is silence in your material, so the honest rehearsal is the slot plus an approach; JD because it scores the stated line |
| E3 | "Your first 90 days: what do you need to find out before you change anything?" | CASE | [generic] | Structure it: where complaints arrive and who holds each channel; what the current reports show and how they are counted; what rules and timelines apply to each kind of complaint; what supervisors find hardest in an escalation; what members say. Only then, first proposals, ranked. Challenge one premise respectfully: "change" is a conclusion you would earn. This is also the honest answer to C1's learning plan | A new-lead case from the manager's seat; CASE because it scores clarify-before-structure |
| F1 | "Walk me through the monthly complaints spreadsheet: what did it show, and what was it built in?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Open in the quote's words. Answer slot: the JD names two measures and a specific tool, so expect a probe on both. If it counted complaints arriving or how long they took to close, say which and how each was counted; if it showed something else, or one of them was not in it, say so plainly. Say what you built it in and what you did in it; if it was something other than the JD's tool, say so plainly | F5 and F9 are where the JD names measures and a tool; JD because it scores the Excel-reporting line |
| F2 | "Which figure on that spreadsheet would you trust least, and why?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | The weakest-assumption move: before they ask, name the figure whose counting you would defend least, in your own words. Answer slot: if you know how it was counted and what it is sensitive to, say so; if you do not know how a figure was counted, say so plainly; if there were no figures, say that. Say which part of the spreadsheet was yours and which was not | F5 is a metric-bearing claim, so a defend-the-figure probe is its natural pairing; EXP because it tests attribution and honesty about counting |

### Reverse questions: Round 2

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "What would a good first 90 days look like for the person owning complaints across branches and the contact centre?" | Turns C1's gap into a shared plan and shows you think in ramp terms |
| R2.2 | "Which parts of the complaints process don't have a single owner today?" | Ties to Own the Fix and shows you look for seams before changing them |
| R2.3 | "How do complaint figures reach senior leaders today, and where would you want them to be sharper?" | Shows you think about the report's audience and gives you the manager's view of F5 and F8 |
| R2.4 | "As service moves toward digital by 2028, which complaint types do you expect to grow?" | Uses S1 as a live question; invites the manager's own view without asserting yours |
| R2.5 | "Where do you expect the new person to need the most support?" | Invites candour about the very gaps you have named, and signals you intend to close them |

## Round 3: Panel of two branch managers, including the 20-minute escalation case (60 minutes, the values round)

### Persona weights

| Persona | Weight | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|---|
| Values / Behavioral (G) | Highest: 4 questions | One scenario probe per published value | Near certain: the recruiter said the panel scores against the four values | Map a story to each value where a quote carries one, a selection scaffold ending in its honest branch where none does; "we" for context, "I" for contribution |
| Case / Strategist (H) | Mid: 3 questions | The 20-minute complaint-escalation case | Certain to occur, format unknown: the recruiter said a 20-minute case on a complaint escalation is part of the round | Clarify, objective, approach, metrics, risks; use Ashgrove's words; think aloud |
| Peer Evaluator (I) | Low: 2 questions | Seam-splitting between the role and the branches | Likely: branch managers work beside the role and the JD has it coaching branch supervisors | Reciprocity: what the role gives their branch, not just what you need; offer seam principles, not a seam you cannot know |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] | No quoted sentence of yours carries this story, so use selection: a named decision, what the easier option was and who it favoured, what the member got, and what it cost you. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would decide it. The pack supplies no story | Members First is the first published value, and the panel scores it directly; VAL because it tests past behaviour against the published words |
| G2 | "Tell me about a time something you explained didn't land, and what you changed." | VAL | [grounded] "trained new tellers on our escalation script" | Your quote carries a teaching setting: new tellers and the escalation script. Answer slot: the value is about explaining twice, so expect a probe on whether anyone needed the script explained twice. If any teller did, say what you changed in how you explained it, in your own words; if none did, or the wording was not yours to change, say so plainly and describe how you taught it | Plain Words is a published value; F6 is the only quote that touches explaining. VAL because it scores the value |
| G3 | "Tell me about a time your branch's town or community shaped a decision you made." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Your quote carries a branch role, not a town; the story is yours to supply. Selection: a named decision, what about the town or its people shaped it, and what the outcome was. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would weigh a town's needs in a decision. Never use a hub-consolidation view as this answer | Neighbours, Not Numbers is a published value and the panel are branch managers, so it will be scored with local knowledge in the room. VAL |
| G4 | "Tell me about a time you kept hold of a problem until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Your quote carries the log, not a case seen through to its end. Selection: a named problem, what keeping hold of it meant for you, what other people had to do, and how it ended. A story where you passed it on is still usable if you say so plainly. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would keep hold of one | Own the Fix is the published value closest to the role's whole job; F2 and F3 are the closest quotes. VAL |
| H1 | "A member has complained three times about the same fee, been told twice it's fixed, and now says they're closing their account. Walk us through what you do." | CASE | [generic] | A rehearsal case, since the real one is unknown. Clarify: what the member was told and in what form, who holds the file, what is recorded, which timeline applies, what the member wants. Objective: the member's problem fixed and the record right. Approach: one owner who keeps hold until it is solved; contact the member first in plain words; check what each channel recorded; decide what needs escalating and to whom; confirm the outcome in writing in plain words. Metrics: problem fixed, repeat contacts, time to resolve. Risks: more hand-offs; saying "fixed" before it is. Challenge one premise: ask what "fixed" meant when they were told it. No claim about your past | The recruiter has announced a 20-minute complaint-escalation case; CASE because it scores structure and reasoning using the panel's own values |
| H2 | "A member complained by phone to the contact centre, then walks into a branch two days later and the supervisor has no record. What do you do, then and as the owner of the process?" | CASE | [generic] | Two layers. Now: take the member's side of the counter, do not ask them to repeat everything, find the record, and name who now owns it. As the owner of the process: where a complaint's record lives, how it travels between channels, who holds it at each step, how reporting shows the gap. Say what you would need to learn about how the contact centre works before proposing a fix | F3 and F4 are the two JD ownership lines; this case stresses the seam between branch and contact centre, where the C1 objection returns in case form. CASE |
| H3 | "A branch is due to fold into a hub, and a longstanding member complains that the change forgets their town. What do you do with that complaint?" | CASE | [inferred] derived from the brief's branch-consolidation line (S2) | Separate the member's feelings from what the complaint can change. Listen first; own it; say plainly what can be fixed (their service, their access) and what cannot (a decision that is not yours); feed the pattern into reporting so leaders see it. Do not defend or criticise the consolidation. Plain Words: no jargon about hubs | S2 is the most visible change for branch managers, and Neighbours, Not Numbers makes this a likely values-flavoured case. CASE |
| I1 | "You'd coach our supervisors on escalations. Where's the line between your coaching and how we manage our branches, and what happens when we disagree?" | JD | [generic] | Seam principles, not a seam you cannot know: you coach escalation practice and they manage the branch; if coaching conflicts with a manager's call, you raise it with them first and with the Head of Member Services only if it persists. Ask what they would want to be told when coaching exposes a problem. Reciprocity: what the role gives their branch is a view across branches and the contact centre on where escalations stall | F6 is the JD line the panel will test from the seat of the people whose supervisors it touches; JD because it scores the coaching line. The same objection as C3 in collegial packaging |
| I2 | "What would you need from a branch manager to do this well, and what would we get from you?" | JD | [generic] | Ask and give. What you need: how their supervisors handle escalations today, access to the log, a say in what is reported. What the role gives them: reporting by branch, coaching for supervisors, one person owning the cross-branch process. Role-based, no claim about your past | A reciprocity probe from branch managers pricing whether the hire adds to or reduces their load. JD |

### Values / principles cheat sheet (Ashgrove's four published values)

Names as published; the working meaning is paraphrased from the values text you pasted.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decisions are made from the member's side of the counter | No quoted sentence carries this. Selection scaffold (G1): a named decision where the easier option favoured the branch or you, what the member got, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would decide it |
| Plain Words | If a member needs it explained twice, the writing is wrong | F6: "trained new tellers on our escalation script". Answer slot (G2): if any teller needed it explained twice, say what you changed; if none did, or the wording was not yours, say so plainly and describe how you taught it |
| Neighbours, Not Numbers | Every branch is part of its town | F1: "6 years in retail banking, the last 3 as a branch supervisor" carries a branch role, not a town. Selection scaffold (G3): a named decision shaped by the town or its people. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would weigh it |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F2: "I handled the branch's formal complaints log". Selection scaffold (G4): a problem you kept hold of to its end; if the log passed it on first, say so plainly and describe what you did with the log |

## Requirement coverage line

| JD requirement | Fit row | Questions |
|---|---|---|
| "4+ years in financial-services customer operations" | F1 | A1 |
| "experience handling regulated complaints" | F2 | B1, C2 |
| "confident presenting to senior leaders" | F8 | B3, C4 |
| "comfortable with Excel reporting" | F9 | F1, F2 |
| "Own the member complaints process end to end across branches" (and the contact centre) | F3, F4 | B2, C1, C2, H2 |
| "report monthly on complaint volumes and resolution times" | F5 | F1, F2, E1 |
| "coach branch supervisors on escalations" | F6 | C3, D1, I1, I2 |
| "work with digital teams on self-service journeys" | F7 | E1, E2 |
| Values round (four published values) | none | G1, G2, G3, G4 |
| 20-minute complaint-escalation case | none | H1, H2, H3, E3 |

## Prohibited claims: what this pack will not coach

Built locally from the fit snapshot, before the banks were written. No dossier was provided.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F3 | F3's quote at its own scope: "I handled the branch's formal complaints log". The limit is the pack's observation: the material says the branch's log, not the process across branches. C2's slot stays inside the log |
| Handled regulated complaints | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: the material says a formal complaints log, and does not show what governed it. The slot asks only what governed the log |
| Reported monthly on complaint volumes and resolution times | Inflated form of F5 | F5's quote at its own scope: a monthly complaints spreadsheet your regional manager uses. The slot asks only what it showed |
| Coached branch supervisors on escalations | Inflated form of F6 | F6's quote at its own scope: "trained new tellers on our escalation script". The slot asks only whether you have coached a supervisor or a peer |
| Has Excel reporting skills | Inflated form of F9 | The quote at its own scope: a spreadsheet you built. The slot asks only what it was built in |
| Has worked in a contact centre | Negative you stated, F4 | The plain acknowledgment: "I have never worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment: "I've never presented to anyone above regional level." No slot beyond what you have presented at regional level |

## Sources

**Provided documents:** the JD you pasted; Ashgrove's four values as you copied them on 26 November 2026 from ashgrovecu.org/about/values; the recruiter's email about the three rounds; the 2026 strategy brief the recruiter sent you, as you relayed it (published July 2026); your background in your own message. No dossier was provided.

**Searches and fetches sent:** none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values text is in hand and fixes the cheat sheet and the G bank; the URL is where the text was copied from, not a link to read |
| 2. `Ashgrove Credit Union interview process member services` | skipped | The recruiter's email fixes the three sessions, their lengths, who runs each and which is the values round, so the loop and persona weights rest on it |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | The July 2026 brief you relayed supplies current priorities and recent moves for the CO and CASE questions; nothing newer than the brief was checked |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No interviewer names were given, only roles, so there was no query to form |
| 5. representative `Member Experience Lead` JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- **Interviewer names, once assigned** → a tailored interviewer read, persona weights adjusted from public professional footprint, and a reverse question tied to each person's own path
- **The recruiter's answer on the panel case** (written brief or spoken, any preparation material) → H1 to H3 rebuilt around the real format; usually one email
- **Your own words on the answer slots** (F2, F3, F5, F6, F7, F9) → those rows move from discovery to presentation or none, and the bank guidance becomes story-mapped instead of a slot
- **The complaints-log layout and the spreadsheet's column headings, with anything confidential removed** → F2, F5 and F9 move from medium to high, since they are the inspectable artifacts for complaints handling and reporting
- **Your CV** → any evidence it carries that your message does not, and new rows where it speaks to F7 or F8
- **Prep time available before 5 December** → a prioritised prep schedule tied to question IDs, so the few things done well come first
- **A deeper research pass, offered once** → up to 6 more searches and 2 more fetches, several more minutes: Ashgrove's recent news and leadership context, how its complaints and member-service teams are described publicly, and a competitor read on app-only banks for the CO and CASE questions
- **A tuesday-dossier.md from a job-underwriter run** → verified evidence and constraints on weak areas such as F3, F4 and F8, so the objection rehearsals rest on confirmed material instead of the pack's inference
