I'm still reading the skill's reference files: personas, research rules and evidence conventions. After that I'll research Ashgrove and write the pack.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a6/runs/sonnet/alone/part-2/rooms/case-8-canned-ee3ae268/ashgrove-credit-union_member-experience-lead_interview_pack.md`.

I built it as a three-round loop from the recruiter's email. It has one shared fit snapshot, then a question bank, persona weights and reverse questions for each round. Round 3's bank is scored against the four values and includes the escalation case. I ran no web research. Your JD, the values text, the recruiter's email and your summary of the strategy brief covered everything it needed.

- **Biggest risk:** "You've never worked in a contact centre, and the role owns complaints there too" (B2). Your own message states the gap and the JD names the contact centre. The pack scripts a four-level hold-then-concede answer that stays inside what your sentences say.
- **Second risk:** presenting to senior leaders (B3). Your sentence "I've never presented to anyone above regional level" is the whole claim, so the pack coaches you to say it at exactly that scope and add a plan.
- **Answer slots:** where your sentences don't show something, the pack leaves a slot for your own words instead of filling it in. The main ones are whether any complaints were regulated, what your spreadsheet counted, whether you coached other supervisors, and any work with digital teams.
- **Date check:** 5 December 2026 is a Saturday. The recruiter's first reverse question asks them to confirm the date and format.

Say the word and I'll play the Head of Member Services on B2, the question the pack names as its highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Prepared 26 November 2026. Loop mode: three rounds on 5 December, with a shared fit snapshot and a mini-pack per round.

| Round | Who | Length | Persona weights, heaviest first |
|---|---|---|---|
| 1 | Recruiter | 30 minutes | Conversational, light Skeptic |
| 2 | Head of Member Services, who would be your manager | 45 minutes, mostly behavioural | Skeptic, Values/Behavioral, Case/Strategist |
| 3 | Panel of two branch managers, with a 20-minute complaint-escalation case; also the values round, scored against the four values | 60 minutes | Values/Behavioral, Case/Strategist, Peer Evaluator, Conversational |

Highest-ROI prep in this pack: B2, "You've never worked in a contact centre, and this role owns complaints there too." Your own message states the gap, the JD names the contact centre in its first line, and your future manager asks in round 2. Rehearse it until it is boring. B3, presenting to senior leaders, is second.

## How to use this pack

Personas describe how a question is asked. Types describe what it is scoring. The guidance is scaffolding for a spoken answer, not a script, and all proposed answer language in this pack is pending your approval: say only what you actually did, in your own words.

| Type | Meaning |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether your background survives scrutiny; what was actually you |
| JD | Whether you can do the listed job, including its gaps |
| CO | Whether you know the company's strategy and can think at its altitude |
| CASE | A live problem from the role, scored on structure and reasoning |

An answer slot is an instruction for the interview, not a question for you now. It names what an interviewer is likely to probe and gives two honest branches. Either branch is a good answer. A pay, notice, location or reason-for-leaving slot is a logistics slot: you give your own fact.

Round 3 runs 60 minutes with a 20-minute case, and the recruiter says the panel scores against the four values. Round 2 is mostly behavioural. The banks are sized per round (8 to 12 questions each) rather than as one session total.

## Fit snapshot (shared across all three rounds)

Evidence is quoted only from your message. Bridge language is proposed wording, pending your approval.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | presentation | Your sentence already gives the span, so the words stay in it: "I have 6 years in retail banking, the last 3 as a branch supervisor." Nothing is added to it. Nothing has been inspected behind this line, so expect it to be taken at your word and probed on the later years |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | Your sentence says a formal complaints log. It does not show whether those complaints fell under a regulator's rules or deadlines, and the pack does not assume it. Words: "I handled the branch's formal complaints log." Answer slot: the JD's word is regulated, so expect a probe on it. If any complaints you handled were subject to regulatory rules or deadlines, say which and what you did, in your own words; if none were, or you are not sure, say so plainly and stay with the log you handled |
| F3 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material is one branch's log, not the process across branches, and the words stay there: "I handled the branch's formal complaints log." Answer slot: if any part of how complaints moved beyond your own branch was yours to touch, say what and how, in your own words; if none was, say so plainly and describe the log you handled |
| F4 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. No claim to contact-centre experience, and no claim that branch work is equivalent to it |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your sentence says a monthly spreadsheet that your regional manager uses. It does not say what it counted. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names volumes and resolution times, so expect a probe on content. If it counted either, say which and how you counted it, and name the assumption you would defend least; if it tracked something else, say what; if you do not know how a figure was counted, say so plainly |
| F6 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your sentence is training new tellers on a script, and supervisors are a different audience, so the words stay at the tellers: "I trained new tellers on our escalation script." Answer slot: if you ever coached another supervisor through an escalation, say what you did, in your own words; if you did not, say so plainly and stay with the tellers |
| F7 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing about digital teams. Answer slot: if you worked with any digital team, say on what and which part was yours; if you did not, say so plainly, then say what you would ask a digital team first, as a plan |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A limit you stated. Words: "I've never presented to anyone above regional level." Your sentence does not say what you have presented at regional level or to whom, and the pack does not assume it. Then how you would prepare, said as a plan and never as a past |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | presentation | The sentence says a spreadsheet and does not name the tool, so expect a probe on it and answer plainly from what you used. Words: "I built the monthly complaints spreadsheet our regional manager uses." Nothing is added to it |

No row is a gate: the JD sets no licence, location or schedule term, and the length-of-experience line in F1 is graded like any other requirement.

## Grounding brief (strategy, in your summary of the recruiter's brief)

Learn this vocabulary so you sound current. It comes from your summary of the July 2026 brief, which is about four months old. The brief itself was not read by this pack.

| Item | What it says | Where it bites in the loop | Provenance |
|---|---|---|---|
| Digital shift | Move 40% of member service to digital channels by 2028 | Digital self-service for complaints, JD line on self-service journeys: B5, B10, C8 | [grounded] your summary of the brief |
| Branch network | Consolidate eight branches into five hubs over 2027 | Round 3 is two branch managers; handle with care and ask what is decided: C8, R3 reverse questions | [grounded] your summary of the brief |
| New product | Launch a small-business lending product in Q1 2027 | A new member segment and new kinds of complaint are possible, which is an angle to raise only if the conversation goes there | [grounded] your summary of the brief |
| Competition | Main pressure is app-only banks | Speed and plain wording in complaint handling are where a member-owned credit union can show a difference; this link is the pack's reading, not the brief's | [inferred] derived from the competition line above |

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| 4+ years in financial-services customer operations | A1, C11 |
| experience handling regulated complaints | A9, B6 |
| Own the member complaints process end to end across branches and the contact centre | A7, B1, B2, B6, C6, C9 |
| report monthly on complaint volumes and resolution times | A8, B4, B11 |
| coach branch supervisors on escalations | B7, C7 |
| work with digital teams on self-service journeys | B5, B10, C8 |
| confident presenting to senior leaders | B3 — and no second question, because round 3 is branch managers, not senior leaders |
| comfortable with Excel reporting | A8, B4 |
| Values: Members First, Always | C1, C5, B9 |
| Values: Plain Words | C2 |
| Values: Neighbours, Not Numbers | C3 |
| Values: Own the Fix | C4 |

---

# Round 1 mini-pack: recruiter (30 minutes)

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly biography and motivation questions | Highest. A recruiter screen is a conversation first, per the round prior | Pre-script a 90-second arc and treat the casual questions as scored (A1, A2, A3) |
| Skeptic, light | Knockout checks in a friendly register: the contact centre, regulated complaints, pay, notice | Second. The recruiter's email says nothing on focus areas, so this rests on the round prior and the JD's contact-centre line | Say the limit plainly once and move on (A7, A9) |

## Question bank

Proposed answer language, pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through your journey so far." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc with only the beats your sentences state: six years in retail banking, the last three as a branch supervisor; the formal complaints log and the escalation script for new tellers; the monthly spreadsheet your regional manager uses. Tell each in your own words and stop at the present. Answer slot: the closing beat, why this role, is yours, in your own words; the pack supplies no motive | F1, F2, F5 and F6 carry every beat. EXP because the screen checks the story hangs together |
| A2 | "What do you know about us, and why a member-owned credit union?" | CO | [grounded] | Two or three facts from the strategy brief, said as things you read: 40% of member service digital by 2028, eight branches into five hubs over 2027, a small-business lending product in Q1 2027, and pressure from app-only banks. Why member-owned: give your own reason, in your own words; if you do not have one yet, say what draws you to this job from the JD | The JD opens with "member-owned" and the brief supplies the facts; CO because it tests homework. A recruiter notes who read the brief they sent |
| A3 | "What's making you look at a move now?" | EXP | [generic] | Logistics slot: give your actual reason, in your own words. A reason about what you want from this role is easier to rehearse than one about where you are now | The reason for leaving is a standard recruiter-screen item; EXP because it is about your own history, though no fact of it is in the material |
| A4 | "What are you looking for salary-wise?" | JD | [generic] | Logistics slot: give your own figure or range, or ask for the role's band first. If asked what you earn now: "I'd rather focus on the range for this role." | Pay is a standard screen item; JD because it concerns the listed job's terms |
| A5 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period, and any start-date constraint of your own | The job's terms, asked by every recruiter |
| A6 | "Where would you be based, and does the location work for you?" | JD | [generic] | Logistics slot: give your actual location and any limit on where or how often you can work, in your own words. Say it now rather than later | The brief's hub plan makes location a live topic, which is why it gets its own row; JD because it concerns the listed job's terms |
| A7 | "You've come from branches, and the role covers the contact centre too. How do you see that gap?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "Never worked in a contact centre, and I've never presented to anyone above regional level." | Say the limit first, in your own words: "I haven't worked in a contact centre." Then what your sentences carry: six years in retail banking, the last three as a branch supervisor. Then a plan in your own words: what you would learn first and from whom, said as what you will do. Stop there, and claim no equivalence | F4 is the sharpest knockout a recruiter can check, so it is rehearsed early; the full treatment is B2 |
| A8 | "Tell me about the monthly complaints spreadsheet you built." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say it as the sentence says: you built it and your regional manager uses it. Answer slot: if it counted complaint volumes or resolution times, say which and how; if it tracked something else, say what; if you do not know how a figure was counted, say so plainly. Say which tool you used, in your own words | F5 and F9 meet here. JD because reporting and Excel are listed requirements |
| A9 | "Tell me about the complaints you handled — and how much of that was regulated work." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Start from the sentence: "I handled the branch's formal complaints log." Answer slot: if any of those complaints were subject to regulatory rules or deadlines, say which and what you did; if none were, or you do not know, say so plainly and stay with the log you handled | F2 is the requirement the JD lists in the middle and the screen is likely to check; the premise is the JD's, so the slot allows that it is false |

## Reverse questions for the recruiter

| # | Question | Why it lands |
|---|---|---|
| 1 | "Can you confirm the date, order and format of the three rounds? 5 December is a Saturday, and I want to plan for the right day." | The date falls on a weekend; confirming it is practical and avoids a missed slot |
| 2 | "Who is on the panel of two branch managers, and which branches do they run?" | Names are unassigned, and knowing them tunes round 3; ask without pushing if the answer is not ready |
| 3 | "Is the contact centre part of the role from day one, or phased in?" | It shows you take your stated gap seriously and tells you how heavily it weighs |
| 4 | "Is the 20-minute case on the escalation shared in advance or cold?" | It shapes your prep for round 3, the longest round |
| 5 | "Is the role based in a branch, a hub or elsewhere, and does that change over 2027?" | It ties the brief's hub plan to your own logistics |

---

# Round 2 mini-pack: Head of Member Services, your future manager (45 minutes)

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the gaps: the contact centre, senior presenting, reporting content | Highest. A manager is de-risking a hire, and F4, F5 and F8 are where the material is thinnest | Name the limit first, hold the facts, concede exactly (B1 to B5) |
| Values/Behavioral | Mostly behavioural, per the recruiter's email: stories about escalation, unpopular truths, members over targets | High. The recruiter says the round is mostly behavioural, which lifts this above the manager prior | Use a story where one of your sentences carries it; otherwise use the selection scaffold and its honest branch (B6 to B9) |
| Case/Strategist | One or two live problems from the role | Lower. The case is formally in round 3, and the manager prior is outweighed by the recruiter's description | Clarify, then structure, then answer (B10, B11) |

## Question bank

Proposed answer language, pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pick the one your sentence names and say it first, plainly: "I haven't worked in a contact centre." Then a plan, as what you will do: the first things you would want to see and who you would sit with before changing anything. Do not volunteer a second weakness unprompted; if asked for another, your sentence names it: "I've never presented to anyone above regional level." One named limit beats a hedged list | F4 and F8 are the two gaps you stated. JD because it scores the listed requirements, with Skeptic delivery |
| B2 | "You've never worked in a contact centre, and this role owns complaints there too. How can you own something in a place you've never worked?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The deepest rehearsal in the pack. Level one, hold: "I haven't worked in a contact centre. I handled the branch's formal complaints log." Level two, when they say a branch log is a different thing, concede exactly: "Yes — that was one branch's log, not the contact centre's." Do not claim equivalence. Level three, when they ask what you would do in the first 30 days: a plan in your own words, naming the first two things you would want to see and who you would learn from. Level four, when they ask why you rather than someone who has: hold only what your two sentences carry, the log and the tellers' training, and say what you would learn rather than what you already know. Name the limit before they do: your material has a branch log and a training script and no contact-centre work. Answer slot: if any of your complaints work involved handing cases to or from a phone or contact-centre team, say how, in your own words; if it did not, or you do not know, say so plainly | F4 is the single most predictable objection: the JD's first line covers the contact centre and your own message states the gap. JD with Skeptic delivery. Hold-then-concede, because a concession made early is a credibility gain |
| B3 | "Part of this role is presenting to senior leaders. What's the most senior audience you've presented to?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Give your sentence at exactly its scope: "I've never presented to anyone above regional level." Answer slot: your sentence leaves open what you have presented at regional level; if you have presented there, say to whom and about what, in your own words; if you have not presented at all, say so plainly. Then a plan, as what you will do: how you would prepare for a senior audience, and what you would ask this interviewer about what leaders expect | F8 is the second most predictable objection. JD because senior presenting is a listed requirement |
| B4 | "Tell me about the monthly complaints spreadsheet you built, and what it reported on." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say it at the sentence's scope: you built it, and your regional manager uses it. Answer slot: the JD names volumes and resolution times, so expect a probe. If it counted either, say which, how it was counted and the assumption you would defend least; if it tracked something else, say what; if others contributed, say who and what; if you do not know how a figure was counted, say so plainly. Name the tool you used | F5 and F9. JD with a Prober edge, because a manager who reads the JD will test the report against its own words |
| B5 | "The brief sets a target of 40% of member service on digital channels by 2028. What's your experience working with digital teams on self-service journeys?" | JD | [grounded] | Answer slot: if you have worked with a digital team, say on what and which part was yours, in your own words; if you have not, say so plainly, then say what you would ask a digital team first, as a plan | F7 is silence in your material, so there is no story to map; the JD and the brief both raise it |
| B6 | "What did handling the branch's formal complaints log involve, day to day?" | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Start from the sentence: "I handled the branch's formal complaints log." Answer slot: say in your own words what handling it meant, which parts were yours and which were someone else's; if a part a manager would expect was not yours, say so plainly and stay with what was | F2 and F3. EXP because a manager checking the CV asks what was actually you |
| B7 | "Tell me about a time you coached someone through an escalation." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | One beat the sentence states: you trained new tellers on the escalation script. Answer slot: if you ever coached another supervisor through an escalation, say what you did and how it went, in your own words; if you did not, say so plainly and stay with the tellers | F6 is training, not coaching supervisors, and the JD's coaching line makes this probe likely |
| B8 | "Tell me about a time you told someone senior something they didn't want to hear." | VAL | [generic] | Selection scaffold: pick a time with a named stake, what you said in your own words, and what the person did next; choose one where it landed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or say how you would handle it | A standard behavioural stem. VAL because a manager hiring someone who will report upward wants the courage to say it |
| B9 | "Tell me about a time you put a member ahead of a target or a process." | VAL | [grounded] | Selection scaffold: pick a time when the member's interest and an internal measure pulled apart, name what you decided and what it cost; keep what you did separate from what others did. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or say how you would handle it | The first published value is Members First, Always, and the stem is the persona's own. It prepares you for round 3 |
| B10 | "A member makes a formal complaint through the app. What has to be true for that to be handled well?" | CASE | [grounded] | Clarify before structuring: what kind of complaint, what the member wants, who owns it once it arrives, and whether any deadline applies. Then objective, approach, how you would know it worked, and the risks, including a member who cannot or will not use the app. Think aloud and challenge one premise politely | The brief's 40% digital target and the JD's self-service line meet here; CASE because it scores structure. The framing is the pack's; the real question will differ |
| B11 | "Resolution times have risen for three months in one channel while the others are flat, and you present to leaders next week. What do you do first?" | CASE | [generic] | Clarify first: which channel, what changed, how resolution time is counted. Then segment by complaint type, find the cause before the fix, decide what leaders need to see, and say what you would not claim yet. Your own reporting experience is the spreadsheet sentence only | JD's monthly reporting line, asked as a decision; the scenario is invented to show the shape, with no claim about this employer |

## Reverse questions for the Head of Member Services

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would a good first 90 days look like, and what would you want me to have learned about the contact centre by then?" | Names your gap and shows you plan to close it |
| 2 | "Where does ownership of a complaint change hands today between a branch and the contact centre?" | The same question as Own the Fix, from the manager's side |
| 3 | "Who gets the monthly report now, and what decisions has it changed?" | Shows you care what reporting is for, beyond producing it |
| 4 | "Where does self-service for complaints sit at the moment, and which digital team would I be working with?" | Covers the JD's digital line and the 2028 target |
| 5 | "How would you like to hear about problems early, and in what form?" | Tunes to your manager and signals the Own the Fix habit |

---

# Round 3 mini-pack: panel of two branch managers (60 minutes, with a 20-minute escalation case; the values round)

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scored against the four published values; stories wanted | Highest. The recruiter says the panel is the values round and scores against the four values | Map a story to each value where a sentence carries one, and use the scaffold and its honest branch otherwise (C1 to C5) |
| Case/Strategist | The 20-minute escalation case, then follow-ups | High. The recruiter names the case, and it is a third of the round | Clarify, then structure; apply the four values as lenses (C6 to C8) |
| Peer Evaluator | Two branch managers whose supervisors you would coach; where is the seam | Medium. Branch managers are the people your coaching and escalations land on, which the JD's coaching line implies | Offer seam principles and reciprocity; do not pretend to know their seam (C9, C10) |
| Conversational | Opening and closing talk | Lower. A scored panel keeps chat short, but the opening still counts | Reuse the A1 arc, shortened (C11, C12) |

The brief says eight branches become five hubs over 2027, and the panel is two branch managers. Whether that is on their minds is the pack's reading, not something the material says. Do not guess which branches are affected; ask, and be careful in C8.

## Question bank

Proposed answer language, pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you made a decision from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick a time when the member's interest and what was convenient for the branch pulled apart; name what you decided, what it cost, and what you did yourself. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: "I handled the branch's formal complaints log." | Members First, Always. F2 is the nearest sentence, and it carries no decision, so the guidance does not invent one |
| C2 | "Tell me about a time a member or a new colleague needed something explained twice." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | One beat the sentence states: you trained new tellers on the escalation script. Answer slot: the value says that if it needs explaining twice, it was written wrong, so expect a probe on whether any wording changed because someone needed it explained again. If it did, say what changed and whether it was yours to change; if not, or the script was not yours to change, say so plainly and stay with the training | Plain Words. F6 is the only sentence near it; VAL because it scores the value by name |
| C3 | "Tell me about a time you kept a branch's local community in mind when you handled a problem." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Selection scaffold: pick a case with a specific local context, a named member, street or business, and say what you did differently because of it. If no such time comes to mind, say so plainly; the nearest thing your material carries is the three years as a branch supervisor, and you can say how you would keep a town in view when you report numbers | Neighbours, Not Numbers. F1 gives the branch role but no story, so this is a scaffold, not a mapped story |
| C4 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold, with the log as your nearest sentence: "I handled the branch's formal complaints log." Answer slot: if you followed any single complaint or fault through to its end, say what the problem was, what you did and where it ended, in your own words; if none comes to mind, say so plainly and say how you would keep hold of one | Own the Fix. F2 shows the log and not a single case, so the case is yours to supply or to decline |
| C5 | "Tell me about a time you disagreed with a colleague about how a member should be treated." | VAL | [grounded] | Selection scaffold: pick a disagreement with a named stake, say what you argued and what happened, and keep the relationship intact. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or say how you would handle it | Members First, Always in a second form; a panel often asks a value twice from different angles |
| C6 | "A member has complained three times about the same fee error. The branch says it is fixed, the contact centre shows it open, and the member has said they will leave. Walk us through what you do." | CASE | [inferred] | Clarify first: what is the actual status, who holds it, what the member wants, any deadline or vulnerability. Then name one owner and keep it (Own the Fix); decide from the member's side (Members First); write to the member in words that need explaining once (Plain Words); consider the branch's relationship with its town (Neighbours, Not Numbers). Close with root cause and what you would record and report. Think aloud and challenge one premise politely | Derived from the JD's escalation and coaching lines and the four values; the real case will differ. CASE because it scores structure, with values as the scoring lens |
| C7 | "The supervisor on that branch says the member is wrong and the escalation was not needed. What do you say to them?" | CASE | [inferred] | Listen first for what the supervisor knew. Agree the facts, show what the member would have seen, and agree the next step, leaving the branch's ownership of the member intact. Hold your position on the member's outcome and concede what you do not yet know | The JD's coaching line applied to a live disagreement. The guidance makes no claim about past coaching |
| C8 | "The plan is 40% of member service on digital channels by 2028, and eight branches become five hubs over 2027. What does that change about handling complaints?" | CO | [grounded] | Three beats: complaints begin in more places, so one owner has to follow each one; wording in an app has to need explaining once; a member who does not use the app and a branch that is changing both still need someone to keep hold. Ask what has been decided rather than guessing which branches are affected. Link app-only competition to speed and plain wording as your reading, not a fact | The brief's two headline moves; CO because it tests altitude, and the hub plan is sensitive for this panel |
| C9 | "A complaint starts in my branch. Where is the seam between my supervisor and you, and what happens when we disagree?" | JD | [grounded] | Offer principles, not a map: the branch keeps the member relationship; you hold the process, reporting and coaching; whoever finds the problem keeps hold of it until it is solved. On disagreement: member outcome first, process second. Ask what they would want to be told and when | A Peer Evaluator stem on the JD's branches-and-contact-centre line; the seam is theirs to define |
| C10 | "How do you handle credit when work spans teams?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Use I for what was yours: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if others contributed to it, say who and what; if you built it alone, say so plainly | A Peer Evaluator stem; F5's sentence is the only one with an authorship claim |
| C11 | "So tell us about yourself, and what brought you to Ashgrove." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Reuse the A1 arc at about 60 seconds. Answer slot: why Ashgrove is yours to give in your own words; pick one or two values that truthfully fit, rather than all four | The opening of the panel still counts; EXP because it checks coherence |
| C12 | "If you started tomorrow, what would you want to understand first, and what would you leave alone?" | JD | [generic] | A plan, in your own words: what you would read and who you would ask across the branches and the contact centre before you change anything. Say what you would hold off on and why | The JD's end-to-end ownership line, asked as a plan; no claim about your past |

## Values cheat sheet

| Value (official name) | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side | Scaffold, C1 and C5 and B9: a time when the member's interest and convenience pulled apart. Nearest sentence, F2: "I handled the branch's formal complaints log and trained new tellers on our escalation script." If nothing comes to mind, say so plainly and say how you would decide |
| Plain Words | Write so a member does not need it explained twice | F6: "I handled the branch's formal complaints log and trained new tellers on our escalation script." The beat is the training on the script; whether any wording changed is an answer slot (C2) |
| Neighbours, Not Numbers | Every branch is part of its town | Scaffold, C3: a case with a local context. Nearest sentence, F1: "6 years in retail banking, the last 3 as a branch supervisor." If nothing comes to mind, say so plainly |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F2: "I handled the branch's formal complaints log and trained new tellers on our escalation script." The beat is the log; a single case followed to the end is an answer slot (C4) |

## Reverse questions for the panel

| # | Question | Why it lands |
|---|---|---|
| 1 | "What could a new complaints lead do in their first month that would genuinely help your branch?" | The reciprocity question for people who will be your peers and internal customers |
| 2 | "What do your supervisors find hardest about escalations?" | Shows you plan to coach from their problems, not your own script |
| 3 | "Where does a complaint most often get stuck between your branch and the contact centre?" | Gives you the live seam and echoes Own the Fix |
| 4 | "As the network changes over 2027, what would you want a complaints lead to protect for your members?" | Neighbours, Not Numbers, asked with tact about a change they may feel closely |
| 5 | "How does your branch's town tend to talk about complaints, and what does a good outcome look like to them?" | Shows the member-owned frame and invites a story you can use |

---

## Prohibited claims

What this pack will not coach, and why. Each entry names its basis and its honest form. The limit is the pack's own observation, not words for you.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches | Inflated form of F3 | F3's sentence at its scope: "I handled the branch's formal complaints log." The material says one branch's log, not the process across branches |
| Handled regulated complaints | Inflated form of F2 | F2's sentence at its scope: "I handled the branch's formal complaints log." The material says formal log; it does not say regulated. A2's and A9's slot stays on whether any were subject to rules |
| Coached branch supervisors on escalations | Inflated form of F6 | "I trained new tellers on our escalation script." The material says new tellers, not supervisors |
| Reported monthly on complaint volumes and resolution times | Inflated form of F5 | "I built the monthly complaints spreadsheet our regional manager uses." The material says a spreadsheet, not what it counted |
| Has contact-centre experience, or that branch work equals it | Negative you stated, F4 | The plain acknowledgment: "I haven't worked in a contact centre." Then a plan, never a past |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment: "I've never presented to anyone above regional level." Then a plan, never a past |

## Sources

Provided documents: the JD text; the values text you copied on 26 November 2026 from ashgrovecu.org/about/values (a source of the pasted text, not a page this pack read); the recruiter's email on the process; your summary of the 2026 strategy brief published in July 2026 (the brief itself was not read); your background as stated in your message. No dossier was present.

Searches and fetches sent: none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values text fixes every output it feeds: the values cheat sheet and the VAL questions |
| 2. Ashgrove interview process, member services roles | skipped | The recruiter's email already names three rounds, who runs each, and what each holds, so the loop is established by the recruiter's own words |
| 3. Ashgrove strategy and recent news | skipped | Your summary of the July 2026 brief supplies the strategy for the CO bank and the grounding brief; a search could have added news since July |
| 4. Interviewer name and Ashgrove | n/a | No interviewer name was given, so no query could be formed; the interviewer read is absent |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD questions |

## Upgrade menu

- Your CV, or the spreadsheet and complaints log you worked with, as text → F1, F2, F3, F5 and F6 move from medium on one sentence each toward high, and the story-mapped answers gain beats
- Your actual pay expectation, notice period, location and reason for leaving, which only you can give → A3 to A6 stop being instructions and become your own words
- What you have actually done on the answer slots: whether any complaints were regulated, whether the spreadsheet counted volumes or resolution times, whether you coached another supervisor, worked with a digital team, or presented at regional level → F2, F5, F6, F7 and F8 and their bank rows become mapped stories or plain limits
- The strategy brief itself → the grounding brief moves from your summary to its own wording
- The names of the Head of Member Services and the two branch managers, once assigned → a Reading the interviewer section, tuned persona weights and a reverse question tied to their own paths
- One email to the recruiter on whether the 20-minute case is shared in advance, and on the date and format (5 December is a Saturday) → a sharper round 3 and no wasted prep
- The hours you have before 5 December → a prioritised prep schedule that puts B2, B3 and the values answers first
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → role-family loop reports, recent organisation context and a fuller strategy read for the CO questions
- A tuesday-dossier.md from earlier verification work on your background → each fit row's confidence would be graded from checked evidence, and the objection worth the deepest rehearsal would come from that check rather than from the pack's reading
