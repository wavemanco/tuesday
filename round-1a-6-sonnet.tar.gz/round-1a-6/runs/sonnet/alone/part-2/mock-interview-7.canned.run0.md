I'll read the reference files the skill points to before building the pack.
I've gathered the sources: the company's values page, its interviewing page, a strategy announcement and a talk summary for Tobias. Next I'm writing the pack file.
Your prep pack is saved as `saltmarsh-games_live-operations-producer_interview_pack.md`. It has 20 questions, a fit snapshot against the JD, a values cheat sheet and five reverse questions.

I built it as a single 60-minute round with Tobias as hiring manager. Saltmarsh's careers page describes that round as a live-incident tabletop followed by a values conversation, with no take-home. If Tobias isn't the hiring manager, the persona weights change.

The question I'd rehearse most is C1, "You haven't worked on a game with in-app purchases. How would you handle that in this role?". The pack's advice is to state the limit plainly, then give what you do have, then a ramp plan.

Say the word and I'll play Tobias on C1, or on a tabletop scenario from bank A, and give you feedback against the pack's guidance.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

Candidate: Femi. Interviewer: Tobias Wrenfield, Head of Live Operations. Round: the single 60-minute hiring-manager interview the company's careers page calls the Outage Hour (a live-incident tabletop, then a values conversation). The pack assumes Tobias is the hiring manager for this role, as the careers page describes the round; if he is not, the persona weights change.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for your own words, not a script, and each cell is sized for a 90 to 120 second answer.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether the claims about your work survive scrutiny |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company's strategy and can think at its level |
| CASE | Structure and reasoning on a live problem from the actual role |

"Answer slot" means an instruction for the interview: say the true thing in your own words, and if the practice was not yours or never existed, say so plainly and return to what you did do. The pack never fills a slot for you.

Highest-ROI prep in the pack: C1, the in-app-purchase question. It will be asked in some form, and a rehearsed, non-defensive answer changes the interview.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title, not a live-events calendar and not two titles, and the words stay there: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's "two of our mobile titles" makes a probe on scale likely. If you ever ran a calendar for more than one title, say how you handled it, in your own words; if you ran only the one, or events were not part of it, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | low | [inferred] | discovery | Your material says you ran the calendar; it does not say which teams were involved or what your part was. Answer slot: the JD names four teams, so expect "which of them did you work with". Name the ones you did and what you did, in your own words; if the calendar did not involve one of them, or the coordination was not yours, say so plainly and stay with the calendar |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented the monthly retention numbers to the studio head; it does not say you reviewed an event or chose the numbers. The words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's "own ... the KPIs it reports" makes a probe on who decided what went into the numbers likely. If you chose or built any of what you presented, say which and how, in your own words; if the numbers came from elsewhere, or there was no review of individual events, say so plainly and stay with presenting them |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap in the JD's terms, but a line with nothing inspected behind it, so expect a probe on how it was used in a release. Lead with it in the quote's own terms: you wrote it, and QA still uses it. The checklist itself is the artifact that would raise this row |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | medium | [grounded] | discovery | The years clear three at face value; your material does not say whether the game was a live service. Answer slot: the JD says live-service, so expect "was the game live". If the main title ran as a live game with ongoing updates, say so in those words; if it did not, say plainly what it was |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap. Lead with it in the quote's terms: weekly, the main title, two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap in the JD's terms, but expect a probe on how the numbers were counted (D1). Lead with the monthly presentation to the studio head, in the quote's terms |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | A checklist is written work, but your material does not show how clear it was or what else you have written. Answer slot: if you have written player-facing notes or team updates, say which, in your own words; if the checklist is the main writing you have, say so plainly. A sample of your writing would raise this row |
| F9 | In-app-purchase experience, which season-pass mobile live-ops work is likely to involve (role-family expectation, not in the JD) | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |

## Persona table

Weights are a shown judgment. Change them if you know something the pack does not.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (bank A) | The Outage Hour tabletop: a simulated outage during a live event, scored on structure and judgment | Highest. The careers page documents a live-incident tabletop as the first half of the hour, and a hiring-manager round tilts to case work anyway | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Values/Behavioral (bank B) | The second half of the hour: a values conversation on the three published values | High. The careers page documents it, and Tobias's published talk theme (Reading the interviewer) overlaps the second value | A selection scaffold per value, each ending in the honest branch; "we" for context, "I" for contribution |
| Skeptic (bank C) | Quiet, persistent probing of the gaps: in-app purchases, two titles, never led a team | High. A hiring manager buys capability and derisks gaps, and F9 and F1 are where your material is thinnest | Rehearse C1 until it is boring; bridges only from the quotes in F1 and F3; the limit said plainly |
| Data-Driven Prober (bank D) | Reads your claims line by line and asks how the retention numbers were counted | Medium. Tobias's published argument is that a live team is judged on whether its patch notes match what shipped, which points toward checking claims against what happened | Know what you can and cannot say about how the numbers were counted; say plainly when you do not know |
| Pressure/Stress (bank E) | Time-boxed challenges inside the tabletop, "sixty seconds" asks | Low to medium. A tabletop invites time pressure, but nothing in the sources describes a stress style | Pause, restate, hold a challenged position through two follow-ups before conceding anything real |
| Conversational (bank G) | The opener and the "why live ops" question | Low. A 60-minute single round leaves little room for small talk, but the opening question is still scored. Bank letters skip F so they cannot be mistaken for fit-snapshot rows | A 90-second arc built only from your own quoted sentences |

## Reading the interviewer

Public professional footprint only, from one search result: a GDC 2026 talk listing, "Patch Notes Are a Promise", which describes Tobias as Head of Live Operations at Saltmarsh Games, previously a QA lead at a console studio. The listing gives his argument as: a live team is judged by how often its patch notes describe what actually shipped. The pack saw only that summary, not the talk.

| Signal | Practical implication |
|---|---|
| Career pattern: QA lead, then live operations | Release and QA vocabulary will land with him. Your checklist is shared ground with QA, not a shared career jump |
| Talk theme: patch notes describe what shipped | Say only what you did, at the scope you did it. A claim wider than the facts is the thing he is most likely to catch |
| Same theme as the second published value | Expect the values half to circle back to announcing what is built; B2 rehearses it |
| Mirror opportunity | Your sentence "Wrote the release checklist our QA team still uses." (F4) sits next to his QA background. Offer it as the thing you wrote, and let him ask about QA |

## Question banks

### Bank A: Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Day two of a weekend event: players can't claim the reward and the support queue is filling. Walk me through your first fifteen minutes." | CASE | [inferred] | Clarify first: what is broken, who is affected, since when, is it spreading. Then objective (stop the harm, keep players informed), who you pull in (engineering to diagnose, community for the player message, QA for scope), and one decision you own (pause, extend or compensate) with what would change it. Think aloud and challenge one premise. Say what you do not yet know instead of guessing a cause | Derived from the documented live-incident tabletop (Sources, row 2); the scenario itself is invented, hence inferred. CASE because it asks for structure on a live problem. Covers the JD's team-coordination line (F2) without asserting any past |
| A2 | "Engineering says the fix needs four hours and the event ends in six. Extend, compensate, or let it lapse, and what do you tell players?" | CASE | [inferred] | Lay out the three options and what each costs players and the calendar, then recommend one and name the condition that flips it. Use the published value in your own words: when the calendar and the players disagree, the players win. Promise players only what is built, so no fix time you cannot hold. Concede what you would need to confirm | A decision under uncertainty, derived from the same documented format. It tests the first two published values at once. CASE because the structure matters more than the answer |
| A3 | "Release is Thursday. QA flags a blocker on Wednesday afternoon, art says the skin is locked, design says the event can't slip. Run the room." | CASE | [inferred] "Wrote the release checklist our QA team still uses." | Say what must be true to ship before picking an option: severity and scope from QA, whether the blocked piece can be cut or flagged off, what a slip costs the event, who makes the call. Give a recommendation and the condition that changes it. Answer slot: if your checklist recorded a go or no-go step, say how it worked, in your own words; if it did not, or the call sat elsewhere, say so plainly and describe how you would structure that step. Return to the quote: "I wrote the release checklist our QA team still uses." | Tests the JD's checklist-with-QA line (F4) and team coordination (F2) as a decision. CASE because it is a live conflict; the checklist quote is the one place your material meets Tobias's QA background |
| A4 | "From February 2027, two titles share one events calendar and the per-title event teams fold into one live-ops group. What would you want to know in your first month, and where is the risk in that plan?" | CO | [grounded] | Use the announcement's terms only as far as you have read them: the pack saw a search summary of Project Larkspur (season-pass model, one shared events calendar from February 2027, per-title event teams retired in favour of a single live-ops group), so read the full page first. Clarify: what changes in cadence, how events differ between the two titles, what a post-event review reports across both. Offer one point everyone prepared would make (the structure change), then one thesis of your own with its concession. Ask rather than assert how this role fits | The strategy question this loop can support, from a September 2026 announcement (Sources, row 3). CO because it tests current-strategy awareness; the JD's "two of our mobile titles" suggests the same two titles, but the pack does not assert it |
| A5 | "Write the player-facing message for that reward outage in three sentences." | CASE | [inferred] | Three beats: what is known right now, what players should do or expect, when the next update comes. Announce only what is built: no promised fix time, no cause you have not confirmed. Plain words, no hedging stack. Answer slot: if you have written player-facing notes before, say which kind, in your own words; if you have not, say so plainly and write this one live | Covers "clear written communication" (F8) and the value about announcing what is built. CASE because it is a live task; derived from the documented tabletop and Tobias's talk theme |

### Bank B: Values/Behavioral (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Selection scaffold for the value "Players Before Plans". Pick one moment with a named stake, a decision you made or influenced, who you told, and what happened to the plan. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I ran the weekly content-drop calendar for our main title for the last two years", or how you would handle it. Do not invent the conflict | The value is published (Sources, row 1). No sentence in F1 carries a disagreement, so this is a scaffold, not a story map |
| B2 | "Tell me about a time you chose not to announce something yet." | VAL | [grounded] | Selection scaffold for "Ship the Patch Not the Promise". Pick a time with a named reason, what you said instead, and what the audience got in the end. If no such time comes to mind, say so plainly, then say how you would decide what is announceable and what is not | The value is published; it is also the theme of Tobias's talk (Reading the interviewer). No quoted sentence carries this, so a scaffold with its honest branch |
| B3 | "Every release should leave the checklist better than it found it. Tell me about a time you improved a process after a release." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story map on F4: you wrote the release checklist, and QA still uses it; those are the beats the quote states, in your own words. Answer slot: if the checklist changed after a release, say what and why; if it did not change, or you did not change it, say so plainly and stay with writing it | The one published value your quoted material meets most directly (F4). VAL because it scores the value "Leave the Build Greener" |
| B4 | "Tell me about a time you delivered an unwelcome number to leadership." | VAL | [generic] "Presented the monthly retention numbers to the studio head." | Story map only as far as the quote: you presented the retention numbers to the studio head each month. Answer slot: if any month's numbers were unwelcome, say what you said and how it landed, in your own words; if none were, or you were not the one who judged them, say so plainly and describe how you would deliver one | Persona stem adapted to F3's quote. VAL because it scores honesty about results; labelled generic because no quoted sentence carries an unwelcome result |

### Bank C: Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You haven't worked on a game with in-app purchases. How would you handle that in this role?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." "Presented the monthly retention numbers to the studio head." | The highest-ROI rehearsal in the pack. Say the limit first: "I haven't worked on a game with in-app purchases." Then what you do have, at its own scope: the calendar and the retention presentations, without saying they cover monetization. Then a ramp plan, said as a plan: what you would ask in week one and of whom. Follow-up one will likely ask how you would plan an event whose job is to drive spend: hold by saying what you would need to learn first, never by claiming you have planned one. Follow-up two will likely press on learning on their time: concede specifically that this is the real gap and the first thing you would close, and return to the two quotes. Never answer with a claim about how fast you learn | F9 is the biggest gap and the likeliest objection. JD because it scores the stated role; hold-then-concede structure because the question presses on a limit you have named yourself |
| C2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Pick one gap honestly from F9, F1 or F2 rather than a false weakness. Name it, then what you would do in week one about it. Your material says the main title's calendar; the pack's observation is that two titles, four teams and monetization are not shown in it, so choose the one you would least want to bluff | A stock stem the pack expects in a hiring-manager round. JD because it scores honest self-assessment against the listed requirements |
| C3 | "This role covers two titles at once. What have you run at that scale?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: if you ever ran a calendar for more than one title, say how you handled it, in your own words; if you ran only the main title's, or events were not part of it, say so plainly and return to "I ran the weekly content-drop calendar for our main title for the last two years." Then, as a plan, what you would want to know about how the two titles differ | F1's likeliest follow-up, from the JD's "two of our mobile titles". JD because it tests the stated scope; the premise "at that scale" is the JD's, so the slot lets it be false |
| C4 | "You haven't led a team, and this role coordinates design, art, engineering and community. Why would they follow your calendar?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." | Say it plainly: "I haven't led a team." The pack's observation is that the JD says coordinate, not manage. Answer slot: which of the four teams your calendar involved and how you got work from them, in your own words; if it involved none of them, or you were not the one coordinating, say so plainly and stay with the calendar you ran. Do not describe authority you did not have | Sourced negative plus F2's gap. JD because the requirement is the JD's; the question names the four teams from the JD |

### Bank D: Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the monthly retention numbers you presented. How were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | State what you presented and to whom, in the quote's terms. Answer slot: if you know how the numbers were counted, say so in your own words, along with what they are sensitive to and the assumption you would defend least; if you do not know how they were counted, or someone else produced them, say that plainly, then say which part was yours | F7's likeliest probe. EXP because it tests attribution; the pack names no method because your material gives none |
| D2 | "Tell me about a time you reviewed how an event or content drop performed." | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Story map only to the quote: the monthly presentation of retention numbers. Answer slot: if the presentation or any other review covered individual drops, say how you ran it, in your own words; if it did not, or you were not the one running it, say so plainly and describe how you would run a post-event review | The JD's post-event review line (F3). JD because it tests the stated responsibility; the theme comes from the JD |
| D3 | "Retention dropped after the last event. Diagnose it." | CASE | [generic] | Clarify: which cohort, since when, against what baseline, and how the company defines retention before you reason about it. Then segment, list hypotheses (event ended, reward cliff, technical fault, content fatigue, seasonality), say which data separates them and what you would do first. Say what you cannot know from here | Covers the retention-metrics requirement (F7) as a live problem. CASE because it asks for diagnosis, not history |

### Bank E: Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has run monetized live events?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | Pause, restate. Three beats from the quotes, in your own words: the calendar, the checklist, the retention presentations. One clause of concession: "I haven't worked on a game with in-app purchases." Hold through two follow-ups; never claim to beat the rival on anything the quotes do not carry | Time-boxed version of C1. EXP because it tests what the claims actually carry |
| E2 | "That release checklist: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Say what the quote carries: "I wrote the release checklist our QA team still uses." Answer slot: if anyone else contributed, say who and what; if you wrote it alone, say so plainly. Hold through two follow-ups by returning to the quote, never by adding to it | F4's attribution probe, which a QA-background interviewer is well placed to press. EXP because it scores precise attribution |

### Bank G: Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc in that order, using your own words for each quoted sentence. Answer slot: the JD says live-service, so if the main title ran as a live game with ongoing updates, say so in those words; if it did not, say plainly what it was. End on why this role, in your own reason | Opening question; F5 and F6 in one arc. EXP because it is a CV walk-through |
| G2 | "What draws you to live operations from where you are now?" | JD | [generic] | Answer slot: give your own actual reason in your own words, one or two sentences; the pack does not supply one. If asked whether you have looked at the company's recent news, say what you have actually read | Motivation consistency is scored even in a friendly register. Generic because your material states no reason |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two titles | C3, A4, G1 |
| Coordinate design, art, engineering and community | A1, A3, C4 |
| Own the post-event review and the KPIs | D1, D2, D3 |
| Manage the release checklist with QA | A3, B3, E2 |
| 3+ years producing live-service games or apps | G1, E1 |
| Experience running a content calendar | C3, E1, G1 |
| Comfortable with player-retention metrics | D1, D3, B4 |
| Clear written communication | A5 |

## Values cheat sheet

The careers page documents a values conversation as part of the round (Sources, row 2). The values are the company's own wording (Sources, row 1).

| Value | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | No quoted sentence carries one. Selection scaffold (B1): a named stake, a decision, an intact relationship. If none comes to mind, say so plainly, then give the nearest thing your material carries (F1: "I ran the weekly content-drop calendar for our main title for the last two years.") or how you would handle it |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | No quoted sentence carries one. Selection scaffold (B2). If none comes to mind, say so plainly, then say how you would decide what is announceable |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F4: "Wrote the release checklist our QA team still uses." Beats are the ones the sentence states; the slot in B3 covers what changed |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "You came to live operations from QA, and you've spoken about patch notes being a promise. What did QA teach you about running live events that you would want a new producer to already see?" | Ties to his own path and published talk theme, and invites him to describe the QA relationship he wants. Say you have read the talk only if you have |
| 2 | "How does this role sit in the move to one shared events calendar from February, and who does the calendar answer to?" | Uses the September 2026 announcement (Sources, row 3) and surfaces the real scope of "two of our mobile titles" |
| 3 | "How are events judged here: retention, spend, something else? How does the post-event review weigh them?" | Lets you hear the real scorecard before you talk about your own gap (C1), and it is the JD's own KPI line |
| 4 | "Which of the three values is hardest to hold during an event, and what does it look like when someone gets it wrong?" | Shows you took the published values seriously and gives you a live example to learn from |
| 5 | "What would you want me to have learned by day 90?" | Turns the in-app-purchase gap into a shared plan and hears his priorities |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team | Negative you stated: "Never led a team, and never worked on a game with in-app purchases." | The plain acknowledgment: "I haven't led a team." No slot |
| Has worked on a game with in-app purchases, or run monetized events | Negative you stated, same sentence | "I haven't worked on a game with in-app purchases." Then a plan, never a past |
| Ran the live-events calendar for two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says the main title's weekly content-drop calendar. C3's slot stays inside that |
| Owned the KPIs a post-event review reports | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says you presented the retention numbers, not that you chose them or reviewed events. D2's slot stays inside the presentation |
| Managed the release checklist through live releases | Inflated form of F4 | F4's quote at its own scope: you wrote it, and QA still uses it. A3's slot asks only whether it recorded a go or no-go step |

## Sources

Provided documents: the pasted JD and your background message. No dossier was consumed.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| # | Query or URL | Returned |
|---|---|---|
| 1 | Saltmarsh Games values | https://saltmarshgames.com/values |
| 2 | Saltmarsh Games interview process live operations producer | https://saltmarshgames.com/careers/interviewing |
| 3 | Saltmarsh Games strategy news mobile | https://saltmarshgames.com/news/project-larkspur (search summary only, not fetched) |
| 4 | Tobias Wrenfield Saltmarsh Games | https://talks.gdconf.example/2026/patch-notes-are-a-promise (search summary only, not fetched) |
| 5 | Fetch: https://saltmarshgames.com/values | The three published values and their one-line meanings |
| 6 | Fetch: https://saltmarshgames.com/careers/interviewing | The loop: recruiter call, then the Outage Hour |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet and bank B: three principles by name |
| 2. Saltmarsh Games interview process | yes | Loop structure: one 60-minute hiring-manager round, tabletop then values conversation, no take-home. It sets persona weights, bank A and the absence of a graded-deliverable section |
| 3. Saltmarsh Games strategy / recent news | yes | A4 and reverse question 2, from a September 2026 announcement |
| 4. Tobias Wrenfield Saltmarsh Games | yes | The interviewer read, persona adjustments and reverse question 1; one talk listing, summary only |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Recruiter's notes on the Outage Hour (which title or event the tabletop uses, any pre-reads) → reweights bank A and replaces the invented scenarios with your real format
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a strategy grounding section, Tobias's other public talks and writing, and sharper CO questions
- The full Project Larkspur page, pasted → A4 rests on the full text instead of a search summary
- The GDC talk, slides or notes → a fuller interviewer read and tailored values stories
- The release checklist itself, or a sample of a written update you wrote → raises F4 from medium and F8 from low
- Your answers to the answer slots: whether the main title ran as a live game, which teams your calendar involved, who produced the retention numbers → upgrades F1, F2, F3 and F5 and regenerates the banks that draw on them
- How many hours you have before Friday → a prioritized prep schedule sized to that time
- A tuesday-dossier.md from an earlier evidence check, if you have one → verified evidence and prohibited claims; the pack is complete without it
