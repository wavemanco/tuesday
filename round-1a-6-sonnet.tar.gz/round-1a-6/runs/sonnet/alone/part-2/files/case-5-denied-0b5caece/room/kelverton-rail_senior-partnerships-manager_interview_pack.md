# Interview pack: Senior Partnerships Manager, Kelverton Rail

## 1. Title block

- Role: Senior Partnerships Manager, Kelverton Rail
- Round: second round, one 60-minute panel on Tuesday
- Panel, in the recruiter's words: "Deepa (VP Partnerships, your future manager) and Ross (Commercial Director)"
- Shape, in the recruiter's words: "First 15 minutes we'd like you to present a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it. Please land on what it means for the operators themselves. Rest is Q&A, and Ross will push on commercials."
- Built from: your message and the recruiter's email as you quoted it. No JD, CV text or market report text reached this pack, and web research was refused (section 10).

## 2. How to use this pack

Personas are how a question is asked; types are what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values. No question carries this tag here: no values-style round is documented in the material, and no published values were in hand |
| EXP | Whether claims about your work survive scrutiny, including what was actually yours |
| JD | The stated role and its requirements, gaps included |
| CO | Knowledge of the company and its market |
| CASE | A live problem set in the role, reasoned aloud |

Labels: `[grounded]` rests on your words or the recruiter's; `[inferred]` is this pack's derivation; `[generic]` is a role-family pattern with no claim about Kelverton or you. Answer slots are instructions for the interview, not questions for you now.

## 3. Prep triage (four hours, spread across the weekend)

| Order | Time | Do this | Where |
|---|---|---|---|
| 1 | 75 min | Choose one thesis, write its concession, and say the whole POV aloud twice against a timer. Aim for 10 to 12 minutes so the panel can break in | Section 5, A1, A3 |
| 2 | 45 min | Settle, in your own words, what you can and cannot say about the £4M: how it was counted if you can find out, what you'd defend least, which part was yours. If you can't find out, rehearse saying so | B1, B2, B3, B5, D1 |
| 3 | 30 min | Say the two gaps aloud until they are boring: no rail selling, no direct quota | C1, C4, D2, F3 and F5 in section 4 |
| 4 | 30 min | Re-read the market report with one job: pick one point to show you read it and one place you'd go further | A4, F6 |
| 5 | 20 min | Choose three reverse questions | Section 8 |
| 6 | 30 min | One live drill on D1 | Offer below |

Everything else is insurance.

## 4. Fit snapshot

No JD was supplied, so requirements are the recruiter's own words, your message, or a role-family prose line marked `[generic]`. Any row asking a practice question is an answer slot, not a claim.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email | "9 years in partnerships" — your message; "last 4 at a payments company running the ISV channel" — your message | medium | [grounded] | transferability | Your material says nine years in partnerships and four running an ISV channel at a payments company. It does not say what an operator partnership is at Kelverton or whether it resembles that channel. Words at that scope: "I've spent nine years in partnerships, the last four running the ISV channel at a payments company." Answer slot: the recruiter's "operator partnerships" wording makes a probe on what you take the term to mean likely. Say what you take it to mean; if you're unsure, say so plainly and state it as an assumption you'd confirm |
| F2 | "Ross will push on commercials" — recruiter's email | "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | discovery | Words at scope: "I took it from six partners to forty, roughly £4M of influenced revenue." Your message gives no period for the figure and does not say how it was counted. Answer slot: how it was counted, what it is most sensitive to, the assumption you would defend least, and which part was yours, each in your own words; "I don't know how it was counted" is an honest branch |
| F3 | A role-family requirement of carrying a commercial number, no source supplied [generic] | "never carried a direct quota, only influenced revenue" — your message | none | [grounded] | capability | You stated this one, so the words are yours: "I've never carried a direct quota, only influenced revenue." Follow it with a plan said as a plan, such as what you would want agreed about how a number is set, and never as a past |
| F4 | "Please land on what it means for the operators themselves" — recruiter's email | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Your material says bus and light rail network planning in consulting. It does not say whether any of it was heavy rail or touched train operating companies, and "from the other side" is your phrase for the consultant's side, so use it only as you said it. Words at scope: "I spent five years in transport consulting, in bus and light rail network planning." Answer slot: the recruiter's call to land on operators makes a probe on what you saw of how operators work likely. If your planning work put you in front of operators, say what you saw, in your own words; if it did not, say so plainly and stay with the network planning |
| F5 | "they sell scheduling software to train operating companies" — your message | "Never sold into rail specifically" — your message | none | [grounded] | capability | You stated this one: "I haven't sold into rail specifically." Then a plan said as a plan, such as what you would learn first and from whom. Never a claim to rail selling, and nothing added to make the gap feel smaller |
| F6 | "the market report their strategy team circulated internally last quarter" — your message | "which I've read" — your message | low | [grounded] | discovery | Your material says you've read it; this pack has not seen it and supplies nothing from it. Words at scope: "I've read the report." Answer slot: if asked about a section, say what you took from it, in your own words; if you don't recall a point, say so plainly |

## 5. Graded deliverable: the 15-minute POV

Declared by the recruiter. Treat it as graded: a thesis, a concession, a point of difference from what the panel already knows, and a close on operators, which was asked for by name.

**Grounded facts to build on.** The recruiter's words in section 1. F1: "9 years in partnerships" and "last 4 at a payments company running the ISV channel". F4: "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)". F6: "which I've read".

**Three limits to design around.** F1: your material does not say what "operator partnerships" means at Kelverton, so open by stating your assumption. F2 points the other way from a depth thesis ("took it from 6 partners to 40" is a breadth result), so expect "why not scale". F6: the report is the panel's own colleagues' work, so reciting it scores as homework.

**Structure, about 10 to 12 minutes spoken.**

| Beat | Holds | Roughly |
|---|---|---|
| 1. Frame | Your assumption about what "operator partnerships" covers, in one sentence, and that you'd confirm it | 30 sec |
| 2. Starting point | What you'd want to learn first, using F1's words at scope | 1 min |
| 3. Thesis | One of the three below | 1 min |
| 4. Moves | Three moves across 18 months, sequenced, with what you would not do first | 4 min |
| 5. Concession | The strongest objection to your own thesis, said before they say it | 1 min |
| 6. Operators | One sentence per move on what an operator would see change, stated as a hypothesis to test with operators, never as what operators want | 2 min |
| 7. Hand over | Stop. Invite the first question | 15 sec |

**Thesis options.** All three are views to argue, not facts about Kelverton or rail; none is established by your material or by research.

| Thesis | Mandatory concession | Differentiation from the consensus answer | Provenance |
|---|---|---|---|
| T1: Go deeper with fewer operators before going broader | Depth concentrates risk in a few relationships and delays visible breadth; you have not seen Kelverton's account data | Most prepared candidates will propose scaling; this one earns attention by saying what you'd hold back, then showing the test that would tell you to scale | [generic] |
| T2: Agree what success means for an operator first, then build the partnership offer from it | Operator priorities differ and can only be learned by asking; this thesis is a hypothesis for the first months, not a finding | Puts the close on operators at the centre of the argument instead of the end | [generic] |
| T3: Sequence the 18 months as learn, prove, scale, with a stop rule at each gate | Slower visible output early; a stop rule needs Ross and Deepa to agree the gates | Gives Ross a commercial structure to push on | [generic] |

**Consensus item, then divergence.** Use the report once, to show you read it: pick one point and name it in a sentence. Then diverge with a reason. Do not recite the report's list; the panel wrote or knows it. Where the report disagrees with your thesis, ask whether it does; do not correct it. This pack has not seen the report, so it cannot say what the consensus item is; that choice is yours after the re-read in triage step 4.

**The anti-pick.** Say one thing you would not do in the first six months, for example launching a broad new partner programme before an operator partnership has proved itself. Choose the one you believe; the example is only the shape. A senior partnerships role is partly the skill of saying no, and a candidate who names the cost of their own plan reads as having judgment.

**The close the recruiter asked for.** The last two minutes are about operators: what changes for them under each move, what you'd test with them first, and how you'd know. Say what you would ask them; do not say what they want.

## 6. Persona table

The loop is established by the recruiter's email: one 60-minute panel with two named people, a talk first and Q&A after. There is no interviewer profile, so weights come from relationship priors plus the recruiter's words, and from nothing else.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (bank A, five questions) | Deepa, the future manager, tests the POV and then moves it | High: the recruiter set a live strategy talk, and the hiring-manager prior is Case plus Skeptic | State assumptions, clarify before structuring, challenge one premise politely |
| Data-Driven Prober (bank B, five questions) | Ross asks how the £4M and the 6 to 40 were counted | High: the recruiter wrote "Ross will push on commercials" and the material holds a headline figure | Know what you can and cannot say about each number, and say plainly when you don't know |
| Skeptic (bank C, four questions) | Either panelist probes the gaps | High: you stated two gaps yourself, in rail selling and direct quota | Rehearse the two acknowledgments until they are boring, then a plan said as a plan |
| Pressure (bank D, three questions) | Ross pushes and time-boxes | Medium: inferred from "push" and a commercial director's role, not documented | Pause, restate, hold through two follow-ups, concede specifically |
| Peer Evaluator (bank E, two questions) | Ross as the commercial counterpart you'd work beside, asking where the seam is | Medium: Ross is not a peer, but the partnerships and commercial seam is the likely topic | Propose seam principles, don't pretend to know the seam |
| Conversational (bank F, two questions) | Early Q&A, "walk me through the journey" | Medium: usually opens the Q&A once the talk ends | A short arc from your own sentences and an answer slot for your reason |

## 7. Question banks

Weights follow the table above. The question tagged D1 is the pack's highest-ROI prep: it will be asked in some form, and a rehearsed non-defensive answer changes the interview.

### Bank A: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have fifteen minutes: where would you take our operator partnerships over the next eighteen months, and what does that mean for the operators themselves?" | CASE | [grounded] "9 years in partnerships"; "last 4 at a payments company running the ISV channel" | The graded deliverable: build it from section 5, not from this cell. Open with your frame in one breath: nine years in partnerships, the last four running the ISV channel at a payments company, then your assumption about what "operator partnerships" means and that you'd confirm it. Answer slot: if the panel asks what you take the term to mean, say, in your own words; if you're unsure, say so plainly and name it as an assumption. Land the last two minutes on operators | The recruiter set this as the opening deliverable; F1 and F4 carry the evidence the opening rests on. CASE because it is a live strategy talk, with JD content |
| A2 | "Pick an operator you know little about. What would you want to understand before proposing anything to them?" | CASE | [generic] | Clarify before you structure: the objective (what the operator is trying to fix), the constraints (who decides, what they can change), and what has been tried. Say your starting hypothesis aloud and what would change your mind. Challenge one premise politely, such as whether a partnership is the right shape for this operator at all. No claim about your past is needed; make none | A Strategist scores clarification before structure, and it rehearses beat 2 of the POV. CASE; generic because it is a pattern for the problem |
| A3 | "You've given me three moves. You can only do one in the first six months. Which, and what do you drop?" | CASE | [generic] | Name the move with the shortest path to proof, the one you drop, and what would make you change the order. This is where the anti-pick in section 5 earns its place. Keep it a judgment, not a claim about anything you've done | Any POV draws this follow-up, because prioritisation is the usual test of a plan. CASE; generic |
| A4 | "You've read our strategy team's market report. What stood out to you, and where would you push back?" | CO | [grounded] "which I've read" | Say what stood out in your own words: one point to show you read it, not a recital, then one place you'd go further, with a reason. Offer the push-back as a question or hypothesis, not a correction of their strategy team. Answer slot: if asked about a section, say what you took from it; if you don't recall a point, say so plainly | F6 is the thinnest row and the report is the panel's own colleagues' work, so this question is likely and easy to fumble. CO because it tests company knowledge. The pack has not seen the report and supplies nothing from it |
| A5 | "At month eighteen, what does success look like for us, and for an operator?" | JD | [generic] | Give one measure on Kelverton's side and one outcome on the operator's side, and say how you'd agree both with the operators and with Ross. Frame them as what you would propose and test, never as what operators want. Name no figure you do not have | The recruiter linked the talk to "what it means for the operators themselves", and Ross will want a measure on the commercial side. JD because it scores the role's success; generic because no JD was supplied |

### Bank B: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the £4M was counted." | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Say the figure as you gave it: roughly £4M of influenced revenue. Answer slots: how it was counted, what it is most sensitive to, the assumption you'd defend least, and which part was yours, each in your own words. If you know the counting method, say it; if you don't, say plainly that you don't know how it was counted. Say the period only if you know it | F2 is the headline figure and the recruiter said Ross will push on commercials. EXP because it tests what the number rests on |
| B2 | "How was the forty counted — what made a partner one of them?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Keep "from six partners to forty" at its own scope. Answer slot: if there was a definition, say it in your own words; if there was none, or you don't know how the count was made, say so plainly | The second number in F2, probed for the same reason. EXP |
| B3 | "Which assumption behind that figure would you defend least?" | EXP | [grounded] "roughly £4M of influenced revenue" | Name it yourself, before Ross does: that converts a gotcha into credibility. Answer slot: if you know the assumption, say it in your own words; if you don't know what the figure rests on, say so plainly and say how you would find out | The weakest-assumption move for F2. EXP |
| B4 | "How would you put numbers on an operator partnership before either side commits?" | CASE | [generic] | Clarify, then structure: the value to the operator, the value to Kelverton, the cost, the risk, and the evidence you would need first. Say what you'd ask Ross to supply, and invent no figure. No claim about your past is needed | Ross pushes on commercials and the role needs a commercial case. CASE; generic |
| B5 | "What does 'influenced' mean in your numbers — what had to be true for revenue to count?" | EXP | [grounded] "roughly £4M of influenced revenue"; "never carried a direct quota, only influenced revenue" | Answer slot: if you know how your company defined it, say so in your own words; if you don't, say plainly that you don't know how it was defined. Do not translate it into a stronger word | F2 and F3 meet here, and "influenced" is the word a commercial director tests. EXP |

### Bank C: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You haven't sold into rail. What would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | The plain acknowledgment: "I haven't sold into rail specifically." Then a plan said as a plan: what you'd want to learn in the first weeks and from whom. Set the consulting years beside it at their own scope, and do not offer them as a substitute | F5 is a gap you stated, and F4 is the adjacent work. JD because it scores a stated requirement of the job, gaps included |
| C2 | "Bus and light rail planning isn't the same as heavy rail. What do you know about how a train operator works day to day?" | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Do not accept the premise as your own claim: your material says bus and light rail network planning in consulting. Answer slot: if your planning work put you in front of operators, say what you saw; if it didn't, say so plainly and stay with the planning. Close with what you'd learn first | F4's limit is the likeliest place to be probed, in rail terms. EXP because it tests attribution |
| C3 | "Why a rail-tech vendor, and why now?" | EXP | [generic] | Give your actual reason, in your own words; this pack has not been told it and will not supply one. Keep it short and specific to the role | A motivation probe every skeptic asks. EXP. Generic because the reason is yours |
| C4 | "A senior partnerships role usually carries a number, and you haven't. How does that sit?" | JD | [grounded] "never carried a direct quota, only influenced revenue" | The plain acknowledgment: "I've never carried a direct quota, only influenced revenue." Then what you would want agreed up front, said as a plan: how the number is set and what is in your control. Do not describe a past that did not happen | F3 is stated, so the acknowledgment has a source. JD because it scores a likely job requirement |

### Bank D: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That £4M was influenced, not carried. How much of it was actually you?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue"; "never carried a direct quota, only influenced revenue" | Highest-ROI prep. Pause, restate, then hold only what the quotes carry: "I took it from six partners to forty, and the revenue was influenced revenue, not a quota I carried." Answer slot: say which part was yours, in your own words; if you don't know how it was apportioned, say so plainly. Follow-up one, "would it have happened without you": do not argue a counterfactual, return to the quote. Follow-up two, "so you've never been held to a number": concede exactly, "I've never carried a direct quota", then your plan. Never fold on the core, and never add to it | F2 and F3 meet here, and the recruiter's email points at it. Pressure persona because the test is composure, not content. EXP |
| D2 | "Sixty seconds: why you over someone who's sold into rail?" | JD | [grounded] "9 years in partnerships"; "last 4 at a payments company running the ISV channel"; "Never sold into rail specifically" | Say what you did, at its scope, and let them draw the inference: nine years in partnerships, the last four running the ISV channel at a payments company. Concede the gap in one sentence: "I haven't sold into rail specifically." Do not tell them what your work proves | A stock stress stem aimed at the F5 gap. JD |
| D3 | "Suppose an operator tells you it has no time for partnerships with a vendor. What do you say?" | CASE | [generic] | Clarify what's behind it, then reframe to the operator's own problem: ask what would be worth their time before pitching anything. Concede that some operators will say no, and say how you'd learn from the refusal. No claim about your past is needed | Tests composure and the operator-first close at once. CASE; generic |

### Bank E: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Where's the seam between partnerships and commercial, and what happens when we disagree about an operator deal?" | JD | [generic] | Propose principles, not a map: who owns the operator relationship, how a deal is credited, how a disagreement is escalated. Say you'd agree them with Ross and Deepa early. Do not pretend to know where their seam sits today | Ross is the commercial counterpart you'd work beside. JD; generic |
| E2 | "How do you handle credit when a deal spans partnerships and sales?" | EXP | [grounded] "never carried a direct quota, only influenced revenue" | Open with a principle: agree how credit is attributed before the deal, not after. Answer slot: if you agreed attribution rules at your last company, say how, in your own words; if there were none, say so plainly and say what you would propose here | Influenced revenue is exactly the credit problem, and a persona stem raises it. EXP because the answer rests on F3 |

### Bank F: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Walk me through the journey: how did you get from consulting to here?" | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"; "9 years in partnerships"; "last 4 at a payments company running the ISV channel" | A 90-second arc whose beats are only what these sentences state: five years in transport consulting in bus and light rail network planning, nine years in partnerships, the last four running the ISV channel. Answer slot: give your actual reason for each move and for this one, in your own words; this pack was not told them | Casual questions are still scored, and the arc is the answer to the first friendly one. EXP |
| F2 | "What have you been reading or looking at lately on operators or rail scheduling?" | CO | [grounded] "which I've read" | Name only what you have actually read. Answer slot: if the report is the main thing, say so plainly and say what you took from it; do not name other sources you haven't read | A rapport-style probe that is really a homework check. CO |

### Requirement coverage

| Requirement | Questions |
|---|---|
| Present a POV on operator partnerships over 18 months (F1) | A1, A2, A3 |
| Land on what it means for the operators (F4) | A1, A5, D3, C2 |
| Commercials: Ross will push (F2) | B1, B2, B3, B4, B5, D1 |
| Carry a commercial number (F3) | C4, D1, E2 |
| Rail selling (F5) | C1, D2 |
| The market report (F6) | A4, F2 |
| Credit and the commercial seam | E1, E2 |
| A values requirement | none: no values-style round is documented and no published values were in hand |

## 8. Reverse questions

No interviewer profile exists, so none of these is tied to a panelist's career path; a name with a public footprint would add one.

| # | Ask | Why it lands |
|---|---|---|
| 1 | To Deepa: "What would you want to be true at month six for you to say this hire is working?" | Your future manager's answer sets how the role is measured, which bears directly on the quota gap |
| 2 | To Ross: "How are partnership numbers attributed between partnerships and your commercial team today?" | Shows you've thought about the credit seam, and Ross's answer tells you what "influenced" would mean here |
| 3 | "When you ask an operator today what the partnership gives them, what do they say?" | Takes the talk's close on operators into the Q&A |
| 4 | To Deepa: "Where do operator partnerships sit relative to direct sales, and who owns the day-to-day operator relationship?" | Resolves the ambiguity in what "operator partnerships" covers |
| 5 | "What did the strategy team's report change in how you're thinking about operators?" | Shows you read it as a working document, and turns the report into a conversation |
| 6 | "What's the part of my background you'd most want to test?" | Invites the gaps on your terms, so the rehearsed answers are used instead of dodged |

## 9. Prohibited claims

Built from the fit snapshot before the banks were written. This pack will not coach:

| Not coached | Basis | Honest form |
|---|---|---|
| Carried a quota, or was accountable for a revenue number | Negative you stated, F3 | "I've never carried a direct quota, only influenced revenue." No slot |
| Sold into rail, or has rail sales experience | Negative you stated, F5 | "I haven't sold into rail specifically." No slot |
| Generated, closed or owned £4M of revenue | Inflated form of F2 | F2's quote at its own scope: roughly £4M of influenced revenue. The limit is the pack's observation: your message says influenced, not what part was yours. B1 and D1 ask only which part was yours |
| Signed or recruited the forty partners yourself | Inflated form of F2 | "took it from 6 partners to 40", at its own scope. Your message does not say who signed them |
| Worked inside a train operator, or knows heavy-rail operations | Inflated form of F4 | F4's quote at its own scope: bus and light rail network planning in consulting. The limit is the pack's observation; C2's slot stays inside the planning work |

## 10. Sources

Provided: your message (your background, and the recruiter's email as you quoted it). The market report you described did not reach this pack, so nothing in it was read. No dossier was present.

Research tier: L1 — searches 5 of 6, fetches 0 of 2; every search was refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Query "Kelverton Rail values": refused. Moved nothing; no published values in hand, so no values cheat sheet. No values-style round is documented either |
| 2. Interview process | skipped | The recruiter's email fixes the session, who runs it and what it holds: a 60-minute panel, a talk, then Q&A |
| 3. Strategy and recent news | unavailable | Query "Kelverton Rail scheduling software train operating companies strategy news": refused. Would have moved A4, A5 and F2 and a grounding brief; those are labelled accordingly |
| 4. Interviewer footprint | unavailable | Queries "Deepa VP Partnerships Kelverton Rail" and "Ross Commercial Director Kelverton Rail": both refused. Would have moved an interviewer read, persona weights and a reverse question tied to a panelist's path |
| 5. Representative JD | unavailable | Query "Senior Partnerships Manager rail technology scheduling software job description": refused. Would have moved the fit snapshot's requirement cells and the JD-tagged questions |

## 11. Upgrade menu

- The JD text → F1 to F6 requirement cells become the posting's own words, and the `[generic]` JD questions (A5, B4, E1) become `[grounded]`
- Your CV text → more of your own sentences in the evidence column, so F1, F2 and F4 can carry more of the banks
- The report's text, or its key pages → a grounding brief, a firmer A4, and F6 raised from low
- A short note on how your company counted influenced revenue, or the attribution report behind it → F2 raised from medium to high, and B1, B2, B3 and D1 can be rehearsed against the real definition
- Search permission → targets 1, 3, 4 and 5 above; a deeper pass of up to 6 more searches and 2 more fetches, several more minutes, is available on request
- A name with a public profile for Deepa or Ross → an interviewer read, persona weights read from it, and a reverse question tied to their path
- One email to the recruiter asking what "operator partnerships" covers → the F1 gap closes and A1's opening assumption becomes a fact
- A `tuesday-dossier.md` from an earlier evidence review → verified evidence and absolute prohibited claims in place of the locally built list; never a prerequisite
