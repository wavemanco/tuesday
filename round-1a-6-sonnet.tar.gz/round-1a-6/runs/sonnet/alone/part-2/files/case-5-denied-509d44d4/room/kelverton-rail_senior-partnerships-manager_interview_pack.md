# Senior Partnerships Manager, Kelverton Rail: interview pack

Round: second round, Tuesday, 60 minutes, two-person panel. Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). The first 15 minutes are a talk-through POV with no slides, landing on what it means for the operators themselves; the rest is Q&A, and Ross will push on commercials.

Built without a JD, without the text of the market report, and without web research (see Sources). Highest-ROI prep in this pack: **B1**, the quota-and-rail objection, because both halves of it come from your own message and Ross is the panelist the recruiter said will push.

## 1. How to use this pack

Personas describe how a question arrives. Types describe what it is scoring. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you did.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values. No values round is detected for this session, so this pack has no VAL rows |
| EXP | Whether your own claims survive scrutiny, and what was actually yours |
| JD | The stated responsibilities of the role, including where you are thin |
| CO | How well you know the company, its market and its recent moves |
| CASE | Structure and reasoning on a live problem from the role |

Answer slots are instructions for the interview, not questions for you now. Where a slot offers two branches, either is a good answer if it is true.

## 2. Prep triage (four hours)

| Order | Time | Do this | Tied to |
|---|---|---|---|
| 1 | 60 min | Choose a lead thesis and write the three moves, each with its concession, plus the operator close | Section 3, A1, A3 |
| 2 | 60 min | Read the market report once more for one point to agree with and one to diverge on, then say the whole POV aloud against a 15-minute clock, twice | Section 3, A1, A4, A5 |
| 3 | 45 min | Say B1 and D1 aloud, concede-hold-concede; write your own answers to the C1 to C3 slots on paper | B1, D1, C1 to C3 |
| 4 | 30 min | Rehearse the 90-second journey and the move-to-rail reason | B2, B3, F1 |
| 5 | 30 min | Pick three reverse questions and say the seam answer for E1 | Section 5, E1 |
| 6 | 15 min | Buffer | |

Everything else in this pack is insurance.

## 3. Graded deliverable: the 15-minute POV

The recruiter announced it, so it is graded. This section builds the structure; the content that depends on the market report is yours to supply, because the report's text was not available to this pack.

| Part | What goes in it | Provenance |
|---|---|---|
| Facts you may build on | F1: "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." F2: "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." Use them at their own scope. Use F3, "Never sold into rail specifically and never carried a direct quota, only influenced revenue.", as the concession rather than hiding it | [grounded] |
| Lead thesis option 1 | Go deep before wide: a small number of operator relationships, each built around a result the operator's own team cares about, before widening. Concession: it is slower to scale, and which operators to start with is a judgement you cannot fully make without Kelverton's account data | [generic] |
| Lead thesis option 2 | Define every partnership by one operator-side outcome agreed at the start, not by Kelverton product usage. Concession: it needs operator data and trust, and the outcome may move for reasons outside the partnership | [generic] |
| Lead thesis option 3 | Build the ecosystem of third parties operators already work with, so operators get value without extra integration effort. Concession: breadth can be confused with operator value, and you have not seen Kelverton's integration landscape. Your ISV sentence in F1 is the only place your material touches this shape; whether it carries over is for the panel to tell you | [generic] |
| Differentiating from the report | The report is the consensus source. Bring one of its points to prove you read it as its authors would, then one thesis-driven divergence with reasons. Its authors are on the other side of the table, so diverge on emphasis or sequence unless you have strong grounds | [grounded] |
| The anti-pick | Name one thing the plan deliberately does not do over 18 months, and why. A plan that says no reads as judgement | [generic] |
| The close the recruiter asked for | For each move, one sentence in operator terms: what an operator's own team would notice, and when. Fill these from the report's vocabulary. Your own sentence on this is F2, at its own scope | [grounded] |
| Timing | About 1 minute thesis, 8 minutes for three moves with concessions, 3 minutes on what it means for operators, 2 minutes on what you would confirm first, 1 minute handing over to Q&A | [generic] |

## 4. Fit snapshot

No JD was supplied, so requirements are the recruiter's own words, quoted, plus one role-family row labelled generic. No row is a gate, because nothing supplied states an eligibility term.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email, as you quoted it | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [grounded] | transferability | Your material carries a payments ISV channel, not operator partnerships, with nothing inspected behind it. The words stay at the sentence: you were running the ISV channel and it went from 6 partners to 40. Answer slot: the recruiter's POV line makes a probe on which parts of that channel carry to operators likely. If any do, say which, in your own words; if none do, or the shape differed, say so plainly and stay with the sentence |
| F2 | "land on what it means for the operators themselves" — recruiter's email, as you quoted it | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." — your message | medium | [grounded] | transferability | The sentence says bus and light rail network planning in transport consulting. Your material does not say train operators, or which side of an operator engagement you stood on, and the words stay at the sentence. Answer slot: the recruiter's close on the operators makes a probe on that work likely. If any of it was for or with train operators, say which and what it was; if it was bus and light rail only, say so plainly and stay with the sentence |
| F3 | "Ross will push on commercials" — recruiter's email, as you quoted it | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never sold into rail specifically and never carried a direct quota; what I have is influenced revenue." Then how you would learn it, said as a plan and never as a past |
| F4 | Build and grow a partner channel, a role-family expectation with no JD supplied | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [generic] | none | No gap in kind, but a figure with nothing inspected behind it, so expect the four defend-the-number probes: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Lead in the sentence's own terms: influenced revenue, not sold |

## 5. Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | Deepa's register: the POV, then live problems on operator partnerships | Highest. A hiring manager buys capability and the first 15 minutes are a graded talk-through; the recruiter's words establish this one session, so the weight rests on them | Clarify, then structure, then answer; use the report's vocabulary; challenge one premise respectfully |
| B. Skeptic | Quiet probing of the two stated negatives and of the payments-to-rail move | High. F2 and F3 are where your material is thinnest, and a future manager derisks gaps | Rehearse B1 until it is boring; concede the two stated negatives plainly, then give a plan |
| C. Data-Driven Prober | Ross on the influenced revenue and the 6 to 40 | High. The recruiter said Ross will push on commercials, and F1 carries two figures | Know what you can and cannot say about how each figure was counted; say plainly when you do not know |
| D. Pressure | Ross time-boxing and interrupting on why you | Medium. Same signal from the recruiter, with less certainty about style | Pause, restate, hold through two follow-ups, concede only the two stated negatives |
| E. Peer Evaluator | Ross on where partnerships ends and sales begins | Medium. A commercial director prices what a partnerships hire does to his team's accounts | Propose seam principles instead of pretending to know the seam; offer what you bring to his team |
| F. Conversational | Deepa's opener and any casual question | Lower, but the biography question is almost certain | A 90-second arc; treat casual questions as scored |

## 6. Question banks

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Take us through your point of view: where would you take our operator partnerships over the next 18 months?" | CASE | [grounded] | The graded deliverable; section 3 is the build. A thesis in the first minute, three moves each with its concession, then what it means for the operators, which the recruiter asked you to land on. Say unknowns as unknowns. This row makes no claim about your past | The recruiter named it, so it is certain; F1 and F2 are the nearest evidence and both are adjacent, which is why the plan is framed as an outside view. CASE because it is live structured reasoning |
| A2 | "What would you need to know about our operators before you committed to that plan?" | CASE | [generic] | Clarify before committing. Group your unknowns in three: who operators are to Kelverton (customers, co-developers or both), what each wants from the relationship, and what Kelverton could offer them that the product does not already give. End by asking the panel one of them. This row makes no claim about your past | Case rounds score clarifying first. F1 means your plan comes from outside, and saying so is stronger than hiding it |
| A3 | "Your plan asks something of operators' own teams. What is it, and why would they give it?" | CASE | [generic] | Name the ask in one sentence and the return in operator terms, then the cost to them. If the return arrives after the cost, say so and say how you would bridge the gap. Land it on the recruiter's close: what it means for the operators themselves. This row makes no claim about your past | This is where the operator close gets tested; F2 is your nearest evidence and it is thin, so the answer should rest on structure |
| A4 | "If you had half the capacity, which of your moves would you drop?" | CASE | [generic] | Rank your three moves before Tuesday and drop the one whose benefit lands furthest from the operators; say why. It is the anti-pick from section 3 said aloud. This row makes no claim about your past | A future manager tests prioritisation. CASE because it is a live trade-off, not a past story |
| A5 | "What in our market report would you disagree with?" | CO | [grounded] | One point you agree with, to show how you read it, then one divergence with reasons, framed as judgement and not correction. Name the section you mean. The report text was not available to this pack, so the content is yours. This row makes no claim about your past | The recruiter attached the report, and it is the consensus source every prepared candidate has read. CO because it tests homework depth |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never carried a quota and you've never sold into rail. Why should we believe you can be accountable for commercial outcomes here?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | The highest-ROI rehearsal in this pack. Concede first, in your own words and no wider than the quote: "I've never sold into rail specifically and never carried a direct quota; what I have is influenced revenue." Hold: you were running the ISV channel, which went from 6 partners to 40, with roughly £4M of influenced revenue, said as influenced and never as sold. Expect two follow-ups. On "influenced isn't sold", agree with the distinction and stay with the sentence. On "what would you commit to", choose between giving your own view once you have seen the baseline and asking to agree the definition with them first; supply no figure. Close with a plan, not a past: what you would agree with Ross in the first weeks about how partnership outcomes are measured. Do not fold on the sentence and do not add to it | F3 is the biggest gap and the recruiter said Ross will push on commercials, so this arrives in some form. This pack inferred it from your two stated negatives; no dossier named it. JD because it scores the commercial requirement |
| B2 | "Your background is bus and light rail network planning in consulting. How does that carry to train operating companies?" | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Say the sentence at its own scope: five years in transport consulting, bus and light rail network planning. Answer slot: if any of that work was for or with train operators, say which and what it was; if it was bus and light rail only, say so plainly, then say what you would need to learn about train operations first. "From the other side" is your phrase, so expect "which side"; answer it from what you actually did | F2 is the only operator-world evidence and it is adjacent; EXP because the probe tests what the sentence actually covers |
| B3 | "Why partnerships at a scheduling-software company, and why now? What's drawing you from payments to rail?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | The two quoted halves are on the table: transport consulting earlier, nine years in partnerships with the last four on a payments ISV channel. The sentence connecting them is yours to give. Answer slot: say your actual reason for the move, in your own words; if the reason is the role and not the sector, say that plainly. Keep it about what you want next, not about the last employer | Motivation consistency is the Skeptic's core test; F1 and F2 are the two halves the story must join. EXP because it tests your own account |
| B4 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Pick from the two negatives you stated and name it before they do, in your own words. Then a ramp as a plan, not a past: who you would ask and what you would read in the first weeks. Stay with those two; do not add a weakness your material does not show | A standard Skeptic stem; F3 is the honest answer, and naming it first converts a probe into candour |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the £4M of influenced revenue was counted." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Answer slot, in your own words: how it was counted; what it is sensitive to; which assumption behind it you would defend least; which part was yours. If you do not know how it was counted, say so plainly and return to the sentence. Keep "roughly" and "influenced"; do not harden the figure | F1 carries a headline figure and Ross is the likely prober; EXP because it tests attribution honesty. The pack supplies no method, and none should be improvised live |
| C2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Name it before they ask for it, in your own words. If you cannot name one, say plainly that you do not know how the figure was assembled and what you would check. A weakest assumption said calmly is a credibility gain | The weakest-assumption move for a metric question; follows C1 in the usual probe order |
| C3 | "You went from 6 partners to 40. How many were active, and how much of the revenue came from the top few?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | A denominator probe. Answer slot: if you know the active count or the concentration, say them as you know them; if you do not, say so plainly and say where the figure would be found. Do not estimate live. The sentence says 6 to 40, and that is the scope | The second figure on F1 is a magnet for denominators; EXP because it tests whether you know your own numbers |
| C4 | "If we set you a commercial target for operator partnerships, how would you want it defined?" | CASE | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Give a definition and what it would miss: a target on influenced revenue, on sourced revenue, or on an operator-side result, and which you would take and the cost of that choice. Concede in your own words that you have never carried a direct quota. The definition is a proposal for this role, not something you have done | Turns the commercials push into a design problem and uses F3 honestly. CASE because it is a live definition task |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you rather than someone who has already sold into rail?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Hold-then-concede. About a minute spoken: answer first, one reason, then the limit. Hold: you were running the ISV channel from 6 partners to 40, and you did five years of bus and light rail network planning in transport consulting, each at its own scope. Concede in plain words that you have never sold into rail specifically; do not argue rail is easy. Hold through two follow-ups before conceding anything beyond the two stated negatives | The stress version of B1; JD because it scores the stated commercial requirement |
| D2 | "That £4M. How much of it was actually you?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Answer slot: say which part was yours, in your own words; if you do not know how the figure was attributed to the channel, say so plainly and return to the sentence. Hold through two follow-ups, and make the concession specific by naming the part you cannot vouch for. A figure that shrinks calmly beats one defended until it breaks | The attribution-honesty probe, delivered with pressure; F1 is the figure it presses on |
| D3 | "Convince me operator partnerships are worth investing in rather than more direct sales headcount." | CASE | [generic] | Clarify what each option buys, set the comparison in operator terms and Kelverton terms, and give the conditions under which more sales headcount wins. If the panel asks for your own evidence, B1 and C1 to C3 carry it. This row makes no claim about your past | A commercial director tests whether you can argue against your own function. CASE because it is a live argument |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Where's the seam between partnerships and sales on an operator account, and what happens when we disagree?" | CASE | [generic] | Propose principles, not a map of their seam: one account plan per operator with a named owner, and disagreements settled by what the operator needs. Say you do not know where their seam sits today and how you would want to set it with Ross. Offer what you bring his team, not only what you need. This row makes no claim about your past | A commercial director is pricing what this hire does to his accounts. CASE because it is a live design problem |
| E2 | "Tell me about a time credit for work was shared across teams. How did you handle it?" | EXP | [generic] | Selection scaffold: pick a time where two teams contributed to one result; it needs a named result, your own part stated plainly, and the other team's part credited. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard peer stem on credit; no quoted sentence of yours carries a story for it, so this is a scaffold and not a story map |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | A 90-second arc with the beats the sentences state: five years in transport consulting, bus and light rail network planning; then nine years in partnerships, the last four running the ISV channel from 6 partners to 40. The last beat, why this role, is yours: say it in your own words | Almost certain as an opener from the future manager; casual openers are scored. EXP because it lays out your own claims |
| F2 | "How do you keep up with how operators are changing?" | CO | [generic] | Answer slot: name what you actually read or follow; if it is little, say so plainly and name the first thing you would follow. Do not list sources you do not use. This row makes no claim about your past | A casual question on a hot topic for a role selling to operators; CO because it tests genuine interest |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| POV on operator partnerships over 18 months | A1, A2, A3, A4 |
| Land on what it means for the operators themselves | A1, A3, B2 |
| Ross will push on commercials | B1, B4, C1, C2, C3, C4, D1, D2, D3 |
| Awareness of the market report | A5 |
| Operator-world credibility | B2, F1, F2 |
| Build and grow a partner channel (role-family) | C3, F1 |
| Working across sales (role-family) | E1, E2 |
| Motivation for the move | B3, F1 |

## 7. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "When you say operator partnerships, what does that cover today: customers, co-development, or something else?" | Your material does not show which, and the answer decides how much of F1 transfers; it also shows you separate the three |
| 2 | "What would you want operators to say about Kelverton in 18 months that they don't say today?" | Puts the operator close back on the panel's own terms |
| 3 | "How do you want partnership outcomes measured, and how does that sit with how commercial targets are set?" (for Ross) | Addresses the commercials push head-on without claiming a quota history |
| 4 | "Which finding in the market report is shaping this role most?" (for Deepa) | Shows you read the report for what it asks of the role, not as a document to recite |
| 5 | "Where does this role end and sales begin on an operator account?" (for Ross) | The seam question from E1, asked first; it signals respect for his accounts |
| 6 | "What would make you say in six months that this was the right hire?" | Gives you the success measure to build the first plan around |

## 8. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has sold into rail, or has carried a quota | Negative you stated, F3 | The plain acknowledgment F3 gives: "I've never sold into rail specifically and never carried a direct quota; what I have is influenced revenue." No slot |
| Sold, closed or owned the £4M | Inflated form of F1 | F1's sentence at its own scope: roughly £4M of influenced revenue. The limit is the pack's observation: your material says influenced, not sold. C1 to C3 stay inside the sentence |
| Built the ISV channel or signed the 40 partners yourself | Inflated form of F1 | F1's sentence: running the ISV channel, 6 partners to 40. The limit is the pack's observation: your material says running it, not building it or signing each partner |
| Worked for a train operator, or has train operations experience | Inflated form of F2 | F2's sentence at its own scope: bus and light rail network planning in transport consulting. The limit is the pack's observation: your material does not say train operators, or which side of an operator you stood on |

## 9. Sources

Provided documents: your message, which contains your background and the recruiter's email as you quoted it. The market report was attached to the recruiter's email but its text was not available to this pack, so nothing here draws on it. No dossier was present.

Research tier: L1 — searches 6 of 6, fetches 0 of 2

| Query | Outcome |
|---|---|
| Kelverton Rail company values | refused |
| Kelverton Rail interview process partnerships manager | refused |
| Kelverton Rail scheduling software train operating companies strategy news | refused |
| Deepa VP Partnerships Kelverton Rail | refused |
| Ross Commercial Director Kelverton Rail | refused |
| Senior Partnerships Manager rail technology train operating companies job description | refused |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | The one call was refused. It would have moved VAL themes; no values round is detected for this session, so no cheat sheet was due either way |
| 2. Kelverton Rail interview process | unavailable | The one call was refused. It would have moved later-round structure; this session's loop is already given by the recruiter's email |
| 3. Kelverton Rail strategy and recent news | unavailable | The one call was refused. It would have moved A5 and a grounding brief, which this pack omits |
| 4. Deepa and Ross at Kelverton Rail | unavailable | Both calls were refused. They would have moved the interviewer read, persona weights and a reverse question tied to each panelist's path |
| 5. Representative Senior Partnerships Manager JD | unavailable | The one call was refused. It would have moved the requirement rows, JD-tagged questions and any gate rows |

## 10. Upgrade menu

- Market report text, or the sections you would lean on → A5 and the POV build become grounded in its vocabulary, and the divergence point can be drafted with you
- JD text → the F4 row and the coverage table become quoted requirements, and any location, travel or pay-term gates would be surfaced
- Search permission restored → the six refused searches rerun, and a deeper pass is available at up to 6 more searches and 2 more fetches, several more minutes
- The panelists' full names or profile links → a reading of Deepa's and Ross's public professional footprint, reweighted personas, and a reverse question tied to each path
- Your own answers to the slots in B1, B2, C1 to C3 and F1 → facts you state become quoted evidence and the rows that draw on them are regenerated
- A tuesday-dossier.md from an earlier assessment of this role → graded evidence and a named highest-ROI objection in place of the one this pack inferred
