# Interview prep pack: Product Operations Manager, Stripe

Round: final round. Interviewer names and relationships: not given. Built as session mode with blended persona weights, because the schedule of the final is not known.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Tag | Meaning |
|---|---|
| VAL | Behavioral or values alignment: does past behavior show the company's published values |
| EXP | Work-experience deep-dive: do your claims survive scrutiny, and what was actually you |
| JD | Role-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge: homework depth and altitude |
| CASE | Live problem from the role: structure and reasoning |

This pack has no CV, no job description and no research behind it, so most of it is `[generic]`: useful rehearsal, no facts about Stripe or about you. The upgrade menu says what each missing input would turn into `[grounded]`.

## Fit snapshot (worksheet variant)

No CV or background was provided, so every evidence cell is `none given`. No job description was provided either, so the requirements below are role-family prose, not quotes from a Stripe posting.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Run launches or rollouts that span several teams (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a named launch or rollout, who was involved and which part was yours. Selection scaffold: pick one rollout you were part of, with a named stake, your own part in it and an outcome you can state. If none comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would run one |
| F2 | Define, track and report product or operational metrics (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a metric you can explain end to end: how it was counted, what it is sensitive to, and what was yours. Selection scaffold: pick one metric you have worked with and be ready to say how it was counted. If you do not know how a figure was counted, say so plainly, then say how you would find out |
| F3 | Turn customer or internal feedback into priorities (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a case where feedback changed what a team did, with your part named. Selection scaffold: pick a time feedback reached a decision you touched. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it |
| F4 | Communicate with senior stakeholders and drive decisions (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a specific decision you helped reach and the audience it went to. Selection scaffold: pick one moment you brought a hard message to someone senior, and what happened to the relationship after. If none comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it |
| F5 | Build or improve processes and tooling that teams adopt (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a process or tool you built or changed, who used it, and your part. Selection scaffold: pick one process change and be ready to separate what you did from what the team did. If you only supported someone else's process, say so plainly |
| F6 | Work through ambiguity and influence without formal authority (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a situation with no clear owner where you moved work forward. Selection scaffold: pick one such situation and say what you could and could not decide. If none comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it |

## Persona table

The loop for this final is not established by any source, so these weights rest on a hiring-manager and cross-functional pattern with flat tilts. If you know who is in the room, the weights change.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | Live problem from the role: plan a rollout, diagnose a metric drop | High: a final for an operations role usually includes one live problem, since it scores reasoning you cannot rehearse as a story | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise politely |
| B. Skeptic | Probes the gaps: why this role, why now, what you would be weakest at | High: every final has a derisking pass, and the pack cannot see your gaps yet | Rehearse the weakest-on-day-one answer until it is boring; build bridges only from what you actually did, and say plainly where there is nothing |
| C. Values/Behavioral | Scenario probes, often from someone outside the function | Medium: no source says Stripe runs a values round, so this is a guess; stories are reusable either way | Pick stories in advance; "we" for context, "I" for your own part |
| D. Peer Evaluator | Seams between teams, credit, disagreement | Medium: a final often includes a peer or cross-functional session | Propose principles for the seam instead of pretending to know it; offer what you bring their team |
| E. Data-Driven Prober | Pushes on how your numbers were counted | Medium: operations roles talk in metrics, so any figure you cite gets tested | Know what you can and cannot say about how each number was counted, and say plainly when you do not know |
| F. Conversational | Friendly, unstructured openers | Medium: it opens most sessions and is still scored | Prepare a 90-second arc for the biography question |
| G. Pressure | Interrupts, time-boxes, questions motives | Low-medium: possible from a senior interviewer | Pause, restate, hold a challenged position through two follow-ups before conceding anything real |

## Question banks

All rows are `[generic]`, with no quote from you to rest on, so no guidance cell makes a claim about your past. Where a story is needed, the guidance is a selection scaffold ending in an honest branch.

### A. Case/Strategist (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A product team is launching a change that touches five other teams in six weeks. Sketch the plan. What do you need to know first?" | CASE | [generic] | Clarify first: what is the change, who is affected, what is fixed (date, scope) and what can move. Then objective, stakeholders, sequencing, how you will know it is working, the main risks. Say your structure aloud before you fill it | Tests structure on a rollout problem, F1's requirement; CASE because it is a live problem, no past is presupposed |
| A2 | "A key adoption metric for an internal tool dropped 20% last month. Diagnose it." | CASE | [generic] | Clarify what the metric counts and when it changed. Split by segment and by time, check for instrumentation or definition changes before real behavior change, then list hypotheses ranked by how cheaply you can test them. Say which you would test first and why | Tests F2's requirement through a diagnosis; CASE with an EXP flavor if they ask what you have diagnosed before |
| A3 | "Three teams each want your help this quarter and you can take on one. How do you decide?" | CASE | [generic] | State the criteria you would use before choosing, ask what you would need to know about each request, say who you would consult, and say what you would tell the two you turn down | Scores prioritization and influence without authority, F6's requirement |
| A4 | "What would you want to understand about our current priorities before proposing anything in your first ninety days?" | CO | [generic] | A list of questions you would ask, not claims about the company's strategy. Do not state what Stripe's priorities are unless you have read them yourself; the pack has no research to give you | CO because it tests whether you think at the company's altitude; `[generic]` because the pack's company research was not available |

### B. Skeptic (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | The highest-ROI prep in this pack. Pick one real gap from your own honest read of the role, name it plainly, then give a concrete ramp plan: who you would talk to, what you would read, what you would do in the first month. Hold the answer through two follow-ups. Do not pick a fake weakness | Every final asks some form of this; it is the highest-ROI rehearsal because a rehearsed, non-defensive answer changes the interview, and the pack cannot yet see your real gap |
| B2 | "Why this role, and why now?" | EXP | [generic] | Give your own reasons, in your own words, and keep them consistent with what you told the recruiter. Two honest reasons beat five | Motivation consistency; EXP because it tests your story's coherence |
| B3 | "Why Stripe, over other companies you could join?" | CO | [generic] | Your own reasons, grounded in what you have actually read or used. Do not recite a brand line; if the reason is thin, say what you are still learning | CO because it tests homework depth; the pack cannot supply Stripe's specifics without research |
| B4 | "Tell me about a time you stepped into work that was outside your remit. What did you do and what did you leave to others?" | EXP | [generic] | Selection scaffold: pick one instance with a named stake, what you did and what you handed off. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it | F6's requirement, asked as an open prompt so it presupposes nothing |

### C. Values/Behavioral (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not fold, and a relationship that was intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it | F4's requirement; a standard values stem |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a case where the two pulled apart, say which you chose and why, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it | F3's requirement; VAL because it tests behavior, not slogans |
| C3 | "Tell me about a process you changed that stuck. How do you know it stuck?" | EXP | [generic] | Selection scaffold: pick one change, separate what you did from what the team did, and say how you checked it was still in use. If you only supported someone else's change, say so plainly | F5's requirement; the follow-up tests whether you know your own evidence |

### D. Peer Evaluator (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where is the seam between us, and what happens when we disagree?" | JD | [generic] | Propose principles for the seam (who owns decisions, how conflicts escalate, what each team can count on) instead of claiming to know the seam. Ask what is currently ambiguous | F6's requirement; tests turf awareness |
| D2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Say how you actually treat credit, in your own words. If you have a real example, tell it with your own part named; if not, say how you would handle it | Credit-sharing probe, a standard peer stem |
| D3 | "What could a new person do in their first month that would genuinely help my team?" | JD | [generic] | Offer one or two things you would ask about and one thing you would not touch yet. Do not promise outcomes you cannot see | Reciprocity: what you bring the peer's team, not only what you need |

### E. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Choose a metric you have worked with and walk me through how it was counted." | EXP | [generic] | Answer slot: say how it was counted and what it is sensitive to, in your own words; if you do not know how it was counted, say so plainly and say how you would find out. Name the assumption you would defend least before they do | F2's requirement; a defend-the-number rehearsal without a number to defend yet |
| E2 | "Pick a result you have been part of. How much of it was actually you?" | EXP | [generic] | State your own part precisely and the shared part as shared. If your part was small, say so plainly; narrow and true holds up under a second question | Attribution honesty; EXP because it tests what was yours |
| E3 | "What would you measure to know whether a new internal process is working?" | CASE | [generic] | Name the outcome you care about, one lead indicator, one lagging one, and one way the metric could mislead you | F2's requirement as a live problem, presupposing nothing |

### F. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc in your own words: where you started, what pulled you toward operations, why this role is the next step. Every beat must be something you can discuss for two more minutes | Opens most sessions and is scored; EXP because it sets up every later probe |
| F2 | "What are you actually playing with these days in your own work or learning that relates to this job?" | JD | [generic] | Name something real that you do, however small. If nothing comes to mind, say so plainly and name what you are curious about | Casual questions about live topics are still scored |

### G. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, restate, then two points about what you would do for the team, not comparisons with people you do not know. Hold the position through two follow-ups; concede specific uncertainty, not the core claim | Tests composure; the stem is a standard one |
| G2 | "Convince me an operations role matters more than another product engineer." | JD | [generic] | Take the premise seriously, give one reason that is true in your own view, and concede what is right in the challenge. Do not fold, and do not get defensive | Composure under a motive challenge |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 rollouts across teams | A1, A3 |
| F2 metrics | A2, E1, E3 |
| F3 feedback into priorities | C2 |
| F4 senior communication | C1, G1 |
| F5 process and tooling | C3 |
| F6 ambiguity and influence | A3, B4, D1 |
| Company knowledge | A4, B3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would make someone in this role clearly successful at the end of year one?" | Shows you think in outcomes and gives you the real bar |
| R2 | "Where does product operations sit relative to the teams it supports, and where does that boundary get tested?" | Shows seam awareness and surfaces how decisions really get made |
| R3 | "What is the hardest thing about this role that doesn't show up in the job description?" | Invites candor and gives you something real to react to |
| R4 | "How do you decide what product operations works on versus what a team should handle itself?" | Shows you think about prioritization and scope |
| R5 | "What has changed in how the team works in the last six months?" | Gives you current context the pack could not research |
| R6 | "What could I do in my first month that would help most?" | A reciprocity question that works with a peer or a manager |

## Prohibited claims

Nothing is listed. Your message gave no sentence about your past, so there is nothing for the pack to stretch, and a requirement your material does not speak to is an answer slot, not a prohibited claim. Once you add a CV, the pack will list any wording that would inflate what it says.

## Sources

Provided: your message (company, role, final round). No job description, CV, interviewer information or pasted research.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Search "Stripe operating principles values" was refused. It would have fed a values cheat sheet; none is built, and no Stripe value is named in this pack |
| 2. Stripe interview process, product operations | unavailable | Search "Stripe interview process product operations manager" was refused. It would have fixed the loop and persona weights; they rest on a generic pattern instead |
| 3. Stripe strategy and recent news | unavailable | Search "Stripe strategy news 2026" was refused. It would have fed company questions; A4 and B3 are generic as a result |
| 4. Interviewer name | n/a | No name was given, so there was no query to form |
| 5. Representative Product Operations Manager JD | unavailable | Search "Stripe Product Operations Manager job description" was refused. It would have grounded the fit snapshot's requirements; they are role-family prose instead |

## Upgrade menu

- The job description text → the six role-family rows in the fit snapshot become quoted requirements, and the JD-tagged questions become `[grounded]`
- Your CV or a short list of your relevant experience → the worksheet becomes a real fit snapshot with your own sentences, the selection scaffolds become story maps, and the prohibited list gets real entries
- Who you are meeting and how many sessions the final has, or the recruiter's prep email → persona weights change from a flat blend to a reasoned one, and any pre-declared deliverable gets its own build section
- Interviewer names → an interviewer read and a reverse question tied to their path
- Permission to search the web → Stripe's published values, interview structure and recent strategy come from sources instead of staying `[generic]`; a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) would add a company brief
- A `tuesday-dossier.md`, if you have one → a verified evidence list and any claims to avoid would replace the pack's local guesses
