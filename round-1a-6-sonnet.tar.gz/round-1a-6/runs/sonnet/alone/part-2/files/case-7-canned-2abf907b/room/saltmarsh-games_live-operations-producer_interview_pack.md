# Interview pack: Live Operations Producer, Saltmarsh Games

- Candidate: Femi
- Interviewer: Tobias Wrenfield, Head of Live Operations
- Relationship and round: hiring manager, assumed. Saltmarsh's careers page describes one 60-minute interview with the hiring manager, and your note names Tobias as your interviewer. The pack has not confirmed that he is the hiring manager.
- Version: first pass

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Every guidance cell is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows Saltmarsh's published values |
| EXP | Whether the claims about your work survive scrutiny |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you can think at Saltmarsh's altitude: its strategy and recent moves |
| CASE | Structure and reasoning on a live problem from the role |

An answer slot is an instruction for the interview, not a question for you now. Fill the first branch only if it is true for you, and use the second branch without apology if it is not.

## Prep triage

Built for a Friday interview, roughly a day away. Do these in order and out loud.

1. C1 and C2, three times each. These are the highest-ROI rehearsals in the pack: the stated limits are where this interview will press hardest.
2. A1 and A2 against a timer, then A3. The tabletop is the first half of the hour.
3. B1 to B3: decide which story, if any, you will use for each value, or that you will use the honest branch.
4. D1: answer its four slots for yourself before Friday, even if one answer is "I don't know how it was counted".
5. Pick two reverse questions, R1 and R2 first.

Everything else is insurance.

## Fit snapshot

No requirement in the JD is a gate: the 3+ years line is an experience requirement, so it is graded like any other row. F9 is not a JD line. It comes from Saltmarsh's own announcement, and it is in the table because your message states a limit against it.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message | medium | [grounded] | discovery | Your material gives four years as an associate producer and does not say whether the studio's main title was run as a live service. Answer slot: the JD asks for years of producing live-service games, so expect a probe on what that title's updates looked like. If it was run as a live service, say how a week of it ran, in your own words; if it was not, or some of the four years were not on live updates, say so plainly and stay with the four years and the calendar you ran |
| F2 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says one title's weekly content drops, and the JD says live events across two titles. Words: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: expect a probe on both differences. If any of your drops were timed events, say how you planned them; if you ever planned for anything beyond the main title, say how; if neither, say so plainly and stay with the calendar you ran |
| F3 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap, but a message line with nothing inspected behind it, so expect a probe. Lead with the quote's own terms: weekly, the main title, the last two years |
| F4 | "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team, and never worked on a game with in-app purchases" — your message | none | [grounded] | discovery | Your material does not show whether you coordinated design, art, engineering or community on a drop, and it states you have never led a team; the JD's line is coordination, not leadership. Words for the stated part: "I've never led a team." Answer slot: if you coordinated any of those groups on a drop, say which and how, in your own words; if you did not, or it was not yours, say so plainly and stay with the calendar you ran |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your material says you presented the monthly retention numbers, not that a review or its figures were yours. Words: "Presented the monthly retention numbers to the studio head." Answer slot: expect a probe on what happened to the numbers after you presented them. If they led to a review or a change, say what and which part was yours; if they were reported and nothing followed, or it was not yours to decide, say so plainly and stay with the monthly presentation |
| F6 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | transferability | Your material says you wrote the checklist and QA still uses it; it does not say what happened to it afterwards. Words: "Wrote the release checklist our QA team still uses." Answer slot: expect a probe on how the checklist was kept current with QA across releases. If you revised it or ran it with them, say how; if you wrote it and it has not changed, or others kept it, say so plainly and stay with the checklist QA still uses |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | No gap on the line as written, but nothing inspected sits behind it, so expect a probe on how the numbers were counted (D1). The pack supplies no definition of retention and no figure |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | low | [grounded] | discovery | Your material has a written checklist and nothing that shows how clear the writing is. Answer slot: if you have a written piece that someone relied on, such as a release note or a post-event summary, name it; if you have none to name, say so plainly and say how you would write one |
| F9 | "moves Tidepool Tactics and Lantern Row to a season-pass model" — Saltmarsh news page, Project Larkspur | "Never led a team, and never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A limit you stated, and wording cannot close it. Words: "I've never worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Never a claim to purchase, monetisation or season-pass work, and nothing added to make the limit feel smaller |

## Persona table

The loop read comes from Saltmarsh's careers page (Sources, search 2): one 60-minute interview with the hiring manager, a live-incident tabletop on a simulated outage during a live event and then a values conversation, with no take-home. That page establishes a single session, so the weights are built on it rather than on an archetype. A Peer Evaluator bank is not included: the page names one interview with the hiring manager, and no peer is named.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | The tabletop: a simulated outage during a live event, then planning questions on the shared calendar | High. The careers page names the tabletop as the first part of the hour, and hiring-manager rounds tilt to case questions | Clarify, then objective, approach, metrics, risks; think aloud; challenge one premise respectfully per case |
| B. Values / Behavioral | The second half: Saltmarsh's three published values, asked as "tell me about a time" | High. The careers page names a values conversation, and the values page names three values | Where one of your quoted sentences carries a story, use it at its own scope; where none does, use the selection scaffold and its honest branch |
| C. Skeptic | Quiet, persistent probing of the stated limits and the season-pass move | High. Hiring-manager prior, and F4 and F9 are limits you stated; the Larkspur page announces the season-pass model | Rehearse C1 until it is boring: plain acknowledgment, a plan stated as a plan, then hold what your quotes carry |
| D. Data-Driven Prober | Retention numbers, the post-event review, "what shipped versus what was written" | Medium. The JD names KPIs and retention, and the interviewer's public path starts in QA (section 7) | Know what you can and cannot say about how the numbers were counted, and say plainly when you do not know |
| E. Pressure | Time-boxed answers inside the tabletop; "why you" in sixty seconds | Medium-low. A simulated outage suggests time pressure inside the case; the page does not describe an interrupting style | Pause, restate, hold the position through two follow-ups, concede specifically |
| F. Conversational | The opener and the motivation question | Medium-low. Most interviews open this way; the page does not describe the opener | A 90-second arc built only from your quoted sentences |

## Reading the interviewer

Public professional footprint only. Both rows come from search-result snippets; the talk itself was not read.

| Public signal | Source | What it means for your answers | Provenance |
|---|---|---|---|
| Head of Live Operations at Saltmarsh Games, previously a QA lead at a console studio | GDC 2026 talk page (Sources, search 4) | Expect release-and-checklist probing. Shared professional ground: his QA background and your sentence "Wrote the release checklist our QA team still uses" (F6). Use it as a topic, not as a claim about how well you know QA | [grounded] |
| GDC 2026 talk "Patch Notes Are a Promise", whose stated argument is that a live team is judged by how often its patch notes describe what actually shipped | GDC 2026 talk page (Sources, search 4) | Describe what shipped, and say plainly where something did not. His argument sits next to Saltmarsh's value "Ship the Patch Not the Promise", so expect precision about announced versus built (A2, B2, D3) | [grounded] |

## Question banks

### A. Case / Strategist (tabletop)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It's Saturday evening, an event is live, and players say their rewards aren't arriving. You're the producer on call. What are your first fifteen minutes?" | CASE | [generic] | Think aloud in this order. Clarify: who is affected (everyone, one platform, one group of players), whether anything players paid for is involved, and what engineering can already see. Objective: stop further harm to players, then restore. Approach: who you pull in and what you ask each for, with engineering to diagnose, community to tell players and QA to check the fix. Metrics and risk: how you will know it is fixed, and what you will not promise yet. Challenge one premise aloud, for example whether pausing the event is the first move. The scenario needs no claim about your past, so the guidance makes none | The careers page names the tabletop as the first part of the hour. CASE because it scores structure under time pressure; `[generic]` because the actual scenario is unknown, and a recruiter note would sharpen it |
| A2 | "Engineering says the fix is two hours out, maybe more. Community wants to post an ETA now. What goes in the first player-facing message?" | CASE | [grounded] | Say what is confirmed: what is wrong, who is affected, what players should and should not do. Say when the next update will come. Leave out a fix time that is not yet built. Saltmarsh's own wording of the value is "we announce what is built, not what is hoped", so you may name it if it comes naturally. Say the message aloud in two or three sentences and say who signs it off. The question needs no claim about your past, so the guidance makes none | The value "Ship the Patch Not the Promise" and the interviewer's public talk both centre on announced versus shipped (section 7). CASE with a written-communication edge (F8, F4) |
| A3 | "Before you give an event launch the green light, what is on your go/no-go checklist, and who has to say yes?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | Story-mapped on F6: open with the checklist in the quote's own terms, which are that you wrote it and QA still uses it, and tell it in your own words. Then answer the live scenario: what must be true before go, such as content in the build, QA sign-off, player-facing copy ready, a pause plan and who is on call. Those items answer this scenario and are not a description of your checklist. Answer slot: expect a probe on what happened to the checklist after you wrote it. If you revised it or ran it with QA, say how; if you wrote it and it has not changed, or others kept it, say so plainly and stay with the checklist QA still uses | F6 is the evidence for the release-checklist requirement and the likeliest place to be probed. JD because it scores that stated requirement; CASE delivery |
| A4 | "From February our titles share one events calendar and the per-title event teams go away. Plan the first month: what do you need to know before you plan anything?" | CO | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Clarify first, and the Larkspur news line gives you little to clarify against: it names a season-pass model, one shared calendar and a single live-ops group, and says nothing about structure, so ask. Which titles and which dates are fixed by the pass, which events must not collide, who owns each slot, and what each team's capacity is. Then objective, approach, metrics and risks, and challenge one premise aloud, such as shared versus staggered events. If you reach for your own experience, stay with the quote: "I ran the weekly content-drop calendar for our main title for the last two years" | Grounded in the company's September 2026 announcement (Sources, search 3). CO because it tests altitude on the announced strategy; F2 and F3 are the evidence it draws on, and the JD's two-title line and this announcement may or may not describe the same pair, so do not assume they do |
| A5 | "The event is over. What goes in the post-event review, and what are the first three numbers you look at?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Structure: what was planned against what shipped, the player impact, and what changes next time. Pick three numbers you would stand behind, say why, and name which of the three you trust least. The pack names no metrics for you. If retention is among them, reach for your own experience only in the quote's terms: "Presented the monthly retention numbers to the studio head." Answer slot: expect a probe on what happened after you presented. If a number led to a decision, say which and what part was yours; if the numbers were reported and nothing followed, or the decision was not yours, say so plainly | F5 and F7 are the evidence for the review and retention requirements. JD because it scores them; the weakest-assumption move is built in |

### B. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Players Before Plans: tell me about a time what the calendar called for and what players needed pulled apart. What did you do?" | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | The quote carries the calendar and no conflict, so it supplies no story beat here. Selection scaffold: pick a drop where the plan and what players needed diverged; it needs a named decision, what following players cost the plan, what you told players or colleagues, and what the relationships looked like afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is the calendar you ran in the quote's terms, or how you would handle it using A1's order | The value is published on the values page (Sources, search 1); the careers page names a values conversation. VAL because it scores one named value, and F3 is the closest row but holds no conflict |
| B2 | "Ship the Patch Not the Promise: tell me about a time something you said would ship did not ship as described. What did you say, and when?" | VAL | [grounded] | Selection scaffold: pick a time with a named announcement, the moment you knew it would not hold, who you told and in what order, and how the next message differed from the first. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it using A2's order. The pack does not supply an incident | The value is published (Sources, search 1) and the interviewer's public talk centres on the same idea (section 7). VAL; no row of the fit snapshot carries an announcement that failed, so this is a scaffold |
| B3 | "Leave the Build Greener: tell me about a time you left a process or a checklist better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Story-mapped on F6: the beats the quote states are that you wrote the checklist and that QA still uses it. Tell those in your own words and let the interviewer draw the inference. Answer slot: if there was an earlier process it replaced, or you changed the checklist after a release, say what and why; if you wrote it from nothing, or it has not changed, say so plainly and stay with the checklist QA still uses | The value is published (Sources, search 1). F6 is the only row that touches it; VAL because the question scores a named value |
| B4 | "Which of our three values would be hardest for you to live by?" | VAL | [grounded] | Pick one you can answer honestly, say what makes it hard for you in practice, and say what you would do about it. Do not choose a value you think sounds safe. The question needs no claim about your past, so the guidance makes none | Asked by values interviewers who want self-awareness; VAL because it scores honest self-assessment against the published values (Sources, search 1) |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Saltmarsh is moving to a season-pass model, and you haven't worked on a game with in-app purchases. How do you get up to speed?" | CO | [grounded] "Never led a team, and never worked on a game with in-app purchases"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Presented the monthly retention numbers to the studio head" | The highest-ROI prep in this pack. Hold-then-concede. Concede first, in your words: "I've never worked on a game with in-app purchases." Then a plan, said as a plan: who you would sit with in the first weeks, which past post-event reviews you would read, and which KPIs you would ask how they change under a season pass. Then hold only what the quotes carry: the weekly calendar and the monthly retention presentation, in their own terms. Follow-up one is likely to be which retention numbers move under a pass: say you do not know how they are counted here, and what you would ask first. Follow-up two is likely to be the risk of hiring you: name the limit specifically and the ramp, and offer no adjacent claim your material does not carry | F9 is the stated limit and the announced season-pass move makes it the most predictable objection to this candidate. CO because the premise is Saltmarsh's own announced direction; JD content, Skeptic delivery |
| C2 | "You haven't led a team, and this job coordinates design, art, engineering and community, none of whom report to you. How does that work?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases"; "I ran the weekly content-drop calendar for our main title for the last two years" | Plain acknowledgment first: "I've never led a team." The JD's line is coordination, so you do not need to claim leadership. Answer slot: if you coordinated any of those groups on a drop, say which and how, in your own words; if you did not, or it was not yours, say so plainly and stay with the calendar you ran. Then your approach, said as an approach: what you would ask each group it needs from you before it says yes | F4 is a discovery row with a stated negative beside it, so this objection arrives in some form. JD because it scores the coordination requirement; the premise is your stated limit, not an assumption |
| C3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases" | Name one and say why. Your material states in-app purchases as a limit, so answering with that is honest; do not invent a smaller weakness to seem modest. If C1 already covered it, give the next one from your own honest list. Then say what you would do in the first weeks about it | A stock Skeptic stem. JD because it scores self-assessment against the listed job; F9 is the stated limit |
| C4 | "You ran one title's calendar. We need two titles, and from February one shared calendar. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Hold the quote's scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if you ever planned for more than the main title, say how; if not, say so plainly and stay with the one calendar. Then what you would want to know first, in A4's order. Do not describe a multi-title process you have not run | F2 is the evidence and the likeliest place to be probed on scale. JD because it scores the two-title line; Skeptic because it presses the seam |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You presented the monthly retention numbers to the studio head. Walk me through how those numbers were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Four slots, each in your own words. How the numbers were counted: say what counted as a retained player at your studio, or say plainly that you do not know. What they were most sensitive to. The assumption behind them you would defend least: name it before he does. Which part was yours: the quote says you presented them. The pack supplies no definition, no baseline and no method | F5 and F7 are the evidence. EXP because it tests whether the claim survives; the weakest-assumption move is built in |
| D2 | "Did those numbers ever change what went into the calendar?" | JD | [grounded] "Presented the monthly retention numbers to the studio head"; "I ran the weekly content-drop calendar for our main title for the last two years" | Answer slot: if a number changed what went into the calendar, say which decision, what part was yours, and what the number showed, in your own words; if they did not, or the decision was not yours, or the numbers were only reported, say so plainly and stay with presenting them each month and running the calendar | The JD asks for the post-event review and its KPIs, so this probe follows D1 (F5). JD because it scores that requirement; EXP delivery |
| D3 | "Write me the player-facing patch note for an event that shipped with one reward missing." | JD | [generic] | Say what shipped, say what did not, say what players can expect, and say when the next update comes. Leave out any date that is not built. Say the three or four sentences aloud, then say what you would check before it goes out. The question needs no claim about your past, so the guidance makes none | F8 is the thin row for the written-communication requirement, and the interviewer's public talk is about patch notes (section 7). JD because it scores that requirement; CASE delivery |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a candidate who has already run events on a game with in-app purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Never led a team, and never worked on a game with in-app purchases"; "Presented the monthly retention numbers to the studio head" | Pause and restate the question. Hold what the quotes carry: the weekly calendar for the main title over two years, and the monthly retention presentation. Concede the limit specifically: "I've never worked on a game with in-app purchases." Do not claim to beat them on it. Hold through two follow-ups by returning to the quoted calendar, never by adding to it | F9 and F2 are the evidence. JD because it scores fit for the listed job; Pressure because the format is time-boxed |
| E2 | "That retention presentation: how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Hold the quote: you presented the numbers. Answer slot: who produced them; if you built any of the analysis, say which part; if analytics produced the numbers and you presented them, say so plainly. Concede only what is true, specifically, and do not fold on what the quote carries | F5 is the evidence and attribution is the standard pressure probe. EXP because it tests attribution honesty |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through your journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc in four beats, each a quoted sentence in your own words: four years as an associate producer at a puzzle-game studio; the weekly content-drop calendar for the main title for the last two years; the release checklist QA still uses; the monthly retention numbers presented to the studio head. Then one sentence of your own on why this role, which the pack cannot write for you | F1, F2, F5 and F6 are the evidence. EXP because it sets the story the rest of the hour probes |
| F2 | "Why live ops, why Saltmarsh, why now?" | VAL | [grounded] | Give your own reason in your own words. Tie it to one thing you have read on Saltmarsh's own pages: the values, or the Larkspur announcement. The pack does not know your motive, so it supplies none | Motivation consistency is scored in every hiring-manager round. VAL because it is the one place the published values and the announced move are both fair game (Sources, searches 1 and 3) |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "3+ years producing live-service games or apps" | E1, F1 |
| "running a content calendar" | A4, C4, F1 |
| "comfortable with player-retention metrics" | A5, D1, D2 |
| "clear written communication" | A2, D3 |
| "Plan and run the live-events calendar for two of our mobile titles" | A4, C4 |
| "coordinate design, art, engineering and community teams on each update" | A1, A2, C2 |
| "own the post-event review and the KPIs it reports" | A5, D1, D2 |
| "manage the release checklist with QA" | A3, B3 |

## Values cheat sheet

The values and their wording come from Saltmarsh's values page (Sources, search 1); the working meanings are paraphrased. A values round is detected because the careers page names a values conversation as part of the single interview.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the schedule and the players disagree, the players' needs win | F3 carries the calendar, not a conflict: "I ran the weekly content-drop calendar for our main title for the last two years". Use B1's selection scaffold and its honest branch |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | No row carries an announcement that failed. Use B2's selection scaffold and its honest branch |
| Leave the Build Greener | Each release leaves the build and the checklist in better shape than it found them | F6: "Wrote the release checklist our QA team still uses". The beats are that you wrote it and QA still uses it; B3 holds the answer slot |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You came to live ops from QA, and your GDC talk argues that patch notes are a promise. On a release here, who checks what shipped against what was written?" | Tied to his own path and talk (section 7). It invites his story, and F6 gives you a real reason to care about the answer |
| R2 | "Project Larkspur moves to one shared calendar and a single live-ops group. Where does this role sit in that, and what changes for it after February?" | Shows you read the announcement, and tests whether the JD's two-title role survives the reorganisation (A4, C4) |
| R3 | "Which KPIs does the post-event review report today, and how do they change under the season-pass model?" | Turns the stated limit in F9 into a learning question, and shows you already know where it sits |
| R4 | "When an event goes wrong here, what does the review look like, and who reads it?" | Shows you think about the review as a working document, and lets you hear how the Outage Hour maps to real practice |
| R5 | "What would make you say, ninety days in, that this hire is going well?" | Concrete success criteria, which also tell you how to prioritise the coordination work (F4) |
| R6 | "What do you want a new producer to ask QA in the first week?" | Draws on your checklist (F6) and tells you what he thinks the seam between producer and QA is |

## Prohibited claims

Built before the banks. A claim listed here is not coached in any cell.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live events across two titles | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: your material says one title's weekly content drops |
| Owned the post-event review and its KPIs | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation: your material says you presented the numbers |
| Produced or analysed the retention numbers | Inflated form of F5 and F7 | The quote "Presented the monthly retention numbers to the studio head". D1 and E2 stay inside presenting |
| Managed the release checklist with QA | Inflated form of F6 | F6's quote at its own scope. The limit is the pack's observation: your material says you wrote the checklist and QA still uses it |
| Has led a team, or managed the groups behind an update | Negative the candidate stated, F4 | The plain acknowledgment F4 gives: "I've never led a team." |
| Has worked on in-app purchases, monetisation or a season pass | Negative the candidate stated, F9 | The plain acknowledgment F9 gives: "I've never worked on a game with in-app purchases." |

## Sources

Provided documents: the JD and your background, both pasted in your message. No dossier was present.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | The values cheat sheet and B1 to B4: three values by name, read from the values page |
| 2. Saltmarsh Games interview process, live ops producer | yes | Loop structure: one 60-minute interview, a tabletop and then a values conversation; persona weights follow it |
| 3. Saltmarsh Games strategy and recent news | yes | A4, C1, R2 and R3, from the Larkspur announcement; read from the search snippet only, the page was not fetched |
| 4. Tobias Wrenfield, Saltmarsh Games | yes | Section 7 and R1; read from the search snippet only, the talk was not read |
| 5. Representative Live Operations Producer JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions |

Searches and what came back:

1. Query `Saltmarsh Games values` returned https://saltmarshgames.com/values, which was fetched.
2. Query `Saltmarsh Games interview process live operations producer` returned https://saltmarshgames.com/careers/interviewing, which was fetched. The page shows no date.
3. Query `Saltmarsh Games mobile studio news strategy` returned https://saltmarshgames.com/news/project-larkspur, dated September 2026 in its snippet.
4. Query `Tobias Wrenfield Saltmarsh Games` returned https://talks.gdconf.example/2026/patch-notes-are-a-promise.

## Upgrade menu

- Confirmation that Tobias is the hiring manager who runs the Outage Hour: persona weights stop resting on the careers page's description alone
- Anything the recruiter has said about the tabletop, such as the game, the event type or what is scored: A1 to A3 become `[grounded]` and are retuned
- Your answers to the slots in F1, F2, F4, F5 and F6: those rows are rewritten from your own sentences, and the bank cells that draw on them follow
- The checklist itself, a calendar export or the retention deck, or your own description of any of them: the medium-confidence rows F2, F3, F5, F6 and F7 can rise
- A short written sample, such as a release note or post-event summary you wrote: F8 moves off `low`
- A deeper research pass, up to 6 more searches and 2 more fetches and several more minutes: a grounding brief on Larkspur and a read of the talk itself instead of its snippet
- A `tuesday-dossier.md` from a job-underwriter run: verified evidence and a prohibited-claims list from it, which would sharpen C1 and C2. It is never a prerequisite for this pack
