# Interview pack — Engineering Manager, Larkfield Systems (loop mode, three rounds)

Candidate: Yusuf. Role as you described it: "Engineering Manager — Larkfield Systems (industrial IoT, ~600 people). Lead two squads building device-management services; own delivery, hiring and growth for 11 engineers; partner with hardware and product on roadmap."

| Round | When | Who | Relationship |
|---|---|---|---|
| 1 | Tuesday, 45 min | Director of Engineering | Hiring manager, your would-be boss |
| 2 | The Thursday after, 60 min | Two staff engineers and a product manager | Panel |
| 3 | The following Monday, 30 min | VP Engineering | Skip-level; recruiter's description: "values and leadership philosophy" |

No interviewer names were given, so there is no interviewer read. Persona weights rest on relationship priors plus the loop as you described it.

## How to use this pack

- Personas describe how a question is asked; types describe what is being scored. Every question carries one of five type tags: VAL (behavioral and values alignment), EXP (work-experience deep-dive), JD (role and job-description driven), CO (company and strategy knowledge), CASE (hypothetical or live problem).
- Provenance labels: `[grounded]` traces to something you gave me, `[inferred]` is derived from an adjacent source with the derivation named, `[generic]` is a role-family pattern with no claim about Larkfield or about you.
- An answer slot is an instruction for the interview, not a question for you now. It names what an interviewer is likely to probe, then gives two honest branches: say how, in your own words, or say plainly that the step did not exist or was not yours.
- Guidance is scaffolding, not a script. It quotes only your own sentences, at their own scope. Say it in your words, and only what you did.
- Question IDs are round, then persona letter, then number: T for Tuesday, P for the panel, V for the VP.

## Prep triage (two weeks, three rounds)

1. Before Tuesday: rehearse T-A1 aloud, with a friend pushing the three follow-ups, until it is boring. It is the highest-ROI prep in this pack, because the hardware-roadmap gap you named is the one every round can reach (F6).
2. Before Tuesday: one sitting on your 60% sentence and your 40-interviews sentence, covering T-C1, T-C2, P-B1 and V-C2. Write down, in your own words, how each number was counted and which part was yours.
3. Before Tuesday: T-A2 and T-A3, and the ninety-second arc in T-D1.
4. Between Tuesday and Thursday: P-A1, P-B3 and P-C1. Tell me what the Director asked and how it landed, and I will re-weight the panel bank.
5. Before Monday: V-A1, V-A4, V-C1 and V-C2. Thirty minutes holds only a handful of questions, so rehearse these four deeply rather than all nine.
6. Everything else is insurance.

## The fit snapshot (shared across all three rounds)

The role summary you pasted names no location, pay, schedule, travel or credential term, so no row is a gate. Evidence cells hold only your own sentences from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role summary in your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | medium | [grounded] | transferability | Your material says a team lead of six, not two squads, and the words stay there: "Three of my nine years in engineering were as a team lead of six." Answer slot: the JD's two-squads line makes a probe on the step up likely. If any of your lead work spanned more than one team, say how, in your own words; if it did not, say so plainly and stay with the team of six |
| F2 | "building device-management services" — role summary in your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | low | [grounded] | discovery | Your material says engineering at a payments company and shows nothing either way about systems that manage or talk to devices. Answer slot: if any of your work touched such systems, say what, in your own words; if none did, say so plainly and say what you would read or ask first |
| F3 | "own delivery" — role summary in your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | Your material says a reliability quarter pushed through, not delivery across quarters, and the words stay at that scope: "I pushed a reliability quarter through against roadmap pressure." The figure raises four slots, each in your own words: how the 60% was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. "I don't know how it was counted" is an honest branch. Say "after", as your sentence does, not "because" |
| F4 | "hiring" — role summary in your message | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | none | No gap, but a one-line claim with nothing inspected behind it, so expect a probe on it. Lead with the loop in the quote's own terms: you run it, for backend roles. The figure raises the same four slots: what the 40 counted, how, and which part was yours, given that the sentence does not say whether the 40 were interviews you conducted yourself |
| F5 | "growth for 11 engineers" — role summary in your message | none given | none | [grounded] | discovery | Your material is silent on developing engineers, and eleven is wider than the team of six your material mentions. Answer slot: if developing people was part of your lead role, say what, in your own words; if it was not, say so plainly and say how you would approach it |
| F6 | "partner with hardware and product on roadmap" (the hardware half) — role summary in your message | "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. Never a claim to hardware exposure, and nothing added to make the gap feel smaller |
| F7 | "partner with hardware and product on roadmap" (the product half) — role summary in your message | "I pushed a reliability quarter through against roadmap pressure" — your message | low | [grounded] | discovery | Your sentence says roadmap pressure and shows nothing either way about who it came from. Answer slot: if product people were part of that pressure, say how you worked it through, in your own words; if they were not, say so plainly and stay with your sentence |

Requirement coverage, by question ID:

| Requirement or headline figure | Covered by |
|---|---|
| "Lead two squads building device-management services" | T-A2, T-B2, P-B3, P-C1 |
| "own delivery" | T-B1, T-B3, P-C2 |
| "hiring" | T-C2 |
| "growth for 11 engineers" | T-D2, V-A3 |
| "partner with hardware and product on roadmap" | T-A1, T-B1, P-A1, P-C2, P-D1, V-B2 |
| Recruiter's "values and leadership philosophy" (round 3) | V-A1, V-A2, V-A4 |
| The 60% figure | T-C1, P-B1, V-C2 |
| The "about 40 interviews" figure | T-C2 |
| A CO question grounded in Larkfield's current strategy | none, because search was not granted: the CO question V-B1 is `[generic]` |

---

# Round 1 — Tuesday, 45 min, Director of Engineering (hiring manager)

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the hardware gap, the step from six to eleven, and why now | High: a hiring manager derisks gaps, and you named two yourself (F6, and the scale step in F1) | Rehearse T-A1 until boring; bridge only from your own sentences; concede the limit before it is asked for |
| Case / Strategist | Live problems from the actual roadmap: hardware slips, inherited squads, on-call load | High: the hiring-manager prior says expect live problems on their real roadmap | Clarify, then objective, options, decision, risks; think aloud; challenge one premise respectfully |
| Data-Driven Prober | Goes two levels into the 60% and the 40 | Medium: two headline figures in your material, and a 45-minute round has room for follow-ups | Know what you can and cannot say about each count; say plainly when you do not know |
| Conversational | Opens with "walk me through the journey" | Medium: a 45-minute first conversation with your future manager usually starts here, and it is still scored | A ninety-second arc built only from your own sentence |
| Pressure | Time-boxes and interrupts | Low: neither the relationship prior nor your description of the round points to it | Pause, restate, hold a challenged position through two follow-ups |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| T-A1 | "Part of this job is partnering with hardware on the roadmap. What have you done that looks like that?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" and "I pushed a reliability quarter through against roadmap pressure" | The deepest rehearsal in the pack. Hold-then-concede. Open with your own words: "I've never owned a hardware-adjacent roadmap." Then a plan, said as a plan: who you would sit down with first, what you would want to learn about how hardware's plans affect the squads' roadmap, and what your first month would look like, in your own words. Follow-up 1, "so why you?": return to what your material carries and no more, your reliability-quarter sentence at its scope. Answer slot: if any of that quarter involved a hardware team, say how; if none did, say so plainly and stay with the plan. Follow-up 2, "hardware doesn't move like software": do not argue; ask what the constraints are here and concede you do not know them yet. Follow-up 3, "that's a real risk for me": concede specifically, "Yes, it is the biggest gap between this role and my experience; here is how and by when I would close it." Never claim hardware exposure you have not stated | F6 is the stated gap and the role's headline partnership, so it arrives in some form in every round; JD because it scores a stated requirement. F7 supplies the only adjacent sentence, and its limit is named before the interviewer asks |
| T-A2 | "You'd have eleven engineers across two squads. What changes for you from leading a team of six?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Start at the sentence's scope: "Three of my nine years in engineering were as a team lead of six." Answer slot: say in your own words what you would do differently at the larger scale, as a plan. If any of your lead work spanned more than one team, say how; if it did not, say so plainly and stay with the team of six. Concede the larger scope openly rather than claiming it is the same job | F1 is the scale step the Director is pricing; JD because it scores the stated two-squads, eleven-engineers requirement |
| T-A3 | "You're at a payments company today. Why industrial IoT, and why now?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Answer slot: your actual reason, in your own words; the pack does not supply one. Criteria for a strong answer: it names what pulls you toward this role (two squads, device-management services, hardware partnership) and not only what pushes you from where you are. If part of the honest reason is leaving, say it plainly and put the pull next to it | F2 is the domain jump; EXP because it tests whether your motivation survives cross-examination |
| T-B1 | "Hardware tells you a device milestone will slip by a quarter. Product has a customer date committed. You have two squads. Walk me through your first week." | CASE | [generic] | A live problem, so the guidance makes no claim about your past. Clarify first: what exactly slips, what depends on it, what the customer date actually commits. Then objective, options (re-sequence, split scope, renegotiate), who needs to hear what and when, and the risk you are accepting. Challenge one premise out loud: how movable is the date? | Built on the hardware-and-product seam in F6 and F7; `[generic]` because no Larkfield research ran; CASE because it is a live problem |
| T-B2 | "You inherit two squads in week one. How do you spend your first thirty days?" | CASE | [generic] | A plan, never a past. Clarify what you need to see first, then sequence: listening to each engineer, the delivery picture, the hiring pipeline, relationships with hardware and product. Say what you would deliberately not change yet and how you would know it was working | F1, F3 and F5 meet in the first-thirty-days question; CASE because the answer is a structure, not a story |
| T-B3 | "One squad's on-call is brutal and the roadmap is full. What do you do?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Structure it as a live problem first: what the load is made of, who is paying for it, what in the roadmap is negotiable, your options, what you would ask for and from whom. Only if you can then back it, close with your own sentence at its scope. Prepare T-C1 before using the figure, since the figure invites that follow-up | F3 is where your material meets the question most directly; CASE because it is a live problem, with an EXP follow-up one sentence away |
| T-C1 | "You said on-call burden dropped 60% after you pushed a reliability quarter through. How was that number counted?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Four slots, each in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, said before they ask, and which part was yours. If you do not know how it was counted, say so plainly. Keep your sentence's own form, "after", and say "because" only if you can back it. Describe no counting method you did not use | F3's headline figure, probed to its assumptions; EXP because it tests attribution and honesty about the number |
| T-C2 | "You mentioned about 40 interviews last year. What did that number count, and what does your loop look like?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Say "I run our hiring loop for backend roles." Slots, in your own words: what the 40 counted, including whether they were interviews you conducted yourself, how it was counted, and which part was yours. The JD's hiring line makes "what does the loop look like" likely: if you set any stage of it, say which and how you decided; if the stages were set by others, say so plainly and describe how you take part | F4 is the strongest row and a figure, so it is both where you lead and where you are probed; EXP because it tests what was actually yours |
| T-D1 | "So — walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | A ninety-second arc with only the beats the sentence states: nine years in engineering, three as a team lead of six, currently at a payments company. Then why this role, as in T-A3, in your own words. Add no other beat | The conversational opener is scored even though it feels casual; F1 supplies the beats and no more |
| T-D2 | "Tell me about a time you helped an engineer grow." | JD | [grounded] | Selection criteria: one specific person, a change you can describe without embellishing, what you did and what they did. No sentence of your material carries this story, so the pack supplies none. If no such time comes to mind, say so plainly, then give how you would approach it | F5 has no evidence in your material, so this is a selection scaffold; JD because the role's growth line is the raising source |

## Reverse questions — Round 1

| # | Question to ask | Why it lands |
|---|---|---|
| T-R1 | "What would you want the two squads to have delivered at six months for you to call this hire right?" | Turns the interview into the success criteria and shows you think in outcomes |
| T-R2 | "Where do hardware and software roadmaps collide hardest right now, and who decides when they do?" | Goes straight at F6 on your terms, and the answer tells you whether the gap is a ramp or a wall |
| T-R3 | "What is the on-call and reliability picture for the squads today?" | Opens the ground F3 stands on, so you can talk where you are strongest |
| T-R4 | "How do you like to work with your managers, and how do you want to hear bad news?" | You are meeting your would-be boss; this reads as partnership, not interrogation |
| T-R5 | "What is the state of hiring for the two squads right now?" | F4 is your strongest row; this invites you to use it |
| T-R6 | "What would make you regret this hire at six months?" | Surfaces the Director's real objection while you can still answer it |

---

# Round 2 — The Thursday after, 60 min, panel: two staff engineers and a product manager

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | "What do you need from me", seam-splitting between engineering and product, credit-sharing | High: all three panelists work alongside the role, so the peer prior applies across the board | Reciprocity framing; propose seam principles, do not pretend to know their seam |
| Data-Driven Prober | Counting and assumptions behind the 60%, and what the reliability quarter held | High: staff engineers are the technical-specialist prior, and F3 is a figure | Know what you can and cannot say; name the weakest assumption first |
| Case / Strategist | Live problems: a failed fleet update, a slipped date | Medium: panels with an engineering-manager role often test judgment live, and the role summary gives them two ready scenarios | Clarify, structure, think aloud, challenge one premise |
| Values / Behavioral | Disagreement and collaboration stories, mostly from the product manager | Medium: a cross-functional panelist is the values-and-behavior prior | A story only where one of your sentences carries it; otherwise criteria and the honest branch |
| Skeptic | The hardware and device-management gaps returning in collegial packaging | Medium: objections from the Tuesday bank come back in friendlier words from peers | Same hold-then-concede as T-A1 |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P-A1 | "Where's the seam between engineering and product when we disagree about what ships, and what happens when we do?" | JD | [grounded] "I pushed a reliability quarter through against roadmap pressure" | Offer seam principles, not knowledge of their seam: who decides what, how trade-offs get surfaced, what should be agreed before a disagreement. Then one story at its scope: "I pushed a reliability quarter through against roadmap pressure." Answer slot: say who the pressure came from and how you worked it through, in your own words; if product people were not part of it, say so plainly and stay with the sentence. Concede you have not seen their seam yet | F7 is the only adjacent sentence for the product half of the partnership; JD because it scores that stated requirement, delivered as a peer question |
| P-A2 | "How do you handle credit when work spans squads?" | VAL | [generic] | Principles first, with no claim about your past: credit named by the people who did the work, and your own part separated from theirs. Selection criteria for a story: a time work spanned teams, with named contributors and your part clear. If no such time comes to mind, say so plainly, then give how you would handle it | Peer stem on credit and ownership; `[generic]` because it carries no claim about you; VAL because it scores collaboration behavior |
| P-A3 | "What do you need from us, and what do we get from you?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." and "I pushed a reliability quarter through against roadmap pressure" | Lead with what you bring, at the quotes' scope: you run a hiring loop for backend roles, and you pushed a reliability quarter through against roadmap pressure. Say it as what you can offer them, and let them draw the inference. Then what you need, in your own words, naming a specific thing from each of them | Reciprocity framing is the counter to the peer persona; F4 and F3 are the sentences it can rest on, and no more |
| P-B1 | "What would make you doubt your 60% figure?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The weakest-assumption slot: name, before they do, the assumption behind the figure that you would defend least, in your own words. If you do not know how it was counted, say so plainly. Supply no method, baseline or attribution you cannot repeat under a second question | F3's figure, asked the way a technical specialist asks it; EXP because it tests honesty about the number |
| P-B2 | "What was in the reliability quarter?" | EXP | [grounded] "I pushed a reliability quarter through against roadmap pressure" | Answer slot: what the quarter contained, in your own words. Your sentence says the quarter and the pressure and nothing about its contents, so describe only what you can defend at that level; if you cannot recall specifics, say so. Separate your part from the squad's, in your own words | F3 is thin on contents, which is where a technical panel goes next |
| P-B3 | "What do you know about device-management systems, and where would you want us to correct you?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Answer slot: if any of your work touched systems that manage or talk to devices, say what, in your own words; if none did, say so plainly and say what you would read or ask first. Invite correction explicitly: the question tests how you take it. Do not present payments work as device-management work | F2 is a discovery gap and the panel's staff engineers are the people best placed to test it; JD because it scores the stated device-management requirement |
| P-C1 | "A device-fleet update fails on a subset of devices and the squad's on-call is paged. How do you run the first hour as the manager, and what stays with the engineers?" | CASE | [generic] | A live problem, so no claim about your past. Clarify scope and customer impact first. Then separate roles: what you decide, what the engineers decide, who communicates to whom. Then containment before cause, and the follow-up you would ask for once it is stable. Say where you would defer to the staff engineers by name of role | F2's domain meets F3's on-call theme in a scenario from the role summary's own work; `[generic]` because it carries no Larkfield fact |
| P-C2 | "Hardware tells you a sensor feature will slip. Product wants the date held. How do you reason about it?" | CASE | [generic] | Clarify what slips and what the date is tied to, then options, the decision you would take to each side, and what you would want agreed so it does not recur. Challenge the premise: is the date or the scope the fixed thing? No claim about your past | The product manager's version of T-B1; F6 and F7 again, and the panel is where you can rehearse it with the person who owns the date |
| P-D1 | "Tell me about a time you disagreed with a product partner and it didn't go your way." | VAL | [grounded] "I pushed a reliability quarter through against roadmap pressure" | Selection criteria: a named stake, a moment you held, a relationship intact at the end. Your sentence says roadmap pressure and says nothing about product people or about not getting your way, so if it fits, tell it only at its scope and mark the rest as slots. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Peer stem on disagreement; F7 is the nearest sentence and its limit is named so it is not stretched |
| P-D2 | "What does a good working relationship between an engineering manager and a staff engineer look like?" | VAL | [generic] | No claim about your past: say what you would expect, what you would ask of them, and what you would offer. Ask them what they have found works | Reciprocity-flavored values question; `[generic]` because it carries no claim about you |

## Reverse questions — Round 2

| # | Question to ask | Why it lands |
|---|---|---|
| P-R1 | To a staff engineer: "What is the one technical decision the squads are living with that I should understand first?" | Shows you want to learn the system before changing it (F2) |
| P-R2 | To a staff engineer: "What do you want from an engineering manager that you have not always had?" | Peer-to-peer; reveals what they will judge you against |
| P-R3 | To the product manager: "When hardware's timeline shifts, how does a roadmap change get decided today?" | Goes at F6 and F7 with the person who lives the seam |
| P-R4 | To the whole panel, reciprocity: "What could a new manager do in their first month that would genuinely help your work?" | Reduces the load you would add to them, which is what a peer panel is pricing |
| P-R5 | To the whole panel: "What do you wish candidates asked about this role that they usually don't?" | Invites the honest, unscripted answer and signals curiosity |

---

# Round 3 — The following Monday, 30 min, VP Engineering ("values and leadership philosophy")

Larkfield's published values were not retrieved, so no cheat sheet is built and the questions below follow the recruiter's description, not named values. If you paste the values page, I will add the sheet. With 30 minutes, expect roughly four or five questions.

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Leadership philosophy, a hard truth delivered, how you develop people | High: the recruiter's own words, "values and leadership philosophy", name this round's purpose | A story only where one of your sentences carries it; otherwise criteria and the honest branch |
| Pressure | Time-boxed "why you" and "how much was you" | Medium: the skip-level and executive prior includes composure tests | Pause, restate, hold through two follow-ups, concede specifically |
| Case / Strategist | Altitude questions: what would you learn first, how hardware and software pace trade off | Medium: the skip-level prior is strategy-heavy, though the recruiter's description points elsewhere | Clarify, hypothesize, think aloud; no Larkfield facts without research |
| Skeptic | The biggest step up in the job | Medium: your two stated gaps are reachable from any seat | Name the step up yourself, with a plan |
| Conversational | Rapport at the open and close | Low to the extent a 30-minute round has little room for it | Keep the arc short |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V-A1 | "How would you describe your leadership philosophy?" | VAL | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" and "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Answer slot: the principle itself is yours to name, in your own words; the pack supplies none. Then one thing you did, at the quotes' scope: three of your nine years were as a team lead of six, and you pushed a reliability quarter through against roadmap pressure. Describe what you did and let them draw the inference; do not tell them what it proves | The recruiter's own words make this question near-certain; F1 and F3 are the only sentences it can rest on; VAL because it scores whether your behavior matches what you say you value |
| V-A2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection criteria: a specific message, a senior person, a moment you did not soften it, and a working relationship intact at the end. No sentence of your material carries this story, so the pack supplies none. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Values stem; `[generic]` because no quote carries it; VAL because it scores behavior over time |
| V-A3 | "How do you think about developing the engineers on your team?" | VAL | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Philosophy first, in your own words. Then answer slot: if developing people was part of your three years as a team lead of six, say what, in your own words; if it was not, say so plainly and say how you would approach it at eleven. No development practice is supplied here | F5 has no evidence in your material; VAL because it is a leadership-philosophy question |
| V-A4 | "Tell me about the reliability quarter — what was the principle behind pushing it through?" | VAL | [grounded] "I pushed a reliability quarter through against roadmap pressure" | Say your sentence at its scope. Answer slot: what drove the call, in your own words. If it was a principle, name it; if it was a practical decision and not a principle, say so plainly. Do not tell them what the work proves | F3 is where the "values" question can use a real sentence, and where a principle is easy to invent after the fact |
| V-B1 | "If you joined, what would you want to know about Larkfield before you changed anything?" | CO | [generic] | A live problem, so no claim about your past or about Larkfield. Say what you would ask: where the squads' work sits in the company's priorities, how hardware dependencies are managed, what has been tried. Ask the VP for the first two or three | The CO slot with no research behind it, kept honest as `[generic]`; add the strategy brief from the upgrade menu to make it specific |
| V-B2 | "How should an engineering organization balance hardware timelines against software pace?" | CASE | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Concede first, in your own words: "I've never owned a hardware-adjacent roadmap." Then reason as principles, not as experience: what you would want visible to both sides, who decides trade-offs, what you would ask hardware for. Do not offer a framework as something you have used | F6 returns at altitude; CASE because the answer is a structure |
| V-C1 | "Sixty seconds: why you, rather than someone who has already managed managers?" | EXP | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" and "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Hold-then-concede. Concede first: "I've never managed managers." Hold on what your material carries at its scope: three of nine years as a team lead of six. The role summary you pasted describes leading two squads and owning delivery, hiring and growth for eleven engineers, and does not mention managing managers, which is an observation for your own reading and not a line to say. Hold through two follow-ups by returning to the role as described | Pressure stem aimed at your stated limit; EXP because it tests whether your claim survives a flat challenge |
| V-C2 | "That on-call result — how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold your sentence: "I pushed a reliability quarter through against roadmap pressure." Answer slot: which part was yours and which part was the team's, in your own words. Concede specifically what others did; hold through two follow-ups without folding on your own part | F3's attribution, at the altitude where a hard-pressed answer matters most |
| V-D1 | "What part of this job is the biggest step up from what you've done?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" and "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Pick one honestly and name it first. Your stated limit is the hardware roadmap: "I've never owned a hardware-adjacent roadmap." The scale from six to eleven is the other your material shows. Then your ramp plan, in your own words, said as a plan | Skeptic stem; F6 and F1 are the two honest candidates, and naming one before they do converts a gotcha into a credibility gain |

## Reverse questions — Round 3

| # | Question to ask | Why it lands |
|---|---|---|
| V-R1 | "What does good engineering leadership look like at Larkfield in your own words, and where is the organization still short of it?" | A leadership-philosophy round deserves a leadership-philosophy question back |
| V-R2 | "What do you expect an engineering manager to bring to you that they would not bring to the Director?" | Clarifies the skip-level relationship and the altitude you are expected to work at |
| V-R3 | "What are the one or two company priorities engineering has to deliver in the next year?" | Fills the strategy gap the pack could not research, from the person best placed to answer |
| V-R4 | "Which part of device management worries you most today?" | Moves you from candidate to colleague and surfaces what the role is really for |
| V-R5 | "What would make hiring an engineering manager here obviously right in a year?" | Gives you the last chance to hear the success criteria and respond to them |

---

## Prohibited claims (shared)

| Not coached | Basis | Honest form |
|---|---|---|
| Managed managers | Negative you stated, F6 | Your own words: "I've never managed managers." No slot |
| Owned a hardware-adjacent roadmap | Negative you stated, F6 | Your own words: "I've never owned a hardware-adjacent roadmap." Then a plan, said as a plan |
| Led two squads, or managed eleven engineers | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says a team lead of six, not two squads. Slots stay inside that scope |
| Owned delivery for the team | Inflated form of F3 | F3's quote at its own scope: you pushed a reliability quarter through against roadmap pressure. The limit is the pack's observation: your material says the quarter, not delivery across quarters |
| Cut on-call burden by 60% | Inflated form of F3 | F3's sentence in its own form, "after", never "because". The limit is the pack's observation: your sentence says the burden dropped after the quarter and does not say the quarter caused it |
| Made the hiring decisions, or hired a number of people | Inflated form of F4 | F4's quote at its own scope: you run the loop, and about 40 interviews took place. The limit is the pack's observation: your sentence does not say whether you conducted the 40 or who decided |

## Sources

Provided documents: the role summary and the account of your background and rounds in your message. No dossier was consumed. Your own words establish the loop (three sessions, who runs each), and the recruiter's description of the Monday round, as you relayed it, establishes a values-style round there. Larkfield's published values were not in hand, so no cheat sheet was built.

Searches sent, all refused, so nothing was retrieved or used:

- `Larkfield Systems company values` — refused
- `Larkfield Systems interview process engineering manager` — refused
- `Larkfield Systems industrial IoT strategy news` — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Every call was refused. Would have moved: a values cheat sheet for round 3, and named values for the VAL questions |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Every call was refused. Would have moved: documented round formats and case formats; persona weights rest on your own account of the loop instead |
| 3. `Larkfield Systems industrial IoT strategy news` | unavailable | Every call was refused. Would have moved: a strategy-grounded CO or CASE question; V-B1 stays `[generic]` |
| 4. Interviewer name and company | n/a | No names were given, so there was no query to form; the interviewer read is absent |
| 5. Representative engineering manager JD | unavailable | No call was sent because search was not granted. Would have moved: more quoted `[inferred]` requirement rows for a role summary this short |

## Upgrade menu

- The full JD text → the role summary's three sentences become line-by-line quoted requirements, and any requirement outside the current rows gains a JD-tagged question
- Your CV → F2, F5 and F7, now `low` or `none`, can move up, and the evidence column gains sentences beyond the four in your message
- An on-call report or postmortem behind the 60% figure, and a hiring-loop scorecard behind the 40 → F3 and F4 can move from `medium` toward `high`
- Your own answers to the answer slots in F1, F2, F3, F5 and F7, pasted into the conversation → each becomes quoted evidence and the rows and questions that draw on it regenerate
- The names of the Director, the two staff engineers, the product manager and the VP → an interviewer read, persona weights adjusted from their public careers, and reverse questions tied to their paths
- Larkfield's published values page pasted, or search access granted → a values cheat sheet for round 3, with each published value mapped to one of your quoted sentences or to a selection scaffold
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes, offered once) → a strategy-grounded CO and CASE set for the Director and the VP
- The recruiter's focus areas for the panel round, and whether it includes a design or case exercise → coverage for any declared deliverable; usually one email
- A `tuesday-dossier.md` from a prior job-underwriter run → verified evidence, a per-gap strategy limit and a prohibited-claims list that this pack would otherwise infer
