# Member Experience Lead — Ashgrove Credit Union — interview pack for Dara

Three rounds on 5 December 2026, built in loop mode because you gave me all three:

- Round 1: recruiter, 30 minutes.
- Round 2: Head of Member Services, 45 minutes. This person would be your manager, and the round is mostly behavioural. Not yet named.
- Round 3: panel of two branch managers, 60 minutes, with a 20-minute complaint-escalation case. It is also the values round. Not yet named.

The highest-ROI prep in this pack is R2-S1: the end-to-end ownership question, which meets your one-branch log and your missing contact-centre experience head on. Start there.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: tell it in your own words, and say only what you actually did.

Question IDs read round, persona, number. R2-S1 is round 2, Skeptic, first question. Persona letters: C Conversational, S Skeptic, P Data-Driven Prober, V Values/Behavioral, K Case/Strategist, E Peer Evaluator, X Pressure.

| Type | What it is really scoring |
|---|---|
| VAL | Whether past behaviour shows Ashgrove's published values, not generic virtue |
| EXP | Whether your own account of your work survives scrutiny, including what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company's strategy and can think at its altitude |
| CASE | Whether you structure a live problem from the real role |

An answer slot is an instruction for the interview, not a question for you now. Meet it with either honest branch, from your own experience.

## Fit snapshot

Your evidence column holds only your own words from your message. The requirements are quoted from the JD you pasted. No row is a gate: the 4+ years is a length requirement, not a licence or a legal bar.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | Say it in your own terms and at its own scope: "I have six years in retail banking, the last three as a branch supervisor." The JD's phrase stays in this table and is not words for you, and nothing inspected sits behind the line yet, so expect a probe on what each stage of those six years involved |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says the formal complaints log, not what governed it, and the words stay there: "I handled the branch's formal complaints log." Answer slot: expect a probe on what governed the log and which part of that was yours. If you know, say so in your own words; if it was an internal record, or you do not know what governed it, say so plainly and stay with the log you handled |
| F3 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says one branch's log, not a process across branches. Words: "I handled the branch's formal complaints log." Answer slot: if any part of that handling reached beyond your branch, say what and whose; if it stayed within the branch, say so plainly |
| F4 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing is added to make the gap feel smaller |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | Your material says the spreadsheet is monthly and about complaints, and does not say what it showed. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names volumes and resolution times, so expect a probe on what the spreadsheet showed and how each figure was counted. Say what it showed, in your own words; if it showed something else, say what; if you do not know how a column was counted, say so plainly |
| F6 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | You said spreadsheet, not Excel, and the pack keeps your word. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: expect "which tool?" If it was Excel, say so; if it was another tool, name it and say so plainly |
| F7 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Then how you would prepare, said as a plan and never as a past. Your sentence is a negative about levels above regional; it does not say what you presented at regional level, so the pack says nothing about that either |
| F8 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your material says new tellers and the escalation script. Words: "I trained new tellers on our escalation script." Answer slot: if the training reached anyone beyond the new tellers, say who and in what form; if it did not, say so plainly and stay with the tellers |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent on digital work, so this is an answer slot, not a gap you have stated. Answer slot: if you have worked with any digital team, say what the work was and which part was yours; if you have not, say so plainly and say what you would want to learn first about the journeys |

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| 4+ years in financial-services customer operations (F1) | R1-C1 |
| experience handling regulated complaints (F2) | R1-S1, R2-S3 |
| Own the complaints process end to end across branches and the contact centre (F3, F4) | R1-S2, R2-S1, R2-S3, R3-K1 |
| report monthly on complaint volumes and resolution times (F5) | R2-P1, R2-K1 |
| comfortable with Excel reporting (F6) | R2-P1, R2-K1, R3-X1 |
| confident presenting to senior leaders (F7) | R2-V2, R2-S3, R3-S1 |
| coach branch supervisors on escalations (F8) | R2-V4, R3-E1 |
| work with digital teams on self-service journeys (F9) | R2-K2, R3-K3 |

## Grounding brief: Ashgrove's 2026 strategy

You told me four points from the brief the recruiter sent you, published in July 2026. I have not read the brief itself, so this table holds only those four. Interviewers know this brief, and so may rival candidates. In an answer, bring one item to show you have read it, then add a view of your own with its concession. Do not recite the list.

| Point | Source | Provenance | Where it appears in this pack |
|---|---|---|---|
| Move 40% of member service to digital channels by 2028 | your message, from the 2026 strategy brief | [grounded] | R2-K2, R3-K3, R1-C2 |
| Consolidate eight branches into five hubs over 2027 | your message, from the 2026 strategy brief | [grounded] | R3-K2, reverse questions |
| Launch a small-business lending product in Q1 2027 | your message, from the 2026 strategy brief | [grounded] | R2 reverse questions |
| Main competitive pressure is app-only banks | your message, from the 2026 strategy brief | [grounded] | R3-K3 |

---

## Round 1: recruiter screen, 30 minutes

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | Friendly walk-through of your background, motivation and logistics | High. The recruiter-screen prior is conversational with logistics, and the recruiter's own email gives this round 30 minutes and no stated focus | Pre-script the 90-second arc; treat the friendly questions as scored |
| Skeptic (light) | Knockout checks on the JD's named requirements | Medium-low. The JD names formal complaints and the contact centre, and your message names a missing contact centre, so both are quick checks | Answer each briefly at its own scope, then stop |

### Conversational (4 of 8 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-C1 | "So, walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | Four sentences in your own words, in this order: the six years in retail banking and the last three as branch supervisor; the formal complaints log you handled; the escalation script you trained new tellers on; the monthly complaints spreadsheet you built. Each keeps its own scope. Stop at about 90 seconds and close on your own reason for wanting this role. Answer slot: say your actual reason; nothing in your material supplies one | F1 is the base requirement and this opens most screens. EXP because it tests your own account of your path; the friendly register is still scored |
| R1-C2 | "What interests you about Ashgrove?" | CO | [grounded] | One published value by its exact name, for example "Plain Words" or "Own the Fix", and one item from the strategy brief, with your own reason for each. Answer slot: say what draws you to a member-owned credit union; if the draw is the role rather than the model, say that plainly. Do not recite the brief | The recruiter sent you the brief and published the values, so this is the cheapest place to show homework. CO because it scores knowledge of the values and strategy, not your history |
| R1-C3 | "What's prompting you to look for a move now?" | EXP | [generic] | Logistics slot: give your actual reason in your own words, in two sentences. Say what you are moving toward as well as what you are leaving, only if that is true. Use the same reason in round 2. Your material states none, so the pack supplies none | The reason for leaving is a standard recruiter check, and rounds 2 and 3 can ask it again. EXP because it is your own account |
| R1-C4 | "What salary range are you looking for?" | JD | [generic] | Logistics slot: choose before the call between giving your own number and asking for the role's band first. If asked what you earn now: "I'd rather focus on the range for this role". Your material states no figure, so the pack supplies none | Pay is a standard recruiter-screen item and the safest answer is your own. JD because it concerns the listed job's terms |

### Conversational, continued

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-C5 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period, in your own words | Standard recruiter-screen item; JD because it concerns the job's start terms |
| R1-C6 | "Where would you be working from, and is there anything about location or hours we should know?" | JD | [generic] | Logistics slot: state where you can work and how often, from your own situation, in your own words. The JD says nothing about location, so asking the recruiter what the working pattern is before you answer is also open to you | Location is a standard screen item. The role spans branches and a contact centre, so the pattern is worth knowing; JD because it concerns the job's terms |

### Skeptic, light (2 of 8 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-S1 | "The role involves regulated complaints. What's your experience with those?" | JD | [grounded] "I handled the branch's formal complaints log" | Say what the sentence carries, in the words you used for it: "I handled the branch's formal complaints log." Answer slot: expect a follow-up on what governed that log and which part was yours. If you know, say so; if it was an internal record, or you do not know what governed it, say so plainly and stay with the log you handled | F2 is the requirement your material reaches least directly, so this knockout check arrives early and in friendly register. JD because it scores a stated requirement |
| R1-S2 | "The role covers the contact centre as well as the branches. Have you worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre" | Short and plain: "I've never worked in a contact centre." Then stop, or add the branch side you can speak to: "I handled the branch's formal complaints log." Answer slot: say in your own words the first thing you would do to learn how the contact centre handles complaints. Nothing in your material speaks to contact-centre work | F4 is a gap you stated, so this question will be asked and the honest short answer is the rehearsal. JD because it scores a stated requirement |

### Reverse questions, round 1

| Question | Why it lands |
|---|---|
| "Who will I be meeting in rounds two and three, and is there anything the panel's case needs me to have read beforehand?" | Names and case format are the two things your material does not have, and the answer feeds the next two rounds' prep |
| "How is complaints work split today between the branches and the contact centre, and where does this role sit between them?" | Tests the scope of the end-to-end ownership line before you are asked about it |
| "The strategy brief aims for 40% of member service on digital channels by 2028. Where does complaints handling fit in that?" | Shows you read the brief and points the role's digital strand at complaints |
| "What would a strong first six months look like from your side?" | Standard but it gives you the success measure to anchor round 2 |
| "What happens after the three rounds on 5 December, and when do you expect to decide?" | Practical closure and a signal you are planning, not just reacting |

---

## Round 2: Head of Member Services (future manager), 45 minutes, mostly behavioural

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "Tell me about a time" stories, scored for fit with how Ashgrove works | Highest. The recruiter described this round as mostly behavioural, and the four values are published | Choose a different story per value where one exists; "we" for context, "I" for your contribution |
| Skeptic | Probes the gaps, since this person would be your manager and is pricing the risk | High. The hiring-manager prior is capability plus risk, and your message states two gaps against two JD lines (F4, F7) | Rehearse R2-S1 until it is boring; concede the specific limit, never the core facts |
| Case / Strategist | Live problems on the real role | Medium. The hiring-manager prior says expect them, lowered because the recruiter said mostly behavioural | Clarify, then structure, then think aloud; challenge one premise respectfully |
| Data-Driven Prober | Reads your one built artifact line by line | Medium-low. F5 is your one artifact and it is the only line a prober can take apart | Say plainly what you do and do not know about how it was counted |

### Values / Behavioral (4 of 10 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-V1 | "When did you put a member's interest ahead of an internal metric or process?" | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold. Choose a time a rule, target or script pointed one way and the member's side pointed the other. It needs a named stake, what you decided, what it cost, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I handled the branch's formal complaints log" at that scope, or say how you would handle it | The first published value is "Members First, Always", and the persona stem asks for exactly this. VAL because it tests whether past behaviour shows the value; F3 is the only quoted sentence near it |
| R2-V2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Selection scaffold. Choose a time you told someone senior what they did not want to hear: what the truth was, how you said it, what happened, whether the relationship held. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I built the monthly complaints spreadsheet our regional manager uses", at that scope (it does not say the report carried bad news), or say how you would handle it | The JD asks for confidence with senior leaders and F7 is a stated gap, so this arrives in a behavioural round. VAL because the hard truth has to land in the story |
| R2-V3 | "Tell me about a time you worked with a team outside your branch." | VAL | [grounded] | Selection scaffold. Choose a time you needed another team to get something done: who they were, what you needed, how you asked, what came of it. If no such time comes to mind, say so plainly and say how you would approach a team you did not know. Your material has no sentence for this, so the pack supplies no story | The JD spans branches, the contact centre and digital teams, so working outside your branch is the core of the role. VAL because it is a behavioural prompt; the JD raises the theme |
| R2-V4 | "The role coaches branch supervisors on escalations. Tell me about a time you taught someone how to handle an escalation." | JD | [grounded] "trained new tellers on our escalation script" | Map the one beat the sentence states: you trained new tellers on your escalation script. Answer slot: pick one moment from that training; if something did not land the first time and you changed how you explained it, say what; if it did not happen, or no moment comes to mind, say so plainly and describe how the training ran. Also expect "and beyond tellers": if the training reached anyone beyond the new tellers, say who and in what form; if it did not, say so plainly | F8 is the nearest your material gets to the coaching line, and the manager will ask. JD because it scores a stated responsibility, with behavioural delivery |

### Skeptic (3 of 10 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-S1 | "This role owns the complaints process across the branches and the contact centre. Your material is one branch's formal complaints log and no contact centre. Convince me." | JD | [grounded] "I handled the branch's formal complaints log"; "Never worked in a contact centre" | **The highest-ROI rehearsal in this pack.** Hold, then concede, through three follow-ups. Open at the quote's scope: "I handled the branch's formal complaints log." Follow-up 1, "is that owning it end to end?": hold at that scope and do not agree to wider. Answer slot: if any part of the handling reached beyond your branch, say what and whose; if it stayed within the branch, say so plainly. Follow-up 2, "and the contact centre?": concede the specific limit in these words, before they press: "I've never worked in a contact centre." Then a plan stated as future: say in your own words the first thing you would do to learn it. Follow-up 3, "why should we take that on?": return to what you did and to the plan. Describe your work and let them draw the inference; do not tell them what it proves | This is where the JD's headline responsibility meets F3 and F4 together, and the manager will ask it in some form. JD because it scores the stated ownership; the guidance never thickens the one-branch log |
| R2-S2 | "Why this role, and why now?" | EXP | [generic] | Use the same reason you gave the recruiter in R1-C3, in your own words, and add what draws you to Ashgrove specifically (R1-C2). Answer slot: if the two are different reasons, say both plainly. The pack supplies no reason of its own | The Skeptic checks motivation consistency across rounds. EXP because it is your own account |
| R2-S3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Name one yourself, with its limit at its own scope: "I've never worked in a contact centre" or "I've never presented to anyone above regional level". Pick the one you would most want your future manager to hear from you first. Then the ramp as a plan, not a past: say in your own words what you would do in the first weeks about it. One plainly stated limit holds credibility better than a list | F4 and F7 are both stated absences, and this question asks for the one you choose. JD because it scores honest self-assessment against the requirements |

### Data-Driven Prober (1 of 10)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-P1 | "Walk me through the monthly complaints spreadsheet your regional manager uses." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Beats the sentence states: you built it, it is monthly, it is about complaints, and your regional manager uses it. Answer slots: what it showed; how each figure was counted; the assumption behind it you would defend least, named in your own words before they ask; and which part was yours. If it showed complaint volumes or resolution times, say which and how each was counted; if you do not know how something was counted, say so plainly. Say which tool it was built in | F5 and F6 both rest on this one line and a prober will take it apart; the weakest-assumption move turns the probe into credibility. EXP because it tests what was actually yours |

### Case / Strategist (2 of 10 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-K1 | "Suppose senior leaders want one monthly view of complaint volumes and resolution times across the branches and the contact centre. How would you build it?" | CASE | [grounded] | Structure aloud. Clarify first: who reads it and what they decide with it; what counts as resolved and when the clock starts, since channels may record differently, so ask rather than assume; what each channel records today. Then the objective, a short list of measures with definitions, how to show them in plain words, and the risks, such as a number hiding a member. The question needs no claim about your past, so the guidance makes none | Both reporting lines in the JD land here, with F5 and F6 behind them. CASE because it scores structure; JD content, CASE delivery |
| R2-K2 | "The strategy is 40% of member service on digital channels by 2028, and the role works with digital teams on self-service journeys. What should a digital complaint journey look like, and what should not be self-service?" | CASE | [grounded] | Bring one item from the brief to show grounding, then your own thesis with its concession; do not recite the brief. Two options to choose between, whichever you actually believe: keep a visible route to a person at every step, conceding it costs some of the digital shift; or self-service for tracking status only, conceding it leaves the hard cases to people. If asked "where have you worked with a digital team", answer slot: say what the work was and which part was yours; if you have not, say so plainly and say what you would want to learn first | F9 is silent in your material and the JD names it, so this arrives as a case and as a probe. CASE; the digital item is the first in the brief |

### Reverse questions, round 2

| Question | Why it lands |
|---|---|
| "Where do complaints go wrong most often for members today, from where you sit?" | Member's-side framing and gives you the real problem to anchor the role |
| "What does the monthly complaints report show now, and who reads it?" | Ties to F5 and tells you what you would inherit |
| "What would you want me to learn first about the contact centre, and from whom?" | Turns the F4 gap into a ramp plan with the person who will manage it |
| "Will the small-business lending launch in Q1 2027 bring complaint handling needs of its own?" | A strategy item most candidates will not touch; asks about it rather than claiming an answer |
| "With eight branches becoming five hubs over 2027, what do you need this role to hold steady?" | Shows you read the hub plan and asks for the manager's priorities |

---

## Round 3: panel of two branch managers, 60 minutes, with the values round and a 20-minute escalation case

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Each of the four values scored with a story | Highest. The recruiter said the panel scores against the four values | One story per value; do not reuse the round 2 story for a different value |
| Case / Strategist | The 20-minute complaint-escalation case | High. The recruiter named the case and its length | Spend the first few minutes clarifying; think aloud; use the values' vocabulary |
| Peer Evaluator | Seam between your coaching and their supervisors | Medium. The role coaches branch supervisors (JD), and the panel are branch managers, so the seam is likely, though which supervisors sit under which manager is my inference | Offer seam principles, not claimed knowledge of their structure |
| Skeptic | Presenting above regional level | Low-medium. F7 is a stated gap and this panel may not be the main audience for it | Hold what you did, concede the specific limit |
| Pressure | Time-boxed, attribution probe | Low. A panel running a timed case may press once | Pause, restate, hold through two follow-ups |

### Values / Behavioral (4 of 10 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-V1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold. Choose a time the member's side and another pull differed: a named stake, what you decided, what it cost, how it ended. If none comes to mind, say so plainly, then give the nearest thing your material carries, "I handled the branch's formal complaints log" at that scope, or say how you would handle it. Use a different story from R2-V1 only if you have two | The first published value, in its own words. VAL because it tests that past behaviour shows the value; F3 is the only nearby sentence |
| R3-V2 | "Tell me about a time something you wrote or explained had to be explained twice." | VAL | [grounded] "trained new tellers on our escalation script" | Selection scaffold. Choose a time your wording failed or you simplified something for members or colleagues: what was unclear, what you changed, what happened. If none comes to mind, say so plainly, then give the nearest thing your material carries, "trained new tellers on our escalation script" at that scope (it does not say how the script was worded), or say how you would test wording with a member | "Plain Words" says if it needs explaining twice, "we wrote it wrong". F8 is the only sentence near teaching or scripts |
| R3-V3 | "You built the monthly complaints spreadsheet your regional manager uses. How do you keep a number from standing in for a member or a town?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say what the sentence carries: you built it, it is monthly, your regional manager uses it. Answer slot: if the spreadsheet carried anything beyond counts, say what and why, in your own words; if it was counts only, say so plainly, and say what you would want a report to carry so a branch's own story is not lost, as a plan | "Neighbours, Not Numbers" meets a candidate whose built artifact is a spreadsheet. VAL because it tests the value; F5 is the quoted premise |
| R3-V4 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Map the one beat the sentence states: you handled the branch's formal complaints log. Answer slot: the value is about whoever finds a problem keeping hold of it, so expect "name one". If you stayed with one from start to solved, say what it was, what you did, and how you knew it was solved; if the log's complaints passed to others to resolve, or no one comes to mind, say so plainly and stay with the log you handled | "Own the Fix", in its own words; F3 is the nearest sentence and says only that you handled the log |

### Case / Strategist (3 of 10 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-K1 | "A member has complained twice and been given different answers each time. They have come into the branch and want it escalated today. Walk us through what you do." | CASE | [generic] | The panel's real case will differ; rehearse the structure. Clarify first (about three minutes): what the member is asking for, what they were told and by whom, what is recorded, what clock or rules apply here. Ask, do not assume. Then objective: the member's side first, and one named person who holds it until it is solved. Then today's actions: listen and restate, reply in plain words, say what happens next and when, record it. Then root cause of the two different answers, feedback to the branch and the contact centre, and what you would report in the monthly numbers. Challenge one premise respectfully, for example what "escalated" means in practice. The case needs no claim about your past | The recruiter named a 20-minute complaint-escalation case; the format is unknown, so this is the pattern. CASE; each step maps to a published value |
| R3-K2 | "Eight branches are becoming five hubs over 2027. A town loses its branch. What happens to the complaints that used to be walked in there?" | CASE | [grounded] | Clarify what a hub offers a town, then structure: where a member can still raise a complaint in person, how it reaches an owner, how the town's voice gets into the monthly reporting. Tie to "every branch is part of its town". The panel are branch managers; whether their own branches are among the eight is not in your material, so do not assume it, and do not argue the decision, only how complaints survive it. Needs no claim about your past | The hub plan is the strategy item most likely to feel personal to branch managers. CASE; it also scores the "Neighbours, Not Numbers" value |
| R3-K3 | "App-only banks are the main competitive pressure, and 40% of member service is to move to digital by 2028. How should a complaint work for a member who started in the app?" | CASE | [grounded] | Bring one item from the brief, then your own thesis with its concession. Two options, whichever you believe: a visible route from the app to a person, conceding it costs some containment; or self-service for status updates only, conceding the hard cases land on people. Use Plain Words for any wording the member sees. If asked about your own digital work, answer slot: if you have worked with a digital team, say the work and which part was yours; if not, say so plainly | Combines the digital target and the competitive frame. CASE; F9 sits behind it |

### Peer Evaluator (1 of 10)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-E1 | "Branch supervisors work for us, not for you. Where is the seam when you coach them, and what happens when we disagree?" | JD | [inferred] "trained new tellers on our escalation script" | Offer seam principles in your own words: who owns the member's outcome, who owns a supervisor's development, what gets raised with the branch manager first, and how credit is shared. Offer what you would bring them, such as a consistent route for escalations, as a plan. Disagreement: answer slot: if you have disagreed with a manager or peer over how to handle a member, say what and how it ended; if not, say so plainly and say how you would handle it | The JD's coaching line meets a panel of branch managers; that the supervisors sit under them is my inference from the roles. JD for the responsibility, with peer delivery; F8 is the nearest sentence |

### Skeptic (1 of 10)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-S1 | "The role reports monthly and presents to senior leaders. You've never presented above regional level. How will you handle that?" | JD | [grounded] "I've never presented to anyone above regional level" | Hold, then concede. Hold what you did: answer slot: if you have presented at regional level, say what and to whom; if what you did was send the report rather than present it, say so plainly. Concede in these words: "I've never presented to anyone above regional level." Then the plan as future: say in your own words what you would do to prepare the first presentation. Do not tell them what your work proves | F7 is a stated gap against an explicit JD line. JD because it scores a stated requirement; the hold-then-concede structure applies |

### Pressure (1 of 10)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-X1 | "That spreadsheet. How much of it was actually you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Pause, restate the question, and answer from the sentence: "I built the monthly complaints spreadsheet our regional manager uses." Hold it through two follow-ups. Answer slot: if anyone else set the format or supplied the data, say who and what; if it was yours throughout, say so plainly. If there is a part you do not know, say which, plainly, and do not add to it | The attribution probe is aimed at your one built artifact (F5, F6). EXP because it tests what was actually yours |

### Values cheat sheet

The four published values, in their own names, with the working meaning and where your material carries a story.

| Value (official name) | Working meaning | Mapped story or scaffold |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Scaffold, ending in its honest branch: choose a time you decided from the member's side and it cost something; if none comes to mind, say so plainly, then give the nearest, F3's "I handled the branch's formal complaints log", at that scope, or how you would handle it |
| Plain Words | If a member needs it explained twice, the wording was wrong | Scaffold: choose a time your wording failed or you simplified something; if none comes to mind, say so plainly, then F8's "trained new tellers on our escalation script" at that scope, or how you would test wording |
| Neighbours, Not Numbers | Every branch is part of its town | Story-mapped on F5's "I built the monthly complaints spreadsheet our regional manager uses", with R3-V3's answer slot on whether it carried anything beyond counts |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Story-mapped on F3's "I handled the branch's formal complaints log", with R3-V4's answer slot naming one you stayed with, or the plain alternative |

### Reverse questions, round 3

| Question | Why it lands |
|---|---|
| "What makes a complaint escalation go well or badly from where you sit?" | Hands the panel their own expertise and tells you what they will score |
| "What would you want from the person in this role during the move from eight branches to five hubs?" | Shows you read the hub plan and puts you on the branches' side of it |
| "What could a new person in this role do in their first month that would genuinely help your branches?" | Reciprocity question for a peer-adjacent panel |
| "How do your supervisors hear back after they escalate something?" | Tests "Own the Fix" from the branch end and points at the coaching line |
| "Which of the four values do you see tested hardest in a complaint, and how?" | Invites them to teach you, and shows you take the values as working tools |

---

## Prohibited claims

What this pack will not coach, and why. Built from the fit snapshot before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F3 | F3's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: your material says one branch's log, not a process across branches. R2-S1's slot stays inside the log |
| Handled regulated complaints | Inflated form of F2 | F2's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: your material says the log, not what governed it. R1-S1's slot stays inside the log |
| Coached branch supervisors on escalations | Inflated form of F8 | F8's quote at its own scope: "trained new tellers on our escalation script." The limit is the pack's observation: your material says new tellers, not supervisors. R2-V4's slot stays inside the training |
| Worked in a contact centre | Negative you stated, F4 | The plain acknowledgment: "I've never worked in a contact centre." No slot |
| Presented to senior leaders | Contradicted by F7's quote | "I've never presented to anyone above regional level." No slot on levels above regional |

## Sources

Provided documents: the JD text you pasted; Ashgrove's four values, pasted, copied on 26 November 2026 from ashgrovecu.org/about/values; the recruiter's email on the three rounds; four points from the July 2026 strategy brief, as you gave them; your own background in your message. No tuesday-dossier.md was present.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values you pasted fix the values cheat sheet and the VAL questions; no page was fetched |
| 2. Ashgrove interview process, member services | skipped | The recruiter's email establishes the loop: who runs each round and what it holds, and that round 3 is the values round |
| 3. Ashgrove strategy and recent news | skipped | The four brief points you gave, from July 2026, fix the CO and CASE questions; the brief itself I have not read |
| 4. Interviewer names at Ashgrove | n/a | No names are assigned yet, so no query could be formed; the interviewer read is absent and the upgrade menu says what names would unlock |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The names and titles of the Head of Member Services and the two panel members → an interviewer read, persona weights read from their public footprint, and a reverse question tied to each one's own path
- The recruiter's detail on the case (discussion or role-play, any materials, whether it is a live member) → R3-K1 rebuilt for the real format; this is usually one email
- Your answers to the slots in F2, F5, F6, F8 and F9: what governed the formal complaints log, what the spreadsheet showed and which tool it was built in, who else the escalation script training reached, and any digital-team work → those rows move from discovery or transferability to quoted evidence, and the matching slots become story-mapped answers
- An anonymised copy of the monthly complaints spreadsheet or its layout → F5 and F6 can move from medium to high confidence
- The full strategy brief text → the grounding brief with exact wording, and CO and CASE questions on more than four points
- How many hours you have before 5 December → a prioritised prep schedule sized to it
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → Ashgrove's recent strategy and organisational context and role-family loop reports; offered once
- A tuesday-dossier.md from job-underwriter, as a separate request → verified evidence and ready-made objections to build the banks from, never required
