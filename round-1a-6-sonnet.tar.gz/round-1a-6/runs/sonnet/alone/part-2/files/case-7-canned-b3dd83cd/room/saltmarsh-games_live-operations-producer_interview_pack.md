# Interview prep pack — Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations — treated as the hiring manager (assumption: Saltmarsh's interviewing page describes the 60-minute interview as run by the hiring manager)
**Round:** the Outage Hour, 60 minutes, Friday

## How to use this pack

- Personas describe how a question is asked. Types describe what it is scoring. Every question carries both, so you can see coverage at a glance.
- Type key: **VAL** = past behaviour against Saltmarsh's published values; **EXP** = whether your background survives scrutiny; **JD** = a stated responsibility or requirement; **CO** = knowledge of the company and its strategy; **CASE** = a live problem from the actual role.
- Answer guidance is scaffolding, not a script. Where it quotes you, the words are yours from your message. Where it says answer slot, it is an instruction for the interview: answer the branch that is true, in your own words, or say plainly that the practice was not yours.

## Prep triage (about a day: interview Friday, built on Thursday)

1. **C1** — the highest-ROI rehearsal in the pack. Say it aloud three times, starting with "I haven't led a team."
2. **A1 and A3** — the tabletop structure and the player message. Time each to two minutes, aloud.
3. **C2 and D1** — your two sharpest limits: in-app purchases, and how the retention numbers were counted.
4. **B1 to B3** — pick or reject a story for each of the three values.
5. Read the full Project Larkspur announcement and Tobias's GDC 2026 talk (E2, reverse questions 1 to 3).

Everything else is insurance.

## The loop

| Fact | Source | Provenance |
|---|---|---|
| Every loop is a recruiter call, then the Outage Hour: one 60-minute interview with the hiring manager, a live-incident tabletop on a simulated outage during a live event, then a values conversation. There is no take-home | https://saltmarshgames.com/careers/interviewing (fetched) | [grounded] |
| Published values: Players Before Plans; Ship the Patch Not the Promise; Leave the Build Greener | https://saltmarshgames.com/values (fetched) | [grounded] |
| September 2026: Project Larkspur moves Tidepool Tactics and Lantern Row to a season-pass model with one shared events calendar from February 2027, and retires per-title event teams in favour of a single live-ops group | https://saltmarshgames.com/news/project-larkspur (search snippet only, page not fetched) | [grounded] |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title, not an events calendar across two titles, and the words stay there: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's "two of our mobile titles" makes a probe on competing demands for the same slot likely. If two things ever competed for one slot in your calendar, say how it was settled and what part was yours; if that never arose, say so plainly and describe how the weekly calendar ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not say which teams the calendar involved. Answer slot: if the content drops needed design, art, engineering or community input, say which and what part of the coordination was yours; if they did not, or it was someone else's, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your material says presenting monthly numbers, not a post-event review and not owning KPIs, and the words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's word "own" makes a probe on who chose what the numbers showed likely. If any of that was your choice, say what and why; if the numbers or their definitions came from elsewhere, say so plainly and stay with presenting them |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | transferability | Same artifact, different verb: your material says wrote, not manage. Words: "I wrote the release checklist our QA team still uses." Answer slot: if you ran the checklist with QA on releases, say how, in your own words; if QA ran it themselves once it was written, or running it was not yours, say so plainly and stay with having written it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | discovery | Your material does not say whether the title was live-service or which of the four years it covered. The requirement is a length of experience, not a gate. Answer slot: if the title kept shipping updates to players after launch, say so and which years that covered; if it was not live-service, or only some years were, say which plainly |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it, so expect a probe. Lead in the quote's own terms: you ran it, weekly, for two years, for the main title |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | No gap on the wording, but nothing inspected behind it, so expect a probe on how the numbers were counted (D1). Lead with the quote's own terms: you presented them, monthly, to the studio head |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | low | [grounded] | transferability | A written document a team still uses is adjacent; your material does not show other writing. Words: "I wrote the release checklist our QA team still uses." Answer slot: if you wrote anything players or other teams read, say what; if you did not, say so plainly and stay with the checklist |
| F9 | Leading a team — the JD asks for none; named because you stated it | "Never led a team" — your message | none | [generic] | capability | A gap wording cannot close, and you have said so. Words: "I haven't led a team." Then what you would do in the role, said as a plan and never as a past |
| F10 | Experience with in-app purchases — derived from the JD's "KPIs it reports" and the Project Larkspur season-pass news; the JD names no monetization requirement | "never worked on a game with in-app purchases" — your message | none | [inferred] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past |

## Reading the interviewer

| Signal | What it shows | Source | Provenance | What it means for you |
|---|---|---|---|---|
| Role | Head of Live Operations at Saltmarsh Games | GDC 2026 talk listing, https://talks.gdconf.example/2026/patch-notes-are-a-promise (search snippet only) | [grounded] | He owns the function you would join, so he scores both the tabletop and the fit |
| Earlier career | Previously a QA lead at a console studio | same listing | [grounded] | Release discipline is native language to him; your release-checklist sentence (F4) is the natural bridge to his world |
| Published argument | "A live team is judged by how often its patch notes describe what actually shipped" — talk title: Patch Notes Are a Promise | same listing | [grounded] | Expect precision probes: what you said, what happened, and what was yours. It echoes the value Ship the Patch Not the Promise |

Mirror opportunity, vocabulary and not a shared path: he came up through QA, and your sentence is "Wrote the release checklist our QA team still uses" (F4). Use it at that scope. Public footprint only; the listing came from a search snippet, so read or watch the talk before Friday.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | The tabletop: a simulated outage during a live event | Highest. The interviewing page names the tabletop as the first half of the hour, and a hiring-manager round leans this way | Clarify, then objective, roles, decisions, player message, record. Say the structure aloud |
| B. Values/Behavioral | The second half of the hour, against the three published values | High. The interviewing page names a values conversation | Map a story only where one of your sentences carries it; where none does, say so plainly and give the nearest thing or how you would handle it |
| C. Skeptic | Probing the gaps: team leadership, in-app purchases, two titles, which years count | High. Hiring-manager prior plus F2, F9 and F10 in the snapshot, and an interviewer whose public argument is about claims matching what shipped | Rehearse C1 until it is boring: plain acknowledgment, hold what the quotes carry, concede one limit specifically |
| D. Data-Driven Prober | How the retention numbers were counted, what the calendar was made of | Medium. The JD names retention metrics and KPIs; nothing in the footprint says he is data-led, so the weight is not raised | Know what you can and cannot say about how each number was counted; say plainly when you do not know |
| E. Conversational | The opener and the "what do you know about us" question | Medium-low. Any hour opens this way; the recruiter call is a separate step on the page | A 90-second arc built only from your four sentences |
| F. Pressure | Time-boxed or interrupting follow-ups during the tabletop | Low. The loop page does not say the tabletop is time-boxed, so this is an inference from the format | Pause, restate, anchor in what you said, hold through two follow-ups |

Weights rest on Saltmarsh's own interviewing page, not on an archetype. Depth follows weight: A has 5 questions, B and C 4, D 3, E and F 2.

## Question banks

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It is an hour into a live event and players report they cannot load the game. You are the producer on call. What do you do first?" | CASE | [inferred] | Think aloud in this order: what you need to know first (what is affected, which players, since when, whether event progress or rewards are at risk, who is already on it); the objective, which is protecting players before the schedule; who you pull in and for what (engineering to diagnose, QA to confirm, community to tell players); the decisions you would put to the team (pause, extend or carry on); what players are told; what you record for the post-event review. Challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | The page names a tabletop on a simulated outage during a live event; the scenario here is derived from that description, hence inferred. CASE because it scores structure under a live problem |
| A2 | "From February 2027 two titles share one events calendar and per-title event teams fold into one group. Two events want the same weekend. How do you decide?" | CO | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Clarify what each event has already promised players and what each depends on; state the objective (players first, in the company's own words: when the calendar and the players disagree, the players win); lay out options (move one, stagger, shrink one) and the criteria that pick between them; say who decides and who is told. Answer slot: the JD's calendar responsibility makes a probe on your own calendar likely. If two things ever competed for one slot in your calendar, say what happened and what part was yours; if that never arose, say so plainly and answer from the structure | The Larkspur news is current strategy and this is the pack's strategy question; F1 is where the collision probe presses. CO delivered as CASE |
| A3 | "You have five minutes to write the message to players about the outage. What does it say and what does it leave out?" | JD | [grounded] value text: "we announce what is built, not what is hoped" | Say it as you would write it: what is known now, what players should do, what the team is doing, when the next update comes. Leave out guesses about cause and any promised time you cannot back, which is the company's own second value. Keep it short and plain. The question needs no claim about your past, so the guidance makes none | Scores the JD's clear written communication (F8) in the format the loop uses, and tests the value the interviewer's own talk is about. JD content, CASE delivery |
| A4 | "The event ended and retention dipped against the week before. Walk me through the post-event review." | JD | [generic] | Clarify what dipped (which players, which days, against which baseline); separate the event from anything else in the window; give hypotheses and the check that would split them; say what the review reports, to whom, and what changes for the next event. Name the weakest assumption in your own diagnosis before he does. The question needs no claim about your past, so the guidance makes none | F3 and F7 are the requirements this covers; a live diagnosis shows whether you can own the review. JD content, CASE delivery; generic because it is a pattern for the problem |
| A5 | "A hotfix and a scheduled event update both want Thursday's release slot. How do you and QA decide what goes?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | Structure: what each risks for players, what QA can confirm in the time, how each rolls back, what the checklist needs before either ships; the decision is made with QA, then the teams are told and it is recorded. The checklist is yours at the scope of one sentence: "I wrote the release checklist our QA team still uses." Answer slot: the JD's "manage the release checklist with QA" makes a probe on running it likely. If you ran it with QA on releases, say how; if QA ran it themselves once written, or running it was not yours, say so plainly and stay with having written it | F4 is the evidence for the checklist requirement; this tests it as a decision rather than a document. JD content, CASE delivery |

### B. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Value: Players Before Plans. Selection scaffold: pick a time the schedule said one thing and what players needed said another; it needs a named stake, a decision you were part of, and what happened to the schedule. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I ran the weekly content-drop calendar for our main title for the last two years", or say how you would handle it | The first published value; no sentence of yours carries a story for it (F6 is the nearest evidence), so this is a scaffold, not a story map |
| B2 | "Tell me about a time what you announced and what shipped were different." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Value: Ship the Patch Not the Promise. Selection scaffold: pick a time what was said and what went out differed; it needs what was said, what shipped, how others found out, and what changed afterwards. If none comes to mind, say so plainly, then give the nearest thing your material carries, "I wrote the release checklist our QA team still uses", at that scope, or say how you would handle it | The interviewer's public talk is about this idea (see Reading the interviewer), so rehearse it first among the values; F4 is the nearest evidence only |
| B3 | "Tell me about a time a release taught you something that changed how you worked." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Value: Leave the Build Greener, whose text says every release leaves the checklist better than it found it. Story-mapped on F4, with only the beats the quote states: you wrote the checklist, and QA still uses it. Answer slot: the value raises a probe on how the checklist improved. If it changed after releases, say what changed and why, in your own words; if it did not change, or the changes were not yours, say so plainly and stay with having written it and QA still using it | F4 is the one sentence of yours that touches this value; the value text itself raises the probe |
| B4 | "Tell me about a time you told a team or a manager something they did not want to hear." | VAL | [generic] | Selection scaffold: pick a time with a named stake, what you said, how it landed, and an intact relationship afterwards. Choose one where the hard truth actually landed. If none comes to mind, say so plainly and say how you would handle it | A standard values-conversation stem; generic because none of your sentences carries it and the pack will not supply one |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "This role coordinates design, art, engineering and community across two titles, and you have not led a team. Where does your experience stop?" | JD | [grounded] "Never led a team"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses" | **Highest-ROI prep in this pack.** Hold-then-concede. Open with the plain acknowledgment: "I haven't led a team." Hold what your quotes carry: "I ran the weekly content-drop calendar for our main title for the last two years" and "I wrote the release checklist our QA team still uses." Return to those two sentences through two follow-ups; never add to them. Concede one limit specifically: your material does not show which teams the calendar involved. Answer slot: if the content drops needed design, art, engineering or community input, say which and what part was yours; if not, or it was someone else's, say so plainly and stay with the calendar and the checklist. Close with the plan, said as a plan: what you would ask each team and read in your first weeks | F9 and F2 are the largest open rows and this question presses both; it will arrive in some form, so a calm, rehearsed answer changes the interview. JD content, Skeptic delivery |
| C2 | "Our titles are moving to a season-pass model. How would you describe your experience with in-app purchases?" | JD | [grounded] "never worked on a game with in-app purchases" | Say it first and plainly: "I haven't worked on a game with in-app purchases." Do not dress up adjacent work; your material says nothing that reaches it. Then a plan, said as a plan: you would ask which measures the post-event review reports for the season pass, how each is counted and who owns each, and read recent reviews first. Do not claim to know the season-pass details beyond what the announcement says | F10 is a stated gap and Larkspur makes it live; second only to C1 in how likely it is to be asked |
| C3 | "Why live operations at a mobile studio, and why now?" | EXP | [generic] | Say your actual reason in your own words; this pack has none from you and supplies none. Name one specific thing about this role or Saltmarsh's published values that draws you, and keep it to what is true for you | Skeptic stem on motivation; the answer is yours alone |
| C4 | "The role asks for three years producing live-service games or apps. Which of your years count?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years" | Say what you have: "4 years as an associate producer at a puzzle-game studio", and the last two ran the weekly content-drop calendar. Answer slot: if the title kept shipping updates to players after launch, say so and which years that covered; if it was not live-service, or only some years were, say which plainly. Count only the years your sentences cover | F5 is a discovery gap; years requirements are often screened literally, so the answer must be exact. JD content, Skeptic delivery |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the monthly retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Defend-the-number slots, each in your own words: how the numbers were counted; what they were sensitive to; the assumption behind them you would defend least; and which part was yours. If you do not know how a figure was counted, say so plainly instead of reconstructing it. Name your weakest assumption before he does. The pack supplies no definition | F7 is the only metrics evidence and nothing inspected stands behind it, so this is where it gets tested |
| D2 | "What would make you distrust a retention number?" | JD | [generic] | A short list, then the first check: a window that contains a release or an outage, a small group, a change in how the number is counted between months. Say which you would check first and why. The question needs no claim about your past, so the guidance makes none | Tests metric judgement without leaning on F7; generic because it is a pattern |
| D3 | "Walk me through how you ran the weekly content-drop calendar." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Story-mapped on F6 with only the beats the quote states: weekly, the main title, two years. Answer slot: the JD's coordination line makes a probe on who fed into each week likely. If other teams fed into the calendar, say which and what you did with their input; if it was mostly you, say so plainly and describe how you ran it | F6 is the core evidence for the role's central responsibility; EXP because it tests what was actually yours |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc built only from those four sentences: four years as an associate producer at a puzzle-game studio; the last two running the weekly content-drop calendar for the main title; writing the release checklist QA still uses; presenting the monthly retention numbers to the studio head. End on why this role, in your own words. Let him draw the inferences | The opener is scored whatever its register; C3 is the reason-for-this-role slot |
| E2 | "What do you know about where Saltmarsh is heading?" | CO | [grounded] https://saltmarshgames.com/news/project-larkspur (search snippet) | Say what the announcement says: Tidepool Tactics and Lantern Row move to a season-pass model with one shared events calendar from February 2027, and per-title event teams are retired in favour of a single live-ops group. Say what you do not know. The pack saw only a snippet, so read the full page before Friday | The company-strategy item most candidates will not reach; ties to A2, C2 and reverse questions 3 and 4 |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you for this job?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head"; "never worked on a game with in-app purchases" | Pause, restate, then three sentences in your own words: "I ran the weekly content-drop calendar for our main title for the last two years. I wrote the release checklist our QA team still uses. I presented the monthly retention numbers to the studio head." If pressed, concede the in-app-purchase limit yourself before he does: "I haven't worked on a game with in-app purchases." Hold the rest | Pressure stem; the concession shows you know your own edges (F10) while the three sentences are F6, F4 and F7 |
| F2 | "That calendar, how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Hold on the sentence: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if some parts were set or supplied by others, say which and which parts were yours; if it was yours throughout, say so plainly and add nothing beyond the sentence | An attribution probe is likely from an interviewer whose public argument is that claims match what shipped; F6 is what it presses |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two titles (F1) | A2, C1, D3, F2 |
| Coordinate design, art, engineering and community teams (F2) | A1, C1, D3 |
| Own the post-event review and KPIs (F3) | A4, D1, D2 |
| Manage the release checklist with QA (F4) | A5, B3 |
| 3+ years producing live-service games or apps (F5) | C4, E1 |
| Experience running a content calendar (F6) | D3, F1, F2 |
| Comfortable with player-retention metrics (F7) | A4, D1, D2 |
| Clear written communication (F8) | A3 |
| Leading a team, not in the JD (F9) | C1 |
| In-app purchases, not in the JD (F10) | C2, F1 |

## Values cheat sheet

| Value (official name) | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Players Before Plans | When the schedule and what players need conflict, players come first | No sentence of yours carries a story here. Selection scaffold at B1, ending in its honest branch: say so plainly, then give the nearest thing your material carries or how you would handle it |
| Ship the Patch Not the Promise | Announce what has been built, not what is hoped for | No sentence of yours carries a story here. Selection scaffold at B2, ending in its honest branch |
| Leave the Build Greener | Every release should leave the codebase and the checklist better than it was found | F4: "Wrote the release checklist our QA team still uses", at that scope, with the answer slot at B3 on how the checklist changed |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "You came to live operations from QA lead at a console studio. What from QA do you still lean on when an event goes wrong?" | Ties to his own path and invites a story rather than an interrogation; it also shows you read the talk listing |
| 2 | "Your GDC talk argues a live team is judged by how often its patch notes describe what actually shipped. How does the team measure that today, and where does it show up in the post-event review?" | Shows you read his published argument and connects it to the KPI responsibility in the JD |
| 3 | "Under Project Larkspur, per-title event teams fold into one live-ops group. Where does this role sit in that group and who does it work with day to day?" | Current-strategy question that also settles the coordination picture in F2 and F9 |
| 4 | "How is a new producer brought up to speed on the season-pass side of the post-event review?" | Raises your known gap yourself and asks about the ramp, so the plan you gave at C2 becomes a shared one |
| 5 | "What does a strong first post-event review from this role look like to you?" | Asks for the bar you will be judged against and shows you think in terms of the review as a deliverable |
| 6 | "Which part of the Outage Hour do candidates most often find hardest?" | Invites him to coach; low risk and tells you what he weights |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team, or led cross-functional teams | Negative you stated, F9 | The plain acknowledgment: "I haven't led a team." No slot |
| Has worked on monetization or a game with in-app purchases | Negative you stated, F10 | The plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot |
| Ran the live-events calendar across two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says a weekly content-drop calendar for your main title |
| Owned the post-event review and the KPIs | Inflated form of F3 | F3's quote at its own scope: presenting the monthly retention numbers to the studio head. The slot at A4 and F3 stays inside presenting |
| Managed the release checklist with QA | Inflated form of F4 | F4's quote at its own scope: wrote the checklist QA still uses. A5's slot stays inside having written it |
| Has four years of live-service production | Inflated form of F5 | F5's quotes at their own scope: four years as an associate producer, and the last two running the weekly calendar. C4's slot asks only which years the updates covered |

## Sources

Provided documents: the job description pasted in your message; your background as stated in your message. No CV file was provided. No dossier was present.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet and B1 to B3. Returned https://saltmarshgames.com/values and the page was fetched |
| 2. `Saltmarsh Games interview process live operations producer` | yes | Loop structure and every persona weight. Returned https://saltmarshgames.com/careers/interviewing and the page was fetched |
| 3. `Saltmarsh Games strategy news mobile` | yes | A2, C2, E2 and reverse questions 3 and 4. Returned https://saltmarshgames.com/news/project-larkspur; snippet only, page not fetched, dated September 2026 |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | Interviewer read and reverse questions 1 and 2. Returned https://talks.gdconf.example/2026/patch-notes-are-a-promise; snippet only, page not fetched |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

L2 (deep research) was not run.

## Upgrade menu

- What the recruiter told you about the Outage Hour (the scenario, or whether anyone besides Tobias joins) → reweights banks A and F and may replace A1
- Answers to the answer slots, said outside a drill: which teams fed your calendar (F2), whether the title was live-service and which years (F5), what the retention numbers counted (F7) → those rows regenerate with your words in the evidence column
- The release checklist itself, or a sample monthly retention deck → inspectable artifacts that could lift F4 and F7 from medium
- The full Project Larkspur page and the transcript or slides of Tobias's talk → A2, E2 and the interviewer read move from snippet to read source
- A deeper research pass, up to 6 further searches and 2 further fetches, several more minutes → a grounding brief on strategy, a deeper interviewer footprint and recent organisation context; say the word and I will run it
- A `tuesday-dossier.md` from an earlier engagement → verified evidence and prohibited claims for the answer cells; this pack stands without one
