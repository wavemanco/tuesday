# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Date of interviews:** 5 December 2026 (prepared 26 November 2026)
**Loop (from the recruiter's email):** three rounds, so this pack is in loop mode: one shared fit snapshot, then a mini-pack per round.

| Round | Who | Length | Shape |
|---|---|---|---|
| 1 | The recruiter (name not given) | 30 min | Screen |
| 2 | Head of Member Services, your would-be manager (name not given) | 45 min | Mostly behavioural |
| 3 | Panel of two branch managers (names not given) | 60 min | Includes a 20-minute case on a complaint escalation; also the values round, scored against the four values |

Interviewer names are not assigned yet, so there is no interviewer read. Persona weights rest on the roles and on the recruiter's own description of each round.

## How to use this pack

Personas describe how a question is asked; types describe what it is scoring. Every question carries one of each.

| Type | What it is scoring |
|---|---|
| VAL | Whether past behaviour shows Ashgrove's published values |
| EXP | Whether what you say you did survives follow-up, and exactly what was yours |
| JD | The job's stated requirements, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem from the actual role, reasoned aloud |

Guidance is scaffolding, not a script. Where a cell says "answer slot", it is an instruction for the interview, not a question for me: give the answer from your own experience, or say plainly that it was not yours or did not exist. Rehearse only what you actually did.

## Prep triage (nine days: 26 November to 5 December)

All three rounds fall on one day, so the register changes within hours: friendly screen, behavioural conversation, then a panel that scores values and runs a case. Do these in order.

| When | Do | Why |
|---|---|---|
| Days 1 to 2 | Say D1 aloud until it is boring, including the plain acknowledgments in B1 and B3 | It is the objection this pack ranks highest; a rehearsed, non-defensive answer changes round 2 and returns in round 3 |
| Days 1 to 3 | Write your own answers to the slots in B2, B4, C1, D1 and E1, and send them to me | Each answer you state becomes quoted material and upgrades the rows it touches |
| Days 3 to 5 | Choose one real story for each of the four values (G1 to G4) and time each at 90 seconds | The panel scores against the values; where your quotes carry no story, only you can supply one |
| Days 6 to 7 | Run H1 aloud twice at 20 minutes, clarifying first | The case is a third of the panel hour |
| Day 8 | Settle your real answers to A4 to A7 | The recruiter will ask all four; nothing in your material states them |
| Day 9 | One light run of D1 and H1, then stop | |

Everything else is insurance.

## Fit snapshot (shared across all three rounds)

Source for requirements: the JD you pasted. Evidence is your own words from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | presentation | Your sentence already carries the years. Say it in its own terms, six years in retail banking, the last three as a branch supervisor, and let the interviewer map it to "customer operations"; do not relabel it yourself. A CV line with nothing inspected behind it, so expect a probe on what the work covered |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | Your words: "I handled the branch's formal complaints log." The material does not show what the log was kept under. Answer slot: expect a probe on what governed the log; if it followed set rules or time limits you worked to, name them in your own words and how you kept to them; if it followed none you can name, or you did not work to them, say so plainly and stay with the log you handled |
| F3 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your words stay at the branch's log. The material shows that log, and does not show the process beyond it or any work across branches. Answer slot: if you took part in any step before or after the log, say which and what you did, in your own words; if you did not, or none was yours, say so plainly and stay with the log you handled |
| F4 | "and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked in a contact centre." Then how you would learn it, said as a plan in your own words and never as a past |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your words: "I built the monthly complaints spreadsheet our regional manager uses." The material does not show what the sheet counted. Answer slot: expect a probe on what it showed; say what it counted in your own words; if you do not know how a field was counted, say so plainly; if part of it was set by someone else, say which part and return to what you built |
| F6 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your sentence says spreadsheet; the JD names a tool. Answer slot: say which tool you built it in, in your own words; if you used others as well, say so; if it was not the one the JD names, say so plainly and say how you would close that distance, as a plan |
| F7 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your words: you "trained new tellers on our escalation script." The JD says supervisors; your sentence says tellers, and the words stay at tellers. Answer slot: if you have guided anyone else on an escalation, say who and what you did; if you have not, say so plainly and stay with training the script |
| F8 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Nothing in your material speaks to this. Answer slot: if you have worked with anyone building digital or app journeys for members, say what and which part was yours; if you have not, say so plainly and say what you would ask a digital team first |
| F9 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | Words: "I've never presented to anyone above regional level." The material does not say whether Ashgrove would count regional level as senior, nor what presenting at regional level involved. Answer slot: if you have presented at regional level, say what and to whom; if not, say so plainly. Then your plan for a first senior presentation, in your own words |

No row is a gate: the JD sets no authorisation, licence, location, schedule or pay term, and the years requirement is graded as experience, not as a gate.

## Grounding brief (from the July 2026 strategy brief the recruiter sent)

You gave me four points from the brief, about four months old. I have not read the brief itself, so nothing here goes beyond those four points.

| Brief point | What it may mean for this role | Provenance |
|---|---|---|
| "move 40% of member service to digital channels by 2028" | The JD's self-service line (F8) sits on the strategy's main shift; expect complaints to be discussed as a digital as well as a branch issue | [grounded] for the point; [inferred] for the implication |
| "consolidate eight branches into five hubs over 2027" | The complaints process you would own spans a changing branch network; the panel are branch managers whose branches may be affected | [grounded] for the point; [inferred] for the implication |
| "launch a small-business lending product in Q1 2027" | A new product may bring new kinds of complaint; low likelihood of being central in these rounds | [grounded] for the point; [inferred] for the implication |
| "the main competitive pressure is app-only banks" | Self-service quality is framed as a defence against app-only banks; a member-owned lender is likely to talk about service as its edge | [grounded] for the point; [inferred] for the implication |

Use this to sound current, not to recite it. One point, with your own reading of what it means for how members complain, beats all four listed.

---

# Round 1: the recruiter (30 minutes)

### Persona table, round 1

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly walk-through of your background, motivation, then pay, notice, location, reason for leaving | High: a recruiter screen's prior is conversational plus logistics, and the recruiter's own note gives this round 30 minutes alone | A 90-second arc built only from your quoted beats (A1); decide the four logistics answers beforehand (A4 to A7) |
| Skeptic (light) | Knockout checks on the JD's named requirements: contact centre, regulated complaints, senior leaders, Excel | Medium: each is a JD line your own sentences leave open or state as absent (F2, F4, F6, F9) | Say the plain acknowledgment once, then move to a plan; do not stretch (B1 to B4) |

### Question bank, round 1

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The role asks for 4+ years in financial-services customer operations. Give me the short version of where yours comes from." | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Story-mapped on F1: the two beats the quote states, six years in retail banking and, within them, the last three as a branch supervisor. Say them in your own words and stop. Answer slot: if asked what the work involved day to day, answer from your own experience; if part of the role's wording does not describe your work, say so plainly and describe what your work was | F1 is the one requirement with a years test, so it is screened first; JD because it scores a stated requirement |
| A2 | "What has drawn you to Ashgrove and to this role?" | CO | [grounded] | The reason is yours and the pack supplies none. Choose from what you have actually read: the four published values, a line of the JD, or the July 2026 strategy points. Say the one thing that genuinely pulls you and why, in two or three sentences. If what draws you is not on the page, say that plainly instead | Motivation consistency is the recruiter's core check, and A7 and D3 must agree with it; CO because it tests homework at light depth |
| A3 | "What have you taken from our 2026 strategy about where member service is heading?" | CO | [grounded] | Bring one or two of the points you were given: 40% of member service on digital channels by 2028, eight branches into five hubs over 2027, small-business lending in Q1 2027, app-only banks as the main pressure. Say what you read each to mean for how members complain or get help, offered as your reading. Do not recite all four and do not criticise the plan. The question makes no claim about your past, so the guidance makes none | The recruiter sent you the brief, so a probe on it is likely; CO because it is the strategy question |
| A4 | "What are you looking for on salary?" | JD | [generic] | Logistics slot. Nothing in your material states a figure, and the pack supplies none. Give your own number, or ask for the role's band first. If asked what you earn now: "I'd rather focus on the range for this role." | A recruiter screen asks pay; JD because it concerns the listed job's terms |
| A5 | "What's your notice period?" | JD | [generic] | Logistics slot. Give your actual notice period, as your contract states it. If you do not know it, say you will confirm it | Same as A4 |
| A6 | "Where and how often could you work for this role?" | JD | [generic] | Logistics slot. State where and how often you can work, in your own words. The JD you pasted does not state the role's location or pattern, so ask the recruiter to confirm both before you commit | Same as A4 |
| A7 | "Why are you looking to move?" | EXP | [generic] | Logistics slot. Say your actual reason in one or two sentences, covering what you are moving toward as well as what you are leaving, and keep it consistent with A2. Do not criticise your current employer | A screen checks that the reason for leaving matches the reason for applying; EXP because it concerns your own history |
| B1 | "The role spans the contact centre. How do you see your background fitting that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Hold-then-concede. Your sentence states the limit, so say it once without apology: "I've never worked in a contact centre." Then your plan, in your own words: what you would want to learn first and from whom. The pack gives no bridge from branch work to contact-centre work, because none of your sentences carries one. If pressed twice, return to the acknowledgment and the plan and add nothing | F4 is a stated gap and the likeliest knockout check; JD because it scores a stated requirement; Skeptic delivery |
| B2 | "The role asks for experience handling regulated complaints. Where does your background meet that?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Your words: "I handled the branch's formal complaints log." Answer slot: expect a probe on what governed the log; if it followed set rules or time limits you worked to, name them in your own words and how you kept to them; if it followed none you can name, or you did not work to them, say so plainly and stay with the log. Do not restate the log in the JD's words unless you can say what governed it | F2 is the JD's second requirement and your sentence does not show what the log was kept under; JD tag |
| B3 | "Have you presented to senior leaders before?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Your own words: "I've never presented to anyone above regional level." Answer slot: if you have presented at regional level, say what and to whom; if not, say so plainly. Then a plan for a first senior presentation, in your own words, with no story added | F9 is a stated limit; a screen checks it directly; JD tag |
| B4 | "How comfortable are you with Excel reporting?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Your words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names a specific tool and your sentence says spreadsheet; say which tool you built it in, in your own words; if it was not the one the JD names, say so plainly and say how you would close that distance. Name only what you used | F6 is a mid-list requirement that is easy to leave unrehearsed; JD tag |

### Reverse questions, round 1

| # | Question | Why it lands |
|---|---|---|
| 1 | "Will the escalation case in the panel round be shared beforehand, or given on the day?" | Sizes your case prep and shows you are preparing for the hour you were told about |
| 2 | "Which parts of the JD matter most to the Head of Member Services?" | The one source who can reweight round 2 for you |
| 3 | "How is complaints handling split between the branches and the contact centre today?" | Shows you are looking at the exact seam your material is thin on |
| 4 | "Is there anything in the strategy brief that has moved since July?" | A freshness check on the one document your prep leans on, framed as care |
| 5 | "What happens after 5 December, and when would you expect to come back to me?" | Plain process; closes the screen well |

---

# Round 2: the Head of Member Services, your would-be manager (45 minutes, mostly behavioural)

### Persona table, round 2

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "Tell me about a time" prompts on coaching, escalation, reporting, working across teams | High: the recruiter says this round is mostly behavioural, which outranks the hiring-manager prior of Case plus Skeptic | One story per prompt where a quote carries one; otherwise a scaffold with its honest branch (C1 to C4). "We" for context, "I" for what you did |
| Skeptic | The scale and contact-centre gap, then senior presenting, then motive | High: a manager derisks gaps, and F3, F4 and F9 are the biggest in the snapshot | D1, the highest-ROI rehearsal in this pack: hold the quote, concede the limit exactly, state a plan |
| Data-Driven Prober | What the monthly spreadsheet counted | Medium: it is the one thing you built that the JD's reporting line points at (F5) | E1: know what it counted, and say plainly where you do not |
| Case / Strategist | A live problem on the role's own roadmap | Lower: the recruiter places the case in round 3, so this round's cases are lighter | F1 and F2: clarify first, structure aloud |

### Question bank, round 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you coached someone through an escalation." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F7, at its own scope: you trained new tellers on the escalation script. Those are the beats. Answer slot: the JD's coaching line makes a probe on a specific person likely; if a particular teller's handling comes to mind, say what you did and what changed, in your own words; if none does, say so plainly and describe how you took new tellers through the script. The JD says supervisors and your sentence says tellers; do not blur that | F7 is transferability and the likeliest place a coaching probe lands; EXP because it tests what was actually yours |
| C2 | "Tell me about a time you worked with a team outside your own to get something changed." | JD | [grounded] | No sentence of yours carries this (F8), so choose a story with these parts: a named other team, one specific thing that changed, and your own part in it. If no such time comes to mind, say so plainly, then say how you would approach working with a digital team on a self-service journey and what you would ask them first | JD line on digital teams has no evidence behind it, so the scaffold is honest about that; JD because it is the stated requirement |
| C3 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | A selection scaffold. Choose a time with a named stake, where you said it plainly, and where the truth actually landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry or how you would handle it. Do not supply an ending that did not happen | A stock behavioural probe, and it rehearses the senior-audience gap from another side; VAL because it scores behaviour, not the company's values by name |
| C4 | "Tell me about a time you explained a report or figure to someone senior." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Your quote carries that you built the sheet and that your regional manager uses it; it does not say you explained it to anyone. Answer slot: if you ever walked the regional manager through what it showed, say what and how it went, in your own words; if you did not, say so plainly and stay with what you built | Bridges F5 and F9; EXP because it tests what was yours |
| D1 | "Your complaints work has been on the branch's log. This role covers every branch and the contact centre. Walk me through how you would step up to that." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "Never worked in a contact centre, and I've never presented to anyone above regional level." | **The highest-ROI rehearsal in this pack.** Hold only what the quote carries: "I handled the branch's formal complaints log." Concede exactly, in your words: "I've never worked in a contact centre." Then a plan, said as a plan: what you would learn in the first weeks, from whom, and what you would ask before changing anything. Likely follow-ups: how you would learn the contact-centre side, then what you would do first; answer both by returning to the plan, never by adding to your past. The limit, named before it is asked: your material shows the branch's log and not the process beyond it. Answer slot: if you took part in any step before or after the log, say which; if none, say so plainly | F3 and F4 are the gap against the JD's headline line, and the Head of Member Services is the person who would carry that risk; JD because it scores the stated requirement; Skeptic delivery |
| D2 | "You would present complaint trends to senior leaders every month. What is your starting point?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Your own words: "I've never presented to anyone above regional level." Then a plan for the first one, in your own words: what you would want to know about the audience, and who you would ask to review it beforehand. Answer slot: if you have presented at regional level, say what and to whom; if not, say so plainly | F9 returns here in manager form; JD tag |
| D3 | "Why move from supervising a branch to this role, and why now?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | The quote gives two beats: six years in retail banking, the last three as a branch supervisor. The reason for moving is yours; say in your own words what you are moving toward, and keep it consistent with A2 and A7. If a crisp reason does not exist yet, find it before 5 December | A manager tests motive for stepping out of a supervisor role; EXP because it concerns your own path |
| E1 | "Walk me through the monthly complaints spreadsheet you built. What did it show?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Beats the quote states: you built it, it is monthly, it is about complaints, and your regional manager uses it. Answer slot: expect a probe on what it counted and how; say what it counted in your own words; if you do not know how a field was counted, say so plainly; if part of it was set by someone else, say which part and return to what you built | F5 is where reporting claims get checked; EXP because it tests attribution |
| F1 | "Members tell us they had to explain the same complaint twice: once at a branch, once to the contact centre. What do you need to know first?" | CASE | [generic] | Clarify before structuring: what the member asked for, where it began, what they were told, what the records show. Then objective, the approach, what you would measure, the risks. Think aloud; challenge one premise respectfully, such as whether this is a handoff gap or a record gap. The pack makes no claim about your past here. Speaking plainly matters: Ashgrove's own value says "if a member needs it explained twice, we wrote it wrong" | A live problem on the role's own seam (branch and contact centre); a pattern for the problem, not Ashgrove's actual issue |
| F2 | "The strategy targets 40% of member service on digital channels by 2028. What happens to complaints as service moves to self-service, and what would you want measured?" | CASE | [grounded] | Structure aloud: who uses self-service, where it fails, how a failed journey becomes a complaint, what you would count. Mention the app-only-bank pressure only if it helps. Answer slot: if you have worked with a digital team on anything similar, say what and which part was yours; if not, say so plainly and stay with the plan and the questions you would ask | Strategy-grounded CASE; F8 has no evidence, so the honest answer is a plan |

### Reverse questions, round 2

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would a strong first six months look like, and what would you want the monthly complaints report to show by then?" | A manager reads this as ownership of the outcome and the reporting line |
| 2 | "Where does complaints handling work well today, and where do members say it does not?" | Echoes Own the Fix without quoting it; invites the real problems |
| 3 | "How do the digital teams use complaints data now?" | Opens the F8 gap as curiosity |
| 4 | "Would you want me learning the contact-centre side or the branch side first?" | Turns the F4 gap into a plan you are asking the manager to shape |
| 5 | "How does the monthly report reach senior leaders today, and who presents it?" | Informs your D2 plan and shows you are thinking about the audience |

---

# Round 3: panel of two branch managers (60 minutes, including a 20-minute escalation case; also the values round)

### Persona table, round 3

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | One prompt per value, scored against Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix | Highest: the recruiter says the panel is the values round and scores against the four values | G1 to G4 and the cheat sheet below |
| Case / Strategist | The 20-minute complaint-escalation case | High: it is stated in the process and fills a third of the hour | H1 to H3: clarify, structure aloud, challenge one premise |
| Peer Evaluator | "What do you need from me?"; the seam between your role and the branches | Medium, [inferred]: your role coaches branch supervisors, whom these managers line-manage; names and exact remits are unassigned, so this is weighted from the roles | I1 and I2: reciprocity first; propose seam principles, not a claim to know the seam |
| Skeptic | The scale gap returning in collegial packaging | Low to medium: no senior challenger is named, but D1's objection travels with you | D1 again |

The panel is two branch managers, both of the same role, so I have blended their personas and not split them by member.

### Question bank, round 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Members First, Always: tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] | No sentence of yours carries a decision of this kind, so choose a story with these parts: a named decision, what you set aside or what it cost someone inside the organisation, and what the member experienced. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry or how you would handle it. Do not supply an ending that did not happen | Each published value needs a VAL question; the panel scores against it |
| G2 | "Plain Words: tell me about a time you explained something so it only needed saying once." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F7 at its own scope: you trained new tellers on the escalation script. Answer slot: the value's test is whether something had to be explained twice; if you ever changed how something was worded or taught because it did, say what and why, in your own words; if you did not, or it was not yours, say so plainly and stay with training the script | The one value where a quoted sentence of yours has a beat to carry |
| G3 | "Neighbours, Not Numbers: tell me about a time you thought about what a decision meant for your branch's town." | VAL | [grounded] | No sentence of yours carries this. Choose a decision with a named local effect and say what you weighed against the numbers. If no such time comes to mind, say so plainly, then say how you would weigh it. Do not comment on which branches should or should not change | VAL; the question also sits near the strategy's branch consolidation, so keep to members, not to the plan |
| G4 | "Own the Fix: tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Your sentence says you handled the log; it does not say any problem was kept until solved. The log is the first place to look for an instance. Answer slot: if a particular complaint comes to mind that you kept hold of until it was resolved, say what happened and which part was yours; if none does, say so plainly, then describe what keeping hold of a problem would mean at this role's scale | VAL; the likeliest story source is your own log, and the pack will not write the ending |
| H1 | "A member's complaint was turned down at the branch and again by the contact centre. They have written to say they will take it further. It lands with you. What do you do?" | CASE | [generic] | A rehearsal pattern, not their case. Clarify first: what the member is asking for, what they have been told and by whom, what the records show, where the case sits and what clock applies, which you ask the panel about and do not assume. Objective: a fair answer in plain words, with one named owner. Approach: take it on, speak to the member, review both decisions, decide, explain, record, follow up. Risks: deadlines, tone, consistency with similar cases. Think aloud; challenge one premise, such as whether both refusals applied the same rule. No claim about your past | The recruiter says 20 minutes of the hour is a case on a complaint escalation |
| H2 | "A branch supervisor escalates a complaint to you, but the branch manager thinks it should not have been escalated. What do you do?" | CASE | [generic] | Facts before sides: what was decided, on what basis, what the member needs. Give principles for the seam: the branch's judgment is respected, the process has one owner, and disagreements are settled on the facts and explained to both. Hold your position through two follow-ups, then concede exactly what you do not yet know. No claim about your past | The panel are branch managers, so this tests whether you respect branch judgment while owning the process |
| H3 | "If this case went into your monthly report, what would the senior team see?" | CASE | [grounded] | Structure only: what you would record from the case and how you would show it alongside the month's wider picture. Say plainly what you would not conclude from a single case. Link to E1 only if you can say what your own spreadsheet counted | Connects the case to the JD's reporting line (F5) |
| I1 | "Our supervisors are busy. What do you need from me, and what will I notice when you are doing the job well?" | JD | [generic] | Reciprocity first: what you would offer a branch, in your own words, then what you would need, such as time with supervisors and honest feedback on how the escalation route works. Propose principles for the seam rather than claiming to know it. No claim about your past | Peer Evaluator; JD because it scores the coaching line (F7) |
| I2 | "How do you handle disagreeing with someone at my level when you have no authority over them?" | VAL | [generic] | A principle with spine and tact: state the disagreement plainly, ask what they are weighing, agree what would settle it, and accept the outcome. If a real example comes to mind, tell it as it happened; if none does, say so plainly and stay with the principle | Peer Evaluator, a behavioural check on partnership |
| J1 | "Eight branches become five hubs over 2027. What should a member's complaint experience look like in a town where the branch has gone?" | CO | [grounded] | Do not take a position on the consolidation. Stay with the member: whoever receives a complaint keeps hold of it, it is answered in plain words, and the town does not have to explain itself to a call centre. Ask what the panel already knows about where members would go. No claim about your past | Branch managers have a stake in the plan, so expect strategy questions to come from the branch side; CO because it is the strategy question |

### Values cheat sheet (round 3)

| Value (Ashgrove's name) | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Selection scaffold, G1: a named decision, what was set aside, what the member experienced; if none comes to mind, say so plainly, then give the nearest thing your material does carry or how you would handle it |
| Plain Words | If a member needs something explained twice, the wording was at fault | F7: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Slot as in G2 |
| Neighbours, Not Numbers | Each branch is part of its town | Selection scaffold, G3: a decision with a named local effect; if none comes to mind, say so plainly, then say how you would weigh it |
| Own the Fix | Whoever finds a problem keeps hold of it until solved | Selection scaffold, G4, pointing you first at your log (F2); if no case comes to mind, say so plainly |

Note, [inferred]: the strategy's digital shift and branch consolidation sit beside "Neighbours, Not Numbers", and the panel are branch managers. Keep your stories about members and towns, and do not argue with the plan.

### Reverse questions, round 3

| # | Question | Why it lands |
|---|---|---|
| 1 | "What could someone in this role do in their first month that would genuinely help your branch?" | The reciprocity question for a peer-style panel |
| 2 | "What has worked and what has not about escalations reaching member services today?" | Shows you want their view before you propose anything |
| 3 | "As branches move toward hubs, what do you most want complaints handling to keep from how your branch works now?" | Speaks to Neighbours, Not Numbers without disputing the plan |
| 4 | "Which of the four values is hardest to live in a busy branch?" | Treats them as practitioners; invites an honest answer you can learn from |
| 5 | "What would you want to be told about complaints trends, and how often?" | Informs your D2 and H3 reporting plan |

---

## Requirement coverage

| JD requirement | Questions |
|---|---|
| 4+ years in financial-services customer operations | A1, D3 |
| experience handling regulated complaints | B2, H1 |
| Own the member complaints process end to end across branches | D1, H1, H2 |
| and the contact centre | B1, D1, F1 |
| report monthly on complaint volumes and resolution times | E1, D2, H3 |
| comfortable with Excel reporting | B4, E1 |
| coach branch supervisors on escalations | C1, G2, H2, I1 |
| work with digital teams on self-service journeys | C2, F2, J1 |
| confident presenting to senior leaders | B3, D2, C4 |

## Prohibited claims

Claims this pack will not coach, because your own words or your quotes do not support them. The first two are limits you stated; the rest are wider wordings of sentences you did say.

| Not coached | Basis | Honest form |
|---|---|---|
| Has worked in a contact centre | Negative you stated, F4 | "I've never worked in a contact centre." Then a plan |
| Has presented to senior leaders | Negative you stated, F9 | "I've never presented to anyone above regional level." Then a plan |
| Owned the complaints process end to end | Inflated form of F3 | F3's quote at its own scope; the limit is the pack's observation: your material shows the branch's log, not the process beyond it |
| Handled regulated complaints | Inflated form of F2 | F2's quote at its own scope; the material says a formal log and does not show what governed it |
| Coached branch supervisors on escalations | Inflated form of F7 | F7's quote at its own scope: new tellers and the escalation script |
| Reported complaint volumes and resolution times to leadership | Inflated form of F5 | F5's quote at its own scope; the material does not show what the sheet counted |
| Is expert at the reporting tool the JD names | Inflated form of F6 | F6's quote at its own scope: a spreadsheet you built |

## Sources

- **Provided documents:** the JD text; the four values as you copied them from ashgrovecu.org/about/values on 26 November 2026; the recruiter's email on the three rounds; your four-point summary of the July 2026 strategy brief; your background as you stated it. No dossier was present.
- **Searches and fetches sent:** none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values content fixes the cheat sheet and the VAL banks |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | The recruiter's email already fixes the three sessions, who runs each, and the case and values-round placement, so persona weights follow it |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | The four-point summary of the July 2026 brief, about four months old, fixes the grounding brief and the CO and CASE questions |
| 4. interviewer name | n/a | No names are assigned yet, so there was no query to form; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Interviewer names for rounds 2 and 3 → an interviewer read, persona weights adjusted from their public professional footprint, and a reverse question tied to each path
- The recruiter's answers on whether the case is shared beforehand, and on location and office pattern → B-bank and A6 answers firm up, and the H bank can be tuned to the case's format
- Your own answers to the slots on F2, F3, F5, F6, F7, F8 and F9 → those rows move from discovery or transferability toward grounded stories, and the matching bank cells are regenerated
- Your CV, or the sentences as written on it → the evidence column quotes your CV in place of your message, and the years and role titles can be checked
- The spreadsheet itself (its column headings), the escalation script, and any procedure your branch's log followed → the inspectable artifacts that would raise F2, F5, F6 and F7 from medium
- The strategy brief itself, not just four points → a fuller grounding brief, with anything that has moved since July
- The regime Ashgrove's complaints are handled under, as the recruiter or the JD names it → B2 and H1 can use its real terms in place of generic ones
- A deeper research pass, offered once: up to 6 further searches and 2 further fetches, several more minutes → loop reports for this kind of role, recent organisational context, and interviewer footprints once names exist; say the word and I will run it
- A tuesday-dossier.md, if you have one → verified evidence and any prohibited claims carried in from earlier work; not required, and this pack stands without it
