# Interview prep pack: Operations Manager, Atlas Freight

- Role: Operations Manager, Atlas Freight (regional logistics, 800 employees)
- Interviewer: not known. Relationship: not known. Built on a hiring-manager prior with blended persona weights, because that is the most common first substantive round for a role like this. If your round is something else, the weights below are the first thing to change.
- Highest-ROI prep in this pack: **A1**, the span-of-control question (three supervisors today, twelve across four sites in the role).

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Rehearse by persona so the delivery is not new to you on the day, and by type so no kind of question is a surprise.

| Tag | Meaning |
|---|---|
| VAL | Behavioral and values: does past behavior show the values, not generic virtue |
| EXP | Experience deep-dive: do the claims on your background survive scrutiny |
| JD | Role-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem from the actual role |

The guidance is scaffolding, not a script. Every sentence about your past in this pack is one of yours, quoted. Where the pack could not know something, it gives you an answer slot: an instruction for the interview, with an honest branch for when the practice was not yours or never existed. Say what is true; return to what you did say.

## Fit snapshot

Requirements are quoted from the JD you pasted. Evidence is your own words from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "currently a senior shift manager over 3 supervisors" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material shows one shift's supervisors and one site's surge plan, and the words stay at that scope: "I'm currently a senior shift manager over 3 supervisors" and "I ran the site's peak-season surge plan two years running." The material does not show work across more than one site, or a freight terminal. Answer slot: the JD's 4-sites line makes a probe on cross-site work likely. If any of your work has covered more than your own site, say what and which part was yours, in your own words; if it has not, say so plainly and stay with the site and shift you run |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Your material carries a mis-pick rate, which is neither of the JD's two measures, and the words stay there: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if you have tracked on-time performance or cost per shipment, say which and how it was counted, in your own words; if you have not, say so plainly and stay with the mis-pick work |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material says three supervisors; the JD says twelve. The words stay at three: "I'm currently a senior shift manager over 3 supervisors." Answer slot: if you have led more people, or other shifts, at any time, say what and which part was yours; if you have not, say so plainly and describe how you would take on a wider span, as a plan |
| F4 | "build reporting in Excel/Power BI" — JD (the Excel half) | "solid Excel" — your message | low | [inferred] | discovery | Derived from the JD's Excel half: "solid Excel" is a self-rating that touches the requirement without showing what was built. Answer slot: if you have built a report or workbook that others used, say what it tracked and who used it; if you have not, say so plainly and say what you would build first for four sites |
| F5 | "build reporting in Excel/Power BI" — JD (the Power BI half) | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used Power BI." Then how you would learn it, said as a plan and never as a past. Never a claim to Power BI work, and nothing added to make the gap feel smaller |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | Not a gate: this is a length-of-experience requirement, so it is graded like any other row, though expect it to be read literally. Your material says seven years in operations and a current supervisory role; it does not show how many of those years involved leading others. Words: "I have 7 years in warehouse and distribution ops, and I'm currently a senior shift manager over 3 supervisors." Answer slot: say which of those years you led others and since when; if the leadership part is shorter than five years, say so plainly |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | The quote already reaches the requirement. Lead with it in its own terms: "I'm green belt certified." Expect a probe on where you have applied it; D2 holds that slot |

## Persona table

No loop source was available, so the loop is not documented and the weights rest on the generic archetype (screen, then hiring manager, then panel) plus the hiring-manager prior. They are close to flat by design.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet, persistent probing of span, years of leadership, terminal versus warehouse, and the measures you have not owned | High. F1, F2, F3 and F6 each sit between what you quoted and what the JD asks, and a hiring manager is buying down exactly that risk | Rehearse A1 until it is boring: hold what your sentences carry through two follow-ups, concede the scope plainly, then give a plan |
| B. Case / Strategist | Live problems on on-time performance, cost per shipment, multi-site peak and reporting | High. The JD is a performance-and-cost job across four sites, and the hiring-manager prior favors live problems | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| C. Data-Driven Prober | Reads your headline number and tool claims line by line | Medium. You have one quantified claim and two tool claims, all of which invite a "how was that counted" or "show me" | Know what you can and cannot say about the 40%, and say plainly what you do not know |
| D. Conversational | Biography, why leave, why us, casual questions on Lean | Medium. Every interview opens here, and it rises to dominant if this is a recruiter screen | A 90-second arc built from your own sentences (D1); treat casual questions on JD topics as scored |
| E. Peer Evaluator | Seam questions between sites, credit when work spans teams | Low to medium. It rises if you meet a site lead or another manager | Propose principles for the seam rather than pretending to know it; credit stated precisely |
| F. Pressure | Time-boxed challenge on why you over a more senior candidate, and on scaling your surge plan | Low to medium. It rises if a senior leader joins | Pause, restate, hold two follow-ups, concede specifically |
| G. Values / Behavioral | Scenario prompts on hard truths and customer-versus-metric trade-offs | Low. No published values were retrieved and no values round is documented, so these are stem-based rehearsal only | Pick a true story; if none fits, say so and give the nearest true thing |

## Question banks

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| "Own daily terminal operations across 4 sites" | A3, B1, B3, B4, E1, F2 |
| "drive on-time performance and cost-per-shipment down" | A4, B1, B2 |
| "lead a team of 12 supervisors" | A1, F1 |
| "build reporting in Excel/Power BI" | B5, C2, C3 |
| "5+ years operations leadership required" | A2 |
| "Lean/Six Sigma a plus" | D2 |

### A. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This role leads twelve supervisors across four sites, and you're over three today. What's the biggest step up for you?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI rehearsal in this pack. Hold only what the quote carries: "I'm currently a senior shift manager over 3 supervisors." Name the limit before they ask: the role's span is wider than that sentence shows. Through two follow-ups, return to the sentence and never add to it. Concede the scope plainly: your span today is three. Answer slot: if you have led more people, or other shifts, at any time, say which and what part was yours, in your own words; if you have not, say so plainly, then give how you would take on a wider span as a plan: what you would learn first about each site and each supervisor | F3 is the widest gap between your evidence and the JD, so this objection arrives in some form. JD because it scores the stated team size | 
| A2 | "The role asks for 5+ years of operations leadership. Which of your seven years count towards that?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Say the two sentences at their own scope: "I have 7 years in warehouse and distribution ops, and I'm currently a senior shift manager over 3 supervisors." Answer slot: say which of those years you led others and since when, in your own words, and let the number be the true one; if the leadership part is shorter than five years, say so plainly and return to the current role | F6 shows seven years in operations but not how many involved leading; a titled-years line is often screened literally. JD because it scores a stated requirement |
| A3 | "You'd own daily operations at a freight terminal. Yours have been warehouse and distribution. What changes?" | JD | [grounded] "7 years in warehouse and distribution ops" | Start with the sentence at its own scope: "7 years in warehouse and distribution ops." Answer slot: if any of your work has touched a freight terminal, say which and what part was yours; if none has, say so plainly and say what you would ask in your first week about how a terminal differs from what you run | F1 carries a warehouse setting against the JD's terminal wording. JD because it scores the stated scope of the role |
| A4 | "Your headline number is a mis-pick rate. How does that connect to on-time performance and cost per shipment?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say it at its own scope: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if you saw a link to on-time performance or cost per shipment in your own work, say what you saw and how it was counted; if you did not track either, say so plainly and stay with the mis-pick work. Do not argue the link on their behalf | F2 maps your one number onto two measures it does not name. JD because the JD's two measures are what is scored |
| A5 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "never used Power BI" | Choose the one that is true. Your material carries two: the span, in your own words "I'm currently a senior shift manager over 3 supervisors," and the tool, "I've never used Power BI." Name it before they do, then give the plan to close it as a plan. Never answer "nothing" | F3 and F5 are the two rows where your own sentences show a limit. JD because it scores honest self-assessment against the listed requirements |

### B. Case / Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one of your four sites has slipped over the past month, and you've just taken over. What do you need to know first, and what do you do in the first two weeks?" | CASE | [generic] | Structure it aloud. Clarify: what on-time means here, which lanes, shifts and customers, since when, what changed. Segment the slip. Decide what data you would pull and from whom. Separate quick fixes from root causes, say how you would involve the supervisors, name the metric you would watch, and name one risk. The question needs no claim about your past, so the guidance makes none | A live problem straight from the JD's on-time line (F2's requirement). `[generic]` because it is a pattern for the problem, not a fact about this employer |
| B2 | "Cost per shipment is rising at two sites and not at the other two. How do you work out why?" | CASE | [generic] | Clarify how cost per shipment is built, then break it into its parts and compare the two groups of sites. Ask what differs between them: volumes, mix, shifts, overtime, rework, claims. State your hypothesis early and what would change your mind. Name the trade-off with on-time performance before they raise it | A live problem from the JD's cost line (F2's requirement), delivered as a decomposition. `[generic]` because it presupposes nothing about your past |
| B3 | "Peak season hits all four sites in the same week, and your supervisors are stretched. How do you plan it?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Open with the sentence at its own scope: "I ran the site's peak-season surge plan two years running." Then treat four sites as a new problem: what you would want to learn from each site's peak before building anything, how you would decide where supervisor time goes, and what you would watch daily. Answer slot: if you set parts of that surge plan, say which and how you decided; if you did not, or there was no such step, say so plainly and return to the sentence | F1 holds the surge evidence at one site. CASE because it asks for a plan live, with EXP flavor from the quote |
| B4 | "You have four sites and limited time. How do you spend your first 90 days?" | CASE | [generic] | Say your objective for the first 90 days, then a sequence: listen at each site, find what is already working, pick two or three measures the JD names, and agree them with the supervisors. Name what you would deliberately not change yet. Speak as a plan, not a past | A multi-site entry plan is the most likely hiring-manager case for a role with F1's scope. `[generic]` because no employer-specific context was available |
| B5 | "What would you put on a one-page weekly view for the four sites?" | CASE | [generic] | Start from the decisions the view serves, then the few measures, led by the JD's own two: on-time performance and cost per shipment. Add one or two early-warning measures and say who reads it and when. Keep it small enough to read in a minute. Tool-agnostic: Excel is enough to design it | The JD asks you to build reporting (F4, F5); this tests the design before the tool. `[generic]` because it makes no claim about your past |

### C. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say the sentence at its own scope first. Then four slots, each in your own words: how mis-picks were counted, what the 40% is most sensitive to, the assumption behind it you would defend least, and which part of the work was yours. Where you do not know how it was counted, say so plainly. Name the weakest assumption yourself before they do | F2's number is the CV claim a prober tests first. EXP because it tests whether the claim survives attribution and counting |
| C2 | "Tell me about a time you used Excel to run or improve an operation." | JD | [grounded] "solid Excel" | The sentence you have is a self-rating, so the story is a selection exercise: pick a workbook or report of yours that someone used to decide something. It needs a named purpose, a named user and something that changed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "solid Excel," or how you would build the weekly view in B5 | F4 touches the JD's Excel half without showing what was built. JD because it scores the stated tool requirement |
| C3 | "The role builds reporting in Power BI as well as Excel, and you've never used it. How do you get up to speed?" | JD | [grounded] "never used Power BI"; "solid Excel" | Words: "I've never used Power BI." Then a plan you will actually follow, said as a plan: one real report for the four sites to rebuild first, the time you will give it, and who you would ask. Your Excel is your starting point at its own scope, "solid Excel." Never imply Power BI work | F5 is a stated gap; the honest rehearsal turns it into a credible ramp. JD because the JD names the tool |

### D. Conversational / Rapport Builder (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | A 90-second arc whose beats are those five sentences, in your own words and at their own scope. Add no event, title or figure they do not carry. End on why this role, in your own true reason (D4) | F1, F2, F3, F6 and F7 are the evidence base; this is where they are first heard. EXP because it is the CV told aloud |
| D2 | "Where does Lean or Six Sigma fit in your work?" | JD | [grounded] "green belt certified" | Say it at its own scope: "I'm green belt certified." Answer slot: if the pick-path redesign came out of that training, or you have used it in other work, say what and which part was yours; if the certification and your work have been separate, or the redesign was not a belt project, say so plainly | F7 is the row the JD calls a plus; the likely probe is where it has been applied. JD because it scores the stated plus |
| D3 | "What do you know about us, and why this role?" | CO | [generic] | Research could not be run for this pack. Build this from Atlas Freight's own website, careers page and what the recruiter tells you, and bring only what you have verified yourself. Say what draws you to the work, in your own words | Homework depth is scored in the casual register. `[generic]` because no company facts were retrieved |
| D4 | "What's behind looking to move from where you are?" | EXP | [generic] | Give your actual reason, in your own words; the pack supplies none. Keep it true, specific to what you want next, and say it once. Then connect it to the role without adding to what your sentences say | A motivation-consistency check that every persona asks in some form. EXP because it tests whether your account holds together |

### E. Peer Evaluator (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Two of our sites disagree about whose problem a late shipment is. What do you do?" | CASE | [generic] | Offer principles, not a claim to know their seam: agree the facts first, agree a shared definition of the handoff, fix the cause rather than the blame, and tell both site leads what you decided and why. Name how you would stop it recurring | F1's four sites make seams inevitable. `[generic]` because it presupposes nothing about your past |
| E2 | "How do you handle credit when an improvement spans teams?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | If you use the pick-path redesign as your example, say it at its own scope. Answer slot: say who else was involved and which part was yours, in your own words; if it was a team effort, say so plainly and say what you did within it. Otherwise choose another true example | F2's result is the natural example and the natural place to be asked about attribution. EXP because it tests attribution honesty |

### F. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over a candidate who already runs several sites?" | JD | [grounded] "7 years in warehouse and distribution ops"; "green belt certified"; "cut mis-pick rate 40% by redesigning the pick path"; "currently a senior shift manager over 3 supervisors" | Pause and restate the question. Say what you have, as those sentences, in your own words. Do not claim to be better than the other candidate. Hold through two follow-ups, then concede specifically: "I'm currently a senior shift manager over 3 supervisors." Never fold on the core claim to restore harmony | F3's gap is the one a pressure interviewer leans on. JD because it scores fit against the role's scope |
| F2 | "Four sites peaking in the same week would break a plan built for one. Convince me." | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Hold the sentence at its own scope: "I ran the site's peak-season surge plan two years running." Concede that it was one site's plan. Then give your approach as a plan: what you would learn from each site's peak first. Answer slot: if you set parts of that plan, say which; if you did not, say so plainly and return to the sentence | F1 holds the surge evidence at one site; this is the pressure form of B3. CASE because it is a live problem |

### G. Values / Behavioral (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time with a named stake, a moment you did not soften it, and an intact relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioral stem; no published values were retrieved, so this is rehearsal only. VAL because it scores behavior, not a claim |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a time where the metric and the customer pulled apart and you chose. Name what the metric was and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A freight operation lives on service against cost, so this stem is likely to be reworded for it. VAL because it scores a decision |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would you want on-time performance and cost per shipment to look like twelve months from now, and which matters more right now?" | The JD names both; the answer tells you which to lead with and shows you read the job as a trade-off |
| R2 | "How are the twelve supervisors spread across the four sites, and where is that team strongest and thinnest today?" | It shows you are thinking about span, and tells you how much of F3's gap the team already covers |
| R3 | "What reporting do the sites and leadership use today, and where does it live?" | It shows you take the reporting line seriously and tells you how large the Power BI ramp in F5 is |
| R4 | "Is this role new, or is it replacing someone, and what changed that makes it open now?" | It surfaces what the role is for beyond the JD |
| R5 | "What does a strong first 90 days look like, and what would make you say it was going badly?" | It turns your B4 plan into a shared definition and shows you want the bar |
| R6 | If the person is a peer: "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer round; it frames you as reducing their load |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned operations across four sites, or a terminal | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation, not words for you: the material says one shift and one site's surge plan. A3 and the F1 slot stay inside that scope |
| Led or managed twelve supervisors | Inflated form of F3 | F3's quote at its own scope: "I'm currently a senior shift manager over 3 supervisors." The limit is the pack's observation |
| Drove on-time performance or cost per shipment down | Inflated form of F2 | F2's quote at its own scope. The material says a mis-pick rate; A4's slot asks only whether you tracked either measure |
| Has Power BI experience | Negative you stated, F5 | The plain acknowledgment F5 gives: "I've never used Power BI." Then a plan, never a past. No slot |
| Led Lean or Six Sigma projects | Inflated form of F7 | F7's quote at its own scope: "I'm green belt certified." The material says the certification, not projects; D2's slot stays inside that scope |
| Five or more years of operations leadership | Inflated form of F6 | F6's quotes at their own scope. The material says seven years in operations, not how many involved leading; A2's slot asks which years |

## Sources

Provided documents: the job description you pasted and your background summary, both in your message. No tuesday-dossier.md was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | The search was refused, so no published values were retrieved. It would have supplied value names for VAL questions; G1 and G2 stay stem-based |
| 2. `Atlas Freight interview process operations manager` | unavailable | The search was refused. It would have documented the loop, so persona weights rest on the generic archetype and the hiring-manager prior |
| 3. `Atlas Freight regional logistics news strategy 2026` | unavailable | The search was refused. It would have grounded CO and CASE questions in current strategy; B1 to B5 and D3 are `[generic]` |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form |
| 5. representative Operations Manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

Queries sent, each refused:

- `Atlas Freight regional logistics company values` — refused
- `Atlas Freight interview process operations manager` — refused
- `Atlas Freight regional logistics news strategy 2026` — refused

## Upgrade menu

- The interviewer's name and role → persona weights read from their public footprint and a reverse question tied to their own path
- Your round type: recruiter, hiring manager, peer or panel → reweighted banks, and logistics rows if it is a recruiter screen
- The recruiter's prep email → coverage of any stated focus areas or a pre-declared task
- Atlas Freight's website about, careers or values text pasted in → a values cheat sheet and D3 and the case bank grounded in the company's own language, in place of `[generic]` rows
- Web search permitted in this session → the three refused targets re-run, which would move D3, the persona weights and the values bank. A deeper research pass, up to 6 more searches and 2 more fetches and several more minutes, is available on your say-so
- How many of your seven years you led others, and since when → upgrades F6 and A2
- Whether you have covered other sites or a freight terminal → upgrades F1, A3 and B3
- What you have tracked on on-time performance or cost per shipment → upgrades F2 and A4
- How the 40% was counted and what part was yours → upgrades C1 and E2
- What you have built in Excel and who used it → upgrades F4 and C2
- Whether the pick-path redesign was a green belt project → upgrades F7 and D2
- A tuesday-dossier.md from a prior evidence check would add user-confirmed claims, a pre-ranked likely objection and an absolute list of claims to avoid; the pack stands without it
