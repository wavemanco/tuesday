# Interview pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship: assumed to be the hiring manager the careers page describes (unconfirmed). Format: the Outage Hour, one 60-minute session, a live-incident tabletop and then a values conversation, no take-home (Sources 2). Candidate: Femi.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for your own words, not a script. Wherever it says "answer slot", that is an instruction for the interview, not a question for me: answer it truthfully from your own experience, or take the plain second branch.

| Type | Meaning |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether a claim about your work survives scrutiny |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company's current situation |
| CASE | A live problem from the role, reasoned aloud |

Provenance labels: `[grounded]` is traceable to your message or a cited source. `[inferred]` is derived from a named source. `[generic]` is a role-family pattern with no claim about Saltmarsh or about you.

## Prep triage

Your interview is Friday, which is tomorrow by today's date. I don't know how many hours you have, so this is sized for roughly one evening.

1. Say B1 aloud until it is boring. It is the highest-ROI prep in this pack.
2. Say A1, A2 and A3 aloud as a tabletop: structure first, then the player message, then the calendar decision.
3. For C1 to C3, pick real instances from your own work, or take the honest branch.
4. Read D1 to D3 and F2 against your own memory of the calendar, the retention report and the checklist. Settle each answer slot.
5. Play Tidepool Tactics and Lantern Row for a while, so E2 has a true answer.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | Your material gives four years as an associate producer and two years running the calendar, and does not show what the other two years held. Keep each at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's years line makes a probe on the other two years likely. Say what they held, in your own words; if nothing in them bears on the JD's line, say so plainly and stay with the two years you ran the calendar |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a message line with nothing inspected behind it, so expect a probe. Lead in the quote's own terms: weekly, your main title, the last two years. A copy of the calendar would raise the band |
| F3 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | The quote says weekly content drops on one title. The JD says live events across two titles. Words stay at the quote's scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if any entry on that calendar was a timed event rather than a content drop, say which and what your part was, in your own words; if none was, say so plainly and stay with the weekly drops |
| F4 | "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | discovery | The sentence says you have not led a team. It does not say whether you coordinated other disciplines, so the material is silent on this requirement. Plain acknowledgment from your own words: "I haven't led a team." Answer slot: if you coordinated any of design, art, engineering or community on a drop, say which and what you did, in your own words; if you did not, or it was not your role, say so plainly and stay with the calendar you ran |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | The quote says you presented monthly numbers to the studio head. The JD says a per-event review and its KPIs. Words stay at the quote's scope: "I presented the monthly retention numbers to the studio head." Answer slot: say which of those numbers, if any, you chose or defined, in your own words; if they came from elsewhere and you presented them, say so plainly and stay with presenting them |
| F6 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap in terms. Lead with the quote: monthly retention numbers, the studio head as audience. You gave no figure, so this pack supplies none and a how-was-it-counted probe is likely (D2). A sample retention slide would raise the band |
| F7 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | The quote says you wrote it and QA still uses it. The JD says manage it with QA. Words: "I wrote the release checklist our QA team still uses." Answer slot: say what you did with the checklist after writing it, in your own words; if nothing, say so plainly and stay with having written it |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | A checklist is writing, but the material does not show who read it or how well it worked, and that reading is this pack's derivation. Answer slot: if other writing of yours bears on the JD's line, name it, in your own words; if the checklist is your main example, say so and stay with it |
| F9 | "Project Larkspur moves Tidepool Tactics and Lantern Row to a season-pass model with one shared events calendar from February 2027" — Saltmarsh news (Sources 3, search result) | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. This is not a JD requirement. It is a public change that makes the gap likely to come up |

## Reading the interviewer

| Item | What the source says | Label | What it suggests |
|---|---|---|---|
| Role | Head of Live Operations at Saltmarsh Games (Sources 4) | [grounded] | He likely runs the Outage Hour the careers page describes, as hiring manager. Confirm this |
| Earlier path | Previously a QA lead at a console studio (Sources 4) | [grounded] | The release checklist is probably his native ground, so expect D3 to go deep |
| Published argument | GDC 2026 talk "Patch Notes Are a Promise": a live team is judged by how often its patch notes describe what actually shipped (Sources 4) | [grounded] | Expect precision about claims to matter. Say what was yours at its own scope. It mirrors the values page's "announce what is built, not what is hoped" (A2, C3) |

Source quality: both interviewer facts come from one search result, and I did not read the talk itself. The result's address ends in ".example", which is not a conference's real address. Confirm them against his own profile before building anything on them.

Mirror opportunity: your side of the shared ground is F7, "Wrote the release checklist our QA team still uses." This is shared professional ground, not a shared career jump, so don't present it as one. Use it where release checklists come up naturally.

## Persona weights

Weights start from the hiring-manager prior (Case plus Skeptic). The loop adjusts them: the careers page documents a tabletop on a simulated outage, then a values conversation (Sources 2). That detects a values-style round, so section "Values cheat sheet" below is included. Interviewer signals add a little to the Prober.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A Case/Strategist (5 questions) | The Outage Hour tabletop: a simulated outage during a live event | High. The careers page names it, and it is the hiring-manager prior | Say your structure aloud before using it, and ask clarifying questions first. Rehearse A1 to A3 as one continuous exercise |
| B Skeptic (4) | Quiet probing of the gaps: monetization, team lead, title, motivation | High. The hiring-manager prior, plus F4 and F9. Larkspur makes F9 likely to come up | Rehearse B1 until it is boring |
| C Values/Behavioral (4) | Scenario prompts mapped to the three published values | High. The careers page says a values conversation follows the tabletop | Map real instances to each value, or take the honest branch |
| D Data-Driven Prober (3) | Line-by-line questions on the calendar, retention numbers and checklist | Medium. These are your strongest lines, and his published theme is claims matching shipped work | Know what you can and cannot say about how each was counted |
| E Conversational (2) | An opening journey question, a casual question about the games | Medium. It is likely to open a 60-minute session | Pre-script the 90-second arc. Treat casual questions as scored |
| F Pressure (2) | Time-boxed challenges on the gap and on attribution | Low. Nothing documented says the session is adversarial, but a tabletop can be time-boxed | Pause, restate, hold through two follow-ups, then concede specifically |
| Peer Evaluator | Not included | The careers page documents one session with the hiring manager, and no peer round | None needed |

## Question banks

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The event has just gone live and an outage is hitting part of your player base. Walk me through your first fifteen minutes." | CASE | [generic] | Say your structure aloud. First, what you need to know: what is failing, which players, since when, and whether it is spreading. Then the objective: stop further harm to players, restore service, keep players informed. Then who you pull in: engineering to diagnose, community for the player voice, QA for anything touching the release. Name the decisions you would own and the ones you would ask others for, and when the next update goes out. Challenge one premise politely, such as whether the event keeps running while you diagnose. The question needs no claim about your past, so the guidance makes none | The Outage Hour is the documented format (Sources 2), so a live-incident case is near-certain. CASE because it is a live problem. `[generic]` because it is a pattern, not a claim about Saltmarsh's process |
| A2 | "Engineering says the fix is a couple of hours out and community wants an ETA. Write me the first two lines of what players see." | CASE | [inferred] | Two lines in plain words: what is wrong, who is affected, what is confirmed, and when the next update comes. Say only what is built or confirmed. Put anything hoped for in a separate line or leave it out. Promise no ETA you cannot back. This is derived from the values page's "we announce what is built, not what is hoped"; the structure is a generic crisis-communication pattern | Scores the JD's clear-written-communication line under time pressure, and it mirrors the interviewer's published theme (Sources 4). CASE with a writing delivery. `[inferred]` because the derivation is the values page |
| A3 | "The outage cost you two days of a week-long event, and the next event is already on the calendar. Extend, shift or hold?" | CASE | [inferred] | Say the principle first: when the calendar and the players disagree, the players win (Players Before Plans). Then the options and what each costs. Extend helps the players who missed out but pushes everything behind it. Shift moves every dependent date across design, art, engineering, community and QA sign-off. Hold keeps the calendar but leaves players with lost time. Say what you would check first: who was affected and how badly, and whether the next event's assets and checklist can move. Commit to a recommendation and concede its cost | Tests calendar judgment, the core of the JD's plan-and-run line. CASE with a VAL flavor, so it is tagged CASE and the value is named in the guidance. `[inferred]` from the values page |
| A4 | "From February 2027 both titles share one events calendar under a single live-ops group. What would you want to know before planning it, and what could go wrong?" | CO | [inferred] "I ran the weekly content-drop calendar for our main title for the last two years." | Clarify first: what the shared calendar is for, how much the two titles' players overlap, how much engineering and community capacity each title has, and what the season-pass cadence fixes in place. Then structure: objective, constraints, approach, metrics, risks. Risks to name: events colliding for shared players or shared engineering, one title's incident delaying the other, and player fatigue. You have seen only the public announcement, so frame what you say as what you would ask, not what you know. If you reach for experience, stay at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." That is one title, so do not stretch it to two | The strategy question that most candidates cannot touch, from the Larkspur announcement (Sources 3). CO because it tests current-strategy fluency. See F3 for the scope limit. `[inferred]` because the announcement was read as a snippet only |
| A5 | "The event is over. What goes in the post-event review, and which KPIs do you report?" | CASE | [generic] | Structure: what the event set out to do, what players experienced, what happened to engagement and retention, what went wrong or right in the run, and what changes next time. Say which numbers you would want and why, and name the weakest assumption in each. Say who you would agree the definitions with before the event, not after. If you reach for your own experience, stay at its scope: "I presented the monthly retention numbers to the studio head." | The JD names the post-event review and its KPIs as owned work (F5). CASE because the question is a live design problem. `[generic]` because the content is a pattern |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "I don't see in-app purchases in your background, and from February both titles move to a season pass. How would you handle that part of the job?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." "Presented the monthly retention numbers to the studio head." | The highest-ROI rehearsal in this pack. Level 1 (60 to 75 seconds). Acknowledge plainly: "I haven't worked on a game with in-app purchases." Then what your material carries, at its scope: "I ran the weekly content-drop calendar for our main title for the last two years." and "I presented the monthly retention numbers to the studio head." Then the ramp, as a plan and not as knowledge: what you would learn first, such as how the season pass constrains which events can run when, what the monetization side needs from event timing, and which numbers the team reads after an event. Level 2: "Retention isn't revenue." Concede it cleanly: it is not, and the review would need the revenue-side numbers from whoever owns them. Do not defend retention as a substitute. Level 3: "What do you do in your first month?" Give the plan only: sit with the owner of the season pass, read recent post-event reviews, ask what they wish the last producer had known. Hold the core, the calendar and retention work you did. Concede the specific gap. Never claim season-pass design, pricing or store familiarity | F9 is the biggest gap, and Larkspur (Sources 3) makes it public, so some form of this question is likely. This objection is inferred from the fit snapshot and the announcement, with no dossier behind it. JD because it tests a stated role context. Deepest rehearsal: three levels and the concession wording are given |
| B2 | "You'd coordinate design, art, engineering and community, and you haven't managed any of them. How do you get a lead from another discipline to move their date for you?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "Wrote the release checklist our QA team still uses." | Acknowledge first: "I haven't led a team." Answer slot: if you got another discipline to move or hold a date on a drop, say which and what you did, in your own words; if you did not, or that was not your role, say so plainly and stay with the calendar you ran. You can add one fact at its scope: "I wrote the release checklist our QA team still uses." Say it as a fact and let him draw the inference. Then your method as a method, not a past: what you bring the lead is the cost of the date to players | F4 is silent on coordination, so this probe has no claim to rest on. JD because it tests the JD's coordination line |
| B3 | "Your title was associate producer. This role owns the post-event review and its KPIs. What changes at that level for you?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." "Presented the monthly retention numbers to the studio head." | Own the title plainly: "I was an associate producer at a puzzle-game studio for four years." Answer slot: say which parts of the monthly retention report were yours, in your own words; if you presented numbers someone else produced, say so plainly and stay with presenting them. Then say what you would want to learn first about how this team defines success for an event. State it as a plan | F1 and F5 both turn on level, and a skeptic will test them. JD because it scores a role requirement |
| B4 | "Why Saltmarsh, and why live ops now?" | EXP | [generic] | Answer slot: give your actual reason in two sentences in your own words. If part of it is the Larkspur change or the Outage Hour format, say what you read. Say only reasons that are true | Motivation consistency is the Skeptic's core check. Your material states no reason, so the slot is yours to fill. EXP because it tests your own story |

### C. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "When have you left a checklist or process better than you found it after a release?" | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Map it to Leave the Build Greener. The beats the quote states: you wrote the checklist, and QA still uses it. Tell them in your own words. Answer slot: the value says every release leaves the checklist better, so expect a probe on whether it changed after releases. If you revised it, say what prompted the change and what you changed; if you did not, say so plainly and stay with having written it | F7 is the one story your material carries to any published value. VAL because it scores a value by name |
| C2 | "Tell me about a time the calendar and the players disagreed." | VAL | [generic] | Selection scaffold, for Players Before Plans. Pick a real time you changed or protected a plan for players' sake. It needs a named stake, the decision, a cost you accepted, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or say how you would handle it (A3 shows the principle) | No quoted sentence carries this story, so this is a scaffold, not a story map. Theme from the values page (Sources 1) |
| C3 | "Tell me about a time you had to correct something you had announced." | VAL | [generic] | Selection scaffold, for Ship the Patch Not the Promise. Pick a real time you corrected or walked back something you had said was coming. It needs what you said, what turned out true, how you corrected it, and what you changed afterwards. If no such time comes to mind, say so plainly, then say how you decide what to announce, or how you would handle it | As C2. It mirrors his published theme (Sources 4) |
| C4 | "Which of our three values would be hardest for you?" | VAL | [generic] | Answer slot: pick the value you honestly find hardest and say why, in your own words. Name one concrete thing you would do about it. Do not pick the safe one | Tests honest self-assessment against the values by name (Sources 1) |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the content-drop calendar you ran." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | The beats the quote states: weekly, your main title, the last two years. Tell them in your own words. Answer slot: the JD says plan and run, so expect a probe on who decided what went into each week. If it was yours to decide, say how; if it was set by others, or fixed some other way, say so plainly and describe how you ran it | F2 and F3 both draw on this line, so it is the likeliest EXP probe. EXP because it tests what was actually yours |
| D2 | "Walk me through the monthly retention numbers you presented to the studio head." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | The beats the quote states: monthly, to the studio head. You gave no figure, so none is supplied here. Answer slot: say which retention measure it was and how it was counted, if you know; if you do not know how it was counted, say so plainly. Name the assumption behind it you would defend least before he asks, or say you do not know of one. Say which part of the report was yours | F6. The defend-the-number move applies even without a figure, because the numbers are the line. EXP because it tests attribution |
| D3 | "What is on the release checklist you wrote, and how does QA use it?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | The beats the quote states: you wrote it, and QA still uses it. Tell them in your own words. Answer slot: say what is on it from your own memory, and what you did with it after writing it; if you did nothing further, say so plainly and stay with having written it. Do not reconstruct items you do not remember | F7, and his QA background (Sources 4) makes this likely to go deep. EXP because it tests detail behind a CV-style claim |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc of four beats, each a sentence you wrote: the four years as an associate producer, the calendar, the checklist, the retention numbers. Tell them in your own words and at their scope. End with why Saltmarsh. Answer slot: give your actual reason in your own words | The opening question of a 60-minute session. EXP because it tests whether your story holds together |
| E2 | "Have you played Tidepool Tactics or Lantern Row?" | CO | [inferred] | Answer slot: if you have played either, say one specific thing you noticed about how its events ran, in your own words; if you have not, say so plainly and say what you would look at first. Playing both before Friday makes the first branch available. Say only what you saw | The titles come from the Larkspur announcement (Sources 3), and the JD's two titles may be these two. That is unconfirmed. CO because it tests homework depth |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you, over someone who has already run a season pass?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." "Presented the monthly retention numbers to the studio head." | Pause, restate the question, then hold and concede. Hold what you can stand behind, at its scope: "I ran the weekly content-drop calendar for our main title for the last two years." and "I presented the monthly retention numbers to the studio head." Concede specifically: "I haven't worked on a game with in-app purchases." Close with the one-sentence ramp from B1. Hold through two follow-ups, and do not fold on the core to restore harmony | The time-boxed form of B1. JD because it scores the same requirement context |
| F2 | "That retention report: how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: say precisely which parts were yours, in your own words; if you presented numbers others produced, say so plainly. Hold the core: "I presented the monthly retention numbers to the studio head." Concede what you do not know about how they were built. Never claim more than the sentence says | F5 and F6. EXP because it tests attribution under pressure |

## Requirement coverage

| JD requirement | Questions | Why none, if none |
|---|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A3, A4, D1, E2 | |
| "coordinate design, art, engineering and community teams on each update" | A1, B2 | |
| "own the post-event review and the KPIs it reports" | A5, B3, D2, F2 | |
| "manage the release checklist with QA" | C1, D3 | |
| "3+ years producing live-service games or apps" | B3, E1 | |
| "experience running a content calendar" | A4, D1 | |
| "comfortable with player-retention metrics" | A5, D2, F2 | |
| "clear written communication" | A2, A5 | |

## Values cheat sheet

Detected because the careers page documents a values conversation as part of the session (Sources 2). Names are from the values page (Sources 1).

| Value | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | No quoted sentence carries one. Selection scaffold at C2, ending in its honest branch |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | No quoted sentence carries one. Selection scaffold at C3, ending in its honest branch |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F7: "Wrote the release checklist our QA team still uses." Used in C1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "From February the two titles share one events calendar under a single live-ops group. Where does this producer role sit in that, and what is the first calendar decision it will face?" | Shows you read the announcement (Sources 3), and it surfaces what the role actually is after the change |
| 2 | "You moved into live ops from QA, and you have argued that a live team is judged on whether its patch notes describe what shipped. What does your team do to make that true on a release, and where does the producer sit in it?" Ask it only if you confirm the talk is his. | Ties to his own path and published argument (Sources 4), and invites him to talk about something he cares about |
| 3 | "What should I learn first about how events and the season pass fit together here?" | Turns the biggest gap (F9) into a ramp conversation and signals you plan to close it |
| 4 | "Which numbers does the team read in a post-event review, and who defines them?" | Tests what owning the review means in practice, and surfaces F5's limit on your terms |
| 5 | "How does the team decide when an event should be extended, shifted or cut?" | Continues A3 and the Players Before Plans value, and shows how decisions are made under the calendar |
| 6 | "What would you want settled by the first post-event review I run?" | Asks what success looks like in the first period, so you can answer the question rather than guess it |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Four years producing live-service games | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation: your material says four years as an associate producer and two years running the calendar |
| Planned and ran the live-events calendar for two titles | Inflated form of F3 | F3's quote at its own scope: weekly content drops on your main title |
| Owned the post-event review and its KPIs | Inflated form of F5 | F5's quote at its own scope: "I presented the monthly retention numbers to the studio head." D2's slots stay inside the report |
| Managed the release checklist with QA | Inflated form of F7 | F7's quote: "I wrote the release checklist our QA team still uses." D3's slot asks what you did with it, inside that scope |
| Has led a team or led other disciplines | Negative you stated, F4 | The plain acknowledgment: "I haven't led a team." No slot |
| Has in-app purchase, season-pass or monetization experience | Negative you stated, F9 | The plain acknowledgment: "I haven't worked on a game with in-app purchases." Then a plan, never a past |

## Sources

Provided documents: the JD text and your background, both in your message. No dossier was consumed.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Fetched the official page. It names three values, which feed the values cheat sheet and bank C |
| 2. `Saltmarsh Games interview process live operations producer` | yes | Fetched the careers page. It establishes one 60-minute session with the hiring manager: tabletop, then values conversation, no take-home. That fixed the persona weights, bank A and the values-round detection |
| 3. `Saltmarsh Games strategy` / recent news | yes | One result, a September 2026 announcement, read as a snippet only. It moved A4, E2, B1 and reverse questions 1 and 3 |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | One result, read as a snippet only. It moved the interviewer read, D3 and reverse question 2 |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

Searches and what they returned:

1. "Saltmarsh Games values" returned https://saltmarshgames.com/values
2. "Saltmarsh Games interview process live operations producer" returned https://saltmarshgames.com/careers/interviewing
3. "Saltmarsh Games mobile studio news strategy" returned https://saltmarshgames.com/news/project-larkspur
4. "Tobias Wrenfield Saltmarsh Games" returned https://talks.gdconf.example/2026/patch-notes-are-a-promise

Fetches: https://saltmarshgames.com/values and https://saltmarshgames.com/careers/interviewing.

## Upgrade menu

- The recruiter's note on the Outage Hour (which game or event the scenario uses, any prep material) → bank A moves from `[generic]` toward `[grounded]`, and the tabletop rehearsal fits the real scenario
- Your answers to the answer slots at F1, F3, F4, F5 and F7 → each becomes quoted material, and the rows and banks that draw on them are regenerated
- A copy of the content calendar, a sample retention slide or the release checklist itself (names redacted) → F2, F5, F6 and F7 can rise from medium to high
- Confirmation that Tobias is the person you would report to → persona weights confirmed or reweighted
- How many hours you have before Friday → the prep triage resized
- Tobias's own profile or the talk's slides or transcript → a fuller interviewer read, and the ".example" source question settled
- A tuesday-dossier.md, if you have one → verified evidence and any prohibited claims folded in, never required
