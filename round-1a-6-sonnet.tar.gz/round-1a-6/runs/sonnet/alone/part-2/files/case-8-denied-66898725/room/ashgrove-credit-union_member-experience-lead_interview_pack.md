# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara. **Date of the loop:** 5 December 2026, three rounds, one day. **Mode:** loop (three scheduled rounds). **Interviewers:** known by role only, and no names are assigned yet: the recruiter (30 min); the Head of Member Services, who would be your manager (45 min, mostly behavioural); a panel of two branch managers (60 min, including a 20-minute case on a complaint escalation, and the round scored against the four values).

## How to use this pack

- **Personas are how a question is asked; types are what it scores.** The five type tags: **VAL** (does past behaviour show Ashgrove's published values), **EXP** (do your own claims survive a close read), **JD** (can you do the listed job, gaps included), **CO** (do you know where Ashgrove is heading), **CASE** (live problem from the real role).
- **Guidance is scaffolding, not a script.** Say it in your own words. Anything in double quotation marks inside a cell is your own sentence from your message to me, or Ashgrove's own words from what you pasted.
- **An answer slot is an instruction for the interview, not a question for me.** It tells you what to say if a thing is true and what to say if it is not. Both branches are honest; neither is a confession.
- **Everything proposed for you to say is pending your approval.** Change any line that is not true to what you did.
- **The highest-ROI prep in the pack is D1** (round 2): the scope question about owning complaints across branches and the contact centre. It will arrive in some form in more than one round.

## Fit snapshot (shared across all three rounds)

Proposed language in the last column, pending your approval.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says one branch's formal complaints log, not a process across branches, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's across-branches line makes a probe on the log's reach likely. If any of what happened to a complaint once it was in the log was yours, say which parts and what you did, in your own words; if the log was the extent of it, or others handled the rest, say so plainly and stay with the log |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your sentence says a monthly complaints spreadsheet your regional manager uses; it does not say what the sheet showed. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names volumes and resolution times, so expect a probe on what the sheet showed. If it showed either, say which and how each was counted; if it showed neither, or other things, say so plainly and stay with the sheet you built |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your sentence says spreadsheet and the JD says Excel, so the words stay at spreadsheet. Answer slot: if the tool was Excel, say so and say what you did in it; if it was another tool, say which, plainly |
| F5 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says new tellers, and the words stay there: "I trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on how you ran that training likely. If you chose what the script covered or how new tellers were checked, say what and how; if the script and any checking were set by others, or there was no check, say so plainly and stay with the training you gave |
| F6 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Nothing in your material speaks to this either way. Answer slot: if you have worked with a digital team or on a self-service journey, say what it was and which part was yours; if you have not, say so plainly, then say what you would want to learn from the digital team first, as a plan |
| F7 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it, so expect a probe. Lead with it in its own terms: 6 years in retail banking, the last 3 as a branch supervisor. The JD says financial-services customer operations and your sentence says retail banking, so the words stay in retail banking |
| F8 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | Your sentence says a formal complaints log and nothing about which rules governed it, so the words stay at: "I handled the branch's formal complaints log." Answer slot: if you know which rules the log was kept under and what you did to meet them, say so in your own words; if the rules sat with others, or you are not sure which applied, say so plainly and stay with the log |
| F9 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't presented to anyone above regional level." Then how you would build that, said as a plan and never as a past. Never a claim to presenting at senior level |

Not one requirement in the JD is a gate in the sense of a licence, credential, schedule, pay or location term, so no row is a `hard_gate`. The 4+ years line is a length of experience and is graded as one (F7).

## Grounding brief

From the 2026 strategy brief the recruiter sent you (July 2026). I have the points as you relayed them, not the brief itself.

| Fact, as relayed | Source | Reading for this role | Provenance of the reading |
|---|---|---|---|
| Move 40% of member service to digital channels by 2028 | Strategy brief, via you | More complaints may begin in digital channels over time, which is where the JD's digital-teams line sits | [inferred] |
| Consolidate eight branches into five hubs over 2027 | Strategy brief, via you | Touches every branch, and sits close to the value "Neighbours, Not Numbers"; expect it to colour the branch-manager panel | [inferred] |
| Launch a small-business lending product in Q1 2027 | Strategy brief, via you | A new product may mean a new kind of complaint; whether the role covers it is a question to ask, not assume | [inferred] |
| Main competitive pressure is app-only banks | Strategy brief, via you | Speed and plain wording in complaint handling matter more where a member can leave through an app | [inferred] |

Use these as vocabulary, not as a recital: any prepared candidate has them. The differentiator is saying what each one means for complaints, as a view you can defend.

---

# Round 1: Recruiter screen (30 minutes)

### Persona weights, with reasoning

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly walk-through of your background, motivation and logistics | High. A recruiter screen is a friendly register with scored logistics, and the recruiter's email gave no other focus | A short, pre-planned arc for the biography question; treat casual questions as scored |
| Skeptic (light) | A gentle check on gaps against the JD | Low. Knockout-style checks come in this round, but the heavy cross-examination belongs to rounds 2 and 3 | Name gaps plainly and early, in your own words, before being asked twice |

### Bank (pending your approval)

**A. Conversational**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your journey so far." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Open with the first sentence as it stands: 6 years in retail banking, the last 3 as a branch supervisor. Then the second, in its own terms: the branch's formal complaints log, and training new tellers on the escalation script. Then, in your own words, say what moves you toward complaints work and toward this role. Under 90 seconds, no beat the two sentences do not state | The standard opener; F7 carries the years and F1 the scope of the complaints work. EXP because it checks that your account matches your CV |
| A2 | "What do you know about Ashgrove, and why us?" | CO | [grounded] | Pick one or two of the brief's points and say what each means for complaints, as in the grounding brief above: for instance the digital target or the hub plan. Name the values by their official names if one fits. The reason you want Ashgrove is yours to give: say your real reason, in one or two sentences | The recruiter is listening for homework and motivation in one answer; CO because it tests current strategy. Grounded in the brief and the pasted values, with nothing from outside them |
| A3 | "What's prompting you to look at a move?" | EXP | [generic] | A logistics slot. Give your actual reason, in one sentence, framed on what you are moving toward. Decide the sentence before the call so it is the same in all three rounds | A recruiter screen always asks it; consistency across rounds is what is scored. EXP because it checks the story against your path |
| A4 | "What salary are you looking for?" | JD | [generic] | A logistics slot. Give your own number, or ask for the role's band first; choose which before the call. If asked what you earn now: "I'd rather focus on the range for this role." | The listed job's terms; the only safe answer is your own |
| A5 | "What's your notice period?" | JD | [generic] | A logistics slot. Give your actual notice period, as it is in your contract | The listed job's terms |
| A6 | "Where are you based, and does the location work for you?" | JD | [generic] | A logistics slot. Give your own location and any constraint you actually have. If the role's base is not stated, ask where it sits before answering | The listed job's terms; the hub plan in the brief makes the role's base worth asking about |

**B. Skeptic (light)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Name the two gaps your own sentence states, in its terms: "I haven't worked in a contact centre." and "I haven't presented to anyone above regional level." Then, for each, one thing you would do first, as a plan in your own words. Do not add a third gap you have not stated, and do not hide either | F2 and F9 are the two stated gaps; stating them first takes the sting out of rounds 2 and 3. JD because it scores the listed requirements |
| B2 | "What experience do you have handling regulated complaints?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Lead with "I handled the branch's formal complaints log." Answer slot: the JD asks for regulated complaints, so expect a probe on which rules the log was kept under. If you know which rules and what you did to meet them, say so in your own words; if the rules sat with others, or you are not sure which applied, say so plainly and stay with the log. Do not describe a regulator's process you did not work to | F8 is the evidence and the likeliest knockout item. JD because it is a stated requirement |

### Reverse questions for round 1

| Question | Why it lands |
|---|---|
| "Do the two branch managers see the case in advance, and is there anything I should prepare for the 20-minute case?" | Gets the case format from the person who can tell you, and shows you are treating it as a scored item |
| "Who will I meet in each round, and can I have their names?" | Names unlock a tailored interviewer read; the answer also shows how fixed the loop is |
| "Where does the role sit day to day: a branch, a hub, the contact centre?" | Settles the location logistics (A6) and shows you have read the hub plan |
| "Which complaints rules does the role work to?" | Turns your own uncertainty in B2 into a question; the answer tells you which rules to read before 5 December |

---

# Round 2: Head of Member Services, your would-be manager (45 minutes, mostly behavioural)

### Persona weights, with reasoning

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "Tell me about a time" stories | High. The recruiter's email says the round is mostly behavioural | A story per published value where your material carries one, otherwise the selection scaffold and its honest branch; "we" for context, "I" for what you did |
| Skeptic | Probing the gap between your background and the whole JD | High. A manager is buying capability and de-risking gaps, and your stated gaps are the obvious targets | Rehearse D1 until it is boring: hold what your sentences carry, concede the contact centre once and specifically |
| Case / Strategist | Live thinking on Ashgrove's priorities and the monthly report | Medium. A manager's roadmap questions appear even in a behavioural round, and the digital target is the brief's headline | Clarify first, then structure; use the company's own words |
| Pressure | Time-boxed challenges, "how much of that was you" | Low. It appears inside D2, not as the round's style | Pause, restate, hold, then concede specifically |

### Bank (pending your approval)

**C. Values / Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you kept hold of a problem until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold, starting where your material is: the complaints you handled through the log. A story qualifies if it has a problem you found or were handed, a point where it could have gone to someone else and stayed with you, and a member or colleague put right at the end. "We" for context, "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, the log you handled, or how you would handle it | The value "Own the Fix" is Ashgrove's own wording and the manager will want a specific decision, not the slogan. VAL; F1 is the nearest evidence |
| C2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Selection scaffold: it needs a named stake, a moment you did not soften it, and a relationship still intact afterwards. Say the level honestly: your own sentence says nothing above regional level, so do not stretch the audience. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioural stem for a role that reports to senior leaders; F9 sets the honest ceiling on the audience. VAL because it scores what the person did, not the claim |
| C3 | "You trained new tellers on the escalation script. Tell me how that went." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The beats the sentence carries: new tellers, the escalation script, training them. Tell those in your own words. Answer slot: the JD's coaching line makes a probe on how you ran the training likely. If you chose what the script covered or how new tellers were checked, say what and how; if the script and any checking were set by others, or there was no check, say so plainly and stay with the training you gave | F5 is the closest your material comes to the coaching line, and the manager will read the CV line closely. EXP because it tests what was actually yours |

**D. Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "This role owns complaints across the branches and the contact centre. You've handled a branch's complaints log and haven't worked in a contact centre. Why would I believe you can own the whole thing?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "Never worked in a contact centre, and I've never presented to anyone above regional level." | **The highest-ROI prep in the pack.** Hold: say what your sentence carries and no more: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Concede once, specifically: "I haven't worked in a contact centre." Then a plan, in your own words: what you would want to understand first, and who you would want to learn it from. Follow-up 1, if they say a branch log is not a process: return to the log; answer slot: which parts of handling the log were yours, and what you did once a complaint was in it; if the log was the extent of it, or others handled the rest, say so plainly and stay with the log. Follow-up 2, if they ask what makes you ready: return to the log and the tellers, do not re-explain the contact centre, and finish on what you would do first. Never add a stage to the log | The role's own wording is "end to end across branches and the contact centre", and F1 and F2 are exactly where your material is thin, so this arrives in some form in rounds 2 and 3. JD because it scores the headline requirement, with Skeptic delivery |
| D2 | "You've never presented above regional level, and this role reports monthly to senior leaders. How do I know you'll hold the room?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I built the monthly complaints spreadsheet our regional manager uses." | Hold only what the sentences carry: "I built the monthly complaints spreadsheet our regional manager uses." Concede: "I haven't presented to anyone above regional level." Then a plan, in your own words, for the first report. Answer slot: if you have talked anyone through the sheet or its figures, say what that was and your part in it; if the sheet was only handed over, or nobody was talked through it, say so plainly and stay with the sheet you built | F9 is a stated gap and F3 is your nearest evidence. JD with a Pressure delivery: the test is whether you hold without bluffing |
| D3 | "Tell me about the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | The beats the sentence states: you built it, it is monthly, your regional manager uses it. Answer slot: expect a probe on what the sheet showed. If it carried volumes, resolution times or both, say which, how each was counted, and which assumption you would defend least; if it carried neither, or other things, say so plainly and say what it did carry; if the tool was not Excel, say which, and if parts were built with others, say which part was yours | F3 and F4 are the evidence for the reporting lines and the one thing in your background you can show. EXP; the weakest-assumption move is an answer slot because no figure was given |

**E. Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our brief targets moving 40% of member service to digital channels by 2028. What does that change about how we should handle complaints?" | CO | [grounded] | Clarify first: what counts as member service, and which channels complaints could come through. Then an objective, a view with your hypotheses marked as hypotheses, and one risk, for instance a member who needs the same thing explained twice. Use Ashgrove's words: "Plain Words" and "Members First, Always". Name the app-only banks as the pressure the brief names. Make no claim to digital experience: that is E2's job | The brief's headline number, and the recruiter's email says the manager will own digital with you. CO with CASE delivery |
| E2 | "Have you worked with digital teams on self-service journeys?" | JD | [grounded] | No sentence of yours carries this. Answer slot: if you have worked with a digital team or on a self-service journey, say what it was and which part was yours; if you have not, say so plainly, then say what you would want to learn from the digital team first, as a plan | F6 is a requirement with no evidence behind it; the honest second branch is the strong one |
| E3 | "What would you put in the monthly complaints report for me, and what would you want me to do with it?" | CASE | [generic] | Clarify first: what is reported today, and who reads it. Then the decision the report supports; the two measures the JD names, volumes and resolution times, by branch and by contact centre; one thing you would leave out; and what a change would look like on the page. Make no claim about what your own sheet showed: D3 covers that | The JD's reporting line asked as a decision rather than a record; `[generic]` because it is a pattern, not a fact about Ashgrove |

### Reverse questions for round 2

| Question | Why it lands |
|---|---|
| "Where does the complaints process work well today, across branches and the contact centre, and where do members get lost?" | Shows you are thinking about the whole process and gives you the starting facts you lack |
| "Who reads the monthly report, and what do they do with it?" | Prepares you for the presentation gap (F9) by finding out the real audience |
| "What would you want me to learn first, given I haven't worked in a contact centre?" | Turns the stated gap into a plan with your future manager's input; candour is what the Skeptic is checking |
| "How do you expect the digital target to change which complaints reach us?" | Ties to the brief and to the JD's digital-teams line, in the manager's own territory |
| "How much of the role would be in the contact centre, and how much with the branches?" | Practical and revealing; shows you are weighing the real scope |

---

# Round 3: Panel of two branch managers (60 minutes, including a 20-minute case; the values round)

### Persona weights, with reasoning

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | A story per value, scored against the four | High. The recruiter's email says the panel scores against the four values | One story option per value, from the values sheet below, with the honest branch ready |
| Case / Strategist | The 20-minute escalation case | High. Twenty of sixty minutes are a case | Clarify, structure, think aloud, use the company's words |
| Peer Evaluator | The seam between the role and the branch managers | Medium. The role coaches branch supervisors, and the branch managers are the supervisors' managers | Propose seam principles instead of claiming to know the seam; show what you bring them |
| Conversational | Friendly opening and closing | Low. Present, but it is the values round and the register will be scored | A short arc for the opening, a real question at the close |
| Pressure | Challenging what was actually yours | Low. It shows up once (H3) | Hold, then concede specifically |

### Bank (pending your approval)

**J. Values / Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Value: Members First, Always. Selection scaffold: pick a decision where the member's side and an easier internal route pointed different ways, name the decision, and say what it cost you or your branch. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, the log you handled, or how you would handle it | The value's own wording is "we decide from the member's side of the counter"; a specific decision is what scores, not the slogan. VAL; F1 is the nearest evidence |
| J2 | "Tell me about a time something had to be explained twice, and what you did about it." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Value: Plain Words. The nearest sentence is the teller training and the escalation script. Answer slot: if you ever changed the wording of the script, or of anything a member read, after it needed explaining twice, say what and why; if you never changed the wording, or it was not yours to change, say so plainly and stay with the training you gave. If no such time comes to mind, say so plainly, then give how you would handle it | The value says "if a member needs it explained twice, we wrote it wrong"; the question turns that into an instance. VAL; F5 is the nearest evidence |
| J3 | "Tell me about a time you thought of a branch as part of its town, not a number." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Value: Neighbours, Not Numbers. Selection scaffold: look inside your 3 years as a branch supervisor for an occasion where the branch's place in its town changed what you did, and say what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. With the hub plan in the brief, say nothing critical of it: acknowledge it, ask a question about it | The panel are branch managers and the brief's hub plan touches their branches, so this value is where the strategy and the values meet. VAL; F7 is the nearest evidence |
| J4 | "Tell me about a time you found a problem that wasn't yours to fix, and what you did." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Value: Own the Fix. Selection scaffold: it needs a problem you found, a reason it could have been passed on, and what you did so that it stayed held until it was solved. Use a different story from C1 if you have one. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, the log you handled, or how you would handle it | The value says whoever finds the problem keeps hold of it; this angle tests the part where the problem is not yours. VAL; F1 is the nearest evidence |

**G. Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | The 20-minute case, in a form to rehearse: "A member has complained twice at a branch and been told two different things. The supervisor escalated it late, and the member says they will move to an app-only bank. Walk us through what you do." | CASE | [generic] | The real case is unknown, so rehearse the structure. Roughly 3 minutes of clarifying (what the member was told, what has been recorded, whether it is a formal complaint and which clock and rules apply, what has been promised), 5 minutes of structure, 8 on the answer, 4 for follow-ups. Say the four values as working tools: decide from the member's side, say it in plain words, keep hold of it until it is solved, and think of the branch's town. End with what you would record and what the branch should learn. Make no claim to complaints you handled; none is needed | A case on a complaint escalation is what the recruiter named. `[generic]` because the actual case is not known; the upgrade menu says how to get it |
| G2 | "The supervisor escalated it late. What do you say to them?" | CASE | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Structure: facts first, ask what they saw before saying what you think, say what needs to happen next time and why, and agree how you will check it together. If they ask about your own coaching, your words are: "I trained new tellers on our escalation script." Stay at that scope | The JD's coaching line asked as a live problem; the panel manages these supervisors. CASE; F5 shows the limit of your material |
| G3 | "The contact centre closed the complaint, and the member walked into our branch still unhappy. Who keeps hold of it?" | CASE | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Whoever is in front of the member keeps hold, which is "Own the Fix" in Ashgrove's words. Say what you would do in the room, then what you would fix in the process afterwards. On the contact centre, say "I haven't worked in a contact centre" once, then say you would ask the contact centre what it could see. Use no claim to how a contact centre works | The seam between branch and contact centre is the role's central problem; F2 is the stated gap. CASE with a VAL angle |

**H. Peer / Pressure**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Our supervisors report to us and you'd be coaching them. Where's the seam, and what happens when we disagree?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Propose principles, not a map: the complaint's owner keeps it, the member's side comes first, and a disagreement is raised directly and early. You have stood as a branch supervisor, which is the point from which to ask what they need from the role: say what you would bring, such as a clear and early route for escalations, as an offer, not a claim | A peer-style probe on turf and disagreement; the panel are the supervisors' managers. JD; F7 is the one relevant sentence |
| H2 | "Eight branches become five hubs over 2027. What do you expect that to do to complaints, and what would you want to know first?" | CO | [grounded] | Clarify first: which branches, in what order, what happens to the services in each. Offer hypotheses marked as hypotheses, never a volume forecast, and tie one to "Neighbours, Not Numbers". Do not criticise the plan. The branch managers' own branches may be affected, so ask, do not assume | The brief's second headline, asked by the people it touches. CO with CASE delivery |
| H3 | "How much of the log, the training and the spreadsheet was actually you?" | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Hold at the sentences' size: "I handled the branch's formal complaints log", "I trained new tellers on our escalation script", "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if any of the three was shared or directed by others, say which and what part was yours; if all three were yours as stated, say so and stop. Hold through two follow-ups by returning to the sentences, never by adding to them | The attribution probe every prober or skeptic uses; F1, F3 and F5 are the three claims. EXP with Pressure delivery |

### Values / principles cheat sheet (round 3)

Official names and wording are from the page you copied this morning, 26 November 2026, from ashgrovecu.org/about/values. Proposed language, pending your approval.

| Value (official name) | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Selection scaffold on F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Pick a decision where the member's side cost something; if none comes to mind, say so plainly, then give the nearest thing your material does carry or how you would handle it (asked as J1) |
| Plain Words | If a member needs it explained twice, the wording was wrong | Selection scaffold on F5 (asked as J2): "I handled the branch's formal complaints log and trained new tellers on our escalation script." The teller training is the nearest sentence; if no occasion comes to mind, say so plainly, then give how you would handle it |
| Neighbours, Not Numbers | Every branch is part of its town | Selection scaffold on F7 (asked as J3): "6 years in retail banking, the last 3 as a branch supervisor." Look inside the 3 years for an occasion; if none comes to mind, say so plainly, then give the nearest thing your material does carry or how you would handle it |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Selection scaffold on F1 (asked as J4): "I handled the branch's formal complaints log and trained new tellers on our escalation script." The log is the nearest evidence; if no occasion comes to mind, say so plainly, then give how you would handle it |

None of your sentences carries a full story for a value, so all four are scaffolds. Finding one real occasion per value before 5 December is the single most useful thing you can do for this round.

### Reverse questions for round 3

| Question | Why it lands |
|---|---|
| "Which escalations reach you late, and what do you wish the supervisor had done differently?" | Shows you are thinking about the branch's problem, and the answer is the panel's own case in miniature |
| "How would you like me to coach your supervisors: in the branch, in a group, or another way?" | Treats the seam (H1) as something to agree rather than assume |
| "How will the move from eight branches to five hubs change what escalations look like at your branch?" | Ties to the brief and to "Neighbours, Not Numbers", asked of the people it affects |
| "What could a new lead do in the first month that would genuinely help your branch?" | The reciprocity question: what you bring to them, not only what you need |
| "Which of the four values is hardest to live at your branch, and what does it look like done well?" | Shows you have read the values and invites a concrete example from the panel |

---

## Requirement coverage

| JD requirement | Questions that cover it |
|---|---|
| "Own the member complaints process end to end across branches and the contact centre" | D1, B1, G1, G3, H3 |
| "report monthly on complaint volumes and resolution times" | D3, E3 |
| "coach branch supervisors on escalations" | C3, G2, H1 |
| "work with digital teams on self-service journeys" | E1, E2 |
| "4+ years in financial-services customer operations" | A1 |
| "experience handling regulated complaints" | B2, G1 |
| "confident presenting to senior leaders" | D2, C2 |
| "comfortable with Excel reporting" | D3, E3 |

The four published values are covered by C1 and J1 to J4.

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the member complaints process end to end across branches and the contact centre | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: your material says one branch's log, not a process across branches. D1's slot stays with what you did once a complaint was in the log |
| Has worked in, or handled complaints for, a contact centre | Negative you stated, F2 | The plain acknowledgment: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F9 | The plain acknowledgment: "I haven't presented to anyone above regional level." No slot |
| Coached branch supervisors on escalations | Inflated form of F5 | F5's quote at its own scope: "I trained new tellers on our escalation script." The limit is the pack's observation: your material says new tellers, not supervisors. C3's slot stays with the training you gave |

## Sources

**Provided documents:** the job description you pasted; Ashgrove's values, which you copied this morning from ashgrovecu.org/about/values; the recruiter's email about the three rounds; the points of the July 2026 strategy brief, as you relayed them (I did not read the brief itself); your own background, in your message. No dossier was present.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values page supplies the four names and their wording, which fix the values sheet and F1 to F4 |
| 2. Ashgrove interview process, member services | skipped | The recruiter's email names three sessions and who runs each, which fixes the loop, the persona weights and the choice of loop mode |
| 3. Ashgrove strategy and recent news | skipped | The July 2026 strategy brief, as you relayed it, is under six months old and fixes the grounding brief and the CO questions |
| 4. Interviewer name and company | n/a | No names are assigned yet, so there is no query to form; the interviewer read is absent and the upgrade menu says what names would unlock |
| 5. Representative Member Experience Lead JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- **The interviewers' names, once assigned** → an interviewer read for each round, persona weights adjusted from their public professional footprint, and a reverse question tied to each one's own path
- **Your answers to the answer slots in F1, F3, F4, F5, F6 and F8** → those rows stop being slots: say what is true and I quote it into the snapshot and regenerate the questions that draw on it, whichever way the answer goes
- **An anonymised copy of the monthly complaints report, or the layout of the log, with no member data** → F3 and F4 can move from medium toward high, because it is the inspectable artifact in this field
- **One occasion per value for "Members First, Always", "Plain Words", "Neighbours, Not Numbers" and "Own the Fix"** → the values sheet moves from four scaffolds to four mapped stories, once you say them outside a drill
- **The full text of the strategy brief** → the grounding brief reads from the source instead of from your summary, and the CO questions can quote it
- **The recruiter's reply on the case format and the complaints rules the role works to** → G1 and B2 stop being `[generic]` and become tuned to the real case and regime
- **How many hours you have before 5 December** → a prep triage: the few things to do well, in order
- **A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes** → recent Ashgrove news and organisational context, plus reports of how this kind of loop has run, for the CO bank and the grounding brief
- **A `tuesday-dossier.md` from an earlier evaluation of this role** → verified evidence and a prohibited-claims list that would replace the ones this pack built locally from your own sentences
