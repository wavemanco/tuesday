# Interview pack: Product Manager, Platform APIs at Quartzline

Round: a 45-minute conversation with the hiring manager (name not given). Built on your Tuesday dossier (conditional_go) and what you told me about the round. Quartzline-specific research was refused in this session, so nothing here claims to know Quartzline's values, loop or strategy.

## How to use this pack

Personas describe how a question arrives; types describe what it is scoring. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Tag | Scores |
|---|---|
| VAL | Past behaviour against the company's published values (none in this pack: no values source or values round was available) |
| EXP | Whether claims about your experience survive scrutiny |
| JD | Whether you can do the listed job, gaps included |
| CO | Homework on the company and its strategy |
| CASE | Reasoning on a live problem from the role |

The highest-ROI rehearsal is B1. The dossier names that objection, and the pack gives it the deepest rehearsal. A line in a guidance cell that starts "Answer slot" is an instruction for the interview, not a question for you now.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — JD (dossier role_profile R1) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1 | low | [grounded] | transferability | Adjacent, with the limit named as the dossier frames it: position it as adjacent, never as product management experience. The material shows integration leadership, not a product role. Words: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Plain acknowledgment, sourced by the dossier's prohibited_claims item "Having held a product manager title or role": "I haven't held a product manager title or role." |
| F2 | "Own the roadmap for the partner-facing API platform" — JD (dossier role_profile responsibilities) | none given | none | [grounded] | capability | The dossier records this as an acknowledge_gap area, so no bridge is coached. Plain acknowledgment, sourced by that area and by prohibited_claims "Having owned a product roadmap": "I haven't owned a product roadmap." Then a plan, said as a plan and never as a past: learn where decision rights sit, how adoption is measured and what the baseline is. The roadmap-input sessions in F7 are a different requirement and are not an answer to this row |
| F3 | "Shipped API or platform products" — JD (dossier role_profile R2) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1 | low | [inferred] | transferability | The quote carries integrating the vendor's REST APIs, not shipping an API or platform product. The dossier's weak-area list has no entry for R2, so no underwriter strategy attaches; the pack applies the same limit it applies to F1. Answer slot: R2 is a must-have, so expect a probe on what you shipped. If any of this work was shipping a product or platform feature, say what and what part was yours; if none of it was, or it was not yours, say so plainly and stay with the integrations you led |
| F4 | "Technical fluency: API docs, schemas" — JD (dossier role_profile R3) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence 2 | medium | [grounded] | discovery | The quotes touch REST APIs, architecture and a written playbook without showing API docs or schemas; the playbook is the inspectable artifact. Answer slot: the JD's wording makes a probe on docs and schemas likely. If you read or wrote schemas or API docs in this work, say which and how; if you did not, say so plainly and stay with the integrations you led and the playbook you wrote |
| F5 | "Stakeholder management across engineering, sales, customers" — JD (dossier role_profile R4) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence 3 | medium | [inferred] | discovery | The quotes carry clients and product; they do not show engineering or sales. Entry 3 is confirmed with limited inspectable proof, so expect a probe. Answer slot: if you worked with engineering or sales in this work, say who and what part was yours; if you did not, say so plainly and stay with clients and product |
| F6 | "Agile delivery experience" — JD (dossier role_profile R5) | none given | low | [grounded] | discovery | Nothing in the verified evidence speaks to this, so no bridge is built from nearby work. Answer slot: the interviewer's probe will be the requirement's own wording, "Agile delivery". If you have worked in agile delivery inside a product org, say how, in your own words; if you have not worked that way, say so plainly, and say what you would want to confirm about how they define it |
| F7 | "Run discovery with integration partners" — JD (dossier role_profile responsibilities) | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence 3 | medium | [grounded] | transferability | Words at the quote's own scope: "I ran quarterly roadmap-input sessions feeding client evidence to product." Confirmed with limited inspectable proof, so volunteer the limit before it is extracted. Answer slot: if the clients in those sessions were integration partners as the JD uses the term, say so; if they were not, say so plainly and stay with the sessions as described |
| F8 | "Write specs and drive delivery with two engineering squads" — JD (dossier role_profile responsibilities) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1 | low | [inferred] | discovery | The quote says requirements and go-live were part of integrations you led; it does not say specs were written for engineers to build from. Answer slot: if any requirements you worked on were written down as documents engineers built from, say what and what was yours; if not, or it was not yours, say so plainly and stay with the integrations you led |
| F9 | "Define and track adoption metrics" — JD (dossier role_profile responsibilities) | none given | none | [grounded] | discovery | Silence, not an absence the dossier records. Answer slot: if you tracked usage or adoption of anything, say what was counted; if you did not, say so plainly and say what you would measure first. The dossier also lists as unknown how adoption is measured today |

The dossier's decision line mentions seven years of integration leadership. No verified entry carries a duration, so no row or guidance cell states one. If you want to state your tenure, say it in your own words.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (weight: 5 questions) | Live problems from the partner API roadmap: diagnose, prioritise, plan | High. Relationship prior for a hiring manager is Case/Strategist plus Skeptic; nothing about the interviewer or loop adjusts it | Clarify first, then objective, segmentation, approach, metrics, risks; think aloud; ask the dossier's two unknowns as clarifying questions |
| Skeptic (weight: 5 questions) | Quiet probing of the missing title and roadmap ownership | High. Same prior, and the dossier names the objection | Rehearse B1 until it is boring: concede first, hold what the quotes carry, name the limit before it is asked |
| Conversational (weight: 3) | "Walk me through your journey" in a friendly register | Medium. A 45-minute hiring-manager conversation usually opens this way; casual questions are still scored | A 90-second arc built from your three verified entries at their own scope (C1) |
| Data-Driven Prober (weight: 3) | Pushes on the 30+ figure and the playbook | Medium. A headline figure and a medium-confidence entry are what probers go to | Know what you can say about how 30+ was counted; say plainly when you do not know |
| Peer Evaluator (weight: 2) | The seam with the two squad leads | Lower. A hiring manager asks this as a scenario, not as a peer | Offer seam principles and ask where decision rights sit; do not pretend to know the seam |
| Pressure (weight: 2) | Time-boxed "why you" and a challenge on prioritisation | Lower. No signal of a stress style; included so the delivery is not new live | Pause, restate, hold the quoted ground through two follow-ups, concede specifically |

Persona weights rest on the hiring-manager prior and on the dossier. No interviewer profile, loop source or recruiter guidance was available.

## Question banks

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "How would you define and track adoption for a partner-facing API?" | CASE | [generic] | Structure it: who counts as an adopter, what counts as adopted (first successful call, production traffic, retained use), what you would segment by, what you would watch for gaming. Ask first how adoption is measured today and what the baseline is; the dossier lists both as unknown. Answer slot: if asked what you have tracked yourself, say what was counted; if you tracked nothing of the kind, say so plainly and say what you would measure first | F9 is silence and the JD names adoption metrics as a responsibility; CASE delivery of a JD item |
| A2 | "Two squads each want the next quarter. One wants a reliability rework, the other a webhook feature a partner asked for. How do you decide?" | CASE | [generic] | The question needs no claim about your past, so the guidance makes none. Structure: what evidence you would want from each lead, what outcome each is meant to move, what it costs to wait, and who holds the decision. Say plainly that you would first want to know which of these calls is yours and which is the squad leads'; that is also your reverse question 1 | Tests the roadmap and decision-authority area the dossier flags as unresolved (F2); CASE because it is a live trade-off |
| A3 | "A partner's first integration fails at the schema validation step. How do you work out whether it is a documentation, product or partner problem?" | CASE | [generic] | Structure it: reproduce, read the request against the schema, check the docs against the schema, check how many other partners hit the same step, then decide who owns the fix. The question asks about no past. If you are asked whether you have handled this kind of failure, use F4's answer slot and nothing beyond it | Covers technical fluency (F4) as a live problem so it does not rest on a claim |
| A4 | "What would your first 30 days look like?" | JD | [generic] | A ramp plan, said as a plan: learn where decision rights sit between this role and the two squad leads, how adoption is measured and the baseline, how the squads run delivery, what partners are asking for. This is the honest ramp for the roadmap gap, so do not present it as experience | F2 is a gap the dossier says to acknowledge with a plan; this is where the plan is rehearsed |
| A5 | "The role has you writing specs and driving delivery with two engineering squads. What have you written that engineers built from?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The quote says requirements were part of integrations you led. Answer slot: if any requirements you worked on were written down as documents engineers built from, say what and what was yours; if not, or it was not yours, say so plainly and stay with the integrations you led | F8: the JD raises specs, the quote does not show them |
| A6 | "What do you know about our partner API platform, and where would you take it?" | CO | [generic] | Research was refused here, so the pack has nothing current about Quartzline. Before Thursday, read what Quartzline publishes about its API and partners, then bring one observation and one question rather than a recitation | Homework depth; `[generic]` because it is a pattern, not a fact about Quartzline |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | Named by the dossier as the objection to rehearse most. Concede first, bridge second, name the limit before it is asked. Concede: "I haven't held a product manager title or role, and I haven't owned a product roadmap" (dossier prohibited_claims "Having held a product manager title or role" and "Having owned a product roadmap"). Bridge: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live — and I wrote the internal integration playbook my team uses." Limit: "That is adjacent to product work, not the same thing." Then a plan: decision rights, adoption baseline, how the squads run delivery. Follow-up 1, "a PM with three years has actually prioritised": hold, with "I haven't set prioritization for an engineering squad" (prohibited_claims "Having set prioritization for an engineering squad"), then return to the quotes. Follow-up 2, "then why not hire the PM": concede specifically that the other candidate has roadmap and prioritisation experience you do not; hold what the quotes carry and stop. Do not answer this with the roadmap-input sessions; they answer different questions (C1, D3, F7) | F1 and F2 are the biggest gaps; the dossier names this objection; JD because it scores the title requirement, with Skeptic delivery |
| B2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] dossier acknowledge_gap and prohibited_claims "Having owned a product roadmap" | Name the roadmap and prioritisation authority yourself before they do: "I haven't owned a product roadmap." Then the plan from A4, as a plan. Do not add a bridge to this answer, since the dossier looked for one and found none. Naming one gap precisely reads better than a list | F2 acknowledge_gap; the stem is the Skeptic's standard probe |
| B3 | "The role asks for shipped API or platform products. What have you shipped?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Say the quote at its own scope. Answer slot: if any of this work was shipping a product or platform feature, say what and what part was yours; if none of it was, or it was not yours, say so plainly and stay with the integrations you led | F3, a must-have the dossier did not put on its weak-area list; the premise is the JD's and the guidance does not adopt it |
| B4 | "Why move from leading integrations into a product seat where you would start by learning?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Selection scaffold: your reason must be your own and must be true. Answer slot: if the roadmap-input sessions are part of why you want the move, say so in your own words; if they are not, say what is. Do not invent a reason. Volunteer that entry 3 is confirmed with limited inspectable proof only if asked about it | Motivation consistency is what the Skeptic scores; F7 is the only entry near a move toward product |
| B5 | "Tell me about a time you had to hold engineering, sales and a client to one plan." | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Selection scaffold: pick an occasion with a named stake, what each side wanted, what you did and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries (the quote, at its scope) or how you would handle it | F5: the quotes show clients and product, not engineering or sales |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So — walk me through the journey. How did you get to wanting this role?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc with three beats, each at its quote's scope: the integrations you led, the playbook you wrote, the roadmap-input sessions you ran. The reason for the move is your own; the pack does not supply it. Entry 3 is confirmed with limited inspectable proof, so say what you can show of it | F1, F4 and F7 supply the arc; EXP because it tests whether the story holds together |
| C2 | "The role calls for fluency with API docs and schemas. Where does yours come from?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | Say the two quotes at their scope. Answer slot: if you read or wrote schemas or API docs in this work, say which and how; if you did not, say so plainly and stay with the integrations you led and the playbook | F4; the premise "yours" is the JD's, so the second branch allows it is false |
| C3 | "How does your team plan and ship work today?" | JD | [grounded] requirement "Agile delivery experience" | A question-shaped answer: ask how they define agile delivery and what cadence the two squads run. Answer slot: if you have worked in agile delivery inside a product org, say how, in your own words; if you have not worked that way, say so plainly and say what you would want to confirm about how they define it | F6, a clarify area; casual in register, still scored |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You led 30+ end-to-end client integrations. How was that counted?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Four slots, each in your own words: how it was counted, what the figure is sensitive to, the assumption behind it you would defend least, and which part was yours. Say "30+" as the source states it. "I don't know how it was counted" is an honest answer; the pack supplies no method | F1's headline figure; probers go here first |
| D2 | "Walk me through the playbook you wrote. What is in it and who uses it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | You wrote it and your team uses it; that is the scope. Describe what is actually in it, from the document. It is the inspectable artifact the dossier cites, so bring it if the format allows | F4; the strongest verified entry, so it should be easy to defend |
| D3 | "Those roadmap-input sessions: how often, who attended, and what happened to what you fed in?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | The quote gives you quarterly, and that you ran them. Answer slot: if you know what product did with the evidence, say what; if you do not know, say so plainly and stay with the sessions as they ran. This entry is confirmed with limited inspectable proof, so say what you can show before being asked | F7; the dossier says to expect a probe here |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "You will sit between two squad leads. Where is the seam between your call and theirs, and what happens when you disagree?" | CASE | [generic] | Offer seam principles rather than pretending to know the seam: product owns the what and why, engineering owns the how, and disagreement goes to evidence and then to whoever holds the decision. Say plainly that you do not yet know where decision rights sit here, and ask. Reciprocity: what you would do to lighten their load | The dossier's top validation risk is decision authority versus the two squad leads |
| E2 | "Tell me about a time you disagreed with an engineering lead and how it resolved." | JD | [generic] | Selection scaffold: a named stake, what each side wanted, what you did, how it ended and the relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | F5's engineering gap |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over someone who has done this job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The B1 answer compressed: concede first ("I haven't held a product manager title or role"), then the quote at its scope, then stop. Hold through two follow-ups and concede specifically; do not fold on the quote and do not add to it | B1 under a clock |
| F2 | "You haven't prioritised for an engineering squad. Two squad leads will test that in week one. What do you do when one says no?" | CASE | [grounded] dossier prohibited_claims "Having set prioritization for an engineering squad" | Acknowledge with the sourced words: "I haven't set prioritization for an engineering squad." Then the plan: bring evidence, ask what the squad is optimising, agree who decides before the disagreement, not during it. No past is claimed | F2; hold-then-concede on a gap the dossier lists |

## Requirement coverage

| Requirement | Questions |
|---|---|
| R1 3+ years PM experience (F1) | B1, B2, F1, A4 |
| Own the roadmap (F2) | B1, B2, A2, A4, F2 |
| R2 Shipped API or platform products (F3) | B3 |
| R3 Technical fluency (F4) | A3, C2, D2 |
| R4 Stakeholder management (F5) | B5, E1, E2 |
| R5 Agile delivery (F6) | C3 |
| Run discovery with partners (F7) | D3, C1 |
| Write specs, drive delivery with two squads (F8) | A5, E1 |
| Define and track adoption metrics (F9) | A1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The dossier's top unresolved risk: authority over the squads is asserted in the JD and not evidenced. It reads as diligence and tells you what you would be accepting |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | The dossier flags adoption metrics as a named responsibility with no baseline; a weak baseline changes what success means |
| 3 | "What would you want this person to have learned by day 90?" | Turns the gap into a shared plan and tells you what the manager actually weighs |
| 4 | "How do the two squads run delivery today, and what does agile mean on your team?" | Resolves the R5 clarification (F6) and is an honest question given you have not said you know their process |
| 5 | "How does partner feedback reach product today, and who owns it?" | Probes the discovery responsibility (F7) and shows you thought about the input side |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims "Having held a product manager title or role" | F1's quote at its own scope, plus the plain acknowledgment "I haven't held a product manager title or role" |
| Having owned a product roadmap | Dossier prohibited_claims "Having owned a product roadmap" and the acknowledge_gap area on roadmap and prioritisation authority | The plain acknowledgment "I haven't owned a product roadmap" and a plan. Not the roadmap-input sessions, which are F7's separate entry |
| Having set prioritization for an engineering squad | Dossier prohibited_claims "Having set prioritization for an engineering squad" | The plain acknowledgment "I haven't set prioritization for an engineering squad" and the plan in F2 |
| Shipped an API or platform product | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material says integrations of the vendor's REST APIs, not shipping them |
| Shaped the roadmap through partner discovery | Inflated form of F7 | F7's quote at its own scope. The limit is the pack's observation: the material says the sessions fed client evidence to product, not what product did with it |

## Sources

Provided documents: tuesday-dossier.md, version 1.1, generated 2026-08-14. The pack consumed handoff_to_mock_interview (verified evidence, weak areas and their allowed strategies, objection, risks, employer questions, prohibited claims) and role_profile (requirements and responsibilities, standing as the JD). evidence_map and evidence_state were not present. The dossier is older than today's date; if anything about your evidence has changed since, say so and I will regenerate the affected rows.

Round and relationship came from your message: one 45-minute conversation with the hiring manager. No loop source documents a values round, and none was needed to fix this session, so no archetype fallback applies and no values cheat sheet is included.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | All calls refused (query: "Quartzline company values"). Would have named the values and any VAL questions; nothing used |
| 2. Quartzline interview process, product manager | unavailable | All calls refused (query: "Quartzline interview process product manager"). Would have checked the round against a documented loop; persona weights rest on your description and the hiring-manager prior |
| 3. Quartzline strategy / recent news | unavailable | All calls refused (query: "Quartzline platform API strategy news"). Would have grounded A6 and a CO or CASE question in current strategy; A6 is generic |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form |
| 5. Representative Product Manager JD | skipped | The dossier's role_profile supplies the requirements and responsibilities |

## Upgrade menu

- The hiring manager's name → a reading of their public footprint, adjusted persona weights and a reverse question tied to their own path
- The recruiter's prep note, if any → coverage of anything pre-declared, and a check of the loop against what is assumed here
- Search access, or a pasted Quartzline values page and strategy brief → a values map (if a values round exists) and an A6 grounded in Quartzline's real direction. A deeper research pass, up to 6 more searches and 2 more fetches and several more minutes, is available once if you want it
- The integration playbook and notes or an agenda from the roadmap-input sessions → entry 3 moves from medium toward high confidence; D2 and D3 get stronger
- Your own answers to the slots in F3, F4, F5, F7, F8 and F9, stated outside a drill → those rows regenerate from your words
- The dossier's author's view on R2, a must-have with no weak-area entry → F3's strategy would then be the underwriter's rather than the pack's inference
- Your raw CV → more story-mapped rows beyond the three verified entries
