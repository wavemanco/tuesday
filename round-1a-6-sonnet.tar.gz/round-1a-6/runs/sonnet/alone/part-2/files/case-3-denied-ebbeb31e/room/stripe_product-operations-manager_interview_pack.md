# Interview prep pack: Product Operations Manager, Stripe

Final-round interview. Interviewer name and relationship: not given. Built on the assumption that the final round blends several conversation styles, since the schedule is unknown.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for your own words, not a script. Nothing here is a fact about your past, because no CV or background was provided; every guidance cell is a selection scaffold or a structure for a live problem.

| Tag | Meaning |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether your claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge (none in this pack, see Sources) |
| CASE | A live problem, scored on structure and reasoning |

Each question carries one primary type. Where a question could be read two ways, the rationale says so.

## Fit snapshot (worksheet)

No JD and no CV were provided, and the research searches were refused, so there are no quoted requirements and no evidence to quote. The rows below are role-family requirements written as plain prose, labeled `[generic]`, and each evidence cell is `none given`. Adding a JD and CV turns this into a real snapshot.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinate launches or process changes across product, engineering and other teams (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is one named launch or process change, with your part stated in your own words. Selection scaffold: pick one where several teams depended on you, with a named stake and a result you can describe; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Define, track and report operating metrics (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a metric you were accountable for and can say how it was counted. Selection scaffold: pick one number, know what it counts and what it excludes, and name the assumption behind it you would defend least; if no such number comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Run recurring operating mechanisms such as reviews, planning cycles and launch checklists (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a recurring mechanism you built or ran, with what you kept and what you dropped. Selection scaffold: pick one, and be ready to say which part was set for you; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Influence senior stakeholders without formal authority (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a moment you held a position with someone more senior and the relationship stayed intact. Selection scaffold: pick one with a named stake and a moment you did not fold; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Use data to diagnose problems (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is an analysis you did yourself and can walk through end to end. Selection scaffold: pick one, and say which tools and which data were yours; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Where the role is based, and whether you can work there (a term, role-family pattern, no source) | none given | none | [generic] | hard_gate | Your material does not establish whether this term is met. It is surfaced, not bridged, and wording cannot settle it |

### Requirement coverage

| Requirement | Questions that cover it |
|---|---|
| F1 | A1, A2, D1, D2 |
| F2 | A4, F1, F2 |
| F3 | A3, A5, B3 |
| F4 | C1, E3, B1 |
| F5 | A4, F1 |
| F6 | none, and why: a gate is surfaced and not rehearsed, and no question can answer it |
| Motivation, not a requirement | B2, E1, G1 |

## Persona table

No source establishes how Stripe's final round is structured, so persona weights rest on the generic archetype (screen, hiring manager, panel) and are close to flat. Treat the order as a starting point and recalibrate if you know who you are meeting.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | Live problems from the role: diagnose, prioritize, design a mechanism | Highest. A hiring-manager conversation is the most common final-round slot, and operations roles are usually scored on structure | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise politely |
| B. Skeptic | Quiet probing of gaps, motivation and role definition | High. Every candidate has a thinnest area, and a final round is where it gets tested | Rehearse the single most predictable objection until it is boring; build bridges only from what you can say you did |
| D. Peer Evaluator | Seam questions with an adjacent team, credit, collaboration | Medium. Operations roles sit between teams, so a cross-functional interviewer is plausible | Offer what you bring their team, propose seam principles rather than claiming to know the seam |
| E. Pressure | Time-boxed challenges, devil's advocate | Medium. Final rounds with senior interviewers often test composure | Pause, restate, anchor in what you can actually say, hold through two follow-ups before conceding |
| C. Values/Behavioral | Behavioral prompts scored against published values | Medium. No values round was detected, because no source was readable, so these use generic stems only | Pick stories where the hard truth landed; say plainly where you have none |
| F. Data-Driven Prober | Walks a number back to its inputs | Medium-low. Depends on whether your CV carries figures, which is unknown | Know how each figure was counted, or say plainly you do not know |
| G. Conversational | Friendly openers that are still scored | Medium-low but certain to appear somewhere | A 90-second arc for the biography question; never answer the reverse-question slot with "I think you've covered everything" |

## Question banks

Highest-ROI prep in this pack: **B1**. It will be asked in some form, it needs nothing from a CV to rehearse, and a calm, specific answer changes the interview. This is inferred from the persona stems, not from your material.

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A feature launched last week and support says tickets have doubled. You own the cross-team response. What do you do in the first two days?" | CASE | [generic] | Clarify first: which feature, which ticket types, since when, what changed besides the launch. Then triage in order: stop the bleeding, find the cause, assign owners, set a communication rhythm. Name the metric you would watch and what would tell you it was working | A live problem from the role family; CASE because it scores structure, with F1 as the requirement it touches |
| A2 | "Three product teams each want your help launching in the same month and you can support one well. How do you choose?" | CASE | [generic] | State your criteria before the answer: impact, readiness, risk, dependency on you. Say what you would ask each team. Then pick, and say what the other two get instead of nothing | Tests prioritization under scarcity, the core daily tension of the role family; F1 |
| A3 | "Design the weekly operating review for a product org of ten teams. What is in it, and what is deliberately left out?" | CASE | [generic] | Start with the decisions the meeting exists to make, then the inputs, then the cadence and owners. The strongest part of the answer is what you leave out and why | Mechanism design is the visible output of this role family; F3 |
| A4 | "A conversion rate dropped 20 percent overnight. Diagnose it." | CASE | [generic] | Clarify definition and timing, check instrumentation before behavior, segment, then list causes in order of cheapness to check. Say what would change your mind | A standard diagnostic stem; F2 and F5 |
| A5 | "How would you decide whether a recurring product process is worth keeping?" | CASE | [generic] | Offer a test: what decision or risk it serves, who would notice if it stopped, what it costs per cycle. Say how you would trial removing it | Probes judgment about process overhead, a common operations failure mode; F3 |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name one real area in a single sentence, say what you would do in the first 30 days to close it, and stop. Choose it from your own sense of the role, never one you cannot back. Do not name a fake weakness | The rehearsal this pack ranks highest; JD because it scores honest self-assessment against the role, across F1 to F5 |
| B2 | "Why this role, why Stripe, and why now?" | EXP | [generic] | Give two reasons only you can state: one about the work, one about the company. The company reason has to come from something you read or used yourself; no company research was available to this pack, so do not borrow a reason from it | Motivation consistency is scored in final rounds; EXP because it tests whether your story holds under follow-up |
| B3 | "How is product operations different from program management, in your view?" | JD | [generic] | Give a definition in one sentence, one example of each in terms of output, and where you think the line blurs. Say which you have done more of only if you can state it plainly; if you cannot, say so | Role-definition clarity is a common skeptic probe for this title; F3 |
| B4 | "What would someone reading your résumé be most likely to doubt?" | EXP | [generic] | Answer before they do: name the doubt, concede what is true in it, and give the nearest thing you can state about your actual work. Never rebut with a claim you cannot back in a follow-up | Invites you to name your own gap, which interviewers read as calibration; F1 to F5 |

### C. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time with a named stake where the hard truth actually landed and the relationship held. Use "we" for context and "I" for what you did; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem; F4. VAL because it scores behavior, though in a hiring-manager round it reads as EXP |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a decision with a visible cost to the internal metric and say what you did and what it cost; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem; generic because no published values were readable to this pack, so the theme is not tied to Stripe's own wording |

### D. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles, not a map: who owns the decision, who owns the follow-through, how a disagreement escalates. Say what you would bring to their team, not only what you would need | Persona stem; F1 |
| D2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Say what you do as a habit, then give an instance only if you can state your part and others' parts plainly; if no such time comes to mind, say so plainly, then give how you would handle it | Persona stem; F1 and F4 |
| D3 | "What would you need from me in your first month?" | JD | [generic] | Ask for specifics you could act on: the two or three decisions that matter most, the people to meet, where the data lives. End with what you will have delivered back by the end of the month | Reciprocity probe; JD because it scores how you would ramp |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over an internal candidate?" | EXP | [generic] | Pause, restate the question, and give two things you can state about your own work. Do not disparage the alternative. If pressed, hold the position through two follow-ups, then concede specifically what you do not know about the team | Persona stem; hold-then-concede structure |
| E2 | "Pick the result you are proudest of. How much of it was actually you?" | EXP | [generic] | Choose a result whose division of credit you can state precisely: what was yours, what was a teammate's, what was luck. State the split before they ask, and hold it through two follow-ups; if no such result comes to mind, say so plainly, then give the nearest thing your material does carry | Persona stem; attribution honesty is what this tests, across F1 and F2 |
| E3 | "I am not convinced this role needs to exist. Convince me in two minutes." | JD | [generic] | Do not get defensive. Concede what is true in the doubt, then say what breaks without the role, in terms of decisions that get slower or errors that repeat. Offer the test you would use to see whether it is working | Tests composure and role-definition clarity at once; F4 |

### F. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Pick a number you have been accountable for. Walk me through how it was counted." | EXP | [generic] | Say what the number counted and excluded, what it was sensitive to, and which part of it was yours. Say plainly where you do not know how an input was produced; if no such number comes to mind, say so plainly, then give the nearest thing your material does carry | Persona stem; the defend-the-number rehearsal, F2 and F5 |
| F2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | Name it before they do, in your own words. Naming the weakest assumption converts a gotcha into a credibility gain. If you do not know one, say so plainly | Follows F1; the weakest-assumption move |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc in your own words: where you started, the one or two turns that matter for this role, and why this role is next. Every sentence has to be something you could expand on if asked | Persona stem; casual openers are still scored |
| G2 | "What are you reading or experimenting with right now that relates to this work?" | JD | [generic] | Name one real thing and one thing you took from it. If nothing comes to mind, say so plainly, and say what you would pick up first | Conversational probe for genuine interest; scored even though it feels casual |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How does the team decide what product operations works on, and what it says no to?" | Shows you think about scarcity, which is the role's central tension |
| R2 | "What does a good first ninety days look like, and how would you know I was on track?" | Turns the interview into a shared definition of success |
| R3 | "Which of the team's operating mechanisms are you least satisfied with today?" | Invites candor and shows you look for work, not credit |
| R4 | "Where does this role's remit end and the product managers' begin?" | Surfaces the seam that peer interviewers probe, from your side |
| R5 | "What is the hardest cross-team disagreement the team has had recently, and how did it resolve?" | Gives you a real example of how the culture handles friction |
| R6 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity question for a peer or cross-functional interviewer |
| R7 | "What would make you hesitate about me that I can still address?" | Lets you answer an objection in the room, not after it |

## Prohibited claims

None built. Your material gave no sentence to inflate and stated no negative, so the pack asserts nothing about your past and lists nothing it will not coach. When you add a CV or background, this section is rebuilt before any bank is rewritten.

## Sources

Provided documents: none. The pack rests on your message alone: the company, the role and the round name.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values and operating principles | unavailable | Search refused (query: "Stripe operating principles values"). Would have moved the values cheat sheet and the VAL bank's wording |
| 2. Stripe interview process, product operations | unavailable | Search refused (query: "Stripe interview process product operations manager final round"). Would have moved persona weights and loop structure |
| 3. Stripe strategy and recent news | unavailable | Search refused (query: "Stripe strategy 2026 annual letter news"). Would have moved a CO question and a grounding brief |
| 4. Interviewer name | n/a | No name was given, so there was no query to form |
| 5. Representative Product Operations Manager JD | unavailable | Search refused (query: "Stripe Product Operations Manager job description responsibilities qualifications"). Would have turned the F rows into `[inferred]` rows with quoted requirements |

No loop source established the loop, so persona weights use the generic archetype (screen, hiring manager, panel) at near-flat weights. Nothing here claims how Stripe's final round is structured.

## Upgrade menu

- The job description text → the F rows get quoted requirements and become `[grounded]`, and JD-tagged questions are rebuilt against its own list
- Your CV or a few lines of background → evidence cells fill in, guidance becomes story-mapped instead of selection scaffolds, and the prohibited list is rebuilt. The artifact that would raise confidence is a launch plan, an operating-review deck or a metrics dashboard you can show
- Round type and who you are meeting → persona weights recomputed, and banks added or dropped. If your final is several sessions, send the schedule and I will build per-session mini-packs
- Interviewer names → an interviewer read, and a reverse question tied to their path
- The recruiter's prep email → coverage of any announced deliverable, such as a presentation or take-home
- Search permission → Stripe's published values, loop reports and recent strategy, which would unlock a values cheat sheet and a company-strategy CASE question
- Whether you can work from the role's location → F6 moves from surfaced to settled
- A tuesday-dossier.md from job-underwriter, if you have one → verified evidence, a named top objection and constraints on what may be claimed, in place of the inferred ones here
