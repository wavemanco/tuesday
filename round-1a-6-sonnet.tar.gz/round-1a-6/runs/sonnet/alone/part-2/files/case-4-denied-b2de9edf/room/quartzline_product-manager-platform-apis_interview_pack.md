# Interview prep pack: Product Manager, Platform APIs at Quartzline

**Interviewer:** the hiring manager (name not given). **Format:** one 45-minute conversation, Thursday.
**Built on:** `tuesday-dossier.md` (decision `conditional_go`). Its two conditions run through the whole pack: the bridge stays adjacent and is never presented as PM experience, and the squad-authority question gets verified in the room (reverse question 1).
**Highest-ROI prep in this pack: B1.** The underwriter named that objection; it is the one question you should rehearse until it is boring.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores | Used here |
|---|---|---|
| VAL | Past behavior against the company's published values | Not built: no Quartzline values source was read |
| EXP | Whether your claims survive scrutiny and attribution | Yes |
| JD | Whether you can do the listed job, gaps included | Yes |
| CO | Company and strategy knowledge | Not built: no Quartzline strategy source was read |
| CASE | A live problem from the actual role | Yes |

Anything marked "Answer slot" is an instruction for the interview, not a question for you now. It names what the interviewer will likely probe and gives two honest branches; pick whichever is true.

## The fit snapshot

Proposed language below is pending your approval. Evidence cells hold only your confirmed sentences, quoted exactly from the dossier.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | low | [grounded] | transferability | The dossier's strategy is `bridge`, with its limit: the case is adjacent and is never PM experience. Your material is integration work, not years in a PM seat. Words, sourced by prohibited_claims: "Having held a product manager title or role": "I haven't held a product manager title or role." Then the two quotes at their own scope and nothing wider |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibilities | none given | none | [grounded] | capability | The dossier's strategy is `acknowledge_gap`, and prohibited_claims lists "Having owned a product roadmap". Words: "I haven't owned a product roadmap." Then how you would learn it, said as a plan and never as a past. No bridge and no slot. The sessions in F5 are R4 evidence and are not brought here |
| F3 | "Shipped API or platform products" — dossier role_profile R2 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [inferred] | discovery | The quote is integration of the vendor's REST APIs. It touches the requirement without showing whether any API or platform product was shipped, and the dossier names R2 a high-priority requirement without a weak-area strategy for it. Answer slot: the JD's R2 line makes a probe on products shipped likely. If you were part of shipping one, say which and what part was yours, in your own words; if you were not, say so plainly and stay with the integrations at the quote's own scope |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | medium | [inferred] | discovery | The quote names REST APIs and an architecture step; it does not say docs or schemas. Answer slot: the JD's R3 line makes a probe on docs and schemas likely. If you worked with API docs or schemas, say how, in your own words; if the work did not involve them, or was not yours, say so plainly and return to the REST APIs and the architecture step of the integrations you led |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [grounded] | transferability | The quotes reach clients and product; neither names engineering or sales. The sessions are confirmed with limited inspectable proof, so volunteer that limit before a prober finds it. Words stay at the quotes' scope: you ran the sessions, and they fed client evidence to product. Answer slot: the JD names engineering, sales and customers, so expect a probe on the two the quotes do not name. If you worked directly with either, say how, in your own words; if you did not, say so plainly and stay with clients and product |
| F6 | "Agile delivery experience" — dossier role_profile R5 | none given | low | [grounded] | discovery | The dossier's strategy is `clarify`, and no confirmed entry speaks to this requirement, so no quote is offered. Answer slot: the interviewer's probe is the JD's own words, "Agile delivery experience". If you worked in an agile delivery process, say where and what you did, in your own words; if you never worked that way, say so plainly, and say what you would want to confirm about how this team defines it |

## Persona table

Weights come from your stated round (one 45-minute conversation with the hiring manager) and from the dossier, not from any Quartzline source. Values / Behavioral is not built: no values source was read and no values round is documented.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | Live problems from the role: prioritize across two squads, diagnose flat adoption, run a partner discovery call | High. The hiring-manager prior is Case plus Skeptic, and the job is defined by roadmap, discovery and adoption responsibilities | Clarify first, then structure, then think aloud. Reason in the conditional ("I would"), never as a past you do not have (F2) |
| B. Skeptic | The title and roadmap gap, "weakest on day one", motivation | High. The underwriter named an objection aimed at F1 and F2, so some form of it is near-certain | Concede the two sourced negatives early, hold the adjacent case at its own scope, never fold on it, never inflate it |
| C. Data-Driven Prober | "30+ integrations: how counted, which part yours"; the playbook; how success is measured | Medium. F1 carries a headline number, and the role's responsibilities include adoption metrics | Say what you can and cannot say about how the figure was counted; say plainly where you do not know |
| D. Conversational / Rapport | The opener ("walk me through the journey") and casual API questions | Medium. A 45-minute conversation usually opens loosely, and casual questions are still scored | A 90-second arc built only from your three confirmed sentences, with the adjacent limit said up front |
| E. Pressure | Time-boxed "why you over a PM with three years of the job" | Low. Nothing in your material or the dossier signals a stress style, but B1 compresses well into a time box | Pause, restate, hold through two follow-ups, concede precisely |
| F. Peer Evaluator | Seam with the two squad leads; credit across teams | Low. The interviewer is the hiring manager, but squad-lead authority is an open risk in the dossier | Propose seam principles instead of pretending to know the seam; ask who decides |

## Question banks

### A. Case / Strategist (highest weight)

Proposed language below is pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two squads, one quarter, and a partner whose go-live is slipping. How do you decide what gets built first, and what do you need to know before you decide?" | CASE | [generic] | Say the clarifying question aloud first: who decides when squad plans and partner needs conflict. Then objective, options (what each choice costs the partner and each squad), the measure you would watch, the risks, and what you would confirm before committing. Keep every verb conditional: you are showing how you would reason, so make no claim about a past decision | The JD raises roadmap and two-squad delivery, and F2 means your answer here is reasoning rather than recall. CASE because it scores structure; the open decision-authority question is the dossier's own risk |
| A2 | "Partner API adoption has been flat for two quarters. How do you diagnose it?" | CASE | [generic] | Start by asking how adoption is defined and what the baseline is, since the dossier says neither is established. Then split partners by how far they got, list two or three competing explanations, say what evidence would separate them, and name the first thing you would check. Supply no figures | Adoption metrics are a named responsibility with no stated baseline, so a diagnosis case is likely. CASE with JD content; labelled generic because it is a pattern, not a fact about Quartzline |
| A3 | "How comfortable are you with API documentation and schemas?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Story-mapped on F4: the REST APIs and the architecture step, which are the beats the quote states, told in your own words. Answer slot: the JD's R3 line makes a probe on docs and schemas likely. If you worked with them, say how; if the work did not involve them, or was not yours, say so plainly and return to the REST APIs and the architecture step | F4 is the evidence for R3 and stops short of docs and schemas. JD because it scores a stated requirement directly |
| A4 | "Tell me about a time you were on the product side of an API or platform launch." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | An open prompt, so pick the occasion yourself. Name what the occasion was and which part was yours. Answer slot: if you were part of shipping an API or platform product, say which and what your part was; if you were not, say so plainly and stay with the integrations at the quote's own scope: you led them, from scoping through go-live. Do not stretch integration work into product shipping | R2 is a must-have and the dossier gives it no weak-area strategy, so this is a likely probe. F3 is why it is a slot and not a story. JD because it scores R2 |
| A5 | "You have thirty minutes with a partner whose integration has stalled. What do you ask?" | CASE | [generic] | Structure: what changed since it last worked, where it is stuck (technical, organizational or priority), what the partner needs from Quartzline, what they would give back, and what you would take to the squads. Keep it as a method you would use, in the conditional | Running discovery with integration partners is a named responsibility. CASE because it scores clarification and structure; generic because it makes no claim about your past |

### B. Skeptic (highest weight)

Proposed language below is pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; prohibited_claims: "Having held a product manager title or role"; prohibited_claims: "Having owned a product roadmap" | **Deepest rehearsal; the underwriter named this objection.** Hold-then-concede in order. (1) Concede first, plainly, before they extract it: "I haven't held a product manager title or role, and I haven't owned a product roadmap." (2) Name the limit before they ask: your case is adjacent. (3) State the adjacent case at its own scope: you led 30+ end-to-end client integrations of the vendor's REST APIs, and you wrote the integration playbook your team uses. Stop there; let the interviewer draw the inference. Follow-up 1, "We asked for three years": hold, and do not argue the years; say the requirement is theirs to weigh and the evidence is what you have just given. Follow-up 2, "What could you not do in month one?": name the roadmap and prioritization decisions, then give the ramp as a plan, for example learning how the squads set priorities and which decisions are the PM's alone. Never call integration leadership product management, and never describe any roadmap as yours | The dossier's own likely objection, so it will arrive in some form; F1 and F2 are the rows it presses on. JD because it scores the title requirement; the tone is Skeptic, and E1 is the same question in a time box |
| B2 | "Tell me about the quarterly roadmap-input sessions you ran. What did you bring to product, and what did product do with it?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Medium confidence: confirmed, with limited inspectable proof, so volunteer the limit before it is extracted: say what you can point to and what you cannot. Beats the quote states: you ran the sessions, they were quarterly, and they fed client evidence to product. Answer slot: if you know what product did with the input, say what, in your own words, and what part of it was yours; if you do not know, or nothing followed, say so plainly and stay with sessions you ran that fed client evidence to product. Hold the verb at "ran" and "fed"; never "decided" or "prioritized" | F5 is the most probe-prone entry because it is confirmed with the least proof behind it. EXP because it tests attribution; the premise is the quote's, and the slot lets "nothing followed" be true |
| B3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] prohibited_claims: "Having owned a product roadmap"; prohibited_claims: "Having set prioritization for an engineering squad" | The dossier's strategy for roadmap ownership is `acknowledge_gap`, so no bridge. Say it plainly: "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then the ramp as a plan: what you would learn first and from whom, and the question you would ask about which decisions are yours alone. Offer nothing from the F5 sessions here. Hold the same answer if pressed | F2 is the dossier's confirmed capability gap, and "weakest on day one" is the stem that goes straight to it. JD because it scores the stated responsibility; the honest answer is the rehearsal |
| B4 | "What's your experience of Agile delivery?" | JD | [grounded] | The dossier's strategy for this area is `clarify`, and no confirmed entry speaks to it, so there is nothing to quote. Answer slot: the interviewer's probe is the JD's own words, "Agile delivery experience". If you worked in an agile delivery process, say where and what you did, in your own words; if you did not work that way, say so plainly, then ask how this team defines it so you answer the real question | F6 is a preferred requirement the underwriter could not establish, so this question is cheap to ask and costly to fumble. JD because it scores R5 |
| B5 | "Why move into product now, and why this role?" | JD | [grounded] | Give your own reason, in your own words, in two sentences. For "this role", use only what you have actually learned: the posting says the role owns the roadmap for the partner-facing API platform, runs discovery with integration partners, and works with two engineering squads. Do not borrow a reason you do not hold | Motivation consistency is what the Skeptic scores, and F1 is the transition it questions. JD because it tests fit to the stated role; the reason is yours to supply |

### C. Data-Driven Prober

Proposed language below is pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You led 30+ client integrations. How was that number counted, and which part was actually yours?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The headline-number defense. Answer slot, in your own words: how the count was made; what it is most sensitive to; the assumption behind it you would defend least; and which part was yours. If you do not know how something was counted, say so plainly. The quote's own beats are the verb "led" and the stages from scoping to go-live; add nothing to them. The playbook is the inspectable artifact the dossier records for this claim | F1 is the strongest evidence and carries the only number, so it is where a prober starts. EXP because it tests attribution and counting |
| C2 | "Tell me about the integration playbook. What's in it, and who uses it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Beats the quote states: you wrote it, it is internal, and your team uses it. Answer slot: the JD's "write specs" line makes a probe on what the writing involved likely. If any of it was specification or requirements writing, say what; if it was a different kind of document, say so plainly. Say nothing about its contents or effect beyond what you can actually describe | F1 is where the playbook sits, and a written artifact invites a close read. EXP because it checks authorship and use |
| C3 | "How do you decide whether a partner integration has succeeded?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Story-mapped on F5's integrations: the quote's stages run to go-live. Answer slot: the JD's adoption-metrics line makes a probe on what happens after go-live likely. If you tracked anything after go-live, say what; if you did not, say so plainly, and say what you would measure first, as a plan | Adoption metrics are a named responsibility with no baseline, and the quote ends at go-live. JD because it scores that responsibility |

### D. Conversational / Rapport Builder

Proposed language below is pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc in three beats, each the quote's own: you led 30+ end-to-end client integrations of the vendor's REST APIs; you wrote the integration playbook your team uses; you ran quarterly roadmap-input sessions that fed client evidence to product. Say the adjacent limit once, early: this is integration work, not a PM seat. Close with your own reason for moving toward product, in your own words | The biography question is always scored, and F1 and F5 are the whole story you can tell. EXP because it is a CV walk-through |
| D2 | "What do you think makes a partner API good to build on?" | JD | [generic] | Offer a view, framed as your opinion, and tie it to what partners need. Keep it as a viewpoint. Where you mention experience, keep it at the F4 quote's scope: REST APIs and architecture | R3 is an important requirement and a casual question invites it. JD because it scores technical fluency; generic because it makes no claim about your past |
| D3 | "Tell me about working across engineering, sales and customers." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | An open prompt, so choose the occasion yourself. Map what the quotes carry: clients (the integrations) and product (the sessions). Answer slot: the JD names engineering and sales too. If you worked directly with either, say how, in your own words; if you did not, say so plainly and stay with clients and product | R4 is a high-priority requirement, and F5's quotes reach only two of the three groups. JD because it scores R4 |

### E. Pressure / Stress Interviewer

Proposed language below is pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | B1 compressed. Pause, restate the question, then three sentences: concede the title and roadmap plainly, say the case is adjacent, and give the integrations at the quote's own scope. If interrupted, hold; if pressed on the years, concede that you cannot match them, then return to the quote | F1 is the objection in a time box. JD because it scores the title requirement; the pressure is the delivery |
| E2 | "That 30+ — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold the verb the quote gives: "led". Answer slot: which stages, from scoping to go-live, were yours alone and which were shared; if others shared any stage, say so plainly. Concede specifically, never broadly, and do not fold on "led" just to ease the room | F1's verb is the claim the probe tests. EXP because it scores attribution under pressure |

### F. Peer Evaluator

Proposed language below is pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "The squad leads own delivery. If you and one of them disagree on what ships next, what happens?" | CASE | [generic] | You do not yet know the seam, and the dossier lists squad authority as unverified, so do not pretend to. Propose principles: separate who decides priority from who decides how it is built, put the disagreement in terms of partner evidence, escalate through a named owner, and agree the rule before the conflict. Then ask who decides today, as in reverse question 1 | Decision authority versus the two squad leads is the dossier's open risk, and F2 is why you cannot answer from experience. CASE because it is a live seam problem; generic because it makes no claim about your past |
| F2 | "When work spans teams, how do you handle credit?" | EXP | [generic] | A selection scaffold: pick a time work spanned teams and credit had to be shared; it needs a named other party, what part was yours, and how credit was divided. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A collegial question that reaches attribution honesty, which F1 and F5 both depend on. EXP because it scores what was actually yours; generic because no quote carries the story |

### Requirement coverage

| Requirement or responsibility | Questions |
|---|---|
| R1 3+ years product management experience | B1, B5, E1, E2 |
| R2 Shipped API or platform products | A4 |
| R3 Technical fluency: API docs, schemas | A3, D2 |
| R4 Stakeholder management | D3, B2, F1 |
| R5 Agile delivery experience | B4 |
| Own the roadmap for the partner-facing API platform | A1, B3, F1 |
| Run discovery with integration partners | A5 |
| Write specs and drive delivery with two engineering squads | C2, A1, F1 |
| Define and track adoption metrics | A2, C3 |

No CO question is built: no Quartzline strategy source was read, so any such question would be generic; the upgrade menu says what would change that.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The dossier lists decision authority as asserted but not evidenced. It reads as diligence, and its answer decides whether F2 is a gap you can close or a gap in the role |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | The dossier names adoption metrics as a responsibility with no stated baseline. You need the answer before you could own the number, and it shows you think in measures |
| 3 | "How do partners' integration problems reach the product team today?" | It opens a natural place to mention the F5 sessions at their own scope, without claiming more |
| 4 | "Where do partner needs and the two squads' plans pull apart most today?" | It surfaces the seam from A1 and F1 and tells you what the first quarter really holds |
| 5 | "What would a strong first 90 days look like for someone coming from the integration side rather than a PM seat?" | It puts the adjacent framing on the table in your terms and shows you have a ramp. Ask it only if B1 went well |
| 6 | "What does the team need most right now that it does not have?" | A forward-looking close that gives the hiring manager room to describe the real priority |

## Prohibited claims

What this pack will not coach, and why. Built before the banks, and binding on every cell.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims | F1's quotes at their own scope, plus the plain acknowledgment sourced by prohibited_claims: "I haven't held a product manager title or role." |
| Having owned a product roadmap | Dossier prohibited_claims, and the dossier's `acknowledge_gap` area for roadmap ownership | The plain acknowledgment: "I haven't owned a product roadmap." Then a ramp plan, said as a plan. No bridge and no answer slot |
| Having set prioritization for an engineering squad | Dossier prohibited_claims | The plain acknowledgment: "I haven't set prioritization for an engineering squad." Then the ramp plan. The F5 sessions stay at "ran" and "fed" |
| Drove or decided roadmap changes from the input sessions | Inflated form of F5 | F5's quote at its own scope: you ran the sessions, and they fed client evidence to product. The limit is the pack's observation: your material says the sessions fed evidence to product, not who decided what followed |

## Sources

Provided documents: `tuesday-dossier.md`, generated 2026-08-14, `dossier_version` 1.1. This pack consumed its `role_profile` (requirements and responsibilities, standing as the JD), its `handoff_to_mock_interview` (verified evidence, weak areas and their strategies, the objection, risks, employer questions and prohibited claims) and its `decision` (context only). It carried no `evidence_map`, `risk_register` or `evidence_state`, so the fit snapshot's grading comes from the handoff section alone.

Searches sent, all refused by the host (no permission was granted); no fetches were sent:

- "Quartzline company values" — refused
- "Quartzline interview process product manager" — refused
- "Quartzline API platform strategy news" — refused

Nothing about Quartzline's values, loop, strategy or recent news is established in this pack.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Every call was refused. It would have fed VAL themes and a values cheat sheet; neither is built |
| 2. `Quartzline interview process product manager` | unavailable | Every call was refused. It would have documented the loop; persona weights rest on your stated round alone |
| 3. `Quartzline strategy` / recent news | unavailable | Every call was refused. It would have grounded CO and CASE questions in current strategy; the CASE questions are generic |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's `role_profile` supplies the requirements and responsibilities, fixing the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The interviewer's name → a reading of their public career path, persona weights tuned to it, and a reverse question tied to their own path
- Permission for the research searches, or the text of Quartzline's values page, strategy notes or interview-process page pasted in → the three unavailable rows become `[grounded]`, and the CASE bank gains a company-grounded question
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes, and it also needs search permission) → a strategy brief and a recent-context section
- Your own answers to the answer slots in F3, F4, F5 and F6 (whether you shipped any API or platform product, worked with docs or schemas, worked directly with engineering or sales, or worked in an agile delivery process) → those rows move from discovery slots to quoted evidence
- One session write-up, or the product-team ticket that cited the client evidence from your roadmap-input sessions → raises F5's second quote from medium to high confidence
- Anything the recruiter said about focus areas or format → coverage tuned to what the conversation will actually weigh
