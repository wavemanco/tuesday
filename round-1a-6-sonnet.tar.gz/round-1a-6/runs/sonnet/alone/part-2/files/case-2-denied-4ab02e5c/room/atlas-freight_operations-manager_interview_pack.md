# Interview pack: Operations Manager, Atlas Freight

Role: Operations Manager, Atlas Freight (regional logistics, 800 employees). Interviewer and relationship: not given. Built for a hiring-manager round, with the Generic loop archetype's flat weights underneath, because no source establishes the loop. The job description was supplied as a short summary, so the fit snapshot quotes only those lines.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Every guidance cell is scaffolding for your own words, not a script, and each is sized for a 90 to 120 second spoken answer. Bank letters skip F so they never collide with the fit rows F1 to F7.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values. No published values were available to this pack, so no question carries this tag |
| EXP | Whether your claims survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | How well you know the company and its strategy |
| CASE | Structure and reasoning on a live problem from the role |

## Prep triage

You said the interview is next week, so this is ordered by what changes the outcome most. Do these in order.

1. A1, then E2. This is the step from 3 supervisors to 12, the likeliest objection. Say it aloud until it is boring.
2. A4. Power BI is a stated gap, so rehearse the plain acknowledgment and a plan.
3. C1 and C2. The 40% figure will be probed on how it was counted and how much was you.
4. B1, B2 and B3. Rehearse the three structured case answers aloud.
5. D1 and D2. Prepare the 90-second path through your career and your reason for this move.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "currently a senior shift manager over 3 supervisors" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material says a shift manager role and the site's surge plan, not four sites, and not terminals. The words stay at the quotes: "I'm currently a senior shift manager over 3 supervisors" and "I ran the site's peak-season surge plan two years running." Answer slot: the JD's four-site line makes a probe on the scope of your responsibility likely. If any part of your responsibility reached beyond your shift, say what, in your own words; if not, say so plainly and stay with the shift and the surge plan |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Your material carries a mis-pick figure, and the JD asks about two other measures. The words stay at the quote: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: the JD's line makes a probe on the measures your site tracks likely. If you track any, say which, in your own words; if none, or they are set by others, say so plainly and stay with the mis-pick figure |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | The material says 3 supervisors, the JD says 12, and the words stay at 3: "I'm currently a senior shift manager over 3 supervisors." Answer slot: if you have led more than 3 supervisors at any time, say when and which part was yours, in your own words; if not, say so plainly and stay with the 3 you lead today. How you would lead 12 is a plan, said as a plan, never as a past |
| F4 | "build reporting in Excel/Power BI" — JD (the Excel half) | "solid Excel" — your message | low | [inferred] | discovery | Your material says "solid Excel", not what you use it for. Answer slot: the JD's reporting line makes a probe on what you build in Excel likely. If you build reports in it, say which and for whom, in your own words; if your Excel work is something other than reporting, or others build the reports, say so plainly and stay with "solid Excel" |
| F5 | "build reporting in Excel/Power BI" — JD (the Power BI half) | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used Power BI." Then how you would learn it, said as a plan and never as a past. Never a claim to Power BI work, and nothing added to make the gap feel smaller |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | The material gives 7 years in operations and a current leadership role, and does not say how many of the 7 years were spent leading people. Answer slot: if asked, give the number of years you led people, in your own words; if it is fewer than five, say so plainly and return to the team you lead today |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | presentation | The quote already reaches the requirement in other terms. Words: "I'm green belt certified." The material does not name the program, so the words stay at "green belt certified" |

The JD's 5+ years line is an experience requirement, not a gate, so no row here is a hard gate.

### Requirement coverage

| JD requirement | Questions that cover it |
|---|---|
| "Own daily terminal operations across 4 sites" | A2, B1, B3, D3 |
| "drive on-time performance and cost-per-shipment down" | B1, B2, C3 |
| "lead a team of 12 supervisors" | A1, B4, E2, H2 |
| "build reporting in Excel/Power BI" | A3, A4 |
| "5+ years operations leadership required" | D1 |
| "Lean/Six Sigma a plus" | A5 |

## Persona table

The relationship is unknown, so the weights start from the hiring-manager prior. The Generic archetype adds no tilt, because no loop source establishes this company's rounds. If you tell me who is interviewing you, every weight below changes.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet, persistent probing of the step from 3 supervisors to 12 and of the Power BI gap | High. A hiring manager is derisking gaps, and F3 and F5 are the widest gaps in the snapshot | Rehearse A1 until it is boring; hold only what the quoted sentences carry; the plan is said as a plan |
| B. Case / Strategist | Live problems from the role: late terminals, cost per shipment, a peak surge, uneven supervisors | High. The hiring-manager prior puts live problems on the role's own roadmap, and the JD's measures are natural case material | Clarify, then objective, segmentation, approach, metrics, risks; challenge one premise per case |
| C. Data-Driven Prober | Reads your lines closely and asks how the 40% was counted | Medium. You gave a headline figure, which is the usual target, and the relationship does not raise or lower it | Know what you can and cannot say about how the figure was counted; say plainly where you do not know |
| D. Conversational | A friendly opener such as the path through your career, or why this move | Medium. Every loop opens somewhere, and these questions are scored even when casual | A 90-second arc built only from your own sentences |
| E. Pressure | Time-boxes you and tests whether you hold under a challenge | Low to medium. Nothing says this is a senior or stress-style round | Pause, restate, hold through two follow-ups, concede only what is true |
| G. Peer Evaluator | Asks where the seam sits between teams and how credit is shared | Low. The prior for this round does not point to a peer, and the answer changes if you meet one | Offer seam principles instead of pretending to know the seam |
| H. Values / Behavioral | Scenario prompts about leadership and hard messages | Low. No values-style round is detected, so these are from persona stems | Choose stories where the hard truth landed, and say so where the material shows none |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You're a senior shift manager over 3 supervisors today, and this role leads 12 supervisors across 4 sites. What makes you ready for that step?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI rehearsal in this pack. Open with what your sentence carries, in your own words: "I'm currently a senior shift manager over 3 supervisors." Concede the step in plain terms, since the JD sets the numbers: the team you lead today is 3, and the role is 12. Then give a plan, said as a plan: what you would learn at each site first, and how you would run 12 supervisors as one team, in your own terms. Hold through two follow-ups by returning to the 3 you lead today and the plan, never by adding scale to the past. Answer slot: if you have led more than 3 supervisors at any time, say when and which part was yours; if not, say so plainly and stay with the 3 you lead today | F3 is the widest visible gap between the evidence and the JD, and F1 compounds it. This objection will arrive in some form before any other. JD because it scores the stated requirement, delivered with Skeptic pressure |
| A2 | "Your background is warehouse and distribution, and this role runs terminals. What would you need to learn first?" | JD | [grounded] "7 years in warehouse and distribution ops" | Say the background in your own words: "7 years in warehouse and distribution ops." Then answer the question as asked, as a plan: what you would want to learn first about running a terminal, and who you would ask. Answer slot: if any of your 7 years were in a terminal, say where and what you did; if all of it was warehouse and distribution, say so plainly and then say what you would learn first | F1 is where the JD's terminal wording presses on a warehouse background. JD because it tests whether you can do the listed job |
| A3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "solid Excel, never used Power BI"; "currently a senior shift manager over 3 supervisors" | Pick one gap and name it before the interviewer does. The one your own material states: "I've never used Power BI." Follow it with a plan, said as a plan: what you would learn first and how you would check you are getting it right. If you would rather name the team size, say it in the same plain shape: "I'm currently a senior shift manager over 3 supervisors" against the role's 12. Do not name a weakness you cannot support | F5 and F3 are the two gaps the snapshot rates widest. JD because it asks you to rank your own fit against the listed job |
| A4 | "This role builds reporting in Excel and Power BI. You've never used Power BI. How do you get up to speed?" | JD | [grounded] "solid Excel, never used Power BI" | Two beats, each at the scope of its quote. First: "I'm solid in Excel." Answer slot: if you build reports in Excel, say which and for whom; if your Excel work is something other than reporting, or others build the reports, say so plainly and stay with "solid Excel". Second: "I've never used Power BI", then a plan said as a plan: what you would start with, the first thing you would try to produce, and how you would check it, in your own timeline. Ask what reports exist today. Make no claim that your Excel skill carries over | F4 and F5 together are the reporting requirement. JD because the line is a stated qualification, and the negative is one you stated |
| A5 | "Tell me about a time you used Lean or Six Sigma on a real problem." | JD | [grounded] "green belt certified"; "cut mis-pick rate 40% by redesigning the pick path" | Selection scaffold: pick one problem where you worked with a structured improvement method. It needs a named problem, what you did, and how you knew it changed. Open with "I'm green belt certified." Answer slot: if the pick-path redesign was part of your green belt work or used its methods, say so and which part was yours; if it was separate, or the certification was not tied to a project, say so plainly and tell it as what it was. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the certification, or how you would approach it | F7 is the JD's plus, so the question is likely and friendly. JD because the JD raises it, and the guidance keeps the certification and the figure as separate sentences |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You take over four terminals, and on-time performance is slipping at one of them. Walk me through your first two weeks." | CASE | [generic] | Structure it aloud: what you would ask first, including how on-time is defined and measured and how long it has been slipping; the objective; a split by site, shift and stage to find where the delay enters; quick fixes against structural ones; the metrics you would watch; the risks. Challenge one premise respectfully, for example whether one site's slip is really the whole problem. This question needs no claim about your past, so the guidance makes none | The JD's on-time line (F2) is the most natural live problem for this role. CASE because it asks for structure and reasoning, not history |
| B2 | "Cost-per-shipment is above target across all four sites. Where do you look first?" | CASE | [generic] | Ask what goes into the figure and who owns the inputs before offering a hypothesis. Split the cost by component and by site. Name the tension with on-time as a risk before the interviewer raises it. Close with the first two checks you would run and how you would know they worked. The guidance makes no claim about your past | The second measure in the JD's line (F2). CASE because it is a problem set in the role, and the answer tests whether you clarify before structuring |
| B3 | "Peak season hits, and one site is overwhelmed while another has slack. What do you do?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Open with your sentence in your own words: "I ran the site's peak-season surge plan two years running." Then structure the multi-site problem as a plan: what you would check first, what could move between sites, what could not, and the trigger for escalating. Answer slot: if any part of the surge plan was yours to design rather than run, say which; if you ran a plan set by others, say so plainly. Never describe a part of the plan you did not run | F1 is the only row where a quoted sentence meets the multi-site requirement. CASE because the delivery is a live problem, with an EXP link back to the surge plan |
| B4 | "You have 12 supervisors and uneven results across the 4 sites. How do you find out why, and what do you do?" | CASE | [generic] | Clarify what uneven means and over what period. Look at the data before the people, then spend time at each site. Separate a supervisor problem from a site problem. Say what you would change in how you lead, and what you would leave alone for the first month. The guidance makes no claim about your past | F3 is the leadership-scale requirement, rehearsed as a decision instead of a record. CASE because it is a live problem set in the role |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say the sentence in your own words: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: how the figure was counted; what it is sensitive to; the assumption behind it you would defend least, named before they do; which part was yours. If you know any of these, say them in your own words; if you do not know how it was counted, say so plainly, and say what you would check to find out | F2's only quantified claim, and the usual target of a prober. EXP because it tests whether the number survives scrutiny |
| C2 | "How much of the pick-path redesign was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold the sentence at its own scope: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if others worked on the redesign, say who did what and which part was yours; if it was entirely yours, say so plainly. Concede what you do not know, specifically, and do not widen the claim to hold your ground | F2 again, because attribution is probed whenever a figure carries a verb. EXP because it scores the honesty of your account |
| C3 | "What do you track on your shift today to know it's going well?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Answer slot: if you track measures on your shift, name them in your own words; if you track none, or they are set by others, say so plainly and say what you would track in this role | F2 and F6 sit behind this question, and the JD raises the measures it points to. JD because it asks what you do in the job you hold |

### D. Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "This role asks for 5+ years of operations leadership. Walk me through your path in operations." | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | A 90-second arc built only from your sentences: "7 years in warehouse and distribution ops", and "currently a senior shift manager over 3 supervisors." The order and the roles in between are yours to supply. Answer slot: if asked how many of the years were leading people, give the number in your own words; if it is fewer than five, say so plainly and return to the team you lead today | F6 is the one requirement that is a count, so the question is likely in an early conversation. JD because the 5+ years line is stated, with EXP content |
| D2 | "Why Atlas Freight, and why this move now?" | EXP | [generic] | Selection scaffold: pick one reason that is true and specific, and say it as yours. The pack holds nothing about Atlas Freight's own reasons, so this one is yours alone. If the reason is mainly the step up in scope, say so plainly. Never use a reason you cannot repeat under a second question | Motivation consistency is scored in every loop. EXP because it tests the story of your move, and the guidance is generic because no research ran |
| D3 | "What do you know about Atlas Freight?" | CO | [grounded] | The posting gives you regional logistics, 800 employees and 4 sites, and that is all this pack can supply. Answer slot: say what you have read, in your own words, and name what you would still want to ask; if you have read little, say so plainly and ask the interviewer to tell you where the company is going. Never claim knowledge of its strategy that you do not have | The searches for current strategy were refused, so this question is rehearsed from the posting alone. CO because it tests homework depth, and the guidance stays inside the JD's own words |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a candidate who has already run multiple sites?" | EXP | [grounded] "ran the site's peak-season surge plan two years running"; "cut mis-pick rate 40% by redesigning the pick path"; "green belt certified" | Pause, restate the question, then hold on three sentences in your own words: "I ran the site's peak-season surge plan two years running", "I cut mis-pick rate 40% by redesigning the pick path", "I'm green belt certified." Concede the scale: "Fair, scale is the step I'd be making." Do not tell them what the sentences prove | F1 and F3 are where a rival with more scale beats you, so the pressure lands there. EXP because it tests what you can hold, not what you can claim |
| E2 | "I need someone who can lead 12 supervisors from day one, not learn it. Convince me." | JD | [grounded] "currently a senior shift manager over 3 supervisors" | This is A1 in a harder register. Pause and restate. Hold what the quote carries: "I'm currently a senior shift manager over 3 supervisors." Concede the step plainly, then give the plan from A1. Do not harden into a claim of day-one readiness, and do not fold on the plan | F3 again, in the packaging most likely to make a candidate overclaim. JD because the requirement is stated, delivered with pressure |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Where's the seam between your team and mine, and what happens when we disagree?" | CASE | [generic] | Propose seam principles instead of pretending to know the seam: who owns which decision, what each side needs from the other, how a disagreement escalates, and how you would raise one early. Offer what your team gives theirs, not only what you need. The guidance makes no claim about your past | A peer's usual opening, relevant if the interviewer turns out to be a peer. CASE because it is a live collaboration problem |
| G2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Selection scaffold: pick a time work spanned teams; it needs a named piece you owned, a named piece others owned, and how credit was shared. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | A peer probe that reads your record on shared work. EXP because it tests attribution style |

### H. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | EXP | [generic] | Selection scaffold: pick a time where the hard truth actually landed; it needs a named stake, what you said, and an intact relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | A standard behavioral stem, kept here because the role reports upward. Tagged EXP, since no published values are in hand for a VAL tag |
| H2 | "Tell me about a time a supervisor on your team wasn't meeting the standard." | EXP | [grounded] "currently a senior shift manager over 3 supervisors" | Selection scaffold: pick a time that fits; it needs a named gap against a standard, what you did, and how you knew it changed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the team of 3 you lead today, or how you would handle it | F3 raises supervisor management, and the JD's 12 supervisors make this prompt likely. EXP because it tests what you did |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What does on-time performance look like across the four sites today, and which site is furthest from where you want it?" | Shows you think in the JD's own measure, and tells you where the job is hardest |
| 2 | "How is cost-per-shipment calculated here, and who owns its inputs?" | The definition decides everything in B2, and asking it shows you would ask before acting |
| 3 | "What reporting exists today in Excel and Power BI, and what is missing?" | Surfaces how large the Power BI gap really is, and frames your learning plan from A4 |
| 4 | "How are the 12 supervisors spread across the four sites?" | Tests the scale the JD describes, and shows you are planning how to lead them |
| 5 | "What would a strong first 90 days look like in this role?" | Turns the interview into a shared plan and tells you what is scored |
| 6 | "What has made people in this role succeed or struggle?" | Draws out the real failure modes, and signals you plan to avoid them |
| 7 | "What could a new person do in their first month that would genuinely help your team?" | A reciprocity question that works whether the interviewer is a manager or a peer |

## Prohibited claims

Built from the fit snapshot before the banks were written. This is what the pack will not coach.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned operations across multiple sites | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation, not words for you: the material says a shift manager role and the site's surge plan |
| Applied the 40% to delivery or cost results | Inflated form of F2 | F2's quote at its own scope: the figure is a mis-pick figure. The slot asks only what your site tracks, never what it moved |
| Led a team of 12 supervisors | Inflated form of F3 | F3's quote at its own scope: "currently a senior shift manager over 3 supervisors" |
| Power BI experience of any kind | Negative you stated, F5 | The plain acknowledgment F5 gives: "I've never used Power BI." No slot |

## Sources

Provided documents: the job description lines and the background statement in your message. No dossier was supplied.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

Search calls sent, each returning nothing because the tool was refused:

- "Atlas Freight regional logistics company values" — refused
- "Atlas Freight interview process operations manager" — refused
- "Atlas Freight regional logistics terminals news strategy" — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | The search was refused. It would have fixed the company's published values and a values cheat sheet if a values round is documented. Nothing was used |
| 2. `Atlas Freight interview process operations manager` | unavailable | The search was refused. It would have fixed the loop structure and the persona weights. They fall back to the Generic archetype, said plainly in the persona table |
| 3. `Atlas Freight strategy` / recent news | unavailable | The search was refused. It would have supplied a strategy brief for CO and CASE questions. D3 is rehearsed from the posting alone |
| 4. interviewer name and company | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. representative `Operations Manager` JD | skipped | The JD lines you supplied fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Who is interviewing you, and their names → reweights every persona, adds an interviewer read, and adds a reverse question tied to their own path
- The recruiter's note on focus areas or anything to prepare → coverage for a pre-declared deliverable, and a sharper weight on the persona it names
- Search access, or Atlas Freight's values and careers pages pasted in → the three unavailable research rows become established, D3 gets real strategy, and a values cheat sheet appears if a values round is documented
- If the interview is several sessions, the schedule → per-round mini-packs with their own persona weights
- Your answers to the slots in F1, F2, F3, F4 and F6 → five fit rows move from slots to quoted evidence, and the questions that draw on them regenerate
- Your green belt certificate, showing the belt level and who issued it → F7 moves from medium to high confidence
- A before-and-after report for the pick-path change → defends the 40% in C1 and C2 with something inspectable
- The full posting, if it has more text than the lines you pasted → more requirement rows and any further JD-tagged questions
- A `tuesday-dossier.md` from an earlier evaluation of this role → verified evidence, constraints per weak area, and a sharper highest-ROI objection, though this pack stands without one
