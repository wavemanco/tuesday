# Interview pack (loop mode): Engineering Manager, Larkfield Systems

Candidate: Yusuf. Three scheduled rounds, one shared fit snapshot, one mini-pack per round.

| Round | When | Who | Relationship | Format |
|---|---|---|---|---|
| R1 | Tuesday | A Director of Engineering | Hiring manager, your would-be boss | 45 min |
| R2 | The Thursday after | Two staff engineers and a product manager | Panel | 60 min |
| R3 | The following Monday | The VP Engineering | Skip-level, described by the recruiter as "values and leadership philosophy" | 30 min |

No interviewer names were given, so personas are assigned by seat, not by person, and there is no interviewer read.

## How to use this pack

- **Personas** describe how a question arrives (who is asking, in what style). **Types** describe what is being scored. Every question carries one of each.
- Type key: **VAL** (past behaviour against values and leadership), **EXP** (does the experience survive scrutiny), **JD** (the stated role and its gaps), **CO** (company and strategy knowledge), **CASE** (a live problem from the role).
- Provenance: `[grounded]` rests on something you wrote, quoted beside it; `[inferred]` is derived from a representative source; `[generic]` is a role-family pattern with no claim about you or Larkfield.
- Guidance is scaffolding, not a script. "Answer slot" lines are instructions for the room, not questions for me: say what is true from your own experience, or say plainly that it was not yours.
- The three rounds share one fit snapshot. A fact you add later enters it and the affected rows regenerate.

## Prep triage

Sized to the window you gave: three rounds over about two weeks.

1. **Before Tuesday, then daily:** B1, the weakest-part-on-day-one question. It is the highest-ROI prep in this pack, because the same objection returns in R2 (G2) and R3 (J1) in different packaging.
2. **Before Tuesday:** C1, your 90-second arc, and one run each of A1 and A2 aloud.
3. **Before Thursday:** D1 and D2, the defend-the-number slots for your 60% and your 40 interviews; F1, your one story-mapped answer on roadmap pressure.
4. **Before Monday:** H1 to H4. Choose instances only where your own material carries them; the honest branch is built into each.
5. Everything else is insurance.

## Fit snapshot (shared across all three rounds)

Requirements are quoted from the role description in your message. Evidence is quoted from your message only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role description in your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message; "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | medium | [grounded] | transferability | Your material says a team lead of six and, separately, no experience managing managers; it does not say what that team built or whether it was one squad. Words at the quote's scope: "9 years engineering, 3 as a team lead of 6." Answer slot: the role's "two squads building device-management services" makes a probe on the step from one team to two likely. If any of your work touched device or fleet-style services, say what and what was yours, in your own words; if none did, say so plainly and stay with the team of six. If asked about managers, your own words: "I've never managed managers." The role description does not say whether the squads have their own leads, so that is a question for them (reverse questions R1-3) |
| F2 | "own delivery, hiring and growth for 11 engineers" (hiring) — role description in your message | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | none | No gap on the term, but a figure with nothing inspected behind it, so expect the defend-the-number probe (D2). Lead with the loop in the quote's own terms: you run it, for backend roles. The quote counts interviews, not hires or outcomes, so the words stay on interviews |
| F3 | "own delivery, hiring and growth for 11 engineers" (delivery) — role description in your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | Your material says one reliability quarter and a 60% drop afterwards, not delivery ownership across two squads. Words at the quote's scope: "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." Answer slots on the figure (D1, G1): how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours, each in your own words; "I don't know how it was counted" is an honest branch. The quote says "after", and the words stay on "after" |
| F4 | "own delivery, hiring and growth for 11 engineers" (growth) — role description in your message | none given | none | [grounded] | discovery | Your material does not show growth work. Answer slot: the role's "growth" makes a probe on how you have developed engineers likely. If you have, say what you did and what was yours, in your own words; if you have not, or it was not yours, say so plainly and stay with the hiring loop you run |
| F5 | "partner with hardware and product on roadmap" (hardware) — role description in your message | "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | none | [grounded] | discovery | Your words on ownership: "I've never owned a hardware-adjacent roadmap." The quote is about owning; it does not say whether you have worked alongside hardware or firmware teams. Answer slot: if you have, say on what and what part was yours; if not, say so plainly. Then how you would learn it, said as a plan and never as a past |
| F6 | "partner with hardware and product on roadmap" (product) — role description in your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | low | [grounded] | discovery | The quote shows roadmap pressure and a push; it does not say who applied the pressure or how it was resolved. Answer slot: the role's product partnership makes a probe on that likely. If product partners were part of it, say what you did, in your own words; if the pressure came from elsewhere, or you cannot say, say so plainly and stay with the quarter as quoted |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| Lead two squads building device-management services | A1, A3, B2, B3, D3, I2 |
| Own delivery for 11 engineers | A3, D1, F1, G1, I2 |
| Own hiring | D2, D4 |
| Own growth | C3 |
| Partner with hardware on roadmap | A2, B1, E2, G2, J1 |
| Partner with product on roadmap | E1, E2, F1, F2 |
| "Values and leadership philosophy" (recruiter's words, R3) | H1, H2, H3, H4, J2 |
| Company and strategy | I1 (generic, see Sources), C2 |

---

# Round 1: Tuesday, Director of Engineering (hiring manager), 45 min

### Persona weights

The starting weights are the hiring-manager prior: Case/Strategist and Skeptic. No interviewer signals exist to adjust them, and no loop source describes how Larkfield runs this round beyond your own account.

| Persona | How it shows up | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Case/Strategist (bank A) | Live problems on the squads' real work | high | The hiring-manager prior; the role is two squads and a delivery mandate | Clarify, objective, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic (bank B) | Quiet probing of the gaps F1, F4, F5 | high | The same prior, and the gaps are visible from the role description and your own words | Rehearse B1 until it is boring; adjacent material only; the limit said first |
| Conversational (bank C) | Biography, motivation, growth, asked casually | medium | My judgment, not a source: a first meeting with a future boss tends to open with biography. Override it if you know better | A 90-second arc; treat casual questions as scored |
| Data-Driven Prober | Reads your lines closely | low | Raised in R2, where it is weighted high | Hold the D1 and D2 slots ready anyway |

### Bank A: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch your first 90 days with two squads you haven't met. What do you need to know first?" | CASE | [generic] | Clarify before you structure: what each squad owns, what each has committed to hardware and product partners, who the 11 engineers are and what is already in flight, how delivery is tracked today. Then objective, approach and the risks you would watch, aloud. Challenge one premise respectfully, for example whether 90 days is the right horizon. The question needs no claim about your past, so the guidance makes none | Live problem from the role's two-squad scope (F1); CASE because it scores structure; generic because it is a pattern, not a fact about Larkfield |
| A2 | "A hardware partner tells you a firmware date is moving six weeks, and a feature product has promised depends on it. What do you do in the next week?" | CASE | [generic] | Structure: what moved and why; what is fixed and what can move; options (re-sequence, reduce scope, hold the date with the risk named); who hears it from you and when; what you record. Say aloud what you do not know about the hardware side and whom you would ask first. That is your stated limit (B1) showing up inside a live problem, handled as a plan | The hardware and product seam is the role's named partnership (F5, F6); CASE for structure under a dependency |
| A3 | "One of your two squads has missed its last two commitments while the other is ahead. Where do you start?" | CASE | [generic] | Clarify first: what was committed, by whom, what changed, what the squad says. Diagnose before you intervene, separate the delivery problem from any people problem, decide what you change first and what you leave alone, and say whom you tell. The question presupposes nothing about your past | Tests the delivery mandate as a live decision, because F3's evidence is one quarter and not two squads |

### Bank B: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | **The highest-ROI rehearsal in the pack.** Say the limit first, in your own words from the quote: "I've never owned a hardware-adjacent roadmap." Then a plan, said as a plan: whom you would sit with first, what you would need to understand before committing dates, how you would check your understanding with them. Then stop. Hold through two follow-ups by returning to the sentence you said, not by adding to it. Likely follow-up one, "so why you?": give only what your quotes carry, "9 years engineering, 3 as a team lead of 6", and let them draw the inference. Follow-up two, "have you worked with hardware teams?": answer slot per F5, if you have, say on what and what was yours; if not, say so plainly. Concede specifically: you have not owned this, and say what you would ask for in the first month. Do not say the reliability quarter or the hiring loop prepares you for hardware | F5 is where the role presses hardest and the one gap your own words name, so this arrives in some form in every round. JD because it scores a stated requirement |
| B2 | "You'd go from a team of six to two squads and 11 engineers. What carries across, and what doesn't?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | The premise is your quote's: a team lead of six. Say that. Answer slot: what carries across is yours to say in your own words, from what you actually did; if little does, say so plainly. On what doesn't, your own words if it turns to managers: "I've never managed managers." Do not describe the step as small or large; let them weigh it | F1 is the scope step the role makes; JD because it tests the stated lead requirement |
| B3 | "I don't see device-management work in your background. How would you handle that in this role?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Answer slot: if any of your work touched device or fleet-style services, say what and what was yours; if none did, say so plainly and stay with "currently at a payments company". Then the learning plan: what you would ask the squads in the first weeks, said as a plan | F1 shows a payments company and does not show the domain; the probe is predictable. JD because it scores the stated domain |

### Bank C: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I run our hiring loop for backend roles — about 40 interviews last year"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | A 90-second arc in your own words using only the beats those sentences state: nine years in engineering, three of them as a team lead of six, now at a payments company; the hiring loop you run for backend roles; the reliability quarter and the on-call figure after it. Leave the figures out of the arc unless you will defend them (D1, D2). Answer slot for the close: why this role, in your reason, not mine; none appears in your material | The biography question is the opener most likely to be asked casually and scored; EXP because it tests what the CV claims survive; F2 and F3 supply the beats |
| C2 | "What draws you to industrial IoT and to this role?" | JD | [generic] | Your own reason in your own words; none appears in your material. Anchor on what the role description itself says: device-management services, and partnership with hardware and product. Name what you would want to learn, which also answers B1 before it is asked | Motivation consistency is scored in a first conversation with a future boss; generic because it asks for your reason, not a fact about you |
| C3 | "Tell me about an engineer you helped grow." | EXP | [generic] | Selection criteria: a named person (no name needed in the room), what you noticed, what you did and what you left to them, how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. Your material shows no growth work (F4), so no story is mapped for you | The role's "growth" line (F4) has no quote behind it; the open prompt keeps the guidance honest |

### Reverse questions, R1

| # | Question | Why it lands |
|---|---|---|
| R1-1 | "What would make you say, twelve months in, that this hire was right?" | Turns the unspoken bar into something you can prepare against, and shows you think in outcomes |
| R1-2 | "How is the roadmap shared today between hardware, product and engineering, and where does it hurt most?" | Aims straight at F5 and F6 and invites the Director to teach you the seam, which is the learning plan from B1 made live |
| R1-3 | "Do the two squads have their own leads, and what do you expect the EM to hold directly?" | The role description does not say; the answer shows how far F1's scope step really goes |
| R1-4 | "What is the first thing you'd want me to understand about the hardware side, and who would I learn it from?" | Converts the gap you named in B1 into a first-month plan the Director shapes |
| R1-5 | "How does growth and promotion work here, and what do you expect from the EM in it?" | Covers F4 and shows you take the growth line seriously |

---

# Round 2: Thursday, panel of two staff engineers and a product manager, 60 min

### Persona weights

The panel rule: blend the top two personas of each seat's relationship. Names are unknown, so seats stand in for people.

| Persona | How it shows up | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Data-Driven Prober (bank D) | The two staff-engineer seats read your lines and ask for inputs | high | Technical-specialist prior is Prober plus Pressure; F2 and F3 are your two figures | Know what you can and cannot say about how each was counted, and say plainly when you do not know |
| Peer Evaluator (bank E) | Seam-splitting, the product seat's roadmap questions | high | The product seat's prior and the role's product and hardware partnership (F5, F6) | Seam principles, not pretended knowledge of the seam; reciprocity |
| Values/Behavioral (bank F) | Behavioral prompts from the product seat | medium | Cross-functional prior | Map a story where a quote carries one; one story-mapped answer is available (F1) |
| Pressure (bank G) | Follow-up pressure on attribution and on the hardware gap | medium | Technical-specialist prior, second half | Hold two follow-ups, then concede specifically |

### Bank D: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how that 60% was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Answer slots, each in your own words: how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, which part was yours. If you do not know how it was counted, say so plainly. Speak the sentence as it stands: the burden dropped 60% after the quarter; "after" is what you have. A probe on whether the quarter caused the drop is likely, so say what you know and what you do not | F3 is a headline figure, and figures are what probers go to first; EXP because it tests attribution and honesty about the number |
| D2 | "About forty interviews last year. How was that counted, and which assumption behind it would you defend least?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Same four slots, in your own words. The quote counts interviews; say it as interviews, not hires or outcomes. If asked what the count tells them, say what you know about it, or say plainly that you have no more than the count | F2's figure is the second magnet; EXP for the same reason |
| D3 | "How do you work with strong staff engineers on technical decisions? Where do you step in and where do you step back?" | VAL | [generic] | Selection criteria: a named decision, who made it, what you did and what you left alone, how it landed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. No story is mapped, because no quote speaks to it | The panel includes two staff engineers who would sit in your squads (F1); VAL because it tests how you behave beside technical authority |
| D4 | "You'd be hiring for these squads. How would you set the bar, and who would be in the loop?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | The beats the quote states: you run the loop, for backend roles. Answer slot: the role's hiring line makes a probe on bar-setting likely. If you set the bar or the loop's structure, say what you set and how you decided; if it was set for you, or there was no explicit bar, say so plainly and describe your part in the loop you run. The figure is handled in D2 | The staff engineers would work with whoever is hired through this loop (F2); JD because it scores the stated hiring requirement |

### Bank E: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our teams sit side by side. Where's the seam between engineering and product on the roadmap, and what happens when we disagree?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Propose seam principles instead of pretending to know the seam: who decides what, what gets escalated and how early, how a disagreement surfaces before a date is committed. Add reciprocity: what you would bring to their planning, in your words. Answer slot on the quarter: use it as your disagreement example only if the roadmap pressure involved product; if it came from elsewhere, or you cannot say, do not map it to product, and give principles only | The product seat's natural question; F6 is where your material touches roadmap tension |
| E2 | "A hardware partner and our PM want incompatible things in the same quarter. How do you decide, and who do you take it to?" | CASE | [generic] | Clarify what each needs and by when; separate what is fixed from what is preference; lay out the options and the cost of each; say who decides, who must be told, and what you record. Say aloud where your own hardware knowledge would run out and whom you would ask. No claim about your past | Live version of the hardware and product partnership (F5, F6) |
| E3 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection criteria: a named piece of shared work, how you described who did what, what you did to make others' contribution visible, how it landed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Collegial probe from the peer seats; generic because no quote speaks to it |

### Bank F: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you pushed back on a roadmap." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Your one story-mapped answer. Its beats are the ones the sentence states: the roadmap pressure; the reliability quarter; you pushed it through; the on-call burden dropped 60% after. Tell them in your own words. Further beats, who applied the pressure, what was traded, how it ended, are not in your material, so they are answer slots: if you can say, say it in your own words; if you do not recall or it was not yours, say so plainly and stay with the sentence. Keep "after", never "because" | F3 and F6 carry the only roadmap-tension sentence you have; VAL because it asks for a choice made under pressure |
| F2 | "What do you need from product to run two squads predictably, and what can product count on from you?" | JD | [generic] | Reciprocity, in principles: what you need to receive (decisions made early, a stable priority order) and what you offer in return (early warning, a clear account of what is and isn't at risk). These are working principles, not claims about what you have done. Choose your own two or three and say why | The product seat prices what you would cost and contribute; generic because it is a pattern |

### Bank G: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "That result: how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold what the sentence carries: you pushed the quarter through, and the burden dropped 60% after. Answer slot: if others carried parts of it, say which and what was yours; if nobody else did, or you cannot separate it, say so plainly. Hold through two follow-ups by returning to the sentence. Concede specifically: you do not know exactly what caused the drop, if that is true, and say what you would check | The attribution probe that follows any figure; EXP because it tests candor under pressure |
| G2 | "You've never owned a hardware-adjacent roadmap, and this role partners with hardware. Convince me in a minute." | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | The same objection as B1, with a clock. The premise is your stated negative, so you may confirm it in your words: "I've never owned a hardware-adjacent roadmap." Then the plan from B1, then one thing your quotes carry, at their own scope. Hold through two follow-ups; do not add practice or experience you have not stated. Concede: the first month is learning | B1 repackaged for pressure; this question will be asked in some form (F5) |

### Reverse questions, R2

| # | Question | Why it lands |
|---|---|---|
| R2-1 | "Which technical decisions do you want the EM in the room for, and which should they stay out of?" | The staff-engineer seats see you drawing your own line for the seam instead of crossing it |
| R2-2 | "What's the on-call and reliability picture for these squads today?" | Ties to F3 honestly: you ask rather than assume the situation |
| R2-3 | "When a hardware date moves, how does the roadmap get re-decided today?" | Hands the product seat the seam question and shows you are learning F5 |
| R2-4 | "What could a new EM do in their first month that would genuinely help your team?" | The reciprocity question for peer seats; it prices what you bring, not just what you need |
| R2-5 | "Where have the squads and product disagreed recently, and how did it get resolved?" | A live case of the seam from E1, from the people who were there |

---

# Round 3: the Monday after, VP Engineering, 30 min, "values and leadership philosophy"

### Persona weights

The recruiter's own description names this round's subject, so Values/Behavioral is detected as the round's dominant style. Larkfield's published values are not in hand (see Sources), so no values cheat sheet is built and no value is named in any question. Thirty minutes means expect three to five questions in total, not the whole bank.

| Persona | How it shows up | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Values/Behavioral (bank H) | "Leadership philosophy" and behavioral prompts | high | The recruiter's description of the round | Choose your own principles; attach an instance only where a quote carries it |
| Case/Strategist (bank I) | Altitude and strategy | medium | The skip-level and executive prior | Hypothesis, confidence stated, a question back |
| Pressure (bank J) | Time-boxed challenge to the gap | medium | The executive prior, plus a 30-minute clock | Hold-then-concede, short |
| Conversational | Light opening | low | Thirty minutes leaves little room | Be ready with C1 |

### Bank H: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "What's your leadership philosophy?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure"; "I run our hiring loop for backend roles — about 40 interviews last year" | Choose two or three principles you actually hold, in your words. Your quotes carry what you did, not why, so the why is yours to supply. Attach an instance to a principle only where a sentence carries it: the reliability quarter and the hiring loop, each at its quoted scope. If no instance comes to mind for a principle, say so plainly, then give the nearest thing your material carries, or how you would handle it | The recruiter named leadership philosophy as the round's subject; F2 and F3 are your only two sentences about how you lead |
| H2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Selection criteria: a named stake, a moment you did not fold, a relationship intact at the end. The reliability quarter is the nearest quoted material, and the sentence does not say leadership was the audience, so use it only if it was. Answer slot: if you can say who the pressure came from and what you held, say it in your own words; if it was not leadership, or you do not recall, say so plainly and give the nearest thing your material carries | Values interviewers use this stem to test a hard truth landing; F6 is the nearest sentence |
| H3 | "Tell me about a decision you made as a lead that you'd make differently now." | VAL | [generic] | Selection criteria: a real decision you owned, what you knew then, what you know now, what you changed since. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. No story is mapped; your material states no decision of this kind | Leadership-philosophy rounds probe reflection; generic because no quote speaks to it |
| H4 | "What's the biggest gap between the leader you are and the leader this role needs?" | VAL | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Pick the edge from your own words and say it plainly: "I've never managed managers" and "I've never owned a hardware-adjacent roadmap" are both yours. Choose one, name it first, and give the plan as a plan: what you would ask for and from whom. Do not fold the other into a strength | Candor about the gap is scored in a values round; F1 and F5 hold your stated limits |

### Bank I: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "What do you think matters most for engineering in industrial IoT over the next few years?" | CO | [generic] | This pack holds no research on Larkfield or its market, so make no claim about either. Give your own read as a hypothesis with your confidence stated, say what you would want to learn, and ask the VP which of their priorities you have missed. A hypothesis you can defend beats a fact you cannot source | The altitude question for a VP; generic because the research did not run |
| I2 | "A major customer escalation lands mid-quarter, on top of hardware and product commitments. Walk me through what you do." | CASE | [generic] | Clarify the escalation and what is already committed; decide what can move; tell the people affected early; record the trade made. The quarter in F3 is one sentence at its own scope, so do not present your approach as a pattern you have run. The question asks about no past | Tests judgment between reliability and roadmap at the VP's altitude (F3) |

### Bank J: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "Sixty seconds: why you over a candidate who has owned a hardware-adjacent roadmap?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | B1 on a short clock. Confirm the limit first in your words: "I've never owned a hardware-adjacent roadmap." Then one thing your quotes carry at their scope, and the learning plan. Do not claim hardware experience or compare yourself to the other candidate. Hold one follow-up; concede that the first months are learning | The VP's version of the same objection (F5) |
| J2 | "A leader above you asks you to drop a reliability quarter for a roadmap commitment. What do you do?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Your position is yours to state; your quote shows one time you pushed a quarter through under pressure and says nothing about what you would do here. Say what you would ask first, what you would hold, and what you would concede, with reasons. Hold-then-concede: hold through one follow-up, then concede what you do not know about this company's constraints | The leadership-philosophy question made concrete; F3 is the nearest quoted sentence |

### Reverse questions, R3

| # | Question | Why it lands |
|---|---|---|
| R3-1 | "What does leadership philosophy look like in practice here? Which recent decision would you point to as an example?" | Substitutes for the values research that did not run; the VP's own example is more current than anything this pack could cite |
| R3-2 | "Which of the company's values do people find hardest to live up to, and why?" | Shows you care about the values as practice, not slogans |
| R3-3 | "Where do you see engineering leadership here in two years, and where does this role sit in that?" | Opens the question of scope above one EM (F1) in the VP's terms |
| R3-4 | "What's the biggest risk to the device-management roadmap you'd want a new EM to take seriously?" | A strategy question that also tells you what to learn first |
| R3-5 | "What do you wish more of your EMs asked you?" | Invites a candid answer and signals you want to be coached |

---

## Prohibited claims

What this pack will not coach, and why. Each is built from your stated limits or from the wording a sentence of yours could be stretched into.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | A negative you stated, F1 | "I've never managed managers and never owned a hardware-adjacent roadmap" — your message. The plain acknowledgment is yours: "I've never managed managers." No slot |
| Has owned a hardware-adjacent roadmap | A negative you stated, F5 | The same sentence, quoted whole. Your words: "I've never owned a hardware-adjacent roadmap." The open point, whether you have worked alongside hardware teams, is an answer slot in F5 |
| Cut or reduced on-call burden by 60% | Inflated form of F3 | The quote at its own scope: "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." The limit is the pack's observation: your material says "after", not what caused the drop or how it was counted |
| Owns or has owned delivery across two squads | Inflated form of F3 | F3's quote at its own scope: one reliability quarter. D1 and G1 stay inside it |
| Designed or built the hiring process, or set its bar | Inflated form of F2 | F2's quote: "I run our hiring loop for backend roles". The limit is the pack's observation: your material says you run it, not that you built it. D4's slot stays inside the loop you run |
| Made about 40 hires | Inflated form of F2 | The quote counts interviews. Your words stay on interviews |

## Sources

Provided: your message (the role description, the three rounds, the recruiter's description of R3, your background). No CV, no full posting, no interviewer names, no dossier.

Research tier: L1 — searches 2 of 6, fetches 0 of 2

Queries sent, both refused: "Larkfield Systems industrial IoT company values"; "Larkfield Systems industrial IoT device management strategy news".

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | The search was refused. It would have moved a values cheat sheet and mapped VAL questions for R3; neither exists, and R3's questions rest on the recruiter's words |
| 2. Larkfield Systems interview process, engineering manager | skipped | Your account and the recruiter's establish the three sessions and who runs each, so the persona weights rest on them, not on a candidate guide |
| 3. Larkfield Systems strategy and recent news | unavailable | The search was refused. It would have moved I1 and C2 from generic to grounded; they remain generic |
| 4. Interviewer name and company | n/a | No names were given, so there was no query to form; the interviewer read is absent |
| 5. Representative engineering manager job description | skipped | The role description you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full posting text → F1 to F6 requirements become quoted from the posting, and any requirement missing from your summary gets a question
- Your CV → more quoted sentences for F1 to F4; rows now at `discovery` may become story-mapped. For F3, the on-call page counts before and after the quarter, or the quarter's planning document, would raise it from `medium` toward `high`; for F2, the interview scorecard or the loop's written structure
- Larkfield's published values or leadership principles (a one-line email to the recruiter) → a values cheat sheet, and R3's selection scaffolds become mapped stories where your material carries them
- Permission to run web search → the values and strategy searches rerun; I1 and C2 become grounded. A deeper pass is available after that: up to 6 more searches and 2 more fetches, several more minutes
- The interviewers' names → persona weights read from public footprint, an interviewer read, and a reverse question tied to each person's path
- Anything the recruiter said about the panel's format (an exercise, a presentation, topics) → a build section for any declared deliverable, and a reweighting of R2
- Whether you have worked alongside hardware or firmware teams in any form, and what the roadmap pressure in your reliability quarter involved → F5 and F6 move from `discovery` to quoted evidence; B1, E1, F1 and G2 regenerate
- A `tuesday-dossier.md` from job-underwriter, if you have one → verified evidence and any prohibited claims it holds would bind this pack; the pack stands without it
