# Member Experience Lead — Ashgrove Credit Union: interview pack for Dara

Three rounds on 5 December 2026, built in loop mode because the recruiter's email gives the schedule and each round's interviewer role. Interviewers are named by role only, since names have not been assigned.

| Round | Who | Length | What the recruiter said |
|---|---|---|---|
| 1 | The recruiter | 30 minutes | Not described beyond the slot |
| 2 | Head of Member Services, your would-be manager | 45 minutes | "mostly behavioural" |
| 3 | Panel of two branch managers | 60 minutes | Includes "a 20-minute case on a complaint escalation"; "also the values round — they score against the four values" |

## How to use this pack

- Personas are how a question arrives (friendly, sceptical, case-led). Types are what it scores. Each question carries both.
- Type key: VAL is behavioural or values alignment. EXP is a deep-dive on your own experience. JD is the stated role and requirements. CO is company and strategy knowledge. CASE is a live problem.
- Guidance is scaffolding, not a script. Where it says answer slot, the slot is an instruction for the interview: answer from your own experience, or say plainly that the practice was not yours.
- Provenance labels: grounded means traceable to something you or the recruiter gave me. Inferred means my derivation, named. Generic means a role-family pattern with no claim about Ashgrove or about you.
- Question IDs run by persona across the whole pack, so the drill can call any one by ID.

## Prep triage

Nine days from today (26 November) to 5 December. You have not told me how many hours a day you have, so this is ordered by what costs you most if skipped, not by clock.

1. **B2**, the contact-centre question. It is the highest-ROI prep in this pack: the JD's headline duty covers the contact centre and your own words say you have never worked in one. Rehearse the hold-then-concede aloud until it is boring.
2. **B3** (presenting) and **E1** (the panel's 20-minute case). Both are stated or scheduled, so both will be asked.
3. **F1 to F4** and the slots in **C1** and **C2**. The panel scores these four values, and the stories have to come from your real incidents, which only you can pick.
4. **A3 to A6**. Decide your real answers on pay, notice, location and reason for leaving before round 1.
5. Everything else is insurance.

## Fit snapshot (shared across all three rounds)

JD requirements are quoted from the JD you pasted. Your evidence is quoted from your message. Where a row says answer slot, nothing in your material settles it.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says the branch's log, not the process end to end, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on whether you saw a complaint through beyond the log likely. If any of that was yours, say which part, in your own words; if the log was where your part began and ended, say so plainly and stay with the log |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The quote shows a monthly complaints spreadsheet you built, and nothing about what it counted. Answer slot: the JD names volumes and resolution times, so expect a probe on what yours tracked. If it counted either, say how, in your own words; if it tracked something else, say what; if you do not know how a number was counted, say so plainly |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | The quote is training new tellers on the script, at its own scope: "I trained new tellers on our escalation script." Answer slot: the JD says supervisors, so expect a probe. If you ever walked another supervisor through an escalation, say what and what part was yours; if not, say so plainly and stay with the tellers |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent on this, which is not the same as a gap. Answer slot: if you have worked with a digital or product team, say what the work was and what part was yours; if you have not, say so plainly, and say what you would ask a digital team first |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | presentation | A length-of-experience line, not a gate. Say it as you wrote it: six years in retail banking, the last three as a branch supervisor, and let them connect it to customer operations. Add no practice or figure to it |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [grounded] | discovery | The quote says formal, and does not show what rules the log answered to. Answer slot: if the log followed any rules or timeframes you can name, say which, in your own words; if you are not sure what governed it, or it followed none, say so plainly and stay with the log |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You have stated the limit. Words: "I've never presented to anyone above regional level." Then how you would prepare for a first leadership report, said as a plan and never as a past |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | presentation | Use your own terms: you built it, it is monthly, the regional manager uses it. Answer slot: if asked which tool, say which, in your own words |

## Grounding brief: Ashgrove's July 2026 strategy

Source: the 2026 strategy brief Ashgrove published in July 2026, as you relayed it from the recruiter's copy. I have your summary, not the brief itself. At about four months old it is current, and I found no stale framing in what you gave me.

| Fact from the brief | Provenance |
|---|---|
| Move 40% of member service to digital channels by 2028 | [grounded] |
| Consolidate eight branches into five hubs over 2027 | [grounded] |
| Launch a small-business lending product in Q1 2027 | [grounded] |
| Main competitive pressure is app-only banks | [grounded] |

Where each could surface (my inference from the JD and the loop, not something Ashgrove stated): the digital shift touches the JD's self-service journeys line (F5); the hub consolidation matters most to the round 3 branch managers and to the value "Neighbours, Not Numbers"; the lending product and the app-only competitor are context for A2 rather than for a complaints question. Treat the brief as shared reading, since every prepared candidate can assemble it: bring one fact to show you read it, then your own view (see A2).

---

# Round 1: the recruiter (30 minutes)

## Persona table, round 1

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly walk-through of your career, plus pay, notice, location and why you are leaving | High. A recruiter screen's prior is conversational plus a light sceptic, and the recruiter's email gives this round no other shape | Prepare a 90-second arc from your own quoted sentences, and treat every casual question as scored |
| Skeptic (light) | A knockout-style check on the biggest gaps | Medium. The prior is light, and F2 and F8 are gaps you have stated yourself | State the gap plainly in your own words before it is pulled out of you |
| Others | Not expected | Low. Nothing in the recruiter's email points to Pressure, Prober, Case or Peer here | None needed |

## Bank A: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your journey so far." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Three beats, each a clause your sentences state: six years in retail banking, the last three as a branch supervisor; the branch's formal complaints log and training new tellers on the escalation script; the monthly complaints spreadsheet you built that your regional manager uses. Tell them in your own words. Close on why this role, in your own words, in one sentence about what you want to do next. Add no beat the sentences do not carry | The opener of every recruiter screen, and the arc the later rounds will test against; F1, F4 and F6 are the rows it draws on. EXP because it is your own history |
| A2 | "What do you know about where Ashgrove is heading?" | CO | [grounded] | Bring one fact from the brief to show you read it, for example the move of 40% of member service to digital channels by 2028. Then give your own view, with its concession: for example, that as more service goes digital, the complaints that reach a person may be the harder ones, said as your reading of a published brief and not as something you have seen in Ashgrove's data. Name what you would want to ask the digital team first. A thesis you can concede beats a recital | The strategy brief is the research this question draws on, and it is equally available to other candidates, so the rubric asks for one consensus fact and one view. CO because it tests homework depth |
| A3 | "What are your salary expectations?" | JD | [generic] | A logistics slot. Give your own figure in your own words, or ask for the role's band first; the posting you pasted states none. If asked what you earn now: "I'd rather focus on the range for this role." Decide which you will do before the call | Pay is a standing recruiter question and the one most worth deciding in advance. JD because it is the listed job's terms |
| A4 | "What's your notice period?" | JD | [generic] | A logistics slot. Give your actual notice period, as your contract states it | A knockout and scheduling question; the only safe answer is your own |
| A5 | "Where can you work, and how would that fit the role?" | JD | [generic] | A logistics slot. Give your own location constraints in your own words, or ask where the role is based before answering. The posting does not say, and the brief mentions eight branches becoming five hubs over 2027, so asking where the role sits is a fair question | The posting names branches and a contact centre without a location, so the recruiter will want it settled. JD because it is the listed job's terms |
| A6 | "Why are you looking to leave your current role?" | EXP | [generic] | A logistics slot. Give your actual reason in your own words, in one sentence, pointing toward what this role does. Say nothing about a past employer that you could not repeat to them | Reason for leaving is asked in every screen, and an unprepared answer is where candour tips into complaint. EXP because it is about your own choices |
| A7 | "Tell me what you understand the job to be." | JD | [grounded] | Say the four duties in the JD's own words: own the member complaints process end to end across branches and the contact centre; report monthly on complaint volumes and resolution times; coach branch supervisors on escalations; work with digital teams on self-service journeys. Then say which two you are most ready for, and which you would need to learn, in your own words. Naming the learning edge first is the honest move, and the sharper one | Checks you read the JD and know your own edges before the managers do; F1 to F5 are the rows. JD because it scores the stated role |

## Bank B (round 1 item): Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | The honest answer is already in your own words: "I've never worked in a contact centre." Say it first, plainly, before it is pulled out of you, then stop. Do not blur it with the presenting gap, which has its own question in round 2 (B3). Then say, in your own words, what you would do first to learn it | The recruiter screen's light sceptic goes to the stated gaps (F2, F8); rehearsing B1 makes B2 easier. JD because it scores the listed requirements |

## Reverse questions, round 1

| # | Question | Why it lands |
|---|---|---|
| 1 | "Can you tell me who is on the panel and who the Head of Member Services is, so I can prepare for them properly?" | Names are unassigned today; asking early shows preparation and is the one input that unlocks the interviewer read |
| 2 | "Is the 20-minute case sent in advance, or is it live on the day?" | The recruiter named the case but not its format, so the answer changes how you prepare |
| 3 | "How is the complaints process split today between the branches and the contact centre?" | It tests the ownership question the JD raises, without claiming anything about the contact centre |
| 4 | "How do the three rounds feed into the decision, and when should I expect to hear?" | A normal process question that also tells you whether the rounds are scored against the same criteria |
| 5 | "Where will the role be based, and does that change with the hub plan?" | Ties your location answer (A5) to the brief, and signals you read it |

---

# Round 2: Head of Member Services, your would-be manager (45 minutes)

## Persona table, round 2

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | "Tell me about a time" questions on complaints, coaching, and difficult messages | High. The recruiter calls this round "mostly behavioural" | Map a story to each question where one of your quoted sentences carries it; use "we" for context and "I" for what you did |
| Skeptic | A calm probe of the contact-centre and presenting gaps | High. A hiring manager is buying capability and de-risking gaps, and F2 and F8 are the two you have stated | Rehearse B2 until it is boring: concede in your own words, hold what your quotes carry, never add to it |
| Prober | One walk-through of your spreadsheet | Low. The spreadsheet (F3) is the only artifact you have named, and it is your most inspectable one | Know what you can and cannot say about what it counted, and say plainly where you do not know |
| Others | Case, Pressure, Peer | Low. The recruiter put the case in round 3, and nothing signals a pressure style | None needed |

## Bank B (round 2 items): Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B2 | "This role owns complaints across branches and the contact centre, and you've said you've never worked in a contact centre. How would you own that half?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | **The highest-ROI rehearsal in this pack.** Concede first, in your own words: "I've never worked in a contact centre." Hold only what your quotes carry: "I handled the branch's formal complaints log." Follow-up one ("so what do you actually know about the contact centre?"): return to the log at its scope, and do not add contact-centre practice. Follow-up two ("so why trust you with it?"): do not fold on the log and do not stretch it; say what you would do in your first weeks to learn their side, in your own words. Answer slot: if any complaint from your branch ever passed to or from a contact centre, say what happened and what part was yours; if none did, say so plainly and stay with the log | F2 is the one place where the JD's headline duty meets a limit you have stated, so the question will arrive in some form. JD because it scores a listed requirement; it is the deepest rehearsal because it is aimed at exactly where the material is thin |
| B3 | "Tell me about the most senior audience you've presented to." | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I built the monthly complaints spreadsheet our regional manager uses." | Say the plain fact: "I've never presented to anyone above regional level." Then answer slot: if you have presented at regional level, say to whom, about what and how it went, in your own words; if what your regional manager received was the spreadsheet rather than a talk, say so plainly. Then how you would prepare for a first leadership report, in your own words, as a plan. Do not describe your spreadsheet as a presentation | F8 is the other gap you have stated, and the JD says "confident presenting to senior leaders". JD because it scores a listed requirement; it is an open prompt with the theme taken from the JD |
| B4 | "You'd be coaching branch supervisors on escalations. What have you done to coach another supervisor?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "6 years in retail banking, the last 3 as a branch supervisor." | Start from the sentence at its own scope: "I trained new tellers on our escalation script." Answer slot: the JD says supervisors, so say whether you ever walked another supervisor through an escalation; if you did, say what and what part was yours; if not, say so plainly and stay with the tellers. A second probe may be whether you wrote the script: if you wrote or changed it, say how; if it was given to you, say so plainly | F4 is a transferable row, and the manager will test whether training tellers reaches coaching supervisors. JD because the question is built from a listed duty |
| B5 | "What experience do you have working with digital teams on self-service journeys?" | JD | [generic] | Answer slot only, since your material is silent (F5). If you have worked with a digital or product team, say what and what part was yours; if you have not, say so plainly, and say what you would ask a digital team first. The brief's 40% digital target gives you a fair reason to ask | F5 is a discovery row, and the 40% target makes the digital half of the job more than a footnote. JD because it scores a listed duty |

## Bank C: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time a member's complaint couldn't be settled at first contact." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | A selection scaffold. Pick a complaint from your own work that needed more than one conversation, with a named stake, what you were responsible for, and what happened next. Your sentence carries only that you handled the log, so the incident itself is yours to choose and describe. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Complaints are the whole job, so a behavioural round will start here; F1 is the row. VAL because it asks for a specific past decision, not a statement of approach |
| C2 | "Tell me about a time you trained or coached someone through an escalation." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F4, with the beats the sentence states: the tellers were new, and what you trained them on was the escalation script. Answer slot: what happened when a teller first used it is yours to say if it happened, and if there is no such moment to describe, say so plainly and describe the training itself | The JD's coaching duty (F4) has this as its natural behavioural form. VAL because it asks for a specific past instance |
| C3 | "Tell me about a time you had to tell someone more senior something they didn't want to hear." | VAL | [generic] | A selection scaffold: it needs a named stake, a moment you did not fold, and an intact relationship at the end. Choose one from your own work. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD asks for confidence with senior leaders (F8), and this is the behavioural form of it. VAL because the point scored is how you handled it |
| C4 | "Tell me about a time you worked with a team outside your branch to fix something for a member." | VAL | [generic] | A selection scaffold. Choose a case where someone outside your branch held part of the fix; say what you needed from them and what you did when they could not give it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's duties cross branches, the contact centre and digital teams (F2, F5), so cross-team work is a natural behavioural probe. VAL because it asks for a specific past instance |

## Bank D: Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the monthly complaints spreadsheet you built — what did it show, and who used it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say what the sentence says: you built it, it is monthly, and your regional manager uses it. Answer slot: the JD names volumes and resolution times, so expect a probe on what yours counted. If it counted either, say how each was counted, in your own words, and which assumption you would defend least; if it tracked other things, say what; if you do not know how a figure was counted, say so plainly. Never name a measure it did not track | F3 is the one artifact you can show, and a prober will go straight to it. EXP because it tests whether the line survives a second question |

## Reverse questions, round 2

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would a good first ninety days look like in this role?" | Manager-level and practical, and it shows you are planning to land the role, not just win it |
| 2 | "Where do complaints get stuck today between branches and the contact centre?" | Tests the JD's end-to-end duty at its seam, and invites your future manager to describe the real problem |
| 3 | "How do you expect the 40% digital target to change the complaints the team sees?" | Ties to the brief and invites their view, which is more useful than reciting the brief at them |
| 4 | "Who sees the monthly report, and what decision does it inform?" | Shows you think of reporting as serving a decision; it also tells you who the senior leaders are (B3) |
| 5 | "How will you judge whether the role is working at six months?" | A direct way to learn what success means to the person who would be your manager |

---

# Round 3: panel of two branch managers (60 minutes)

## Persona table, round 3

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Stories scored against the four published values | High. The recruiter says "they score against the four values" | Map a story to each value where one of your quoted sentences carries it, a selection scaffold where none does |
| Case/Strategist | The 20-minute complaint-escalation case | High. The recruiter named it; it is a third of the round | Clarify, set the objective, structure the approach, name how you would measure it and the risks; think aloud and challenge one premise respectfully |
| Peer Evaluator | Where the lead's role meets the branches, and how disagreements get settled | Medium. Branch managers run the supervisors you would coach, so they will price what the hire does to their load. This is my inference from the JD, not something the recruiter said | Reciprocity: say what you bring their branches, and propose seam principles instead of pretending to know today's seam |
| Others | Skeptic, Pressure, Prober | Low. The recruiter describes a values-and-case round, and the gaps will have been tested in round 2 | None needed |

## Bank E: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A member's formal complaint has stayed open longer than it should. The branch says it is with the contact centre, the contact centre says it is back with the branch, and the member has now called three times. You have 20 minutes: what do you do?" | CASE | [generic] | Structure it aloud. Clarify first: what the complaint is about, what clock it is on under the rules it falls under, what the member has been told, who holds it right now. Objective: the member's problem solved, then the process fixed. Approach: name one owner today and keep them on it until it is solved; tell the member in plain words what happens next; then find why it bounced between two teams. Metrics and risks: what you would record, how you would report it, what you would watch for in the next month. The case needs no claim about your past, so the guidance makes none | The recruiter named a complaint-escalation case, and this is the JD's end-to-end duty (F1, F2) in a live problem. CASE because it scores structure; generic because it is a pattern for the problem, not a fact about Ashgrove |
| E2 | "A long-standing member of a branch that is moving into a hub tells you nobody here cares about their town. How do you respond?" | CASE | [grounded] | Separate the three things in it: the member's feeling, any specific complaint inside it, and a decision that is not yours to change. Listen first and say back what you heard in plain words; log any specific complaint and name an owner; be honest about what you can and cannot change without promising what the decision-makers have not. Concede that you know the hub plan only from the published brief. Report the theme monthly so the pattern reaches leaders | The brief's eight-branches-to-five-hubs move is the one strategy fact that lands on branch managers directly. CASE because it asks for live structure; the value "Neighbours, Not Numbers" is its backdrop |
| E3 | "Next month's report shows complaints about one branch rising while resolution times stay flat. What do you do with that?" | CASE | [generic] | Clarify before concluding: is it more complaints or more members, did the way they are counted change, what kinds of complaint are rising. Talk to the branch supervisor before the leaders' report, not after. Decide what goes in the report and what does not, and say what you would still be unsure of. The case needs no claim about your past, so the guidance makes none | The JD's monthly reporting duty (F3) as a live problem; CASE because the scoring is the reasoning, not a right answer |

## Bank F: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Members First, Always: tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | A selection scaffold. Choose a moment where what the member needed and what a process or target asked pulled apart; say what you decided and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is that "I handled the branch's formal complaints log", or how you would handle it | The first of the four published values, and the one the recruiter's panel will score first. VAL because it scores a decision, not a slogan |
| F2 | "Plain Words: tell me about a time you explained something so clearly that it needed no second explanation." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F4 and the beats the sentence states: you trained new tellers, and what you trained them on was the escalation script. Answer slot: if the script's wording was yours, or you changed it, say what you changed; if it was given to you, say so plainly and stay with how you trained the tellers | The value's own test is "if a member needs it explained twice, we wrote it wrong", and an escalation script is where wording matters. VAL because it asks for a specific instance |
| F3 | "Neighbours, Not Numbers: tell me about a time you looked behind a number to the members it stood for." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F3 at the sentence's own scope: you built the monthly spreadsheet. Answer slot: if there was a month when a figure in it led you to a specific branch or members, say what you did and what part was yours; if not, say so plainly. The JD asks for monthly volumes, so expect this one to be asked with a smile and meant | The job reports numbers monthly, and this value says numbers are not the point; that tension is the likeliest values probe. VAL because it asks for a specific instance |
| F4 | "Own the Fix: tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F1 at its scope: you handled the log. Answer slot: the complaint you kept hold of is yours to choose; say what you did and what finally solved it, in your own words. If none stayed with you through to the end, say so plainly and describe where your part stopped | The fourth value matches the JD's end-to-end duty almost word for word. VAL because it asks for a specific instance |

## Bank G: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "You'd coach our supervisors on escalations. Where is the seam between what a branch manager owns and what you own, and what happens when we disagree?" | JD | [generic] | Offer principles rather than pretending to know today's seam: a complaint has one named owner at every moment; the branch keeps the member relationship; you own the process and the monthly picture. Say what you would ask them first about how it works today. On disagreement, bring the case and not a position, and agree who decides before you start. Name your own limit: you would be learning their branches | The role works through branch supervisors, so the managers will price what the hire does to their load. JD because it scores the coaching duty (F4) |
| G2 | "How do you handle credit when a complaint is fixed by several people across a branch and the contact centre?" | VAL | [generic] | Principle first: name everyone who fixed it in the record and in the monthly report, and say so to their managers. Say what you would do if credit is disputed. The question needs no claim about your past, so the guidance makes none | A peer-style probe of partnership fit; VAL because it scores behaviour over capability, and it mirrors the cross-team nature of the job |

## Values cheat sheet

Values quoted from the page you pasted from ashgrovecu.org/about/values. A values round is detected because the recruiter says the panel "is also the values round".

| Value | Working meaning (paraphrased) | Mapped story, or scaffold | Asked in |
|---|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Scaffold with its honest branch; nearest thing carried is F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." | F1 |
| Plain Words | If a member needs it explained twice, the writer got it wrong | F4: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Beats: the tellers, and the escalation script; wording changes are an answer slot | F2 |
| Neighbours, Not Numbers | Every branch is part of its town | F3: "I built the monthly complaints spreadsheet our regional manager uses." Beats: you built it, monthly; what a figure led you to is an answer slot | F3 |
| Own the Fix | Whoever finds a problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Beat: you handled the log; the complaint you kept hold of is an answer slot | F4 |

A tension to expect: the JD asks you to report volumes and resolution times monthly, and one value is "Neighbours, Not Numbers". This is my reading, and it is the likeliest place a panel will test whether you can report numbers and still see members.

## Reverse questions, round 3

| # | Question | Why it lands |
|---|---|---|
| 1 | "What do your supervisors find hardest about escalations today?" | Asks about their world before yours, and it ties directly to the coaching duty |
| 2 | "When a complaint comes from your branch, how would you want to hear about it, and when?" | Opens the seam conversation and shows you plan to work with branches, not above them |
| 3 | "How are the branch managers involved in the move from eight branches to five hubs, and where do complaints fit in it?" | The brief's consolidation touches them directly, and you show you read it |
| 4 | "Which of the four values is hardest to live in a busy branch, and what does it look like when it is done well?" | Meets the panel on the scored ground and invites a real story |
| 5 | "What could a new complaints lead do in their first month that would genuinely help your branch?" | The reciprocity question; it turns a panel into a conversation |

---

# Requirement coverage

| JD requirement | Questions |
|---|---|
| Own the member complaints process end to end across branches and the contact centre | A7, B1, B2, C1, E1, F4 |
| Report monthly on complaint volumes and resolution times | A7, D1, E3, F3 |
| Coach branch supervisors on escalations | A7, B4, C2, F2, G1 |
| Work with digital teams on self-service journeys | A2, A7, B5, C4 |
| 4+ years in financial-services customer operations | A1 |
| Experience handling regulated complaints | C1 (the complaints story), E1 (the live case); none — and why: no question names regulation, because nothing you gave me shows what rules the log answered to, so that slot lives in F7 |
| Confident presenting to senior leaders | B3, C3 |
| Comfortable with Excel reporting | D1, E3 |

# Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end, or across branches | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: the material says the branch's log, not the process end to end |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: "I trained new tellers on our escalation script." The material says tellers, not supervisors |
| Reported monthly on complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." The material does not show what it counted |
| Handled regulated complaints | Inflated form of F7 | F7's quote at its own scope: "I handled the branch's formal complaints log." The material says formal, and does not show what rules it answered to |
| Has contact-centre experience | Negative you stated, F2 | The plain acknowledgment: "I've never worked in a contact centre." No slot beyond B2's, which allows that no complaint ever crossed over |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment: "I've never presented to anyone above regional level." |

# Sources

Provided documents: the JD you pasted; the values text you copied from ashgrovecu.org/about/values (not fetched, since its content is in hand); the recruiter's email about the process; your summary of the July 2026 strategy brief; your background in your message. No dossier was present. No interviewer information was provided beyond roles.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values text fixes the values cheat sheet and the VAL questions |
| 2. Ashgrove interview process, member services | skipped | The recruiter's email establishes all three rounds, who runs each and the case, so persona weights follow the named rounds |
| 3. Ashgrove strategy and recent news | skipped | Your summary of the July 2026 brief fixes the grounding brief and A2, E2; it is about four months old |
| 4. Interviewer name and Ashgrove | n/a | No names were given, so there was no query to form; the interviewer read is absent |
| 5. Representative Member Experience Lead JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions |

# Upgrade menu

- The names of the Head of Member Services and the two branch managers → an interviewer read from their public professional footprint, persona weights adjusted to them, and reverse questions tied to their own paths
- The strategy brief itself, or the recruiter's detail on the 20-minute case (format, material sent in advance, how it is scored) → the grounding brief and E1 to E3 move from your summary to the document
- A redacted copy of your monthly complaints spreadsheet, or a short description of what each tab counted → F3 and F9 confidence rises from medium toward high, and D1 becomes story-mapped instead of an answer slot
- Your own answers to the answer slots in F1, F3, F4, F5, F7 (what the log answered to, what the spreadsheet counted, whether you ever coached a supervisor, any digital-team work) → each row can be quoted into the fit snapshot and the questions that draw on it regenerated
- Your real notice period, pay position, location and reason for leaving → A3 to A6 are filled in your own words instead of left as instructions
- A deeper research pass, up to 6 more searches and 2 more fetches, several more minutes → recent news on the hub consolidation and app-only competitors, and candidate reports on this kind of loop, flagged as inferred; say the word if you want it
- A `tuesday-dossier.md`, if you have one → verified evidence, a named highest objection and absolute prohibited claims would replace what I inferred here
