# Interview prep pack: Product Manager, Platform APIs at Quartzline

Round: a 45-minute conversation with the hiring manager (interviewer's name not given), on Thursday. Built from your `tuesday-dossier.md` (conditional_go) plus your message. Persona weights rest on your own words about the round, not on a documented Quartzline loop.

## How to use this pack

Personas are how a question arrives. Types are what it scores. Guidance is scaffolding to rehearse aloud in your own words, not a script. Answer slots are instructions for the interview: they ask nothing of you here.

| Type | Meaning |
|---|---|
| VAL | Past behaviour against the company's published values. Appears in no row: no values-style round is detected (see Persona table) |
| EXP | Whether your claims survive scrutiny; what was actually you |
| JD | The stated role and requirements, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem set in the role |

## Fit snapshot

Requirement text is quoted from the dossier's `role_profile`. Evidence is quoted from the dossier's `verified_candidate_evidence`. The origin tag on each quote names the requirement it sits nearest, which is this pack's pairing and not the dossier's. Confidence and gap type follow the dossier's own grading where it gave one: F1, F2 and F6 are its rows. F3, F4 and F5 are graded here from the quotes, because the dossier lists no weak area for R2, R3 or R4.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — JD, must have (R1) | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier R1; "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier R2 | low | [grounded] | transferability | The underwriter's strategy is bridge, positioned as adjacent and never as product management experience. Words stay at the quotes' scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" and "I ran quarterly roadmap-input sessions that fed client evidence to product." The pack's observation: your material shows work beside product, and no quoted sentence reaches three years in a product management role. Answer slot: the JD's three-years line makes a probe on which of your work sat closest to product likely. Say which, and what part was yours, in your own words; if none sat close to product, say so plainly and stay with the integrations and the sessions |
| F2 | "Own the roadmap for the partner-facing API platform" — JD responsibility, the roadmap and prioritization-authority part of R1 | none given | none | [grounded] | capability | The dossier records this area as `acknowledge_gap`, and its `prohibited_claims` list "Having owned a product roadmap" and "Having set prioritization for an engineering squad". Words: "I haven't owned a product roadmap." Then how you would learn it, said as a plan and never as a past. No bridge from the sessions in F1: they fed evidence to product, which is not owning what product built |
| F3 | "Shipped API or platform products" — JD, must have (R2) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier R2 | high | [grounded] | transferability | The dossier names no strategy for this requirement; the pack treats it as adjacent work and keeps the limit in view. The pack's observation: the quote is about integrating the vendor's APIs, and it does not say you shipped an API product. Words at the quote's scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Answer slot: the JD says shipped, so expect a probe on the release of the API itself. If you were involved in any such release, say what your part was; if there was none, or it was not yours, say so plainly and stay with the integrations you led |
| F4 | "Technical fluency: API docs, schemas" — JD, important (R3) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier R2; "Wrote the internal integration playbook her team uses" — dossier R3 | high | [grounded] | discovery | The quotes touch the requirement without showing API docs or schemas. Words at scope: "I wrote the internal integration playbook my team uses." Answer slot: the JD names API docs and schemas. If you worked from, wrote or reviewed either in the integrations or the playbook, say which, in your own words; if not, say so plainly and stay with the playbook and the integrations |
| F5 | "Stakeholder management across engineering, sales, customers" — JD, important (R4) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier R2; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier R1 | medium | [grounded] | transferability | The quotes carry clients and product. They do not say engineering or sales. Medium because the sessions quote has limited inspectable proof. Answer slot: the JD lists engineering and sales, so expect a probe on each. If either was among the people you worked with in those integrations or sessions, say how, in your own words; if not, say so plainly and stay with clients and product |
| F6 | "Agile delivery experience" — JD, preferred (R5) | none given | low | [grounded] | discovery | The dossier's strategy is clarify. No quoted sentence speaks to this requirement, so nothing about your past goes into an answer. Answer slot: the JD says agile delivery, so expect a probe on how you have worked. If you have worked that way, say how, in your own words; if you never worked that way, say so plainly, and say what you would want to confirm about how this team defines it |

## Persona table

The loop rests on your own words: one 45-minute conversation with the hiring manager. No Quartzline loop source was read, so no archetype is applied. No values-style round is detected, so there is no Values bank and no values cheat sheet.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the title and roadmap gap | High, weight 5. The hiring-manager prior puts it first, and the underwriter named a specific objection built on F1 and F2 | Rehearse the A1 objection until it is boring: concede first, bridge at the quotes' scope, hold through two follow-ups |
| Case / Strategist | Live problems from the role: adoption, partner discovery, API change, prioritization | High, weight 5. The hiring-manager prior puts it first, and the JD responsibilities are decisions to be made | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise |
| Conversational | The opener and the motivation question | Medium, weight 3. Weighted from what the conversation must contain, not from a signal | A short arc built from your three quoted sentences, and your own reason for the move |
| Data-Driven Prober | Line-by-line probes on the 30+ figure, the playbook and the sessions | Medium, weight 3. The 30+ is the one headline figure on file, and two quotes carry caveats | Know what you can and cannot say about each; volunteer the limit before it is extracted |
| Peer Evaluator | The seam between this role and the two engineering squads | Low, weight 2. No peer interviewer is known, but squad authority is an open risk in the dossier | Propose seam principles instead of claiming a seam you do not know |
| Pressure | Time-boxed or interrupting versions of the objection | Low, weight 2. No signal of a stress style | Pause, restate, hold the position the quotes carry, concede specifically |
| Values / Behavioral | Scenario probes against published values | Low, weight 0. No values-style round is detected, and no values page was read | No bank |

## Question banks

Bank A is the Skeptic, B the Case / Strategist, C the Conversational, D the Prober, E the Peer and P the Pressure persona. A1 is the highest-ROI prep in the pack: the underwriter named this objection from the evidence you confirmed, and it will arrive in some form.

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; the objection is the dossier's `likely_interviewer_objections`, and its negatives rest on `prohibited_claims` and `acknowledge_gap` | The deepest rehearsal in the pack. Beat 1, concede first, plainly: "I haven't held a product manager title or role, and I haven't owned a product roadmap." Beat 2, the bridge at the quotes' scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live, and I ran quarterly roadmap-input sessions that fed client evidence to product." Beat 3, the limit before it is asked for: "I haven't set prioritization for an engineering squad." Then stop, and let them draw the inference. Follow-up 1 likely asks why you would learn it faster than a PM already in the seat. Do not claim you would; return to beat 2 and give the plan: "My first weeks would go to the two squads' constraints, how adoption is measured today, and which decisions are mine and which are theirs." Follow-up 2 likely asks why they should take the bet. Concede specifically, since a PM in the seat is the safer bet on roadmap ownership, hold the beats, and ask what they would want to see early. Never call the work equivalent to product management | F1 and F2 are the biggest gaps and the objection is aimed exactly there, so it arrives in some form. JD because it scores the first must-have, delivered as a Skeptic probe |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] `acknowledge_gap` area for the roadmap and prioritization authority | Name the gap the underwriter already established, so it is yours and not extracted: "I haven't owned a product roadmap." Then the plan as a plan: what you would read first, who you would ask, and the question you will put to them about which decisions are the PM's alone. No past claim goes after the acknowledgment. Do not name a weakness you have not been shown to have | F2 is the weakest row and A2 is the standard Skeptic stem for it. JD because it scores fit against the listed role |
| A3 | "You would be driving delivery with two engineering squads. Where do your decisions end and theirs begin?" | JD | [generic] | You do not know the seam, so do not pretend to. Offer principles: who decides what, who is consulted, how a disagreement escalates, and what you would want written down before the first sprint. Then turn it into your question: which decisions does this role make alone. The question needs no claim about your past, so the guidance makes none | The dossier lists squad authority as an unvalidated risk, and the JD line on two squads raises it. JD because it scores a stated responsibility, generic because it is a pattern and not a fact about Quartzline |
| A4 | "Tell me about an API or platform product you have shipped." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Story-mapped on F3 at the quote's scope: tell the integrations you led in your own words. Answer slot: the JD says shipped, so expect a probe on the API's own release. If you were involved in one, say what your part was; if there was none, or it was not yours, say so plainly and stay with the integrations. Do not call the integrations a shipped product | F3 is the evidence for a must-have the quote only touches. JD because it scores the second must-have |
| A5 | "How have you worked in an agile delivery setting?" | JD | [grounded] | No quote of yours speaks to this, so the guidance is a slot. Answer slot: the JD asks for agile delivery experience, preferred. If you have worked that way, say how, in your own words; if you never worked that way, say so plainly, then say what you would want to confirm about how this team defines it. It is a preferred requirement, so a calm honest answer costs little | F6 is a discovery gap and the dossier's strategy is clarify. JD because it scores the preferred requirement |

### B. Case / Strategist (weight 5)

No Quartzline strategy source was read (the search was refused), so every case below is generic. The cases are live problems and presuppose nothing about your past.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Partners have integrated the API but call volume is flat. Diagnose it." | CASE | [generic] | Clarify first: what adoption means here and how it is measured today, which the dossier lists as unknown. Then the objective, a segmentation of partners by where they stopped, hypotheses under each, the data that would separate them, and the risks. Say your assumptions aloud and challenge one premise respectfully | The JD makes adoption metrics a responsibility and the baseline is unstated. CASE because it is a live diagnosis |
| B2 | "You meet five integration partners next week. What do you want to learn, and how do you run it?" | CASE | [generic] | Objective first, then who you would pick and why, the questions grouped by what you need to decide, how you would avoid leading the partner, and what you would do with the answers. Make no claim about having run discovery before | The JD lists discovery with integration partners as a responsibility. Nothing in F1 to F6 speaks to it, so this is rehearsed as a case |
| B3 | "Two partners want conflicting changes to the same endpoint: one needs a breaking change and one needs stability. Walk me through it." | CASE | [generic] | Clarify who is affected and how badly, then the options: a versioned change, a deprecation window, an extension that avoids the break. State your decision criteria, how you would tell both partners, what you would write in the spec, and the metric that shows it worked | The JD makes writing specs a responsibility. CASE because the answer is a structure |
| B4 | "What makes API documentation and a schema good enough for a partner to integrate without help?" | JD | [grounded] "Wrote the internal integration playbook her team uses" | Give your criteria as opinions, in your own words. Answer slot: the JD names API docs and schemas, so expect a probe on your own use of them. If the playbook or the integrations had you working from either, say which; if not, say so plainly and stay with the playbook you wrote | F4 is the discovery row for the technical-fluency requirement. JD because it scores that requirement, with a CASE delivery |
| B5 | "One squad needs two sprints for technical debt, and a top partner asks for a new endpoint. How do you decide?" | CASE | [generic] | Say first what you would need to know, including which part of this decision is yours: that is the open authority question, and asking it is the strong move. Then the criteria, the options, the conversation with each side, and how you would record the call. Use "I would", never "I have" | It tests prioritization without asking you to claim any. CASE because it is a live trade-off |

### C. Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey. How did you get here, and why this role?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc built from those three sentences and no others: the integrations you led, the playbook you wrote, the sessions you ran. Tell each at its own scope, in your own words. The why-this-role beat is yours: say your actual reason in your own words | F1 and F3 carry the arc. EXP because it is the CV walk-through |
| C2 | "What do you know about Quartzline and its partner API platform?" | CO | [generic] | Research was unavailable, so the pack states nothing about Quartzline. Before Thursday, read what is public (its developer docs and its announcements, if they exist) and note two specifics you can say as things you read. If you find little, say so plainly and ask the interviewer to fill in the picture | CO coverage with no source to ground it, so it is honest rehearsal of how to answer |
| C3 | "What draws you to platform work rather than leading client integrations?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Your reason is your own and the pack will not supply one. Selection criteria: pick something real from the integrations you led that you would want to change upstream, in your own words. If no such thing comes to mind, say so plainly, then give the nearest honest reason you do have | The Skeptic's motivation question in a friendly register. EXP because it tests whether the story holds together |

### D. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You led 30+ integrations. How was that counted, and which part of each was yours?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Defend-the-number slots, each in your own words. Answer slot: how the 30+ was counted; what the count is sensitive to; the assumption behind it you would defend least; which part was yours. If you do not know how something was counted, say so plainly. The quote says led, so hold that word and neither add to it nor shrink it | F3 is the one headline figure and probers go there first. EXP because it tests attribution |
| D2 | "Walk me through the integration playbook. How do you know your team uses it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | At the quote's scope: you wrote it and your team uses it. Answer slot: the question asks how you know. If you know how it is used, say how you know; if you do not, say so plainly and stay with the playbook you wrote. The playbook is inspectable, so offer to walk through it, after checking what you are allowed to share | F4's quote is the strongest evidence in the dossier. EXP because it tests whether the claim survives |
| D3 | "What changed because of the roadmap-input sessions?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | This is the medium-confidence quote, so volunteer the limit before it is extracted. Say what you ran and what you fed to product, in the quote's words. Answer slot: if any of it changed what product did, say what and how you know; if you do not know, or nothing changed, or you could not see the decision, say so plainly and stay with the sessions. Never say the sessions shaped the roadmap | F1 and F5 lean on this quote and nothing inspected sits behind it. EXP because it tests attribution |

### E. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you disagreed with an engineering team about scope." | JD | [generic] | Selection criteria: it needs a real disagreement, what each side wanted, your part, and a working relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Do not borrow an incident | F5 asks for engineering stakeholders and no quote reaches them. JD because it scores that requirement |
| E2 | "How do you work with sales when a deal needs something the platform cannot do yet?" | JD | [generic] | Same selection criteria and the same honest branch. If you have no such case, give principles: what you would want to know about the deal, what you could and could not promise, and how you would feed the request into the roadmap process | F5 asks for sales stakeholders and no quote reaches them. JD because it scores that requirement |

### P. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Sixty seconds: why you over a PM with three years in the seat?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; `prohibited_claims` | A1 compressed. Pause and restate the question. One sentence of concession: "I haven't held a product manager title or role." Two sentences of bridge at the quotes' scope. Stop. If interrupted, hold through two follow-ups, then concede specifically and never claim equivalence | A1 under time pressure. JD because it scores the same requirement |
| P2 | "That integration work: how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold: the quote says you led them. Answer slot: which parts were yours and which belonged to others, in your own words; if you cannot split them, say so plainly. Concede specifically, and do not fold on the core claim to make the pressure stop | The attribution probe at its harshest. EXP because it tests what was yours |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| R1: 3+ years product management experience | A1, A2, C1, P1, and the roadmap part in A3 and B5 |
| R2: Shipped API or platform products | A4, D1, P2 |
| R3: Technical fluency: API docs, schemas | B4, D2 |
| R4: Stakeholder management across engineering, sales, customers | E1, E2, A3 |
| R5: Agile delivery experience | A5 |
| Responsibility: discovery with integration partners | B2 |
| Responsibility: specs and delivery with two squads | B3, B5, A3 |
| Responsibility: adoption metrics | B1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The JD asserts the authority and the dossier found no evidence of it. The answer is what you need before accepting, and it reads as diligence |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | Adoption metrics are a named responsibility with no stated baseline, so the answer sets what success is |
| 3 | "Given I have not held a PM role, what would you want to see in my first months to feel the hire was right?" | It turns the A1 objection into a shared definition of success. Ask it only if A1 went well |
| 4 | "What does the rest of the process look like, and who else would I meet?" | Gives you the shape of the remaining rounds, which this pack could not source |
| 5 | "What is the hardest open question on the platform roadmap right now?" | It invites the interviewer to talk about the work, and tells you what you would walk into |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | `prohibited_claims` | The plain acknowledgment, sourced from that field: "I haven't held a product manager title or role." Then the quotes in F1 at their scope |
| Having owned a product roadmap | `prohibited_claims` and the `acknowledge_gap` area | The plain acknowledgment, sourced from those fields: "I haven't owned a product roadmap." No slot, no bridge |
| Having set prioritization for an engineering squad | `prohibited_claims` and the `acknowledge_gap` area | The plain acknowledgment, sourced from those fields: "I haven't set prioritization for an engineering squad." No slot |
| Shipped an API or platform product | Inflated form of F3 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" at its own scope. The limit is the pack's observation: the material says integrations of the vendor's APIs, not a shipped product. A4's slot stays inside the integrations |
| The roadmap-input sessions shaped or set the roadmap | Inflated form of F1 | "Ran quarterly roadmap-input sessions feeding client evidence to product" at its own scope. The limit is the pack's observation: the material says the sessions fed evidence to product, not what product did with it. D3's slot stays inside the sessions |
| Acting as the product manager in all but title | Inflated form of F1 | The two quotes in F1 at their own scope, with nothing added to them |

## Sources

Provided: your message (round, length, day) and `tuesday-dossier.md`, version 1.1. The dossier supplied `role_profile` (requirements and responsibilities, standing as the JD), and from `handoff_to_mock_interview`: `high_priority_requirements`, `verified_candidate_evidence`, `uncertain_or_weak_areas`, `likely_interviewer_objections`, `opportunity_risks_to_validate`, `questions_for_employer` and `prohibited_claims`. Its `decision` was read as context only. It carries no `evidence_map`, so F3 to F5 are graded here, not by the underwriter.

Searches sent: "Quartzline values" (refused); "Quartzline partner API platform strategy news" (refused). No page was fetched.

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | The search was refused. It would have themed questions in Bank C by published values. Nothing moved |
| 2. `Quartzline interview process product manager` | skipped | Your own words fix the loop: one 45-minute hiring-manager conversation, which sets the persona weights |
| 3. `Quartzline strategy` / recent news | unavailable | The search was refused. It would have grounded one CO or CASE question; B1 to B5 and C2 are labelled generic instead |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative Product Manager, Platform APIs JD | skipped | The dossier's `role_profile` supplies the requirement lines the snapshot and the JD questions rest on |

## Upgrade menu

- Permission to search the web, or Quartzline's values page, strategy notes or developer docs pasted in → a CO question grounded in what it is doing now, values-themed prompts in Bank C, and C2 and B1 to B5 moving from `[generic]` toward `[grounded]`. A deeper pass would add up to 6 more searches and 2 more fetches and take several more minutes
- The interviewer's name or profile → an interviewer read, reweighted personas and a reverse question tied to their own path
- The recruiter's guidance on focus areas or any pre-declared exercise → coverage of anything the loop grades beyond these banks
- The agenda, notes or deck from one roadmap-input session → F1, F5 and D3 move from medium toward high, because it is the inspectable artifact a product-side claim keeps
- Your own answers to the slots in F1, F3, F4, F5 and F6 → those rows regenerate from your words, and A4, A5, B4 and E1 sharpen with them
- The raw CV behind the confirmed claims → more of your own sentences to quote, so more rows can be story-mapped
