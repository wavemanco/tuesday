# Interview pack — Engineering Manager, Larkfield Systems (loop of three rounds)

Candidate: Yusuf. Mode: loop — one shared fit snapshot, then a mini-pack per round.

| Round | Who | Length | Relationship |
|---|---|---|---|
| Tuesday | Director of Engineering | 45 min | Hiring manager, would-be boss |
| The Thursday after | Two staff engineers and a product manager | 60 min | Panel, names unknown |
| The following Monday | VP Engineering | 30 min | Skip-level; recruiter's description: "values and leadership philosophy" |

Built on: the role description and background as you gave them, in your message. No interviewer names, no recruiter notes beyond the Monday description, no full JD text, and no company research (see Sources).

Highest-ROI prep in the loop: A1 then A2 (Tuesday). The step from a team of six to two squads, eleven engineers and a hardware partner is the objection every round can reach, and A1 and A2 rehearse it until it is boring. Rounds 2 and 3 reuse the same two concessions.

## How to use this pack

- Personas describe how a question is asked. Types describe what is scored.
- Type key: VAL is behavior against values or leadership. EXP is a deep-dive on what you actually did. JD is the stated role requirements. CO is company and strategy knowledge. CASE is a live problem.
- Guidance is scaffolding, not a script. Where a cell says "Answer slot", the words have to be yours: either branch is a fine answer, and saying a practice was not yours is a complete answer.
- Provenance column: the label, then the exact sentences from your message that the guidance rests on.

## Prep triage

| When | Do, in this order | Tied to |
|---|---|---|
| Before Tuesday | Say A1 then A2 aloud until the concession is boring. Write your own answers to the number slots in C1 and C2. Run B1 to B3 once each, thinking aloud | A1, A2, C1, C2, B1 to B3 |
| Before Thursday | Settle who did what in the reliability quarter (E4, F1, F2). Run G2 and H1 once | E4, F1, F2, G2, H1 |
| Before Monday | Re-read the prohibited list. Run J1 to J3 and L1 aloud. Send me what you learn on Tuesday about how the squads are led, and I will regenerate Monday | J1, J2, J3, L1, section Prohibited claims |

Everything else is insurance.

## Fit snapshot (shared by all three rounds)

The JD column quotes the role description you gave me. The evidence column holds only your own words. The JD you gave carries no pay, location, schedule, travel or credential terms, so there are no gate rows.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads" — JD as you gave it | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message | medium | [grounded] | transferability | Your material says a team lead of six, not two squads, and the words stay there: "Three years as a team lead of six." Answer slot: the step from one team to two squads and eleven engineers is the likeliest probe. If any part of that step is one you have already taken, say which and what your part was; if none is, say so plainly and stay with the team of six |
| F2 | "building device-management services" — JD as you gave it | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message | low | [grounded] | discovery | Your material does not show whether any of your work touched devices. Answer slot: if a service you worked on dealt with devices in the field, say which and what your part was; if none did, say so plainly and say how you would get up to speed, as a plan |
| F3 | "own delivery" — JD as you gave it | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | The sentence carries a reliability quarter and an on-call result that came after it, not delivery for a larger group. Words stay in the sentence's order and at its scope. Answer slot: the JD's own-delivery line makes a probe on how delivery was tracked and committed likely. If any of that was yours, say how in your own words; if it was not yours, or there was no such step, say so plainly and stay with the quarter. A self-reported figure with nothing inspected behind it, so expect a probe on the 60% |
| F4 | "hiring" — JD as you gave it | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it, so expect a probe on the figure. Lead with the loop in the quote's own terms: you run it, for backend roles, about 40 interviews last year. The number raises these slots: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours |
| F5 | "growth for 11 engineers" — JD as you gave it | none given | none | [grounded] | discovery | Your material says nothing on developing engineers. Answer slot: if you have helped an engineer grow, say who and what you did, in your own words; if you have not, say so plainly and say how you would start, as a plan |
| F6 | "partner with hardware and product on roadmap", the hardware side — JD as you gave it | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | A gap wording cannot close, and you said so. Words: "I haven't owned a hardware-adjacent roadmap." Then what you would ask hardware first, said as a plan and never as a past. The same sentence says you have not managed managers; your role description does not say whether the squads have leads, so Tuesday's first reverse question decides whether that matters. Nothing added to make either feel smaller |
| F7 | "partner with hardware and product on roadmap", the product side — JD as you gave it | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | The sentence says roadmap pressure and not who it came from, so the words stay: "I pushed a reliability quarter through against roadmap pressure." Answer slot: the JD line makes a probe on the product side likely. If you made the case to anyone for the quarter, say to whom and what happened; if the pressure did not come from product, or you made no case, say so plainly and stay with the quarter |

### Requirement coverage

| JD requirement | Question IDs | Note |
|---|---|---|
| "Lead two squads" | A1, B1, B3, H1, K2 | |
| "building device-management services" | B1, F3, K1 | All three are CASE: your material does not show device work, so none asks about your past |
| "own delivery" | B3, C3, H1, K2 | |
| "hiring" | C1, H2, J1 | |
| "growth for 11 engineers" | D2, J1 | One question each for a one-line requirement; J1 covers it only if your philosophy answer reaches it |
| Hardware roadmap partnership | A2, B2, F3, J3 | |
| Product roadmap partnership | B2, B3, G2, K2 | |

## Persona weights — how they were set

Each round starts from the relationship prior in the persona model, adjusted by what you told me about the round. No interviewer names or profiles exist, so there is no per-person adjustment. Your own description of the three sessions is the only loop source; persona weights rest on it and on relationship priors.

# Round 1 — Tuesday, Director of Engineering (hiring manager, 45 min)

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Derisking the step from a team of six to two squads, eleven engineers and a hardware partner | High. Prior for a hiring manager is Case/Strategist plus Skeptic; F1 and F6 are the gaps a would-be boss prices first | Rehearse A1 then A2 until boring. Hold what the F1 and F3 quotes carry, concede F6 plainly, then give a plan and never a past |
| Case/Strategist | Live problems from the role: first thirty days, the hardware and product seam, an oversubscribed roadmap | Medium-high. Same prior; the role description is a list of things to plan | Clarify, objective, approach, metrics, risks. Think aloud and challenge one premise respectfully |
| Data-Driven Prober | The two figures in your message | Medium. F3 and F4 each carry a figure, and a close reader of your material asks how each was counted | Use the four number slots in F4's bridge; say plainly where you do not know |
| Conversational | The opening "walk me through" and a growth question | Low-medium. No signal either way; kept so the opener is never met cold | A 90-second arc built only from the F1 sentence; treat casual questions as scored |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "I see a team lead of six at a payments company. This is two squads, eleven engineers and a hardware partner. Which part of that step worries you most?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." "I've never managed managers and never owned a hardware-adjacent roadmap." | The highest-ROI rehearsal in the pack. Hold only what the first quote carries: three years as a team lead of six. Concede in the same breath what your material does not show: "I haven't owned a hardware-adjacent roadmap." Then say what you would ask first, as a plan and not a past. If the squads have leads, "I haven't managed managers" is the second plain acknowledgment, said only if that is where the question goes. Answer slot: if one part of the step worries you more than the others, say which and why; if none does, say so plainly and say what you would check first. Hold through two follow-ups by returning to the quote and the plan, never by adding to the quote | F1 and F6 are the gaps a boss derisks first, so this arrives in some form. JD because it scores the requirement itself |
| A2 | "You've never owned a hardware-adjacent roadmap. Why should I believe you can partner with hardware?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Words: "I haven't owned a hardware-adjacent roadmap." Then the adjacent sentence at its scope: you pushed a reliability quarter through against roadmap pressure. The sentence names roadmap pressure and not hardware, so do not connect them for the interviewer; let them ask. Then what you would ask hardware first, as a plan. Answer slot: if you have worked alongside a hardware team in any capacity, say how and what your part was; if you have not, say so plainly and stay with the plan. Hold through two follow-ups by returning to the acknowledgment and the plan | Second level of the A1 objection, pressing on F6. JD because the hardware partnership line is the requirement being scored |
| A3 | "Why leave a payments company for industrial IoT?" | EXP | [generic] | A selection scaffold, not a story. Build it from your real reason: one specific pull toward this work and one thing your current seat does not give you, in your own words. If no reason sharper than a change of scene comes to mind, say so plainly and say what you want to learn | Motivation consistency is the Skeptic's staple, and the pack holds no sentence of yours on it. EXP because it tests whether your story survives cross-examination |
| A4 | "If this wasn't working at six months, what would the most likely reason be?" | JD | [generic] | Pick the real risk from the limits this pack already names — the step in scale (F1), the hardware seam (F6), developing engineers (F5) — and say what you would do about it in your first ninety days, as a plan. Do not invent a past failure to sound candid. If no risk beyond those comes to mind, say so plainly | A boss testing honest self-assessment; tied to the three weakest rows rather than a generic weakness |
| B1 | "You inherit two squads building device-management services. What do you need to know in your first thirty days, and what do you do first?" | CASE | [generic] | Clarify before structuring: how each squad is led today, what each ships, where hardware dependencies sit, what the current delivery and reliability state is. Then objective, approach, metrics, risks. Think aloud. Challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | A live problem on the role's actual scope (F1, F2). Case/Strategist persona; CASE because it scores structure and not the right answer |
| B2 | "Hardware wants a change in the next release that product says will slow its own priorities. You sit between them. Walk me through it." | CASE | [generic] "I've never managed managers and never owned a hardware-adjacent roadmap." | Restate each side's interest, ask what each constraint is, propose principles for deciding and say who decides. If asked whether you have been here before, the words are "I haven't owned a hardware-adjacent roadmap", then back to the principles. The hypothetical is the interviewer's | The seam from F6 and F7 asked as a decision rather than a history; stems from the Case persona |
| B3 | "Two squads, eleven engineers, a quarter's roadmap that is oversubscribed. How do you decide what slips?" | CASE | [generic] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Clarify capacity and commitments, then criteria, then how you tell the people affected. If you reach for your reliability quarter as the example, tell it at its sentence's scope: you pushed it through against roadmap pressure, and the on-call burden dropped 60% after. Answer slot: if you set the criteria for what slipped, say what they were; if the call was made elsewhere, or there was no such step, say so plainly and describe your part | F3 and F7 together; the JD's own-delivery line makes a prioritization case likely. CASE with JD content |
| C1 | "You said about forty interviews last year. How was that counted, and how much of the loop was yours?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Lead with the quote's own terms: you run the loop for backend roles, about forty interviews last year. Then the four number slots, in your own words: how the forty was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. Never turn interviews into hires | F4 is a self-reported figure; a headline number gets a defend-the-number question. EXP because it tests attribution |
| C2 | "Tell me about the 60% drop in on-call burden. How was that measured?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Say it in the sentence's order: the burden dropped after you pushed the quarter through. Do not upgrade "after" into "because". Answer slot: how the 60% was counted, what it is sensitive to, the assumption you would defend least, and which part was yours, in your own words; if you do not know how it was counted, say so plainly | F3's figure is the likeliest probe. EXP because it tests attribution under a number |
| C3 | "Tell me about a time delivery went off track on a team you led." | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | An open prompt, so the instance is yours. Pick one with a named stake, what you did and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries — the reliability quarter, at its sentence's scope — or how you would handle it | The JD's own-delivery line raises it (F3). Provenance carries the nearest sentence because the guidance may fall back on it |
| D1 | "So — walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | A 90-second arc with the beats the sentence states: nine years in engineering, three of them as a team lead of six, now at a payments company. Answer slot: what moved you toward management, in your own words; the pack supplies none | The opener is scored. EXP because it checks the CV line holds up in speech |
| D2 | "Tell me about an engineer you've helped grow." | JD | [grounded] | An open prompt, so the instance is yours. Pick someone and say what you did and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would approach it | The JD's growth line (F5) is the only requirement with no evidence, so the question is rehearsed with a scaffold and nothing invented |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "How are the two squads led today, and where would you expect me to spend my first month?" | Settles whether managing leads is in scope, which decides how Monday's J3 is handled |
| 2 | "Who owns the seam between hardware and software on the roadmap today?" | Shows you are thinking about the exact partnership you have not owned (F6) |
| 3 | "What would make you say in six months that this hire worked?" | Gives you the scoring sheet and lets you check it against F1 to F7 |
| 4 | "Is this a new seat or a backfill, and what did that teach you about the role?" | Surfaces what the role actually needs without asking for a verdict on you |
| 5 | "How do you want to hear about problems from me, and how often?" | Treats the interviewer as your future boss rather than a gate |

# Round 2 — The Thursday after, panel: two staff engineers and a product manager (60 min)

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Seam-splitting between manager and staff engineers, disagreement style, credit-sharing | High. The panel blends each member's relationship prior; for staff engineers the prior is Peer Evaluator plus Prober | Reciprocity: what you bring their work. Propose seam principles instead of pretending to know the seam. Credit: "we" for context, "I" for contribution |
| Data-Driven Prober | Technical depth on the reliability quarter and its number | Medium. Same panel prior, and F3 holds the only figure that touches reliability | Use C2's number slots; say plainly what you do not know |
| Values/Behavioral | Scenario and behavioral questions from the product manager | Medium. A cross-functional interviewer's prior is Values/Behavioral plus Conversational | Pick stories only where one of your quotes carries one; honest branch where not |
| Case/Strategist | One or two live problems on collaboration | Low-medium. Present in every manager loop; kept at two so it does not crowd the other styles | Same structure as Tuesday's B-bank |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you disagreed with a senior engineer about technical direction." | VAL | [generic] | An open prompt. Pick an instance with a named stake, a position you held, and a relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Disagreement with equals is the Peer Evaluator's core probe; nothing in your quotes carries this story |
| E2 | "Where is the seam between what an engineering manager decides and what staff engineers decide?" | CASE | [generic] | Offer seam principles and not a claimed map: who owns people and delivery, who owns technical direction, and what you would do when the two collide. Ask how it works today. The question needs no claim about your past | Seam-splitting is the Peer Evaluator's signature; principles are honest where you do not know their seam |
| E3 | "What do you need from me in your first month, and what can I expect from you?" | JD | [generic] | Reciprocity first: what you bring their work, then what you need. Keep the ask small and specific to what you have learned about the squads by then | Peers price what the hire adds to their own load; the reciprocity move answers it |
| E4 | "You pushed a reliability quarter through against roadmap pressure. How much of that was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Say what the sentence says: you pushed it through. Answer slot: which parts were yours and which were other people's, in your own words; if others carried the work, say so plainly. "We" for context, "I" for what you did. Do not claim the 60% as yours alone: the sentence says the burden dropped after | Credit and attribution probes arrive collegially from peers (F3, F7). EXP because it scores attribution honesty |
| F1 | "What did that reliability quarter actually cover?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Answer slot: say what it covered, in your own words; the pack supplies no contents. If you do not remember a detail, say so plainly and give the part you do | A technical audience asks for the contents behind a headline. The sentence names the quarter, not what was in it |
| F2 | "What made you push for that reliability quarter?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Answer slot: say what made you push, in your own words, and what the roadmap pressure was. If it was not your initiative, or there was no single reason, say so plainly and describe your part | The "against roadmap pressure" half of F3 and F7 is the story an engineer wants the reasoning for |
| F3 | "A device-management service pushes a configuration to ten thousand devices and some never report back. What do you ask first?" | CASE | [generic] | Clarify the blast radius, rollback and visibility before touching the fix; name what you would want from the squad and what you would hold back. A hypothetical on the role's domain; it asks about no past, so the guidance makes none | F2 shows no device work in your material; this tests how you reason where you have no history, which is the honest test. CASE because it scores structure |
| G1 | "Tell me about a decision of yours that a teammate disagreed with." | VAL | [generic] | An open prompt. Pick an instance where you held your position and the relationship survived. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | A behavioral prompt from a cross-functional interviewer; none of your quotes carries a decision a teammate disputed |
| G2 | "Tell me about a time engineering priorities and the product roadmap pulled apart." | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-map on the sentence's beats only: a reliability quarter, pushed through, against roadmap pressure, the burden dropping after. Answer slot: who the pressure came from and what you did about it, in your own words; if it did not come from product, or you made no case to anyone, say so plainly and stay with the quarter | The JD's product partnership line raises it (F7), and the product manager on the panel is the person to hear it |
| G3 | "What can a product manager count on you for?" | VAL | [generic] | State two or three working principles in the first person about how you will work with product. They are commitments about the future, not claims about your past, so nothing here rests on a story | A cross-functional interviewer scores how you will behave; principles are honest here |
| H1 | "A customer escalation lands mid-quarter and takes a squad's capacity. How do you handle the squad, the PM and your director?" | CASE | [generic] | Triage first, then who needs to hear what and when, then what slips and how you say it. Think aloud. The question needs no claim about your past | A manager-specific live problem that touches F1, F3 and F7; Case persona |
| H2 | "A staff engineer tells you your hiring bar is too low for the squad. What do you do?" | CASE | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Ask what they have seen before defending anything. If you draw on the loop, lead with the quote: you run it, for backend roles. Answer slot: if you have changed a loop after feedback, say what; if you have not, say so plainly and describe how you would decide | The JD's hiring line (F4) combined with the peer relationship; CASE delivery |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What could a new manager do in the first month that would genuinely help your work?" | Reciprocity; turns an examination into a working conversation |
| 2 | "Where does the process between engineering, hardware and product get stuck?" | Targets the seam you have not owned (F6) and shows you are listening for it |
| 3 | "What do you want more of from your engineering manager, and less of?" | Gives you the staff engineers' scoring sheet |
| 4 | "How do you want to learn about engineering trade-offs before they reach a roadmap meeting?" | Directed at the PM; shows the product partnership (F7) is a two-way habit |
| 5 | "What technical decision do the squads revisit more than they would like?" | Invites the staff engineers to explain the real work and lets you ask follow-ups |

# Round 3 — The following Monday, VP Engineering (30 min)

The recruiter described this round as "values and leadership philosophy", which your message relayed. That is a loop source naming a values-style round. Larkfield's published values are not in hand (see Sources), so there is no values cheat sheet; the VAL questions draw on the recruiter's words and the standard behavioral prompts, and the upgrade menu says what the values page would add.

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario probes on how you lead; a leadership philosophy question | High. The recruiter named values and leadership philosophy; the prior for a skip-level is Case/Strategist plus Pressure, adjusted up for the stated focus | Pick stories only where one of your quotes carries one; use the honest branch elsewhere |
| Case/Strategist | Where engineering should invest; reliability against features | Medium. Skip-level prior; a VP scores altitude | Structure aloud; no claims about Larkfield's strategy, which the pack does not have |
| Pressure | Time-boxed "why you" and a hard question on your leadership | Medium. Skip-level prior | Pause, restate, hold two follow-ups, concede specifically |
| Conversational | A closing motivation question | Low. Thirty minutes leaves little room | One real reason, in your own words |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "What's your leadership philosophy?" | VAL | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." "I run our hiring loop for backend roles — about 40 interviews last year." | State two or three principles in the first person, each with one instance from your own material. If a principle's story is one of the two quotes, tell it at the sentence's scope: three years as a team lead of six, or the hiring loop for backend roles. If a principle has no story, say so plainly and give the nearest thing your material carries. Do not tell the VP what your work proves | The recruiter's own words raise it. VAL because it scores whether behavior shows the stated principles |
| J2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | An open prompt. If the reliability quarter is your story, its beats are the sentence's: pushed through, against roadmap pressure, the burden dropping after. Answer slot: if you told someone senior something they did not want to hear, say who and how it landed; if it was not that, say so plainly and stay with the quarter. Pick one story for this and G2, and know both angles | A standard values prompt; F3 and F7 are the only quote touching pressure from above |
| J3 | "How do you think about the jump from leading engineers to leading managers?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Principles first: what changes when you lead through other leaders. If asked directly, the words are "I haven't managed managers." Then what you would want to learn. Your role description does not say whether the squads have leads; Tuesday's first reverse question settles that and I will regenerate this row from the answer | Raises the managers half of F6 at the altitude where it matters; no claim about your past beyond the stated negative |
| J4 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | An open prompt. Pick an instance with a named stake, what you decided and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | A standard values prompt; none of your quotes carries a customer story |
| K1 | "Where should engineering invest in the next two years in a device-management business, and what would you stop doing?" | CASE | [generic] | State the structure aloud: who the customers are, what the platform has to be true, where reliability and features trade off, what you would retire. Make no claim about Larkfield's own strategy, which this pack has not researched. Ask the VP one question before you answer | Altitude question; CASE because no company research was available, so it is a role-family problem and not a company-strategy one |
| K2 | "How do you balance reliability work against feature delivery when the business is asking for features?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Principles first, then the sentence's own story at its scope. Answer slot: what the business was asking for and what you traded, in your own words; if you did not make that trade, or there was no such ask, say so plainly and stay with the quarter | The JD's own-delivery line (F3) in the VP's register |
| L1 | "Sixty seconds: why you?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." "I run our hiring loop for backend roles — about 40 interviews last year." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." "I've never managed managers and never owned a hardware-adjacent roadmap." | Hold three things at their own scope: three years as a team lead of six; the hiring loop for backend roles; the reliability quarter pushed through against roadmap pressure. Concede one thing specifically: "I haven't owned a hardware-adjacent roadmap." Do not compare yourself with other candidates. Hold through two interruptions by returning to the quotes | A Pressure-persona time-box built from the quotes you have; the concession is the F6 negative you stated |
| L2 | "If I asked your current team what they would change about how you lead, what would they say?" | VAL | [generic] | Answer slot: if you have asked your team, say what they told you; if you have not, say so plainly and say what you would ask them. Do not guess their answer | Tests self-awareness; your material holds no sentence on team feedback |
| M1 | "What draws you to engineering management at this point in your career?" | EXP | [generic] | One real reason, in your own words, with one thing it has to be true of the role. If no reason sharper than progression comes to mind, say so plainly | A closing motivation probe; nothing in your quotes states why |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What do you want engineering managers here to be known for?" | Tells you the VP's own bar in their own words |
| 2 | "How do you think about the path from managing engineers to managing managers here?" | Raises F6's manager half yourself and gets the answer from the person who sets the path |
| 3 | "What does engineering have to be true of in two years for the business to succeed?" | Strategy-level, and makes up for the company research this pack could not run |
| 4 | "Which decision would you rather your managers escalate, and which would you rather they not?" | Reads the VP's delegation line |
| 5 | "What does growth look like for a manager here after eighteen months?" | Shows you are thinking past the first role |

## Prohibited claims

What this pack will not coach, and why. The banks above were written against this list.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | Negative you stated, F6 | "I haven't managed managers." Nothing added |
| Has owned a hardware-adjacent roadmap | Negative you stated, F6 | "I haven't owned a hardware-adjacent roadmap." Then a plan, never a past |
| Led two squads or eleven engineers | Inflated form of F1 | F1's quote at its own scope: three years as a team lead of six. The limit is the pack's observation: your material says the team of six, not two squads |
| Cut on-call burden by 60% through your own work | Inflated form of F3 | F3's quote in its own order: the burden dropped after you pushed the quarter through. The sentence does not say because, and does not say alone |
| Hired about forty people, or built the hiring process | Inflated form of F4 | F4's quote at its own scope: you run the loop, about forty interviews last year. Interviews are not hires |

## Sources

Provided: your message (role description, the three rounds and their relationships, your background, the recruiter's description of Monday's round). No dossier was present. No document came from outside your message.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

Searches sent, all refused:

- "Larkfield Systems industrial IoT company values" — refused
- "Larkfield Systems interview process engineering manager" — refused
- "Larkfield Systems industrial IoT device management strategy news" — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | unavailable | One call, refused. Would have fed a values cheat sheet for Monday and named values for the VAL questions; none is in the pack, and the upgrade menu offers it |
| 2. Interview process | unavailable | One call, refused. The loop here rests on your own description of three sessions, which establishes who runs each; it would have added what the company publishes about them |
| 3. Strategy and recent news | unavailable | One call, refused. Would have fed a company-strategy CO question; K1 is a role-family CASE question instead |
| 4. Interviewer public footprint | n/a | No interviewer name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative JD | skipped | The role description you gave fixes the fit snapshot's requirements, the only ones this pack quotes |

## Upgrade menu

- Search permission, or the company's published values page pasted in: a values cheat sheet for Monday, mapped to your quotes or to selection scaffolds, and company-specific CO questions replacing K1. A deeper research pass, up to 6 more searches and 2 more fetches and several more minutes, is available if you want it
- Interviewer names for any round: an interviewer read, persona weights per person, and a reverse question tied to their own path
- The recruiter's notes for each round, especially the panel format and whether any case, presentation or take-home is expected: any pre-declared deliverable gets its own build section
- The full JD text: the quoted requirements sharpen, and any pay, location, travel or schedule term becomes a gate row
- Your own answers to the answer slots in F1, F2, F3, F5, F6 and F7: each enters the fit snapshot verbatim and the rows and banks that draw on it regenerate
- What you learn on Tuesday about how the two squads are led: Monday's J3 and the F6 handling regenerate from it
- The on-call report or pager export showing before and after the reliability quarter, and the interview scorecard or loop document for your hiring loop: either would lift F3 or F4 from medium to high, because each is something an interviewer could inspect
- A tuesday-dossier.md from earlier prep, if you have one: its verified evidence and prohibited claims would replace the locally built list here
