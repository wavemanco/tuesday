# Operations Manager, Atlas Freight: interview prep pack

Interviewer: not known. Round: assumed to be a hiring-manager conversation, because nothing said otherwise. Persona weights below are priors, not a read of your loop.

## How to use this pack

- Personas describe how a question is asked. Types describe what is being scored.
- Type key: VAL (alignment with the company's published values; no rows here, because no published values were read), EXP (does your experience survive scrutiny), JD (can you do the listed job, gaps included), CO (company and strategy knowledge; no rows here, because research was unavailable), CASE (a live problem from the role).
- Guidance is scaffolding, not a script. Every sentence about your past comes from something you wrote, quoted next to it. Where your material is silent, the guidance is an answer slot: an instruction for the interview with two honest branches, and the second branch always allows that the thing never happened or was not yours.
- The highest-ROI rehearsal in this pack is B1, the step from three supervisors to twelve across four sites. Rehearse it until it is boring.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material says warehouse and distribution ops and a shift manager's remit, with nothing inspected behind it and nothing about more than one site. The words stay there: "I've spent 7 years in warehouse and distribution ops." Answer slot: the JD says 4 sites, so expect a probe on working across more than one. If you have, say how, in your own words; if you have not, say so plainly and stay with the work you do run |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message; "ran the site's peak-season surge plan two years running" — your message | low | [grounded] | discovery | Your material says a mis-pick cut and a surge plan, and shows neither on-time nor cost results. Answer slot: the JD names both measures, so expect a probe on either. If you tracked one, say which and what it showed; if neither was tracked, or neither was yours, say so plainly and return to the mis-pick cut as you wrote it |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | The quote is three supervisors and the JD is twelve, so the words stay at three: "Today I'm a senior shift manager over 3 supervisors." Answer slot: expect a probe on the step to twelve. If any part of how you supervise carries to a bigger team, say which part and why; if you have not had more than three, say so plainly and say how you would learn the extra ground |
| F4 | "build reporting in Excel/Power BI" — JD (Excel half) | "solid Excel" — your message | low | [grounded] | discovery | "Solid" is a self-assessment with nothing inspected behind it, and it does not say what was built. Words: "My Excel is solid." Answer slot: the JD says build reporting, so expect a probe on what you produced. If you have built reports, say what, in your own words; if you used Excel for other work, say so plainly |
| F5 | "build reporting in Excel/Power BI" — JD (Power BI half) | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used Power BI." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message | low | [grounded] | discovery | A years requirement is a risk to name, not a gate. Your material says seven years in the field and does not say how many were in a leading role. Answer slot: if you held roles leading others, say which years and what each covered, in your own words; if few of the seven were, say so plainly and stay with the roles you did hold |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | The quote already reaches the requirement, but a certification line with nothing inspected behind it draws a probe on use. Words: "I'm green belt certified." Answer slot: if the pick-path redesign used the belt's methods, say which; if it did not, or the belt is separate from it, say so plainly |

No row is a hard gate: the JD states no authorization, location, schedule or pay term. If one exists in the posting, add it and the snapshot gains a row.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A Case/Strategist | Live operating problems: a slipping site, a cost spike, a peak squeeze | High. Hiring-manager prior; the JD is operational and names two measures | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully per case |
| B Skeptic | Quiet, persistent probing of the span, the sites, Power BI and the leadership years | High. Hiring-manager prior; F1, F3, F5 and F6 are the widest gaps between the JD and your material | Hold the quoted scope, concede the step specifically, give a plan. For F3: "currently a senior shift manager over 3 supervisors" is the held position, never more |
| C Data-Driven Prober | Line-by-line questions on the 40% and on the two JD measures | Medium. You have one headline figure and the JD names two metrics | Know what you can and cannot say about how the figure was counted, and say plainly when you do not know |
| D Conversational | Opener, motivation, "what are you playing with in Excel these days" | Medium. Every round has an opening; these are scored though they feel casual | A 90-second arc built only from your own sentences |
| E Pressure | Time-boxed challenges: "sixty seconds, why you" | Low. Nothing signals a stress style; the 3-to-12 gap is where one would land | Pause, restate, hold through two follow-ups, concede only what is true |
| F Peer Evaluator | Seam questions between sites and with other functions | Low. No sign a peer is in this loop, but four sites imply lateral conflict | Propose principles for the seam rather than pretending to know it |
| G Values/Behavioral | Open prompts on unpopular truths and customers versus metrics | Low. No loop source was read, and no published values were read | Pick a real story; where none comes to mind, say so |

Weighting: relationship priors for a hiring manager, adjusted up for Prober because of the 40% figure. No interviewer signals exist. No loop source was read, so the loop falls back to the generic archetype (screen, hiring manager, panel) with flat weights, and these weights rest on a pattern rather than on Atlas Freight's documented process. Knowing the round type would sharpen every bank.

## Question banks

### A. Case/Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "On-time performance is slipping at one of your four sites. Walk me through your first two weeks." | CASE | [generic] | Clarify first: how on-time is defined and whether it is the same at every site, what changed, and when it started. Then split the problem by the stages a shipment passes through, pick the one or two stages that explain most of the miss, name the metric for each, and say what would change your mind. Challenge one premise respectfully, for example whether the definition is consistent across sites. It makes no claim about your past, so the guidance makes none | F2 is where the JD's first measure is least evidenced, so a live problem on it is likely. CASE because it scores structure, not history |
| A2 | "Cost per shipment is up at all four sites. What do you look at first, and how do you decide what to change?" | CASE | [generic] | Start by asking how the number is built: what sits in it and what it is divided by. Then separate what moved from what was always high, rank causes by size and by how fast you can act, and name the assumption in your reasoning you would defend least before they do. Say what you would not change yet, and why | F2's second measure has no result in the evidence, so the interviewer will test the reasoning instead. CASE for the same reason as A1 |
| A3 | "Peak season starts in six weeks and two of your four sites are short of people. How do you plan it?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Structure it: what demand you expect and how sure you are, where the shortage bites, options in order of cost and speed, a trigger for escalating, and what you report weekly. You may anchor with one sentence at its own scope: "I ran the site's peak-season surge plan two years running." Stop there unless asked, then answer only what you can back | F1 and F2 make a multi-site surge a natural probe, and F2 holds the quote this anchors on. CASE because it is a decision, with the quote as a one-line anchor |
| A4 | "You inherit twelve supervisors across four sites, none of whom you've worked with. What do you do in your first thirty days?" | CASE | [grounded] "currently a senior shift manager over 3 supervisors" | A plan, not a past: listen before changing anything, meet each supervisor one to one, find what each site does differently and why, decide the two or three things you will not change in month one, and agree what you will report on. Be plain about scale: "Today I'm a senior shift manager over 3 supervisors," so the first thirty days are partly about learning to run a bigger team | F3 is the widest numeric gap, so the interviewer will test how you would close it. CASE because it asks what you would do |
| A5 | "Design the weekly operations report you would want in front of you. What is in it?" | JD | [grounded] "solid Excel" | Choose five or six measures and define each in one line: what counts, over what period, and who acts on it. Say what you would put on the first page and what you would keep off it. On tools: "My Excel is solid"; you would start there and build what you need. Do not describe a report you have not built | F4 and F5 together make this the JD's reporting line in practice. JD because it scores a stated requirement, with CASE delivery |

### B. Skeptic (high weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You're over three supervisors today. This role is twelve, across four sites. What changes?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI rehearsal in this pack. Hold only what the quote carries: "Today I'm a senior shift manager over 3 supervisors." Then concede the step specifically, in your own words: twelve across four sites is a bigger span than you have now. Follow-up 1, what scales: answer slot: if any part of how you supervise carries to twelve, say which part and why; if none you can point to, say so plainly and say how you would find out. Follow-up 2, what you would not do early: a plan, not a claim. Follow-up 3, how do you know you can: return to the quote and the plan, never to a promise. Hold through all three by returning to the quote, never by adding to it | F3 is the widest gap between the JD and the evidence, so this objection arrives in some form. JD because it scores a stated requirement; the Skeptic delivery is the rehearsal |
| B2 | "This role covers four sites. What have you run across more than one site?" | JD | [grounded] "7 years in warehouse and distribution ops" | Answer slot: the JD raises four sites. If you have worked across more than one, say how and what part was yours, in your own words; if you have not, or what you ran sat at one site, say so plainly and return to "7 years in warehouse and distribution ops" and how you would get across four. The honest branch is a limit, not a confession | F1 is where the multi-site mandate presses hardest. JD because it scores the stated requirement |
| B3 | "We want five-plus years of operations leadership. How much of your seven years was leading people?" | JD | [grounded] "7 years in warehouse and distribution ops" | Answer slot: say which years you held a role leading others and what each covered, in your own words; if only part of the seven was, say so plainly and stay with the roles you did hold. Do not round the answer up to meet the requirement | F6 is silent on how many years were in a leading role, and a literal screen on the number is likely. JD because it scores a stated requirement |
| B4 | "You've never used Power BI, and this role builds reporting in it. Convince me." | JD | [grounded] "never used Power BI" and "solid Excel" | Say it first and plainly: "I've never used Power BI. My Excel is solid." Then a plan in your own words: the first thing you would build in it, and by when. Never say you have started learning it unless you have. Hold through two follow-ups by returning to the plan, never to a claim of exposure | F5 is a stated gap and the interviewer will test whether you bluff. JD because it scores a named tool |
| B5 | "Lean and Six Sigma are a plus here. How have you used your green belt?" | JD | [grounded] "green belt certified" | Start with the quote: "I'm green belt certified." Answer slot: if you applied it to a real problem, say which and what you used, in your own words; if the pick-path redesign used the belt's methods, say so; if the belt is a certification not yet applied, or separate from that work, say so plainly | F7 closes the requirement on paper, so the probe goes to use. JD because it scores a stated plus |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% mis-pick figure was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say it at its scope: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: how it was counted, in your own words; if you do not know how it was counted, say so plainly. The pack supplies no baseline, period or method, and you should not either | A headline figure is where a prober starts; F2 is the nearest row. EXP because it tests whether the claim survives |
| C2 | "Which assumption behind that 40% would you defend least?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Name it before they do. Answer slot: the assumption you would defend least, in your own words; if you have not thought about it, say so plainly and say what you would check first. Also say which part of the result was yours and which part others did | The weakest-assumption move turns a gotcha into credibility. EXP for the same reason as C1 |
| C3 | "Did that redesign move on-time or cost numbers, or only mis-picks?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: the JD names on-time performance and cost-per-shipment. If either was tracked, say which and what it showed; if only mis-picks were, or the redesign was not measured that way, say so plainly and return to the quote as written | F2 is the row this probes, and an honest "only mis-picks" scores better than a stretch. JD because the measures come from the JD |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops" and "currently a senior shift manager over 3 supervisors" and "cut mis-pick rate 40% by redesigning the pick path" and "ran the site's peak-season surge plan two years running" and "green belt certified" | A 90-second arc with only the beats those sentences state, in your own words: the seven years, where you are now, the pick-path redesign, the two surge plans, the belt. End with why this role: answer slot: give your actual reason; the pack supplies none | Every loop opens with a version of this, and it is scored. F1 to F7 are what it draws on. EXP because it is your history |
| D2 | "Why this job, and why now?" | JD | [generic] | Give your actual reason, in your own words. Keep it to one reason that is true and specific to the job in the JD: four sites, twelve supervisors, reporting. Never an answer you would not repeat under a second question | Motivation is asked in every round, and a consistent answer matters more than a clever one. JD because it is about this job |
| D3 | "What are you actually playing with in Excel or Power BI these days?" | JD | [grounded] "solid Excel" and "never used Power BI" | Answer slot: if you are building something, say what; if not at the moment, say so plainly. On Power BI the plain form is "I've never used Power BI," then what you would try first. Never claim practice you have not had | The JD's plus-skills arrive as casual questions and are still scored. F4 and F5 are the rows it probes |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That 40%: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Pause and restate. Hold the sentence as you wrote it. Answer slot: which part was yours and which was others', in your own words; if you do not know a detail, say so plainly. Hold through two follow-ups, then concede only the specific detail you cannot support, never the whole claim | Attribution probes exist to catch inflation, and F2 holds the quote it targets. EXP because it scores what was yours |
| E2 | "Sixty seconds: why you over someone who's already run twelve supervisors across several sites?" | JD | [grounded] "7 years in warehouse and distribution ops" and "cut mis-pick rate 40% by redesigning the pick path" and "green belt certified" and "currently a senior shift manager over 3 supervisors" | Hold what you have, in your own words and in that scope: the seven years, the mis-pick cut, the belt. Then concede the span: "Today I'm a senior shift manager over 3 supervisors." Do not claim you will catch up quickly; say what you would do in the first month instead | The gap behind B1 delivered under time pressure. JD because it scores fit to the stated team size |

### F. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Four sites will sometimes want the same people or equipment in the same week. How do you decide, and what happens when a colleague disagrees?" | CASE | [generic] | Propose principles rather than pretending to know the seam: a shared priority order, a way to see each site's constraint, and who has the last word. Ask what exists today. For disagreement, show spine and tact: the data you would bring and the point at which you escalate | Four sites in the JD make lateral conflict likely. CASE because it asks for a method |
| F2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Pick a real time the work crossed teams; it needs a named outcome, what you did, and what others did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem; the credit probe is typical of peer rounds. EXP because it scores what you did |

### G. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | EXP | [generic] | Pick a real time: it needs a named stake, what you said, how it landed and what you did next. Choose one where the hard truth actually landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem, and a likely behavioral prompt for a manager. EXP rather than VAL because no published values were read |
| G2 | "When did you put a customer ahead of an internal metric?" | EXP | [generic] | Pick a real time: it needs the customer's need, the metric you set aside and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem; it fits an operation scored on delivery. EXP for the same reason as G1 |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "Own daily terminal operations across 4 sites" | A1, A3, B2, F1 |
| "drive on-time performance and cost-per-shipment down" | A1, A2, C3 |
| "lead a team of 12 supervisors" | A4, B1, E2 |
| "build reporting in Excel/Power BI" | A5, B4, D3 |
| "5+ years operations leadership required" | B3, D1 |
| "Lean/Six Sigma a plus" | B5 |
| Headline figure on your background: the 40% | C1, C2, E1 |

No CO question exists, because research was unavailable and nothing was supplied on Atlas Freight's strategy.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "How do you define on-time performance here, and which of the four sites is furthest from where you want it?" | It shows you define a measure before chasing it, and the answer tells you where your first weeks go |
| 2 | "How is cost-per-shipment built here, and what moves it most?" | It mirrors the case you may be asked, and the answer shows how mature the reporting is |
| 3 | "How are the twelve supervisors spread across the four sites, and where is the bench strongest and thinnest?" | It treats the span as a plan to work out rather than a threat, which is the B1 answer in question form |
| 4 | "What reporting exists today, and what would you want built first?" | It scales the Power BI gap honestly and tells the interviewer you intend to close it |
| 5 | "What would make you say in a year that this was the right hire?" | It asks for the scoring sheet, so your first ninety days can be aimed at it |
| 6 | "What has been hardest about peak season across the sites?" | It connects to your surge-plan experience without claiming more than you wrote |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team of 12 supervisors | Inflated form of F3 | F3's quote at its own scope: "currently a senior shift manager over 3 supervisors". The limit is the pack's observation: your material says three, the JD says twelve. B1's slot stays inside what carries to a bigger team |
| Ran terminal operations | Inflated form of F1, in the JD's vocabulary | F1's quotes at their own scope: "7 years in warehouse and distribution ops". The limit is the pack's observation: your material says warehouse and distribution, not terminals |
| Cut cost per shipment or lifted on-time performance | Inflated form of the mis-pick quote | The quote at its own scope: "cut mis-pick rate 40% by redesigning the pick path". C3's slot asks only whether either number was tracked |
| Has 5+ years of operations leadership | Inflated form of F6 | "7 years in warehouse and distribution ops" at its own scope. The limit is the pack's observation: the material does not say how many years were in a leading role |
| Built reports or dashboards in Power BI | Negative you stated, F5: "never used Power BI" | The plain acknowledgment: "I've never used Power BI." No slot |
| Led Lean or Six Sigma programmes | Inflated form of F7 | "green belt certified" at its own scope. B5's slot asks only about use, in your own words |

## Sources

Provided documents: the JD text and your background summary, both pasted in your message. No CV file, interviewer profile or recruiter notes were provided. No dossier was present.

Queries sent, all refused (web search permission was not granted):

- "Atlas Freight regional logistics company values": refused
- "Atlas Freight interview process operations manager": refused
- "Atlas Freight regional logistics terminals news strategy": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Every call was refused. It would have fed a values cheat sheet and VAL questions mapped to published value names; none appear here |
| 2. Atlas Freight interview process, operations manager | unavailable | Every call was refused. It would have named the actual rounds; persona weights therefore rest on the generic archetype and say so |
| 3. Atlas Freight strategy and recent news | unavailable | Every call was refused. It would have fed CO questions and a grounding brief; the pack has neither |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative Operations Manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The round type and who you are meeting: reweights every bank, and adds a Peer or Skip-level emphasis if that is what it is
- The recruiter's prep notes or focus areas: replaces assumed coverage, and adds a build section for any declared deliverable
- The interviewer's name: adds an interviewer read, tailored persona weights and a reverse question tied to their path
- Web search permission for Atlas Freight values, loop structure and recent news: adds a values cheat sheet, CO questions and loop-based weights; a deeper pass of up to 6 more searches and 2 more fetches takes several more minutes and adds a strategy brief
- Your own words on the answer slots in F1, F2, F3, F4, F6 and F7: turns those discovery and transferability rows into grounded stories with story-mapped guidance
- The mis-pick log or the before-and-after report for the pick-path redesign: lifts F2's evidence and C1 to C3 from low or medium toward high
- The green belt certificate and the peak-season surge plan document: lift F7 and A3's anchor from medium toward high
- A tuesday-dossier.md from job-underwriter, if you have one: adds verified evidence and a prohibited-claims list from underwriting; this pack is complete without it
