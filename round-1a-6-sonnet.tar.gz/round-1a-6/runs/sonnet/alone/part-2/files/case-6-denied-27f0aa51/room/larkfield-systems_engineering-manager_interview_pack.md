# Interview pack: Engineering Manager, Larkfield Systems (three-round loop)

Candidate: Yusuf. Mode: loop, three scheduled rounds sharing one fit snapshot.

| Round | When | Who (names not given) | Length | Relationship |
|---|---|---|---|---|
| R1 | Tuesday | Director of Engineering, the hiring manager and would-be boss | 45 min | Hiring manager |
| R2 | The Thursday after | Panel: two staff engineers and a product manager | 60 min | Panel: technical peers and a cross-functional partner |
| R3 | The following Monday | VP Engineering, described by the recruiter as "values and leadership philosophy" | 30 min | Skip-level, values-style |

Built on one assumption: your evidence is the four sentences in your message and the one-sentence role description, with no CV and no full JD. Everything about the candidate quotes those sentences or is an answer slot.

## How to use this pack

Personas describe how a question arrives; types describe what is scored. Guidance is scaffolding, not a script: say it in your own words.

| Type | What it scores |
|---|---|
| EXP | Whether your own account of your past survives scrutiny |
| JD | Whether you can do the listed job, gaps included |
| CO | How well you know the company and think at its altitude |
| CASE | Structure and reasoning on a live problem from the role |
| VAL | Not used: Larkfield's published values are not in hand, so no question can be scored against them |

An answer slot is an instruction for the interview, not a question for you. Meet it with either branch: say what you did in your own words, or say plainly that it was not yours or did not exist.

## Prep triage

You have roughly two weeks and three rounds. Do these in order; the rest is insurance.

| When | Do | Why |
|---|---|---|
| Before Tuesday | Rehearse R1-B1 and R1-B2 aloud until they are boring | The step up from one team to two squads, and the two things you told me you have not done, are where a hiring manager derisks first. R1-B1 is the highest-ROI prep in this pack |
| Before Tuesday | Write out your answer to each answer slot in F1, F3, F5, F7, then send them to me | Your answers become quoted material and the rows regenerate |
| Before Tuesday | Drill R1-A2 once as a case | Live problems from the role are the hiring manager's likeliest format |
| Between Tuesday and Thursday | Rehearse R2-E1, R2-E2, R2-E3 | The same two figures return in every round; settle what each one counts before the panel asks |
| Between Tuesday and Thursday | Drill R2-D1 and R2-D4 | Staff engineers test the seam between you and them |
| Before Monday | Prepare R3-F1, R3-F2, R3-F3 as selection exercises | The VP round is short and open-ended; stories chosen in advance matter most |
| Before Monday | Rehearse R3-G1 | It is R1-B1 at VP altitude and time-boxed |

Everything else is insurance.

## Fit snapshot (shared by all three rounds)

The role description you gave is one sentence, so the requirements are its fragments.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role description in your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message; "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | medium | [grounded] | transferability | Words stay at the quote's scope: "Nine years in engineering, three of them as a team lead of six." The pack's observation: the material says one team of six and no managers under you, not two squads, and does not say whether the two squads have leads of their own. Answer slot: the role's two squads make a probe on the step up from six likely. Say the step as a plan for your first weeks, never as a past; if any of your three years went beyond your own team, say what, in your own words, and if none did, say so plainly and stay with the team of six. If asked directly: "I've never managed managers." |
| F2 | "building device-management services" — role description in your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message | low | [inferred] | discovery | The quote reaches engineering and a payments employer; it does not show device or fleet work. Answer slot: expect a probe on how your payments work compares with device management. If any of your work had something in common with it, say what, in your own words; if none did, say so plainly and stay with payments engineering and what you would learn first |
| F3 | "partner with hardware and product on roadmap" (the product half) — role description in your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | discovery | Hold the sentence as written: "I pushed a reliability quarter through against roadmap pressure." The material does not say where the pressure came from or how the quarter was agreed. Answer slot: expect a probe on who pressed and how it was agreed with product. If you can say, say it in your own words; if the pressure was not from product, or nothing was agreed with anyone, say so plainly and stay with the sentence |
| F4 | "partner with hardware and product on roadmap" (the hardware half) — role description in your message | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. Never a claim to hardware roadmap work, and nothing added to make the gap feel smaller |
| F5 | "own delivery" — role description in your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | discovery | The sentence shows a reliability quarter pushed through, not how delivery was tracked. Words: "I pushed a reliability quarter through against roadmap pressure." Answer slot: expect a probe on how you knew your team's delivery was on track. If you had a way, say what, in your own words; if there was none, or it was not yours, say so plainly and stay with the quarter. The 60% raises its own slots under R2-E1 |
| F6 | "hiring" — role description in your message | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead with the sentence in its own terms: you run the hiring loop for backend roles, and the figure is interviews. The figure raises the defend-the-number slots under R2-E3 |
| F7 | "growth for 11 engineers" — role description in your message | none given | none | [grounded] | discovery | Your material does not show growth work. Answer slot: expect a probe on how you have helped an engineer grow. If you have, say who and what, in your own words; if not, say so plainly and say what you would do first |

## Prohibited claims

Built from the snapshot before any question was written. No cell in this pack asserts, softens or implies these.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | Negative you stated, F1 | The plain acknowledgment: "I've never managed managers." No slot |
| Has owned a hardware-adjacent roadmap | Negative you stated, F4 | The plain acknowledgment: "I've never owned a hardware-adjacent roadmap." Then a learning plan, said as a plan |
| Has led two squads or a team of eleven | Inflated form of F1 | F1's quote at its own scope: three years as a team lead of six. The limit is the pack's observation, not words for you: the material says one team of six |
| Hired about 40 engineers, or made the hiring decisions | Inflated form of F6 | F6's quote at its own scope: you run the hiring loop for backend roles, and the figure is interviews. R2-E3's slot asks only what the figure counted |
| The reliability quarter caused the 60% drop, or the drop was yours alone | Inflated form of F5 | F5's quote at its own scope: the drop came after you pushed the quarter through. The material gives a sequence, not a cause or a share; R2-E2's slot asks only which part was yours |

## Round 1: Tuesday, Director of Engineering (hiring manager), 45 min

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (4 questions) | Quiet probing of the step up and of the two things you have not done | High. A hiring manager is buying capability and derisking gaps (relationship prior), and F1 and F4 hold the two negatives you stated | Rehearse the single most predictable objection until it is boring; build bridges only from F1's quote; where there is no evidence, say the limit plainly and add a plan |
| Case/Strategist (4 questions) | Live problems from the role: plan, diagnose, sequence | High. Same prior; the role description names hardware and product partnering, so expect problems set there | Clarify, then objective, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Conversational (2 questions) | Opening biography and motivation, friendly register | Medium. Every interview opens this way, and it is still scored | Prepare a 90-second arc from your own sentence |

No interviewer name was given, so there is no interviewer read and the weights rest on the relationship prior alone.

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-B1 | "You've led a team of six. This role is two squads and eleven engineers. What's the biggest step up for you?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." and "I've never managed managers and never owned a hardware-adjacent roadmap." | The highest-ROI rehearsal in this pack. Hold what the quote carries: "Nine years in engineering, three of them as a team lead of six." Name the limit before it is asked for: "I've never managed managers." Then say, as a plan and not a past, what you would learn first and from whom. Hold through two follow-ups, such as who would report to you or what you would do in your first thirty days, by returning to the plan and to the team of six, never by adding to either. Answer slot: if any of your three years went beyond your own team, say what, in your own words; if none did, say so plainly | F1 is where the role presses hardest and where the Director's own doubt is most likely to land. JD because it scores the stated requirement; the question is the Skeptic's, delivered as a plain request |
| R1-B2 | "You've never owned a hardware-adjacent roadmap. Where would you be weakest on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Hold, then concede: "I've never owned a hardware-adjacent roadmap." Then a plan, said as a plan: what you would ask the hardware side to explain first and how you would find out what slips for them. Answer slot: if you have worked alongside hardware or firmware people in any form, say how, in your own words; if you have not, say so plainly. Never imply hardware roadmap experience | F4 is a stated gap, so this arrives in some form. JD because it scores the hardware half of the partnering requirement |
| R1-B3 | "You're at a payments company today. Why device management, and why now?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Give your own reason, in your own words. The question tests whether your motive is specific to this role. If the pull is mainly the step into managing two squads rather than the industrial domain, say that; if the domain draws you, say where that comes from. If no reason specific to this role comes to mind yet, say so plainly and give the reason that is true. Answer slot: expect a probe on what you know about device management; say what you actually know, and what you would learn first | F2 shows no device-domain evidence, so motive carries weight. JD because it asks about fit with the listed work |
| R1-B4 | "You mention a reliability quarter you pushed through against roadmap pressure. Walk me through it." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped on F3 and F5: the beats the sentence states are the reliability quarter, the roadmap pressure, you pushing it through, and the 60% drop in on-call burden afterwards. Tell them in your own words. Answer slot: expect a probe on who was pressing and how the quarter was agreed. If you can say, say it; if the pressure was not from product, or it was settled another way, say so plainly and stay with the sentence. The 60% raises its own slots: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours | Your strongest line and the one most likely to be probed, since both F3 and F5 rest on it. EXP because it tests what was actually yours |
| R1-A1 | "You inherit two squads you didn't build. How do you spend your first ninety days, and what do you need to know first?" | CASE | [generic] | Clarify first: what each squad owns, how work is planned, what each is committed to, who the stakeholders are. Then objective, approach in phases, how you would know it was working, and risks. Challenge one premise, such as asking what "inherit" includes. Makes no claim about your past | The Director's own roadmap is the likeliest case. CASE; `[generic]` because it is a pattern for the problem, not a fact about Larkfield |
| R1-A2 | "A hardware release slips by two weeks and both squads' plans depend on it. What do you do first?" | CASE | [generic] | Clarify: what exactly slipped, which commitments depend on it, who has been told, what can proceed without it. Then options, communication to product and hardware, and what you would change so one slip does not stall both squads. Say aloud what you do not know about hardware dependencies. Makes no claim about your past | Tests the hardware half of F4 as a decision rather than a record. CASE; `[generic]` |
| R1-A3 | "One squad is shipping on time and the other keeps slipping. How do you work out why?" | CASE | [generic] | State hypotheses before gathering data, say what you would look at for each, and how you would avoid blaming the squad before the evidence. Close with what you would not conclude yet. Makes no claim about your past | Tests delivery ownership across two squads, the F1 and F5 requirement, in a live form. CASE; `[generic]` |
| R1-A4 | "You run your hiring loop for backend roles. What would you do differently hiring for device-management squads?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Story-mapped on F6: you run the loop for backend roles, and the figure is interviews. "Differently" is a plan: say what you would want to learn about device-management skills before changing anything, and from whom. Answer slot: expect a probe on how the loop is built. If you set its structure, say what, in your own words; if you inherited it, or it had no set structure, say so plainly and stay with the sentence | F6 is your strongest direct fit to a stated duty, so the Director will test how far it transfers. JD because it scores the hiring requirement |
| R1-C1 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | A 90-second arc with only the beats the sentence states: nine years in engineering, three as a team lead of six, now at a payments company. Then your own reason for this move, in your own words. Do not add roles, scope or outcomes the sentence does not carry | The opener of any interview and still scored; EXP because it is your own account. The arc recurs in R2 and R3, so build it once |
| R1-C2 | "What drew you to this role?" | JD | [generic] | Pick the one line of the role description that actually draws you and say why, in your own words. If none does, say so plainly and give the reason that is true. Makes no claim about your past | A rapport-register question that is scored for specific interest. JD because the answer should tie to the listed work |

### Reverse questions (R1)

| Question | Why it lands |
|---|---|
| "How are the two squads structured today: do they have leads of their own, and who would report to me directly?" | Settles the managers-of-managers question with facts instead of an assumption, and shows you have found the real shape of the job (F1) |
| "Where do hardware dependencies hurt delivery most today, and which squad feels it?" | Locates the seam you have not owned (F4) and signals you want to learn it from the person who knows it |
| "What does success look like at ninety days and at twelve months?" | Lets your boss define the scorecard you will be held to |
| "How many seats are open across the eleven, and what is the hiring plan?" | Connects to the hiring duty you can speak to (F6) |
| "Which decisions do you want to be consulted on, and which informed of?" | Clarifies the relationship with your would-be boss early |

## Round 2: The Thursday after, panel of two staff engineers and a product manager, 60 min

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator (4 questions) | Seam-splitting between a manager and staff engineers; what you would need from them; credit | High. The panel blends the top two personas of each member's relationship, and all three members are colleagues who will work beside you | Reciprocity: say what you bring them, not only what you need; propose seam principles instead of pretending to know the seam |
| Data-Driven Prober (4 questions) | Reads your lines closely and asks how the figures were counted | High. Staff engineers verify depth, and your 60% and your 40 interviews are the only numbers in your material | Know what you can and cannot say about each figure; say plainly when you do not know; name the weakest assumption before they do |
| Values/Behavioral (3 questions) | Scenario probes in a collaborative register, likely from the product manager | Medium. Cross-functional interviewers lean this way. The role description also names product partnering | Choose stories from your own sentences; where none fits, a selection scaffold with its honest branch |

The gaps from R1 return here in collegial packaging. No interviewer names were given, so no interviewer read. The Conversational opener from R1 will likely reappear as a short introduction: reuse R1-C1.

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-E1 | "You said the on-call burden dropped 60%. Walk me through how that number was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Say what the figure is of and how it was counted, only as far as you know. Name the assumption you would defend least before they do. Say what it is sensitive to. Answer slot: if you know how it was counted, say so in your own words; if you do not, say plainly that you do not, and stay with the sentence. Never supply a baseline or a method you cannot repeat under a second question | The Prober's first move on your headline number (F5). EXP; the answer is precision about your own claim |
| R2-E2 | "How much of that was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold, then concede. Hold: "I pushed a reliability quarter through against roadmap pressure." Concede only what is true: the sentence gives a sequence, not a share. Answer slot: say which part was yours, in your own words; if others did parts of it, say so plainly and stay with what you pushed through | Probes attribution on F5. EXP |
| R2-E3 | "You mention about 40 interviews last year. What does that figure count?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Say what the figure counts in the sentence's own terms: interviews. Answer slot: if you know how many people it covered, how many you ran yourself, or what the loop produced, say so in your own words; if you do not, say plainly that you do not. Never turn it into a hiring number | The only other figure in your material (F6), so it will be probed the same way as the 60%. EXP |
| R2-E4 | "How do you stay close to technical decisions without second-guessing the staff engineers?" | JD | [generic] | Offer principles, not a claim about your past: what you would want to decide, what you would leave with the engineers, and how you would ask questions rather than overrule. Say aloud where you would want their view first. Makes no claim about your past | Staff engineers want to know if a manager will help or hinder. JD because it scores the leading-a-technical-team requirement |
| R2-D1 | "Where's the seam between a manager and staff engineers on technical decisions, and what happens when we disagree?" | CASE | [generic] | Propose seam principles, such as who decides what and how a disagreement is raised, and say you would agree the specifics with them. Do not pretend to know the seam. Makes no claim about your past | The Peer Evaluator's signature question; CASE because it asks for reasoning on a live seam |
| R2-D2 | "How do you handle credit when work spans teams?" | EXP | [generic] | A selection scaffold: pick a time credit was shared across teams, with a named stake and a result the other side would recognise. If no such time comes to mind, say so plainly, then give how you would handle it | A peer stem about partnership. EXP because it probes behaviour, `[generic]` because your material carries no such story |
| R2-D3 | "What would you need from us, and what could you give us?" | CASE | [generic] | Lead with what you bring them before what you need, in your own words. Keep it to principles. Makes no claim about your past | The reciprocity probe: does the hire reduce or add to their load |
| R2-D4 | "A staff engineer wants to rewrite a service you want left alone this quarter. How do you handle it?" | CASE | [generic] | Clarify what is driving the rewrite and what leaving it alone protects; hear the engineer first; say what you would decide and what you would not. Concede that the engineer may know something you do not. Makes no claim about your past | Tests disagreement style with technical seniors; CASE |
| R2-F1 | "Tell me about a time you and a product partner disagreed about what the team should build." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Open prompt, and the nearest sentence you have is this one. Its beats are the reliability quarter, the roadmap pressure and you pushing it through. Answer slot: if the pressure came from product and there was a disagreement, say what and what part was yours; if it came from elsewhere, or there was no disagreement, say so plainly and stay with the sentence. If no such time comes to mind, say so plainly, then give how you would handle it | The role description names product partnering (F3). EXP; the sentence may or may not be this story |
| R2-F2 | "How do you work with a product partner who wants things faster than engineering can deliver?" | CASE | [generic] | Offer a way of working: what you would ask first, what you would show them, how you would trade scope for time, and when you would say no. Makes no claim about your past | Probes product partnering as a method. CASE |
| R2-F3 | "How would you help an engineer who delivers well but is quiet in design reviews?" | CASE | [generic] | Say what you would observe first, what you would ask the engineer, and what support you would offer before any expectation. Makes no claim about your past | The growth duty has no evidence yet (F7); a CASE keeps it honest. CASE |

### Reverse questions (R2)

| Question | Why it lands |
|---|---|
| "What could a new manager do in the first month that would genuinely help you?" | Reciprocity: shifts the panel from judging you to working with you |
| "Where do technical decisions get made today, and where would you want a manager to stay out?" | Shows respect for the staff engineers' seam (R2-D1) |
| "Where does the roadmap conversation between product, hardware and engineering get stuck today?" | Directed at the product manager; locates the seam from F3 and F4 |
| "What does the on-call and reliability picture look like for these services?" | Ties to your reliability sentence (F5) without claiming it applies here |
| "What is one thing the squads would want a new manager not to change?" | Signals you are not arriving to overwrite |

## Round 3: The following Monday, VP Engineering, 30 min

"Values and leadership philosophy" is the recruiter's description, as you relayed it. Larkfield's published values were not retrieved, so nothing here is mapped to named values.

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral (4 questions) | Scenario probes on leadership, growth and truth-telling | High. The recruiter's own words name values and leadership philosophy | Choose stories carried by your sentences; "we" for context, "I" for contribution; where none fits, a scaffold with its honest branch |
| Pressure (2 questions) | Time-boxed challenge to your fit and your attribution | Medium. Skip-levels test composure at altitude (relationship prior) | Pause, restate, anchor in what you stated; hold through two follow-ups before conceding anything real |
| Case/Strategist (2 questions) | Company-altitude strategy | Medium. Short round, but strategy fluency separates candidates at this level | Use the company's own vocabulary only after reading it first; say what you do not know |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-F1 | "What is your leadership philosophy?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | State your philosophy in two sentences, in your own words. Then offer one thing you did, at the sentence's own scope: you pushed a reliability quarter through against roadmap pressure. Do not tell the VP what it proves; let the VP draw it | The recruiter's own framing makes this likely. JD because it scores the leadership requirement |
| R3-F2 | "Tell me about a time you delivered an unpopular truth to leadership." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Open prompt. The nearest sentence is this one: you pushed a reliability quarter through against roadmap pressure. Answer slot: if the pressure came from leadership and you told them something they did not want to hear, say what and what part was yours; if it came from elsewhere, or you did not, say so plainly and give the nearest thing your material carries, or how you would handle it | A persona stem the VP round tends to use (F3's source). EXP |
| R3-F3 | "Tell me about an engineer you helped grow." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Selection scaffold: pick someone from your three years as a team lead whose change you can describe specifically, with a named starting point and what you did. Answer slot: if no such person comes to mind, say so plainly, then give the nearest thing your material carries, or how you would approach growing the people on your teams | The role owns "growth for 11 engineers" (F7), with no evidence yet. EXP |
| R3-F4 | "You've never managed managers. How do you think about leading leaders?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Hold, then concede: "I've never managed managers." Then how you would approach it as a stance and a plan: what you would ask of a lead and what you would leave to them. Answer slot: ask whether the squads have leads of their own, and what the VP expects. Never imply experience | The R1 objection at VP altitude (F1). JD |
| R3-G1 | "Sixty seconds: why you, rather than someone who has already managed managers?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." and "I run our hiring loop for backend roles — about 40 interviews last year." and "I've never managed managers and never owned a hardware-adjacent roadmap." | Hold, then concede. Hold with your own sentences: "Nine years in engineering, three of them as a team lead of six, and I run our hiring loop for backend roles." Concede: "I've never managed managers." Hold through two follow-ups by returning to those sentences, never by adding to them. Do not claim to be the better candidate | The time-boxed form of R1-B1 (F1, F6). JD |
| R3-G2 | "That reliability result: how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold: "I pushed a reliability quarter through against roadmap pressure." The sentence gives a sequence, not a share. Answer slot: say which part was yours, in your own words; if others did parts of it, say so plainly | Same attribution probe as R2-E2 in a skip-level register (F5). EXP |
| R3-A1 | "What would you want engineering to be known for at a company building industrial IoT, three years from now?" | CO | [generic] | Offer a short answer with a reason, then say what you would want to learn about Larkfield before committing to it. Makes no claim about Larkfield or your past | CO at VP altitude. `[generic]`: no company research was retrieved |
| R3-A2 | "What do you know about us, and where do you think our device-management services face their hardest problems?" | CO | [generic] | No researched facts about Larkfield are in this pack. Before Monday, read the company's own site and pick two things you can actually say, and say what you do not know. Do not guess at their strategy | The homework check. `[generic]` until the upgrade menu's research input arrives |

### Reverse questions (R3)

| Question | Why it lands |
|---|---|
| "What does good leadership look like in your managers here, in practice?" | Turns the philosophy round into your question |
| "How does engineering decide between roadmap commitments and reliability when they collide?" | Echoes your reliability sentence (F5) without claiming it applies here |
| "What would you most want a new engineering manager here to get right in the first six months?" | Gives the VP the scorecard |
| "How are leaders grown here, and what does growing into leading managers look like?" | Addresses F1's gap as curiosity, not as an excuse |
| "What change do you expect engineering to face over the next two years?" | A strategy question that shows altitude |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| "Lead two squads building device-management services" | R1-B1, R1-A1, R1-A3, R3-F4, R3-G1 |
| Device-management domain | R1-B3, R3-A1, R3-A2 |
| "partner with hardware" | R1-B2, R1-A2 |
| "product on roadmap" | R1-B4, R2-F1, R2-F2 |
| "own delivery" | R1-A2, R1-A3, R1-B4, R2-E1, R2-E2 |
| "hiring" | R1-A4, R2-E3 |
| "growth for 11 engineers" | R2-F3, R3-F3 |

## Sources

Provided: your message (the role description, the three rounds, the four background sentences, the recruiter's description of R3). The loop is established by your own words: one session per round, with who runs each.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Query "Larkfield Systems industrial IoT company values" was refused. It would have moved the values cheat sheet and mapped R3 stories; the section is dropped |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Query "Larkfield Systems interview process engineering manager" was refused. It would have added round formats beyond what you described; your own words fixed the loop |
| 3. `Larkfield Systems strategy` / recent news | unavailable | Query "Larkfield Systems industrial IoT device management strategy news" was refused. It would have moved R3-A1 and R3-A2, which stay `[generic]` |
| 4. `{interviewer name} Larkfield Systems` | n/a | No interviewer names were given, so there was no query to form; there is no interviewer read |
| 5. representative `Engineering Manager` JD | skipped | The role description you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full job description → the seven rows above rest on a one-sentence summary; the full text may add requirements, and `[inferred]` rows could become `[grounded]`
- Your CV → its lines become quoted evidence and could raise the bands, especially F2, F5 and F7
- Your written answers to the answer slots in F1, F3, F5 and F7 → each becomes quoted material and the rows and questions that draw on it regenerate
- Larkfield's published values, pasted or linked → a values cheat sheet for R3, with each value mapped to your sentences or a selection scaffold
- The names of the Director, the two staff engineers, the product manager and the VP → an interviewer read for each, and reverse questions tied to their own paths
- The recruiter's notes for each round, especially the panel's focus areas and any pre-declared deliverable → coverage and build sections for graded deliverables
- Search permission for company research, with a deeper pass of up to 6 more searches and 2 more fetches, several more minutes → R3-A1 and R3-A2 and the CO coverage move from `[generic]` to researched
- A tuesday-dossier.md from job-underwriter, if you have run it → verified evidence and strategy limits for weak areas that this pack otherwise infers
