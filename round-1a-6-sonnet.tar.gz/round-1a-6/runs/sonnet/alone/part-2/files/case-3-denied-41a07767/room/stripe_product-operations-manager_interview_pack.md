# Interview prep pack: Product Operations Manager, Stripe (final round)

Interviewer: not given. Relationship: not given. Built for a final round of unknown format, so persona weights are flat and the pack covers every plausible style.

## How to use this pack

- Personas describe how a question is asked. Types describe what is being scored. Rehearse both: say the answers aloud, in your own words.
- Type key: VAL is behavioral or values alignment. EXP is a work-experience deep-dive. JD is role-driven. CO is company and strategy knowledge. CASE is a live problem.
- Guidance is scaffolding, not a script. This pack has no CV, no job description and no research, so every guidance cell is a selection scaffold: it tells you how to choose a true story from your own history, never what that story says. Every row is labeled generic, and each scaffold ends with an honest branch for when no story comes to mind.
- Highest-ROI rehearsal: B1, "Which part of this role would you be weakest at on day one?" Some form of it is likely in any final round. Its generic version is the deepest bank here (hold through two follow-ups, concede specifically). It sharpens a lot once your CV is added.

## Fit snapshot (worksheet variant)

No CV or JD was supplied, so this is a worksheet. Requirements are role-family prose for product operations roles, not quotes from Stripe's posting. Fill the evidence column yourself, using your real sentences, before relying on any row.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinate cross-team product launches or programs (role-family, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a named launch or program, your exact part in it, and who depended on your work. Selection scaffold: pick the one where your part is easiest to state exactly. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Run planning and operating rhythms for a product organization (role-family, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a recurring process you ran, its cadence, and what changed because of it. Selection scaffold: pick a rhythm where you can say what you owned and what others owned. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Use data to spot problems and judge outcomes (role-family, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a metric you tracked, how it was counted, and a decision it changed. Selection scaffold: pick a figure whose counting method you can explain. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Design and improve processes and tooling (role-family, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a process or tool you changed, the problem it addressed, and how you knew it worked. Selection scaffold: pick a change where you can separate your part from the team's. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Influence people across teams without formal authority (role-family, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a disagreement or competing priorities you worked through, with the outcome and what was yours. Selection scaffold: pick an instance where the relationship was intact at the end. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Communicate clearly in writing and to senior audiences (role-family, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a document or briefing you wrote or gave, and who it was for. Selection scaffold: pick one you can describe without embellishing. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

No gate rows are listed: nothing supplied states a location, schedule, pay or work-authorization term, so none can be assessed.

## Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 cross-team launches or programs | A1, A3, B3 |
| F2 planning and operating rhythms | A1, A4 |
| F3 data and outcome judgment | A2, D1, D2, D3 |
| F4 process and tooling | A4, D3 |
| F5 influence without authority | A3, C3, E1, E2, E3 |
| F6 communication to senior audiences | C1, G1, H1 |
| Company-specific requirements | none, and why: no JD and no research, so none are known |

## Persona table

The loop is not established: no loop source was read. Weights rest on the generic archetype (screen, hiring manager, panel), not on Stripe's documented process, and a final round of unknown format could be several sessions. Treat the weights as a starting point and recalibrate if you know more.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | Live problems from the role: plan this, diagnose that | High: product operations work is problem-shaped, and a final round tends to test reasoning live | Clarify, objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully |
| B. Skeptic | Quiet probing of gaps, motivation and the "why here, why now" | High: a final round is where remaining doubts get tested | Rehearse the single most predictable objection (B1) until it is boring. Use only adjacent experience you can state exactly |
| C. Values / Behavioral | Scenario questions for stories that show behavior | Medium: no values-style round is established, so Stripe's published values are not known here | Choose stories where you can say what you did, using we for context and I for your contribution |
| D. Data-Driven Prober | Goes two levels deep on any number you give | Medium: likely whenever a metric appears in your answers | Know how each figure was counted and say plainly when you do not know |
| E. Peer Evaluator | Seams between teams, credit, disagreement | Medium: product operations sits between teams | Offer principles for a seam rather than pretending to know it. Frame what you bring them |
| G. Pressure | Interrupts, time-boxes, questions motives | Low to medium: composure test, more common with senior interviewers | Pause, restate, hold a position through two follow-ups, then concede specifically |
| H. Conversational | Friendly, unstructured openers that are still scored | Medium: opening minutes of most rounds | A prepared 90-second arc, and treat casual questions as scored |

## Question banks

Provenance is `[generic]` throughout: no candidate material was supplied, so no guidance makes a claim about your past.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch the plan for getting a cross-team product launch ready. What do you need to know first?" | CASE | [generic] | Clarify first: what ready means, who decides, the date and what is fixed about it. Then objective, the groups involved, approach, how you would track progress, risks. State one assumption aloud and challenge one premise respectfully | Live problem from the role's F1 and F2 areas. CASE because it scores structure, not a past claim |
| A2 | "A metric the product team watches dropped 20 percent week on week. Diagnose it." | CASE | [generic] | Check the definition and instrumentation first, then segments, then recent changes, then external causes. Say what data you would request and what would change your mind | Covers F3. CASE because the stem is a classic diagnose-it prompt |
| A3 | "Two teams each say their launch should get the same shared resource. You are asked to decide how. What is your approach?" | CASE | [generic] | Criteria before choices, who owns the final call, what data you would gather, how you would communicate the decision and record the reasoning. Propose a principle rather than naming a winner | Covers F1 and F5. CASE with an influence flavor |
| A4 | "What should a product operations team be accountable for here, and how would you know it is working?" | CO | [generic] | Offer a hypothesis in your own words, then say what you would ask to test it. State no facts about Stripe's organization that you have not read in an official source. Before the interview, read Stripe's own published material yourself | Homework-depth question. Generic because no research ran, so it asserts nothing about Stripe |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | The highest-ROI rehearsal. Pick the requirement where your own material is thinnest (use the worksheet). Name it in one plain sentence, then give a concrete first-30-days ramp: who you would ask, what you would read, what you would produce. Hold through two follow-ups and concede specifically; do not minimize and do not pivot to a fake weakness. If no gap comes to mind, say so plainly, then name the area where you would most want a second opinion | The most predictable objection in any final round. JD because it scores honest self-assessment against the role |
| B2 | "Why this role, why Stripe, why now?" | EXP | [generic] | One true reason about what you are moving toward, in two sentences, consistent with your CV. No criticism of your current employer. If no single clear reason comes to mind, say so plainly, then say the part that is true | Motivation consistency is what a Skeptic scores. EXP because it tests the story of your path |
| B3 | "Suppose part of this role is something your background does not cover. How would you handle it?" | JD | [generic] | Structure: say what you would ask, who you would learn from, what you would do first, and how you would show progress. Add no experience you cannot state exactly | Tests F1 transferability without presupposing a gap. A hypothetical, so it claims nothing about your past |
| B4 | "What is the biggest risk in hiring you?" | JD | [generic] | Name one real risk plainly and what you would do about it. If none comes to mind, say so plainly, then name what you would watch in your first month | Pressure-tests candor. JD because it scores fit against the role |

### C. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not soften it, and an outcome where the truth landed. Use we for context and I for your contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Standard behavioral stem. Stripe's published values are not known here, so it is not mapped to any |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a decision where the two pulled apart, what you chose, and what you gave up. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Standard behavioral stem. VAL because it scores behavior, not opinion |
| C3 | "Tell me about a time you held a position under pressure from someone senior." | VAL | [generic] | Selection scaffold: a named stake, a moment you did not fold, and an intact relationship at the end. Concede what was genuinely uncertain. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Covers F5 under pressure. VAL because the story shows spine and tact |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Pick a figure you would put on your CV. Walk me through how that number was counted." | EXP | [generic] | Say how it was counted, in your own words. If you do not know how it was counted, say so plainly. Never supply a method you cannot repeat under a second question | Defend-the-number rehearsal for F3. EXP because it tests attribution honesty |
| D2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | Name the weakest assumption you know of before they do, and what the figure is sensitive to. If you do not know, say so plainly | The weakest-assumption move turns a gotcha into a credibility gain |
| D3 | "How would you decide whether a new launch process is working?" | CASE | [generic] | Say what outcome the process is for, which few measures you would watch, how you would get a baseline, and what result would make you stop or change it | Covers F3 and F4. CASE because it is a hypothetical with no claim about your past |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you disagreed with a peer about how something should be done." | VAL | [generic] | Selection scaffold: the disagreement, what each side wanted, how it resolved, and the relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Collegial packaging for F5. VAL because it scores disagreement style |
| E2 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | JD | [generic] | Offer seam principles rather than pretending to know the seam: who owns what outcome, who decides ties, how to surface conflict early. Add what you would bring their team | Peer personas test turf awareness. JD because it is about the role's interfaces |
| E3 | "How do you handle credit when work spans teams?" | VAL | [generic] | Say your approach in your own words: who you name, how you describe shared work. If you have an example, give it with exactly what was yours. If not, say so plainly and describe how you would handle it | Credit-sharing is a standard peer probe |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over an internal candidate?" | EXP | [generic] | Pause, restate, then give one or two true differentiators from your own material. Hold through two follow-ups, then concede specifically what you cannot claim to know yet | Hold-then-concede rehearsal. EXP because it scores your own case |
| G2 | "That result: how much of it was actually you?" | EXP | [generic] | Pick a result you own. Separate your part from the team's in plain words. If your part was small, say so plainly and describe it exactly | The attribution probe interviewers use to catch inflation. Candor is the preparation |

### H. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc: where you started, the turns, why this role. Every beat comes from your own CV, in your own words. If a turn has no clear reason, say so plainly | Casual openers are still scored. EXP because it tests the coherence of your path |
| H2 | "What are you actually working on or learning these days that is relevant to this role?" | JD | [generic] | Name one real thing, why it interests you, and what you have done with it. If nothing comes to mind, say so plainly, then say what you plan to learn first | A casual question about a JD-adjacent topic. Scored for genuine interest |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would a successful first 90 days look like, and what would you most want me to have learned by then?" | Shows you are planning to deliver, and gives you the interviewer's own bar |
| 2 | "What does the product operations function here own outright, and what does it only influence?" | Probes scope honestly, and it is a question a candidate who has thought about the seam asks |
| 3 | "Where do the seams with product, program and engineering teams currently cause friction?" | Signals partnership thinking and surfaces the real problems of the role |
| 4 | "How is the team's work measured, and how do you know it is helping?" | Shows metric discipline and tells you what you would be judged on |
| 5 | "What is one decision the team made recently that you would make differently now?" | Invites candor and a peer conversation instead of an interrogation |
| 6 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity question, useful if the interviewer is a peer |
| 7 | "What are the next steps and timeline from here?" | Practical close, and shows you are ready to proceed |

## Prohibited claims

None listed from this material: no sentences of yours were supplied, so there is no stretched wording to list. Instead, the pack follows these limits throughout:

- It asserts no fact about Stripe's values, interview loop or strategy, because research was refused and model memory is not a source.
- It tells you to claim no experience. Every row where a claim would sit is a selection scaffold ending in an honest branch.

## Sources

Provided documents: your message (company, role title, "final round"). No dossier was consumed.

Research tier: L1, searches 4 of 6, fetches 0 of 2

Queries sent, all refused (search permission was not granted): "Stripe operating principles values"; "Stripe interview process product operations manager"; "Stripe strategy recent news 2026"; "Stripe Product Operations Manager job description".

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Would have fed a values cheat sheet and VAL mapping. Not built; VAL questions use generic stems |
| 2. Stripe interview process, role family | unavailable | Would have fixed the loop and persona weights. Weights fall back to the generic archetype |
| 3. Stripe strategy and recent news | unavailable | Would have grounded CO and CASE questions. A4 is generic instead |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form; no interviewer read |
| 5. Representative Product Operations Manager JD | unavailable | Would have turned the fit snapshot's requirements into quoted, inferred ones. They are generic prose instead |

## Upgrade menu

- Your CV, or a few sentences about your background: the fit snapshot worksheet becomes a real one with quoted evidence, and the selection scaffolds become story maps where your sentences carry a story.
- The job description text: the six generic requirement rows become quoted and grounded, and any term it states (location, schedule, pay) becomes a gate row.
- Round type and who you are meeting (manager, peer, skip-level, cross-functional, recruiter): persona weights stop being flat and the banks are reordered.
- If your final is several sessions, the schedule: per-session mini-packs.
- Anything the recruiter said about focus areas or a pre-declared deliverable (usually one email to ask): coverage stops being assumed from the generic archetype, and any deliverable gets its own build section.
- The interviewer's name: an interviewer read and a reverse question tied to their path.
- Search permission: Stripe's published values, the documented loop and current strategy replace generic rows, and a values cheat sheet appears if a values round is documented. A deeper pass afterwards would be up to 6 more searches and 2 more fetches, several more minutes.
- A tuesday-dossier.md from earlier work, if you have one: verified evidence, weak-area strategies and prohibited claims arrive pre-graded.
