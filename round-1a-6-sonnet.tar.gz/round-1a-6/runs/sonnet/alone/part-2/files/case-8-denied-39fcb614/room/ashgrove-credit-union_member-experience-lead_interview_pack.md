# Member Experience Lead, Ashgrove Credit Union: interview pack for Dara

Loop mode, three rounds on 5 December 2026. Built 26 November 2026.

| Round | Who | Length | Shape, from the recruiter's email |
|---|---|---|---|
| 1 | The recruiter | 30 min | Screen |
| 2 | Head of Member Services, who would be your manager | 45 min | Mostly behavioural |
| 3 | Panel of two branch managers | 60 min | Includes a 20-minute case on a complaint escalation; also the values round, scored against the four values |

No interviewer has been named, so there is no interviewer read. Personas rest on the roles and on the recruiter's description of each round.

## How to use this pack

- Personas describe how a question arrives. Types describe what it scores. Every question carries both.
- Type key: **VAL** is values and behaviour. **EXP** tests whether your background survives probing. **JD** tests a stated requirement. **CO** is company and strategy knowledge. **CASE** is a live problem.
- Provenance key: `[grounded]` traces to something you gave me. `[inferred]` is derived from adjacent material, with the derivation named. `[generic]` is a pattern for the role family and asserts nothing about Ashgrove or you.
- Guidance is scaffolding, not a script. Where a cell says "Answer slot", it describes a probe the JD or the values make likely, and the answer must come from what actually happened, in your own words. Both branches are fine, including "that wasn't mine" and "that didn't exist".
- The highest-ROI prep in the pack is **C1**, the contact-centre question. It will arrive in some form, and the pack's whole fit picture turns on how calmly you take it.

## Prep triage

Sized to the nine days between today and 5 December. Your daily hours weren't given, so the order matters more than the pace.

1. By 28 Nov: say C1 and C2 out loud until they are boring. Say the plain acknowledgments from F2 and F8 aloud as written.
2. 29 Nov to 1 Dec: work through the answer slots in F1, F3, F4, F7 and F9. Write down, from memory, what is true on each branch. Those notes become the stories the guidance cells need.
3. 2 to 3 Dec: choose a real story for each of G1 to G4 using the selection criteria, or settle on the honest branch.
4. 4 Dec: run H1 aloud against a 20-minute clock. Go through the reverse questions for all three rounds.

Everything else in the pack is insurance.

## Fit snapshot

No requirement in the JD is a term-type gate, so no row is a `hard_gate`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Words at the quote's scope: "I handled the branch's formal complaints log." Your material says the branch's log, not the process end to end across branches; that limit is the pack's observation, not words for you. Answer slot: the JD's "end to end" line makes a probe on what lay beyond your branch likely. If any part of a complaint's journey beyond the branch's log was yours, say which part, in your own words; if none was, or it was not yours, say so plainly and stay with the log |
| F2 | "the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap you stated, which wording cannot close. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. C1 rehearses this. Nothing is added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Words at the quote's scope: "I built the monthly complaints spreadsheet our regional manager uses." Your material does not show what the spreadsheet counted. Answer slot: the JD's volumes and resolution times line makes a probe on its contents likely. If it showed volumes, resolution times or both, say which and how each was counted, in your own words; if it showed neither, say so plainly and say what it did show |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message, "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | transferability | Words at the quote's scope: "I trained new tellers on our escalation script." Your material says tellers and a script, not supervisors; that is the pack's observation. Answer slot: if any of your training reached supervisors, or went beyond the script, say what and how; if none did, say so plainly and stay with the tellers |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing on digital or self-service work. Answer slot: if you have worked with digital or online-channel colleagues on how members get help or make complaints, say what and which part was yours, in your own words; if you have not, say so plainly and say what you would want to learn first |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap on the length. Say it in the quote's own terms: six years in retail banking, the last three as a branch supervisor. The JD's phrase is wider than branch work, and the contact centre sits inside it (F2), so state your years as yours and let the interviewer decide how the label fits |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | Words at the quote's scope: "I handled the branch's formal complaints log." Your material says formal complaints, not what governed them. Answer slot: the JD's "regulated" wording makes a probe on which rules applied likely. If you worked to any external rules, say which and how, in your own words; if the log was an internal record, or the rules were someone else's to apply, say so plainly and stay with the log |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap you stated. Words: "I haven't presented above regional level." Then how you would prepare for a first presentation to senior leaders, said as a plan and never as a past. Neither the JD nor your material says who counts as a senior leader at Ashgrove, so do not guess |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | Inferred from: a spreadsheet was built, but the sentence does not name Excel or say what the spreadsheet did. Words at the quote's scope. Answer slot: if the spreadsheet was in Excel, say what you built in it, in your own words; if it was another tool, say so plainly and say what you can do in Excel today |

## Grounding brief

Four points from the July 2026 strategy brief the recruiter sent. You pasted these four points, not the whole brief.

| Point | What it means for your answers | Provenance |
|---|---|---|
| "move 40% of member service to digital channels by 2028" | Expect it in the digital-team duty (F5) and in F1 and H3. What counts as "member service" is not in what you pasted, so ask rather than assume | [grounded] |
| "consolidate eight branches into five hubs over 2027" | It sits beside the value "Neighbours, Not Numbers — every branch is part of its town". Two branch managers on the panel may feel it directly, so expect it in round 3 (F2, H2, I2). Do not defend or criticise the plan | [grounded] |
| "launch a small-business lending product in Q1 2027" | A new member segment means new kinds of complaint. Useful as a reverse question, not as a claim you know the answer | [grounded] |
| "the main competitive pressure is app-only banks" | The reason a credit union's plain, human complaint handling matters. Useful for A2 and F1 | [grounded] |

## Persona table

| Round | Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|---|
| 1 | Conversational (A) | Friendly biography and logistics: pay, notice, location, reason for moving | High. The recruiter-screen prior is a conversational register with logistics, and the email calls it 30 minutes "with me". Casual questions are still scored | A 90-second arc, and your own answer ready for each logistics item |
| 1 | Skeptic, light (B) | A knockout check on the contact centre and the formal complaints | Medium. A screen checks the JD's first duty against what you have said | Say the limit plainly before it is asked for, then stop |
| 2 | Skeptic (C) | Quiet probing of the gaps, with one 60-second pressure item | High. The hiring-manager prior is Skeptic, and F2 and F8 are gaps you have stated | Rehearse C1 until it is boring. Hold the quoted position through two follow-ups, concede specifically, never fold |
| 2 | Values / Behavioral (D) | "Tell me about a time" stories | High. The recruiter described round 2 as mostly behavioural | Selection criteria, "I" for contribution and "we" for context, and the honest branch where no story fits |
| 2 | Data-Driven Prober (E) | What the spreadsheet counted and what handling the log involved | Medium. Reporting on volumes and resolution times is a JD duty, and your spreadsheet is the artifact that speaks to it | Know what you can say about how each thing was counted, and say plainly where you do not know |
| 2 | Case / Strategist (F) | Questions from the strategy brief | Lower. The email says mostly behavioural, and a manager's prior would otherwise raise it | Clarify, structure, then answer, using Ashgrove's own vocabulary |
| 3 | Values / Behavioral (G) | One story per value, scored against the four values | Highest. The recruiter says the panel "scores against the four values" | Map a real story to each value where one exists, and use the honest branch where none does |
| 3 | Case / Strategist (H) | The 20-minute complaint escalation case | High. It is announced, and it is a third of the hour | Ask two or three clarifying questions, think aloud, and ask rather than assume where the case turns on the contact centre |
| 3 | Peer Evaluator (I) | Seam and credit questions from branch managers whose supervisors you would coach | Medium. This is inferred from the JD's coaching duty and from the panel being branch managers, and it is the weakest weighting in the pack | Reciprocity: what you bring their branches, and principles for the seam rather than a claim to know it |

## Question banks

### Round 1: the recruiter (30 min)

**A. Conversational (weight 6, four of them fixed logistics rows)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc in the order your sentences give it, telling only the beats they state: six years in retail banking, the last three as a branch supervisor; the branch's formal complaints log; training new tellers on the escalation script; the monthly complaints spreadsheet your regional manager uses. Say them in your own words and add no outcome. Close with your actual reason for wanting this role | Recruiter screens open on the biography, and F6, F1, F4 and F3 are the rows it draws on. EXP because it tests what was actually yours |
| A2 | "What draws you to Ashgrove, and to a credit union rather than another bank?" | CO | [grounded] | Give your actual reason, in your own words. Two public anchors you may use: the value "Members First, Always — we decide from the member's side of the counter", and the brief's point that app-only banks are the main competitive pressure. Do not borrow a reason that is not yours, and make no claim about a history with Ashgrove | Motivation consistency is scored even in a friendly screen. CO because it tests homework, with a motivation edge |
| A3 | "What are your salary expectations?" | JD | [generic] | Logistics slot. Give your own number, or ask for the role's band first. If asked what you earn now: "I'd rather focus on the range for this role." Say nothing beyond your own figure | A screen checks pay against the role's terms. JD because the answer is a term of the listed job |
| A4 | "What's your notice period, and when could you start?" | JD | [generic] | Logistics slot. Give your actual notice period and earliest start date, as they stand | A knockout item on the role's start date. JD because it is a term of the job |
| A5 | "The role covers branches, the contact centre and, from 2027, hubs. Where are you based, and what travel works for you?" | JD | [generic] | Logistics slot. Say where you can work and how often, as it stands, or ask first how the week splits across sites. The JD gives no location, so the recruiter's answer may be news to both of you | The JD is silent on location, and the strategy brief's hubs make travel real. JD because it is a term of the job |
| A6 | "What's prompting you to look at a move now?" | EXP | [generic] | Say your actual reason in one or two sentences, in your own words. Include what you are moving toward only if that is true | Consistency of motivation is the recruiter's core check. EXP because it is about your own path |

**B. Skeptic, light (weight 2)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role covers the contact centre as well as branches, and you haven't worked in one. How do you see that?" | JD | [grounded] "Never worked in a contact centre" | Acknowledge it plainly: "I haven't worked in a contact centre." Then say how you would learn it, as a plan. Stop there. The full rehearsal is C1 | F2 is the one gap you have stated and the JD names the contact centre in its first duty. JD because it tests the stated requirement |
| B2 | "Tell me about the formal complaints you've handled." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Beats the sentence states: you handled the branch's formal complaints log. Answer slot: the JD says "regulated", so expect a probe on which rules applied. If you worked to any external rules, say which and how, in your own words; if the log was an internal record, or the rules were someone else's to apply, say so plainly and stay with the log | F7 is the snapshot's discovery row on the "regulated" requirement. JD because it is a stated requirement |

### Round 2: Head of Member Services (45 min, your future manager)

**C. Skeptic (weight 4)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log and trained new tellers on our escalation script." | **Highest-ROI prep in the pack.** Level 1: name it before they do: "I haven't worked in a contact centre." Level 2, "How would you get up to speed": give a plan, not a past. Choose the first two things you would actually do in your first month, in your own words; if unsure, say what you would ask first. Level 3, "So you'd own half a process you've never seen": concede exactly, "Yes, the contact-centre half would be new to me", and hold only what your sentence carries: "I handled the branch's formal complaints log." Do not add "but I have…". Answer slot: if any complaint in your branch involved the contact centre, say what and which part was yours; if none did, say so plainly and stay with the branch | F2 is a gap you stated and the JD's first duty names the contact centre, so this objection arrives in some form. JD because it scores a stated requirement, with a Skeptic's delivery |
| C2 | "Part of this role is presenting to senior leaders. What's your experience of that?" | JD | [grounded] "I've never presented to anyone above regional level" "I built the monthly complaints spreadsheet our regional manager uses." | Hold-then-concede. Say it plainly: "I haven't presented above regional level." Then say how you would prepare for your first one, as a plan. The only thing you can hold is your own sentence: "I built the monthly complaints spreadsheet our regional manager uses." Do not call that presenting. Answer slot: if you have walked your regional manager, or anyone, through the spreadsheet in person, say how that went; if it was only sent or used, say so plainly and stay with that | F8 is a stated gap against a JD requirement. JD because it scores the requirement |
| C3 | "You've been a branch supervisor yourself. How is coaching supervisors different from training new tellers?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Beats your sentences carry: three years as a branch supervisor; you trained new tellers on the escalation script. Answer slot: if you have supported another supervisor through an escalation, say what and which part was yours; if you have not, say so plainly and stay with the tellers. Then say how you would approach coaching a peer, as what you would do and not as something you have done | F4 is a transferability row, from tellers and a script to supervisors. JD because it scores the coaching duty |
| C4 | "Sixty seconds: why you, over someone who has run complaints in a contact centre?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I built the monthly complaints spreadsheet our regional manager uses." | Pause, restate the question, then concede the contact centre first: "I haven't worked in a contact centre." Then use only the beats your sentences carry: six years in retail banking, the last three as a branch supervisor, and the spreadsheet your regional manager uses. Do not argue that you are better. Say what you would bring and what you would need to learn | A time-boxed challenge tests composure, not content. The gap is F2; JD because it asks you to weigh yourself against the requirement |

**D. Values / Behavioral (weight 3)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time a member's problem took longer to solve than it should have. What did you do?" | VAL | [generic] | Selection criteria: a specific member's problem, a moment when passing it on would have been easy, and an outcome you can state without adding to it. Use "I" for what you did and "we" for context. If no such time comes to mind, say so plainly, then give the nearest thing you did handle, or how you would handle it | Own the Fix and Members First both run through this. VAL because it tests behaviour against published values |
| D2 | "Tell me about a time you had to tell someone senior something they didn't want to hear." | VAL | [generic] | Selection criteria: a named stake, a moment you did not soften it, and a relationship that was still intact afterwards. Choose a time the message landed. Describe the person's real level, whatever it was, and do not stretch it. If none comes to mind, say so plainly, then give the nearest thing or how you would handle it | A manager probes how you handle upward honesty. VAL, with a Skeptic's edge |
| D3 | "Tell me about a time the escalation script didn't fit the situation." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Beats the sentence carries: you trained new tellers on the escalation script. Answer slot: if there was a case where the script did not fit, say what you did and why, in your own words; if the script always fitted, or you never had to depart from it, say so plainly and describe how you taught it | F4's coaching duty depends on judgement beyond a script. VAL because it tests behaviour, and the slot allows that no such case existed |

**E. Data-Driven Prober (weight 2)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about the monthly complaints spreadsheet. What did it show, and how did your regional manager use it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Beats the sentence carries: you built it, and your regional manager uses it. Answer slot: if it showed volumes or resolution times, say how each was counted and which assumption behind them you would defend least; if you do not know how a figure was counted, say so plainly; if it showed neither, say what it did show. Answer slot: if it was built in Excel, say what you built in it; if it was another tool, say so | The one artifact in your material that speaks to F3 and F9. EXP because a Prober tests whether it survives scrutiny |
| E2 | "Tell me what handling the branch's formal complaints log involved, day to day." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Beats the sentence carries: you handled the branch's formal complaints log. Answer slot: if some steps of a complaint's journey were yours and some sat with others, say which; if the log was all of it, say so. Answer slot: if you worked to external rules, say which; if the log was an internal record, say so plainly | F1 and F7 both rest on this sentence. JD because it tests the end-to-end and regulated requirements |

**F. Case / Strategist (weight 2)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Ashgrove wants 40% of member service on digital channels by 2028. Which complaints should never be pushed to self-service, and how would you decide?" | CO | [grounded] | Clarify first: what counts as member service in the 40%, which channels, and what the complaint mix is today. Then segment by the member's need and by how serious the complaint is. State the approach, the measures you would watch, and the risk. Name the risk in plain words: a member who needs it explained twice. Make no claim about your past | A manager from the strategy brief asks how you think at Ashgrove's altitude. CO because it is the strategy, with CASE delivery |
| F2 | "Eight branches become five hubs over 2027. What happens to complaint handling during that change?" | CO | [grounded] | Clarify what changes first, without claiming to know which branches. Then say where complaints would surface, how local ownership stays visible so that every branch stays part of its town, and what you would watch while supervisors learn a new setup. Take no side on the consolidation itself | The most concrete move in the brief for a complaints lead. CO because it tests current strategy |

### Round 3: panel of two branch managers (60 min, includes a 20-minute case, scored against the four values)

**G. Values / Behavioral (weight 5)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time the right answer for a member wasn't the easy one for your branch." | VAL | [generic] | Selection criteria for Members First: a decision made from the member's side, a cost to the branch that you can name, and an outcome you can state without adding to it. If no such time comes to mind, say so plainly, then give the nearest thing you did handle, or how you would decide | Members First, Always: "we decide from the member's side of the counter". VAL, mapped to the first value |
| G2 | "Tell me about a time you had to explain something to a member more than once." | VAL | [generic] | Selection criteria for Plain Words: what needed explaining, what you changed about how you said it, and what the member understood afterwards. Own the wording: "if a member needs it explained twice, we wrote it wrong". If no such time comes to mind, say so plainly, then give the nearest thing or how you would handle it | Plain Words. VAL, mapped to the second value |
| G3 | "Tell me about a time you weighed a decision against what it meant for the town a branch serves, not just the numbers." | VAL | [generic] | Selection criteria for Neighbours, Not Numbers: a decision with a local effect, a number you did not simply follow, and an outcome you can state without adding to it. If no such time comes to mind, say so plainly, then give the nearest thing or how you would weigh it. Expect the hub plan in the room | Neighbours, Not Numbers, with the 2027 hubs beside it. VAL, mapped to the third value |
| G4 | "Tell me about a problem you found that wasn't yours to fix. What did you do?" | VAL | [generic] | Selection criteria for Own the Fix: a problem you found, a moment you could have passed it on, and a point where you kept hold of it until it closed, or handed it over with a named person. If no such time comes to mind, say so plainly, then give the nearest thing or how you would handle it | Own the Fix: "whoever finds the problem keeps hold of it until it is solved". VAL, mapped to the fourth value |
| G5 | "Which of our four values would be hardest for you to live by here?" | VAL | [grounded] | Pick the value that is truly hardest for you and say why, in your own words, with one concrete limit. A weakest-value answer concedes specifically and does not fold. Do not pick the easy one, and make no claim about a record of living by any of them | A values panel checks honest self-assessment. VAL because it tests the published values directly |

**H. Case / Strategist (weight 3)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "A member's complaint was marked resolved by the branch. The member says nothing has changed and has now called the contact centre, where nobody has the branch's notes. The supervisor says it is the contact centre's file now, and the contact centre says it is the branch's. You have 20 minutes. What do you do?" | CASE | [generic] | Ask two or three clarifying questions first, such as what the member has been told, what harm is ongoing, and what is time-critical. State the objective. Settle who holds it today, and hold it yourself until that is clear. Speak to the member in plain words. Then fix the handover and decide what you would report. Think aloud. If the case turns on how the contact centre works, ask rather than assume | The panel announced a 20-minute complaint escalation case. CASE because it is a live problem, built from the JD's first duty and the Own the Fix value |
| H2 | "A complaint comes from a town whose branch is due to merge into a hub in 2027. The member says the bank has stopped caring about the town. What do you do?" | CASE | [grounded] | Clarify what the complaint is actually about and what the member has been told. Treat the complaint on its merits, in plain words, without defending or criticising the plan. Say what you would pass to whoever owns the hub plan, and how the branch's supervisors are kept in the loop | Branch managers are the people closest to the consolidation in the brief. CASE with a Neighbours, Not Numbers edge |
| H3 | "A member says the app told them to call us, the branch sent them back to the app, and nobody owned the problem. Where do you start?" | CASE | [grounded] | Clarify what happened and what the member lost. Fix the member's problem first. Then name the journey gap and who owns it, and say what you would bring to the digital team, in line with the 40% target. Own the fix until it is closed, and be plain about what you do not know of the digital side | The strategy's digital shift meets the digital-teams duty (F5). CASE because it is a live problem |

**I. Peer Evaluator (weight 3)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "When you and a branch manager disagree about an escalation, where is the seam, and what happens?" | JD | [generic] | Offer principles for the seam rather than claiming to know it: who holds the member's problem, who decides, and how the disagreement is recorded. Say what you would ask the branch to tell you early. Make no claim about a past disagreement | Peers test turf awareness. JD because it concerns owning the process across branches |
| I2 | "When a complaint shows a problem inside a branch, how do you handle who gets the credit or the blame?" | VAL | [generic] | A principle, not a story: the complaint is the member's, the fix is the branch's to own with your support, and you report the pattern and not the person. Spine and tact together | Peers probe credit-sharing. VAL because Own the Fix and Neighbours, Not Numbers both bear on it |
| I3 | "What would you want from us in your first month?" | JD | [generic] | Reciprocity framing. Say what you would ask of them, such as a day on the floor and honest access to how escalations run, and what you would offer back. Offer only what you would actually do | The reciprocity question for a peer panel. JD because it concerns working across branches |

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| "Own the member complaints process end to end across branches" | B2, E2, H1, H2, I1 |
| "the contact centre" | B1, C1, C4, H1 |
| "report monthly on complaint volumes and resolution times" | E1 |
| "coach branch supervisors on escalations" | C3, D3, I1 |
| "work with digital teams on self-service journeys" | F1, H3 |
| "4+ years in financial-services customer operations" | A1, C4 |
| "experience handling regulated complaints" | B2, E2 |
| "confident presenting to senior leaders" | C2, D2 |
| "comfortable with Excel reporting" | E1 |

## Values cheat sheet

The panel scores against these four values, as the recruiter's email says. The names are from the page you copied on 26 November 2026.

| Value | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from what the member needs at the counter, not from what suits the branch | No sentence of yours carries a story here (F1, "I handled the branch's formal complaints log and trained new tellers on our escalation script.", is handling, not a decision). Use G1's selection criteria, and the honest branch if none fits |
| Plain Words | Write and speak so that nobody has to ask twice | No sentence of yours carries a story here (F4, the escalation script, is a teaching tool, not a record of plain explaining). Use G2's selection criteria, and the honest branch if none fits |
| Neighbours, Not Numbers | A branch is part of its town, so decisions are weighed locally | No sentence of yours carries a story here. Use G3's selection criteria, and the honest branch if none fits. The 2027 hubs sit beside this value |
| Own the Fix | The person who finds a problem keeps hold of it until it is solved | No sentence of yours carries a story here (F1 says you handled a log, not that you carried a problem to the end). Use G4's selection criteria, and the honest branch if none fits |

## Reverse questions

**Round 1, the recruiter**

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "Can you confirm the times and format for the three rounds on 5 December?" | 5 December 2026 is a Saturday, so confirming the day, times and in-person or video format avoids a surprise |
| R1.2 | "How does the week split across the branches, the contact centre and, later, the hubs, and where is the role based?" | The JD says nothing on location, and A5 will ask |
| R1.3 | "Is there a published scoring guide for the values round, or a format for the 20-minute case?" | You can then rehearse the real shape of H1, not a guess |
| R1.4 | "Who is on the panel, and which branches do they manage?" | It tells you which of the hub moves the panel feels most, and lets you tune round 3 |
| R1.5 | "What is the timeline for a decision after the 5th?" | A practical close that shows you are planning |

**Round 2, the Head of Member Services**

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "How are complaint volumes and resolution times reported today, and to whom each month?" | It ties to the JD's reporting duty and shows you think about the audience |
| R2.2 | "Where does the contact centre's complaint handling sit today relative to branches, and what would you want me to learn first there?" | It turns F2 into a plan and invites your future manager to shape it |
| R2.3 | "As the digital target of 40% by 2028 moves, which complaints do you expect to reach this role instead?" | It shows you read the strategy brief for what it means for the job |
| R2.4 | "Which senior leaders would I present to, and how often?" | It meets F8 honestly and shows you are planning |
| R2.5 | "As the small-business lending product launches in Q1 2027, what new complaint types do you expect?" | A forward-looking question from the brief, not from a claim of knowledge |
| R2.6 | "What would success look like after 90 days, and what would worry you?" | A generic manager question, but it gets the manager to state their own bar |

**Round 3, the branch-manager panel**

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "How do your supervisors handle escalations today, and what would you want from this role?" | Reciprocity for a peer panel, and it surfaces what they actually need |
| R3.2 | "As branches become hubs, what do you most want preserved about how your branch deals with members?" | It speaks to Neighbours, Not Numbers, and it is for the people living the change |
| R3.3 | "When a complaint shows a problem inside a branch, how would you want to hear about it?" | It sets the seam in their terms before you have to guess it |
| R3.4 | "Where does Own the Fix break down in practice here?" | It shows you take the value as practice, not as a slogan |
| R3.5 | "What is one thing a new person in this role could do in the first month to help your branch?" | The reciprocity question for a peer |

## Prohibited claims

What this pack will not coach, and why. These were built before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: your material says the branch's log, not the process end to end across branches |
| Has contact-centre experience | Negative you stated, F2 | The plain acknowledgment F2 gives: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment F8 gives: "I haven't presented above regional level." No slot |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: "I trained new tellers on our escalation script." The limit is the pack's observation: your material says tellers and a script, not supervisors |
| Reported complaint volumes and resolution times each month | Inflated form of F3 | F3's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." The limit is the pack's observation: your material does not show what it counted |
| Handled regulated complaints | Inflated form of F7 | F7's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: your material says formal complaints, not what governed them |
| Is comfortable with advanced Excel reporting | Inflated form of F9 | F9's quote at its own scope. The limit is the pack's observation: your material says a spreadsheet, not Excel or what it did |

## Sources

Provided documents: the job description you pasted; the values text you copied from ashgrovecu.org/about/values on 26 November 2026; the recruiter's email on the three rounds; four points from the July 2026 strategy brief; your own background message. The values page was named only as where your text came from, and was not fetched.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values text is in hand, and it fixes the values cheat sheet and the VAL questions |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | The recruiter's email gives the three rounds, their lengths and who runs each, and it fixes the loop structure and persona weights |
| 3. `Ashgrove Credit Union strategy` | skipped | The four brief points in hand, dated July 2026, fix the CO and CASE questions. The full brief was not pasted |
| 4. `interviewer name Ashgrove Credit Union` | n/a | No interviewer was named, so no query could be formed |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Interviewers' names, once assigned → an interviewer read, persona weights adjusted to their public footprint, and a reverse question tied to their path
- Your answers to the slots in F1, F3, F4, F5, F7 and F9, said in your own words → those rows move from discovery toward presentation or none, and the guidance in B2, C3, D3, E1 and E2 becomes story-mapped
- A redacted view of the monthly complaints spreadsheet's headings or an anonymised extract of the complaints log → F3, F7 and F9 can move from medium or low toward high, because the artifact can be inspected
- The recruiter's answers on the 20-minute case format and on any scoring guide for the values round → H1 can be tuned to the real format (one email)
- The full July 2026 strategy brief → the grounding brief and the CO and CASE questions move from four points to the brief's own wording and figures
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → role-family loop reports and recent organisation context for Ashgrove
- A `tuesday-dossier.md` from an earlier evidence check, if you have one → verified evidence and any gaps already recorded, which would sharpen F1 to F9
