# Interview pack: Senior Partnerships Manager, Kelverton Rail

Round 2, Tuesday. Panel of two, as the recruiter described it: Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). 60 minutes: a 15-minute POV from you, then Q&A in which "Ross will push on commercials". Per your message, Kelverton sells scheduling software to train operating companies.

Built from your message and the recruiter's email as you quoted it. No JD was supplied, no interviewer profile exists, and the market report you attached was not available to me, so nothing here draws on it. All six L1 searches were refused (see Sources), so company facts are absent rather than guessed.

## How to use this pack

- Personas are how a question arrives: the letter before each question number. Types are what it scores: VAL (values-style behavioral), EXP (your experience survives scrutiny), JD (the stated job), CO (company and strategy knowledge), CASE (a live problem).
- Guidance is scaffolding, not a script. Words in double quotation marks are your own sentences from your message, kept at their own scope. Anything marked "Answer slot" is for you to fill truthfully in the interview, in your own words.
- Provenance: `[grounded]` rests on a quote from your material or the recruiter's words, `[inferred]` is derived, `[generic]` is a pattern for the role with no claim about you or Kelverton.

## Prep triage (4 hours)

Do these in order. Everything else is insurance.

1. 90 minutes: the POV (section 5). Choose one thesis, write a five-line spine, run it aloud against a timer twice, recording the second run. Target 13 minutes 30 seconds so the room has slack.
2. 45 minutes: C1, the objection this panel is most likely to open on. Say it aloud five times until it is boring.
3. 40 minutes: defend the numbers, B1, B2, B3 and D2.
4. 25 minutes: B4, B5, and reverse questions R3 and R4, since Ross's push on commercials is the one thing the recruiter named.
5. 20 minutes: the 90-second arc in E1, and the rest of the reverse questions.
6. 20 minutes: re-read the market report once, only to pick the one consensus item for the POV opening.

## Fit snapshot

No JD was supplied, so requirements are the recruiter's own words, quoted, and the one line of context you gave about Kelverton. No term in the material works as a gate (nothing states authorization, location, schedule or pay as a requirement), so no row is a gate and no gate question is asked.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email | "9 years in partnerships, last 4 at a payments company running the ISV channel" — your message; "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Your material carries channel growth at a payments company; it says nothing about operator partnerships in rail, and the bridge stays at the quote's scope: "For the last 4 years I was at a payments company running the ISV channel, and I took it from 6 partners to 40." The POV itself is a view about the future, not a claim about your past. Expect probes on the two figures: say how each was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours, in your own words; where you do not know how a figure was counted, say so plainly |
| F2 | "Please land on what it means for the operators themselves." — recruiter's email | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | At the quote's own scope: "I spent 5 years in transport consulting, in bus and light rail network planning." The pack's observation is that the material says bus and light rail, not train operating companies, and the phrase "from the other side" is yours; this pack does not extend it into what operators want. Answer slot: expect a probe on where train operating companies differ from the operators you planned for. If you know where, say so in your own words; if you do not know, say so plainly and say what you would ask first |
| F3 | "Ross will push on commercials" — recruiter's email | "roughly £4M of influenced revenue" — your message | low | [grounded] | discovery | The quote touches commercials without showing whether it reaches commercial terms, and the material is silent on them. Words: "Roughly £4M of influenced revenue." Answer slot: if you negotiated or structured commercial terms with partners, say what and which part was yours, in your own words; if you did not, or it was someone else's, say so plainly and stay with the influenced revenue you stated |
| F4 | "Ross will push on commercials" — recruiter's email | "never carried a direct quota, only influenced revenue" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never carried a direct quota." Then the plan, said as a plan and never as a past: how you would learn how the number is set here. Nothing added to make the gap feel smaller |
| F5 | "they sell scheduling software to train operating companies" — your message | "Never sold into rail specifically" — your message | none | [grounded] | capability | A gap you stated. Words: "I've never sold into rail specifically." Then how you would learn it, as a plan. Not a claim to rail selling, and not a claim that bus and light rail planning substitutes for it |

## 5. Graded deliverable: the 15-minute POV

The recruiter's own words: "a short POV on where you'd take our operator partnerships over the next 18 months", "no slides needed, just talk us through it", and "Please land on what it means for the operators themselves." The close is therefore graded. Both interviewers have read the report you read, per the recruiter's attachment, so a recitation of its shortlist is the answer every prepared candidate gives.

**Facts you may build on, at their own scope**

- F1: "took it from 6 partners to 40, roughly £4M of influenced revenue". Use it as your one piece of partnership track record. It is a count of partners growing, so a thesis that argues for fewer partners is a divergence from your own record, and you should say so before Ross does.
- F2: "bus and light rail network planning". Use it for operator-side vocabulary only, never as "I know what train operators need".
- Your reading of the report: not visible to me. The consensus item and its framing come from you.

**Check the term first.** The recruiter wrote "operator partnerships" and then asked you to land on "the operators themselves", so they appear to be partners and not only customers. Spend ten seconds saying how you are reading it and invite correction.

**Three defensible theses (pick one, rehearse its concession)** — all `[generic]` patterns until you test them against the report

| Thesis | The argument | Mandatory concession | What it means for operators (your close) |
|---|---|---|---|
| T1 Fewer, deeper | Concentrate on the small number of operators where Kelverton builds something with them, and decline the rest | You cannot see operator appetite or capacity from outside, and depth raises dependence on a few accounts. It runs against a record that grew by partner count (F1), so say that | The operators in the deep set shape direction and carry more of the working load; those outside get less attention, and you should say that plainly |
| T2 Operator outcomes as the unit | Define each partnership by an outcome the operator would recognise, agreed up front and reviewed against it | You do not yet know which outcomes Kelverton can evidence; the first 90 days would settle that | The operator is asked to commit to an outcome as well as being offered a service; name what it costs them |
| T3 Partnerships as a rollout path | If adoption cost or risk is what slows operators, use third parties to lower it, as an extension of the channel work in F1 | A conditional: it depends on whether operators have, or tolerate, third-party integrators, which you would check before proposing. The F1 channel was ISV partners at a payments company, not rail | The operator gets a lower-effort path to adopt; name who carries the risk if it goes wrong |

**Differentiation.** Open with one item from the report to show grounding (your pick, from your own reading). Then give one thesis-driven divergence from the report's emphasis, with your reason. Then give an anti-pick, one thing you would say no to; the role includes saying no, and a POV with no refusal reads as a wishlist. A candidate anti-pick: a goal measured by partner count alone, which ties directly to F1.

**Structure and timing (15 minutes)**

1. 1:30 framing and your reading of "operator partnerships".
2. 3:00 starting position: the consensus item, then where you diverge.
3. 6:00 the thesis, its concession, the anti-pick.
4. 3:00 what it means for the operators themselves: what changes for them, what it costs them, what they can say no to.
5. 1:30 what you would test first and where you are least sure.

Do not read the structure out. Say the numbers of minutes to yourself while rehearsing, not in the room.

## Persona table

| Persona | How it shows up here | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Deepa, VP Partnerships and your future manager, probing the POV and live problems from her own roadmap | Highest, 5 questions. Panels blend the top two personas of each member's relationship; a future manager's relationship prior is Case/Strategist plus Skeptic, and the first 15 minutes of the session are a strategy deliverable | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Data-Driven Prober | Ross, Commercial Director: "Ross will push on commercials", and the only headline numbers in your material are F1's | Highest, 5 questions. The recruiter's words, not a public profile, are the signal; no interviewer profile was available | Know what you can and cannot say about how each figure was counted; say plainly when you do not know |
| Skeptic | Either of them, on the two gaps you named: rail and quota (F4, F5) | Mid, 3 questions. The gaps are the likeliest place a second round probes, and the one predictable objection sits here | Rehearse the objection until it is boring; bridges only from what you stated |
| Pressure / Stress | Ross, time-boxed or devil's-advocate on commercials | Mid, 3 questions. Follows the recruiter's description of Ross; the register is a guess from that one sentence | Pause, restate, anchor in what you stated, hold through two follow-ups before conceding anything real |
| Conversational / Rapport | Opening biography question, closing chat | Low, 2 questions. Always occurs, rarely decides, but a casual question is still scored | A 90-second arc; treat casual questions as scored |
| Values / Behavioral | A behavioral probe on how you deal with partners or leadership | Low, 2 questions. No loop source documents a values round and no published values were available, so none is detected; these are open prompts from standard stems | Selection scaffolds with an honest branch |
| Peer Evaluator | Not banked: neither panelist is described as a peer | None | Reverse question R5 covers the seam with Ross |

## Question banks

### A. Case/Strategist (Deepa, and the POV Q&A) — weight 5

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "If you could only do one thing in your first six months, what would it be and what would it displace?" | CASE | [generic] | Name the one move from your chosen thesis, then what it displaces, which is your anti-pick said out loud. Close with how you would know it was working. The question needs no claim about your past, so the guidance makes none | Tests whether the POV collapses into a single decision. CASE because it is a live prioritisation; follows from the POV the recruiter announced |
| A2 | "Which operator relationship would you deepen first, and which would you stop investing in? How would you decide without our data?" | CASE | [generic] | Say what you would ask for first, then the two or three criteria you would use, stated as your approach for this role. Name the data you would need and say what you would do in its absence. Do not describe tiering as something you have done | Forces the clarify-before-structure move that Case interviewers score. Without Kelverton's data, the honest answer is a method and its limits |
| A3 | "Where do you see the operators under most pressure over the next 18 months, and what does that change for us?" | CO | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Use the report's own framing where it helps, since the panel has read it. If you add a view from your own planning background, state it at the quote's scope: bus and light rail network planning. Answer slot: if you can say where heavy rail operators differ, say so in your own words; if you cannot, say so plainly and say what you would ask | F2 is the only row that reaches the operator world, and it is a bridge, not an equivalence. CO because it tests altitude on the company's customers; no strategy research ran, so this is not grounded in Kelverton's strategy |
| A4 | "What would you want to know in your first 30 days that we haven't told you today?" | JD | [generic] | List three things you would want to learn, in the order you would ask, with the reason each changes your plan. Include how a partnership number is set here (F4) and where operators differ from the bus and light rail you know (F2). Said as questions you would ask, not as things you know | A friendly-sounding probe that scores humility and prioritisation; JD because it tests the role's ramp |
| A5 | "What would make you abandon your POV at month six?" | CASE | [generic] | Name one signal that would make you drop or change the thesis, say what you would do instead, and concede plainly what you cannot know from outside. Do not defend the thesis past what you can support | Tests whether the thesis is falsifiable; the hold-then-concede shape applies even in a friendly register |

### B. Data-Driven Prober (Ross) — weight 5

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the £4M of influenced revenue was counted." | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Say the sentence, then answer the four slots in your own words: how the figure was counted, what it is sensitive to, the assumption you would defend least, which part was yours. Answer slot: if you do not know how it was counted, say so plainly. Keep the word "influenced" every time; do not let it become "generated" or "closed" | F3 is where Ross will press, and the figure is the only number in your material. EXP because it tests whether the claim survives scrutiny |
| B2 | "What does '40 partners' mean in your count: signed, live or producing?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Answer the definition in your own words. Answer slot: if the figure meant signed, say so; if you do not know how the split looked, say so plainly. Do not offer a split you cannot repeat under a second question | A count is the easiest figure to inflate by definition, so the probe goes straight there |
| B3 | "How much of the 6-to-40 was actually you?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel"; "took it from 6 partners to 40, roughly £4M of influenced revenue" | Start from what your own words say: you were running the ISV channel and took it from 6 partners to 40. Answer slot: if others contributed, name who and what; if the work was yours alone, say so. Then stop; do not enlarge the verb | Attribution probe; the verb in the quote is "running" and "took it", and the answer holds at that scope |
| B4 | "How would you set a number for an operator partnership channel, and defend it to me?" | JD | [grounded] "never carried a direct quota, only influenced revenue" | Open with the plain acknowledgment: "I've never carried a direct quota." Then give your method as a method, not a past: what you would ask, what you would want to see, what you would put in front of Ross to be challenged. Say what you do not know about this channel | F4 is the stated gap and Ross is the person who will test it. The answer is candour, then structure |
| B5 | "Walk me through the commercial structure you'd propose for an operator partnership: who pays whom, for what?" | CASE | [generic] | The recruiter named commercials as Ross's push, so expect this. Ask what the partnership is for before proposing terms; offer two structures as options with a trade-off each; say what you would test. Answer slot: if you have negotiated or structured partner commercial terms, say what and which part was yours, in your own words; if you have not, say so plainly and describe how you would decide | F3 is a discovery row, so the honest answer has two branches. CASE because it is a live design problem; it presupposes nothing about your past |

### C. Skeptic (either panelist) — weight 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've never sold into rail and you've never carried a quota. Why should we hire you for this?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue" | **The highest-ROI prep in this pack.** Hold: "I've never sold into rail specifically, and I've never carried a direct quota." Then the two quotes at their scope: "For the last 4 years I was at a payments company running the ISV channel", and "Before that, 5 years in transport consulting, in bus and light rail network planning." The limit named before they ask: the material says bus and light rail, not train operating companies, and influenced revenue, not quota; say those two limits yourself. Follow-up 1, "so why you": return to the two quotes, add nothing. Follow-up 2, "a quota is different from influence": concede it specifically, "That's a real difference and I haven't carried one", and do not defend it. Follow-up 3, "how would you close it": give the plan, as a plan: what you would ask for in the first 30 days, who you would ask. Never say the gap does not matter | F4 and F5 are both stated negatives, and a panel that includes a Commercial Director will ask this in some form. JD because it tests the stated job against the gap; Skeptic because it is cross-examination of the background |
| C2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue" | Pick one of the two gaps you already stated and say plainly which is the larger, in your own words. Then one sentence on how you would close it, said as a plan. Do not choose a gap you do not have | A stem the Skeptic asks to see whether you will pick the true gap or a safe one |
| C3 | "Your background is bus and light rail planning. How much of that carries to train operators?" | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Say what the quote says: 5 years in transport consulting, in bus and light rail network planning. Answer slot: if you know where it carries and where it does not, say so in your own words; if you do not know, say so plainly and say what you would ask. Do not use "from the other side" to claim knowledge of what operators need | F2 is a bridge, not an equivalence; this is the probe that checks it |

### D. Pressure / Stress (Ross) — weight 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has sold into rail?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel"; "took it from 6 partners to 40, roughly £4M of influenced revenue"; "Never sold into rail specifically and never carried a direct quota, only influenced revenue" | Hold-then-concede in sixty seconds: the two track-record quotes at their scope, then concede "I haven't sold into rail." Do not claim to be better; say what you bring and what you lack. If pushed twice, return to the same two quotes | A stem from the Pressure persona; F5 is the stated gap. The test is composure, not content |
| D2 | "Influenced revenue is not revenue you carried. Why should that count for a commercial role?" | EXP | [grounded] "roughly £4M of influenced revenue"; "never carried a direct quota, only influenced revenue" | Concede the distinction in one sentence, "That's right, I haven't carried a direct quota", then hold on what the quote carries: roughly £4M of influenced revenue. Answer slot: if you can say which part of it was yours and how it was counted, say so in your own words; if you do not know, say so plainly. Do not rename influenced as sourced or closed | F3 and F4 meet here. Pressure because it is a challenge to the core claim; the structure is concession on the stated gap, hold on the stated evidence |
| D3 | "Suppose an operator partnership takes twelve months to produce anything measurable. Would you back it?" | CASE | [generic] | Say what you would need to know first, then give a position and a condition under which you would change it. Concede what you cannot judge without data. No claim about your past is needed or made | Tests holding a position under time pressure with a commercial edge |

### E. Conversational / Rapport (Deepa) — weight 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey: consulting, partnerships, and why Kelverton?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | A 90-second arc with only the beats the quotes carry: 5 years in transport consulting, in bus and light rail network planning, then 9 years in partnerships, the last 4 at a payments company running the ISV channel. Answer slot: give your own reason for the move toward rail operators, in your own words; none is stated in your material | The most likely first question after the POV. EXP because it tests whether the story hangs together |
| E2 | "What do you make of how operators plan their timetables and resources today?" | CO | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Network planning is the quote's scope, and the pack does not equate it with scheduling. Answer slot: if you have looked at how operators schedule, say what you saw, in your own words; if you have not, say so plainly and say what you would ask first | Casual register, topical for a company that sells scheduling software per your message. It is still scored |

### F. Values / Behavioral — weight 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you delivered an unpopular truth to a partner or to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not back down, and a relationship that was intact at the end. No sentence in your material speaks to this, so the pack supplies no story. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioral stem; no values round is documented, so this is insurance |
| F2 | "Tell me about a time you put a partner's interest ahead of an internal metric." | VAL | [generic] | Same scaffold, with the stake named in the partner's terms. This mirrors the recruiter's ask to land on what it means for operators, which is why it is here. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The recruiter's instruction to land on operators suggests a partner-first value; the question is generic until the company's own values are known |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| A POV on operator partnerships over 18 months | Section 5; A1, A2, A5 |
| Land on what it means for the operators themselves | Section 5 close; A3, F2, E2 |
| Ross will push on commercials | B1, B2, B3, B4, B5, D2 |
| Carrying a number (stated gap, F4) | B4, C1, D2 |
| Rail domain (stated gap, F5) | C1, C2, C3, D1, E2 |
| Track record in partnerships (F1) | B1, B2, B3, E1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would make the first 90 days a clear success for you, Deepa?" | Your future manager answers in her own terms, and you learn what you would be measured against |
| R2 | "Which operator partnership do you consider strongest today, and which worries you most?" | It shows you think in operator terms and gives you something to test your POV against |
| R3 | "How do you judge a partnership commercially, Ross: what's the first number you look at?" | It turns his push on commercials into a conversation, and it matters because of F4 |
| R4 | "Does this role carry a direct number, or does it contribute to the commercial team's?" | It addresses the quota gap directly and honestly, and the answer decides how much of C1 and D2 you will face |
| R5 | "Where does partnerships end and the commercial team begin on an operator account?" | Seam question for Ross; it proposes you think in principles for the boundary, not turf |
| R6 | "What would you push back on in what I said today?" | Invites correction of the POV and shows you are testing it, not defending it |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Carried or owned a revenue number | Inflated form of F3; F4 states the absence | "roughly £4M of influenced revenue" at its own scope; the plain acknowledgment F4 gives, "I've never carried a direct quota" |
| Sold into rail, or knows what train operators need | F5 is a stated negative; inflated form of F2 | The plain acknowledgment F5 gives, "I've never sold into rail specifically"; F2's quote, "bus and light rail network planning", at its own scope. The pack's observation: the material says bus and light rail, not train operating companies |
| Built or grew the partner programme from nothing | Inflated form of F1 | "running the ISV channel" and "took it from 6 partners to 40", at their own scope |
| Partners closed or generated the £4M | Inflated form of F3 | "influenced revenue" every time |
| Negotiated or structured commercial terms | The material is silent on it, so it is an answer slot (F3, B5), not a claim | Answered only by you, in your own words, or not at all |

## Sources

Provided: your message (background, round details, the recruiter's email as you quoted it). The attached market report was not available to me and was not read.

Research tier: L1 — searches 6 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Query "Kelverton Rail values": refused. Would have moved a values cheat sheet and VAL themes, if a values round were documented |
| 2. Kelverton Rail interview process | unavailable | Query "Kelverton Rail interview process partnerships": refused. The recruiter's own words establish this session's shape, so the loop does not rest on an archetype, but wider loop facts are missing |
| 3. Kelverton Rail strategy and recent news | unavailable | Query "Kelverton Rail scheduling software train operating companies news strategy": refused. The report you attached is not in my context, so it cannot stand in. Would have moved A3, E2 and a grounding brief |
| 4. Interviewer names | unavailable | Queries "Deepa VP Partnerships Kelverton Rail" and "Ross Commercial Director Kelverton Rail": both refused. The interviewer read is absent and persona weights rest on the recruiter's description |
| 5. Representative Senior Partnerships Manager JD | unavailable | Query "Senior Partnerships Manager rail technology scheduling software job description": refused. The fit snapshot rests on the recruiter's words, so JD-derived rows are thinner than they would be |

## Upgrade menu

- The JD text → F1 to F5 and the coverage table move from the recruiter's words to the JD's own lines, and JD-tagged questions become fuller
- The market report's executive summary or its shortlist, pasted → a grounding brief, the consensus item for the POV opening, and A3 grounded in what the panel has read
- Search permission, then a retry of the six refused L1 searches → company values, loop facts, current strategy, interviewer footprints, a representative JD
- A deeper research pass, up to 6 more searches and 2 more fetches and several more minutes, once search works → a strategy brief, interviewer talks and writing, recent organisation context
- Ask the recruiter whether the role carries a direct number → settles how hard B4, C1 and D2 will be; usually one email
- The partner-attributed pipeline report or CRM export behind the £4M → F1 and F3 move from medium and low toward high, and B1 to B3 become answerable from an artifact
- The interviewers' public profile text, pasted → an interviewer read and a reverse question tied to their own paths
- A tuesday-dossier.md from an earlier engagement → verified evidence, per-gap strategies and a recorded prohibited-claims list, for later sessions; never a precondition for this pack
