# Interview prep pack: Senior Partnerships Manager, Kelverton Rail

Round: second round, one 60-minute panel. Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). First 15 minutes: your POV on where you'd take operator partnerships over the next 18 months, no slides, landing on what it means for the operators themselves. Remaining 45 minutes: Q&A, with Ross pushing on commercials.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and where a cell says answer slot, the answer has to come from what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether your CV claims survive scrutiny, and what was actually yours |
| JD | The stated role requirements, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem from the actual role |

Provenance labels: `[grounded]` rests on something you or the recruiter said, `[inferred]` is derived from an adjacent source, `[generic]` is a role-family pattern with no claim about Kelverton or you. Web search was not permitted in this session, so everything about Kelverton itself rests on the recruiter's email as you quoted it, and the question banks that need company facts are labelled generic. The market report text was not in this conversation and is not used.

## Prep triage (about 4 hours)

| Order | Time | Do this | Where |
|---|---|---|---|
| 1 | 90 min | Build the 15-minute POV: pick one thesis, write the running order, speak it aloud twice against a timer | Graded deliverable below |
| 2 | 30 min | Re-read the market report with one job: pick the consensus item you will cite and the one you will diverge from | Graded deliverable below |
| 3 | 30 min | Rehearse the rail gap and the quota gap until they are boring | B1, B4, D1 |
| 4 | 30 min | Write down, for your own use only, what you know and don't know about how the £4M was counted | C1, C2, D2 |
| 5 | 15 min | Choose three reverse questions | Reverse questions |
| 6 | 45 min | One full run: 15-minute POV, then someone throws A1, C3, C4, D3 at you | All of the above |

Everything else is insurance.

## Fit snapshot

No JD was supplied, so requirements are the recruiter's own words as you quoted them, or the role title, quoted from your message. Three rows rest on three of your sentences:

- S1: "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue."
- S2: "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)."
- S3: "Never sold into rail specifically and never carried a direct quota, only influenced revenue."

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" — recruiter email | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [grounded] | transferability | Your sentence carries running the ISV channel and its growth from 6 partners to 40. The pack's observation is that it says channel partners at a payments company, not operators as partners. Words at that scope: "I ran the ISV channel at a payments company and took it from 6 partners to 40." Answer slot: the brief puts operator partnerships at the centre, so expect a probe on how a channel of software partners compares with partnering with operators. If you see a real link, say what it is, in your own words; if you do not, say so plainly and stay with the channel you ran |
| F2 | "Please land on what it means for the operators themselves." — recruiter email | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." — your message | medium | [grounded] | transferability | Your sentence carries five years of transport consulting in bus and light rail network planning, plus your own phrase about the operator world. The pack's observation is that it does not say which operators, whether any ran trains on heavy rail, or what "the other side" is, so the phrase stays yours and unextended. Words: "For five years I did transport consulting, in bus and light rail network planning." Answer slot: the brief asks you to land on operators, so expect a probe on what rail operators care about. If you know how they differ from bus and light rail operators, say how, in your own words; if you do not, say so plainly and return to the network planning work |
| F3 | "Ross will push on commercials" — recruiter email; this row covers the £4M figure | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [grounded] | transferability | The figure stays at its own scope: roughly £4M of influenced revenue, never sourced, closed or generated. Words: "Roughly £4M of influenced revenue." Answer slot: expect the four probes a figure raises. Say how it was counted, what it is most sensitive to, the assumption behind it you would defend least, and which part was yours, each in your own words. Your sentence does not say over what period the £4M accrued, so say that only as you know it; if you do not know how it was counted, say that plainly |
| F4 | "Ross will push on commercials" — recruiter email; this row covers carrying a number | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never carried a direct quota; my number was influenced revenue." Then how you would approach being accountable for a number, said as a plan in your own words and never as a past. Nothing added to make the gap feel smaller, and no deal, target or figure attributed to you beyond F3's |
| F5 | Experience selling into rail, written as plain prose because no JD was supplied | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [generic] | capability | You stated this one. Words: "I've never sold into rail specifically." Then how you would learn it, as a plan. The pack's observation is that the recruiter's brief makes this the likeliest objection, so B1 is the deepest rehearsal |
| F6 | "Senior Partnerships Manager" — your message, the role title, no JD supplied | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [grounded] | none | No gap in how the quote reads: it already names partnerships, the channel and its growth in role-relevant terms. It is a line with nothing inspected behind it, so expect the probe on the figure (F3). Lead with the partner count in the quote's own terms, 6 to 40, because a named count beats an adjective |

No requirement in your material is a gate: nothing you quoted from the recruiter names a licence, location, pay or similar term.

## Graded deliverable: the 15-minute POV

The recruiter declared this one, so it is graded before the Q&A starts. Facts to build on, from the recruiter's email as you quoted it: 15 minutes, no slides, "just talk us through it", scope "where you'd take our operator partnerships over the next 18 months", and the close "what it means for the operators themselves". Facts about you: F1 and "took it from 6 partners to 40" (S1), F2 and "bus and light rail network planning" (S2), F4 and "only influenced revenue" (S3).

### Two things to settle in the first minute

- Say how you are reading "operator partnerships". The phrase could mean Kelverton's relationships with the train operators it serves, or partners built around those operators. Name your reading aloud and invite correction. This is a scoping move and costs nothing.
- Treat your channel experience as a lens you are testing, not a credential you are importing. S1 says channel partners at a payments company.

### Three theses, each with the concession you must make

These are role-family options, labelled generic: check each against the report before choosing.

| Thesis | The argument in one line | Mandatory concession | Why it may suit you |
|---|---|---|---|
| T1 Depth before breadth | Spend the 18 months making fewer operator relationships work end to end, each with a shared outcome plan | It is slower to cover the market, and it concentrates risk in a few operators | Ross hears accountability, and it does not lean on experience you don't have |
| T2 Operator voice in the roadmap | Give a small set of operators a structured say in what gets built, in return for commitment | Without a commercial price it becomes roadmap capture, so the operator must give something concrete back | Deepa hears a partnerships role that shapes product, and Ross hears the price of it |
| T3 An ecosystem around the operator | Bring adjacent partners in so operators get a connected workflow | Your channel experience is S1's payments ISV channel, not rail, and operators may not want more vendors to manage | It is the thesis closest to S1, which is also why it is the riskiest to over-claim |

### Differentiation against the report

The report went to every prepared candidate and to the panel, so reciting its shortlist scores as homework. Do three things in order:

1. Cite one report item as your consensus point, to show you read it. Take it from the report, since this pack could not see it.
2. State one place where your thesis diverges from the report, with your reason.
3. Give one anti-pick: something you would say no to in the 18 months. Options, labelled generic: chasing operator count for its own sake, building a broad marketplace before the first relationships work, or bespoke work for a single operator. Choose the one you can defend, and concede what saying no costs.

If the report's headline is an ecosystem or channel play, make T1 or T2 your divergence and say why. If it is depth-led, T3 may be the divergence.

### Running order

| Time | Beat |
|---|---|
| 0:00 to 1:00 | Frame: your reading of "operator partnerships", what you are assuming, what you do not know |
| 1:00 to 3:00 | Consensus item from the report, and why it holds |
| 3:00 to 8:00 | Your thesis and the three-stage shape of the 18 months, with the stages in your own words |
| 8:00 to 10:30 | Divergence, anti-pick and the concession it costs |
| 10:30 to 14:30 | The landing, what it means for the operators themselves |
| 14:30 to 15:00 | One thing you would need to learn first, then hand over to Q&A |

### The landing the recruiter asked for

End on the operator, as a person in a job. Name the role at the operator you are talking about, say what changes for them at month 6 and at month 18, say what they are asked to give (time, data or commitment), and say how they would tell it is working. Draw the pain points from the report, not from this pack: nothing here knows what Kelverton's operators struggle with. If you say "I know the operator world from the other side", keep it at S2's scope and be ready for a probe on rail.

## Persona table

The recruiter's email establishes the loop: one 60-minute panel, a 15-minute POV, then Q&A. The weights follow the panel's two members, blending the top two personas of each relationship, and no archetype fallback is needed.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (A) | Deepa, your future manager, probes the POV and sets live operator problems | High. The first 15 minutes are a strategy deliverable, and a hiring manager is buying capability | Clarify, objective, segmentation, approach, metrics, risks; challenge one premise respectfully |
| Skeptic (B) | The rail and quota gaps (F4, F5) return in several packagings | High. Both gaps are ones you stated, and the recruiter's email makes commercials a focus | Rehearse B1 until it is boring; say the plain acknowledgment first, then only what your sentences carry |
| Data-Driven Prober (C) | Ross takes the £4M and the 6 to 40 apart | High. "Ross will push on commercials" is the recruiter's own warning | Know what you can and cannot say about how the number was counted, and say plainly when you do not know |
| Pressure (D) | Ross or Deepa time-box you and ask how much was actually you | Medium. A commercial director on a two-person panel often tests composure on the number | Pause, restate, hold through two follow-ups, concede specifically |
| Conversational (E) | The opening of the Q&A, "walk me through the journey" | Medium. It is a common opener and still scored | Prepare a 90-second arc from your own sentences |
| Peer Evaluator | Not drilled | Low. Only Deepa and Ross are named, and neither is a peer | None needed |
| Values/Behavioural | Not drilled | Low. The recruiter named no values round, and the company's published values could not be researched | If it arrives, use the selection scaffold in B3 |

## Question banks

### A. Case/Strategist (Deepa), weight high

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Take one operator we serve. What do you need to know before you tell us how to approach them over the next 18 months?" | CASE | [generic] | The question needs no claim about your past, so the guidance makes none. Clarify first: who at the operator, what they buy and how, where the relationship stands today, and what Kelverton wants from it. Then objective, segments, approach, metrics, risks, thinking aloud. Challenge one premise politely | The live version of the POV, so a rehearsed structure is reusable in both halves of the session; CASE because it scores structure |
| A2 | "Two operators want conflicting things from our roadmap. What do you do?" | CASE | [generic] | Structure it: what you ask each of them first, who decides inside Kelverton, how both stay informed, what you record. No claim about your past | Partnership roles live on this seam, and it tests judgment without leaning on rail knowledge; CASE because it is a live decision |
| A3 | "Who do operators turn to instead of us, and why would they stay with us?" | CO | [generic] | Name alternatives only from the report or what you can verify, and where you do not know, say so plainly and say what you would look at. It is a knowledge probe and makes no claim about your history | Research could not run, so this CO question is generic rather than grounded in Kelverton's strategy; CO because it scores homework depth |
| A4 | "How would you carry what you did with the ISV channel into operator partnerships, and where would it not carry over?" | JD | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Story-mapped on F1: you ran the ISV channel at a payments company and took it from 6 partners to 40, told in your own words. Answer slot: the question asks where the lesson transfers. If you see a real link between channel partners and operators, say what it is and why; if you do not, say so plainly and stay with the channel's own scope. Make your own concession on where it does not carry over before they do | F1 is the thin point between your experience and the brief; JD because it scores the stated focus on operator partnerships |
| A5 | "What would you say no to in the first year?" | CASE | [generic] | Pick one anti-pick from the deliverable section and give the criterion that rules it out, then what saying no costs. The guidance asserts nothing about your past | The role's real job includes refusing work, and the POV asks for the same judgment; CASE because it is a decision under constraint |

### B. Skeptic, weight high

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't sold into rail. Why would operators take your call?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." and "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | The highest-ROI rehearsal in this pack, the single likeliest objection, so it gets the most levels. Hold: say the plain acknowledgment first, "I've never sold into rail specifically." Then what S2 carries, at its scope: five years of transport consulting in bus and light rail network planning. First follow-up, "that isn't rail": concede only what the sentence concedes, that it was bus and light rail. Second follow-up: return to the plan for learning rail, in your own words. Answer slot: if you know how rail operators differ from the ones you worked with, say how; if you do not, say so plainly and return to the network planning work. Never extend "the other side" beyond your own phrase | F4 and F5 are the stated gaps and F2 is the adjacent evidence; JD because it scores a requirement, and the Skeptic persona because it presses on the gap |
| B2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Name it before they do. Your own list from your own sentence: "I've never sold into rail specifically" and "I've never carried a direct quota". Then, for each, your plan in your own words. Answer slot: if there is a third weakness you know about, say it plainly; if there is not, do not manufacture one | F4 and F5; JD because it asks for self-assessment against the role |
| B3 | "Why are you moving from payments partnerships into rail technology?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Selection scaffold, since your material does not carry your reasons. The answer needs a specific pull toward operators and toward this company, drawn from the report and your own experience, and no complaint about the past. If no specific reason comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle the transition. Your reason is yours to give and this pack will not write it | F6 frames the move; EXP because it tests consistency of motivation with your story; it doubles as the fallback if a values question arrives |
| B4 | "You've only carried influence, never a number. Are you ready to be accountable for one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Hold-then-concede. Open with the plain acknowledgment: "I've never carried a direct quota; my number was influenced revenue." Hold through two follow-ups by returning to that sentence rather than adding to it. Then say, in your own words, what you would want agreed about how a number is set and counted before you commit, and what you would do in the first stretch to earn the right to carry one. Answer slot: if you have been accountable for anything you would count as a number, say exactly what; if not, say so plainly | F4 is the second most predictable objection and Ross's natural line; JD because it scores a stated commercial emphasis |
| B5 | "Operators are demanding on scheduling. What do you actually know about how they run a timetable?" | CO | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Say only what you know, at S2's scope: five years in bus and light rail network planning. Answer slot: if some of what you know about running a timetable applies to rail, say which part and how; if you do not know, say so plainly and say how you would learn it in the first month | F2; CO because it scores how deep your domain knowledge goes, with the Skeptic's edge |

### C. Data-Driven Prober (Ross), weight high

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the £4M was counted." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Defend-the-number. Say how it was counted, what it is most sensitive to, the assumption you would defend least, and which part was yours, each in your own words. Name the weakest assumption before he does; it converts a gotcha into credibility. If you do not know how a piece was counted, say so plainly. The word is influenced, not sourced or closed | F3 is the headline figure and the likeliest target for the commercial director; EXP because it tests attribution |
| C2 | "You went from 6 partners to 40. What part of that was you?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Answer slot: say which of those partners you brought in yourself and which came another way, and what the 6 and the 40 were counting, in your own words. If part of the growth was not yours, say so plainly and return to what S1 says you did, running the ISV channel. Do not add a process or a team that your sentence does not state | F6 and F3; EXP because it tests attribution on the second headline number |
| C3 | "How would you think about the commercial model of an operator partnership: who pays, who earns, what does Kelverton give up?" | CASE | [generic] | The guidance claims nothing about your past. Clarify what kind of partnership it is, then who captures value, what terms Kelverton would be exposed to, and how you would know it was working. Concede what you cannot know about Kelverton's actual terms and ask. Ross pushes on commercials, so a visible structure beats a figure | The recruiter's own warning; CASE because it is a live commercial problem. Generic because no commercial facts about Kelverton were available |
| C4 | "Give me one number you would want us to hold you to at month 18." | CASE | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Propose one number and the leading indicator behind it, then concede in the same breath what you would want agreed on how it is counted, since your own number has been influenced revenue. The number is a proposal for the future and no claim about your past. Do not offer a target figure you cannot defend | F4 meets Ross's brief; CASE because it asks you to commit to a measure |

### D. Pressure, weight medium

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has sold into rail?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." and "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Pause, restate, then hold. Start with the acknowledgment, "I've never sold into rail specifically." Then what S1 carries, at its scope, in your own words. Do not claim you are better; say what you would bring and what you would have to learn. Hold through one push, concede specifically, and do not fold on the core | The Pressure version of B1; JD because it scores the gap, with composure as what is actually scored |
| D2 | "That £4M. How much of it was actually you?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Hold then concede: "roughly £4M of influenced revenue" is the claim, and the word is influenced. Answer slot: say which part of it was yours and which was not, in your own words; if you cannot separate them, say so plainly. Concede that influence is not ownership before they do | F3 under pressure; EXP because it is the attribution probe |
| D3 | "Isn't your POV just a rehash of the report?" | CASE | [generic] | Concede the overlap openly: you cited one report item on purpose. Then name the one place you diverge and your reason, and the anti-pick. The guidance asserts nothing about your past | The POV's differentiation tested live; CASE because it is a challenge to reasoning |

### E. Conversational, weight medium

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through the journey, from network planning to partnerships to us." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." and "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | A 90-second arc with the beats your sentences state: five years of transport consulting in bus and light rail network planning, then nine years in partnerships, the last four running the ISV channel at a payments company. The last beat, why this role, is yours to give in your own words; this pack does not write it | F1 and F2; EXP because it tests the story's coherence; opening questions are scored even when they feel casual |
| E2 | "What do you know about us, and what would you want to find out?" | CO | [generic] | Pick two or three things from the report you can speak to with confidence, and one thing you would want to learn from the panel. The guidance claims nothing about your history | Research could not run, so this is generic; CO because it scores homework depth |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "where you'd take our operator partnerships over the next 18 months" | POV deliverable, A1, A2, A4, A5 |
| "Please land on what it means for the operators themselves." | POV landing, A1, B5 |
| "Ross will push on commercials" (the figure) | C1, C2, D2 |
| "Ross will push on commercials" (carrying a number) | B4, C3, C4 |
| Experience selling into rail | B1, B2, D1 |
| "Senior Partnerships Manager" | A4, B3, E1 |
| Company and competitor knowledge | A3, E2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would your operators say is the best thing about working with Kelverton today, and the one thing they'd change?" | Puts operators at the centre, which is where the brief told you to land, and gets the panel to say what it hears |
| R2 | "At month 18, what would make you say this hire was the right call, and which number would you look at first?" | Ross can answer it with a figure, and your answer to C4 shows you were listening |
| R3 | "How does partnership revenue get counted here, and what would be attributed to the person in this role?" | Settles the one thing your material cannot (F4) in a commercial director's own language |
| R4 | "Where is the seam between partnerships and the account or sales teams, and what happens when they disagree?" | Shows you think about the internal path to an operator, not only the operator |
| R5 | "What's the hardest conversation you've had with an operator recently, as far as you can share it?" | Invites a real story, and your next question follows from the answer |
| R6 | "What did you hope a POV from this role would show that most candidates miss?" | Signals you treated the first 15 minutes as an assignment, and tells you how to follow up |

## Prohibited claims

What this pack will not coach, and the honest form of each.

| Not coached | Basis | Honest form |
|---|---|---|
| Having sold into rail, or having rail operator experience | Negative you stated, S3 | "I've never sold into rail specifically." Then a plan, said as a plan. No slot |
| Having carried a quota or direct revenue number | Negative you stated, S3 | "I've never carried a direct quota; my number was influenced revenue." No slot |
| Sourced, closed or generated £4M | Inflated form of F3 | "Roughly £4M of influenced revenue." The limit is the pack's observation, not words for you. Slots stay inside what the sentence says |
| Knowing heavy-rail operations or how rail operators work | Inflated form of F2 | "Bus and light rail network planning." The pack's observation: the sentence says bus and light rail, nothing on heavy rail. B5's slot stays inside that scope |
| Having worked for or advised train operators | Inflated form of F2 | The quote at its own scope, with "the other side" left as your phrase. The pack's observation: the sentence does not say whom you worked with |
| Having built or run partnerships with operators | Inflated form of F1 | "I ran the ISV channel at a payments company." The pack's observation: the sentence carries channel partners, not operators |

## Sources

Provided: your message, including your background and the recruiter's email as you quoted it. The market report you mentioned was not in this conversation, so no part of this pack uses it. No dossier was present.

Research tier: L1 attempted, searches 6 of 6 sent and all refused, fetches 0 of 2

Queries sent, every one refused:

- `Kelverton Rail values` — refused
- `Kelverton Rail interview process partnerships` — refused
- `Kelverton Rail scheduling software train operating companies strategy news` — refused
- `Deepa VP Partnerships Kelverton Rail` — refused
- `Ross Commercial Director Kelverton Rail` — refused
- `Senior Partnerships Manager rail technology job description train operating companies` — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Would have fed a values cheat sheet and VAL questions with the official value names; neither is in this pack |
| 2. `Kelverton Rail interview process partnerships` | unavailable | Would have checked loop structure beyond the recruiter's email; persona weights rest on that email alone |
| 3. `Kelverton Rail` strategy and recent news | unavailable | Would have grounded A3, E2 and C3 in current strategy instead of generic structures |
| 4. `Deepa` and `Ross` with Kelverton Rail | unavailable | Would have produced an interviewer read and tailored reverse questions; both are absent |
| 5. representative `Senior Partnerships Manager` JD | unavailable | Would have given the fit snapshot requirements to quote instead of the recruiter's words |

## Upgrade menu

- The JD text: F1, F2, F5 and F6 requirements become quoted JD lines, and the requirement-coverage table is checked against the posting instead of the recruiter's email
- The market report text, or its main recommendations: fills the consensus slot in the POV, grounds A3, C3 and E2 in something real, and adds a grounding brief
- Your CV, or the artifact behind the £4M such as a partner-attributed revenue report or the programme's reporting: could raise F3 and F6 from medium confidence and sharpens C1 and C2
- The panel's surnames or public profiles: an interviewer read, persona weights read from their public footprint, and a reverse question tied to their own path
- Permission for web search: a research pass at up to 6 searches and 2 fetches, plus a deeper one at up to 6 more and 2 more, taking several more minutes, would supply Kelverton's values, strategy and loop structure
- A short email to the recruiter asking whether the POV and the Q&A are scored separately and whether any competencies or values will be assessed: confirms coverage the pack currently assumes
- A `tuesday-dossier.md` from job-underwriter would add user-confirmed evidence, per-gap strategies and a recorded list of claims not to make
